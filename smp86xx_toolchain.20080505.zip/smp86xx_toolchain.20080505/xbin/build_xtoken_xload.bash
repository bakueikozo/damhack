#!/bin/bash
set -e
#
cat <<EOF
 $0 has changed name , please use build_token_xload.bash instead.

 Sorry for the inconvenience.
EOF

exit -1 

