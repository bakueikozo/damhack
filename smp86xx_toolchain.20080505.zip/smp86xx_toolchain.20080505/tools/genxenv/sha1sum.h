/* sha1sum.h */

void sha1sum(const unsigned char *buffer, size_t n, char sha1[20]);

