/*
 * JFFS3 -- Journalling Flash File System, Version 3.
 *
 * Copyright (C) 2001-2003 Red Hat, Inc.
 *
 * Created by David Woodhouse <dwmw2@infradead.org>
 *
 * For licensing information, see the file 'LICENCE' in this directory.
 *
 * JFFS2 Id: gc.c,v 1.143 2004/11/16 20:36:11 dwmw2  Exp
 * $Id: gc.c,v 3.11 2005/01/21 10:55:42 havasi Exp $
 *
 */

#include <linux/kernel.h>
#include <linux/mtd/mtd.h>
#include <linux/slab.h>
#include <linux/pagemap.h>
#include <linux/crc32.h>
#include <linux/compiler.h>
#include <linux/stat.h>
#include "nodelist.h"
#include "compr.h"
#include "summary.h"

static int jffs3_garbage_collect_pristine(struct jffs3_sb_info *c,
					  struct jffs3_inode_cache *ic,
					  struct jffs3_raw_node_ref *raw);
static int jffs3_garbage_collect_metadata(struct jffs3_sb_info *c, struct jffs3_eraseblock *jeb,
					struct jffs3_inode_info *f, struct jffs3_full_dnode *fd);
static int jffs3_garbage_collect_dirent(struct jffs3_sb_info *c, struct jffs3_eraseblock *jeb,
					struct jffs3_inode_info *f, struct jffs3_full_dirent *fd);
static int jffs3_garbage_collect_deletion_dirent(struct jffs3_sb_info *c, struct jffs3_eraseblock *jeb,
					struct jffs3_inode_info *f, struct jffs3_full_dirent *fd);
static int jffs3_garbage_collect_hole(struct jffs3_sb_info *c, struct jffs3_eraseblock *jeb,
				      struct jffs3_inode_info *f, struct jffs3_full_dnode *fn,
				      uint32_t start, uint32_t end);
static int jffs3_garbage_collect_dnode(struct jffs3_sb_info *c, struct jffs3_eraseblock *jeb,
				       struct jffs3_inode_info *f, struct jffs3_full_dnode *fn,
				       uint32_t start, uint32_t end);
static int jffs3_garbage_collect_live(struct jffs3_sb_info *c,  struct jffs3_eraseblock *jeb,
			       struct jffs3_raw_node_ref *raw, struct jffs3_inode_info *f);

/* Called with erase_completion_lock held */
static struct jffs3_eraseblock *jffs3_find_gc_block(struct jffs3_sb_info *c)
{
	struct jffs3_eraseblock *ret;
	struct list_head *nextlist = NULL;
	int n = jiffies % 128;

	/* Pick an eraseblock to garbage collect next. This is where we'll
	   put the clever wear-levelling algorithms. Eventually.  */
	/* We possibly want to favour the dirtier blocks more when the
	   number of free blocks is low. */
	if (!list_empty(&c->bad_used_list) && c->nr_free_blocks > c->resv_blocks_gcbad) {
		DBG_GC(1, "Picking block from bad_used_list to GC next\n");
		nextlist = &c->bad_used_list;
	} else if (n < 50 && !list_empty(&c->erasable_list)) {
		/* Note that most of them will have gone directly to be erased.
		   So don't favour the erasable_list _too_ much. */
		DBG_GC(1, "Picking block from erasable_list to GC next\n");
		nextlist = &c->erasable_list;
	} else if (n < 110 && !list_empty(&c->very_dirty_list)) {
		/* Most of the time, pick one off the very_dirty list */
		DBG_GC(1, "Picking block from very_dirty_list to GC next\n");
		nextlist = &c->very_dirty_list;
	} else if (n < 126 && !list_empty(&c->dirty_list)) {
		DBG_GC(1, "Picking block from dirty_list to GC next\n");
		nextlist = &c->dirty_list;
	} else if (!list_empty(&c->clean_list)) {
		DBG_GC(1, "Picking block from clean_list to GC next\n");
		nextlist = &c->clean_list;
	} else if (!list_empty(&c->dirty_list)) {
		DBG_GC(1, "Picking block from dirty_list to GC next (clean_list was empty)\n");

		nextlist = &c->dirty_list;
	} else if (!list_empty(&c->very_dirty_list)) {
		DBG_GC(1, "Picking block from very_dirty_list to GC next (clean_list and dirty_list were empty)\n");
		nextlist = &c->very_dirty_list;
	} else if (!list_empty(&c->erasable_list)) {
		DBG_GC(1, "Picking block from erasable_list to GC next (clean_list and {very_,}dirty_list were empty)\n");

		nextlist = &c->erasable_list;
	} else {
		/* Eep. All were empty */
		DBG_GC(1, "No clean, dirty _or_ erasable blocks to GC from! Where are they all?\n");
		return NULL;
	}

	ret = list_entry(nextlist->next, struct jffs3_eraseblock, list);
	list_del(&ret->list);
	c->gcblock = ret;
	ret->gc_node = ret->first_node;
	if (!ret->gc_node) {
		ERROR_MSG("Eep. ret->gc_node for block at %#08x is NULL\n", ret->offset);
		BUG();
	}

	/* Have we accidentally picked a clean block with wasted space ? */
	if (ret->wasted_size) {
		DBG_GC(1, "Converting wasted_size %#08x to dirty_size\n", ret->wasted_size);
		ret->dirty_size += ret->wasted_size;
		c->wasted_size -= ret->wasted_size;
		c->dirty_size += ret->wasted_size;
		ret->wasted_size = 0;
	}

	if (DEBUG2)
		jffs3_dbg_dump_block_lists(c);
	return ret;
}

/* jffs3_garbage_collect_pass
 * Make a single attempt to progress GC. Move one node, and possibly
 * start erasing one eraseblock.
 */
int jffs3_garbage_collect_pass(struct jffs3_sb_info *c)
{
	struct jffs3_inode_info *f;
	struct jffs3_inode_cache *ic;
	struct jffs3_eraseblock *jeb;
	struct jffs3_raw_node_ref *raw;
	int ret = 0, inum, nlink;

	if (down_interruptible(&c->alloc_sem))
		return -EINTR;

	for (;;) {
		spin_lock(&c->erase_completion_lock);
		if (!c->unchecked_size)
			break;

		/* We can't start doing GC yet. We haven't finished checking
		   the node CRCs etc. Do it now. */

		/* checked_ino is protected by the alloc_sem */
		if (c->checked_ino > c->highest_ino) {
			ERROR_MSG("Checked all inodes but still 0x%x bytes of unchecked space?\n",
			       c->unchecked_size);
			if (DEBUG2)
				jffs3_dbg_dump_block_lists(c);
			spin_unlock(&c->erase_completion_lock);
			BUG();
		}

		spin_unlock(&c->erase_completion_lock);

		spin_lock(&c->inocache_lock);

		ic = jffs3_get_ino_cache(c, c->checked_ino++);

		if (!ic) {
			spin_unlock(&c->inocache_lock);
			continue;
		}

		if (!ic->nlink) {
			DBG_GC(1, "Skipping check of ino #%d with nlink zero\n", ic->ino);
			spin_unlock(&c->inocache_lock);
			continue;
		}
		switch(ic->state) {
		case INO_STATE_CHECKEDABSENT:
		case INO_STATE_PRESENT:
			DBG_GC(1, "Skipping ino #%u already checked\n", ic->ino);
			spin_unlock(&c->inocache_lock);
			continue;

		case INO_STATE_GC:
		case INO_STATE_CHECKING:
			ERROR_MSG("Inode #%u is in state %d during CRC check phase!\n", ic->ino, ic->state);
			spin_unlock(&c->inocache_lock);
			BUG();

		case INO_STATE_READING:
			/* We need to wait for it to finish, lest we move on
			   and trigger the BUG() above while we haven't yet
			   finished checking all its nodes */
			DBG_GC(1, "Waiting for ino #%u to finish reading\n", ic->ino);
			up(&c->alloc_sem);
			sleep_on_spinunlock(&c->inocache_wq, &c->inocache_lock);
			return 0;

		default:
			BUG();

		case INO_STATE_UNCHECKED:
			;
		}
		ic->state = INO_STATE_CHECKING;
		spin_unlock(&c->inocache_lock);

		DBG_GC(1, "Triggering inode scan of ino#%u\n", ic->ino);

		ret = jffs3_do_crccheck_inode(c, ic);
		if (ret)
			WARNING_MSG("Returned error for crccheck of ino #%u. Expect badness...\n", ic->ino);

		jffs3_set_inocache_state(c, ic, INO_STATE_CHECKEDABSENT);
		up(&c->alloc_sem);
		return ret;
	}

	/* First, work out which block we're garbage-collecting */
	jeb = c->gcblock;

	if (!jeb)
		jeb = jffs3_find_gc_block(c);

	if (!jeb) {
		DBG_GC(1, "Couldn't find erase block to garbage collect!\n");
		spin_unlock(&c->erase_completion_lock);
		up(&c->alloc_sem);
		return -EIO;
	}

	DBG_GC(1, "GC from block %#08x, used_size %#08x, dirty_size %#08x, free_size %#08x\n",
			jeb->offset, jeb->used_size, jeb->dirty_size, jeb->free_size);

	if (c->nextblock)
		DBG_GC(1, "Nextblock at  %#08x, used_size %#08x, dirty_size %#08x, wasted_size %#08x, free_size %#08x\n",
				c->nextblock->offset, c->nextblock->used_size, c->nextblock->dirty_size,
				c->nextblock->wasted_size, c->nextblock->free_size);

	if (!jeb->used_size) {
		up(&c->alloc_sem);
		goto eraseit;
	}

	raw = jeb->gc_node;

	while(ref_obsolete(raw)) {
		DBG_GC(1, "Node at %#08x is obsolete... skipping\n", ref_offset(raw));
		raw = raw->next_phys;
		if (unlikely(!raw)) {
			ERROR_MSG("Eep. End of raw list while still supposedly nodes to GC\n");
			ERROR_MSG("Erase block at %#08x. free_size %#08x, dirty_size %#08x, used_size %#08x\n",
				       jeb->offset, jeb->free_size, jeb->dirty_size, jeb->used_size);
			jeb->gc_node = raw;
			spin_unlock(&c->erase_completion_lock);
			up(&c->alloc_sem);
			BUG();
		}
	}
	jeb->gc_node = raw;

	DBG_GC(1, "Going to garbage collect node at %#08x\n", ref_offset(raw));

	if (!raw->next_in_ino) {
		/* Inode-less node. Clean marker, snapshot or something like that */
		/* FIXME: If it's something that needs to be copied, including something
		   we don't grok that has JFFS3_NODETYPE_RWCOMPAT_COPY, we should do so */
		spin_unlock(&c->erase_completion_lock);
		jffs3_mark_node_obsolete(c, raw);
		up(&c->alloc_sem);
		goto eraseit_lock;
	}

	ic = jffs3_raw_ref_to_ic(raw);

	/* We need to hold the inocache. Either the erase_completion_lock or
	   the inocache_lock are sufficient; we trade down since the inocache_lock
	   causes less contention. */
	spin_lock(&c->inocache_lock);

	spin_unlock(&c->erase_completion_lock);

	DBG_GC(1, "Collecting from block %#08x. Node %#08x(%d), ino #%u\n",
		jeb->offset, ref_offset(raw), ref_flags(raw), ic->ino);

	/* Three possibilities:
	   1. Inode is already in-core. We must iget it and do proper
	      updating to its fragtree, etc.
	   2. Inode is not in-core, node is REF_PRISTINE. We lock the
	      inocache to prevent a read_inode(), copy the node intact.
	   3. Inode is not in-core, node is not pristine. We must iget()
	      and take the slow path.
	*/

	switch(ic->state) {
	case INO_STATE_CHECKEDABSENT:
		/* It's been checked, but it's not currently in-core.
		   We can just copy any pristine nodes, but have
		   to prevent anyone else from doing read_inode() while
		   we're at it, so we set the state accordingly */
		if (ref_flags(raw) == REF_PRISTINE)
			ic->state = INO_STATE_GC;
		else {
			DBG_GC(1, "Ino #%u is absent but node not REF_PRISTINE. Reading.\n", ic->ino);
		}
		break;

	case INO_STATE_PRESENT:
		/* It's in-core. GC must iget() it. */
		break;

	case INO_STATE_UNCHECKED:
	case INO_STATE_CHECKING:
	case INO_STATE_GC:
		/* Should never happen. We should have finished checking
		   by the time we actually start doing any GC, and since
		   we're holding the alloc_sem, no other garbage collection
		   can happen.
		*/
		ERROR_MSG("Inode #%u already in state %d in jffs3_garbage_collect_pass()!\n",
				ic->ino, ic->state);
		up(&c->alloc_sem);
		spin_unlock(&c->inocache_lock);
		BUG();

	case INO_STATE_READING:
		/* Someone's currently trying to read it. We must wait for
		   them to finish and then go through the full iget() route
		   to do the GC. However, sometimes read_inode() needs to get
		   the alloc_sem() (for marking nodes invalid) so we must
		   drop the alloc_sem before sleeping. */

		up(&c->alloc_sem);
		DBG_GC(1, "Waiting for ino #%u in state %d\n", ic->ino, ic->state);
		sleep_on_spinunlock(&c->inocache_wq, &c->inocache_lock);
		/* And because we dropped the alloc_sem we must start again from the
		   beginning. Ponder chance of livelock here -- we're returning success
		   without actually making any progress.

		   Q: What are the chances that the inode is back in INO_STATE_READING
		   again by the time we next enter this function? And that this happens
		   enough times to cause a real delay?

		   A: Small enough that I don't care :)
		*/
		return 0;
	}

	/* OK. Now if the inode is in state INO_STATE_GC, we are going to copy the
	   node intact, and we don't have to muck about with the fragtree etc.
	   because we know it's not in-core. If it _was_ in-core, we go through
	   all the iget() crap anyway */

	if (ic->state == INO_STATE_GC) {
		spin_unlock(&c->inocache_lock);

		ret = jffs3_garbage_collect_pristine(c, ic, raw);

		spin_lock(&c->inocache_lock);
		ic->state = INO_STATE_CHECKEDABSENT;
		wake_up(&c->inocache_wq);

		if (ret != -EBADFD) {
			spin_unlock(&c->inocache_lock);
			goto release_sem;
		}

		/* Fall through if it wanted us to, with inocache_lock held */
	}

	/* Prevent the fairly unlikely race where the gcblock is
	   entirely obsoleted by the final close of a file which had
	   the only valid nodes in the block, followed by erasure,
	   followed by freeing of the ic because the erased block(s)
	   held _all_ the nodes of that inode.... never been seen but
	   it's vaguely possible. */

	inum = ic->ino;
	nlink = ic->nlink;
	spin_unlock(&c->inocache_lock);

	f = jffs3_gc_fetch_inode(c, inum, nlink);
	if (IS_ERR(f)) {
		ret = PTR_ERR(f);
		goto release_sem;
	}
	if (!f) {
		ret = 0;
		goto release_sem;
	}

	ret = jffs3_garbage_collect_live(c, jeb, raw, f);

	jffs3_gc_release_inode(c, f);

 release_sem:
	up(&c->alloc_sem);

 eraseit_lock:
	/* If we've finished this block, start it erasing */
	spin_lock(&c->erase_completion_lock);

 eraseit:
	if (c->gcblock && !c->gcblock->used_size) {
		DBG_GC(1, "Block at %#08x completely obsoleted by GC. Moving to erase_pending_list\n", c->gcblock->offset);
		/* We're GC'ing an empty block? */
		list_add_tail(&c->gcblock->list, &c->erase_pending_list);
		c->gcblock = NULL;
		c->nr_erasing_blocks++;
		jffs3_erase_pending_trigger(c);
	}
	spin_unlock(&c->erase_completion_lock);

	return ret;
}

static int jffs3_garbage_collect_live(struct jffs3_sb_info *c,  struct jffs3_eraseblock *jeb,
				      struct jffs3_raw_node_ref *raw, struct jffs3_inode_info *f)
{
	struct jffs3_node_frag *frag;
	struct jffs3_full_dnode *fn = NULL;
	struct jffs3_full_dirent *fd;
	uint32_t start = 0, end = 0, nrfrags = 0;
	int ret = 0;

	down(&f->sem);

	/* Now we have the lock for this inode. Check that it's still the one at the head
	   of the list. */

	spin_lock(&c->erase_completion_lock);

	if (c->gcblock != jeb) {
		spin_unlock(&c->erase_completion_lock);
		DBG_GC(1, "GC block is no longer gcblock. Restart\n");
		goto upnout;
	}
	if (ref_obsolete(raw)) {
		spin_unlock(&c->erase_completion_lock);
		DBG_GC(1, "node to be GC'd was obsoleted in the meantime.\n");
		/* They'll call again */
		goto upnout;
	}
	spin_unlock(&c->erase_completion_lock);

	/* OK. Looks safe. And nobody can get us now because we have the semaphore. Move the block */
	if (f->metadata && f->metadata->raw == raw) {
		fn = f->metadata;
		ret = jffs3_garbage_collect_metadata(c, jeb, f, fn);
		goto upnout;
	}

	/* FIXME. Read node and do lookup? */
	for (frag = frag_first(&f->fragtree); frag; frag = frag_next(frag)) {
		if (frag->node && frag->node->raw == raw) {
			fn = frag->node;
			end = frag->ofs + frag->size;
			if (!nrfrags++)
				start = frag->ofs;
			if (nrfrags == frag->node->frags)
				break; /* We've found them all */
		}
	}
	if (fn) {
		if (ref_flags(raw) == REF_PRISTINE) {
			ret = jffs3_garbage_collect_pristine(c, f->inocache, raw);
			if (!ret) {
				/* Urgh. Return it sensibly. */
				frag->node->raw = f->inocache->nodes;
			}
			if (ret != -EBADFD)
				goto upnout;
		}
		/* We found a datanode. Do the GC */
		if((start >> PAGE_CACHE_SHIFT) < ((end-1) >> PAGE_CACHE_SHIFT)) {
			/* It crosses a page boundary. Therefore, it must be a hole. */
			ret = jffs3_garbage_collect_hole(c, jeb, f, fn, start, end);
		} else {
			/* It could still be a hole. But we GC the page this way anyway */
			ret = jffs3_garbage_collect_dnode(c, jeb, f, fn, start, end);
		}
		goto upnout;
	}

	/* Wasn't a dnode. Try dirent */
	for (fd = f->dents; fd; fd=fd->next) {
		if (fd->raw == raw)
			break;
	}

	if (fd && fd->ino) {
		ret = jffs3_garbage_collect_dirent(c, jeb, f, fd);
	} else if (fd) {
		ret = jffs3_garbage_collect_deletion_dirent(c, jeb, f, fd);
	} else {
		WARNING_MSG("Raw node at %#08x wasn't in node lists for ino #%u\n",
			       ref_offset(raw), f->inocache->ino);
		if (ref_obsolete(raw)) {
			WARNING_MSG("But it's obsolete so we don't mind too much\n");
		} else {
			ret = -EIO;
		}
	}
 upnout:
	up(&f->sem);

	return ret;
}

static int jffs3_garbage_collect_pristine(struct jffs3_sb_info *c,
					  struct jffs3_inode_cache *ic,
					  struct jffs3_raw_node_ref *raw)
{
	union jffs3_node_union *node;
	struct jffs3_raw_node_ref *nraw;
	size_t retlen;
	int ret;
	uint32_t phys_ofs, alloclen;
	uint32_t crc, rawlen;
	int retried = 0;
	struct kvec vecs[1];

	DBG_GC(1, "Going to GC REF_PRISTINE node at %#08x\n", ref_offset(raw));

	rawlen = ref_totlen(c, c->gcblock, raw);

	/* Ask for a small amount of space (or the totlen if smaller) because we
	   don't want to force wastage of the end of a block if splitting would
	   work. */
	ret = jffs3_reserve_space_gc(c, min_t(uint32_t, sizeof(struct jffs3_raw_inode) + JFFS3_MIN_DATA_LEN,
					      rawlen), &phys_ofs, &alloclen, rawlen); /* this is not optimal yet */
	if (ret)
		return ret;

	if (alloclen < rawlen) {
		/* Doesn't fit untouched. We'll go the old route and split it */
		return -EBADFD;
	}

	node = kmalloc(rawlen, GFP_KERNEL);
	if (!node)
               return -ENOMEM;

	ret = jffs3_flash_read(c, ref_offset(raw), rawlen, &retlen, (char *)node);
	if (!ret && retlen != rawlen)
		ret = -EIO;
	if (ret)
		goto out_node;

	crc = crc32(0, node, sizeof(struct jffs3_unknown_node)-4);
	if (je32_to_cpu(node->u.hdr_crc) != crc) {
		WARNING_MSG("Header CRC failed on REF_PRISTINE node at %#08x: Read %#08x, calculated %#08x\n",
		       ref_offset(raw), je32_to_cpu(node->u.hdr_crc), crc);
		goto bail;
	}

	switch(je16_to_cpu(node->u.nodetype)) {
	case JFFS3_NODETYPE_INODE:
		crc = crc32(0, node, sizeof(node->i)-8);
		if (je32_to_cpu(node->i.node_crc) != crc) {
			WARNING_MSG("Node CRC failed on REF_PRISTINE data node at %#08x: Read %#08x, calculated %#08x\n",
			       ref_offset(raw), je32_to_cpu(node->i.node_crc), crc);
			goto bail;
		}

		if (je32_to_cpu(node->i.dsize)) {
			crc = crc32(0, node->i.data, je32_to_cpu(node->i.csize));
			if (je32_to_cpu(node->i.data_crc) != crc) {
				WARNING_MSG("Data CRC failed on REF_PRISTINE data node at %#08x: Read %#08x, calculated %#08x\n",
				       ref_offset(raw), je32_to_cpu(node->i.data_crc), crc);
				goto bail;
			}
		}
		break;

	case JFFS3_NODETYPE_DIRENT:
		crc = crc32(0, node, sizeof(node->d)-8);
		if (je32_to_cpu(node->d.node_crc) != crc) {
			WARNING_MSG("Node CRC failed on REF_PRISTINE dirent node at %#08x: Read %#08x, calculated %#08x\n",
			       ref_offset(raw), je32_to_cpu(node->d.node_crc), crc);
			goto bail;
		}

		if (node->d.nsize) {
			crc = crc32(0, node->d.name, node->d.nsize);
			if (je32_to_cpu(node->d.name_crc) != crc) {
				WARNING_MSG("Name CRC failed on REF_PRISTINE dirent ode at %#08x: Read %#08x, calculated %#08x\n",
				       ref_offset(raw), je32_to_cpu(node->d.name_crc), crc);
				goto bail;
			}
		}
		break;
	default:
		WARNING_MSG("Unknown node type for REF_PRISTINE node at %#08x: 0x%04x\n",
		       ref_offset(raw), je16_to_cpu(node->u.nodetype));
		goto bail;
	}

	nraw = jffs3_alloc_raw_node_ref();
	if (!nraw) {
		ret = -ENOMEM;
		goto out_node;
	}

	/* OK, all the CRCs are good; this node can just be copied as-is. */
 retry:
	nraw->flash_offset = phys_ofs;
#ifdef TMP_TOTLEN
	nraw->__totlen = rawlen;
#endif
	nraw->next_phys = NULL;

	vecs[0].iov_base = (unsigned char *) node;
	vecs[0].iov_len = rawlen;

	ret = jffs3_flash_writev(c, vecs, 1, phys_ofs, &retlen, 0);

	if (ret || (retlen != rawlen)) {
		WARNING_MSG("Write of %d bytes at %#08x failed. returned %d, retlen %zd\n",
	                       rawlen, phys_ofs, ret, retlen);
		if (retlen) {
                        /* Doesn't belong to any inode */
			nraw->next_in_ino = NULL;

			nraw->flash_offset |= REF_OBSOLETE;
			jffs3_add_physical_node_ref(c, nraw, rawlen);
			jffs3_mark_node_obsolete(c, nraw);
		} else {
			WARNING_MSG("Not marking the space at %#08x as dirty because the flash "
					"driver returned retlen zero\n", nraw->flash_offset);
                        jffs3_free_raw_node_ref(nraw);
		}
		if (!retried && (nraw = jffs3_alloc_raw_node_ref())) {
			/* Try to reallocate space and retry */
			uint32_t dummy;
			struct jffs3_eraseblock *jeb = &c->blocks[phys_ofs / c->sector_size];

			retried = 1;

			DBG_GC(1, "Retrying failed write of REF_PRISTINE node.\n");

			jffs3_dbg_acct_sanity_check(c, jeb);
			if (PARANOIA)
				jffs3_dbg_acct_paranoia_check(c, jeb);

			ret = jffs3_reserve_space_gc(c, rawlen, &phys_ofs, &dummy, rawlen);  /* this is not optimal yet */

			if (!ret) {
				DBG_GC(1, "Allocated space at %#08x to retry failed write.\n", phys_ofs);

				jffs3_dbg_acct_sanity_check(c, jeb);
				if (PARANOIA)
					jffs3_dbg_acct_paranoia_check(c, jeb);

				goto retry;
			}
			DBG_GC(1, "Failed to allocate space to retry failed write: %d!\n", ret);
			jffs3_free_raw_node_ref(nraw);
		}

		jffs3_free_raw_node_ref(nraw);
		if (!ret)
			ret = -EIO;
		goto out_node;
	}
	nraw->flash_offset |= REF_PRISTINE;
	jffs3_add_physical_node_ref(c, nraw, rawlen);

	/* Link into per-inode list. This is safe because of the ic
	   state being INO_STATE_GC. Note that if we're doing this
	   for an inode which is in-core, the 'nraw' pointer is then
	   going to be fetched from ic->nodes by our caller. */
	spin_lock(&c->erase_completion_lock);
        nraw->next_in_ino = ic->nodes;
        ic->nodes = nraw;
	spin_unlock(&c->erase_completion_lock);

	jffs3_mark_node_obsolete(c, raw);
	DBG_GC(1, "WHEEE! GC REF_PRISTINE node at %#08x succeeded\n", ref_offset(raw));

 out_node:
	kfree(node);
	return ret;
 bail:
	ret = -EBADFD;
	goto out_node;
}

static int jffs3_garbage_collect_metadata(struct jffs3_sb_info *c, struct jffs3_eraseblock *jeb,
					struct jffs3_inode_info *f, struct jffs3_full_dnode *fn)
{
	struct jffs3_full_dnode *new_fn;
	struct jffs3_raw_inode ri;
	jint16_t dev;
	char *mdata = NULL, mdatalen = 0;
	uint32_t alloclen, phys_ofs;
	int ret;

	if (S_ISBLK(JFFS3_F_I_MODE(f)) ||
	    S_ISCHR(JFFS3_F_I_MODE(f)) ) {
		/* For these, we don't actually need to read the old node */
		/* FIXME: for minor or major > 255. */
		dev = cpu_to_je16(((JFFS3_F_I_RDEV_MAJ(f) << 8) |
			JFFS3_F_I_RDEV_MIN(f)));
		mdata = (char *)&dev;
		mdatalen = sizeof(dev);
		DBG_GC(1, "Writing %d bytes of kdev_t\n", mdatalen);
	} else if (S_ISLNK(JFFS3_F_I_MODE(f))) {
		mdatalen = fn->size;
		mdata = kmalloc(fn->size, GFP_KERNEL);
		if (!mdata) {
			WARNING_MSG("kmalloc of mdata failed in jffs3_garbage_collect_metadata()\n");
			return -ENOMEM;
		}
		ret = jffs3_read_dnode(c, f, fn, mdata, 0, mdatalen);
		if (ret) {
			WARNING_MSG("Read of old metadata failed in jffs3_garbage_collect_metadata(): %d\n", ret);
			kfree(mdata);
			return ret;
		}
		DBG_GC(1, "Writing %d bites of symlink target\n", mdatalen);

	}

	ret = jffs3_reserve_space_gc(c, sizeof(ri) + mdatalen, &phys_ofs, &alloclen, JFFS3_SUMMARY_INODE_SIZE);
	if (ret) {
		WARNING_MSG("Reserve space of %zd bytes for garbage_collect_metadata failed: %d\n",
		       sizeof(ri)+ mdatalen, ret);
		goto out;
	}

	memset(&ri, 0, sizeof(ri));
	ri.magic = cpu_to_je16(JFFS3_MAGIC_BITMASK);
	ri.nodetype = cpu_to_je16(JFFS3_NODETYPE_INODE);
	ri.totlen = cpu_to_je32(sizeof(ri) + mdatalen);
	ri.hdr_crc = cpu_to_je32(crc32(0, &ri, sizeof(struct jffs3_unknown_node)-4));

	ri.ino = cpu_to_je32(f->inocache->ino);
	ri.version = cpu_to_je32(++f->highest_version);
	ri.mode = cpu_to_jemode(JFFS3_F_I_MODE(f));
	ri.uid = cpu_to_je16(JFFS3_F_I_UID(f));
	ri.gid = cpu_to_je16(JFFS3_F_I_GID(f));
	ri.isize = cpu_to_je32(JFFS3_F_I_SIZE(f));
	ri.atime = cpu_to_je32(JFFS3_F_I_ATIME(f));
	ri.ctime = cpu_to_je32(JFFS3_F_I_CTIME(f));
	ri.mtime = cpu_to_je32(JFFS3_F_I_MTIME(f));
	ri.offset = cpu_to_je32(0);
	ri.csize = cpu_to_je32(mdatalen);
	ri.dsize = cpu_to_je32(mdatalen);
	ri.compr = JFFS3_COMPR_NONE;
	ri.node_crc = cpu_to_je32(crc32(0, &ri, sizeof(ri)-8));
	ri.data_crc = cpu_to_je32(crc32(0, mdata, mdatalen));

	new_fn = jffs3_write_dnode(c, f, &ri, mdata, mdatalen, phys_ofs, ALLOC_GC);

	if (IS_ERR(new_fn)) {
		WARNING_MSG("Error writing new dnode: %ld\n", PTR_ERR(new_fn));
		ret = PTR_ERR(new_fn);
		goto out;
	}
	jffs3_mark_node_obsolete(c, fn->raw);
	jffs3_free_full_dnode(fn);
	f->metadata = new_fn;
 out:
	if (S_ISLNK(JFFS3_F_I_MODE(f)))
		kfree(mdata);
	return ret;
}

static int jffs3_garbage_collect_dirent(struct jffs3_sb_info *c, struct jffs3_eraseblock *jeb,
					struct jffs3_inode_info *f, struct jffs3_full_dirent *fd)
{
	struct jffs3_full_dirent *new_fd;
	struct jffs3_raw_dirent rd;
	uint32_t alloclen, phys_ofs;
	int ret;

	rd.magic = cpu_to_je16(JFFS3_MAGIC_BITMASK);
	rd.nodetype = cpu_to_je16(JFFS3_NODETYPE_DIRENT);
	rd.nsize = strlen(fd->name);
	rd.totlen = cpu_to_je32(sizeof(rd) + rd.nsize);
	rd.hdr_crc = cpu_to_je32(crc32(0, &rd, sizeof(struct jffs3_unknown_node)-4));

	rd.pino = cpu_to_je32(f->inocache->ino);
	rd.version = cpu_to_je32(++f->highest_version);
	rd.ino = cpu_to_je32(fd->ino);
	rd.mctime = cpu_to_je32(max(JFFS3_F_I_MTIME(f), JFFS3_F_I_CTIME(f)));
	rd.type = fd->type;
	rd.node_crc = cpu_to_je32(crc32(0, &rd, sizeof(rd)-8));
	rd.name_crc = cpu_to_je32(crc32(0, fd->name, rd.nsize));

	ret = jffs3_reserve_space_gc(c, sizeof(rd)+rd.nsize, &phys_ofs, &alloclen, JFFS3_SUMMARY_DIRENT_SIZE(rd.nsize));
	if (ret) {
		WARNING_MSG("Reserve space of %zd bytes for garbage_collect_dirent failed: %d\n",
		       sizeof(rd)+rd.nsize, ret);
		return ret;
	}
	new_fd = jffs3_write_dirent(c, f, &rd, fd->name, rd.nsize, phys_ofs, ALLOC_GC);

	if (IS_ERR(new_fd)) {
		WARNING_MSG("Write dirent failed: %ld\n", PTR_ERR(new_fd));
		return PTR_ERR(new_fd);
	}
	jffs3_add_fd_to_list(c, new_fd, &f->dents);
	return 0;
}

static int jffs3_garbage_collect_deletion_dirent(struct jffs3_sb_info *c, struct jffs3_eraseblock *jeb,
					struct jffs3_inode_info *f, struct jffs3_full_dirent *fd)
{
	struct jffs3_full_dirent **fdp = &f->dents;
	int found = 0;

	/* On a medium where we can't actually mark nodes obsolete
	   pernamently, such as NAND flash, we need to work out
	   whether this deletion dirent is still needed to actively
	   delete a 'real' dirent with the same name that's still
	   somewhere else on the flash. */
	if (!jffs3_can_mark_obsolete(c)) {
		struct jffs3_raw_dirent *rd;
		struct jffs3_raw_node_ref *raw;
		int ret;
		size_t retlen;
		int name_len = strlen(fd->name);
		uint32_t name_crc = crc32(0, fd->name, name_len);
		uint32_t rawlen = ref_totlen(c, jeb, fd->raw);

		rd = kmalloc(rawlen, GFP_KERNEL);
		if (!rd)
			return -ENOMEM;

		/* Prevent the erase code from nicking the obsolete node refs while
		   we're looking at them. I really don't like this extra lock but
		   can't see any alternative. Suggestions on a postcard to... */
		down(&c->erase_free_sem);

		for (raw = f->inocache->nodes; raw != (void *)f->inocache; raw = raw->next_in_ino) {

			/* We only care about obsolete ones */
			if (!(ref_obsolete(raw)))
				continue;

			/* Any dirent with the same name is going to have the same length... */
			if (ref_totlen(c, NULL, raw) != rawlen)
				continue;

			/* Doesn't matter if there's one in the same erase block. We're going to
			   delete it too at the same time. */
			if ((raw->flash_offset & ~(c->sector_size-1)) ==
			    (fd->raw->flash_offset & ~(c->sector_size-1)))
				continue;

			DBG_GC(1, "Check potential deletion dirent at %#08x\n", ref_offset(raw));

			/* This is an obsolete node belonging to the same directory, and it's of the right
			   length. We need to take a closer look...*/
			ret = jffs3_flash_read(c, ref_offset(raw), rawlen, &retlen, (char *)rd);
			if (ret) {
				WARNING_MSG("Read error (%d), reading obsolete node at %#08x\n", ret, ref_offset(raw));
				/* If we can't read it, we don't need to continue to obsolete it. Continue */
				continue;
			}
			if (retlen != rawlen) {
				WARNING_MSG("Short read (%zd not %u) reading header from obsolete node at %#08x\n",
				       retlen, rawlen, ref_offset(raw));
				continue;
			}

			if (je16_to_cpu(rd->nodetype) != JFFS3_NODETYPE_DIRENT)
				continue;

			/* If the name CRC doesn't match, skip */
			if (je32_to_cpu(rd->name_crc) != name_crc)
				continue;

			/* If the name length doesn't match, or it's another deletion dirent, skip */
			if (rd->nsize != name_len || !je32_to_cpu(rd->ino))
				continue;

			/* OK, check the actual name now */
			if (memcmp(rd->name, fd->name, name_len))
				continue;

			/* OK. The name really does match. There really is still an older node on
			   the flash which our deletion dirent obsoletes. So we have to write out
			   a new deletion dirent to replace it */
			up(&c->erase_free_sem);

			DBG_GC(1, "Deletion dirent at %#08x still obsoletes real dirent \"%s\" at %#08x for ino #%u\n",
				  ref_offset(fd->raw), fd->name, ref_offset(raw), je32_to_cpu(rd->ino));
			kfree(rd);

			return jffs3_garbage_collect_dirent(c, jeb, f, fd);
		}

		up(&c->erase_free_sem);
		kfree(rd);
	}

	/* No need for it any more. Just mark it obsolete and remove it from the list */
	while (*fdp) {
		if ((*fdp) == fd) {
			found = 1;
			*fdp = fd->next;
			break;
		}
		fdp = &(*fdp)->next;
	}
	if (!found) {
		WARNING_MSG("Deletion dirent \"%s\" not found in list for ino #%u\n", fd->name, f->inocache->ino);
	}
	jffs3_mark_node_obsolete(c, fd->raw);
	jffs3_free_full_dirent(fd);
	return 0;
}

static int jffs3_garbage_collect_hole(struct jffs3_sb_info *c, struct jffs3_eraseblock *jeb,
				      struct jffs3_inode_info *f, struct jffs3_full_dnode *fn,
				      uint32_t start, uint32_t end)
{
	struct jffs3_raw_inode ri;
	struct jffs3_node_frag *frag;
	struct jffs3_full_dnode *new_fn;
	uint32_t alloclen, phys_ofs;
	int ret;

	DBG_GC(1, "Writing replacement hole node for ino #%u from offset 0x%x to 0x%x\n",
		f->inocache->ino, start, end);

	memset(&ri, 0, sizeof(ri));

	if(fn->frags > 1) {
		size_t readlen;
		uint32_t crc;
		/* It's partially obsoleted by a later write. So we have to
		   write it out again with the _same_ version as before */
		ret = jffs3_flash_read(c, ref_offset(fn->raw), sizeof(ri), &readlen, (char *)&ri);
		if (readlen != sizeof(ri) || ret) {
			WARNING_MSG("Node read failed. Ret %d, retlen %zd. Data will be lost by "
					"writing new hole node\n", ret, readlen);
			goto fill;
		}
		if (je16_to_cpu(ri.nodetype) != JFFS3_NODETYPE_INODE) {
			WARNING_MSG("Node at %#08x had node type 0x%04x instead of JFFS3_NODETYPE_INODE(0x%04x)\n",
				       ref_offset(fn->raw), je16_to_cpu(ri.nodetype), JFFS3_NODETYPE_INODE);
			return -EIO;
		}
		if (je32_to_cpu(ri.totlen) != sizeof(ri)) {
			WARNING_MSG("Node at %#08x had totlen 0x%x instead of expected 0x%zx\n",
				       ref_offset(fn->raw), je32_to_cpu(ri.totlen), sizeof(ri));
			return -EIO;
		}
		crc = crc32(0, &ri, sizeof(ri)-8);
		if (crc != je32_to_cpu(ri.node_crc)) {
			WARNING_MSG("Node at %#08x had CRC %#08x which doesn't match calculated CRC %#08x\n",
				       ref_offset(fn->raw), je32_to_cpu(ri.node_crc), crc);
			/* FIXME: We could possibly deal with this by writing new holes for each frag */
			WARNING_MSG("Data in the range %#08x to %#08x of inode #%u will be lost\n",
				       start, end, f->inocache->ino);
			goto fill;
		}
		if (ri.compr != JFFS3_COMPR_ZERO) {
			WARNING_MSG("Node %#08x wasn't a hole node!\n", ref_offset(fn->raw));
			WARNING_MSG("Data in the range %#08x to %#08x of inode #%u will be lost\n",
					       start, end, f->inocache->ino);
			goto fill;
		}
	} else {
	fill:
		ri.magic = cpu_to_je16(JFFS3_MAGIC_BITMASK);
		ri.nodetype = cpu_to_je16(JFFS3_NODETYPE_INODE);
		ri.totlen = cpu_to_je32(sizeof(ri));
		ri.hdr_crc = cpu_to_je32(crc32(0, &ri, sizeof(struct jffs3_unknown_node)-4));

		ri.ino = cpu_to_je32(f->inocache->ino);
		ri.version = cpu_to_je32(++f->highest_version);
		ri.offset = cpu_to_je32(start);
		ri.dsize = cpu_to_je32(end - start);
		ri.csize = cpu_to_je32(0);
		ri.compr = JFFS3_COMPR_ZERO;
	}
	ri.mode = cpu_to_jemode(JFFS3_F_I_MODE(f));
	ri.uid = cpu_to_je16(JFFS3_F_I_UID(f));
	ri.gid = cpu_to_je16(JFFS3_F_I_GID(f));
	ri.isize = cpu_to_je32(JFFS3_F_I_SIZE(f));
	ri.atime = cpu_to_je32(JFFS3_F_I_ATIME(f));
	ri.ctime = cpu_to_je32(JFFS3_F_I_CTIME(f));
	ri.mtime = cpu_to_je32(JFFS3_F_I_MTIME(f));
	ri.data_crc = cpu_to_je32(0);
	ri.node_crc = cpu_to_je32(crc32(0, &ri, sizeof(ri)-8));

	ret = jffs3_reserve_space_gc(c, sizeof(ri), &phys_ofs, &alloclen, JFFS3_SUMMARY_INODE_SIZE);
	if (ret) {
		WARNING_MSG("Reserve space of %zd bytes for garbage_collect_hole failed: %d\n",
		       sizeof(ri), ret);
		return ret;
	}
	new_fn = jffs3_write_dnode(c, f, &ri, NULL, 0, phys_ofs, ALLOC_GC);

	if (IS_ERR(new_fn)) {
		WARNING_MSG("Error writing new hole node: %ld\n", PTR_ERR(new_fn));
		return PTR_ERR(new_fn);
	}
	if (je32_to_cpu(ri.version) == f->highest_version) {
		jffs3_add_full_dnode_to_inode(c, f, new_fn);
		if (f->metadata) {
			jffs3_mark_node_obsolete(c, f->metadata->raw);
			jffs3_free_full_dnode(f->metadata);
			f->metadata = NULL;
		}
		return 0;
	}

	/*
	 * We should only get here in the case where the node we are
	 * replacing had more than one frag, so we kept the same version
	 * number as before. (Except in case of error -- see 'goto fill;'
	 * above.)
	 */

	/* This is a partially-overlapped hole node. Mark it REF_NORMAL not REF_PRISTINE */
	mark_ref_normal(new_fn->raw);

	for (frag = jffs3_lookup_node_frag(&f->fragtree, fn->ofs);
	     frag; frag = frag_next(frag)) {
		if (frag->ofs > fn->size + fn->ofs)
			break;
		if (frag->node == fn) {
			frag->node = new_fn;
			new_fn->frags++;
			fn->frags--;
		}
	}
	if (fn->frags) {
		ERROR_MSG("Old node still has frags!\n");
		BUG();
	}
	if (!new_fn->frags) {
		ERROR_MSG("New node has no frags!\n");
		BUG();
	}

	jffs3_mark_node_obsolete(c, fn->raw);
	jffs3_free_full_dnode(fn);

	return 0;
}

static int jffs3_garbage_collect_dnode(struct jffs3_sb_info *c, struct jffs3_eraseblock *jeb,
				       struct jffs3_inode_info *f, struct jffs3_full_dnode *fn,
				       uint32_t start, uint32_t end)
{
	struct jffs3_full_dnode *new_fn;
	struct jffs3_raw_inode ri;
	uint32_t alloclen, phys_ofs, offset, orig_end, orig_start;
	int ret = 0;
	unsigned char *comprbuf = NULL, *writebuf;
	unsigned long pg;
	unsigned char *pg_ptr;

	memset(&ri, 0, sizeof(ri));

	DBG_GC(1, "Writing replacement dnode for ino #%u from offset 0x%x to 0x%x\n",
			  f->inocache->ino, start, end);

	orig_end = end;
	orig_start = start;

	if (c->nr_free_blocks + c->nr_erasing_blocks > c->resv_blocks_gcmerge) {
		/* Attempt to do some merging. But only expand to cover logically
		   adjacent frags if the block containing them is already considered
		   to be dirty. Otherwise we end up with GC just going round in
		   circles dirtying the nodes it already wrote out, especially
		   on NAND where we have small eraseblocks and hence a much higher
		   chance of nodes having to be split to cross boundaries. */

		struct jffs3_node_frag *frag;
		uint32_t min, max;

		min = start & ~(PAGE_CACHE_SIZE-1);
		max = min + PAGE_CACHE_SIZE;

		frag = jffs3_lookup_node_frag(&f->fragtree, start);

		/* BUG_ON(!frag) but that'll happen anyway... */

		BUG_ON(frag->ofs != start);

		/* First grow down... */
		while((frag = frag_prev(frag)) && frag->ofs >= min) {

			/* If the previous frag doesn't even reach the beginning, there's
			   excessive fragmentation. Just merge. */
			if (frag->ofs > min) {
				DBG_GC(1, "Expanding down to cover partial frag (0x%x-0x%x)\n",
						  frag->ofs, frag->ofs+frag->size);
				start = frag->ofs;
				continue;
			}
			/* OK. This frag holds the first byte of the page. */
			if (!frag->node || !frag->node->raw) {
				DBG_GC(1, "First frag in page is hole (0x%x-0x%x). Not expanding down.\n",
					  frag->ofs, frag->ofs+frag->size);
				break;
			} else {

				/* OK, it's a frag which extends to the beginning of the page. Does it live
				   in a block which is still considered clean? If so, don't obsolete it.
				   If not, cover it anyway. */

				struct jffs3_raw_node_ref *raw = frag->node->raw;
				struct jffs3_eraseblock *jeb;

				jeb = &c->blocks[raw->flash_offset / c->sector_size];

				if (jeb == c->gcblock) {
					DBG_GC(1, "Expanding down to cover frag (0x%x-0x%x) in gcblock at %#08x\n",
						  frag->ofs, frag->ofs+frag->size, ref_offset(raw));
					start = frag->ofs;
					break;
				}
				if (!ISDIRTY(jeb->dirty_size + jeb->wasted_size)) {
					DBG_GC(1, "Not expanding down to cover frag (0x%x-0x%x) in clean block %#08x\n",
						  frag->ofs, frag->ofs+frag->size, jeb->offset);
					break;
				}

				DBG_GC(1, "Expanding down to cover frag (0x%x-0x%x) in dirty block %#08x\n",
						  frag->ofs, frag->ofs+frag->size, jeb->offset);
				start = frag->ofs;
				break;
			}
		}

		/* ... then up */

		/* Find last frag which is actually part of the node we're to GC. */
		frag = jffs3_lookup_node_frag(&f->fragtree, end-1);

		while((frag = frag_next(frag)) && frag->ofs+frag->size <= max) {

			/* If the previous frag doesn't even reach the beginning, there's lots
			   of fragmentation. Just merge. */
			if (frag->ofs+frag->size < max) {
				DBG_GC(1, "Expanding up to cover partial frag (0x%x-0x%x)\n",
					  frag->ofs, frag->ofs+frag->size);
				end = frag->ofs + frag->size;
				continue;
			}

			if (!frag->node || !frag->node->raw) {
				DBG_GC(1, "Last frag in page is hole (0x%x-0x%x). Not expanding up.\n",
					  frag->ofs, frag->ofs+frag->size);
				break;
			} else {

				/* OK, it's a frag which extends to the beginning of the page. Does it live
				   in a block which is still considered clean? If so, don't obsolete it.
				   If not, cover it anyway. */

				struct jffs3_raw_node_ref *raw = frag->node->raw;
				struct jffs3_eraseblock *jeb;

				jeb = &c->blocks[raw->flash_offset / c->sector_size];

				if (jeb == c->gcblock) {
					DBG_GC(1, "Expanding up to cover frag (0x%x-0x%x) in gcblock at %#08x\n",
						  frag->ofs, frag->ofs+frag->size, ref_offset(raw));
					end = frag->ofs + frag->size;
					break;
				}
				if (!ISDIRTY(jeb->dirty_size + jeb->wasted_size)) {
					DBG_GC(1, "Not expanding up to cover frag (0x%x-0x%x) in clean block %#08x\n",
						  frag->ofs, frag->ofs+frag->size, jeb->offset);
					break;
				}

				DBG_GC(1, "Expanding up to cover frag (0x%x-0x%x) in dirty block %#08x\n",
						  frag->ofs, frag->ofs+frag->size, jeb->offset);
				end = frag->ofs + frag->size;
				break;
			}
		}
		DBG_GC(1, "Expanded dnode to write from (0x%x-0x%x) to (0x%x-0x%x)\n",
			  orig_start, orig_end, start, end);

		BUG_ON(end > JFFS3_F_I_SIZE(f));
		BUG_ON(end < orig_end);
		BUG_ON(start > orig_start);
	}

	/* First, use readpage() to read the appropriate page into the page cache */
	/* Q: What happens if we actually try to GC the _same_ page for which commit_write()
	 *    triggered garbage collection in the first place?
	 * A: I _think_ it's OK. read_cache_page shouldn't deadlock, we'll write out the
	 *    page OK. We'll actually write it out again in commit_write, which is a little
	 *    suboptimal, but at least we're correct.
	 */
	pg_ptr = jffs3_gc_fetch_page(c, f, start, &pg);

	if (IS_ERR(pg_ptr)) {
		WARNING_MSG("read_cache_page() returned error: %ld\n", PTR_ERR(pg_ptr));
		return PTR_ERR(pg_ptr);
	}

	offset = start;
	while(offset < orig_end) {
		uint32_t datalen;
		uint32_t cdatalen;
		uint16_t comprtype = JFFS3_COMPR_NONE;

		ret = jffs3_reserve_space_gc(c, sizeof(ri) + JFFS3_MIN_DATA_LEN, &phys_ofs, &alloclen, JFFS3_SUMMARY_INODE_SIZE);

		if (ret) {
			WARNING_MSG("Reserve space of %zd bytes for garbage_collect_dnode failed: %d\n",
			       sizeof(ri)+ JFFS3_MIN_DATA_LEN, ret);
			break;
		}
		cdatalen = min_t(uint32_t, alloclen - sizeof(ri), end - offset);
		datalen = end - offset;

		writebuf = pg_ptr + (offset & (PAGE_CACHE_SIZE -1));

		comprtype = jffs3_compress(c, f, writebuf, &comprbuf, &datalen, &cdatalen);

		ri.magic = cpu_to_je16(JFFS3_MAGIC_BITMASK);
		ri.nodetype = cpu_to_je16(JFFS3_NODETYPE_INODE);
		ri.totlen = cpu_to_je32(sizeof(ri) + cdatalen);
		ri.hdr_crc = cpu_to_je32(crc32(0, &ri, sizeof(struct jffs3_unknown_node)-4));

		ri.ino = cpu_to_je32(f->inocache->ino);
		ri.version = cpu_to_je32(++f->highest_version);
		ri.mode = cpu_to_jemode(JFFS3_F_I_MODE(f));
		ri.uid = cpu_to_je16(JFFS3_F_I_UID(f));
		ri.gid = cpu_to_je16(JFFS3_F_I_GID(f));
		ri.isize = cpu_to_je32(JFFS3_F_I_SIZE(f));
		ri.atime = cpu_to_je32(JFFS3_F_I_ATIME(f));
		ri.ctime = cpu_to_je32(JFFS3_F_I_CTIME(f));
		ri.mtime = cpu_to_je32(JFFS3_F_I_MTIME(f));
		ri.offset = cpu_to_je32(offset);
		ri.csize = cpu_to_je32(cdatalen);
		ri.dsize = cpu_to_je32(datalen);
		ri.compr = comprtype & 0xff;
		ri.usercompr = (comprtype >> 8) & 0xff;
		ri.node_crc = cpu_to_je32(crc32(0, &ri, sizeof(ri)-8));
		ri.data_crc = cpu_to_je32(crc32(0, comprbuf, cdatalen));

		new_fn = jffs3_write_dnode(c, f, &ri, comprbuf, cdatalen, phys_ofs, ALLOC_GC);

		jffs3_free_comprbuf(comprbuf, writebuf);

		if (IS_ERR(new_fn)) {
			WARNING_MSG("Error writing new dnode: %ld\n", PTR_ERR(new_fn));
			ret = PTR_ERR(new_fn);
			break;
		}
		ret = jffs3_add_full_dnode_to_inode(c, f, new_fn);
		offset += datalen;
		if (f->metadata) {
			jffs3_mark_node_obsolete(c, f->metadata->raw);
			jffs3_free_full_dnode(f->metadata);
			f->metadata = NULL;
		}
	}

	jffs3_gc_release_page(c, pg_ptr, &pg);
	return ret;
}
