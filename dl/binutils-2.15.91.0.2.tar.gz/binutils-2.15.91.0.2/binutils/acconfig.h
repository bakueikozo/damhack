/* Define if you have weak symbol.  */
#undef HAVE_WEAK_SYMBOL
