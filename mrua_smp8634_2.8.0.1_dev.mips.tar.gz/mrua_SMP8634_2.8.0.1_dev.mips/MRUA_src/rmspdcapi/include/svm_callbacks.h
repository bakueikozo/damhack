/****************************************************************************
 *    Copyright (c) Sigma Designs, Inc. 2005. All rights reserved.
 **/
/**
 *      @file       svm_callbacks.h
 *
 *      @brief      BD+ Virtual Machine callbacks definitions
 *
 *      @author     Alan Liddeke
 *      
 ****************************************************************************/
#ifndef __SVM_CALLBACKS_H__
#define __SVM_CALLBACKS_H__

/*---------------------------------------------------------------------------
                                  INCLUDES
 ---------------------------------------------------------------------------*/

#include "rmdef/rmdef.h"
#include "svm_def.h"


/*---------------------------------------------------------------------------
                               CLASSES / TYPES
 ---------------------------------------------------------------------------*/


/* forward declarations */
union SVMINTRP;


/* CALLBACKS ---------------------------------------------------------------*/

/** ApplicationLayer callback: Communication between BD+<==>APPLICATION
 *  @param resource  - PSR to access (0,1,2)
 *  @param direction - direction of data xfer (0=to BD+,1=from BD+)
 *
 *  @return:  RM_OK for success
 *            RM_ERROR for all errors.
 */
typedef RMstatus (*applicationlayer_callback_t)     (void *ctx, RMuint32 resource, RMuint32 direction, RMuint32 *dataPtr);

/** GetClock callback: Get clock value as defined in BD+ spec, Annex C, Table C-4
 *  @param  dstPtr - clock value.
 *  
 *  @return:  Return value is ignored by SPDC library.
 */
typedef RMstatus  (*getclock_callback_t)            (void *ctx, RMuint32 dstPtr[3]);

/** GetMediaInfoBits callback: Get Media Information as defined in BD+ spec, Annex C, Table C-4 
 *  (See also SPDC_MEDIAINFOBITS0_xxx defines in svm_def.h)
 *  @param  dstPtr - Media information.
 *
 *  @return:  RM_OK  on success
 *            RM_ERROR on failure to retrieve VolumeId or PMSN
 */
typedef RMstatus (*getmediainfobits_callback_t)     (void *ctx, RMuint32 dstPtr[10]);

/** GetPortInfo callback: Get Port information as defined by BD+ 3.2.2.4.2 & Annex C, Table C-5
 *  @param portIndex - Index of port
 *  @param portInfo  - port information 
 *
 *  @return:  RM_OK on sucess
 *            RM_PARAMETER_OUT_OF_RANGE when an invalid port 'index' has been specified.
 *            RM_ERROR  for all other errors.
 */
typedef RMstatus (*getportinfo_callback_t)          (void *ctx, RMuint32 index, RMuint32 dstPtr[32]);

/** Discovery Ram callback 
 *  @param addr   - source address to read at.
 *  @param dstptr - ptr to store the contents read.
 *  @param len    - length of bytes to read.
 *
 *  @return:      RM_OK  on success
 *                RM_ACCESS_VIOLATION  for invalid address range specified
 *                RM_ERROR for all other errors.
 */
typedef RMstatus  (*discoveryram_callback_t)        (void *ctx, RMuint32 addr, RMuint8 *dstptr, RMuint32 len);

/** Run Native callback
 *  @param code - pointer to the start of the run native exe code.
 *  @param len  - length of the exe code.
 *  @param mode - Either (0=New, 1=Use existing Native Code)
 *
 *  @return:  RM_OK on succesful running of native code.
 *            RM_ERROR for all failures.
 */
typedef RMstatus  (*runnative_callback_t)           (void *ctx, RMuint8 *code, RMint32 len, RMuint32 mode);

/** Send Fixup Table callback
 *  @param fixupTable - pointer to the fixuptable.
 *  @param size       - size of the fixuptable in bytes.
 *
 *  @return:  RM_OK on sucess
 *            RM_ERROR for all failures.
 */
typedef RMstatus  (*sendfixuptable_callback_t)      (void *ctx, RMuint8 *fixupTable, RMuint32 size);

/** Read file callback
 *  
 *  @param filename - pathname relative to the root directory of the Bluray media.
 *  @param offset   - 64 bit relative byte offset from the begining of the file.
 *  @param length   - number of bytes to read.  Returned as # of bytes read.
 *  @param dstPtr   - pointer to the buffer to store the data read.
 *
 *  @return:  RM_OK on success.
 *            RM_ERRORSEEKFILE  for failure to seek file, this includes the case
 *                              that the seek offset is > than the length of the file.
 *                 
 *            RM_ERROR  for all other failures.
 */
typedef RMstatus  (*readfile_callback_t)            (void *ctx, RMuint8 *filename, RMuint64 offset, RMuint32 *length, RMuint8* dstPtr);

/** sleep callback
 *
 *   Sleep the Background VM. 
 */
typedef void      (*sleep_callback_t)               (void *ctx);


/** Slot RW callback
 *
 *   Read or write a given slot.
 *   @param direction - 0=read, 1=write
 *   @param memptr    - Buffer to read to/ write from.
 *   @param slot      - the id of the slot.
 *
 *   return:  RM_OK on success
 *            RM_ERROR for all errors.
 */
typedef RMstatus  (*slotrw_callback_t)              (void* ctx, RMint32 direction, RMuint8* memptr, RMuint32 slot);


/** Interrupt done callback - deprecated!
 *
 *  Called whenever an interrupt is finished processing.
 *  ### No longer called!
 *
 *  @param intrp   - The pointer to the interrupt context.
 *  @param intrpID - The Type of interrupt.
 */
typedef void      (*interrupt_done_callback_t)      (void* ctx, union SVMINTRP* intrp, RMuint32 intrpID);


/** Lock Q semaphore 
 *
 *  Called before switching into interrupt mode, and before queueing an interrupt.
 *  This call should wait until the semaphore is taken.  There cannot be a timeout
 *  on this call.
 *
 *  @param ctx     - The callback context.
 *
 *  @return:  RM_OK  on success
 *            RM_ERROR on fatal error that puts VM into unknown state.
 */
typedef RMstatus  (*lock_q_semaphore_callback_t)    (void* ctx);


/** UnLock Q semaphore 
 *
 *  Called after performing a switch into interrupt mode, or after queueing an interrupt 
 *  to make the queue available.
 *
 *  @param ctx     - The callback context.
 *  
 *  @return:  RM_OK on success
 *            RM_ERROR on fatal error that puts VM into unknown state.
 */
typedef RMstatus  (*unlock_q_semaphore_callback_t)  (void* ctx);

/** Lock VM semaphore 
 *
 *  Called before invoking the VM. 
 *
 *  @param ctx     - The callback context.
 *
 *  @return:  RM_OK on success
 *            RM_ERROR on fatal error that puts VM into unknown state.
 */
typedef RMstatus  (*lock_vm_semaphore_callback_t)    (void* ctx);


/** UnLock VM semaphore 
 *
 *  Called after VM processing has finished. 
 *
 *  @param ctx     - The callback context.
 *
 *  @return:  RM_OK on success
 *            RM_ERROR on fatal error that puts VM into unknown state.
 */
typedef RMstatus  (*unlock_vm_semaphore_callback_t)  (void* ctx);


/** Callback table
 */
struct SVM_Callbacks {
	applicationlayer_callback_t     applicationlayer_callback;
	getclock_callback_t             getclock_callback;
	getmediainfobits_callback_t     getmediainfobits_callback;
	getportinfo_callback_t          getportinfo_callback;
	discoveryram_callback_t         discoveryram_callback;
	runnative_callback_t            runnative_callback;
	sendfixuptable_callback_t       sendfixuptable_callback;
	readfile_callback_t             readfile_callback;
	sleep_callback_t                sleep_callback;
	slotrw_callback_t               slotrw_callback;
	interrupt_done_callback_t       interrupt_done_callback;
	lock_q_semaphore_callback_t     lock_q_semaphore_callback;
	unlock_q_semaphore_callback_t   unlock_q_semaphore_callback;
	
};

#endif // __SVM_CALLBACKS_H__

