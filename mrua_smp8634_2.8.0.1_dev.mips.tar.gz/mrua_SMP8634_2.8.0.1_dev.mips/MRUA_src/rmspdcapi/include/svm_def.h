/****************************************************************************
 *    Copyright (c) Sigma Designs, Inc. 2005. All rights reserved.
 **/
/**
 *      @file       svm_def.h
 *
 *      @brief      Definitions for the SVM.
 * 
 *
 *      @author     Alan Liddeke
 *      
 ****************************************************************************/
#ifndef __SVM_DEF_H__
#define __SVM_DEF_H__

/*---------------------------------------------------------------------------
                                  INCLUDES
 ---------------------------------------------------------------------------*/

#include "rmdef/rmdef.h"

/*---------------------------------------------------------------------------
                             CONSTANT LITERALS
 ---------------------------------------------------------------------------*/
/* BD+ Memory MAP*/

/* VM Memory space size : 2MB */
#define VM_RAM_SIZE                0x200000
//#define VM_RAM_SIZE                0x400000

/* Uses 2MB for cached CC Block */
#define CACHED_CC_BLOCKSIZE        0x200000 
#define CACHED_CC_OFFSET           VM_RAM_SIZE

/* 2MB maximum media check */
#define MEDIACHECK_BUFFER_SIZE     0x200000 
#define MEDIACHECK_BUFFER_OFFSET   VM_RAM_SIZE + CACHED_CC_BLOCKSIZE

/* 64KB used for Xtask load/unload/calls */
#define XTASK_BUFFER_SIZE          0x10000 
#define XTASK_BUFFER_OFFSET        MEDIACHECK_BUFFER_OFFSET + MEDIACHECK_BUFFER_SIZE

/* 64KB used for RunNative */
// RunNative Callback must retain the previous code
// for RunNative.
//#define RUNNATIVE_BUFFER_SIZE      0x10000
//#define RUNNATIVE_BUFFER_OFFSET    XTASK_BUFFER_SIZE + XTASK_BUFFER_OFFSET


/* Values for MediaInfoBits[0] returned to getmediainfobits callbacks */
/* Coded big endian, according to BD+ spec v0.99 table C-4 */
#define SPDC_MEDIAINFOBITS0_BD_ROM       (0x00000000)
#define SPDC_MEDIAINFOBITS0_BD_RE        (0x10000000)
#define SPDC_MEDIAINFOBITS0_BD_R         (0x20000000)
#define SPDC_MEDIAINFOBITS0_SINGLE_LAYER (0x00000000) 
#define SPDC_MEDIAINFOBITS0_DUAL_LAYER   (0x01000000)

enum {
	RUNNATIVE_MODE_NEW=0,    /* Load new Runnative code */
	RUNNATIVE_MODE_CONTINUE  /* invoke previously loaded Runnative code */
} RunnativeModes;

#endif // __SVM_DEF_H__

