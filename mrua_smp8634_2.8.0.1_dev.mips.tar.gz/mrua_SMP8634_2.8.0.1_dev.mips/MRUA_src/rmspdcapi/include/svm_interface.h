/**************************************************************
 *
 *	Copyright (c) Sigma Designs, Inc. 2005. All rights reserved.
 *
 */
/**
 *     @file   svm_interface.h
 *     @brief  BD+ SVM interface to shared library
 *
 *     @author Alan Liddke / Fabrice
 *
 ***************************************************************/
#ifndef __SVM_INTERFACE_H__
#define __SVM_INTERFACE_H__

#include "svm_api.h"


struct svm_interface_s {
	
	RMstatus (* SVM_Init)(struct SVM** pSVMContext, struct SVM_Callbacks *pSVMCallbacks,
		  void *callback_ctx, RMuint8* svm_ram_addr, RMuint32 rua_addr, RMuint32 svm_ram_size, RMuint32 xtask_flash_page);

	RMstatus (* SVM_Term)(struct SVM* pSVMContext);

	RMstatus (* SVM_QueueInterrupt)(struct SVM* pSVMContext, union SVMINTRP* pSVMINTRPContext);

	RMstatus (* SVM_VMRun)(struct SVM* pSVMContext, RMint32 *numCycles);

	RMstatus (* SVM_Init_Preloaded)(struct SVM** pSVMContext, struct SVM_Callbacks *pSVMCallbacks,
		  void *callback_ctx, RMuint8* svm_ram_addr, RMuint32 rua_addr, RMuint32 svm_ram_size, RMuint32 xtask_flash_page, RMuint32 xtask_slot_id);

};

#endif // __SVM_INTERFACE_H__
