/****************************************************************************
 *    Copyright (c) Sigma Designs, Inc. 2005. All rights reserved.
 **/
/**
 *      @file       svmintrp.h
 *
 *      @brief      Definitions and constants for the SVMINTRP types.
 *
 *      @author     Alan Liddeke
 *
 ****************************************************************************/

#ifndef __SVMINTRP_H__
#define __SVMINTRP_H__

/*---------------------------------------------------------------------------
                                  INCLUDES
 ---------------------------------------------------------------------------*/
#include "rmdef/rmdef.h"


/*---------------------------------------------------------------------------
                               CONSTANT LITERALS
 ---------------------------------------------------------------------------*/

enum SPDC_INTERRUPT_IDS {

	INTRP_ApplicationLayer         = 0x00000210,
	INTRP_ComputeSP                = 0x00000220,
	INTRP_InitializeMedia          = 0x00000000,
	INTRP_InitializeTitle          = 0x00000110,
	INTRP_Shutdown                 = 0x00000010,
};
#define INTRP_TO_STR(id)               (id==INTRP_ApplicationLayer)?"ApplicationLayer":(id==INTRP_ComputeSP)?"ComputeSP":\
                                       (id==INTRP_InitializeMedia)?"InitializeMedia":(id==INTRP_InitializeTitle)?"InitializeTitle":\
                                       (id==INTRP_Shutdown)?"Shutdown":"InvalidInterrupt!!!"

#define IS_VALID_INTERRUPT_ID(id)      ((id==INTRP_ApplicationLayer)||(id==INTRP_ComputeSP)||(id==INTRP_InitializeMedia)|| \
                                        (id==INTRP_InitializeTitle) ||(id==INTRP_Shutdown))?TRUE:FALSE


/* TODO:  Look at transfering these to rmstatus.inc */
enum SPDC_INTERRUPT_RESULTS {
	
	INTERRUPT_RETURN_OK            = 0x00000000,
	INTERRUPT_RETURN_FAILED        = 0x80000000,
	INTERRUPT_RETURN_FATAL         = 0xFF000000
};


#define SVMINTRP_Failed(intrp)        \
	( intrp != INTERRUPT_RETURN_OK ) ? 1 : 0


/*---------------------------------------------------------------------------
                               CLASSES / TYPES
 ---------------------------------------------------------------------------*/


#define SVMINTRP_BASE_ELEMENTS() \
	RMuint32 InterruptID;\
	RMuint32 ReturnVal;


struct SVMINTRPContext_base {
	SVMINTRP_BASE_ELEMENTS()
};

struct SVMINTRPContext_ApplicationLayer {
	/* Common for INTRP */
	SVMINTRP_BASE_ELEMENTS()
	/* Application Layer Params */
	RMuint32 Resource;
};

struct SVMINTRPContext_ComputeSP {
	/* Common for INTRP */
	SVMINTRP_BASE_ELEMENTS()
	/* Compute SP Params */
	RMuint32 ClipID;
	RMuint32 SP_ID;
	RMuint8  SP[16];
	RMuint8  FM_ID[8];
};

struct SVMINTRPContext_InitializeMedia {
	/* Common for INTRP */
	SVMINTRP_BASE_ELEMENTS()
};

struct SVMINTRPContext_InitializeTitle {
	/* Common for INTRP */
	SVMINTRP_BASE_ELEMENTS()
	/* Initialize Title Params */
	RMuint32 TitleNumber;
};

struct SVMINTRPContext_Shutdown {
	/* Common for INTRP */
	SVMINTRP_BASE_ELEMENTS()
};

/* Software interrupt Context */
union SVMINTRP {
	struct SVMINTRPContext_base             base;
	struct SVMINTRPContext_ApplicationLayer applayer;
	struct SVMINTRPContext_ComputeSP        computesp;
	struct SVMINTRPContext_InitializeMedia  initmedia;
	struct SVMINTRPContext_InitializeTitle  inittitle;
	struct SVMINTRPContext_Shutdown         shutdown;
};

#endif

