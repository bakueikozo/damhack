#ifndef __SPDC_VERSION_H__
#define __SPDC_VERSION_H__

#define SPDC_LIBRARY_NAME "librmspdc.1_3.Maa.so"

#endif /* __SPDC_VERSION_H__ */
