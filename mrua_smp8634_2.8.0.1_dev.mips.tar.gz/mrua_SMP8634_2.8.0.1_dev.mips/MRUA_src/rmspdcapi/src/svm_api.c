/****************************************************************************
 *    Copyright (c) Sigma Designs, Inc. 2006. All rights reserved.
 **/
/**
 *      @file       svm_api.c
 *
 *      @brief      Stub Implementation of an API for launching/interacting
 *                  with BD+ Virtual Machine.
 *
 *      @author     Alan / Fabrice
 *      
 ****************************************************************************/

#include "rmdef/rmdef.h"
#include "rmdrm/include/rmdrm.h"
#include "../include/svm_api.h"
#include "../include/svm_version.h"
#include "svm_interface.h"


static struct svm_interface_s *g_svm_interface;

RMstatus SVM_Init(struct SVM** pSVMContext, struct SVM_Callbacks *pSVMCallbacks, void *callback_ctx,
		  RMuint8* svm_ram_addr, RMuint32 rua_addr, RMuint32 svm_ram_size, RMuint32 xtask_flash_page)
{
	// Try to load the shared library if not done yet
        if(g_svm_interface==NULL) {
		g_svm_interface = load_drm(SPDC, NULL);
	}
	
        if(g_svm_interface) {
		RMDBGLOG((ENABLE,"&SVM_Init = 0x%08lx\n&SVM_Term = 0x%08lx\n,&SVM_QueueIntrp = 0x%08lx,&SVM_VMRun = 0x%08lx\n",g_svm_interface->SVM_Init,
		              g_svm_interface->SVM_Term, g_svm_interface->SVM_QueueInterrupt, g_svm_interface->SVM_VMRun));
		return g_svm_interface->SVM_Init(pSVMContext, pSVMCallbacks, callback_ctx,
		                                 svm_ram_addr, rua_addr, svm_ram_size, xtask_flash_page);
	}
        else
		return RM_ERROR;
}


RMstatus SVM_Init_Preloaded(struct SVM** pSVMContext, struct SVM_Callbacks *pSVMCallbacks, void *callback_ctx,
		  RMuint8* svm_ram_addr, RMuint32 rua_addr, RMuint32 svm_ram_size, RMuint32 xtask_flash_page, RMuint32 xtask_slot_id)
{
	// Try to load the shared library if not done yet
        if(g_svm_interface==NULL) {
		g_svm_interface = load_drm(SPDC, NULL);
	}
	
        if(g_svm_interface) {
		RMDBGLOG((ENABLE,"&SVM_Init_Preloaded= 0x%08lx\n&SVM_Term = 0x%08lx\n,&SVM_QueueIntrp = 0x%08lx,&SVM_VMRun = 0x%08lx\n",g_svm_interface->SVM_Init_Preloaded,
		              g_svm_interface->SVM_Term, g_svm_interface->SVM_QueueInterrupt, g_svm_interface->SVM_VMRun));
		return g_svm_interface->SVM_Init_Preloaded(pSVMContext, pSVMCallbacks, callback_ctx,
		                                 svm_ram_addr, rua_addr, svm_ram_size, xtask_flash_page, xtask_slot_id);
	}
        else
		return RM_ERROR;
}


RMstatus SVM_Term(struct SVM *pSVMContext)
{
	if(g_svm_interface) return g_svm_interface->SVM_Term(pSVMContext);
	else return RM_ERROR;
}

RMstatus SVM_QueueInterrupt(struct SVM* pSVMContext, union SVMINTRP* pSVMINTRPContext)
{
	if(g_svm_interface) return g_svm_interface->SVM_QueueInterrupt(pSVMContext, pSVMINTRPContext);
	else return RM_ERROR;
}

RMstatus SVM_VMRun(struct SVM* pSVMContext, RMint32 *numCycles)
{
	if(g_svm_interface) return g_svm_interface->SVM_VMRun(pSVMContext, numCycles);
	else return RM_ERROR;
}

