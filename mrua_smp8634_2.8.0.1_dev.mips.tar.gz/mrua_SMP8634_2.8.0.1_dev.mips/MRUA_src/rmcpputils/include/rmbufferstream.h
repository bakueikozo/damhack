/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   rmbufferstream.h
  @brief  

  This is the class of a stream based on a buffer.

  @author Julien Soulier
  @date   2001-09-07
*/

#ifndef __RMBUFFERSTREAM_H__
#define __RMBUFFERSTREAM_H__

/**
   Class to get bits from a bitstream. 
*/ 
class RM_LIBRARY_IMPORT_EXPORT RMbufferStream: public RMobject
{
 public:
	RMbufferStream(RMuint8 *buf, RMuint64 size);


        /**
           Default destructor

	*/
	virtual ~RMbufferStream();


        /**
	   Return size bits from the bitstream. Move the position of
	   the pointer in the stream for the next read call. This
	   fucntion doesn't check any error or end of stream.
	   
	   @param size  number of bits to get from the bitstream
	   @return the value composed of the size bits.
	*/
	virtual RMuint64 GetBits(RMuint8 size);


	/**
	   The same as the previous GetBits except that it checks some
	   error.
	   
	   @param size  number of bits to get from the bitstream
	   @param value value composed by the size bits.
	   @return number of bits read
	*/
	virtual RMuint8 GetBits(RMuint8 size, RMuint64 *value);


        /**
           Writes size bits in the buffer stream.

           @param size  nb of bits to write.
           @param value value to write.
           @return nb of bits written.
	*/
	virtual RMuint8 SetBits(RMuint8 size, RMuint32 value);


        /**
	   Return size bits from the bitstream. Does not Move the
	   position of the pointer in the stream so the next read call
	   will be return the same thing. This fucntion doesn't check
	   any error or end of stream.
	   
	   @param size  number of bits to get from the bitstream
	   @return the value composed of the size bits.
	*/
	virtual RMuint64 ShowBits(RMuint8 size);


	/**
	   The same as the previous ShowBits execpt that it checks some
	   error.
	   
	   @param size  number of bits to get from the bitstream
	   @param value value composed by the size bits.
	   @return number of bits read
	*/
	virtual RMuint8 ShowBits(RMuint8 size, RMuint64 *value);


        /**
           Reads a 32 bits integer encoded as in the VTC bitstream.

           @param nbits encodage parameter
           @param nbytes number of bytes of the encoded parameter       
           @return the decoded parameter
	*/
	virtual RMint32 GetParam(RMuint8 nbits, RMuint8 *nbytes);


	/**
	   Encodes a 32 bits integer to a VTC parameter.

           @param nbits encodage parameter
           @param size the decoded parameter      
           @return the number of bytes needed to encode.
	*/   
	virtual RMuint8 SetParam(RMuint8 nbits, RMuint32 *size);


        /**
           Decodes a size parameter as in objectdescriptor in MPeg-4

           @param nbytes number of bytes of the encoded size.
           @return the decoded size.
	*/
	virtual RMuint32 DecodeSize(RMuint8 *nbytes);


	/** 
	    get the current position in the bitstream
	*/
	virtual RMuint32 GetCurrentPosition(void);

	/** 
	    get the number of octets read from the bitstream
	*/
	virtual RMuint32 GetNbOctetRead();
         
        /**
           flush the last word in the buffer
	   used only to write in a buffer
	
           @param 	
	*/

	virtual void Flush();

	virtual void AlignBytes();

	virtual RMuint64 GetTotalSize();

 private:
	RMint8   m_bits;
	RMuint64 m_word;
	RMuint8 *m_buf;
	RMuint64 m_size;
	RMuint64 m_bytes;
};

#endif // __RMBUFFERSTREAM_H__

