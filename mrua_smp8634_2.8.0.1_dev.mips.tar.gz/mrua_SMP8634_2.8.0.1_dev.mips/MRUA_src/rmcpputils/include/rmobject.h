/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   object.h
  @brief  implementation of the base class of all nodes.

  @author Julien Soulier, Emmanuel Michon
  @date   2001-02-06
*/

/**
   @page naminglayout Files naming and layout conventions
   
   @subsection naming Naming

   - files names are not limited to 8+3 characters. Do not
   use names like cqsrbrd.c or micros~1. 
   However, file names with spaces are a pain to handle.
   - remember most operating systems use case-sensitive
   file names. UNIX for example can't include "MyFile.h" 
   properly if its name is not exactly MyFile.h on the disk.
   - file line termination is not a problem anymore, both
   terminations ^M^J (DOS-style) and ^J (UNIX-style) are ok.
   - last line of a file should always have a final line
   termination (this confuses GNU C a lot).

   @subsection caseconcerns Case concerns
   
   - CARIBBEAN file names are written in lowercase
   - CARIBBEAN directory names are written beginning with an uppercase
   - CARIBBEAN functions and methods names all begin with RM;
   every sub-word begins with an uppercase. 
   @code
   RMWaitForThreadToFinish
   @endcode
   Local functions do not have to respect this rule (and they should be declared
   static).
   - CARIBBEAN types and classes names all begin with RM;
   excepted the first sub-word, every sub-word begins with an uppercase. 
   For instance
   @code
   RMmemoryZone
   @endcode
   You can declare a pointer to RMsomething as PRMsomething.

   @subsection layout Layout

   - we do not impose a rigid coding style; we advise reading
   the Linux kernel coding style below and only keep good ideas. Summary:
   - indentation is 8 SPACE characters and is not a ASCII TAB = 0x08 character
   - do not write extremely long functions, split them in small
   functional units
   - do not write deeply nested if-then-else statements
   - write macros to automatically copy&paste large blocks with
   only one word changing
   - do not overcomment .c or .cpp files; what the function does
   MUST be clear because its name is clear and because the
   algorithm used is small and correct. Remember comments must be kept
   up-to-date with the matching code.
   - DO COMMENT a tricky line for which reading-at-first understanding 
   is not the right in-depth understanding.

   @code
		Linux kernel coding style 

This is a short document describing the preferred coding style for the
linux kernel.  Coding style is very personal, and I won't _force_ my
views on anybody, but this is what goes for anything that I have to be
able to maintain, and I'd prefer it for most other things too.  Please
at least consider the points made here. 

First off, I'd suggest printing out a copy of the GNU coding standards,
and NOT read it.  Burn them, it's a great symbolic gesture. 

Anyway, here goes:


	 	Chapter 1: Indentation

Tabs are 8 characters, and thus indentations are also 8 characters. 
There are heretic movements that try to make indentations 4 (or even 2!)
characters deep, and that is akin to trying to define the value of PI to
be 3. 

Rationale: The whole idea behind indentation is to clearly define where
a block of control starts and ends.  Especially when you've been looking
at your screen for 20 straight hours, you'll find it a lot easier to see
how the indentation works if you have large indentations. 

Now, some people will claim that having 8-character indentations makes
the code move too far to the right, and makes it hard to read on a
80-character terminal screen.  The answer to that is that if you need
more than 3 levels of indentation, you're screwed anyway, and should fix
your program. 

In short, 8-char indents make things easier to read, and have the added
benefit of warning you when you're nesting your functions too deep. 
Heed that warning. 


		Chapter 2: Placing Braces

The other issue that always comes up in C styling is the placement of
braces.  Unlike the indent size, there are few technical reasons to
choose one placement strategy over the other, but the preferred way, as
shown to us by the prophets Kernighan and Ritchie, is to put the opening
brace last on the line, and put the closing brace first, thusly:

	if (x is true) {
		we do y
	}

However, there is one special case, namely functions: they have the
opening brace at the beginning of the next line, thus:

	int function(int x)
	{
		body of function
	}

Heretic people all over the world have claimed that this inconsistency
is ...  well ...  inconsistent, but all right-thinking people know that
(a) K&R are _right_ and (b) K&R are right.  Besides, functions are
special anyway (you can't nest them in C). 

Note that the closing brace is empty on a line of its own, _except_ in
the cases where it is followed by a continuation of the same statement,
ie a "while" in a do-statement or an "else" in an if-statement, like
this:

	do {
		body of do-loop
	} while (condition);

and

	if (x == y) {
		..
	} else if (x > y) {
		...
	} else {
		....
	}
			
Rationale: K&R. 

Also, note that this brace-placement also minimizes the number of empty
(or almost empty) lines, without any loss of readability.  Thus, as the
supply of new-lines on your screen is not a renewable resource (think
25-line terminal screens here), you have more empty lines to put
comments on. 


		Chapter 3: Naming

C is a Spartan language, and so should your naming be.  Unlike Modula-2
and Pascal programmers, C programmers do not use cute names like
ThisVariableIsATemporaryCounter.  A C programmer would call that
variable "tmp", which is much easier to write, and not the least more
difficult to understand. 

HOWEVER, while mixed-case names are frowned upon, descriptive names for
global variables are a must.  To call a global function "foo" is a
shooting offense. 

GLOBAL variables (to be used only if you _really_ need them) need to
have descriptive names, as do global functions.  If you have a function
that counts the number of active users, you should call that
"count_active_users()" or similar, you should _not_ call it "cntusr()". 

Encoding the type of a function into the name (so-called Hungarian
notation) is brain damaged - the compiler knows the types anyway and can
check those, and it only confuses the programmer.  No wonder MicroSoft
makes buggy programs. 

LOCAL variable names should be short, and to the point.  If you have
some random integer loop counter, it should probably be called "i". 
Calling it "loop_counter" is non-productive, if there is no chance of it
being mis-understood.  Similarly, "tmp" can be just about any type of
variable that is used to hold a temporary value. 

If you are afraid to mix up your local variable names, you have another
problem, which is called the function-growth-hormone-imbalance syndrome. 
See next chapter. 

		
		Chapter 4: Functions

Functions should be short and sweet, and do just one thing.  They should
fit on one or two screenfuls of text (the ISO/ANSI screen size is 80x24,
as we all know), and do one thing and do that well. 

The maximum length of a function is inversely proportional to the
complexity and indentation level of that function.  So, if you have a
conceptually simple function that is just one long (but simple)
case-statement, where you have to do lots of small things for a lot of
different cases, it's OK to have a longer function. 

However, if you have a complex function, and you suspect that a
less-than-gifted first-year high-school student might not even
understand what the function is all about, you should adhere to the
maximum limits all the more closely.  Use helper functions with
descriptive names (you can ask the compiler to in-line them if you think
it's performance-critical, and it will probably do a better job of it
that you would have done). 

Another measure of the function is the number of local variables.  They
shouldn't exceed 5-10, or you're doing something wrong.  Re-think the
function, and split it into smaller pieces.  A human brain can
generally easily keep track of about 7 different things, anything more
and it gets confused.  You know you're brilliant, but maybe you'd like
to understand what you did 2 weeks from now. 


		Chapter 5: Commenting

Comments are good, but there is also a danger of over-commenting.  NEVER
try to explain HOW your code works in a comment: it's much better to
write the code so that the _working_ is obvious, and it's a waste of
time to explain badly written code. 

Generally, you want your comments to tell WHAT your code does, not HOW. 
Also, try to avoid putting comments inside a function body: if the
function is so complex that you need to separately comment parts of it,
you should probably go back to chapter 4 for a while.  You can make
small comments to note or warn about something particularly clever (or
ugly), but try to avoid excess.  Instead, put the comments at the head
of the function, telling people what it does, and possibly WHY it does
it. 
   @endcode
*/

/**
   @page subset Details of C++ language subset used in CARIBBEAN 

   The C++ language (or: the C++ dialect implemented by your compiler) allows a large 
   variety of features involving: portability concerns, intricated object-oriented paradigms,
   binary code size, runtime pointer arithmetic...

   We decided to restrict strongly the allowed combinations according to this summary:

   @subsection enhancements Non object-oriented enhancement over plain C:
   
   - YES: one-line comments
   @code
   // This is a one-line comment.
   @endcode
   - USE WITH CARE: two functions can have the same name and be different if they take different parameters
   [mostly useful for constructors]
   - USE WITH CARE: a function can be declared inline
   [a pain to see function bodies in .h files. Exception for trivial constructors]
   - USE WITH CARE: will-be-defined-later types 
   (only way for mutually referrent struct or classes)
   @code
   struct date;
   @endcode
   [preprocessor tricks have to work the same way for C and C++]
   - DON'T USE: variable declaration can happen in the middle of a { ... } block 
   [makes porting back to plain C a pain]
   - DON'T USE: variables can be declared inside a for loop declaration 
   [same reason]
   - DON'T USE: variables can be initialized by a calculation involving other variables 
   [same reason]
   - DON'T USE: global variables can be accessed even if a local variables has the same name (::x and x)
   [code clarity please]
   - DON'T USE: it is possible to declare a REFERENCE towards another variable with & 
   [ruins the way plain C programmers think. Prevents the self-assignment bug]
   - DON'T USE: exceptions.
   [stack-smashing jumps make it difficult to catch malloc/free balance faults]
   - DON'T USE: functions can have default parameters
   [what for?]
   - DON'T USE: struct shortcut
   @code
   typedef struct tagBinom { int x; int y; } Binom;
   tagBinom binom;
   @endcode
   [GCC complains about this]
   - DON'T USE: function-like typecasting, writing LONG(x) for (LONG)x

   @subsection oofeatures RMobject-oriented features:
   - YES: simple inheritance
   - YES: overriding methods
   - YES: virtual functions, pure virtual functions
   [necessary to access the methods of a module without dlsym/GetProcAddress on all methods names]
   - YES: static members (much better than global variables)
   - YES: new/delete. It is pointless to test for NULLity before calling new or delete (see C++ FAQs)
   - USE WITH CARE: initialization of members with fancy syntax (for constructors only)
   @code
   DummyRMnode::DummyRMnode()
   :m_refcount(0)
   { 
   ... 
   }
   @endcode
   - USE WITH CARE: ``protected''
   [keep things simple and clear]
   - USE WITH CARE: symbolic operators (+ - * / ...) can be redefined for new data types
   - USE WITH CARE: a method can call ``delete this''
   [use with extreme care]
   - DON'T USE: defining a class inside a class
   - DON'T USE: multiple inheritance
   [involves tricky pointer resolution, not part of embedded C++]
   - DON'T USE: virtual inheritance
   @code
   class foo: virtual bar;
   @endcode
   [involves tricky pointer arithmetic, not part of embedded C++]
   - DON'T USE: templates
   [not part of embedded C++]
   - DON'T USE: the copy constructor
   [REFERENCE variable are not allowed]
   - DON'T USE: stream objects, cout, >> notations and friends
   [makes porting back to plain C a pain]
   - DON'T USE: ``friend''
   [keep things simple and clear]

   @subsection remember Keep in mind for safe programming:
   - C++FAQ: in C f() notation as a typedef is a generic notation for a variable
   number of args. in C++ it means f(void). 	
   - C++ allows typedef redefinition if redefinition is the same, but not C.
   - C++FAQ: ``sizeof('x') is equal to sizeof(char) in C++ but is equal to sizeof(int) in C''
   - C++FAQ: static initialization order fiasco is a very subtle and 
   commonly misunderstood aspect of C++. Unfortunately it's very hard 
   to detect --- the errors occur before main() begins.
   [order of variable declaration can be important in C++ if constructors
   have to be called in a certain order]
   - multiple inheritance of pure virtual functions allows the address
   of a typecast to change (see inheritance/dummynode.cpp) (won't happen in CARIBBEAN)
*/   

/**   
   @page rmframework C++ rmframework architecture: objects
   
   @subsection object RMobject
   @anchor anchorobject
   Usually you never use directly an RMobject but a class inheriting from the top-level class RMobject
   doing something useful.

   So, the RMnode class inherits from RMobject and compells the programmer to implement
   the needed functions to receive samples, process them, etc.

   For instance, a Proxy class inheriting from the RMnode class will be able to fullfill three missions:
   -# receive and process samples,
   -# keep a clock up to date and serve as a reference for other nodes,
   -# have the ability to receive and process stream change properties (such as: switch from NTSC to PAL).
   
   First mission can be considered as the main purpose of the Proxy seen as a RMnode.
   Ability to receive, play, pause comes from the RMnode class methods (that may be overridden
   if a more complex implementation of receive, play, pause is needed).
   
   Second and third missions can be considered as side effects or bonus features of the first one.

   So that other RMnodes may ask for a reference clock, an RMobject has to export an Interface
   hiding the implementation details. If another RMnode implements differently a reference clock Interface,
   switching from one to the other must be immediate.

   To achieve this goal any entity inheriting from RMobject has a RequestInterface method allowing
   a ``client'' RMnode to ask if the considered RMnode can fullfill such or such mission.
   Once one or more ``clients'' use the interface of a ``server'' node, Acquire/Release methods 
   are used to keep track of the number of ``clients'', so that a RMnode cannot complete its cleanup
   routines while this number is not zero.

   Implementation of Acquire and Release can be found in object.cpp and is (normally) never
   overridden. It is thread-safe.

   As soon as a class implements an Interface, the RequestInterface method must be 
   appropriately overridden to match its actual abilities. 

   If Y inherits from X, and Z wants to access an interface of X by a call to Y::RequestInterface, 
   the following should happen (schematically):
   @code
   RMstatus Y::RequestInterface(RMiid iid) 
   {
   if (iid==Yknowsaboutthisone) {
   ...
   }
   else if (iid==Yknowsaboutthisonealso) {
   ...
   }
   else return X::RequestInterface(iid)
   }
   @endcode

   Each node has a unique identificator that allows proper referencing in the module loader
   and possibly in other places (defined in enumtypes.h, see RMnid).

   [Please refer to @ref anchorinterface "Interface" section above for the rest of the explanations.]
*/

#ifndef __RMOBJECT_H__
#define __RMOBJECT_H__

/**
   Parent class of all the other classes. It implements all the basic features
   that a class must provide. */
class RM_LIBRARY_IMPORT_EXPORT RMobject 
{
 public:

        /// 
        /**
           Constructor.
	   Initializes the reference counter and its lock.
	   It also set the name of the class, for debugging purpose.

           @param RMstring : name of the class.	
	*/
	RMobject(const RMascii *name);

	//
	/**
	   A default constructor.
	 */
	RMobject ();
	
        /// 
        /**
	   Default Destructor.
	   Destroys the reference counter lock.

           @param void	
	*/
	virtual ~RMobject(void);
	
	/**
	   This is the equivalent of 'placement new'.

	   @param size  
	   @param p buffer to return from new.
	   @return 
	 */
	void *operator new(RMnewOperatorSize size, RMuint8 *const p);

	/**
	   Overriding new operator to use RMMalloc.
	   
	   We cannot define it another way.
	   
	   @param size  
	   @return 
	*/
	void *operator new(RMnewOperatorSize size);
	
	/**
	   overriding delete operator to use RMFree.
	   
	   @param ptr   
	   @return 
	*/
	void operator delete(void *ptr);

	void *operator new[](RMnewOperatorSize size);
	void operator delete[](void *ptr);

        /// 
        /**
           Must be called before using for the first time an object.
	   This allow to know when an object is not used anymore and
	   to destroy it only when it is safe.

           @param void	
	*/
	virtual void Acquire(void);
	
        /// 
        /**
           Must be called when you don't need anymore to use the object.
	   If after this call the reference counter is zero, then the object
	   is deleted.

           @param void	
	*/
	virtual RMstatus Release(void);

	virtual const RMascii *GetObjectName (void) const;

	virtual void PrintRefCount (void);

#ifdef WITH_THREADS
	static void CreateLock(void);
	static void DeleteLock(void);
#endif // WITH_THREADS

 private:
	/** reference counter to keep trace of the number of users of an object */
	RMuint32 m_RefCount;
#ifdef _DEBUG
	RMascii *m_name;
#endif // _DEBUG

#ifdef WITH_THREADS
	static RMcriticalsection m_critSec;
#endif // WITH_THREADS

 private:
	void InitObject (void);
};

#endif // __RMOBJECT_H__
