/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   rmreadwritebufferstream.h
  @brief  

  This is the class of a stream based on a buffer.

  @author Laurent Crinon
  @date   2003-11-20
*/

#ifndef __RMRDWRBUFFERSTREAM_H__
#define __RMRDWRBUFFERSTREAM_H__

/**
   Class to get or set bits from a bitstream. 
*/ 
class RM_LIBRARY_IMPORT_EXPORT RMrdWrBufferStream: public RMobject
{
 public:
	RMrdWrBufferStream(RMuint8 *buf, RMuint64 size);
	RMrdWrBufferStream(RMuint8 *buf, RMuint64 size, 
			   RMuint8 *previousBuf, RMuint64 sizePreviousBuf);

        /**
           Default destructor

	*/
	virtual ~RMrdWrBufferStream();


	/**
	    Return size bits from the bitstream. Move the position of
	   the pointer in the stream for the next read call. 
	   
	   @param size  number of bits to get from the bitstream
	   @param value value composed by the size bits.
	   @return number of bits read
	*/
	virtual RMuint8 GetBits(RMuint8 size, RMint64 *value);


        /**
           Writes size bits in the buffer stream.

           @param size  nb of bits to write.
           @param value value to write.
           @return nb of bits written.
	*/
	virtual RMuint8 SetBits(RMuint8 size, RMint64 value);


	/**
	   Return size bits from the bitstream. Does not Move the
	   position of the pointer in the stream so the next read call
	   will be return the same thing.
	   
	   @param size  number of bits to get from the bitstream
	   @param value value composed by the size bits.
	   @return number of bits read
	*/
	virtual RMuint8 ShowBits(RMuint8 size, RMint64 *value);



	/** 
	    get the current position in the bitstream
	*/
	void GetCurrentPosition(RMuint64 *bytesPosition, RMuint8 *bitsPostion);
	void GetCurrentPosition(RMuint64 *bytesPosition, RMuint8 *bitsPostion, RMuint64 *bytesPositionInPreviousBuffer, RMuint8 *bitsPostionInPreviousBuffer);

	virtual void AlignBytes();

	virtual RMuint64 GetTotalSize();

	virtual void SkipBits(RMuint32 size);

	virtual void Reset();

	void Rewind(RMuint32 size);

 private:
	RMint8   m_bits;
	RMuint8 *m_buf;
	RMuint64 m_size;
	RMuint64 m_bytes;	

	RMuint8 *m_previousBuffer;
	RMbool m_using2Buffers;
	RMuint64 m_bytesPreviousBuffer;
	RMint8 m_bitsPreviousBuffer;
	RMuint64 m_sizePreviousBuffer;	
};

#endif // __RMRDWRBUFFERSTREAM_H__

