/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   rmfilestream.h
  @brief  

  This is the class of a stream based on a file.

  @author Julien Soulier
  @date   2001-09-07
*/

#ifndef __RMFILESTREAM_H__
#define __RMFILESTREAM_H__

typedef enum {
	RM_FILESTREAM_BIG_ENDIAN = 1,
	RM_FILESTREAM_LITTLE_ENDIAN,
} RMfileStreamEndianess;

/**
   This class is used to manipulate a file as a stream. This means
   this allow to call function as getInt32.
*/
class RM_LIBRARY_IMPORT_EXPORT RMfileStream: public RMobject
{ 
 public:
	
        /** 
	    Default constructor
	*/
	RMfileStream();
	

        /**
           Default destructor
	*/
	virtual ~RMfileStream();


        /**
           Create a new filestream which is clone of the current fileStream

           @param fs	
	*/
	virtual RMfileStream *Clone();


        /**
           Set the cache size to 'newCacheSize'

           @param newCacheSize
	*/
	virtual RMstatus SetCacheSize(RMuint32 newCacheSize);
        /**
           Opens the file.

           @param name file name
           @return RM_ERROR if the file does not exists
	*/
	virtual RMstatus OpenFile(const RMnonAscii *name, RMuint32 cacheSize, RMfileStreamEndianess endian);

        /**
           Build a RMfilestream based on an already opened file.

           @param file - opened file (can be a custom file)
	   @param cacheSize
	   @param endian
           @return RM_ERROR if the file does not exists
	*/
	virtual RMstatus OpenExternalFile(RMfile file, RMuint32 cacheSize, RMfileStreamEndianess endian);

        /**
           Opens a custom filestream.

           @param cookie - the cookie that will be passed to the RMFileOps
	   @param cacheSize
	   @param RMfileStreamEndianess
	   @param ops - file operations for this custom file
           @return RM_ERROR if the file does not exists
	*/
	virtual RMstatus OpenFileCookie(void *cookie, RMuint32 cacheSize, RMfileStreamEndianess endian, RMFileOps *ops);
	
        /**
           @return the current postion in the file.
	*/
	virtual RMuint64 GetPos();

	
        /**
           Sets the position in the file.

           @param pos 
	   @return the number of bytes skip if the new position is
           greater than the old one. O otherwise.
	*/
	virtual RMstatus SetPos(RMuint64 pos);


        /**
           Sets the position to the end of the file

           @return number of bytes seeked
	*/
	virtual RMstatus GotoEnd();


        /**
           Reads an int64 from the file.

           @param val   
           @return number of bytes actually read (8 = OK)
	*/
	virtual RMuint8 GetInt64(RMuint64 *val);


        /**
           Reads an int32 from the file.

           @param val   
           @return number of bytes actually read (4 = OK)
	*/
	virtual RMuint8 GetInt32(RMuint32 *val);


        /**
           Reads an int24 from the file.

           @param val   
           @return number of bytes actually read (3 = OK)
	*/
	virtual RMuint8 GetInt24(RMuint32 *val);


        /**
           Reads an int16 from the file.

           @param val   
           @return number of bytes actually read (2 = OK)
	*/
	virtual RMuint8 GetInt16(RMuint16 *val);


        /**
           Reads an int8 from the file.

           @param val   
           @return number of bytes actually read (1 = OK)
	*/
	virtual RMuint8 GetInt8(RMuint8 *val);


        /**
           Reads a string. Reads bytes until one is 0.

           @param string        
           @return size of the string.
	*/
	virtual RMstatus GetString(RMascii *string, RMuint32 *length);


        /**
           Reads size bytes in the file

           @param size  
           @param buf   
           @return number of bytes actually read
	*/
	virtual RMstatus GetBytes(RMuint32 size, RMuint8 *buf);


        /**
           Reads size bytes at offset. This call is "atomic".

           @param offset        
           @param size  
           @param buf   
           @return number of bytes actually read.
	*/
	virtual RMstatus ReadOffset(RMuint32 offset, RMuint32 size, RMuint8 *buf);
	
        /**
           Reads all the bytes from the current position to the end

           @param buf   
           @return number of bytes actually read.
	*/
	virtual RMstatus GetFinalBytes(RMuint8 **buf);


        /**
           Tests if End of file is reached

           @return TRUE or FALSE
	*/
	virtual RMbool EndOfFile();

	virtual RMstatus GetFileDescriptor(RMfile *fileDescriptor);

 private:
	RMbool Hit(RMuint64 pos);
	RMstatus UpdateCache(RMuint32 size);

 private:
	RMfile  m_file;
	RMbool  m_eof;
	RMuint64 m_cachePos;
	RMuint8 *m_cache;
	RMuint32 m_cacheSize;
	RMuint32 m_size;
	RMuint32 m_offset;
	RMint64 m_fileSize;
	RMbool m_closeFile;
	RMfileStreamEndianess m_endian;
};


#endif // __RMFILESTREAM_H__
