/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmcpputils.h
  @brief  

  long description

  @author Emmanuel Michon
  @date   2003-02-10
*/

#ifndef __RMCPPUTILS_H__
#define __RMCPPUTILS_H__

#include "rmlibcw/include/rmlibcw.h"

#include "rmobject.h"

#include "rmbufferstream.h"
#include "rmreadwritebufferstream.h"
#include "rmfilestream.h"

#endif // __RMCPPUTILS_H__
