/*****************************************
 Copyright � 2001-2005  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmcdfs.h
  @brief  

  @author 
  @date   2005-10-17
*/

#ifndef __RMCDFS_H__
#define __RMCDFS_H__

RM_EXTERN_C_BLOCKSTART

// for LSB - 0, for MSB 1
#define L_M_TYPE 0

#define RM_CDFS_MAX_PATHNAME_LENGTH 255
#define RM_CDFS_MAX_ID_LENGTH       255

#define RM_UDFS_MAX_PATHNAME_LENGTH 255
#define RM_UDFS_MAX_ID_LENGTH       255

#define RM_FLAGS_DIRECTORY          0x02
#define RM_FLAGS_PROTECTION         0x10

#define RM_CDFS_UDF_INVALID_HANDLE   0
#define RM_CDFS_UDF_SEEK_SET         0
#define RM_CDFS_UDF_SEEK_CUR         1
#define RM_CDFS_UDF_SEEK_END         2

typedef void *(*RM_MEMALLOC)(RMuint32 dwNumBytes);
typedef void (*RM_MEMFREE)(void *);

// this function must not write more than dwBufSizeInBytes in the buffer
typedef RMuint32 (*RM_ATA_SEND_CMD)(RMuint8 bDrive, RMuint8 *pCmd, RMuint8 *pbIoBuf,
				    RMuint32 dwBufSizeInBytes, void *cookie);

typedef void (*RM_CLOSE_FILE)(void *cookie);

/** Internal structure used to mount/unmount drive */
struct RM_CDFS_UDF_VOLUME;

struct RM_CDFS_UDF_CALLBACK_TABLE
{
	RM_ATA_SEND_CMD      Ata_SendCmd;
	RM_MEMALLOC          mmalloc;
	RM_MEMFREE           mfree;
	RM_CLOSE_FILE        File_Close;
}; 

/** Exported symbol, suitable for use with RMOpenFileCookie, see rmfile.h */
RM_LIBRARY_IMPORT_EXPORT extern void *pcdfsFileOps;
RM_LIBRARY_IMPORT_EXPORT extern void *pudfsFileOps;

struct RM_CDFS_UDF_FOPS_COOKIE {
	RMuint32 hFileHandle;
	struct RM_CDFS_UDF_VOLUME *volume;
	void *user_cookie;
};

/***************************************************************
                           ECMA-119
***************************************************************/

RMstatus RMcdfs_mount(struct RM_CDFS_UDF_CALLBACK_TABLE *pCallbackTable, 
		      struct RM_CDFS_UDF_VOLUME **volume, void *cookie);
RMstatus RMcdfs_umount(struct RM_CDFS_UDF_VOLUME *volume);

/***************************************************************
This function enables caching
Parameters:
RMuint8 *pBuffer    - a buffer for cashing, supplied by the user
RMuint32 bufferSize - total size of the cash buffer in bytes
RMuint32 segments - number of the cash segments
Notes:
1) bufferSize must be >= LSsize * segments;
2) segment must be >= LSsize bytes;
3) maximum segments number - 512
To disable cashing pass NULL as pBuffer (default)
****************************************************************/

RMstatus RMcdfs_enable_cache(RMuint8 *pBuffer, RMuint32 bufferSize, RMuint32 segments);


struct RM_CDFS_DIR_ENTRY_INFO
{
	RMuint16 year;
	RMuint8  day;
	RMuint8  month;
	RMuint8  hour;
	RMuint8  min;
	RMuint8  sec;
	RMint8   GreenwichOffset;
	RMuint16 ownerId;
	RMuint16 groupId;
	RMuint16 permissions;
	RMint16  version;
	RMint32  size;
	RMuint32 nameLength; // in bytes
	RMuint32 parentDirNameLength; // in bytes
	RMuint8  unicodeName;
	RMint8   name[RM_CDFS_MAX_ID_LENGTH];
	RMint8   parentDirName[RM_CDFS_MAX_ID_LENGTH];
	RMint8   flags;
};

/****************************************************************
The path is a unix style path (/Dir1/Dir2/.../DirN/File).
cdfs_fopen and cdfs_dopen take a path from ROOT as 1st parameter.
For cdfs_fopenW and cdfs_dopenW 1st parameter should be
a most significant byte first string.
*****************************************************************/

RMstatus RMcdfs_fopen(RMuint8 *pFullFileName, RMuint32 *phFileHandle);
RMstatus RMcdfs_fopenW(RMuint16 *pFullFileName, RMuint32 *phFileHandle);
RMstatus RMcdfs_fclose(RMuint32 hFileHandle);
RMstatus RMcdfs_fread(RMuint32 hFileHandle, RMuint8 *pbBufUser, RMuint32 nBytesToRead, RMuint32 *pnBytesRead);
RMstatus RMcdfs_fsize(RMuint32 hFileHandle, RMuint32 *pdwFileSize);
RMstatus RMcdfs_ftell(RMuint32 hFileHandle, RMuint32 *pdwInternalCurPos);
RMstatus RMcdfs_fseek(RMuint32 hFileHandle, RMint32 dwPosRel, RMint32 dwFlagRel);
RMstatus RMcdfs_feof(RMuint32 hFileHandle, RMuint32 *pdwFEOF);

RMstatus RMcdfs_dopen(RMuint8 *pFullDirName, RMuint32 *phDirHandle);
RMstatus RMcdfs_dopenW(RMuint16 *pFullDirName, RMuint32 *phDirHandle);
RMstatus RMcdfs_dclose(RMuint32 hDirHandle);
RMstatus RMcdfs_dread(RMuint32 hDirHandle, struct RM_CDFS_DIR_ENTRY_INFO *pDirInfo);
RMstatus RMcdfs_dseek(RMuint32 hDirHandle, RMuint32 dwZeroBasedIndexValidEntry);




/***************************************************************
                     ECMA-167 / UDF 2.01
***************************************************************/

RMstatus RMudfs_mount(struct RM_CDFS_UDF_CALLBACK_TABLE *pCallbackTable, 
		      struct RM_CDFS_UDF_VOLUME **volume, void *cookie);
RMstatus RMudfs_umount(struct RM_CDFS_UDF_VOLUME *volume);

/***************************************************************
This function enables cashing
Parameters:
RMuint8 *pBuffer    - a buffer for cashing, supplied by the user
RMuint32 bufferSize - total size of the cash buffer in bytes
RMuint32 segments - number of the cash segments
Notes:
1) bufferSize must be >= LSsize * segments;
2) segment must be >= LSsize bytes;
3) maximum segments number - 512
To disable cashing pass NULL as pBuffer (default)
****************************************************************/

RMstatus RMudfs_enable_cache(RMuint8 *pBuffer, RMuint32 bufferSize, RMuint32 segments);

/***************************************************************
This function sets the separator, which from now on will be
used in path strings to separate path components.
Parameters:
RMuint16 sep - 16-bit separator
Notes:
1) this function has to be called after udfs_mount function
2) default separator is 16-bit '/' character (MSB first)
***************************************************************/

RMstatus RMudfs_set_separator(RMuint16 sep);

struct RM_UDFS_DIR_ENTRY_INFO
{

	RMuint8  modType;
	RMint16  modCUTOffset; // in minutes
	RMuint16 modYear;
	RMuint8  modMonth;
	RMuint8  modDay;
	RMuint8  modHour;
	RMuint8  modMin;
	RMuint8  modSec;
	RMuint8  accType;
	RMint16  accCUTOffset; // in minutes
	RMuint16 accYear;
	RMuint8  accMonth;
	RMuint8  accDay;
	RMuint8  accHour;
	RMuint8  accMin;
	RMuint8  accSec;

	RMuint32 ownerId;
	RMuint32 groupId;
	RMuint32 permissions;
	RMuint64 size;

	RMuint32  nameLength; // in bytes
	RMuint32  parentDirNameLength; // in bytes
	RMuint16  name[RM_UDFS_MAX_ID_LENGTH];
	RMuint16  parentDirName[RM_UDFS_MAX_ID_LENGTH];
	RMint16   version;
	RMint8    flags;
};

/****************************************************************
The path is a 16-bit (MSB first) string ("/CDROM/Dir1/Dir2/.../DirN/File").
The path is considered to be a path from ROOT directory.
To open ROOT directory use string "/CDROM"
Note: default '/' separator in the path can be changed
using udfs_set_separator function.
*****************************************************************/

RMstatus RMudfs_fopen(RMuint16 *pFullFileName, RMuint32 *phFileHandle);
RMstatus RMudfs_fclose(RMuint32 hFileHandle);
RMstatus RMudfs_fread(RMuint32 hFileHandle, RMuint8 *pbBufUser, RMuint32 nBytesToRead, RMuint32 *pnBytesRead);
RMstatus RMudfs_fsize(RMuint32 hFileHandle, RMuint64 *pddwFileSize);
RMstatus RMudfs_ftell(RMuint32 hFileHandle, RMuint64 *pddwInternalCurPos);
RMstatus RMudfs_fseek(RMuint32 hFileHandle, RMint64 ddwPosRel, RMint32 dwFlagRel);
RMstatus RMudfs_feof(RMuint32 hFileHandle, RMuint32 *pdwFEOF);
RMstatus RMudfs_fgetstartlogicaladdress(RMuint32 hFileHandle, RMuint32 *pLogicalAddress);

RMstatus RMudfs_dopen(RMuint16 *pFullDirName, RMuint32 *phDirHandle);
RMstatus RMudfs_dclose(RMuint32 hDirHandle);
RMstatus RMudfs_dread(RMuint32 hDirHandle, struct RM_UDFS_DIR_ENTRY_INFO *pDirEntryInfo);
RMstatus RMudfs_dseek(RMuint32 hDirHandle, RMuint32 dwZeroBasedIndexValidEntry);
RMstatus RMudfs_set_disc_structure_cache (RMuint8 *pBuffer, RMuint32 bufferSize, RMuint32 nReadAhead);

RM_EXTERN_C_BLOCKEND

#endif // __RMCDFS_H__
