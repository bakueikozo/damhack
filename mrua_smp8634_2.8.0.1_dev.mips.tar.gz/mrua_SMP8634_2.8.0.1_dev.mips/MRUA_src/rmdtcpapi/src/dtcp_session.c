
/****************************************************************************
 * Copyright (c) Sigma Designs, Inc. 2007. All rights reserved.
 */
/**
 *	@file     dtcp_session.c
 *
 *	@brief    DTCP for the SMP86xx
 *
 *	@version  0.1
 *
 *	@buglog   first revision
 *
 *	@author   Thulasi Jeganathan
 *
 *	@date     2007-22-02
 *
 ****************************************************************************/
 

#include "../include/dtcp_session.h"
#include "../include/dtcp_interface.h"
#include "../../samples/common.h"


/* Certificates PATH */
#define PATH_TO_CERTIFICATES "/mnt/"
#define DTCP_SERIAL_FLASH_SECTOR 4
#define DTCP_DECRYPT_SIZE (200 * 1024)
#define DTCP_SLOT_ID 0


/* Extern declarations for the forward and inverse DCT routines. */
extern RMstatus AESKeyPrecipherInband(struct RUA *Context_RUA,RMuint32 Context_demux_task,enum EMhwlibScramblingBits scrambling, RMuint8 *pkey, RMuint8 *piv, RMuint32 key_size,RMuint32 inband_state);


static void dtcpInbandCallback(struct dtcp_cookie *cookie, RMuint8 *dtcp_key, RMuint8 *dtcp_iv)
{
	RMstatus err;
	struct dcc_context *dcc_info = (struct dcc_context *)cookie->dtcp_inband_context;

	if (cookie->dtcp_emi == 0) {
		if (cookie->dtcp_emi_updated == TRUE) {
			struct InbandCommandX_type ibc;
			ibc.flags_tag = INBAND_COMMAND_TAG_STOP_PRECIPHER;
			ibc.offset_control = EMhwlibInbandOffset_Ignore;
			ibc.output_mask = 0;
			
			/* Sending inband command to stop Precipher */
			err = RUASetProperty(dcc_info->pRUA, dcc_info->demux_task, RMGenericPropertyID_InbandCommandX, &ibc, sizeof(ibc), 0);
			if (RMFAILED(err))
				RMDBGLOG((ENABLE, "dtcpInbandCallback failed when stopping precipher\n"));
			else {
				cookie->dtcp_emi_updated = FALSE;
				cookie->dtcp_inband_state++;
			}
		}
	}
	else {
		/* Sending DTCP Inband key and IV */
		err = AESKeyPrecipherInband(dcc_info->pRUA, dcc_info->demux_task,EMhwlibScramblingBits_PreCipher,dtcp_key,dtcp_iv,16,cookie->dtcp_inband_state);
		if (err != RM_OK)
			RMDBGLOG((ENABLE, "dtcpInbandCallback failed when updating Key and IV\n"));
		else {
			cookie->dtcp_emi_updated = TRUE;
			cookie->dtcp_inband_state++;
		}
	}
}


RMstatus init_DTCP_session (struct dtcp_cookie **dtcpCookieHandle,
			    struct stream_options_s *stream_opts,
		            struct RUA *pRUA,
			    RMascii *filename,
			    RMbool use_inband)
{
	*dtcpCookieHandle = NULL;

	if ((*dtcpCookieHandle = dtcp_parse_url(filename)) != NULL)
	{
		RMDBGLOG((ENABLE, "starting DTCP-IP session\n"));
		RMint32 dtcp_result;
	
		/* Allocate the 1st temporary RUA buffer for RPC communication*/
		(*dtcpCookieHandle)->dtcp_xrpc_base_addr1 = RUAMalloc(pRUA,
							           0,
							           RUA_DRAM_UNPROTECTED,
							           DTCP_XRPC_SIZE);
		if ((*dtcpCookieHandle)->dtcp_xrpc_base_addr1 == 0) {
			RMDBGLOG((ENABLE,"RUAMalloc failed for dtcp drmn"));
			return RM_ERROR;
		}
		(*dtcpCookieHandle)->dtcp_RUAMalloc1Completed = TRUE;
		if (use_inband == TRUE) {
			// Initialize the DTCP subsystem		
			if ((dtcp_result = dtcp_interface_init(-1,
							       (*dtcpCookieHandle)->dtcp_xrpc_base_addr1,
							       DTCP_XRPC_SIZE,
							       DTCP_SERIAL_FLASH_SECTOR,
							       PATH_TO_CERTIFICATES,
							       0,
							       NULL,
							       DTCP_SLOT_ID)) < 0) {
				RMDBGLOG((ENABLE,"dtcp_interface_init failed with: %ld\n", dtcp_result));
				return RM_ERROR;
			}
		}
		else {
			/* Allocate a 2nd temporary RUA buffer for decryption */
			(*dtcpCookieHandle)->dtcp_xrpc_base_addr2 = RUAMalloc(pRUA,
									   0,
									   RUA_DRAM_UNPROTECTED,
									   DTCP_DECRYPT_SIZE);
			if ((*dtcpCookieHandle)->dtcp_xrpc_base_addr2 == 0) {
				return RM_ERROR;
			}
			(*dtcpCookieHandle)->dtcp_RUAMalloc2Completed = TRUE;

			/* Lock the temporary RUA buffer so it can be mapped */ 
			if (RUALock(pRUA, (*dtcpCookieHandle)->dtcp_xrpc_base_addr2, DTCP_DECRYPT_SIZE) != RM_OK) {
				RMDBGLOG((ENABLE, "RUALock failed\n"));
				return RM_ERROR;
			}
			(*dtcpCookieHandle)->dtcp_RUALockCompleted = TRUE;

			/* Map the 2nd temporary RUA buffer */
			(*dtcpCookieHandle)->dtcp_map_addr = RUAMap(pRUA,
								 (*dtcpCookieHandle)->dtcp_xrpc_base_addr2,
								 DTCP_DECRYPT_SIZE);
			if ((*dtcpCookieHandle)->dtcp_map_addr == NULL) {
				RMDBGLOG((ENABLE, "RUAMap failed\n"));
				return RM_ERROR;
			}
			(*dtcpCookieHandle)->dtcp_RUAMapCompleted = TRUE;

			//Initialize the DTCP subsystem	
			if ((dtcp_result = dtcp_interface_init(-1,
								(*dtcpCookieHandle)->dtcp_xrpc_base_addr1,
								DTCP_XRPC_SIZE,
								DTCP_SERIAL_FLASH_SECTOR,
								PATH_TO_CERTIFICATES,
								(*dtcpCookieHandle)->dtcp_xrpc_base_addr2,
								(*dtcpCookieHandle)->dtcp_map_addr,
								DTCP_SLOT_ID)) < 0) {
				RMDBGLOG((ENABLE,"dtcp_interface_init failed with: %ld\n", dtcp_result));
				return RM_ERROR;
			}
		} // use_inband

		// Perform AKE
		if (dtcp_interface_do_AKE((*dtcpCookieHandle)->dtcp_host,
					  (*dtcpCookieHandle)->dtcp_port,
					  &((*dtcpCookieHandle)->dtcp_ake_handle)) < 0) {
			RMDBGLOG((ENABLE, "dtcp_interface_do_AKE failed\n"));
			return RM_ERROR;
		}

		// Setup DTCP hooks into HTTP
		if (RMFAILED(set_http_hook_options(stream_opts,
						   RM_HTTP_CUSTOM_HOOKS,
						   (void *)*dtcpCookieHandle,
						   (HttpHookOps *)httpDtcpOps))) {
			RMDBGLOG((ENABLE, "Error setting DTCP session parameter.\n"));
			return RM_ERROR;
		}

		// Setup inband commands just in case Transport Demux microcode performs hardware decryption [only for MPEG files]
		(*dtcpCookieHandle)->dtcp_inband_callback = dtcpInbandCallback;
	}
	return RM_OK;
}


RMstatus term_DTCP_session(struct dtcp_cookie *dtcpCookieHandle, struct RUA *pRUA)
{

	RMDBGLOG((ENABLE, "closing DTCP-IP session\n"));
	if (dtcpCookieHandle) {
		// Free the temporary RUA buffer of DTCP drm
		if (dtcpCookieHandle->dtcp_RUAMalloc1Completed)
			RUAFree(pRUA, dtcpCookieHandle->dtcp_xrpc_base_addr1);

		// Unmap the 2nd temporary RUA buffer needed for decryption of header blocks
		if (dtcpCookieHandle->dtcp_RUAMapCompleted)
			RUAUnMap(pRUA,dtcpCookieHandle->dtcp_map_addr, DTCP_DECRYPT_SIZE);
	
		//Unlock the 2nd temporary RUA buffer needed for decryption of header blocks
		if (dtcpCookieHandle->dtcp_RUALockCompleted)
			RUAUnLock(pRUA, dtcpCookieHandle->dtcp_xrpc_base_addr2, DTCP_DECRYPT_SIZE);
	
		// Free 2nd the temporary RUA buffer
		if (dtcpCookieHandle->dtcp_RUAMalloc2Completed)
			RUAFree(pRUA, dtcpCookieHandle->dtcp_xrpc_base_addr2);

		// Close AKE
		if ((dtcpCookieHandle->dtcp_ake_handle != NULL) &&
		   (dtcp_interface_close_AKE(dtcpCookieHandle->dtcp_ake_handle) < 0)) {
			RMDBGLOG((ENABLE, "dtcp_interface_close_AKE failed\n"));
			return RM_ERROR;
		}

		// Terminate the DTCP subsystem
		if (dtcp_interface_term() < 0) {
			RMDBGLOG((ENABLE, "dtcp_interface_term failed\n"));
			return RM_ERROR;
		}
		// Free the DTCP cookie
		RMFree(dtcpCookieHandle);
	}
	return RM_OK;
}


RMstatus buffer_pool_decryption (struct RUABufferPool *pDMA,
				 RMuint8 *Buffer,
				 RMuint32 BufferSize)
{  	
	RMint32 dtcp_result;
	RMuint32 addr_phys;
	RMstatus err = RM_OK;

	err = RUAGetPhysicalAddress(pDMA, Buffer, BufferSize, &addr_phys);
	if ( RMFAILED(err)) {
	fprintf(stderr,"Error getting DTCP data buffer physical addr\n");
		return err;
	}

	err = RUACleanCache(pDMA, Buffer, BufferSize);
	if ( RMFAILED(err)) {
		fprintf(stderr,"Error cleaning DTCP data buffer from cache\n");
		return err;
	}

	err = RUAInvalidateCache(pDMA, Buffer,  BufferSize);
	if ( RMFAILED(err)) {
		fprintf(stderr,"Error invalidating DTCP data buffer from cache\n");
		return err;
	}

	if ((dtcp_result = dtcp_interface_decrypt_buffer(addr_phys,  BufferSize)) < 0) {
		fprintf(stderr, "dtcp_decrypt_buffer_buffer failed %ld\n", dtcp_result);
		return err;
	}
	return err;
}
