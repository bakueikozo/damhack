/****************************************************************************
 * Copyright (c) Sigma Designs, Inc. 2006. All rights reserved.
 */
/**
 *	@file     dtcp_interface.c
 *
 *	@brief    Wrapper for DTCP shared library
 *
 *	@version  0.1
 *
 *	@buglog   First revision
 *
 *	@author   Thulasi Jeganathan
 *
 *	@date     2006-05-25
 *
 ****************************************************************************/


/*---------------------------------------------------------------------------
                                 INCLUDES
 ---------------------------------------------------------------------------*/

#define ALLOW_OS_CODE
#include "rmdef/rmdef.h"
#include "rmdrm/include/rmdrm.h"
#include "dtcp_interface.h"


/*---------------------------------------------------------------------------
                                 MACROS
 ---------------------------------------------------------------------------*/

#if 0
#define DTCPDBG ENABLE
#else
#define DTCPDBG DISABLE
#endif

#if (EM86XX_MODE == EM86XX_MODEID_WITHHOST) || (EM86XX_CHIP != EM86XX_CHIPID_TANGO15)
static struct dtcp_interface_s *dtcp_interface;

#undef FUNC0
#undef FUNC1
#undef FUNC2
#undef FUNC3
#undef FUNC4
#undef FUNC5
#undef FUNC6
#undef FUNC7
#undef FUNC8
#undef FUNC9
#undef FUNC10


#undef FUNC

#define FUNC(name, return_error, ...)							\
if (dtcp_interface){ 									\
	RMDBGLOG((DTCPDBG,"got %p for " #name "\n", dtcp_interface->name));		\
	return dtcp_interface->name(__VA_ARGS__);					\
} else {										\
	RMDBGLOG((DTCPDBG,"Attempting to load DTCP...\n"));				\
	if ((dtcp_interface = load_drm(DTCP, NULL))) {					\
		RMDBGLOG((DTCPDBG,"got %p for " #name "\n", dtcp_interface->name));	\
		return dtcp_interface->name(__VA_ARGS__);				\
	} else {									\
		RMDBGLOG((DTCPDBG,"Cannot load DTCP\n"));				\
		return return_error;							\
	}										\
}

#define FUNC0(name, return_type, return_error)						\
	return_type name (void){							\
		FUNC(name, return_error)						\
	}

#define FUNC1(name, return_type, return_error, t1, p1)					\
	return_type name (t1 p1){							\
		FUNC(name, return_error, p1)						\
	}

#define FUNC2(name, return_type, return_error, t1, p1, t2, p2)				\
	return_type name (t1 p1, t2 p2){						\
		FUNC(name, return_error, p1, p2)					\
	}

#define FUNC3(name, return_type, return_error, t1, p1, t2, p2, t3, p3)			\
	return_type name (t1 p1, t2 p2, t3 p3){						\
		FUNC(name, return_error, p1, p2, p3)					\
	}

#define FUNC4(name, return_type, return_error, t1, p1, t2, p2, t3, p3, t4, p4)		\
	return_type name (t1 p1, t2 p2, t3 p3, t4 p4){					\
		FUNC(name, return_error, p1, p2, p3, p4)				\
	}
	
#define FUNC5(name, return_type, return_error, t1, p1, t2, p2, t3, p3, t4, p4,          \
                                               t5, p5)                   		\
	return_type name (t1 p1, t2 p2, t3 p3, t4 p4, t5 p5)				\
	{	  									\
		FUNC(name, return_error, p1, p2, p3, p4, p5)				\
	}
	
#define FUNC6(name, return_type, return_error, t1, p1, t2, p2, t3, p3, t4, p4,          \
                                               t5, p5, t6, p6 )         		\
	return_type name (t1 p1, t2 p2, t3 p3, t4 p4, t5 p5, t6 p6)			\
	{	  									\
		FUNC(name, return_error, p1, p2, p3, p4, p5, p6)			\
	}
	
#define FUNC7(name, return_type, return_error, t1, p1, t2, p2, t3, p3, t4, p4,          \
                                               t5, p5, t6, p6, t7, p7 ) 		\
	return_type name (t1 p1, t2 p2, t3 p3, t4 p4, t5 p5, t6 p6, t7 p7)		\
	{	  									\
		FUNC(name, return_error, p1, p2, p3, p4, p5, p6, p7)			\
	}	

#define FUNC8(name, return_type, return_error, t1, p1, t2, p2, t3, p3, t4, p4,          \
                                               t5, p5, t6, p6, t7, p7, t8, p8)  	\
	return_type name (t1 p1, t2 p2, t3 p3, t4 p4, t5 p5, t6 p6, t7 p7, t8 p8)	\
	{	  									\
		FUNC(name, return_error, p1, p2, p3, p4, p5, p6, p7, p8)		\
	}	

	
#define FUNC9(name, return_type, return_error, t1, p1, t2, p2, t3, p3, t4, p4,          \
                                               t5, p5, t6, p6, t7, p7, t8, p8, t9, p9)  \
	return_type name (t1 p1, t2 p2, t3 p3, t4 p4, t5 p5, t6 p6, t7 p7, t8 p8, t9 p9)\
	{	  									\
		FUNC(name, return_error, p1, p2, p3, p4, p5, p6, p7, p8, p9)		\
	}	

#define FUNC10(name, return_type, return_error, t1, p1, t2, p2, t3, p3, t4, p4,         \
                                               t5, p5, t6, p6, t7, p7, t8, p8,          \
					       t9, p9, t10, p10)                 	\
	return_type name (t1 p1, t2 p2, t3 p3, t4 p4, t5 p5, t6 p6, t7 p7, t8 p8, t9 p9,\
	t10 p10)									\
	{	  									\
		FUNC(name, return_error, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10)	\
	}

	
#include "dtcp_interface.inc"


#endif /* EM86XX_MODEID_WITHHOST || not EM86XX_CHIPID_TANGO15 */

