/**************************************************************
 * Copyright (c) Sigma Designs, Inc. 2006. All rights reserved.
 */
/**
 *	@file     dtcp_interface.h
 *
 *	@brief    DTCP interface to shared library
 *
 *	@version  0.1
 *
 *	@buglog   First revision
 *
 *	@author   Thulasi Jeganathan
 *
 *	@date     2006-05-25
 *
 ***************************************************************/

#ifndef __DTCP_INTERFACE_H__
#define __DTCP_INTERFACE_H__

#include "dtcp_api.h"

struct dtcp_interface_s {

#undef FUNC0
#undef FUNC1
#undef FUNC2
#undef FUNC3
#undef FUNC4
#undef FUNC5
#undef FUNC6
#undef FUNC7
#undef FUNC8
#undef FUNC9
#undef FUNC10

/* Function Type Macros */
#define FUNC0(name, return_type, return_error)                                           \
	return_type (* name) ();

#define FUNC1(name,return_type,return_error,t1,p1)                                       \
	return_type (* name)(t1 p1);

#define FUNC2(name,return_type,return_error,t1,p1,t2,p2)                                 \
	return_type (* name)(t1 p1, t2 p2);

#define FUNC3(name,return_type,return_error,t1,p1,t2,p2,t3,p3)                           \
	return_type (* name)(t1 p1, t2 p2, t3 p3);

#define FUNC4(name,return_type,return_error,t1,p1,t2,p2,t3,p3,t4,p4)                     \
	return_type (* name)(t1 p1, t2 p2, t3 p3, t4 p4);

#define FUNC5(name, return_type, return_error, t1, p1, t2, p2, t3, p3, t4, p4,           \
                                               t5, p5)                   		 \
	return_type  (* name)(t1 p1, t2 p2, t3 p3, t4 p4, t5 p5);	
	
#define FUNC6(name, return_type, return_error, t1, p1, t2, p2, t3, p3, t4, p4,           \
                                               t5, p5, t6, p6 )                          \
	return_type  (* name)(t1 p1, t2 p2, t3 p3, t4 p4, t5 p5, t6 p6);
	

#define FUNC7(name, return_type, return_error, t1, p1, t2, p2, t3, p3, t4, p4,           \
                                               t5, p5, t6, p6, t7, p7 )                  \
	return_type  (* name)(t1 p1, t2 p2, t3 p3, t4 p4, t5 p5, t6 p6, t7 p7 );
	

#define FUNC8(name, return_type, return_error, t1, p1, t2, p2, t3, p3, t4, p4,           \
                                               t5, p5, t6, p6, t7, p7, t8, p8)           \
	return_type  (* name)(t1 p1, t2 p2, t3 p3, t4 p4, t5 p5, t6 p6, t7 p7, t8 p8 );
	
#define FUNC9(name, return_type, return_error, t1, p1, t2, p2, t3, p3, t4, p4,           \
                                               t5, p5, t6, p6, t7, p7, t8, p8, t9, p9)   \
	return_type  (* name)(t1 p1, t2 p2, t3 p3, t4 p4, t5 p5, t6 p6, t7 p7, t8 p8,    \
					       t9 p9); 
	
#define FUNC10(name, return_type, return_error, t1, p1, t2, p2, t3, p3, t4, p4,          \
                                               t5, p5, t6, p6, t7, p7, t8, p8,           \
					       t9, p9, t10, p10)               		 \
	return_type  (* name)(t1 p1, t2 p2, t3 p3, t4 p4, t5 p5, t6 p6, t7 p7, t8 p8, t9 \
	p9, t10 p10);


#include "dtcp_interface.inc"

};
#endif /* __DTCP_INTERFACE_H__ */
