/****************************************************************************
 * Copyright (c) Sigma Designs, Inc. 2006. All rights reserved.
 */
/**
 *	@file     dtcp_api.h
 *
 *	@brief    DTCP for the SMP86xx
 *
 *	@version  0.1
 *
 *	@buglog   first revision
 *
 *	@author   Thulasi Jeganathan
 *
 *	@date     2006-05-25
 *
 ****************************************************************************/
 
#ifndef __DTCP_API_H__
#define __DTCP_API_H__


/*---------------------------------------------------------------------------
                                 INCLUDES
 ---------------------------------------------------------------------------*/

#include "rmdef/rmdef.h"
#include "rmdef/rmmacros.h"

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------------------------------------------------------
                            CONSTANT LITERALS
 ---------------------------------------------------------------------------*/

/**
   Minimum size of the RUA memory used for communicating with the xtask.
   This RUA memory is passed as the first parameter to dtcp_initialize().
*/
#define DTCP_XRPC_SIZE (32 * 1024)
#define DTCP_INTERFACE_SUCCESS             0   /* Function succeeded               */
#define DTCP_INTERFACE_FAILURE            -1   /* General failure                  */
#define DTCP_INTERFACE_INVALID_ARGUMENT   -2   /* Invalid function argument        */
#define DTCP_INTERFACE_LOGIC_ERROR        -3   /* Functional logic error           */
#define DTCP_INTERFACE_FILE_NOT_FOUND     -4   /* File not found                   */
#define DTCP_INTERFACE_XSTART_FAILURE     -5   /* Xtask starting failure           */
#define DTCP_INTERFACE_XTASK_SYNC_FAILURE -6   /* CPU-XPU synchronization failure  */
#define DTCP_INTERFACE_XTASK_MISMATCH     -7   /* Loaded wrong DRM                 */ 
#define DTCP_INTERFACE_VERSION_MISMATCH   -8   /* Loaded wrong version of xtask    */
#define DTCP_INTERFACE_UNRESOLVED_SYMBOL  -9   /* Unresolved shared library symbol */

/*---------------------------------------------------------------------------
                           FUNCTION PROTOTYPES
 ---------------------------------------------------------------------------*/
/**
   Loads the DTCP shared library and the DTCP xtask.
   
   @param dtcp_sector : the internal serial flash sector used to store dtcp key
   @param debug_level : controls the amount of debug information printed to the serial port
			-1 means print no debug output
			 0 means print all debug output
			>0 means print only messages with priority less than debug_level
   @param dtcp_xrpc_base_addr base address of RUA memory used for communicating with the xtask
   @param dtcp_xrpc_base_size size of RUA memory used for communicating with the xtask
   @param dtcp_sector : the internal serial flash sector used to store dtcp key
   @param certificate_path : path to the certificates
   @param decrypt_map_addr : map address of RUA memory used for decryption
   @param decrypt_base_addr : base address of RUA memory used for decryption
   @param dtcp_slot_id : the slot number where the DTCP xtask image has been preloaded
   @return DTCP_INTERFACE_SUCCESS if successful, above error codes otherwise
*/			    
RMint32 dtcp_interface_init(RMuint32 debug_level,
			    RMuint32  dtcp_xrpc_base_addr,
			    RMuint32 dtcp_xrpc_base_size,
			    RMuint32 dtcp_sector,
			    RMascii  *certificate_path,
			    RMint32  decrypt_base_addr,
			    RMuint8 *decrypt_map_addr,
			    RMuint8  dtcp_slot_id);

/**
   Unloads the DTCP xtask and the DTCP shared library.
   Terminate the DTCP subsystem
   @param void
   @return DTCP_INTERFACE_SUCCESS if successful, above error codes otherwise
*/
RMint32 dtcp_interface_term(void);

/**
   Initiate an AKE session with a DTCP server

   @param remote_ip   : IP address of the DTCP server in dot notation xxx.xxx.xxx.xxx
   @param remote_port : Port number that the DTCP server is listening on
   @param ake_handle  : Handle to a new AKE session, if successful
   @return DTCP_INTERFACE_SUCCESS if successful, above error codes otherwise
*/
RMint32  dtcp_interface_do_AKE(RMascii* remote_ip,
	                       RMint32 remote_port,
			       void** ake_handle);


/**
   Close the AKE session with the DTCP server

   @param ake_handle : Handle of the AKE session
   @return DTCP_INTERFACE_SUCCESS if successful, above error codes otherwise
*/
RMint32 dtcp_interface_close_AKE(void *ake_handle);

/**
   Open a DTCP stream using an AKE handle

   @param stream_handle : Handle to a new DTCP stream, if successful
   @param ake_handle    : Handle of the AKE session
   @return DTCP_INTERFACE_SUCCESS if successful, above error codes otherwise
*/
RMint32 dtcp_interface_open_stream(void **stream_handle,
                                   void *ake_handle);

/**
   Close a DTCP stream

   @param stream_handle : Handle of the DTCP stream
   @return DTCP_INTERFACE_SUCCESS if successful, above error codes otherwise
*/
RMint32 dtcp_interface_close_stream(void *stream_handle);

/**
   Truncate the desired read size if too close to a PCP boundary

   @param stream_handle : Handle of the DTCP stream
   @param size          : Desired amount of data to be read from the DTCP server into a buffer
   @return size if far enough away from a PCP boundary, or a truncated size if too close
*/
RMuint32 dtcp_interface_read_size(void *stream_handle,
                                  RMuint32 size);

/**
   Process encrypted data.  If inband is zero, this function with decrypt the data in place.
   If inband is nonzero, this function will not decrypt the data.  Rather, the application
   will decrypt the data (using microcode inband commands).  When using inband decryption
   and a DTCP key rotates, the new key and iv will be provided.

   @param stream_handle       : Handle of the DTCP stream
   @param encrypted_data      : Encrypted data to be processed
   @param encrypted_data_size : Size of encrypted data
   @param buffer              : Pointer to start of actual data (used for skipping PCPH's)
   @param buffer_size         : Amount of actual data, excluding PCPH's and padding bytes
   @param emi                 : Receives the EMI type for this protected content packet
   @param inband              : If inband is nonzero, do NOT decrypt (otherwise decrypt)
   @param cipher_key          : If inband is nonzero and key rotates, new key (otherwise NULL)
   @param cipher_iv           : If inband is nonzero and key rotates, new iv (otherwise NULL)
   @param BufferPoolDecryptionFlag : If it nonzero do NOT decrypt (otherwise decrypt)
   @return DTCP_INTERFACE_SUCCESS if successful, above error codes otherwise
*/
RMint32 dtcp_interface_decrypt(void *stream_handle,
			       RMuint8  *encrypted_data,
			       RMint32   encrypted_data_size,
			       RMuint8 **buffer,   
			       RMint32  *buffer_size,
			       RMint32  *emi,
			       RMint32   inband,
			       RMuint8 **cipher_key,
			       RMuint8 **cipher_iv,
			       RMint32   BufferPoolDecryptionFlag);
/**
   Process encrypted data. Decrypt the encrypted test vectors using temporary RUA buffer.
   
   @param encrypted_data      : Encrypted data to be processed
   @param encrypted_data_size : Size of encrypted data
   @param ContentKey          :  key (AES128)
   @param ContentIV           :  iv  (AES128)
   @return DTCP_INTERFACE_SUCCESS if successful, above error codes otherwise
 */	       		
RMint32 dtcp_interface_decrypt_test_buffer(RMuint8 *encrypted_data,
				           RMuint32 encrypted_data_size,
				           RMuint8 *ContentKey,
				           RMuint8 *ContentIV);

/**
   Process encrypted data. Decrypt RUA buffer (from pool or temporary RUA buffer)
   
   @param encrypted_data      : Physical address of the RUA buffer
   @param buffer_size         : Size of the buffer
   @return DTCP_INTERFACE_SUCCESS if successful, above error codes otherwise
 */					 
RMint32 dtcp_interface_decrypt_buffer(RMuint32  buffer_phys_addr,
				      RMuint32  buffer_size);

#ifdef __cplusplus
};
#endif

#endif //#ifndef __DTCP_API_H__

