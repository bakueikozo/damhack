/*
 *
 * Copyright (c) Sigma Designs, Inc. 2005. All rights reserved.
 *
 */

/**
  @file   dtcp_callbacks.h
  @brief  DTCP callbacks suitable for use as HTTP hooks

  @author Glen Adams
  @date   2005-04-29
*/

#ifndef __DTCP_CALLBACKS_H__
#define __DTCP_CALLBACKS_H__

#ifndef ALLOW_OS_CODE
#define ALLOW_OS_CODE 1
#endif

#include "../../rmdef/rmdef.h"

#define DTCP_HEADER_SIZE 14
#define AES_BLOCK_SIZE 16
#define DTCPHOSTLENGTH 32

RM_EXTERN_C_BLOCKSTART

RM_LIBRARY_IMPORT_EXPORT extern void *httpDtcpOps;

struct dtcp_cookie {
	RMascii dtcp_host[DTCPHOSTLENGTH + 1];
	RMint32 dtcp_port;
	void *dtcp_ake_handle;
	void *dtcp_stream_handle;
	RMint32 dtcp_emi;
	RMbool dtcp_emi_updated;
	RMint32 dtcp_inband_flag;
	void *dtcp_inband_context;
	RMint32 dtcp_inband_state;
	RMint32 BufferPoolDecryptionFlag;
	RMint32 dtcp_xrpc_base_addr1;
	RMint32 dtcp_xrpc_base_addr2;
	RMuint8 *dtcp_map_addr; 
	RMbool dtcp_RUAMalloc1Completed;
	RMbool dtcp_RUAMalloc2Completed;
	RMbool dtcp_RUALockCompleted;
	RMbool dtcp_RUAMapCompleted;
	void *dtcp_DMA_ptr;
	void (*dtcp_inband_callback)(struct dtcp_cookie *cookie, RMuint8 *dtcp_key, RMuint8 *dtcp_iv);
};

struct dtcp_cookie *dtcp_parse_url(RMascii *url);
RMint32 dtcp_open_callback(struct dtcp_cookie *cookie);
RMint32 dtcp_close_callback(struct dtcp_cookie *cookie);
RMint32 dtcp_reopen_callback(struct dtcp_cookie *cookie);
RMint32 dtcp_pre_read_callback(struct dtcp_cookie *cookie, RMuint8 *buffer, RMint32 length);
RMint32 dtcp_post_read_callback(struct dtcp_cookie *cookie, RMuint8 *buffer, RMint32 length, RMint32 *more_data);

RM_EXTERN_C_BLOCKEND

#endif /* __DTCP_CALLBACKS_H__ */

