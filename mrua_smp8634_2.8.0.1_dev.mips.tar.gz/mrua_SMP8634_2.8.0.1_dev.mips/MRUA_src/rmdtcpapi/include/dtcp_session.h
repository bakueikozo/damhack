
/****************************************************************************
 * Copyright (c) Sigma Designs, Inc. 2007. All rights reserved.
 */
/**
 *	@file     dtcp_session_handler.h
 *
 *	@brief    DTCP for the SMP86xx
 *
 *	@version  0.1
 *
 *	@buglog   first revision
 *
 *	@author   Thulasi Jeganathan
 *
 *	@date     2007-22-02
 *
 ****************************************************************************/

#ifndef __DTCP_SESSION_H__
#define __DTCP_SESSION_H__


/* RUA header files */
#include "../../rua/include/rua.h"                 // RUA API
#include "../../rua/include/rua_property.h"        // RUA properties

#include "../../rmcore/include/rmstatustostring.h" // ERROR codes
#include "../../rmdef/rmdef.h"                     // TYPE definitions
#include "../../samples/rminputstream.h"           // HTTP properties

/* DTCP callbacks */
#include "../include/dtcp_callbacks.h"             // DTCP callbacks


/* Same function prototype for EM8622 and SMP8634 */
/**
    Check and initiate a session with a DTCP server if needed.
   
   @param  dtcpCookieHandle  : Structure containing dtcp parameters and handle for communicate with the server
   @param  stream_opts       : stream options for set dtcp http hooks
   @param  pRUA              : RUA  pointer
   @param  filename          : filename
   @param  use_inband        : use_inband is TRUE if Transport Demux microcode performs hardware decryption, FALSE otherwise.   
   @return  RM_OK if success, otherwise returns an error code.
*/
RMstatus init_DTCP_session (struct dtcp_cookie **dtcpCookieHandle,
			    struct stream_options_s *stream_opts,
		            struct RUA *pRUA,
			    RMascii *filename,
			    RMbool use_inband);

/**
   Terminate a session with a DTCP server.

   @param  dtcpCookieHandle  : Structure containing dtcp parameters and handle for communicate with the server
   @param  pRUA              : RUA  pointer 
   @return RM_OK if success, otherwise returns an error code.
*/     					  
RMstatus term_DTCP_session(struct dtcp_cookie *dtcpCookieHandle,
			   struct RUA *pRUA);

    
/**
   Decrypt using buffers from pool.

   @param  pDMA        : pDMA pool
   @param  Buffer      : content to decrypt
   @param  BufferSize  : size of the content to decrypt.   
   @return RM_OK if success, otherwise returns an error code.
*/
RMstatus buffer_pool_decryption(struct RUABufferPool *pDMA,
				RMuint8 *Buffer,
				RMuint32 BufferSize);

#endif //__DTCP_SESSION_H__
