/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   rmmpeg4track.h
  @brief  Main class for mp4 mpeg4tracks

  @author Julien Soulier
  @date   2001-10-08
*/

#ifndef __RMMPEG4TRACK_H__
#define __RMMPEG4TRACK_H__

#include "../../rmdef/rmdef.h"

#ifndef BASIC_MPEG4_FRAMEWORK
  #include "../../rmproperties/include/rmproperties.h"
#endif

#include "../../rmcpputils/include/rmcpputils.h"
#include "../../rmmpeg4types/rmmpeg4types.h"
#include "rmmpeg4_framework_common.h"


class RM_LIBRARY_IMPORT_EXPORT RMmpeg4Track : public RMobject
{
 public:
	RMmpeg4Track(const RMascii *name, RMmpeg4TrackType type);
	virtual ~RMmpeg4Track(void);
	
	virtual RMstatus Dump(const RMnonAscii *filename) PURE_VIRTUAL;
	virtual void Print(void) PURE_VIRTUAL; 
	virtual RMstatus GetNextSample(struct tagRMmp4Sample *sample, RMuint32 maxSize) PURE_VIRTUAL;
	virtual RMuint8 *GetDSI(RMuint32 *size) PURE_VIRTUAL;

#ifndef BASIC_MPEG4_FRAMEWORK
	virtual RMstatus GetProperty(RMpropertyId propId, void *data, RMuint32 size) PURE_VIRTUAL;
	virtual RMstatus SetProperty(RMpropertyId propId, void *data, RMuint32 size) PURE_VIRTUAL;
#endif

	/* Set property access */
	virtual RMstatus SetTrackType(void *data, RMuint32 size) PURE_VIRTUAL;

	/* Get property access */
	virtual RMstatus GetTrackType(void *data) PURE_VIRTUAL;
	virtual RMstatus GetTrackDuration(void *data, RMuint32 size) PURE_VIRTUAL;
	virtual RMstatus GetTrackVOPTimeIncrement(void *data, RMuint32 size) PURE_VIRTUAL;
	virtual RMstatus GetTrackSampleCount(void *data, RMuint32 size) PURE_VIRTUAL;
	virtual RMstatus GetTrackTimeScale(void *data, RMuint32 size) PURE_VIRTUAL;
	virtual RMstatus GetTrackRandomAccessSampleCount(void *data, RMuint32 size) PURE_VIRTUAL;
	virtual RMstatus GetTrackNextSampleSize(void *data, RMuint32 size) PURE_VIRTUAL;
	virtual RMstatus GetTrackTotalDataReceived(void *data, RMuint32 size) PURE_VIRTUAL;

	virtual RMstatus GetNextRandomAccessPoint(RMmp4Sample *mp4Sample, RMuint32 maxSize);
	virtual RMstatus GetPreviousRandomAccessPoint(RMmp4Sample *mp4Sample, RMuint32 maxSize);

	virtual RMstatus GetTrackWidth(RMuint32 *width);
	virtual RMstatus GetTrackHeight(RMuint32 *height);
	virtual RMstatus GetTrackSize(RMuint32 *trackSize, RMuint32 *sampleCount);
	virtual RMstatus GetNextSampleReadPos(RMuint64 *nextReadPos);

	virtual RMbool   isH264Track(void);
	virtual RMstatus GetH264Level(RMuint32 *level);
	virtual RMstatus GetH264Profile(RMuint32 *profile);
	virtual RMstatus GetH264LengthSize(RMuint32 *lengthSize);
	
	virtual RMstatus GetTrackSampleRate(RMuint32 *sampleRate);
	virtual RMstatus GetTrackChannelCount(RMuint32 *channelCount);
	virtual RMstatus GetTrackBitPerSample(RMuint32 *bitPerSample);


 protected:
	RMstate m_state;

	RMmpeg4TrackType m_typeTrack;
};	

#endif // __RMMPEG4TRACK_H__
