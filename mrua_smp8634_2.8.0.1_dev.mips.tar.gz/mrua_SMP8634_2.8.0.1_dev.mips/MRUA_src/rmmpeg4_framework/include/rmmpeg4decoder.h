/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   rmmp4decoder.h
  @brief  Describes the common interface for all decoder modules.

  @author Julien Soulier
  @date   2001-11-15
*/

#ifndef __RMMPEG4DECODER_H__
#define __RMMPEG4DECODER_H__

#include "../../rmcpputils/include/rmcpputils.h"
#include "../../rmmodule_framework/include/rmmodule_framework.h"

class RM_LIBRARY_IMPORT_EXPORT RMmpeg4Decoder: public RMobject
{
 public:
	RMmpeg4Decoder(const RMascii *name);
	virtual ~RMmpeg4Decoder(void);

	virtual RMstatus DsiInit(RMuint8* DSI, RMuint32 dsiSize) PURE_VIRTUAL;
	virtual RMstatus DecodeAU(RMuint8 *dataIn, RMuint32 dataInSize, RMuint8 *dataOut, RMuint32 *dataOutSize) PURE_VIRTUAL;
	virtual RMstatus GetProperty(RMpropertyId propertyID, RMuint32 *property);
};

#endif // __RMMPEG4DECODER_H__
