
/**
  @file   rmmpeg4_framework_common.h
  @brief  common type between track and class

  @author Laurent Crinon
  @date   2003-02-12
*/

#ifndef __RMMPEG4FRAMEWORKCOMMON_H__
#define __RMMPEG4FRAMEWORKCOMMON_H__

/** this is the maximum size of a video DSI or video sequence header */ 
#define RM_MAX_DSI_SIZE 1024

typedef enum {
	RM_STATE_UNKNOWN = 1259,
	RM_STATE_PLAY,
	RM_STATE_PAUSE,
	RM_STATE_STOP,
	RM_STATE_INITIALIZED,
	RM_STATE_SEEK,
	RM_STATE_CLOSING,
	RM_STATE_FASTFORWARD,
	RM_STATE_FASTREWIND,
	RM_STATE_OPEN,
	RM_STATE_DISCARD,
	RM_STATE_EOS
} RMstate;

typedef enum {
        RM_MPEG4_PLAY_FORWARD,
        RM_MPEG4_PLAY_IFRAMES_FORWARD,
        RM_MPEG4_PLAY_IFRAMES_BACKWARD,
} RMmpeg4PlayMode;

typedef enum {
        RM_MPEG4_AUDIO = 1,
        RM_MPEG4_VIDEO = 2
} RMmpeg4MediaType;

#endif /*__RMMPEG4FRAMEWORKCOMMON_H__*/
