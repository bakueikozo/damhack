/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   rmmpeg4audiodecoder.h
  @brief  describes the common interface for all audio decoders.

  @author Julien Soulier
  @date   2001-11-15
*/

#ifndef __RMMPEG4AUDIODECODER_H__
#define __RMMPEG4AUDIODECODER_H__

#include "rmmpeg4decoder.h"

class RM_LIBRARY_IMPORT_EXPORT RMmpeg4AudioDecoder: public RMmpeg4Decoder
{
 public:
	RMmpeg4AudioDecoder(const RMascii *name);
	virtual ~RMmpeg4AudioDecoder(void);

	virtual RMstatus GetProperty(RMpropertyId propertyID, RMuint32 *property);

 protected:
	RMuint32 m_audioObjectType;
	RMuint32 m_channelCount;
	RMuint32 m_bitsPerSample;
	RMuint32 m_sampleRate;
	RMuint32 m_frameSize;
};
	
#endif // __RMMPEG4AUDIODECODER_H__
