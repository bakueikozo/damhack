/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmmpeg4_framework.h
  @brief  

  long description

  @author Julien Soulier
  @date   2003-02-18
*/

#ifndef __RMMPEG4_FRAMEWORK_H__
#define __RMMPEG4_FRAMEWORK_H__

#include "../../rmdef/rmdef.h"

#ifndef BASIC_MPEG4_FRAMEWORK
  #include "../../rmproperties/include/rmproperties.h"
  #include "rmmpeg4decoder.h"
  #include "rmmpeg4audiodecoder.h"
#endif 

#include "rmmpeg4_framework_common.h"
#include "rmmpeg4client.h"
#include "rmmpeg4track.h"

#endif // __RMMPEG4_FRAMEWORK_H__
