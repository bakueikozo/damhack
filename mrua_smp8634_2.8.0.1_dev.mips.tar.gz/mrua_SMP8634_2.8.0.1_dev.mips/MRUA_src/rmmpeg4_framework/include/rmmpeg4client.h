/**
   long-description

   @param name  
*/
/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   rmmpeg4client.h
  @brief  Main class for the MPEG4 client

  @author Julien Soulier
  @date   2001-10-08
*/

#ifndef __RMMPEG4CLIENT_H__
#define __RMMPEG4CLIENT_H__

#include "../../rmdef/rmdef.h"

#ifndef BASIC_MPEG4_FRAMEWORK
  #include "../../rmmodule_framework/include/rmmodule_framework.h"
#else
  #include "../../rmcpputils/include/rmcpputils.h"
#endif

#include "rmmpeg4_framework_common.h"

class RMmpeg4Track;

class RM_LIBRARY_IMPORT_EXPORT RMmpeg4Client: public RMobject
{
 public:
	
	RMmpeg4Client(const RMascii *name);
	virtual ~RMmpeg4Client(void);

	virtual RMstatus OpenUrl(const RMascii *url) PURE_VIRTUAL;
	virtual RMstatus OpenFile(const RMnonAscii *filename) PURE_VIRTUAL;
 	virtual RMstatus OpenExternalFile(RMfile file);
	virtual RMstatus OpenUrlForBroadcast(const RMnonAscii *fileName, const RMascii *url);
	virtual RMstatus Close(void);
	virtual RMstatus Play(void);
	virtual RMstatus Pause(void);
	virtual RMstatus Stop(void);
	virtual RMstatus Seek(RMuint32 time, RMuint32 *actualTime_ms);
	virtual void Print(void);
	virtual RMmpeg4Track *OpenTrack(RMuint32 trackID) PURE_VIRTUAL;
	virtual RMstatus CloseTrack(RMmpeg4Track *track) PURE_VIRTUAL;
	virtual void *GetIOD(void) PURE_VIRTUAL;
	virtual RMuint32 GetVideoTrackID(void) PURE_VIRTUAL;
	virtual RMuint32 GetAudioTrackID(void) PURE_VIRTUAL;

#ifndef BASIC_MPEG4_FRAMEWORK
	virtual RMstatus GetProperty(RMpropertyId propId, void *data, RMuint32 size);
	virtual RMstatus SetProperty(RMpropertyId propId, void *data, RMuint32 size);
#endif

	/* Get property direct access */	
	virtual RMstatus GetVideoWidth(void *data, RMuint32 size) PURE_VIRTUAL;
	virtual RMstatus GetVideoHeight(void *data, RMuint32 size) PURE_VIRTUAL;
	virtual RMstatus GetVideoDuration(void *data, RMuint32 size) PURE_VIRTUAL;
	virtual RMstatus GetMonitoringCheckBitrate(void *data, RMuint32 size) PURE_VIRTUAL;
	virtual RMstatus GetMonitoringVideoBitrate(void *data, RMuint32 size) PURE_VIRTUAL;
	virtual RMstatus GetMonitoringVideoAvgBitrate(void *data, RMuint32 size) PURE_VIRTUAL;
	virtual RMstatus GetMonitoringAudioBitrate(void *data, RMuint32 size) PURE_VIRTUAL;
	virtual RMstatus GetMonitoringAudioAvgBitrate(void *data, RMuint32 size) PURE_VIRTUAL;

	/* Set property direct access */
	virtual RMstatus SetMonitoringUpdateCheckBitrate() PURE_VIRTUAL;

	virtual RMuint32 GetNumberOfVideoTracks(void);
	virtual RMuint32 GetNumberOfAudioTracks(void);
	virtual RMuint32 GetNumberOfSPUTracks(void);
	virtual RMuint32 GetNumberOfSubtitleTracks(void);
	virtual RMstatus GetVideoTrackIDByIndex(RMuint32 index, RMuint32 *trackID);
	virtual RMstatus GetAudioTrackIDByIndex(RMuint32 index, RMuint32 *trackID);
	virtual RMstatus GetSPUTrackIDByIndex(RMuint32 index, RMuint32 *trackID);
	virtual RMstatus GetSubtitleTrackIDByIndex(RMuint32 index, RMuint32 *trackID);
	virtual RMstatus SeekTrack(RMuint32 time_ms, RMuint32 *actualTime_ms, RMmpeg4Track *mp4t);

	virtual RMbool isNero(void);

	/* nero specific */
	virtual RMstatus GetClosestChapter(RMuint64 currentTime_100ns, RMuint64 *nextChapterTime_100ns, RMuint8 *chapterName, RMuint32 maxNameLen, RMint32 chapter);
	virtual RMstatus GetChapterByIndex(RMuint32 index, RMuint64 *ChapterTime_100ns, RMuint8 *chapterName, RMuint32 maxNameLen);
	virtual RMbool canBePlayed(void);


 protected:
	RMstate m_state;
};

#endif // __RMMPEG4CLIENT_H__
