/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   rmmpeg4types.h
  @brief  

  long description

  @author Julien Soulier
  @date   2003-02-18
*/

#ifndef __RMMPEG4TYPES_H__
#define __RMMPEG4TYPES_H__

#include "../rmdef/rmdef.h"

/** when the sample got corresponds to the first bytes of an Access Unit */
#define MP4_AU_START         0x01
/** when the last byte of the sample got corresponds to the last byte of an Access Unit */
#define MP4_AU_END           0x02
/** not used in mp4core (divx ?) */
#define MP4_AU_DISCONTINUITY 0x04
/** when the CTS and DTS fields are valids */
#define MP4_CTS_VALID        0x08
/** not used in mp4core (divx ?) */
#define MP4_NEED_HEADER      0x10

/** maximum number of tracks per mp4 file */
#define MP4_MAXTRACKS 1024

/**
   structure that contains a sample. The buffer must be allocated by
   the external application. flags is used to know if this is the
   start of an AU or/and the end of an AU.
*/
typedef struct tagRMmp4Sample {	
	RMuint32 size;            /* size read */
	RMuint8 *buf;             /* pointer to data */
	RMuint32 DTS_LSB;         /* lowest significant part of Decoding Time Stamp */
	RMuint32 DTS_MSB;         /* highest significant part of Decoding Time Stamp */
	RMuint32 CTS_LSB;         /* lowest significant part of Presentation Time Stamp */
	RMuint32 CTS_MSB;         /* highest significant part of Presentation Time Stamp */
	RMuint32 flags;           /* bit field with above values */
} RMmp4Sample;

typedef enum {
	RM_TYPE_TRACK_NOT_DEFINED = 7563,
	RM_VIDEO_MPEG4_TRACK,
	RM_VIDEO_AVI_TRACK,
	RM_VIDEO_DIVX3_TRACK,
	RM_VIDEO_WMV9_TRACK,
	RM_AUDIO_AAC_TRACK,
	RM_AUDIO_MP3_TRACK,
	RM_AUDIO_AC3_TRACK,
	RM_AUDIO_PCM_TRACK,
	RM_AUDIO_RPCM_TRACK,
	RM_AUDIO_MPEG2_TRACK,
	RM_AUDIO_WMA_TRACK,
	RM_AUDIO_WMAPRO_TRACK,
	RM_VIDEO_ONLY_TRACK,
	RM_MULTICAST_VIDEO_MP4_TRACK,
	RM_MULTICAST_AUDIO_AAC_TRACK,
	RM_MULTICAST_RTSP_VIDEO_MP4_TRACK,
	RM_MULTICAST_RTSP_AUDIO_AAC_TRACK,
	RM_VIDEO_H264_TRACK
} RMmpeg4TrackType;


#endif // __RMMPEG4TYPES_H__
