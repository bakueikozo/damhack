/*****************************************
 Copyright  2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file rmlibungif.h 
  @brief Describes the prototypes to access the
  gif drawing based on libungif lib

  @author Raul Chirinos
  @date   2004-08-02
*/

#ifndef __RMLIBUNGIF_H__
#define __RMLIBUNGIF_H__

#include "../../rmdef/rmdef.h"

RM_EXTERN_C_BLOCKSTART
RM_EXTERN_C_BLOCKEND

#endif // __RMLIBUNGIF_H__
