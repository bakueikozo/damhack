/*****************************************
 Copyright � 2001-2003       
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE 1

#include "../llad/include/llad.h"
#include "../llad/include/gbus.h"

// Arguments
#include "getargs.h"

#include <stdio.h>
#include <stdlib.h>

int main(int argc,char **argv) 
{
	struct llad *pllad;
	struct gbus *pgbus;
	RMuint32 byte_address;
	RMuint16 data;
	RMascii device[256];

	CheckArgCount (argc, 1, 1, argv, "<address>");
	
	byte_address = GetUL(argv[1], 2, argv, "<address>");
	
	GetDeviceServer(argv, device, 256);
	pllad = llad_open(device);
	if (pllad == NULL) {
		fprintf(stderr, "%s: Unable to access device\n", argv[0]);
		exit(1);
	}

	pgbus = gbus_open(pllad);

	data = gbus_read_uint16(pgbus, byte_address);
	printf("0x%04hx\n", data);

	gbus_close(pgbus);
	llad_close(pllad);

	return 0;
}

