/*****************************************
 Copyright � 2001-2003       
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE 1

#include "../llad/include/llad.h"
#include "../llad/include/gbus.h"

// Arguments
#include "getargs.h"

#include <stdio.h>
#include <stdlib.h>

int main(int argc,char **argv) 
{
	struct llad *pllad;
	RMascii device[256];

	GetDeviceServer(argv, device, 256);
	pllad = llad_open(device);
	if (pllad == NULL) {
		fprintf(stderr, "%s: Unable to access device\n", argv[0]);
		exit(1);
	}

	llad_get_config(pllad, device, sizeof(device));
	
	printf("config is : %s\n", device);
	
	llad_close(pllad);

	return 0;
}


