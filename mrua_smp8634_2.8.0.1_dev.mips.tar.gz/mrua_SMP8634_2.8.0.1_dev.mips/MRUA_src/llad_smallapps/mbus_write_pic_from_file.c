/*****************************************
 Copyright � 2001-2003       
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE 1

#include "../mbus/include/mbus.h"

// Arguments
#include "getargs.h"

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

/* string.h does not compile everywhere */
char *strcat(char *dest, const char *src);
int strcmp(const char *s1, const char *s2);
size_t strlen(const char *s);
char *strcpy(char *dest, const char *src);

#define BLOCK_SIZE 65536

int main(int argc,char **argv) 
{
	struct llad *pllad;
	char *data;
	char *filename, *extended_filename;
	unsigned long i;
	unsigned long chroma_422;
	FILE *f;
	unsigned long Y_byte_address;
	unsigned long UV_byte_address;
	unsigned long X, Y, total_width;
	unsigned long max_pci_count;
	RMascii device[256];

	CheckArgCount (argc, 5, 8, argv, "<Y_address> <UV_address> <width> <height> <filename> [<max pci count>] [4:2:0 | 4:2:2] [<total width>]");

	Y_byte_address = GetUL(argv[1], 16, argv, "<Y_address>");
	UV_byte_address = GetUL(argv[2], 16, argv, "<UV_address>");
	X = GetUL(argv[3], 2, argv, "<width>");
	Y = GetUL(argv[4], 1, argv, "<height>");

	filename = argv[5];
	
	if (argc > 6) 
		max_pci_count = GetUL(argv[6], 4, argv, "<max pci countt>");
	else
		max_pci_count = 65532;

	if (argc > 7)
		if (!strcmp(argv[7], "4:2:0"))
			chroma_422 = 0;
		else if (!strcmp(argv[7], "4:2:2"))
			chroma_422 = 1;
		else {
			fprintf(stderr, "Usage: %s Y_address> <UV_address> <width> <height> <filename> [4:2:0 | 4:2:2] [<total width>]\n", argv[0]);
			exit(1);
		}
	else
		chroma_422 = 0;

	if (argc > 8)
		total_width = GetUL(argv[8], 1, argv, "<total width>");
	else
		total_width = X;

	data = (char*)malloc(X * Y * sizeof(char));
	if (data == NULL) {
		fprintf(stderr, "Unable to allocate %ld bytes\n", X * Y * sizeof(char));
		exit(1);
	}
	extended_filename = (char*)malloc((strlen(filename) + 2) * sizeof(char)); 
	if (extended_filename == NULL) {
		fprintf(stderr, "Unable to allocate %d bytes\n", (int) ((strlen(filename) + 2) * sizeof(char)));
		exit(1);
	}

	GetDeviceServer(argv, device, 256);
	pllad = llad_open(device);
	if (pllad == NULL) {
		fprintf(stderr, "%s: Unable to access device\n", argv[0]);
		exit(1);
	}


	strcpy(extended_filename, filename);
	strcat(extended_filename, ".Y");
	f = fopen(extended_filename, "rb");
	if (f == NULL) {
		free(data);
		fprintf(stderr, "Can not open %s\n", extended_filename);
		exit(1);
	}

	fread(data, sizeof(char), X * Y, f);
	if (ferror(f)) {
		fclose(f);
		free(data);
		fprintf(stderr, "Error reading %s\n", extended_filename);
		exit(1);
	}

	mbus_write_picture(pllad, Y_byte_address, (RMuint8 *)data, X, Y, total_width, 8, max_pci_count);
  
	fclose(f);
  
	if(!chroma_422)
		Y = (Y + 1) / 2;

	strcpy(extended_filename, filename);
	strcat(extended_filename, ".U");
	f = fopen(extended_filename, "rb");
	if (f == NULL) {
		free(data);
		fprintf(stderr, "Can not open %s\n", extended_filename);
		exit(1);
	}
  
	for(i = 0; i < X * Y / 2; i++)
		fread(&data[2 * i], sizeof(char), 1, f);
	if (ferror(f)) {
		fclose(f);
		free(data);
		fprintf(stderr, "Error reading %s\n", extended_filename);
		exit(1);
	}
	fclose(f);

	strcpy(extended_filename, filename);
	strcat(extended_filename, ".V");
	f = fopen(extended_filename, "rb");
	if (f == NULL) {
		free(data);
		fprintf(stderr, "Can not open %s\n", extended_filename);
		exit(1);
	}
  
	for(i = 0; i < X * Y / 2; i++)
		fread(&data[2 * i + 1], sizeof(char), 1, f);
	if (ferror(f)) {
		fclose(f);
		free(data);
		fprintf(stderr, "Error reading %s\n", extended_filename);
		exit(1);
	}
	fclose(f);

	mbus_write_picture(pllad, UV_byte_address, (RMuint8 *)data, X, Y, total_width, 8, max_pci_count);

	llad_close(pllad);

	free(data);
  
	exit(0);
}

