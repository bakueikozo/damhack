#define ALLOW_OS_CODE 1
#include "../rmdef/rmdef.h"

#include "../llad/include/llad.h"
#include "../llad/include/gbus.h"
#include "../emhwlib_hal/include/emhwlib_registers.h"

#include "getargs.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define REGSCNT 15

struct {
	char *name;
	int enable;
	int min,max; 
	int maxmin,maxmax;
} B[REGSCNT]={
	{"gfx_in",0,0,0,32,32},
	{"video_in",0,0,0,8,8},
	{"main_Y",0,0,0,31,31},
	{"main_UV",0,0,0,16,16},
	{"pip_Y",0,0,0,16,16},
	{"pip_UV",0,0,0,8,8},
	{"vcr_Y",0,0,0,16,16},
	{"vcr_UV",0,0,0,8,8},
	{"crt_Y",0,0,0,16,16},
	{"crt_UV",0,0,0,8,8},
	{"osd",0,0,0,32,32},
	{"spu",0,0,0,16,16},
	{"gfxaccelx_in",0,0,0,31,8},
	{"gfxaccely_in",0,0,0,31,8},
	{"gfxaccel_out",0,0,0,31,8}
};

static void chkconfig()
{
	int i,condition,sum;
	
	condition=1;
	for (i=0;i<REGSCNT;i++) if (B[i].min>B[i].max) goto panic;

	condition=2;
	sum=0;
	for (i=0;i<REGSCNT;i++) if (B[i].enable) sum+=B[i].min;
	printf("informative: sum bwmin = %3d%%\n",100*sum/256);
	if (100*sum/256>90) goto panic;

	condition=3;
	sum=0;
	for (i=0;i<REGSCNT;i++) if (B[i].enable) sum+=B[i].max;
	printf("informative: sum bwmax = %4d%%\n",100*sum/256);
				    
	return;

 panic:
	printf("condition %d fails.\n",condition);
	exit(-1);
}

static void readbw(struct gbus *pgbus) 
{
	int i=0;

	for (i=0;i<REGSCNT;i++) {
		RMuint32 val=gbus_read_uint32(pgbus,REG_BASE_system_block+VARB_mid01_cfg+i*4);
		
		B[i].enable=(val&0x10000)?1:0;
		B[i].max=(val&0xff00)>>8;
		B[i].min=(val&0xff);
	}

	chkconfig();
}

static void dumpbw() 
{
	int i=0;

	for (i=0;i<REGSCNT;i++) {
		if (B[i].enable) 
			printf("channel %15s: %3d%% < bw < %3d%% <= limit%3d%%\n",
			       B[i].name,
			       100*B[i].min/256,
			       100*B[i].max/256,
			       100*B[i].maxmax/256);
	}
}

static void commit(struct gbus *pgbus)
{
	int i=0;

	chkconfig();

	for (i=0;i<REGSCNT;i++) {
		RMuint32 val=(B[i].enable<<16)
			|(B[i].max<<8)
			|B[i].min;
		
		gbus_write_uint32(pgbus,REG_BASE_system_block+VARB_mid01_cfg+i*4,val);
	}
}

static int getbyname(char *name)
{
	int i;

	for (i=0;i<REGSCNT;i++) if (!strcmp(B[i].name,name)) return i;

	if (i==REGSCNT) {
		fprintf(stderr,"cannot recognize channel\n");
		exit(-1);
	}
	return -1;
}

static void disch(struct gbus *pgbus,char *name)
{
	int i=getbyname(name);

	B[i].enable=0;
	dumpbw(pgbus);
	commit(pgbus);
}

static void ench(struct gbus *pgbus,char *name)
{
	int i=getbyname(name);

	B[i].enable=1;
	dumpbw(pgbus);
	commit(pgbus);
}

static void writemin(struct gbus *pgbus,char *name,int v)
{
	int i=getbyname(name);

	if (256*v/100<=B[i].maxmin)
		B[i].min=256*v/100;
	else {
		fprintf(stderr,"min exceeds field capacity\n");
		exit(-1);
	}
	
	dumpbw(pgbus);
	commit(pgbus);
}

static void writemax(struct gbus *pgbus,char *name,int v)
{
	int i=getbyname(name);

	printf("wanna set %d\n",v);

	if (256*v/100<=B[i].maxmax)
		B[i].max=256*v/100;
	else {
		fprintf(stderr,"max exceeds field capacity\n");
		exit(-1);
	}
	dumpbw(pgbus);
	commit(pgbus);
}

int main(int argc,char **argv) 
{
	RMascii device[256];
	struct llad *pllad;
	struct gbus *pgbus;

	if (argc<3) {
		fprintf(stderr,"Syntax: %s command --- example\n"
			"r\n"
			"d channel\n"
			"w channel >4   (in percent!)\n"
			"w channel <12\n"
			,argv[0]);
		return -1;
	}
	
	GetDeviceServer(argv, device, 256);
	pllad = llad_open(device);
	if (pllad == NULL) {
		fprintf(stderr, "%s: Unable to access device\n", argv[0]);
		exit(1);
	}

	pgbus=gbus_open(pllad);

	readbw(pgbus);

	switch (argv[1][0]) {
	case 'r':
		dumpbw();
		break;
	case 'd':
		disch(pgbus,argv[2]);
	case 'e':
		ench(pgbus,argv[2]);
	case 'w':
		if (argv[3][0]=='>') writemin(pgbus,argv[2],atoi(argv[3]+1));
		if (argv[3][0]=='<') writemax(pgbus,argv[2],atoi(argv[3]+1));
	default:
		break;
		printf("0x%08lx\n",gbus_read_uint32(pgbus,REG_BASE_system_block+VARB_mid30_cfg));
	}

	gbus_close(pgbus);
	llad_close(pllad);

	return 0;
}
