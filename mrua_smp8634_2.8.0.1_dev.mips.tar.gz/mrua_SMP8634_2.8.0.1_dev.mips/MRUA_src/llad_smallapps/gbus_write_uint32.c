/*****************************************
 Copyright � 2001-2003       
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE 1

#include "../llad/include/llad.h"
#include "../llad/include/gbus.h"

// Arguments
#include "getargs.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *basename(const char *str)
{
	const char *ptr;
	
	if ((str == NULL) || (strlen(str) == 0))
		return(str);
	
	ptr = str + strlen(str) - 1;
	while (ptr >= str) {
		if (*ptr == '/')
			break;
		else
			ptr--;
	}
	return(ptr + 1);
}

int main(int argc,char **argv) 
{
	struct llad *pllad;
	struct gbus *pgbus;
	RMuint32 byte_address;
	RMuint32 data;
	RMascii device[256];

	CheckArgCount (argc, 2, 2, argv, "<address> <data>");
	
	GetDeviceServer(argv, device, 256);
	pllad = llad_open(device);
	if (pllad == NULL) {
		fprintf(stderr, "%s: Unable to access device\n", argv[0]);
		exit(1);
	}

	pgbus = gbus_open(pllad);

	if (strcmp(basename(argv[0]), "gbus_write_uint8") == 0) {
		byte_address = GetUL(argv[1], 1, argv, "<address>");
		data         = GetUL(argv[2], 1, argv, "<data>");
		gbus_write_uint8(pgbus, byte_address, (RMuint8)(data & 0xff));
	} else if (strcmp(basename(argv[0]), "gbus_write_uint16") == 0) {
		byte_address = GetUL(argv[1], 2, argv, "<address>");
		data         = GetUL(argv[2], 1, argv, "<data>");
		gbus_write_uint16(pgbus, byte_address, (RMuint16)(data & 0xffff));
	} else { /* default is gbus_write_uint32 */
		byte_address = GetUL(argv[1], 4, argv, "<address>");
		data         = GetUL(argv[2], 1, argv, "<data>");
		gbus_write_uint32(pgbus, byte_address, data);
	}

	gbus_close(pgbus);
	llad_close(pllad);
	
	return 0;
}
