/*****************************************
 Copyright � 2001-2003       
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE 1

#include "../llad/include/llad.h"
#include "../llad/include/gbus.h"

// Arguments
#include "getargs.h"

#include <stdio.h>
#include <stdlib.h>

int main(int argc,char **argv) 
{
	struct llad *pllad;
	struct gbus *pgbus;
	RMuint32 byte_address;
	RMuint32 *data;
	FILE *f;
	unsigned long size, i;
	RMascii device[256];

	CheckArgCount (argc, 3, 3, argv, "<start> <size> <filename>");
    
	byte_address = GetUL(argv[1], 4, argv, "<start>");
	size         = GetUL(argv[2], 4, argv, "<size>");

	data = (RMuint32 *) malloc(size * sizeof(RMuint8)); 
	if (data == NULL) {
		perror(argv[0]);
		exit(1);
	}

	GetDeviceServer(argv, device, 256);
	pllad = llad_open(device);
	if (pllad == NULL) {
		fprintf(stderr, "%s: Unable to access device\n", argv[0]);
		exit(1);
	}

	pgbus = gbus_open(pllad);

	gbus_read_data32(pgbus, byte_address, data, size >> 2);

	gbus_close(pgbus);
	llad_close(pllad);
	
	f = fopen(argv[3], "w");
	if (f == NULL) {
		free(data);
		perror(argv[3]);
		exit(1);
	}
	
	for(i = 0; i < (size >> 2); i++) {
		fprintf(f, "%08lx\n", data[i]);
		if (ferror(f)) {
			perror(argv[0]);
			fclose(f);
			free(data);
			exit(1);
		}
	}
	
	fclose(f);
	free(data);

	return 0;

}

