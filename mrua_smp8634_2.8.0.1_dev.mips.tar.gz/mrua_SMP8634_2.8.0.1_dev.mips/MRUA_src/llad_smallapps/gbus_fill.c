/*****************************************
 Copyright � 2001-2003       
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE 1

#include "../llad/include/llad.h"
#include "../llad/include/gbus.h"

// Arguments
#include "getargs.h"

#include <stdio.h>
#include <stdlib.h>

int main(int argc,char **argv) 
{
	struct llad *pllad;
	struct gbus *pgbus;
	RMuint32 byte_address;
	RMuint32 data;
	RMuint32 size;
	RMascii device[256];
	RMuint32 count;

	CheckArgCount (argc, 3, 3, argv, "<address> <data> <size>");
	
	byte_address = GetUL(argv[1], 4, argv, "<address>");
	data         = GetUL(argv[2], 1, argv, "<data>");
	size         = GetUL(argv[3], 4, argv, "<size>");
	
	GetDeviceServer(argv, device, 256);
	pllad = llad_open(device);
	if (pllad == NULL) {
		fprintf(stderr, "%s: Unable to access device\n", argv[0]);
		exit(1);
	}

	pgbus = gbus_open(pllad);

	for (count = 0; count < size; count += 4)
		gbus_write_uint32(pgbus, byte_address + count, data);

	gbus_close(pgbus);
	llad_close(pllad);
	
	return 0;
}
