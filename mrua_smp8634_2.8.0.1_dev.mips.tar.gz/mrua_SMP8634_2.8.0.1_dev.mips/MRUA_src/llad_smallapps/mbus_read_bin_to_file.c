/*****************************************
 Copyright � 2001-2003       
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE 1

#include "../mbus/include/mbus.h"

// Arguments
#include "getargs.h"

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

/* string.h does not compile everywhere */
char *strcat(char *dest, const char *src);
int strcmp(const char *s1, const char *s2);
size_t strlen(const char *s);
char *strcpy(char *dest, const char *src);

int main(int argc,char **argv) 
{
	struct llad *pllad;
	unsigned long byte_address;
	unsigned char *data;
	FILE *f;
	unsigned long size, xfer_size;
	unsigned long max_pci_count;
	RMint32 status;
	RMascii device[256];
	
	CheckArgCount (argc, 3, 4, argv, "<start> <size> <filename> [<max pci count>]");
	
	byte_address = GetUL(argv[1], 1, argv, "<start>");
	size         = GetUL(argv[2], 1, argv, "<size>");

	if (argc > 4) 
		max_pci_count = GetUL(argv[4], 4, argv, "<max pci countt>");
	else
		max_pci_count = 65532;

	xfer_size = ((size + 3) / 4) * 4; // Just in case we are doing master transfers
	data = (unsigned char*)malloc(xfer_size * sizeof(char)); 
	if (data == NULL) {
		perror(argv[0]);
		exit(1);
	}
	
	GetDeviceServer(argv, device, 256);
	pllad = llad_open(device);
	if (pllad == NULL) {
		fprintf(stderr, "%s: Unable to access device\n", argv[0]);
		exit(1);
	}

	status = mbus_read_dram(pllad, byte_address, data, xfer_size,max_pci_count);
	
	llad_close(pllad);
	
	f = fopen(argv[3], "w");
	if (f == NULL) {
		free(data);
		perror(argv[3]);
		exit(1);
	}
	
	fwrite(data, sizeof(char), size, f);
	fclose(f);
	free(data);

	if (status > 0) {
		fprintf(stderr, "parameters not valid, src=0x%08lx, dest=%p size=%lu max_pci=%lu\n", byte_address, data, xfer_size, max_pci_count);
		exit(1);
	}
	if (status <0) {
		fprintf(stderr, "pci error with pci_count = %ld\n", (-status));
		exit(1);
	}

	printf("DONE\n");
	exit(0);
}
