/*****************************************
 Copyright � 2001-2003       
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE 1

#include "run_pt110.h"

#include "../llad/include/gbus.h"
#include "../mbus/include/mbus.h"

// Arguments
#include "getargs.h"

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <limits.h>
#include <math.h>
#include <time.h>
#include <sys/times.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

char *strcpy(char *dest, const char *src);
size_t strlen(const char *s);
int strcmp(const char *s1, const char *s2);
char *strncat(char *dest, const char *src, size_t n);

static struct llad *g_llad;
static struct gbus *g_gbus;
static options_t *options;

// ---------------------
// run_pt110 Entry point
// ---------------------

int main(int argc, char *argv[]) 
{
	RMascii device[256];

	options = parse_command_line (argc, argv); // Allocates the space. Don't forget to free if needed.
  
	// Connect to device
	GetDeviceServer(argv, device, 256);
	if (options->debug) 
		fprintf(stderr, "%s: opening mum device '%s'\n", argv[0], device);
	g_llad = llad_open(device);
	if (g_llad == NULL) {
		fprintf(stderr, "%s: Unable to access device\n", argv[0]);
		exit(1);
	}

	g_gbus = gbus_open(g_llad);

	// Reset pT-110
	gbus_write_uint32(g_gbus, CPU_RESET, 3);
	gbus_write_uint32(g_gbus, CPU_RESET, 1);

	// Set clock speed
	if (options->clock_speed != 0)
		set_clock_speed(options->clock_speed);
	else
		options->clock_speed = get_clock_speed();

	// Initialize DRAM
	if (!options->no_init_dram)
		init_dram(options->clock_speed);

	// Load MAMBiOs - Set the 0 address position
	if (options->MAMBiOs[0]) {
		if (options->debug) 
			fprintf(stderr, "%s: loading bios '%s' to 0x%08X\n", argv[0], options->MAMBiOs, CPU_REMAP_BASE);
		gbus_write_bin_file (CPU_REMAP_BASE, options->MAMBiOs);
	}
	gbus_write_uint32(g_gbus, CPU_REMAP, CPU_REMAP_BASE);
  
	// Load program
	if (options->debug) 
		fprintf(stderr, "%s: loading program '%s' to 0x%08lX\n", argv[0], options->program_name, options->code_start);
	gbus_write_bin_file (options->code_start, options->program_name);

	// Configure MAMBiOs
	gbus_write_uint32(g_gbus, TOP_OF_MEMORY, options->data_start + options->data_size);
	gbus_write_uint32(g_gbus, SVC_STACK_SIZE, 0x100);
	gbus_write_uint32(g_gbus, FIQ_STACK_SIZE, 0x100);
	gbus_write_uint32(g_gbus, IRQ_STACK_SIZE, 0x400);
	options->stack_limit = options->data_start + options->data_size - 0x300;
	gbus_write_uint32(g_gbus, STACK_LIMIT, options->stack_limit);
	gbus_write_uint32(g_gbus, HEAP_LIMIT, options->data_start);
	gbus_write_uint32(g_gbus, ENTRY_POINT, options->code_start);
	switch (options->device) {
	case DEVICE_MAMBO:
		gbus_write_uint32(g_gbus, PCI_INT_ADDRESS, MAMBO_PCI_INT);
		break;
	case DEVICE_TANGO:
		gbus_write_uint32(g_gbus, PCI_INT_ADDRESS, TANGO_PCI_SET_INT);
		break;
	default:
		fprintf(stderr, "Unknown device. Cannot handle interrupts\n");
		exit(1);
	}

	// Start program
	gbus_write_uint32(g_gbus, CPU_RESET, 0);

	// Wait for PCI interrupts
	while (1) {
		RMuint32 timeout_us = 100000;

		if (llad_wait_interrupt(g_llad, LLAD_WAIT_MAMBIOS_SYSCALL, &timeout_us)) {
			do_SWI(0);
		}
	}

	// Disconnect from device
	gbus_close(g_gbus);
	llad_close(g_llad);

	return 0;
}

void do_SWI(int dummy) 
{
	unsigned long SWI_r0;
	
	SWI_r0 = gbus_read_uint32(g_gbus, SWI_regs + 0);
	
	switch(SWI_r0) {
	case 0x01: SYS_OPEN        ((options_t*)options); break;
	case 0x02: SYS_CLOSE       ((options_t*)options); break;
	case 0x03: SYS_WRITEC      ((options_t*)options); break;
	case 0x04: SYS_WRITE0      ((options_t*)options); break;
	case 0x05: SYS_WRITE       ((options_t*)options); break;
	case 0x06: SYS_READ        ((options_t*)options); break;
	case 0x07: SYS_READC       ((options_t*)options); break;
	case 0x08: fprintf(stderr, "SYS_ISERROR not implemented yet\n"); break;
	case 0x09: SYS_ISTTY       ((options_t*)options); break;
	case 0x0a: SYS_SEEK        ((options_t*)options); break;
	case 0x0c: SYS_FLEN        ((options_t*)options); break;
	case 0x0d: SYS_TMPNAM      ((options_t*)options); break;
	case 0x0e: SYS_REMOVE      ((options_t*)options); break;
	case 0x0f: SYS_RENAME      ((options_t*)options); break;
	case 0x10: SYS_CLOCK       ((options_t*)options); break;
	case 0x11: SYS_TIME        ((options_t*)options); break;
	case 0x12: SYS_SYSTEM      ((options_t*)options); break;
	case 0x13: SYS_ERRNO       ((options_t*)options); break;
	case 0x15: SYS_GET_CMDLINE ((options_t*)options); break;
	case 0x16: SYS_HEAPINFO    ((options_t*)options); break;
	case 0x17: fprintf(stderr, "angel_SWIreason_EnterSVC not implemented yet\n"); break;
	case 0x18: angel_SWIreason_ReportException((options_t*)options); break;
	default: fprintf(stderr, "Invalid SWI number 0x%0lx\n", SWI_r0); break;
	}

	// acknowledge end of processing
	gbus_write_uint32(g_gbus, SWI_regs + 8, 0);
}

void SYS_OPEN(options_t* options) 
{
	char *filename;
	RMuint32 SWI_r0 = 0, SWI_r1;
	RMuint32 SWI_r1_struct[3];
	mode_t perm = S_IRUSR|S_IWUSR|S_IRGRP|S_IWGRP|S_IROTH|S_IWOTH;
	
	SWI_r1 = gbus_read_uint32(g_gbus, SWI_regs + 4);
	gbus_read_data32(g_gbus, REMAP(SWI_r1), SWI_r1_struct, 3);
	if (options->debug)
		fprintf(stderr, "SYS_OPEN r1: %08lX [r1]: name:%08lX mode:%08lX size:%08lX\n", 
			REMAP(SWI_r1), SWI_r1_struct[0], SWI_r1_struct[1], SWI_r1_struct[2]);
	filename = copy_string_from_ram(SWI_r1_struct[0], SWI_r1_struct[2] + 1);
	
	if (options->debug)
		fprintf(stderr, "SYS_OPEN %s\n", filename);
	
	if (strcmp(filename, ":tt"))
		switch (SWI_r1_struct[1]) {
		case 0: SWI_r0 = (unsigned long)open(filename, O_RDONLY, perm); break;
		case 1: SWI_r0 = (unsigned long)open(filename, O_RDONLY, perm); break;
		case 2: SWI_r0 = (unsigned long)open(filename, O_RDWR|O_CREAT, perm); break;
		case 3: SWI_r0 = (unsigned long)open(filename, O_RDWR|O_CREAT, perm); break;
		case 4: SWI_r0 = (unsigned long)open(filename, O_WRONLY|O_CREAT|O_TRUNC, perm); break;
		case 5: SWI_r0 = (unsigned long)open(filename, O_WRONLY|O_CREAT|O_TRUNC, perm); break;
		case 6: SWI_r0 = (unsigned long)open(filename, O_RDWR|O_CREAT|O_TRUNC, perm); break;
		case 7: SWI_r0 = (unsigned long)open(filename, O_RDWR|O_CREAT|O_TRUNC, perm); break;
		case 8: SWI_r0 = (unsigned long)open(filename, O_WRONLY|O_CREAT|O_APPEND, perm); break;
		case 9: SWI_r0 = (unsigned long)open(filename, O_WRONLY|O_CREAT|O_APPEND, perm); break;
		case 10: SWI_r0 = (unsigned long)open(filename, O_RDWR|O_CREAT|O_APPEND, perm); break;
		case 11: SWI_r0 = (unsigned long)open(filename, O_RDWR|O_CREAT|O_APPEND, perm); break;
		default: fprintf(stderr, "Error in SYS_OPEN: wrong open mode %lu\n", SWI_r1_struct[1]);
		}
	else
		switch (SWI_r1_struct[1]) {
		case 0: case 1: case 2: case 3: SWI_r0 = (unsigned long)STDIN_FILENO; break;
			// FIX: the ARM C Library asks for stdout and then for stderr
		case 4: case 5: case 6: case 7: SWI_r0 = (unsigned long)STDERR_FILENO; break;
		}
	
	if (options->debug)
		fprintf(stderr, "returns 0x%0lx\n", SWI_r0);
	
	gbus_write_uint32(g_gbus, SWI_regs + 0, SWI_r0);
	
	free(filename);
}

void SYS_CLOSE(options_t* options) 
{
	RMuint32 SWI_r0, SWI_r1;
	RMuint32 SWI_r1_struct[1];
	
	if (options->debug)
		fprintf(stderr, "SYS_CLOSE\n");
	
	SWI_r1 = gbus_read_uint32(g_gbus, SWI_regs + 4);
	gbus_read_data32(g_gbus, REMAP(SWI_r1), SWI_r1_struct, 1);
	SWI_r0 = close((int)SWI_r1_struct[0]);
	gbus_write_uint32(g_gbus, SWI_regs + 0, SWI_r0);
	
}

void SYS_WRITEC(options_t* options) 
{
	RMuint32 SWI_r1;
	
	if (options->debug)
		fprintf(stderr, "SYS_WRITEC\n");
	
	SWI_r1 = gbus_read_uint32(g_gbus, SWI_regs + 4);
	putchar(gbus_read_uint8(g_gbus, REMAP(SWI_r1)));
}

void SYS_WRITE0(options_t* options) 
{
	RMuint32 SWI_r1;
	char *s;
	
	if (options->debug)
		fprintf(stderr, "SYS_WRITE0\n");
	
	SWI_r1 = gbus_read_uint32(g_gbus, SWI_regs + 4);
	s = copy_string_from_ram(REMAP(SWI_r1), 0);
	printf("%s", s);
	free(s);
}

void SYS_WRITE(options_t* options) 
{
	RMuint32 SWI_r0, SWI_r1;
	RMuint32 SWI_r1_struct[3];
	char *s;
	int n;
	
	SWI_r1 = gbus_read_uint32(g_gbus, SWI_regs + 4);
	gbus_read_data32(g_gbus, REMAP(SWI_r1), SWI_r1_struct, 3);

	if (options->debug)
		fprintf(stderr, "SYS_WRITE %lu bytes from 0x%0lx\n", SWI_r1_struct[2], SWI_r1_struct[1]);

	s = copy_string_from_ram(SWI_r1_struct[1], SWI_r1_struct[2]);
	n = write((int)SWI_r1_struct[0], s, SWI_r1_struct[2]);
	if (n != -1)
		SWI_r0 = SWI_r1_struct[2] - n;
	else
		SWI_r0 = SWI_r1_struct[2];
	gbus_write_uint32(g_gbus, SWI_regs + 0, SWI_r0);
	free(s);
}

void SYS_READ(options_t* options) 
{
	RMuint32 SWI_r0, SWI_r1;
	RMuint32 SWI_r1_struct[4];
	char *s;
	int n;
	
	SWI_r1 = gbus_read_uint32(g_gbus, SWI_regs + 4);
	gbus_read_data32(g_gbus, REMAP(SWI_r1), SWI_r1_struct, 4);
	
	if (options->debug)
		fprintf(stderr, "SYS_READ %lu bytes from 0x%0lx to 0x%0lx\n",
			SWI_r1_struct[2], SWI_r1_struct[0], SWI_r1_struct[1]);
	
	s = (char*)malloc(SWI_r1_struct[2] * sizeof(char));
	n = read((int)SWI_r1_struct[0], s, SWI_r1_struct[2]);
	copy_string_to_ram (s, SWI_r1_struct[1], SWI_r1_struct[2] * sizeof(char));
	SWI_r0 = SWI_r1_struct[2] - n;
	gbus_write_uint32(g_gbus, SWI_regs + 0, SWI_r0);
	free(s);
}

void SYS_READC(options_t* options) 
{
	RMuint32 SWI_r0;
	
	if (options->debug)
		fprintf(stderr, "SYS_READC\n");
	
	SWI_r0 = getchar();
	gbus_write_uint32(g_gbus, SWI_regs + 0, SWI_r0);
}

void SYS_ISTTY(options_t* options) 
{
	RMuint32 SWI_r0, SWI_r1;
	RMuint32 SWI_r1_struct[1];
	
	if (options->debug)
		fprintf(stderr, "SYS_ISTTY\n");
	
	SWI_r1 = gbus_read_uint32(g_gbus, SWI_regs + 4);
	gbus_read_data32(g_gbus, REMAP(SWI_r1), SWI_r1_struct, 1);

	if (options->debug)
		fprintf(stderr, "isatty start\n");

	SWI_r0 = isatty((int)SWI_r1_struct[0]);

	if (options->debug)
		fprintf(stderr, "isatty end\n");

	gbus_write_uint32(g_gbus, SWI_regs + 0, SWI_r0);
}

void SYS_SEEK(options_t* options) 
{
	RMuint32 SWI_r0, SWI_r1;
	RMuint32 SWI_r1_struct[2];
	
	SWI_r1 = gbus_read_uint32(g_gbus, SWI_regs + 4);
	gbus_read_data32(g_gbus, REMAP(SWI_r1), SWI_r1_struct, 2);
	if (lseek(((int)SWI_r1_struct[0]), SWI_r1_struct[1], SEEK_SET) == (off_t)-1) {
		SWI_r0 = -1;
		if (options->debug) {
			fprintf(stderr, "SYS_SEEK FAILED with file %d, position %lu\n", ((int)SWI_r1_struct[0]), SWI_r1_struct[1]);
			perror("");
		}
	} else {
		if (options->debug)
			fprintf(stderr, "SYS_SEEK OK\n");
		SWI_r0 = 0;
	}
	
	gbus_write_uint32(g_gbus, SWI_regs + 0, SWI_r0);
}

void SYS_FLEN(options_t* options) 
{
	RMuint32 SWI_r0, SWI_r1;
	RMuint32 SWI_r1_struct[1];
	struct stat buf;
	
	if (options->debug)
		fprintf(stderr, "SYS_FLEN\n");
	
	SWI_r1 = gbus_read_uint32(g_gbus, SWI_regs + 4);
	gbus_read_data32(g_gbus, REMAP(SWI_r1), SWI_r1_struct, 1);

	if(fstat((int)SWI_r1_struct[0], &buf) == -1)
		SWI_r0 = -1;
	else
		SWI_r0 = (unsigned long)buf.st_size;
	gbus_write_uint32(g_gbus, SWI_regs + 0, SWI_r0);
}


void SYS_TMPNAM(options_t* options) 
{
	RMuint32 SWI_r0, SWI_r1;
	RMuint32 SWI_r1_struct[3];
	char s[] = "mambiosXXXXXX";
	int fd;

	if (options->debug)
		fprintf(stderr, "SYS_TMPNAM\n");
	
	SWI_r1 = gbus_read_uint32(g_gbus, SWI_regs + 4);
	gbus_read_data32(g_gbus, REMAP(SWI_r1), SWI_r1_struct, 3);

	fd = mkstemp(s);
	copy_string_to_ram (s, SWI_r1_struct[0], strlen(s));
	close(fd);
	SWI_r0 = 0;
	gbus_write_uint32(g_gbus, SWI_regs + 0, SWI_r0);
}

void SYS_REMOVE(options_t* options) 
{
	RMuint32 SWI_r0, SWI_r1;
	RMuint32 SWI_r1_struct[2];
	char *filename;
	
	if (options->debug)
		fprintf(stderr, "SYS_REMOVE\n");
	
	SWI_r1 = gbus_read_uint32(g_gbus, SWI_regs + 4);
	gbus_read_data32(g_gbus, REMAP(SWI_r1), SWI_r1_struct, 2);

	filename = copy_string_from_ram(SWI_r1_struct[0], SWI_r1_struct[1]);
	SWI_r0 = remove(filename);
	gbus_write_uint32(g_gbus, SWI_regs + 0, SWI_r0);
	free(filename);
}

void SYS_RENAME(options_t* options) 
{
	RMuint32 SWI_r0, SWI_r1;
	RMuint32 SWI_r1_struct[4];
	char *old_filename;
	char *new_filename;
	
	if (options->debug)
		fprintf(stderr, "SYS_RENAME\n");
	
	SWI_r1 = gbus_read_uint32(g_gbus, SWI_regs + 4);
	gbus_read_data32(g_gbus, REMAP(SWI_r1), SWI_r1_struct, 4);

	old_filename = copy_string_from_ram(SWI_r1_struct[0], SWI_r1_struct[1]);
	new_filename = copy_string_from_ram(SWI_r1_struct[2], SWI_r1_struct[3]); 
	SWI_r0 = rename(old_filename, new_filename);
	gbus_write_uint32(g_gbus, SWI_regs + 0, SWI_r0);
	free(old_filename);
	free(new_filename);
}

void SYS_CLOCK(options_t* options) 
{
	RMuint32 SWI_r0;
	struct tms buffer;
	
	SWI_r0 = (unsigned long)(times(&buffer) * 100) / CLK_TCK;
	
	if (options->debug)
		fprintf(stderr, "SYS_CLOCK -> %ld (%ld)\n", SWI_r0, times(&buffer));
	
	gbus_write_uint32(g_gbus, SWI_regs + 0, SWI_r0);
}

void SYS_TIME(options_t* options) 
{
	RMuint32 SWI_r0;
	
	if (options->debug)
		fprintf(stderr, "SYS_TIME\n");
	
	SWI_r0 = (unsigned long)time(NULL);
	gbus_write_uint32(g_gbus, SWI_regs + 0, SWI_r0);
}

void SYS_SYSTEM(options_t* options) 
{
	RMuint32 SWI_r0, SWI_r1;
	RMuint32 SWI_r1_struct[2];
	char *command;
	
	if (options->debug)
		fprintf(stderr, "SYS_SYSTEM\n");
	
	SWI_r1 = gbus_read_uint32(g_gbus, SWI_regs + 4);
	gbus_read_data32(g_gbus, REMAP(SWI_r1), SWI_r1_struct, 2);

	command = copy_string_from_ram(SWI_r1_struct[0], SWI_r1_struct[1]);
	SWI_r0 = system(command);
	gbus_write_uint32(g_gbus, SWI_regs + 0, SWI_r0);
	free(command);
}

void SYS_ERRNO(options_t* options) 
{
	RMuint32 SWI_r0;
	
	SWI_r0 = errno;
	
	if (options->debug)
		fprintf(stderr, "SYS_ERRNO %lu\n", SWI_r0);
	
	gbus_write_uint32(g_gbus, SWI_regs + 0, SWI_r0);
}

void SYS_GET_CMDLINE (options_t* options) 
{
	RMuint32 SWI_r0, SWI_r1;
	RMuint32 SWI_r1_struct[2];
	int i;
	unsigned long bytes_left_in_buffer;
	char *s;
	
	if (options->debug) {
		fprintf(stderr, "argc = %d\n", options->argc);
		for(i = 0; i < options->argc; i++)
			fprintf(stderr, "argv[%d] = %s\n", i, options->argv[i]);
	}
	
	SWI_r1 = gbus_read_uint32(g_gbus, SWI_regs + 4);
	gbus_read_data32(g_gbus, REMAP(SWI_r1), SWI_r1_struct, 2);

	bytes_left_in_buffer = SWI_r1_struct[1] - 1;
	s = (char*)malloc(SWI_r1_struct[1]);
	if(s == NULL) {
		fprintf(stderr, "Unable to malloc 0x%08lx bytes\n", SWI_r1_struct[1]);
		exit (1);
	}
	s[0] = 0;
	for(i = 0; i < options->argc - 1; i++) {
		strncat(s, options->argv[i], bytes_left_in_buffer);
		bytes_left_in_buffer -= strlen(options->argv[i]);
		strncat(s, " ", bytes_left_in_buffer);
		bytes_left_in_buffer -= 1;
	}
	strncat(s, options->argv[options->argc - 1], bytes_left_in_buffer);
	bytes_left_in_buffer -= strlen(options->argv[options->argc - 1]);
	
	if (options->debug)
		fprintf(stderr, "SYS_GET_CMDLINE \"%s\" to 0x%0lx\n", s, SWI_r1_struct[0]);
	
	copy_string_to_ram (s, SWI_r1_struct[0], SWI_r1_struct[1]);  
	SWI_r1_struct[1] = strlen(s);
	SWI_r0 = 0;
	gbus_write_uint32(g_gbus, SWI_regs + 0, SWI_r0);
	gbus_write_data32(g_gbus, REMAP(SWI_r1), SWI_r1_struct, 2);
	
	free(s);
}

void SYS_HEAPINFO(options_t* options) 
{
	RMuint32 SWI_r1;
	RMuint32 SWI_r1_struct[1];
	
	if (options->debug)
		fprintf(stderr, "SYS_HEAPINFO\nheap_limit = 0x%0lx\nstack_limit = 0x%0lx\n",
			options->data_start, options->stack_limit);
	
	SWI_r1 = gbus_read_uint32(g_gbus, SWI_regs + 4);
	gbus_read_data32(g_gbus, REMAP(SWI_r1), SWI_r1_struct, 1);

	if (options->debug) {
		fprintf(stderr, "r1 = 0x%0lx, [r1] = 0x%0lx\n", SWI_r1, SWI_r1_struct[0]);
	}
	gbus_write_uint32(g_gbus, REMAP(SWI_r1_struct[0]) +  0, options->data_start);
	gbus_write_uint32(g_gbus, REMAP(SWI_r1_struct[0]) +  4, options->stack_limit);
	gbus_write_uint32(g_gbus, REMAP(SWI_r1_struct[0]) +  8, options->stack_limit);
	gbus_write_uint32(g_gbus, REMAP(SWI_r1_struct[0]) + 12, options->data_start);
}

void angel_SWIreason_ReportException (options_t* options) {
	RMuint32 SWI_r1;

	SWI_r1 = gbus_read_uint32(g_gbus, SWI_regs + 4);
	
	switch (SWI_r1) {
	case 0x20000: fprintf(stderr, "ADP_Stopped_BranchThroughZero\n"); break;
	case 0x20001: fprintf(stderr, "ADP_Stopped_UndefinedInstr\n"); break;
	case 0x20002: fprintf(stderr, "ADP_Stopped_SoftwareInterrupt\n"); break;
	case 0x20003: fprintf(stderr, "ADP_Stopped_PrefetchAbort\n"); break;
	case 0x20004: fprintf(stderr, "ADP_Stopped_DataAbort\n"); break;
	case 0x20005: fprintf(stderr, "ADP_Stopped_AddressException\n"); break;
	case 0x20006: fprintf(stderr, "ADP_Stopped_IRQ\n"); break;
	case 0x20007: fprintf(stderr, "ADP_Stopped_FIQ\n"); break;
	case 0x20020: fprintf(stderr, "ADP_Stopped_BreakPoint\n"); break;
	case 0x20021: fprintf(stderr, "ADP_Stopped_WatchPoint\n"); break;
	case 0x20022: fprintf(stderr, "ADP_Stopped_StepComplete\n"); break;
	case 0x20023: fprintf(stderr, "ADP_Stopped_RunTimeErrorUnknown\n"); break;
	case 0x20024: fprintf(stderr, "ADP_Stopped_InternalError\n"); break;
	case 0x20025: fprintf(stderr, "ADP_Stopped_UserInterruption\n"); break;
	case 0x20026: if (options->debug) fprintf(stderr, "ADP_Stopped_ApplicationExit\n"); break;
	case 0x20027: fprintf(stderr, "ADP_Stopped_StackOverflow\n"); break;
	case 0x20028: fprintf(stderr, "ADP_Stopped_DivisionByZero\n"); break;
	case 0x20029: fprintf(stderr, "ADP_Stopped_OSSpecific\n"); break;
	default: fprintf(stderr, "Received invalid angel_SWIreason_ReportException\n"); break;
	}

	if (options->reset_on_exit)
		gbus_write_uint32(g_gbus, CPU_RESET, 2);

	exit(0);
}


#define REALLOC_STEP 4096
char* copy_string_from_ram (unsigned long start_address, unsigned long size) 
{
	unsigned long i = 0;
	unsigned long current_size = 0;
	char *s = NULL;
	
	if(size) {
		unsigned long mbus_xfer_size = 0;
		s = (char*)malloc(size * sizeof(char));
		if (s == NULL) {
			fprintf(stderr, "Error in copy_string_from_ram: malloc failed\n");
			exit(1);
		}
 		if ((size > 128) && (REMAP(start_address) >= 0x10000000)) {
		  mbus_xfer_size = size - (size % 4);
  		  mbus_read_dram(g_llad, REMAP(start_address), (RMuint8 *)s, mbus_xfer_size, 65532);
  		}
		if (size - mbus_xfer_size) {
		  gbus_read_data8(g_gbus, REMAP(start_address + mbus_xfer_size),
				  (RMuint8 *)(s + mbus_xfer_size), size - mbus_xfer_size);
		}
	} else {
		do {
			if (i == current_size) {
				current_size += REALLOC_STEP;
				s = (char*)realloc((void*)s, current_size * sizeof(char));
			}
			s[i] = gbus_read_uint8(g_gbus, REMAP(start_address) + i);
			i++;
		} while (s[i - 1]);
		
		s = (char*)realloc((void*)s, i * sizeof(char));
		if (s == NULL) {
			fprintf(stderr, "Error in copy_string_from_ram: realloc failed\n");
			exit(1);
		}
	}
	return s;
}

void copy_string_to_ram (char *s, unsigned long start_address, unsigned long size) 
{
		unsigned long mbus_xfer_size = 0;
 		if ((size > 128) && (REMAP(start_address) >= 0x10000000)) {
		  mbus_xfer_size = size - (size % 4);
  		  mbus_write_dram(g_llad, REMAP(start_address), (RMuint8 *)s, mbus_xfer_size, 65532);
  		}
		if (size - mbus_xfer_size) {
		  gbus_write_data8(g_gbus, REMAP(start_address + mbus_xfer_size),
				  (RMuint8 *)(s + mbus_xfer_size), size - mbus_xfer_size);
		}
}

unsigned long gbus_write_bin_file (unsigned long start_address, char *filename) 
{
	
	FILE *f;
	unsigned char *data;
	unsigned long byte_address;
	unsigned long size;
	
	f = fopen(filename, "rb");
	if (f == NULL) {
		perror(filename);
		exit(1);
	}
	
	data = (unsigned char*)malloc(BLOCK_SIZE * sizeof(unsigned char));
	byte_address = start_address;
	size = 0;
	while((size = fread(data, sizeof(char), BLOCK_SIZE, f))) {
		gbus_write_data8(g_gbus, byte_address, data, size);
		byte_address += size;
	}
	
	fclose(f);
	free(data);
	return (byte_address - start_address);
}

float set_clock_speed (float speed) 
{
	float ratio;
	float error, min_error;
	int n, m, best_n = 0, best_m = 0;
	const float XTAL_IN = 27.0;
	
	min_error = 100000;
	ratio = 2 * speed / XTAL_IN;
	for (m = 1; m < 64; m++) {
		n = (int)floor(ratio * (m + 2) - 2 + 0.5);
		if (n < 256) {
			error = (float)fabs(ratio - (double)(n + 2) / (m + 2));
			if(error < min_error) {
				min_error = error;
				best_n = n;
				best_m = m;
			}
		}
	}
	gbus_write_uint32(g_gbus, SYS_CLKGEN0_PLL, (1 << 24) + (best_m << 16) + best_n);
	gbus_write_uint32(g_gbus, SYS_SYSCLK_MUX, 1);
	return (XTAL_IN * (best_n + 2) / (best_m + 2) / 2);
}

float get_clock_speed () 
{
	unsigned long pll_reg;
	int n, m;
	const float XTAL_IN = 27.0;
	
	pll_reg = gbus_read_uint32(g_gbus, SYS_CLKGEN0_PLL);
	n = pll_reg & 0xFF;
	m = (pll_reg >> 16) & 0x3F;
	return (XTAL_IN * (n + 2) / (m + 2));
}

void init_dram(float clock_speed) 
{
	if ((clock_speed < 133.0) || (clock_speed > 167.0)) {
		fprintf(stderr, "Error: Clock speed must be between 133 MHz and 167 MHz\n");
		exit(1);
	}
	
	gbus_write_uint32(g_gbus, DRAM0_RESET, 0x3);
	gbus_write_uint32(g_gbus, DRAM1_RESET, 0x3);
	gbus_write_uint32(g_gbus, DRAM0_RESET, 0x2);
	gbus_write_uint32(g_gbus, DRAM1_RESET, 0x2);
	gbus_write_uint32(g_gbus, DRAM0_DUNIT_CFG, 0xE34000B8);
	/* hack hardcoding odyssey board setting. Must be done
	   by serial flash or by taking decision by subsystemid */
	gbus_write_uint32(g_gbus, DRAM1_DUNIT_CFG, 0xE34000B8);
	gbus_write_uint32(g_gbus, DRAM0_DUNIT_DELAY_CTRL, 0x93333);
	gbus_write_uint32(g_gbus, DRAM1_DUNIT_DELAY_CTRL, 0x93333);
	gbus_write_uint32(g_gbus, DRAM0_RESET, 0x0);
	gbus_write_uint32(g_gbus, DRAM1_RESET, 0x0);
}


options_t* parse_command_line (int argc, char **argv) 
{
	options_t* options;
	int option_incr;
	char *endptr;
	
	// Check for program name
	if (argc == 1) {
		fprintf(stderr, "\
Usage: run_pt110 <option(s)> <file>\n\
 Run <file> on the pt110.\n\
 <option(s)> are:\n\
  -v, --verbose               Turns on debugging output\n\
  -d, --device [mambo|tango]  select hardware (default is mambo)\n\
  -o, --code-start <address>  Loads <file> and starts execution at <address>\n\
  -h, --data-start <address>\n\
  -s, --data-size <size>\n\
  -c, --clock-speed <freq>    Sets the clock speed to <freq> MHz\n\
                              133.0 < <freq> < 167.0\n\
  -n, --no-init-dram          Don't set up DRAM\n\
  -r, --no-reset              Don't reset CPU on exit\n\
  -M, --load-MAMBiOs <file>\n\
\n\
  Default memory map is:\n\
  code-start = 0x10000000\n\
  data-start = 0x10100000\n\
  data-size  = 0x00100000\n\
\n\
  If your data or your code is more than 1 MB, you need to adjust these values.\n\
");
		exit(1);
	}
	
	options = (options_t*)malloc(sizeof(options_t));
	
	// Default values
	options->debug = 0;
	options->code_start  = 0x10000000;
	options->data_start  = 0x10100000; 
	options->data_size   = 0x00100000;
	options->clock_speed = 148.5;
	options->no_init_dram = 0;
	options->reset_on_exit = 1;
	options->MAMBiOs = (char*)malloc(256 * sizeof(char));
	options->device = DEVICE_MAMBO;
	strcpy(options->MAMBiOs, "/utils/em8xxx/shelldriver/lib/MAMBiOs.bin");
	
	// Skip "run_p110"
	argv++; argc--;
	// Parse command line
	do {
		option_incr = 0;
		if ((!strcmp(argv[0], "-v")) || (!strcmp(argv[0], "--verbose"))) {
			options->debug = 1;
			option_incr = 1;
		}
		if ((!strcmp(argv[0], "-d")) || (!strcmp(argv[0], "--device"))) {
			if (argc < 2)
				goto cmdline_error;
			if (strcmp(argv[1], "mambo") == 0) 
				options->device = DEVICE_MAMBO;
			else if (strcmp(argv[1], "tango") == 0) 
				options->device = DEVICE_TANGO;
			else
				goto cmdline_error;
			option_incr = 2;
		}
		if ((!strcmp(argv[0], "-n")) || (!strcmp(argv[0], "--no-init-dram"))) {
			options->no_init_dram = 1;
			option_incr = 1;
		}
		if ((!strcmp(argv[0], "-r")) || (!strcmp(argv[0], "--no-reset"))) {
			options->reset_on_exit = 0;
			option_incr = 1;
		}
		if ((!strcmp(argv[0], "-o")) || (!strcmp(argv[0], "--code-start"))) {
			if (argc < 2)
				goto cmdline_error;
			options->code_start = strtoul(argv[1], &endptr, 0);
			if(endptr[0] != '\0')
				goto cmdline_error;
			option_incr = 2;
		}
		if ((!strcmp(argv[0], "-h")) || (!strcmp(argv[0], "--data-start"))) {
			if (argc < 2)
				goto cmdline_error;
			options->data_start = strtoul(argv[1], &endptr, 0);
			if(endptr[0] != '\0')
				goto cmdline_error;
			option_incr = 2;
		}
		if ((!strcmp(argv[0], "-s")) || (!strcmp(argv[0], "--data-size"))) {
			if (argc < 2)
				goto cmdline_error;
			options->data_size = strtoul(argv[1], &endptr, 0);
			if(endptr[0] != '\0')
				goto cmdline_error;
			option_incr = 2;
		}
		if ((!strcmp(argv[0], "-c")) || (!strcmp(argv[0], "--clock-speed"))) {
			if (argc < 2)
				goto cmdline_error;
			options->clock_speed = (float)strtod(argv[1], &endptr);
			if(endptr[0] != '\0')
				goto cmdline_error;
			option_incr = 2;
		}
		if ((!strcmp(argv[0], "-M")) || (!strcmp(argv[0], "--load-MAMBiOs"))) {
			if (argc < 2)
				goto cmdline_error;
			options->MAMBiOs = argv[1];
			option_incr = 2;
		}
		
		argv += option_incr;
		argc -= option_incr;
	} while (option_incr);
	
	// Get the program name
	if (argc < 1) {
		fprintf(stderr, "run_pt110: Missing program name\n");
		exit(1);
	}
	options->program_name = argv[0];
	
	// Send the rest of the command line to the pt110
	options->argc = argc;
	options->argv = argv;
	
	return options;
	
 cmdline_error:
	
	fprintf(stderr, "run_pt110: Error in %s option\n", argv[0]);
	exit(1);
}
