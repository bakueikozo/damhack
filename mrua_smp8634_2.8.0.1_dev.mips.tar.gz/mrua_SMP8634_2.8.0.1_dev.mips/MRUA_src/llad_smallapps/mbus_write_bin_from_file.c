/*****************************************
 Copyright � 2001-2003       
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE 1

#include "../mbus/include/mbus.h"

// Arguments
#include "getargs.h"

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

/* string.h does not compile everywhere */
char *strcat(char *dest, const char *src);
int strcmp(const char *s1, const char *s2);
size_t strlen(const char *s);
char *strcpy(char *dest, const char *src);

#define BLOCK_SIZE 65536

int main(int argc,char **argv) 
{
	struct llad *pllad;
	unsigned long byte_address;
	unsigned char *data;
	FILE *f;
	unsigned long size;
	unsigned long offset;
	unsigned long max_pci_count;
	RMascii device[256];

	CheckArgCount (argc, 2, 5, argv, "<address> <filename> [<max pci count>] [<offset>] [<size>]");

	byte_address = GetUL(argv[1], 1, argv, "<address>");

	if (argc > 3) 
		max_pci_count = GetUL(argv[3], 4, argv, "<max pci countt>");
	else
		max_pci_count = 65532;

	if (argc > 4)
		offset = GetUL(argv[4], 1, argv, "<offset>");
	else
		offset = 0;

	if (argc > 5)
		size = GetUL(argv[5], 1, argv, "<size>");
	else
		size = 0;

	f = fopen(argv[2], "rb");
	if (f == NULL) {
		perror(argv[2]);
		exit(1);
	}
	fseek(f, offset, SEEK_SET);

	GetDeviceServer(argv, device, 256);
 	pllad = llad_open(device);
	if (pllad == NULL) {
		fprintf(stderr, "%s: Unable to access device\n", argv[0]);
		exit(1);
	}

	
	if (size) {
		RMint32 status;
		
		data = (unsigned char*)malloc(size * sizeof(unsigned char));
		size = fread(data, sizeof(char), size, f);
		status = mbus_write_dram(pllad, byte_address, data, size, max_pci_count);
		if (status > 0) {
			fprintf(stderr, "parameters not valid, dest=0x%08lx, src=0x%p size=%lu max_pci=%lu\n", byte_address, data, size, max_pci_count);
			exit(1);
		}
		if (status <0) {
			fprintf(stderr, "pci error with pci_count = %ld\n", (-status));
			exit(1);
		}
	} else {
		RMint32 status;

		data = (unsigned char*)malloc(BLOCK_SIZE * sizeof(unsigned char));
		size = 0;
		while((size = fread(data, sizeof(char), BLOCK_SIZE, f)) > 0) {
			status = mbus_write_dram(pllad, byte_address, data, size, max_pci_count);
			if (status > 0) {
				fprintf(stderr, "parameters not valid, dest=0x%08lx, src=0x%p size=%lu max_pci=%lu\n", byte_address, data, size, max_pci_count);
				exit(1);
			}
			if (status <0) {
				fprintf(stderr, "pci error with pci_count = %ld\n", (-status));
				exit(1);
			}
			byte_address += size;
		}
	}

	llad_close(pllad);
  
	fclose(f);
	free(data);
	printf("DONE\n");
  
	exit(0);
}
