/*****************************************
 Copyright � 2001-2003       
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE 1

#include "../llad/include/llad.h"
#include "../llad/include/gbus.h"
#include "../emhwlib_hal/include/emhwlib_registers.h"

// Arguments
#include "getargs.h"

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// remove these
#define SYS_CLKGEN0_PLL 0x10000
#define SYS_SYSCLK_MUX 0x1003C
#define CPU_RESET 0x6FFFC
#define DRAM0_DUNIT_CFG 0x30000
#define DRAM0_DUNIT_DELAY_CTRL 0x30004
#define DRAM0_RESET 0x3FFFC
#define DRAM1_DUNIT_CFG 0x40000
#define DRAM1_DUNIT_DELAY_CTRL 0x40004
#define DRAM1_RESET 0x4FFFC

// search&replace these
RMmustBeEqual(REG_BASE_system_block+SYS_clkgen0_pll,SYS_CLKGEN0_PLL,seed0);
RMmustBeEqual(REG_BASE_system_block+SYS_sysclk_mux,SYS_SYSCLK_MUX,seed1);
RMmustBeEqual(REG_BASE_cpu_block+G2L_RESET_CONTROL,CPU_RESET,seed2);
RMmustBeEqual(REG_BASE_dram_controller_0+DRAM_dunit_cfg,DRAM0_DUNIT_CFG,seed3);
RMmustBeEqual(REG_BASE_dram_controller_0+DRAM_dunit_delay0_ctrl,DRAM0_DUNIT_DELAY_CTRL,seed4);
RMmustBeEqual(REG_BASE_dram_controller_0+G2L_RESET_CONTROL,DRAM0_RESET,seed5);
RMmustBeEqual(REG_BASE_dram_controller_1+DRAM_dunit_cfg,DRAM1_DUNIT_CFG,seed6);
RMmustBeEqual(REG_BASE_dram_controller_1+DRAM_dunit_delay0_ctrl,DRAM1_DUNIT_DELAY_CTRL,seed7);
RMmustBeEqual(REG_BASE_dram_controller_1+G2L_RESET_CONTROL,DRAM1_RESET,seed8);

#define XTAL_IN 27000000.0

int main(int argc,char **argv) 
{
	struct llad *pllad;
	struct gbus *pgbus;
	RMuint32 clock;
	double ratio, error, min_error;
	int n, m, best_n, best_m;
	RMascii device[256];

	CheckArgCount (argc, 1, 1, argv, "<clock Hz>");
	
	clock = GetUL(argv[1], 1, argv, "<clock Hz>");
	
	GetDeviceServer(argv, device, 256);
	pllad = llad_open(device);
	if (pllad == NULL) {
		fprintf(stderr, "%s: Unable to access device\n", argv[0]);
		exit(1);
	}

	pgbus = gbus_open(pllad);

	ratio = 2 * clock / XTAL_IN;
	min_error = 200000000.0;
	error = 0;
	best_n = 0;
	best_m = 0;
	for (m=1; m<64; m++) {
                n = (int)floor(ratio * (m + 2) - 2 + 0.5);
                if (n < 256) {
                        error = (float)fabs(ratio - (double)(n + 2) / (m + 2));
                        if(error < min_error) {
                                min_error = error;
                                best_n = n;
                                best_m = m;
                        }
                }
        }

	/* stop CPU */
	gbus_write_uint32(pgbus, CPU_RESET, 3);
        gbus_write_uint32(pgbus, CPU_RESET, 1);
	
	/* program system clock */
        gbus_write_uint32(pgbus, SYS_CLKGEN0_PLL, (1 << 24) + (best_m << 16) + best_n);
        gbus_write_uint32(pgbus, SYS_SYSCLK_MUX, 1);

	/* program DRAM controllers */
	gbus_write_uint32(pgbus, DRAM0_RESET, 0x3);
        gbus_write_uint32(pgbus, DRAM1_RESET, 0x3);
        gbus_write_uint32(pgbus, DRAM0_RESET, 0x2);
        gbus_write_uint32(pgbus, DRAM1_RESET, 0x2);
	if (clock >= 120000000) {
		gbus_write_uint32(pgbus, DRAM0_DUNIT_CFG, 0xE34000B8);
		gbus_write_uint32(pgbus, DRAM1_DUNIT_CFG, 0xE34000B8);
	}
	else if (clock >= 68000000) {
		gbus_write_uint32(pgbus, DRAM0_DUNIT_CFG, 0xE33000B4);
		gbus_write_uint32(pgbus, DRAM1_DUNIT_CFG, 0xE33000B4);
	}
	else {
		gbus_write_uint32(pgbus, DRAM0_DUNIT_CFG, 0xE32000A8);
		gbus_write_uint32(pgbus, DRAM1_DUNIT_CFG, 0xE32000A8);
	}
	gbus_write_uint32(pgbus, DRAM0_DUNIT_DELAY_CTRL, 0x93333);
        gbus_write_uint32(pgbus, DRAM1_DUNIT_DELAY_CTRL, 0x93333);
        gbus_write_uint32(pgbus, DRAM0_RESET, 0x0);
        gbus_write_uint32(pgbus, DRAM1_RESET, 0x0);

	gbus_close(pgbus);
	llad_close(pllad);
	
	printf("best n:%d, best m:%d\n", best_n, best_m); 
	printf("set clock to %lu Hz\n", (RMuint32) (XTAL_IN * (best_n + 2) / (best_m + 2) / 2));

	return 0;
}
