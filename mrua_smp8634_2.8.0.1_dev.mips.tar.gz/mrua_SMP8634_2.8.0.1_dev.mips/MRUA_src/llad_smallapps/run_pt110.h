/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   run_pt110.h
  @brief  

  long description

  @author Guillaume Etorre
  @date   2003-05-12
*/

#ifndef __RUN_PT110_H__
#define __RUN_PT110_H__

#include "../rmdef/rmdef.h"
#include "../emhwlib_hal/include/emhwlib_registers.h"

#define DEVICE_MAMBO 1
#define DEVICE_TANGO 2

#define MAMBO_PCI_INT     0x29020
#define TANGO_PCI_SET_INT 0x29024

#define SYS_CLKGEN0_PLL 0x10000
#define SYS_SYSCLK_MUX 0x1003C
#define DRAM0_DUNIT_CFG 0x30000
#define DRAM0_DUNIT_DELAY_CTRL 0x30004
#define DRAM0_RESET 0x3FFFC
#define DRAM1_DUNIT_CFG 0x40000
#define DRAM1_DUNIT_DELAY_CTRL 0x40004
#define DRAM1_RESET 0x4FFFC
#define CPU_REMAP 0x6F000
#define CPU_RESET 0x6FFFC

RMmustBeEqual(REG_BASE_system_block+SYS_clkgen0_pll,SYS_CLKGEN0_PLL,seed0);
RMmustBeEqual(REG_BASE_system_block+SYS_sysclk_mux,SYS_SYSCLK_MUX,seed1);
RMmustBeEqual(REG_BASE_dram_controller_0+DRAM_dunit_cfg,DRAM0_DUNIT_CFG,seed3);
RMmustBeEqual(REG_BASE_dram_controller_0+DRAM_dunit_delay0_ctrl,DRAM0_DUNIT_DELAY_CTRL,seed4);
RMmustBeEqual(REG_BASE_dram_controller_0+G2L_RESET_CONTROL,DRAM0_RESET,seed5);
RMmustBeEqual(REG_BASE_dram_controller_1+DRAM_dunit_cfg,DRAM1_DUNIT_CFG,seed6);
RMmustBeEqual(REG_BASE_dram_controller_1+DRAM_dunit_delay0_ctrl,DRAM1_DUNIT_DELAY_CTRL,seed7);
RMmustBeEqual(REG_BASE_dram_controller_1+G2L_RESET_CONTROL,DRAM1_RESET,seed8);
RMmustBeEqual(REG_BASE_cpu_block+CPU_remap,CPU_REMAP,seed2);
RMmustBeEqual(REG_BASE_cpu_block+G2L_RESET_CONTROL,CPU_RESET,seed9);

#define CPU_REMAP_BASE 0x60000
#define REMAP(x) ((x < 0x10000) ? x + CPU_REMAP_BASE : x)
#define TOP_OF_MEMORY     REMAP(0x40)
#define SVC_STACK_SIZE    REMAP(0x44)
#define FIQ_STACK_SIZE    REMAP(0x48)
#define IRQ_STACK_SIZE    REMAP(0x4C)
#define STACK_LIMIT       REMAP(0x50)
#define HEAP_LIMIT        REMAP(0x54)
#define MMU_TABLE         REMAP(0x58)
#define ENTRY_POINT       REMAP(0x5C)
#define SWI_regs          REMAP(0x60)
#define PCI_INT_ADDRESS   REMAP(0x6C)

#define BLOCK_SIZE 65536


// --------------------
// Command line options
// --------------------
struct s_options_t {
	int debug;
	char* program_name;
	char* MAMBiOs;
	unsigned long code_start;
	unsigned long data_start;
	unsigned long data_size;
	float clock_speed;
	int no_init_dram;
	int reset_on_exit;
	unsigned long device;

	unsigned long stack_limit;
	int argc;
	char **argv;
};

typedef struct s_options_t options_t;

// ---------
// Utilities
// ---------
options_t* parse_command_line (int argc, char **argv);
float set_clock_speed (float speed);
float get_clock_speed (void);
void init_dram(float clock_speed);
char* copy_string_from_ram (unsigned long start_address, unsigned long size);
void copy_string_to_ram (char *s, unsigned long start_address, unsigned long size);
unsigned long gbus_write_bin_file (unsigned long start_address, char *filename);
void do_SWI(int dummy);

// -------------------------------------------------------
// Semi-hosting tasks as defined in ARM debug target guide
// -------------------------------------------------------
void SYS_OPEN        (options_t* options);
void SYS_CLOSE       (options_t* options);
void SYS_WRITEC      (options_t* options);
void SYS_WRITE0      (options_t* options);
void SYS_WRITE       (options_t* options);
void SYS_READ        (options_t* options);
void SYS_READC       (options_t* options);
void SYS_ISTTY       (options_t* options);
void SYS_SEEK        (options_t* options);
void SYS_FLEN        (options_t* options);
void SYS_TMPNAM      (options_t* options);
void SYS_REMOVE      (options_t* options);
void SYS_RENAME      (options_t* options);
void SYS_CLOCK       (options_t* options);
void SYS_TIME        (options_t* options);
void SYS_SYSTEM      (options_t* options);
void SYS_ERRNO       (options_t* options);
void SYS_GET_CMDLINE (options_t* options);
void SYS_HEAPINFO    (options_t* options);
void angel_SWIreason_ReportException (options_t* options);
 
#endif // __RUN_PT110_H__
