/*****************************************
 Copyright � 2001-2003       
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE 1

#include "../llad/include/llad.h"
#include "../llad/include/gbus.h"

// Arguments
#include "getargs.h"

#include <stdio.h>
#include <stdlib.h>

int main(int argc,char **argv) 
{
	struct llad *pllad;
	struct gbus *pgbus;
	RMuint32 byte_address;
	unsigned long *data, *more_data;
	char *error_pos;
	char line[10];
	FILE *f;
	unsigned long index, size;
	RMascii device[256];
	
	CheckArgCount (argc, 2, 4, argv, "<address> <filename> [<offset>] [<size>]");

	byte_address = GetUL(argv[1], 4, argv, "<address>");

	f = fopen(argv[2], "r");
	if (f == NULL) {
		perror(argv[2]);
		exit(1);
	}
	
	index = 0;
	data = NULL;
	size = 0;
	while(fgets(line, 10, f) != NULL) {
		while(index >= size) {
			size += 65536;
			more_data = (unsigned long*)realloc(data, size * sizeof(unsigned long));
			if (more_data == NULL) {
				perror(argv[0]);
				free(data);
				exit(1);
			} else {
				data = more_data;
			}
		}
		
		data[index] = strtoul(line, &error_pos, 16);
		if (error_pos[0] == '\0') {
			fprintf(stderr, "%s: Error: Missing newline at end of file\n", argv[0]);
			free(data);
			exit(1);
		}
		if (error_pos[0] != '\n') {
			fprintf(stderr, "%s: Error: data in <filename> must be hexadecimal numbers\n", argv[0]);
			free(data);
			exit(1);
		}
		index++;
	}
	fclose(f);

	GetDeviceServer(argv, device, 256);
	pllad = llad_open(device);
	if (pllad == NULL) {
		fprintf(stderr, "%s: Unable to access device\n", argv[0]);
		exit(1);
	}

	pgbus = gbus_open(pllad);

	gbus_write_data32(pgbus, byte_address, data, index);
	
	gbus_close(pgbus);
	llad_close(pllad);
	
	free(data);
  
	return 0;
}
