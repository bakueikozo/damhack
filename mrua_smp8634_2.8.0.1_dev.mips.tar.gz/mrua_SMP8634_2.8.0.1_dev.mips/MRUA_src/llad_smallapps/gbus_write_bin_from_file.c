/*****************************************
 Copyright � 2001-2003       
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE 1

#include "../llad/include/llad.h"
#include "../llad/include/gbus.h"

// Arguments
#include "getargs.h"

#include <stdio.h>
#include <stdlib.h>

#define BLOCK_SIZE 65536

int main(int argc,char **argv) 
{
	struct llad *pllad;
	struct gbus *pgbus;
	RMuint32 byte_address;
	RMuint8 *data;
	FILE *f;
	unsigned long size, offset;
	RMascii device[256];

	CheckArgCount (argc, 2, 4, argv, "<address> <filename> [<offset>] [<size>]");

	byte_address = GetUL(argv[1], 1, argv, "<address>");

	if (argc > 3)
		offset = GetUL(argv[3], 1, argv, "<offset>");
	else
		offset = 0;

	if (argc > 4)
		size = GetUL(argv[4], 1, argv, "<size>");
	else
		size = 0;

	f = fopen(argv[2], "rb");
	if (f == NULL) {
		perror(argv[2]);
		exit(1);
	}
	fseek(f, offset, SEEK_SET);
  
	GetDeviceServer(argv, device, 256);
	pllad = llad_open(device);
	if (pllad == NULL) {
		fprintf(stderr, "%s: Unable to access device\n", argv[0]);
		exit(1);
	}

	pgbus = gbus_open(pllad);

	if (size > 0) {
		data = (unsigned char*) malloc(size * sizeof(unsigned char));
		if (data == NULL) {
			perror(argv[0]);
			exit(1);
		}
		size = fread(data, sizeof(char), size, f);
		gbus_write_data8(pgbus, byte_address, data, size);
	}	
	else {
		unsigned long int xfer_size;

		data = (unsigned char*)malloc(BLOCK_SIZE * sizeof(unsigned char));
		if (data == NULL) {
			perror(argv[0]);
			exit(1);
		}

		while ((xfer_size = fread(data, sizeof(char), BLOCK_SIZE, f)) > 0) {
			gbus_write_data8(pgbus, byte_address, data, xfer_size);
			byte_address += xfer_size;
			size += xfer_size;
		}
	}
	printf("wrote %lu bytes\n", size);

	gbus_close(pgbus);
	llad_close(pllad);

	fclose(f);
	free(data);

	return 0;
}




