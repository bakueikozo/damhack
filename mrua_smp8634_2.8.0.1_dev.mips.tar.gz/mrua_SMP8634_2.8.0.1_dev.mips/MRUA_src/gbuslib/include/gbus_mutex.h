/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   gbus_mutex.h
  @brief  

  describes the hardware mutex api

  @author Julien Soulier
  @date   2003-04-15
*/

#ifndef __GBUS_MUTEX_H__
#define __GBUS_MUTEX_H__

#include "../../emhwlib_hal/include/emhwlib_registers.h"
#include "../../emhwlib/include/emhwlib_resources.h"
#include "../../irq_handler/include/undef_callid.h"

RM_EXTERN_C_BLOCKSTART

struct gbus_mutex;

#if (RMPLATFORM<RMPLATFORMID_TANGO2)

/*
 * Save the value of CPSR register, and mask out fast interrupt flag
 * in CPSR. Note: IRQ is already disabled.
 */
#define gbus_save_flags_clf(x)          \
        {                               \
                RMuint32 tmp;           \
                __asm__(                \
                "mrs    %0, cpsr\n"     \
                "orr    %1, %0, #64\n"  \
                "msr    cpsr_c, %1\n"   \
                : "=r" (x), "=r" (tmp)  \
                :                       \
                : "memory");            \
        }

/* 
 * Restore the saved value back to CPSR register.
 */
#define gbus_restore_flags(x)           \
        __asm__(                        \
        "msr    cpsr_c, %0\n"           \
        :                               \
        : "r" (x))

static inline struct gbus_mutex *gbus_mutex_open(struct gbus *pgbus, RMuint32 gbus_addr)
{
	return (struct gbus_mutex *)gbus_addr;
}

static inline void gbus_mutex_close(struct gbus *pgbus, struct gbus_mutex *mutex)
{
}

/*
 * Inside the pT110 core if a sequence of LDR instructions is
 * interrupted the interrupted LDR will be duplicated. This behaviour
 * is not compatible with "action on read" register such as
 * mutex. Therefore we ensure when running on pT110 that the read
 * sequence will not be interrupted.
 *
 * Note we do:
 *   while {
 *       save_flags_clf
 *       read
 *       restore_flags
 *   }
 *
 * and not:
 *   save_flags_clf
 *   while read
 *   restore_flags
 *
 * on purpose.
 *
 * The reason is that we want to re-enable the FIQ for VSYNC handling (to not
 * cause a glitch in the video being displayed) on every loop.
 * 
*/
static inline void gbus_mutex_lock(struct gbus *pgbus, struct gbus_mutex *mutex)
{
#ifndef INIRQHANDLER
#if ((EM86XX_MODE==EM86XX_MODEID_WITHHOST) || (RMPLATFORM!=RMPLATFORMID_JASPERMAMBO))
	while (gbus_read_uint32(pgbus, (RMuint32) mutex));
#elif (EM86XX_MODE==EM86XX_MODEID_STANDALONE)
	do_undef_call_2(GBUS_MUTEX_LOCK, (RMuint32) mutex);	
#else
	NOTCOMPILABLE;
#endif // EM86XX_MODE = ...
#else  // INIRQHANDLER

#if (RMPLATFORM==RMPLATFORMID_JASPERMAMBO)
	{
		RMuint32 flags;

		while (1) {			
			gbus_save_flags_clf(flags);
			if (gbus_read_uint32(pgbus, (RMuint32) mutex) == 0) {
				gbus_restore_flags(flags);
				break;
			}
		       	gbus_restore_flags(flags);
		}
	}
#else
#error no such platform       
#endif

#endif // INIRQHANDLER      

}

/*
 * There is no problem with the write operation.
 */
static inline void gbus_mutex_unlock(struct gbus *pgbus, struct gbus_mutex *mutex)
{
	gbus_write_uint32(pgbus, (RMuint32)mutex, 0);
}

/**
   Returns the owner of the mutex, 0 if the mutex is free.
   A free mutex cannot be read without getting owned by the reader.
   
   Owners are found in SystemBlock.xml, GBUS_MUTEX_PT110 and next ones
   
   We need to disable interrupts like in gbus_mutex_lock

   @param pgbus 
   @param mutex 
   @return 
*/
static inline RMuint32 gbus_mutex_trylock(struct gbus *pgbus, struct gbus_mutex *mutex)
{
	RMuint32 owner;
	
#ifndef INIRQHANDLER
	
#if (EM86XX_MODE==EM86XX_MODEID_WITHHOST)
	owner = gbus_read_uint32(pgbus, (RMuint32) mutex);
#elif (EM86XX_MODE==EM86XX_MODEID_STANDALONE)
	owner = do_undef_call_2(GBUS_MUTEX_TRYLOCK, (RMuint32) mutex);	
#else
	NOTCOMPILABLE;
#endif // EM86XX_MODE = ...
	
#else  // INIRQHANDLER
	
#if (RMPLATFORM==RMPLATFORMID_JASPERMAMBO)
	{
		RMuint32 flags;
		
		gbus_save_flags_clf(flags);
		owner = gbus_read_uint32(pgbus, (RMuint32) mutex);
		gbus_restore_flags(flags);
	}
#else
#error no such platform       
#endif
	
#endif // INIRQHANDLER      
	
	return owner;
} 

#else

// >=tango2: much simpler

#ifdef INIRQHANDLER
#error INIRQHANDLER toggle does not make sense on tango2
#endif

static inline struct gbus_mutex *gbus_mutex_open(struct gbus *pgbus, RMuint32 gbus_addr)
{
	return (struct gbus_mutex *)gbus_addr;
}

static inline void gbus_mutex_close(struct gbus *pgbus, struct gbus_mutex *mutex)
{
}

static inline void gbus_mutex_lock(struct gbus *pgbus, struct gbus_mutex *mutex)
{
	while (gbus_read_uint32(pgbus, (RMuint32) mutex));
}

static inline void gbus_mutex_unlock(struct gbus *pgbus, struct gbus_mutex *mutex)
{
	gbus_write_uint32(pgbus, (RMuint32)mutex, 0);
}

static inline RMuint32 gbus_mutex_trylock(struct gbus *pgbus, struct gbus_mutex *mutex)
{
	return gbus_read_uint32(pgbus, (RMuint32) mutex);
} 

#endif

RM_EXTERN_C_BLOCKEND

#endif // __GBUS_MUTEX_H__
