/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   gbus_spinlock.h
  @brief  

  linux-style locking
  
  In WITHHOST mode, the host and arm may compete for the
  same resource and have to exclude each other by causing
  temporarily the other to busy loop.

  In STANDALONE mode, making an exclusive access is made
  easier by the fact you just have to disable interrupts
  
  @author Emmanuel Michon
  @date   2003-07-17
*/

#ifndef __GBUS_SPINLOCK_H__
#define __GBUS_SPINLOCK_H__

#include "gbus_mutex.h"
#include "../../emhwlib/include/emhwlib_interface.h"
#include "../../irq_handler/include/undef_callid.h"

RM_EXTERN_C_BLOCKSTART

#if (RMPLATFORM<RMPLATFORMID_TANGO2)

static inline RMuint32 gbus_spin_lock_mutex_irq(struct gbus *pGBus, struct gbus_mutex *mutex, RMuint32 irq)
{
	RMuint32 flags = 0;

#if (EM86XX_MODE==EM86XX_MODEID_WITHHOST)
	gbus_mutex_lock(pGBus,mutex);
#elif (EM86XX_MODE==EM86XX_MODEID_STANDALONE)
#ifndef INIRQHANDLER
	flags = do_undef_call_2(GBUS_SPIN_LOCK_IRQ, irq);	
#endif // INIRQHANDLER      
#else
	NOTCOMPILABLE;
#endif // EM86XX_MODE = ...

	return flags;
}

static inline void gbus_spin_unlock_mutex_irq(struct gbus *pGBus, struct gbus_mutex *mutex, RMuint32 flags)
{
#if (EM86XX_MODE==EM86XX_MODEID_WITHHOST)
	gbus_mutex_unlock(pGBus,mutex);
#elif (EM86XX_MODE==EM86XX_MODEID_STANDALONE)
#ifndef INIRQHANDLER
	do_undef_call_2(GBUS_SPIN_UNLOCK_IRQ, flags);	
#endif // INIRQHANDLER
#else
	NOTCOMPILABLE;
#endif // EM86XX_MODE = ...
}

#else

// >=tango2: much simpler

static inline RMuint32 gbus_spin_lock_mutex_irq(struct gbus *pGBus, struct gbus_mutex *mutex, RMuint32 irq)
{
	gbus_mutex_lock(pGBus,mutex);

	return 0;
}

static inline void gbus_spin_unlock_mutex_irq(struct gbus *pGBus, struct gbus_mutex *mutex, RMuint32 flags)
{
	gbus_mutex_unlock(pGBus,mutex);
}

#endif

RM_EXTERN_C_BLOCKEND

#endif // __GBUS_SPINLOCK_H__
