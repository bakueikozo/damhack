/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#include "../../llad/include/llad.h"
#include "../include/gbus_fifo_16.h"
#include "../include/gbus_mutex.h"

struct gbus_fifo_16 *gbus_fifo_16_open(struct gbus *pgbus, struct gbus_mutex *mutex, RMuint32 data_address, RMuint32 data_size, RMuint32 fifo_address)
{
	return gbus_fifo_16_open_rdwr(pgbus, mutex, data_address, data_size, fifo_address, 0, 0);
}

struct gbus_fifo_16 *gbus_fifo_16_open_rdwr(struct gbus *pgbus, struct gbus_mutex *mutex, RMuint32 data_address, RMuint32 data_size, RMuint32 fifo_address, RMuint32 rd_ptr, RMuint32 wr_ptr)
{
	struct gbus_fifo_16 *fifo = (struct gbus_fifo_16 *) fifo_address;
	
	gbus_mutex_lock(pgbus, mutex);
	gbus_write_uint32(pgbus, (RMuint32) &(fifo->base_lo), data_address & 0xffff);
	gbus_write_uint32(pgbus, (RMuint32) &(fifo->base_hi), data_address >> 16);
	gbus_write_uint32(pgbus, (RMuint32) &(fifo->size_lo), data_size & 0xffff);
	gbus_write_uint32(pgbus, (RMuint32) &(fifo->size_hi), data_size >> 16);
	gbus_write_uint32(pgbus, (RMuint32) &(fifo->rd_lo), rd_ptr & 0xffff);
	gbus_write_uint32(pgbus, (RMuint32) &(fifo->rd_hi), rd_ptr >> 16);
	gbus_write_uint32(pgbus, (RMuint32) &(fifo->wr_lo), wr_ptr & 0xffff);
	gbus_write_uint32(pgbus, (RMuint32) &(fifo->wr_hi), wr_ptr >> 16);
	gbus_mutex_unlock(pgbus, mutex);
	
	return fifo;
}

void gbus_fifo_16_close(struct gbus *pgbus, struct gbus_mutex *mutex, struct gbus_fifo_16 *fifo)
{
	RMASSERT(gbus_fifo_16_is_empty(pgbus,mutex,fifo));
}

void gbus_fifo_16_get_pointer(struct gbus *pgbus, struct gbus_mutex *mutex, struct gbus_fifo_16 *fifo, 
	RMuint32 *base, RMuint32 *size, RMuint32 *rd_ptr, RMuint32 *wr_ptr)
{
	gbus_mutex_lock(pgbus, mutex);
	*base  = gbus_read_uint32(pgbus, (RMuint32) &(fifo->base_lo));
	*base += gbus_read_uint32(pgbus, (RMuint32) &(fifo->base_hi)) << 16;
	*size  = gbus_read_uint32(pgbus, (RMuint32) &(fifo->size_lo));
	*size += gbus_read_uint32(pgbus, (RMuint32) &(fifo->size_hi)) << 16;
	*rd_ptr  = gbus_read_uint32(pgbus, (RMuint32) &(fifo->rd_lo));
	*rd_ptr += gbus_read_uint32(pgbus, (RMuint32) &(fifo->rd_hi)) << 16;
	*wr_ptr  = gbus_read_uint32(pgbus, (RMuint32) &(fifo->wr_lo));
	*wr_ptr += gbus_read_uint32(pgbus, (RMuint32) &(fifo->wr_hi)) << 16;
	gbus_mutex_unlock(pgbus, mutex);
}

RMbool gbus_fifo_16_is_empty(struct gbus *pgbus, struct gbus_mutex *mutex, struct gbus_fifo_16 *fifo)
{
	RMuint32 base, size, rd, wr;
	
	gbus_fifo_16_get_pointer(pgbus, mutex, fifo, &base, &size, &rd, &wr);
	
	return (rd == wr);
}

RMuint32 gbus_fifo_16_get_info(struct gbus *pgbus, struct gbus_mutex *mutex, struct gbus_fifo_16 *fifo, RMuint32 *data_start, RMuint32 *writable, RMuint32 *readable)
{
	RMuint32 start, size, rd, wr;

	gbus_fifo_16_get_pointer(pgbus, mutex, fifo, &start, &size, &rd, &wr);
	
	*data_start = start;

	*writable = rd - wr + size - 1;
	if ((*writable) >= size)
		(*writable) -= size;

	*readable = size - 1 - (*writable);

	return size;
}

RMuint32 gbus_fifo_16_get_writable_size(struct gbus *pgbus, struct gbus_mutex *mutex, struct gbus_fifo_16 *fifo, RMuint32 *wr_ptr1, RMuint32 *wr_size1, RMuint32 *wr_ptr2)
{
	RMuint32 base, size, rd, wr;
	
	gbus_fifo_16_get_pointer(pgbus, mutex, fifo, &base, &size, &rd, &wr);
	
	*wr_ptr1 = wr + base;
	
	if (wr >= rd) {
		if (rd > 0) {
			*wr_size1 = size - wr;
			*wr_ptr2 = base;
			return (*wr_size1 + rd - 1);
		}
		else {
			*wr_size1 = size - 1 - wr;
			*wr_ptr2 = 0;
			return (*wr_size1);
		}			
	}
	else {
		*wr_size1 = rd - 1 - wr;
		*wr_ptr2 = 0;
		return (*wr_size1);
	}
}

RMuint32 gbus_fifo_16_get_readable_size(struct gbus *pgbus, struct gbus_mutex *mutex, struct gbus_fifo_16 *fifo, RMuint32 *rd_ptr1, RMuint32 *rd_size1, RMuint32 *rd_ptr2)
{
	RMuint32 base, size, rd, wr;
	
	gbus_fifo_16_get_pointer(pgbus, mutex, fifo, &base, &size, &rd, &wr);
	
	*rd_ptr1 = rd + base;
	
	if (wr >= rd) {
		*rd_size1 = wr - rd;
		*rd_ptr2 = 0;
		return (*rd_size1);
	}
	else {
		*rd_size1 = size - rd;
		*rd_ptr2 = base;
		return (*rd_size1 +  wr);
	}
}

RMuint32 gbus_fifo_16_incr_write_ptr(struct gbus *pgbus, struct gbus_mutex *mutex, struct gbus_fifo_16 *fifo, RMuint32 incr)
{ 
	RMuint32 base, size, rd, wr;
	
	gbus_fifo_16_get_pointer(pgbus, mutex, fifo, &base, &size, &rd, &wr);
	
	wr += incr;
	if (wr >= size)
		wr -= size;
	
	gbus_mutex_lock(pgbus, mutex);
	gbus_write_uint32(pgbus, (RMuint32) &(fifo->wr_lo), wr & 0xffff);
	gbus_write_uint32(pgbus, (RMuint32) &(fifo->wr_hi), wr >> 16);
 	gbus_mutex_unlock(pgbus, mutex);
		
	return wr + base;
}

RMuint32 gbus_fifo_16_incr_read_ptr(struct gbus *pgbus, struct gbus_mutex *mutex, struct gbus_fifo_16 *fifo, RMuint32 incr)
{
	RMuint32 base, size, rd, wr;
	
	gbus_fifo_16_get_pointer(pgbus, mutex, fifo, &base, &size, &rd, &wr);
	
	rd += incr;
	if (rd >= size)
		rd -= size;
	
	gbus_mutex_lock(pgbus, mutex);
	gbus_write_uint32(pgbus, (RMuint32) &(fifo->rd_lo), rd & 0xffff);
	gbus_write_uint32(pgbus, (RMuint32) &(fifo->rd_hi), rd >> 16);
 	gbus_mutex_unlock(pgbus, mutex);
		
	return rd + base;
}

void gbus_fifo_16_flush_ptr(struct gbus *pgbus, struct gbus_mutex *mutex, struct gbus_fifo_16 *fifo)
{
	gbus_mutex_lock(pgbus, mutex);
	gbus_write_uint32(pgbus, (RMuint32) &(fifo->rd_lo), 0);
	gbus_write_uint32(pgbus, (RMuint32) &(fifo->rd_hi), 0);
	gbus_write_uint32(pgbus, (RMuint32) &(fifo->wr_lo), 0);
	gbus_write_uint32(pgbus, (RMuint32) &(fifo->wr_hi), 0);
 	gbus_mutex_unlock(pgbus, mutex);
}

