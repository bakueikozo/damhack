/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#include "../../llad/include/llad.h"
#include "../include/gbus_multiple_readers_fifo_eraser.h"

struct gbus_multiple_readers_fifo_eraser *gbus_multiple_readers_fifo_eraser_open(
	struct gbus *h, RMuint32 data_address, RMuint32 data_size, RMuint32 fifo_address)
{
	struct gbus_multiple_readers_fifo_eraser *fifo = (struct gbus_multiple_readers_fifo_eraser *) fifo_address;
	RMuint32 i;
	
	gbus_write_uint32(h, (RMuint32) &(fifo->base), data_address);
	gbus_write_uint32(h, (RMuint32) &(fifo->size), data_size);
	gbus_write_uint32(h, (RMuint32) &(fifo->wr), 0);
	gbus_write_uint32(h, (RMuint32) &(fifo->er), 0);
	for (i=0 ; i<MAX_GBUS_FIFO_READER_COUNT ; i++) {
		gbus_write_uint32(h, (RMuint32) &(fifo->rd[i]), data_size);
		gbus_write_uint32(h, (RMuint32) &(fifo->re[i]), data_size);
	}
	return fifo;

}

void gbus_multiple_readers_fifo_eraser_close(
	struct gbus *h, struct gbus_multiple_readers_fifo_eraser *fifo)
{
	// warn about pending erasable entries 
/* 	RMASSERT(gbus_multiple_readers_fifo_eraser_is_empty(h,fifo)); */
}

RMbool gbus_multiple_readers_fifo_eraser_is_empty(
	struct gbus *h, struct gbus_multiple_readers_fifo_eraser *fifo)
{
	RMuint32 er, wr;
	
	/* check if everything has been erased */
	er   = gbus_read_uint32(h, (RMuint32) &(fifo->er));
	wr   = gbus_read_uint32(h, (RMuint32) &(fifo->wr));
	
	return (er==wr);
}

RMuint32 gbus_multiple_readers_fifo_eraser_get_latest_releaser(
	struct gbus *h, struct gbus_multiple_readers_fifo_eraser *fifo, RMuint32 *releasable)
{
	RMuint32 wr, re, size, i, max_i;
	
	size = gbus_read_uint32(h, (RMuint32) &(fifo->size));
	wr   = gbus_read_uint32(h, (RMuint32) &(fifo->wr));
	*releasable = 0;
	max_i=(RMuint32) -1;
	for (i=0 ; i<MAX_GBUS_FIFO_READER_COUNT ; i++) {
		RMuint32 tmp;

		re = gbus_read_uint32(h, (RMuint32) &(fifo->re[i]));
		if (re == size)
			continue;
		
		tmp = wr - re + size;
		if (tmp >= size)
			tmp -= size;

		if (tmp >= *releasable) {
			*releasable = tmp;
			max_i = i;
		}
	}

	if (max_i == (RMuint32) -1)
		*releasable = size;
	
	return max_i;
}

RMuint32 gbus_multiple_readers_fifo_eraser_connect_reader(struct gbus *h, 
							  struct gbus_multiple_readers_fifo_eraser *fifo, 
							  RMuint32 reader_idx)
{
	RMuint32 i, size, wr, last_re_idx, releasable, re;

	/* WARNING: Caller must ensure two connects cannot happen concurrently */


	size = gbus_read_uint32(h, (RMuint32) &(fifo->size));
	wr = gbus_read_uint32(h, (RMuint32) &(fifo->wr));

	/* set the new re and rd pointers for this reader to the latest releaser.
	   if there are no other readers, set it to the wr pointer
	   the rationale for this is to allow new readers to start consuming asap.
	*/
	last_re_idx = gbus_multiple_readers_fifo_eraser_get_latest_releaser(h, fifo, &releasable);
	if (releasable == size){
		re = wr;
	}
	else{
		re = gbus_read_uint32(h, (RMuint32) &(fifo->re[last_re_idx]));
	}


	/* -1 if 0xffffffff which is > MAX_GBUS_FIFO_READER_COUNT */
	if ((reader_idx < MAX_GBUS_FIFO_READER_COUNT) && (gbus_read_uint32(h, (RMuint32) &(fifo->rd[reader_idx])) == size)) {
		i = reader_idx;
		gbus_write_uint32(h, (RMuint32) &(fifo->rd[i]), re);
		gbus_write_uint32(h, (RMuint32) &(fifo->re[i]), re);
	}
	else {
		for (i=0 ; i<MAX_GBUS_FIFO_READER_COUNT ; i++) {
			
			if (gbus_read_uint32(h, (RMuint32) &(fifo->rd[i])) == size) {
				gbus_write_uint32(h, (RMuint32) &(fifo->rd[i]), re);
				gbus_write_uint32(h, (RMuint32) &(fifo->re[i]), re);
				break;
			}
		}
		
		i = (i == MAX_GBUS_FIFO_READER_COUNT) ? (RMuint32) -1 : i;
	}

	return i;
}

void gbus_multiple_readers_fifo_eraser_disconnect_reader(
	struct gbus *h, struct gbus_multiple_readers_fifo_eraser *fifo, RMuint32 reader_idx)
{
	RMuint32 size;
	
	size = gbus_read_uint32(h, (RMuint32) &(fifo->size));
	gbus_write_uint32(h, (RMuint32) &(fifo->rd[reader_idx]), size);
	gbus_write_uint32(h, (RMuint32) &(fifo->re[reader_idx]), size);
}

RMuint32 gbus_multiple_readers_fifo_eraser_get_info(
	struct gbus *h, struct gbus_multiple_readers_fifo_eraser *fifo, RMuint32 reader_idx, 
	RMuint32 *start_address, RMuint32 *writable, RMuint32 *readable, RMuint32 *releasable, RMuint32 *erasable)
{
	RMuint32 start, size, rd, wr, er, re, max_releasable;

	start = gbus_read_uint32(h, (RMuint32) &(fifo->base));
	size  = gbus_read_uint32(h, (RMuint32) &(fifo->size));
	er   = gbus_read_uint32(h, (RMuint32) &(fifo->er));
	wr   = gbus_read_uint32(h, (RMuint32) &(fifo->wr));
	rd   = gbus_read_uint32(h, (RMuint32) &(fifo->rd[reader_idx]));
	re   = gbus_read_uint32(h, (RMuint32) &(fifo->re[reader_idx]));

	*start_address = start;

	*writable = er - wr + size - 1;
	if ((*writable) >= size)
		(*writable) -= size;

	*readable = wr - rd + size;
	if ((*readable) >= size)
		(*readable) -= size;

	*releasable = rd - re + size;
	if ((*releasable) >= size)
		(*releasable) -= size;
	
	gbus_multiple_readers_fifo_eraser_get_latest_releaser(h, fifo, &max_releasable);
	(*erasable) = size - 1 - max_releasable - (*writable);

	return size;
}

RMuint32 gbus_multiple_readers_fifo_eraser_get_writable_size(
	struct gbus *h, struct gbus_multiple_readers_fifo_eraser *fifo, 
	RMuint32 *wr_ptr1, RMuint32 *wr_size1, RMuint32 *wr_ptr2)
{
	RMuint32 wr, er, base, size;

	base = gbus_read_uint32(h, (RMuint32) &(fifo->base));
	size = gbus_read_uint32(h, (RMuint32) &(fifo->size));
	er   = gbus_read_uint32(h, (RMuint32) &(fifo->er));
	wr   = gbus_read_uint32(h, (RMuint32) &(fifo->wr));
	
	*wr_ptr1 = base + wr;

	if (wr >= er) {
		if (er > 0) {
			*wr_size1 = size - wr;
			*wr_ptr2 = base;
			return (*wr_size1 + er - 1);
		}
		else {
			*wr_size1 = size - 1 - wr;
			*wr_ptr2 = 0;
			return (*wr_size1);
		}			
	}
	else {
		*wr_size1 = er - 1 - wr;
		*wr_ptr2 = 0;
		return (*wr_size1);
	}
}

RMuint32 gbus_multiple_readers_fifo_eraser_get_readable_size(
	struct gbus *h, struct gbus_multiple_readers_fifo_eraser *fifo, RMuint32 reader_idx, 
	RMuint32 *rd_ptr1, RMuint32 *rd_size1, RMuint32 *rd_ptr2)
{
	RMuint32 wr, rd, base, size;

	base = gbus_read_uint32(h, (RMuint32) &(fifo->base));
	size = gbus_read_uint32(h, (RMuint32) &(fifo->size));
	rd   = gbus_read_uint32(h, (RMuint32) &(fifo->rd[reader_idx]));
	wr   = gbus_read_uint32(h, (RMuint32) &(fifo->wr));

	*rd_ptr1 = base + rd;

	if (wr >= rd) {
		*rd_size1 = wr - rd;
		*rd_ptr2 = 0;
		return (*rd_size1);
	}
	else {
		*rd_size1 = size - rd;
		*rd_ptr2 = base;
		return (*rd_size1 +  wr);
	}
}

RMuint32 gbus_multiple_readers_fifo_eraser_get_releasable_size(
	struct gbus *h, struct gbus_multiple_readers_fifo_eraser *fifo, RMuint32 reader_idx, 
	RMuint32 *re_ptr1, RMuint32 *re_size1, RMuint32 *re_ptr2)
{
	RMuint32 re, rd, base, size;

	base = gbus_read_uint32(h, (RMuint32) &(fifo->base));
	size = gbus_read_uint32(h, (RMuint32) &(fifo->size));
	rd   = gbus_read_uint32(h, (RMuint32) &(fifo->rd[reader_idx]));
	re   = gbus_read_uint32(h, (RMuint32) &(fifo->re[reader_idx]));

	*re_ptr1 = base + re;

	if (rd >= re) {
		*re_size1 = rd - re;
		*re_ptr2 = 0;
		return (*re_size1);
	}
	else {
		*re_size1 = size - re;
		*re_ptr2 = base;
		return (*re_size1 + rd);
	}
}

RMuint32 gbus_multiple_readers_fifo_eraser_get_erasable_size(
	struct gbus *h, struct gbus_multiple_readers_fifo_eraser *fifo, 
	RMuint32 *er_ptr1, RMuint32 *er_size1, RMuint32 *er_ptr2)
{
	RMuint32 er, re, base, size, releasable, re_idx;

	base = gbus_read_uint32(h, (RMuint32) &(fifo->base));
	size = gbus_read_uint32(h, (RMuint32) &(fifo->size));
	er   = gbus_read_uint32(h, (RMuint32) &(fifo->er));
	re_idx = gbus_multiple_readers_fifo_eraser_get_latest_releaser(h, fifo, &releasable);
	if (releasable == size)
		return 0;
	re = gbus_read_uint32(h, (RMuint32) &(fifo->re[re_idx]));

	*er_ptr1 = base + er;
	
	if (re >= er) {
		*er_size1 = re - er;
		*er_ptr2 = 0;
		return (*er_size1);
	}
	else {
		*er_size1 = size - er;
		*er_ptr2 = base;
		return (*er_size1 +  re);
	}
}

RMuint32 gbus_multiple_readers_fifo_eraser_incr_write_ptr(
	struct gbus *h, struct gbus_multiple_readers_fifo_eraser *fifo, RMuint32 incr)
{
	RMuint32 wr, base, size;

	base = gbus_read_uint32(h, (RMuint32) &(fifo->base));
	size = gbus_read_uint32(h, (RMuint32) &(fifo->size));
	wr   = gbus_read_uint32(h, (RMuint32) &(fifo->wr));

	wr += incr;
	if (wr >= size)
		wr = (wr - size);

	gbus_write_uint32(h, (RMuint32) &(fifo->wr), wr);
		
	return base + wr;
}

RMuint32 gbus_multiple_readers_fifo_eraser_incr_read_ptr(
	struct gbus *h, struct gbus_multiple_readers_fifo_eraser *fifo, RMuint32 reader_idx, RMuint32 incr)
{
	RMuint32 rd, base, size;

	base = gbus_read_uint32(h, (RMuint32) &(fifo->base));
	size = gbus_read_uint32(h, (RMuint32) &(fifo->size));
	rd   = gbus_read_uint32(h, (RMuint32) &(fifo->rd[reader_idx]));

	rd += incr;
	if (rd >= size)
		rd = (rd - size);
		
	gbus_write_uint32(h, (RMuint32) &(fifo->rd[reader_idx]), rd);

	return base + rd;
}

RMuint32 gbus_multiple_readers_fifo_eraser_incr_release_ptr(
	struct gbus *h, struct gbus_multiple_readers_fifo_eraser *fifo, RMuint32 reader_idx, RMuint32 incr)
{
	RMuint32 re, base, size;

	base = gbus_read_uint32(h, (RMuint32) &(fifo->base));
	size = gbus_read_uint32(h, (RMuint32) &(fifo->size));
	re   = gbus_read_uint32(h, (RMuint32) &(fifo->re[reader_idx]));

	re += incr;
	if (re >= size)
		re = (re - size);
		
	gbus_write_uint32(h, (RMuint32) &(fifo->re[reader_idx]), re);

	return base + re;
}

RMuint32 gbus_multiple_readers_fifo_eraser_incr_erase_ptr(
	struct gbus *h, struct gbus_multiple_readers_fifo_eraser *fifo, RMuint32 incr)
{
	RMuint32 er, base, size;

	base = gbus_read_uint32(h, (RMuint32) &(fifo->base));
	size = gbus_read_uint32(h, (RMuint32) &(fifo->size));
	er   = gbus_read_uint32(h, (RMuint32) &(fifo->er));

	er += incr;
	if (er >= size)
		er = (er - size);
		
	gbus_write_uint32(h, (RMuint32) &(fifo->er), er);

	return base + er;
}
