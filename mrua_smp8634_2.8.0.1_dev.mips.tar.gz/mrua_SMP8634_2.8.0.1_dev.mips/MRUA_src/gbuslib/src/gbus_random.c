/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#include "../include/gbus_random.h"
#include "../include/gbus_time.h"

#include "../../emhwlib_hal/include/emhwlib_registers.h"

// to enable or disable the debug messages of this source file, put 1 or 0 below
#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

#if (EM86XX_CHIP>=EM86XX_CHIPID_TANGO2)
// system block counters have changed a lot. Anyways, should xrpc to get random.
RMuint32 gbus_random_init(struct gbus *pgbus, RMuint32 pll)
{
	return 0;
}
#else
RMuint32 gbus_random_init(struct gbus *pgbus, RMuint32 pll)
{
	RMuint32 oldpll,olddiv,oldmux;
	RMuint32 i,t,x;
	RMuint32 duration = 1;

	// save how it was before
	oldmux=gbus_read_uint32(pgbus,REG_BASE_system_block+SYS_avclk_mux);
	oldpll=gbus_read_uint32(pgbus,REG_BASE_system_block+SYS_clkgen0_pll+8*pll);
	olddiv=gbus_read_uint32(pgbus,REG_BASE_system_block+SYS_clkgen0_div+8*pll);
	
	// connect chosen pll to `sel' output
	gbus_write_uint32(pgbus,REG_BASE_system_block+SYS_avclk_mux,(8+2*pll)<<28);
	
	// quartz*7*11/2/3
#define F1_N  (7*11-2)
#define F1_M  (2-2) 
#define F1_D1 3
#define F1_MHZ (27.0*(F1_N+2)/(F1_M+2)/F1_D1)

	// quartz*13*19/11/7
#define F2_N  (13*19-2)
#define F2_M  (11-2)
#define F2_D1 7
#define F2_MHZ (27.0*(F2_N+2)/(F2_M+2)/F2_D1)

#define MAXDURATION 1024	/* 1024 * 20000 = 20.5 sec */
#define RUNLENGTH_US 20000
#define MINVAL (1<<20) 		/* must be much larger than (1<<11) (eleven bits) */

	do {
		/* now, toggle PLL between F1 and F2 during RUNLENGTH_US*duration */
		t=gbus_time_us(pgbus);
		gbus_write_uint32(pgbus,REG_BASE_system_block+SYS_sel_clk_cnt,0);

		RMDBGLOG((LOCALDBG,"Duration = %lu us.\n", duration*RUNLENGTH_US));
		i=0;
		while (1) {
			/* set F1, about 346MHz */
			gbus_write_uint32(pgbus,REG_BASE_system_block+SYS_clkgen0_pll+8*pll,(1<<24)+(F1_M<<16)+F1_N);
			gbus_write_uint32(pgbus,REG_BASE_system_block+SYS_clkgen0_div+8*pll,(2<<8)+F1_D1);

			if (gbus_time_delta(t,gbus_time_us(pgbus))>(RUNLENGTH_US*duration)) break;

			/* set F2, about 87MHz */
			gbus_write_uint32(pgbus,REG_BASE_system_block+SYS_clkgen0_pll+8*pll,(1<<24)+(F2_M<<16)+F2_N);
			gbus_write_uint32(pgbus,REG_BASE_system_block+SYS_clkgen0_div+8*pll,(2<<8)+F2_D1);

			if (gbus_time_delta(t,gbus_time_us(pgbus))>(RUNLENGTH_US*duration)) break;

			i++;
		}
		x=gbus_read_uint32(pgbus,REG_BASE_system_block+SYS_sel_clk_cnt);

		/* Adjust the duration of the toggling if we don't have enough random bits */
		duration = duration << 1;
	} while ((x<MINVAL) && ( duration <= MAXDURATION ));
	RMDBGLOG((LOCALDBG,"toggles %d. x=%ld\n", i, x));

	if (x<MINVAL)
		/* Should not happen */
		RMDBGLOG((ENABLE,"Warning, not enough random bits.\n"));

	// keep lower eleven bits
	x=x&((1<<11)-1);

	RMDBGLOG((LOCALDBG,"gbus_random_init: returning 0x%08lx\n",x));

	// restore how it was before
	gbus_write_uint32(pgbus,REG_BASE_system_block+SYS_avclk_mux,oldmux);
	gbus_write_uint32(pgbus,REG_BASE_system_block+SYS_clkgen0_pll+8*pll,oldpll);
	gbus_write_uint32(pgbus,REG_BASE_system_block+SYS_clkgen0_div+8*pll,olddiv);

	return x;
}
#endif

RMuint32 gbus_random_value(struct gbus *pgbus, RMuint32 seed_address)
{
	RMuint32 x=gbus_read_uint32(pgbus,seed_address);
	
	// really bad recurrence
	x=40483*x-31531;

	gbus_write_uint32(pgbus,seed_address,x);
	
	return x;
}
