/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#include "../include/gbus_list.h"

struct gbus_list *gbus_list_open(struct gbus *pgbus, RMuint32 gbus_addr)
{
	struct gbus_list *list = (struct gbus_list *) gbus_addr;

	gbus_write_uint32(pgbus, (RMuint32) &(list->next), gbus_addr);
	gbus_write_uint32(pgbus, (RMuint32) &(list->prev), gbus_addr);

	return list;
}

void gbus_list_close(struct gbus *pgbus, struct gbus_list *list)
{
}

void gbus_list_add_entry(struct gbus *pgbus, struct gbus_list *head, struct gbus_list *new)
{
	struct gbus_list *next;

	next = (struct gbus_list *) gbus_read_uint32(pgbus, (RMuint32) &(head->next));
	gbus_write_uint32(pgbus, (RMuint32) &(head->next), (RMuint32) new);
	gbus_write_uint32(pgbus, (RMuint32) &(new->next), (RMuint32) next);
	gbus_write_uint32(pgbus, (RMuint32) &(new->prev), (RMuint32) head);
	gbus_write_uint32(pgbus, (RMuint32) &(next->prev), (RMuint32) new);
}

void gbus_list_del_entry(struct gbus *pgbus, struct gbus_list *entry)
{
	struct gbus_list *next, *prev;
	
	next = (struct gbus_list *) gbus_read_uint32(pgbus, (RMuint32) &(entry->next));
	prev = (struct gbus_list *) gbus_read_uint32(pgbus, (RMuint32) &(entry->prev));
	
	gbus_write_uint32(pgbus, (RMuint32) &(prev->next), (RMuint32) next);
	gbus_write_uint32(pgbus, (RMuint32) &(next->prev), (RMuint32) prev);
}

struct gbus_list *gbus_list_next_entry(struct gbus *pgbus, struct gbus_list *entry)
{
	return (struct gbus_list *) gbus_read_uint32(pgbus, (RMuint32) &(entry->next));
}

struct gbus_list *gbus_list_prev_entry(struct gbus *pgbus, struct gbus_list *entry)
{
	return (struct gbus_list *) gbus_read_uint32(pgbus, (RMuint32) &(entry->prev));
}
