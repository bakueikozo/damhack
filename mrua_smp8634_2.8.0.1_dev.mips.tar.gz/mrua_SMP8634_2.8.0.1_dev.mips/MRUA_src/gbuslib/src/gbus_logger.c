/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#include "../../llad/include/llad.h"
#include "../include/gbus_fifo.h"
#include "../include/gbus_logger.h"
#include "../include/gbus_time.h"

// to enable or disable the debug messages of this source file, put 1 or 0 below
#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

static void gbus_logger_fifo(struct gbus *pgbus,struct gbus_fifo *gbus_logger_fifo,enum gbus_logger_tag tag,RMint32 val)
{
	RMuint32 wr_ptr1;
	RMuint32 wr_size1;
	RMuint32 wr_ptr2;
	RMuint32 wr_size;
	
	struct gbus_logger_entry e;
	RMuint8 *src=(RMuint8 *)(&e);
	
	RMuint32 lostcount=gbus_read_uint32(pgbus,GBUS_LOGGER_LOSTCOUNT);
	if (lostcount==INVALID) return;
	
	e.tag=tag;
	e.time_us=gbus_time_us(pgbus);
	e.val=val;
	
	wr_size=gbus_fifo_get_writable_size(pgbus,gbus_logger_fifo,&wr_ptr1,&wr_size1,&wr_ptr2);
	
	if (wr_size<sizeof(struct gbus_logger_entry)) {
		lostcount++;
		gbus_write_uint32(pgbus,GBUS_LOGGER_LOSTCOUNT,lostcount);
	}
	else {
		RMuint32 left=sizeof(struct gbus_logger_entry),xfersize;
		
		xfersize=RMmin(left,wr_size1);
		gbus_write_data32(pgbus,wr_ptr1,(RMuint32 *)src,xfersize>>2);
		left-=xfersize;
		if (left>0) gbus_write_data32(pgbus,wr_ptr2,(RMuint32 *)(src+xfersize),left>>2);
		gbus_fifo_incr_write_ptr(pgbus,gbus_logger_fifo,sizeof(struct gbus_logger_entry));
	}
}

void gbus_logger(struct gbus *pgbus,enum gbus_logger_tag tag,RMint32 val)
{
#if (RMPLATFORM==RMPLATFORMID_JASPERMAMBO)
	gbus_logger_fifo(pgbus,(struct gbus_fifo *)GBUS_LOGGER_ARMFIFO,tag,val);
#else
	gbus_logger_fifo(pgbus,(struct gbus_fifo *)GBUS_LOGGER_HOSTFIFO,tag,val);
#endif
}

void gbus_logger_start(struct gbus *pgbus)
{
	gbus_write_uint32(pgbus,GBUS_LOGGER_LOSTCOUNT,0);

	gbus_fifo_open(pgbus,
		       GBUS_LOGGER_MPEGFIFODATA,
		       GBUS_LOGGER_FIFOSIZE,
		       GBUS_LOGGER_MPEGFIFO);

	gbus_fifo_open(pgbus,
		       GBUS_LOGGER_ARMFIFODATA,
		       GBUS_LOGGER_FIFOSIZE,
		       GBUS_LOGGER_ARMFIFO);

	gbus_fifo_open(pgbus,
		       GBUS_LOGGER_HOSTFIFODATA,
		       GBUS_LOGGER_FIFOSIZE,
		       GBUS_LOGGER_HOSTFIFO);
	gbus_logger_fifo(pgbus,(struct gbus_fifo *)GBUS_LOGGER_HOSTFIFO,GBUS_LOGGER_START,0);
	
	RMDBGLOG((ENABLE,"gbus_logger_start: done (0x%08lx(start) 0x%08lx 0x%08lx 0x%08lx 0x%08lx(end) --- %d<tags<%d)\n",
		  GBUS_LOGGER_LOSTCOUNT,
		  GBUS_LOGGER_MPEGFIFO,
		  GBUS_LOGGER_ARMFIFO,
		  GBUS_LOGGER_HOSTFIFO,
		  GBUS_LOGGER_END,
		  GBUS_LOGGER_FIRST,
		  GBUS_LOGGER_LAST));
}

void gbus_logger_stop(struct gbus *pgbus)
{
	gbus_logger_fifo(pgbus,(struct gbus_fifo *)GBUS_LOGGER_HOSTFIFO,GBUS_LOGGER_STOP,0);

	RMDBGLOG((LOCALDBG,"gbus_logger_stop: done\n"));
}

RMbool gbus_logger_fetch_isready(struct gbus *pgbus)
{
	return gbus_read_uint32(pgbus,GBUS_LOGGER_LOSTCOUNT)!=INVALID;
}

static RMuint32 gbus_logger_fetch_fifo(struct gbus *pgbus,struct gbus_fifo *gbus_logger_fifo,struct gbus_logger_entry *thedst,RMuint32 count)
{
	RMuint32 rd_ptr1;
	RMuint32 rd_size1;
	RMuint32 rd_ptr2;
	RMuint32 rd_size;
	RMuint8 *dst=(RMuint8 *)thedst;
	
	rd_size=gbus_fifo_get_readable_size(pgbus,gbus_logger_fifo,&rd_ptr1,&rd_size1,&rd_ptr2);
	rd_size=RMmin(rd_size,count*sizeof(struct gbus_logger_entry));
	
	if (rd_size>0) {
		RMuint32 left=rd_size,xfersize;
		
		xfersize=RMmin(left,rd_size1);
		gbus_read_data32(pgbus,rd_ptr1,(RMuint32 *)dst,xfersize>>2);
		left-=xfersize;
		if (left>0) gbus_read_data32(pgbus,rd_ptr2,(RMuint32 *)(dst+xfersize),left>>2);
		gbus_fifo_incr_read_ptr(pgbus,gbus_logger_fifo,rd_size);
	}

	return rd_size/sizeof(struct gbus_logger_entry);
}

RMuint32 gbus_logger_fetch(struct gbus *pgbus,struct gbus_logger_entry *thedst,RMuint32 count)
{
	RMuint32 answer;
	RMuint32 i;
	
	answer=gbus_logger_fetch_fifo(pgbus,(struct gbus_fifo *)GBUS_LOGGER_MPEGFIFO,thedst,count);
	// hack: the cost of /27 (27MHz) division is too much for MPEG engine; let's make it afterwards
	for (i=0;i<answer;i++) thedst[i].time_us/=27;
	RMDBGLOG((LOCALDBG,"gbus_logger_fetch: %ld entries with MPEG\n",answer));

	answer+=gbus_logger_fetch_fifo(pgbus,(struct gbus_fifo *)GBUS_LOGGER_ARMFIFO,thedst+answer,count-answer);
	RMDBGLOG((LOCALDBG,"gbus_logger_fetch: now %ld entries with ARM\n",answer));

	answer+=gbus_logger_fetch_fifo(pgbus,(struct gbus_fifo *)GBUS_LOGGER_HOSTFIFO,thedst+answer,count-answer);
	RMDBGLOG((LOCALDBG,"gbus_logger_fetch: now %ld entries with HOST\n",answer));

	return answer;
}

void gbus_logger_invalidate(struct gbus *pgbus)
{
	gbus_write_uint32(pgbus,GBUS_LOGGER_LOSTCOUNT,INVALID);
}
