/*****************************************
 Copyright � 2004
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   rmrtspapi.h

  based on code from Laurent Crinon and Glen Adams

  @author Sebastian Frias Feltrer
  @date   2005-09-09
*/

#ifndef __RMRTSP_API_H__
#define __RMRTSP_API_H__

#include "../../rmdef/rmdef.h"
#include "../../rmlibcw/include/rmsocket.h"

typedef void *RMRTSPHandle;

typedef RMstatus (*RMRTSP_Payload_Callback)(void *callbackContext, RMuint8 *buf, RMuint32 size);
typedef RMstatus (*RMRTSP_EOS_Callback)(void *callbackContext);
typedef RMstatus (*RMRTSP_SequenceLostCallback)(void *callbackContext);


RMRTSPHandle RMRTSPOpen(RMascii *url, RMuint32 heartBeatInterval);

RMstatus RMRTSPRegisterCallbacks(RMRTSPHandle rtspHandle, 
				 void *callbackContext, 
				 RMRTSP_Payload_Callback payloadCallback,
				 RMRTSP_EOS_Callback eosCallback,
				 RMRTSP_SequenceLostCallback seqLostCallback);


RMstatus RMRTSPSendDescribeRequest(RMRTSPHandle rtspHandle, RMuint8 *responseBuf);
RMstatus RMRTSPSendSetupRequest(RMRTSPHandle rtspHandle, RMascii *media);
RMstatus RMRTSPSendPlayRequest(RMRTSPHandle rtspHandle, RMint32 position, RMint32 speed);
RMstatus RMRTSPSendPauseRequest(RMRTSPHandle rtspHandle);
RMstatus RMRTSPSendResumeRequest(RMRTSPHandle rtspHandle);
RMstatus RMRTSPSendTeardownRequest(RMRTSPHandle rtspHandle);
RMstatus RMRTSPSendOKReply(RMRTSPHandle rtspHandle);

RMstatus RMRTSPSendGetParameterRequest(RMRTSPHandle rtspHandle);

RMstatus RMRTSPReadSockets(RMRTSPHandle rtspHandle, RMuint8 *buf, RMuint32 size, RMuint32 timeOut_us, RMuint32 *receivedSize);

RMstatus RMRTSPClose(RMRTSPHandle rtspHandle);



#endif // __RMRTSP_API_H__

