/*
 *
 * Copyright (c) Sigma Designs, Inc. 2006. All rights reserved.
 *
 */
 
#ifndef __OUTPUTCCI_H__
#define __OUTPUTCCI_H__
 
 
/**
  @file   output_cci.h
  @brief  
  Defines the output control module structures and enum
  
  @author Michael Ignaszewski
  @date   2006-11-2
  
  Changelog:
   - Version 1.0: First release. Should support AACS, CPRM,CPPM, CSS, Cardea, Janus, BD-CPS.
   - Version 1.1: Second release. Added APS and RCD bits.
*/ 
  
#define CCI_VERSION 1.1  
  
struct rmcci {
	/** DirtyBit
	 * FALSE (default): structure content has not changed.
	 * TRUE: structure content has changed
	 * The dirty bit is cleaned by the application and set by the DRM
	 * It is only used when callbacks are not used and the cci structure is passed
	 * as an argument to a drm call*/
	 RMbool  DirtyBit;
	
	/** Audio Analog */
	/** AnalogAudio_disable, (R) @par
	 *   FALSE (default): analog audio is enabled,
	 *   TRUE: analog audio is disabled;
	 *   DRMs: None*/
	RMbool	 AnalogAudio_disable;
	
	/** Audio Digital (SPDIF and HDMI) */
	/** DigitalCompressedAudio_disable, (R) @par
	 *   FALSE (default): Digital Compressed audio is enabled,
	 *   TRUE: Digital Compressed audio is disabled;
	 *   DRMs: Cardea, Janus*/
	RMbool	 DigitalCompressedAudio_disable;

	/** DigitalUncompressedAudioDisable, (R) @par 
	 *   FALSE (default): Digital Uncompressed audio is enabled,
	 *   TRUE: Digital Uncompressed audio is disabled;
	 *   DRMs: Cardea, Janus*/
	RMbool	 DigitalUncompressedAudio_disable;

	/** SPDIF_PCMLimit, (R) @par 
	 *   TRUE: SPDIF is compressed (ac3, dts) or in Linear PCM format
	 *   sampled at no more than 48 kHz and no more than 16 bits,
	 *   FALSE (DEFAULT): SPDIF output has no limit;
	 *   DRMs: CSS, CPRM, CPPM, AACS, DTCP-IP */
	RMbool   SPDIF_PCMLimit;

	/** SPDIF_CpBit, (R) @par 
	 *   FALSE (Default): Set the Cp Bit to 1 (No Copyright)
	 *   iec60958-3, bit 2 of channel status,
	 *   TRUE : Set the Cp Bit to 0 (With Copyright) iec60958-3, bit
	 *   2 of channel status;
	 *   See RMAudioEnginePropertyID_ChannelStatus
	 *   DRMs: CSS, CPRM, CPPM, DTCP-IP*/
	RMbool 	 SPDIF_CpBit;

	/** SPDIF_LBit, (R) @par
	 *   FALSE (Default): Set the L Bit to 0 (No indication)
	 *   iec60958-3, bit 15 of channel status,
	 *   TRUE : Set the L Bit to 1 (Commercially released
	 *   pre-recorded software) iec60958-3, bit 15 of channel status;
	 *   See RMAudioEnginePropertyID_ChannelStatus
	 *   DRMs: CSS, CPRM, CPPM, DTCP-IP*/
	RMbool 	 SPDIF_LBit;

	/** Relationship between CGMS and Cp and L bits
	 *  0 0b CopyFreely :  Cp Bit : 1 (FALSE), L bit: 0 (FALSE)
	 *  0 1b CopyNoMore :  Cp Bit : 0 (TRUE) , L bit: 1 (TRUE)
	 *  1 0b CopyOnce   :  Cp Bit : 0 (TRUE) , L bit: 0 (FALSE)
	 *  1 1b CopyNever  :  Cp Bit : 0 (TRUE) , L bit: 1 (TRUE)*/
		
	/** Video */
	/** AnalogVideoDisable, (R) @par
	 *   FALSE (default): analog video is enabled, TRUE: analog video
	 *   is disabled;
	 *   DRMs:  AACS */
	RMbool	 AnalogVideo_disable;
	
	/** Video_agc, (R) @par 
	 *   0 (Default): Disable macrovision,
	 *   1 : Macrovision Level 1: AGC;
	 *   2 : Macrovision Level 2: AGC + 2L Color Stripe (for 480i)/AGC(for 480p);
	 *   3 : Macrovision Level 3: AGC + 4L Color Stripe (for 480i)/AGC(for 480p);
	 *   See RMGenericPropertyID_MacroVision
	 *   DRMs: All*/
	RMuint32  Video_agc;
	
	/** Video_cgmsa, (R) @par 
	 *   0 0b  (Default) CopyFreely Unlimited copies may be made of
	 *   the content.
	 *   0 1b CopyNoMore: One generation of copies has already been
	 *   made; no further copying is allowed.
	 *   1 0b CopyOnce  : One generation of copies may be made
	 *   1 1b CopyNever : No copies may be made of the content.
	 *   See RMGenericPropertyID_CGMSA DRMs: All*/
	RMuint32	Video_CGMSA;
	
	/** DigitalVideo_disable, (R) @par
	 *   FALSE (default):  Enable output of Digital Uncompressed Video.
	 *   TRUE : No digital Uncompressed Video output
	 *   DRMs: Janus, Cardea*/
	RMbool DigitalVideo_disable;

	/** AnalogVideo_imageConstraint, (R) @par
	 *   FALSE (default):  No Constraint.
	 *   TRUE : shall mean an image having the visual equivalent of
	 *   no more than 520,000 pixels per frame (e.g., an image with
	 *   resolution of 960 pixels by 540 pixels for a 16:9 aspect
	 *   ratio). A Constrained Image may be attained by reducing
	 *   resolution, for example, by discarding, dithering, or
	 *   averaging pixels to obtain the specified value. A
	 *   Constrained Image can be displayed using video processing
	 *   techniques such as line doubling or sharpening to improve
	 *   the perceived quality of the image. By way of example, a
	 *   Constrained Image may be stretched or doubled, and displayed
	 *   full-screen, on a 1000- line monitor.
	 *   DRMs: DTCP-IP, AACS*/
	RMbool AnalogVideo_imageConstraint;
	
	/** HDCP for digital uncompressed video
	 *   FALSE (default):  HDCP is disabled.
	 *   TRUE: HDCP is enabled.
	 *   DRMs: All*/
	RMbool HDCP_Enable;

	/** Video_aps, (R) @par
	 *   Analog Protection System, the APS trigger bits are send on
	 *   line 20 for NTSC(IEC 61880), Line 21 as XDS (CEA 608-C) and
	 *   following EIA/CEA-805-TypeA for 720p and 1080i component.
	 *   0 1 (Default): No APS,
	 *   0 1b : PSP on, split burst off;
	 *   1 0b : PSP on, 2-line split burst on;
	 *   1 1b : PSP on, 4-line split burst on;
	 *  See RMGenericPropertyID_
	 *  DRMs: All*/
	RMuint32  Video_aps;

	/** Video_rcd, (R) @par
	 *  Redistribution Control Descriptor (RCD).
	 *  FALSE (default)
	 *  TRUE: Technological control of consumer redistribution is signaled
	 *  DRMs: AACS */
	RMbool Video_rcd;
};

/**
 * CCI application callback
 *
 * @param ctx - context from application
 * @param cci - cci structure
 * Pseudo code of the callback:
 *  - Block re-entrency
 */
typedef RMstatus (*cps_cci_callback_t) (void *ctx, struct rmcci* cci);

#define DUMP_CCI(cci) \
do {													\
	RMDBGPRINT((ENABLE, "----   CCI information   ----\n"));					\
	RMDBGPRINT((ENABLE, "Dirty                   : %d\n", (cci)->DirtyBit));			\
	RMDBGPRINT((ENABLE, "Audio disable\n"));							\
	RMDBGPRINT((ENABLE, " Analog                 : %d\n", (cci)->AnalogAudio_disable));		\
	RMDBGPRINT((ENABLE, " Digital Compressed     : %d\n", (cci)->DigitalCompressedAudio_disable));	\
	RMDBGPRINT((ENABLE, " Digital Uncompressed   : %d\n", (cci)->DigitalUncompressedAudio_disable));\
	RMDBGPRINT((ENABLE, "SPDIF PCM limit         : %d\n", (cci)->SPDIF_PCMLimit));			\
	RMDBGPRINT((ENABLE, "SPDIF Cp Bit            : %d\n", (cci)->SPDIF_CpBit));			\
	RMDBGPRINT((ENABLE, "SPDIF L Bit             : %d\n", (cci)->SPDIF_LBit));			\
	RMDBGPRINT((ENABLE, "Analog Video disable    : %d\n", (cci)->AnalogVideo_disable));		\
	RMDBGPRINT((ENABLE, "Video AGC               : %lu\n", (cci)->Video_agc));			\
	RMDBGPRINT((ENABLE, "Video CGMSA             : %lu\n", (cci)->Video_CGMSA));			\
	RMDBGPRINT((ENABLE, "Digital Video disable   : %d\n", (cci)->DigitalVideo_disable));		\
	RMDBGPRINT((ENABLE, "Analog Video Constraint : %d\n", (cci)->AnalogVideo_imageConstraint));	\
	RMDBGPRINT((ENABLE, "HDCP Enable             : %d\n", (cci)->HDCP_Enable));			\
	RMDBGPRINT((ENABLE, "Video APS               : %d\n", (cci)->Video_aps));			\
	RMDBGPRINT((ENABLE, "Video RCD               : %d\n", (cci)->Video_rcd));			\
} while (0);

#endif /* __OUTPUTCCI_H__ */
