#ifndef __RMLIBMONITORING_H__
#define __RMLIBMONITORING_H__

RMstatus start_monitoring(RMuint32 scaler_index);
RMstatus stop_monitoring(void);
void update_monitoring(void);

#endif /* __RMLIBMONITORING_H__ */
