/*
 *
 * Copyright (c) Sigma Designs, Inc. 2005. All rights reserved.
 *
 */

/**
 * @file librmmonitoring.c
 * @brief Library of functions for monitoring EM86xx decoders.
 * 
 * @author Sylvain Garrigues
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define ALLOW_OS_CODE 1
#include "rmrtk/include/rmrtk.h"
#include "../include/librmmonitoring.h"

#define WAIT_TIMEOUT_US 1000000

#define FONT_FILE "Vera.ttf"
#define FONT_FG_COLOR 0xff99ff99
#define FONT_SCALE 14 

#define MAX_LINES 32 /* maximum number of lines to display */
#define BUFFER_SIZE 512 /* maximum number of bytes to read per /proc entries */

#define STC_FILENAME "/proc/driver/em8xxx/0/monitoring/STC/STC0"
#define VD_FILENAME "/proc/driver/em8xxx/0/monitoring/video/video_decoder0"
#define AD_FILENAME "/proc/driver/em8xxx/0/monitoring/audio/audio_decoder0"
#if (EM86XX_MODE == EM86XX_MODEID_STANDALONE)
#define DMA0_FILENAME "/proc/driver/llad/pools/pool0"
#define DMA1_FILENAME "/proc/driver/llad/pools/pool1"
#else
#define DMA0_FILENAME "/proc/driver/mum/0/DMA/pool0"
#define DMA1_FILENAME "/proc/driver/mum/0/DMA/pool1"
#endif

#define GRAPH_SIDE_MARGIN 50
#define GRAPH_BOTTOM_MARGIN 40
#define GRAPH_COLORS_MAX 6

static void draw_string(RMascii *, const RMuint32, const RMuint32, RMint32 *);
static struct DCC *pDCC;
static struct RUA *pRUA;
static struct DCCVideoSource *pOSDSource;
static RMTrtk rtk;
static int fvideo_decoder, faudio_decoder, fstc, fdmapool0, fdmapool1;
static RtkRect outputRect[MAX_LINES]; /* rectangles in which strings are written */

static RMuint32 graph_osd_width;
static RMuint32 graph_osd_height;
static RMuint32 graph_current_column;
static RMuint32 graph_color_index;
static RMuint32 graph_color_table[GRAPH_COLORS_MAX] = {0xffff0000, 0xff0000ff, 0xffffff00, 0xffff00ff, 0xff00ff00, 0xff00ffff};

static void graph_init(RMuint32 width, RMuint32 height)
{
	RtkProp prop;
	RtkRect rect;

	/* Remember the OSD width and height */
	graph_osd_width = width;
	graph_osd_height = height;

	/* The current column starts at the left margin */
	graph_current_column = GRAPH_SIDE_MARGIN;

	/* Set the color property to the foreground color */
	prop.scale = 1;
	prop.fgColor = FONT_FG_COLOR;
	prop.bgColor = FONT_FG_COLOR;
	prop.lineWidth = 0;
	prop.lineColor = FONT_FG_COLOR;

	/* Draw the top and bottom boundaries of the graph */
	rect.width = graph_osd_width - (2 * GRAPH_SIDE_MARGIN);
	rect.height = 1;
	rect.x = GRAPH_SIDE_MARGIN;
	rect.y = graph_osd_height - GRAPH_BOTTOM_MARGIN;
	RMFRTKDrawRect(rtk, &rect, &prop);
	rect.y = graph_osd_height - GRAPH_BOTTOM_MARGIN - 100;
	RMFRTKDrawRect(rtk, &rect, &prop);
}

static void graph_erase_current_column()
{
	RtkProp prop;
	RtkRect rect;
	RtkPoint point;

	/* Set the color property to clear */
	prop.scale = 1;
	prop.fgColor = 0xff000000;
	prop.bgColor = 0xff000000;
	prop.lineWidth = 0;
	prop.lineColor = 0xff000000;

	/* Erase the current column */
	rect.width = 1;
	rect.height = 101;
	rect.x = graph_current_column;
	rect.y = graph_osd_height - GRAPH_BOTTOM_MARGIN - 100;
	RMFRTKDrawRect(rtk, &rect, &prop);

	/* Redraw the top and bottom pixels of the boundaries of the graph */
	point.x = graph_current_column;
	point.y = graph_osd_height - GRAPH_BOTTOM_MARGIN;
	RMFRTKSetPixel(rtk, &point, FONT_FG_COLOR);
	point.y = graph_osd_height - GRAPH_BOTTOM_MARGIN - 100;
	RMFRTKSetPixel(rtk, &point, FONT_FG_COLOR);

	/* Reset the graph color table index */
	graph_color_index = 0;
}

static void graph_advance_current_column()
{
	RtkProp prop;
	RtkRect rect;

	/* Advance the current column, wrapping if necessary */
	graph_current_column++;
	if (graph_current_column + GRAPH_SIDE_MARGIN > graph_osd_width)
		graph_current_column = GRAPH_SIDE_MARGIN;

	/* Set the color property to the foreground color */
	prop.scale = 1;
	prop.fgColor = FONT_FG_COLOR;
	prop.bgColor = FONT_FG_COLOR;
	prop.lineWidth = 0;
	prop.lineColor = FONT_FG_COLOR;

	/* Draw short vertical stubs at the top and bottom boundaries of the graph */
	/* to mark the location of the current column */
	rect.width = 1;
	rect.height = 10;
	rect.x = graph_current_column;
	rect.y = graph_osd_height - GRAPH_BOTTOM_MARGIN - 100;
	RMFRTKDrawRect(rtk, &rect, &prop);
	rect.y = graph_osd_height - GRAPH_BOTTOM_MARGIN - 9;
	RMFRTKDrawRect(rtk, &rect, &prop);
}

void update_monitoring()
{
        const char delimiters[] = "\n";
        RMascii buffer[BUFFER_SIZE];
        RMascii *running, *token;
        RMint32 line_number = 0;
        RMuint32 current_y = 40;
      	RtkProp prop = {0, 0xff000000};
        int times = 0;
        
        putchar('.');
        fflush(stdout);

	/* Erase the current column on the graph */
	graph_erase_current_column();

        /* Read STC information from /proc entry. */
        lseek(fstc, 0, SEEK_SET);
        memset(buffer, '\0', BUFFER_SIZE);
        read(fstc, buffer, BUFFER_SIZE - 1);
      
        running = buffer;
        token = strsep(&running, delimiters);
        while (running != NULL) { 
       	        RMFRTKDrawRect(rtk, &outputRect[line_number], &prop);
              	draw_string(token, 50, current_y, &line_number);
                current_y += FONT_SCALE;
                token = strsep(&running, delimiters);
        }
        
        current_y += FONT_SCALE; /* skip a line */

        /* Read video decoder information from /proc entry. */
        lseek(fvideo_decoder, 0, SEEK_SET);
        memset(buffer, '\0', BUFFER_SIZE);
        read(fvideo_decoder, buffer, BUFFER_SIZE - 1);
      
        running = buffer;
        token = strsep(&running, delimiters);
        while (running != NULL) {
       	        RMFRTKDrawRect(rtk, &outputRect[line_number], &prop);
              	draw_string(token, 50, current_y, &line_number);
                current_y += FONT_SCALE;
                token = strsep(&running, delimiters);
        }
                
        current_y += FONT_SCALE; /* skip a line */

        /* Read audio decoder information from /proc entry. */
        lseek(faudio_decoder, 0, SEEK_SET);
        memset(buffer, '\0', BUFFER_SIZE);
        read(faudio_decoder, buffer, BUFFER_SIZE - 1);

        running = buffer;
        token = strsep(&running, delimiters);
        while (running != NULL) {
       	        RMFRTKDrawRect(rtk, &outputRect[line_number], &prop);
              	draw_string(token, 50, current_y, &line_number);
                current_y += FONT_SCALE;
                token = strsep(&running, delimiters);
        }
        
        current_y += FONT_SCALE;

        /* Read DMA pool 0 decoder information from /proc entry. */
        lseek(fdmapool0, 0, SEEK_SET);
        memset(buffer, '\0', BUFFER_SIZE);
        read(fdmapool0, buffer, BUFFER_SIZE - 1);

        running = buffer;
        token = strsep(&running, delimiters);
        while (running != NULL) {
                times++;
       	        RMFRTKDrawRect(rtk, &outputRect[line_number], &prop);
              	draw_string(token, 50, current_y, &line_number);
                current_y += FONT_SCALE;
                token = strsep(&running, delimiters);
        }

        if (times == 1) {
       	        RMFRTKDrawRect(rtk, &outputRect[line_number++], &prop);
       	        RMFRTKDrawRect(rtk, &outputRect[line_number++], &prop);
        }
        times = 0;
        
        current_y += FONT_SCALE;

        /* Read DMA pool 1 decoder information from /proc entry. */
        lseek(fdmapool1, 0, SEEK_SET);
        memset(buffer, '\0', BUFFER_SIZE);
        read(fdmapool1, buffer, BUFFER_SIZE - 1);

        running = buffer;
        token = strsep(&running, delimiters);
        while (running != NULL) {
                times++;
       	        RMFRTKDrawRect(rtk, &outputRect[line_number], &prop);
              	draw_string(token, 50, current_y, &line_number);
                current_y += FONT_SCALE;
                token = strsep(&running, delimiters);
        }

        if (times == 1) {
       	        RMFRTKDrawRect(rtk, &outputRect[line_number++], &prop);
       	        RMFRTKDrawRect(rtk, &outputRect[line_number++], &prop);
        }
        times = 0;        
        
        current_y += FONT_SCALE;
        
	/* Advance to the next column in the graph */
	graph_advance_current_column();
}

static void draw_string(RMascii *text, const RMuint32 x, const RMuint32 y, RMint32 *line_number)
{
	RtkPoint position;
	RtkProp prop;
	RMascii *ch;

        position.x = x;
        position.y = y;
        
	prop.scale = FONT_SCALE;
	prop.fgColor = FONT_FG_COLOR;
        prop.bgColor = 0x00000000;

	/* Search for a '%' within the string */
	if ((ch = strchr(text, '%')) != NULL) {

		/* Check if the previous character is a number */
		ch--;
		if ((ch >= text) && (*ch >= '0') && (*ch <= '9')) {
			RtkPoint pixel;
			RMuint32 percentage = *ch - '0';

			/* Assemble the percentage from characters within the string */
			ch--;
			if ((ch >= text) && (*ch >= '0') && (*ch <= '9')) {
				percentage += ((*ch - '0') * 10);
				ch--;
				if ((ch >= text) && (*ch == '1'))
					percentage = 100;
			}

			/* Graph the percentage extracted from the string */
			pixel.y = graph_osd_height - GRAPH_BOTTOM_MARGIN - percentage;
			pixel.x = graph_current_column;
			RMFRTKSetPixel(rtk, &pixel, graph_color_table[graph_color_index]);

			/* Set the text's color to the same color used to graph the percentage */
			prop.fgColor = graph_color_table[graph_color_index];

			/* Advance to the next available color in the color table, wrapping if necessary */
			graph_color_index++;
			if (graph_color_index >= GRAPH_COLORS_MAX)
				graph_color_index = 0;
		}
	}

	RMFRTKDrawString(rtk, text, &position, &prop,  &outputRect[(*line_number)++]);
}

RMstatus start_monitoring(RMuint32 scaler_index)
{
	struct DCCOSDProfile  osd_profile;
	enum EMhwlibMixerSourceState state = EMhwlibMixerSourceState_Slave;
	RMuint32 surfaceID, scaler = EMHWLIB_MODULE(DispGFXMultiScaler, 0), src_index;
	RMuint32 osd_mixer = EMHWLIB_MODULE(DispMainMixer, 0);
	RMuint32 mixer_src;
        RMstatus err;
	Rtk86Handle handle;

#if (EM86XX_CHIP == EM86XX_CHIPID_TANGO2)
	RMbool enable;
#endif

        /* Open /proc files */
        fstc = open(STC_FILENAME, O_RDONLY);
        fvideo_decoder = open(VD_FILENAME, O_RDONLY);
        faudio_decoder = open(AD_FILENAME, O_RDONLY);
        fdmapool0 = open(DMA0_FILENAME, O_RDONLY);
        fdmapool1 = open(DMA1_FILENAME, O_RDONLY);

        if ((fstc == -1) || (fvideo_decoder == -1) || (faudio_decoder == -1)) {
		RMDBGLOG((ENABLE, "Unable to open em8xxx /proc entry.\n"));
		RMDBGLOG((ENABLE, "Did you compile em8xxx with the appropriate flags (-DWITH_PROC=1 and -DWITH_MONITORING=1)? \n"));
                return RM_ERROR;
        }
                
        if ((fdmapool0 == -1) || (fdmapool1 == -1)) {
		RMDBGLOG((ENABLE, "Unable to open llad /proc entry.\n"));
		RMDBGLOG((ENABLE, "Did you compile llad with the appropriate flags (-DWITH_PROC=1 and -DWITH_MONITORING=1)?\n"));
                return RM_ERROR;
        }

        /* Initialize RUA and DCC. */
	err = RUACreateInstance(&pRUA, 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error creating RUA instance: error %d.\n", (int) err));
		return err;
	}
	
	err = DCCOpen(pRUA, &pDCC);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error opening DCC: error %d.\n", (int) err));
		goto exit;
	}

	err = DCCInitChainEx(pDCC, DCCInitMode_LeaveDisplay);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error initializing micro-code: error %d.\n", (int) err));
		goto exit;
	}

	osd_profile.Width = 640;
	osd_profile.Height = 480;
	osd_profile.ColorMode = EMhwlibColorMode_TrueColorWithKey;
	osd_profile.ColorFormat = EMhwlibColorFormat_32BPP;
	osd_profile.SamplingMode = EMhwlibSamplingMode_444;
	osd_profile.ColorSpace = EMhwlibColorSpace_RGB_0_255;

#if (EM86XX_CHIP == EM86XX_CHIPID_TANGO2)

        /* Set up the connector. */
	DCCSetStandard(pDCC, DCCRoute_Main, EMhwlibTVStandard_NTSC_M);
        DCCEnableVideoConnector(pDCC, DCCRoute_Main, DCCVideoConnector_SVIDEO, TRUE);

	DCCSetRouteDisplayAspectRatio(pDCC, DCCRoute_Main, 4, 3);

        /* Set up the OSD surface. */
	err = DCCGetScalerModuleID(pDCC, DCCRoute_Main, DCCSurface_OSD, scaler_index, &surfaceID);
	if (RMFAILED(err)) {
		printf("Cannot get a surface to display OSD source: error %d.\n", (int) err);
		goto exit;
	}

	err = RUAExchangeProperty(pRUA, osd_mixer, RMGenericPropertyID_MixerSourceIndex, &surfaceID, sizeof(surfaceID), &src_index, sizeof(src_index));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get DCCSurface_OSD's index\n"));
		goto exit;
	}

	mixer_src = EMHWLIB_TARGET_MODULE(osd_mixer, 0, src_index);
	state = EMhwlibMixerSourceState_Master;
	while((err =  RUASetProperty(pRUA, mixer_src, RMGenericPropertyID_MixerSourceState, &state, sizeof(state), 0))==RM_PENDING);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set DCCSurface_OSD's state on mixer\n"));
		goto exit;
	}

	while ((err = RUASetProperty(pRUA, mixer_src, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot RMGenericPropertyID_Validate mixer\n"));
		goto exit;
	}

	enable = FALSE;
	err =  RUASetProperty(pRUA, surfaceID, RMGenericPropertyID_Enable, &enable, sizeof(enable), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot enable DCCSurface_OSD\n"));
		goto exit;
	}

     	err = DCCOpenOSDVideoSource(pDCC, &osd_profile, &pOSDSource);
	if (RMFAILED(err)) {
		printf("Cannot open the OSD surface source: error %d.\n", (int) err);
		goto exit;
	}

	/* clear the surface first */
	err = DCCClearOSDVideoSource(pOSDSource);
	if (RMFAILED(err)) {
		printf("Cannot clear the OSD surface: error %d.\n", (int) err);
		goto exit;
	}

	err = DCCSetSurfaceSource(pDCC, surfaceID, pOSDSource);
	if (RMFAILED(err)) {
		printf("Cannot set the OSD surface source: error %d.\n", (int) err);
		goto exit;
	}

	while ((err = RUASetProperty(pRUA, surfaceID, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot validate DCCSurface_OSD's input window: %s\n", RMstatusToString(err)));
		goto exit;
	}

	enable = TRUE;
	err =  RUASetProperty(pRUA, surfaceID, RMGenericPropertyID_Enable, &enable, sizeof(enable), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot enable DCCSurface_OSD\n"));
		goto exit;
	}
#else
     	err = DCCOpenOSDVideoSource(pDCC, &osd_profile, &pOSDSource);
	if (RMFAILED(err)) {
		printf("Cannot open the OSD surface source: error %d.\n", (int) err);
		goto exit;
	}

	err = DCCGetScalerModuleID(pDCC, DCCRoute_Main, DCCSurface_OSD, scaler_index, &surfaceID);
	if (RMFAILED(err)) {
		printf("Cannot get a surface to display OSD source: error %d.\n", (int) err);
		goto exit;
	}
        
	err = DCCClearOSDVideoSource(pOSDSource);
	if (RMFAILED(err)) {
		printf("Cannot clear the OSD surface: error %d.\n", (int) err);
		goto exit;
	}

	err = DCCSetSurfaceSource(pDCC, surfaceID, pOSDSource);
	if (RMFAILED(err)) {
		printf("Cannot set the OSD surface source: error %d.\n", (int) err);
		goto exit;
	}

	DCCSetStandard(pDCC, DCCRoute_Main, EMhwlibTVStandard_NTSC_M);
	DCCSetRouteDisplayAspectRatio(pDCC, DCCRoute_Main, 4, 3);
	DCCEnableVideoSource(pOSDSource, TRUE);
        DCCEnableVideoConnector(pDCC, DCCRoute_Main, DCCVideoConnector_SVIDEO, TRUE);
#endif


        /* Set the GFX scaler source state on mixer. */
	scaler = EMHWLIB_MODULE(DispGFXMultiScaler, 0);

	err = DCCSetSurfaceSource(pDCC, scaler, NULL);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot unset gfx scaler's surface: error %d.\n", (int) err));
		goto exit;
	}

	err = RUAExchangeProperty(pRUA, osd_mixer, RMGenericPropertyID_MixerSourceIndex, &scaler, sizeof(scaler), &src_index, sizeof(src_index));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get scaler index: error %d.\n", (int) err));
		goto exit;
	}

	mixer_src = EMHWLIB_TARGET_MODULE(osd_mixer, 0, src_index);
	state = EMhwlibMixerSourceState_Slave;

	while ((err =  RUASetProperty(pRUA, mixer_src, RMGenericPropertyID_MixerSourceState, &state, sizeof(state), 0)) == RM_PENDING);
       	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set scaler's state on mixer: error %d.\n", (int) err));
		goto exit;
	}

	while ((err = RUASetProperty(pRUA, osd_mixer, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot validate mixer: error %d.\n", (int) err));
		goto exit;
	}

        /* Open RTK and load font. */
	handle.pOSDSource = pOSDSource;
	handle.pRUA = pRUA;
	rtk = RMFRTKOpen(&handle);
        
	RMFRTKLoadFontFile(rtk, RMNONASCII(FONT_FILE));
     
        RMFRTKClearScreen(rtk);

	/* Initialize the graph by drawing the top and bottom boundaries */
	graph_init(osd_profile.Width, osd_profile.Height);
        
        return RM_OK;

 exit:
	stop_monitoring();
	return err;
	
}

RMstatus stop_monitoring(void)
{
        RMstatus err;
	struct RUAEvent evt;
	RMbool empty_queue = FALSE;
        
       	/* Wait for all commands to be finished. */
	evt.ModuleID = EMHWLIB_MODULE(GFXEngine,0);
	evt.Mask = RUAEVENT_COMMANDCOMPLETION;
	while (!empty_queue) {
		RUAGetProperty(pRUA, EMHWLIB_MODULE(GFXEngine,0), RMGFXEnginePropertyID_CommandQueueEmpty, &empty_queue, sizeof(empty_queue));
		/* Avoid continuous polling. */
		if (!empty_queue) 
			while (RUAWaitForMultipleEvents(pRUA, &evt, 1, WAIT_TIMEOUT_US, NULL) != RM_OK)
				RMDBGLOG((ENABLE, "Waiting for a command to finish.\n"));
	}
        
        close(fvideo_decoder);
        close(faudio_decoder);
        close(fstc);
        close(fdmapool0);
        close(fdmapool1);

        if (rtk != NULL) {
        	err = RMFRTKClose(rtk);
        	if (RMFAILED(err)) {
        		RMDBGLOG((ENABLE, "Cannot close rtk: error %d.\n", err));
        		return err;
	        }
        }

        if (pOSDSource != NULL) {
        	err = DCCCloseVideoSource(pOSDSource);
        	if (RMFAILED(err)) {
        		RMDBGLOG((ENABLE, "Cannot close OSD source: error %d.\n", err));
        		return err;
	        }
        }
		
        if (pDCC != NULL) {
        	err = DCCClose(pDCC);
        	if (RMFAILED(err)) {
        		RMDBGLOG((ENABLE, "Cannot close DCC: error %d.\n", err));
        		return err;
	        }
        }

        if (pRUA != NULL) {
        	err = RUADestroyInstance(pRUA);
        	if (RMFAILED(err)) {
        		RMDBGLOG((ENABLE, "Cannot destroy RUA instance: error %d.\n", err));
        		return err;
	        }
        }

        return RM_OK;
}

