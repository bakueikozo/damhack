/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   rmdetectorapi.h
  @brief  

  long description

  @author Laurent Crinon
  @date   2004-02-05
*/

#ifndef __RMDETECTORAPI_H__
#define __RMDETECTORAPI_H__

#include "rmdetector/include/rmdetector-exported.h"


typedef enum
{
	DETECTOR_AUDIO_PCM=586,
	DETECTOR_AUDIO_RPCM,
	DETECTOR_AUDIO_AAC,
	DETECTOR_AUDIO_AAC_DSI,
	DETECTOR_AUDIO_AAC_ADTS, //590
	DETECTOR_AUDIO_AAC_ADIF,
	DETECTOR_AUDIO_MPEG1,
	DETECTOR_AUDIO_MPEG2,
	DETECTOR_AUDIO_AC3,
	DETECTOR_AUDIO_DTS,
	DETECTOR_AUDIO_MLP,
	DETECTOR_AUDIO_MPEG1_LAYER3,
	DETECTOR_AUDIO_MPEG2_LAYER1,
	DETECTOR_AUDIO_MPEG2_LAYER2,
	DETECTOR_AUDIO_MPEG2_LAYER3, //600
	DETECTOR_AUDIO,
	DETECTOR_VIDEO_MPEG1,
	DETECTOR_VIDEO_MPEG2,
	DETECTOR_VIDEO_MPEG4,
	DETECTOR_VIDEO_VC1,
	DETECTOR_VIDEO_H263,
	DETECTOR_VIDEO_H264,
	DETECTOR_PICTURE_BMP,
	DETECTOR_PICTURE_JPEG,
	DETECTOR_PICTURE_TIFF,
	DETECTOR_PICTURE_GIF,
	DETECTOR_PICTURE_PNG,
	DETECTOR_SYSTEM_M1S,//610
	DETECTOR_SYSTEM_M2P,
	DETECTOR_SYSTEM_M2T,
	DETECTOR_SYSTEM_M2T_192,
	DETECTOR_SYSTEM_M4T,
	DETECTOR_SYSTEM_M4P,
	DETECTOR_SYSTEM_MP4,
	DETECTOR_SYSTEM_VOB,
	DETECTOR_SYSTEM_AVI,
	DETECTOR_SYSTEM_RIFFCDXA, // this is RIFF/CDXA type or VCD, we do not support it but we detect it
	DETECTOR_SYSTEM_DIVX_PCM,
	DETECTOR_SYSTEM_DIVX_MP3,
	DETECTOR_SYSTEM_DIVX_AC3,
	DETECTOR_SYSTEM_DIVX_MPEG1,
	DETECTOR_SYSTEM_DIVX_WMA,
	DETECTOR_SYSTEM_DIVX3_PCM,
	DETECTOR_SYSTEM_DIVX3_MP3,
	DETECTOR_SYSTEM_DIVX3_AC3,
	DETECTOR_SYSTEM_DIVX3_MPEG1,
	DETECTOR_SYSTEM_DIVX_WMV9_PCM,
	DETECTOR_SYSTEM_DIVX_WMV9_MP3,
	DETECTOR_SYSTEM_DIVX_WMV9_AC3,
	DETECTOR_SYSTEM_DIVX_WMV9_MPEG1,
	DETECTOR_SYSTEM_ASF,
	// TO COMPLETE
	DETECTOR_TYPE_UNKNOWN
}RMFDetector_type;



typedef struct {
	RMascii Title[31];
	RMascii Artist[31];
	RMascii Album[31];
	RMascii Year[5];
	RMascii Comment[31];
	RMuint8 Track;
	RMuint8 Genre;
}RMID3v1Tag;

	

typedef struct _RMdetectorHandle *RMdetectorHandle;

RM_EXTERN_C_BLOCKSTART

RM_LIBRARY_IMPORT_EXPORT RMdetectorHandle RMFDetectorCreate();

RM_LIBRARY_IMPORT_EXPORT void RMFDetectorDestruct(RMdetectorHandle h);

RM_LIBRARY_IMPORT_EXPORT RMstatus RMFDetect(RMdetectorHandle h, RMascii *fileName, RMFDetector_type *type);

RM_LIBRARY_IMPORT_EXPORT RMstatus RMFDetectOnOpenFile(RMdetectorHandle h, RMascii *fileName, 
						      RMfile file, RMFDetector_type *type);

RM_LIBRARY_IMPORT_EXPORT RMstatus RMFDetectAudio(RMdetectorHandle h, RMuint8 *buf, RMuint32 size,
						 eAudioFormat_type *type, RMuint32 *frequency,
						 RMuint32 *channels, RMuint32 *bitrate, RMbool *isDetected);

RM_LIBRARY_IMPORT_EXPORT RMstatus RMFDetectVideo(RMdetectorHandle h, RMuint8 *buf, RMuint32 size,
						 RMvideoType *type, RMuint32 *bitrate,  RMbool *isDetected);

RM_LIBRARY_IMPORT_EXPORT RMstatus RMFDetectSystem(RMdetectorHandle h, RMuint8 *buf, RMuint32 size,
						 RMsystemType *type,  RMbool *isDetected);

RM_LIBRARY_IMPORT_EXPORT RMstatus RMFGetSystemSpecificInfo(RMdetectorHandle h, RMsystemType type, struct RM_Detection_Specific_Info *info);

RM_LIBRARY_IMPORT_EXPORT RMstatus RMFGetDetectedAudioType(RMdetectorHandle h, eAudioFormat_type *audioType);

RM_LIBRARY_IMPORT_EXPORT RMstatus RMFGetAudioSpecificInfo(RMdetectorHandle h, eAudioFormat_type audioType, struct RM_Detection_Specific_Info *info);


RM_LIBRARY_IMPORT_EXPORT RMstatus RMFDetectVariableAudioBitrate(RMdetectorHandle h, RMbool *isVariable);

RM_LIBRARY_IMPORT_EXPORT void RMFDetectorReset(RMdetectorHandle h);

RM_LIBRARY_IMPORT_EXPORT RMstatus RMReadID3v1(RMuint8 *buf, RMuint32 buf_size, RMID3v1Tag *tag);


RM_EXTERN_C_BLOCKEND

#endif // __RMDETECTORAPI_H__
