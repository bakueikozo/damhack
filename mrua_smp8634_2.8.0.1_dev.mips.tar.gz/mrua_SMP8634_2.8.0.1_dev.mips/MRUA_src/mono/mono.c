#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define ALLOW_OS_CODE 1

#include <sys/types.h>

#include "../samples/common.h"
#include "../samples/command_ids.h"
#include "rmlocalremote.h"
#include "../rmremoteapi/include/rmremoteapi.h"

#include "../rmrtk/include/rmrtk.h"

/* #### Begin CARDEA code #### */
#include "rmupnp/rmlibwmdrmnd/include/ms_cardea.h"
/* #### End CARDEA code #### */

/* #### Begin DTCP code #### */
#if (EM86XX_CHIP == EM86XX_CHIPID_TANGO15)
#include "../rmdtcp/include/dtcp_session.h"
#else
#include "../rmdtcpapi/include/dtcp_session.h"
#endif
/* #### End DTCP code #### */

#include "mono.h"

#if 1
#define MONODBG ENABLE
#else
#define MONODBG DISABLE
#endif

#define MAX_DIR_RECURSION 8
#define SRM_SIZE 5 * 1024
#define SRM_PATH "/mnt/sigma/hdcp.srm"

#define ERROR_CLEANUP(i)	do { error = (i); goto cleanup; }  while(0)

struct dcc_context dcc_info = {0,};


// callback for the application to receive dcc context
void RMDCCInfo(struct dcc_context *dcc_info)
{
	RMDBGLOG((ENABLE, "got dcc info @ 0x%08lx\n", (RMuint32) dcc_info));
	// nothing to do for mono
}

// callback to pass stream information to the application, DRM protected, number of chapters, etc
void RMFileStreamInfoCallback(struct RMFileStreamInfo *streamInfo)
{
	// nothing to do for mono
	RMDBGLOG((ENABLE, "got stream info!\n"));
}


RM_EXTERN_C_BLOCKSTART

void RMremoteResetState(void);

RM_EXTERN_C_BLOCKEND


static struct playback_cmdline play_opt;
static struct display_cmdline disp_opt;
static struct video_cmdline video_opt;
static struct demux_cmdline demux_opt;

struct mono_context mono_opt;

static RMdirectory directory[MAX_DIR_RECURSION];
static RMascii path[256];
static RMuint32 path_index[MAX_DIR_RECURSION];

/* returns TRUE to play the file and FALSE to skip it */

static RMascii *filename;
static RMascii *remote_dev;
RMremoteHandle rh = (RMremoteHandle) NULL;
RMbool osd_enabled = FALSE;

static RtkProp info_face ={
	scale: 24,
	fgColor: 0xff555555,
	bgColor: 0xff000000,
};

static RtkProp data_face ={
	scale: 32,
	fgColor: 0xff808080,
	bgColor: 0xff000000,
};



/* this is the EOS callback, must be implemented by curacao */
void RMEOSCallback()
{
	/* mono doesnt do anything */
	RMDBGLOG((ENABLE, "RMEOSCallback() called, awaiting a command\n"));
	RMDBGLOG((ENABLE, "reset remote state to playing\n"));
	RMremoteResetState();	
}


// Write SRM to non-volatile memory or other persistent storage
static RMstatus Write_SRM(RMuint8 *pSRM, RMuint32 Size) 
{
	RMstatus err = RM_OK;
	RMfile fd;
	RMnonAscii *naname;
	RMuint32 size;
	
	// read /mnt/sigma/hdcp.srm
	RMDBGLOG((ENABLE, "Writing new SRM file to non-volatile memory at %s\n", SRM_PATH));
	naname = RMnonAsciiFromAscii(SRM_PATH);
	fd = RMOpenFile(naname, RM_FILE_OPEN_WRITE);
	RMFreeNonAscii(naname);
	if (fd) {
		err = RMWriteFile(fd, pSRM, Size, &size);
		RMCloseFile(fd);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error, could not write persistent SRM file!\n"));
			err = RM_ERROR;
		} else {
			if (Size != size) err = RM_ERROR;
		}
	} else {
		RMDBGLOG((ENABLE, "Error: could not open persistent SRM file for writing\n"));
		err = RM_ERROR;
	}
	
	return err;
}

// Read SRM from non-volatile memory or other persistent storage
static RMstatus Read_SRM(RMuint8 *pSRM, RMuint32 *pSize) 
{
	RMstatus err;
	RMfile fd;
	RMnonAscii *naname;
	RMuint32 size, max_size = SRM_SIZE;
	static const RMuint8 SRM_empty[] = {
		0x80, 0x00, 0x00, 0x01,  // version
		0x00, 0x00, 0x00, 0x2b,  // length
		// no keys
		// "DCP LLC" production DSS signature
		0xd2, 0x48, 0x9e, 0x49, 0xd0, 0x57, 0xae, 0x31, 
		0x5b, 0x1a, 0xbc, 0xe0, 0x0e, 0x4f, 0x6b, 0x92, 
		0xa6, 0xba, 0x03, 0x3b, 0x98, 0xcc, 0xed, 0x4a, 
		0x97, 0x8f, 0x5d, 0xd2, 0x27, 0x29, 0x25, 0x19, 
		0xa5, 0xd5, 0xf0, 0x5d, 0x5e, 0x56, 0x3d, 0x0e 
	};
	
	// note max data size
	if (pSize && *pSize) max_size = *pSize;
	size = 0;
	
	// read /mnt/sigma/hdcp.srm
	RMDBGLOG((ENABLE, "Reading current HDCP SRM file from non-volatile memory at %s\n", SRM_PATH));
	naname = RMnonAsciiFromAscii(SRM_PATH);
	fd = RMOpenFile(naname, RM_FILE_OPEN_READ);
	RMFreeNonAscii(naname);
	if (fd) {
		err = RMReadFile(fd, pSRM, SRM_SIZE, &size);
		RMCloseFile(fd);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error, could not read persistent HDCP SRM file!\n"));
			size = 0;
		} else {
			RMDBGLOG((ENABLE, "Read %lu bytes of the persistent HDCP SRM file.\n", size));
			if (pSize) *pSize = size;
		}
	} else {
		RMDBGLOG((ENABLE, "Error: could not open persistent HDCP SRM file!\n"));
	}
	
	// Fallback: empty, valid SRM
	if (size == 0) {
		RMDBGLOG((ENABLE, "Fall back to empty, valid HDCP SRM\n"));
		size = RMmin(sizeof(SRM_empty) / sizeof(RMuint8), max_size);
		RMMemcpy(pSRM, SRM_empty, size);
		if (pSize) *pSize = size;
		Write_SRM(pSRM, size);
	}
	
	return RM_OK;
}

// Read SRM from current medium and update if more recent than previous one
static RMstatus Update_SRM(RMascii *filename, struct DH_control *pDH, RMuint8 *pSRM)
{
	RMstatus err = RM_OK;
	RMdirectory directory;
	RMascii path[2048];
	RMdirectoryEntry entry;
	RMfile fd;
	RMnonAscii *naname;
	RMuint32 size;
	RMbool update = FALSE;
	
	if (pSRM == NULL) {
		RMDBGLOG((ENABLE, "SRM pointer invalid!\n"));
		return RM_ERROR;
	}
	
	directory = open_directory(filename);
 	if (directory == NULL) {
 		// Single file, nothing to do
 		return RM_OK;
	}
	RMDBGLOG((MONODBG, "%s is a directory\n", filename));
	RMCopyAscii (path, filename);
	if (path[RMasciiLength(path) - 1] != '/') {
		RMAppendAscii (path, "/");
	}
	
	while (RMSUCCEEDED(RMReadDirectory(directory, &entry))) {
		if (
		    (! strcmp((char*)entry.name, "HDCP.SRM")) || 
		    (! strcmp((char*)entry.name, "HDCP.srm"))
		) {
			RMAppendAscii (path, (RMascii*)entry.name);
			RMDBGLOG((MONODBG, "Found HDCP SRM file: %s\n", path));
			naname = RMnonAsciiFromAscii(path);
			fd = RMOpenFile(naname, RM_FILE_OPEN_READ);
			RMFreeNonAscii(naname);
			if (fd) {
				err = RMReadFile(fd, pSRM, SRM_SIZE, &size);
				RMCloseFile(fd);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Error, could not read SRM file %s!\n", path));
					break;
				}
				RMDBGLOG((MONODBG, "Successfully read %lu bytes of HDCP SRM in %s\n", size, path));
				err = DHValidateSRM(pDH, pSRM, &update);
				if (RMSUCCEEDED(err) && update) {
					err = Write_SRM(pSRM, size);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Error: Failed to store new HDCP SRM in flash memory!\n"));
					}
				}
			} else {
				RMDBGLOG((ENABLE, "Error: could not open HDCP SRM file %s\n", path));
				err = RM_ERROR;
			}
			break;
		}
	}
	RMCloseDirectory(directory);
	
	return err;
}

static inline RMascii *get_next_filename(void)
{
	static RMuint32 rec_depth = 0;
	RMdirectoryEntry entry;
	
	while( RMReadDirectory(directory[rec_depth], &entry) == RM_OK ){
		if(entry.name[0] == '.') /* skip . .. and hidden files */
			continue;
		path[path_index[rec_depth]] = '\0';
		RMAppendAscii (path, (RMascii*)entry.name);
		directory[rec_depth+1] = open_directory(path);
		if(directory[rec_depth+1] != NULL) {
			if((!mono_opt.recurse_dirs) || (rec_depth+1 >= MAX_DIR_RECURSION))
				continue;
			rec_depth++;
			RMAppendAscii (path, "/");
			path_index[rec_depth] = RMasciiLength(path);
			RMDBGLOG((MONODBG, "==============%s is a directory\n", entry.name));
			return get_next_filename();
		}
		else
			return path;
	}
	RMCloseDirectory(directory[rec_depth]);
	if(rec_depth) {
		rec_depth--;
		return get_next_filename();
	}

	return NULL;
}

static inline enum rfp_application get_app(struct rfp_stream_info *stream_info)
{
	switch(stream_info->system_type){
	case RM_SYSTEM_MPEG4:
		return APP_MP4;
	case RM_SYSTEM_ASF:
		return APP_ASF;
	case RM_SYSTEM_ELEMENTARY_VIDEO:
		switch(stream_info->video_type){
		case RM_VIDEO_MPEG12:
		case RM_VIDEO_MPEG4:
		case RM_VIDEO_H263:
		case RM_VIDEO_H264:
		case RM_VIDEO_WMV:
		case RM_VIDEO_VC1:
		case RM_VIDEO_DIVX3:
		case RM_VIDEO_DIVX4:
		case RM_VIDEO_XVID:
		case RM_VIDEO_MJPEG:
			return APP_VIDEO;
		case RM_VIDEO_BMP:
		case RM_VIDEO_TIFF:
		case RM_VIDEO_GIF:
		case RM_VIDEO_PNG:
			return APP_PICTURE;
		case RM_VIDEO_JPEG:
			switch(mono_opt.jpeg_decode){
			case mono_decode_soft:
				return APP_PICTURE;
			case mono_decode_hard:
				return APP_VIDEO;
			case mono_decode_auto:
				return APP_PICTURE;
			}
		case RM_VIDEO_UNKNOWN:
			break;
		}
		break;
	case RM_SYSTEM_ELEMENTARY_AUDIO:
		return APP_AUDIO;
	case RM_SYSTEM_MPEG1:
	case RM_SYSTEM_MPEG2_TRANSPORT:
	case RM_SYSTEM_MPEG2_TRANSPORT_192:
	case RM_SYSTEM_MPEG2_PROGRAM:
	case RM_SYSTEM_MPEG2_DVD:
		switch(mono_opt.demux_decode){
		case mono_decode_soft:
			return APP_DEMUX_SOFT;
		case mono_decode_hard:
			return APP_DEMUX;
		case mono_decode_auto:
			return APP_DEMUX;
		}
		break;
	case RM_SYSTEM_AVI:
		return APP_AVI;
	case RM_SYSTEM_MPEG2_DVD_AUDIO:
	case RM_SYSTEM_DIVX_MP3:
	case RM_SYSTEM_DIVX_AC3:
	case RM_SYSTEM_DIVX_MPEG1:
	case RM_SYSTEM_DIVX_PCM:
	case RM_SYSTEM_DIVX_WMA:
	case RM_SYSTEM_DIVX_WMV9_MP3:
	case RM_SYSTEM_DIVX_WMV9_AC3:
	case RM_SYSTEM_DIVX_WMV9_MPEG1:
	case RM_SYSTEM_DIVX_WMV9_PCM:
	case RM_SYSTEM_DIVX3_MP3:
	case RM_SYSTEM_DIVX3_AC3:
	case RM_SYSTEM_DIVX3_MPEG1:
	case RM_SYSTEM_DIVX3_PCM:
	case RM_SYSTEM_RIFFCDXA:
	case RM_SYSTEM_ID3:
	case RM_SYSTEM_UNKNOWN:
		break;
	}
	return NOT_SUPPORTED;
}

static inline RMstatus gui_enable_osd(RMbool enable)
{
	RMstatus err = RM_OK;
	
	if(enable && !osd_enabled){
		err = DCCSetSurfaceSource(dcc_info.pDCC, mono_opt.osd_scaler, mono_opt.osd_source);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set the surface source %d\n", err));
			return RM_ERROR;
		}

		err = DCCInsertPictureInMultiplePictureOSDVideoSource(mono_opt.osd_source, 0, 0);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot insert picture inside surface %d\n", err);
			return RM_ERROR;
		}

		osd_enabled = TRUE;
	}
	if(!enable && osd_enabled){
		DCCSetSurfaceSource(dcc_info.pDCC, mono_opt.osd_scaler, NULL);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set the surface source %d\n", err));
			return RM_ERROR;
		}
		osd_enabled = FALSE;
	}
	return RM_OK;
}

static inline RMstatus gui_show_stream_info(RMascii *filename, struct rfp_stream_info *stream_info)
{    
	RtkPoint point;
	RtkProp prop;
	RMascii filename_copy[256], *basename,  *tmp, *audio_type_string = NULL;

	RMstatus err;

	RMCopyAscii(filename_copy, play_opt.filename); /* if too long, will need to be modified */
	basename = filename_copy;
	while(RMFindAsciiCharacter (basename, '/', &tmp))
		basename = ++tmp;
	if(RMasciiLength(basename)>30){
		basename[27] = '\0';
		RMAppendAscii (basename, "...");
	}
	switch(stream_info->audio_type){
	case eAudioFormat_MPEG1:
		audio_type_string = "MPEG1";
		break;
	case eAudioFormat_MPEG2:
		audio_type_string = "MPEG2";
		break;
	case eAudioFormat_AC3:
		audio_type_string = "AC3";
		break;
	case eAudioFormat_PCM:
		audio_type_string = "PCM";
		break;
	case eAudioFormat_DTS:
		audio_type_string = "DTS";
		break;
	case eAudioFormat_DVD_AUDIO:
		audio_type_string = "DVD AUDIO";
		break;
	case eAudioFormat_REVERSE_PCM:
		audio_type_string = "Reverse PCM";
		break;
	case eAudioFormat_AAC:
		audio_type_string = "AAC";
		break;
	case eAudioFormat_AAC_DSI:
		audio_type_string = "AAC with DSI";
		break;
	case eAudioFormat_AAC_ADIF:
		audio_type_string = "AAC ADIF";
		break;
	case eAudioFormat_AAC_ADTS:
		audio_type_string = "AAC ADTS";
		break;
	case eAudioFormat_AAC_LATM:
		audio_type_string = "AAC LATM";
		break;
	case eAudioFormat_MPEG1_LAYER3:
		audio_type_string = "MPEG1 Layer 3";
		break;
	case eAudioFormat_MPEG2_LAYER1:
		audio_type_string = "MPEG2 Layer 1";
		break;
	case eAudioFormat_MPEG2_LAYER2:
		audio_type_string = "MPEG2 Layer 2";
		break;
	case eAudioFormat_MPEG2_LAYER3:
		audio_type_string = "MPEG2 Layer 3";
		break;
	case eAudioFormat_WMA:
		audio_type_string = "WMA";
		break;
	case eAudioFormat_WMAPRO:
		audio_type_string = "WMA PRO";
		break;
	case eAudioFormat_WMATS:
		audio_type_string = "WMATS";
		break;
	case eAudioFormat_UNKNOWN:
		audio_type_string = "Unknown";
		break;
	}

	prop.lineWidth = 0;
	prop.fgColor = 0xff000000;
	RMFRTKDrawRect(mono_opt.rtk, &mono_opt.osd_rect, &prop);


	point.x = 64;
	point.y = 90;
	RMFRTKDrawString(mono_opt.rtk, "Now playing file:", &point, &info_face, NULL);
	point.y += info_face.scale;
	RMFRTKDrawString(mono_opt.rtk, basename, &point, &data_face, NULL);
	point.y += data_face.scale;
	RMFRTKDrawString(mono_opt.rtk, "Audio Type:", &point, &info_face, NULL);
	point.y += info_face.scale;
	RMFRTKDrawString(mono_opt.rtk, audio_type_string, &point, &data_face, NULL);
	point.y += data_face.scale;



	/* for mp3, try to display the id3 tag fields */
	if((stream_info->system_type == RM_SYSTEM_ELEMENTARY_AUDIO) &&
	   (stream_info->audio_type == eAudioFormat_MPEG1_LAYER3)){
		RMID3v1Tag id3_tag;
		RMuint8 buf[1024];
		RMuint32 count;
		RMfile file;
		struct stream_options_s stream_options;
		init_stream_options(&stream_options);
	
		file = open_stream(filename, RM_FILE_OPEN_READ, &stream_options);
		if (file == NULL) {
			RMDBGLOG((ENABLE, "Cannot open file %s\n", filename));
			return RM_ERROR;
		}
	
		if (RMSeekFile(file, -512, RM_FILE_SEEK_END) != RM_OK) {
			RMDBGLOG((ENABLE, "seeking file to the last 1Kb\n"));
			return RM_ERROR;
		}

		err = RMReadFile(file, buf, 512, &count);
		if(RMFAILED(err)){
			RMDBGLOG((ENABLE, "Cannot read form file\n"));
			return RM_ERROR;
		}

		RMCloseFile(file);

		err = RMReadID3v1(buf, 512, &id3_tag);
		if(err == RM_OK){
			RMFRTKDrawString(mono_opt.rtk, "Song Title:", &point, &info_face, NULL);
			point.y += info_face.scale;
			RMFRTKDrawString(mono_opt.rtk, id3_tag.Title, &point, &data_face, NULL);
			point.y += data_face.scale;
			RMFRTKDrawString(mono_opt.rtk, "Artist:", &point, &info_face, NULL);
			point.y += info_face.scale;
			RMFRTKDrawString(mono_opt.rtk, id3_tag.Artist, &point, &data_face, NULL);
			point.y += data_face.scale;
			RMFRTKDrawString(mono_opt.rtk, "Album:", &point, &info_face, NULL);
			point.y += info_face.scale;
			RMFRTKDrawString(mono_opt.rtk, id3_tag.Album, &point, &data_face, NULL);
			point.y += data_face.scale;
			RMFRTKDrawString(mono_opt.rtk, "Comment:", &point, &info_face, NULL);
			point.y += info_face.scale;
			RMFRTKDrawString(mono_opt.rtk, id3_tag.Comment, &point, &data_face, NULL);
			point.y += data_face.scale;
		}


		if(err == RM_OK){
			fprintf(stderr, "title %s\nartist %s\nalbum %s\ntrack %d\nyear %s\ngenre %d\ncomment %s\n", 
				id3_tag.Title, 
				id3_tag.Artist, 
				id3_tag.Album,
				id3_tag.Track, 
				id3_tag.Year, 
				id3_tag.Genre, 
				id3_tag.Comment);
		}
	}
	return RM_OK;
}
	

static inline void gui_show_filename()
{

	RtkPoint point;
	RtkProp prop;
	RMascii filename_copy[256], *basename,  *tmp;
	
	/* erase last filename */
	prop.lineWidth = 0;
	prop.fgColor = 0xff000000;
	RMFRTKDrawRect(mono_opt.rtk, &mono_opt.osd_rect, &prop);



	RMCopyAscii(filename_copy, play_opt.filename); /* if too long, will need to be modified */
	basename = filename_copy;
	while(RMFindAsciiCharacter (basename, '/', &tmp))
		basename = ++tmp;
	if(RMasciiLength(basename)>30){
		basename[27] = '\0';
		RMAppendAscii (basename, "...");
	}
	point.x = 64;
	point.y = 300;
	RMFRTKDrawString(mono_opt.rtk , basename, &point, &data_face, NULL);
	RMDBGLOG((MONODBG, "-----> about to play %s\n", basename));
	point.x = 64;
	point.y = 256;
	RMFRTKDrawString(mono_opt.rtk , "Press q to quit, N to skip, p to play:", &point,  &info_face, NULL);

}


static inline RMstatus gui_init_osd()
{

	Rtk86Handle handle;
	RMstatus err;
	struct osd_picture_info osd_picture = {0};
	osd_picture.scaler = 0;
	osd_picture.route = DCCRoute_Main;
	osd_picture.enable = TRUE;
	osd_picture.filename = "mono.bmp";
	osd_picture.dramblock = 0;
	osd_picture.alpha = 128;
	osd_picture.alpha_merge = FALSE;
	osd_picture.zoom = FALSE;
	osd_picture.color_space = EMhwlibColorSpace_None;
	osd_picture.orientation = FRTop_FCLeft;
	set_default_out_window(&(osd_picture.source_window));
	set_default_out_window(&(osd_picture.output_window));
	
	err = DCCGetScalerModuleID(dcc_info.pDCC, osd_picture.route, DCCSurface_OSD, osd_picture.scaler, &(mono_opt.osd_scaler));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get surface to display OSD source %d\n", err));
		return err;
	}
	
	
	err = apply_osd_picture(&dcc_info, &osd_picture, NULL, &(mono_opt.osd_source));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot open osd source %s\n", RMstatusToString(err)));
		return err;
	}


	handle.pOSDSource = mono_opt.osd_source;
	handle.pRUA = dcc_info.pRUA;
	mono_opt.rtk = RMFRTKOpen(&handle);
	{
		RMnonAscii *naname = RMnonAsciiFromAscii("Vera.ttf");
		err = RMFRTKLoadFontFile( mono_opt.rtk, naname);
		RMFreeNonAscii(naname);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot load font file \'Vera.ttf\': %s\n", RMstatusToString(err));
			return err;
		}
	}

	mono_opt.osd_rect.x = 50;
	mono_opt.osd_rect.y = 90;
	mono_opt.osd_rect.width = 620;
	mono_opt.osd_rect.height = 350;

	osd_enabled = TRUE;

	return RM_OK;
}


static inline RMstatus init_dcc_info()
{
	RMstatus err;

	err = RUACreateInstance(&(dcc_info.pRUA), play_opt.chip_num);
	if (RMFAILED(err)) {
		RMDBGLOG((MONODBG, "Error creating RUA instance! %d\n", err));
		return err;
	}

	err = DCCOpen(dcc_info.pRUA, &(dcc_info.pDCC));
	if (RMFAILED(err)) {
		RMDBGLOG((MONODBG, "Error Opening DCC! %d\n", err));
		return err;
	}

	if (!play_opt.noucode) {
		err = DCCInitMicroCodeEx(dcc_info.pDCC, disp_opt.init_mode);
		if (RMFAILED(err)) {
			RMDBGLOG((MONODBG, "Cannot initialize microcode %d\n", err));
			return err;
		}
	}


	dcc_info.chip_num = play_opt.chip_num;
	dcc_info.route = DCCRoute_Main;

	// comment the following line to compile this file under em8620branch
	disp_opt.dh_info->pDH = NULL;
	return RM_OK;
}


static void show_usage(char *progname)
{
	fprintf(stderr, "MONO OPTIONS\n"
		"\t-forceSD: SD profile used instead of HD\n"
		"\t-R: If filename is a directory, play its sub-directories recursively\n"
		"\t-nogui: don't display the GUI (defaut is yes)\n"
		"\t-demux <soft|hard|auto>: Set demuxing method (default is auto)\n"
		"\t-jpeg <soft|hard|auto>: Set jpeg decompression method (default is auto)\n"
		"\t-cc <tv|soft|608soft|708soft>: Selects the closed caption display mode.\n"
		"\t-sat: send audio while in trickmode (default is not to send it)\n"
		"\t-displayerror <threshold>: sets display error threshold [0]\n"
		"\t-err_prop_threshold <threshold> : sets anchor error propagation threshold\n"
		"\t-err_prop_length <length> : sets anchor error propagation length\n"
		);

	show_playback_options();
	show_display_options();

	fprintf(stderr, "------------------------------------------------m-0-n-o-----\n");
	fprintf(stderr, "Minimum cmd line: %s filename [remote control device (Ex: /dev/ttyS0)] \n", progname);
	fprintf(stderr, "------------------------------------------------------------\n");
	exit(1);
}

static void parse_cmdline(int argc, char *argv[], struct mono_info *opts)
{
	int i;
	RMstatus err;

	// FIXME: temp soln to "internal error--unrecognizable insn"
	// moved 'app_params.noDolby = FALSE' from main() to here
	opts->noDolby = FALSE;
	if (argc < 2) 
		show_usage(argv[0]);
	i = 1;
	while ((argc > i)) {
		/* RMDBGLOG((ENABLE,"Arg %d : %s\n", i, argv[i])); */
		err = RM_OK;

		if (argv[i][0] != '-') {
			if (filename == NULL) {
				filename = argv[i];
				i++;
			}
			else if (remote_dev == NULL) {
				remote_dev = argv[i];
				i++;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-R")) {
			mono_opt.recurse_dirs = TRUE;
			i++;
		}
		else if ( ! strcmp(argv[i], "-nogui")) {
			mono_opt.use_gui = FALSE;
			i++;
		}
		else if ( ! strcmp(argv[i], "-use_multiple_audio")) {
			if (argc > i+1) {
				RMuint32 instances;
				RMasciiToUInt32(argv[i+1], &instances);
				i += 2;

				if ((instances > MAX_AUDIO_DECODER_INSTANCES) || (instances <= 0))
					show_usage(argv[0]);

				mono_opt.audio_instances = instances;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-demux")) {
			if (argc > i+1) {
				if( ! strcmp(argv[i+1], "soft")) {
					mono_opt.demux_decode = mono_decode_soft;
				}
				else if( ! strcmp(argv[i+1], "hard")) {
					mono_opt.demux_decode = mono_decode_hard;
				}
				else if( ! strcmp(argv[i+1], "auto")) {
					mono_opt.demux_decode = mono_decode_auto;
				}
				else{
					show_usage(argv[0]);
				}
				i+=2;
			}
		}
		else if ( ! strcmp(argv[i], "-jpeg")) {
			RMDBGLOG((ENABLE, "jpeg, and next is %s\n", argv[i+1]));
			if (argc > i+1) {
				if( ! strcmp(argv[i+1], "soft")) {
					mono_opt.jpeg_decode = mono_decode_soft;
				}
				else if( ! strcmp(argv[i+1], "hard")) {
					mono_opt.jpeg_decode = mono_decode_hard;
				}
				else if( ! strcmp(argv[i+1], "auto")) {
					mono_opt.jpeg_decode = mono_decode_auto;
				}
				else{
					show_usage(argv[0]);
				}
				i+=2;
			}
			else{
				show_usage(argv[0]);
			}
		}
		else if ( ! strcmp(argv[i], "-sw")) {
			mono_opt.demux_decode = mono_decode_soft;
			i++;
		}
		else if ( ! strcmp(argv[i], "-forceSD")) {
			mono_opt.force_sd = TRUE;
			i++;
		}
		else if (! strcmp(argv[i], "-nodolby")) {
			 opts->noDolby = TRUE; 
			 i++;
		}
		else if ( ! strcmp(argv[i], "-past")) {
			opts->play_opt->require_video_audio = FALSE;
			i++;
		}
		else if ( ! strcmp(argv[i], "-disk_control")) {
			/* from bug #4005 comment #18:

			   for disk_ctrl_low_level i assume that i takes about 1 second to resume the harddisk, which gives 16
			   blocks at a blocksize of 128 kb at 2 mb/s stream.
			*/
			opts->play_opt->disk_ctrl_state = DISK_CONTROL_STATE_RUNNING;
			opts->play_opt->disk_ctrl_low_level = 16;
			opts->play_opt->prebuf_max = 1024 * 1024;
			fprintf(stderr, ">> disk control enabled, low level is %lu, prebuf_max is %lu bytes\n",
				opts->play_opt->disk_ctrl_low_level,
				opts->play_opt->prebuf_max);

			i++;
		}
		else if ( ! strcmp(argv[i], "-max_mem")) {
			if (argc > i+1) {
				RMasciiToUInt32(argv[i+1], &(opts->play_opt->disk_ctrl_max_mem));
				opts->play_opt->disk_ctrl_max_mem *= 1024;

				i += 2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-max_usable_RUA_mem")) {
			if (argc > i+1) {
				RMasciiToUInt32(argv[i+1], &(opts->play_opt->max_usable_RUA_mem));
				opts->play_opt->max_usable_RUA_mem *= 1024;

				i += 2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-block_size")) {
			if (argc > i+1) {
				RMasciiToUInt32(argv[i+1], &(opts->play_opt->disk_ctrl_log2_block_size));
				i += 2;
			}
			else
				show_usage(argv[0]);
		}
		else if (! strcmp(argv[i], "-cc")) {
			if (argc > i+1) {
				if (RMCompareAscii(argv[i+1], "tv")) {
					mono_opt.display_cc = TRUE;
					mono_opt.use_soft_cc_decoder = 0;
				}
				else if (RMCompareAscii(argv[i+1], "soft") || 
					 RMCompareAscii(argv[i+1], "608soft") ||
					 RMCompareAscii(argv[i+1], "cc1")) {
					mono_opt.display_cc = TRUE;
					mono_opt.use_soft_cc_decoder = 1;
					mono_opt.cc_select = EMhwlibCCSelect_CC1;
				}
				else if(RMCompareAscii(argv[i+1], "cc2") ){
					mono_opt.display_cc = TRUE;
					mono_opt.use_soft_cc_decoder = 1;
					mono_opt.cc_select = EMhwlibCCSelect_CC2;
				}
				else if(RMCompareAscii(argv[i+1], "cc3") ){
					mono_opt.display_cc = TRUE;
					mono_opt.use_soft_cc_decoder = 1;
					mono_opt.cc_select = EMhwlibCCSelect_CC3;
				}
				else if(RMCompareAscii(argv[i+1], "cc4") ){
					mono_opt.display_cc = TRUE;
					mono_opt.use_soft_cc_decoder = 1;
					mono_opt.cc_select = EMhwlibCCSelect_CC4;
				}
				else if(RMCompareAscii(argv[i+1], "708soft")) {
					mono_opt.display_cc = TRUE;
					mono_opt.use_soft_cc_decoder = 2;
				}
				else if(RMCompareAscii(argv[i+1], "off")) {
					mono_opt.display_cc = FALSE;
				}
				else {
					show_usage(argv[0]);
				}
				
				i += 2;
			}
			else 
				show_usage(argv[0]);
		}
		else if (!strcmp(argv[i], "-displayerror")) {
			if (argc > i+1) {
				RMasciiToUInt32(argv[i+1], &(mono_opt.display_error_threshold));
				i += 2;
			}
			else 
				show_usage(argv[0]);
		}
		else if (!strcmp(argv[i], "-err_prop_threshold")) {
			if (argc > i+1) {
				RMasciiToUInt32(argv[i+1], &(mono_opt.AnchorErrPropagationThreshold));
				i += 2;
			}
			else 
				show_usage(argv[0]);
		}
		else if (!strcmp(argv[i], "-err_prop_length")) {
			if (argc > i+1) {
				RMasciiToUInt32(argv[i+1], &(mono_opt.AnchorErrPropagationLength));
				i += 2;
			}
			else 
				show_usage(argv[0]);
		}
		else {
			err = parse_playback_cmdline(argc, argv, &i, &play_opt);
			if (err == RM_ERROR)
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_display_cmdline(argc, argv, &i, &disp_opt);
			if (err == RM_ERROR)
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_video_cmdline(argc, argv, &i, &video_opt);
			if (err == RM_ERROR)
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
		}
		
		if (err == RM_PENDING) 
			show_usage(argv[0]);
		
	}
	if (filename == NULL){
		show_usage(argv[0]);
	}

	if (opts->play_opt->disk_ctrl_low_level) {
		if ((!opts->play_opt->disk_ctrl_max_mem) || (!opts->play_opt->disk_ctrl_log2_block_size)) {
			    fprintf(stderr, "**** disk control enabled, but not all required parameters where specified!\n\n\n\n");
			    show_usage(argv[0]);
		}
	}

}

RMbool RMPlayNonInterleavedAVI(void)
{
	RMascii key;
	RMbool confirm = FALSE;
	RtkRect rect;
	RtkPoint point;
	RtkProp prop;
	if (!mono_opt.use_gui){
		return TRUE;
	}

	/* erase whatever there was on the osd (except the logo) */
	prop.lineWidth = 0;
	prop.fgColor = 0xff000000;
	RMFRTKDrawRect(mono_opt.rtk, &mono_opt.osd_rect, &prop);

	point.x = 64;
	point.y = 200;
	RMFRTKDrawString(mono_opt.rtk , "Warning: non-interleaved AVI file. Play anyways?", &point,  &info_face, &rect);

	gui_enable_osd(TRUE);	
 get_key:
	key = RMGetKey();
		
	switch(key){
	case KEY_CMD_QUIT:
	case KEY_CMD_NEXT_TRACK:
		confirm = FALSE;
		break;
	case KEY_CMD_PLAY:
	case KEY_CMD_PAUSE:
		confirm = TRUE;
		break;
	default:
		RMDBGLOG((ENABLE, "Unknown command %c (%d), try again\n", key, key));
		goto get_key;
		break;
		}

	gui_enable_osd(FALSE);
	return confirm;
}

static struct playback_cmdline local_play_opt;
static struct video_cmdline local_video_opt;
static struct display_cmdline local_disp_opt;
static struct demux_cmdline local_demux_opt;
static struct mono_context local_mono_opt;
static struct dcc_context local_dcc_info;

static RMbool open_path() 
{
	RMbool is_directory = FALSE;
	directory[0] = open_directory(filename);
 	if(directory[0] != NULL) {
		RMDBGLOG((MONODBG, "%s is a directory\n", filename));
		is_directory = TRUE;
		RMCopyAscii (path, filename);
		if(path[RMasciiLength(path)-1] != '/')
			RMAppendAscii (path, "/");
		path_index[0] = RMasciiLength(path);
		play_opt.filename = get_next_filename();
	}
	else
		play_opt.filename = filename;
	return is_directory;
}

static RMstatus play_file_app(
	struct mono_info *app_params, 
	enum rfp_application app
)
{
	RMuint32 i;
	
	RMDBGLOG((ENABLE, "instances %lu\n", mono_opt.audio_instances));
	app_params->audio_opt[0].audioInstances = mono_opt.audio_instances;

	/* 
	   replicate audio_opt[0] which was filled by rfp_detect to the rest of the audio instances;
	   setup engineID and decoderID accordingly, and restore data lost during replication
	*/
	for (i = 1; i < mono_opt.audio_instances; i++) {
		RMMemcpy(&(app_params->audio_opt[i]), &(app_params->audio_opt[0]), sizeof(struct audio_cmdline));

		// we have to restore these settings according to set_audio_options
		app_params->audio_opt[i].thisAudioInstance = i; 
		app_params->audio_opt[i].audioInstances = mono_opt.audio_instances;
		//app_params->audio_opt[i].dh_info = &dh_info;

		// setup engineID and decoderID
		switch (i) {
		case 1:
			// this is the second instance, assign it to engine 1, decoder 0 (the first instance is default engine=0 decoder=0)
			app_params->audio_opt[i].AudioEngineID = 1;
			app_params->audio_opt[i].AudioDecoderID = 0;
			break;
		case 2:
			// this is the third instance, assign it to engine 0, decoder 1
			app_params->audio_opt[i].AudioEngineID = 0;
			app_params->audio_opt[i].AudioDecoderID = 1;
			break;
		case 3:
			// this is the fourth instance, assign it to engine 1, decoder 1
			app_params->audio_opt[i].AudioEngineID = 1;
			app_params->audio_opt[i].AudioDecoderID = 1;
			break;
		default:
			fprintf(stderr, "error when replicating %lu audio instances\n", mono_opt.audio_instances);
			break;
		}
	}

	print_parsed_audio_options(app_params->audio_opt);

	/* in case we use psfdemux, force some STC/PTS delay */
	if ((app == APP_DEMUX) && (app_params->play_opt->video_delay_ms == 0)) {
		app_params->play_opt->video_delay_ms = 500;
		app_params->play_opt->audio_delay_ms = 500;
	}

	return rfp_play(app_params, app);
}

static void init_globals()
{
	/* Init static global variables in case we are used in a library, and
	 * it is not the first call */
	filename = NULL;
	remote_dev = NULL;
	rh = (RMremoteHandle) NULL;
	RMMemset(&dcc_info, 0, sizeof(dcc_info));
	RMMemset(&play_opt, 0, sizeof(play_opt));
	RMMemset(&video_opt, 0, sizeof(video_opt));
	RMMemset(&disp_opt, 0, sizeof(disp_opt));
	RMMemset(&mono_opt, 0, sizeof(mono_opt));
	RMMemset(&demux_opt, 0, sizeof(demux_opt));

	init_playback_options(&play_opt);
	init_video_options(&video_opt);
	init_display_options(&disp_opt);

	mono_opt.recurse_dirs = FALSE;
	mono_opt.use_gui = TRUE;

	mono_opt.demux_decode = mono_decode_auto;
	mono_opt.jpeg_decode = mono_decode_auto;
	mono_opt.force_sd = FALSE;
	mono_opt.display_cc = TRUE;
	mono_opt.cc_select = EMhwlibCCSelect_CC1;
	mono_opt.use_soft_cc_decoder = 0;
	mono_opt.audio_instances = 1;

	mono_opt.display_error_threshold = 0;
	mono_opt.AnchorErrPropagationThreshold = 500;
	mono_opt.AnchorErrPropagationLength = 13;
}

int main(int argc, char **argv)
{
	RMstatus err;
	remoteHandleType *handle = (remoteHandleType *) NULL;
	RMbool is_directory = FALSE;
	int error = 0;
	struct rfp_detect_options detect_opt;
	enum rfp_application app = NOT_SUPPORTED;
	struct mono_info app_params;
	struct rfp_stream_info stream_info;
	RMuint32 SRM_Size;
	RMuint8 SRM[SRM_SIZE];

	// comment the following line to compile this file under em8620branch
	struct dh_context dh_info;
	
	struct audio_cmdline audio_options[MAX_AUDIO_DECODER_INSTANCES]; /*access through audio_opt*/

	RMuint32 i;
	
	init_globals();
	// Initialize the HTTP stream options data structure
	init_stream_options(&app_params.stream_opts);

	app_params.play_opt = &play_opt;
	app_params.video_opt = &video_opt;
	app_params.demux_opt = &demux_opt;
	app_params.disp_opt = &disp_opt;
	app_params.audio_opt = audio_options;
	
	// comment the following lines to compile this file under em8620branch
	RMMemset(&dh_info, 0, sizeof(dh_info));
	disp_opt.dh_info = &dh_info;
	for (i = 0; i < MAX_AUDIO_DECODER_INSTANCES; i++)
		audio_options[i].dh_info = &dh_info;
	
	dh_info.pSRM = SRM;
	SRM_Size = SRM_SIZE;
	err = Read_SRM(dh_info.pSRM, &SRM_Size);

	parse_cmdline(argc, argv, &app_params);

	RMDBGLOG((ENABLE, ">>> Mono will be using %lu audio instances\n", mono_opt.audio_instances));

	app_params.osd_scaler = 0;
	app_params.video_scaler = disp_opt.video_scaler;

	err = init_dcc_info();
	if (RMFAILED(err)) {
		RMDBGLOG((MONODBG, "Could not create RUA and DCC handles %d\n", err));
		return -1;
	}
	dcc_info.dh_info = &dh_info;

	err = apply_playback_options(&dcc_info, &play_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((MONODBG, "Cannot set playback options %d\n", err));
		ERROR_CLEANUP(-1);
	}
	
	if (remote_dev != NULL) {
		if (RMlocalRemoteOpen(remote_dev,&handle) != RM_OK) {
			RMDBGLOG((MONODBG,"Cannot open remote control \"%s\"\n",remote_dev));
			ERROR_CLEANUP(-1);
		}
		rh = RMFremoteOpenEx((void *)handle, PseudoFileReadWithTimeout, RMFlushCallback, RMSleepCallback, PseudoFileAvailable);
		if (rh != 0){
			printf("remote device %s successfully opened\n", remote_dev);
		}
		else {
			RMDBGLOG((MONODBG,"Cannot open remote control \"%s\"\n",remote_dev));
			RMlocalRemoteClose(&handle);
			ERROR_CLEANUP(-1);
		}
	}
	err = DCCGetScalerModuleID(dcc_info.pDCC, dcc_info.route, DCCSurface_Video, app_params.video_scaler, &(dcc_info.SurfaceID));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get surface to display video source %d\n", err));
		ERROR_CLEANUP(-1);
	}

	err = apply_display_options(&dcc_info, &disp_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((MONODBG, "Cannot set display options %d\n", err));
		ERROR_CLEANUP(-1);
	}
	
	if (mono_opt.use_gui){
		err = gui_init_osd();
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot init osd\n");
			ERROR_CLEANUP(-1);
		}
	} else {
		// Give HDMI sink 1/2 Sec to set up
		RMuint32 i;
		for (i = 0; i < 25; i++) {
			RMMicroSecondSleep(20 * 1000);
			update_hdmi(&dcc_info, app_params.disp_opt, app_params.audio_opt);
		}
	}
	
	//init_doubleBuffer_OSD();

	app_params.pRUA = dcc_info.pRUA;
	app_params.pDCC = dcc_info.pDCC;

	// Check for HDCP.SRM file in root of medium
	dh_info.pSRM = SRM;
	Update_SRM(filename, dh_info.pDH, dh_info.pSRM);
	
	is_directory = open_path();
	if (play_opt.filename == NULL) {
		RMDBGLOG((MONODBG, "No files found on directory\n"));
		ERROR_CLEANUP(-1);
	}

	RMMemcpy(&local_dcc_info, &dcc_info, sizeof(dcc_info));
	RMMemcpy(&local_play_opt, &play_opt, sizeof(play_opt));
	RMMemcpy(&local_video_opt, &video_opt, sizeof(video_opt));
	RMMemcpy(&local_disp_opt, &disp_opt, sizeof(disp_opt));
	RMMemcpy(&local_mono_opt, &mono_opt, sizeof(mono_opt));
	RMMemcpy(&local_demux_opt, &demux_opt, sizeof(demux_opt));

 new_filename:
	RMMemcpy(&video_opt, &local_video_opt, sizeof(video_opt));
	init_audio_options2(app_params.audio_opt, MAX_AUDIO_DECODER_INSTANCES);
	if (video_opt.UseAFD) {
		apply_active_format(dcc_info.pRUA, &disp_opt, video_opt.afd, dcc_info.SurfaceID);
	}
	
	/* set cc options after video init */
	{
		video_opt.display_cc = mono_opt.display_cc;
		video_opt.use_soft_cc_decoder = mono_opt.use_soft_cc_decoder;
		video_opt.cc_select = mono_opt.cc_select;
		video_opt.display_error_threshold = mono_opt.display_error_threshold;
		video_opt.anchor_error_parms.AnchorErrPropagationThreshold = mono_opt.AnchorErrPropagationThreshold;
		video_opt.anchor_error_parms.AnchorErrPropagationLength = mono_opt.AnchorErrPropagationLength;
	}

	RMTermInit(TRUE);
	RMSignalInit(NULL, NULL);

	if (mono_opt.use_gui){
		RMascii key = 0;
		gui_show_filename();
		gui_enable_osd(TRUE);
	
	get_key:
		while (! RMKeyAvailable()) {
			update_hdmi(&dcc_info, app_params.disp_opt, app_params.audio_opt);
		}
		key = RMGetKey();
		
		switch(key){
		case KEY_CMD_QUIT:
			RMTermExit();
			goto cleanup;
			break;
		case KEY_CMD_NEXT_TRACK:
			goto next_file;
			break;
		case KEY_CMD_PLAY:
		case KEY_CMD_PAUSE:
			RMremoteResetState();
			break;
		default:
			RMDBGLOG((ENABLE, "Unknown command, try again\n"));
			goto get_key;
			break;
		}
	
	}

	/* keep compatibility with deprecated player_conf struct */
	detect_opt.force_sd = mono_opt.force_sd;

	/* #### Begin DTCP code #### */
	// Parse the URL searching for DTCP parameters.
	// If found, initialize the DTCP subsystem.
	err = init_DTCP_session(((struct dtcp_cookie**)(&app_params.dtcpCookieHandle)),
				&app_params.stream_opts,
				app_params.pRUA,
				play_opt.filename,
				FALSE);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot initialize or check for DTCP-IP session correctly !!!\n");
		goto cleanup;
	}
	/* #### End DTCP code #### */

	err = rfp_detect(&app_params, &detect_opt, &app, &stream_info);
	if(RMFAILED(err)){
		RMDBGLOG((ENABLE, "Detection failed\n"));

		if (!mono_opt.recurse_dirs) {
			RMTermExit();
			ERROR_CLEANUP(-1);
		}
		else {
			RMDBGLOG((MONODBG, "skip file %s\n", play_opt.filename));
			goto next_file;
		}
	}

	/* it's up to mono (not rfp) to decide which app to use for each format */
	app = get_app(&stream_info);
 
	if(app == NOT_SUPPORTED){
		RMDBGLOG((MONODBG, "Could not play file, error %d\n", err));
		if (!mono_opt.recurse_dirs) {
			RMTermExit();
			ERROR_CLEANUP(-1);
		}
		else {
			RMDBGLOG((MONODBG, "skip file %s\n", play_opt.filename));
			goto next_file;
		}
	}
	
	if (mono_opt.use_gui) {
		if(app == APP_AUDIO){
			gui_show_stream_info(play_opt.filename, &stream_info);
		} else {
			gui_enable_osd(FALSE);
		}
	}
	
	if((app == APP_VIDEO) && (stream_info.video_type == RM_VIDEO_JPEG)){
		app_params.play_opt->waitexit = TRUE;
	}


	app_params.audio_opt[0].dh_info = &dh_info;

	err = play_file_app(&app_params, app);
	if (err == RM_DRM_PREVENTS_PLAYBACK)
		fprintf(stderr, "DRM prevents this file's playback, skipping\n");
	else if(RMFAILED(err)){
		RMTermExit();
		RMDBGLOG((ENABLE, "Could not play file %d\n", err));
		ERROR_CLEANUP(-1);
	}
	
 next_file:
	RMTermExit();
	if(is_directory){
		RMMemcpy(&dcc_info, &local_dcc_info, sizeof(dcc_info));
		RMMemcpy(&play_opt, &local_play_opt, sizeof(play_opt));
		//RMMemcpy(&disp_opt, &local_disp_opt, sizeof(disp_opt));
		//RMMemcpy(&mono_opt, &local_mono_opt, sizeof(mono_opt));
		RMMemcpy(&demux_opt, &local_demux_opt, sizeof(demux_opt));

		if((play_opt.filename = get_next_filename()) != NULL){
			goto new_filename;
		}
	}

 cleanup:

	if (is_directory) {
		RMCloseDirectory(directory[0]);
	}

	if (rh != 0)
		RMFremoteRelease(rh);
	
	if (handle != 0)
		RMlocalRemoteClose(&handle);

	//if (mono_opt.use_gui){
		if(mono_opt.rtk)
			RMFRTKClose(mono_opt.rtk);

		if (mono_opt.osd_source) {
			gui_enable_osd(FALSE);
			err = DCCCloseVideoSource(mono_opt.osd_source);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot close osd source %d\n", err));
				return err;
			}
		}

		if (mono_opt.pSPU_double_buffer_source) {
			RMDBGLOG((ENABLE, "close doubleBufferOSD\n"));
			err = DCCCloseVideoSource(mono_opt.pSPU_double_buffer_source);
			mono_opt.pSPU_double_buffer_source = NULL;
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot close SPU doubleBuffer source %d\n", err));
				return err;
			}
			
		}

		//}

	/* #### Begin DTCP code #### */
	if (app_params.dtcpCookieHandle) {
		err = term_DTCP_session(((struct dtcp_cookie*)(&app_params.dtcpCookieHandle)),
					app_params.pRUA);
		if (RMFAILED(err)) 
			fprintf(stderr, "Cannot close DTCP-IP session !!!\n");	
	}
	/* #### End DTCP code #### */
	
	err = clear_display_options(&dcc_info, &disp_opt);
	if (RMFAILED(err))
		RMDBGLOG((ENABLE, "Cannot clear display options %d\n", err));
	
	err = DCCClose(dcc_info.pDCC);
	if (RMFAILED(err))
		RMDBGLOG((ENABLE, "Cannot close DCC %d\n", err));

	err = RUADestroyInstance(dcc_info.pRUA);
	if (RMFAILED(err))
		RMDBGLOG((ENABLE, "Cannot destroy RUA instance %d\n", err));

	return error;
}

