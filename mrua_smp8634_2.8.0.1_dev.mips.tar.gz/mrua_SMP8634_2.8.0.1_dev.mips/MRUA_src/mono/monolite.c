#define ALLOW_OS_CODE 1

#include "../samples/common.h"


void RMDCCInfo(struct dcc_context *dcc_info)
{
/* 	nothing to do for mono */
}

/* this is the EOS callback, must be implemented by curacao */
void RMEOSCallback()
{
	/* mono doesnt do anything */
}


int main(int argc, char **argv)
{
	RMstatus err;
	struct mono_info app_params;
	struct playback_cmdline play_opt;
	struct display_cmdline disp_opt;
	struct video_cmdline video_opt;
	struct audio_cmdline audio_opt;
	struct player_options player_conf;
	struct dcc_context dcc_info = {0,};
	
	init_display_options(&disp_opt);
	init_playback_options(&play_opt);
	init_video_options(&video_opt);
	init_audio_options(&audio_opt);

	player_conf.forceSD = FALSE;
	player_conf.use_hwdemux = FALSE;
	
	if(argc != 2){
		RMDBGLOG((ENABLE, "Usage: %s <filename>\n", argv[0]));
		return -1;
	}
	play_opt.filename = argv[1];

	err = RUACreateInstance(&(dcc_info.pRUA), play_opt.chip_num);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error creating RUA instance! %d\n", err));
		return -1;
	}

	err = DCCOpen(dcc_info.pRUA, &(dcc_info.pDCC));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error Opening DCC! %d\n", err));
		return -1;
	}

	err = DCCInitMicroCodeEx(dcc_info.pDCC, disp_opt.init_mode);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot initialize microcode %d\n", err));
		return -1;
	}

	dcc_info.chip_num = play_opt.chip_num;
	dcc_info.pDH = NULL;
	dcc_info.route = DCCRoute_Main;

	err = apply_playback_options(&dcc_info, &play_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set playback options %d\n", err));
		return -1;
	}
	
	err = apply_display_options(&dcc_info, &disp_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set display options %d\n", err));
		return -1;
	}
	// give audio code access to info from display's EDID, to determine audio capabilities
	audio_opt.ppDBC = &(disp_opt.pDBC);
	audio_opt.pnDBC = &(disp_opt.nDBC);
	
	app_params.pRUA = dcc_info.pRUA;
	app_params.pDCC = dcc_info.pDCC;
	app_params.play_opt = &play_opt;
	app_params.video_opt = &video_opt;
	app_params.audio_opt = &audio_opt;

	err = play_file(&app_params, &player_conf);
	if(RMFAILED(err)){
		RMDBGLOG((ENABLE, "Could not play file %d\n", err));
		return -1;
	}

	err = clear_display_options(&dcc_info, &disp_opt);
	if (RMFAILED(err)){
		RMDBGLOG((ENABLE, "Cannot clear display options %d\n", err));
		return -1;
	}
	
	err = DCCClose(dcc_info.pDCC);
	if (RMFAILED(err)){
		RMDBGLOG((ENABLE, "Cannot close DCC %d\n", err));
		return -1;
	}

	err = RUADestroyInstance(dcc_info.pRUA);
	if (RMFAILED(err)){
		RMDBGLOG((ENABLE, "Cannot destroy RUA instance %d\n", err));
		return -1;
	}
	return 0;
}
