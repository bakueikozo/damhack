/*****************************************
 Copyright � 2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE 1

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>
#include <sys/time.h>

#include "../rmdef/rmdef.h"
#include "../rmremoteapi/include/rmremoteapi.h"
#include "rmlocalremote.h"

#ifndef EM86XX_REMOTE
static RMstatus RMPseudoFileSetRaw(RMint32 fd)
{
	struct termios newtermios;

        if (tcgetattr(fd,&newtermios)<0) {
		printf("RMPseudoFileSetRaw : failed tcgetattr\n");
		return RM_ERROR;
	}

	// all the basic magic for raw mode
	cfmakeraw(&newtermios);

	// input speed setting
	if (cfsetispeed(&newtermios,B1200)<0) {
		printf("RMPseudoFileSetRaw : failed cfsetispeed\n");
		return RM_ERROR;
	}

	// receive byte per byte
	newtermios.c_cc[VMIN] = 1;
        newtermios.c_cc[VTIME] = 0;
	
        /* You tell me why TCSAFLUSH. */
        if(tcsetattr(fd, TCSAFLUSH, &newtermios) < 0) {
		printf("RMPseudoFileSetRaw : failed newtermios\n");
		return RM_ERROR;
	}

	return RM_OK;
}
#endif

RMstatus RMlocalRemoteOpen(const RMascii *device, remoteHandleType **handle)
{
	int flags = O_RDONLY;

	*handle=(remoteHandleType *)RMMalloc(sizeof(remoteHandleType));

	(*handle)->fd=open(device, flags);

	if ((*handle)->fd <= 0) {
		printf("RMlocalRemoteOpen : Cannot open device %s \n", device);
		free(*handle);
		*handle = NULL;
		return RM_ERROR;
	}

#ifndef EM86XX_REMOTE
	if (RMPseudoFileSetRaw((*handle)->fd)!=RM_OK) {
		printf("Cannot exec RMPseudoFileSetRaw\n");
		free(*handle);
		*handle = NULL;
		return RM_ERROR;
	}
#endif
	return RM_OK;
}

RMint32 RMFlushCallback (void *fileHandle)
{
#ifndef EM86XX_REMOTE
	return tcflush(((remoteHandleType*)fileHandle)->fd,TCIOFLUSH);
#else
	return 0;
#endif
}

void RMlocalRemoteClose(remoteHandleType **handle)
{
	close((*handle)->fd);
	RMFree(*handle);
	*handle = NULL;
}

RMint32 PseudoFileReadWithTimeout(void *fileHandle,void *buf,RMuint32 count,RMint64 timeoutMicroSeconds)
{
	fd_set rfds;
	struct timeval tv, *tva;
	ssize_t res = 0;

	FD_ZERO(&rfds);
	FD_SET(((remoteHandleType*)fileHandle)->fd,&rfds);
	
	if (timeoutMicroSeconds==-1)
		tva=NULL;
	else {
		tv.tv_sec=timeoutMicroSeconds/1000000ULL;
		tv.tv_usec=timeoutMicroSeconds%1000000ULL;
		
		tva=&tv;
	}

	if (select(((remoteHandleType*)fileHandle)->fd+1, &rfds, NULL, NULL, tva) > 0) {
		res = read(((remoteHandleType*)fileHandle)->fd,buf,count);
		return(res > 0 ? res : 0);
	}
	else
		return 0;
}

RMbool PseudoFileAvailable(void *fileHandle)
{
	fd_set rfds;
	struct timeval tv, *tva;

	FD_ZERO(&rfds);
	FD_SET(((remoteHandleType*)fileHandle)->fd,&rfds);
	tv.tv_sec=0;
	tv.tv_usec=0;
	tva=&tv;
	
	return (select(((remoteHandleType*)fileHandle)->fd+1, &rfds, NULL, NULL, tva) > 0);
}

void RMSleepCallback(RMuint64 microsec)
{
	usleep (microsec);
}
