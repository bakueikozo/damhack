#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>

#define ALLOW_OS_CODE 1


#include "rmdef/rmdef.h"
#include "rmcore/include/rmcore.h"
#include "rmlibcw/include/rmlibcw.h"

#include "rmdetector3api/include/rmdetector3api.h"


#define DETECTION_THRESHOLD 512  // in KB

static RMuint32 g_nestingLevel = 0;
static RMuint32 g_currentRootStreamID = 0;


static RMuint8 *print_type(enum RMdetector3_streamType type)
{
	switch (type) {
	case RMdetector3_streamType_UNKNOWN:
		return (RMuint8 *)"unknown";
	case RMdetector3_streamType_ELEMENTARY_AUDIO:
		return (RMuint8 *)"elementary_audio";
	case RMdetector3_streamType_ELEMENTARY_VIDEO:
		return (RMuint8 *)"elementary_video";
	case RMdetector3_streamType_SYSTEM:
		return (RMuint8 *)"system";

	// pictures
	case RMdetector3_streamType_BMP:
		return (RMuint8 *)"bmp";
	case RMdetector3_streamType_JPEG:
		return (RMuint8 *)"jpeg";
	case RMdetector3_streamType_TIFF:
		return (RMuint8 *)"tiff";
	case RMdetector3_streamType_PNG:
		return (RMuint8 *)"png";
	case RMdetector3_streamType_GIF:
		return (RMuint8 *)"gif";

	// elementary audio
	case RMdetector3_streamType_AUDIO_AC3:
		return (RMuint8 *)"audio_ac3";
	case RMdetector3_streamType_AUDIO_ADIF:
		return (RMuint8 *)"audio_adif";
	case RMdetector3_streamType_AUDIO_ADTS:
		return (RMuint8 *)"audio_adts";
	case RMdetector3_streamType_AUDIO_DTS:
		return (RMuint8 *)"audio_dts";
	case RMdetector3_streamType_AUDIO_DVD:
		return (RMuint8 *)"audio_dvd";
	case RMdetector3_streamType_AUDIO_MPEG1:
		return (RMuint8 *)"audio_mpeg1";
	case RMdetector3_streamType_AUDIO_MPEG1_LAYER3:
		return (RMuint8 *)"audio_mpeg1_layer3";
	case RMdetector3_streamType_AUDIO_MPEG2:
		return (RMuint8 *)"audio_mpeg2";
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER1:
		return (RMuint8 *)"audio_mpeg2_layer1";
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER2:
		return (RMuint8 *)"audio_mpeg2_layer2";
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER3:
		return (RMuint8 *)"audio_mpeg2_layer3";
	case RMdetector3_streamType_AUDIO_PCM:
		return (RMuint8 *)"audio_pcm";
	case RMdetector3_streamType_AUDIO_REVERSE_PCM:
		return (RMuint8 *)"audio_reverse_pcm";
	case RMdetector3_streamType_AUDIO_WMA:
		return (RMuint8 *)"audio_wma";
	case RMdetector3_streamType_AUDIO_WMAPRO:
		return (RMuint8 *)"audio_wmapro";
	case RMdetector3_streamType_AUDIO_WMATS:
		return (RMuint8 *)"audio_wmats";
	case RMdetector3_streamType_AUDIO_LATM:
		return (RMuint8 *)"audio_wmats";

	// elementary video
	case RMdetector3_streamType_VIDEO_DIVX3:
		return (RMuint8 *)"video_divx3";
	case RMdetector3_streamType_VIDEO_DIVX4:
		return (RMuint8 *)"video_divx4";
	case RMdetector3_streamType_VIDEO_H263:
		return (RMuint8 *)"video_h263";
	case RMdetector3_streamType_VIDEO_H264:
		return (RMuint8 *)"video_h264";
	case RMdetector3_streamType_VIDEO_MJPEG:
		return (RMuint8 *)"video_mjpeg";
	case RMdetector3_streamType_VIDEO_MPEG12:
		return (RMuint8 *)"video_mpeg2";
	case RMdetector3_streamType_VIDEO_MPEG4:
		return (RMuint8 *)"video_mpeg4";
	case RMdetector3_streamType_VIDEO_VC1:
		return (RMuint8 *)"video_vc1";
	case RMdetector3_streamType_VIDEO_WMV:
		return (RMuint8 *)"video_wmv";
	case RMdetector3_streamType_VIDEO_XVID:
		return (RMuint8 *)"xvid";

	// system
	case RMdetector3_streamType_SYSTEM_ASF:
		return (RMuint8 *)"system_asf";
	case RMdetector3_streamType_SYSTEM_AVI:
		return (RMuint8 *)"system_avi";
	case RMdetector3_streamType_SYSTEM_DVD:
		return (RMuint8 *)"system_dvd";
	case RMdetector3_streamType_SYSTEM_ID3:
		return (RMuint8 *)"system_id3";
	case RMdetector3_streamType_SYSTEM_M1S:
		return (RMuint8 *)"system_m1s";
	case RMdetector3_streamType_SYSTEM_M2P:
		return (RMuint8 *)"system_m2p";
	case RMdetector3_streamType_SYSTEM_M2T:
		return (RMuint8 *)"system_m2t";
	case RMdetector3_streamType_SYSTEM_M2T_192:
		return (RMuint8 *)"system_m2t_192";
	case RMdetector3_streamType_SYSTEM_MP4:
		return (RMuint8 *)"system_mp4";
	case RMdetector3_streamType_SYSTEM_RIFFCDXA:
		return (RMuint8 *)"system_riff/cdxa";
	case RMdetector3_streamType_SYSTEM_RIFFWAVE:
		return (RMuint8 *)"system_riff/wave";
	}
	return (RMuint8 *)"unknown";
}



static void system_stream_callback(void *context, struct RM_Detection3_Specific_Info info, RMuint32 parentStreamID, RMuint32 streamID)
{
	RMuint32 i;

	if (parentStreamID == streamID)
		g_currentRootStreamID = streamID;

	if (parentStreamID != g_currentRootStreamID) {
		g_nestingLevel++;

		for (i = 0; i < g_nestingLevel; i++)
			fprintf(stderr, "\t");
	}

	g_currentRootStreamID = streamID;

	fprintf(stderr, "[%2lu %2lu ] %s\n", parentStreamID, streamID, print_type(info.type));

	// get specific data.

	switch (info.type) {
	case RMdetector3_streamType_UNKNOWN:
	case RMdetector3_streamType_ELEMENTARY_AUDIO:
	case RMdetector3_streamType_ELEMENTARY_VIDEO:
	case RMdetector3_streamType_SYSTEM:
		break;

	// elementary audio
	case RMdetector3_streamType_AUDIO_AC3:
	case RMdetector3_streamType_AUDIO_ADIF:
	case RMdetector3_streamType_AUDIO_ADTS:
	case RMdetector3_streamType_AUDIO_DTS:
	case RMdetector3_streamType_AUDIO_DVD:
	case RMdetector3_streamType_AUDIO_MPEG1: //unused?
	case RMdetector3_streamType_AUDIO_MPEG1_LAYER3:
	case RMdetector3_streamType_AUDIO_MPEG2: //unused?
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER1:
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER2:
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER3:
	case RMdetector3_streamType_AUDIO_PCM:
	case RMdetector3_streamType_AUDIO_REVERSE_PCM:
	case RMdetector3_streamType_AUDIO_WMA:
	case RMdetector3_streamType_AUDIO_WMAPRO:
	case RMdetector3_streamType_AUDIO_WMATS:
	case RMdetector3_streamType_AUDIO_LATM:
		break;

	// pictures
	case RMdetector3_streamType_BMP:
	case RMdetector3_streamType_JPEG:
	case RMdetector3_streamType_TIFF:
	case RMdetector3_streamType_PNG:
	case RMdetector3_streamType_GIF:
		break;

	// elementary video
	case RMdetector3_streamType_VIDEO_DIVX3:
	case RMdetector3_streamType_VIDEO_DIVX4:
	case RMdetector3_streamType_VIDEO_H263:
	case RMdetector3_streamType_VIDEO_H264:
	case RMdetector3_streamType_VIDEO_MJPEG:
	case RMdetector3_streamType_VIDEO_MPEG12:
	case RMdetector3_streamType_VIDEO_MPEG4:
	case RMdetector3_streamType_VIDEO_VC1:
	case RMdetector3_streamType_VIDEO_WMV:
	case RMdetector3_streamType_VIDEO_XVID:
		break;

	// system
	case RMdetector3_streamType_SYSTEM_ASF:
	case RMdetector3_streamType_SYSTEM_AVI:
	case RMdetector3_streamType_SYSTEM_DVD:
		break;

	case RMdetector3_streamType_SYSTEM_ID3:
		fprintf(stderr, "ID3: bitstream offset %lu\n", info.data.system.data.id3.bitstream_offset);
		break;
	case RMdetector3_streamType_SYSTEM_M1S:
	case RMdetector3_streamType_SYSTEM_M2P:
	case RMdetector3_streamType_SYSTEM_M2T:
	case RMdetector3_streamType_SYSTEM_M2T_192:
	case RMdetector3_streamType_SYSTEM_MP4:
	case RMdetector3_streamType_SYSTEM_RIFFCDXA:
	case RMdetector3_streamType_SYSTEM_RIFFWAVE:
		break;
	}


	return;
}

static void video_stream_callback(void *context, struct RM_Detection3_Specific_Info info, RMuint32 parentStreamID, RMuint32 streamID)
{
	RMuint32 i;

	if (parentStreamID == g_currentRootStreamID) {

		for (i = 0; i < g_nestingLevel + 1; i++)
			fprintf(stderr, "\t");
	}

	fprintf(stderr, "[%2lu %2lu ] %s", parentStreamID, streamID, print_type(info.type));

	if (!info.data.video.PID_INFO_VALID)
		fprintf(stderr, "\n");
	else
		fprintf(stderr, " (pid=%lu [0x%lx] subid=%lu [0x%lx] pidType=%lu [0x%lx])\n", 
			info.data.video.pid, 
			info.data.video.pid, 
			info.data.video.subid, 
			info.data.video.subid, 
			info.data.video.pidType,
			info.data.video.pidType);


	// get specific data
	//RMDetector3GetStreamSpecificInfo(context, streamNum, type, &info);

	// big switch...
	switch (info.type) {
	case RMdetector3_streamType_UNKNOWN:
	case RMdetector3_streamType_ELEMENTARY_AUDIO:
	case RMdetector3_streamType_ELEMENTARY_VIDEO:
	case RMdetector3_streamType_SYSTEM:
		break;

	// elementary audio
	case RMdetector3_streamType_AUDIO_AC3:
	case RMdetector3_streamType_AUDIO_ADIF:
	case RMdetector3_streamType_AUDIO_ADTS:
	case RMdetector3_streamType_AUDIO_DTS:
	case RMdetector3_streamType_AUDIO_DVD:
	case RMdetector3_streamType_AUDIO_MPEG1: //unused?
	case RMdetector3_streamType_AUDIO_MPEG1_LAYER3:
	case RMdetector3_streamType_AUDIO_MPEG2: //unused?
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER1:
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER2:
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER3:
	case RMdetector3_streamType_AUDIO_PCM:
	case RMdetector3_streamType_AUDIO_REVERSE_PCM:
	case RMdetector3_streamType_AUDIO_WMA:
	case RMdetector3_streamType_AUDIO_WMAPRO:
	case RMdetector3_streamType_AUDIO_WMATS:
	case RMdetector3_streamType_AUDIO_LATM:
		break;

	// pictures
	case RMdetector3_streamType_BMP:
	case RMdetector3_streamType_JPEG:
	case RMdetector3_streamType_TIFF:
	case RMdetector3_streamType_PNG:
	case RMdetector3_streamType_GIF:
		break;

	// elementary video
	case RMdetector3_streamType_VIDEO_DIVX3:
	case RMdetector3_streamType_VIDEO_DIVX4:
	case RMdetector3_streamType_VIDEO_H263:
	case RMdetector3_streamType_VIDEO_H264:
	case RMdetector3_streamType_VIDEO_MJPEG:
	case RMdetector3_streamType_VIDEO_MPEG12:
	case RMdetector3_streamType_VIDEO_MPEG4:

		if (info.data.video.skipNCP)
			fprintf(stderr, "\tMPEG4 skip NCP = 1\n");

	case RMdetector3_streamType_VIDEO_VC1:
	case RMdetector3_streamType_VIDEO_WMV:
	case RMdetector3_streamType_VIDEO_XVID:
		break;

	// system
	case RMdetector3_streamType_SYSTEM_ASF:
	case RMdetector3_streamType_SYSTEM_AVI:
	case RMdetector3_streamType_SYSTEM_DVD:
		break;

	case RMdetector3_streamType_SYSTEM_ID3:
	case RMdetector3_streamType_SYSTEM_M1S:
	case RMdetector3_streamType_SYSTEM_M2P:
	case RMdetector3_streamType_SYSTEM_M2T:
	case RMdetector3_streamType_SYSTEM_M2T_192:
	case RMdetector3_streamType_SYSTEM_MP4:
	case RMdetector3_streamType_SYSTEM_RIFFCDXA:
	case RMdetector3_streamType_SYSTEM_RIFFWAVE:
		break;
	}
	

	return;
}

static void audio_stream_callback(void *context, struct RM_Detection3_Specific_Info info, RMuint32 parentStreamID, RMuint32 streamID)
{
	RMuint32 i;

	if (parentStreamID == g_currentRootStreamID) {

		for (i = 0; i < g_nestingLevel + 1; i++)
			fprintf(stderr, "\t");
	}

	fprintf(stderr, "[%2lu %2lu ] %s", parentStreamID, streamID, print_type(info.type));

	if (!info.data.video.PID_INFO_VALID)
		fprintf(stderr, "\n");
	else
		fprintf(stderr, " (pid=%lu [0x%lx] subid=%lu [0x%lx] pidType=%lu [0x%lx])\n", 
			info.data.video.pid, 
			info.data.video.pid, 
			info.data.video.subid, 
			info.data.video.subid, 
			info.data.video.pidType,
			info.data.video.pidType);

	if (!info.data.audio.SPECIFIC_INFO_VALID)
		return;

	switch (info.type) {
	case RMdetector3_streamType_UNKNOWN:
	case RMdetector3_streamType_ELEMENTARY_AUDIO:
	case RMdetector3_streamType_ELEMENTARY_VIDEO:
	case RMdetector3_streamType_SYSTEM:
		break;

	// elementary audio
	case RMdetector3_streamType_AUDIO_AC3:
		fprintf(stderr, "\tAC3: sampleRate %lu, channels %lu, bitrate %lu\n", 
			info.data.audio.data.ac3.sampleRate, 
			info.data.audio.data.ac3.channels, 
			info.data.audio.data.ac3.bitrate);
		break;
	case RMdetector3_streamType_AUDIO_ADIF:
		fprintf(stderr, "\tADIF: sampleRate %lu, channels %lu, bitrate %lu, isVBR %lu\n", 
			info.data.audio.data.adif.sampleRate, 
			info.data.audio.data.adif.channels, 
			info.data.audio.data.adif.bitrate, 
			(RMuint32)info.data.audio.data.adif.isVBR);
		break;
	case RMdetector3_streamType_AUDIO_ADTS:
		fprintf(stderr, "\tADTS: sampleRate %lu, channels %lu, isVBR %lu\n", 
			info.data.audio.data.adts.sampleRate, 
			info.data.audio.data.adts.channels, 
			(RMuint32)info.data.audio.data.adts.isVBR);
		break;
	case RMdetector3_streamType_AUDIO_DTS:
		fprintf(stderr, "\tDTS: sampleRate %lu, channels %lu, bitrate %lu\n", 
			info.data.audio.data.dts.sampleRate, 
			info.data.audio.data.dts.channels, 
			info.data.audio.data.dts.bitrate);
		break;
	case RMdetector3_streamType_AUDIO_DVD:

		break;
	case RMdetector3_streamType_AUDIO_MPEG1: //unused?
		break;
	case RMdetector3_streamType_AUDIO_MPEG1_LAYER3:
		fprintf(stderr, "\tMPEG1layer3: sampleRate %lu, channels %lu, bitrate %lu, isVBR %lu\n", 
			info.data.audio.data.mpegAudio.sampleRate, 
			info.data.audio.data.mpegAudio.channels, 
			info.data.audio.data.mpegAudio.bitrate, 
			(RMuint32)info.data.audio.data.mpegAudio.isVBR);
		break;
	case RMdetector3_streamType_AUDIO_MPEG2: //unused?
		break;
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER1:
		fprintf(stderr, "\tMPEG2layer1: sampleRate %lu, channels %lu, bitrate %lu, isVBR %lu\n", 
			info.data.audio.data.mpegAudio.sampleRate, 
			info.data.audio.data.mpegAudio.channels, 
			info.data.audio.data.mpegAudio.bitrate, 
			(RMuint32)info.data.audio.data.mpegAudio.isVBR);

		break;
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER2:
		fprintf(stderr, "\tMPEG2layer2: sampleRate %lu, channels %lu, bitrate %lu, isVBR %lu\n", 
			info.data.audio.data.mpegAudio.sampleRate, 
			info.data.audio.data.mpegAudio.channels, 
			info.data.audio.data.mpegAudio.bitrate, 
			(RMuint32)info.data.audio.data.mpegAudio.isVBR);
		break;
	case RMdetector3_streamType_AUDIO_MPEG2_LAYER3:
		fprintf(stderr, "\tMPEG2layer3: sampleRate %lu, channels %lu, bitrate %lu, isVBR %lu\n", 
			info.data.audio.data.mpegAudio.sampleRate, 
			info.data.audio.data.mpegAudio.channels, 
			info.data.audio.data.mpegAudio.bitrate, 
			(RMuint32)info.data.audio.data.mpegAudio.isVBR);
		break;

	case RMdetector3_streamType_AUDIO_PCM:
		fprintf(stderr, 
			"\tPCM/WAVE: format %lu, payloadOffset %lu payloadLength %lu\n"
			"\t          sampleRate %lu, channels %lu, bitrate %lu, blockAlign %lu, bitsPerSample %lu\n",
			info.data.audio.data.wave.format,	
			info.data.audio.data.wave.payloadOffset,
			info.data.audio.data.wave.payloadLength,
			info.data.audio.data.wave.sampleRate,
			info.data.audio.data.wave.channels, 
			info.data.audio.data.wave.bitrate, 
			info.data.audio.data.wave.blockAlign,
			info.data.audio.data.wave.bitsPerSample);
		break;
	case RMdetector3_streamType_AUDIO_REVERSE_PCM:

		break;
	case RMdetector3_streamType_AUDIO_WMA:

		break;
	case RMdetector3_streamType_AUDIO_WMAPRO:

		break;
	case RMdetector3_streamType_AUDIO_WMATS:

		break;
	case RMdetector3_streamType_AUDIO_LATM:
	
		break;

	// pictures
	case RMdetector3_streamType_BMP:
	case RMdetector3_streamType_JPEG:
	case RMdetector3_streamType_TIFF:
	case RMdetector3_streamType_PNG:
	case RMdetector3_streamType_GIF:

	// elementary video
	case RMdetector3_streamType_VIDEO_DIVX3:
	case RMdetector3_streamType_VIDEO_DIVX4:
	case RMdetector3_streamType_VIDEO_H263:
	case RMdetector3_streamType_VIDEO_H264:
	case RMdetector3_streamType_VIDEO_MJPEG:
	case RMdetector3_streamType_VIDEO_MPEG12:
	case RMdetector3_streamType_VIDEO_MPEG4:
	case RMdetector3_streamType_VIDEO_VC1:
	case RMdetector3_streamType_VIDEO_WMV:
	case RMdetector3_streamType_VIDEO_XVID:

	// system
	case RMdetector3_streamType_SYSTEM_ASF:
	case RMdetector3_streamType_SYSTEM_AVI:
	case RMdetector3_streamType_SYSTEM_DVD:
	case RMdetector3_streamType_SYSTEM_ID3:
	case RMdetector3_streamType_SYSTEM_M1S:
	case RMdetector3_streamType_SYSTEM_M2P:
	case RMdetector3_streamType_SYSTEM_M2T:
	case RMdetector3_streamType_SYSTEM_M2T_192:
	case RMdetector3_streamType_SYSTEM_MP4:
	case RMdetector3_streamType_SYSTEM_RIFFCDXA:
	case RMdetector3_streamType_SYSTEM_RIFFWAVE:
		break;
	}
		

	return;
}

static void data_stream_callback(void *context, struct RM_Detection3_Specific_Info info, RMuint32 parentStreamID, RMuint32 streamID)
{

	fprintf(stderr, "[%lu %lu] %s\n", parentStreamID, streamID, print_type(info.type));

	// big switch...
       	// get specific data

	return;
}



int main(int argc, char **argv)
{
	RMstatus err = RM_OK;
	RMuint8 *filename = NULL;
	RMint32 i;
	struct RMdetector3Handle *pDetectorHandle = NULL;
	RMfile filehandle = NULL;
	RMuint32 parsing_length = DETECTION_THRESHOLD;

	RMDBGLOG((ENABLE, "argc = %lu\n", argc));
	for (i = 0; i < argc; i++)
		RMDBGLOG((ENABLE, "argv[%lu] = %s\n", i, argv[i]));

	if (argc < 2) {
		fprintf(stderr, "usage: %s filename [parsing_length]\n", argv[0]);
		fprintf(stderr, "          parsing_length is default to 512KB\n");
		return -1; // EXIT!
	}

	if (argc >= 2)
		filename = (RMuint8 *)argv[1];

	if (argc >= 3)
		parsing_length = strtol(argv[2], NULL, 10);

	parsing_length *= 1024;
	
	if (filename) {
		
		filehandle = RMOpenFile(filename, RM_FILE_OPEN_READ);
		if (!filehandle) {
			fprintf(stderr, "error %s couldn't open input file\n", RMstatusToString(err));
			goto exit_with_error;
		}
			

		err = RMDetector3Create(&pDetectorHandle);
		if (err != RM_OK) {
			fprintf(stderr, "error %s creating dectector instance\n", RMstatusToString(err));
			goto exit_with_error;
		}

		err = RMDetector3RegisterCallbacks(pDetectorHandle, 
						   pDetectorHandle, 
						   system_stream_callback,
						   video_stream_callback,
						   audio_stream_callback,
						   data_stream_callback);
		if (err != RM_OK) {
			fprintf(stderr, "error %s registering callbacks\n", RMstatusToString(err));
			goto exit_with_error;
		}

		fprintf(stderr, "----------------------------\n");
		fprintf(stderr, "file: %s\n\n", filename);

		err = RMDetector3DetectOpenFile(pDetectorHandle, filehandle, (RMascii *)filename, 0, parsing_length);
		if (err != RM_OK) {
			fprintf(stderr, "error %s detecting\n", RMstatusToString(err));
			goto exit_with_error;
		}

		fprintf(stderr, "\n");

		err = RMDetector3Destroy(pDetectorHandle);
		if (err != RM_OK) {
			fprintf(stderr, "error %s destroying detector instance\n", RMstatusToString(err));
			goto exit_with_error;
		}

		if (filehandle)
			RMCloseFile(filehandle);
	}

	//RMCheckAndReleaseMemory();
	return 0;

 exit_with_error:

	if (filehandle)
		RMCloseFile(filehandle);

	if (pDetectorHandle)
		RMDetector3Destroy(pDetectorHandle);

	//RMCheckAndReleaseMemory();

	fprintf(stderr, "error %s\n", RMstatusToString(err));
	return err;
}

