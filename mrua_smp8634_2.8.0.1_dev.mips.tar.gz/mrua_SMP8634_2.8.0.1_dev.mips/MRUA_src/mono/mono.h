#ifndef __MONO_H__
#define __MONO_H__


enum mono_decode{
	mono_decode_hard,
	mono_decode_soft,
	mono_decode_auto,
};


struct mono_context{
	RMuint32 gfx_id;
	RMTrtk rtk;
	RMbool recurse_dirs;
	RMbool use_gui;
	struct DCCVideoSource *osd_source;
	RMuint32 osd_scaler;
	RtkRect osd_rect;
	struct DCCVideoSource *pSPU_double_buffer_source;
	struct OSDdoubleBuffer doubleBuffer;
	enum mono_decode demux_decode;
	enum mono_decode jpeg_decode;
	RMbool force_sd;
	RMuint32 use_soft_cc_decoder;
	RMbool display_cc;
	enum EMhwlibCCSelect cc_select;
	RMuint32 audio_instances;
	RMuint32 display_error_threshold;
	RMuint32 AnchorErrPropagationThreshold;
	RMuint32 AnchorErrPropagationLength;
};

/**
 * Start mono 
 * @param argc - arg count (includes mono)
 * @param argv - arguments, last one should be NULL
 * @return != 0 on error
 */
int main_mono(int argc, char **argv);

#endif /* __MONO_H__ */
