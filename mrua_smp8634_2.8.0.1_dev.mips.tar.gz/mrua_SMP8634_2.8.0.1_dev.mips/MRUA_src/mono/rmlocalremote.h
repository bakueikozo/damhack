/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmlocalremote.h
  @brief  remote local callback api

  @author Julien Soulier
  @date   2005-03-24
*/

#ifndef __RMLOCALREMOTE_H__
#define __RMLOCALREMOTE_H__

typedef struct 
{
	RMint32 fd;
}remoteHandleType;

RMstatus RMlocalRemoteOpen(const RMascii *device, remoteHandleType **handle);
RMint32 RMFlushCallback (void *fileHandle);
void RMlocalRemoteClose(remoteHandleType **handle);
RMint32 PseudoFileReadWithTimeout(void *fileHandle,void *buf,RMuint32 count,RMint64 timeoutMicroSeconds);
void RMSleepCallback(RMuint64 microsec);
RMbool PseudoFileAvailable(void *fileHandle);

#endif // __RMLOCALREMOTE_H__
