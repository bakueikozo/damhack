/* 

test bench for rmpfs.c functions


to use threads:

-include 'librmpthreadw/librmpthreadw.a' to the lib_list in the Makefile
-export COMPILKIND += withthreads



*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define ALLOW_OS_CODE 1

#include <sys/types.h>

#include "../samples/common.h"
#include "../samples/command_ids.h"
#include "rmlocalremote.h"
#include "../rmremoteapi/include/rmremoteapi.h"

#include "../rmrtk/include/rmrtk.h"

/* #### Begin CARDEA code #### */
#include "rmupnp/rmlibwmdrmnd/include/ms_cardea.h"
/* #### End CARDEA code #### */


#ifdef WITH_THREADS
#include "../rmlibcw/include/rmthreads.h"
#endif


#include "mono.h"

#if 1
#define MONODBG ENABLE
#else
#define MONODBG DISABLE
#endif

#define MAX_DIR_RECURSION 8

#define ERROR_CLEANUP(i)	do { error = (i); goto cleanup; }  while(0)



// callback for the application to receive dcc context
void RMDCCInfo(struct dcc_context *dcc_info)
{
	RMDBGLOG((ENABLE, "got dcc info @ 0x%08lx\n", (RMuint32) dcc_info));
	// nothing to do for mono
}

// callback to pass stream information to the application, DRM protected, number of chapters, etc
void RMFileStreamInfoCallback(struct RMFileStreamInfo *streamInfo)
{
	// nothing to do for mono
	RMDBGLOG((ENABLE, "got stream info!\n"));
}


RM_EXTERN_C_BLOCKSTART

void RMremoteResetState(void);

RM_EXTERN_C_BLOCKEND


static struct playback_cmdline play_opt;
static struct display_cmdline disp_opt;
static struct video_cmdline video_opt;
static struct demux_cmdline demux_opt;

struct mono_context mono_opt;


/* returns TRUE to play the file and FALSE to skip it */

static RMascii *filename;
RMremoteHandle rh = (RMremoteHandle) NULL;

struct dcc_context dcc_info = {0,};
RMbool osd_enabled = FALSE;

/* this is the EOS callback, must be implemented by curacao */
void RMEOSCallback()
{
	/* mono doesnt do anything */
	RMDBGLOG((ENABLE, "RMEOSCallback() called, awaiting a command\n"));
	RMDBGLOG((ENABLE, "reset remote state to playing\n"));
	RMremoteResetState();	
}




static inline enum rfp_application get_app(struct rfp_stream_info *stream_info)
{
	switch(stream_info->system_type){
	case RM_SYSTEM_MPEG4:
		RMDBGLOG((ENABLE, "play_mp4\n"));
		return APP_MP4;
	case RM_SYSTEM_ASF:
		RMDBGLOG((ENABLE, "play_asf\n"));
		return APP_ASF;
	case RM_SYSTEM_ELEMENTARY_VIDEO:
		switch(stream_info->video_type){
		case RM_VIDEO_MPEG12:
		case RM_VIDEO_MPEG4:
		case RM_VIDEO_H263:
		case RM_VIDEO_H264:
		case RM_VIDEO_WMV:
		case RM_VIDEO_VC1:
		case RM_VIDEO_DIVX3:
		case RM_VIDEO_DIVX4:
		case RM_VIDEO_XVID:
		case RM_VIDEO_MJPEG:
			RMDBGLOG((ENABLE, "play_video\n"));
			return APP_VIDEO;
		case RM_VIDEO_BMP:
		case RM_VIDEO_TIFF:
		case RM_VIDEO_GIF:
		case RM_VIDEO_PNG:
			RMDBGLOG((ENABLE, "play_picture\n"));
			return APP_PICTURE;
		case RM_VIDEO_JPEG:
			switch(mono_opt.jpeg_decode){
			case mono_decode_soft:
				return APP_PICTURE;
			case mono_decode_hard:
				return APP_VIDEO;
			case mono_decode_auto:
				return APP_PICTURE;
			}
		case RM_VIDEO_UNKNOWN:
			RMDBGLOG((ENABLE, "unknwon\n"));
			break;
		}
		break;
	case RM_SYSTEM_ELEMENTARY_AUDIO:
		RMDBGLOG((ENABLE, "play_audio\n"));
		return APP_AUDIO;
	case RM_SYSTEM_MPEG1:
	case RM_SYSTEM_MPEG2_TRANSPORT:
	case RM_SYSTEM_MPEG2_TRANSPORT_192:
	case RM_SYSTEM_MPEG2_PROGRAM:
	case RM_SYSTEM_MPEG2_DVD:
		RMDBGLOG((ENABLE, "play_psfdemux\n"));

		switch(mono_opt.demux_decode){
		case mono_decode_soft:
			return APP_DEMUX_SOFT;
		case mono_decode_hard:
			return APP_DEMUX;
		case mono_decode_auto:
			return APP_DEMUX;
		}
		break;
	case RM_SYSTEM_AVI:
		RMDBGLOG((ENABLE, "play_avi_push\n"));
		return APP_AVI;
	case RM_SYSTEM_MPEG2_DVD_AUDIO:
	case RM_SYSTEM_DIVX_MP3:
	case RM_SYSTEM_DIVX_AC3:
	case RM_SYSTEM_DIVX_MPEG1:
	case RM_SYSTEM_DIVX_PCM:
	case RM_SYSTEM_DIVX_WMA:
	case RM_SYSTEM_DIVX_WMV9_MP3:
	case RM_SYSTEM_DIVX_WMV9_AC3:
	case RM_SYSTEM_DIVX_WMV9_MPEG1:
	case RM_SYSTEM_DIVX_WMV9_PCM:
	case RM_SYSTEM_DIVX3_MP3:
	case RM_SYSTEM_DIVX3_AC3:
	case RM_SYSTEM_DIVX3_MPEG1:
	case RM_SYSTEM_DIVX3_PCM:
	case RM_SYSTEM_RIFFCDXA:
	case RM_SYSTEM_ID3:
	case RM_SYSTEM_UNKNOWN:
		break;
	}
	return NOT_SUPPORTED;
}






static struct playback_cmdline local_play_opt;
static struct display_cmdline local_disp_opt;
static struct demux_cmdline local_demux_opt;
static struct mono_context local_mono_opt;
static struct dcc_context local_dcc_info;



static RMstatus play_file_app(
	struct mono_info *app_params, 
	enum rfp_application app
)
{
	RMuint32 i;
	
	RMDBGLOG((ENABLE, "instances %lu\n", mono_opt.audio_instances));
	app_params->audio_opt[0].audioInstances = mono_opt.audio_instances;

	/* 
	   replicate audio_opt[0] which was filled by rfp_detect to the rest of the audio instances;
	   setup engineID and decoderID accordingly, and restore data lost during replication
	*/
	for (i = 1; i < mono_opt.audio_instances; i++) {
		RMMemcpy(&(app_params->audio_opt[i]), &(app_params->audio_opt[0]), sizeof(struct audio_cmdline));

		// we have to restore these settings according to set_audio_options
		app_params->audio_opt[i].thisAudioInstance = i; 
		app_params->audio_opt[i].audioInstances = mono_opt.audio_instances;
		//app_params->audio_opt[i].dh_info = &dh_info;

		// setup engineID and decoderID
		switch (i) {
		case 1:
			// this is the second instance, assign it to engine 1, decoder 0 (the first instance is default engine=0 decoder=0)
			app_params->audio_opt[i].AudioEngineID = 1;
			app_params->audio_opt[i].AudioDecoderID = 0;
			break;
		case 2:
			// this is the third instance, assign it to engine 0, decoder 1
			app_params->audio_opt[i].AudioEngineID = 0;
			app_params->audio_opt[i].AudioDecoderID = 1;
			break;
		case 3:
			// this is the fourth instance, assign it to engine 1, decoder 1
			app_params->audio_opt[i].AudioEngineID = 1;
			app_params->audio_opt[i].AudioDecoderID = 1;
			break;
		default:
			fprintf(stderr, "error when replicating %lu audio instances\n", mono_opt.audio_instances);
			break;
		}
	}

	print_parsed_audio_options(app_params->audio_opt);

	return rfp_play(app_params, app);
}


static void show_usage(char *progname)
{
	fprintf(stderr, "MONO OPTIONS\n"
		"\t-forceSD: SD profile used instead of HD\n"
		"\t-R: If filename is a directory, play its sub-directories recursively\n"
		"\t-nogui: don't display the GUI (defaut is yes)\n"
		"\t-demux <soft|hard|auto>: Set demuxing method (default is auto)\n"
		"\t-jpeg <soft|hard|auto>: Set jpeg decompression method (default is auto)\n"
		"\t-cc <tv|soft|608soft|708soft>: Selects the closed caption display mode.\n"
		"\t-sat: send audio while in trickmode (default is not to send it)\n");

	show_playback_options();
	show_display_options();
	fprintf(stderr, "------------------------------------------------m-0-n-o-----\n");
	fprintf(stderr, "Minimum cmd line: %s filename [remote control device (Ex: /dev/ttyS0)] \n", progname);
	fprintf(stderr, "------------------------------------------------------------\n");
	exit(1);
}


static void parse_cmdline(int argc, char *argv[], struct mono_info *opts)
{
	int i;
	RMstatus err;

	// FIXME: temp soln to "internal error--unrecognizable insn"
	// moved 'app_params.noDolby = FALSE' from main() to here
	opts->noDolby = FALSE;
	if (argc < 2) 
		show_usage(argv[0]);
	i = 1;
	while ((argc > i)) {
		/* RMDBGLOG((ENABLE,"Arg %d : %s\n", i, argv[i])); */
		err = RM_OK;

		if (argv[i][0] != '-') {
			if (filename == NULL) {
				filename = argv[i];
				i++;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-R")) {
			mono_opt.recurse_dirs = TRUE;
			i++;
		}
		else if ( ! strcmp(argv[i], "-nogui")) {
			mono_opt.use_gui = FALSE;
			i++;
		}
		else if ( ! strcmp(argv[i], "-use_multiple_audio")) {
			if (argc > i+1) {
				RMuint32 instances;
				RMasciiToUInt32(argv[i+1], &instances);
				i += 2;

				if ((instances > MAX_AUDIO_DECODER_INSTANCES) || (instances <= 0))
					show_usage(argv[0]);

				mono_opt.audio_instances = instances;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-demux")) {
			if (argc > i+1) {
				if( ! strcmp(argv[i+1], "soft")) {
					mono_opt.demux_decode = mono_decode_soft;
				}
				else if( ! strcmp(argv[i+1], "hard")) {
					mono_opt.demux_decode = mono_decode_hard;
				}
				else if( ! strcmp(argv[i+1], "auto")) {
					mono_opt.demux_decode = mono_decode_auto;
				}
				else{
					show_usage(argv[0]);
				}
				i+=2;
			}
		}
		else if ( ! strcmp(argv[i], "-jpeg")) {
			RMDBGLOG((ENABLE, "jpeg, and next is %s\n", argv[i+1]));
			if (argc > i+1) {
				if( ! strcmp(argv[i+1], "soft")) {
					mono_opt.jpeg_decode = mono_decode_soft;
				}
				else if( ! strcmp(argv[i+1], "hard")) {
					mono_opt.jpeg_decode = mono_decode_hard;
				}
				else if( ! strcmp(argv[i+1], "auto")) {
					mono_opt.jpeg_decode = mono_decode_auto;
				}
				else{
					show_usage(argv[0]);
				}
				i+=2;
			}
			else{
				show_usage(argv[0]);
			}
		}
		else if ( ! strcmp(argv[i], "-sw")) {
			mono_opt.demux_decode = mono_decode_soft;
			i++;
		}
		else if ( ! strcmp(argv[i], "-forceSD")) {
			mono_opt.force_sd = TRUE;
			i++;
		}
		else if (! strcmp(argv[i], "-nodolby")) {
			 opts->noDolby = TRUE; 
			 i++;
		}
		else if ( ! strcmp(argv[i], "-past")) {
			opts->play_opt->require_video_audio = FALSE;
			i++;
		}
		else if ( ! strcmp(argv[i], "-disk_control")) {
			/* from bug #4005 comment #18:

			   for disk_ctrl_low_level i assume that i takes about 1 second to resume the harddisk, which gives 16
			   blocks at a blocksize of 128 kb at 2 mb/s stream.
			*/
			opts->play_opt->disk_ctrl_state = DISK_CONTROL_STATE_RUNNING;
			opts->play_opt->disk_ctrl_low_level = 16;
			opts->play_opt->prebuf_max = 1024 * 1024;
			fprintf(stderr, ">> disk control enabled, low level is %lu, prebuf_max is %lu bytes\n",
				opts->play_opt->disk_ctrl_low_level,
				opts->play_opt->prebuf_max);

			i++;
		}
		else if ( ! strcmp(argv[i], "-max_mem")) {
			if (argc > i+1) {
				RMasciiToUInt32(argv[i+1], &(opts->play_opt->disk_ctrl_max_mem));
				opts->play_opt->disk_ctrl_max_mem *= 1024;

				i += 2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-max_usable_RUA_mem")) {
			if (argc > i+1) {
				RMasciiToUInt32(argv[i+1], &(opts->play_opt->max_usable_RUA_mem));
				opts->play_opt->max_usable_RUA_mem *= 1024;

				i += 2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-block_size")) {
			if (argc > i+1) {
				RMasciiToUInt32(argv[i+1], &(opts->play_opt->disk_ctrl_log2_block_size));
				i += 2;
			}
			else
				show_usage(argv[0]);
		}
		else if (! strcmp(argv[i], "-cc")) {
			if (argc > i+1) {
				if (RMCompareAscii(argv[i+1], "tv")) {
					mono_opt.display_cc = TRUE;
					mono_opt.use_soft_cc_decoder = 0;
				}
				else if (RMCompareAscii(argv[i+1], "soft") || 
					 RMCompareAscii(argv[i+1], "608soft") ||
					 RMCompareAscii(argv[i+1], "cc1")) {
					mono_opt.display_cc = TRUE;
					mono_opt.use_soft_cc_decoder = 1;
					mono_opt.cc_select = EMhwlibCCSelect_CC1;
				}
				else if(RMCompareAscii(argv[i+1], "cc2") ){
					mono_opt.display_cc = TRUE;
					mono_opt.use_soft_cc_decoder = 1;
					mono_opt.cc_select = EMhwlibCCSelect_CC2;
				}
				else if(RMCompareAscii(argv[i+1], "cc3") ){
					mono_opt.display_cc = TRUE;
					mono_opt.use_soft_cc_decoder = 1;
					mono_opt.cc_select = EMhwlibCCSelect_CC3;
				}
				else if(RMCompareAscii(argv[i+1], "cc4") ){
					mono_opt.display_cc = TRUE;
					mono_opt.use_soft_cc_decoder = 1;
					mono_opt.cc_select = EMhwlibCCSelect_CC4;
				}
				else if(RMCompareAscii(argv[i+1], "708soft")) {
					mono_opt.display_cc = TRUE;
					mono_opt.use_soft_cc_decoder = 2;
				}
				else if(RMCompareAscii(argv[i+1], "off")) {
					mono_opt.display_cc = FALSE;
				}
				else {
					show_usage(argv[0]);
				}
				
				i += 2;
			}
			else {
				show_usage(argv[0]);
			}
		}
		else {
			err = parse_playback_cmdline(argc, argv, &i, &play_opt);
			if (err == RM_ERROR)
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_display_cmdline(argc, argv, &i, &disp_opt);
			if (err == RM_ERROR)
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
		}
		
		if (err == RM_PENDING) 
			show_usage(argv[0]);
		
	}
	if (filename == NULL){
		show_usage(argv[0]);
	}

	if (opts->play_opt->disk_ctrl_low_level) {
		if ((!opts->play_opt->disk_ctrl_max_mem) || (!opts->play_opt->disk_ctrl_log2_block_size)) {
			    fprintf(stderr, "**** disk control enabled, but not all required parameters where specified!\n\n\n\n");
			    show_usage(argv[0]);
		}
	}

}


RMbool RMPlayNonInterleavedAVI(void)
{
	return FALSE;
}

struct reader_thread_context {
	RMuint32 slot;
	RMbool running;
};

void *prefetch_thread(void *context);

void *prefetch_thread(void *context)
{
	struct reader_thread_context *ThreadContext = (struct reader_thread_context *)context;

	fprintf(stderr, "\n\n***************thread for slot %lu start\n", ThreadContext->slot);

	ThreadContext->running = TRUE;

	rmpfs_prefetch_slot(ThreadContext->slot);

	ThreadContext->running = FALSE;

	fprintf(stderr, "\n\n***************thread for slot %lu end\n", ThreadContext->slot);

	return NULL;
}

	


int main(int argc, char **argv)
{
	RMstatus err;
	int error = 0;
	struct rfp_detect_options detect_opt;
	enum rfp_application app = NOT_SUPPORTED;
	struct mono_info app_params;
	struct rfp_stream_info stream_info;
	
	// comment the following line to compile this file under em8620branch
	struct dh_context dh_info = {0,};
	
	struct audio_cmdline audio_options[MAX_AUDIO_DECODER_INSTANCES]; /*access through audio_opt*/

	RMuint32 i;

// PFS STUFF

#define MAX_CACHEABLE_URL 8
#define PFS_BUF_SIZE (MAX_CACHEABLE_URL * 1024 * 1024)


	struct pfs_profile pfsHandle;

#ifdef WITH_THREADS
	RMthread threadID[MAX_CACHEABLE_URL];
#endif
	struct reader_thread_context prefetch_thread_context[MAX_CACHEABLE_URL];

	RMMemset(&prefetch_thread_context, 0, sizeof(struct reader_thread_context)*MAX_CACHEABLE_URL);

// PFS STUFF



	/* Init static global variables in case we are used in a library, and
	 * it is not the first call */

	filename = NULL;

	rh = (RMremoteHandle) NULL;
	RMMemset(&dcc_info, 0, sizeof(dcc_info));
	RMMemset(&play_opt, 0, sizeof(play_opt));
	RMMemset(&disp_opt, 0, sizeof(disp_opt));
	RMMemset(&mono_opt, 0, sizeof(mono_opt));
	RMMemset(&demux_opt, 0, sizeof(demux_opt));

	init_playback_options(&play_opt);
	init_display_options(&disp_opt);

	mono_opt.recurse_dirs = FALSE;
	mono_opt.use_gui = TRUE;

	mono_opt.demux_decode = mono_decode_auto;
	mono_opt.jpeg_decode = mono_decode_auto;
	mono_opt.force_sd = FALSE;
	mono_opt.display_cc = TRUE;
	mono_opt.cc_select = EMhwlibCCSelect_CC1;
	mono_opt.use_soft_cc_decoder = 0;
	mono_opt.audio_instances = 1;


	app_params.play_opt = &play_opt;
	app_params.video_opt = &video_opt;
	app_params.demux_opt = &demux_opt;

	app_params.audio_opt = audio_options;
	
	// comment the following line to compile this file under em8620branch
	disp_opt.dh_info = &dh_info;

	parse_cmdline(argc, argv, &app_params);

	RMDBGLOG((ENABLE, ">>> Mono will be using %lu audio instances\n", mono_opt.audio_instances));

	app_params.osd_scaler = 0;
	app_params.video_scaler = disp_opt.video_scaler;

	err = RUACreateInstance(&(dcc_info.pRUA), play_opt.chip_num);
	if (RMFAILED(err)) {
		RMDBGLOG((MONODBG, "Error creating RUA instance! %d\n", err));
		return err;
	}

	err = DCCOpen(dcc_info.pRUA, &(dcc_info.pDCC));
	if (RMFAILED(err)) {
		RMDBGLOG((MONODBG, "Error Opening DCC! %d\n", err));
		return err;
	}

	err = DCCInitMicroCodeEx(dcc_info.pDCC, disp_opt.init_mode);
	if (RMFAILED(err)) {
		RMDBGLOG((MONODBG, "Cannot initialize microcode %d\n", err));
		return err;
	}


	dcc_info.chip_num = play_opt.chip_num;
	dcc_info.route = DCCRoute_Main;

	// comment the following line to compile this file under em8620branch
	disp_opt.dh_info->pDH = NULL;



	err = apply_playback_options(&dcc_info, &play_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((MONODBG, "Cannot set playback options %d\n", err));
		ERROR_CLEANUP(-1);
	}

	err = DCCGetScalerModuleID(dcc_info.pDCC, dcc_info.route, DCCSurface_Video, app_params.video_scaler, &(dcc_info.SurfaceID));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get surface to display video source %d\n", err));
		ERROR_CLEANUP(-1);
	}

	err = apply_display_options(&dcc_info, &disp_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((MONODBG, "Cannot set display options %d\n", err));
		ERROR_CLEANUP(-1);
	}
	
	app_params.pRUA = dcc_info.pRUA;
	app_params.pDCC = dcc_info.pDCC;

	

// PFS STUFF

	pfsHandle.prefetch_area = RMMalloc(PFS_BUF_SIZE);
	pfsHandle.prefetch_area_size = PFS_BUF_SIZE;
	pfsHandle.prefetch_slots = MAX_CACHEABLE_URL;

	RMMemset(pfsHandle.prefetch_area, 0x80, PFS_BUF_SIZE);

	rmpfs_open(&pfsHandle);

	// allocate slots for the URLs
	rmpfs_allocate_slot_to_url("/media/avi/mp3/moulin_rouge_1200.avi", 0);
	rmpfs_allocate_slot_to_url("/media/mp4/mpeg4/nero/002-nd-standard.mp4", 1);
	rmpfs_allocate_slot_to_url("/media/asf/wmv9/Robotica_720.wmv", 2);
	rmpfs_allocate_slot_to_url("/media/asf/wmv9/Dolphins.wmv", 3);

	//rmpfs_allocate_slot_to_url("http://172.27.0.160:10243/WMCv2/%7bC1C0EEE2-E569-4148-9557-DA7BBE4DBE30%7d/8-28.wmv", 1);
	rmpfs_allocate_slot_to_url("/media/asf/wma/newstories.wma", 4);
	rmpfs_allocate_slot_to_url("/media/elementary/mp3/matrix_revolution.mp3", 5);

	for (i = 0; i < MAX_CACHEABLE_URL; i++) {
		RMDBGLOG((ENABLE, "setup slot %lu for context %lu\n", i, i));
		prefetch_thread_context[i].slot = i;
	}

#ifdef WITH_THREADS

	for (i = 0; i < MAX_CACHEABLE_URL; i++) {
		RMDBGLOG((ENABLE, "clear thread id for slot %lu\n", i));
		threadID[i] = 0;
	}


	// launch prefetch threads
	threadID[0] = RMCreateThread("prefetchThread 0", prefetch_thread, (void*)&prefetch_thread_context[0]);
	//rmpfs_prefetch_slot(0);


	// test case for bugct #2719, interrupt prefetching
	RMDBGLOG((ENABLE, "start thread 1 ******************\n"));
 	threadID[1] = RMCreateThread("prefetchThread 1", prefetch_thread, (void*)&prefetch_thread_context[1]);
	RMDBGLOG((ENABLE, "thread 1 launched, close it *****\n"));
	RMDBGLOG((ENABLE, "waiting!\n"));
	usleep(1 * 1000 * 1000);
	RMDBGLOG((ENABLE, "continue!\n"));
 	rmpfs_close_slot(1);
	RMDBGLOG((ENABLE, "closed slot 1 *******************\n"));
 
	threadID[2] = RMCreateThread("prefetchThread 2", prefetch_thread, (void*)&prefetch_thread_context[2]);
	threadID[3] = RMCreateThread("prefetchThread 3", prefetch_thread, (void*)&prefetch_thread_context[3]);

	RMDBGLOG((ENABLE, "waiting!\n"));
	usleep(2 * 1000 * 1000);
	RMDBGLOG((ENABLE, "continue!\n"));

	threadID[4] = RMCreateThread("prefetchThread 4", prefetch_thread, (void*)&prefetch_thread_context[4]);
	threadID[5] = RMCreateThread("prefetchThread 5", prefetch_thread, (void*)&prefetch_thread_context[5]);

#else

	prefetch_thread((void*)&prefetch_thread_context[0]);
	prefetch_thread((void*)&prefetch_thread_context[1]);
	prefetch_thread((void*)&prefetch_thread_context[2]);
	prefetch_thread((void*)&prefetch_thread_context[3]);
	prefetch_thread((void*)&prefetch_thread_context[4]);
	prefetch_thread((void*)&prefetch_thread_context[5]);

#endif


// PFS STUFF


	play_opt.filename = filename;

	RMMemcpy(&local_dcc_info, &dcc_info, sizeof(dcc_info));
	RMMemcpy(&local_play_opt, &play_opt, sizeof(play_opt));
	RMMemcpy(&local_disp_opt, &disp_opt, sizeof(disp_opt));
	RMMemcpy(&local_mono_opt, &mono_opt, sizeof(mono_opt));
	RMMemcpy(&local_demux_opt, &demux_opt, sizeof(demux_opt));

	init_video_options(&video_opt);
	init_audio_options2(app_params.audio_opt, MAX_AUDIO_DECODER_INSTANCES);


	// comment the following 2 lines to compile this file under em8620branch
	for (i = 0; i < MAX_AUDIO_DECODER_INSTANCES; i++)
		app_params.audio_opt[i].dh_info = &dh_info;

	RMTermInit(FALSE);
	//RMSignalInit(NULL, NULL);


	/* keep compatibility with deprecated player_conf struct */
	detect_opt.force_sd = mono_opt.force_sd;

// NO DTCP!!
	app_params.dtcpCookieHandle = NULL;


	err = rfp_detect(&app_params, &detect_opt, &app, &stream_info);
	if(RMFAILED(err)){
		RMDBGLOG((ENABLE, "Detection failed\n"));

		RMTermExit();
		ERROR_CLEANUP(-1);
		
	}

	/* it's up to mono (not rfp) to decide which app to use for each format */
	app = get_app(&stream_info);

	if(app == NOT_SUPPORTED){
		RMDBGLOG((MONODBG, "Could not play file, detection yielded %s (%ld) but it is not supported\n", RMstatusToString(err), (RMuint32)err));
		RMTermExit();
		ERROR_CLEANUP(-1);
		
	}


	if((app == APP_VIDEO) && (stream_info.video_type == RM_VIDEO_JPEG)){
		app_params.play_opt->waitexit = TRUE;
	}


	app_params.audio_opt[0].dh_info = &dh_info;
	
	
	err = play_file_app(&app_params, app);
	if (err == RM_DRM_PREVENTS_PLAYBACK)
		fprintf(stderr, "DRM prevents this file's playback, skipping\n");
	else if(RMFAILED(err)){
		RMTermExit();
		RMDBGLOG((ENABLE, "Could not play file %d\n", err));
		ERROR_CLEANUP(-1);
	}



	RMTermExit();

 cleanup:

// PFS STUFF

#ifdef WITH_THREADS
	RMDBGLOG((ENABLE, "waiting for thread 0 to finish\n"));
	// wait for threads to finish
	RMWaitForThreadToFinish(threadID[0]);
	RMDBGLOG((ENABLE, "waiting for thread 1 to finish\n"));
	RMWaitForThreadToFinish(threadID[1]);
	RMDBGLOG((ENABLE, "waiting for thread 2 to finish\n"));
	RMWaitForThreadToFinish(threadID[2]);
	RMDBGLOG((ENABLE, "waiting for thread 3 to finish\n"));
	RMWaitForThreadToFinish(threadID[3]);
	RMDBGLOG((ENABLE, "waiting for thread 4 to finish\n"));
	RMWaitForThreadToFinish(threadID[4]);
	RMDBGLOG((ENABLE, "waiting for thread 5 to finish\n"));
	RMWaitForThreadToFinish(threadID[5]);

	RMDBGLOG((ENABLE, "done\n"));
#endif

	rmpfs_close_slot(0);
	rmpfs_close_slot(1);
	rmpfs_close_slot(2);
	rmpfs_close_slot(3);
	rmpfs_close_slot(4);
	rmpfs_close_slot(5);

	rmpfs_close();

// PFS STUFF

	if (mono_opt.pSPU_double_buffer_source) {
		RMDBGLOG((ENABLE, "close doubleBufferOSD\n"));
		err = DCCCloseVideoSource(mono_opt.pSPU_double_buffer_source);
		mono_opt.pSPU_double_buffer_source = NULL;
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot close SPU doubleBuffer source %d\n", err));
			return err;
		}
		
	}


	err = clear_display_options(&dcc_info, &disp_opt);
	if (RMFAILED(err))
		RMDBGLOG((ENABLE, "Cannot clear display options %d\n", err));
	
	err = DCCClose(dcc_info.pDCC);
	if (RMFAILED(err))
		RMDBGLOG((ENABLE, "Cannot close DCC %d\n", err));

	err = RUADestroyInstance(dcc_info.pRUA);
	if (RMFAILED(err))
		RMDBGLOG((ENABLE, "Cannot destroy RUA instance %d\n", err));

	//RMCheckAndReleaseMemory();

	return error;
}

