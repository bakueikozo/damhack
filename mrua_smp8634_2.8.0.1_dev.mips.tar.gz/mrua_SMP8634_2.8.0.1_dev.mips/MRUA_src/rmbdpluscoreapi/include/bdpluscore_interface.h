/**************************************************************
 *
 *	Copyright (c) Sigma Designs, Inc. 2005. All rights reserved.
 *
 */
/**
 *     @file   bdplus_interface.h
 *     @brief  BD+ interface to shared library
 *
 *     @author Alan Liddke
 *
 ***************************************************************/
#ifndef __BDPLUSCORE_INTERFACE_H__
#define __BDPLUSCORE_INTERFACE_H__

#include "bdpluscore_api.h"


struct bdpluscore_interface_s {
	
	struct bdpx_context* (* BDPX_open)(RMuint32 base_addr,RMuint32 size, RMuint8 flashPage);
		
	RMstatus (* BDPX_close) (struct bdpx_context *ctx);
	
	// BD+ SSS API
	RMstatus (* BDPX_aes128) (struct bdpx_context *ctx,
	                         RMuint8 *dstPtr, const RMuint8 *srcPtr,
	                         RMuint32 blockcount, const RMuint8 *keyPtr, RMuint32 opID);
	
	RMstatus (* BDPX_random) (struct bdpx_context *ctx, RMuint8 *dstPtr, RMuint32 len);
	RMstatus (* BDPX_sha1)   (struct bdpx_context *ctx, RMuint32 *dstPtr, const RMuint8 *srcPtr,
	                         RMuint32 len, RMuint32 op);

	RMstatus (* BDPX_ecdsa_generate) (struct bdpx_context *ctx, RMuint8 *sigPtr, const RMuint8 *hashPtr, const RMuint16 keyIndex);
	RMstatus (* BDPX_ecdsa_verify)   (struct bdpx_context *ctx, const RMuint8 *sigPtr, const RMuint8 *hashPtr, const RMuint16 keyIndex);

	
	// BD+ TD API - moved to AACS module 
	//RMstatus (* BDPX_setSP)   (struct bdpx_context *h, RMuint16 ClipID, RMuint16 SP_ID, RMuint8 SP[16], RMuint8 FM_ID[8]);
	//RMstatus (* BDPX_sendFUT) (struct bdpx_context *h, RMuint32 *fixupTable);

	RMstatus (* BDPX_get_cert) (struct bdpx_context *ctx,RMuint32 *dstPtr, const RMuint32 certType);

	struct bdpx_context* (* BDPX_open_preloaded)(RMuint32 base_addr,RMuint32 size, RMuint8 flashPage, RMuint32 xtask_slot_id);

	RMstatus (*BDPX_get_last_error)(void);
};

#endif // __BDPLUSCORE_INTERFACE_H__
