#ifndef __BDPLUSCORE_VERSION_H__
#define __BDPLUSCORE_VERSION_H__

#define BDPLUSCORE_LIBRARY_NAME "librmbdpluscore.1_2.Maa.so"

#endif /* __BDPLUSCORE_VERSION_H__ */
