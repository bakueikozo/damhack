/*
 *
 * Copyright (c) Sigma Designs, Inc. 2005. All rights reserved.
 *
 */
#ifndef __BPPLUSCORE_API_H__
#define __BDPLUSCORE_API_H__

/* 
 *
 *  BD+ Crypto Core and Media Transform API
 *
 */

 
#include "rmdef/rmdef.h"

#define BDPLUS_SSS_AES_OPID_ENCRYPT 0xFFF10000
#define BDPLUS_SSS_AES_OPID_DECRYPT 0xFFF10001
#define BDPLUS_SSS_AES_OPID_INDIRECT(x) (x)

#define BDPLUS_SSS_CERT_0_SIZE 284
#define BDPLUS_SSS_CERT_1_SIZE 292

#define BDPLUSCORE_XRPC_SIZE         20*1024 // 20KB


/* Invalid slot ID is currently used as the last parameter to 'Init_Preloaded' 
 * to specify that the xtask contained within the library should be used in 
 * leu of a preloaded image. */
#define BDPLUS_INVALID_SLOT 0xFFFFFFFF


struct bdpx_context;

struct bdpx_context *BDPX_open(RMuint32 base_addr, RMuint32 size, RMuint8 flashSector);

struct bdpx_context *BDPX_open_preloaded(RMuint32 base_addr, RMuint32 size, RMuint8 flashSector, RMuint32 xtask_slot_id);

RMstatus BDPX_close(struct bdpx_context *ctx);

RMstatus BDPX_get_last_error(void);

// BD+ SSS API 
RMstatus BDPX_aes128(struct bdpx_context *ctx,
                    RMuint8 *dstPtr, const RMuint8 *srcPtr,
                    RMuint32 blockcount, const RMuint8 *keyPtr, RMuint32 opID);

RMstatus BDPX_random(struct bdpx_context *ctx, RMuint8 *dstPtr, RMuint32 len);

RMstatus BDPX_sha1(struct bdpx_context *ctx, RMuint32 *dstPtr, const RMuint8 *srcPtr,
                   RMuint32 len, RMuint32 op);

RMstatus BDPX_ecdsa_generate(struct bdpx_context *ctx, RMuint8 *sigPtr, const RMuint8 *hashPtr, const RMuint16 keyID);
RMstatus BDPX_ecdsa_verify(struct bdpx_context *ctx, const RMuint8 *sigPtr, const RMuint8 *hashPtr, const RMuint16 keyID);

RMstatus BDPX_get_cert (struct bdpx_context *ctx, RMuint32 *dstPtr, const RMuint32 certType);

#endif /* __BDPLUSCORE_API_H__ */
