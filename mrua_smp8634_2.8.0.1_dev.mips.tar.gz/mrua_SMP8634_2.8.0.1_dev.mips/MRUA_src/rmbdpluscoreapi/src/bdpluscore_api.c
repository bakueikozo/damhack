/****************************************************************************
 * Copyright (c) Sigma Designs, Inc. 2005. All rights reserved.
 */
/**
 *	@file     bdpluscore_interface.c
 *
 *	@brief    Wrapper for css shared library.
 * 
 *	@author   Alan Liddeke 
 *	
 ****************************************************************************/



/*---------------------------------------------------------------------------
                                 INCLUDES
 ---------------------------------------------------------------------------*/

#define ALLOW_OS_CODE
#include "rmdef/rmdef.h"
#include "rmdrm/include/rmdrm.h"
#include "../include/bdpluscore_api.h"
#include "../include/bdpluscore_version.h"
#include "bdpluscore_interface.h"


#if (EM86XX_MODE == EM86XX_MODEID_WITHHOST) || (EM86XX_CHIP == EM86XX_CHIPID_TANGO2)

static struct bdpluscore_interface_s *g_bdpx_interface;

struct bdpx_context *BDPX_open(RMuint32 base_addr, RMuint32 size,RMuint8 flashPage)
{
	if(g_bdpx_interface) return g_bdpx_interface->BDPX_open(base_addr,size,flashPage);
	else {
		g_bdpx_interface = load_drm(BDPLUSCORE, NULL);
		if(g_bdpx_interface) return g_bdpx_interface->BDPX_open(base_addr,size,flashPage);
		else return NULL;
	}
}

struct bdpx_context *BDPX_open_preloaded(RMuint32 base_addr, RMuint32 size,RMuint8 flashPage, RMuint32 xtask_slot_id)
{

	if(g_bdpx_interface) return g_bdpx_interface->BDPX_open_preloaded(base_addr,size,flashPage, xtask_slot_id);
	else {
		g_bdpx_interface = load_drm(BDPLUSCORE, NULL);
		if(g_bdpx_interface) return g_bdpx_interface->BDPX_open_preloaded(base_addr,size,flashPage,xtask_slot_id);
		else return NULL;
	}
}

RMstatus BDPX_get_last_error(void)
{

	if(g_bdpx_interface) return g_bdpx_interface->BDPX_get_last_error();
	else {
		g_bdpx_interface = load_drm(BDPLUSCORE, NULL);
		if(g_bdpx_interface) return g_bdpx_interface->BDPX_get_last_error();
		else return RM_ERROR;
	}
}


RMstatus BDPX_close(struct bdpx_context *ctx)
{
	if(g_bdpx_interface) return g_bdpx_interface->BDPX_close(ctx);
	else return RM_ERROR;
}

// BD+ SSS API
RMstatus BDPX_aes128(struct bdpx_context *ctx,
                    RMuint8 *dstPtr, const RMuint8 *srcPtr,
                    RMuint32 blockcount, const RMuint8 *keyPtr, RMuint32 opID)
{
	if(g_bdpx_interface) return g_bdpx_interface->BDPX_aes128(ctx, dstPtr, srcPtr, blockcount, keyPtr, opID);
	else return RM_ERROR;
}

RMstatus BDPX_random(struct bdpx_context *ctx, RMuint8 *dstPtr, RMuint32 len)
{
	if(g_bdpx_interface) return g_bdpx_interface->BDPX_random(ctx, dstPtr, len);
	else return RM_ERROR;
}

RMstatus BDPX_sha1(struct bdpx_context *ctx, RMuint32 *dstPtr, const RMuint8 *srcPtr,
                   RMuint32 len, RMuint32 op)
{
	if(g_bdpx_interface) return g_bdpx_interface->BDPX_sha1(ctx, dstPtr, srcPtr, len, op);
	else return RM_ERROR;
}

RMstatus BDPX_ecdsa_generate(struct bdpx_context *ctx, RMuint8 *sigPtr, const RMuint8 *hashPtr, const RMuint16 keyID)
{
	if(g_bdpx_interface) return g_bdpx_interface->BDPX_ecdsa_generate(ctx, sigPtr, hashPtr, keyID);
	else return RM_ERROR;
}

RMstatus BDPX_ecdsa_verify(struct bdpx_context *ctx, const RMuint8 *sigPtr, const RMuint8 *hashPtr, const RMuint16 keyID)
{
	if(g_bdpx_interface) return g_bdpx_interface->BDPX_ecdsa_verify(ctx, sigPtr, hashPtr, keyID);
	else return RM_ERROR;
}

RMstatus BDPX_get_cert (struct bdpx_context *ctx, RMuint32 *dstPtr, const RMuint32 certType)
{
	if(g_bdpx_interface) return g_bdpx_interface->BDPX_get_cert(ctx, dstPtr, certType);
	else return RM_ERROR;
}

#endif /* EM86XX_MODEID_WITHHOST || EM86XX_CHIPID_TANGO2 */
