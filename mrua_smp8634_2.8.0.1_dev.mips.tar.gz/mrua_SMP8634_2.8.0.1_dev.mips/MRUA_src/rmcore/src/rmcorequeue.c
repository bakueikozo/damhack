/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
*****************************************/

#define RM_LIBRARY_SELF_COMPILING 1

#include "../include/rmcore.h"

struct _RMcoreQueue {
	void **array;
	RMuint32 arrayEntries;
	RMuint32 rd,wr;
};

#if 0
#define COREQUEUEDBG ENABLE
static void dumpCQ(RMcoreQueue corequeue) 
{
	RMuint32 i;
	RMascii enough[400];
	
	for (i=0;i<corequeue->arrayEntries;i++) {
		if (i==corequeue->rd) {
			RMPrintAscii(enough,"[");
			RMPrintDebug(enough);
		}
		
		RMPrintAscii(enough,"%p ",(int)corequeue->array[i]);
		RMPrintDebug(enough);
		
		if (i==(corequeue->arrayEntries+corequeue->wr-1)%corequeue->arrayEntries) {
			RMPrintAscii(enough,"]");
			RMPrintDebug(enough);
		}
	}
	
	RMPrintAscii(enough,"\n");
	RMPrintDebug(enough);
}
#else 
#define COREQUEUEDBG DISABLE
#endif

#define COREQUEUENAN 0x0

RMcoreQueue RMCreateCoreQueue(RMuint32 maxItems)
{
	RMcoreQueue corequeue=(RMcoreQueue)RMMalloc(sizeof(struct _RMcoreQueue));
	
	corequeue->arrayEntries = maxItems+1; // rd=wr case means empty
	corequeue->array = (void **)RMMalloc(corequeue->arrayEntries*sizeof(void *));
	
	corequeue->rd = 0;
	corequeue->wr = 0;
	
#ifdef _DEBUG
	RMMemset(corequeue->array,COREQUEUENAN,corequeue->arrayEntries*sizeof(void*));
#endif // _DEBUG
	
	return corequeue;
}

void RMDeleteCoreQueue(RMcoreQueue corequeue)
{
	RMASSERT(corequeue!=NULL);
	
	if (RMGetCountCoreQueue(corequeue)!=0) RMPanic(RM_FATALCOREQUEUENOTVALID);
	
	RMFree(corequeue->array);
	RMFree(corequeue);
}

RMstatus RMInsertFirstCoreQueue(const RMcoreQueue corequeue, void * item)
{
	RMDBGLOG((COREQUEUEDBG,"RMInsertFirstCoreQueue %p\n",item));

	RMASSERT(corequeue!=NULL);
	
	if (RMGetCountCoreQueue(corequeue)==corequeue->arrayEntries-1) return RM_ERROR;
	
	//dumpCQ(corequeue);

	corequeue->rd=(corequeue->arrayEntries+corequeue->rd-1)%corequeue->arrayEntries;
	(corequeue->array)[corequeue->rd]=item;
	
	//dumpCQ(corequeue);

	return RM_OK;
}

RMstatus RMInsertLastCoreQueue(const RMcoreQueue corequeue, void * item)
{
	RMDBGLOG((COREQUEUEDBG,"RMInsertLastCoreQueue %p\n",item));

	RMASSERT(corequeue!=NULL);
	
	if (RMGetCountCoreQueue(corequeue)==corequeue->arrayEntries-1) return RM_ERROR;

	//dumpCQ(corequeue);

	(corequeue->array)[corequeue->wr]=item;
	corequeue->wr=(corequeue->wr+1)%corequeue->arrayEntries;

	//dumpCQ(corequeue);

	return RM_OK;
}

RMstatus RMRemoveFirstCoreQueue(const RMcoreQueue corequeue, void **item)
{
	RMASSERT(corequeue!=NULL);
	
	if (RMGetCountCoreQueue(corequeue)==0) return RM_ERROR;
	
	//dumpCQ(corequeue);
	
	*item=(corequeue->array)[corequeue->rd];
	corequeue->rd=(corequeue->rd+1)%corequeue->arrayEntries;

	//dumpCQ(corequeue);

	RMDBGLOG((COREQUEUEDBG,"RMRemoveFirstCoreQueue = %p\n",*item));

	return RM_OK;
}

RMstatus RMRemoveLastCoreQueue(const RMcoreQueue corequeue, void **item)
{
	RMASSERT(corequeue!=NULL);
	
	if (RMGetCountCoreQueue(corequeue)==0) return RM_ERROR;

	//dumpCQ(corequeue);

	corequeue->wr=(corequeue->arrayEntries+corequeue->wr-1)%corequeue->arrayEntries;
	*item=(corequeue->array)[corequeue->wr];

	//dumpCQ(corequeue);

	RMDBGLOG((COREQUEUEDBG,"RMRemoveLastCoreQueue = %p\n",*item));

	return RM_OK;
}

RMstatus RMGetNextItemCoreQueue(RMcoreQueue corequeue, void **item, void **cookie)
{
	RMuint32 li=(RMuint32)(*cookie);

	RMASSERT(corequeue!=NULL);
	
	if (li<RMGetCountCoreQueue(corequeue)) {
		*item=(corequeue->array)[(corequeue->rd+li)%corequeue->arrayEntries];
		*cookie=(void *)(li+1);
		return RM_OK;
	}
	
	// update cookie even when going after last position (allow insert at end this way)
	*cookie=(void *)(li+1);
	return RM_ERROR;
}

RMstatus RMRemoveCookieItemCoreQueue(RMcoreQueue corequeue, void **cookie)
{
	// MINUS ONE!!! RMGetNextItemCoreQueue HAS INCREASED ONE TOO MUCH!!!
	RMint32 li=(RMuint32)(*cookie)-1;
	RMint32 usedSize=RMGetCountCoreQueue(corequeue);
	RMint32 i;

	RMASSERT(corequeue!=NULL);
	
	if (
	    (0<=li)
	    &&
	    (li<usedSize)
	    ) {

		//dumpCQ(corequeue);
		
		// shl right part of the corequeue
		for (i=li+1;i<usedSize;i++) {
			RMuint32 itemindex;
			void **ppreviousitem,*currentitem;
			
			itemindex=(corequeue->arrayEntries+corequeue->rd+i-1)%corequeue->arrayEntries;
			ppreviousitem=&( (corequeue->array)[itemindex] );
			itemindex=(corequeue->rd+i)%corequeue->arrayEntries;  
			currentitem=(corequeue->array)[itemindex];
			
			*ppreviousitem=currentitem;
		}

		corequeue->wr=(corequeue->arrayEntries+corequeue->wr-1)%corequeue->arrayEntries;
		
		// move cookie accordingly (it is decreased!)
		*cookie=(void *)li;
		
		//dumpCQ(corequeue);
		
		return RM_OK;
	}

	return RM_ERROR;
}

RMstatus RMInsertCookieItemCoreQueue(RMcoreQueue corequeue, void *item, void **cookie)
{
	// MINUS ONE!!! RMGetNextItemCoreQueue HAS INCREASED ONE TOO MUCH!!!
	RMint32 li=(RMuint32)(*cookie)-1;
	RMint32 usedSize=RMGetCountCoreQueue(corequeue);
	RMint32 i;

	RMASSERT(corequeue!=NULL);
	
	if (
	    (0<=li)
	    &&
	    // the <= below means we can insert after last...
	    (li<=usedSize)
	    ) {
		if (usedSize==(RMint32)corequeue->arrayEntries-1) return RM_ERROR;

		//dumpCQ(corequeue);

		// shr right part of the corequeue. i must decrease!
		for (i=usedSize;i>=(RMint32)li+1;i--) {
			RMuint32 itemindex;
			void **pnextitem,*currentitem;
			
			itemindex=(corequeue->rd+i)%corequeue->arrayEntries; 
			pnextitem=&( (corequeue->array)[itemindex] );
			itemindex=(corequeue->arrayEntries+corequeue->rd+i-1)%corequeue->arrayEntries;
			currentitem=(corequeue->array)[itemindex];
			
			*pnextitem=currentitem;
		}
		
		// put new item in the created hole
		(corequeue->array)[(corequeue->rd+li)%corequeue->arrayEntries]=item;

		corequeue->wr=(corequeue->wr+1)%corequeue->arrayEntries;
		
		// cookie does not move
		
		//dumpCQ(corequeue);

		return RM_OK;
	}

	return RM_ERROR;
}

RMstatus RMShowLastCoreQueue(const RMcoreQueue corequeue, void **item)
{
	RMASSERT(corequeue!=NULL);
	
	if (RMGetCountCoreQueue(corequeue)==0) return RM_ERROR;
	
	*item=(corequeue->array)[(corequeue->arrayEntries+corequeue->wr-1)%corequeue->arrayEntries];
	
	return RM_OK;
}

RMstatus RMShowFirstCoreQueue(const RMcoreQueue corequeue, void **item)
{
	RMASSERT(corequeue!=NULL);
	
	if (RMGetCountCoreQueue(corequeue)==0) return RM_ERROR;
	
	*item=(corequeue->array)[corequeue->rd];
	
	return RM_OK;
}

RMuint32 RMGetCountCoreQueue (const RMcoreQueue corequeue)
{
	RMASSERT(corequeue!=NULL);

	return (corequeue->arrayEntries+corequeue->wr-corequeue->rd)%corequeue->arrayEntries;
}


RMuint32 RMGetMaxCountCoreQueue (const RMcoreQueue corequeue)
{
	if (corequeue==NULL) RMPanic(RM_FATALCOREQUEUENOTVALID);

	return corequeue->arrayEntries-1;
}
