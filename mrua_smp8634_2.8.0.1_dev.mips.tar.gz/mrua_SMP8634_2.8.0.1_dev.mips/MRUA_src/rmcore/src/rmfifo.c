/*****************************************
 Copyright © 2001-2004	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define RM_LIBRARY_SELF_COMPILING 1

#include "../include/rmcore.h"

#if 0
#define FIFODBG ENABLE
#else
#define FIFODBG DISABLE
#endif

struct RMfifo *RMfifo_open (RMuint32 data_address, RMuint32 data_size, RMuint32 fifo_address)
{
	struct RMfifo *fifo = (struct RMfifo *) fifo_address;
	fifo->base = data_address;
	fifo->size = data_size;
	fifo->rd = 0;
	fifo->wr = 0;
	return fifo;
}

void RMfifo_close (struct RMfifo *fifo)
{
	//RMASSERT(RMfifo_is_empty(fifo));
}

void RMfifo_flush (struct RMfifo *fifo)
{	
	fifo->rd = 0;
	fifo->wr = 0;	
}

static void RMfifo_get_pointer (struct RMfifo *fifo, RMuint32 *base, RMuint32 *size, RMuint32 *rd_ptr, RMuint32 *wr_ptr)
{
	*base = fifo->base;
	*size = fifo->size;
	*rd_ptr = fifo->rd;
	*wr_ptr = fifo->wr;
}

RMbool RMfifo_is_empty(struct RMfifo *fifo)
{
	RMuint32 base, size, rd, wr;
	RMfifo_get_pointer(fifo, &base, &size, &rd, &wr);
	return (rd == wr);
}

RMuint32 RMfifo_get_info(struct RMfifo *fifo, RMuint32 *data_start)
{
	*data_start = fifo->base;
	return fifo->size;
}

RMuint32 RMfifo_get_writable_size (struct RMfifo *fifo, RMuint32 *wr_ptr1, RMuint32 *wr_size1, RMuint32 *wr_ptr2)
{
	RMuint32 base, size, rd, wr;
	RMfifo_get_pointer(fifo, &base, &size, &rd, &wr);
	
	*wr_ptr1 = base + wr;
	if (wr >= rd) {
		if (rd > 0) {
			*wr_size1 = size - wr;
			*wr_ptr2 = base;
			return (*wr_size1 + rd - 1);
		}
		else {
			*wr_size1 = size - 1 - wr;
			*wr_ptr2 = 0;
			return (*wr_size1);
		}			
	}
	else {
		*wr_size1 = rd - 1 - wr;
		*wr_ptr2 = 0;
		return (*wr_size1);
	}
}

RMuint32 RMfifo_get_readable_size(struct RMfifo *fifo, RMuint32 *rd_ptr1, RMuint32 *rd_size1, RMuint32 *rd_ptr2)
{
	RMuint32 base, size, rd, wr;
	RMfifo_get_pointer(fifo, &base, &size, &rd, &wr);
	
	*rd_ptr1 = base + rd;
	if (wr >= rd) {
		*rd_size1 = wr - rd;
		*rd_ptr2 = 0;
		return (*rd_size1);
	}
	else {
		*rd_size1 = size - rd;
		*rd_ptr2 = base;
		return (*rd_size1 + wr);
	}
}

RMuint32 RMfifo_incr_write_ptr(struct RMfifo *fifo, RMuint32 incr)
{
	RMuint32 base, size, rd, wr;
	RMfifo_get_pointer(fifo, &base, &size, &rd, &wr);
	
	wr += incr;
	if (wr >= size)
		wr -= size;
	fifo->wr = wr;
	return wr + base;
}

RMuint32 RMfifo_incr_read_ptr(struct RMfifo *fifo, RMuint32 incr)
{
	RMuint32 base, size, rd, wr;
	RMfifo_get_pointer(fifo, &base, &size, &rd, &wr);
	
	rd += incr;
	if (rd >= size)
		rd -= size;
	fifo->rd = rd;
	return rd + base;
}

RMstatus RMFifoRead( RMuint8 *dest, RMuint32 size, RMuint8 **src1, RMuint32 *size1, RMuint8 **src2, RMuint32 *size2,  RMuint32 fifo )
{
	RMuint32 rd_size, rd_ptr1, rd_size1, rd_ptr2;
	rd_size = RMfifo_get_readable_size((struct RMfifo *)fifo, &rd_ptr1, &rd_size1, &rd_ptr2);

	RMDBGLOG((FIFODBG, "FIFO to rd  %lx from %lx to %p\n", size, rd_ptr1, dest ));
	if (rd_size <= 0) {
		*src1 = NULL;
		*src2 = NULL;
		RMDBGLOG((ENABLE, "RMFifoRead %lx empty: %lx %lx %lx %lx\n", rd_size, rd_ptr1, rd_size1, rd_ptr2, size - rd_size1));
		return RM_ERROR;
	}

	*src1 = (RMuint8 *)rd_ptr1;
	*src2 = (RMuint8 *)rd_ptr2;
	RMDBGLOG((FIFODBG, "FIFO rd starts!\n"));
	if (size <= rd_size1) {
		*size1 = size;
		*size2 = 0;
		RMMemcpy(dest,(void *)rd_ptr1,  size);
	}
	else if (size <= rd_size) {
		*size1 = rd_size1;
		*size2 = size - rd_size1;
		RMMemcpy(dest, (void *)rd_ptr1, rd_size1);
		RMMemcpy(dest + rd_size1, (void *)rd_ptr2, size - rd_size1);
	}
	else // size>rd_size
	{
		*size1 = rd_size1;
		*size2 = rd_size - rd_size1;
		RMMemcpy(dest, (void *)rd_ptr1, rd_size1);
		RMMemcpy(dest + rd_size1, (void *)rd_ptr2, rd_size - rd_size1);
	}

	RMDBGLOG((FIFODBG, "FIFO rd done!\n"));
	RMfifo_incr_read_ptr((struct RMfifo *)fifo, *size1 + *size2);
	RMDBGLOG((FIFODBG, "RMFifoRead  %lx: %lx %lx %lx %lx\n", size, rd_ptr1, *size1, rd_ptr2, *size2));
	return RM_OK;
}

RMstatus RMFifoWrite( RMuint8 *src, RMuint32 size, RMuint8 **dest1, RMuint32 *size1, RMuint8 **dest2, RMuint32 *size2, RMuint32 fifo )
{
	RMuint32 wr_ptr1, wr_size1, wr_ptr2;
	RMuint32 wr_size = RMfifo_get_writable_size((struct RMfifo *)fifo, &wr_ptr1, &wr_size1, &wr_ptr2);

	if (wr_size > size) {
		*dest1 = (RMuint8 *)wr_ptr1;
		if (wr_size1 <= size)
			*dest2 = (RMuint8 *)wr_ptr2;
		else
			*dest2 = NULL;
			
		if (wr_size1 >= size) {
			*size1 = size;
			*size2 = 0;
			RMMemcpy((void *)wr_ptr1, src, size);
		}
		else {
			*size1 = wr_size1;
			*size2 = size - wr_size1;
			RMMemcpy((void *)wr_ptr1, src, wr_size1);
			RMMemcpy((void *)wr_ptr2, src + wr_size1, size - wr_size1);
		}
		RMfifo_incr_write_ptr((struct RMfifo *)fifo, size);
		RMDBGLOG((FIFODBG, "RMFifoWrite           %lx: %lx %lx %lx %lx %lx\n", fifo, size, wr_ptr1, *size1, wr_ptr2, *size2));
		return RM_OK;
	}

	RMDBGLOG((FIFODBG, "RMFifoWrite           %lx insufficient size: %lx %lx %lx %lx %lx\n", fifo, wr_size, wr_ptr1, wr_size1, wr_ptr2, size - wr_size1));
	return RM_INSUFFICIENT_SIZE;
}

