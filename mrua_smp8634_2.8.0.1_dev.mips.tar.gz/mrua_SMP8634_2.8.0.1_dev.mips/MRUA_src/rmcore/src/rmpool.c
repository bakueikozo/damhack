/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define RM_LIBRARY_SELF_COMPILING 1

#include "../include/rmcore.h"

struct _RMpool {
	RMcorePool corePool;
	RMcriticalsection crit;
	RMsemaphore semCount;
	RMbool blocking;
	RMcriticalsectionOps *pCSops;
	RMsemaphoreOps *pSemops;
};

RMpool RMCreatePool(RMalignment alignment,RMuint32 nObjects,RMuint32 objectSize, RMpoolType poolType,RMcriticalsectionOps *pCSops,RMsemaphoreOps *pSemops)
{
	RMpool pool = (RMpool) RMMalloc(sizeof(struct _RMpool));

	if (pCSops==NULL) RMPanic(RM_FATAL);
	pool->pCSops=pCSops;
	if (pSemops==NULL) RMPanic(RM_FATAL);
	pool->pSemops=pSemops;
	
	pool->corePool = RMCreateCorePool(alignment,nObjects, objectSize);
	pool->crit = pool->pCSops->Create();
	pool->semCount = pool->pSemops->Create(nObjects);
	pool->blocking = (poolType == RM_POOL_BLOCKING) ? TRUE : FALSE;

	return pool;
}

RMpool RMCreatePoolInArea(RMalignment alignment, const RMuint8 *area, RMuint32 areaSize, RMuint32 objectSize, RMpoolType poolType)
{
	RMpool pool = (RMpool) RMMalloc(sizeof(struct _RMpool));

	pool->corePool = RMCreateCorePoolInArea(alignment, area, areaSize, objectSize);
	pool->crit = pool->pCSops->Create();
	pool->semCount = pool->pSemops->Create(RMGetAvailableCountCorePool(pool->corePool));
	pool->blocking = (poolType == RM_POOL_BLOCKING) ? TRUE : FALSE;

	return pool;
}

void RMDeletePool(RMpool pool)
{	
	RMDeleteCorePool(pool->corePool);
	pool->pCSops->Delete(pool->crit);
	pool->pSemops->Delete(pool->semCount);
	RMFree(pool);
}

void RMBorrowObjectFromPool(RMpool pool, void **pObject)
{	
	if (pool->blocking)
		pool->pSemops->WaitFor(pool->semCount);

	pool->pCSops->Enter(pool->crit);
	RMBorrowObjectFromCorePool(pool->corePool, pObject);
	pool->pCSops->Leave(pool->crit);
}

void RMReturnObjectToPool(RMpool pool,void *object)
{
	pool->pCSops->Enter(pool->crit);
	RMReturnObjectToCorePool(pool->corePool, object);
	if (pool->blocking)
		pool->pSemops->Release(pool->semCount, 1);
	pool->pCSops->Leave(pool->crit);

	return;
}

RMuint32 RMGetAvailableCountPool(RMpool pool)
{	
	RMuint32 count;
 
	pool->pCSops->Enter(pool->crit);
	count = RMGetAvailableCountCorePool(pool->corePool);
	pool->pCSops->Leave(pool->crit);

	return count;
}

void *RMGetObjectFromPoolByIndex(RMpool pool, RMuint32 index)
{
	void *object;

	pool->pCSops->Enter(pool->crit);
	object = RMGetObjectFromCorePoolByIndex(pool->corePool, index);
	pool->pCSops->Leave(pool->crit);
	
	return object;
}


RMuint32 RMGetPoolObjectIndex(RMpool pool, void *object)
{
	RMuint32 index;

	pool->pCSops->Enter(pool->crit);
	index = RMGetCorePoolObjectIndex(pool->corePool, object);
	pool->pCSops->Leave(pool->crit);
	
	return index;
}

RMuint32 RMGetPoolMaxObject(RMpool pool)
{
	return RMGetCorePoolMaxObject(pool->corePool);
}

