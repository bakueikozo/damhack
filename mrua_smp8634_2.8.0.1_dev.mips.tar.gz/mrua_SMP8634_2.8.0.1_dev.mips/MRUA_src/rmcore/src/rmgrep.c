/*****************************************
 Copyright � 2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define RM_LIBRARY_SELF_COMPILING 1

#include "../include/rmcore.h"

#if 0
#define RMGREPDBG ENABLE
#else
#define RMGREPDBG DISABLE
#endif

RMint32 RMGrepAnyStartCode(RMuint8 *buf,
			   RMint32 size, 
			   RMuint8 *pResult,
			   RMGrepStartCode_state *pState)
{
	RMint32 i=0;
	
	while (i<size) {
		switch (*pState) {
		case RMGREP_NOTHING: 
			switch (buf[i]) {
			case 0:
				*pState=RMGREP_GOT_00xxxxxx;
				break;
			default:
				// keep current state
				break;
			}
			break;

		case RMGREP_GOT_00xxxxxx:
			switch (buf[i]) {
			case 0:
				*pState=RMGREP_GOT_0000xxxx;
				break;
			default:
				*pState=RMGREP_NOTHING;
				break;
			}
			break;
			
		case RMGREP_GOT_0000xxxx:
			switch (buf[i]) {
			case 0:
				// keep current state
				break;
			case 1:
				*pState=RMGREP_GOT_000001xx;
				break;
			default:
				*pState=RMGREP_NOTHING;
				break;
			}
			break;
			
		case RMGREP_GOT_000001xx:
			*pResult=buf[i];
			*pState=RMGREP_NOTHING;
			RMDBGLOG((RMGREPDBG,"RMGrepAnyStartCode: 0x%02hx at %ld\n",*pResult,i+1));
			return i+1;
			break;
		}
		
		i++;
	}
	
	return -1;
}

RMint32 RMGrepSpecificStartCode(RMuint8 *buf,
				RMint32 size, 
				RMuint8 desiredStartCode,
				RMGrepStartCode_state *pState)
{
	RMint32 offset=0;
	
	while (1) {
		RMuint8 result;
		RMint32 suboffset;

		suboffset=RMGrepAnyStartCode(buf+offset,size-offset,&result,pState);
		if (suboffset==-1) return -1;
		
		offset+=suboffset;
		RMDBGLOG((RMGREPDBG,"RMGrepSpecificStartCode: candidate 0x%02hx at %ld\n",result,offset));
		if (result==desiredStartCode) break;
	}
	
	RMDBGLOG((RMGREPDBG,"RMGrepSpecificStartCode: ok at %ld\n",offset));
	return offset;
}
