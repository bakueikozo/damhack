/*****************************************
 Copyright � 2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define RM_LIBRARY_SELF_COMPILING 1

#include "../include/rmcore.h"

static RMstatus extract_substring_glouton(RMascii *dest, const RMascii *src,
				          const RMascii *key, RMascii delim, 
					  RMbool isKeyGlouton, RMbool isDelimGlouton)
{
	RMascii *strbegin;
	RMascii *strend;
	RMascii *strbeginglouton;
	RMascii *strendglouton;

	if(key != (RMascii *)NULL) {
		if (RMFindAsciiString (src, key, &strbegin) == -1) {
			return RM_ERROR;
		}

		if (isKeyGlouton){
			do{
				strbeginglouton = strbegin + RMasciiLength (key);
			}while(RMFindAsciiString (strbeginglouton, key, &strbegin) != -1);
			strbegin = strbeginglouton;
		}else{
			strbegin += RMasciiLength (key);
		}
	}
	else {
		strbegin  = (RMascii*)src;
	}

	if (isDelimGlouton){
		strbeginglouton = strbegin;
		strend = strbegin+RMasciiLength(strbegin);
		while (RMFindAsciiCharacter (strbeginglouton, delim, &strendglouton)){
			strend = strendglouton;
			strbeginglouton = strendglouton + 1;
		}
	}else{
		RMFindAsciiCharacter (strbegin, delim, &strend);
	}

	RMNCopyAscii (dest, strbegin, strend - strbegin);
	dest[strend - strbegin] = '\0';

       	return RM_OK;
}

static RMstatus extract_substring(RMascii *dest, const RMascii *src,
				  const RMascii *key, RMascii delim)
{
	return extract_substring_glouton(dest, src, key, delim, FALSE, FALSE);
}

RMstatus RMGetUrlPrefix(const RMascii *url, RMascii **prefix, RMascii **newUrl)
{
	RMint32 pos;
	RMascii *tmp;
	
	*prefix = (RMascii *) NULL;
	pos = RMFindAsciiString(url, "://", &tmp);
	if (pos > 0) {
		*prefix = RMMallocAscii(pos);
		RMNCopyAscii (*prefix, url, pos);
		(*prefix)[pos] = '\0';
		
		*newUrl = RMMallocAndDuplicateAscii(tmp + 3);
		return RM_OK;
	}

	return RM_INVALID_URL;
}
	
RMstatus RMGetBoardNumberFromUrl(const RMascii *url, RMascii **urlWithoutBoardNumber, RMuint32 *pBoardNumber)
{
	RMascii *p=(RMascii *)url;
	RMascii *boardNumberAsString;

	if (*p!='[') 
		return RM_ERROR;

	while ((*p != ']') && (*p != '\0')) 
		p++;

	if (*p == '\0')
		return RM_ERROR;

	boardNumberAsString=RMMallocAscii(p-url-1);
	RMNCopyAscii(boardNumberAsString,url+1,p-url-1);
	boardNumberAsString[p-url-1]=0;
	RMasciiToUInt32(boardNumberAsString,pBoardNumber);
	RMFreeAscii(boardNumberAsString);

	*urlWithoutBoardNumber = RMMallocAndDuplicateAscii (p+1);
	
	return RM_OK;
}


RMuint32 RMGetPropertiesFromBoardNumber(const RMascii *boardNumberAsString, 
                                        RMuint32 *properties, RMuint32 size)
{
        RMascii *p=(RMascii *)boardNumberAsString;
        RMuint32 index=0;
        RMascii *last_token=(RMascii *)boardNumberAsString;
        RMascii *propertyAsString;
       
        if ((size == 0) || (*p == '\0'))
                return 0;
        
        while (index <= size){
                if ( (*p == ',') || (*p == '\0') ){
                        propertyAsString=RMMallocAscii(p-last_token);
                        RMNCopyAscii(propertyAsString,last_token,p-last_token);
                        propertyAsString[p-last_token]=0;
                        RMasciiToUInt32(propertyAsString,&properties[index]);
                        RMFreeAscii(propertyAsString);
                        index++;
                        last_token=p+1;
                }
                if (*p == '\0')
                        break;
                p++;
        }
        
        return index;
}

RMstatus RMGetBoardPropertiesFromUrl(const RMascii *url, RMascii **urlWithoutProperties,
                                     RMascii **properties)
{
        RMascii *p=(RMascii *)url;

	if (*p!='[') 
		return RM_ERROR;

	while ((*p != ']') && (*p != '\0')) 
		p++;

	if (*p == '\0')
		return RM_ERROR;

	*properties=RMMallocAscii(p-url-1);
	RMNCopyAscii(*properties,url+1,p-url-1);
	(*properties)[p-url-1]=0;

	*urlWithoutProperties = RMMallocAndDuplicateAscii (p+1);

	return RM_OK;
}

RMstatus RMGetServerIPFromUrl(RMascii *url, RMascii **serverIP)
{
	RMascii *tempString;
	RMascii *location;

	if(url == (RMascii*)NULL)
		return RM_ERROR;
	
	tempString = RMMallocAscii(RMasciiLength(url));	

	extract_substring(tempString, url, "//", '/');

	if(RMFindAsciiCharacter (tempString, ':', &location) == TRUE)
		extract_substring(tempString, url, "//", ':');

	if((*serverIP) != (RMascii *)NULL)
		RMFreeAscii((*serverIP));

	(*serverIP) = RMMallocAscii(RMasciiLength (tempString));

	RMCopyAscii((*serverIP), tempString);

	RMFreeAscii(tempString);

	return RM_OK;
}

RMstatus RMGetServerPortFromUrl(RMascii *url, RMuint16 *port)
{

	RMascii *tempString;
	RMascii *location;

	if(url == (RMascii*)NULL)
		return RM_ERROR;
	
	*port = 0;

	tempString = RMMallocAscii(RMasciiLength(url));	

	extract_substring(tempString, url, "//", '/');

	if(RMFindAsciiCharacter (tempString, ':', &location) == TRUE) 
		RMasciiToUInt16 ((RMascii*)(location+1), port);

	RMFreeAscii(tempString);

	return RM_OK;
}

RMstatus RMGetUrlWithoutParametersFromUrl(RMascii *url, RMascii **newUrl)
{
	RMascii *tempStringNoParameter;
	RMascii *tempStringNoQuery;
	

	if(url == (RMascii*)NULL)
		return RM_ERROR;
	
	tempStringNoQuery = RMMallocAscii(RMasciiLength(url));	
	tempStringNoParameter = RMMallocAscii(RMasciiLength(url));	

	extract_substring_glouton(tempStringNoParameter, url, (RMascii*)NULL, '#', FALSE, TRUE);
	extract_substring(tempStringNoQuery, tempStringNoParameter, (RMascii*)NULL, '?');

	if((*newUrl) != (RMascii *)NULL)
		RMFreeAscii((*newUrl));

	(*newUrl) = RMMallocAscii(RMasciiLength (tempStringNoQuery));

	RMCopyAscii((*newUrl), tempStringNoQuery);

	RMFreeAscii(tempStringNoParameter);
	RMFreeAscii(tempStringNoQuery);

	return RM_OK;
}

RMstatus RMGetFileNameFromUrl(RMascii *url, RMascii **fileName)
{
	RMascii *tempString;
	RMascii *name;

	if(url == (RMascii*)NULL)
		return RM_ERROR;
	
	tempString = RMMallocAscii(RMasciiLength(url));	

	extract_substring_glouton(tempString, url, "//", '#', FALSE, TRUE);
	
	name = RMMallocAscii(RMasciiLength(tempString));	

	extract_substring_glouton(name, tempString, "/", '#', FALSE, TRUE);

	if((*fileName) != (RMascii *)NULL)
		RMFreeAscii((*fileName));

	(*fileName) = RMMallocAndDuplicateAscii (name);
	
	RMFreeAscii(tempString);
	RMFreeAscii(name);

	return RM_OK;
}

RMstatus RMGetParameterFromUrl(RMascii *url, RMascii *name, RMuint32 *value)
{
	RMascii *parameterName = (RMascii*)NULL;
	RMascii *parameterValue = (RMascii*)NULL;
	RMascii *stringParameters = (RMascii*)NULL;
	RMascii *ptrStringParameters = (RMascii*)NULL;
	RMascii *location = (RMascii*)NULL;
	RMstatus status;
	RMbool foundIt = FALSE;

	status = RM_ERROR;

	if ((url == NULL) || (name == NULL)) 
		return RM_ERROR;
	
	stringParameters = RMMallocAscii(RMasciiLength(url));	
	if(RMFAILED(extract_substring_glouton(stringParameters, url, "#", '/', TRUE, TRUE)))
		goto free_strings_and_return;
	   
	parameterName  = RMMallocAscii(RMasciiLength(stringParameters));
	parameterValue = RMMallocAscii(RMasciiLength(stringParameters));

	ptrStringParameters = stringParameters;
	
	while (RMFindAsciiCharacter (ptrStringParameters, '=', &location) == TRUE) {
		// parameter name
		extract_substring(parameterName, ptrStringParameters, (RMascii*)NULL, '=');
		ptrStringParameters += RMasciiLength(parameterName)+1;

		// parameter value
		extract_substring(parameterValue, ptrStringParameters, (RMascii*)NULL, ',');
		if(parameterValue[RMasciiLength(parameterValue)] == '/')
			extract_substring(parameterValue, ptrStringParameters, (RMascii*)NULL, '/');

		ptrStringParameters += RMasciiLength(parameterValue)+1;

		if (RMCompareAsciiCaseInsensitively(parameterName, name)) {
			RMasciiToUInt32(parameterValue, value);
			status = RM_OK;
			foundIt = TRUE;
			goto free_strings_and_return;
		}

	}
 free_strings_and_return:

	if(stringParameters != (RMascii*)NULL)
		RMFreeAscii(stringParameters);

	if(parameterValue != (RMascii*)NULL)
		RMFreeAscii(parameterValue);

	if(parameterName != (RMascii*)NULL)
		RMFreeAscii(parameterName);

	if(foundIt == TRUE)
		return RM_OK;	
	else
		return RM_ERROR;
}

RMstatus RMGetRealParameterFromUrl(RMascii *url, RMascii *name, RMreal *value)
{
	RMascii *parameterName = (RMascii*)NULL;
	RMascii *parameterValue = (RMascii*)NULL;
	RMascii *stringParameters = (RMascii*)NULL;
	RMascii *ptrStringParameters = (RMascii*)NULL;
	RMascii *location = (RMascii*)NULL;
	RMstatus status;
	RMbool foundIt = FALSE;

	status = RM_ERROR;

	if ((url == NULL) || (name == NULL)) 
		return RM_ERROR;
	
	stringParameters = RMMallocAscii(RMasciiLength(url));	
	if(RMFAILED(extract_substring_glouton(stringParameters, url, "#", '/', TRUE, TRUE)))
		goto free_strings_and_return;
	   
	parameterName  = RMMallocAscii(RMasciiLength(stringParameters));
	parameterValue = RMMallocAscii(RMasciiLength(stringParameters));

	ptrStringParameters = stringParameters;
	
	while (RMFindAsciiCharacter (ptrStringParameters, '=', &location) == TRUE) {
		// parameter name
		extract_substring(parameterName, ptrStringParameters, (RMascii*)NULL, '=');
		ptrStringParameters += RMasciiLength(parameterName)+1;

		// parameter value
		extract_substring(parameterValue, ptrStringParameters, (RMascii*)NULL, ',');
		if(parameterValue[RMasciiLength(parameterValue)] == '/')
			extract_substring(parameterValue, ptrStringParameters, (RMascii*)NULL, '/');

		ptrStringParameters += RMasciiLength(parameterValue)+1;

		if (RMCompareAsciiCaseInsensitively(parameterName, name)) {
			RMasciiToReal(parameterValue, value);
			status = RM_OK;
			foundIt = TRUE;
			goto free_strings_and_return;
		}

	}
 free_strings_and_return:

	if(stringParameters != (RMascii*)NULL)
		RMFreeAscii(stringParameters);

	if(parameterValue != (RMascii*)NULL)
		RMFreeAscii(parameterValue);

	if(parameterName != (RMascii*)NULL)
		RMFreeAscii(parameterName);

	if(foundIt == TRUE)
		return RM_OK;	
	else
		return RM_ERROR;
}	

RMstatus RMGetQueryFromUrl(RMascii *url, RMascii **query)
{	
	RMascii *stringQuery = (RMascii*)NULL;

	if (url == NULL) 
		return RM_ERROR;
	
	stringQuery = RMMallocAscii(RMasciiLength(url));	
	if(RMFAILED(extract_substring(stringQuery, url, "?", '#')))
		goto free_strings_and_return;

	*query = stringQuery;

	return RM_OK;
 free_strings_and_return:
	RMFreeAscii(stringQuery);
	*query = (RMascii*)NULL;
	return RM_ERROR;
}	

RMstatus RMGetAsciiParameterFromUrl(RMascii *url, RMascii *name, RMascii *value, RMuint32 maxLength)
{
	RMascii *parameterName = (RMascii*)NULL;
	RMascii *parameterValue = (RMascii*)NULL;
	RMascii *stringParameters = (RMascii*)NULL;
	RMascii *ptrStringParameters = (RMascii*)NULL;
	RMascii *location = (RMascii*)NULL;
	RMstatus status;
	RMbool foundIt = FALSE;

	status = RM_ERROR;

	if ((url == NULL) || (name == NULL)) 
		return RM_ERROR;
	
	stringParameters = RMMallocAscii(RMasciiLength(url));	
	if(RMFAILED(extract_substring_glouton(stringParameters, url, "#", '/', TRUE, TRUE)))
		goto free_strings_and_return;
	   
	parameterName  = RMMallocAscii(RMasciiLength(stringParameters));
	parameterValue = RMMallocAscii(RMasciiLength(stringParameters));

	ptrStringParameters = stringParameters;
	
	while (RMFindAsciiCharacter (ptrStringParameters, '=', &location) == TRUE) {
		// parameter name
		extract_substring(parameterName, ptrStringParameters, (RMascii*)NULL, '=');
		ptrStringParameters += RMasciiLength(parameterName)+1;

		// parameter value
		extract_substring(parameterValue, ptrStringParameters, (RMascii*)NULL, ',');
		if(parameterValue[RMasciiLength(parameterValue)] == '/')
			extract_substring(parameterValue, ptrStringParameters, (RMascii*)NULL, '/');

		ptrStringParameters += RMasciiLength(parameterValue)+1;

		if (RMCompareAsciiCaseInsensitively(parameterName, name)) {
			RMNCopyAscii (value, parameterValue, maxLength);
			status = RM_OK;
			foundIt = TRUE;
			goto free_strings_and_return;
		}

	}
 free_strings_and_return:

	if(stringParameters != (RMascii*)NULL)
		RMFreeAscii(stringParameters);

	if(parameterValue != (RMascii*)NULL)
		RMFreeAscii(parameterValue);

	if(parameterName != (RMascii*)NULL)
		RMFreeAscii(parameterName);

	if(foundIt == TRUE)
		return RM_OK;	
	else
		return RM_ERROR;
}	
