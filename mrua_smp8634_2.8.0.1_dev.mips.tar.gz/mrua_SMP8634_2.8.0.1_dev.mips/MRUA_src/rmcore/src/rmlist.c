/*****************************************
 Copyright � 2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define RM_LIBRARY_SELF_COMPILING 1

#include "../include/rmcore.h"

#if 0
#define LISTDBG ENABLE
#else
#define LISTDBG DISABLE
#endif

struct _RMlist {
	RMcoreList coreList;
	RMcriticalsection membersLock;
	RMsemaphore counterSemOccupied;
	RMcriticalsectionOps *pCSops;
	RMsemaphoreOps *pSemops;
};

RMlist RMCreateList(RMcriticalsectionOps *pCSops,RMsemaphoreOps *pSemops)
{
	RMlist pl = (RMlist) RMMalloc(sizeof(struct _RMlist));

	if (pCSops==NULL) RMPanic(RM_FATAL);
	pl->pCSops=pCSops;
	if (pSemops==NULL) RMPanic(RM_FATAL);
	pl->pSemops=pSemops;
	
	pl->membersLock=pl->pCSops->Create();
	
	pl->pCSops->Enter(pl->membersLock);
	{
		pl->counterSemOccupied=pl->pSemops->Create(0);
		pl->coreList = RMCreateCoreList();
	}
	pl->pCSops->Leave(pl->membersLock);
	
	return pl;
}

void RMDeleteList(RMlist list)
{
	if (list==NULL) 
		RMPanic(RM_FATALLISTNOTVALID);

 	list->pCSops->Enter(list->membersLock);
	
	RMDeleteCoreList(list->coreList);
	list->pSemops->Delete(list->counterSemOccupied);

 	list->pCSops->Leave(list->membersLock);

	list->pCSops->Delete(list->membersLock);

	RMFree(list);
}

void RMInsertFirstList(RMlist list,void *item)
{	
	if (list==NULL) 
		RMPanic(RM_FATALLISTNOTVALID);

	list->pCSops->Enter(list->membersLock);

	RMInsertFirstCoreList(list->coreList, item);
	list->pSemops->Release(list->counterSemOccupied,1);

	RMDBGLOG((LISTDBG,"RMInsertFirstList: in list %p, inserted %p\n",list,item));

  	list->pCSops->Leave(list->membersLock);
}	


void RMInsertLastList(RMlist list,void *item)
{	
	if (list==NULL) 
		RMPanic(RM_FATALLISTNOTVALID);

	list->pCSops->Enter(list->membersLock);

	RMInsertLastCoreList(list->coreList, item);
	list->pSemops->Release(list->counterSemOccupied,1);

	list->pCSops->Leave(list->membersLock);
}

void RMRemoveFirstList(RMlist list, void **item)
{	
	if (list==NULL) 
		RMPanic(RM_FATALLISTNOTVALID);

	list->pSemops->WaitFor(list->counterSemOccupied);
	
	list->pCSops->Enter(list->membersLock);
	if (RMFAILED(RMRemoveFirstCoreList(list->coreList, item)))
		RMPanic(RM_FATALLISTNOTVALID);

	list->pCSops->Leave(list->membersLock);
}

void RMRemoveLastList(RMlist list, void **item)
{	
	if (list==NULL) 
		RMPanic(RM_FATALLISTNOTVALID);

	list->pSemops->WaitFor(list->counterSemOccupied);
	
	list->pCSops->Enter(list->membersLock);

	if (RMFAILED(RMRemoveLastCoreList(list->coreList, item)))
		RMPanic(RM_FATALLISTNOTVALID);

	RMDBGLOG((LISTDBG,"RMRemoveLastList: in list %p, got %p\n",list,*item));

	list->pCSops->Leave(list->membersLock);
}

RMstatus RMShowLastList(RMlist list, void **item)
{
	RMstatus status;

	if (list==NULL) 
		RMPanic(RM_FATALLISTNOTVALID);

	list->pCSops->Enter(list->membersLock);
	status = RMShowLastItemCoreList(list->coreList, item);
	list->pCSops->Leave(list->membersLock);
	
	return status;
}

RMuint32 RMGetCountList(RMlist list)
{
	return list->pSemops->GetValue(list->counterSemOccupied);
}


void RMReverseList(RMlist list)
{
	if (list==NULL) 
		RMPanic(RM_FATALLISTNOTVALID);

	list->pCSops->Enter(list->membersLock);
	RMReverseCoreList(list->coreList);
	list->pCSops->Leave(list->membersLock);
}

RMstatus RMGetNextItemList(RMlist list, void **item, void **cookie)
{
	RMstatus status;
	if (list==NULL) 
		RMPanic(RM_FATALLISTNOTVALID);

	list->pCSops->Enter(list->membersLock);
	status = RMGetNextItemCoreList(list->coreList, item, cookie);
	list->pCSops->Leave(list->membersLock);

	return status;
}	

void RMRemoveCookieItemList(RMlist list, void **cookie)
{
	if (list==NULL) 
		RMPanic(RM_FATALLISTNOTVALID);

	list->pCSops->Enter(list->membersLock);
	if (RMSUCCEEDED(RMRemoveCookieItemCoreList(list->coreList, cookie)))
		list->pSemops->WaitFor(list->counterSemOccupied);
	else
		RMPanic(RM_FATALLISTNOTVALID);
	list->pCSops->Leave(list->membersLock);
}	

void RMInsertCookieItemList(RMlist list, void *item, void **cookie)
{
	if (list==NULL) 
		RMPanic(RM_FATALLISTNOTVALID);

	list->pCSops->Enter(list->membersLock);
	if (RMSUCCEEDED(RMInsertCookieItemCoreList(list->coreList, item, cookie)))
		list->pSemops->Release(list->counterSemOccupied, 1);
	else
		RMPanic(RM_FATALLISTNOTVALID);

	list->pCSops->Leave(list->membersLock);
}	
