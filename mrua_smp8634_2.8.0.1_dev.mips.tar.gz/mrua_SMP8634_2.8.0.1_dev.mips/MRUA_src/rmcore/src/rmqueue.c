/*****************************************
 Copyright � 2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define RM_LIBRARY_SELF_COMPILING 1

#include "../include/rmcore.h"

#if 0
   #define QUEUEDBG ENABLE
#else 
   #define QUEUEDBG DISABLE
#endif

struct _RMqueue {
	RMcoreQueue corequeue;
	RMcriticalsection membersLock;
	// these semaphores allow to the queue to block when it is full or empty
	RMsemaphore counterSemFree;
	RMsemaphore counterSemOccupied;
	RMcriticalsectionOps *pCSops;
	RMsemaphoreOps *pSemops;
};

RMqueue RMCreateQueue(RMuint32 maxItems,RMcriticalsectionOps *pCSops,RMsemaphoreOps *pSemops)
{
	RMqueue queue=(RMqueue)RMMalloc(sizeof(struct _RMqueue));

	if (pCSops==NULL) RMPanic(RM_FATAL);
	queue->pCSops=pCSops;
	if (pSemops==NULL) RMPanic(RM_FATAL);
	queue->pSemops=pSemops;

	queue->membersLock=queue->pCSops->Create();
	queue->pCSops->Enter(queue->membersLock);
	{
		queue->corequeue=RMCreateCoreQueue(maxItems);
		queue->counterSemFree=queue->pSemops->Create(maxItems);
		queue->counterSemOccupied=queue->pSemops->Create(0);
	}
	queue->pCSops->Leave(queue->membersLock);
	
	return queue;
}

void RMDeleteQueue(RMqueue queue)
{
	if (queue==NULL) RMPanic(RM_FATALQUEUENOTVALID);

	queue->pCSops->Enter(queue->membersLock);
	{
		if (RMGetCountCoreQueue(queue->corequeue)>0) RMPanic(RM_FATALQUEUENOTVALID);
		
		queue->pSemops->Delete(queue->counterSemOccupied);
		queue->pSemops->Delete(queue->counterSemFree);
		RMDeleteCoreQueue(queue->corequeue);
	}
	queue->pCSops->Leave(queue->membersLock);

	// if somebody does something now, too bad. User has to be aware of this.
	
	queue->pCSops->Delete(queue->membersLock);

	RMFree(queue);
}

void RMInsertFirstQueue(const RMqueue queue, void * item)
{
	if (queue==NULL) RMPanic(RM_FATALQUEUENOTVALID);

	queue->pSemops->WaitFor(queue->counterSemFree);
	
	queue->pCSops->Enter(queue->membersLock);
	{
		if (RMInsertFirstCoreQueue(queue->corequeue,item)!=RM_OK) RMPanic(RM_FATALQUEUENOTVALID);
		queue->pSemops->Release(queue->counterSemOccupied,1);
	}
	queue->pCSops->Leave(queue->membersLock);
}

void RMInsertLastQueue(const RMqueue queue, void * item)
{
	if (queue==NULL) RMPanic(RM_FATALQUEUENOTVALID);

	queue->pSemops->WaitFor(queue->counterSemFree);
	
	queue->pCSops->Enter(queue->membersLock);
	{
		if (RMInsertLastCoreQueue(queue->corequeue,item)!=RM_OK) RMPanic(RM_FATALQUEUENOTVALID);
		queue->pSemops->Release(queue->counterSemOccupied,1);      
	}
	queue->pCSops->Leave(queue->membersLock);
}

void RMRemoveFirstQueue(const RMqueue queue, void **item)
{
	if (queue==NULL) RMPanic(RM_FATALQUEUENOTVALID);
	
	queue->pSemops->WaitFor(queue->counterSemOccupied);
	
	queue->pCSops->Enter(queue->membersLock);
	{
		if (RMRemoveFirstCoreQueue(queue->corequeue,item)!=RM_OK) RMPanic(RM_FATALQUEUENOTVALID);
		queue->pSemops->Release(queue->counterSemFree,1);  	
	}
	queue->pCSops->Leave(queue->membersLock);
}

void RMRemoveLastQueue(const RMqueue queue, void **item)
{
	if (queue==NULL) RMPanic(RM_FATALQUEUENOTVALID);
	
	queue->pSemops->WaitFor(queue->counterSemOccupied);
	
	queue->pCSops->Enter(queue->membersLock);
	{
		if (RMRemoveLastCoreQueue(queue->corequeue,item)!=RM_OK) RMPanic(RM_FATALQUEUENOTVALID);
		queue->pSemops->Release(queue->counterSemFree,1);  
	}
	queue->pCSops->Leave(queue->membersLock);
}

RMstatus RMGetNextItemQueue(RMqueue queue, void **item, void **cookie)
{
	RMstatus status;
	
	if (queue==NULL) RMPanic(RM_FATALQUEUENOTVALID);
	
	queue->pCSops->Enter(queue->membersLock);
	status = RMGetNextItemCoreQueue(queue->corequeue,item,cookie);
	queue->pCSops->Leave(queue->membersLock);
	
	return status;
}

void RMRemoveCookieItemQueue(RMqueue queue, void **cookie)
{
	if (queue==NULL) RMPanic(RM_FATALQUEUENOTVALID);
	
	queue->pSemops->WaitFor(queue->counterSemOccupied);
		
	queue->pCSops->Enter(queue->membersLock);
	if (RMRemoveCookieItemCoreQueue(queue->corequeue,cookie)!=RM_OK) RMPanic(RM_FATALQUEUENOTVALID);
	// algorithmically non blocking
	queue->pSemops->Release(queue->counterSemFree,1); 
	queue->pCSops->Leave(queue->membersLock);
}

void RMInsertCookieItemQueue(RMqueue queue,void *item,void **cookie)
{
	if (queue==NULL) RMPanic(RM_FATALQUEUENOTVALID);
	
	queue->pSemops->WaitFor(queue->counterSemFree);

	queue->pCSops->Enter(queue->membersLock);
	if (RMInsertCookieItemCoreQueue(queue->corequeue,item,cookie)!=RM_OK) RMPanic(RM_FATALQUEUENOTVALID);
	// algorithmically non blocking
	queue->pSemops->Release(queue->counterSemOccupied,1); 
	queue->pCSops->Leave(queue->membersLock);
}

RMstatus RMShowLastQueue(const RMqueue queue, void **item)
{
	RMstatus answer;

	if (queue==NULL) RMPanic(RM_FATALQUEUENOTVALID);

	queue->pCSops->Enter(queue->membersLock);
	{
		answer=RMShowLastCoreQueue(queue->corequeue,item);
	}
	queue->pCSops->Leave(queue->membersLock);
	
	return answer;
}

RMstatus RMShowFirstQueue(const RMqueue queue, void **item)
{
	RMstatus answer;

	if (queue==NULL) RMPanic(RM_FATALQUEUENOTVALID);

	queue->pCSops->Enter(queue->membersLock);
	{
		answer=RMShowFirstCoreQueue(queue->corequeue,item);
	}
	queue->pCSops->Leave(queue->membersLock);
	
	return answer;
}

void RMBlockingShowLastQueue(const RMqueue queue, void **item)
{
	if (queue==NULL) RMPanic(RM_FATALQUEUENOTVALID);

	queue->pSemops->WaitFor(queue->counterSemOccupied);

	queue->pCSops->Enter(queue->membersLock);
	{
		if (RMShowLastCoreQueue(queue->corequeue,item)!=RM_OK) RMPanic(RM_FATALQUEUENOTVALID);
		queue->pSemops->Release(queue->counterSemOccupied,1);
	}
	queue->pCSops->Leave(queue->membersLock);
}

RMuint32 RMGetCountQueue (const RMqueue queue)
{
	RMuint32 retval;

	if (queue==NULL) RMPanic(RM_FATALQUEUENOTVALID);

	queue->pCSops->Enter(queue->membersLock);
	{
		retval = RMGetCountCoreQueue(queue->corequeue);
	}
	queue->pCSops->Leave(queue->membersLock);
	
	return retval;
}

RMuint32 RMGetMaxCountQueue (const RMqueue queue)
{
	// thread safe because I know RMGetMaxCountCoreQueue is one operation (hack)
	return RMGetMaxCountCoreQueue (queue->corequeue);
}
