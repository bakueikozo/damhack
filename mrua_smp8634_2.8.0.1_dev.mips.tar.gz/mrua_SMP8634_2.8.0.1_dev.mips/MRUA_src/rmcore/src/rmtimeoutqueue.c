/*****************************************
 Copyright � 2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define RM_LIBRARY_SELF_COMPILING 1

#include "../include/rmcore.h"

#if 0
   #define TIMEOUTQUEUEDBG ENABLE
#else 
   #define TIMEOUTQUEUEDBG DISABLE
#endif

struct _RMtimeoutQueue {
	RMcoreQueue corequeue;
	RMcriticalsection membersLock;
	// these semaphores allow to the queue to block when it is full or empty
	RMtimeoutSemaphore counterSemFree;
	RMtimeoutSemaphore counterSemOccupied;
	RMcriticalsectionOps *pCSops;
	RMtimeoutSemaphoreOps *pSemops;
};

RMtimeoutQueue RMCreateTimeoutQueue(RMuint32 maxItems,RMcriticalsectionOps *pCSops,RMtimeoutSemaphoreOps *pSemops)
{
	RMtimeoutQueue queue=(RMtimeoutQueue)RMMalloc(sizeof(struct _RMtimeoutQueue));

	if (pCSops==NULL) RMPanic(RM_FATAL);
	queue->pCSops=pCSops;
	if (pSemops==NULL) RMPanic(RM_FATAL);
	queue->pSemops=pSemops;

	queue->membersLock=queue->pCSops->Create();
	queue->pCSops->Enter(queue->membersLock);
	{
		queue->corequeue=RMCreateCoreQueue(maxItems);
		queue->counterSemFree=queue->pSemops->Create(maxItems);
		queue->counterSemOccupied=queue->pSemops->Create(0);
	}
	queue->pCSops->Leave(queue->membersLock);
	
	return queue;
}

void RMDeleteTimeoutQueue(RMtimeoutQueue queue)
{
	if (queue==NULL) RMPanic(RM_FATALQUEUENOTVALID);

	queue->pCSops->Enter(queue->membersLock);
	{
		if (RMGetCountCoreQueue(queue->corequeue)>0) RMPanic(RM_FATALQUEUENOTVALID);
		
		queue->pSemops->Delete(queue->counterSemOccupied);
		queue->pSemops->Delete(queue->counterSemFree);
		RMDeleteCoreQueue(queue->corequeue);
	}
	queue->pCSops->Leave(queue->membersLock);

	// if somebody does something now, too bad. User has to be aware of this.
	
	queue->pCSops->Delete(queue->membersLock);

	RMFree(queue);
}

RMstatus RMInsertFirstTimeoutQueue(const RMtimeoutQueue queue, void * item, RMuint64 microsec)
{
	RMstatus status;
	if (queue==NULL) RMPanic(RM_FATALQUEUENOTVALID);

	status = queue->pSemops->WaitFor(queue->counterSemFree, microsec);
	
	if(status == RM_TOS_EVENT){
		queue->pCSops->Enter(queue->membersLock);
		{
			if (RMInsertFirstCoreQueue(queue->corequeue,item)!=RM_OK) RMPanic(RM_FATALQUEUENOTVALID);
			queue->pSemops->Release(queue->counterSemOccupied,1);
		}
		queue->pCSops->Leave(queue->membersLock);
	}

	return status;
}

RMstatus RMInsertLastTimeoutQueue(const RMtimeoutQueue queue, void * item, RMuint64 microsec)
{
	RMstatus status;
	if (queue==NULL) RMPanic(RM_FATALQUEUENOTVALID);

	status = queue->pSemops->WaitFor(queue->counterSemFree, microsec);

	if(status == RM_TOS_EVENT){
		queue->pCSops->Enter(queue->membersLock);
		{
			if (RMInsertLastCoreQueue(queue->corequeue,item)!=RM_OK) RMPanic(RM_FATALQUEUENOTVALID);
			queue->pSemops->Release(queue->counterSemOccupied,1);      
		}
		queue->pCSops->Leave(queue->membersLock);
	}

	return status;
}

RMstatus RMRemoveFirstTimeoutQueue(const RMtimeoutQueue queue, void **item, RMuint64 microsec)
{
	RMstatus status;
	if (queue==NULL) RMPanic(RM_FATALQUEUENOTVALID);
	
	status = queue->pSemops->WaitFor(queue->counterSemOccupied, microsec);
		
	if(status == RM_TOS_EVENT){
		queue->pCSops->Enter(queue->membersLock);
		{
			if (RMRemoveFirstCoreQueue(queue->corequeue,item)!=RM_OK) RMPanic(RM_FATALQUEUENOTVALID);
			queue->pSemops->Release(queue->counterSemFree,1);  	
		}
		queue->pCSops->Leave(queue->membersLock);
	}

	return status;
}

RMstatus RMRemoveLastTimeoutQueue(const RMtimeoutQueue queue, void **item, RMuint64 microsec)
{
	RMstatus status;
	if (queue==NULL) RMPanic(RM_FATALQUEUENOTVALID);
	
	status = queue->pSemops->WaitFor(queue->counterSemOccupied, microsec);
	
	if(status == RM_TOS_EVENT){
		queue->pCSops->Enter(queue->membersLock);
		{
			if (RMRemoveLastCoreQueue(queue->corequeue,item)!=RM_OK) RMPanic(RM_FATALQUEUENOTVALID);
			queue->pSemops->Release(queue->counterSemFree,1);  
		}
		queue->pCSops->Leave(queue->membersLock);
	}

	return status;
}

RMstatus RMGetNextItemTimeoutQueue(RMtimeoutQueue queue, void **item, void **cookie)
{
	RMstatus status;
	
	if (queue==NULL) RMPanic(RM_FATALQUEUENOTVALID);
	
	queue->pCSops->Enter(queue->membersLock);
	status = RMGetNextItemCoreQueue(queue->corequeue,item,cookie);
	queue->pCSops->Leave(queue->membersLock);
	
	return status;
}

RMstatus RMRemoveCookieItemTimeoutQueue(RMtimeoutQueue queue, void **cookie, RMuint64 microsec)
{
	RMstatus status;
	if (queue==NULL) RMPanic(RM_FATALQUEUENOTVALID);
	
	status = queue->pSemops->WaitFor(queue->counterSemOccupied, microsec);
		
	if(status == RM_TOS_EVENT){
		queue->pCSops->Enter(queue->membersLock);
		if (RMRemoveCookieItemCoreQueue(queue->corequeue,cookie)!=RM_OK) RMPanic(RM_FATALQUEUENOTVALID);
		// algorithmically non blocking
		queue->pSemops->Release(queue->counterSemFree,1); 
		queue->pCSops->Leave(queue->membersLock);
	}

	return status;
}

RMstatus RMInsertCookieItemTimeoutQueue(RMtimeoutQueue queue,void *item,void **cookie, RMuint64 microsec)
{
	RMstatus status;
	if (queue==NULL) RMPanic(RM_FATALQUEUENOTVALID);
	
	status = queue->pSemops->WaitFor(queue->counterSemFree, microsec);

	if(status == RM_TOS_EVENT){
		queue->pCSops->Enter(queue->membersLock);
		if (RMInsertCookieItemCoreQueue(queue->corequeue,item,cookie)!=RM_OK) RMPanic(RM_FATALQUEUENOTVALID);
		// algorithmically non blocking
		queue->pSemops->Release(queue->counterSemOccupied,1); 
		queue->pCSops->Leave(queue->membersLock);	
	}

	return status;
}

RMstatus RMShowLastTimeoutQueue(const RMtimeoutQueue queue, void **item)
{
	RMstatus answer;

	if (queue==NULL) RMPanic(RM_FATALQUEUENOTVALID);

	queue->pCSops->Enter(queue->membersLock);
	{
		answer=RMShowLastCoreQueue(queue->corequeue,item);
	}
	queue->pCSops->Leave(queue->membersLock);
	
	return answer;
}

RMstatus RMShowFirstTimeoutQueue(const RMtimeoutQueue queue, void **item)
{
	RMstatus answer;

	if (queue==NULL) RMPanic(RM_FATALQUEUENOTVALID);

	queue->pCSops->Enter(queue->membersLock);
	{
		answer=RMShowFirstCoreQueue(queue->corequeue,item);
	}
	queue->pCSops->Leave(queue->membersLock);
	
	return answer;
}

RMstatus RMBlockingShowLastTimeoutQueue(const RMtimeoutQueue queue, void **item, RMuint64 microsec)
{
	RMstatus status;
	if (queue==NULL) RMPanic(RM_FATALQUEUENOTVALID);

	status = queue->pSemops->WaitFor(queue->counterSemOccupied, microsec);

	if(status == RM_TOS_EVENT){
		queue->pCSops->Enter(queue->membersLock);
		{
			if (RMShowLastCoreQueue(queue->corequeue,item)!=RM_OK) RMPanic(RM_FATALQUEUENOTVALID);
			queue->pSemops->Release(queue->counterSemOccupied,1);
		}
		queue->pCSops->Leave(queue->membersLock);
	}

	return status;
}

RMuint32 RMGetCountTimeoutQueue (const RMtimeoutQueue queue)
{
	RMuint32 retval;

	if (queue==NULL) RMPanic(RM_FATALQUEUENOTVALID);

	queue->pCSops->Enter(queue->membersLock);
	{
		retval = RMGetCountCoreQueue(queue->corequeue);
	}
	queue->pCSops->Leave(queue->membersLock);
	
	return retval;
}

RMuint32 RMGetMaxCountTimeoutQueue (const RMtimeoutQueue queue)
{
	// thread safe because I know RMGetMaxCountCoreQueue is one operation (hack)
	return RMGetMaxCountCoreQueue (queue->corequeue);
}

