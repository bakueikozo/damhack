/*****************************************
 Copyright � 2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define RM_LIBRARY_SELF_COMPILING 1

// stdarg with gcc 2.95.3 uses macros with compiler types
#define ALLOW_OS_CODE 1
#include "../include/rmcore.h"

#include <stdarg.h>

#define AsciiToInt(c) ((c) - '0')
#define IsInt(c) ((c) >= '0' && (c) <= '9')?TRUE:FALSE


RMuint32 RMasciiLength (const RMascii *string)
{
	RMuint32 i;

	i = 0;
	while (*string != '\0') {
		string++;
		i++;
	}

	return i;
}

RMbool RMCompareAscii (const RMascii *a,
		       const RMascii *b)
{
	while (*a != '\0' && *b != '\0') {
		if (*a != *b) {
			return FALSE;
		}
		a++;
		b++;
	}
	
	/* still have to see if one string is not shorter than the other. Both
	   pointers must be at the end */
	if (*a == '\0' && *b == '\0')
		return TRUE;
	else
		return FALSE; 
}

RMbool RMNCompareAscii (const RMascii *a,
			const RMascii *b,RMuint32 rank)
{
	RMuint32 i=0;

	for (i=0;i<rank;i++) {
		if (
		    (a[i]=='\0')
		    ||
		    (b[i]=='\0')
		    ||
		    (a[i]!=b[i]) 
		    ) 
			return FALSE;
	}

	return TRUE;
}

RMbool RMNCompareAsciiCaseInsensitively (const RMascii *a,
				       const RMascii *b,
				       RMuint32 rank)
{
	RMuint32 i=0;

	for (i=0;i<rank;i++) {
		if (
		    (a[i]=='\0')
		    ||
		    (b[i]=='\0')
		    ||
		    (RMasciiCharacterToLower(a[i]) != RMasciiCharacterToLower(b[i])) 
		    ) 
			return FALSE;
	}

	return TRUE;
}


RMbool RMCompareAsciiCaseInsensitively (const RMascii *a,
					const RMascii *b)
{
	while (*a != '\0' && *b != '\0') {
		if (RMasciiCharacterToLower(*a) != RMasciiCharacterToLower(*b)) {
			return FALSE;
		}
		a++;
		b++;
	}
	
	/* still have to see if one string is not shorter than the other. Both
	   pointers must be at the end */
	if (*a == '\0' && *b == '\0')
		return TRUE;
	else
		return FALSE;
}

void RMCopyAscii (RMascii *dest, const RMascii *src)
{
	while (*src != '\0') {
		*dest = *src;
		dest++;
		src++;
	}
	*dest = '\0';
}

RMascii *RMMallocAndDuplicateAscii (const RMascii *string)
{
	RMuint32 size;
	RMascii *retval;

	size = RMasciiLength (string);

	retval = RMMalloc (size+1);

	RMCopyAscii (retval, string);

	return retval;
}

void RMFreeAscii (RMascii *string)
{
	RMFree (string);
}

void RMasciiToLower (const RMascii *str, RMascii *lowStr)
{
	while (*str != '\0') {
		*lowStr = RMasciiCharacterToLower (*str);
		str++;
		lowStr++;
	}
	*lowStr = *str;
}

RMascii RMasciiCharacterToLower (RMascii character)
{
	if ( ('A'<=character) && (character<='Z') ) {
		return (character-'A')+'a';
	} else {
		return character;
	}
}

void RMasciiToUpper (const RMascii *str, RMascii *upperStr)
{
	while (*str != '\0') {
		*upperStr = RMasciiCharacterToUpper (*str);
		str++;
		upperStr++;
	}
}

RMascii RMasciiCharacterToUpper (RMascii character)
{
	if ( ('a'<=character) && (character<='z') ) {
		return (character-'a')+'A';
	} else {
		return character;
	}
}

void RMTranslateAscii(RMascii *str, RMascii in, RMascii out)
{
	while ((*str) != '\0') {
		if ((*str) == in)
			*str = out;
		str++;
	}
}

static void StripLeadingSpaces (RMascii **str)
{
	while ((**str) != '\0' &&
	       (**str) == ' ') {
		(*str)++;
	}
}

static RMbool IsPositive (RMascii **str)
{
	RMbool retval;

	switch (**str) {
	case '-':
		(*str)++;
		retval = FALSE;
		break;
	case '+':
		(*str)++;
		retval = TRUE;
		break;
	default:
		retval = TRUE;
		break;
	}


	return retval;
}

#define GenericConversion(str,value) \
	{			     \
		RMbool isPositive;   \
		RMascii *strCopy;    \
				     \
		strCopy = (RMascii *)str;	\
		*value = 0;			\
						\
		StripLeadingSpaces (&strCopy);	\
		isPositive = IsPositive (&strCopy);	\
		StripLeadingSpaces (&strCopy);		\
							\
		if (isPositive) {			\
			while (IsInt(*strCopy)) {			\
				*value = (*value) * 10 + AsciiToInt (*strCopy); \
				strCopy++;				\
			}						\
		} else {						\
			while (IsInt (*strCopy)) {			\
				*value = (*value) * 10 - AsciiToInt (*strCopy); \
				strCopy++;				\
			}						\
		}							\
	}

void RMasciiToUInt8 (const RMascii *str, RMuint8 *value)
{
	GenericConversion (str,value);
}

void RMasciiToUInt16 (const RMascii *str, RMuint16 *value)
{
	GenericConversion (str,value);
}

void RMasciiToInt32(const RMascii *str, RMint32 *value)
{
	GenericConversion (str,value);
}

void RMasciiToUInt32(const RMascii *str, RMuint32 *value)
{
	GenericConversion (str,value);
}

void RMasciiToInt64(const RMascii *str, RMint64 *value)
{
	GenericConversion (str,value);
}

void RMasciiToUInt64(const RMascii *str, RMuint64 *value)
{
	GenericConversion (str,value);
}

void RMasciiToReal(const RMascii *str, RMreal *value)
{
        RMbool                  decimal = FALSE;
        RMreal                  accum;
        RMreal                  mult;
        RMuint32                i = 0;

        *value = 0.0;
        mult = 0.0;
        accum = 0.0;

        if(str == (RMascii*) NULL)
                return ;

        while (str[i] != (RMuint8)'\0') {
                if (IsInt(str[i])) {
                        if (decimal == FALSE) {
                                accum *= 10.0;
                                accum += str[i] - '0';
                        } 
                        else {
                                accum += ((str[i] - '0') * mult);
                                mult /= 10.0;
                        }
                } 
                else if (str[i] == (RMuint8)'.') {
                        decimal = TRUE;
                        mult = .1;
                }
                else {
                        *value = 0.0;
                        return;
                }

                i++;
        }

        *value += accum;
}

RMbool RMFindAsciiCharacter (const RMascii *str, RMascii character, RMascii **location)
{
	
	*location = (RMascii *)str;

	while(**location != '\0')
	{
		if(**location == character)
			return TRUE;
		
		(*location)++;
	}

	return FALSE;
}

RMint32 RMFindAsciiString (const RMascii *str, const RMascii *stringToFind, RMascii **location)
{
	RMascii *strIntermediate;
	RMascii *strToFind;
	RMbool	found = FALSE;
	*location = (RMascii *)str;
	
	while(**location != '\0')
	{
		if(**location == stringToFind[0])
		{
			strIntermediate = *location;
			strToFind = (RMascii *)&stringToFind[0];
			found = TRUE;
			while (*strToFind != '\0') 
			{
				if (*strIntermediate != *strToFind) 
				{
					found = FALSE;
					break;
					
				}
				strIntermediate++;
				strToFind++;
			}

			if (found)
				return (RMint32) (*location - str);
		}
		
		(*location)++;
	}

	return -1;
}

void RMNCopyAscii (RMascii *dest, const RMascii *src, RMuint32 n)
{
	RMuint32 i,sourceLength=RMasciiLength(src);
	
	for (i=0;i<n;i++) {
		if (i<sourceLength) {
			*dest = *src;
			dest++;
			src++;
		}
		else {
			*dest='\0';
			dest++;
		}
	}
}

RMascii *RMMallocAscii (RMuint32 sizeWithoutTrailingZero)
{
	RMascii *str;

	str = (RMascii *)RMCalloc(sizeWithoutTrailingZero+1, sizeof(RMascii));

	return str;
}

RMascii * RMCatAscii(const RMascii* str1, ...)
{
	RMuint32   l;
	va_list args;
	RMascii *s;
	RMascii *concat;

	if (str1 == NULL) {
		return NULL;
	}

	l = 1 + RMasciiLength (str1);
	va_start (args, str1);
	s = va_arg (args, RMascii*);
	while (s)
		{
			l += RMasciiLength (s);
			s = va_arg (args, RMascii*);
		}
	va_end (args);

	concat = RMMalloc (l);
	concat[0] = 0;

	RMAppendAscii (concat, str1);
	va_start (args, str1);
	s = va_arg (args, RMascii*);
	while (s)
		{
			RMAppendAscii (concat, s);
			s = va_arg (args, RMascii*);
		}
	va_end (args);

	return concat;
}

void RMAppendAscii (RMascii *dest, const RMascii *src)
{
	dest += RMasciiLength (dest);

	RMCopyAscii (dest, src);
}


void RMasciiHexToUint16(const RMascii *str, RMuint16 *value)
{
	RMascii *strCopy;
	RMuint8 val;

	strCopy = (RMascii *)str;
	*value = 0; 

	StripLeadingSpaces (&strCopy); 

	while (RMasciiHexCharacterToUInt8(*strCopy, &val) == RM_OK) { 
		*value = (*value) * 16 + val; 
		strCopy++; 
	} 

}

void RMasciiHexToUint64(const RMascii *str, RMuint64 *value)
{
	RMascii *strCopy;
	RMuint8 val;

	strCopy = (RMascii *)str;
	*value = 0; 

	StripLeadingSpaces (&strCopy); 

	while (RMasciiHexCharacterToUInt8(*strCopy, &val) == RM_OK) { 
		*value = (*value) * 16 + val; 
		strCopy++; 
	} 

}

void RMasciiHexToUint32(const RMascii *str, RMuint32 *value)
{
	RMascii *strCopy;
	RMuint8 val;

	strCopy = (RMascii *)str;
	*value = 0; 

	StripLeadingSpaces (&strCopy); 

	while (RMasciiHexCharacterToUInt8(*strCopy, &val) == RM_OK) { 
		*value = (*value) * 16 + val; 
		strCopy++; 
	} 

}

RMstatus RMasciiHexCharacterToUInt8(RMascii c, RMuint8 *value)
{
	RMstatus status;

	status = RM_OK;

	if ((c <= '9') && (c >= '0'))
		*value = (RMuint8)(c-'0');
	else if ((c <= 'F') && (c >= 'A'))
		*value = (RMuint8)((c-'A')+10);
	else if ((c <= 'f') && (c >= 'a'))
		*value = (RMuint8)((c-'a')+10);
	else
		status = RM_ERROR;

	return status;
}

RMbool RMasciiCharacterIsDigit (RMuint8 c)
{
	return IsInt (c);
}
