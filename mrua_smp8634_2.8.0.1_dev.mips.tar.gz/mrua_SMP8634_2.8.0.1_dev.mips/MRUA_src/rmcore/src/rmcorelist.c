/*****************************************
 Copyright � 2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define RM_LIBRARY_SELF_COMPILING 1

#include "../include/rmcore.h"

struct _RMcoreList {
	struct _RMcoreList *nextNode;
	void *item;
};

RMcoreList RMCreateCoreList(void)
{
	RMcoreList list = (RMcoreList) RMMalloc(sizeof(struct _RMcoreList));

	list->item = NULL;
	list->nextNode = NULL;
	
	return list;
}

void RMDeleteCoreList(RMcoreList list)
{
	if (list == NULL) {
		RMDBGLOG ((ENABLE, "Deleting invalid core list.\n"));
		RMPanic(RM_FATALLISTNOTVALID);
	} else if (list->nextNode != NULL) {
		RMDBGLOG ((ENABLE, "Deleting non-empty core list.\n"));
		RMPanic(RM_FATALLISTNOTVALID);
	}
	
	RMFree(list);
}

void RMInsertFirstCoreList(RMcoreList list,void *item)
{	
	struct _RMcoreList *newNode;

	if (list==NULL) {
		RMDBGLOG ((ENABLE, "Invalid list in insert first\n"));
		RMPanic(RM_FATALLISTNOTVALID);
	}

	newNode = (struct _RMcoreList *) RMMalloc(sizeof(struct _RMcoreList));
	
	newNode->item = item;
	newNode->nextNode = list->nextNode;
	list->nextNode = newNode;
}

void RMInsertLastCoreList(RMcoreList list,void *item)
{	
	struct _RMcoreList *newNode;
	struct _RMcoreList *node;

	if (list==NULL) {
		RMDBGLOG ((ENABLE, "Invalid list in insert last\n"));
		RMPanic(RM_FATALLISTNOTVALID);
	}

	newNode = (struct _RMcoreList *)RMMalloc(sizeof(struct _RMcoreList));
	newNode->item=item;
	newNode->nextNode=NULL;
	
	node = list;
	while (node->nextNode != NULL)
		node = node->nextNode;
	
	node->nextNode = newNode;
}

RMstatus RMRemoveFirstCoreList(RMcoreList list, void **item)
{	
	struct _RMcoreList *node;
	
	if (list == NULL) {
		RMDBGLOG ((ENABLE, "Invalid list in remove first\n"));
		RMPanic(RM_FATALLISTNOTVALID);
	}

	if (list->nextNode == NULL)
		return RM_LISTISEMPTY;

	node = list->nextNode;
	*item = node->item;

	list->nextNode = node->nextNode;

	RMFree(node);

	return RM_OK;
}

RMstatus RMRemoveLastCoreList(RMcoreList list, void **item)
{	
	struct _RMcoreList *node, *prev;
 
	if (list == NULL) {
		RMDBGLOG ((ENABLE, "Invalid list in remove last\n"));
		RMPanic(RM_FATALLISTNOTVALID);
	}

	if (list->nextNode == NULL)
		return RM_LISTISEMPTY;

	node = list;
	prev = NULL;
	while (node->nextNode != NULL) {  // we enter here at least once (otherwise RM_LISTISEMPTY)
		prev = node;
		node = node->nextNode;
	}
	
	*item = node->item;
	RMFree(node);
	prev->nextNode = NULL;  // here prev is not NULL
	
	return RM_OK;
}

void RMReverseCoreList(RMcoreList list)
{
	struct _RMcoreList *node, *next, *prev;

	if (list == NULL) {
		RMDBGLOG ((ENABLE, "Invalid list in reverse\n"));
		RMPanic(RM_FATALLISTNOTVALID);
	}
	
	prev = NULL;	
	node = list->nextNode;
	
	while (node != NULL) {
		next = node->nextNode;
		node->nextNode = prev;
		prev = node;
		node = next;
	}

	list->nextNode = prev;
}

RMstatus RMGetNextItemCoreList(RMcoreList list, void **item, void **cookie)
{
	struct _RMcoreList *node;
	RMstatus status;

	if (list == NULL) {
		RMDBGLOG ((ENABLE, "Invalid list in getnext\n"));
		RMPanic(RM_FATALLISTNOTVALID);
	}

	if (*cookie == NULL) {
		*cookie = list;
		
		if (list->nextNode == NULL)
			return RM_LISTISEMPTY;
		
		*item = list->nextNode->item;
		return RM_OK;
	}
		
	node = (struct _RMcoreList *) *cookie;
	if (node->nextNode->nextNode == NULL) {
		status = RM_ERROR;
	}
	else {
		*item = node->nextNode->nextNode->item;
		status = RM_OK;
	}
	
	*cookie = node->nextNode;

	return status;
}

RMstatus RMRemoveCookieItemCoreList(RMcoreList list, void **cookie)
{
	struct _RMcoreList *node, *next;

	if (list == NULL) {
		RMDBGLOG ((ENABLE, "Invalid list in remove cookie\n"));
		RMPanic(RM_FATALLISTNOTVALID);
	}
	
	if (list->nextNode == NULL)
		return RM_LISTISEMPTY;
	
	node = (struct _RMcoreList *) *cookie;
	next = node->nextNode;

	node->nextNode = next->nextNode;
	RMFree(next);

	/* if we removed the first element, the next call to getnext must
	   return the new first element. */
	if (node == list)
		*cookie = NULL;
	else {
		next = (struct _RMcoreList *) list;
		while (next->nextNode != node) 
			next = next->nextNode;
		*cookie = next;
	}

	return RM_OK;
}

RMstatus RMInsertCookieItemCoreList(RMcoreList list, void *item, void **cookie)
{
	struct _RMcoreList *node, *newNode;

	if (list == NULL) {
		RMDBGLOG ((ENABLE, "Invalid list in insert cookie\n"));
		RMPanic(RM_FATALLISTNOTVALID);
	}
	
	node = (struct _RMcoreList *) *cookie;

	newNode = (struct _RMcoreList *)RMMalloc(sizeof(struct _RMcoreList));
	newNode->item=item;
	newNode->nextNode=node->nextNode;
	node->nextNode = newNode;
	
	return RM_OK;
}
		
RMstatus RMShowLastItemCoreList(RMcoreList list, void **item)
{
	struct _RMcoreList *node;
	
	if (list == NULL) {
		RMDBGLOG ((ENABLE, "Invalid list in show last\n"));
		RMPanic(RM_FATALLISTNOTVALID);
	}
	
	if (list->nextNode == NULL)
		return RM_LISTISEMPTY;
	
	node = list;
	while (node->nextNode != NULL) {  // we enter here at least once (otherwise RM_LISTISEMPTY)
		node = node->nextNode;
	}
	
	*item = node->item;
	
	return RM_OK;
}
