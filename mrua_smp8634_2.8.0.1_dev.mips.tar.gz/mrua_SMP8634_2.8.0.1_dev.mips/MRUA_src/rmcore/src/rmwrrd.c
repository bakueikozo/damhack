/*****************************************
 Copyright � 2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/*
  @file   rmwrrd.c
  See licensing details in LICENSING file  
*/

#define RM_LIBRARY_SELF_COMPILING 1

#include "../include/rmcore.h"

#if 1
#define WRRDDBG DISABLE
#else
#define WRRDDBG ENABLE
#endif

struct tagRMwrrd {
	RMuint8 *address;
	RMuint32 size;
	RMuint32 rd,wr;
	RMMemcpyLike *WriteF,*ReadF;
	RMcriticalsection cs;
	RMcriticalsectionOps *pCSops;
};

RMwrrd RMCreateWRRD(RMuint8 *address,RMuint32 size,RMMemcpyLike WriteF,RMMemcpyLike ReadF,RMcriticalsectionOps *pCSops)
{	
	RMwrrd h=RMMalloc(sizeof(struct tagRMwrrd));
	h->address=address;
	h->size=size;
	h->wr=0;
	h->rd=0;
	h->WriteF=WriteF;
	h->ReadF=ReadF;

	h->pCSops=pCSops;
	if (h->pCSops!=NULL) h->cs=h->pCSops->Create();
	
	return h;
}

void RMDeleteWRRD(RMwrrd h)
{
	if (h->pCSops!=NULL) h->pCSops->Delete(h->cs);
	RMFree(h);
}

static RMuint32 RMWriteWRRD_contiguous(RMwrrd h,RMuint8 *sourceData,RMuint32 desiredWriteLength)
{
	RMuint32 actuallyWritten;

	RMDBGLOG((WRRDDBG,"W: wr=%ld rd=%ld desired=%ld\n",h->wr,h->rd,desiredWriteLength));
	
	// normal case
	actuallyWritten=desiredWriteLength;
	// if rd is inside the ]wr,wr+desiredWriteLength] interval, restrict
	if ((h->wr<h->rd)&&(h->rd<=h->wr+desiredWriteLength)) actuallyWritten=h->rd-h->wr-1;
	/* if rd is zero, wr can't be updated to h->size afterwards (both rd and wr would 
	   have the same value afterwards, reserved to code emptiness) */
	if ((h->rd==0)&&(h->wr+desiredWriteLength==h->size)) actuallyWritten=desiredWriteLength-1;

	h->WriteF(h->address+h->wr,sourceData,actuallyWritten);

	h->wr+=actuallyWritten;
	if (h->wr==h->size) h->wr=0;

	RMDBGLOG((WRRDDBG,"W: wr=%ld rd=%ld actually=%ld\n",h->wr,h->rd,actuallyWritten));

	return actuallyWritten;
}

static RMuint32 RMReadWRRD_contiguous(RMwrrd h,RMuint8 *targetData,RMuint32 desiredReadLength)
{
	RMuint32 actuallyRead;

	RMDBGLOG((WRRDDBG,"R: wr=%ld rd=%ld desired=%ld\n",h->wr,h->rd,desiredReadLength));
	
	// normal case
	actuallyRead=desiredReadLength;
	// if wr is inside the [rd,rd+desiredReadLength[ interval, restrict
	if ((h->rd<=h->wr)&&(h->wr<h->rd+desiredReadLength)) actuallyRead=h->wr-h->rd;
	// no special case like RMWriteWRRD_contiguous to handle ;-)

	h->ReadF(targetData,h->address+h->rd,actuallyRead);

	h->rd+=actuallyRead;
	if (h->rd==h->size) h->rd=0;

	RMDBGLOG((WRRDDBG,"R: wr=%ld rd=%ld actually=%ld\n",h->wr,h->rd,actuallyRead));

	return actuallyRead;
}

RMuint32 RMWriteWRRD(RMwrrd h,RMuint8 *sourceData,RMuint32 desiredWriteLength)
{
	RMuint32 placeLeftAtTop,actuallyWritten;
	
	if (h->pCSops!=NULL) h->pCSops->Enter(h->cs);
	
	placeLeftAtTop=h->size-h->wr;
	
	if (placeLeftAtTop>=desiredWriteLength) {
		// normal situation
		actuallyWritten=RMWriteWRRD_contiguous(h,sourceData,desiredWriteLength);
		goto wayout;
	}
	else {
		// have to do two steps
		
		// do little chunk at top...
		actuallyWritten=RMWriteWRRD_contiguous(h,sourceData,placeLeftAtTop);
		if (actuallyWritten<placeLeftAtTop) goto wayout;

		// sanity check: wr must have looped.
		if (h->wr!=0) RMPanic(RM_FATAL);

		// and little chunk at bottom...
		actuallyWritten+=RMWriteWRRD_contiguous(h,sourceData+placeLeftAtTop,desiredWriteLength-placeLeftAtTop);
		goto wayout;
	}
	
 wayout:
	if (h->pCSops!=NULL) h->pCSops->Leave(h->cs);

	return actuallyWritten;
}

RMuint32 RMReadWRRD(RMwrrd h,RMuint8 *targetData,RMuint32 desiredReadLength)
{
	RMuint32 placeLeftAtTop,actuallyRead;
	
	if (h->pCSops!=NULL) h->pCSops->Enter(h->cs);
	
	placeLeftAtTop=h->size-h->rd;
	
	if (placeLeftAtTop>=desiredReadLength) {
		// normal situation
		actuallyRead=RMReadWRRD_contiguous(h,targetData,desiredReadLength);
		goto wayout;
	}
	else {
		// have to do two steps
		
		// do little chunk at top...
		actuallyRead=RMReadWRRD_contiguous(h,targetData,placeLeftAtTop);
		if (actuallyRead<placeLeftAtTop) goto wayout;

		// sanity check: rd must have looped.
		if (h->rd!=0) RMPanic(RM_FATAL);
		
		// and little chunk at bottom...
		actuallyRead+=RMReadWRRD_contiguous(h,targetData+placeLeftAtTop,desiredReadLength-placeLeftAtTop);
		goto wayout;
	}
	
 wayout:
	if (h->pCSops!=NULL) h->pCSops->Leave(h->cs);

	return actuallyRead;
}

RMuint32 RMReportUsedWRRD(RMwrrd h)
{
	RMuint32 answer;

	if (h->pCSops!=NULL) h->pCSops->Enter(h->cs);
	if (h->wr>=h->rd)
		answer=h->wr-h->rd;
	else
		answer=h->size-(h->rd-h->wr);
	if (h->pCSops!=NULL) h->pCSops->Leave(h->cs);

	return answer;
}

void RMResetWRRD(RMwrrd h)
{
	if (h->pCSops!=NULL) h->pCSops->Enter(h->cs);
	h->wr=0;
	h->rd=0;
	if (h->pCSops!=NULL) h->pCSops->Leave(h->cs);
}
