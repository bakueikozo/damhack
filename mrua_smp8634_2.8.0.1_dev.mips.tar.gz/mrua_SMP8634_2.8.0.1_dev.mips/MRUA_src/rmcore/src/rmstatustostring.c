/*****************************************
 Copyright � 2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define RM_LIBRARY_SELF_COMPILING 1

#include "../include/rmcore.h"

static RMascii *errorArray [] = {
#undef RM_DEFINE_ERROR
#define RM_DEFINE_ERROR(x,v) "RM_" # x,
#include "../../rmdef/rmstatus.inc"
#undef RM_DEFINE_ERROR
};

const RMascii *RMstatusToString (RMstatus error)
{
	return errorArray[error-RM_ERROR_FIRST__-1];
}
