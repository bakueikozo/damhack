/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define RM_LIBRARY_SELF_COMPILING 1

#include "../include/rmcore.h"

#ifdef USE_LEAK_CHECKER
#include "../../rmleakchecker/include/rmleakchecker.h"
#endif //USE_LEAK_CHECKER

struct _RMcorePool {
	RMuint32 nObjects;
	RMuint32 objectSize;
	RMuint32 stride; 
	RMbool allocatedBuffer;
	RMuint8 *area;
	void **firstFree;
#ifdef _DEBUG
	RMuint32 useCount;
	RMuint32 useCountMax;
#endif // _DEBUG
#ifdef USE_LEAK_CHECKER
	RMleakChecker checker;
#endif //USE_LEAK_CHECKER
};

#if 0
#define COREPOOLDBG ENABLE
#else 
#define COREPOOLDBG DISABLE
#endif

#define VALIDADDRESSTOINDEX(pool,addr) (((RMuint8 *)(addr)-(pool)->area)/(pool)->stride)
#define VALIDINDEXTOADDRESS(pool,i) ((pool)->area+i*(pool)->stride)

static void Init (RMcorePool pool)
{
	RMint32 i;
	// chain free ones (decreasing order makes they will be borrowed in increasing mem addresses)
	pool->firstFree=NULL;
	for (i=pool->nObjects-1;i>=0;i--) {
		void **link=(void **)VALIDINDEXTOADDRESS(pool,i);
		*link=pool->firstFree;
		pool->firstFree=link;
	}

#ifdef _DEBUG
	pool->useCount=0;
	pool->useCountMax=0;
#endif // _DEBUG

#ifdef USE_LEAK_CHECKER
	pool->checker = RMCreateLeakChecker ();
#endif //USE_LEAK_CHECKER
}

RMcorePool RMCreateCorePoolInArea(RMalignment alignment,const RMuint8 *area, RMuint32 areaSize, RMuint32 objectSize)
{
	RMcorePool pool;

	pool = (RMcorePool) RMMalloc(sizeof(struct _RMcorePool));
	pool->objectSize=objectSize;
	// stride is the distance in bytes between two records
	pool->stride=((pool->objectSize+alignment-1)/alignment)*alignment;

	if ((areaSize % pool->stride) != 0) {
		RMDBGLOG ((ENABLE, "RMCreateCorePoolInArea: buffer size/alignment constraints does not fit the object size.\n"));
		RMPanic (RM_ERROR);
	}

	pool->nObjects = areaSize / pool->stride;
	pool->area = (RMuint8 *)area;
	pool->allocatedBuffer = FALSE;

	Init (pool);

	RMDBGLOG((COREPOOLDBG,"RMCreateCorePoolInArea: pool %p ready (%dx%dbytes)\n",pool,pool->nObjects,pool->objectSize));

	return pool;
}

RMcorePool RMCreateCorePool(RMalignment alignment,RMuint32 nObjects,RMuint32 objectSize)
{
	RMcorePool pool=(RMcorePool) RMMalloc(sizeof(struct _RMcorePool));

	pool->nObjects=nObjects;
	pool->objectSize=objectSize;
	pool->allocatedBuffer = TRUE;

	// stride is the distance in bytes between two records
	pool->stride=((pool->objectSize+alignment-1)/alignment)*alignment;

	pool->area = (RMuint8 *) RMMalloc(pool->nObjects*pool->stride);

	Init (pool);
	
	RMDBGLOG((COREPOOLDBG,"RMCreateCorePool: pool %p ready (%dx%dbytes)\n",pool,pool->nObjects,pool->objectSize));
		  
	return pool;
}

void RMDeleteCorePool(RMcorePool pool)
{	
	RMuint32 i,borrowedCount;
	void **borrowedOnes=RMMalloc(pool->nObjects*sizeof(void*));
	
	RMGetArrayOfBorrowedOnesCorePool(pool,borrowedOnes,&borrowedCount);

	for (i=0;i<borrowedCount;i++) {
		RMDBGLOG((COREPOOLDBG,"RMDeleteCorePool: in pool %p, #%d (%p) borrowed, never returned!\n",
			  pool,
			  VALIDADDRESSTOINDEX(pool,borrowedOnes[i]),
			  borrowedOnes[i]));
	}
	
	if (borrowedCount>0) {
		RMDBGLOG ((ENABLE, "Borrowed count: %d\n", borrowedCount));
#ifdef USE_LEAK_CHECKER
		RMPrintLeaksLeakChecker (pool->checker);
#endif //USE_LEAK_CHECKER
		RMPanic(RM_FATALCOREPOOLLEAKS);
	}
	
	RMFree(borrowedOnes);

	if (pool->allocatedBuffer) {
		RMFree(pool->area);
	}

#ifdef USE_LEAK_CHECKER
	RMDeleteLeakChecker (pool->checker);
#endif //USE_LEAK_CHECKER

	RMDBGLOG((COREPOOLDBG,
		  "RMDeleteCorePool: in pool %p, peak usage=%d/%d (%d%%)\n",
		  pool,
		  pool->useCountMax,
		  pool->nObjects,
		  100*pool->useCountMax/pool->nObjects)); 	
	
	RMFree(pool);
}

void RMBorrowObjectFromCorePool(RMcorePool pool, void **pObject)
{	
	RMuint8 *border=(RMuint8 *)pool->firstFree;
	
	// no more objects
	if (border==NULL) {
		RMDBGLOG((ENABLE,"RMBorrowObjectFromCorePool: in pool %p, overflow (increase the value: %d)\n",pool,pool->nObjects));
		RMPanic(RM_FATALCOREPOOLOVERFLOW);
	}

	// remove from free list
	pool->firstFree=*(void **)border;
	
#ifdef _DEBUG
	/* don't leave in the way something that looks like a valid pointer
	   read RMReturnObjectToCorePool before removing this */
	RMMemset((void *)border, 0x66, pool->objectSize);
#endif

	*pObject=border;
	RMDBGLOG((COREPOOLDBG,"RMBorrowObjectFromCorePool: in pool %p, borrowed #%d (%p)\n",
		  pool,
		  VALIDADDRESSTOINDEX(pool,*pObject),
		  *pObject));

#ifdef _DEBUG
	pool->useCount++;
	pool->useCountMax=RMmax(pool->useCountMax,pool->useCount);
#endif // _DEBUG

#ifdef USE_LEAK_CHECKER
	RMRecordMallocLeakChecker (pool->checker, *pObject, pool->objectSize);
#endif //USE_LEAK_CHECKER
}

// we might expose this...
static RMbool RMIsInsideCorePool(RMcorePool pool, void *object)
{
	RMuint32 offset;
	
	// before left border?
	if (((RMuint8 *)object)<VALIDINDEXTOADDRESS(pool,0)) return FALSE;

	// after right border?
	if (((RMuint8 *)object)>=VALIDINDEXTOADDRESS(pool,pool->nObjects)) return FALSE;
	
	offset = ((RMuint8 *)object) - pool->area;
	
	// not on a boundary?
	if (offset%pool->stride!=0) return FALSE;
	
	RMDBGLOG((COREPOOLDBG,
		  "RMIsInsideCorePool: in pool %p, talking about #%d (%p)\n",
		  pool,
		  VALIDADDRESSTOINDEX(pool,object),
		  object));
	
	return TRUE;
}

static void EnsureNotInside (RMcorePool pool, void *object)
{
	// O(n) deterministic method (will dramatically slow down execution!)	
	void **link;
	for (link=pool->firstFree;link!=NULL;link=*link) {
		if (link == (void **)object) 
			RMPanic(RM_FATALCOREPOOLRETURNEDTWICE);
	}
}

void RMReturnObjectToCorePool(RMcorePool pool,void *object)
{
	if (!RMIsInsideCorePool (pool, object)) {
		RMDBGLOG ((ENABLE, "Object is not mine: %p in %p\n", object, pool));
		RMPanic(RM_FATALCOREPOOLISNOTMINE);
	}
	
	// sanity check: if the user returns twice the same object, we detect it here
#if 1	
	/* O(1) probabilist method: if the four first bytes store something that matches a border,
	   this looks like something that has freshly been RMReturnObjectToCorePool()'d.
	*/
	if (RMIsInsideCorePool (pool,*(void **)object)) {
		EnsureNotInside (pool, object);
	}
#else 
	EnsureNotInside (pool, object);
#endif

	// return to pool.
	*(void **)object=pool->firstFree;
	pool->firstFree=(void **)object;

#ifdef _DEBUG
	pool->useCount--;
#endif // _DEBUG
#ifdef USE_LEAK_CHECKER
	RMRecordFreeLeakChecker (pool->checker, object);
#endif //USE_LEAK_CHECKER
}

RMuint32 RMGetAvailableCountCorePool(RMcorePool pool)
{	
	void **link;
	RMuint32 answer=0;
	
	for (link=pool->firstFree;link!=NULL;link=*link) answer++;
	
	return answer;
}

void *RMGetObjectFromCorePoolByIndex(RMcorePool pool, RMuint32 index)
{
	RMASSERT(index < pool->nObjects);
	
	return (void *) VALIDINDEXTOADDRESS(pool,index);
}


RMuint32 RMGetCorePoolObjectIndex(RMcorePool pool, void *object)
{
	return (RMuint32) VALIDADDRESSTOINDEX(pool, object);
}
	

void RMGetArrayOfBorrowedOnesCorePool(RMcorePool pool,void **borrowedOnes,RMuint32 *pBorrowedCount)
{
#define ISBORROWED(i) (RMbool *)(borrowedOnes+i)

	void **link;
	RMuint32 i,j;
	
	for (i=0;i<pool->nObjects;i++) *ISBORROWED(i)=TRUE;

	for (link=pool->firstFree;link!=NULL;link=*link) {
		RMuint32 k=((RMuint8 *)link-pool->area)/pool->stride;
		*ISBORROWED(k)=FALSE;
	}
	
	j=0;
	for (i=0;i<pool->nObjects;i++) if (*ISBORROWED(i)) {
		borrowedOnes[j]=VALIDINDEXTOADDRESS(pool,i);
		j++;
	}
	
	*pBorrowedCount=j;
}

RMuint32 RMGetCorePoolMaxObject(RMcorePool pool)
{
	return pool->nObjects;
}
