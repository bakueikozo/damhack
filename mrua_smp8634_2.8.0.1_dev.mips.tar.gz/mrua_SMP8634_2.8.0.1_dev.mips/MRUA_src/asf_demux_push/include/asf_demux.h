/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   asf_demux.h
  @brief  Demultiplexer for Microsoft Advanced Systems Format (ASF)

@verbatim
  Input: Buffer
  Output: Callbacks

  Usage:
    1. declare and allocate (struct asf_demux_state_t*)
    2. call asf_demux_init
    3. regsiter the callbacks
    4. call asf_demux as many times as you need to
    5. call asf_demux_reset, if needed, to recover from missed/ing data (within the ASF Data Object)
@endverbatim

  Unsupported features:
    - see Application_Specific_Object_Handler for unsupported headers

  @author Guillaume Etorre
  @date   2003-01-17
*/

#ifndef __ASF_DEMUX_H__
#define __ASF_DEMUX_H__

enum Standard_Payload_Extension_Sytem_ID {
	ASF_Payload_Extension_System_Pixel_Aspect_Ratio   = 0x0001,
	ASF_Payload_Extension_System_Encryption_Sample_ID = 0x0002,
	ASF_Payload_Extension_System_Timecode             = 0x0004,
	ASF_Payload_Extension_System_File_Name            = 0x0008,
	ASF_Payload_Extension_System_Content_Type         = 0x0010,
	ASF_Payload_Extension_System_Sample_Duration      = 0x0020
};

struct asf_demux_state_t;

/**
   Returns the size of the internal state demux structure
   (for mem allocation purposes)
   @return
   sizeof(struct asf_demux_state_t)
*/

unsigned long asf_demux_state_t_getsize (void);
/**
   
   asf_demux initialization

   Initialize demux
   @param asf_demux_state 
   Pointer on internal demux state struct
   @param context
   Pointer which is sent back to each callback.
   @return
   0 if internal state struct has been succesfully initialized, -1 otherwise.
*/

int asf_demux_init
(
 struct asf_demux_state_t *asf_demux_state,
 void *context
 );

/**
   in case of streaming ASF file, this function needs to be called to
   change the demux behavior
*/
void asf_demux_set_streaming_behavior(struct asf_demux_state_t *asf_demux_state);

/**

   Callback registering function.
   Unused entries must be set to NULL.
   The callbacks can change after the registering function is called (maybe ...), but the
   pointer to the callbacks must not.
   
   @param asf_demux_state
   Pointer on internal demux state struct
   @param
   @param
   @param
   @param
   @param
   @param
   @param
   @param
   @return 
   0 if registering has been OK, -1 otherwise.
   
*/

int asf_demux_register_callbacks 
(
 struct asf_demux_state_t *asf_demux_state,

/**

  Callback to handle GUIDs not supported by asf_demux.

  Currently unsupported GUIDs include:
    - Header Extension Object
    - Script Command Object
    - Marker Object
    - Error Correction Object
    - Content Description Object
    - Extended Content Description Object
    - Type Specific Data Length in a Command-type Stream Properties Object
       in this last case only, the Data is Size bytes long

  All unsupported GUIDs are skipped by asf_demux after the callback is processed

  @param context
  @param GUID
    The GUID is transfered in the same byte order as in the ASF file.
  @param Size
    As read in the ASF file
  @param Data
    (Size - 24) bytes long (except for Type Specific Data Length
    in a ASF_Command_Media type ASF_Stream_Properties_Object).
*/
  
  void (*Application_Specific_Object_Handler)
       (
	void *context,
	unsigned char GUID[16],
	unsigned char *Name,
	unsigned char *Data,
	unsigned long long Partial_Size,                // bytes
	unsigned long long Size               // bytes
	),

/**

  Callback to handle the file properties.

  Called once at the beginning of the demux.

  @param context
  @param File_Size
    Size of the entire file. Invalid if Broadcast mode.
  @param Creation_Date
    See MSDN for details
  @param Data_Packets_Count
    Invalid if Broadcast mode.
  @param Play_Duration
    Time needed to play the file. Invalid if Broadcast mode.
  @param Send_Duration
    Time needed to send the file. 
    Invalid if Broadcast mode.
  @param Preroll
    Amount of time to buffer data before starting to play the file.
  @param Minimum_Data_Packet_Size
    Minimum size of a data packet.
    Should be equal to Maximum_Data_Packet_Size.
    Invalid if Broadcast mode.
  @param Maximum_Data_Packet_Size
    Maximum size of a data packet.
    Should be equal to Minimum_Data_Packet_Size.
    Invalid if Broadcast mode.
  @param Maximum_Bitrate
    Maximum bitrate for the entire file.
    Data packetization overhead is included in the count.
  @param Broadcast
    Specifies the file is currently being written.
    asf_demux does not currently support Broadcast files.
  @param Seekable
    Specifies the file is seekable. This either implies that 
    Maximum_Data_Packet_Size is equal to Minimum_Data_Packet_Size,
    or that a Simple Index object is present for each video stream.

*/
  void (*ASF_File_Properties_Handler)
       (
	void *context,
	unsigned long long File_Size,                 // bytes (invalid if Broadcast)
	unsigned long long Creation_Date,             // See MSDN Library
	unsigned long long Data_Packets_Count,        // (invalid if Broadcast)
	unsigned long long Play_Duration,             // 100-ns units (invalid if Broadcast)
	unsigned long long Send_Duration,             // 100-ns units (invalid if Broadcast)
	unsigned long long Preroll,                   // milliseconds
	unsigned long Minimum_Data_Packet_Size,       // bytes
	unsigned long Maximum_Data_Packet_Size,       // bytes
	unsigned long Maximum_Bitrate,                // bits/s
	unsigned char Broadcast,                      // boolean
	unsigned char Seekable                        // boolean
	),

 /**

   Callback to receive bitrate information on the streams

   @param context
   @param Stream_Number
   @param Average_Bitrate

*/

  void (*ASF_Stream_Bitrate_Properties_Handler)
       (
	void *context,
	unsigned char Stream_Number,                  // 1..127
	unsigned long Average_Bitrate                 // bits/s
	),
  
  /**

     Callback to create a new video stream

     @param context
     @param Stream_Number
     @param Compression_ID
       Type of compression, as in the biCompression
       field of a BITMAPINFOHEADER structure. See MSDN Library.
     @param Image_Width
     @param Image_Height
     @param *Codec_Specific_Data
     @param Codec_Specific_Data_Size
  */
  
  void (*ASF_Video_Stream_Properties_Handler)
       (
	void *context,
	unsigned char Stream_Number,                  // 1..127
	unsigned long Compression_ID,                 // See MSDN Library
	unsigned long Image_Width,                    // pixels
	unsigned long Image_Height,                   // pixels
	unsigned char *Codec_Specific_Data,
	unsigned long Partial_Codec_Specific_Data_Size,
	unsigned long Codec_Specific_Data_Size        // bytes
	),

/**
   Callback to create a new audio stream

   @param context
   @param Stream_Number
   @param Codec_ID
     Defined in the MSDN Library as the wFormatTag field
     of a WAVEFORMATEX structure
   @param Number_of_Channels
   @param Samples_Per_Second
   @param Bits_Per_Sample
   @param Codec_Specific_Data
   @param Codec_Specific_Data_Size
*/
  
  void (*ASF_Audio_Stream_Properties_Handler)
       (
	void *context,
	unsigned char Stream_Number,                  // 1..127
	unsigned short Codec_ID,                      // see MSDN Library
	unsigned short Number_of_Channels,
	unsigned long Samples_Per_Second,
	unsigned long Average_Number_of_Bytes_Per_Second,
	unsigned short Block_Alignment,
	unsigned short Bits_Per_Sample,
	unsigned char *Codec_Specific_Data,
	unsigned long Partial_Codec_Specific_Data_Size,
	unsigned long Codec_Specific_Data_Size        // bytes
	),

/**

   Callback to signal mutually exclusive bitstreams.

   Each value of mutex_index is associated with multiple
   Stream_Number values. Only one Stream_Number should be
   used per mutex_index value.
   
   @param context
   @param mutex_index
   @param Stream_Numbers_Count
   Constant for a given mutex_index
   @param bitrate_exclusion
   Signals that the mutually exclusive streams encode
   the same content at different bitrates.
   Constant for a given mutex_index
   @param Stream_Number
*/
  
  void (*ASF_Bitrate_Mutual_Exclusion_Handler)
       (
	void *context,
	unsigned long mutex_index,
	unsigned short Stream_Numbers_Count,
	unsigned char bitrate_exclusion,              // boolean
	unsigned char Stream_Number                   // 1..127
	),
 /**
    Callback for DRM clients (Secret + Key ID + license URL)
    
    @param context
    @param Secret_Data
    Array of bytes containing secret data.
    @param Secret_Data_Length
    Size of secret data array.
    @param Key_ID
    Key_ID ASCII string.
    @param KeyID_Length
    Key_ID length.
    @param License_URL
    License server URL (ASCII string).
    @param License_URL_Length
    Length of license URL string.
 */

 void (*ASF_Content_Encryption_Handler)
 (
  void *context,
  unsigned char *Secret_Data,
  unsigned long Partial_Secret_Data_Length,
  unsigned long Secret_Data_Length,
  unsigned char *Key_ID,                                // ASCII char
  unsigned long Partial_Key_ID_Length,
  unsigned long Key_ID_Length,
  unsigned char *License_URL,                           // ASCII char
  unsigned long Partial_License_URL_Length,
  unsigned long License_URL_Length
  ),

 /**
    Callback for DRM clients ( XML )

    @param context
    @param Data
    Array of bytes required by the DRM client to 
    manipulate the protected content (XML using 16-bit WCHAR)
    @parma Data_Size
    Array size.
 */
 
 void (*ASF_Extended_Content_Encryption_Handler)
 (
  void *context,
  unsigned char *Data,
  unsigned long Partial_Data_Size,
  unsigned long Data_Size
  ),
 
 /**
    Callback for handling standard Payload Extension Systems.
    It will be called successively for each Payload Extension System present 
    within the Replicated Data of a given Media Object (ASF Data Packet).
    
    @param context
    @param Stream_Number
    @param Media_Object_Number
    Number of the Audio or Video frame.
    @param Media_Object_Number_valid
    @param Payload_Extension_System_ID
    Refers to enum Standard_Payload_Extension_Sytem_ID
    @param Payload_Extension_System_Data
    Pointer to the payload extension buffer.
    @param Partial_Payload_Extension_System_Data
    Number of payload extension bytes to be read.
    @param Payload_Extension_System_Data_Size
    Total number of bytes for this particular payload extension.
    @param bytes_left
    Number of payload bytes remaining.
 */
 
 void (*ASF_Payload_Extension_System_Handler)
 (
  void *context,
  unsigned short Stream_Number,
  unsigned long Media_Object_Number,
  unsigned char Media_Object_Number_valid,      // boolean
  unsigned short Payload_Extension_System_ID,
  unsigned char *Payload_Extension_System_Data,
  unsigned short Partial_Payload_Extension_System_Data_Size,
  unsigned short Payload_Extension_System_Data_Size,
  unsigned short bytes_left
  ),
 
 /**
    Callback which returns the digital signature of the part 
    of the header which lies between the end of the File Properties object
    and the beginning of the Digital Signature Object.
    
    @param context
    @param Signature_Data
    Signature data buffer.
    @param Signature_Data_Length
    Size of the Signature.
 */

 void (*ASF_Digital_Signature_Handler)
 (
  void *context,
  unsigned char *Signature_Data,
  unsigned long Partial_Signature_Data_Length,
  unsigned long Signature_Data_Length
  ),

 /**
    Callback which successively returns the 'Language_ID's in a ASF file.
    
    @param context
    @param Language_ID_Records_Count
    Total number of languages in the list.
    @param Language_ID_Records_Index
    Index number of the language (position in the list of languages).
    @param Language_ID
    Array of bytes which should be interpreted as a WCHAR string.
    @param Language_ID_Length
    Length in bytes of the Language_ID string.
 */
 
 void (*ASF_Language_List_Handler)
 (
  void *context,
  unsigned short Language_ID_Records_Count,
  unsigned short Language_ID_Records_Index,
  unsigned char *Language_ID,
  unsigned char Partial_Language_ID_Length,
  unsigned char Language_ID_Length
  ),
 
 /**
    Callback which successively returns some extended properties associated with data streams.
    
    @param context
    @param Stream_Number
    @param Stream_Language_ID_Index
    Index number relative to the Language List 
    (the list is returned by the ASF_Language_List_Handler callback).
    @param Stream_Name_Count
    Total number of WCHAR strings describing the 'name' of the stream.
    @param Stream_Name_Count_Index
    Index number (position in the list of WCHAR strings) of a string 
    describing the 'name' of the stream.
    @param Language_ID_Index
    Index number (relative to the Language List), for the WCHAR string of the stream name.
    @param Stream_Name
    Name of the stream returned as an array of bytes
    (should be interpreted a WCHAR string localized in a language specified by Language_ID_Index).
    @param Stream_Name_Length
    Length in bytes of Stream_Name.
    @param Payload_Extension_System_Count
    Total number of Payload Extension Systems for the stream
    @param Payload_Extension_System_ID
    Refers to enum Standard_Payload_Extension_Sytem_ID
 */

 void (*ASF_Extended_Stream_Properties_Handler)
 (
  void *context,
  unsigned short Stream_Number,
  unsigned short Stream_Language_ID_Index,
  unsigned short Stream_Name_Count,
  unsigned short Stream_Name_Count_Index,
  unsigned short Language_ID_Index, // for the string of the language name
  unsigned char *Stream_Name,
  unsigned short Partial_Stream_Name_Length,
  unsigned short Stream_Name_Length,
  unsigned short Payload_Extension_System_Count,// number of payload extension for Stream_Number
  unsigned short Payload_Extension_System_ID   // refers to enum Standard_Payload_Extension_Sytem_ID
  ),

/**
	@param context
	@param Stream_Number
	@param buf
	  Pointer to the payload buffer
	@param size
	  Number of payload bytes to be read
	@param bytes_left
	  Number of payload bytes remaining
	@param Is_Key_Frame
	@param Media_Object_Number
	  Number of the Audio or Video frame.
	@param Media_Object_Number_valid
	@param Presentation_Time
	  Presentation Time of the Media Object the payload belongs to.
	@param Presentation_Time_valid
	@param Offset_Into_Media_Object
	  the offset of the payload on the media object
*/
  
  void (*ASF_Payload_Handler)
       (
	void *context,
	unsigned char Stream_Number,                  // 1..127
	unsigned char *buf,
	unsigned long size,                           // bytes
	unsigned long bytes_left,                     // bytes of payload remaining
	unsigned char Is_Key_Frame,                   // boolean
	unsigned long Media_Object_Number,
	unsigned char Media_Object_Number_valid,      // boolean
	unsigned long Presentation_Time,              // milliseconds
	unsigned char Presentation_Time_valid,         // boolean
	unsigned long Offset_Into_Media_Object
	),

/**

   Callback to create an index entry.

   There is one index per video stream;
   they are ordered by Stream Number.
   Each index contains multiple index entries,
   separated in time by Index_Entry_Time_Interval
   and has a unique index_index. 
   Each index entry contains a Packet_Number
   and a Packet_Count.

   @param context
   @param index_index
   @param Index_Entries_Count
     Constant for a given index_index
   @param Index_Entry_Time_Interval
     Constant for a given index_index
   @param Packet_Number
     Number of the data packet associated with this entry.
     For video streams containing both key frames and
     non-key frames, this field should point to the
     closest past key frame.
   @param Packet_Count
     Number of data packets to send starting at Packet_Number
     to reach the index entry time.
*/
  
  void (*ASF_Simple_Index_Entry_Handler)
       (
	void *context,
	unsigned char simple_index_number,
	unsigned long index_index,
	unsigned long Index_Entries_Count,
	unsigned long long Index_Entry_Time_Interval, // 100-ns units
	unsigned long Packet_Number,
	unsigned short Packet_Count
	),

  void (*ASF_Index_Entry_Handler)
       (
	void *context,
	unsigned char Phase_Num,
	unsigned short Specifier_Number,
	unsigned long Block_Number,
	unsigned long Entry_Number,
	unsigned long Index_Entry_Time_Interval, // 100-ns units
	unsigned short Index_Specifiers_Count,
	unsigned long Index_Block_Count,
	unsigned short Stream_Number,
	unsigned short Index_Type,
	unsigned long Index_Entry_Count,
	unsigned long long Position,
	unsigned long Offset
	),

 void (*ASF_Aspec_Ratio_Handler)
 (
  void *context,
  unsigned short Stream_Num,
  unsigned long aspectRatioX,
  unsigned long aspectRatioY
  )
 );

/**
   reset demux to beginning of specified data packet
   
   @param asf_demux_state
   @param Packet_Number
   @return
   0 if demux resetted successfully, -1 otherwise.

*/

int asf_demux_reset_packet
(
 struct asf_demux_state_t *asf_demux_state,
 unsigned long Packet_Number
);

/**
   reset demux to beginning of first data packet (beginning of ASF Data object)
   
   @param asf_demux_state
   @return
   0 if demux resetted successfully, -1 otherwise.

*/

int asf_demux_reset
(
 struct asf_demux_state_t *asf_demux_state
);
/**

  asf_demux entry point

  @param asf_demux_state
  @param buffer
  @param buffer_size
  @return 0 if parsing is over (last buffer of Index object successfully parsed), -1 otherwise

*/
int asf_demux
(
 struct asf_demux_state_t *asf_demux_state,
 unsigned char * buffer_in,
 unsigned long long size_in
 );

unsigned long long asf_demux_get_header_objects_size(struct asf_demux_state_t *asf_demux_state);
unsigned long asf_demux_finished_parsing_header(struct asf_demux_state_t *asf_demux_state);
unsigned long long asf_demux_get_data_objects_size(struct asf_demux_state_t *asf_demux_state);
unsigned long asf_demux_get_min_packet_size_info(struct asf_demux_state_t *asf_demux_state);
unsigned long asf_demux_get_max_packet_size_info(struct asf_demux_state_t *asf_demux_state);
     
int asf_demux_init_index_construction
(
 struct asf_demux_state_t *asf_demux_state
);

int asf_demux_construct_index 
(
 struct asf_demux_state_t *asf_demux_state, 
 unsigned char * buffer_in, 
 unsigned long long size_in
);

int asf_demux_seek 
(
 struct asf_demux_state_t *asf_demux_state, 
 unsigned char * buffer_in, 
 unsigned long long size_in,
 unsigned long packetNum
);

void asf_demux_set_position_in_file (struct asf_demux_state_t *asf_demux_state, unsigned long long position_in_file);

#endif // __ASF_DEMUX_H__
