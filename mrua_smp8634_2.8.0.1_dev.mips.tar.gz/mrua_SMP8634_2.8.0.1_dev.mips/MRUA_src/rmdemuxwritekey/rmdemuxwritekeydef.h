#ifndef RMDEMUXWRITEKEYDEF_H_
#define RMDEMUXWRITEKEYDEF_H_

#include "rua/include/rua.h"

#define	MAX_KEY_LEN                          128 /* 1024 Bts */
#define	DES_BYTES_LEN                        8
#define	DVB_BYTES_LEN                        8
#define	MULTI2_SYSTEM_KEY_BYTES_LEN          32
#define	MULTI2_256BITS_DATA_KEY_BYTES_LEN    32
#define	MULTI2_DATA_KEY_BYTES_LEN            8
#define	MULTI2_IV_KEY_BYTES_LEN              8
#define	AES_128BITS_BYTES_LEN                16
#define	AES_256BITS_BYTES_LEN                32
#define AES_128BITS							 4

struct Multi2_System_Key_256
{
    RMuint32 *pKey; /*256 bit key*/
};

struct Multi2_Data_Key_256
{
    RMuint32 *pKey; /*256 bit key*/
};

struct Multi2_Data_Key_64
{
    RMuint32 *pKey; /*64 bit key*/
};

struct Multi2_IV_64
{
    RMuint32 *pKey; /*64 bit key*/
};

struct Multi2_Key
{
    struct Multi2_System_Key_256 sysKey;
    struct Multi2_Data_Key_64    dataKey;
	struct	Multi2_IV_64     IV;	
};

struct	AES_Key_128
{
     RMuint32 *pKey; /*128 bit key*/
     RMuint32 *pIV;  /*128 bit key*/
};

struct	AES_Key_256
{
     RMuint32 *pKey; /*256 bit key*/
     RMuint32 *pIV;  /*256 bit key*/
};

struct	DES_Key
{
     RMuint32 *pKey; /* 64 bit key */
};

struct	DVB_Key
{
     RMuint32 *pKey; /* 64 bit key*/
};

struct	Cipher_Text
{
     RMuint32	*pCipherText;
     RMuint32	len;
};

union	Demux_Cipher_Key
{
     struct Multi2_Key               multi2Key;
     struct Multi2_System_Key_256    multi2Sys256BitKey;
     struct Multi2_Data_Key_256      multi2Data256BitKey;
     struct Multi2_IV_64             multi2IV;
     struct Multi2_Data_Key_64       multi2Data64BitKey;
     struct AES_Key_128              aes128BitKey;
     struct AES_Key_256              aes256BitKey;
     struct DES_Key                  desKey;
     struct DVB_Key                  dvbKey;
     struct Cipher_Text              cipherText;
};


enum	DEMUX_WRITE_XOS_Key_Type
{
     DEMUX_WRITE_DES_64BITS = 1,
     DEMUX_WRITE_AES_128BITS_KEY_IV,
     DEMUX_WRITE_AES_256BITS_KEY_IV,
     DEMUX_WRITE_DVB_64BITS,
     DEMUX_WRITE_MULTI2_SYSTEM_KEY,
     DEMUX_WRITE_MULTI2_256BITS_DATA_KEY,
     DEMUX_WRITE_MULTI2_DATA_KEY,
     DEMUX_WRITE_MULTI2_IV,
     DEMUX_WRITE_MULTI2
};
#endif /*RMDEMUXWRITEKEYDEF_H_*/
