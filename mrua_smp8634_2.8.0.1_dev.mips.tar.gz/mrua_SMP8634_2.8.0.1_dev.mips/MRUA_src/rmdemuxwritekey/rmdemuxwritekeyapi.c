#include <stdio.h>
#include "../rmdrm/include/rmdrm.h"
#include "rmdemuxwritekeyapi.h"
#include "rmdemuxwritekeyinterface.h"
/* handle to the DemuxWriteKey shared library */
static struct Demux_Write_Key_Interface_t *g_pWriteKey = NULL;
/*
 * This API loads the Xtask.  
 */
RMstatus initDemuxWriteKey(RMuint32 physAddr, 
                           RMuint32 memSize, 
                           RMuint8  flashSector)
{
	RMstatus status = RM_ERROR;	
	/* Try to load the shared library if not done yet */
    if (g_pWriteKey == NULL) 
		g_pWriteKey = load_drm(WRITEKEY, NULL);
	
    if (g_pWriteKey)
		status = g_pWriteKey->initDemuxWriteKey(physAddr,
                                                        memSize,
                                                        flashSector);
	else
		printf("Load DRM failed \n");
	return status;
}

/*
 * This API unloads the Xtask.
 */
RMstatus termDemuxWriteKey(void)
{
	RMstatus status = RM_ERROR;	
	if (g_pWriteKey)
		status = g_pWriteKey->termDemuxWriteKey();
	return status;
}

/*
 * This API writes key to the appropriate demux cipher key	memory.
 */
RMstatus setDemuxCipherKey( union	Demux_Cipher_Key            *pKey,
			    enum	DEMUX_WRITE_XOS_Key_Type    type,
			    RMbool                                  bEncFlag,
			    RMuint32	                            index)
{
	RMstatus status = RM_ERROR;	
	if (g_pWriteKey)
		status = g_pWriteKey->setDemuxCipherKey(pKey, type, bEncFlag, index);
	return status;
}

/* 
 * This API generate and store an AES 128 key in the sflash specified in the init function.
 */
RMstatus generateInternalDemuxAesKey(RMuint32 key_index)
{
	RMstatus status = RM_ERROR;	
	if (g_pWriteKey)
		status = g_pWriteKey->generateInternalDemuxAesKey(key_index);
	return status;	
}

/*
 * This API load an internal AES 128 key to the demux cipher key memory.
 */
RMstatus setInternalDemuxAesKey(RMuint32 key_index, RMuint32 cipher_index)
{
	RMstatus status = RM_ERROR;	
	if (g_pWriteKey)
		status = g_pWriteKey->setInternalDemuxAesKey(key_index,cipher_index);
	return status;	
}

/*
 * The API export an Internal AES key, encrypted with a secret key K
 */
RMstatus exportInternalDemuxKey(RMuint32 key_index, RMuint32 seed[AES_128BITS], RMuint32 *pKey)
{
	RMstatus status = RM_ERROR;	
	if (g_pWriteKey)
		status = g_pWriteKey->exportInternalDemuxKey(key_index, seed, pKey);
	return status;
}

/*
 * The API import an AES key previously exported and store it in the serial flash 
 */
RMstatus importInternalDemuxKey(RMuint32 key_index, RMuint32 seed[AES_128BITS], RMuint32 *pKey)
{
	RMstatus status = RM_ERROR;	
	if (g_pWriteKey)
		status = g_pWriteKey->importInternalDemuxKey(key_index, seed, pKey);
	return status;
}
