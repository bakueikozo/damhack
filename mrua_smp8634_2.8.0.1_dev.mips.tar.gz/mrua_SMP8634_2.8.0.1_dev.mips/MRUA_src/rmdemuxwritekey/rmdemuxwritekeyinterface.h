#ifndef RMDEMUXWRITEKEYINTERFACE_H_
#define RMDEMUXWRITEKEYINTERFACE_H_


#include "rmdemuxwritekeyapi.h"


struct Demux_Write_Key_Interface_t {	
       RMstatus     (*initDemuxWriteKey)(RMuint32 xrpcBaseAddr, 
                                          RMuint32 xrpcSize, 
                                          RMuint8  writeKeySector);
	
        RMstatus     (*termDemuxWriteKey)(void);
	
        RMstatus     (*setDemuxCipherKey)(union	Demux_Cipher_Key          *pKey,
                                          enum	DEMUX_WRITE_XOS_Key_Type  type,
                                          RMbool                          bEncFlag,
                                          RMuint32                        index);
        RMstatus     (*generateInternalDemuxAesKey)(RMuint32 key_index);
        RMstatus     (*setInternalDemuxAesKey)(RMuint32 key_index, RMuint32 cipher_index);
        RMstatus     (*exportInternalDemuxKey)(RMuint32 key_index, RMuint32 seed[AES_128BITS], RMuint32 *pKey);
        RMstatus     (*importInternalDemuxKey)(RMuint32 key_index, RMuint32 seed[AES_128BITS], RMuint32 *pKey);        
};
#endif /*RMDEMUXWRITEKEYINTERFACE_H_*/
