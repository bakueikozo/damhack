#include <stdio.h>
#include "../rmdemuxwritekeyapi.h"

#define DEMUX_WRITE_KEY_XRPC_SIZE 				(64 * 1024)

int main()
{
	
	//int rc=0;

	RMuint32 xrpc_base_addr = 0;
	RMuint32 xrpc_size      = 0;
	struct RUA *pRUA  = NULL;
	RMuint8 *map_addr = NULL;
	RMuint8 ruaLocked  = FALSE;
	RMstatus status;
	RMuint32 key[4] = {0x01234567,0x89ABCDEF, 0x01234567,0x89ABCDEF};
	RMuint32 iv[4]  = {0x11111111,0x22222222, 0x33333333,0x44444444};
	
	RMuint32 enc_key[4];// = {0x01234567,0x89ABCDEF, 0x01234567,0x89ABCDEF};
	RMuint32 seed1[4]  = {0x11111111,0x22222222, 0x33333333,0x44444444};
	RMuint32 seed2[4]  = {0x11111111,0x22222222, 0x33333333,0x44444444};
	struct	AES_Key_128		aesKey;
	int		i;
	/* Allocate Memory for the Xtask RPC and XRPC communication */
	/* Create an instance of RUA */
	status = RUACreateInstance(&pRUA, 0);
	if (status != RM_OK) {
		fprintf(stderr, "RUACreateInstance failed %d\n",status);
		goto cleanup;
	}
	
	
	xrpc_size = DEMUX_WRITE_KEY_XRPC_SIZE;
	
	/* Allocate an RUA buffer for XRPC commuication */
	xrpc_base_addr = RUAMalloc(pRUA, 0, RUA_DRAM_UNPROTECTED, xrpc_size);
	if (xrpc_base_addr == 0) {
		fprintf(stderr, "RUAMalloc failed\n");
		status = RM_ERROR;
		goto cleanup;
	}

	/* Lock the temporary RUA buffer so it can be mapped */
	status = RUALock(pRUA, xrpc_base_addr, xrpc_size);
	if (status != RM_OK) {
		fprintf(stderr, "RUALock failed\n");
		goto cleanup;
	}

	ruaLocked = TRUE;
	
	/* Map the temporary RUA buffer */
	map_addr = RUAMap(pRUA, xrpc_base_addr, xrpc_size);
	if (map_addr == NULL) {
		fprintf(stderr, "RUAMap failed\n");
		status = RM_ERROR;
		goto cleanup;
	}	
	/*1. Test case for Init Demux Write Key Xtask*/
	status = initDemuxWriteKey(xrpc_base_addr,xrpc_size,1);
	fprintf(stderr, "Init completed %s \n", status == RM_OK ? "OK" : "FAIL");
	aesKey.pKey = key;
	aesKey.pIV = iv;
	/*2. Test case for Setting External clear Demux Aes Key*/
	status = setDemuxCipherKey((union	Demux_Cipher_Key*)&aesKey,
				    DEMUX_WRITE_AES_128BITS_KEY_IV,
				    FALSE,
				    2);
				   
	fprintf(stderr, "Set Demux cipher %s \n", status == RM_OK ? "OK" : "FAIL");
	/*3. Test case for Generate Internal Demux Aes Key*/
	status = generateInternalDemuxAesKey(0);				   
	fprintf(stderr, "generateInternalDemuxAesKey %s \n", status == RM_OK ? "OK" : "FAIL");
	/*4. Test case for Set Internal Demux Aes Key*/
	status = setInternalDemuxAesKey(0,0);				   
	fprintf(stderr, "SetInternalDemuxAesKey %s \n", status == RM_OK ? "OK" : "FAIL");
	/*5. Test case for Export Internal DemuxKey*/
	status = exportInternalDemuxKey(0,seed1, enc_key);
	fprintf(stderr, "ExportInternalDemuxKey %s \n", status == RM_OK ? "OK" : "FAIL");
	for(i = 0; i < 4; i++)
	{
		printf("Enc Key[%d] = %lx \n", i, (RMuint32) enc_key[i]);
	}
	/*6. Test case for Import Internal DemuxKey*/
	status = importInternalDemuxKey(0,seed2, enc_key);
	fprintf(stderr, "ImportInternalDemuxKey %s \n", status == RM_OK ? "OK" : "FAIL");
	/*7. Test case for NO KEY ERROR*/
	status = exportInternalDemuxKey(6,seed1, enc_key);
	fprintf(stderr, "ExportInternalDemuxKey %s \n", status == RM_OK ? "OK" : "FAIL");
	if(status == RM_NOT_FOUND)
	{
		fprintf(stderr, "NO KEY ERROR: The Key not found in serial flash \n");
	}
	/*8. Test case for Terminating Demux Write Key Xtask*/
	status	=	termDemuxWriteKey();
	fprintf(stderr, "Term completed %s \n", status == RM_OK ? "OK" : "FAIL");
	
cleanup:
	
		
	if(map_addr) {
		/* Unmap the temporary RUA buffer */
		RUAUnMap(pRUA, map_addr, xrpc_size);
	}

	if( ruaLocked ) {
		/* Unlock the temporary RUA buffer */
		RUAUnLock(pRUA, xrpc_base_addr, xrpc_size);
	}
	if( xrpc_base_addr ) {
		/* Free temporary RUA buffer */
		RUAFree(pRUA, xrpc_base_addr);
	}
	if( pRUA ) {
		/* Terminate RUA */
		RUADestroyInstance(pRUA);
	}
	return 1;
}
