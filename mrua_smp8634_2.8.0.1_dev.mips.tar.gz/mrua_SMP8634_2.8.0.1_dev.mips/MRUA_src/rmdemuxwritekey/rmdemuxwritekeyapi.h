#ifndef RMDEMUXWRITEKEYAPP_H_
#define RMDEMUXWRITEKEYAPP_H_

#include "rmdemuxwritekeydef.h"

/*
 * This API initialize the DemuxWriteKey module.
 *
 * Parameters: none
 *
 * Returns: 
 * 	RM_OK on success
 * 	RM_ERROR on failure
 */
RMstatus initDemuxWriteKey(RMuint32 xrpcBaseAddr,
                           RMuint32 xrpcSize,
                           RMuint8 writeKeySector);

/*
 * This API terminate the DemuxWriteKey module.
 *
 * Parameters: none
 *
 * Returns: 
 * 	RM_OK on success
 * 	RM_ERROR on failure
 */
RMstatus termDemuxWriteKey(void);

/*
 * This API writes an external key to the appropriate demux cipher key memory.
 *
 * Parameters:
 *  - pKey: key data
 *  - type: key type
 *  - bEncFlag: is key data encrypted 
 *  - cipher_index: cipher index into which to load the key data
 *
 *  Returns:
 *  	RM_OK on success
 *  	RM_ERROR on failure
 */
RMstatus setDemuxCipherKey(union Demux_Cipher_Key *pKey,
                           enum DEMUX_WRITE_XOS_Key_Type type,
                           RMbool bEncFlag,
                           RMuint32 cipher_index);

/* 
 * This API generate and store an AES 128 key in the sflash specified in the init function.
 *
 * Parameters:
 *  - key_index: index of the key to generate.
 *
 * Returns:
 * 	RM_OK on success
 * 	RM_ERROR on failure
 *
 */
RMstatus generateInternalDemuxAesKey(RMuint32 key_index);

/*
 * This API load an internal AES 128 key to the demux cipher key memory.
 *
 * Parameters:
 *  - key_index: index of the key to set
 *  - cipher_index: index into which to load the key.
 *
 *  Returns:
 *  	RM_OK on success
 *  	RM_ERROR on failure
 */
RMstatus setInternalDemuxAesKey(RMuint32 key_index, RMuint32 cipher_index);


/*
 * The API export an Internal AES key, encrypted with a secret key K
 *
 * Parameters:
 *  - key_index: index of the key to set
 *  - seed: seed used to derive the secret key K.
 *  - pKey: key data
 *
 *  Returns:
 *  	RM_OK on success
 *  	RM_ERROR on failure
 */
RMstatus exportInternalDemuxKey(RMuint32 key_index, RMuint32 seed[AES_128BITS], RMuint32 *pKey);


/*
 * The API import an AES key previously exported and store it in the serial flash 
 *
 * Parameters:
 *  - key_index: index of the key to set
 *  - seed: seed used to derive the secret key K. (must be the same as used when export)
 *  - pKey: key data
 *
 *  Returns:
 *  	RM_OK on success
 *  	RM_ERROR on failure
 */
RMstatus importInternalDemuxKey(RMuint32 key_index, RMuint32 seed[AES_128BITS], RMuint32 *pKey);


#endif /*RMDEMUXWRITEKEYAPP_H_*/
