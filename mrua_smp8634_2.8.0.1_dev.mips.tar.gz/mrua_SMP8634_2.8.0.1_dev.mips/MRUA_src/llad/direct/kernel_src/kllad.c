/*
Copyright (C) 2003  Sigma Designs, Inc.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/version.h>

#include <linux/fs.h>
#include <linux/sched.h>
#include <linux/interrupt.h>
#include <linux/devfs_fs_kernel.h>

#include <asm/io.h>
#include <asm/irq.h>
#include <asm/uaccess.h>
#include <asm/semaphore.h>

#define ALLOW_OS_CODE 1

#ifdef WITH_PROC
#ifdef WITH_MONITORING
#include "kllad_proc.h"
#endif
#endif

unsigned long max_dmapool_memory_size = 4*1024*1024;
unsigned long max_dmabuffer_log2_size = 17;

MODULE_PARM(max_dmapool_memory_size, "i");
MODULE_PARM_DESC(max_dmapool_memory_size, "Sets the maximum amount of memory shared by the all dmapools");

MODULE_PARM(max_dmabuffer_log2_size, "i");
MODULE_PARM_DESC(max_dmabuffer_log2_size, "Sets the dmapool buffers maximum size (ex: set 15 for 32kB)");

MODULE_PARM(major, "i");
MODULE_PARM_DESC(major, "Sets the major number");

/* the main chip ids */
#define EM86XX_CHIPID_MAMBO      1000
#define EM86XX_CHIPID_MAMBOLIGHT 2000
#define EM86XX_CHIPID_TANGO      3000
#define EM86XX_CHIPID_TANGOLIGHT 4000
#define EM86XX_CHIPID_TANGO15    4500
#define EM86XX_CHIPID_TANGO2     5000
#define EM86XX_CHIPID_TANGO3    10000

#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
#include <asm/tango2/hardware.h>

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
#include <asm/tango2/rmdefs.h>
#include <asm/tango2/tango2_gbus.h>
#endif

#include <linux/mm.h>

#ifndef XLAT_G2P // Subject to redefinition in kernel
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
#if defined(CONFIG_TANGO2_USE_TLB_REMAP_DRAM1) || defined(CONFIG_TANGOX_USE_TLB_REMAP_DRAM1) 
// In Tango 2, we need to remap addresses greater than 0x20000000. For this, the kernel is currently 
// - subject to change - setting the TLB so that @ > 0x20000000 is remapped to em86xx_tlb_dram1_map_base. 
// Therefore for the kernel point of view GBUS address is equal to PHYSICAL address.
#define XLAT_G2P(g) (g)
#else
// In Tango 2, we need to remap addresses greater than 0x20000000. For this, the kernel is currently 
// - subject to change - setting the remap register so that @ > 0x20000000 is remapped to 
// 0x08000000. Therefore @ becomes @ -  0x20000000 + 0x08000000" (== 0x18000000) when @ > 0x20000000.
#define XLAT_G2P(g) (((g) >= 0x20000000) ? ((g) - 0x18000000) : (g)) 
#endif
#else
#define XLAT_G2P(g) (g)
#endif
#endif

#define REG_BASE_CPU REG_BASE_cpu_block
//#include "../../../emhwlib_hal/include/emhwlib_registers.h"
#define REG_BASE_HOST 0x20000
#define PCI_devcfg_reg0 0xfee8
#define PCI_devcfg_reg1 0xfeec
#define PCI_devcfg_reg2 0xfef0
#define PCI_devcfg_reg3 0xfef4
#define SOFTIRQMASK_VALID               0xf010
#define IRQ_SOFTINT                     (IRQ_CONTROLLER_IRQ_BASE+0)   // Software interrupt
#define IRQ_TIMER1                      (IRQ_CONTROLLER_IRQ_BASE+6)   // Timer 1
#define IRQ_MBUS_W1                     (IRQ_CONTROLLER_IRQ_BASE+10)  // Host interface MBUS W1 channel
#define IRQ_MBUS_R1                     (IRQ_CONTROLLER_IRQ_BASE+12)  // Host interface MBUS R1 channel
#define IRQ_GRAPHICACCEL                (IRQ_CONTROLLER_IRQ_BASE+23)  // Graphic accelerator
#define IRQ_VSYNC0                      (IRQ_CONTROLLER_IRQ_BASE+24)  // Vsync 0
#define IRQ_VSYNC1                      (IRQ_CONTROLLER_IRQ_BASE+25)  // Vsync 1
#define IRQ_VSYNC2                      (IRQ_CONTROLLER_IRQ_BASE+26)  // Vsync 2
#define IRQ_VSYNC3                      (IRQ_CONTROLLER_IRQ_BASE+27)  // Vsync 3

#if 0
unsigned long loop_cnt = 5000;
MODULE_PARM(loop_cnt, "i");
MODULE_PARM_DESC(loop_cnt, "Sets the loop counter for vsync workaround");
#endif

/* buffer size for large data transfer transition into kernel */
#define GBUS_BUF_SIZE (32 * 1024)

static unsigned char gbus_buf[GBUS_BUF_SIZE] __attribute__ ((__aligned__(PAGE_SIZE)));
#else  /* (EM86XX_CHIP==EM86XX_CHIPID_TANGO2) */

#include <asm/hardware.h>

#undef REG_BASE_cpu_block /* avoid redefinition */
#define REG_BASE_cpu_block REG_BASE_CPU

#endif /* (EM86XX_CHIP==EM86XX_CHIPID_TANGO2) */

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
#ifndef __user
#define __user
#endif
#endif

static struct semaphore gbus_buf_sem;
static spinlock_t open_lock;

struct llad;
struct gbus;
#ifndef pGBus
#define pGBus ((struct gbus *) 1)
#endif
#ifndef pLLAD
#define pLLAD ((struct llad *) 1)
#endif

#include "kernelcalls.h"
#include "../../include/kdmapool.h"

// Update the value in emhwlib/include/emhwlib_resources.h as well
#define UCLINUX_LLAD_IRQHANDLER_HANDSHAKE    (REG_BASE_CPU + 0x006C)
#define IRQHANDLER_ENTRY                     (REG_BASE_CPU + 0x0070) 
#define FIQHANDLER_ENTRY                     (REG_BASE_CPU + 0x0074) 
#define UNDEFHANDLER_ENTRY                   (REG_BASE_CPU + 0x0078) 
#define JUMPTABLE_ADDRESS                    (REG_BASE_CPU + 0x007c)
#define UCLINUX_UNDEF_VECTOR   (REG_BASE_CPU + 0x0048)
#define UCLINUX_IRQ_VECTOR     (REG_BASE_CPU + 0x005c)


MODULE_DESCRIPTION("llad kernel module for standalone configuration");
MODULE_AUTHOR("Mambo standalone team");
MODULE_LICENSE("LGPL");

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
static inline int ctu(void __user *x, void *y, unsigned long z) 
{ 
	if (!access_ok(VERIFY_WRITE, x, z))
		return -EFAULT;
	memcpy(x,y,z); 
	return 0; 
}

static inline int cfu(void *x, void __user *y, unsigned long z) 
{ 
	if (!access_ok(VERIFY_READ, y, z))
		return -EFAULT;
	memcpy(x,y,z); 
	return 0;
}
#else
static inline int ctu(void __user *x, void *y, unsigned long z) 
{ 
	int rc;
	if ((rc=copy_to_user(x,y,z))!=0)
		printk("copy_to_user %p %p %ld failed\n",x,y,z);
	return rc;
}

static inline int cfu(void *x, void __user *y, unsigned long z) 
{ 
	int rc;
	if ((rc=copy_from_user(x,y,z))!=0)
		printk("copy_from_user %p %p %ld failed\n",x,y,z);
	return rc;
}
#endif

unsigned long long kc_longlongdiv(unsigned long long a, unsigned long long b);

// For long long division
// Otherwise We can not link _udivdi3 from libgcc.a due to a pic and non-pic problem.
EXPORT_SYMBOL(kc_longlongdiv);
unsigned long long kc_longlongdiv(unsigned long long a, unsigned long long b)
{
        unsigned long long remainder = 0, quotient = 0;
        unsigned long r32,d,b_low;
        int i;
        unsigned char nbits = sizeof(unsigned long long)*8;
                                                                                                                                                                
        if ( ((b >> 32 ) == 0) && ( (a >> 32 ) == 0) )
                /* Simplest Case, 32 bits division */
                return (unsigned long long)( (unsigned long) a / (unsigned long) b );
                                                                                                                                                                
        if ( (b >> 28) == 0){
                /* Divisor is less than 28bit length */
                b_low = (unsigned long)b;
                d = a >> 32;
                quotient = (d / b_low);
                r32 = d % b_low;
                                                                                                                                                                
                for (i = 0; i < 8; i++) {
                        d = (r32 << 4) | ((a >> (7-i)*4) & 0xf);
                        quotient = (quotient << 4) | (d / b_low);
                        r32 = d % b_low;
                }
                return quotient;
        }
                                                                                                                                                                
        /* Skip first zeros */
        quotient = ( (unsigned long long) 1 << ( nbits-1 ) );
        while( quotient && ((a & quotient) == 0) ){
                nbits--;
                quotient = quotient >> 1;
        }
                                                                                                                                                                
        /* Compute, simple 2-radix */
        quotient = 0;
        for ( i = (nbits-1) ; i >=0 ; i--){
                remainder = remainder << 1 | (( a >> i ) & 1);
                quotient = quotient << 1 ;
                if ( remainder >= b ){
                        remainder = remainder - b;
                        quotient |=  1 ;
                }
        }
        return quotient;
}

/** US_TO_JIFFIES abstraction
 * Microseconds are converted in jiffies.
 * 1 jiffie = 1000000/HZ us, where HZ = number of PC real timer interrupts per second.
 * If u < 1000000/HZ => 0 jiffies
 * Conversion is done using 64bit mult&div => maximum timeout is 71 min.
 * Usually HZ=100 => 1 jiffie = 10 ms. For HZ=512 => 1 jiffie = 1953.125 us
 */
EXPORT_SYMBOL(US_TO_JIFFIES);
unsigned long US_TO_JIFFIES(unsigned long u)
{ 
	return (unsigned long)( kc_longlongdiv((unsigned long long)u * (unsigned long long)HZ, (unsigned long long)1000000) ); 
}

//static unsigned long JIFFIES_TO_US(unsigned long j){ return j*(unsigned long)1000000/HZ; };
EXPORT_SYMBOL(JIFFIES_TO_US);
unsigned long JIFFIES_TO_US(unsigned long j)
{ 
	return (unsigned long)( kc_longlongdiv((unsigned long long)j * (unsigned long long)1000000, (unsigned long long)HZ) ); 
}

/******************* USEFUL FUNCTION TO ACCESS MAMBO REGISTER *********************/
void llad_get_config(struct llad *pllad, char *config, unsigned long size);
struct llad *llad_open(char *dev);
void llad_close(struct llad *pllad);
struct gbus *gbus_open(struct llad *pllad);
void gbus_close(struct gbus *PGBUS);

EXPORT_SYMBOL(llad_open);
struct llad *llad_open(char *dev)
{
	if (*dev == '0')
		return pLLAD;
	else
		return (struct llad *) NULL;
}

EXPORT_SYMBOL(llad_close);
void llad_close(struct llad *pllad)
{
}

EXPORT_SYMBOL(gbus_open);
struct gbus *gbus_open(struct llad *pllad)
{
	if (pllad != NULL)
		return pGBus;
        return NULL;
}

EXPORT_SYMBOL(gbus_close);
void gbus_close(struct gbus *PGBUS)
{
}


#if (EM86XX_CHIP!=EM86XX_CHIPID_TANGO2) 
#define RMuint32 unsigned long


static inline void gbus_write_uint32(struct gbus *h, unsigned long byte_address, unsigned long data)
{
	*((volatile unsigned long *) byte_address) = data;
}

static inline unsigned long gbus_read_uint32(struct gbus *h, unsigned long byte_address)
{
	return *((volatile unsigned long *) byte_address);
}

#define gbus_save_flags_clf(x)          \
        {                               \
                unsigned long tmp;           \
                __asm__(                \
                "mrs    %0, cpsr\n"     \
                "orr    %1, %0, #64\n"  \
                "msr    cpsr_c, %1\n"   \
                : "=r" (x), "=r" (tmp)  \
                :                       \
                : "memory");            \
        }

/* 
 * Restore the saved value back to CPSR register.
 */
#define gbus_restore_flags(x)           \
        __asm__(                        \
        "msr    cpsr_c, %0\n"           \
        :                               \
        : "r" (x))


#else

#define RMPanic(x)
#include "../../../init_4ke/helpers_4ke_mipsel.h"
#define RMuint8 unsigned char
#define RMuint16 unsigned short

#define RMmin(x,y) (((x) < (y)) ? (x) : (y))

/* gbus_read_uint* and gbus_write_uint* functions are defined in Linux 
 * header file include/linux/config.h for TANGO2 */

static inline void gbus_read_data8 (struct gbus *h, RMuint32 byte_address, RMuint8  *data, RMuint32 count)
{
	RMuint32 i;

	for (i=0 ; i<count ; i++) {
		*(data+i) = gbus_read_uint8(h, byte_address + i);
	}
}

static inline void gbus_read_data16(struct gbus *h, RMuint32 byte_address, RMuint16 *data, RMuint32 count)
{
	RMuint32 i;

	for (i=0 ; i<count ; i++) {
		*(data+i) = gbus_read_uint16(h, byte_address + 2*i);
	}
}

static inline void gbus_read_data32(struct gbus *h, RMuint32 byte_address, RMuint32 *data, RMuint32 count)
{
	RMuint32 i;

	for (i=0 ; i<count ; i++) {
		*(data+i) = gbus_read_uint32(h, byte_address + 4*i);
	}
}

static inline void gbus_write_data8 (struct gbus *h, RMuint32 byte_address, const RMuint8  *data, RMuint32 count)
{
	RMuint32 i;

	for (i=0 ; i<count ; i++) {
		gbus_write_uint8(h, byte_address + i, *(data+i));
	}
}

static inline void gbus_write_data16(struct gbus *h, RMuint32 byte_address, const RMuint16 *data, RMuint32 count)
{
	RMuint32 i;

	for (i=0 ; i<count ; i++) {
		gbus_write_uint16(h, byte_address + 2*i, *(data+i));
	}
}

static inline void gbus_write_data32(struct gbus *h, RMuint32 byte_address, const RMuint32 *data, RMuint32 count)
{
	RMuint32 i;

	for (i=0 ; i<count ; i++) {
		gbus_write_uint32(h, byte_address + 4*i, *(data+i));
	}
}

#endif

/* struct llad; */
/* #define pGBus ((struct gbus *) 1) */
/* #define pLLAD ((struct llad *) 1) */

/* struct llad *llad_open(char *dev); */
/* void llad_close(struct llad *pllad); */
/* void llad_get_config(struct llad *pllad, char *config, unsigned long size); */
/* struct gbus *gbus_open(struct llad *pllad); */
/* void gbus_close(struct gbus *PGBUS); */

/* EXPORT_SYMBOL(llad_open); */
/* struct llad *llad_open(char *dev) */
/* { */
/*         if (*dev == '0') */
/*                 return pLLAD; */
/*         else */
/*                 return (struct llad *) NULL; */
/* } */

/* EXPORT_SYMBOL(llad_close); */
/* void llad_close(struct llad *pllad) */
/* { */
/* } */

/* EXPORT_SYMBOL(gbus_open); */
/* struct gbus *gbus_open(struct llad *pllad) */
/* { */
/*         if (pllad != NULL) */
/*                 return pGBus; */
/* } */

/* EXPORT_SYMBOL(gbus_close); */
/* void gbus_close(struct gbus *PGBUS) */
/* { */
/* } */

#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
static inline void gbus_mutex_lock(struct gbus *PGBUS, unsigned long mutex)
{
        while (gbus_read_uint32(PGBUS, mutex));
}
#else
static inline void gbus_mutex_lock(struct gbus *PGBUS, unsigned long mutex)
{
	unsigned long flags;

	while (1) {			
		gbus_save_flags_clf(flags);
		if (gbus_read_uint32(PGBUS, mutex) == 0) {
			gbus_restore_flags(flags);
			break;
		}
		gbus_restore_flags(flags);
	}
}
#endif

static inline void gbus_mutex_unlock(struct gbus *PGBUS, unsigned long mutex)
{
	gbus_write_uint32(PGBUS, (unsigned long) mutex, 0);
}


EXPORT_SYMBOL(llad_get_config);
void llad_get_config(struct llad *pllad, char *config, unsigned long size)
{
	// accessing PCI device configuration `from inside'
	unsigned short vendor;
	unsigned short device;
	unsigned char revisionid;
	unsigned short subsystem_vendor;
	unsigned short subsystem_device;
	unsigned short pci_bus_id;
	unsigned int pci_class;
	
	vendor=gbus_read_uint32(pGBus,REG_BASE_HOST+PCI_devcfg_reg0)>>16;
	device=gbus_read_uint32(pGBus,REG_BASE_HOST+PCI_devcfg_reg0)&0xffff;
	revisionid=gbus_read_uint32(pGBus,REG_BASE_HOST+PCI_devcfg_reg1)&0xff;
	pci_class=gbus_read_uint32(pGBus,REG_BASE_HOST+PCI_devcfg_reg1)>>8;
	subsystem_vendor=gbus_read_uint32(pGBus,REG_BASE_HOST+PCI_devcfg_reg2)>>16;
	subsystem_device=gbus_read_uint32(pGBus,REG_BASE_HOST+PCI_devcfg_reg2)&0xffff;
	
	pci_bus_id=0;
	
	snprintf(config, size, "%02x:%02x.%01x %06x %04x:%04x %04x:%04x %02x",
		 (pci_bus_id >> 8) & 0x00ff, 
		 (pci_bus_id >> 3) & 0x001f, 
		 pci_bus_id & 0x0007, 
		 pci_class, 
		 vendor, 
		 device, 
		 subsystem_vendor, 
		 subsystem_device, 
		 revisionid);
}

/********************* TO BE SYNCHRONIZED WITH emhwlib ****************************/
#define CPU_RESET_jump 0x0020 
#define CPU_undef_vec 0x0004 
#define CPU_irq_vec 0x0018 
#define DMEM_BASE_demux_engine 0x00150000
#define DMEM_BASE_audio_engine_0 0x00190000
#define DMEM_BASE_audio_engine_1 0x001b0000
#define audio_mutex7 0x3e97 

#define SOFT_IRQ_ORIGIN_PT110 0x10
#define PCI_INTERRUPT_ENABLE  0x617f4
#define HOST_INTERRUPT_STATUS 0x617f8
#define LOG2_LLAD_WAIT_WRITE_COMPLETE 1
#define LOG2_LLAD_SOFT_INTERRUPT      4

#define EM86XX_MODEID_WITHHOST 1000
#define EM86XX_MODEID_STANDALONE 2000

#if ((EM86XX_CHIP==EM86XX_CHIPID_MAMBOLIGHT) || (EM86XX_CHIP==EM86XX_CHIPID_MAMBO))
#define DMEM_BASE_audio_engine_1 0x001b0000
#define DMEM_BASE_demux_engine   0x00150000
#define audio_mutex3             0x3e93
#define audio_mutex7             0x3e97 
#define demux_mutex1             0x1e91 
#define SOFT_IRQ_MUTEX_IRQ       (DMEM_BASE_audio_engine_1 + 4 * audio_mutex7)
#define SOFT_IRQ_MUTEX_FIQ       (DMEM_BASE_demux_engine   + 4 * demux_mutex1)
#define PCI_IRQ_MUTEX            (DMEM_BASE_audio_engine_1 + 4 * audio_mutex3)
#elif ((EM86XX_CHIP==EM86XX_CHIPID_TANGO) || (EM86XX_CHIP==EM86XX_CHIPID_TANGOLIGHT) || (EM86XX_CHIP==EM86XX_CHIPID_TANGO15) || (EM86XX_CHIP==EM86XX_CHIPID_TANGO2))
#define REG_BASE_host_interface  0x00020000
#define host_mutex7              0x905c
#define host_mutex8              0x9060
#define host_mutex3              0x904c
#define SOFT_IRQ_MUTEX_IRQ       (REG_BASE_host_interface + host_mutex7)
#define SOFT_IRQ_MUTEX_FIQ       (REG_BASE_host_interface + host_mutex8)
#define PCI_IRQ_MUTEX            (REG_BASE_host_interface + host_mutex3)
#if (EM86XX_CHIP!=EM86XX_CHIPID_TANGO2)
#define demux_mutex1             0x1e91 /* For Tango2, it's been defined in emhwlib_registers_tango2.h */
#endif
#else
#error EM86XX_CHIP is not set in RMCFLAGS: refer to emhwlib/include/emhwlib_chips.h.
#endif


#if (EM86XX_CHIP<EM86XX_CHIPID_TANGO2) && defined WITH_IRQHANDLER_BOOTLOADER

static void clean_data_cache(void)
{        
	__asm("MCR     p15, 0, r0, c7, c10, 0");

	// drains write buffer
        __asm("LDR     r3, =0");          // reset vector 
        __asm("SWP     r2, r0, [r3]");    // r2 = [r3], [r3] = r0
	__asm("SWP     r0, r2, [r3]");    // r0 = [r3], [r3] = r2
}

static void flush_instr_cache(void) 
{
        __asm("MCR     p15, 0, r0, c7, c5, 0");
}

static RMuint32 install_handler(struct gbus *pgbus, RMuint32 handler, RMuint32 vector_index, RMuint32 *old_vector)
{
	RMuint32 old_handler, old_vec;
	RMuint32 cpu_remap;
	RMuint32 vector;

	cpu_remap = gbus_read_uint32(pgbus, REG_BASE_cpu_block + CPU_remap);
	if (cpu_remap == REG_BASE_cpu_block)
		return 0;

	old_vec = gbus_read_uint32(pgbus, cpu_remap + vector_index);
	if ((old_vec & 0xfffff000) == 0xe59ff000) {
		RMuint32 location = (old_vec & 0x00000fff) + vector_index + 0x8;
		old_handler = gbus_read_uint32(pgbus, cpu_remap + location);
	}
	else if ((old_vec & 0xff000000) == 0xea000000)
		old_handler = ((old_vec & 0x00ffffff) << 2) + vector_index + 0x8;
	else
		return 0;

	*old_vector = old_vec;
	
	/* stores the new handler address in local RAM (jump table) */
	gbus_write_uint32(pgbus, REG_BASE_cpu_block + CPU_RESET_jump + vector_index, handler);
	
	/* creates the instruction to execute new handler and stores it in local RAM vector */
	vector = CPU_RESET_jump - 8;
	vector |= 0xe59ff000;
	gbus_write_uint32(pgbus, REG_BASE_cpu_block + vector_index, vector);

	/* creates the new vector and install it */
	vector = REG_BASE_cpu_block - 8;  /* branch to the vector in local RAM */
	vector >>= 2;
	vector |= 0xea000000;
	gbus_write_uint32(pgbus, cpu_remap + vector_index, vector);
	
	return old_handler;
}

static void overload_IRQHandler(struct gbus *pgbus, RMuint32 handler, RMuint32 jump_table)
{
	RMuint32 irq_set;
	RMuint32 old_handler, old_vector;

	irq_set = gbus_read_uint32(pgbus, REG_BASE_cpu_block + CPU_irq_enableset);
	gbus_write_uint32(pgbus, REG_BASE_cpu_block + CPU_irq_enableclr, 0xffffffff);

	old_handler = install_handler(pgbus, handler, CPU_irq_vec, &old_vector);
	if (old_handler) {
		gbus_write_uint32(pgbus, jump_table + CPU_irq_vec, old_handler);
		gbus_write_uint32(pgbus, UCLINUX_IRQ_VECTOR, old_vector);
	}
	else
		gbus_write_uint32(pgbus, REG_BASE_cpu_block + CPU_irq_vec, 0xdeadbeef);

	clean_data_cache();
	flush_instr_cache();

	gbus_write_uint32(pgbus, REG_BASE_cpu_block + CPU_irq_enableset, irq_set);
}

static void overload_UNDEFHandler(struct gbus *pgbus, RMuint32 handler, RMuint32 jump_table)
{
	RMuint32 old_handler, old_vector;

	old_handler = install_handler(pgbus, handler, CPU_undef_vec, &old_vector);
	if (old_handler) {
		gbus_write_uint32(pgbus, jump_table + CPU_undef_vec, old_handler);
		gbus_write_uint32(pgbus, UCLINUX_UNDEF_VECTOR, old_vector);
	}
	else
		gbus_write_uint32(pgbus, REG_BASE_cpu_block + CPU_undef_vec, 0xdeadbeef);

	clean_data_cache();
	flush_instr_cache();
}

static void restore_IRQHandler(struct gbus *pgbus)
{
	RMuint32 irq_set;
	RMuint32 old_vector;
	
	irq_set = gbus_read_uint32(pgbus, REG_BASE_cpu_block + CPU_irq_enableset);
	gbus_write_uint32(pgbus, REG_BASE_cpu_block + CPU_irq_enableclr, 0xffffffff);
	
	old_vector = gbus_read_uint32(pgbus, UCLINUX_IRQ_VECTOR);
	gbus_write_uint32(pgbus, CPU_irq_vec, old_vector);

	clean_data_cache();
	flush_instr_cache();

 	gbus_write_uint32(pgbus, REG_BASE_cpu_block + CPU_irq_enableset, irq_set);
}
 
static void restore_UNDEFHandler(struct gbus *pgbus)
{
	RMuint32 old_vector;

	old_vector = gbus_read_uint32(pgbus, UCLINUX_UNDEF_VECTOR);
	gbus_write_uint32(pgbus, CPU_undef_vec, old_vector);
 
	clean_data_cache();
	flush_instr_cache();
}

#endif


/*************** TO BE SYNCHRONIZED WITH ../include/direct_kk.h" ******************/
struct kc_tasklet_struct;

void mumk_register_tasklet(struct gbus *PGBUS, struct kc_tasklet_struct *tasklet, unsigned long *irq_status, unsigned long mask);
void mumk_unregister_tasklet(struct gbus *PGBUS, struct kc_tasklet_struct *kctasklet);
int mumk_dmapool_release(struct gbus *PGBUS, unsigned long dmapool_id, unsigned long bus_address);

/*************** TO BE SYNCHRONIZED WITH ../include/direct_uk.h" ******************/
#define DIRECT_IOCTL_WAIT                 2
#define DIRECT_IOCTL_ENABLE_INTERRUPT     3
#define DIRECT_IOCTL_DISABLE_INTERRUPT    4
#define DIRECT_IOCTL_LLAD_GET_CONFIG     10
#define DIRECT_IOCTL_LLAD_GET_OPEN_COUNT 11

#define DIRECT_IOCTL_DMAPOOL_OPEN                  33
#define DIRECT_IOCTL_DMAPOOL_CLOSE                 34
#define DIRECT_IOCTL_DMAPOOL_RESET                 42
#define DIRECT_IOCTL_DMAPOOL_GET_BUFFER            36
#define DIRECT_IOCTL_DMAPOOL_GET_PHYSICAL_ADDRESS  37
#define DIRECT_IOCTL_DMAPOOL_GET_VIRTUAL_ADDRESS   35
#define DIRECT_IOCTL_DMAPOOL_ACQUIRE               38
#define DIRECT_IOCTL_DMAPOOL_RELEASE               39
#define DIRECT_IOCTL_DMAPOOL_FLUSH_CACHE           40
#define DIRECT_IOCTL_DMAPOOL_INVALIDATE_CACHE      41
#define DIRECT_IOCTL_DMAPOOL_GET_AVAILABLE_BUFFER_COUNT 43

#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
#define DIRECT_IOCTL_GBUS_READ_UINT8               50
#define DIRECT_IOCTL_GBUS_READ_UINT16              51
#define DIRECT_IOCTL_GBUS_READ_UINT32              52
#define DIRECT_IOCTL_GBUS_READ_DATA8               53
#define DIRECT_IOCTL_GBUS_READ_DATA16              54
#define DIRECT_IOCTL_GBUS_READ_DATA32              55
#define DIRECT_IOCTL_GBUS_WRITE_UINT8              56
#define DIRECT_IOCTL_GBUS_WRITE_UINT16             57
#define DIRECT_IOCTL_GBUS_WRITE_UINT32             58
#define DIRECT_IOCTL_GBUS_WRITE_DATA8              59
#define DIRECT_IOCTL_GBUS_WRITE_DATA16             60
#define DIRECT_IOCTL_GBUS_WRITE_DATA32             61

#define DIRECT_IOCTL_GBUS_LOCK_AREA                70
#define DIRECT_IOCTL_GBUS_GET_LOCKED_AREA          71
#define DIRECT_IOCTL_GBUS_UNLOCK_REGION            72
#define DIRECT_IOCTL_GBUS_GET_REGIONS_INFO         73
#define DIRECT_IOCTL_GBUS_MMAP_REGION              74
#define DIRECT_IOCTL_GBUS_GET_SYSTEM_PAGE_COUNT    75

struct gbus_uint8 {
	unsigned long byte_address;
	unsigned char data;
};

struct gbus_uint16 {
	unsigned long byte_address;
	unsigned short data;
};

struct gbus_uint32 {
	unsigned long byte_address;
	unsigned long data;
};

struct gbus_data8 {
	unsigned long byte_address;
	unsigned char __user *data;
	unsigned long count;
};

struct gbus_data16 {
	unsigned long byte_address;
	unsigned short __user *data;
	unsigned long count;
};

struct gbus_data32 {
	unsigned long byte_address;
	unsigned long __user *data;
	unsigned long count;
};

struct gbus_regions_info {
	unsigned long region_count;
	unsigned long region_size;
};

struct gbus_lock_area {
	unsigned long byte_address;
	unsigned long size;
	unsigned long offset;
	unsigned long region_index;
	unsigned long region_count;
};

struct gbus_region_count {
	unsigned long region_index;
	unsigned long region_count;
};
#define KERNEL_PAGE_SIZE   (1<<PAGE_SHIFT)
#define DIRECT_REGION_SIZE (2*1024*1024)
#define DIRECT_REGION_COUNT 512
#define DIRECT_DUMMY_REGION_MAP_ADDRESS 0x200000

#endif // EM86XX_CHIP


struct waitable {
	unsigned long timeout_microsecond; // no way to specify ``infinite'', sorry.
        unsigned long mask;
}; 

struct llad_get_config {
	char *ConfigName;
	unsigned long ConfigNameSize;
};

struct kdmapool_dimension {
	unsigned long area;
	unsigned long buffercount;
	unsigned long buffersize;
	unsigned long dmapool_id;
};

struct kdmapool_getbuffer {
	unsigned long dmapool_id;
	unsigned char *ptr;
	unsigned long timeout_microsecond;
};

struct kdmapool_userbuffer {
	unsigned long dmapool_id;
	unsigned char *ptr;
	unsigned long size;
	unsigned long physical_address;
};

struct kdmapool_buffercount {
	unsigned long dmapool_id;
	unsigned long buffer_count;
};

struct kdmapool_physbuffer {
	unsigned long dmapool_id;
	unsigned long physical_address;
};

struct kdmapool_reset {
	unsigned long dmapool_id;
	unsigned long acquired_count;
};

struct region_info_struct {


	unsigned long region_count;
	unsigned long map_refcount;
	unsigned long direct_map;
	unsigned long area_offset;
	unsigned long area_size;
	unsigned long area_byte_address;	


};	

#define DIRECT_MAJOR 126
#define DIRECT_DEVICE_NAME "mum0"

/* Major number */
static int major = DIRECT_MAJOR;

#define LLAD_WAIT_WRITE_COMPLETE (1<<LOG2_LLAD_WAIT_WRITE_COMPLETE)
#define LLAD_SOFT_INTERRUPT      (1<<LOG2_LLAD_SOFT_INTERRUPT)

#define MAX_OPENERS 8

/* Number of supported tasklets */
#define MAX_TASKLETS  4

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
#define CURRENT_DIRECT_ID (current->pgrp) 
#else
#define CURRENT_DIRECT_ID (current->signal->pgrp)
#endif

struct direct_opener {
	int direct_id;
	unsigned long open_count;
	unsigned dmapool_usage_mask;
};

static struct {
	int total_open_count;
	wait_queue_head_t irq_queue;
	unsigned long irq_bits;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
	devfs_handle_t devfs_handle;
#endif
	struct tasklet_struct *tasklet[MAX_TASKLETS];
	unsigned long *tasklet_irq_status[MAX_TASKLETS];
	unsigned long tasklet_mask[MAX_TASKLETS];
	struct direct_opener openers[MAX_OPENERS];

#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)

	struct region_info_struct region_info[DIRECT_REGION_COUNT];

#endif // EM86XX_CHIP
} R;


#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
static inline int unlocked_regions(unsigned int index, unsigned int count)
{
	unsigned int i,c;
	
	for (i=index,c=0 ; ((i<DIRECT_REGION_COUNT) && (c<count)) ; i++,c++) {
		if (R.region_info[i].direct_map)
			break;
	}
	
	return (count == c);
}

static inline int is_inside_region(struct gbus_lock_area *param, unsigned int index)
{
	unsigned long offset;

	//1) same address?

	if (!(param->byte_address ==R.region_info[index].area_byte_address))
		return 0;

	
	//2 same offset?
	//get address offset from page 
	

	offset = param->byte_address & (KERNEL_PAGE_SIZE - 1);
	
	if (!(offset-R.region_info[index].area_offset==0)) {
		return 0;
	}


	
	//3 same size?

	if (!(param->size==R.region_info[index].area_size))
		return 0;

/* 	 printk("is_inside_region: param->byte_address=%x, R.region_info[%i].area_byte_address=%x\n",param->byte_address,index,R.region_info[index].area_byte_address); 	 */
/* 	 printk("is_inside_region: offset=%i, R.region_info[%i].area_offset=%i\n",offset,index,R.region_info[index].area_offset);  */

/* 	 printk("is_inside_region: param->size=%u, R.region_info[%i].area_size=%u\n",param->size,index,R.region_info[index].area_size);  */

	return 1;
}


 
static int get_locked_area(struct gbus_lock_area *param)
{
	unsigned long i;

	
	i = 0;
	while (i<DIRECT_REGION_COUNT) {
		if (R.region_info[i].direct_map == 0) {
		
			i++;
			continue;
		}
		
		
		if (!(is_inside_region(param, i))) {
			i++;
			continue;
		}

		param->region_index = i;
		param->offset = param->byte_address - R.region_info[i].direct_map;
		// warning: get_locked_area always return  region_count=1. for real sys pages  count, use ioctl with DIRECT_IOCTL_GBUS_GET_SYSTEM_PAGE_COUNT
		param->region_count = 1;
		//this way ruaunlock will only unlock 1 region, no neighbours are concerned.
		/* printk("get_locked_area(): region found: index=%i; offset=%i\n",param->region_index,param->offset); */
		

		break;		

	}
	return i;
}
#endif // EM86XX_CHIP


/* Goal of the following ISR: we are declaring a IRQ handler for the hardware 
   interrupts we will be using in the emhwlib. Unfortunately, the IRQ handler
   we will be inserting before the OS (re-route interrupt vector table) will
   "miss" some interrupts that will end up in the kernel. The default behavior
   of the kernel is to mask these "unused" interrupts. To prevent this, we
   right a semi-"dummy" interrupt handler that will disable the used IRQ until
   the emhwlib is loaded. 
*/

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0) 
static void dummy_isr(int irq, void *dev_id, struct pt_regs *regs) 
#else
static irqreturn_t dummy_isr(int irq, void *dev_id, struct pt_regs *regs) 
#endif
{
	unsigned long flag;

	flag = gbus_read_uint32(pGBus, UCLINUX_LLAD_IRQHANDLER_HANDSHAKE);
	if ((flag & (1 << irq)) == 0) {
		/* Nobody is ready to handle it yet, disable the interrupt.
		   If we don't disable the irq, the kernel will unmask it */
		disable_irq(irq);
	} else {
		/* IRQ handler is ready to handle it the interrupt.
		   If we don't re-enable the irq, the kernel will keep it masked */
		enable_irq(irq);
	}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0) 
	return IRQ_HANDLED;
#endif
}

#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
/* HACK ALTERT: We hook up an ISR with VSYNCx, the sole purpose for that is to
 * loop inside the ISR until XPU takes care of business (to reduce the load on GBUS 
 * due to CPU operations as the loop is small enough to fit into the cache).
 */ 
static irqreturn_t tango2_vsync_intr(int irq, void *devinfo, struct pt_regs *regs)
{
#if 0
	// Per #4067 Comment #31, disable this portion, if no problem found, we can remove the
	// whole tango2_vsync_intr() stuff...
	volatile RMuint32 i;
	RMuint32 mask = 1UL << (irq - IRQ_CONTROLLER_IRQ_BASE);
	do {
		for (i = 0; i < loop_cnt; i++) /* Busy loop to be fitted into cache */
			;
	} while (gbus_read_uint32(pGBus, REG_BASE_irq_handler_block + CPU_edge_rawstat) & mask);
	/* XPU is done here */
#endif

	return IRQ_HANDLED;
}
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0) 
static void tophalf(int irq, void *dev_id, struct pt_regs *regs)
#else
static irqreturn_t tophalf(int irq, void *dev_id, struct pt_regs *regs)
#endif
{
	unsigned long status, mask;
	int i;

	status = gbus_read_uint32(pGBus, REG_BASE_cpu_block + CPU_irq_softset);

/* 	printk("Received a llad software interrupt %lu\n", status); */

	if ((status & SOFT_IRQ_ORIGIN_PT110) == 0) 
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0) 
		return;
#else
		return IRQ_HANDLED;
#endif

 	gbus_mutex_lock(pGBus, PCI_IRQ_MUTEX);

	status = gbus_read_uint32(pGBus, HOST_INTERRUPT_STATUS);
	mask = status & ~(LLAD_WAIT_WRITE_COMPLETE | LLAD_SOFT_INTERRUPT);

	for( i=0; i<MAX_TASKLETS ; i++ )
		mask = mask & ~(R.tasklet_mask[i]);

	gbus_write_uint32(pGBus, HOST_INTERRUPT_STATUS, mask);
	if (mask == 0)
		gbus_write_uint32(pGBus, REG_BASE_cpu_block + CPU_irq_softclr, SOFT_IRQ_ORIGIN_PT110);

 	gbus_mutex_unlock(pGBus, PCI_IRQ_MUTEX);

/* 	printk("HOST_INTERRUPT_STATUS=0x%08lx\n",status); */

	if (status & LLAD_WAIT_WRITE_COMPLETE) {
		if (!test_and_set_bit(LOG2_LLAD_WAIT_WRITE_COMPLETE, &(R.irq_bits)))
			wake_up_interruptible(&(R.irq_queue));
	}
	if (status & LLAD_SOFT_INTERRUPT) {
		if (!test_and_set_bit(LOG2_LLAD_SOFT_INTERRUPT, &(R.irq_bits)))
			wake_up_interruptible(&(R.irq_queue));
	}

	for( i=0 ; i<MAX_TASKLETS ; i++ ) {
		if (status & R.tasklet_mask[i]) {
			if (R.tasklet[i]) {
				*(R.tasklet_irq_status[i]) |= status & R.tasklet_mask[i];
				tasklet_schedule(R.tasklet[i]);
			}
		}
	}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0) 
	return IRQ_HANDLED;
#endif
}

EXPORT_SYMBOL(mumk_register_tasklet);
void mumk_register_tasklet(struct gbus *PGBUS, struct kc_tasklet_struct *kctasklet, unsigned long *irq_status, unsigned long mask)
{
	int i;
	for( i=0 ; i<MAX_TASKLETS ; i++ ) {
		if (!(R.tasklet[i])) {
			R.tasklet_irq_status[i] = irq_status;
			R.tasklet[i] = (struct tasklet_struct *)kctasklet;
			R.tasklet_mask[i] = mask;
			printk("mumk_register_tasklet: (%d) tasklet %p status @%p\n",i,R.tasklet[i],R.tasklet_irq_status[i]);
			return;
		}
	}

	printk("mumk_register_tasklet: cannot register\n");
}

EXPORT_SYMBOL(mumk_unregister_tasklet);
void mumk_unregister_tasklet(struct gbus *PGBUS, struct kc_tasklet_struct *kctasklet)
{
	int i;
	for( i=0 ; i<MAX_TASKLETS ; i++ ) {
		if (R.tasklet[i]==(struct tasklet_struct *)kctasklet) {
			R.tasklet_mask[i] = 0;
			R.tasklet[i] = (struct tasklet_struct *) NULL;
			R.tasklet_irq_status[i] = (unsigned long *) NULL;
			return;
		}
	}

	printk("mumk_unregister_tasklet: cannot unregister\n");
}

static void direct_wait(struct waitable *h)
{
	long timeout_jiffies = US_TO_JIFFIES(h->timeout_microsecond);
	unsigned long targets;
 
	targets = h->mask & R.irq_bits;
        
	//	printk("Wait for mask 0x%08x for %lu us and %lu jiffies\n", h->mask, h->timeout_microsecond, timeout_jiffies);
        while (1) {
                if (targets) {
                        h->mask = targets;

                        {
                                int bitno=0;
                                
                                while (targets) {
                                        if (targets & 0x1) 
                                                clear_bit(bitno,&(R.irq_bits));
                                        
                                        targets >>= 1;
                                        bitno++;
                                }
                        }
                        return;
                }
                
		//		printk("no bit set so go to sleep\n");
                timeout_jiffies = interruptible_sleep_on_timeout(&(R.irq_queue), timeout_jiffies);
                h->timeout_microsecond = JIFFIES_TO_US(timeout_jiffies);

                // handle signals gently (esp. Control-C...)
                if ((timeout_jiffies == 0) || signal_pending(current)) break;
                
                targets = h->mask & R.irq_bits;
        }
        
        if (timeout_jiffies != 0) printk("direct_wait: signal pending\n");
	h->mask = 0;
}

static int minor_ioctl(struct inode *i_node, struct file *filp,unsigned int cmd, unsigned long arg)
{
	int rc;

/* 	printk("ioctl %lu %lu\n", cmd, arg); */

        rc = 0;
	switch (cmd) {
	case DIRECT_IOCTL_WAIT:
		{
			struct waitable h;
			
			if (cfu(&h,(char *)arg,sizeof(struct waitable)) != 0)
				return -EFAULT;
			direct_wait(&h);
			rc = ctu((char *)arg,&h,sizeof(struct waitable));
			if (rc != 0) rc = -EFAULT;
		}
		break;

	case DIRECT_IOCTL_ENABLE_INTERRUPT:
		{
			int flags;
			unsigned long enable;

			local_irq_save(flags);
			enable = gbus_read_uint32(pGBus, PCI_INTERRUPT_ENABLE);
			enable |= arg;
			gbus_write_uint32(pGBus, PCI_INTERRUPT_ENABLE, enable);
			local_irq_restore(flags);
		}
		break;

	case DIRECT_IOCTL_DISABLE_INTERRUPT:
		{
			int flags;
			unsigned long enable, status;

			local_irq_save(flags);

			enable = gbus_read_uint32(pGBus, PCI_INTERRUPT_ENABLE);
			enable &= ~arg;
			gbus_write_uint32(pGBus, PCI_INTERRUPT_ENABLE, enable);

			status = gbus_read_uint32(pGBus, HOST_INTERRUPT_STATUS);
			status &= enable;
			gbus_write_uint32(pGBus, HOST_INTERRUPT_STATUS, status);

			local_irq_restore(flags);
		}
		break;
		
	case DIRECT_IOCTL_LLAD_GET_CONFIG:
		{
			struct llad_get_config param;
			unsigned long size;
			static char llad_buf[256];

			rc = -EINVAL;
			if (cfu(&param, (char *)arg, sizeof(param)) != 0) break;
			size = param.ConfigNameSize;
			if (size > sizeof(llad_buf)) size = sizeof(llad_buf);
			llad_get_config(pLLAD, llad_buf, size);
			if (ctu(param.ConfigName, llad_buf, size) == 0) rc = 0;
		}
		break;
		
	case DIRECT_IOCTL_LLAD_GET_OPEN_COUNT:
		{
			unsigned long count;
			
			count = R.total_open_count;
			if (ctu((char *) arg, &count, sizeof(count)) != 0)
				return -EFAULT;
		}
		break;

	case DIRECT_IOCTL_DMAPOOL_OPEN:
		{
			struct kdmapool_dimension param;
			int i;

			if (cfu(&param, (char *)arg, sizeof(param)) != 0)
				return -EFAULT;

			// find direct_id in the table
			for (i=0;i<MAX_OPENERS;i++) if (R.openers[i].direct_id==CURRENT_DIRECT_ID) break;
			if (i==MAX_OPENERS) {
				printk("minor_ioctl: invalid openers\n");
				return -EINVAL;
			}

			rc = kdmapool_open((struct llad *) NULL, (char *) param.area, param.buffercount, param.buffersize);
			if (rc >= 0) {
				set_bit(rc, (void*)&(R.openers[i].dmapool_usage_mask)); 
				param.dmapool_id = rc;
				rc = 0;
				if (ctu((char *) arg, &param, sizeof(param)) != 0)
					return -EFAULT;
			}
		}
		break;
		
	case DIRECT_IOCTL_DMAPOOL_CLOSE:
		{
			unsigned long dmapool_id;
			int i;

			if (cfu(&dmapool_id, (char *)arg, sizeof(unsigned long)) != 0)
				return -EFAULT;

			// find direct_id in the table
			for (i=0;i<MAX_OPENERS;i++) if (R.openers[i].direct_id==CURRENT_DIRECT_ID) break;
			if (i==MAX_OPENERS) {
				printk("minor_ioctl: invalid openers\n");
				return -EINVAL;
			}

			rc = kdmapool_close((struct llad *) NULL, dmapool_id);
			clear_bit(dmapool_id, (void *)&(R.openers[i].dmapool_usage_mask)); 
		}
		break;

	case DIRECT_IOCTL_DMAPOOL_RESET:
		{
			struct kdmapool_reset param;

			if (cfu(&param, (char *)arg, sizeof(param)) != 0)
				return -EFAULT;
			param.acquired_count = kdmapool_reset((struct llad *) NULL, param.dmapool_id);
			if (ctu((char *) arg, &param, sizeof(param)) != 0)
				return -EFAULT;
			rc = 0;
		}
		break;

	case DIRECT_IOCTL_DMAPOOL_GET_BUFFER:
		{
			struct kdmapool_getbuffer param;

			if (cfu(&param, (char *)arg, sizeof(param)) != 0)
				return -EFAULT;

			rc = kdmapool_check_valid((struct llad *) NULL,param.dmapool_id);
			if (rc ==0){
				param.ptr = kdmapool_getbuffer((struct llad *) NULL, param.dmapool_id, &(param.timeout_microsecond));
				if (ctu((char *) arg, &param, sizeof(param)) != 0)
					return -EFAULT;
			}
		}
		break;

	case DIRECT_IOCTL_DMAPOOL_GET_AVAILABLE_BUFFER_COUNT:
		{
			struct kdmapool_buffercount param;

			if (cfu(&param, (char *)arg, sizeof(param)) != 0)
				return -EFAULT;
			
			rc = kdmapool_check_valid((struct llad *)NULL,param.dmapool_id);
			if (rc == 0){
				param.buffer_count = kdmapool_get_available_buffer_count((struct llad *) NULL, param.dmapool_id);
				if (ctu((char *) arg, &param, sizeof(param)) != 0)
					return -EFAULT;
			}
		}
		break;

	case DIRECT_IOCTL_DMAPOOL_GET_PHYSICAL_ADDRESS:
		{
			struct kdmapool_userbuffer param;
			
			if (cfu(&param, (char *)arg, sizeof(param)) != 0)
				return -EFAULT;
			
			rc = kdmapool_check_valid((struct llad*)NULL,param.dmapool_id);
			if (rc == 0) {
				param.physical_address = kdmapool_get_bus_address((struct llad *) NULL, param.dmapool_id,  param.ptr, param.size);
				if (ctu((char *) arg, &param, sizeof(param)) != 0)
					return -EFAULT;
			}
		}
		break;

	case DIRECT_IOCTL_DMAPOOL_GET_VIRTUAL_ADDRESS:
		{
			struct kdmapool_userbuffer param;

			if (cfu(&param, (char *)arg, sizeof(param)) != 0)
				return -EFAULT;
			
			rc = kdmapool_check_valid((struct llad *)NULL,param.dmapool_id);
			if (rc == 0) {
				param.ptr = kdmapool_get_virt_address((struct llad *) NULL, param.dmapool_id,  param.physical_address, param.size);
				if (ctu((char *) arg, &param, sizeof(param)) != 0)
					return -EFAULT;
			}
		}
		break;

	case DIRECT_IOCTL_DMAPOOL_ACQUIRE:
		{
			struct kdmapool_physbuffer param;

			if (cfu(&param, (char *)arg, sizeof(param)) != 0)
				return -EFAULT;
			
			rc = kdmapool_check_valid((struct llad *)NULL,param.dmapool_id);
			if (rc == 0)
				rc = kdmapool_acquire((struct llad *) NULL, param.dmapool_id, param.physical_address);
		}
		break;

	case DIRECT_IOCTL_DMAPOOL_RELEASE:
		{
			struct kdmapool_physbuffer param;

			if (cfu(&param, (char *)arg, sizeof(param)) != 0)
				return -EFAULT;
			
			rc = kdmapool_check_valid((struct llad *)NULL,param.dmapool_id);
			if (rc == 0)
				rc = kdmapool_release((struct llad *) NULL, param.dmapool_id, param.physical_address);
		}
		break;

        case DIRECT_IOCTL_DMAPOOL_FLUSH_CACHE:
		{
			struct kdmapool_userbuffer param;
			
			if (cfu(&param, (char *)arg, sizeof(param)) != 0)
				return -EFAULT;
			
			kc_flush_cache((void *)param.physical_address, param.size);

			rc = 0;
		}
		break;
		
	case DIRECT_IOCTL_DMAPOOL_INVALIDATE_CACHE:
		{
			struct kdmapool_userbuffer param;
			
			if (cfu(&param, (char *)arg, sizeof(param)) != 0)
				return -EFAULT;

			kc_invalidate_cache((void *)param.physical_address, param.size);

			rc = 0;
		}
		break;
		
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
	case DIRECT_IOCTL_GBUS_READ_UINT8:
		{	
			struct gbus_uint8 param;
			
			if (cfu(&param, (char *)arg, sizeof(param)) != 0)
				return -EFAULT;
			param.data = gbus_read_uint8(pGBus, param.byte_address);
			rc = ctu((char *) arg, &param, sizeof(param));
			if (rc != 0) rc=-EFAULT;
		}
		break;
	case DIRECT_IOCTL_GBUS_READ_UINT16:
		{	
			struct gbus_uint16 param;

			if (cfu(&param, (char *)arg, sizeof(param)) != 0)
				return -EFAULT;
			param.data = gbus_read_uint16(pGBus, param.byte_address);
			rc = ctu((char *) arg, &param, sizeof(param));
			if (rc != 0) rc=-EFAULT;
		}
		break;
	case DIRECT_IOCTL_GBUS_READ_UINT32:
		{	
			struct gbus_uint32 param;

			if (cfu(&param, (char *)arg, sizeof(param)) != 0)
				return -EFAULT;
			param.data = gbus_read_uint32(pGBus, param.byte_address);
			rc = ctu((char *) arg, &param, sizeof(param));
			if (rc != 0) rc=-EFAULT;
		}
		break;
	case DIRECT_IOCTL_GBUS_READ_DATA8:
		{	
			struct gbus_data8 param;
			RMuint32 xfer_size, xfer_offset;

			if (cfu(&param, (char *)arg, sizeof(param)) != 0)
				return -EFAULT;
			xfer_offset = 0;
			rc = 0;

			if (down_interruptible(&gbus_buf_sem)) {
				rc = -ERESTARTSYS; 
				goto done;
			}
			while (xfer_offset < param.count) {
				xfer_size = RMmin(param.count - xfer_offset, GBUS_BUF_SIZE / sizeof(RMuint8));
				gbus_read_data8(pGBus, 
						param.byte_address + xfer_offset * sizeof(RMuint8), 
						(RMuint8 *) gbus_buf, 
						xfer_size * sizeof(RMuint8));
				if (ctu(param.data + xfer_offset, gbus_buf, xfer_size * sizeof(RMuint8)) != 0) {
					rc = -EFAULT;
					break;
				}
				xfer_offset += xfer_size;
			}
			up(&gbus_buf_sem);
		}
		break;
	case DIRECT_IOCTL_GBUS_READ_DATA16:
		{	
			struct gbus_data16 param;
			RMuint32 xfer_size, xfer_offset;

			if (cfu(&param, (char *)arg, sizeof(param)) != 0)
				return -EFAULT;
			xfer_offset = 0;
			rc = 0;
			if (down_interruptible(&gbus_buf_sem)) {
				rc = -ERESTARTSYS; 
				goto done;
			}
			while (xfer_offset < param.count) {
				xfer_size = RMmin(param.count - xfer_offset, GBUS_BUF_SIZE / sizeof(RMuint16));
				gbus_read_data16(pGBus, 
						 param.byte_address + xfer_offset * sizeof(RMuint16), 
						 (RMuint16 *) gbus_buf, 
						 xfer_size);
				if (ctu(param.data + xfer_offset, gbus_buf, xfer_size * sizeof(RMuint16)) != 0) {
					rc = -EFAULT;
					break;
				}
				xfer_offset += xfer_size;
			}
			up(&gbus_buf_sem);
		}
		break;
	case DIRECT_IOCTL_GBUS_READ_DATA32:
		{	
			struct gbus_data32 param;
			RMuint32 xfer_size, xfer_offset;
				
			if (cfu(&param, (char *)arg, sizeof(param)) != 0)
				return -EFAULT;
			xfer_offset = 0;
			rc = 0;
			if (down_interruptible(&gbus_buf_sem)) {
				rc = -ERESTARTSYS; 
				goto done;
			}
			while (xfer_offset < param.count) {
				xfer_size = RMmin(param.count - xfer_offset, GBUS_BUF_SIZE / sizeof(RMuint32));
				gbus_read_data32(pGBus, 
						 param.byte_address + xfer_offset * sizeof(RMuint32), 
						 (RMuint32 *) gbus_buf, 
						 xfer_size);
				if (ctu(param.data + xfer_offset, gbus_buf, xfer_size * sizeof(RMuint32)) != 0) {
					rc = -EFAULT;
					break;
				}
				xfer_offset += xfer_size;
			}
			up(&gbus_buf_sem);
		}
		break;
	case DIRECT_IOCTL_GBUS_WRITE_UINT8:
		{	
			struct gbus_uint8 param;

			if (cfu(&param, (char *)arg, sizeof(param)) != 0) 
				return -EFAULT;
			gbus_write_uint8(pGBus, param.byte_address, param.data);
			rc = 0;
		}
		break;
	case DIRECT_IOCTL_GBUS_WRITE_UINT16:
		{	
			struct gbus_uint16 param;

			if (cfu(&param, (char *)arg, sizeof(param)) != 0) 
				return -EFAULT;
			gbus_write_uint16(pGBus, param.byte_address, param.data);
			rc = 0;
		}
		break;
	case DIRECT_IOCTL_GBUS_WRITE_UINT32:
		{	
			struct gbus_uint32 param;

			if (cfu(&param, (char *)arg, sizeof(param)) != 0) 
				return -EFAULT;
			gbus_write_uint32(pGBus, param.byte_address, param.data);
			rc = 0;
		}
		break;
	case DIRECT_IOCTL_GBUS_WRITE_DATA8:
		{	
			struct gbus_data8 param;
			RMuint32 xfer_size, xfer_offset;

			if (cfu(&param, (char *)arg, sizeof(param)) != 0)
				return -EFAULT;
			xfer_offset = 0;
			rc = 0;
			if (down_interruptible(&gbus_buf_sem)) {
				rc = -ERESTARTSYS; 
				goto done;
			}
			while (xfer_offset < param.count) {
				xfer_size = RMmin(param.count - xfer_offset, GBUS_BUF_SIZE / sizeof(RMuint8));
				if (cfu(gbus_buf, param.data + xfer_offset, sizeof(RMuint8) * xfer_size) != 0) {
					rc = -EFAULT;
					break;
				}
				gbus_write_data8(pGBus, 
						 param.byte_address + xfer_offset * sizeof(RMuint8), 
						 (RMuint8 *) gbus_buf, 
						 xfer_size);
				xfer_offset += xfer_size;
			}
			up(&gbus_buf_sem);
		}
		break;
	case DIRECT_IOCTL_GBUS_WRITE_DATA16:
		{	
			struct gbus_data16 param;
			RMuint32 xfer_size, xfer_offset;

			if (cfu(&param, (char *)arg, sizeof(param)) != 0)
				return -EFAULT;
			xfer_offset = 0;
			rc = 0;
			if (down_interruptible(&gbus_buf_sem)) {
				rc = -ERESTARTSYS; 
				goto done;
			}
			while (xfer_offset < param.count) {
				xfer_size = RMmin(param.count - xfer_offset, GBUS_BUF_SIZE / sizeof(RMuint16));
				if (cfu(gbus_buf, param.data + xfer_offset, sizeof(RMuint16) * xfer_size) != 0) {
					rc = -EFAULT;
					break;
				}
				gbus_write_data16(pGBus, 
						  param.byte_address + xfer_offset * sizeof(RMuint16), 
						  (RMuint16 *) gbus_buf, 
						  xfer_size);
				xfer_offset += xfer_size;
			}
			up(&gbus_buf_sem);
		}
		break;
	case DIRECT_IOCTL_GBUS_WRITE_DATA32:
		{	
			struct gbus_data32 param;
			RMuint32 xfer_size, xfer_offset;

			if (cfu(&param, (char *)arg, sizeof(param)) != 0)
				return -EFAULT;
			xfer_offset = 0;
			rc = 0;
			if (down_interruptible(&gbus_buf_sem)) {
				rc = -ERESTARTSYS; 
				goto done;
			}
			while (xfer_offset < param.count) {
				xfer_size = RMmin(param.count - xfer_offset, GBUS_BUF_SIZE / sizeof(RMuint32));
				if (cfu(gbus_buf, param.data + xfer_offset, sizeof(RMuint32) * xfer_size) != 0) {
					rc = -EFAULT;
					break;
				}
				gbus_write_data32(pGBus, 
						  param.byte_address + xfer_offset * sizeof(RMuint32), 
						  (RMuint32 *) gbus_buf, 
						  xfer_size);
				xfer_offset += xfer_size;
			}
			up(&gbus_buf_sem);
		}
		break;
	case DIRECT_IOCTL_GBUS_GET_REGIONS_INFO:
		{
			struct gbus_regions_info param;

			param.region_size = DIRECT_REGION_SIZE;
			param.region_count = DIRECT_REGION_COUNT;
			//			printk("DIRECT_IOCTL_GBUS_GET_REGION_INFO: param.region_size=%lu param.region_count=%lu\n", param.region_size, param.region_count);
			if (ctu((char *) arg, &param, sizeof(param)) != 0) {
				rc = -EFAULT;
				break;
			}
			rc = 0;
		}
		break;
	case DIRECT_IOCTL_GBUS_LOCK_AREA:
		{
			struct gbus_lock_area param, local_param;
			int i, size, addr, do_map=1, region_count;

			if (cfu(&param, (char *)arg, sizeof(param)) != 0)
				return -EFAULT;

			if (param.region_index >= DIRECT_REGION_COUNT)
				return -EINVAL;
			
			/* locking is done on multiple of KERNEL_PAGE_SIZE bytes */

			//get address offset from page 
			param.offset = param.byte_address & (KERNEL_PAGE_SIZE - 1);
			//get page base address 
			addr = param.byte_address & ~(KERNEL_PAGE_SIZE - 1);
			
			//get the system pages region count
			param.region_count = (param.size + param.offset+ KERNEL_PAGE_SIZE - 1) / KERNEL_PAGE_SIZE;


			region_count=param.region_count; //number of kernel pages for this region


			/* keep track of orignial parameters */
			local_param = param;

			if (param.region_index == 0) { //region_index is a parameter
				
				/* try to get an already locked area */
				param.region_index = get_locked_area(&param);
				/* printk("lock_area: get_locked= %p %d %d %u\n", param.byte_address, param.offset, param.size, param.region_index); */
				
				if (param.region_index<DIRECT_REGION_COUNT) {
					do_map = 0; //add lock on this zone 
					goto end_lock_area;
				}
				
				/* restore original parameters */
				param = local_param;
				
				//look for first available free region
				for (i=0 ; i<DIRECT_REGION_COUNT ; i++) {
					if (unlocked_regions(i, 1))
						break;
				}
				
				if (i==DIRECT_REGION_COUNT) //no more available
					return -EINVAL;
				
				param.region_index = i;
/* 				printk("lock_area: found unlocked region %i\n", i); */
			}
			else {
				if (!unlocked_regions(param.region_index, 1))
					return -EINVAL;
			}
			
		end_lock_area:
		/* 	printk("end_lock_area:this area will take %i system pages (0x%x bytes)\n", param.region_count, param.region_count*KERNEL_PAGE_SIZE); */
			i = param.region_index;

			size = param.size +param.offset;
			
		/* 	 printk("end_lock_area:R.region_info[%i].direct_map = 0x%x\n",i,addr);  */
			if (do_map)
				R.region_info[i].direct_map = addr;
	
			R.region_info[i].map_refcount ++; 
			R.region_info[i].region_count=region_count; 
			R.region_info[i].area_byte_address=param.byte_address;
			R.region_info[i].area_size=param.size;
			R.region_info[i].area_offset=param.offset;

		/* 	printk("end_lock_area: locked @%p off:%d size:%d index:%d sys pages count=%d\n", param.byte_address, param.offset, param.size, param.region_index, param.region_count);				 */
			if (ctu((char *) arg, &param, sizeof(param)) != 0) 
				return -EFAULT;
			rc = 0;
		}
		break;
	case DIRECT_IOCTL_GBUS_UNLOCK_REGION:
		{
			unsigned long region_index;
 
			if (cfu(&region_index, (char *)arg, sizeof(region_index)) != 0)
				return -EFAULT;
			
			if (region_index >= DIRECT_REGION_COUNT)
				return -EINVAL;

			if (R.region_info[region_index].region_count == 0)
				return -EINVAL;
	/* 		printk("unlock_region: R.region_info[%i].region_count=%i -> 0\n",region_index,R.region_info[region_index].region_count); */
			R.region_info[region_index].map_refcount--;
			if (R.region_info[region_index].map_refcount == 0) {
				/* printk("unlock_region:area unlocked %d\n", region_index); */
				R.region_info[region_index].direct_map = 0;
				R.region_info[region_index].region_count=0;
			}
			rc = 0;
		}
		break;
	case DIRECT_IOCTL_GBUS_GET_LOCKED_AREA:
		{
			struct gbus_lock_area param;
			unsigned long i;
			
 			if (cfu(&param, (char *)arg, sizeof(param)) != 0)
				return -EFAULT;

			rc = 0;
			i = get_locked_area(&param);
		/* 	printk("get_locked area %p %d %d %d\n", param.byte_address, param.offset, param.size, i); */
			if (i==DIRECT_REGION_COUNT) 
				rc = -EINVAL;


			if (ctu((char *) arg, &param, sizeof(param)) != 0) 
				return -EFAULT;
			
		}
		break;
	case DIRECT_IOCTL_GBUS_GET_SYSTEM_PAGE_COUNT:
		{
			
			struct gbus_region_count param;
			unsigned long  region_index, system_page_count;
			
			if (cfu(&param, (char *)arg, sizeof(param)) != 0)
				return -EFAULT;

			rc = 0;
			region_index=param.region_index;
			if (region_index >= DIRECT_REGION_COUNT) { 
				return  -EINVAL;

			}


			system_page_count=R.region_info[region_index].region_count;
		
/* 			printk("get_system_page_count: region=%i, count=%i\n", region_index, system_page_count); */
			param.region_count=system_page_count;

			if (ctu((char *) arg, &param, sizeof(param)) != 0) 
				return -EFAULT;
			


		}
		break;
#endif // EM86XX_CHIP 
		
	default:
		rc = -EINVAL;
	}

done:
	return rc;
}

#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)

#define DIRECT_MMAP_MASK          0xff000000
#define DIRECT_MMAP_DMAPOOL       0x02000000
#define DIRECT_MMAP_REGION        0x03000000
#define DIRECT_MMAP_DMAPOOL_SHIFT 12
#define DIRECT_MMAP_REGION_SHIFT  12

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
struct page *kdmapool_vma_nopage(struct vm_area_struct *vma, unsigned long addr, int *type);
#else
struct page *kdmapool_vma_nopage(struct vm_area_struct *vma, unsigned long addr, int unused);
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
static struct page *direct_vma_nopage(struct vm_area_struct *vma, unsigned long addr, int *type)
#else
static struct page *direct_vma_nopage(struct vm_area_struct *vma, unsigned long addr, int type)
#endif
{
	unsigned long offset = vma->vm_pgoff << PAGE_SHIFT;
	struct page *page = NULL;

	if ((offset & DIRECT_MMAP_MASK) == DIRECT_MMAP_DMAPOOL) 
		page = kdmapool_vma_nopage(vma, addr, type);
#if 0
	/* this is only true if the region mapped is under kernel control */
	else if ((offset & DIRECT_MMAP_MASK) == DIRECT_MMAP_REGION) {
		unsigned long region_index, base, vaddr;
		region_index = (offset - DIRECT_MMAP_REGION) >> DIRECT_MMAP_REGION_SHIFT;
		base = XLAT_G2P(R.region_info[region_index].direct_map);
		offset = (addr - vma->vm_start); /* absolute offset */
		vaddr = (base + offset) & PAGE_MASK;
		page = virt_to_page(vaddr);
	}
#endif
	if (page)
		get_page(page);
	return page;
}

static struct vm_operations_struct direct_vm_ops = {
	.nopage = direct_vma_nopage
};

static int minor_mmap(struct file *filp, struct vm_area_struct *vma)
{
	int rc = 0;
	unsigned long offset;
	unsigned long dmapool_id, region_index;
	
	offset = vma->vm_pgoff << PAGE_SHIFT;
 	/*  printk("mmap at offset 0x%x\n", offset);   */

	switch (offset & DIRECT_MMAP_MASK) {
	case DIRECT_MMAP_DMAPOOL:
		dmapool_id = (offset - DIRECT_MMAP_DMAPOOL) >> DIRECT_MMAP_DMAPOOL_SHIFT;
		rc = kdmapool_mmap((struct llad *) NULL, (struct kc_vm_area_struct *)vma, dmapool_id, vma->vm_start, 
				   vma->vm_end-vma->vm_start,(struct kc_pgprot_t *)&(vma->vm_page_prot));
		break;
	case DIRECT_MMAP_REGION:
  	/* 	printk("mmaping region: %p 0x%08lx\n", vma->vm_start, vma->vm_end-vma->vm_start);   */
		region_index = (offset - DIRECT_MMAP_REGION) >> DIRECT_MMAP_REGION_SHIFT;

		/* because we run on MIPS */
		vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);
		
/* from linux-2.6.10 remap_page_range is replaced by remap_pfn_range */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,10)
		rc = remap_page_range(vma->vm_start,
				      XLAT_G2P(R.region_info[region_index].direct_map),
				      vma->vm_end - vma->vm_start,
				      vma->vm_page_prot);
#else
		rc = remap_pfn_range(vma,
				     vma->vm_start,
				     XLAT_G2P(R.region_info[region_index].direct_map) >> PAGE_SHIFT,
				     vma->vm_end - vma->vm_start,
				     vma->vm_page_prot);
#endif // LINUX_VERSION_CODE

		if (rc) {
			printk("failed to mmap region\n");
			return -EAGAIN;
		} 

		break;
	default:
		printk("Unknown offset\n");
		rc = -EINVAL;
		break;
	}

	if (rc >= 0) {
		vma->vm_ops = &direct_vm_ops;
		vma->vm_flags |= VM_RESERVED;
	}

	return rc;
}
#endif // EM86XX_CHIP

static int minor_open(struct inode *i_node, struct file *filp)
{
	int i;

	spin_lock(&open_lock);

	// find direct_id in the table
	for (i=0;i<MAX_OPENERS;i++) if (R.openers[i].direct_id==CURRENT_DIRECT_ID) break;

 	if (i==MAX_OPENERS) {
		// find empty entry
		for (i=0;i<MAX_OPENERS;i++) if (R.openers[i].direct_id==0) break;

		if (i==MAX_OPENERS) {
			printk("minor_open: too many openers (increase MAX_OPENERS)\n");
			spin_unlock(&open_lock);
			return -EINVAL;
		}
			
		R.openers[i].direct_id=CURRENT_DIRECT_ID;
		//printk("minor_open: #%d new mum_id %d\n", i,R.openers[i].direct_id);
	}

	R.openers[i].open_count ++;
	R.total_open_count ++;
	spin_unlock(&open_lock);

	return 0;
}

static int minor_release(struct inode *i_node, struct file *filp)
{
	int i;

	spin_lock(&open_lock);

	// find direct_id in the table
	for (i=0;i<MAX_OPENERS;i++) if (R.openers[i].direct_id==CURRENT_DIRECT_ID) break;

	if (i>=MAX_OPENERS) {
		printk("minor_release: too many openers (increase MAX_OPENERS)\n");
		spin_unlock_bh(&open_lock);
		return -EINVAL;
	}

	R.openers[i].open_count --;
	if (R.openers[i].open_count == 0) {
		/* close openned dmapools */
		int j=0;
		
		while (R.openers[i].dmapool_usage_mask) {
			if (test_and_clear_bit(j, (void *)&(R.openers[i].dmapool_usage_mask))) {
				kdmapool_close((struct llad *) NULL, j);
			}
			j++;
		}
		R.openers[i].direct_id = 0;
	}
		
	R.total_open_count --;
	spin_unlock(&open_lock);
	return 0;
}

static struct file_operations direct_fops = 
{
	// this replaces MOD_INC_USE_COUNT/MOD_DEC_USE_COUNT pain
	owner: THIS_MODULE,
	
	ioctl:minor_ioctl, 
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
 	mmap:minor_mmap,
#endif // EM86XX_CHIP
	open:minor_open, 
	release:minor_release, 
};

int llad_init(void)
{  
	int res,i;

	init_waitqueue_head(&(R.irq_queue));
	
	sema_init(&gbus_buf_sem, 1);
	spin_lock_init(&open_lock);

	R.total_open_count = 0;
	
	for (i=0 ; i<MAX_OPENERS ; i++) {
		R.openers[i].direct_id = 0;
		R.openers[i].open_count = 0;
		R.openers[i].dmapool_usage_mask = 0;
	}
	
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
	for (res=0 ; res<DIRECT_REGION_COUNT ; res++) {

		R.region_info[res].direct_map =0; 
		R.region_info[res].region_count=0;
		R.region_info[res].map_refcount=0;
		R.region_info[res].area_offset=0;
		R.region_info[res].area_size=0;
		R.region_info[res].area_byte_address=0;

	}
#endif // EM86XX_CHIP

#if (EM86XX_CHIP<EM86XX_CHIPID_TANGO2) && defined WITH_IRQHANDLER_BOOTLOADER
	{
		/*
		  when linux boots, it has overwritten irq and undef; in case
		  of bootirq we put it back.
		*/
		
		RMuint32 val, table;
		
		table = gbus_read_uint32(pGBus, JUMPTABLE_ADDRESS);
		val = gbus_read_uint32(pGBus, IRQHANDLER_ENTRY);
		overload_IRQHandler(pGBus, val, table);
		
		val = gbus_read_uint32(pGBus, UNDEFHANDLER_ENTRY);
		overload_UNDEFHandler(pGBus, val, table);
	}
#else
	/* 
	   when not using irqhandler from bootloader, clear all events/interrupts 
	   before enabling the SOFTINT.
	*/
	gbus_write_uint32(pGBus, HOST_INTERRUPT_STATUS, 0);
	gbus_write_uint32(pGBus, REG_BASE_cpu_block + CPU_irq_softclr, ~SOFTIRQMASK_VALID);
	
	/* We need to initialize the UCLINUX_LLAD_IRQHANDLER_HANDSHAKE parmater to 0 since we are
           going to register an IRQ that cannot be handled by the emhwlib IRQ handler yet since
           the emhwlib will be loaded only later. */
	gbus_write_uint32(pGBus, UCLINUX_LLAD_IRQHANDLER_HANDSHAKE, 0);
#endif
	
	res = kdmapool_init((struct llad *) NULL);
	if (res < 0) 
		return res;

	request_irq(IRQ_SOFTINT, tophalf, SA_INTERRUPT | SA_SHIRQ, DIRECT_DEVICE_NAME, &R);

	request_irq(IRQ_MBUS_W1, dummy_isr, SA_INTERRUPT, "mbus_w1", &R);
	request_irq(IRQ_GRAPHICACCEL, dummy_isr, SA_INTERRUPT, "gfx", &R);
	request_irq(IRQ_MBUS_R1, dummy_isr, SA_INTERRUPT, "mbus_r1", &R);
	request_irq(IRQ_TIMER1, dummy_isr, SA_INTERRUPT, "timer1", &R);
#if (EM86XX_CHIP == EM86XX_CHIPID_TANGOLIGHT) || (EM86XX_CHIP == EM86XX_CHIPID_MAMBOLIGHT) || (EM86XX_CHIP == EM86XX_CHIPID_MAMBO)
	request_irq(IRQ_RTC, dummy_isr, SA_INTERRUPT, "rtc", &R);
#endif

#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
	request_irq(IRQ_VSYNC0, tango2_vsync_intr, SA_INTERRUPT, "vsync0", &R);
	request_irq(IRQ_VSYNC1, tango2_vsync_intr, SA_INTERRUPT, "vsync1", &R);
	request_irq(IRQ_VSYNC2, tango2_vsync_intr, SA_INTERRUPT, "vsync2", &R);
	request_irq(IRQ_VSYNC3, tango2_vsync_intr, SA_INTERRUPT, "vsync3", &R);
#endif

	res = register_chrdev(major, DIRECT_DEVICE_NAME, &direct_fops);
	if (res < 0) {
		printk("Cannot register module major=%d for %s\n", major, DIRECT_DEVICE_NAME);
		free_irq(IRQ_SOFTINT, &R);
		free_irq(IRQ_MBUS_W1, &R);
		free_irq(IRQ_GRAPHICACCEL, &R);
		free_irq(IRQ_MBUS_R1, &R);
		free_irq(IRQ_TIMER1, &R);
#if (EM86XX_CHIP == EM86XX_CHIPID_TANGOLIGHT) || (EM86XX_CHIP == EM86XX_CHIPID_MAMBOLIGHT) || (EM86XX_CHIP == EM86XX_CHIPID_MAMBO)
		free_irq(IRQ_RTC, &R);
#endif
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
		free_irq(IRQ_VSYNC3, &R);
		free_irq(IRQ_VSYNC2, &R);
		free_irq(IRQ_VSYNC1, &R);
		free_irq(IRQ_VSYNC0, &R);
#endif
		return res;
	}
	
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
 	/* does nothing if CONFIG_DEVFS_FS is undefined */
	R.devfs_handle = devfs_register(NULL, DIRECT_DEVICE_NAME, DEVFS_FL_AUTO_DEVNUM, major, 0,
				      S_IFCHR | S_IRUGO | S_IWUGO,
				      &direct_fops, NULL);
	
	if (R.devfs_handle == NULL) {
		printk("devfs module not registered\n");
	}
#endif

#ifdef WITH_PROC
#ifdef WITH_MONITORING
        /* Add /proc/driver/mum/ entries */
      	add_driver_proc_entry();
       	add_driver_proc_files();
#endif
#endif	

	return res;
}


void llad_exit(void)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
	/* does nothing if CONFIG_DEVFS_FS is undefined */
	if (R.devfs_handle != NULL)
		devfs_unregister(R.devfs_handle);
#endif

	unregister_chrdev(major, DIRECT_DEVICE_NAME);

	free_irq(IRQ_SOFTINT, &R);
	free_irq(IRQ_MBUS_W1, &R);
	free_irq(IRQ_GRAPHICACCEL, &R);
#if (EM86XX_CHIP == EM86XX_CHIPID_TANGOLIGHT) || (EM86XX_CHIP == EM86XX_CHIPID_MAMBOLIGHT) || (EM86XX_CHIP == EM86XX_CHIPID_MAMBO)
	free_irq(IRQ_RTC, &R);
#endif
	free_irq(IRQ_MBUS_R1, &R);
	free_irq(IRQ_TIMER1, &R);

#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
	free_irq(IRQ_VSYNC3, &R);
	free_irq(IRQ_VSYNC2, &R);
	free_irq(IRQ_VSYNC1, &R);
	free_irq(IRQ_VSYNC0, &R);
#endif

	kdmapool_deinit((struct llad *) NULL);

#ifdef WITH_PROC
#ifdef WITH_MONITORING
        /* Add /proc/driver/mum/ entries */
      	rm_driver_proc_entry();
       	rm_driver_proc_files();
#endif
#endif	

#if (EM86XX_CHIP<EM86XX_CHIPID_TANGO2) && defined WITH_IRQHANDLER_BOOTLOADER
	restore_IRQHandler(pGBus);
	restore_UNDEFHandler(pGBus);
#endif
}

module_init(llad_init);
module_exit(llad_exit);
