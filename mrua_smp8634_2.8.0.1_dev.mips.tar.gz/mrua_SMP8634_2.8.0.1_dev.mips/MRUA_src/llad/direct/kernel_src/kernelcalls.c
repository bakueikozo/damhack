/*
Copyright (C) 2003  Sigma Designs, Inc.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <linux/kernel.h>
#include <linux/module.h>

#include <linux/vmalloc.h>
#include <linux/fs.h>
#include <linux/sched.h>
#include <linux/interrupt.h>
#include <linux/devfs_fs_kernel.h>
#include <linux/poll.h>

/* the main chip ids */
#define EM86XX_CHIPID_MAMBO      1000
#define EM86XX_CHIPID_MAMBOLIGHT 2000
#define EM86XX_CHIPID_TANGO      3000
#define EM86XX_CHIPID_TANGOLIGHT 4000
#define EM86XX_CHIPID_TANGO15    4500
#define EM86XX_CHIPID_TANGO2     5000
#define EM86XX_CHIPID_TANGO3    10000

#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
#include <asm/tango2/hardware.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
#include <asm/tango2/rmdefs.h>
#endif
#include <asm/delay.h>
#define RMPanic(x)
#include "../../../init_4ke/helpers_4ke_mipsel.h"
#else
#include <asm/hardware.h>
#endif
#include <asm/irq.h>

#include "kernelcalls.h"

#if 0
#define kcinfo(x...) kc_printk(x)
#else
#define kcinfo(...)
#endif

/*
  The two following macros are from Solomon Peachy 

  They should be present in future linux 2.4 kernels

  See also `going to sleep without races' (linux device drivers 2nd edition ch 9)
 */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
#define __wait_event_interruptible_timeout(wq, condition, ret)            \
do {                                                                      \
          wait_queue_t __wait;                                            \
          init_waitqueue_entry(&__wait, current);                         \
                                                                          \
          add_wait_queue(&wq, &__wait);                                   \
          for (;;) {                                                      \
                  set_current_state(TASK_INTERRUPTIBLE);                  \
                  if (condition)                                          \
                          break;                                          \
                  if (!signal_pending(current)) {                         \
                          if (ret) ret = schedule_timeout(ret);           \
                          if (!ret)                                       \
                                 break;                                   \
                          continue;                                       \
                  }                                                       \
                  ret = -ERESTARTSYS;                                     \
                  break;                                                  \
          }                                                               \
          set_current_state(TASK_RUNNING);                                \
          remove_wait_queue(&wq, &__wait);                                \
} while (0)
#endif


/**
   register a kernel module using devfs
*/
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
EXPORT_SYMBOL(kc_devfs_register);
struct kc_devfs_handle_t *kc_devfs_register(struct kc_devfs_handle_t *dir, const char *name, unsigned int flags, unsigned int major, unsigned int minor, unsigned long mode, void *ops, void *info)
{
	devfs_handle_t true_dir;
	devfs_handle_t *de;
	
	if (dir == NULL)
		true_dir = NULL;
	else
		true_dir = *(devfs_handle_t *) dir;

	de = (devfs_handle_t *) vmalloc(sizeof(devfs_handle_t));
	
	*de = devfs_register(true_dir, name, flags, major, minor, (umode_t) mode, ops, info);
	if (*de == NULL) {
		vfree(de);
		de = (devfs_handle_t *) NULL;
	}

	return (struct kc_devfs_handle_t *) de;
}

/**
   unregister a kernel module using devfs
*/
EXPORT_SYMBOL(kc_devfs_unregister);
void kc_devfs_unregister(struct kc_devfs_handle_t *de)
{
	if (de != NULL) {
		devfs_unregister(*(devfs_handle_t *) de);
		vfree(de);
	}
}
#endif

/** remap_page_range abstraction
 * ...
 */
EXPORT_SYMBOL(kc_remap_page_range);
int kc_remap_page_range(struct kc_vm_area_struct *vma, unsigned long from,
	unsigned long to, unsigned long size,struct kc_pgprot_t *prot)
{
	int ret = 0;

	/*
	Disable caching of VMAs (position _CACHE_MASK and _CACHE_UNCACHED bits accordingly)
	see linux/include/asm/pgtable-32.h
	*/
	((struct vm_area_struct *)vma)->vm_page_prot = pgprot_noncached(((struct vm_area_struct *)vma)->vm_page_prot);

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
#ifdef REMAP_PAGE_RANGE_FIVE_ARGS
	ret = remap_page_range((struct vm_area_struct *) vma, from, to, size,
			*(pgprot_t *) prot);
#else
	ret = remap_page_range(from, to, size, *(pgprot_t *) prot);
#endif /* REMAP_PAGE_RANGE_FIVE_ARGS */
#else
	/* linux-2.6.x always have five args */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,10)
	ret = remap_page_range((struct vm_area_struct *) vma, from, to, size,
				*(pgprot_t *) prot);
#else
	/* starting from linux-2.6.10 remap_page_range is deprecated to remap_pfn_range */
	ret = remap_pfn_range((struct vm_area_struct *) vma, from, to >> PAGE_SHIFT, size,
				*(pgprot_t *) prot);
#endif /* LINUX_VERSION_CODE < KERNEL_VERSION(2,6,10) */
#endif /* LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0) */

	return ret;
}


/** copy_from_user abstraction
 * ...
 */
EXPORT_SYMBOL(kc_copy_from_user);
unsigned long kc_copy_from_user(void *to, const void *from,unsigned long n)
{
 	memcpy(to,from,n); 
	return 0;
}



/** copy_to_user abstraction
 * ...
 */
EXPORT_SYMBOL(kc_copy_to_user);
unsigned long kc_copy_to_user(void *to, const void *from, unsigned long n)
{
 	memcpy(to,from,n); 
	return 0;
}

/** poll_wait
 * ...
 */
EXPORT_SYMBOL(kc_poll_wait);
void kc_poll_wait(void *filp, struct kc_wait_queue_head_t *q, void *wait)
{
	poll_wait((struct file *) filp, (wait_queue_head_t *) q, (struct poll_table_struct *) wait);
}

/** printk abstraction
 * ...
 */
EXPORT_SYMBOL(kc_printk);
int kc_printk(const char *fmt, ...)
{
#ifdef WITH_LOGGING
	char dest[1024];		/* hope it's enough */
	int rc;

	va_list ap;
	va_start(ap, fmt);
	rc = vsprintf(dest, fmt, ap);
	va_end(ap);

	if (rc >= 0)
		rc = printk(dest);

	return rc;
#else
	return 0;
#endif				/* WITH_LOGGING */
}

/** sprintf abstraction
 * ...
 */
EXPORT_SYMBOL(kc_sprintf);
int kc_sprintf(char * buf, const char * fmt, ...)
{
	int rc;
	
	va_list ap;
	va_start(ap,fmt);
	rc=vsprintf(buf,fmt,ap);
	va_end(ap);
	
	return rc;
}


/** sscanf abstraction
 * ...
 */
EXPORT_SYMBOL(kc_sscanf);
int kc_sscanf(const char * buf, const char * fmt, ...)
{
	va_list args;
	int i;

	va_start(args,fmt);
	i = vsscanf(buf,fmt,args);
	va_end(args);
	return i;
}


/** vmalloc abstraction
 * ...
 */
EXPORT_SYMBOL(kc_vmalloc);
void *kc_vmalloc(unsigned long size)
{
	return (void *) vmalloc(size);
}

/** vfree abstraction
 * ...
 */
EXPORT_SYMBOL(kc_vfree);
void kc_vfree(void *addr)
{
	vfree(addr);
}

//
// spinlocks
//

/** spin_lock_init abstraction
 * ...
 */
EXPORT_SYMBOL(kc_spin_lock_init);
void kc_spin_lock_init(struct kc_spinlock_t **lock)
{
	spinlock_t *truelock;

	/* in some cases, spinlock_t is just an empty struct. 
	   So, do not try to allocate it (it will never be dereferenced of course) */
	if (sizeof(spinlock_t) > 0)
		truelock = (spinlock_t *) vmalloc(sizeof(spinlock_t));
	else
		truelock = (spinlock_t *) NULL;

	spin_lock_init(truelock);

	*lock = (struct kc_spinlock_t *) truelock;
}


/** spin_lock_deinit free the memory used by a spinlock
 * @param lock a pointer to a struct kc_spinlock_t to free
 */
EXPORT_SYMBOL(kc_spin_lock_deinit);
void kc_spin_lock_deinit(struct kc_spinlock_t *lock)
{
	if (sizeof(spinlock_t) > 0)
		vfree(lock);
}

/** spin_lock abstraction
 * ...
 */
EXPORT_SYMBOL(kc_spin_lock);
void kc_spin_lock(struct kc_spinlock_t *lock)
{
	spin_lock((spinlock_t *) lock);
}

/** spin_unlock abstraction
 * ...
 */
EXPORT_SYMBOL(kc_spin_unlock);
void kc_spin_unlock(struct kc_spinlock_t *lock)
{
	spin_unlock((spinlock_t *) lock);
}


/** spin_lock_bh abstraction
 * ...
 */
EXPORT_SYMBOL(kc_spin_lock_bh);
void kc_spin_lock_bh(struct kc_spinlock_t *lock)
{
	spin_lock_bh((spinlock_t *) lock);
}

/** spin_unlock_bh abstraction
 * ...
 */
EXPORT_SYMBOL(kc_spin_unlock_bh);
void kc_spin_unlock_bh(struct kc_spinlock_t *lock)
{
	spin_unlock_bh((spinlock_t *) lock);
}


/** spin_lock_irq abstraction
 * ...
 */
EXPORT_SYMBOL(kc_spin_lock_irq);
void kc_spin_lock_irq(struct kc_spinlock_t *lock)
{
	spin_lock_irq((spinlock_t *) lock);
}

/** spin_unlock_irq abstraction
 * ...
 */
EXPORT_SYMBOL(kc_spin_unlock_irq);
void kc_spin_unlock_irq(struct kc_spinlock_t *lock)
{
	spin_unlock_irq((spinlock_t *) lock);
}

/** spin_lock_irqsave abstraction
 * ...
 */
EXPORT_SYMBOL(kc_spin_lock_irqsave);
void kc_spin_lock_irqsave(struct kc_spinlock_t *lock, unsigned long *flags)
{				/* ! this is a macro */
	spin_lock_irqsave((spinlock_t *) lock, *flags);
}

/** spin_unlock_irqrestore abstraction
 * ...
 */
EXPORT_SYMBOL(kc_spin_unlock_irqrestore);
void kc_spin_unlock_irqrestore(struct kc_spinlock_t *lock,
	unsigned long flags)
{
	spin_unlock_irqrestore((spinlock_t *) lock, flags);
}

//
// semaphores
//

/** semaphore_init abstraction
 * ...
 */
EXPORT_SYMBOL(kc_semaphore_init);
void kc_semaphore_init(struct kc_semaphore_t **sem, int val)
{
	struct semaphore *truesem;

	truesem = (struct semaphore *) vmalloc(sizeof(struct semaphore));
	sema_init(truesem, val);

	*sem = (struct kc_semaphore_t *) truesem;
}

/** semaphore_deinit abstraction
 * ...
 */
EXPORT_SYMBOL(kc_semaphore_deinit);
void kc_semaphore_deinit(struct kc_semaphore_t *sem)
{
	vfree(sem);
}

/** down abstraction
 * ...
 */
EXPORT_SYMBOL(kc_down);
void kc_down(struct kc_semaphore_t *sem)
{
	down((struct semaphore *)sem);
}

/** down_interruptible abstraction
 * ...
 */
EXPORT_SYMBOL(kc_down_interruptible);
int kc_down_interruptible(struct kc_semaphore_t *sem)
{
	return down_interruptible((struct semaphore *)sem);
}

/** down_trylock abstraction
 * ...
 */
EXPORT_SYMBOL(kc_down_trylock);
int kc_down_trylock(struct kc_semaphore_t *sem)
{
	return down_trylock((struct semaphore *)sem);
}

/** up abstraction
 * ...
 */
EXPORT_SYMBOL(kc_up);
void kc_up(struct kc_semaphore_t *sem)
{
	up((struct semaphore *)sem);
}

//
// wait queues
// 

/** init_waitqueue_head abstraction
 * ...
 */
EXPORT_SYMBOL(kc_init_waitqueue_head);
void kc_init_waitqueue_head(struct kc_wait_queue_head_t **q)
{
	wait_queue_head_t *trueq;
	trueq = (wait_queue_head_t *) vmalloc(sizeof(wait_queue_head_t));
	init_waitqueue_head(trueq);

	*q = (struct kc_wait_queue_head_t *) trueq;
}

/** free the memory used by a waitqueue_head
 * @param q pointer to the struct kc_wait_queue_head_t to free
 */
EXPORT_SYMBOL(kc_deinit_waitqueue_head);
void kc_deinit_waitqueue_head(struct kc_wait_queue_head_t *q)
{
	vfree(q);
}

/** wake_up_interruptible abstraction
 * ...
 */
EXPORT_SYMBOL(kc_wake_up_interruptible);
void kc_wake_up_interruptible(struct kc_wait_queue_head_t *q)
{
	wake_up_interruptible((wait_queue_head_t *) q);
}

/** interruptible_sleep_on_timeout abstraction
 * ...
 */
EXPORT_SYMBOL(kc_interruptible_sleep_on_timeout);
long kc_interruptible_sleep_on_timeout(struct kc_wait_queue_head_t *q,
				       signed long timeout)
{
	if (timeout == 0) return 0;
	return interruptible_sleep_on_timeout((wait_queue_head_t *) q, timeout);
}

/** signal_pending abstraction for current process
 * ...
 */
EXPORT_SYMBOL(kc_signal_pending_current);
int kc_signal_pending_current()
{
	return signal_pending(current);
}

/** get current pid
 */
EXPORT_SYMBOL(kc_currentpid);
int kc_currentpid()
{
	return current->pid;
}

/** Wait for an event with given timeout
 * @param wq the wait_queue
 * @param condition the condition to wait
 * @timeout maximum wait
 * @return time remaining
 */
EXPORT_SYMBOL(kc_wait_event_interruptible_timeout);
long kc_wait_event_interruptible_timeout(struct kc_wait_queue_head_t *wq, 
					 unsigned int (*condition)(void *cookie), signed long timeout,void *cookie)
{
	long __ret = timeout;
        if (!(condition(cookie)))                       
                __wait_event_interruptible_timeout( 
			     *(wait_queue_head_t *)wq, condition(cookie), __ret);
        return __ret;
}


//
// atomic
// 

/** allocate a new atomic_t
 * @param v pointer to struct kc_atomic_t *
 */
EXPORT_SYMBOL(kc_atomic_init);
void kc_atomic_init(struct kc_atomic_t **v)
{
	atomic_t *truev;
	truev = (atomic_t *) vmalloc(sizeof(atomic_t));

	*v = (struct kc_atomic_t *) truev;
}


/** Free memory used by a struct kc_atomic_t
 * @param v struct kc_atomic_t to free
 */
EXPORT_SYMBOL(kc_atomic_deinit);
void kc_atomic_deinit(struct kc_atomic_t *v)
{
	vfree(v);
}

/** atomic_read abstraction
 * ...
 */
EXPORT_SYMBOL(kc_atomic_read);
int kc_atomic_read(struct kc_atomic_t *v)
{
	return atomic_read((atomic_t *) v);
}

/** atomic_set abstraction
 * ...
 */
EXPORT_SYMBOL(kc_atomic_set);
void kc_atomic_set(struct kc_atomic_t *v, int i)
{
	atomic_set((atomic_t *) v, i);
}


/** atomic_inc abstraction
 * ...
 */
EXPORT_SYMBOL(kc_atomic_inc);
void kc_atomic_inc(struct kc_atomic_t *v)
{
	atomic_inc((atomic_t *) v);
}


/** atomic_add_negative abstraction
 * ...
 */
EXPORT_SYMBOL(kc_atomic_add_negative);
int kc_atomic_add_negative(int i, struct kc_atomic_t *v)
{
	return atomic_add_negative(i, (atomic_t *) v);
}


/** atomic_dec_and_test abstraction
 * ...
 */
EXPORT_SYMBOL(kc_atomic_dec_and_test);
int kc_atomic_dec_and_test(struct kc_atomic_t *v)
{
	return atomic_dec_and_test((atomic_t *) v);
}

//
// bitops
// 

/** test_and_set_bit abstraction
 * ...
 */
EXPORT_SYMBOL(kc_test_and_set_bit);
int kc_test_and_set_bit(int nr, volatile void *addr)
{
	return test_and_set_bit(nr, addr);
}

/** test_and_clear_bit abstraction
 * ...
 */
EXPORT_SYMBOL(kc_test_and_clear_bit);
int kc_test_and_clear_bit(int nr, volatile void *addr)
{
	return test_and_clear_bit(nr, addr);
}

/** clear_bit abstraction
 * ...
 */
EXPORT_SYMBOL(kc_clear_bit);
void kc_clear_bit(int nr, volatile void *addr)
{
	clear_bit(nr, addr);
}

/** test_bit abstraction
 * ...
 */
EXPORT_SYMBOL(kc_test_bit);
int kc_test_bit(int nr, volatile void *addr)
{
	return test_bit(nr, (void *) addr);
}

/** set_bit abstraction
 * ...
 */
EXPORT_SYMBOL(kc_set_bit);
void kc_set_bit(int nr, volatile void *addr)
{
	set_bit(nr, addr);
}

//
// string
// 

/** memcpy abstraction
 * ...
 */
EXPORT_SYMBOL(kc_memcpy);
void *kc_memcpy(void *const dest, const void *src, unsigned long n)
{
	return memcpy(dest, src, n);
}

/** memset abstraction
 * ...
 */
EXPORT_SYMBOL(kc_memset);
void *kc_memset(void *d, int c, unsigned int l)
{
	return memset(d, c, l);
}

/** memcmp abstraction
 * ...
 */
EXPORT_SYMBOL(kc_memcmp);
int kc_memcmp(const void *d, const void *s, unsigned int l)
{
	return memcmp(d, s, l);
}

/** strncpy abstraction
 * ...
 */
EXPORT_SYMBOL(kc_strncpy);
char *kc_strncpy(char *d, const char *s, unsigned int l)
{
	return strncpy(d, s, l);
}


/** strcat abstraction
 * ...
 */
EXPORT_SYMBOL(kc_strcat);
char *kc_strcat(char *d, const char *s)
{
	return strcat(d, s);
}


/** strcpy abstraction
 * ...
 */
EXPORT_SYMBOL(kc_strcpy);
char *kc_strcpy(char *d, const char *s)
{
	return strcpy(d, s);
}

/** strlen abstraction
 * ...
 */
EXPORT_SYMBOL(kc_strlen);
unsigned int kc_strlen(const char *d)
{
	return strlen(d);
}

/** strnicmp
 * ...
 */
EXPORT_SYMBOL(kc_strnicmp);
int kc_strnicmp(const char *d, const char *s, unsigned int l)
{
	return strnicmp(d, s, l);
}

//
// tophalf & tasklet
// 


/** tasklet_init abstraction
 * ...
 */
EXPORT_SYMBOL(kc_tasklet_init);
void kc_tasklet_init(struct kc_tasklet_struct **t,
	void (*func) (unsigned long), unsigned long data)
{
	*t = (struct kc_tasklet_struct *) vmalloc(sizeof(struct tasklet_struct));
	tasklet_init((struct tasklet_struct *) *t, func, data);
}

/** free a kc_tasklet_struct
 * @param t the tasklet ro destroy
 */
EXPORT_SYMBOL(kc_tasklet_deinit);
void kc_tasklet_deinit(struct kc_tasklet_struct *t)
{
	vfree(t);
}

/** tasklet_disable abstraction
 * ...
 */
EXPORT_SYMBOL(kc_tasklet_disable);
void kc_tasklet_disable(struct kc_tasklet_struct *t)
{
	tasklet_disable((struct tasklet_struct *) t);
}


/** virt/phys/page abstraction
 * ...
 */
EXPORT_SYMBOL(kc_virt_to_page);
struct kc_page * kc_virt_to_page(unsigned long addr)
{
	return (struct kc_page *)virt_to_page(addr);
}

EXPORT_SYMBOL(kc_virt_to_phys);
unsigned long kc_virt_to_phys(unsigned long addr)
{
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
	/* virt_to_xxx can not handle uncached address correctly */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
	kcinfo("kc_virt_to_phys: virt = %p to -> phys= %p\n", addr, PHYSADDR(addr));
	return PHYSADDR((void *)addr);
#else
	kcinfo("kc_virt_to_phys: virt = %p to -> phys= %p\n", addr, CPHYSADDR(addr));
	return CPHYSADDR((void *)addr);
#endif
#else
	return (unsigned long) virt_to_phys(addr);
#endif /* (EM86XX_CHIP==EM86XX_CHIPID_TANGO2) */
}

EXPORT_SYMBOL(kc_virt_to_bus);
unsigned long kc_virt_to_bus(unsigned long addr)
{
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
	/* virt_to_xxx can not handle uncached address correctly */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
	kcinfo("kc_virt_to_bus: virt = %p to -> bus = %p\n", addr, PHYSADDR(addr));
	return PHYSADDR((void *)addr);
#else
	kcinfo("kc_virt_to_bus: virt = %p to -> bus = %p\n", addr, CPHYSADDR(addr));
	return CPHYSADDR((void *)addr);
#endif
#else
	return (unsigned long) virt_to_bus(addr);
#endif /* (EM86XX_CHIP==EM86XX_CHIPID_TANGO2) */
}

EXPORT_SYMBOL(kc_phys_to_virt);
unsigned long kc_phys_to_virt(unsigned long addr){
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
	/* kcinfo("kc_phys_to_virt: phys = %p to -> virt= %p\n", addr, KSEG0ADDR(addr)); */
	return KSEG0ADDR((void *)addr);
#else
	return (unsigned long) phys_to_virt(addr);
#endif /* (EM86XX_CHIP==EM86XX_CHIPID_TANGO2) */
}

//
// time
// 

/** jiffies abstraction
 * ...
 */
EXPORT_SYMBOL(kc_jiffies);
unsigned long kc_jiffies(void) { return jiffies; }

/** mdelay abstraction
 * ...
 */
EXPORT_SYMBOL(kc_mdelay);
void kc_mdelay(unsigned long n) { udelay(n*1000); }

/** udelay abstraction
 * ...
 */
EXPORT_SYMBOL(kc_udelay);
void kc_udelay(unsigned long n) { udelay(n); }

/** get time in ms
 * @return time in ms
 */
EXPORT_SYMBOL(kc_gettimems);
unsigned long kc_gettimems(void) 
{ 
	static int firsttimehere=TRUE;
	static struct timeval timeorigin;
	struct timeval now;
	
	if (firsttimehere) {
		do_gettimeofday(&timeorigin);
		firsttimehere=FALSE;
	}
	
	do_gettimeofday(&now);
	
	return (now.tv_sec-timeorigin.tv_sec)*1000+now.tv_usec/1000-timeorigin.tv_usec/1000;
}

/** get time in us
 * @return time in us
 */
EXPORT_SYMBOL(kc_gettimeus);
unsigned long long kc_gettimeus(void) 
{ 
	static int firsttimehere=TRUE;
	static struct timeval timeorigin;
	struct timeval now;
	
	if (firsttimehere) {
		do_gettimeofday(&timeorigin);
		firsttimehere=FALSE;
	}
	
	do_gettimeofday(&now);
	
	return 
		(unsigned long long)(
		 (
		  (long long)now.tv_sec
		  -(long long)timeorigin.tv_sec
		  )*1000000LL
		 +
		 ( 
		  (long long)now.tv_usec
		  -(long long)timeorigin.tv_usec
		  )
		 );
}

/** Invalidate data cache. 
 * @param pData the physical address to be flushed
 * @param size the size of the zone to flush
 */
void kc_invalidate_cache(void *pData, unsigned int size)
{
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
                        dcache_range_i(KSEG0ADDR((unsigned long) pData), (unsigned long) size);
#else
			cpu_pt110_dcache_invalidate_range((unsigned long) pData,(unsigned long) size);
#endif

	kcinfo("cache invalidated : addr = %p, size = %lu\n", pData, size);
}


/** Flush data cache. 
 * @param pData the physical address to be flushed
 * @param size the size of the zone to flush
 */
EXPORT_SYMBOL(kc_flush_cache);
void kc_flush_cache(void *pData, unsigned int size)
{
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
                        dcache_range_w(KSEG0ADDR((unsigned long) pData),(unsigned long) size);
#else
			cpu_pt110_dcache_clean_range( (unsigned long) pData,(unsigned long) size);
#endif

	kcinfo("cache flushed : addr = %p, size = %lu\n", pData, size);
}
