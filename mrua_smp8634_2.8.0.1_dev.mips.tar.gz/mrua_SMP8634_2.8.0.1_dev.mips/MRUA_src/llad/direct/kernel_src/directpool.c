/*
Copyright (C) 2003  Sigma Designs, Inc.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <linux/kernel.h>
#include <linux/module.h>

#include "directpool.h"

#include <linux/slab.h>
#include <linux/vmalloc.h>
#include <linux/interrupt.h>
#include <linux/mm.h>
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
#include <asm/tango2/hardware.h>
#include <asm/tango2/rmdefs.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
#include <asm/tango2/rmdefs.h>
#endif
#include <asm/io.h>

#ifndef XLAT_P2G // Subject to redefinition in kernel
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
#if defined(CONFIG_TANGO2_USE_TLB_REMAP_DRAM1) || defined(CONFIG_TANGOX_USE_TLB_REMAP_DRAM1) 
// In Tango 2, we need to remap addresses greater than 0x20000000. For this, the kernel is currently 
// - subject to change - setting the TLB so that @ > 0x20000000 is remapped to 0x08000000.
// Therefore for the kernel point of view GBUS address is equal to PHYSICAL address.
#define XLAT_P2G(p) (p)
#else
// In Tango 2, we need to remap addresses greater than 0x20000000. For this, the kernel is currently 
// - subject to change - setting the remap register so that @ > 0x20000000 is remapped to 0x08000000
// (128MB). Therefore @ becomes @ - 0x08000000 + 0x20000000" (== 0x18000000) when 0x08000000 < @ < 0x10000000.
#define XLAT_P2G(p) ((((p) >= 0x08000000) && ((p) < 0x10000000)) ? (p) + 0x18000000 : (p)) 
#endif
#else
#define XLAT_P2G(p) (p)
#endif
#endif

#if (EM86XX_CHIP < EM86XX_CHIPID_TANGO2)
#define UNCACHED(p) ((unsigned long) ((p)&0x7FFFFFFF))
#endif

#else
#include <asm/hardware.h>
#endif

#include <asm/irq.h>
#include <asm/atomic.h>

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
#include <asm/softirq.h>
#else
#include <asm/pgtable.h>
#endif

struct llad;
#include "kernelcalls.h"
#include "../../include/kdmapool.h"

extern unsigned long max_dmapool_memory_size;
extern unsigned long max_dmabuffer_log2_size;

/* not static because shared with kllad.c */
unsigned long kdmapool_usage_mask = 0;

/* not static because shared with kllad.c */
struct kdmapool bufferpools[MAXDMAPOOL];

static struct kdmapool_address kdmapool_area[MAXAREABUFFERCOUNT];
static unsigned long kdmapool_area_buffer_count;

#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
static unsigned long kdmapool_mmap_mask = 0;
#endif // EM86XX_CHIP

#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
#define MALLOC(x) (void *) kmalloc(x, GFP_KERNEL | __GFP_REPEAT)
#else
#define MALLOC(x) (void *) kmalloc(x, GFP_KERNEL)
#endif
#define FREE(x) kfree(x)
#else
#define MALLOC(x) vmalloc(x)
#define FREE(x) vfree(x)
#endif // EM86XX_CHIP

static int kdmapool_alloc(struct kdmapool *pool)
{
	int i, j, k;
	unsigned long buffersize = (1<<pool->log2_buffersize);
	// buffer_split is the number of buffers within 1 llad dma buffer
	int buffer_split = (1<<(max_dmabuffer_log2_size - pool->log2_buffersize));

	for (i=0 , j=0 ; i<kdmapool_area_buffer_count ; i++) {
		if (j >= pool->buffercount)
			break;

		if (test_and_set_bit(0, &(kdmapool_area[i].used)))
			continue;

		for (k=0 ; ((k<buffer_split) &&  (j<pool->buffercount)) ; k++ , j++) {
			pool->buf_info[j].area_buffer_index = i;
			pool->buf_info[j].addr = (unsigned char *) kdmapool_area[i].addr + k*buffersize;
			//			printk("buffer virt address : %p ", pool->buf_info[j].addr);
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
			pool->buf_info[j].bus_addr = kdmapool_area[i].bus_addr + k*buffersize;
			//			printk("bus address : 0x%08lx ", pool->buf_info[j].bus_addr);
#endif // EM86XX_CHIP
			//			printk("\n");
		}
	}

	if (j<pool->buffercount) {
		for (k=0 ; k<j ; k += buffer_split) {
			i = pool->buf_info[k].area_buffer_index; 
			clear_bit(0, &(kdmapool_area[i].used));
		}
		return -ENOMEM;
	}

	return 0;
}

static void kdmapool_free(struct kdmapool *pool)
{
	int i,j;
	int buffer_split = (1<<(max_dmabuffer_log2_size - pool->log2_buffersize));

	for (j=0 ; j<pool->buffercount ; j += buffer_split) {
		i = pool->buf_info[j].area_buffer_index;
		clear_bit(0, &(kdmapool_area[i].used));
	}
}

int kdmapool_init(struct llad *h)
{
	int i;
	unsigned long buffersize = (1 << max_dmabuffer_log2_size);

	for (i=0 ; i<MAXDMAPOOL ; i++) {
		init_waitqueue_head(&(bufferpools[i].queue));
		bufferpools[i].first_free = 0;
	}

	kdmapool_area_buffer_count = max_dmapool_memory_size / buffersize;

	if (kdmapool_area_buffer_count > MAXAREABUFFERCOUNT) {
		printk("mumpool_init: too many buffers to create this dmapool area (%lu > %d)\n", kdmapool_area_buffer_count, MAXAREABUFFERCOUNT);
		return -ENOMEM;
	}
	
	for (i=0 ; i<kdmapool_area_buffer_count ; i++) {
		clear_bit(0, &(kdmapool_area[i].used));
		
		kdmapool_area[i].addr = MALLOC(buffersize);
		if (kdmapool_area[i].addr == NULL) {
			int j;
			
			for (j=0 ; j<i ; j++) {
				FREE(kdmapool_area[j].addr);
			}
			kdmapool_area_buffer_count = 0;
			printk("mumpool_init: cannot allocate dma buffers\n");
			return -ENOMEM;
		}

#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
		kdmapool_area[i].bus_addr=XLAT_P2G(virt_to_phys(kdmapool_area[i].addr));
#endif // EM86XX_CHIP
	}

#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
/* Only applied for kernel 2.4.x */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
	for (i=0 ; i<kdmapool_area_buffer_count ; i++) {
		struct page *pbeg, *pend, *page;
		
		pbeg = virt_to_page(kdmapool_area[i].addr);
		pend = virt_to_page((unsigned char *) kdmapool_area[i].addr + buffersize);
		for (page=pbeg;page<pend;page++)
			set_bit(PG_reserved, &((page)->flags));
	}
#endif
#endif // EM86XX_CHIP
	
	return 0;
}

void kdmapool_deinit(struct llad *h)
{
	int i;

	for (i=0 ; i<kdmapool_area_buffer_count ; i++) {
		if (test_and_clear_bit(0, &(kdmapool_area[i].used)))
			printk("kdmapool_deinit: an area buffer has not been released\n");
		FREE(kdmapool_area[i].addr);
	}

	kdmapool_area_buffer_count = 0;
}

EXPORT_SYMBOL(kdmapool_check_valid);
long kdmapool_check_valid(struct llad *h, unsigned long dmapool_id)
{

	if (!test_bit(dmapool_id, &(kdmapool_usage_mask))) { 
		printk("dmapool index %lu is not opened\n", dmapool_id);
		return -EINVAL;
	}
	
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
	if (!test_bit(dmapool_id, &kdmapool_mmap_mask)) {
		printk("dmapool index %lu is not mmaped\n", dmapool_id);
		return -EINVAL;
	}
#endif // EM86XX_CHIP	

	return 0;
}

EXPORT_SYMBOL(kdmapool_check_opened);
long kdmapool_check_opened(struct llad *h, unsigned long dmapool_id)
{

	if (!test_bit(dmapool_id, &(kdmapool_usage_mask))) { 
		printk("dmapool index %lu is not opened\n", dmapool_id);
		return -EINVAL;
	}
	
	return 0;
}


EXPORT_SYMBOL(kdmapool_open);
int kdmapool_open(struct llad *h, void *area, unsigned long buffercount, unsigned long log2_buffersize)
{
	int dmapool_id;
	struct kdmapool *pool;
	unsigned long buffersize = (1 << log2_buffersize);
	int i;

#ifdef _DEBUG
	printk("Opening DMAPOOL %lu %lu\n", buffercount, log2_buffersize);
#endif

	if (log2_buffersize > max_dmabuffer_log2_size) {
		printk("kdmapool_open: buffersize too big, (%lu > %lu)\n", log2_buffersize, max_dmabuffer_log2_size);
		return -EINVAL;
	}

	if (log2_buffersize < PAGE_SHIFT) {
		printk("kdmapool_open: buffersize too small, (%u > %lu)\n", PAGE_SHIFT, log2_buffersize);
		return -EINVAL;
	}

	/* looks for a free entry */
	for (dmapool_id=0 ; dmapool_id<MAXDMAPOOL ; dmapool_id++) {
		if (!test_and_set_bit(dmapool_id, &(kdmapool_usage_mask)))
			break;
	}
	
	if (dmapool_id == MAXDMAPOOL) {
		printk("Cannot find any free space for a new pool\n");
		return -EINVAL;
	}

	pool = &(bufferpools[dmapool_id]);
	pool->buf_info = (struct buffer_info *) vmalloc(sizeof(struct buffer_info) * buffercount);
	if (pool->buf_info == NULL) {
		printk("Cannot allocate ref_count array (%lu entries)\n", buffercount);
		return -EINVAL;
	}

	pool->buffercount = buffercount;
	pool->buffersize = buffersize;
	pool->log2_buffersize = log2_buffersize;
	pool->area = (unsigned char *) area;
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
	pool->user_addr = NULL;
#endif

	if (area == NULL) {
		if (kdmapool_alloc(pool)) {
			pool->buffercount = 0;
			pool->buffersize = 0;
			vfree(pool->buf_info);
			printk("Cannot allocate dma buffers\n");
			clear_bit(dmapool_id, &(kdmapool_usage_mask));
			return -ENOMEM;
		}
	}
	else {
		for (i=0 ; i<buffercount ; i++) {
			pool->buf_info[i].addr = phys_to_virt((unsigned long) area + i*buffersize);
			//printk("buffer virt address : %p ", pool->buf_info[i].addr);
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
 			pool->buf_info[i].bus_addr = XLAT_P2G(virt_to_phys(pool->buf_info[i].addr));
			//printk("bus address : 0x%08lx ", pool->buf_info[i].bus_addr);
#endif // EM86XX_CHIP
			//printk("\n");
		}
	}

        spin_lock_init(&(pool->lock));
	atomic_set(&(pool->available_buffer_count), pool->buffercount);
	
	kdmapool_reset(h, dmapool_id);
		
	return dmapool_id;
}

EXPORT_SYMBOL(kdmapool_close);
int kdmapool_close(struct llad *h, unsigned long dmapool_id)
{
	struct kdmapool *pool;
	
	if (!test_bit(dmapool_id, &(kdmapool_usage_mask))) { 
		printk("dmapool index %lu is not opened\n", dmapool_id);
		return -EINVAL;
	}

	pool = &(bufferpools[dmapool_id]);

	if (pool->area == NULL) {
		kdmapool_free(pool);
	}
	vfree(pool->buf_info);

#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
	clear_bit(dmapool_id, &kdmapool_mmap_mask);
#endif 

	clear_bit(dmapool_id, &kdmapool_usage_mask);

	return 0;
}

int kdmapool_reset(struct llad *h, unsigned long dmapool_id)
{
	int i, count;
	struct kdmapool *pool;

	if (!test_bit(dmapool_id, &(kdmapool_usage_mask))) { 
		printk("dmapool index %lu is not opened\n", dmapool_id);
		return -EINVAL;
	}

	pool = &(bufferpools[dmapool_id]);

	if ((count = atomic_read(&(pool->available_buffer_count))) != pool->buffercount) {
		printk("cannot reset dmapool index %lu since %lu buffers are still acquired\n", dmapool_id, pool->buffercount-count);
		return pool->buffercount - count;
	}

	spin_lock_bh(&(pool->lock));
	for (i=0 ; i<pool->buffercount ;  i++) {
		atomic_set(&(pool->buf_info[i].ref_count), 0);
		/* the last link is not dereferenced. It's like we used NULL. */ 
		pool->buf_info[i].next_free = i+1;
	}	
	pool->first_free = 0;
	pool->last_free = pool->buffercount - 1;
	spin_unlock_bh(&(pool->lock));
 	
	return 0;
}

int kdmapool_getinfo(struct llad *h, unsigned long dmapool_id, unsigned long *size)
{
	struct kdmapool *pool;
	
	if (!test_bit(dmapool_id, &(kdmapool_usage_mask))) { 
		printk("dmapool index %lu is not opened\n", dmapool_id);
		return -EINVAL;
	}
	
	pool = &(bufferpools[dmapool_id]);
	
	*size = pool->buffercount * pool->buffersize;
	
	return 0;
}

EXPORT_SYMBOL(kdmapool_getbuffer);
unsigned char *kdmapool_getbuffer(struct llad *h, unsigned long dmapool_id, unsigned long *timeout_us)
{
	struct kdmapool *pool;
	long timeout_jiffies = US_TO_JIFFIES(*timeout_us);
	
	pool = &(bufferpools[dmapool_id]);
	
	while (1) {
		if (atomic_add_negative(-1, &(pool->available_buffer_count))) {
			atomic_inc(&(pool->available_buffer_count));
			timeout_jiffies = interruptible_sleep_on_timeout(&(pool->queue), timeout_jiffies);	
			*timeout_us = JIFFIES_TO_US(timeout_jiffies);
			
			// handle signals gently (esp. Control-C...)
			if ((timeout_jiffies == 0) || signal_pending(current)) break;
		}
		else {
			unsigned long i;
			
			/* once here, there is a buffer available for sure */
			spin_lock_bh(&(pool->lock));
			i = pool->first_free;
			pool->first_free = pool->buf_info[i].next_free;
			if (pool->first_free == pool->buffercount)
				pool->last_free = pool->buffercount;
			spin_unlock_bh(&(pool->lock));
			atomic_set(&(pool->buf_info[i].ref_count), 1);
			
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
			if (pool->user_addr != NULL)
				return (pool->user_addr + pool->buffersize*i);
			else 
				return pool->buf_info[i].addr;
#else
			return (unsigned char *) pool->buf_info[i].addr;
#endif // EM86XX_CHIP
		}		
	}

	return NULL;
}

EXPORT_SYMBOL(kdmapool_get_available_buffer_count);
unsigned long kdmapool_get_available_buffer_count(struct llad *h, unsigned long dmapool_id)
{
	struct kdmapool *pool;
	
	pool = &(bufferpools[dmapool_id]);

	return atomic_read(&(pool->available_buffer_count));
}

EXPORT_SYMBOL(kdmapool_get_bus_address);
unsigned long kdmapool_get_bus_address(struct llad *h, unsigned long dmapool_id, unsigned char *ptr, unsigned long size)
{
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
	struct kdmapool *pool;
	unsigned long user_offset, buffer_index, buffer_offset,i;
#endif // EM86XX_CHIP

#if (EM86XX_CHIP >= EM86XX_CHIPID_TANGO2)

	pool = &(bufferpools[dmapool_id]);
	if (pool->user_addr != NULL) {
		if ((ptr < pool->user_addr) || (ptr + size > pool->user_addr + pool->buffersize * pool->buffercount)) {
			printk("user address out of range : 0x%p (%lu) [0x%p,0x%p[\n", 
			       ptr, size, pool->user_addr, pool->user_addr + pool->buffersize * pool->buffercount);
			return 0;
		}
		
		user_offset = (unsigned long) (ptr-pool->user_addr);
		
		buffer_index = user_offset >> pool->log2_buffersize;
		if ((size > 0) && (((user_offset + size - 1) >> pool->log2_buffersize) != buffer_index)) {
			printk("cannot send data belonging to two different dma buffers : %lu %lu\n", user_offset, size);
			return 0;
		}

		/* buffersize is a power of 2 */
		buffer_offset = user_offset & (pool->buffersize-1);
		return pool->buf_info[buffer_index].bus_addr + buffer_offset;
	}
	else{
		// RMuint32 buffersize = 1 << pool->log2_buffersize;
		
		for (i=0 ; i<pool->buffercount ; i++) {
			if ((ptr >= (RMuint8 *) pool->buf_info[i].addr) && (ptr + size <= (RMuint8 *) pool->buf_info[i].addr + pool->buffersize))
				break;
		}
		
		if (i == pool->buffercount) {
			printk("virtual address out of range 0x%p\n", ptr);
			return 0;
		}
		
		buffer_offset = ptr - (RMuint8 *) pool->buf_info[i].addr;
		return pool->buf_info[i].bus_addr + buffer_offset;
	}
	
#else
	/* mask bit 31 in order to convert a pt110 address to a mbus address */
	return UNCACHED(ptr);
#endif // EM86XX_CHIP
}

EXPORT_SYMBOL(kdmapool_get_virt_address);
unsigned char *kdmapool_get_virt_address(struct llad *h, unsigned long dmapool_id, unsigned long bus_addr, unsigned long size)
{
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
	struct kdmapool *pool;
	unsigned long i;
#endif // EM86XX_CHIP

#if (EM86XX_CHIP >= EM86XX_CHIPID_TANGO2)

	pool = &(bufferpools[dmapool_id]);
	for (i=0 ; i<pool->buffercount ; i++) {
		if ((bus_addr >= pool->buf_info[i].bus_addr) && (bus_addr + size <= pool->buf_info[i].bus_addr + pool->buffersize))
			break;
	}

	if (i == pool->buffercount) {
		printk("kdmapool_get_virt_address bus_address out of range 0x%08lx\n", bus_addr);
		return NULL;
	}
	
	if (pool->user_addr != NULL)
		return pool->user_addr + i*pool->buffersize + (bus_addr-pool->buf_info[i].bus_addr);
	else
		return pool->buf_info[i].addr + (bus_addr-pool->buf_info[i].bus_addr);
#else
	/* physical address is already uncached */
	return (unsigned char *) bus_addr;
#endif // EM86XX_CHIP
}

static inline unsigned long get_index_from_address(struct kdmapool *pool, unsigned long bus_addr)
{
	unsigned long i;

	for (i=0 ; i<pool->buffercount ; i++) {
#if (EM86XX_CHIP >= EM86XX_CHIPID_TANGO2)
		unsigned long addr = pool->buf_info[i].bus_addr;
#else
		unsigned long addr = UNCACHED(pool->buf_info[i].addr);
#endif // EM86XX_CHIP
		
		if ((bus_addr >= addr) && (bus_addr < addr + pool->buffersize))
			break;
	}

	return i;
}

int kdmapool_acquire(struct llad *h, unsigned long dmapool_id, unsigned long bus_addr)
{
	struct kdmapool *pool;
	unsigned long i;
	
	pool = &(bufferpools[dmapool_id]);

	i = get_index_from_address(pool, bus_addr);

	if (i == pool->buffercount) {
		printk("kdmapool_acquire bus_address out of range 0x%08lx\n", bus_addr);
		return -EINVAL;
	}

	if (atomic_read(&(pool->buf_info[i].ref_count)) == 0) {
		printk("kdmapool_acquire Buffer 0x%08lx already released\n", bus_addr);
		return -EINVAL;
	}

	atomic_inc(&(pool->buf_info[i].ref_count));
	
	return 0;
}

EXPORT_SYMBOL(kdmapool_release);
int kdmapool_release(struct llad *h, unsigned long dmapool_id, unsigned long bus_addr)
{
	struct kdmapool *pool;
	unsigned long i;
	
	pool = &(bufferpools[dmapool_id]);

	i = get_index_from_address(pool, bus_addr);

	if (i == pool->buffercount) {
		printk("kdmapool_release bus_address out of range 0x%08lx\n", bus_addr);
		return -EINVAL;
	}

	if (atomic_read(&(pool->buf_info[i].ref_count)) == 0) {
		printk("kdmapool_release Buffer 0x%08lx already released\n", bus_addr);
		return -EINVAL;
	}

	if (atomic_dec_and_test(&(pool->buf_info[i].ref_count))) {
		spin_lock_bh(&(pool->lock));
		pool->buf_info[i].next_free = pool->buffercount;
		if (pool->last_free == pool->buffercount)
			pool->first_free = i;
		else 
			pool->buf_info[pool->last_free].next_free = i;
		pool->last_free = i;
		spin_unlock_bh(&(pool->lock));

		atomic_inc(&(pool->available_buffer_count));
		wake_up_interruptible(&(pool->queue));
	}

	return 0;
}

#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)

#define DIRECT_MMAP_MASK          0xff000000
#define DIRECT_MMAP_DMAPOOL       0x02000000
#define DIRECT_MMAP_REGION        0x03000000
#define DIRECT_MMAP_DMAPOOL_SHIFT 12
#define DIRECT_MMAP_REGION_SHIFT  12

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
struct page *kdmapool_vma_nopage(struct vm_area_struct *vma, unsigned long addr, int *type)
#else
struct page *kdmapool_vma_nopage(struct vm_area_struct *vma, unsigned long addr, int unused)
#endif
{
	unsigned long offset = vma->vm_pgoff << PAGE_SHIFT;
	struct page *page = NULL;
	unsigned long dmapool_id, vaddr, i;
	struct kdmapool *pool;

	dmapool_id = (offset - DIRECT_MMAP_DMAPOOL) >> DIRECT_MMAP_DMAPOOL_SHIFT;
	pool = &(bufferpools[dmapool_id]);
	offset = (addr - vma->vm_start); /* absolute offset */
	i = offset / pool->buffersize;
	offset -= (i * pool->buffersize);  /* pool offset */
	vaddr = ((unsigned long)(pool->buf_info[i].addr + offset)) & PAGE_MASK;

	if ((page = virt_to_page(vaddr)) == NULL)
		return page;

	get_page(page);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
	if (type)
		*type = VM_FAULT_MINOR;
#endif

	return page;
}

int kdmapool_mmap(struct llad *h, struct kc_vm_area_struct *kc_vma, unsigned long dmapool_id, unsigned long start, int size,struct kc_pgprot_t *kc_prot)
{
	struct kdmapool *pool;
	struct vm_area_struct *vma = (struct vm_area_struct *) kc_vma;
	pgprot_t *prot = (pgprot_t *) kc_prot;

	if (!test_bit(dmapool_id, &kdmapool_usage_mask)) { 
		printk("dmapool index %lu is not opened\n", dmapool_id);
		return -EINVAL;
	}

	if (test_and_set_bit(dmapool_id, &kdmapool_mmap_mask)) {
		printk("dmapool index %lu is already mmaped\n", dmapool_id);
		return -EINVAL;
	}
	
	pool = &(bufferpools[dmapool_id]);

	if (size != pool->buffercount * pool->buffersize) {
		printk("wrong size to map: %u instead of %lu\n", size, pool->buffercount * pool->buffersize);
		clear_bit(dmapool_id, &kdmapool_mmap_mask);
		return -EINVAL;
	}

	/* because we run on MIPS */
	vma->vm_page_prot = pgprot_noncached(*prot);
	pool->user_addr = (unsigned char *) start;

#ifdef _DEBUG
	printk("process %d maps %d bytes at userland 0x%p\n", kc_currentpid(), size, (void *)start);
#endif

	return 0;
}
#endif // EM86XX_CHIP
