#ifndef __DIRECTPOOL_H__
#define __DIRECTPOOL_H__

#include <linux/wait.h>

#define EM86XX_CHIPID_MAMBO      1000
#define EM86XX_CHIPID_MAMBOLIGHT 2000
#define EM86XX_CHIPID_TANGO      3000
#define EM86XX_CHIPID_TANGOLIGHT 4000
#define EM86XX_CHIPID_TANGO15    4500
#define EM86XX_CHIPID_TANGO2     5000

#define MAXDMAPOOL 32
#define MAXAREABUFFERCOUNT (1024)

struct buffer_info {
	unsigned long area_buffer_index; 
	atomic_t ref_count;
	void *addr;
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
	unsigned long bus_addr;
#endif
	unsigned long next_free;
};

struct kdmapool_address {
	void *addr;
	unsigned long used;
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
	unsigned long bus_addr;
#endif
};

struct kdmapool {
	unsigned char *area;
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
	unsigned char *user_addr;
#endif
	unsigned long log2_buffersize;
	struct buffer_info *buf_info;
        spinlock_t lock;
	unsigned long buffercount;
	unsigned long buffersize;
	atomic_t available_buffer_count;
	wait_queue_head_t queue;
	unsigned long first_free;
	unsigned long last_free;
};
#endif /* __DIRECTPOOL_H__ */

