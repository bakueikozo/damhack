/*****************************************
 Copyright © 2001-2005  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   kllad_proc.c
  @brief  /proc related functions for llad 
  @author Sylvain Garrigues
  @date   2005-12-14
*/

#include <linux/module.h>
#include <linux/proc_fs.h>
#include "kllad_proc.h"
#include "directpool.h"

#define TEXT_DRIVER_PROC_ENTRY "driver/"
#define LLAD_DEVICE_NAME "llad"

static struct proc_dir_entry *proc_driver_dir;
static struct proc_dir_entry *proc_pools_dir;

int proc_read_pool(char *page, char **start, off_t off, int count, int *eof, void *data) {
       	int len = 0;
	struct kdmapool *pool = (struct kdmapool *) data;
        unsigned long dmapool_id = pool - bufferpools;

   	if (test_bit(dmapool_id, &kdmapool_usage_mask)) { 
                unsigned long buffer_count = pool->buffercount;
                unsigned long buffer_used_count = buffer_count - (unsigned long) atomic_read((atomic_t *) &(pool->available_buffer_count)); 
            
                len += snprintf(page + off + len, count - len, "pool%lu: buffer count: %lu\n", dmapool_id, buffer_count);
        	if (len >= count)
                        goto exit_read_pool;

                len += snprintf(page + off + len, count - len, "pool%lu: log2 buffer size: %lu\n", dmapool_id, pool->log2_buffersize);
        	if (len >= count)
                        goto exit_read_pool;

                len += snprintf(page + off + len, count - len, "pool%lu: buffer used: %lu (%lu%%)\n", dmapool_id, buffer_used_count, buffer_used_count * 100 / buffer_count);
        }
        else 
                len += snprintf(page + off + len, count - len, "pool%lu: no buffer in this pool\n", dmapool_id);

exit_read_pool:
        *eof = 1;
	return len;
}

void add_driver_proc_entry(void) {
	proc_driver_dir = proc_mkdir(TEXT_DRIVER_PROC_ENTRY LLAD_DEVICE_NAME, NULL);
	proc_driver_dir->owner = THIS_MODULE;
}

void rm_driver_proc_entry(void) {
	remove_proc_entry(TEXT_DRIVER_PROC_ENTRY LLAD_DEVICE_NAME, NULL);
}

void add_driver_proc_files(void) {
        char temp_string[8];
        int i;
        
        proc_pools_dir = proc_mkdir("pools", proc_driver_dir);
	proc_pools_dir->owner = THIS_MODULE;
        
        for(i = 0 ; i < MAXDMAPOOL ; i++) {
                sprintf(temp_string, "pool%d", i);
                create_proc_read_entry(temp_string, PROC_ENTRY_FILE_ACCESS, proc_pools_dir, proc_read_pool, bufferpools + i);
        }
}
        
void rm_driver_proc_files(void) {
        char temp_string[8];
        int i;
        
        for(i = 0; i < MAXDMAPOOL ; i++) {
                sprintf(temp_string, "pool%d", i);
                remove_proc_entry(temp_string, proc_pools_dir);
        }

       	remove_proc_entry("pools", proc_driver_dir);
}

