/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   rmrtktypes.h
  @brief  Types used by RealMagic OSD tool kit 
  
  @author Laurent Crinon
  @date   2004-09-07
*/

#ifndef __RMRTKTYPES_H__
#define __RMRTKTYPES_H__

#include "../../rmdef/rmdef.h"

typedef struct
{
	RMuint32 x;
	RMuint32 y;
	RMuint32 width;
	RMuint32 height;
}RtkRect;

typedef struct
{
	RMuint32 scale;
	RMuint32 fgColor;
	RMuint32 bgColor;
	RMuint32 lineWidth;
	RMuint32 lineColor;
}RtkProp;

typedef struct
{
	RMuint32 x;
	RMuint32 y;
}RtkPoint;

typedef struct
{
	RMuint32 widthInCm;
	RMuint32 heightInCm;
	RMuint32 pixelAspectRatioX;
	RMuint32 pixelAspectRatioY;
}RtkDisplayInfo;


typedef struct {
	void *pRUA;
	void *pDCC;
	void *pOSDSource;
} Rtk86Handle;


#endif // __RMRTKTYPES_H__

