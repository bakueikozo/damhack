/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmttf.h
  @brief  TrueType font parser library

  @author Oriol Prieto Gasco
  @date   2004-10-11
*/

#ifndef __RMTTF_H__
#define __RMTTF_H__

#include "../../rua/include/rua.h"

struct ttf_metrics {
	RMint16 ascender;
	RMint16 descender;
	RMuint16 unitsPerEm;
	RMuint16 max_advance;
};


struct ttf_glyph_metrics {
	RMint16 xMin;
	RMint16 yMin;
	RMint16 xMax;
	RMint16 yMax;
	RMint16 advance;
	RMint16 leftSideBearing;
};


struct ttf_scale_matrix{
	RMint16 x_scale;
	RMint16 y_scale;
	RMint16 xy_scale;
	RMint16 yx_scale;
	RMuint16 x_offset;
	RMuint16 y_offset;
};


struct ttf_subglyph{
	RMuint32 addr;
	RMuint32 size;
	struct ttf_scale_matrix scale_matrix;
};


struct ttf_glyph{
	RMuint16 subglyph_count;
	struct ttf_glyph_metrics metrics;
	RMuint32 addr; /* casted to (ttf_subglyph *) for compounds */
	RMuint32 size; /* must be 0 for compounds */
};


struct ttf_charset{
	RMuint32 char_count;
	RMuint32 *unicodes;
};


struct RMTTFont {
	struct ttf_metrics metrics;
	struct ttf_glyph *glyph_table;
	RMuint32 glyph_no;
	RMuint32 lib_base_addr;
};




RMstatus RMTTOpenFont(struct RUA *pRUA, struct RMTTFont **rmfont, RMnonAscii *fname, struct ttf_charset *charset);

/// 
/**
   Close a true type font
   @param rmfont        
   @return 
*/
RMstatus RMTTCloseFont(struct RUA *pRUA, struct RMTTFont *rmfont);

/// 
/**
   Get the glyph index of a given character from its character code
   @param rmfont        
   @param char_code     
   @return 
*/
RMuint32 RMTTGetGlyphIndex(struct RMTTFont *rmfont, RMuint32 char_code);

RMuint32 RMTTGetCompoundCount(struct RMTTFont *rmfont, RMuint32 char_code);

RMstatus RMTTGetGlyphPointer(struct RMTTFont *rmfont, RMuint32 char_code, RMuint32 index, RMuint32 *addr, RMuint32 *size);

struct ttf_glyph_metrics *RMTTGetGlyphMetrics(struct RMTTFont *rmfont, RMuint32 char_code);
struct ttf_scale_matrix *RMTTGetScaleMatrix(struct RMTTFont *rmfont, RMuint32 char_code, RMuint32 index);




#endif // __RMTTF_H__
