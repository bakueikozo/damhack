/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   rmrtk.h
  @brief  RealMagic OSD tool kit 

  This library allows to perform basic graphic operations:
  drawing rectangles, lines,
  reading and setting pixels,
  drawing characters and character strings.
  
  @author Laurent Crinon
  @date   2004-09-07
*/

#ifndef __RMRTK_H__
#define __RMRTK_H__

#include "../../dcc/include/dcc.h"
#include "../../rmdef/rmdef.h"
#include "rmrtktypes.h"

typedef struct _RMTrtk *RMTrtk;

typedef RMuint32 (*RMXlateChar) (void *charmap, RMuint32 unicode);


/// 
/**
   Open the realmagic OSD toolkit

   @param handle : handle needed to interact with the OSD (RM84xx : pRua instance, RM86xx : pOsdSurface instance)
   @return RMrtk handle if succeeded, NULL otherwise
*/
RM_EXTERN_C RMTrtk RMFRTKOpen(void *handle);

/// 
/**
   Close the rtk handle

   @param rtk : rtk handle
   @return RM_OK if succeeded, RM_ERROR otherwise
*/
RM_EXTERN_C RMstatus RMFRTKClose(RMTrtk rtk);


RM_EXTERN_C RMstatus RMFRTKSetOSD(RMTrtk rtk, struct DCCVideoSource *osd_source);


/// 
/**
   Set the information about the display (display size in centimeter, pixel aspect ratio)

   @param rtk : rtk handle
   @param displayInfo : info describing the display
*/
RM_EXTERN_C void RMFRTKSetDisplayInfo(RMTrtk rtk, RtkDisplayInfo *displayInfo);

/// 
/**
   Draw a rectangle on the OSD 

   @param rtk : rtk handle
   @param rect : rectangle to draw 
   @param prop : properies of the rectangle (foreground color = frame color, background color = fill color, ...). if set to NULL, default values are used
   @return RM_OK if succeeded, RM_ERROR otherwise
*/
RM_EXTERN_C RMstatus RMFRTKDrawRect(RMTrtk rtk, RtkRect *rect, RtkProp *prop);

/// 
/**
   Draw a line between start point and end point

   @param rtk : rtk handle
   @param startPoint : point xhere the line start
   @param endPoint : point where the line end
   @param prop : properies of the line (foreground color = line color, ...). if set to NULL, default values are used
   @return RM_OK if succeeded, RM_ERROR otherwise
*/
RM_EXTERN_C RMstatus RMFRTKDrawLine(RMTrtk rtk, RtkPoint *startPoint, RtkPoint *endPoint, RtkProp *prop);

/// 
/**
   Draw a character at the specified position.

   @param rtk : rtk handle  
   @param c : character to draw
   @param position : wanted position of the char
   @param prop : properies of the char (foreground color, background color, ...) if set to NULL, default values are used
   @param out_rect : real position of the char 
   @return RM_OK if succeeded, RM_ERROR otherwise
*/
RM_EXTERN_C RMstatus RMFRTKDrawChar(RMTrtk rtk, RMascii c, RtkPoint *position, RtkProp *prop, RtkRect *out_rect);

RM_EXTERN_C RMstatus RMFRTKDrawUnicodeChar(RMTrtk rtk, RMuint32 c, RtkPoint *position, RtkProp *prop, RtkRect *out_rect);


/// 
/**
   Draw a character at the specified position.

   @param rtk : rtk handle  
   @param c : character to get size of
   @param prop : properies of the char (only its scale size is used)
   @param out_rect : contains the character's real size on return
   @return RM_OK if succeeded, RM_ERROR otherwise
*/
RM_EXTERN_C RMstatus RMFRTKGetCharSize(RMTrtk rtk, RMascii c, RtkProp *prop, RtkRect *out_rect);

RM_EXTERN_C RMstatus RMFRTKGetUnicodeCharSize(RMTrtk rtk, RMuint32 c, RtkProp *prop, RtkRect *out_rect);


/// 
/**
   Draw a string at the specified position

   @param rtk : rtk handle
   @param string : string to draw
   @param position : wanted position of the string
   @param prop : properies of the string (foreground color, background color, ...) if set to NULL, default values are used
   @param out_rect : real position of the string
   @return RM_OK if succeeded, RM_ERROR otherwise
*/
RM_EXTERN_C RMstatus RMFRTKDrawString(RMTrtk rtk, RMascii *string, RtkPoint *position, RtkProp *prop, RtkRect *out_rect);

/// 
/**
   Set a specified pixel to the wanted foreground color.

   @param rtk : rtk handle
   @param position : position of the pixel 
   @param color : color of the pixel
   @return RM_OK if succeeded, RM_ERROR otherwise
*/
RM_EXTERN_C RMstatus RMFRTKSetPixel(RMTrtk rtk, RtkPoint *position, RMuint32 color);

/// 
/**
   Get the forground color of a particular pixel.
   --NOTE:
   --On rtk86a, when working on indexed mode, this function
   --will set the variable color to the index of the first palette entry 
   --containing the pixel's color. If the palette does not contain
   --the color, the variable is set to the 32 bit true color value,
   --and RM_ERROR is returned.

   @param rtk : rtk handle
   @param position : pixel position
   @param color : color of the pixel
   @return RM_OK if succeeded, RM_ERROR otherwise
*/
RM_EXTERN_C RMstatus RMFRTKGetPixel(RMTrtk rtk, RtkPoint *position, RMuint32 *color);

/// 
/**
   Load the font to be used to draw characters/strings. Font type is differenciate using the file extension : 
   .ttf = true type fonts, .psf = bitmap fonts

   @param rtk : rtk handle
   @param fileName : file containing the font
   @return RM_OK if succeeded, RM_ERROR otherwise
*/
RM_EXTERN_C RMstatus RMFRTKLoadFontFile(RMTrtk rtk, RMnonAscii *fontFile);

/// 
/**
   Load the font to be used to draw characters/strings. Font type is differenciate using the file extension : 
   .ttf = true type fonts, .psf = bitmap fonts. A charmap must be specified.

   @param rtk : rtk handle
   @param fileName : file containing the font
   @param unicodes : array of codes
   @param char_count: number of glyphs to load (length of unicodes[])
   @return RM_OK if succeeded, RM_ERROR otherwise
*/
RM_EXTERN_C RMstatus RMFRTKLoadFontWithCharmap(RMTrtk rtk, RMnonAscii *fontFile, RMuint32 *unicodes, RMuint32 char_count);



/// 
/**
   Set the  translation function callback. Will be applied to all drawn chars.
   @param rtk : rtk handle
   @param charmap
   @param xlate_func
   @return RM_OK if succeeded, RM_ERROR otherwise
*/
RM_EXTERN_C RMstatus RMFRTKSetCharTranslation(RMTrtk rtk,  void *charmap, RMXlateChar xlate_func);

/// 
/**
   Clear OSD

   @param rtk : rtk handle
   @return RM_OK if succeeded, RM_ERROR otherwise
*/
RM_EXTERN_C RMstatus RMFRTKClearScreen(RMTrtk rtk);

/// 
/**
   Return the dimension of the current OSD

   @param rtk : rtk handle
   @param width : width of the OSD
   @param height : height of the osd
   @param color_depth : color of the OSD
   @return RM_OK if succeeded, RM_ERROR otherwise
*/
RM_EXTERN_C RMstatus RMFRTKGetOsdDimension(RMTrtk rtk, RMuint32 *width, RMuint32 *height, RMuint32 *color_depth);

/// 
/**
   Set thendimension of theOSD buffer. Vali only on 84xxx. On 86xxx,
   the OSD dimension is set by the application using DCC

   @param rtk : rtk handle
   @param width : wanted width of the OSD
   @param height : wanted height
   @param color_depth : wanted color depth
   @return RM_OK if succeeded, RM_ERROR otherwise
*/
RM_EXTERN_C RMstatus RMFRTKSetOsdDimension(RMTrtk rtk, RMuint32 width, RMuint32 height, RMuint32 color_depth);

/// 
/**
   Get the font dimension.

   @param rtk : rtk handle
   @param width : font width
   @param height : font height
   @return RM_OK if succeeded, RM_ERROR otherwise
*/
RM_EXTERN_C RMstatus RMFRTKGetFontDimension(RMTrtk rtk, RMuint32 *width, RMuint32 *height);

/// 
/**
   enable/disable OSD, this function hide or show the OSD

   @param rtk : rtk handle
   @param enable : if TRUE, enable the OSD, if FALSE : disable OSD
   @return RM_OK if succeeded, RM_ERROR otherwise
*/
RM_EXTERN_C RMstatus RMFRTKEnableOSD(RMTrtk rtk, RMbool enable);

/// 
/**
   Reset all palette entries

   @param rtk : rtk handle
   @return RM_OK if succeeded, RM_ERROR otherwise
*/
RM_EXTERN_C RMstatus RMFRTKClearPalette(RMTrtk rtk);

/// 
/**
   Add an entry in the palette

   @param rtk : rtk handle
   @param index : index in the palette
   @param color : color to add, format=AARRGGBB 
   @return RM_OK if succeeded, RM_ERROR otherwise
*/
RM_EXTERN_C RMstatus RMFRTKSetPaletteEntry(RMTrtk rtk, RMuint8 index, RMuint32 color);

/// 
/**
   Get the color corresponding to an entry in the palette

   @param rtk : rtk handle
   @param index : wanted index
   @param color : returned color, format=AARRGGBB 
   @return RM_OK if succeeded, RM_ERROR otherwise
*/
RM_EXTERN_C RMstatus RMFRTKGetPaletteEntry(RMTrtk rtk, RMuint8 index, RMuint32 *color);

/// 
/**
   Update a rectangle color. It compares the old rectangle dimension and
   color with the new rectangle. If the colors are the same, the over
   lapped part of the rectangles are kept unchanged. If the colors are
   different, the new rectangle is completely drawn.

   @param rtk : rtk handle
   @param oldRect : old rectangle
   @param newRect : new rectangle
   @param color : wanted color
   @return RM_OK if succeeded, RM_ERROR otherwise
*/
RM_EXTERN_C RMstatus RMFRTKUpdateRect(RMTrtk rtk, RtkRect *oldRect, RtkRect *newRect, RMuint32 color);

/// 
/**
   For 86xxx only. Calculate the dimension of the rectangle where the
   wanted text will be drawn. Usefull to erase a zone before writting
   in it.

   @param rtk : rtk handle
   @param string : text to draw
   @param position      
   @param prop  
   @param out_rect    
   @return <ReturnValue>
*/
RM_EXTERN_C RMstatus RMFRTKCalculateDestWindow(RMTrtk rtk, RMascii *string, RtkPoint *position, RtkProp *prop, RtkRect *out_rect);

#endif // __RMRTK_H__
