/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/


#include "rmrtk86.h"
#include "../../rmcore/include/rmascii.h"
#include "../../dcc/include/dcc.h"


#define TIMEOUT_US 10000

#if 1
#define RTK86DBG ENABLE
#else
#define RTK86DBG DISABLE
#endif



RM_EXTERN_C RMTrtk RMFRTKOpen(void *h)
{

	RMTrtk rtk;
	RMuint32 gfx_count, i;
	RMstatus err;
	Rtk86Handle *handle;
	struct GFXEngine_ColorFormat_type format_param;
	struct GFXEngine_DRAMSize_in_type  dramSizeIn;
	struct GFXEngine_DRAMSize_out_type dramSizeOut;
	struct GFXEngine_Open_type profile;
	struct GFXEngine_Palette_1BPP_type palette_param;		
          
	if(h == NULL) {
		RMDBGLOG((RTK86DBG, "Cannot open RTK86 : handle == NULL\n"));
		return (RMTrtk)NULL;
	}
	
	handle = (Rtk86Handle *)h;
	rtk = (RMTrtk)RMMalloc(sizeof(struct _RMTrtk));
	if(!rtk){
		RMDBGLOG((RTK86DBG, "Could not allocate rtk handle\n"));
		return (RMTrtk)NULL;
	}

	rtk->pRUA = (struct RUA *)handle->pRUA;
	rtk->scratch = 0;
	rtk->gfxCachedAddr = 0;
	rtk->gfxUncachedAddr = 0;
	rtk->ttfont = NULL;
	rtk->font_type = rtk_font_type_None;
	rtk->xlate = (RMXlateChar)NULL;
	rtk->charmap = NULL;
	rtk->defaultColor = 0xffffffff;
	rtk->scratch = 0;

	dramSizeIn.CommandFIFOCount = 10;
	rtk->gfxID = EMHWLIB_MODULE(GFXEngine,0);
	err = RUAExchangeProperty(rtk->pRUA, rtk->gfxID, RMGFXEnginePropertyID_DRAMSize,
				  &dramSizeIn, sizeof(dramSizeIn), &dramSizeOut, sizeof(dramSizeOut));
	if (RMFAILED(err)) {
		RMDBGLOG((RTK86DBG, "Error getting dram size for gfx engine\n"));
		goto cleanup;
	}
	profile.CommandFIFOCount = dramSizeIn.CommandFIFOCount;
	profile.Priority = 1;
	
	profile.CachedSize = dramSizeOut.CachedSize;
	if (profile.CachedSize > 0){
		profile.CachedAddress = RUAMalloc(rtk->pRUA, 0, RUA_DRAM_CACHED, profile.CachedSize);
		rtk->gfxCachedAddr = profile.CachedAddress;
	}
	
	profile.UncachedSize = dramSizeOut.UncachedSize;
	if (profile.UncachedSize > 0) {
		profile.UncachedAddress = RUAMalloc(rtk->pRUA, 0, RUA_DRAM_UNCACHED, profile.UncachedSize);
		rtk->gfxUncachedAddr = profile.UncachedAddress;
	}
	 

	err = RUAExchangeProperty(rtk->pRUA, EMHWLIB_MODULE(Enumerator,0),  RMEnumeratorPropertyID_CategoryIDToNumberOfInstances, 
				  &(rtk->gfxID), sizeof(rtk->gfxID), &gfx_count, sizeof(gfx_count));
	if (RMFAILED(err)) {
		RMDBGLOG((RTK86DBG, "Error getting gfx engine count\n"));
		goto cleanup;
	}
	for (i=0 ; i< gfx_count ; i++) {
		rtk->gfxID = EMHWLIB_MODULE(GFXEngine, i);
		err = RUASetProperty(rtk->pRUA, rtk->gfxID, RMGFXEnginePropertyID_Open, &profile, sizeof(profile), 0);
		if (err == RM_OK) 
			break;
	}
		
	if (i==gfx_count) {
		RMDBGLOG((RTK86DBG, "Cannot open a gfx engine [0..%lu[\n", gfx_count));
		goto cleanup;
	}
	
	rtk->scratch_palette[0] = 0x0;
	rtk->scratch_palette[1] = 0xffffffff;

	palette_param.Palette[0] = rtk->scratch_palette[0];
	palette_param.Palette[1] = rtk->scratch_palette[1];
	
	palette_param.SurfaceID = GFX_SURFACE_ID_Y;
	while((err = RUASetProperty(rtk->pRUA, rtk->gfxID, RMGFXEnginePropertyID_Palette_1BPP, &palette_param, sizeof(palette_param), 0)) == RM_PENDING);
	if (RMFAILED(err)){
		RMDBGLOG((RTK86DBG, "Error sending command set palette\n"));
		goto cleanup;
	}
	

	/* setup Y */
	
	format_param.MainMode = EMhwlibColorMode_LUT_1BPP;
	format_param.SubMode = EMhwlibColorFormat_32BPP;
	format_param.SurfaceID = GFX_SURFACE_ID_Y;	

	while ((err = RUASetProperty(rtk->pRUA, rtk->gfxID, RMGFXEnginePropertyID_ColorFormat, &format_param, sizeof(format_param), 0)) == RM_PENDING);
	if (RMFAILED(err)) {
		RMDBGLOG((RTK86DBG, "Error setting color format parameters\n"));
		goto cleanup;
	}

	err = RMFRTKSetOSD(rtk, (struct DCCVideoSource *)handle->pOSDSource);
	if (RMFAILED(err)) {
		RMDBGLOG((RTK86DBG, "Error setting osd source\n"));
		goto cleanup;
	}
	
	return rtk;


 cleanup:
	if (rtk->gfxCachedAddr)
		RUAFree(rtk->pRUA, rtk->gfxCachedAddr);
	
	if (rtk->gfxUncachedAddr)
		RUAFree(rtk->pRUA, rtk->gfxUncachedAddr);

	if(rtk->scratch)
		RUAFree(rtk->pRUA, rtk->scratch);

	RMFree(rtk);
	
	return (RMTrtk) NULL;


}

RM_EXTERN_C RMstatus RMFRTKClose(RMTrtk rtk)
{
	RMuint32 close_profile = 0;
	RMstatus err;

	if(rtk == (RMTrtk)NULL){
		RMDBGLOG((RTK86DBG, "Cannot close RTK86 : rtk == NULL\n"));
		return RM_ERROR;
	}

	RUAFree(rtk->pRUA, rtk->scratch);

	err = RUASetProperty(rtk->pRUA, rtk->gfxID, RMGFXEnginePropertyID_Close, &close_profile, sizeof(close_profile), 0);
	if (RMFAILED(err)) 
		RMDBGLOG((RTK86DBG, "Cannot close de gfx accelerator\n"));
	
	
	if (rtk->gfxCachedAddr)
		RUAFree(rtk->pRUA, rtk->gfxCachedAddr);
	
	if (rtk->gfxUncachedAddr)
		RUAFree(rtk->pRUA, rtk->gfxUncachedAddr);


 	if(rtk->font_type != rtk_font_type_None){
		rtk86_unload_font(rtk);
 	}
	
	RMFree(rtk);

	RMDBGLOG((RTK86DBG, "RTK86 close\n"));

	return RM_OK;
}


RM_EXTERN_C RMstatus RMFRTKSetOSD(RMTrtk rtk, struct DCCVideoSource *osd_source)
{

	RMstatus err;
	RMuint32 scratch_size;
	RMuint32 surfAddr, picAddr;
	struct DisplayBlock_SurfaceInfo_out_type surfInfo;
	struct DisplayBlock_PictureInfo_out_type picInfo;

	struct GFXEngine_ColorFormat_type format_param;
	struct GFXEngine_Surface_type surface_param;



	/* get the physical address of the pixel buffer */
	err = DCCGetOSDPictureInfo(osd_source, 0 , &picAddr, NULL, NULL, NULL, NULL);
	if (RMFAILED(err)) {
		
		RMDBGLOG((RTK86DBG, "Cannot get surface address\n" ));
		return err;
	}
	
	err = DCCGetOSDSurfaceInfo(NULL, osd_source, NULL, &surfAddr, NULL);
	if (RMFAILED(err)) {
		RMDBGLOG((RTK86DBG, "Cannot get surface address\n" ));
		return err;
	}

	if(!picAddr){
		/* this code can be removed when the single picture surfaces are deprecated */
		err = RUAExchangeProperty(rtk->pRUA, DisplayBlock, RMDisplayBlockPropertyID_SurfaceInfo, 
					  &(surfAddr), sizeof(surfAddr), &surfInfo, sizeof(surfInfo));
		if (RMFAILED(err)) {
			RMDBGLOG((RTK86DBG, "Cannot get surface infos\n" ));
			return err;
		}

		rtk->osd = surfInfo.LumaAddress;
		rtk->osd_width = surfInfo.Width;
		rtk->osd_height = surfInfo.Height;
		rtk->color_mode = surfInfo.ColorMode;
		rtk->color_format = surfInfo.ColorFormat;
	}
	else{
		err = RUAExchangeProperty(rtk->pRUA, DisplayBlock, RMDisplayBlockPropertyID_SurfaceInfo, 
					  &(surfAddr), sizeof(surfAddr), &surfInfo, sizeof(surfInfo));
		if (RMFAILED(err)) {
			RMDBGLOG((RTK86DBG, "Cannot get surface infos\n" ));
			return err;
		}

		RMDBGLOG((ENABLE, "picture at 0x%08lx\n", picAddr));

		err = RUAExchangeProperty(rtk->pRUA, DisplayBlock, RMDisplayBlockPropertyID_PictureInfo, 
					  &(picAddr), sizeof(picAddr), &picInfo, sizeof(picInfo));
		if (RMFAILED(err)) {
			RMDBGLOG((RTK86DBG, "Cannot get picture infos\n" ));
			return err;
		}

		rtk->color_mode = surfInfo.ColorMode;
		rtk->color_format = surfInfo.ColorFormat;
		rtk->osd_width = picInfo.Width;
		rtk->osd_height = picInfo.Height;
		rtk->osd = picInfo.LumaAddress;
	}
	RMDBGLOG((RTK86DBG, "OSD size : %lu*%lu\n", rtk->osd_width, rtk->osd_height));
	//scratch_width and scratch_height should be 64 multiples
	scratch_size = rtk->osd_width + ((rtk->osd_width & 0x3F) ? (64 - (rtk->osd_width & 0x3F)) : 0);
	scratch_size *= rtk->osd_height + ((rtk->osd_height & 0x3F) ? (64 - (rtk->osd_height & 0x3F)) : 0);
	//allocate space for the scratch surface
	if(rtk->scratch)
		RUAFree(rtk->pRUA, rtk->scratch);
			
	rtk->scratch = RUAMalloc(rtk->pRUA, 0, RUA_DRAM_UNCACHED, scratch_size);
	if(!rtk->scratch){
		RMDBGLOG((RTK86DBG,  "Error allocating scratch\n"));
		return err;
	}

	/* setup NX */
	format_param.SurfaceID = GFX_SURFACE_ID_NX;
	format_param.MainMode = rtk->color_mode;
	format_param.SubMode = rtk->color_format;
		
		
	while((err = RUASetProperty(rtk->pRUA, rtk->gfxID, RMGFXEnginePropertyID_ColorFormat, &format_param, sizeof(format_param), 0)) == RM_PENDING);
	if (RMFAILED(err)) {
		RMDBGLOG((RTK86DBG,  "Error setting color format parameters\n"));
		return err;
	}
		
	surface_param.SurfaceID = GFX_SURFACE_ID_NX;
	surface_param.StartAddress = rtk->osd;
	surface_param.TotalWidth = rtk->osd_width; 
	surface_param.Tiled = FALSE; 
	while((err = RUASetProperty(rtk->pRUA, rtk->gfxID, RMGFXEnginePropertyID_Surface, &surface_param, sizeof(surface_param), 0)) == RM_PENDING); 
	if (RMFAILED(err)) {
		RMDBGLOG((RTK86DBG,  "Error setting surface parameters\n"));
		return err;
	}

	return RM_OK;
}

RM_EXTERN_C RMstatus RMFRTKDrawLine(RMTrtk rtk, RtkPoint *startPoint, RtkPoint *endPoint, RtkProp *prop)
{
	/* missing implementation */
	return RM_OK;
}


RM_EXTERN_C RMstatus RMFRTKDrawRect(RMTrtk rtk,  RtkRect*rect, RtkProp *prop)
{
	struct GFXEngine_FillRectangle_type fill_param;
	RMstatus err;
	RMuint32 lineWidth, lineColor = 0, fillColor;

	if((rtk == (RMTrtk)NULL) || (rtk->osd == 0) || (rtk->scratch == 0)){
		RMDBGLOG((RTK86DBG, "Failed to draw rectangle due to an invalid rtk handler\n"));
		return RM_ERROR;
	}
	if(rect == NULL){
		RMDBGLOG((RTK86DBG, "Failed to draw rectangle: rectangle argument is null\n"));
		return RM_ERROR;	
	}


	if((rect->x + rect->width > rtk->osd_width) ||  (rect->height + rect->y > rtk->osd_height)){
		RMDBGLOG((RTK86DBG, "Failed to draw rectangle: one or more points off osd limits\n"));
		return RM_ERROR;	
	}
	
	if((rect->width == 0) ||  (rect->height == 0)){
		return RM_OK;	
	}

	
	if (prop){
		lineWidth = prop->lineWidth;
		lineColor = prop->lineColor;
		fillColor = prop->fgColor;
		if (2*lineWidth >= RMmin(rect->width, rect->height) ){
			//outline is far too thick
			fillColor = lineColor;
			lineWidth = 0;
		}
	}
	else{
		lineWidth = 0;
		fillColor = rtk->defaultColor;
	}

	//Draw the rectangle, using a fill command.
	if(lineWidth){
		fill_param.X = rect->x;
		fill_param.Y = rect->y;
		fill_param.Width = rect->width;
		fill_param.Height = rect->height;
		fill_param.Color = lineColor;
		while((err = RUASetProperty(rtk->pRUA, rtk->gfxID, RMGFXEnginePropertyID_FillRectangle, &fill_param, sizeof(fill_param), 0)) == RM_PENDING);
		if (RMFAILED(err)) 
			RMDBGLOG((RTK86DBG, "Error sending command fill\n"));
	}
	fill_param.X = rect->x + lineWidth;
	fill_param.Y = rect->y + lineWidth;
	fill_param.Width = rect->width - 2*lineWidth;
	fill_param.Height = rect->height - 2*lineWidth;
	fill_param.Color = fillColor;
 	while((err = RUASetProperty(rtk->pRUA, rtk->gfxID, RMGFXEnginePropertyID_FillRectangle, &fill_param, sizeof(fill_param), 0)) == RM_PENDING);
	if (RMFAILED(err)) 
		RMDBGLOG((RTK86DBG, "Error sending command fill\n"));
		
	return RM_OK;

}


RM_EXTERN_C RMstatus RMFRTKDrawChar(RMTrtk rtk, RMascii c, RtkPoint *position, RtkProp *prop, RtkRect *out_rect)
{
	RMuint32 fgColor, bgColor, char_size;
	RMstatus err;


	if((rtk == (RMTrtk)NULL) || (rtk->osd == 0) || (rtk->scratch == 0)){
		RMDBGLOG((RTK86DBG, "Failed to draw character due to an invalid rtk handler\n"));
		return RM_ERROR;
	}

	if(rtk->font_type == rtk_font_type_None){
 		RMDBGLOG((RTK86DBG, "No font is open yet\n"));
 		return RM_ERROR;
 	}
	

	if(position == NULL){
		RMDBGLOG((RTK86DBG, "Failed to draw character due to an invalid position parameter\n"));
		return RM_ERROR;
		
	}
	if(position->x >= rtk->osd_width || position->y >= rtk->osd_height){
		RMDBGLOG((RTK86DBG, "Failed to draw character: position is off osd limits\n"));
		return RM_ERROR;
	}			

	if(prop != NULL){
		fgColor = prop->fgColor;
		bgColor = prop->bgColor;
		char_size = prop->scale;
	}
	else{
		fgColor = rtk->defaultColor;
		bgColor = 0x0;
		char_size= 32;
	}
	
	err = rtk86_draw_char(rtk, (RMuint32)c, char_size, fgColor, bgColor, position, out_rect);
	if(RMFAILED(err)){
		RMDBGLOG((RTK86DBG, "The glyph for character \'%c\' could not be drawn\n", c));
		return RM_ERROR;
	}
	
	return RM_OK;
}

RM_EXTERN_C RMstatus RMFRTKGetCharSize(RMTrtk rtk, RMascii c, RtkProp *prop, RtkRect *out_rect)
{

	RMuint32 char_size = 32;
	struct GFXEngine_GlyphMask_type glyph_param;

	if(prop != NULL){
		char_size = prop->scale;
	}
	
	switch(rtk->font_type){
	case rtk_font_type_None:
 		RMDBGLOG((RTK86DBG, "No font is open yet\n"));
 		return RM_ERROR;
	case rtk_font_type_TT:
		return rtk86_get_tt_char_size(rtk, (RMuint32)c, char_size, &glyph_param, out_rect);
	case rtk_font_type_PS:
		return rtk86_get_ps_char_size(rtk, (RMuint32)c, char_size, out_rect);
	}
	
	return RM_OK;
}

RM_EXTERN_C RMstatus RMFRTKDrawUnicodeChar(RMTrtk rtk, RMuint32 c, RtkPoint *position, RtkProp *prop, RtkRect *out_rect)
{
	RMuint32 fgColor, bgColor, char_size;
	RMstatus err;


	if(position->x >= rtk->osd_width || position->y >= rtk->osd_height){
		RMDBGLOG((RTK86DBG, "Failed to draw character: position is off osd limits\n"));
		return RM_ERROR;
	}			

	
	if(rtk->xlate != NULL){
		c = (*(rtk->xlate))(rtk->charmap, c);
	}

	if(prop != NULL){
		fgColor = prop->fgColor;
		bgColor = prop->bgColor;
		char_size = prop->scale;
	}
	else{
		fgColor = rtk->defaultColor;
		bgColor = 0x0;
		char_size = 32;
	}

	err = rtk86_draw_char(rtk, (RMuint32)c, char_size, fgColor, bgColor, position, out_rect);
	if(RMFAILED(err)){
		RMDBGLOG((RTK86DBG, "The glyph for character \'%c\' could not be drawn\n", c));
		return RM_ERROR;
	}
	return RM_OK;
}

RM_EXTERN_C RMstatus RMFRTKGetUnicodeCharSize(RMTrtk rtk, RMuint32 c, RtkProp *prop, RtkRect *out_rect)
{

	RMuint32 char_size = 32;
	struct GFXEngine_GlyphMask_type glyph_param;

	if(prop != NULL){
		char_size = prop->scale;
	}

	if(rtk->xlate != NULL){
		c = (*(rtk->xlate))(rtk->charmap, c);
	}
	
	switch(rtk->font_type){
	case rtk_font_type_None:
 		RMDBGLOG((RTK86DBG, "No font is open yet\n"));
 		return RM_ERROR;
	case rtk_font_type_TT:
		return rtk86_get_tt_char_size(rtk, (RMuint32)c, char_size, &glyph_param, out_rect);
	case rtk_font_type_PS:
		return rtk86_get_ps_char_size(rtk, (RMuint32)c, char_size, out_rect);
	}
	
	return RM_ERROR;
}



RM_EXTERN_C RMstatus RMFRTKDrawString(RMTrtk rtk, RMascii *string, RtkPoint *position, RtkProp *prop, RtkRect *out_rect)
{
	RMuint32 fgColor, bgColor, char_size;
	RMuint32 i;
	RMstatus err;
	RtkPoint pos;

	if(position->x >= rtk->osd_width || position->y >= rtk->osd_height){
		RMDBGLOG((RTK86DBG, "Failed to draw string: position x: %lu >= %lu or y: %lu >= %lu is off osd limits\n", position->x, rtk->osd_width, position->y, rtk->osd_height));
		return RM_ERROR;
	}			

	if(prop != NULL){
		fgColor = prop->fgColor;
		bgColor = prop->bgColor;
		char_size = prop->scale;
	}
	else{
		fgColor = rtk->defaultColor;
		bgColor = 0x0;
		char_size=32;
	}

	if(out_rect){
		out_rect->x = position->x;
		out_rect->y = position->y;
		out_rect->width = 0;
	}

	pos.x = position->x;
	pos.y = position->y;

	for( i = 0; i < RMasciiLength(string); i++){
		RtkRect char_out_rect;
		RMuint32 char_code = (RMuint32)string[i];
		/* filter out non ascii chars */
		if(char_code > 127) char_code = ' ';
		err = rtk86_draw_char(rtk, char_code, char_size, fgColor, bgColor, &pos, &char_out_rect);
		if(RMFAILED(err)){
			RMDBGLOG((RTK86DBG, "The glyph for character \'%c\' could not be drawn\n", string[i]));
			break;
		}
		pos.x += char_out_rect.width;
		if(out_rect){
			out_rect->width += char_out_rect.width;
			out_rect->height = char_out_rect.height;

		}
	}
	
	return RM_OK;
}


RM_EXTERN_C RMstatus RMFRTKCalculateDestWindow(RMTrtk rtk, RMascii *string, RtkPoint *position, RtkProp *prop, RtkRect *out_rect)
{
	RMuint32 char_size = 32;
	RMuint32 i;
	RMstatus err = RM_ERROR;
	struct GFXEngine_GlyphMask_type glyph_param;


	if(position->x >= rtk->osd_width || position->y >= rtk->osd_height){
		RMDBGLOG((RTK86DBG, "Failed to draw string: position is off osd limits\n"));
		return RM_ERROR;
	}
	if(prop != NULL){
		char_size = prop->scale;
	}

	if(out_rect){
		out_rect->x = position->x;
		out_rect->y = position->y;
		out_rect->width = 0;
		out_rect->height = 0;
	}



	for( i = 0; i < RMasciiLength(string); i++){
		RtkRect char_out_rect = {0};
		switch(rtk->font_type){
		case rtk_font_type_None:
			RMDBGLOG((RTK86DBG, "No font is open yet\n"));
			err = RM_ERROR;
		case rtk_font_type_TT:
			err = rtk86_get_tt_char_size(rtk, (RMuint32)string[i], char_size, &glyph_param, &char_out_rect);
			break;
		case rtk_font_type_PS:
			err = rtk86_get_ps_char_size(rtk, (RMuint32)string[i], char_size, &char_out_rect);
			break;
		}
		if(RMFAILED(err)){
			RMDBGLOG((RTK86DBG, "Could not get size for character \'%c\'\n", string[i]));
			return err;
		}
		if(out_rect){
			out_rect->width += char_out_rect.width;
			if(out_rect->height < char_out_rect.height)
				out_rect->height = char_out_rect.height;
		}
	}
	
	return RM_OK;
}




RM_EXTERN_C RMstatus RMFRTKSetPixel(RMTrtk rtk, RtkPoint *position, RMuint32 color){
	RMstatus err;
	RMuint32 addr;
	RMuint32 *pixel;
	//this function does not use the gfx acc
	if((rtk == (RMTrtk)NULL) || (rtk->osd == 0)){
		RMDBGLOG((RTK86DBG, "Failed to draw string due to an invalid rtk handler\n"));
		return RM_ERROR;
	}
	addr = rtk86_get_pixel_address(rtk, position);
	err = RUALock(rtk->pRUA, addr, 4);
	if (RMFAILED(err)) {
		RMDBGLOG((RTK86DBG, "Error locking OSD buffer at 0x%08lX (0x%08lX bytes)\n", addr, 4));
		return err;
	}
	pixel =(RMuint32 *) RUAMap(rtk->pRUA, addr,  4);
	if (pixel == NULL) {
		RMDBGLOG((RTK86DBG, "Error mapping OSD buffer at 0x%08lX (0x%08lX bytes)\n", addr, 4));
		return RM_ERROR;
	}
	
	*pixel = color;

	RUAUnMap(rtk->pRUA, (RMuint8*)pixel, 4);
	
	err = RUAUnLock(rtk->pRUA, addr, 4);
	if (RMFAILED(err)) {
		RMDBGLOG((RTK86DBG, "Error unlocking OSD buffer at 0x%08lX (0x%08lX bytes)\n", addr, 4));
		return err;
	}


	return RM_OK;

	

}

RM_EXTERN_C RMstatus RMFRTKGetPixel(RMTrtk rtk, RtkPoint *position, RMuint32 *color){
	RMstatus err;
	RMuint32 addr;
	RMuint32 *pixel;
	//this function does not use the gfx acc
	if((rtk == (RMTrtk)NULL) || (rtk->osd == 0)){
		RMDBGLOG((RTK86DBG, "Failed to draw string due to an invalid rtk handler\n"));
		return RM_ERROR;
	}
	addr = rtk86_get_pixel_address(rtk, position);
	err = RUALock(rtk->pRUA, addr, 4);
	if (RMFAILED(err)) {
		RMDBGLOG((RTK86DBG, "Error locking OSD buffer at 0x%08lX (0x%08lX bytes)\n", addr, 4));
		return err;
	}
	pixel =(RMuint32 *) RUAMap(rtk->pRUA, addr,  4);
	if (pixel == NULL) {
		RMDBGLOG((RTK86DBG, "Error mapping OSD buffer at 0x%08lX (0x%08lX bytes)\n", addr, 4));
		return RM_ERROR;
	}

	*color = *pixel;

	RUAUnMap(rtk->pRUA, (RMuint8*)pixel, 4);
	
	err = RUAUnLock(rtk->pRUA, addr, 4);
	if (RMFAILED(err)) {
		RMDBGLOG((RTK86DBG, "Error unlocking OSD buffer at 0x%08lX (0x%08lX bytes)\n", addr, 4));
		return err;
	}

	return RM_OK;

	

}

RM_EXTERN_C RMstatus RMFRTKClearScreen(RMTrtk rtk){
	struct GFXEngine_FillRectangle_type fill_param;
	RMstatus err;

	if((rtk == (RMTrtk)NULL) || (rtk->osd == 0)){
		RMDBGLOG((RTK86DBG, "Failed to draw string due to an invalid rtk handler\n"));
		return RM_ERROR;
	}

	fill_param.X = 0;
	fill_param.Y = 0;
	fill_param.Width = rtk->osd_width;
	fill_param.Height = rtk->osd_height;
	fill_param.Color = 0x0;
	while((err = RUASetProperty(rtk->pRUA, rtk->gfxID, RMGFXEnginePropertyID_FillRectangle, &fill_param, sizeof(fill_param), 0)) == RM_PENDING);
	if (RMFAILED(err)) RMDBGLOG((RTK86DBG, "Error sending command fill\n"));
	
	return RM_OK;
}

RM_EXTERN_C RMstatus RMFRTKLoadFontWithCharmap(RMTrtk rtk, RMnonAscii *fontFile, RMuint32 *unicodes, RMuint32 char_count)
{
	
	
	RMstatus err;
	struct ttf_charset charset;
	if((rtk == (RMTrtk)NULL) || (rtk->osd == 0)){
		RMDBGLOG((RTK86DBG, "Failed to open font due to an invalid rtk handler\n"));
		return RM_ERROR;
	}
	
	if(rtk->font_type != rtk_font_type_None){
		rtk86_unload_font(rtk);
 	}


	/* this function is only available for truetype fonts */
	charset.unicodes = unicodes;
	charset.char_count = char_count;

	err = RMTTOpenFont(rtk->pRUA, &(rtk->ttfont), fontFile, &charset);
	if (RMSUCCEEDED(err)){
		rtk->font_type = rtk_font_type_TT;
	}

	return err;
}


RM_EXTERN_C RMstatus RMFRTKSetCharTranslation(RMTrtk rtk,  void *charmap, RMXlateChar xlate_func)
{
	if(rtk == (RMTrtk)NULL){
		RMDBGLOG((RTK86DBG, "Failed to open font due to an invalid rtk handler\n"));
		return RM_ERROR;
	}
	rtk->xlate = xlate_func;
	rtk->charmap = charmap;
	return RM_OK;
}


RM_EXTERN_C RMstatus RMFRTKLoadFontFile(RMTrtk rtk, RMnonAscii *fontFile)
{
	
	RMstatus err;
	RMuint32 charset_unicodes[256];
	struct ttf_charset charset;
	charset.unicodes = charset_unicodes;

	if((rtk == (RMTrtk)NULL) || (rtk->osd == 0)){
		RMDBGLOG((RTK86DBG, "Failed to open font due to an invalid rtk handler\n"));
		return RM_ERROR;
	}

	if(rtk->font_type != rtk_font_type_None){
		err = rtk86_unload_font(rtk);
		if(RMFAILED(err)){
			RMDBGLOG((RTK86DBG, "Failed to close the previously open font\n"));
			return RM_ERROR;
		}
 	}

	return rtk86_load_font(rtk, fontFile);
}



RM_EXTERN_C RMstatus RMFRTKGetOsdDimension(RMTrtk rtk, RMuint32 *width, RMuint32 *height, RMuint32 *color_depth)
{
	if (rtk == (RMTrtk)NULL)
		return RM_ERROR;

	if(width != NULL)
		*width = rtk->osd_width;
	if(height != NULL)
		*height = rtk->osd_height;
	if(color_depth != NULL)
		*color_depth = rtk86_get_color_depth(rtk);
	return RM_OK;

}


#if 0

RM_EXTERN_C void RMFRTKSetDisplayInfo(RMTrtk rtk, RtkDisplayInfo *displayInfo)
{
	/* deprecated */
}

RM_EXTERN_C RMstatus RMFRTKClearPalette(RMTrtk rtk)
{
	return RM_ERROR;
	/* deprecated */
}

RM_EXTERN_C RMstatus RMFRTKSetOsdDimension(RMTrtk rtk, RMuint32 width, RMuint32 height, RMuint32 color_depth)
{
	return RM_ERROR;
	/* deprecated */
}

RM_EXTERN_C RMstatus RMFRTKGetFontDimension(RMTrtk rtk, RMuint32 *width, RMuint32 *height)
{
	return RM_ERROR;
	/* deprecated */
}

RM_EXTERN_C RMstatus RMFRTKSetPaletteEntry(RMTrtk rtk, RMuint8 index, RMuint32 color)
{
	return RM_ERROR;
	/* deprecated */
}

RM_EXTERN_C RMstatus RMFRTKEnableOSD(RMTrtk rtk, RMbool enable)
{
	return RM_ERROR;
	/* deprecated */
}

RM_EXTERN_C RMstatus RMFRTKUpdateRect(RMTrtk rtk, RtkRect *oldRect, RtkRect *newRect, RMuint32 color)
{
	return RM_ERROR;
	/* deprecated */
}

RM_EXTERN_C RMstatus RMFRTKGetPaletteEntry(RMTrtk rtk, RMuint8 index, RMuint32 *color)
{
	return RM_ERROR;
	/* deprecated */
}

#endif
