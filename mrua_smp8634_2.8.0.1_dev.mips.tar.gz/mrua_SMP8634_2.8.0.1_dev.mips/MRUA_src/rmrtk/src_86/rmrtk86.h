/*****************************************
 Copyright © 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/


/**
  @file   rmrtk86.h
  @brief  Structures and functions used internally by the rmrtk lib. 
  For em86xxx chips, using the graphic accelerator.

  @author Oriol Prieto Gasco
  @date   2004-10-12
*/

#ifndef __RMRTK86_H__
#define __RMRTK86_H__

#include "../include/rmrtk.h"
#include "../include/rmttf.h"

struct rtk_psf_font {
	RMuint32 lib_addr;      /* address in DRAM of the first pixel of first char */
	RMuint32 size;          /* size in bytes of every char */
 	RMuint32 width;         /* widht in pixels */
	RMuint32 height;        /* height in pixels */
	RMuint32 numchars;
	RMuint32 version;
	RMuint32 flags;
};


enum rtk_font_type {
	rtk_font_type_None,
	rtk_font_type_TT,
	rtk_font_type_PS
};

struct _RMTrtk
{
	struct RUA *pRUA;
	
	RMuint32 osd;           /* address in DRAM of the first pixel of osd */
	RMuint32 osd_width;
	RMuint32 osd_height;
	enum EMhwlibColorMode color_mode;
	enum EMhwlibColorFormat color_format;


	RMuint32 scratch; //phys addr
	RMuint32 scratch_size; //allocated size
	RMbool   scratch_ignore;
	RMuint32 scratch_palette[2];

	RMuint32 gfxID;
	RMuint32 gfxCachedAddr, gfxUncachedAddr;
	RMuint32 scalerID;

	RMuint32 defaultColor;
	enum rtk_font_type font_type;
	struct RMTTFont *ttfont;
	struct rtk_psf_font psfont;

	/* charmap translation */
	void *charmap;
	RMXlateChar xlate;
};


enum rtk_charset_type{
	rtk_charset_type_ASCII,
	rtk_charset_type_LATIN1,
	rtk_charset_type_DTVCC
};




RMstatus rtk86_draw_char(RMTrtk rtk, 
			 RMuint32 char_index, 
			 RMuint32 char_size, 
			 RMuint32 fg_color, 
			 RMuint32 bg_color, 
			 RtkPoint *point, 
			 RtkRect *out_rect);



RMstatus rtk86_load_font(RMTrtk rtk, RMnonAscii *fname);

RMstatus rtk86_unload_font(RMTrtk rtk);

RMuint32 rtk86_get_color_depth(RMTrtk rtk);

RMuint32 rtk86_get_pixel_address(RMTrtk rtk, RtkPoint *point);



static inline RMstatus rtk86_get_tt_char_size(RMTrtk rtk, RMuint32 char_index, RMuint32 char_size, struct GFXEngine_GlyphMask_type *glyph_param, RtkRect *out_rect)
{

	struct ttf_glyph_metrics *glyph_metrics;
	struct GFXEngine_GlyphOutputSize_out_type glyph_out;
	RMstatus err;

	glyph_metrics = RMTTGetGlyphMetrics(rtk->ttfont, char_index);
	if(glyph_metrics == NULL){
		RMDBGLOG((ENABLE, "Could not retrieve size( char_index %ld)\n", char_index ));
		return RM_ERROR;
	}


	glyph_param->ScaleFactor = (char_size<<11)/rtk->ttfont->metrics.unitsPerEm;
	glyph_param->XMin = glyph_metrics->xMin; 
	glyph_param->XMax = glyph_param->XMin +  glyph_metrics->advance;
	glyph_param->YMin = (RMint16)rtk->ttfont->metrics.descender; 
	glyph_param->YMax = rtk->ttfont->metrics.ascender;

	err = RUAExchangeProperty(rtk->pRUA, rtk->gfxID, RMGFXEnginePropertyID_GlyphOutputSize, glyph_param, sizeof(*glyph_param), &glyph_out, sizeof(glyph_out));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get glyph output size\n"));
		return err;
	}

	
	out_rect->width =  glyph_out.Width;
	out_rect->height = glyph_out.Height;
	return RM_OK;
}


static inline RMstatus rtk86_get_ps_char_size(RMTrtk rtk, RMuint32 char_index, RMuint32 char_size, RtkRect *out_rect)
{
	out_rect->width = (char_size * rtk->psfont.width)/rtk->psfont.height;
	out_rect->height = char_size;
	return RM_OK;
}



/* only invoked from one place in util.c */
static inline  RMstatus rtk86_draw_tt_char(RMTrtk rtk, RMuint32 char_index, RMuint32 char_size, RMuint32 fg_color, RMuint32 bg_color, RtkPoint *point, RtkRect *out_rect)
{
	struct GFXEngine_GlyphMask_type glyph_param;
	struct ttf_scale_matrix *tt_matrix = NULL;
	struct GFXEngine_GlyphScaleMatrix_type gfx_matrix;
	RMstatus err;
	RMuint32 glyph_size, glyph_addr, compound_cnt, i;

	out_rect->x = point->x;
	out_rect->y = point->y;
	
	rtk86_get_tt_char_size(rtk, char_index, char_size, &glyph_param, out_rect);

	if((out_rect->x + out_rect->width > rtk->osd_width) ||  (out_rect->height + out_rect->y > rtk->osd_height)){
		RMDBGLOG((ENABLE, "Failed to write scratch: glyph is outside the osd\n"));
		return RM_ERROR;	
	}


	compound_cnt = RMTTGetCompoundCount(rtk->ttfont, char_index);
	if(compound_cnt == 0){
		/* no glyph associated to this index, blank the osd */
		if(bg_color & 0xff000000) { 
			struct GFXEngine_FillRectangle_type fill_param;
			fill_param.X = out_rect->x;
			fill_param.Y = out_rect->y;
			fill_param.Width = out_rect->width;
			fill_param.Height = out_rect->height;
			fill_param.Color = bg_color;
			while((err = RUASetProperty(rtk->pRUA, rtk->gfxID, RMGFXEnginePropertyID_FillRectangle, &fill_param, sizeof(fill_param), 0)) == RM_PENDING);
			if (RMFAILED(err)){
				RMDBGLOG((ENABLE, "Error sending command fill\n"));
				return RM_ERROR;
			}
		}
		return RM_OK;
	}

	if (rtk->scratch_palette[0] != bg_color || rtk->scratch_palette[1] != fg_color){
		
		struct GFXEngine_Palette_1BPP_type palette_param;
		palette_param.Palette[0] = bg_color;
		palette_param.Palette[1] = fg_color;
		
		palette_param.SurfaceID = GFX_SURFACE_ID_Y;
		while((err = RUASetProperty(rtk->pRUA, rtk->gfxID, RMGFXEnginePropertyID_Palette_1BPP, &palette_param, sizeof(palette_param), 0)) == RM_PENDING);
		if (RMFAILED(err)){
			RMDBGLOG((ENABLE, "Error sending command set palette\n"));
			return RM_ERROR;
		}
		rtk->scratch_palette[0] = bg_color;
		rtk->scratch_palette[1] = fg_color;
	}

	for (i = 0; i< compound_cnt; i++){
		struct GFXEngine_MoveReplaceRectangle_type replace_param;	
		struct GFXEngine_Surface_type surface_param;

		
		tt_matrix = RMTTGetScaleMatrix(rtk->ttfont, char_index, i);
		if(tt_matrix !=NULL){
			gfx_matrix.XScale  = tt_matrix->x_scale;
			gfx_matrix.YScale  = tt_matrix->y_scale;
			gfx_matrix.YXScale = tt_matrix->yx_scale;
			gfx_matrix.XYScale = tt_matrix->xy_scale;
			gfx_matrix.XOffset = tt_matrix->x_offset;
			gfx_matrix.YOffset = tt_matrix->y_offset;
			while((err = RUASetProperty(rtk->pRUA, rtk->gfxID, RMGFXEnginePropertyID_GlyphScaleMatrix, &gfx_matrix, sizeof(gfx_matrix), 0))== RM_PENDING);
			if(RMFAILED(err)) {
				RMDBGLOG((ENABLE,"Error sending command matrix (char code %ld)\n",char_index));
				return RM_ERROR;
			}
		}

		RMTTGetGlyphPointer(rtk->ttfont, char_index, i, &glyph_addr, &glyph_size);

		if(glyph_addr == 0x0) 
			return RM_ERROR;
		
		glyph_param.GlyphAddr = glyph_addr;
		glyph_param.Size = glyph_size;
		glyph_param.OutAddr = rtk->scratch;
		while((err = RUASetProperty(rtk->pRUA, rtk->gfxID, RMGFXEnginePropertyID_GlyphMask, &glyph_param, sizeof(glyph_param), 0))== RM_PENDING);
		if(RMFAILED(err)) {	
			RMDBGLOG((ENABLE,"Error sending command glyph (char code %ld)\n", char_index));
			return RM_ERROR;
		}
		
		surface_param.SurfaceID = GFX_SURFACE_ID_Y;
		surface_param.StartAddress = rtk->scratch;
		surface_param.TotalWidth = ((out_rect->width + 0x3f)>>6)<<6;
		surface_param.Tiled = FALSE;
		
		while((err = RUASetProperty(rtk->pRUA, rtk->gfxID, RMGFXEnginePropertyID_Surface, &surface_param, sizeof(surface_param), 0)) == RM_PENDING);
		if (RMFAILED(err)) 
			RMDBGLOG((ENABLE, "Error setting surface parameters\n"));
		
		
		replace_param.SrcX = 0;
		replace_param.SrcY = 0;
		replace_param.DstX = out_rect->x;
		replace_param.DstY = out_rect->y;
		replace_param.Width = RMmax(out_rect->width, 8);
		replace_param.Height = out_rect->height;
		replace_param.AlphaX = 0;
		replace_param.AlphaY = 0;
		replace_param.Merge = GFX_MERGE_MODE_DISABLE;
		
		
		
		while((err = RUASetProperty(rtk->pRUA, rtk->gfxID, RMGFXEnginePropertyID_ReplaceRectangle, &replace_param, sizeof(replace_param), 0)) == RM_PENDING);
		if (RMFAILED(err)) 
			RMDBGLOG((ENABLE, "Error sending command move\n"));
		
	}
		
	return RM_OK;
}

/* only invoked from one place in util.c */
static inline RMstatus rtk86_draw_ps_char(RMTrtk rtk, RMuint32 char_index, RMuint32 char_size, RMuint32 fg_color, RMuint32 bg_color,  RtkPoint *point, RtkRect *out_rect)
{
	struct GFXEngine_MoveReplaceScaleRectangle_type replace_param;
	struct GFXEngine_Surface_type surface_param;
	struct GFXEngine_ColorFormat_type format_param;
	struct GFXEngine_Palette_1BPP_type palette_param;

	RMstatus err;

	out_rect->x = point->x;
	out_rect->y = point->y;
	
	rtk86_get_ps_char_size(rtk, char_index, char_size, out_rect);

	if((out_rect->x + out_rect->width > rtk->osd_width) ||  (out_rect->height + out_rect->y > rtk->osd_height)){
		RMDBGLOG((ENABLE, "Failed to write scratch: glyph is outside the osd\n"));
		return RM_ERROR;	
	}



	format_param.SurfaceID = GFX_SURFACE_ID_Z;
	surface_param.SurfaceID = GFX_SURFACE_ID_Z;
	
	format_param.MainMode = EMhwlibColorMode_LUT_1BPP;
	format_param.SubMode = EMhwlibColorFormat_32BPP;
	surface_param.StartAddress = rtk->psfont.lib_addr + (char_index * rtk->psfont.size);
	surface_param.TotalWidth = ((rtk->psfont.width + 7)>>3)<<3;
	surface_param.Tiled = FALSE;
	while((err = RUASetProperty(rtk->pRUA, rtk->gfxID, RMGFXEnginePropertyID_Surface, &surface_param, sizeof(surface_param), 0))== RM_PENDING);
	if(RMFAILED(err)) {	
		RMDBGLOG((ENABLE,"Error sending command surface (char code %ld)\n", char_index));
		return RM_ERROR;
	}

	while((err = RUASetProperty(rtk->pRUA, rtk->gfxID, RMGFXEnginePropertyID_ColorFormat, &format_param, sizeof(format_param), 0))== RM_PENDING);
	if(RMFAILED(err)) {	
		RMDBGLOG((ENABLE,"Error sending command colorformat (char code %ld)\n", char_index));
		return RM_ERROR;
	}

	palette_param.Palette[0] = bg_color;
	palette_param.Palette[1] = fg_color;
		
	palette_param.SurfaceID = GFX_SURFACE_ID_Z;
	while((err = RUASetProperty(rtk->pRUA, rtk->gfxID, RMGFXEnginePropertyID_Palette_1BPP, &palette_param, sizeof(palette_param), 0)) == RM_PENDING);
	if (RMFAILED(err)){
		RMDBGLOG((ENABLE, "Error sending command set palette\n"));
		return RM_ERROR;
	}
	
	replace_param.SrcX = 0;
	replace_param.SrcY = 0;
	replace_param.SrcWidth = rtk->psfont.width;
	replace_param.SrcHeight = rtk->psfont.height;
	replace_param.DstX = out_rect->x;
	replace_param.DstY = out_rect->y;
	replace_param.DstWidth = out_rect->width;
	replace_param.DstHeight = out_rect->height;
	replace_param.AlphaX = 0;
	replace_param.AlphaY = 0;
	replace_param.Merge = GFX_MERGE_MODE_DISABLE;

	while((err = RUASetProperty(rtk->pRUA, rtk->gfxID,  RMGFXEnginePropertyID_ReplaceAndScaleRectangle, &replace_param, sizeof(replace_param), 0))== RM_PENDING);
	if(RMFAILED(err)) {	
		RMDBGLOG((ENABLE,"Error sending command move (char code %ld)\n", char_index));
		return RM_ERROR;
	}

	return RM_OK;

}




#endif // __RMRTK86_H__
