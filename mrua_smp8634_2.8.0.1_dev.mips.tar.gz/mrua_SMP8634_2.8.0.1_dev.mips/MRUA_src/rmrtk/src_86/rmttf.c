/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
*****************************************/

#include "../../rmlibcw/include/rmlibcw.h"
#include "../../rmcore/include/rmascii.h"
#include "../include/rmttf.h"

#if 1
#define RMTTDBG ENABLE
#else
#define RMTTDBG DISABLE
#endif


/* for simple glyph flags */
#define ONOROFF	0x01
#define XSHORT	0x02
#define YSHORT	0x04
#define REPEAT	0x08
#define XSAME	0x10
#define YSAME	0x20
#define Y_GOES_HERE 0x40
#define X_GOES_HERE 0x80


/* for compound glyph flags */
#define ARG_1_AND_2_ARE_WORDS    0x0001
#define ARGS_ARE_XY_VALUES       0x0002
#define XY_BOUND_TO_GRID         0x0004
#define WE_HAVE_A_SCALE	         0x0008
#define MORE_COMPONENTS	         0x0020
#define WE_HAVE_AN_X_AND_Y_SCALE 0x0040
#define WE_HAVE_A_TWO_BY_TWO     0x0080
#define WE_HAVE_INSTRUCTIONS     0x0100
#define USE_MY_METRICS	         0x0200



#define INVALID_GLYPH 0xFFFFFFFF
#define LAT1_CHAR_NO 191
#define IS_ASCII(a) ((a)>=32 && (a)<=126)
#define IS_LATIN1(a) ((a)>=160 && (a)<=255)
#define IS_VALID_CHAR(a) (IS_ASCII(a) ? 1 : IS_LATIN1(a))




/* #define WITH_TTF */


struct table_ptrs{
	RMuint8 *head_table;
	RMuint8 *hhea_table;
	RMuint8 *cmap_table;
	RMuint8 *hmtx_table;
	RMuint8 *glyf_start;
	RMuint8 *maxp_table;
	RMuint8 *loca_table;
};

struct ttf_charmap {
	RMuint16 segCountX2;
	RMuint16 *ttf_cmap;
};



struct lib_index_entry{
	RMuint32 index;
	RMuint32 addr;
};
	

struct glyph_lib_index{
	struct lib_index_entry tab[255];
	RMuint32 cnt;
	RMuint32 size;
	RMuint32 sub_cnt;
};





static inline void get_glyph_pos(RMuint32 glyphno, struct table_ptrs *tp, RMuint8 **pos, RMuint32 *len)
{
	RMbool long_off = RMbeBufToUint16(tp->head_table + 50/*indexToLocFormat_off*/) ? TRUE : FALSE;
	if (long_off) {
		*pos = tp->glyf_start + RMbeBufToUint32(tp->loca_table + 4*glyphno);
		if (len != NULL)
			*len = RMbeBufToUint32(tp->loca_table + 4*(glyphno+1)) -  RMbeBufToUint32(tp->loca_table + 4*glyphno);
		
	} else {
		*pos = tp->glyf_start + 2*RMbeBufToUint16(tp->loca_table + 2*glyphno);
		if (len != NULL)
			*len = 2*(RMbeBufToUint16(tp->loca_table + 2*(glyphno+1)) - RMbeBufToUint16(tp->loca_table + 2*glyphno));
	}
}

		

static RMuint32 inline get_glyph_index(RMuint32 char_code)
{
	if(char_code >=0x20 && char_code < 0x7f)
		return ( char_code - 32);
	else if (char_code >=0xa0 && char_code<=0xff)
		return ( char_code - 65);
	else if (char_code >=0x7f && char_code<=0x9f)
		return ( char_code + 64);
	else if (char_code >=0x00 && char_code<=0x1f)
		return ( char_code + 192);
	return INVALID_GLYPH;
}


static RMuint32 get_glyph_index_from_charmap(struct ttf_charmap *charmap, RMuint16 char_code)
{
	RMuint32 i;
	RMuint32 glyph_no = 0;
	RMuint16 segCount = charmap->segCountX2/2;
	RMuint16 *endCount =  charmap->ttf_cmap;
	RMuint16 *startCount =  &(endCount[segCount + 1]);
	RMuint16 *idDelta = &(startCount[segCount]);
	RMuint16 *idRangeOffset =  &(idDelta[segCount]);
	for(i=0; (i<segCount) && (char_code > endCount[i]) ; i++);
	if( char_code >= startCount[i]){
		if(idRangeOffset[i]){
			glyph_no = *(idRangeOffset[i]/2 + (char_code - startCount[i]) + &idRangeOffset[i]);
		}
		else{
			glyph_no = char_code;
		}
		glyph_no += idDelta[i];
		glyph_no &= 0xffff;
	}
	else{
		return 0;
	}
	return glyph_no;
}


static RMbool search_glyph_lib(struct glyph_lib_index *lib_index, RMuint32 glyph_index, RMuint32 *addr, RMuint32 *size){
	RMuint8 i;
	for(i = 0; i < lib_index->cnt; i++){
		if(lib_index->tab[i].index == glyph_index){
			if((addr != NULL) && (size!=NULL)){
				*addr = lib_index->tab[i].addr;
				*size = (RMuint32)lib_index->tab[i+1].addr - (RMuint32)lib_index->tab[i].addr;
			}
			return TRUE;
		}
	}
	return FALSE;
}


static RMuint32 get_glyph_size(RMuint32 glyph_index, struct glyph_lib_index *lib_index, struct table_ptrs *tp)
{
	RMuint32 len, inst_size, glyph_size;
	RMint16  n_contours;
	RMuint8 *pos;
	get_glyph_pos(glyph_index, tp, &pos, &len);
	if(!len){
		return 0;
	}
	n_contours = (RMint16)RMbeBufToUint16(pos);
	if(n_contours > 0){

		/* skip if the glyph is already marked for upload */
		if(search_glyph_lib(lib_index, glyph_index, NULL, NULL)) {
			return 1;
		}
		pos += 10 + 2*n_contours; /*skip n_contours(2), xmin(2), ymin(2), xmax(2), ymax(2), all endpoints (x2) */
		inst_size = RMbeBufToUint16(pos);
		glyph_size = len + 2 - 10  - inst_size + ((n_contours & 0x1) ? 2:0);
		/* force each glyph to start into a 4-byte boundary */
		if(glyph_size & 0x3)
			glyph_size += 4-(glyph_size & 0x3);
		lib_index->size += glyph_size;

		lib_index->tab[lib_index->cnt].index = glyph_index;
		lib_index->cnt++;
		return 1;
		
	}
	else{
		RMuint16 flags, sub_glyph_index = 0;
		RMuint32 sub_glyph_count;
		sub_glyph_count = 0;
		pos += 10; /*skip bounding box*/
		do{
			flags = RMbeBufToUint16(pos); pos += 2;

			sub_glyph_index = RMbeBufToUint16(pos); pos += 2;
			sub_glyph_count += get_glyph_size(sub_glyph_index, lib_index, tp);
			if (flags & ARG_1_AND_2_ARE_WORDS)
				pos+=4;
			else
				pos+=2;
			if (flags & WE_HAVE_A_SCALE)
				pos += 2;
			else if (flags & WE_HAVE_AN_X_AND_Y_SCALE)
				pos += 4;
			else if (flags & WE_HAVE_A_TWO_BY_TWO)
				pos += 8;
		}while(flags & MORE_COMPONENTS);
		lib_index->sub_cnt += sub_glyph_count;
		return sub_glyph_count;
	}
}


static RMstatus create_glyph_lib(struct RUA *pRUA, struct glyph_lib_index *lib_index, struct table_ptrs *tp)
{
	RMstatus err;
	RMuint8 *pos, *xpos, *ypos, *mapped_lib, *mapped_lib_original, *glyph_start;
	RMuint8 flags = 0, repeat = 0;
	RMint16 n_contours;
	RMuint32 i, j, k, x_size, last_k, n_points, inst_size;
	RMuint32 lib, lib_pos;


	lib = RUAMalloc(pRUA, 0, RUA_DRAM_UNCACHED, lib_index->size);
	if(lib == 0){
		RMDBGLOG((ENABLE, "Error allocating font buffer \n"));
		return RM_ERROR;
	}

	lib_pos = lib;

	err = RUALock(pRUA, lib, lib_index->size);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error locking font buffer \n"));
		return err;
	}
	
	mapped_lib = RUAMap(pRUA, lib, lib_index->size);
	if (mapped_lib == NULL) {
		RMDBGLOG((ENABLE, "Error mapping font buffer\n"));
		return RM_ERROR;
	}
	mapped_lib_original = mapped_lib;

	for (i = 0; i < lib_index->cnt; i++){
		lib_index->tab[i].addr = lib_pos;
		glyph_start = mapped_lib;
		get_glyph_pos(lib_index->tab[i].index, tp, &pos, NULL);
		n_contours = (RMint16)RMbeBufToUint16(pos);
		RMuint16ToBeBuf(n_contours, mapped_lib); mapped_lib += 4; /* skip two extra bytes (alignment) */
		
		pos += 10; /*skip n_contours + bounding box */
		RMMemcpy(mapped_lib, pos, 2*n_contours);
		mapped_lib += 2*n_contours + ((n_contours & 0x1) ? 2:0);

		pos += 2*(n_contours-1);

		n_points = RMbeBufToUint16(pos) + 1; pos += 2;
		inst_size = RMbeBufToUint16(pos); pos += 2 + inst_size;
		j = k = x_size = repeat = 0;
		while(j < n_points) {
			if( !repeat){
				flags = (*pos) & 0x3f;
				pos++;
				mapped_lib[k] = flags;
				k++;
				if(flags & REPEAT){
					repeat = *pos;
					pos++;
					mapped_lib[k] = repeat;
					k++;
				}
			}else
				repeat--;
			if(flags & XSHORT){
				//next byte is for x
				mapped_lib[k] = X_GOES_HERE;
				k++;
				x_size++;

			}
			else if (!(flags & XSAME)){ //means xlong
				//two next bytes are for x
				mapped_lib[k] = X_GOES_HERE;
				mapped_lib[k+1] = X_GOES_HERE;
				k+=2;
				x_size+=2;
			}
			if(flags & YSHORT){
				//next byte is for y
				mapped_lib[k] = Y_GOES_HERE;
				k++;
			}
			else if (!(flags & YSAME)){
				//two following bytes are for y
				mapped_lib[k] = Y_GOES_HERE;
				mapped_lib[k+1] = Y_GOES_HERE;
				k+=2;
			}
			j++;
		}
		last_k = k;
		k = 0;
		xpos = pos;
		ypos = xpos + x_size;
		while(k < last_k){
			if (mapped_lib[k] == X_GOES_HERE){
				mapped_lib[k] = *xpos;
				xpos++;
			}
			else if (mapped_lib[k] == Y_GOES_HERE){
				mapped_lib[k] = *ypos;
				ypos++;
			}
			k++;
		}

		mapped_lib += last_k;
		if ((mapped_lib - glyph_start)& 0x3)
			mapped_lib += 4 - ((mapped_lib - glyph_start) & 0x3);
		lib_pos += (mapped_lib - glyph_start);
	}
	
	/*add an entry containing the last position*/
	lib_index->tab[lib_index->cnt].addr = lib_pos;
	
	RUAUnMap(pRUA, mapped_lib_original, lib_index->size);
	err = RUAUnLock(pRUA, lib, lib_index->size);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error locking OSD buffer\n"));
		return err;
	}
	

	return RM_OK;
}


/* returns the number of sub_glyph headers used */
static RMuint32 add_compound_glyph(RMuint32 glyph_index, 
				   struct ttf_subglyph *subs_table, 
				   struct glyph_lib_index *lib_index, 
				   struct table_ptrs *tp, 
				   struct ttf_scale_matrix  global_matrix)
{
	struct ttf_scale_matrix new_matrix, local_matrix;
	RMint16 n_contours;
	RMuint16 flags;
	RMuint16 sub_glyph_index;
	RMuint32 len, sub_table_index = 0;
	RMuint8* pos;

	get_glyph_pos(glyph_index, tp, &pos, &len);
	if(!len){
		/* this is very bad */
		return 0;
	}
	n_contours = (RMint16)RMbeBufToUint16(pos);
	pos += 10;
	if(n_contours>0){
		/* we got to a simple glyph, add the subglyph entry */
		search_glyph_lib(lib_index, glyph_index, &(subs_table->addr), &(subs_table->size));
		RMMemcpy(&(subs_table->scale_matrix), &(global_matrix), sizeof(struct ttf_scale_matrix));
		return 1;
	}
	do{
		flags = RMbeBufToUint16(pos); pos += 2;
		sub_glyph_index = RMbeBufToUint16(pos); pos += 2;
		if (flags & ARG_1_AND_2_ARE_WORDS) {
			local_matrix.x_offset = RMbeBufToUint16(pos); pos += 2;
			local_matrix.y_offset = RMbeBufToUint16(pos); pos += 2;
		} else {
			local_matrix.x_offset = *pos; pos++;
			local_matrix.y_offset = *pos; pos++;
		}
		local_matrix.xy_scale = local_matrix.yx_scale = 0;
				
		if (flags & WE_HAVE_A_SCALE) {
			local_matrix.x_scale = local_matrix.y_scale = RMbeBufToUint16(pos); pos +=2;
		} else if (flags & WE_HAVE_AN_X_AND_Y_SCALE) {
			local_matrix.x_scale = RMbeBufToUint16(pos); pos +=2;
			local_matrix.y_scale = RMbeBufToUint16(pos); pos +=2;
		} else if (flags & WE_HAVE_A_TWO_BY_TWO) {
			local_matrix.x_scale = RMbeBufToUint16(pos); pos +=2;
			local_matrix.xy_scale = RMbeBufToUint16(pos); pos +=2;
			local_matrix.yx_scale = RMbeBufToUint16(pos); pos +=2;
			local_matrix.y_scale = RMbeBufToUint16(pos); pos +=2;
		} else {
			local_matrix.x_scale = local_matrix.y_scale = 1<<14;
		}


		/*0x 1xy 2yx 3y 4ox 5oy*/

		/* combine matrices */
		
		new_matrix.x_scale  = (global_matrix.x_scale  * local_matrix.x_scale  + global_matrix.yx_scale * local_matrix.xy_scale)>>14;
		new_matrix.xy_scale = (global_matrix.x_scale  * local_matrix.yx_scale + global_matrix.yx_scale * local_matrix.y_scale)>>14;
		new_matrix.yx_scale = (global_matrix.xy_scale * local_matrix.x_scale  + global_matrix.y_scale  * local_matrix.xy_scale)>>14;
		new_matrix.y_scale  = (global_matrix.xy_scale * local_matrix.yx_scale + global_matrix.y_scale  * local_matrix.y_scale)>>14;
		new_matrix.x_offset = (global_matrix.x_scale  * local_matrix.x_offset + global_matrix.yx_scale * local_matrix.y_offset + global_matrix.x_offset)>>14;
		new_matrix.y_offset = (global_matrix.xy_scale * local_matrix.x_offset + global_matrix.y_scale  * local_matrix.y_offset + global_matrix.y_offset)>>14;

		sub_table_index += add_compound_glyph(sub_glyph_index, &(subs_table[sub_table_index]), lib_index, tp, new_matrix);

	}while(flags & MORE_COMPONENTS);
	return sub_table_index;
}

static RMstatus upload_glyphs(struct RUA *pRUA,
			      struct ttf_glyph **ppglyph_table, 
			      struct ttf_charmap *charmap,
			      struct glyph_lib_index *lib_index,
			      struct ttf_charset *char_set,
			      struct table_ptrs *tp)
{

	struct ttf_glyph *table;
	struct ttf_subglyph *subs_table;
	RMuint8 *pos;
	RMuint32 len;
	RMuint32 i, glyph_index;
	RMuint32 table_index, subs_index = 0;
	RMint16 n_contours = 0; 
	RMuint16 n_lhm;
	
	RMuint8 *lhm;
	RMuint16 n_glyphs, n_subs;
	RMuint32 table_size, sub_count;

	n_glyphs = RMbeBufToUint16(tp->maxp_table + 4/*numGlyphs_off*/);
	n_lhm = RMbeBufToUint16(tp->hhea_table + 34 /*numOfLongHorMetrics_off*/);
	lhm = tp->hmtx_table;

	lib_index->cnt = 0;
	lib_index->sub_cnt = 0;
	lib_index->size = 0;

	/* calculate the size of the whole table first, so we can malloc at once */
	sub_count = 0;
	for(i = 0; i< char_set->char_count; i++){
		glyph_index = get_glyph_index_from_charmap(charmap, char_set->unicodes[i]);
		get_glyph_size(glyph_index, lib_index, tp);
	}
	

	/* do the malloc */

	table_size  = char_set->char_count*sizeof(struct ttf_glyph);
	table_size += lib_index->sub_cnt*sizeof(struct ttf_subglyph);


	if(table_size & 0x3) table_size += 4-(table_size & 0x3);
	
	*ppglyph_table = (struct ttf_glyph *)RMMalloc(table_size);
	
	table = (*ppglyph_table);
	subs_table = (struct ttf_subglyph *)((RMuint8*)(*ppglyph_table)+ char_set->char_count*sizeof(struct ttf_glyph));

	/* create the lib */
	create_glyph_lib(pRUA, lib_index, tp);

	for(i = 0; i< char_set->char_count; i++){
		glyph_index = get_glyph_index_from_charmap(charmap, char_set->unicodes[i]);
		table_index = i;/*get_glyph_index(char_set->char_table[i].font_code);*/
		get_glyph_pos(glyph_index, tp, &pos, &len);
		
		/* get the metrics first */
		if(glyph_index < n_lhm)	{
			table[table_index].metrics.advance = RMbeBufToUint16(lhm+4*glyph_index ); 
			table[table_index].metrics.leftSideBearing = (RMint16)RMbeBufToUint16(lhm+4*glyph_index + 2);
		}
		else{	
			table[table_index].metrics.advance =  RMbeBufToUint16(lhm+4*(n_lhm-1));
			table[table_index].metrics.leftSideBearing = (RMint16)RMbeBufToUint16(lhm+2*glyph_index);
		}
		if(!len){
			table[table_index].subglyph_count = 0;
			table[table_index].addr = 0x0;
			table[table_index].size = 0x0;
			continue;
		}

		n_contours = (RMint16)RMbeBufToUint16(pos); pos +=2;
		table[table_index].metrics.xMin = (RMint16)RMbeBufToUint16(pos); pos += 2;
		table[table_index].metrics.yMin = (RMint16)RMbeBufToUint16(pos); pos += 2;
		table[table_index].metrics.xMax = (RMint16)RMbeBufToUint16(pos); pos += 2;
		table[table_index].metrics.yMax = (RMint16)RMbeBufToUint16(pos); pos += 2;

		
		if(n_contours > 0){ 
			/* just link to the correct position on the glyph lib */
			search_glyph_lib(lib_index, glyph_index, &(table[table_index].addr), &(table[table_index].size));
			table[table_index].subglyph_count = 1;
		}
		else{
			struct ttf_scale_matrix id_matrix = {1<<14, 1<<14, 0,0,0,0};
			n_subs = add_compound_glyph(glyph_index, &(subs_table[subs_index]), lib_index, tp, id_matrix);
			table[table_index].subglyph_count = n_subs;
			table[table_index].addr = (RMuint32)&(subs_table[subs_index]);
			table[table_index].size = 0; /* this makes this glyph a compound glyph */
			subs_index += n_subs;
		}
	}

	return RM_OK;
}



static RMstatus upload_charmap(struct ttf_charmap *charmap, struct table_ptrs *tp)
{
	RMuint16             num_tables;
	RMuint32             i, offset = 0;
	RMuint16             platform, encoding_id;
	RMuint8              *table_head;

	table_head = tp->cmap_table; 
	table_head += 2; /* skip version (2) */
	num_tables = RMbeBufToUint16(table_head); table_head += 2;
	for (i = 0; i < num_tables; i++) {
		platform    = RMbeBufToUint16(table_head); table_head += 2;
		encoding_id = RMbeBufToUint16(table_head); table_head += 2;
		offset      = RMbeBufToUint32(table_head); table_head += 4;

		if ( (platform == 3) && (encoding_id == 1)) {
			RMuint8  *cmap_fmt4;
			RMuint16 format, length;
			RMint32 j;
			cmap_fmt4 = tp->cmap_table + offset;
			format              = RMbeBufToUint16(cmap_fmt4); cmap_fmt4 += 2;
			length              = RMbeBufToUint16(cmap_fmt4); cmap_fmt4 += 4; /* skip version (2) */
			charmap->segCountX2 = RMbeBufToUint16(cmap_fmt4); cmap_fmt4 += 8;  /* skip searchRange(2), entrySelector(2), rangeShift(2) */

			if( format != 4){
				RMDBGLOG((ENABLE,"Wrong CMAP subtable format\n"));
				return RM_ERROR;
			}
			
			charmap->ttf_cmap = (RMuint16*)RMMalloc(length - 14);
			for(j=0; j < (length - 14)/2; j++){
				charmap->ttf_cmap[j] = RMbeBufToUint16(cmap_fmt4); cmap_fmt4 += 2;
			}
			return RM_OK;
		} 
	}
	return RM_ERROR;
}


static RMstatus open_ttf_file(struct RUA *pRUA, struct RMTTFont *rmfont, RMnonAscii *fname, struct ttf_charset *charset )
{
	RMfile ttf_file;

	struct ttf_charmap charmap;
	struct glyph_lib_index lib_index;

	RMuint32 i, j;
	RMint64 file_size; 
	RMuint32 read_size;
	RMstatus err;
	RMuint8 *file_buf, *file_buf_base;

	RMuint8 *directory;
	RMuint16 num_tables;
	RMuint32 fnt_version;
	struct table_ptrs tp; 



	
	struct{
		RMuint8 **pptb; /* pointer to pointer to the table */
		RMascii name[5]; /* table name */
	} table_dico[] = {
		{ (RMuint8 **)&(tp.head_table), "head" },
		{ (RMuint8 **)&(tp.hhea_table), "hhea" },
		{ (RMuint8 **)&(tp.glyf_start), "glyf" },
		{ (RMuint8 **)&(tp.cmap_table), "cmap" },
		{ (RMuint8 **)&(tp.maxp_table), "maxp" },
		{ (RMuint8 **)&(tp.hmtx_table), "hmtx" },
		{ (RMuint8 **)&(tp.loca_table), "loca" },
		{ NULL, "" } /* end of table */
	};



	err = RMSizeOfFile(fname, &file_size);
	if(RMFAILED(err)){
		RMDBGLOG((ENABLE, "Error getting file size of %s\n", fname ));
		return RM_ERROR;
	}
	if ((file_buf_base = RMMalloc(file_size)) == NULL) {
		RMDBGLOG((ENABLE, "Could not allocate 0x%08lx bytes for truetype font buffer\n" ));
		return RM_ERROR;
	}
	    
	if ((ttf_file = RMOpenFile(fname, RM_FILE_OPEN_READ)) == (RMfile)NULL) {
		RMDBGLOG((ENABLE, "Could not open file %s\n", fname ));
		return RM_ERROR;
	} 
	
	err = RMReadFile (ttf_file, file_buf_base, file_size, &read_size );
	if(RMFAILED(err)){
		RMDBGLOG((ENABLE, "Could not read truetype font file %s\n", fname ));
		return RM_ERROR;
	} 
	err = RMCloseFile(ttf_file);
	if(RMFAILED(err)){
		RMDBGLOG((ENABLE, "Could not close file %s\n", fname ));
		return RM_ERROR;
	} 

	file_buf = file_buf_base;


	directory =  file_buf;
	fnt_version = RMbeBufToUint32(directory); directory += 4;
	num_tables  = RMbeBufToUint16(directory); directory += 8; /*skip searchRange(2), entrySelector(2), rangeShift(2)*/
	if (fnt_version != 0x00010000) {
		RMDBGLOG((ENABLE,"Could not store truetype charmap on memory (read 0x%08lx)\n",fnt_version ));
		return RM_ERROR;
	}

	for(j=0; table_dico[j].pptb != NULL; j++)
		*(table_dico[j].pptb) = NULL;


	for (i = 0; i < num_tables; i++) {
		RMuint8* tag;
		RMuint32 offset;
		tag = directory; directory += 8; /*skip checksum (4) */
		offset = RMbeBufToUint32(directory); directory += 8; /*skip length (4)*/
		
		for(j=0; table_dico[j].pptb != NULL; j++){
			if (RMMemcmp(tag, table_dico[j].name, 4) == 0) {
				*(table_dico[j].pptb) = file_buf + offset;
			}
		}
	}
	
	for(j=0; table_dico[j].pptb != NULL; j++)
		if( (*(table_dico[j].pptb)) == NULL) {
			RMDBGLOG((ENABLE, "Font is missing the '%s' table\n", table_dico[j].name)) ;
			return RM_ERROR;
			
		}
	
	//init the structure;

 	rmfont->metrics.unitsPerEm = RMbeBufToUint16(tp.head_table + 18); 
	rmfont->metrics.ascender = (RMint16)RMbeBufToUint16(tp.hhea_table + 4); 
	rmfont->metrics.descender = (RMint16)RMbeBufToUint16(tp.hhea_table + 6); 


	err = upload_charmap(&charmap, &tp);
	if(RMFAILED(err)) {
		RMDBGLOG((ENABLE,"Could not store truetype charmap on memory\n"));
		return RM_ERROR;
	}

	err = upload_glyphs(pRUA, &(rmfont->glyph_table), &charmap, &lib_index, charset, &tp);
	if(RMFAILED(err)) {
		RMDBGLOG((ENABLE,"Could not store truetype glyphs on memory\n"));
		return RM_ERROR;
	}
	rmfont->lib_base_addr = lib_index.tab[0].addr;

	RMFree(file_buf_base);
	RMFree(charmap.ttf_cmap);


	return RM_OK;
}

#ifdef WITH_RMG		
static RMstatus open_rmg_file(struct RMTTFont *rmfont, RMascii *fname )
{

	RMuint64 file_size; 
	RMfile rmg_file;
	RMuint32 read_size;
	RMuint32 glyph_lib_size, sub_cnt, table_size;
	RMuint8 *file_buf, *file_buf_base;
	RMuint32 glyph_off; 
	RMuint8 *lib, *table_end;
	RMuint32 i;
	RMuint32 tag;
	RMstatus err;
	struct ttf_subglyph *subs_table;

	err = RMSizeOfFile(fname, &file_size);
	if(RMFAILED(err)){
		RMDBGLOG((ENABLE, "Error getting file size of %s\n", fname ));
		return RM_ERROR;
	}
	if ((file_buf_base = RMMalloc(file_size)) == NULL) {
		RMDBGLOG((ENABLE, "Could not allocate 0x%08lx bytes for truetype font buffer\n" ));
		return RM_ERROR;
	}
	    
	if ((rmg_file = RMOpenFile(fname, RM_FILE_OPEN_READ)) == (RMfile)NULL) {
		RMDBGLOG((ENABLE, "Could not open file %s\n", fname ));
		return RM_ERROR;
	} 
	
	err = RMReadFile (rmg_file, file_buf_base, file_size, &read_size );
	if(RMFAILED(err)){
		RMDBGLOG((ENABLE, "Could not read truetype font file %s\n", fname ));
		return RM_ERROR;
	} 
	err = RMCloseFile(rmg_file);
	if(RMFAILED(err)){
		RMDBGLOG((ENABLE, "Could not close file %s\n", fname ));
		return RM_ERROR;
	} 


	/* read magic number 0x524d4746 */
	file_buf = file_buf_base;
	tag = RMbeBufToUint32(file_buf); file_buf += 4; /*RMGF*/
	if(tag!= 0x524d4746 ){
		RMDBGLOG((ENABLE, "Not a valid RMG file\n"));
		return RM_ERROR;
	} 


	/* read metrics */
	tag = RMbeBufToUint32(file_buf); file_buf += 4; /*METR*/
	if(tag!= 0x4d455452){
		RMDBGLOG((ENABLE, "Not a valid RMG file\n"));
		return RM_ERROR;
	} 
	
	/* 	rmfont->metrics.xMin=	        RMbeBufToUint16(file_buf); file_buf += 2; */
	/* 	rmfont->metrics.yMin=	        RMbeBufToUint16(file_buf); file_buf += 2; */
	/* 	rmfont->metrics.xMax=	        RMbeBufToUint16(file_buf); file_buf += 2; */
	/* 	rmfont->metrics.yMax=	        RMbeBufToUint16(file_buf); file_buf += 2; */
	rmfont->metrics.ascender= 	RMbeBufToUint16(file_buf); file_buf += 2;
	rmfont->metrics.descender=	RMbeBufToUint16(file_buf); file_buf += 2;
	rmfont->metrics.unitsPerEm=	RMbeBufToUint16(file_buf); file_buf += 2;
	
	
	/* read glyph table */
	tag = RMbeBufToUint32(file_buf); file_buf += 4; /*GTAB*/
	if(tag!= 0x47544142 ){
		RMDBGLOG((ENABLE, "Not a valid RMG file\n"));
		return RM_ERROR;
	} 
	sub_cnt = RMbeBufToUint32(file_buf); file_buf += 4; 
	glyph_lib_size = RMbeBufToUint32(file_buf); file_buf += 4; 


	table_size  = LAT1_CHAR_NO*sizeof(struct ttf_glyph);
	table_size += sub_cnt*sizeof(struct ttf_subglyph);
	table_size += glyph_lib_size;


	rmfont->glyph_table =(struct ttf_glyph *) RMMalloc(table_size);

	table_end = (RMuint8*)rmfont->glyph_table + LAT1_CHAR_NO*sizeof(struct ttf_glyph);
	lib = (RMuint8*)rmfont->glyph_table + LAT1_CHAR_NO*sizeof(struct ttf_glyph) + sub_cnt*sizeof(struct ttf_subglyph);


		
	subs_table = (struct ttf_subglyph*)table_end;
	for (i=0; i<LAT1_CHAR_NO; i++){
 		rmfont->glyph_table[i].subglyph_count = RMbeBufToUint32(file_buf); file_buf += 4;

		if(rmfont->glyph_table[i].subglyph_count == 0){
			rmfont->glyph_table[i].addr = 0;
			rmfont->glyph_table[i].size = 0;
		}
		else if(rmfont->glyph_table[i].subglyph_count == 1){
			glyph_off =  RMbeBufToUint32(file_buf);file_buf += 4;
			rmfont->glyph_table[i].addr = lib + glyph_off;
			rmfont->glyph_table[i].size = RMbeBufToUint32(file_buf);file_buf += 4;
		}
		else{
			glyph_off =  RMbeBufToUint32(file_buf);file_buf += 4;
			rmfont->glyph_table[i].addr = (RMuint32)&(subs_table[glyph_off]);
			rmfont->glyph_table[i].size = 0;
		}
		rmfont->glyph_table[i].metrics.xMin =		RMbeBufToUint16(file_buf);file_buf += 2;
		rmfont->glyph_table[i].metrics.yMin =		RMbeBufToUint16(file_buf);file_buf += 2;
		rmfont->glyph_table[i].metrics.xMax =		RMbeBufToUint16(file_buf);file_buf += 2;
		rmfont->glyph_table[i].metrics.yMax =		RMbeBufToUint16(file_buf);file_buf += 2;
		rmfont->glyph_table[i].metrics.advance =		RMbeBufToUint16(file_buf);file_buf += 2;
		rmfont->glyph_table[i].metrics.leftSideBearing =	RMbeBufToUint16(file_buf);file_buf += 2;

	}
	RMDBGLOG((ENABLE, "done with glyph table\n"));
	/* read the subs table */
	tag = RMbeBufToUint32(file_buf); file_buf += 4; /*STAB*/
	if(tag!= 0x53544142){
		RMDBGLOG((ENABLE, "Not a valid RMG file\n"));
		return RM_ERROR;
	} 
	for (i=0; i<sub_cnt; i++){
		glyph_off = RMbeBufToUint32(file_buf);file_buf += 4;
		subs_table[i].addr = lib + glyph_off;
		subs_table[i].size = RMbeBufToUint32(file_buf);file_buf += 4;
		subs_table[i].scale_matrix.x_scale  = RMbeBufToUint16(file_buf);file_buf += 2;
		subs_table[i].scale_matrix.y_scale  = RMbeBufToUint16(file_buf);file_buf += 2;
		subs_table[i].scale_matrix.xy_scale = RMbeBufToUint16(file_buf);file_buf += 2;
		subs_table[i].scale_matrix.yx_scale = RMbeBufToUint16(file_buf);file_buf += 2;
		subs_table[i].scale_matrix.x_offset = RMbeBufToUint16(file_buf);file_buf += 2;
		subs_table[i].scale_matrix.y_offset = RMbeBufToUint16(file_buf);file_buf += 2;
	}

	/* read the glyph library */
	tag = RMbeBufToUint32(file_buf); file_buf += 4; /*GLIB*/
	if(tag!= 0x474c4942){
		RMDBGLOG((ENABLE, "Not a valid RMG file\n"));
		return RM_ERROR;
	} 
	RMMemcpy(lib, file_buf, glyph_lib_size);

	RMFree(file_buf_base);

	return RM_OK;

}
#endif

static void set_max_advance(struct RMTTFont *rmfont)
{
	RMuint32 i;
	RMint32 max_advance = 0;
	for (i = 0; i < LAT1_CHAR_NO; i++){
		if (max_advance < rmfont->glyph_table[i].metrics.advance)
			max_advance = rmfont->glyph_table[i].metrics.advance;
	}
	rmfont->metrics.max_advance = max_advance;
}




RMstatus RMTTOpenFont(struct RUA *pRUA, struct RMTTFont **rmfont, RMnonAscii *fname, struct ttf_charset *charset)
{
	RMnonAscii *file_ext;
	RMstatus err;
	if (RMnonAsciiLength(fname)>5)
		file_ext = fname + RMnonAsciiLength(fname) - 5;
	else{
		RMDBGLOG((ENABLE, "Font should be a truetype font (.ttf, .TTF) or a RealMagic Glyph Font (.rmg, .RMG)\n"));
		return RM_ERROR;
	}

	*rmfont = RMMalloc(sizeof(struct RMTTFont));
	if(rmfont == NULL){
		RMDBGLOG((ENABLE, "Could not allocate struct RMTTFont (%ld bytes)\n", sizeof(struct RMTTFont)));
		return RM_FATALOUTOFMEMORY;
	}
	
	if( !(RMMemcmp( file_ext, ".ttf", 4))  ||  !(RMMemcmp( file_ext, ".TTF", 4))){
		err = open_ttf_file(pRUA, *rmfont, fname, charset);
		if (RMFAILED(err)) goto cleanup;
	}
#ifdef WITH_RMG
	else if( !(RMMemcmp( file_ext, ".rmg", 4))  ||  !(RMMemcmp( file_ext, ".RMG", 4))){
		err = open_rmg_file(*rmfont, fname);
		if (RMFAILED(err)) goto cleanup;

	}
#endif

	else{
		RMDBGLOG((ENABLE, "Font should be a truetype font (.ttf, .TTF) or a RealMagic Glyph Font (.rmg, .RMG)\n"));
		err = RM_ERROR;
		goto cleanup;
	}

	set_max_advance(*rmfont);

	return RM_OK;

 cleanup:
	RMFree(*rmfont);
	*rmfont = NULL;
	return err;
		

}



RMstatus RMTTCloseFont(struct RUA *pRUA,  struct RMTTFont *rmfont)
{
	RMFree(rmfont->glyph_table);
	rmfont->glyph_table = NULL;
	RUAFree(pRUA, rmfont->lib_base_addr);
	RMFree(rmfont);
	return RM_OK;
}



RMuint32 RMTTGetCompoundCount(struct RMTTFont *rmfont, RMuint32 char_code)
{
	RMuint32 glyph_index;
	glyph_index = char_code;/* get_glyph_index(char_code); */
	if (glyph_index == INVALID_GLYPH) 
		return 0; /* lets not fool the calling app */
	return rmfont->glyph_table[glyph_index].subglyph_count;
}

RMstatus RMTTGetGlyphPointer(struct RMTTFont *rmfont, RMuint32 char_code, RMuint32 index, RMuint32 *addr, RMuint32 *size)
{
	RMuint32 glyph_index;
	struct ttf_subglyph *sub_table;

	glyph_index = char_code;/* get_glyph_index(char_code); */
	if (glyph_index == INVALID_GLYPH) return RM_INVALID_PARAMETER; 
	if (index >=rmfont->glyph_table[glyph_index].subglyph_count ) return RM_INVALID_PARAMETER;

	if(rmfont->glyph_table[glyph_index].subglyph_count == 0) { 
		*size = 0;
		*addr = 0;
	}
	else if(rmfont->glyph_table[glyph_index].size) { 
		*size = rmfont->glyph_table[glyph_index].size; 
		*addr = rmfont->glyph_table[glyph_index].addr;
	}
	else{
		sub_table = (struct ttf_subglyph *)(rmfont->glyph_table[glyph_index].addr);
		*size = sub_table[index].size;
		*addr = sub_table[index].addr;
	}
 
	return RM_OK;
}


struct ttf_scale_matrix *RMTTGetScaleMatrix(struct RMTTFont *rmfont, RMuint32 char_code, RMuint32 index)
{
	RMuint32 glyph_index;
	struct ttf_subglyph *sub_table;
	glyph_index = char_code;/*  get_glyph_index(char_code); */
	if (glyph_index == INVALID_GLYPH) return NULL;
	if (index >=rmfont->glyph_table[glyph_index].subglyph_count ) return NULL;
	if (rmfont->glyph_table[glyph_index].size > 0) return NULL; /* means a simple glyph */
	sub_table = (struct ttf_subglyph *)(rmfont->glyph_table[glyph_index].addr);
	return &(sub_table[index].scale_matrix);
}


struct ttf_glyph_metrics *RMTTGetGlyphMetrics(struct RMTTFont *rmfont, RMuint32 char_code)
{
	RMuint32 glyph_index;
	glyph_index = char_code;/* get_glyph_index(char_code); */
	if (glyph_index == INVALID_GLYPH) return NULL;
	return &(rmfont->glyph_table[glyph_index].metrics);
}


#if 0
RMstatus RMTTSetupCharset(struct ttf_charset *charset, enum ttf_charset_type type)
{
	RMuint32 uni_code;
	charset->char_count = 0;
	if( type == ASCII_charset || type == LATIN1_charset || type == DTVCC_charset){
		for(uni_code = 0x20; uni_code < 0x7f; uni_code++)
			ADD_CHARSET_PAIR( charset, uni_code, uni_code);
	}
	if( type == LATIN1_charset || type == DTVCC_charset){
		for(uni_code = 0xa0; uni_code < 0x100; uni_code++)
			ADD_CHARSET_PAIR( charset, uni_code, uni_code);
	}

	if( type == DTVCC_charset){
		ADD_CHARSET_PAIR( charset, 8216, 0x91);
		ADD_CHARSET_PAIR( charset, 8217, 0x92);
		ADD_CHARSET_PAIR( charset, 8220, 0x93);
		ADD_CHARSET_PAIR( charset, 8221, 0x94);
		ADD_CHARSET_PAIR( charset, 8230, 0x85);
		ADD_CHARSET_PAIR( charset, 8226, 0x95);
		ADD_CHARSET_PAIR( charset, 8482, 0x99);
		ADD_CHARSET_PAIR( charset, 352 , 0x8a);
		ADD_CHARSET_PAIR( charset, 353 , 0x9a);
		ADD_CHARSET_PAIR( charset, 338 , 0x8c);
		ADD_CHARSET_PAIR( charset, 339 , 0x9c);
		ADD_CHARSET_PAIR( charset, 8480, 0x9d);
		ADD_CHARSET_PAIR( charset, 376 , 0x9f);
		ADD_CHARSET_PAIR( charset, 8216, 0x91);
	}
	return RM_OK;
}

RMstatus RMTTHackedSetupCharset(struct ttf_charset *charset, enum ttf_charset_type type)
{
	RMuint32 uni_code;
	charset->char_count = 0;
	for(uni_code = 0; uni_code < 256; uni_code++){
		if(((uni_code >= 0x20) && (uni_code < 0x7f)) || (uni_code == 0xf1))
			ADD_CHARSET_PAIR( charset, uni_code, uni_code);
		else
			ADD_CHARSET_PAIR( charset, 0, uni_code);
	}
	
	return RM_OK;
}
#endif
