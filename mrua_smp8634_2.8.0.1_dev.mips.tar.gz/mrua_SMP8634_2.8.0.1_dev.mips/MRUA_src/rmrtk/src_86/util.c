#include "rmrtk86.h"
#include "../../rmlibcw/include/rmlibcw.h"

#if 1
#define RTK86DBG ENABLE
#else
#define RTK86DBG DISABLE
#endif

#define TIMEOUT_US 10000



static RMstatus rtk86_load_ps_font(RMTrtk rtk, RMnonAscii *fname)
{
	RMuint8 header_buf[32];
	RMfile psf_file;
	RMuint32 read_size;
	RMuint32 header_size = 32;
	RMuint8 *mapped_lib;
	RMstatus err;
	RMuint32 lib_size;

	if ((psf_file = RMOpenFile(fname, RM_FILE_OPEN_READ)) == (RMfile)NULL) {
		RMDBGLOG((ENABLE, "Could not open file %s\n", fname ));
		return RM_ERROR;
	} 
	
	err = RMReadFile (psf_file, header_buf, header_size, &read_size);
	if(RMFAILED(err)){
		RMDBGLOG((ENABLE, "Could not read psf font file %s\n", fname ));
		return RM_ERROR;
	} 

	/* psf1 type font */
	if ((header_buf[0] == 0x36) && (header_buf[1] == 0x04)) {
		rtk->psfont.flags = header_buf[2];
		rtk->psfont.height = header_buf[3];
		rtk->psfont.width = 8;
		if (rtk->psfont.flags & 0x01)
			rtk->psfont.numchars = 512;
		else
			rtk->psfont.numchars = 256;
		rtk->psfont.size = rtk->psfont.height;
		header_size = 4;
	}
	/* psf2 type font */
	else if ((header_buf[0] == 0x72) && (header_buf[1] == 0xb5) && (header_buf[2] == 0x4a) && (header_buf[3] = 0x86)){
		rtk->psfont.version    = RMleBufToUint32(header_buf + 4);
		header_size            = RMleBufToUint32(header_buf + 8);
		rtk->psfont.flags      = RMleBufToUint32(header_buf + 12);
		rtk->psfont.numchars   = RMleBufToUint32(header_buf + 16);
		rtk->psfont.size       = RMleBufToUint32(header_buf + 20);
		rtk->psfont.height     = RMleBufToUint32(header_buf + 24);
		rtk->psfont.width      = RMleBufToUint32(header_buf + 28);
	}

	lib_size = rtk->psfont.numchars*rtk->psfont.size;

	err = RMSeekFile(psf_file, header_size, RM_FILE_SEEK_START);
	if(RMFAILED(err)){
		RMDBGLOG((ENABLE, "Error seeking file\n"));
		return RM_ERROR;
	}

	rtk->psfont.lib_addr = RUAMalloc(rtk->pRUA, 0, RUA_DRAM_UNCACHED, lib_size);
	if(rtk->psfont.lib_addr == 0){
		RMDBGLOG((ENABLE, "Error allocating font buffer \n"));
		return RM_ERROR;
	}

	err = RUALock(rtk->pRUA, rtk->psfont.lib_addr, lib_size);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error locking font buffer \n"));
		return err;
	}
	
	mapped_lib = RUAMap(rtk->pRUA, rtk->psfont.lib_addr, lib_size);
	if (mapped_lib == NULL) {
		RMDBGLOG((ENABLE, "Error mapping font buffer\n"));
		return RM_ERROR;
	}

	err = RMReadFile (psf_file, mapped_lib, lib_size, &read_size);
	if(RMFAILED(err)){
		RMDBGLOG((ENABLE, "Could not read psf font file %s\n", fname ));
		return RM_ERROR;
	} 

	RUAUnMap(rtk->pRUA, mapped_lib, lib_size);
	err = RUAUnLock(rtk->pRUA, rtk->psfont.lib_addr, lib_size);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error locking OSD buffer\n"));
		return err;
	}

	err = RMCloseFile(psf_file);
	if(RMFAILED(err)){
		RMDBGLOG((ENABLE, "Could not close file %s\n", fname ));
		return RM_ERROR;
	} 

	return RM_OK;
}


static RMstatus rtk86_unload_ps_font(RMTrtk rtk)
{
	if(rtk->psfont.lib_addr)
		RUAFree(rtk->pRUA, rtk->psfont.lib_addr);
	return RM_OK;
}


static void rtk86_fill_charset(struct ttf_charset *charset, enum rtk_charset_type type)
{
	RMuint32 index, last_used = 0;
	for(index = 0; index<256; index++){
		switch(type){
		case rtk_charset_type_DTVCC:
		case rtk_charset_type_LATIN1:
			if((index >= 0xa0) && (index < 0x100)){
				charset->unicodes[index] = index;
				last_used = index;
				break;
			}
			/* no break */
		case rtk_charset_type_ASCII:
			if((index >= 0x20) && (index < 0x7f)){
				charset->unicodes[index] = index;
				last_used = index;
			}
			else{
				charset->unicodes[index] = 0;
			}
			break;
		}
	}
	charset->char_count = last_used;
/* 	if( type == DTVCC_charset){ */
/* 		ADD_CHARSET_PAIR( charset, 8216, 0x91); */
/* 		ADD_CHARSET_PAIR( charset, 8217, 0x92); */
/* 		ADD_CHARSET_PAIR( charset, 8220, 0x93); */
/* 		ADD_CHARSET_PAIR( charset, 8221, 0x94); */
/* 		ADD_CHARSET_PAIR( charset, 8230, 0x85); */
/* 		ADD_CHARSET_PAIR( charset, 8226, 0x95); */
/* 		ADD_CHARSET_PAIR( charset, 8482, 0x99); */
/* 		ADD_CHARSET_PAIR( charset, 352 , 0x8a); */
/* 		ADD_CHARSET_PAIR( charset, 353 , 0x9a); */
/* 		ADD_CHARSET_PAIR( charset, 338 , 0x8c); */
/* 		ADD_CHARSET_PAIR( charset, 339 , 0x9c); */
/* 		ADD_CHARSET_PAIR( charset, 8480, 0x9d); */
/* 		ADD_CHARSET_PAIR( charset, 376 , 0x9f); */
/* 		ADD_CHARSET_PAIR( charset, 8216, 0x91); */
/* 	} */
/* 	return RM_OK; */
};


RMstatus rtk86_load_font(RMTrtk rtk, RMnonAscii *fname)
{
	RMstatus err;
	RMuint32 charset_unicodes[256];
	struct ttf_charset charset;
	RMnonAscii *file_ext;
	
	rtk->font_type = rtk_font_type_None;

	if (RMnonAsciiLength(fname)>5)
		file_ext = fname + RMnonAsciiLength(fname) - 5;
	else{
		RMDBGLOG((ENABLE, "Font should be a truetype font (.ttf, .TTF) or a PC Screen font (.psf, .PSF)\n"));
		return RM_ERROR;
	}
	
	if( !(RMMemcmp( file_ext, ".ttf", 4))  ||  !(RMMemcmp( file_ext, ".TTF", 4))){
		rtk->font_type = rtk_font_type_TT;
	}
	else if( !(RMMemcmp( file_ext, ".psf", 4))  ||  !(RMMemcmp( file_ext, ".PSF", 4))){
		rtk->font_type = rtk_font_type_PS;
	}
	else{
		RMDBGLOG((ENABLE, "Font should be a truetype font (.ttf, .TTF) or a PC Screen font (.psf, .PSF)\n"));
		return RM_ERROR;
	}


	switch(rtk->font_type){
	case rtk_font_type_None:
		return RM_ERROR;
	case rtk_font_type_TT:
		charset.unicodes = charset_unicodes;
		rtk86_fill_charset(&charset, rtk_charset_type_LATIN1);
		err = RMTTOpenFont(rtk->pRUA, &(rtk->ttfont), fname, &charset);
		if (RMFAILED(err)){
			RMDBGLOG((ENABLE, "Error while loading TT font\n"));
			rtk->font_type = rtk_font_type_None;
			return err;
		}
		break;
	case rtk_font_type_PS:
		err = rtk86_load_ps_font(rtk, fname);
		if (RMFAILED(err)){
			RMDBGLOG((ENABLE, "Error while loading PS font\n"));

			rtk->font_type = rtk_font_type_None;
			return err;
		}
		break;
	}
	return RM_OK;
}

RMstatus rtk86_unload_font(RMTrtk rtk){
	switch(rtk->font_type){
	case rtk_font_type_None:
		return RM_ERROR;
	case rtk_font_type_TT:
		if(rtk->ttfont != NULL){
			RMTTCloseFont(rtk->pRUA, rtk->ttfont);
		}
		break;
	case rtk_font_type_PS:
		return rtk86_unload_ps_font(rtk);
	}
	return RM_OK;
}


RMstatus rtk86_draw_char(RMTrtk rtk, RMuint32 char_index, RMuint32 char_size, RMuint32 fg_color, RMuint32 bg_color, RtkPoint *point, RtkRect *out_rect)
{
	switch(rtk->font_type){
	case rtk_font_type_None:
		return RM_ERROR;
	case rtk_font_type_TT:
		return rtk86_draw_tt_char(rtk, char_index, char_size, fg_color, bg_color, point, out_rect);
	case rtk_font_type_PS:
		return rtk86_draw_ps_char(rtk, char_index, char_size, fg_color, bg_color, point, out_rect);
	}
	return RM_ERROR;

}



RMuint32 rtk86_get_color_depth(RMTrtk rtk)
{
	RMuint32  bits_per_pixel = 0;
       	switch (rtk->color_mode){
	case EMhwlibColorMode_TrueColor:
	case EMhwlibColorMode_TrueColorWithKey:
		switch (rtk->color_format) {
		case EMhwlibColorFormat_24BPP_565:
		case EMhwlibColorFormat_24BPP:
			bits_per_pixel = 24;
			break;
			
		case EMhwlibColorFormat_32BPP_4444:
		case EMhwlibColorFormat_32BPP:
			bits_per_pixel = 32;
			break;
			
		case EMhwlibColorFormat_16BPP_565:
		case EMhwlibColorFormat_16BPP_1555:
		case EMhwlibColorFormat_16BPP_4444:
			bits_per_pixel = 16;
			break;
		}
		break;
	case EMhwlibColorMode_LUT_1BPP:
		bits_per_pixel = 1;
		break;
	case EMhwlibColorMode_LUT_2BPP:	
		bits_per_pixel = 2;
		break;
	case EMhwlibColorMode_LUT_4BPP:
		bits_per_pixel = 4;
		break;
	case EMhwlibColorMode_LUT_8BPP:
		bits_per_pixel = 8;
		break;
	default:
		break;
	}
	return bits_per_pixel;
};


RMuint32 rtk86_get_pixel_address(RMTrtk rtk, RtkPoint *point)
{
	RMuint32 addr;
	addr  = point->y;
	addr *= rtk->osd_width;
	addr += point->x;
	addr *= rtk86_get_color_depth(rtk);
	addr /= 8;
	addr += rtk->osd; 
	return addr;
};
