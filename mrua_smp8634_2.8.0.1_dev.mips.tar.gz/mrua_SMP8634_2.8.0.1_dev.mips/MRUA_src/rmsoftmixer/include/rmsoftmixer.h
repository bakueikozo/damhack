/*****************************************
 Copyright © 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   rmsoftmixer.h
  @brief  

  rmsoftmixer api

  @author Oriol Prieto Gasco
  @date   2005-07-18
*/

#ifndef __RMSOFTMIXER_H__
#define __RMSOFTMIXER_H__
#include "../../rmdef/rmdef.h"
#include "../../dcc/include/dcc.h"


struct rmsmx_config{
	struct DCC *pDCC;
	struct RUA *pRUA;
	struct DCCOSDProfile canvas_profile;
	RMuint32 canvas_color;
	RMuint32 canvas_scaler;
};

struct rmsmx_source{
	RMuint32 decoder_id;
	RMuint32 stc_id;
};

struct rmsmx_window{
	RMuint32 x;
	RMuint32 y;
	RMuint32 width;
	RMuint32 height;
	RMuint32 border_width;
	RMuint32 border_color;
};

struct rmsmx_slot_status{
	RMuint64 displayed_pts;
	RMbool starved;
};

typedef struct _RMsmx *RMsmx;

RMsmx RMSMXOpen(struct rmsmx_config *config);

RMstatus RMSMXClose(RMsmx smx);

RMstatus RMSMXSetInputSource(RMsmx smx, struct rmsmx_source *source, RMuint32 slot);

RMstatus RMSMXSetOutputWindow(RMsmx smx, struct rmsmx_window *window, RMuint32 slot);

RMstatus RMSMXSetCanvasColor(RMsmx smx, RMuint32 canvas_color);

/* RMstatus RMSMXGetOutputWindow(RMsmx smx, struct rmsmx_window *window, RMuint32 slot); */

RMstatus RMSMXRefresh(RMsmx smx);

RMstatus RMSMXFlushSlot(RMsmx smx, RMuint32 slot); //, enum EMhwlibFlushMode flush_mode);

RMstatus RMSMXGetSlotStatus(RMsmx smx, struct rmsmx_slot_status *status, RMuint32 slot);






#endif // __RMSOFTMIXER_H__
