/*****************************************
 Copyright © 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
*****************************************/

#include "../include/rmsoftmixer.h"


#if 0
#define RMSMXDBG ENABLE
#else
#define RMSMXDBG DISABLE
#endif

#define MAX_SLOTS 16

#define TIMEOUT_US 1000

#define SMX_BUFFER_COUNT 3

#define SEND_GFX_COMMAND(smx_handle, propertyID, value)								\
{															\
	RMstatus err;													\
	RMuint32 n;													\
	n = 5;														\
	do{														\
		err = RUASetProperty(smx_handle->pRUA, smx_handle->gfx_id, propertyID, &value, sizeof(value), 0);	\
		if ((err == RM_PENDING)) {										\
 			struct RUAEvent evt;										\
			evt.ModuleID = smx_handle->gfx_id;								\
			evt.Mask = RUAEVENT_COMMANDCOMPLETION;								\
		RMDBGLOG((ENABLE, "Can't send command to command fifo\n" ));						\
			while (RUAWaitForMultipleEvents(smx_handle->pRUA, &evt, 1, TIMEOUT_US, NULL) != RM_OK);		\
                }													\
                n--;													\
	}while((n>0) && (err == RM_PENDING));										\
															\
	if (err != RM_OK) {												\
		RMDBGLOG((ENABLE, "Can't send command to command fifo\n" ));						\
		return err;												\
	}														\
															\
}

struct smx_slot{
	RMbool active;
	RMuint32 decoder;
	RMuint32 stc;
	RMuint32 tir;
	RMuint32 draw_border;
	struct VideoDecoder_NextPicture_type new_pic;
	struct VideoDecoder_NextPicture_type current_pic;
	struct rmsmx_window current_window;
	RMbool starved;
};
	
struct _RMsmx{
	struct DCC *pDCC;
	struct RUA *pRUA;
	RMuint32 canvas_buffer[SMX_BUFFER_COUNT]; /*address to canvas buffers */
	RMuint32 canvas_picture[SMX_BUFFER_COUNT]; /*address to pictures, needed for gfx engine sync */
	RMuint32 canvas_index;
	RMuint32 canvas_surface;
	RMuint32 canvas_color;
	RMuint32 canvas_width;
	RMuint32 canvas_height;
	RMuint32 canvas_dirty;
	struct DCCVideoSource *canvas_source;
	RMuint32 gfx_id;
	RMuint32 gfx_cached_buf;
	RMuint32 gfx_uncached_buf;
	struct smx_slot slots[MAX_SLOTS];
};

static inline RMstatus smx_set_picture(RMsmx smx, struct EMhwlibNewPicture *pic, RMuint32 slot);
static inline RMstatus smx_open_gfx(RMsmx smx, 	struct DCCOSDProfile *canvas_profile);
static RMstatus smx_clear_buffers(RMsmx smx);

static RMstatus smx_disconnect(RMsmx smx, RMuint32 slot)
{
	RMstatus err;

	if(smx->slots[slot].active){
		if(smx->slots[slot].current_pic.PictureAddress){
			err = RUASetProperty(smx->pRUA, smx->slots[slot].decoder, RMVideoDecoderPropertyID_ReleasePicture,
					     &(smx->slots[slot].current_pic.PictureAddress),
					     sizeof(smx->slots[slot].current_pic.PictureAddress), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot release picture\n"));
			}
			
			smx->slots[slot].current_pic.PictureAddress = 0; 
		}
		
		err = RMSMXFlushSlot(smx, slot);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot flush slot %d\n", slot));
			return err;
		}
		smx->slots[slot].active = FALSE;
		
		err = RUASetProperty(smx->pRUA, smx->slots[slot].decoder, RMVideoDecoderPropertyID_DisconnectReader, NULL, 0, 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot disconnect reader %\n", err));
			return err;
		}
	}
	return RM_OK;
}

RM_EXTERN_C RMsmx RMSMXOpen(struct rmsmx_config *config)
{
	RMsmx smx;
	struct EMhwlibDisplayWindow window;
	enum EMhwlibMixerSourceState state;
 

	RMstatus err;
	RMuint32 scaler, src_index, mixer;
	RMuint32 slot, i;
	RMbool enable;
	RMuint32 canvas_alpha = 0x80;

	struct EMhwlibNonLinearScalingMode nonlinearmode = {0,0};
	struct EMhwlibBlackStripMode blackstrip = {0,0};
	struct EMhwlibCutStripMode cutstrip = {0,0};

	/* allocate handle */
	if(config == NULL) {
		RMDBGLOG((RMSMXDBG, "Cannot open RMSMX : config == NULL\n"));
		return NULL;
	}
	
	smx = (RMsmx)RMMalloc(sizeof(struct _RMsmx));
	if(!smx){
		RMDBGLOG((RMSMXDBG, "Could not allocate smx handler\n"));
		return NULL;
	}

	/* initialize handle */
	smx->pDCC = config->pDCC;
	smx->pRUA = config->pRUA;
	smx->canvas_index = 0;
	smx->canvas_width  = config->canvas_profile.Width;	
	smx->canvas_height = config->canvas_profile.Height;
	smx->canvas_color = config->canvas_color;
	for(slot = 0; slot < MAX_SLOTS; slot++){
		smx->slots[slot].active = FALSE;
		smx->slots[slot].current_pic.PictureAddress = 0;
		smx->slots[slot].new_pic.PictureAddress = 0;
		smx->slots[slot].current_window.width = 0;
		smx->slots[slot].starved = TRUE;
	}

	err =  smx_open_gfx(smx, &(config->canvas_profile));
	if (RMFAILED(err)){
		RMDBGLOG((ENABLE, "Error opening gfx engine : %d\n",err));
		return NULL;
	}

	/* create an osd */
	scaler = config->canvas_scaler;
	mixer = DispMainMixer;
	
	window.X = 2048;
	window.Y = 2048;
	window.Width = 4096;
	window.Height = 4096;
	
	window.XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToCenter;
	window.YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToCenter;
	window.XMode = EMhwlibDisplayWindowValueMode_Relative;
	window.YMode = EMhwlibDisplayWindowValueMode_Relative;
	window.WidthMode = EMhwlibDisplayWindowValueMode_Relative;
	window.HeightMode = EMhwlibDisplayWindowValueMode_Relative;
	
	
	err = DCCOpenMultiplePictureOSDVideoSource(smx->pDCC, &(config->canvas_profile), SMX_BUFFER_COUNT, &(smx->canvas_source), NULL);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot open OSD surface %d\n", err));
		return NULL;
	}

	err = DCCGetOSDSurfaceInfo(smx->pDCC, smx->canvas_source, NULL, &(smx->canvas_surface), NULL);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get canvas surface info %d\n", err));
		return NULL;
	}

	for(i = 0; i < SMX_BUFFER_COUNT; i++){
		err = DCCGetOSDPictureInfo(smx->canvas_source, i, &(smx->canvas_picture[i]),  
					   &(smx->canvas_buffer[i]), NULL, NULL, NULL);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot get picture info %d\n", err));
			return NULL;
		}
	}

	while ((err = RUASetProperty(smx->pRUA, scaler, RMGenericPropertyID_NonLinearScalingMode, 
				     &nonlinearmode, sizeof(nonlinearmode), 0)) == RM_PENDING);
	if (RMFAILED(err) && (err != RM_INVALIDMODE)) {
		RMDBGLOG((ENABLE, "Error setting current scaler non-linear selection %d\n", err));
		return NULL;
	}
	
	while ((err = RUASetProperty(smx->pRUA, scaler, RMGenericPropertyID_BlackStripMode, 
		&blackstrip, sizeof(blackstrip), 0)) == RM_PENDING);
	if (RMFAILED(err) && (err != RM_INVALIDMODE)) {
		RMDBGLOG((ENABLE, "Error setting current scaler blackstrip mode %d\n", err));
		return NULL;
	}

	while ((err = RUASetProperty(smx->pRUA, scaler, RMGenericPropertyID_CutStripMode, 
		&cutstrip, sizeof(cutstrip), 0)) == RM_PENDING);
	if (RMFAILED(err) && (err != RM_INVALIDMODE)) {
		RMDBGLOG((ENABLE, "Error setting current scaler cutstrip mode %d\n", err));
		return NULL;
	}


	enable = TRUE;
	err =  RUASetProperty(smx->pRUA, scaler, RMGenericPropertyID_Enable, &enable, sizeof(enable), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot enable scaler\n"));
		return NULL;
	}

	while( (err = RUASetProperty(smx->pRUA, scaler, RMGenericPropertyID_Alpha0, &(canvas_alpha), sizeof(canvas_alpha), 0)) == RM_PENDING);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set the alpha value on the scaler\n"));
	}

	while ((err = RUASetProperty(smx->pRUA, scaler, RMGenericPropertyID_ScalerInputWindow, &(window), sizeof(window), 0)) == RM_PENDING);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set scaler input window on OSD surface %d\n", err));
		if(err == RM_ERROR){
			/* when scaler == DispVideoPlane, RUA will return RM_NOT_FOUND */
			return NULL;
		}
	}
	
	
	err = RUAExchangeProperty(smx->pRUA, mixer, RMGenericPropertyID_MixerSourceIndex, &scaler, sizeof(scaler), &src_index, sizeof(src_index));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get scaler index\n"));
		return NULL;
	}
	
	mixer = EMHWLIB_TARGET_MODULE(mixer, 0, src_index);
	state = EMhwlibMixerSourceState_Master;

	while((err =  RUASetProperty(smx->pRUA, mixer, RMGenericPropertyID_MixerSourceState, &state, sizeof(state), 0)) == RM_PENDING);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set scaler's state on mixer\n"));
		return NULL;
	}

	
	while ((err = RUASetProperty(smx->pRUA, mixer, RMGenericPropertyID_MixerSourceWindow, &(window), sizeof(window), 0)) == RM_PENDING);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set scaler output window %d\n", err));
		return NULL;
	}

	while ((err = RUASetProperty(smx->pRUA, mixer, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot Validate mixer\n"));
		return NULL;
	}

	/*clear both buffers */
	smx_clear_buffers(smx);

	err = DCCSetSurfaceSource(smx->pDCC, scaler, smx->canvas_source);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set the surface source %d\n", err));
		return NULL;
	}
	
	return smx;
}

RMstatus RMSMXClose(RMsmx smx)
{
	RMuint32 close_profile = 0;
	RMuint32 slot;

	for(slot = 0; slot < MAX_SLOTS; slot++){
		smx_disconnect(smx, slot);
	}
	
	
	SEND_GFX_COMMAND(smx, RMGFXEnginePropertyID_Close, close_profile);
	
	if (smx->gfx_cached_buf)
		RUAFree(smx->pRUA, smx->gfx_cached_buf);
	
	if (smx->gfx_uncached_buf)
		RUAFree(smx->pRUA, smx->gfx_uncached_buf);

	DCCCloseVideoSource(smx->canvas_source);


	RMFree(smx);

	return RM_OK;

}

RMstatus RMSMXSetInputSource(RMsmx smx, struct rmsmx_source *source, RMuint32 slot)
{
	RMuint32 surface, stc_tir;
	RMstatus err;
	struct DisplayBlock_SurfaceInfo_out_type surface_info;
	struct GFXEngine_ColorFormat_type format_param;
	RMuint32 r2, r1;
	
	if(source == NULL){
		smx_disconnect(smx,slot);
		return RM_OK;
	}
	
	err = RUAGetProperty(smx->pRUA, source->decoder_id, RMGenericPropertyID_Surface, 
			     &(surface), sizeof(surface));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get surface adress\n" ));
		return err;
	}
	RUAExchangeProperty(smx->pRUA, DisplayBlock, RMDisplayBlockPropertyID_SurfaceInfo, 
			    &(surface), sizeof(surface), &surface_info, sizeof(surface_info));
	
	/* returns RM_ERROR for video surfaces */
	
	err = RUAGetProperty(smx->pRUA, source->stc_id, RMSTCPropertyID_VideoTimeResolution, 
			     &stc_tir, sizeof(stc_tir));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get stc resolution\n" ));
		return err;
	}

	format_param.SurfaceID = GFX_SURFACE_ID_Z;
	format_param.MainMode =	surface_info.ColorMode;
	format_param.SubMode = 	surface_info.ColorFormat;
	format_param.SamplingMode = surface_info.SamplingMode;
	format_param.ColorSpace = surface_info.ColorSpace;
	SEND_GFX_COMMAND(smx, RMGFXEnginePropertyID_ColorFormat, format_param);
	
	r1 = 0;
	err = RUAExchangeProperty(smx->pRUA, source->decoder_id, RMVideoDecoderPropertyID_ConnectReader, &r1, sizeof(r1), &r2, sizeof(r2));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot connect reader to video surface\n"));
		return err;
	}
	
	smx->slots[slot].active = TRUE;
	smx->slots[slot].decoder = EMHWLIB_TARGET_MODULE(EMHWLIB_MODULE_CATEGORY(source->decoder_id), EMHWLIB_MODULE_INDEX(source->decoder_id), r2);
	smx->slots[slot].stc = source->stc_id;
	smx->slots[slot].tir = stc_tir;
	RMDBGLOG((ENABLE, "stc resolution %ld\n", stc_tir ));
	
	
	return RM_OK;
}

RMstatus RMSMXGetSlotStatus(RMsmx smx, struct rmsmx_slot_status *status, RMuint32 slot)
{
	status->starved = smx->slots[slot].starved;
	if(smx->slots[slot].current_pic.PictureAddress){
		status->displayed_pts = smx->slots[slot].current_pic.Picture.first_pts_hi;
		status->displayed_pts <<= 32;
		status->displayed_pts = smx->slots[slot].current_pic.Picture.first_pts_lo;
	}
	else
		return RM_ERROR;
	return RM_OK;
}


RMstatus RMSMXRefresh(RMsmx smx)
{
	RMstatus err;
	RMuint32 slot = 0;
	RMuint64 stc;
	RMuint64 pts;
	RMbool empty_queue = FALSE;
	struct GFXEngine_Surface_type surface_param;
	struct GFXEngine_DisplayPicture_type display_pic;

	
	/* The eraser process is performed by the GFX engine via the wait_picture command */

/* 	err = RUASetProperty(smx->pRUA, DisplayBlock, RMDisplayBlockPropertyID_ErasePicturesInSurfaceFifo,  */
/* 			     &(smx->canvas_surface), sizeof(smx->canvas_surface), 0); */
/* 	if (RMFAILED(err)) { */
/* 		RMDBGLOG((ENABLE, "Cannot erase surface\n")); */
/* 		return err; */
/* 	} */

	/* 
	 * check if the gfx queue is empty
	 * otherwise it's unsafe to release any picture
	 */

	RUAGetProperty(smx->pRUA, smx->gfx_id, RMGFXEnginePropertyID_CommandQueueEmpty,
		       &empty_queue, sizeof(empty_queue));
	if(!empty_queue){
		RMDBGLOG((DISABLE, "GFX command queue not empty\n"));
		return RM_PENDING;
	}
	
	for(slot = 0; slot < MAX_SLOTS; slot++){
		if(! smx->slots[slot].active)
			continue;
		smx->slots[slot].starved = FALSE;
		if(smx->slots[slot].new_pic.PictureAddress == 0){
		read_next_pic:
			err = RUAGetProperty(smx->pRUA, smx->slots[slot].decoder, RMVideoDecoderPropertyID_NextPicture, 
					     &smx->slots[slot].new_pic, sizeof(smx->slots[slot].new_pic));
			if(RMFAILED(err)){ /*this includes empty fifo */
				RMDBGLOG((RMSMXDBG, "slot %ld EMPTY FIFO!\n", slot));
				smx->slots[slot].new_pic.PictureAddress = 0;
				smx->slots[slot].starved = TRUE;
				continue;
			}
		}
		/* get stc */
		err = RUAExchangeProperty(smx->pRUA, smx->slots[slot].stc, RMSTCPropertyID_TimeInfo,
					  &smx->slots[slot].tir, sizeof(smx->slots[slot].stc), &stc, sizeof(stc));
		if (err != RM_OK) {
			RMDBGLOG((ENABLE, "Cannot get STC time %s\n", RMstatusToString(err)));
			return err;
		}
		/*get pts */
		pts = smx->slots[slot].new_pic.Picture.first_pts_hi;
		pts <<= 32;
		pts = smx->slots[slot].new_pic.Picture.first_pts_lo;
		pts <<= 1;
		if(pts > stc){ /* too early */
			RMDBGLOG((RMSMXDBG, "slot %ld stc %lld, pts %lld: --EARLY\n", slot, stc, pts));
			continue;
		}
		else{ /* too late or in time */

			if(smx->slots[slot].current_pic.PictureAddress){
				err = RUASetProperty(smx->pRUA, smx->slots[slot].decoder, RMVideoDecoderPropertyID_ReleasePicture,
						     &(smx->slots[slot].current_pic.PictureAddress),
						     sizeof(smx->slots[slot].current_pic.PictureAddress), 0);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Cannot release picture\n"));
				}
				smx->slots[slot].current_pic.PictureAddress = 0;
			}
			/* if new_pic.pts > current_pic.pts */
			RMMemcpy(&(smx->slots[slot].current_pic), &(smx->slots[slot].new_pic),
				 sizeof(smx->slots[slot].current_pic));
			smx->slots[slot].new_pic.PictureAddress = 0;
			if(pts + 3000 < stc){ /* too late */
				RMDBGLOG((RMSMXDBG, "slot %ld stc %lld, pts %lld: --LATE\n", slot, stc, pts));
				goto read_next_pic;
			}

		}
	}

	if (SMX_BUFFER_COUNT > 1) {
		/* block the engine until the current canvas is no longer on display */
		SEND_GFX_COMMAND(smx, RMGFXEnginePropertyID_WaitForPicture,
			 (smx->canvas_picture[smx->canvas_index]));
	}

	/* setup the gfx to draw on the current canvas buffer */
	surface_param.SurfaceID = GFX_SURFACE_ID_NX;
	surface_param.StartAddress = smx->canvas_buffer[smx->canvas_index];
	surface_param.TotalWidth = smx->canvas_width;
	surface_param.Tiled = FALSE;
	SEND_GFX_COMMAND(smx, RMGFXEnginePropertyID_Surface, surface_param);
	
	if(smx->canvas_dirty){
		/* when a window is resized, moved, added, removed we need to clean the canvas */
		struct GFXEngine_FillRectangle_type fill_param;
		smx->canvas_dirty--;
		fill_param.X = 0;
		fill_param.Y = 0;
		fill_param.Width = smx->canvas_width;
		fill_param.Height = smx->canvas_height;
		fill_param.Color = smx->canvas_color;
		SEND_GFX_COMMAND(smx, RMGFXEnginePropertyID_FillRectangle, fill_param);
	}



	for(slot = 0; slot < MAX_SLOTS; slot++){
		if(smx->slots[slot].current_pic.PictureAddress)
			smx_set_picture(smx, &(smx->slots[slot].current_pic.Picture), slot);
	}
	
	/* ask gfx to display the current canvas buffer */
	display_pic.Surface = smx->canvas_surface;
	display_pic.Picture = smx->canvas_picture[smx->canvas_index];
	SEND_GFX_COMMAND(smx, RMGFXEnginePropertyID_DisplayPicture, display_pic);

	RMDBGLOG((RMSMXDBG, "Send picture 0x%08lx on surface 0x%08lx\n", smx->canvas_picture[smx->canvas_index], smx->canvas_surface));

	/* flip the canvas buffer index */
	smx->canvas_index++;
	smx->canvas_index %= SMX_BUFFER_COUNT;

	return RM_OK;

}

RMstatus RMSMXFlushSlot(RMsmx smx, RMuint32 slot)
{
	RMstatus err;

	RMASSERT(slot<MAX_SLOTS);
	
	if (!smx->slots[slot].active)
		return RM_OK;

	if(smx->slots[slot].current_pic.PictureAddress){
		err = RUASetProperty(smx->pRUA, smx->slots[slot].decoder, RMVideoDecoderPropertyID_KeepPictureBeforeFlushing,
				     &(smx->slots[slot].current_pic.PictureAddress),
				     sizeof(smx->slots[slot].current_pic.PictureAddress), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot release picture\n"));
		}

		/* do not clear it to keep it on screen */
/* 		smx->slots[slot].current_pic.PictureAddress = 0; */
	}

	if(smx->slots[slot].new_pic.PictureAddress){
		err = RUASetProperty(smx->pRUA, smx->slots[slot].decoder, RMVideoDecoderPropertyID_ReleasePicture,
				     &(smx->slots[slot].new_pic.PictureAddress),
				     sizeof(smx->slots[slot].new_pic.PictureAddress), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot release picture\n"));
		}
		
		smx->slots[slot].new_pic.PictureAddress = 0;
	}

	err = RUASetProperty(smx->pRUA, smx->slots[slot].decoder, RMVideoDecoderPropertyID_FlushReaderDisplayFIFO,
			     NULL, 0, 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot release picture\n"));
	}
	
	smx->slots[slot].starved = TRUE;
	
	return RM_OK;
}

RMstatus RMSMXSetCanvasColor(RMsmx smx, RMuint32 canvas_color)
{
	smx->canvas_color = canvas_color;
	smx->canvas_dirty = SMX_BUFFER_COUNT;
	return RM_OK;
}

RMstatus RMSMXSetOutputWindow(RMsmx smx, struct rmsmx_window *window, RMuint32 slot)
{
	
	if((window->x < window->border_width) ||
	   (window->y < window->border_width) ||
	   (window->x + window->width + window->border_width > smx->canvas_width) ||
	   (window->y + window->height + window->border_width > smx->canvas_height)){
		RMDBGLOG((ENABLE, "INVALID WINDOW: X %ld Y %ld W %ld H %ld B %ld\n",
			  window->x,
			  window->y,
			  window->width,
			  window->height,
			  window->border_width));
		return RM_ERROR;
	}
	smx->canvas_dirty = SMX_BUFFER_COUNT;
	if(window->border_width)
		smx->slots[slot].draw_border = SMX_BUFFER_COUNT;
	
	RMMemcpy(&(smx->slots[slot].current_window), window, sizeof(struct rmsmx_window));
	RMDBGLOG((RMSMXDBG, "WINDOW OK: X %ld Y %ld W %ld H %ld B %ld\n",
		  smx->slots[slot].current_window.x,
		  smx->slots[slot].current_window.y,
		  smx->slots[slot].current_window.width,
		  smx->slots[slot].current_window.height,
		  smx->slots[slot].current_window.border_width));

	return RM_OK;
}

static inline RMuint32 get_vbus_pixel_address(RMuint32 base, RMuint32 x, RMuint32 y, RMuint32 width, RMuint32 bits_per_pixel, RMbool tiled)
{
	x = (x * bits_per_pixel) / 8;

	if (tiled) {
		RMuint32 buffer_start, x_offset, y_offset;

		buffer_start = base & ~(4095);          /* (base / 4096) * 4096; */
		x_offset = x + (base & 127);            /* x + (base - buffer_start) % 128 */
		y_offset = y + ((base & 4095) >> 7);    /* y + (base - buffer_start) / 128 */ 
		
		/* buffer_start + (x_offset/128)*4096 + (y_offset/32)*width*4096 + (x_offset%128) + (y_offset%32)*128 */
		return buffer_start + ((x_offset >> 7)<<12) + ((y_offset >> 5)<<12)*width + (x_offset & 127) + ((y_offset & 31)<<7);
		
	}
	else {
		return base + y * width + x;
	}
}

static inline RMstatus smx_set_picture(RMsmx smx, struct EMhwlibNewPicture *pic, RMuint32 slot)
{
	struct GFXEngine_MoveReplaceScaleRectangle_type move_param;
	struct GFXEngine_Surface_type surface_param;
	struct GFXEngine_FieldType_type field_param;
	RMuint32 width, height;
	RMuint32 val, x, y, w;
	
	surface_param.SurfaceID = GFX_SURFACE_ID_Z;
	val = pic->luma_address;
	x = pic->luma_position_in_buffer.x;
	y = pic->luma_position_in_buffer.y;
	w = pic->luma_total_width;
	val = get_vbus_pixel_address(val, x, y, w, 8, TRUE);
	surface_param.StartAddress = val;
	surface_param.TotalWidth = w; 
	
	val = pic->chroma_address;
	x = pic->chroma_position_in_buffer.x;
	y = pic->chroma_position_in_buffer.y;
	w = pic->chroma_total_width;
	val = get_vbus_pixel_address(val, x, y, w, 8, TRUE);
	surface_param.ChromaStartAddress = val;
	surface_param.ChromaTotalWidth = w; 
	surface_param.Tiled = TRUE;
	SEND_GFX_COMMAND(smx, RMGFXEnginePropertyID_Surface, surface_param);
	
	field_param.SurfaceID = GFX_SURFACE_ID_Z;
	field_param.LineSkipFactor = 2;
	field_param.FieldType = EMhwlibFieldType_Top;
	SEND_GFX_COMMAND(smx, RMGFXEnginePropertyID_FieldType, field_param);
	width = pic->luma_position_in_buffer.width;
	height = pic->luma_position_in_buffer.height;

	if(smx->slots[slot].draw_border){
		struct GFXEngine_FillRectangle_type fill_param;
		fill_param.X = smx->slots[slot].current_window.x
			- smx->slots[slot].current_window.border_width;
		fill_param.Y = smx->slots[slot].current_window.y
			- smx->slots[slot].current_window.border_width;
		fill_param.Width = smx->slots[slot].current_window.width
			+ 2*smx->slots[slot].current_window.border_width;
		fill_param.Height = smx->slots[slot].current_window.height
			+ 2*smx->slots[slot].current_window.border_width;
		fill_param.Color = smx->slots[slot].current_window.border_color;
		SEND_GFX_COMMAND(smx, RMGFXEnginePropertyID_FillRectangle, fill_param);
		smx->slots[slot].draw_border--;
	}
	move_param.SrcX = 0;
	move_param.SrcY = 0;
	move_param.SrcWidth = width;
	move_param.SrcHeight = height;
	move_param.DstX = smx->slots[slot].current_window.x;
	move_param.DstY = smx->slots[slot].current_window.y;
	move_param.DstWidth = smx->slots[slot].current_window.width;
	move_param.DstHeight = smx->slots[slot].current_window.height;
	move_param.AlphaX = 0;
	move_param.AlphaY = 0;
	move_param.Merge = FALSE;
	SEND_GFX_COMMAND(smx, RMGFXEnginePropertyID_MoveAndScaleRectangle, move_param);
	return RM_OK;
}



static inline RMstatus smx_open_gfx(RMsmx smx,	struct DCCOSDProfile *canvas_profile )
{
	struct GFXEngine_ColorFormat_type format_param;
	struct GFXEngine_DRAMSize_in_type  dramSizeIn;
	struct GFXEngine_DRAMSize_out_type dramSizeOut;
	struct GFXEngine_Open_type profile;
	struct GFXEngine_AlphaPalette_type alpha_palette;

	RMuint32 gfx_count, i;
	RMstatus err;
	

	dramSizeIn.CommandFIFOCount = 32;
	smx->gfx_id = EMHWLIB_MODULE(GFXEngine,0);
	err = RUAExchangeProperty(smx->pRUA, smx->gfx_id, RMGFXEnginePropertyID_DRAMSize,
				  &dramSizeIn, sizeof(dramSizeIn), &dramSizeOut, sizeof(dramSizeOut));
	if (RMFAILED(err)) {
		RMDBGLOG((RMSMXDBG, "Error getting dram size for gfx engine\n"));
		return RM_ERROR;
	}
	profile.CommandFIFOCount = dramSizeIn.CommandFIFOCount;
	profile.Priority = 1;
	
	profile.CachedSize = dramSizeOut.CachedSize;
	if (profile.CachedSize > 0){
		profile.CachedAddress = RUAMalloc(smx->pRUA, 0, RUA_DRAM_CACHED, profile.CachedSize);
		smx->gfx_cached_buf = profile.CachedAddress;
	}
	
	profile.UncachedSize = dramSizeOut.UncachedSize;
	if (profile.UncachedSize > 0) {
		profile.UncachedAddress = RUAMalloc(smx->pRUA, 0, RUA_DRAM_UNCACHED, profile.UncachedSize);
		smx->gfx_uncached_buf = profile.UncachedAddress;
	}
	 

	err = RUAExchangeProperty(smx->pRUA, EMHWLIB_MODULE(Enumerator,0),  RMEnumeratorPropertyID_CategoryIDToNumberOfInstances, 
				  &(smx->gfx_id), sizeof(smx->gfx_id), &gfx_count, sizeof(gfx_count));
	if (RMFAILED(err)) {
		RMDBGLOG((RMSMXDBG, "Error getting gfx engine count\n"));
		return RM_ERROR;
	}
	for (i=0 ; i< gfx_count ; i++) {
		smx->gfx_id = EMHWLIB_MODULE(GFXEngine, i);
		err = RUASetProperty(smx->pRUA, smx->gfx_id, RMGFXEnginePropertyID_Open, &profile, sizeof(profile), 0);
		if (err == RM_OK) 
			break;
	}
	
	if (i==gfx_count) {
		RMDBGLOG((RMSMXDBG, "Cannot open a gfx engine [0..%lu[\n", gfx_count));
		return RM_ERROR;
	}
	
	format_param.SurfaceID = GFX_SURFACE_ID_NX;	
	format_param.MainMode = canvas_profile->ColorMode;
	format_param.SubMode = canvas_profile->ColorFormat;
	format_param.SamplingMode = canvas_profile->SamplingMode;
	format_param.ColorSpace = canvas_profile->ColorSpace;
	SEND_GFX_COMMAND(smx, RMGFXEnginePropertyID_ColorFormat, format_param);


	/* possibly let the application chose this */
	alpha_palette.SurfaceID = GFX_SURFACE_ID_Z;
	alpha_palette.Alpha0 = 0xff;
	SEND_GFX_COMMAND(smx, RMGFXEnginePropertyID_AlphaPalette, alpha_palette);
	return RM_OK;

}

static RMstatus smx_clear_buffers(RMsmx smx)
{
	struct GFXEngine_FillRectangle_type fill_param;
	struct GFXEngine_Surface_type surface_param;
	struct GFXEngine_DisplayPicture_type display_pic;

	RMuint32 i;

	surface_param.SurfaceID = GFX_SURFACE_ID_NX;
	surface_param.TotalWidth = smx->canvas_width; 
	surface_param.Tiled = FALSE; 
	
	fill_param.X = 0;
	fill_param.Y = 0;
	fill_param.Width = smx->canvas_width;
	fill_param.Height = smx->canvas_height;
	fill_param.Color = smx->canvas_color;
	
	/* clear buffers with background color */
	for(i = 0; i < SMX_BUFFER_COUNT; i++){
		surface_param.StartAddress = smx->canvas_buffer[i];
		SEND_GFX_COMMAND(smx, RMGFXEnginePropertyID_Surface, surface_param);
		SEND_GFX_COMMAND(smx, RMGFXEnginePropertyID_FillRectangle, fill_param);
	}
	
	/* display the first buffer */
	display_pic.Surface = smx->canvas_surface;
	display_pic.Picture = smx->canvas_picture[smx->canvas_index];
	SEND_GFX_COMMAND(smx, RMGFXEnginePropertyID_DisplayPicture, display_pic);

	/* flip the canvas buffer index */
	smx->canvas_index++;
	smx->canvas_index %= SMX_BUFFER_COUNT;


	return RM_OK;
}
