/*
 *
 * Copyright (c) Sigma Designs, Inc. 2006. All rights reserved.
 *
 */

/**
	@file dcc_multiple_audio.c
	@brief handles simultaneus audio instances
	
	@author Sebastian Frias Feltrer (June 22nd 2006)

*/



#include "dcc_common.h"


struct DCCMultipleAudioSource {
	struct RUA *pRUA;
	struct DCC *pDCC;

	RMuint32 instances;  //number of decoders opened

	struct DCCAudioSourceHandle AudioSourceHandles[MAX_AUDIO_DECODER_INSTANCES];

	RMuint32 nextInstance;
};

#define LOCALDBG DISABLE

RMstatus DCCOpenMultipleAudioDecoderSource(struct DCC *pDCC, struct DCCAudioProfile *profiles, RMuint32 profiles_count, struct DCCMultipleAudioSource **ppMultipleAudioSource)
{
	RMuint32 i;
	RMstatus status;
	struct DCCAudioSource *pAudioSource;
	RMuint32 audio_decoder, audio_engine, audio_timer;
	struct DCCAudioProfile *pProfile = NULL;

	RMDBGLOG((LOCALDBG, "DCCOpenMultipleAudioDecoderSource: %lu instances\n", profiles_count));

	*ppMultipleAudioSource = (struct DCCMultipleAudioSource *) RMMalloc(sizeof(struct DCCMultipleAudioSource));
	if (*ppMultipleAudioSource == NULL) {
		RMDBGLOG((ENABLE, "ERROR: could not allocate %lu bytes in system memory\n", sizeof(struct DCCMultipleAudioSource)));
		return RM_FATALOUTOFMEMORY;
	}

	RMMemset((void*)(*ppMultipleAudioSource), 0, sizeof(struct DCCMultipleAudioSource));


	for (i = 0; i < profiles_count ; i++) {
		pProfile = (struct DCCAudioProfile *) &(profiles[i]);

		RMDBGLOG((LOCALDBG, "open instance %lu\n", i));
		status = DCCOpenAudioDecoderSource(pDCC, pProfile, &pAudioSource);
		if (RMFAILED(status)) {
			RMDBGLOG((ENABLE, "error opening instance %lu\n", i));
			return status;
		}
		
		status = DCCGetAudioDecoderSourceInfo(pAudioSource, &audio_decoder, &audio_engine, &audio_timer);
		if (RMFAILED(status)) {
			RMDBGLOG((ENABLE, "Error getting audio decoder source information for instance %lu\n", i));
			return status;
		}

		RMDBGLOG((LOCALDBG, "engine 0x%lx decoder 0x%lx\n", audio_engine, audio_decoder));

		(*ppMultipleAudioSource)->AudioSourceHandles[i].pAudioSource = pAudioSource;
		(*ppMultipleAudioSource)->AudioSourceHandles[i].engineID = audio_engine;
		(*ppMultipleAudioSource)->AudioSourceHandles[i].moduleID = audio_decoder;
	}
	(*ppMultipleAudioSource)->instances = profiles_count;
	(*ppMultipleAudioSource)->pRUA = pDCC->pRUA;
	(*ppMultipleAudioSource)->pDCC = pDCC;
	(*ppMultipleAudioSource)->nextInstance = 0;

	return RM_OK;
}

RMstatus DCCMultipleAudioSourceGetNumberOfInstances(struct DCCMultipleAudioSource *pMultipleAudioSource, RMuint32 *instances)
{
	if (!pMultipleAudioSource)
		return RM_ERROR;

	*instances = pMultipleAudioSource->instances;

	return RM_OK;
}

RMstatus DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(struct DCCMultipleAudioSource *pMultipleAudioSource, RMuint32 instance, struct DCCAudioSourceHandle *pSingleAudioSourceHandle)
{
	if (!pMultipleAudioSource)
		return RM_ERROR;

	if (instance >= pMultipleAudioSource->instances)
		return RM_ERROR;

	RMMemcpy((void *)pSingleAudioSourceHandle, (void *)&(pMultipleAudioSource->AudioSourceHandles[instance]), (sizeof(struct DCCAudioSourceHandle)));
	

	return RM_OK;
}


RMstatus DCCCloseMultipleAudioSource(struct DCCMultipleAudioSource *pMultipleAudioSource)
{
	RMuint32 i;
	if (!pMultipleAudioSource)
		return RM_ERROR;

	for (i = 0; i < pMultipleAudioSource->instances; i++) {
		RMDBGLOG((LOCALDBG, "closing instance %lu\n", i));
		DCCCloseAudioSource(pMultipleAudioSource->AudioSourceHandles[i].pAudioSource);
		pMultipleAudioSource->AudioSourceHandles[i].pAudioSource = NULL;
	}


	RMFree(pMultipleAudioSource);
	return RM_OK;
}

RMstatus DCCPlayMultipleAudioSource(struct DCCMultipleAudioSource *pMultipleAudioSource)
{
	RMuint32 i;
	RMstatus status;

	if (!pMultipleAudioSource)
		return RM_ERROR;

	for (i = 0; i < pMultipleAudioSource->instances; i++) {
		RMDBGLOG((LOCALDBG, "play instance %lu\n", i));
		status = DCCPlayAudioSource(pMultipleAudioSource->AudioSourceHandles[i].pAudioSource);
		if (status != RM_OK)
			return status;
	}

	return RM_OK;
}

RMstatus DCCStopMultipleAudioSource(struct DCCMultipleAudioSource *pMultipleAudioSource)
{
	RMuint32 i;
	RMstatus status;

	if (!pMultipleAudioSource)
		return RM_ERROR;

	for (i = 0; i < pMultipleAudioSource->instances; i++) {
		RMDBGLOG((LOCALDBG, "stop instance %lu\n", i));
		status = DCCStopAudioSource(pMultipleAudioSource->AudioSourceHandles[i].pAudioSource);
		if (status != RM_OK)
			return status;
	}

	return RM_OK;
}

RMstatus DCCPauseMultipleAudioSource(struct DCCMultipleAudioSource *pMultipleAudioSource)
{
	RMuint32 i;
	RMstatus status;

	if (!pMultipleAudioSource)
		return RM_ERROR;

	for (i = 0; i < pMultipleAudioSource->instances; i++) {
		RMDBGLOG((LOCALDBG, "pause instance %lu\n", i));
		status = DCCPauseAudioSource(pMultipleAudioSource->AudioSourceHandles[i].pAudioSource);
		if (status != RM_OK)
			return status;
	}

	return RM_OK;
}



RMstatus DCCMultipleAudioSendData(struct DCCMultipleAudioSource *pMultipleAudioSource, struct RUABufferPool *pBufferPool, RMuint8 *pData, RMuint32 DataSize, void *pInfo, RMuint32 InfoSize, RMint32 *lastOKInstance)
{
	RMuint32 i;
	RMstatus status;
	*lastOKInstance = -1;

	if (!pMultipleAudioSource)
		return RM_ERROR;

	for (i = pMultipleAudioSource->nextInstance; i < pMultipleAudioSource->instances; i++) {

		*lastOKInstance = (RMint32)i;
		pMultipleAudioSource->nextInstance = i;

		status = RUASendData(pMultipleAudioSource->pRUA, pMultipleAudioSource->AudioSourceHandles[i].moduleID, pBufferPool, pData, DataSize, pInfo, InfoSize);
		if (status != RM_OK) {
			RMDBGLOG((LOCALDBG, "instance %lu status is %s\n", i, RMstatusToString(status)));
			return status;
		}
		else {
			RMDBGLOG((LOCALDBG, "sent %lu bytes to instance %lu\n", DataSize, i));
		}
	}
	pMultipleAudioSource->nextInstance = 0;
	*lastOKInstance = -1;

	return RM_OK;
}



RMstatus DCCSetMultipleAudioSourceVolume(struct DCCMultipleAudioSource *pMultipleAudioSource, RMuint32 volume)
{
	RMuint32 i;
	RMstatus status;

	if (!pMultipleAudioSource)
		return RM_ERROR;

	for (i = 0; i < pMultipleAudioSource->instances; i++) {
		RMDBGLOG((LOCALDBG, "set volume 0x%lx to instance %lu\n", volume, i));
		status = DCCSetAudioSourceVolume(pMultipleAudioSource->AudioSourceHandles[i].pAudioSource, volume);
		if (status != RM_OK)
			return status;
	}

	return RM_OK;

}


RMstatus DCCSetMultipleAudioBtsThreshold(struct DCCMultipleAudioSource *pMultipleAudioSource, RMuint32 level)
{
	RMuint32 i;
	RMstatus status;

	if (!pMultipleAudioSource)
		return RM_ERROR;

	for (i = 0; i < pMultipleAudioSource->instances; i++) {
		RMDBGLOG((LOCALDBG, "set BTS level to 0x%lx to instance %lu\n", level, i));
		status = DCCSetAudioBtsThreshold(pMultipleAudioSource->AudioSourceHandles[i].pAudioSource, level);
		if (status != RM_OK)
			return status;
	}

	return RM_OK;
}
