/*****************************************
 Copyright © 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   dcc.c
  @brief  Decoding Chain Control API

  @author Julien Soulier
  @date   2003-10-02
*/

// to enable or disable the debug messages of this source file, put 1 or 0 below
#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

#include "dcc_common.h"

RMstatus DCCOpenOSDVideoSource(struct DCC *pDCC, struct DCCOSDProfile *profile, struct DCCVideoSource **ppVideoSource)
{
	struct DisplayBlock_SurfaceSize_in_type dram_in;
	struct DisplayBlock_SurfaceSize_out_type dram_out;
	struct DisplayBlock_InitSurface_in_type valueIn;
	struct DisplayBlock_InitSurface_out_type valueOut;
	RMstatus err;
	RMuint32 addr;
	
	*ppVideoSource = (struct DCCVideoSource *) RMMalloc(sizeof(struct DCCVideoSource));
	if (*ppVideoSource == NULL) {
		RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in system memory %lu!\n", sizeof(struct DCCVideoSource)));
		return RM_FATALOUTOFMEMORY;
	}

	RMMemset((void*)(*ppVideoSource), 0, sizeof(struct DCCVideoSource));

	(*ppVideoSource)->pRUA = pDCC->pRUA;
	(*ppVideoSource)->pDCC = pDCC;
	(*ppVideoSource)->decoder_moduleID = 0;
	(*ppVideoSource)->scaler_moduleID = 0;
	(*ppVideoSource)->timer_number = 0xff;

	dram_in.ColorMode = profile->ColorMode;
	dram_in.ColorFormat = profile->ColorFormat;
	dram_in.SamplingMode = profile->SamplingMode;
	dram_in.Width = profile->Width;
	dram_in.Height = profile->Height;
	err = RUAExchangeProperty(pDCC->pRUA, DisplayBlock, RMDisplayBlockPropertyID_SurfaceSize, 
				  &dram_in, sizeof(dram_in), &dram_out, sizeof(dram_out));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error Cannot get size to allocate the OSD surface, %s\n", RMstatusToString(err)));
		return err;
	}
	
	addr = pDCC->rua_malloc(pDCC->pRUA, DisplayBlock, pDCC->dram, RUA_DRAM_UNCACHED, dram_out.BufferSize);
	if (addr == 0) {
		RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in system memory %lu!\n", dram_out.BufferSize));
		return RM_FATALOUTOFMEMORY;
	}
 	(*ppVideoSource)->uncached_address = addr;
 	(*ppVideoSource)->cached_address = 0;
 	(*ppVideoSource)->surface = addr;

	valueIn.ColorMode = dram_in.ColorMode;
	valueIn.ColorFormat = dram_in.ColorFormat;
	valueIn.SamplingMode = dram_in.SamplingMode;
	valueIn.Width = dram_in.Width;
	valueIn.Height = dram_in.Height;
	valueIn.Address = addr;
	valueIn.LumaSize = dram_out.LumaSize;
	valueIn.ChromaSize = dram_out.ChromaSize;
	valueIn.ColorSpace = profile->ColorSpace;
	valueIn.PixelAspectRatio = profile->PixelAspectRatio;
	err = RUAExchangeProperty(pDCC->pRUA, DisplayBlock, RMDisplayBlockPropertyID_InitSurface, 
				  &valueIn, sizeof(valueIn), &valueOut, sizeof(valueOut));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot initialize OSD surface, %s\n", RMstatusToString(err)));
		return err;
	}

 	(*ppVideoSource)->picture_count = 1;
	(*ppVideoSource)->pictures = (struct DCCOSDPicture *) RMMalloc(sizeof(struct DCCOSDPicture));
	if ((*ppVideoSource)->pictures == NULL) {
		RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in system memory %lu!\n", sizeof(struct DCCOSDPicture)));
		return RM_FATALOUTOFMEMORY;
	}

	(*ppVideoSource)->pictures[0].picture_addr = valueOut.PictureAddress;
	(*ppVideoSource)->pictures[0].pRUA = pDCC->pRUA;
	(*ppVideoSource)->pictures[0].Y_size = valueIn.LumaSize;
	(*ppVideoSource)->pictures[0].Y_addr = valueOut.LumaAddress;
	(*ppVideoSource)->pictures[0].UV_size = valueIn.ChromaSize;
	(*ppVideoSource)->pictures[0].UV_addr = valueOut.ChromaAddress;
	(*ppVideoSource)->pictures[0].P_size = 0;
	(*ppVideoSource)->pictures[0].P_addr = 0;
	(*ppVideoSource)->pictures[0].width = dram_in.Width;
	(*ppVideoSource)->pictures[0].height = dram_in.Height;


	
	return RM_OK;
}

RMstatus DCCOpenMultiplePictureOSDVideoSource(struct DCC *pDCC, struct DCCOSDProfile *profile, 
					      RMuint32 picture_count, struct DCCVideoSource **ppVideoSource,
					      struct DCCSTCSource *pStcSource)
{
	struct DisplayBlock_InitMultiplePictureSurface_type surface_init;
	struct DisplayBlock_PictureSize_in_type dram_in;
	struct DisplayBlock_PictureSize_out_type dram_out;
	struct DisplayBlock_InitPictureX_in_type valueIn;
	struct DisplayBlock_InitPictureX_out_type valueOut;
	struct DisplayBlock_EnableGFXInteraction_type gfxInteraction;

	RMstatus err;
	RMuint32 addr, ptr, i;
	RMuint32 surface_size;
	RMuint32 stc_id;
	
	*ppVideoSource = (struct DCCVideoSource *) RMMalloc(sizeof(struct DCCVideoSource));
	if (*ppVideoSource == NULL) {
		RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in system memory %lu!\n", sizeof(struct DCCVideoSource)));
		return RM_FATALOUTOFMEMORY;
	}

	RMMemset((void*)(*ppVideoSource), 0, sizeof(struct DCCVideoSource));

	(*ppVideoSource)->pRUA = pDCC->pRUA;
	(*ppVideoSource)->pDCC = pDCC;
	(*ppVideoSource)->decoder_moduleID = 0;
	(*ppVideoSource)->scaler_moduleID = 0;
	(*ppVideoSource)->timer_number = 0xff;

	err = RUAExchangeProperty(pDCC->pRUA, DisplayBlock, RMDisplayBlockPropertyID_MultiplePictureSurfaceSize,
				  &picture_count, sizeof(picture_count), &surface_size, sizeof(surface_size));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error Cannot get size to allocate the OSD surface, %s\n", RMstatusToString(err)));
		return err;
	}

	dram_in.ColorMode = profile->ColorMode;
	dram_in.ColorFormat = profile->ColorFormat;
	dram_in.SamplingMode = profile->SamplingMode;
	dram_in.Width = profile->Width;
	dram_in.Height = profile->Height;
	err = RUAExchangeProperty(pDCC->pRUA, DisplayBlock, RMDisplayBlockPropertyID_PictureSize,
				  &dram_in, sizeof(dram_in), &dram_out, sizeof(dram_out));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error Cannot get size to allocate an OSD picture, %s\n", RMstatusToString(err)));
		return err;
	}

	addr = pDCC->rua_malloc(pDCC->pRUA, DisplayBlock, pDCC->dram, RUA_DRAM_UNCACHED, surface_size + dram_out.BufferSize * picture_count);
	if (addr == 0) {
		RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in system memory %lu!\n", 
			  surface_size + dram_out.BufferSize * picture_count));
		return RM_FATALOUTOFMEMORY;
	}
 	(*ppVideoSource)->uncached_address = addr;
 	(*ppVideoSource)->cached_address = 0;
 	(*ppVideoSource)->surface = addr;

	if(pStcSource)
		DCCSTCGetModuleId(pStcSource, &stc_id);
	else 
		stc_id = 0;

	surface_init.Address = addr;
	surface_init.ColorMode = profile->ColorMode; 
	surface_init.ColorFormat = profile->ColorFormat;
	surface_init.SamplingMode = profile->SamplingMode;
	surface_init.ColorSpace = profile->ColorSpace;
	surface_init.PixelAspectRatio = profile->PixelAspectRatio;
	surface_init.PictureCount = picture_count;
	surface_init.STCModuleId = stc_id;

 	err = RUASetProperty(pDCC->pRUA, DisplayBlock, RMDisplayBlockPropertyID_InitMultiplePictureSurface,
			     &surface_init, sizeof(surface_init), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error Cannot initialize surface, %s\n", RMstatusToString(err)));
		pDCC->rua_free(pDCC->pRUA, surface_init.Address);
		return err;
	}

	addr += surface_size;

	(*ppVideoSource)->pictures = RMMalloc(sizeof(struct DCCOSDPicture) * picture_count);
	if ((*ppVideoSource)->pictures == NULL) {
		RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in system memory %lu!\n", sizeof(struct DCCOSDPicture) * picture_count));
		return RM_FATALOUTOFMEMORY;
	}
	(*ppVideoSource)->picture_count = picture_count;
	
	valueIn.Width = dram_in.Width;
	valueIn.Height = dram_in.Height;
	valueIn.LumaSize = dram_out.LumaSize;
	valueIn.ChromaSize = dram_out.ChromaSize;
	valueIn.PaletteSize = dram_out.PaletteSize;

	for (i=0, ptr=addr; i<picture_count ; i++, ptr += dram_out.BufferSize) {
		valueIn.Address = ptr;
		err = RUAExchangeProperty(pDCC->pRUA, DisplayBlock, RMDisplayBlockPropertyID_InitPictureX,
					  &valueIn, sizeof(valueIn), &valueOut, sizeof(valueOut));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error Cannot initialize surface, %s\n", RMstatusToString(err)));
			pDCC->rua_free(pDCC->pRUA, surface_init.Address);
			return err;
		}
		
		(*ppVideoSource)->pictures[i].pRUA = pDCC->pRUA;
		(*ppVideoSource)->pictures[i].picture_addr = ptr;
		(*ppVideoSource)->pictures[i].Y_addr = valueOut.LumaAddress;
		(*ppVideoSource)->pictures[i].UV_addr = valueOut.ChromaAddress;
		(*ppVideoSource)->pictures[i].Y_size = valueIn.LumaSize;
		(*ppVideoSource)->pictures[i].UV_size = valueIn.ChromaSize;
		(*ppVideoSource)->pictures[i].P_size = valueIn.PaletteSize;
		(*ppVideoSource)->pictures[i].P_addr = valueOut.PaletteAddress;
		(*ppVideoSource)->pictures[i].width = dram_in.Width;
		(*ppVideoSource)->pictures[i].height = dram_in.Height;

	}
	gfxInteraction.Surface = surface_init.Address;
	gfxInteraction.Enable = TRUE;
 	err = RUASetProperty(pDCC->pRUA, DisplayBlock, RMDisplayBlockPropertyID_EnableGFXInteraction,
			     &gfxInteraction, sizeof(gfxInteraction), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error Cannot enable GFX Interaction on Surface %s\n", RMstatusToString(err)));
		pDCC->rua_free(pDCC->pRUA, surface_init.Address);
		return err;
	}



	return RM_OK;
}

RMstatus DCCGetOSDPictureInfo(struct DCCVideoSource *pVideoSource, RMuint32 index, RMuint32 *PictureAddr,  RMuint32 *LumaAddr, RMuint32 *LumaSize, RMuint32 *ChromaAddr, RMuint32 *ChromaSize)
{
	RMASSERT(pVideoSource);
	RMASSERT(pVideoSource->pictures);

	if(index >= pVideoSource->picture_count)
		return RM_ERROR;

	if(PictureAddr != NULL)
		*PictureAddr = pVideoSource->pictures[index].picture_addr;
	if(LumaAddr != NULL)
		*LumaAddr = pVideoSource->pictures[index].Y_addr;
	if(LumaSize != NULL)
		*LumaSize = pVideoSource->pictures[index].Y_size;
	if(ChromaAddr != NULL)
		*ChromaAddr = pVideoSource->pictures[index].UV_addr;
	if(ChromaSize != NULL)
		*ChromaSize = pVideoSource->pictures[index].UV_size;
				     
	return RM_OK;
}

RMstatus DCCGetOSDVideoSourceInfo(struct DCCVideoSource *pVideoSource, RMuint32 *LumaAddr, RMuint32 *LumaSize, RMuint32 *ChromaAddr, RMuint32 *ChromaSize)
{
	return DCCGetOSDPictureInfo(pVideoSource, 0 , NULL, LumaAddr, LumaSize, ChromaAddr, ChromaSize);
}

RMstatus DCCGetOSDSurfaceInfo(struct DCC *pDCC, struct DCCVideoSource *pVideoSource, struct DCCOSDProfile *profile, 
			      RMuint32 *SurfaceAddr, RMuint32 *SurfaceSize)
{
      if(profile != NULL) {
	      struct DisplayBlock_SurfaceSize_in_type dram_in;
	      struct DisplayBlock_SurfaceSize_out_type dram_out;
	      RMstatus err;
	      dram_in.ColorMode = profile->ColorMode;
	      dram_in.ColorFormat = profile->ColorFormat;
	      dram_in.SamplingMode = profile->SamplingMode;
	      dram_in.Width = profile->Width;
	      dram_in.Height = profile->Height;
	      err = RUAExchangeProperty(pDCC->pRUA, DisplayBlock, RMDisplayBlockPropertyID_SurfaceSize, 
					&dram_in, sizeof(dram_in), &dram_out, sizeof(dram_out));
	      if (RMFAILED(err)) {
		      RMDBGLOG((ENABLE, "Error Cannot get size to allocate the OSD surface %d\n", err));
		      return err;
	      }
	      *SurfaceSize = dram_out.BufferSize;

      }

      *SurfaceAddr = pVideoSource->surface;
      return RM_OK;
}
 

static RMstatus set_memory(struct RUA *pRUA, 
			   RMuint32 rua_addr, 
			   RMuint32 size, 
			   RMuint8 * user_addr, 
			   RMbool clear,
			   RMint32 clearwith)
{
	RMuint32 chunk;
	RMuint8 *BaseAddr;
	RMstatus err;

#if ((EM86XX_MODE == EM86XX_MODEID_WITHHOST) || (EM86XX_CHIP == EM86XX_CHIPID_TANGO2))
	while (size) {
		chunk = RMmin(size, 0x100000);  // 1 MByte max
		
		err = RUALock(pRUA, rua_addr, chunk);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error locking OSD buffer at 0x%08lX (0x%08lX bytes): %s\n", rua_addr, chunk, RMstatusToString(err)));
			return err;
		}
		BaseAddr = RUAMap(pRUA, rua_addr, chunk);
		if (BaseAddr == NULL) {
			RMDBGLOG((ENABLE, "Error mapping OSD buffer at 0x%08lX (0x%08lX bytes)\n", rua_addr, chunk));
			return RM_ERROR;
		}
		
		if((!clear) && (user_addr != NULL))
			RMMemcpy(BaseAddr, user_addr, chunk);
		else
			RMMemset(BaseAddr, clearwith, chunk);
		
		RUAUnMap(pRUA, BaseAddr, chunk);

		err = RUAUnLock(pRUA, rua_addr, chunk);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error unlocking OSD buffer at 0x%08lX (0x%08lX bytes): %s\n", rua_addr, chunk, RMstatusToString(err)));
			return err;
		}
		rua_addr += chunk;
		size -= chunk;
		if((!clear) && (user_addr != NULL)) user_addr += chunk;
	}
#else
	BaseAddr = (RMuint8 *)rua_addr;
	chunk = 0;
	err = RM_OK;
	if((!clear) && (user_addr != NULL))
		RMMemcpy(BaseAddr, user_addr, size);
	else
		RMMemset(BaseAddr, clearwith, size);
#endif
	return RM_OK;
}

RMstatus DCCClearOSDVideoSource(struct DCCVideoSource *pVideoSource)
{
	return DCCClearOSDPicture(pVideoSource, 0);
}

RMstatus DCCClearOSDPicture(struct DCCVideoSource *pVideoSource, RMuint32 index)
{
	RMuint32 Y_addr, Y_size, UV_addr, UV_size;
	RMstatus err;

	err = DCCGetOSDPictureInfo(pVideoSource, index, NULL, &Y_addr, &Y_size, &UV_addr, &UV_size);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get OSD video info, %s\n", RMstatusToString(err)));
		return err;
	}

	err = set_memory(pVideoSource->pRUA, Y_addr, Y_size, (RMuint8 *)NULL, TRUE, 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot clear memory of Luma Buffer 0x%08lx 0x%08lx, %s\n", Y_addr, Y_size, RMstatusToString(err)));
		return err;
	}

	if ((UV_addr != 0) && (UV_size > 0)) {
		err = set_memory(pVideoSource->pRUA, UV_addr, UV_size, (RMuint8 *)NULL, TRUE, 128);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot clear memory of Chroma Buffer 0x%08lx 0x%08lx, %s\n", UV_addr, UV_size, RMstatusToString(err)));
			return err;
		}
	}

	return RM_OK;
}

RMstatus DCCSetOSDVideoSource(struct DCCVideoSource *pVideoSource, RMuint8 * pUserLuma, RMuint8 * pUserChroma)
{
	return DCCSetOSDPicture(pVideoSource, 0, pUserLuma, pUserChroma);
}

RMstatus DCCSetOSDPicture(struct DCCVideoSource *pVideoSource, RMuint32 index, RMuint8 * pUserLuma, RMuint8 * pUserChroma)
{
	RMuint32 Y_addr, Y_size, UV_addr, UV_size;
	RMstatus err;

	err = DCCGetOSDPictureInfo(pVideoSource, index, NULL, &Y_addr, &Y_size, &UV_addr, &UV_size);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get OSD video info, %s\n", RMstatusToString(err)));
		return err;
	}
	
	err = set_memory(pVideoSource->pRUA, Y_addr, Y_size, pUserLuma, FALSE, 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set memory of Luma Buffer 0x%08lx 0x%08lx, %s\n", Y_addr, Y_size, RMstatusToString(err)));
		return err;
	}
	
	if ((UV_addr != 0) && (UV_size > 0)) {
		err = set_memory(pVideoSource->pRUA, UV_addr, UV_size, pUserChroma, FALSE, 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set memory of Chroma Buffer 0x%08lx 0x%08lx, %s\n", UV_addr, UV_size, RMstatusToString(err)));
			return err;
		}
	}

	return RM_OK;
}

RMstatus DCCInsertPictureInMultiplePictureOSDVideoSource(struct DCCVideoSource *pVideoSource, RMuint32 index, RMuint64 Pts)
{
	RMstatus err;
	struct DisplayBlock_InsertPictureInSurfaceFifo_type param;

	RMASSERT(pVideoSource);
	RMASSERT(pVideoSource->pictures);


	param.Surface = pVideoSource->surface;
	param.Picture = pVideoSource->pictures[index].picture_addr;
	param.Pts = Pts;
	err = RUASetProperty(pVideoSource->pRUA, DisplayBlock, RMDisplayBlockPropertyID_InsertPictureInSurfaceFifo, &param, sizeof(param), 0);
	if (RMFAILED(err)){
		RMDBGLOG((ENABLE, "Cannot insert picture into surface, %s\n", RMstatusToString(err)));
		return err;
	}
	
	return err;
}
