/*****************************************
 Copyright © 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   dcc.c
  @brief  Decoding Chain Control API

  @author Julien Soulier
  @date   2003-10-02
*/

// to enable or disable the debug messages of this source file, put 1 or 0 below
#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

#include "dcc_common.h"

static RMuint32 default_rua_malloc(struct RUA *pRua, RMuint32 ModuleID, RMuint32 dramIndex, enum RUADramType dramtype, RMuint32 size)
{
	return RUAMalloc(pRua, dramIndex, dramtype, size);
}
static void default_rua_free(struct RUA *pRua, RMuint32 ptr)
{
	return RUAFree(pRua, ptr);
}

RMstatus DCCOpen(struct RUA *pRUA, struct DCC **ppDCC)
{
	struct DCC *pDCC;

	pDCC = (struct DCC *) RMMalloc(sizeof(struct DCC));
	if (pDCC == NULL) {
		return RM_FATALOUTOFMEMORY;
	}

	RMMemset(pDCC, 0, sizeof(struct DCC));
	pDCC->pRUA = pRUA;
	pDCC->dram = 0;
	pDCC->rua_malloc = default_rua_malloc;
	pDCC->rua_free = default_rua_free;

	*ppDCC = pDCC;

	RMDBGLOG((LOCALDBG, "dccOpen (RUA @ 0x%08lx DCC @0x%08lx\n", (RMuint32)pRUA, (RMuint32)pDCC));
	
	return RM_OK;
}

RMstatus DCCClose(struct DCC *pDCC)
{
	enum ProcessorState run;
	RMstatus err = RM_OK;
    
	RMASSERT(pDCC);

	RMDBGLOG((LOCALDBG, "dccClose (DCC @ 0x%08lx\n", (RMuint32)pDCC));

#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2 || EM86XX_CHIP==EM86XX_CHIPID_TANGO15)
	RMDBGLOG((ENABLE, "DCCClose TANGO2 just stops the riscs, it doesn't reset them !\n"));
	run = CPU_STOPPED; /* Prevent gbus crash for first tango2 - riscs reset and then DMEM/PMEM accessed.*/
#else
	run = CPU_RESET;
#endif

#ifndef WITH_XLOADED_UCODE
	if (pDCC->video_ucode_address) {
		/* resetting the MPEG engine */
		DCCSP(pDCC->pRUA, EMHWLIB_MODULE(MpegEngine, 0), RMMpegEnginePropertyID_State, &run, sizeof(run));
#ifdef RMFEATURE_HAS_VIDEO_ENGINE_1
		DCCSP(pDCC->pRUA, EMHWLIB_MODULE(MpegEngine, 1), RMMpegEnginePropertyID_State, &run, sizeof(run));
#endif
		pDCC->rua_free(pDCC->pRUA, pDCC->video_ucode_address);
	}
		
	if (pDCC->audio_ucode_address) {
		/* resetting the Audio engine */
		DCCSP(pDCC->pRUA, EMHWLIB_MODULE(AudioEngine, 0), RMAudioEnginePropertyID_State, &run, sizeof(run));
#ifdef RMFEATURE_HAS_AUDIO_ENGINE_1
		DCCSP(pDCC->pRUA, EMHWLIB_MODULE(AudioEngine, 1), RMAudioEnginePropertyID_State, &run, sizeof(run));
#endif
		pDCC->rua_free(pDCC->pRUA, pDCC->audio_ucode_address);
	}

	if (pDCC->demux_ucode_address) {
		/* resetting the Demux engine */
		DCCSP(pDCC->pRUA, EMHWLIB_MODULE(DemuxEngine, 0), RMDemuxEnginePropertyID_State, &run, sizeof(run));
		pDCC->rua_free(pDCC->pRUA, pDCC->demux_ucode_address);
	}
#endif /* WITH_XLOADED_UCODE */

	RMFree(pDCC);
	
	return err;
}

RMstatus DCCInitChain(struct DCC *pDCC)
{
	return DCCInitChainEx(pDCC, DCCInitMode_LeaveDisplay);
}

RMstatus DCCInitChainEx(struct DCC *pDCC, enum DCCInitMode init_mode)
{
	RMstatus err;
	RMuint32 mixer, scaler, surface;
	RMbool enable;
	struct DispMainMixer_LayerOrder_type layer;

	struct EMhwlibDisplayWindow window;
	enum EMhwlibScalingMode scalingmode;
	struct EMhwlibDownScalingMode downscalingmode;
	struct EMhwlibNonLinearScalingMode nonlinearmode;
	struct EMhwlibBlackStripMode blackstrip;
	struct EMhwlibCutStripMode cutstrip;
	enum EMhwlibDeinterlacingMode deinterlacing_mode;
	enum EMhwlibScalerFieldSelection field_selection;
	struct DispMainVideoScaler_DeinterlacingProportion_type deinterlacing_prop;
	struct DispMainVideoScaler_FilterSelection_type filtermode;
	struct EMhwlibColor color;
	RMuint32 src_index, val;
	RMint8 brightness;
	RMuint8 contrast, saturation;
	enum EMhwlibMixerSourceState state;
	struct DispOSDScaler_ScalingConfig_type scalingcfg;
	RMbool scaler_already_enabled;
	RMuint32 deinterlacing_scaler;
	struct DispMainVideoScaler_DeinterlacingMotionConfig_type deinterlacer_mode;
	RMuint32 force_interlaced_boundary;

	mixer = EMHWLIB_MODULE(DispMainMixer, 0); 
	scaler = EMHWLIB_MODULE(DispMainVideoScaler, 0);

	RMDBGLOG((LOCALDBG, "dccInitChainEx DCC @ 0x%08lx\n", (RMuint32)pDCC));

	if ( init_mode == DCCInitMode_LeaveDisplay ){
		/* Don't reset the whole chain if scaler already enabled */
		err = RUAGetProperty(pDCC->pRUA, scaler, RMGenericPropertyID_Enable, &scaler_already_enabled, sizeof(RMbool));
		if (err != RM_OK) {
			RMDBGLOG((ENABLE, "Cannot get Property %d on module %d, %s\n", RMGenericPropertyID_Enable, scaler, RMstatusToString(err)));
			return err;
		}

		if (scaler_already_enabled){
			RMDBGLOG((ENABLE, "Display already configured and initDisplay=FALSE. Do not reconfigure it!\n"));
			return RM_OK;
		}
	}
	
	
	/* set up VCR Mixer */
#ifdef RMFEATURE_HAS_VCR_MIXER
	{
		struct DispVCRMixer_LayerOrder_type vcr_layer;
		RMuint32 vcr_mixer, vcr_scaler;
		
		vcr_mixer = EMHWLIB_MODULE(DispVCRMixer, 0); 
		
		vcr_layer.Layer0SourceModuleID = EMHWLIB_MODULE(DispCRTMultiScaler, 0);
		vcr_layer.Layer1SourceModuleID = EMHWLIB_MODULE(DispVCRMultiScaler, 0);
		vcr_layer.Layer2SourceModuleID = EMHWLIB_MODULE(DispGFXMultiScaler, 0);
		vcr_layer.Layer3SourceModuleID = EMHWLIB_MODULE(DispSubPictureScaler, 0);
		DCCSP(pDCC->pRUA, vcr_mixer, RMDispVCRMixerPropertyID_LayerOrder, &vcr_layer, sizeof(vcr_layer));
		
		color.R_Cr = 128;
		color.G_Y = 64;
		color.B_Cb = 128;
		DCCSP(pDCC->pRUA, vcr_mixer, RMGenericPropertyID_BackgroundColor, &color, sizeof(color));
		
		enable = TRUE;
		DCCSP(pDCC->pRUA, vcr_mixer, RMGenericPropertyID_ForceBackGround, &enable, sizeof(enable));
		
		DCCSP(pDCC->pRUA, vcr_mixer, RMGenericPropertyID_Validate, NULL, 0);
		
		enable = TRUE;
		DCCSP(pDCC->pRUA, vcr_mixer, RMGenericPropertyID_Enable, &enable, sizeof(enable));
		
		
		/* put all Scaler of the VCRMixer in "slave" mode, to avoid them being handled twice. */
		
		vcr_scaler = EMHWLIB_MODULE(DispVCRMultiScaler, 0);
		err = RUAExchangeProperty(pDCC->pRUA, vcr_mixer, RMGenericPropertyID_MixerSourceIndex, &vcr_scaler, sizeof(vcr_scaler), &src_index, sizeof(src_index));
		if (err != RM_OK) {
			RMDBGLOG((ENABLE, "Cannot get scaler index, %s\n", RMstatusToString(err)));
			return err;
		}
		vcr_mixer = EMHWLIB_TARGET_MODULE(EMHWLIB_MODULE_CATEGORY(vcr_mixer), EMHWLIB_MODULE_INDEX(vcr_mixer), src_index);
		state = EMhwlibMixerSourceState_Slave;
		DCCSP(pDCC->pRUA, vcr_mixer, RMGenericPropertyID_MixerSourceState, &state, sizeof(state));
		
		vcr_scaler = EMHWLIB_MODULE(DispCRTMultiScaler, 0);
		err = RUAExchangeProperty(pDCC->pRUA, vcr_mixer, RMGenericPropertyID_MixerSourceIndex, &vcr_scaler, sizeof(vcr_scaler), &src_index, sizeof(src_index));
		if (err != RM_OK) {
			RMDBGLOG((ENABLE, "Cannot get scaler index, %s\n", RMstatusToString(err)));
			return err;
		}
		vcr_mixer = EMHWLIB_TARGET_MODULE(EMHWLIB_MODULE_CATEGORY(vcr_mixer), EMHWLIB_MODULE_INDEX(vcr_mixer), src_index);
		state = EMhwlibMixerSourceState_Slave;
		DCCSP(pDCC->pRUA, vcr_mixer, RMGenericPropertyID_MixerSourceState, &state, sizeof(state));
		
		vcr_scaler = EMHWLIB_MODULE(DispGFXMultiScaler, 0);
		err = RUAExchangeProperty(pDCC->pRUA, vcr_mixer, RMGenericPropertyID_MixerSourceIndex, &vcr_scaler, sizeof(vcr_scaler), &src_index, sizeof(src_index));
		if (err != RM_OK) {
			RMDBGLOG((ENABLE, "Cannot get scaler index, %s\n", RMstatusToString(err)));
			return err;
		}
		vcr_mixer = EMHWLIB_TARGET_MODULE(EMHWLIB_MODULE_CATEGORY(vcr_mixer), EMHWLIB_MODULE_INDEX(vcr_mixer), src_index);
		state = EMhwlibMixerSourceState_Slave;
		DCCSP(pDCC->pRUA, vcr_mixer, RMGenericPropertyID_MixerSourceState, &state, sizeof(state));
		
		vcr_scaler = EMHWLIB_MODULE(DispSubPictureScaler, 0);
		err = RUAExchangeProperty(pDCC->pRUA, vcr_mixer, RMGenericPropertyID_MixerSourceIndex, &vcr_scaler, sizeof(vcr_scaler), &src_index, sizeof(src_index));
		if (err != RM_OK) {
			RMDBGLOG((ENABLE, "Cannot get scaler index, %s\n", RMstatusToString(err)));
			return err;
		}
		vcr_mixer = EMHWLIB_TARGET_MODULE(EMHWLIB_MODULE_CATEGORY(vcr_mixer), EMHWLIB_MODULE_INDEX(vcr_mixer), src_index);
		state = EMhwlibMixerSourceState_Slave;
		DCCSP(pDCC->pRUA, vcr_mixer, RMGenericPropertyID_MixerSourceState, &state, sizeof(state));
	}
#endif
	
	/* set up Main Mixer and connect Main Video Scaler to it */
	layer.Layer0SourceModuleID = EMHWLIB_MODULE(DispCRTMultiScaler, 0);
	layer.Layer1SourceModuleID = EMHWLIB_MODULE(DispVCRMultiScaler, 0);
	layer.Layer2SourceModuleID = EMHWLIB_MODULE(DispMainVideoScaler, 0);
	layer.Layer3SourceModuleID = EMHWLIB_MODULE(DispGFXMultiScaler, 0);
	layer.Layer4SourceModuleID = EMHWLIB_MODULE(DispOSDScaler, 0);
	layer.Layer5SourceModuleID = EMHWLIB_MODULE(DispSubPictureScaler, 0);
	layer.Layer6SourceModuleID = EMHWLIB_MODULE(DispGraphicInput, 0);
	DCCSP(pDCC->pRUA, mixer, RMDispMainMixerPropertyID_LayerOrder, &layer, sizeof(layer));

	color.R_Cr = 128;
	color.G_Y = 16;
	color.B_Cb = 128;
	DCCSP(pDCC->pRUA, mixer, RMGenericPropertyID_BackgroundColor, &color, sizeof(color));

	enable = TRUE;
	DCCSP(pDCC->pRUA, mixer, RMGenericPropertyID_ForceBackGround, &enable, sizeof(enable));

	err = RUAExchangeProperty(pDCC->pRUA, mixer, RMGenericPropertyID_MixerSourceIndex, &scaler, sizeof(scaler), &src_index, sizeof(src_index));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get scaler index, %s\n", RMstatusToString(err)));
		return err;
	}
	mixer = EMHWLIB_TARGET_MODULE(DispMainMixer, 0 , src_index);

	window.X = 0;
	window.Y = 0;
	window.Width = 4096;
	window.Height = 4096;
	window.XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
	window.YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
	window.XMode = EMhwlibDisplayWindowValueMode_Relative;
	window.YMode = EMhwlibDisplayWindowValueMode_Relative;
	window.WidthMode = EMhwlibDisplayWindowValueMode_Relative;
	window.HeightMode = EMhwlibDisplayWindowValueMode_Relative;
	DCCSP(pDCC->pRUA, mixer, RMGenericPropertyID_MixerSourceWindow, &window, sizeof(window));

	state = EMhwlibMixerSourceState_Master;
	DCCSP(pDCC->pRUA, mixer, RMGenericPropertyID_MixerSourceState, &state, sizeof(state));

	DCCSP(pDCC->pRUA, mixer, RMGenericPropertyID_Validate, NULL, 0);

	enable = TRUE;
	DCCSP(pDCC->pRUA, mixer, RMGenericPropertyID_Enable, &enable, sizeof(enable));
	
	
	/* set up Main Video Scaler */
	
	surface = 0;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Surface, &surface, sizeof(surface));

	window.X = 0;
	window.Y = 0;
	window.Width = 4096;
	window.Height = 4096;
	window.XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
	window.YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
	window.XMode = EMhwlibDisplayWindowValueMode_Relative;
	window.YMode = EMhwlibDisplayWindowValueMode_Relative;
	window.WidthMode = EMhwlibDisplayWindowValueMode_Relative;
	window.HeightMode = EMhwlibDisplayWindowValueMode_Relative;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_ScalerInputWindow, &window, sizeof(window));

	scalingmode = EMhwlibScalingMode_LetterBox;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_ScalingMode, &scalingmode, sizeof(scalingmode));

	field_selection = EMhwlibScalerFieldSelection_BestFieldType;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_ScalerFieldSelection, &field_selection, sizeof(field_selection));

	filtermode.Boundary_0_1 = 0x1400;
	filtermode.Boundary_1_2 = 0x1c00;
	filtermode.Boundary_2_3 = 0x2c00;
	DCCSP(pDCC->pRUA, scaler, RMDispMainVideoScalerPropertyID_FilterSelection, &filtermode, sizeof(filtermode));

	downscalingmode.Discard = FALSE;
	downscalingmode.FilterBoundary[0] = 384;
	downscalingmode.FilterBoundary[1] = 256;
	downscalingmode.FilterBoundary[2] = 128;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_DownScalingMode, &downscalingmode, sizeof(downscalingmode));
	
	nonlinearmode.Width = 0;
	nonlinearmode.Level = 0;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_NonLinearScalingMode, &nonlinearmode, sizeof(nonlinearmode));

	blackstrip.Horizontal = 4096;
 	blackstrip.Vertical = 4096;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_BlackStripMode, &blackstrip, sizeof(blackstrip));

	cutstrip.Horizontal = 0;
 	cutstrip.Vertical = 0;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_CutStripMode, &cutstrip, sizeof(cutstrip));
	
	deinterlacing_mode = EMhwlibDeinterlacingMode_Discard_Bob;
	DCCSP(pDCC->pRUA, scaler, RMDispMainVideoScalerPropertyID_DeinterlacingMode, &deinterlacing_mode, sizeof(deinterlacing_mode));

	deinterlacing_prop.NewLineProportion = 12;
	deinterlacing_prop.ExistingLineProportion = 4;
	DCCSP(pDCC->pRUA, scaler, RMDispMainVideoScalerPropertyID_DeinterlacingProportion, &deinterlacing_prop, sizeof(deinterlacing_prop));
	
	deinterlacer_mode.Value0 = 0x00;
	deinterlacer_mode.Value8 = 0x04;
	deinterlacer_mode.Value16 = 0x40;
	deinterlacer_mode.Value32 = 0xC0;
	DCCSP(pDCC->pRUA, scaler, RMDispMainVideoScalerPropertyID_DeinterlacingMotionConfig, &deinterlacer_mode, sizeof(deinterlacer_mode));

	deinterlacing_scaler = EMHWLIB_MODULE(DispGFXMultiScaler, 0);
	DCCSP(pDCC->pRUA, scaler, RMDispMainVideoScalerPropertyID_DeinterlacingMotionScaler, &deinterlacing_scaler, sizeof(deinterlacing_scaler));

	val = 0x80;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Alpha0, &val, sizeof(val));

	brightness = 0;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Brightness, &brightness, sizeof(brightness));

	contrast = 0x80;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Contrast, &contrast, sizeof(contrast));

	saturation = 0x80;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_CbSaturation, &saturation, sizeof(saturation));

	saturation = 0x80;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_CrSaturation, &saturation, sizeof(saturation));

	force_interlaced_boundary = 0x100;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_ForceInterlacedBoundary, &force_interlaced_boundary, sizeof(force_interlaced_boundary));

	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Validate, NULL, 0);

	enable = TRUE;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Enable, &enable, sizeof(enable));

	/* -------------------------------- */
	
	
	/* set up OSD Scaler and connect to Main Mixer */
	
	scaler = EMHWLIB_MODULE(DispOSDScaler, 0);
	err = RUAExchangeProperty(pDCC->pRUA, mixer, RMGenericPropertyID_MixerSourceIndex, &scaler, sizeof(scaler), &src_index, sizeof(src_index));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get scaler index, %s\n", RMstatusToString(err)));
		return err;
	}
	mixer = EMHWLIB_TARGET_MODULE(DispMainMixer, 0 , src_index);

	window.X = 0;
	window.Y = 0;
	window.Width = 4096;
	window.Height = 4096;
	window.XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
	window.YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
	window.XMode = EMhwlibDisplayWindowValueMode_Relative;
	window.YMode = EMhwlibDisplayWindowValueMode_Relative;
	window.WidthMode = EMhwlibDisplayWindowValueMode_Relative;
	window.HeightMode = EMhwlibDisplayWindowValueMode_Relative;
	DCCSP(pDCC->pRUA, mixer, RMGenericPropertyID_MixerSourceWindow, &window, sizeof(window));

	state = EMhwlibMixerSourceState_Master;
	DCCSP(pDCC->pRUA, mixer, RMGenericPropertyID_MixerSourceState, &state, sizeof(state));

	DCCSP(pDCC->pRUA, mixer, RMGenericPropertyID_Validate, NULL, 0);
	
	surface = 0;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Surface, &surface, sizeof(surface));

	window.X = 0;
	window.Y = 0;
	window.Width = 4096;
	window.Height = 4096;
	window.XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
	window.YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
	window.XMode = EMhwlibDisplayWindowValueMode_Relative;
	window.YMode = EMhwlibDisplayWindowValueMode_Relative;
	window.WidthMode = EMhwlibDisplayWindowValueMode_Relative;
	window.HeightMode = EMhwlibDisplayWindowValueMode_Relative;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_ScalerInputWindow, &window, sizeof(window));

	scalingcfg.Taps = 1;
	scalingcfg.AdaptativeEnable = TRUE;
	scalingcfg.AntiFlickerColor = 2;
	scalingcfg.AntiFlickerAlpha = 2;
	DCCSP(pDCC->pRUA, scaler, RMDispOSDScalerPropertyID_ScalingConfig, &scalingcfg, sizeof(scalingcfg));

	field_selection = EMhwlibScalerFieldSelection_BestFieldType;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_ScalerFieldSelection, &field_selection, sizeof(field_selection));

	val = 0x80;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Alpha0, &val, sizeof(val));

	force_interlaced_boundary = 0x100;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_ForceInterlacedBoundary, &force_interlaced_boundary, sizeof(force_interlaced_boundary));

	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Validate, NULL, 0);

	enable = TRUE;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Enable, &enable, sizeof(enable));

	/* -------------------------------- */
	
	/* connect GFX Multi Scaler to Main Mixer */
 	scaler = EMHWLIB_MODULE(DispGFXMultiScaler, 0);
	brightness = 0;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Brightness, &brightness, sizeof(brightness));

	contrast = 0x80;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Contrast, &contrast, sizeof(contrast));

	saturation = 0x80;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_CbSaturation, &saturation, sizeof(saturation));

	saturation = 0x80;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_CrSaturation, &saturation, sizeof(saturation));

	val = 0x80;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Alpha0, &val, sizeof(val));

	force_interlaced_boundary = 0x100;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_ForceInterlacedBoundary, &force_interlaced_boundary, sizeof(force_interlaced_boundary));
	
	enable = TRUE;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Enable, &enable, sizeof(enable));
	
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Validate, NULL, 0);


	err = RUAExchangeProperty(pDCC->pRUA, mixer, RMGenericPropertyID_MixerSourceIndex, &scaler, sizeof(scaler), &src_index, sizeof(src_index));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get scaler index, %s\n", RMstatusToString(err)));
		return err;
	}
	mixer = EMHWLIB_TARGET_MODULE(DispMainMixer, 0 , src_index);

	state = EMhwlibMixerSourceState_Slave;
	DCCSP(pDCC->pRUA, mixer, RMGenericPropertyID_MixerSourceState, &state, sizeof(state));

	DCCSP(pDCC->pRUA, mixer, RMGenericPropertyID_Validate, NULL, 0);

#ifdef RMFEATURE_HAS_SPU_SCALER
	/* connect SPU scaler to Main Mixer */
 	scaler = EMHWLIB_MODULE(DispSubPictureScaler, 0);
	
	enable = TRUE;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Enable, &enable, sizeof(enable));
	
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Validate, NULL, 0);

	err = RUAExchangeProperty(pDCC->pRUA, mixer, RMGenericPropertyID_MixerSourceIndex, &scaler, sizeof(scaler), &src_index, sizeof(src_index));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get scaler index, %s\n", RMstatusToString(err)));
		return err;
	}
	mixer = EMHWLIB_TARGET_MODULE(DispMainMixer, 0 , src_index);

	state = EMhwlibMixerSourceState_Slave;
	DCCSP(pDCC->pRUA, mixer, RMGenericPropertyID_MixerSourceState, &state, sizeof(state));

	DCCSP(pDCC->pRUA, mixer, RMGenericPropertyID_Validate, NULL, 0);
#endif

	/* basic init of other scaler */
	
#ifdef RMFEATURE_HAS_VCR_SCALER
 	scaler = EMHWLIB_MODULE(DispVCRMultiScaler, 0);
	brightness = 0;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Brightness, &brightness, sizeof(brightness));
	contrast = 0x80;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Contrast, &contrast, sizeof(contrast));
	saturation = 0x80;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_CbSaturation, &saturation, sizeof(saturation));
	saturation = 0x80;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_CrSaturation, &saturation, sizeof(saturation));

	enable = TRUE;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Enable, &enable, sizeof(enable));
	val = 0x80;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Alpha0, &val, sizeof(val));

	force_interlaced_boundary = 0x100;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_ForceInterlacedBoundary, &force_interlaced_boundary, sizeof(force_interlaced_boundary));
	
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Validate, NULL, 0);

	err = RUAExchangeProperty(pDCC->pRUA, mixer, RMGenericPropertyID_MixerSourceIndex, &scaler, sizeof(scaler), &src_index, sizeof(src_index));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get scaler index, %s\n", RMstatusToString(err)));
		return err;
	}
	mixer = EMHWLIB_TARGET_MODULE(DispMainMixer, 0 , src_index);

	state = EMhwlibMixerSourceState_Slave;
	DCCSP(pDCC->pRUA, mixer, RMGenericPropertyID_MixerSourceState, &state, sizeof(state));

	DCCSP(pDCC->pRUA, mixer, RMGenericPropertyID_Validate, NULL, 0);
#endif

#ifdef RMFEATURE_HAS_CRT_SCALER
 	scaler = EMHWLIB_MODULE(DispCRTMultiScaler, 0);
	brightness = 0;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Brightness, &brightness, sizeof(brightness));
	contrast = 0x80;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Contrast, &contrast, sizeof(contrast));
	saturation = 0x80;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_CbSaturation, &saturation, sizeof(saturation));
	saturation = 0x80;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_CrSaturation, &saturation, sizeof(saturation));
	force_interlaced_boundary = 0x100;
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_ForceInterlacedBoundary, &force_interlaced_boundary, sizeof(force_interlaced_boundary));
	DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Validate, NULL, 0);
#endif

	return RM_OK;
}

RMstatus DCCInitMicroCode(struct DCC *pDCC)
{
	return DCCInitMicroCodeEx(pDCC, DCCInitMode_LeaveDisplay);
}

RMstatus DCCInitMicroCodeEx(struct DCC *pDCC, enum DCCInitMode init_mode)
{
	RMstatus err;

	RMDBGLOG((LOCALDBG, "dccInitMicroCodeEx DCC @ 0x%08lx\n", (RMuint32)pDCC));

	// Initialize Demux microcode
	err = DCCInitSpecificMicroCode(pDCC, DCCMicrocode_Demux);
	if (RMFAILED(err))
	{
		RMDBGLOG((ENABLE, "Error %s: cannot initialize demux microcode.\n", RMstatusToString(err)));
		return err;
	}
	
	// Initialize MPEG engine (Video RISC)
	err = DCCInitSpecificMicroCode(pDCC, DCCMicrocode_Video);
	if (RMFAILED(err))
	{
		RMDBGLOG((ENABLE, "Error %s: cannot initialize video microcode.\n", RMstatusToString(err)));
		return err;
	}
	
	// resetting the Audio Engine(s)
	err = DCCInitSpecificMicroCode(pDCC, DCCMicrocode_Audio);
	if (RMFAILED(err))
	{
		RMDBGLOG((ENABLE, "Error %s: cannot initialize audio microcode.\n", RMstatusToString(err)));
		return err;
	}

	return DCCInitChainEx(pDCC, init_mode);
}

#ifndef WITH_XLOADED_UCODE
static RMstatus init_video_microcode(struct DCC *pDCC)
{
	enum ProcessorState run;
	RMstatus err = RM_OK;
	struct MpegEngine_MicrocodeDRAMSize_in_type video_size_in;
 	struct MpegEngine_MicrocodeDRAMSize_out_type video0_size_out;
#ifdef RMFEATURE_HAS_VIDEO_ENGINE_1
	struct MpegEngine_MicrocodeDRAMSize_out_type video1_size_out;
#endif
	struct MpegEngine_Microcode_type video_ucode;
	RMuint32 mpeg_engine0 = EMHWLIB_MODULE(MpegEngine, 0);  
#ifdef RMFEATURE_HAS_VIDEO_ENGINE_1
	RMuint32 mpeg_engine1 = EMHWLIB_MODULE(MpegEngine, 1);  
#endif
	RMuint32 video_size_out;

	RMDBGLOG((LOCALDBG, "dcc_init_video_microcode DCC @ 0x%08lx\n", (RMuint32)pDCC));

	// resetting the MPEG engine
	run = CPU_RESET;
	DCCSP(pDCC->pRUA, mpeg_engine0, RMMpegEnginePropertyID_State, &run, sizeof run);
		
	run = CPU_STOPPED;
	DCCSP(pDCC->pRUA, mpeg_engine0, RMMpegEnginePropertyID_State, &run, sizeof run);
#ifdef RMFEATURE_HAS_VIDEO_ENGINE_1
	run = CPU_RESET;
	DCCSP(pDCC->pRUA, mpeg_engine1, RMMpegEnginePropertyID_State, &run, sizeof(run));

	run = CPU_STOPPED;
	DCCSP(pDCC->pRUA, mpeg_engine1, RMMpegEnginePropertyID_State, &run, sizeof(run));
#endif
	video_size_in.MicrocodeVersion = 1;
	err = RUAExchangeProperty(pDCC->pRUA, 
				  mpeg_engine0, 
				  RMMpegEnginePropertyID_MicrocodeDRAMSize, 
				  &video_size_in, sizeof video_size_in, 
				  &video0_size_out, sizeof video0_size_out);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting property RMMpegEnginePropertyID_MicrocodeDRAMSize! %s\n", RMstatusToString(err)));
		return err;
	}
	video_size_out = video0_size_out.Size;
	
#ifdef RMFEATURE_HAS_VIDEO_ENGINE_1
	video_size_in.MicrocodeVersion = 1; // Same microcode for now; could be different in the future
	err = RUAExchangeProperty(pDCC->pRUA, 
				  mpeg_engine1, 
				  RMMpegEnginePropertyID_MicrocodeDRAMSize, 
				  &video_size_in, sizeof video_size_in, 
				  &video1_size_out, sizeof video1_size_out);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting property RMMpegEnginePropertyID_MicrocodeDRAMSize! %s\n", RMstatusToString(err)));
		return err;
	}
	// Allocate 4 more bytes to guaranty alignment for second microcode instance that 
	// will be store at the address of the first microcode + size of the first microcode. 
	// Microcode DRAM base address has to be aligned on 4 bytes. Failure to do this results.
	video_size_out += video1_size_out.Size + 2;
#endif

	video_ucode.MicrocodeVersion = video_size_in.MicrocodeVersion;
	if (video_size_out) {
		/* allocate only once per DCC instance */
		if (!pDCC->video_ucode_address) {
			pDCC->video_ucode_address = pDCC->rua_malloc(pDCC->pRUA, mpeg_engine0, 0, RUA_DRAM_CACHED, video_size_out);
			if (!pDCC->video_ucode_address) {
				RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in cached DRAM %d!\n", video_size_out, 0));
				return RM_FATALOUTOFMEMORY;
			}
		}
		video_ucode.Address = pDCC->video_ucode_address;
		RMDBGLOG((LOCALDBG, "video ucode cached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n", video_ucode.Address, video_size_out, video_ucode.Address + video_size_out));
	}
	else {
		video_ucode.Address = 0;
		RMDBGLOG((LOCALDBG, "video ucode doesn't need DRAM\n"));
	}
		
	DCCSP(pDCC->pRUA, mpeg_engine0, RMMpegEnginePropertyID_Microcode, &video_ucode, sizeof video_ucode);
#ifdef RMFEATURE_HAS_VIDEO_ENGINE_1
	// Size may not be a multiple of 4. We need to align.
	video_ucode.Address = pDCC->video_ucode_address + ((video0_size_out.Size + 3) & 0xFFFFFFC); 
	DCCSP(pDCC->pRUA, mpeg_engine1, RMMpegEnginePropertyID_Microcode, &video_ucode, sizeof video_ucode);
#endif
	
	// starting the MPEG Engine
	run = CPU_RUNNING;
	DCCSP(pDCC->pRUA, mpeg_engine0, RMMpegEnginePropertyID_State, &run, sizeof(run));
#ifdef RMFEATURE_HAS_VIDEO_ENGINE_1
	DCCSP(pDCC->pRUA, mpeg_engine1, RMMpegEnginePropertyID_State, &run, sizeof(run));
#endif

#if (EM86XX_CHIP<EM86XX_CHIPID_TANGO2)
	{
		struct PLL_RouteClockFromPLL_type rcfp;
		rcfp.PLL = PLLGen_pll_3;
		rcfp.PLLOutput = PLLOut_1;
		rcfp.Clock = ClockSignal_sel;
		DCCSP(pDCC->pRUA, PLL, RMPLLPropertyID_RouteClockFromPLL, &rcfp, sizeof(rcfp));
	}
#endif
		return err;
}

static RMstatus init_audio_microcode(struct DCC *pDCC)
{
	enum ProcessorState run;
	RMstatus err = RM_OK;

	struct AudioEngine_MicrocodeDRAMSize_in_type audio_size_in;
	struct AudioEngine_MicrocodeDRAMSize_out_type audio0_size_out;
#ifdef RMFEATURE_HAS_AUDIO_ENGINE_1
	struct AudioEngine_MicrocodeDRAMSize_out_type audio1_size_out;
#endif
	struct AudioEngine_Microcode_type audio_ucode;
	RMuint32 audio_engine0 = EMHWLIB_MODULE(AudioEngine, 0);  
#ifdef RMFEATURE_HAS_AUDIO_ENGINE_1
	RMuint32 audio_engine1 = EMHWLIB_MODULE(AudioEngine, 1);  
#endif
	RMuint32 audio_size_out;

	RMDBGLOG((LOCALDBG, "dcc_init_audio_microcode DCC @ 0x%08lx\n", (RMuint32)pDCC));

	// resetting the Audio Engine(s)
	run = CPU_RESET;
	DCCSP(pDCC->pRUA, audio_engine0, RMAudioEnginePropertyID_State, &run, sizeof run);
		
	run = CPU_STOPPED;
	DCCSP(pDCC->pRUA, audio_engine0, RMAudioEnginePropertyID_State, &run, sizeof run);
#ifdef RMFEATURE_HAS_AUDIO_ENGINE_1
	run = CPU_RESET;
	DCCSP(pDCC->pRUA, audio_engine1, RMAudioEnginePropertyID_State, &run, sizeof run);
			
	run = CPU_STOPPED;
	DCCSP(pDCC->pRUA, audio_engine1, RMAudioEnginePropertyID_State, &run, sizeof run);
#endif
	
	audio_size_in.MicrocodeVersion = 1;
	err = RUAExchangeProperty(pDCC->pRUA, audio_engine0, 
			RMAudioEnginePropertyID_MicrocodeDRAMSize, 
			&audio_size_in, sizeof(audio_size_in), 
			&audio0_size_out, sizeof(audio0_size_out));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting property RMAudioEnginePropertyID_MicrocodeDRAMSize! %s\n", RMstatusToString(err)));
		return err;
	}
	audio_size_out = audio0_size_out.Size;
#ifdef RMFEATURE_HAS_AUDIO_ENGINE_1
	audio_size_in.MicrocodeVersion = 1;
	err = RUAExchangeProperty(pDCC->pRUA, 
				  audio_engine1, 
				  RMAudioEnginePropertyID_MicrocodeDRAMSize, 
				  &audio_size_in, sizeof(audio_size_in), 
				  &audio1_size_out, sizeof(audio1_size_out));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting property RMAudioEnginePropertyID_MicrocodeDRAMSize! %s\n", RMstatusToString(err)));
		return err;
	}
	audio_size_out += audio1_size_out.Size;
#endif

	audio_ucode.MicrocodeVersion = audio_size_in.MicrocodeVersion;
	if (audio_size_out) {
		/* allocate only once per DCC instance */
		if (!pDCC->audio_ucode_address) {
			pDCC->audio_ucode_address = pDCC->rua_malloc(pDCC->pRUA, audio_engine0, 0, RUA_DRAM_CACHED, audio_size_out);
			if (!pDCC->audio_ucode_address)	{
				RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in cached DRAM %lu!\n", audio_size_out, 0L));
				return RM_FATALOUTOFMEMORY;
			}
		}
		audio_ucode.Address = pDCC->audio_ucode_address;
		RMDBGLOG((LOCALDBG, "audio ucode cached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n", audio_ucode.Address, audio_size_out, audio_ucode.Address + audio_size_out));
	}
	else {
		audio_ucode.Address = 0;
		RMDBGLOG((LOCALDBG, "audio ucode doesn't need DRAM\n"));
	}
	
	DCCSP(pDCC->pRUA, audio_engine0, RMAudioEnginePropertyID_Microcode, &audio_ucode, sizeof(audio_ucode));
#ifdef RMFEATURE_HAS_AUDIO_ENGINE_1
	audio_ucode.Address = pDCC->audio_ucode_address + audio0_size_out.Size;
	DCCSP(pDCC->pRUA, audio_engine1, RMAudioEnginePropertyID_Microcode, &audio_ucode, sizeof(audio_ucode));
#endif
	
	run = CPU_RUNNING;
	DCCSP(pDCC->pRUA, audio_engine0, RMAudioEnginePropertyID_State, &run, sizeof(run));
#ifdef RMFEATURE_HAS_AUDIO_ENGINE_1
	run = CPU_RUNNING;
	DCCSP(pDCC->pRUA, audio_engine1, RMAudioEnginePropertyID_State, &run, sizeof(run));
#endif
	return err;
}

static RMstatus init_demux_microcode(struct DCC *pDCC)
{
	enum ProcessorState run;
	RMstatus err = RM_OK;
	struct DemuxEngine_MicrocodeDRAMSize_in_type demux_size_in;
	struct DemuxEngine_MicrocodeDRAMSize_out_type demux_size_out;
	struct DemuxEngine_Microcode_type demux_ucode;
	RMuint32 demux_engine = EMHWLIB_MODULE(DemuxEngine, 0);

	RMDBGLOG((LOCALDBG, "dcc_init_demux_microcode DCC @ 0x%08lx\n", (RMuint32)pDCC));

	run = CPU_RESET;
	DCCSP(pDCC->pRUA, demux_engine, RMDemuxEnginePropertyID_State, &run, sizeof run);
		
	run = CPU_STOPPED;
	DCCSP(pDCC->pRUA, demux_engine, RMDemuxEnginePropertyID_State, &run, sizeof run);
		
	demux_size_in.MicrocodeVersion = 1;
	err = RUAExchangeProperty(pDCC->pRUA, 
				  demux_engine, 
				  RMDemuxEnginePropertyID_MicrocodeDRAMSize,
				  &demux_size_in, sizeof demux_size_in, 
				  &demux_size_out, sizeof demux_size_out);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting property RMDemuxEnginePropertyID_MicrocodeDRAMSize!%s\n", RMstatusToString(err)));
		return err;
	}
		
	demux_ucode.MicrocodeVersion = demux_size_in.MicrocodeVersion;
	if (demux_size_out.Size) {
		/* allocate only once per DCC instance */
		if (!pDCC->demux_ucode_address) {
			pDCC->demux_ucode_address = pDCC->rua_malloc(pDCC->pRUA, demux_engine, 0, RUA_DRAM_CACHED, demux_size_out.Size);
			if (!pDCC->demux_ucode_address)	{
				RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in cached DRAM %lu!\n", demux_size_out.Size, 0L));
				return RM_FATALOUTOFMEMORY;
			}
		}
		demux_ucode.Address = pDCC->demux_ucode_address;
		RMDBGLOG((LOCALDBG, "demux ucode cached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n", demux_ucode.Address, demux_size_out.Size, demux_ucode.Address + demux_size_out.Size));
	}
	else {
		demux_ucode.Address = 0;
		RMDBGLOG((LOCALDBG, "demux ucode doesn't need DRAM\n"));
	}
	
	DCCSP(pDCC->pRUA, demux_engine, RMDemuxEnginePropertyID_Microcode, &demux_ucode, sizeof(demux_ucode));
	
	// starting the Demux Engine
	run = CPU_RUNNING;
	DCCSP(pDCC->pRUA, demux_engine, RMDemuxEnginePropertyID_State, &run, sizeof(run));

	return err;
}
#endif /* WITH_XLOADED_UCODE */

RMstatus DCCInitSpecificMicroCode(struct DCC *pDCC, enum DCCMicrocode ucode)
{
	RMstatus err = RM_OK;

#ifdef WITH_XLOADED_UCODE

	RMDBGLOG((LOCALDBG, "DCCInitSpecificMicroCode: already loaded\n"));

	if (ucode==DCCMicrocode_Demux) 
		DCCSP(pDCC->pRUA, EMHWLIB_MODULE(DemuxEngine, 0), RMDemuxEnginePropertyID_TimerInit, 0, 0);
	if (ucode==DCCMicrocode_Video) {
		DCCSP(pDCC->pRUA, EMHWLIB_MODULE(MpegEngine, 0), RMMpegEnginePropertyID_InitMicrocodeSymbols, 0, 0);
#ifdef RMFEATURE_HAS_VIDEO_ENGINE_1
		DCCSP(pDCC->pRUA, EMHWLIB_MODULE(MpegEngine, 1), RMMpegEnginePropertyID_InitMicrocodeSymbols, 0, 0);
#endif
	}
	
#else

	switch (ucode)
	{
	case DCCMicrocode_Video:
		err = init_video_microcode(pDCC);
		break;
	case DCCMicrocode_Audio:
		err = init_audio_microcode(pDCC);
		break;
	case DCCMicrocode_Demux:
		err = init_demux_microcode(pDCC);
		break;
	}

#endif

	return err;
}

RMstatus DCCSetMemoryManager(struct DCC *pDCC, RMuint8 dram)
{
	RMstatus err;
	RMuint32 category = MM;
	RMuint32 mm_instances = 0;

	RMASSERT(pDCC);
   
	err = RUAExchangeProperty(pDCC->pRUA, EMHWLIB_MODULE(Enumerator, 0), 
				  RMEnumeratorPropertyID_CategoryIDToNumberOfInstances,
				  &category, sizeof(category), &mm_instances, 
				  sizeof(mm_instances));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get memory manager count %d\n", err));
		return RM_ERROR;
	}

	if (mm_instances <= dram) {
		RMDBGLOG((ENABLE, "Only %d Dram controller, cannot access Dram %d\n", mm_instances, dram));
		return RM_ERROR;
	}	

	pDCC->dram = dram;
	return RM_OK;
}

RMstatus DCCSetMemoryManagerCallbacks(struct DCC *pDCC, DCCAllocFunc alloc_cb, DCCFreeFunc free_cb)
{
	if (alloc_cb == NULL) 
		pDCC->rua_malloc = default_rua_malloc;
	else
		pDCC->rua_malloc = alloc_cb;
	
	if (free_cb == NULL) 
		pDCC->rua_free = default_rua_free;
	else
		pDCC->rua_free = free_cb;

	return RM_OK;
}


RMuint32 DCCMalloc(struct DCC *pDCC, RMuint32 dramIndex, enum RUADramType dramtype, RMuint32 size)
{
	return pDCC->rua_malloc(pDCC->pRUA, 0, dramIndex, dramtype, size);
}

void DCCFree(struct DCC *pDCC, RMuint32 ptr)
{
	return pDCC->rua_free(pDCC->pRUA, ptr);
}

static RMstatus AddXferFifoForReceive(struct ReceiveObject_type *pReceive)
{
	RMstatus err;
	struct AddXferFIFO_type XferFIFO;
	struct DRAMSizeXferFIFO_in_type dram_in;
	struct DRAMSizeXferFIFO_out_type dram_out;
	RMuint32 buffer_size = pReceive->buffer_count * (1<<pReceive->buffer_size_log2);
	
	dram_in.XferFIFOSize = buffer_size;
	dram_in.XferFIFOCount = pReceive->buffer_count;
	err = RUAExchangeProperty(pReceive->pRUA, pReceive->targetModule, RMGenericPropertyID_DRAMSizeXferFIFO, 
		&dram_in, sizeof(dram_in), &dram_out, sizeof(dram_out));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "AddXferFifoForReceive Error getting RMGenericPropertyID_DRAMSizeXferFIFO"));
		return RM_ERROR;
	}

	XferFIFO.XferFIFOSize = buffer_size;
	XferFIFO.XferFIFOCount = pReceive->buffer_count;
	XferFIFO.CachedSize = dram_out.CachedSize;
	XferFIFO.UncachedSize = dram_out.UncachedSize;

	// alloc cached memory
	if (dram_out.CachedSize > 0) {
		XferFIFO.CachedAddress = RUAMalloc(pReceive->pRUA, 0, RUA_DRAM_CACHED, dram_out.CachedSize);
		if (!XferFIFO.CachedAddress) {
			RMDBGLOG((ENABLE, "AddXferFifoForReceive ERROR: could not allocate 0x%08lX bytes for cached DRAM !\n", XferFIFO.CachedSize));
			return RM_FATALOUTOFMEMORY;
		}
		RMDBGLOG((LOCALDBG, "AddXferFifoForReceive cached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n", XferFIFO.CachedAddress, XferFIFO.CachedSize, XferFIFO.CachedAddress + XferFIFO.CachedSize));
	}
	pReceive->CachedAddr = XferFIFO.CachedAddress;

	// alloc uncached memory
	if (dram_out.UncachedSize > 0) {
		XferFIFO.UncachedAddress = RUAMalloc(pReceive->pRUA, 0, RUA_DRAM_UNCACHED, dram_out.UncachedSize);
		if (!XferFIFO.UncachedAddress) {
			RMDBGLOG((ENABLE, "AddXferFifoForReceive ERROR: could not allocate 0x%08lX bytes for uncached DRAM !\n", XferFIFO.UncachedSize));
			return RM_FATALOUTOFMEMORY;
		}
		RMDBGLOG((LOCALDBG, "AddXferFifoForReceive uncached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n", XferFIFO.UncachedAddress, XferFIFO.UncachedSize, XferFIFO.UncachedAddress + XferFIFO.UncachedSize));
	}
	pReceive->UncachedAddr = XferFIFO.UncachedAddress;

	err = RUASetProperty(pReceive->pRUA, pReceive->targetModule, RMGenericPropertyID_AddXferFIFO, &XferFIFO, sizeof(XferFIFO), 0);

	err = RUAOpenPool(pReceive->pRUA, RUA_POOL_FORCE_DRAM_COPY | pReceive->targetModule,
		pReceive->buffer_count, pReceive->buffer_size_log2, RUA_POOL_DIRECTION_RECEIVE, &pReceive->pDMA);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "AddXferFifoForReceive Error opening RUA_POOL_DIRECTION_RECEIVE\n"));
		return RM_ERROR;
	}

	return err;
}

/* to be removed in next step of cleanup */
RMstatus DCCOpenReceive(struct Receive_type *Receive, struct ReceiveObject_type **ppR, struct RUABufferPool **ppDma)
{
	RMstatus err;
	struct ReceiveObject_type *pR;
	pR = (struct ReceiveObject_type *) RMMalloc(sizeof(struct ReceiveObject_type));
	if (pR == NULL) {
		return RM_FATALOUTOFMEMORY;
	}
	RMMemset(pR, 0, sizeof(struct ReceiveObject_type));
	RMMemcpy(pR, Receive, sizeof(struct Receive_type));
	err = AddXferFifoForReceive(pR);
	*ppDma = pR->pDMA;
	*ppR = pR;
	return err;
}

RMstatus DCCCloseReceive(struct ReceiveObject_type *pR)
{
	RMstatus err = RM_OK;
	if (pR->pDMA) {
		err = RUAClosePool(pR->pDMA);
		pR->pDMA = NULL;
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "DCCCloseReceive Error closing DMA pool: %d\n", err));
		}
	}
	if (pR->CachedAddr) {
		RUAFree(pR->pRUA, pR->CachedAddr);
		pR->CachedAddr = 0;
	}
	if (pR->UncachedAddr) {
		RUAFree(pR->pRUA, pR->UncachedAddr);
		pR->UncachedAddr = 0;
	}
	RMFree(pR);
	return err;
}

RMstatus DCCGetReceiveEvent(struct ReceiveObject_type *pR, struct RUAEvent* pEvent)
{
	pEvent->ModuleID = EMHWLIB_MODULE(EMHWLIB_MODULE_CATEGORY(pR->targetModule), EMHWLIB_MODULE_INDEX(pR->targetModule));  // remove the target
	
	//TODO depending on target and module Id get the correct event
	switch (EMHWLIB_MODULE_CATEGORY(pR->targetModule)) {
	case VideoDecoder:
		pEvent->Mask = SOFT_IRQ_EVENT_XFER_RECEIVE_READY; // SOFT_IRQ_EVENT_USER_DATA
		break;
	case DispVideoInput:
	case DispGraphicInput:
		pEvent->Mask = RUAEVENT_XFER_FIFO_READY;
		break;
	default:
		return RM_ERROR;
	}

	return RM_OK;
}

RMstatus DCCResetReceive(struct ReceiveObject_type *pR)
{
	RMstatus err = RM_OK;
	if (pR->pDMA) {
		err = RUAResetPool(pR->pDMA);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error reseting demux Pid DMA pool: %d\n", err));
		}
		err = RUAPreparePoolForReceiveData(pR->pDMA);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error preparing demux Pid DMA pool: %d\n", err));
		}
	}
	return err;
}

