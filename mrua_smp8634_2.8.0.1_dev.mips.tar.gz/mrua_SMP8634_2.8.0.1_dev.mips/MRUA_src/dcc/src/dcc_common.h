/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   dcc_common.h
  @brief  common macros and structures in dcc internal

  @author Julien Soulier
  @date   2005-03-10
*/

#ifndef __DCC_COMMON_H__
#define __DCC_COMMON_H__

#include "../include/dcc.h"
#include "../../rmdef/rmem86xxid.h"
#include "../include/dcc_macros.h"

struct DCC {
	struct RUA *pRUA;
	RMuint32 video_ucode_address;
	RMuint32 audio_ucode_address;
	RMuint32 demux_ucode_address;
	RMuint8 dram;
	DCCAllocFunc rua_malloc;
	DCCFreeFunc rua_free;
};

struct DCCVideoSource {
	struct RUA *pRUA;
	struct DCC *pDCC; /* to get the memory manager callbacks */
	RMuint32 decoder_moduleID;
	RMuint32 engine_moduleID;
	RMuint32 spu_decoder_moduleID;
	RMuint32 scaler_moduleID;
	RMuint32 spu_scaler_moduleID;
	RMuint32 mixer_moduleID;
	RMuint32 cached_address;
	RMuint32 uncached_address;
	RMuint32 spu_cached_address;
	RMuint32 spu_uncached_address;
	RMuint32 timer_number;
	RMuint32 surface;
	RMuint32 spu_surface;
	RMuint32 picture_count;
	struct DCCOSDPicture *pictures;
	RMuint32 picture_protected_address;
};

struct DCCOSDPicture {
	struct RUA *pRUA;
	RMuint32 picture_addr;
	RMuint32 Y_addr;
	RMuint32 Y_size;
	RMuint32 UV_addr;
	RMuint32 UV_size;
	RMuint32 P_addr;
	RMuint32 P_size;
	RMuint32 width;
	RMuint32 height;
};

struct DCCAudioSource {
	struct RUA *pRUA;
	struct DCC *pDCC; /* to get the memory manager callbacks */
	RMuint32 decoder_moduleID;
	RMuint32 engine_moduleID;
	RMuint32 cached_address;
	RMuint32 uncached_address;
	RMuint32 timer_number;
};

struct DCCDemuxSource {
	struct RUA *pRUA;
	struct DCC *pDCC; /* to get the memory manager callbacks */
	RMuint32 demux_moduleID;
	RMuint32 demuxProgram0_moduleID;
	RMuint32 demuxProgram1_moduleID;
	RMuint32 cached_address;
	RMuint32 uncached_address;
	RMuint32 timer_number;
};

struct DCCDemuxTask {
	struct RUA *pRUA;
	struct DCC *pDCC; /* to get the memory manager callbacks */
	RMuint32 demux_task_moduleID;
	RMuint32 protected_address;
	RMuint32 unprotected_address;
};

struct DCCSTCSource {
	struct RUA *pRUA;
	RMuint32 StcModuleId;
};

#endif // __DCC_COMMON_H__
