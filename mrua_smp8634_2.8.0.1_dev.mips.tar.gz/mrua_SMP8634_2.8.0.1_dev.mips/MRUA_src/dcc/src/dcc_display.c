/*****************************************
 Copyright © 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   dcc.c
  @brief  Decoding Chain Control API

  @author Julien Soulier
  @date   2003-10-02
*/

// to enable or disable the debug messages of this source file, put 1 or 0 below
#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

#if 0
#define OUTPORTDBG ENABLE
#else
#define OUTPORTDBG DISABLE
#endif

#include "dcc_common.h"

static RMuint32 get_mixer_moduleID(struct DCC *pDCC, RMuint32 scaler)
{
	enum RMcategoryID category = EMHWLIB_MODULE_CATEGORY(scaler);
	
	switch (category) {
	case DispVCRMultiScaler:
	case DispCRTMultiScaler:
	case DispGFXMultiScaler:
#ifdef RMFEATURE_HAS_VCR_MIXER
		{
			RMstatus err;
			enum EMhwlibMixerSourceState state;
			RMuint32 src_index;
			
			// Is scaler in master mode on VCRMixer?
			err = RUAExchangeProperty(pDCC->pRUA, 
				EMHWLIB_MODULE(DispVCRMixer, 0), 
				RMGenericPropertyID_MixerSourceIndex, 
				&category, sizeof(category), 
				&src_index, sizeof(src_index));
			if (RMSUCCEEDED(err)) {
				err = RUAGetProperty(pDCC->pRUA, 
					EMHWLIB_TARGET_MODULE(DispVCRMixer, 0, src_index), 
					RMGenericPropertyID_MixerSourceState, 
					&state, sizeof(state));
				if (RMSUCCEEDED(err) && (state == EMhwlibMixerSourceState_Master)) {
					return EMHWLIB_MODULE(DispVCRMixer, 0);
				}
			}
		}
		/* no break */
#endif
	case DispMainVideoScaler:
#ifdef RMFEATURE_HAS_SPU_SCALER
	case DispSubPictureScaler:
#endif
#ifdef RMFEATURE_HAS_VIDEO_PLANE
	case DispVideoPlane:
#endif
	case DispOSDScaler:
		return EMHWLIB_MODULE(DispMainMixer, 0);
	default:
		return 0;
	}
	
	return 0;
}


static RMstatus get_mixer_from_route(enum DCCRoute route, RMuint32 *mixer)
{
	switch (route) {
	case DCCRoute_Main:
		*mixer = EMHWLIB_MODULE(DispMainMixer, 0);
		return RM_OK;
	case DCCRoute_Secondary:
#ifdef RMFEATURE_HAS_VCR_MIXER
		*mixer = EMHWLIB_MODULE(DispVCRMixer, 0);
		return RM_OK;
#else
#ifdef RMFEATURE_HAS_VCR_CHANNEL
		*mixer = EMHWLIB_MODULE(DispVCRMultiScaler, 0);
		return RM_OK;
#else
		return RM_ERROR;
#endif
#endif
	case DCCRoute_HDSD:   /* TO BE REMOVED */
		*mixer = EMHWLIB_MODULE(DispHDSDConverter, 0);
		return RM_OK;
	case DCCRoute_ColorBars:
		*mixer = EMHWLIB_MODULE(DispColorBars, 0);
		return RM_OK;
	}
	RMDBGLOG((ENABLE, "Invalid route\n"));
	return RM_ERROR;
}


static RMstatus get_route_from_mixer( RMuint32 mixer, enum DCCRoute *route)
{
	switch (EMHWLIB_MODULE_CATEGORY(mixer)) {
	case DispMainMixer: 
#ifdef RMFEATURE_HAS_HDSD_CONVERTER
	case DispHDSDConverter:
#endif
		*route = DCCRoute_Main;
		break;
	case DispVCRMixer: 
#ifdef RMFEATURE_HAS_CRT_CHANNEL
	case DispCRTMultiScaler: 
#endif
#ifdef RMFEATURE_HAS_VCR_CHANNEL
 	case DispVCRMultiScaler: 
#endif
		*route = DCCRoute_Secondary;
		break;
	case DispColorBars: 
		*route = DCCRoute_Main;
		break;
	default:
		return RM_ERROR;
	}
	
	return RM_OK;
}





/* this makes the outport stop being slave of other outports */
static RMstatus unbind_outport(struct DCC *pDCC, RMuint32 outport_id)
{
	struct DispComponentOut_TimingResetMaster_type reset_master;
	outport_id = EMHWLIB_MODULE_CATEGORY(outport_id);
	reset_master.ResetSourceID = outport_id;
	reset_master.DelayLines = 0;
	reset_master.DelayPixels = 0;

	DCCSP(pDCC->pRUA, outport_id, RMGenericPropertyID_TimingResetMaster, &reset_master, sizeof(reset_master));
/* 	DCCSP(pDCC->pRUA, outport_id, RMGenericPropertyID_Validate, NULL, 0); */

	if(outport_id != DispDigitalOut){
		DCCSP(pDCC->pRUA, DispDigitalOut, RMGenericPropertyID_RemoveSlaveOutput, &outport_id, sizeof(outport_id));
		DCCSP(pDCC->pRUA, DispDigitalOut, RMGenericPropertyID_Validate, NULL, 0);

	}
/* 	else 	RMDBGLOG((ENABLE, "unbinding digital\n")); */
#ifdef RMFEATURE_HAS_COMPONENT_OUT
	if(outport_id != DispComponentOut){
		DCCSP(pDCC->pRUA, DispComponentOut, RMGenericPropertyID_RemoveSlaveOutput, &outport_id, sizeof(outport_id));
		DCCSP(pDCC->pRUA, DispComponentOut, RMGenericPropertyID_Validate, NULL, 0);

	}
/* 	else 	RMDBGLOG((ENABLE, "unbinding component\n")); */
#endif

	if(outport_id != DispMainAnalogOut){
		DCCSP(pDCC->pRUA, DispMainAnalogOut, RMGenericPropertyID_RemoveSlaveOutput, &outport_id, sizeof(outport_id));
		DCCSP(pDCC->pRUA, DispMainAnalogOut, RMGenericPropertyID_Validate, NULL, 0);

	}
/* 	else 	RMDBGLOG((ENABLE, "unbinding main analog\n")); */

#ifdef RMFEATURE_HAS_COMPOSITE_OUT
	if(outport_id != DispCompositeOut){
		DCCSP(pDCC->pRUA, DispCompositeOut, RMGenericPropertyID_RemoveSlaveOutput, &outport_id, sizeof(outport_id));
		DCCSP(pDCC->pRUA, DispCompositeOut, RMGenericPropertyID_Validate, NULL, 0);
	}
#endif

	return RM_OK;
}

RMstatus DCCGetRouteVCXO(enum DCCRoute route, RMuint32 *vcxo)
{
	/* connect the outport clock to the route VCXO */
	switch (route) {
	case DCCRoute_Main:
		*vcxo = EMHWLIB_MODULE(VCXO, 0);
		break;
	case DCCRoute_Secondary:
		*vcxo = EMHWLIB_MODULE(VCXO, 1);
		break;
	case DCCRoute_ColorBars:
		*vcxo = EMHWLIB_MODULE(VCXO, 2);
		break;
	default:
		RMDBGLOG((ENABLE, "Invalid route %d\n", route));
		return RM_ERROR;
	}
	
	return RM_OK;
}

RMstatus DCCSetRouteDisplayAspectRatio(struct DCC *pDCC, enum DCCRoute route, RMuint8 ar_x, RMuint8 ar_y)
{
	struct EMhwlibAspectRatio dar;
	RMuint32 mixer;
	
	switch (route) {
	case DCCRoute_Main:
		mixer = EMHWLIB_MODULE(DispMainMixer, 0);
		break;
	case DCCRoute_Secondary:
#ifdef RMFEATURE_HAS_VCR_MIXER
		mixer = EMHWLIB_MODULE(DispVCRMixer, 0);
		break;
#else
#ifdef RMFEATURE_HAS_VCR_CHANNEL
		return RM_NOTIMPLEMENTED;
#else
		return RM_ERROR;
#endif
#endif
	case DCCRoute_ColorBars:
		return RM_OK;
	default:
		return RM_ERROR;
	}
	
	dar.X = ar_x;
	dar.Y = ar_y;	
	DCCSP(pDCC->pRUA, mixer, RMGenericPropertyID_DisplayAspectRatio, &dar, sizeof(dar));

	DCCSP(pDCC->pRUA, mixer, RMGenericPropertyID_Validate, NULL, 0);

	return RM_OK;
}

RMstatus DCCSetRouteDisplayAspectRatioFromSource(struct DCC *pDCC, enum DCCRoute route, RMuint32 scaler) //enum DCCSurface surface, RMuint32 index)
{
	struct EMhwlibAspectRatio dar;
	RMuint32 mixer;
	RMuint32 src_index;
	RMstatus err;
	
	switch (route) {
	case DCCRoute_Main:
		mixer = EMHWLIB_MODULE(DispMainMixer, 0);
		break;
	case DCCRoute_Secondary:
#ifdef RMFEATURE_HAS_VCR_MIXER
		mixer = EMHWLIB_MODULE(DispVCRMixer, 0);
		break;
#else
#ifdef RMFEATURE_HAS_VCR_CHANNEL
		return RM_NOTIMPLEMENTED;
#else
		return RM_ERROR;
#endif
#endif
	case DCCRoute_ColorBars:
		return RM_OK;
	default:
		return RM_ERROR;
	}

	err = RUAExchangeProperty(pDCC->pRUA, mixer, RMGenericPropertyID_MixerSourceIndex, &scaler, sizeof(scaler), &src_index, sizeof(src_index));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get scaler index, %s\n", RMstatusToString(err)));
		return err;
	}
	mixer = EMHWLIB_TARGET_MODULE(EMHWLIB_MODULE_CATEGORY(mixer), 0, src_index);
	
	dar.X = 0;
	dar.Y = 0;
	DCCSP(pDCC->pRUA, mixer, RMGenericPropertyID_DisplayAspectRatio, &dar, sizeof(dar));

	DCCSP(pDCC->pRUA, mixer, RMGenericPropertyID_Validate, NULL, 0);

	return RM_OK;
}

/* returns TRUE if the mode requires to set the DoubleRate feature on the digital output */
RMbool DCCGetDoubleRate(enum EMhwlibTVStandard standard)
{
	switch (standard) {
		case EMhwlibTVStandard_HDMI_480i59: 
		case EMhwlibTVStandard_HDMI_480i60: 
		case EMhwlibTVStandard_HDMI_240p59: 
		case EMhwlibTVStandard_HDMI_240p60: 
		case EMhwlibTVStandard_HDMI_576i50: 
		case EMhwlibTVStandard_HDMI_288p50: 
		case EMhwlibTVStandard_HDMI_576i100: 
		case EMhwlibTVStandard_HDMI_480i119: 
		case EMhwlibTVStandard_HDMI_480i120: 
		case EMhwlibTVStandard_HDMI_576i200: 
		case EMhwlibTVStandard_HDMI_480i239: 
		case EMhwlibTVStandard_HDMI_480i240: 
			return TRUE;
		default:
			return FALSE;
	}
}

RMstatus DCCSetMasterConnector(struct DCC *pDCC,
			       enum DCCVideoConnector connector,
			       enum DCCRoute route,
			       enum EMhwlibTVStandard standard)
{
	RMbool enable;
	RMuint32 master, mixer=0;
	RMuint32 bus_size = 24;
	enum EMhwlibColorSpace colorspace;
	RMuint32 routing = EMHWLIB_MODULE(DispRouting, 0); 
	struct DispRouting_Route_type disp_route;
	RMstatus err;

	if (RMFAILED(err = DCCGetVideoConnectorModuleID(pDCC, route, connector, &master))) 
		return err;

	if (RMFAILED(err = get_mixer_from_route(route, &mixer))) 
		return err;

	unbind_outport(pDCC, master);

	colorspace = EMhwlibColorSpace_RGB_0_255;
	DCCSP(pDCC->pRUA, master, RMGenericPropertyID_ColorSpace, &colorspace, sizeof(colorspace));
	if (EMHWLIB_MODULE_CATEGORY(master) == DispDigitalOut) {
		RMbool DoubleRate;
		DCCSP(pDCC->pRUA, master, RMDispDigitalOutPropertyID_BusSize, &bus_size, sizeof(bus_size));
		DoubleRate = DCCGetDoubleRate(standard);
		RMDBGLOG((LOCALDBG, "Applying DoubleRate(%s)\n", DoubleRate ? "TRUE" : "FALSE"));
		DCCSP(pDCC->pRUA, DispDigitalOut, RMDispDigitalOutPropertyID_DoubleRate, &DoubleRate, sizeof(DoubleRate));
	}
	DCCSP(pDCC->pRUA, master, RMGenericPropertyID_TVStandard, &standard, sizeof(standard));
	DCCSP(pDCC->pRUA, master, RMGenericPropertyID_SyncSourceModuleID, &master, sizeof(master));
	DCCSP(pDCC->pRUA, master, RMGenericPropertyID_Validate, NULL, 0);
	
 	enable = TRUE;
	DCCSP(pDCC->pRUA, master, RMGenericPropertyID_Enable, &enable, sizeof(enable));

	disp_route.Enable = TRUE;
	disp_route.SourceModuleID = mixer;
	disp_route.DestinationModuleID = master;
	DCCSP(pDCC->pRUA, routing, RMDispRoutingPropertyID_Route, &disp_route, sizeof(disp_route));

	DCCSP(pDCC->pRUA, routing, RMGenericPropertyID_Validate, NULL, 0);

	enable = TRUE;
	DCCSP(pDCC->pRUA, routing, RMGenericPropertyID_Enable, &enable, sizeof(enable));

	return RM_OK;

}

RMstatus DCCSetSlaveConnector(struct DCC *pDCC,
			      enum DCCVideoConnector slave_connector,
			      enum DCCVideoConnector master_connector,
			      enum DCCRoute route)
{

	RMbool enable;
	RMuint32 master, slave, mixer=0;
	RMuint32 routing = EMHWLIB_MODULE(DispRouting, 0); 
	struct DispRouting_Route_type disp_route;
	enum EMhwlibTVStandard standard;
	RMstatus err;


	if (RMFAILED(err = DCCGetVideoConnectorModuleID(pDCC, DCCRoute_Main, master_connector, &master))) 
		return err;
	if (RMFAILED(err = DCCGetVideoConnectorModuleID(pDCC, DCCRoute_Main, slave_connector, &slave))) 
		return err;
	if (RMFAILED(err = get_mixer_from_route(route, &mixer))) 
		return err;

	unbind_outport(pDCC, slave);
	
	/* the slave output has the same tv standard than its master */
	err = RUAGetProperty(pDCC->pRUA, master, RMGenericPropertyID_TVStandard, &standard, sizeof(standard));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get the master's tv standard\n"));
		return err;
	}


	disp_route.Enable = TRUE;
	disp_route.SourceModuleID = mixer;
	disp_route.DestinationModuleID = slave;
	DCCSP(pDCC->pRUA, routing, RMDispRoutingPropertyID_Route, &disp_route, sizeof(disp_route));

	DCCSP(pDCC->pRUA, routing, RMGenericPropertyID_Validate, NULL, 0);

	enable = TRUE;
	DCCSP(pDCC->pRUA, routing, RMGenericPropertyID_Enable, &enable, sizeof(enable));
	DCCSP(pDCC->pRUA, master, RMGenericPropertyID_AddSlaveOutput, &slave, sizeof(slave));
	DCCSP(pDCC->pRUA, master, RMGenericPropertyID_Validate, NULL, 0);
	
	DCCSP(pDCC->pRUA, slave, RMGenericPropertyID_SyncSourceModuleID, &master, sizeof(master));
	DCCSP(pDCC->pRUA, slave, RMGenericPropertyID_TVStandard, &standard, sizeof(standard));
	DCCSP(pDCC->pRUA, slave, RMGenericPropertyID_Validate, NULL, 0);

 	enable = TRUE;
	DCCSP(pDCC->pRUA, slave, RMGenericPropertyID_Enable, &enable, sizeof(enable));


	return RM_OK;
}

RMstatus DCCSetSDSlaveConnector(struct DCC *pDCC,
				enum DCCVideoConnector sd_connector,
				enum DCCVideoConnector hd_connector,
				enum EMhwlibTVStandard sd_standard,
				enum EMhwlibHDSDConversionMode hdsd_mode)
{
	enum EMhwlibTVStandard hd_standard;
	RMbool enable;
	RMuint32 hd_outport_id, sd_outport_id;
	RMuint32 routing = EMHWLIB_MODULE(DispRouting, 0); 
	RMuint32 dumped_lines = 0;
	struct DispRouting_Route_type disp_route;
	RMstatus err;

	struct EMhwlibClockGenerator sd_clock_pll;

	struct DispHDSDConverter_OnTheFlyModeParameters_in_type fly_params_in;
	struct DispHDSDConverter_OnTheFlyModeParameters_out_type fly_params_out;

	struct DispHDSDConverter_BufferedModeParameters_in_type buffer_params_in;
	struct DispHDSDConverter_BufferedModeParameters_out_type buffer_params_out;
	struct DispHDSDConverter_Open_type hdsd_open;
	struct DispComponentOut_TimingResetMaster_type reset_master;



	if (RMFAILED(err = DCCGetVideoConnectorModuleID(pDCC, DCCRoute_Main, sd_connector, &sd_outport_id))) 
		return err;
	if (RMFAILED(err = DCCGetVideoConnectorModuleID(pDCC, DCCRoute_Main, hd_connector, &hd_outport_id))) 
		return err;

	unbind_outport(pDCC, sd_outport_id);
	
	/* free previously allocated conversion buffer (if any) */
	{
		struct DispHDSDConverter_ConversionBuffer_type conversion_buffer;

		err = RUAGetProperty(pDCC->pRUA, DispHDSDConverter, RMDispHDSDConverterPropertyID_ConversionBuffer, &conversion_buffer, sizeof(conversion_buffer));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot get HDSD converter's converison buffer info\n"));
			return err;
		}
		
		DCCSP(pDCC->pRUA, DispHDSDConverter,RMDispHDSDConverterPropertyID_Close, NULL, 0);
		if(conversion_buffer.BufferAddress){
			pDCC->rua_free(pDCC->pRUA, conversion_buffer.BufferAddress);
			RMDBGLOG((ENABLE, "Freed %ld bytes from 0x%08lx\n",conversion_buffer.BufferSize, conversion_buffer.BufferAddress));
		}
	}

	err = RUAGetProperty(pDCC->pRUA, hd_outport_id, RMGenericPropertyID_TVStandard, &hd_standard, sizeof(hd_standard));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get the master's tv standard\n"));
		return err;
	}


	disp_route.Enable = TRUE;
	disp_route.SourceModuleID = EMHWLIB_MODULE(DispHDSDConverter, 0);
	disp_route.DestinationModuleID = sd_outport_id;
	DCCSP(pDCC->pRUA, routing, RMDispRoutingPropertyID_Route, &disp_route, sizeof(disp_route));

	DCCSP(pDCC->pRUA, routing, RMGenericPropertyID_Validate, NULL, 0);
 	enable = TRUE;
	DCCSP(pDCC->pRUA, routing, RMGenericPropertyID_Enable, &enable, sizeof(enable));


	sd_clock_pll.PLL = PLLGen_cd_9;
	sd_clock_pll.PLLOut = PLL_VIDEO_OUT;
 	DCCSP(pDCC->pRUA, sd_outport_id, RMGenericPropertyID_MasterClockGenerator, &sd_clock_pll, sizeof(sd_clock_pll));

/* 	sd_clock_pll.PLL = PLLGen_cd_8; */
/* 	sd_clock_pll.PLLOut = PLL_VIDEO_OUT; */
/*  	DCCSP(pDCC->pRUA, hd_outport_id, RMGenericPropertyID_MasterClockGenerator, &sd_clock_pll, sizeof(sd_clock_pll)); */

	RUAExchangeProperty(pDCC->pRUA, DisplayBlock, RMDisplayBlockPropertyID_TVFormatAnalog,
			    &hd_standard, sizeof(hd_standard), &(fly_params_in.HDFormat), sizeof(fly_params_in.HDFormat));

	RUAExchangeProperty(pDCC->pRUA, DisplayBlock, RMDisplayBlockPropertyID_TVFormatAnalog, 
			    &sd_standard, sizeof(sd_standard), &(fly_params_in.SDFormat), sizeof(fly_params_in.SDFormat));

	RUAExchangeProperty(pDCC->pRUA, DisplayBlock, RMDisplayBlockPropertyID_TVFormatAnalog,
			    &hd_standard, sizeof(hd_standard), &(buffer_params_in.HDFormat), sizeof(buffer_params_in.HDFormat));

	RUAExchangeProperty(pDCC->pRUA, DisplayBlock, RMDisplayBlockPropertyID_TVFormatAnalog, 
			    &sd_standard, sizeof(sd_standard), &(buffer_params_in.SDFormat), sizeof(buffer_params_in.SDFormat));

	RUAExchangeProperty(pDCC->pRUA, DisplayBlock, RMDisplayBlockPropertyID_TVFormatAnalog, 
			    &sd_standard, sizeof(sd_standard), &(hdsd_open.SDFormat), sizeof(hdsd_open.SDFormat));
	
	switch(hdsd_mode){
	case EMhwlibHDSDConversionMode_OnTheFly:
		err = RUAExchangeProperty(pDCC->pRUA, DispHDSDConverter, RMDispHDSDConverterPropertyID_OnTheFlyModeParameters, 
					  &fly_params_in, sizeof(fly_params_in), &(fly_params_out), sizeof(fly_params_out));
		if(RMFAILED(err)){
			RMDBGLOG((ENABLE, "Incompatible formats for on-the-fly conversion\n"));
			return RM_ERROR;
		}
		RMDBGLOG((ENABLE, "=================ON THE FLY MODE====================\n", buffer_params_out.BufferSize));
		RMDBGLOG((ENABLE, "dumped lines %ld, delay %ld\n", fly_params_out.DumpedLines, fly_params_out.DelayLines, fly_params_out.DelayPixels));

		dumped_lines = fly_params_out.DumpedLines;
		reset_master.ResetSourceID = sd_outport_id;
		reset_master.DelayLines = fly_params_out.DelayLines;
		reset_master.DelayPixels = fly_params_out.DelayPixels;
		break;
	case EMhwlibHDSDConversionMode_Buffered:

		RUAExchangeProperty(pDCC->pRUA, DispHDSDConverter, RMDispHDSDConverterPropertyID_BufferedModeParameters, 
				    &buffer_params_in, sizeof(buffer_params_in), &(buffer_params_out), sizeof(buffer_params_out));
		RMDBGLOG((ENABLE, "=================BUFFERED MODE====================\n", buffer_params_out.BufferSize));
		RMDBGLOG((ENABLE, "buffer is %ld bytes long\n", buffer_params_out.BufferSize));

		hdsd_open.BufferSize = buffer_params_out.BufferSize;
		hdsd_open.BufferAddress = pDCC->rua_malloc(pDCC->pRUA, DisplayBlock, pDCC->dram, RUA_DRAM_UNCACHED, buffer_params_out.BufferSize);
		DCCSP(pDCC->pRUA, DispHDSDConverter, RMDispHDSDConverterPropertyID_Open, &hdsd_open, sizeof(hdsd_open));

		dumped_lines = 0;
		reset_master.ResetSourceID = hd_outport_id;
		reset_master.DelayLines = 0;
		reset_master.DelayPixels = 0;
		break;
	}

	DCCSP(pDCC->pRUA, hd_outport_id, RMGenericPropertyID_TimingResetMaster, &reset_master, sizeof(reset_master));

	DCCSP(pDCC->pRUA, DispHDSDConverter, RMDispHDSDConverterPropertyID_ConversionMode, &hdsd_mode, sizeof(hdsd_mode));

	DCCSP(pDCC->pRUA, DispHDSDConverter, RMDispHDSDConverterPropertyID_DumpedLines, &dumped_lines, sizeof(dumped_lines));
	DCCSP(pDCC->pRUA, DispHDSDConverter, RMGenericPropertyID_Validate, NULL, 0);
	enable = TRUE;
	DCCSP(pDCC->pRUA, DispHDSDConverter, RMGenericPropertyID_Enable, &enable, sizeof(enable));

	DCCSP(pDCC->pRUA, sd_outport_id, RMGenericPropertyID_SyncSourceModuleID, &sd_outport_id, sizeof(sd_outport_id));
	DCCSP(pDCC->pRUA, sd_outport_id, RMGenericPropertyID_TVStandard, &sd_standard, sizeof(sd_standard));

	enable = TRUE;
	DCCSP(pDCC->pRUA, sd_outport_id, RMGenericPropertyID_Enable, &enable, sizeof(enable));
	DCCSP(pDCC->pRUA, hd_outport_id, RMGenericPropertyID_Enable, &enable, sizeof(enable));


	DCCSP(pDCC->pRUA, sd_outport_id, RMGenericPropertyID_Validate, NULL, 0);
	DCCSP(pDCC->pRUA, hd_outport_id, RMGenericPropertyID_Validate, NULL, 0);

	return RM_OK;
}





RMstatus DCCSetStandard(struct DCC *pDCC, enum DCCRoute route, enum EMhwlibTVStandard standard)
{
	RMstatus err;

	err = DCCSetMasterConnector(pDCC, DCCVideoConnector_DVI, route, standard);
	if(RMFAILED(err)){
		RMDBGLOG((ENABLE, "Error while setting the DVI connector\n"));
		return err;
	}
	if (! DCCGetDoubleRate(standard)) {
		err = DCCSetSlaveConnector(pDCC, DCCVideoConnector_COMPONENT,  DCCVideoConnector_DVI, route);
		if(RMFAILED(err)){
			RMDBGLOG((ENABLE, "Error while setting the COMPONENT connector\n"));
			return err;
		}
		err = DCCSetSlaveConnector(pDCC, DCCVideoConnector_COMPOSITE,  DCCVideoConnector_DVI, route);
		if(RMFAILED(err)){
			RMDBGLOG((ENABLE, "Error while setting the COMPOSITE connector\n"));
			return err;
		}
	}

	return RM_OK;
}



RMstatus DCCSetStandardDual(
	struct DCC *pDCC, 
	enum DCCRoute route_video, 
	enum DCCRoute route_vga, 
	enum EMhwlibTVStandard standard_video, 
	enum EMhwlibTVStandard standard_vga)
{
	RMbool enable;
	RMuint32 master_vga, slave_vga, master_video, slave_video, mixer_video = 0, mixer_vga = 0;
	RMuint32 bus_size = 24;
	enum EMhwlibColorSpace colorspace;
	RMuint32 routing = EMHWLIB_MODULE(DispRouting, 0); 
	struct DispRouting_Route_type disp_route;
	struct EMhwlibClockGenerator vga_clock_pll, video_clock_pll;
	
/* Works only on chips with two mixers, TODO adapt to future chips with "full" display */
#ifndef RMFEATURE_HAS_VCR_MIXER
	return RM_ERROR;
#endif
	
	master_vga = EMHWLIB_MODULE(DispDigitalOut, 0);
	slave_vga = EMHWLIB_MODULE(DispComponentOut, 0);
 	master_video = EMHWLIB_MODULE(DispMainAnalogOut, 0);
	slave_video = EMHWLIB_MODULE(DispCompositeOut, 0);
	
	if (route_video == route_vga) return RM_ERROR;
	
	switch (route_video) {
	case DCCRoute_Main:
		mixer_video = EMHWLIB_MODULE(DispMainMixer, 0);
		break;
	case DCCRoute_Secondary:
		mixer_video = EMHWLIB_MODULE(DispVCRMixer, 0);
		break;
	case DCCRoute_ColorBars:
		mixer_video = EMHWLIB_MODULE(DispColorBars, 0);
		break;
	case DCCRoute_HDSD:
		return RM_ERROR;
	}
	
	switch (route_vga) {
	case DCCRoute_Main:
		mixer_vga = EMHWLIB_MODULE(DispMainMixer, 0);
		break;
	case DCCRoute_Secondary:
		mixer_vga = EMHWLIB_MODULE(DispVCRMixer, 0);
		break;
	case DCCRoute_ColorBars:
		mixer_vga = EMHWLIB_MODULE(DispColorBars, 0);
		break;
	case DCCRoute_HDSD:
		return RM_ERROR;

	}
	
	vga_clock_pll.PLL = PLL_VIDEO_PRI;  // make sure DispDigitalOut is assigned primary PLL (hwlimit of SMP8634)
	vga_clock_pll.PLLOut = PLLOut_1;
	video_clock_pll.PLL = PLL_VIDEO_SEC;
	video_clock_pll.PLLOut = PLLOut_1;
	
	colorspace = EMhwlibColorSpace_RGB_0_255;
	DCCSP(pDCC->pRUA, master_vga, RMGenericPropertyID_ColorSpace, &colorspace, sizeof(colorspace));
	DCCSP(pDCC->pRUA, master_vga, RMGenericPropertyID_MasterClockGenerator, &vga_clock_pll, sizeof(vga_clock_pll));
	DCCSP(pDCC->pRUA, master_vga, RMDispDigitalOutPropertyID_BusSize, &bus_size, sizeof(bus_size));
	DCCSP(pDCC->pRUA, master_vga, RMGenericPropertyID_TVStandard, &standard_vga, sizeof(standard_vga));
	DCCSP(pDCC->pRUA, master_vga, RMGenericPropertyID_SyncSourceModuleID, &master_vga, sizeof(master_vga));
	DCCSP(pDCC->pRUA, master_vga, RMGenericPropertyID_AddSlaveOutput, &slave_vga, sizeof(slave_vga));
	{
		RMbool DoubleRate = DCCGetDoubleRate(standard_vga);
		RMDBGLOG((LOCALDBG, "Applying DoubleRate(%s)\n", DoubleRate ? "TRUE" : "FALSE"));
		DCCSP(pDCC->pRUA, DispDigitalOut, RMDispDigitalOutPropertyID_DoubleRate, &DoubleRate, sizeof(DoubleRate));
	}
	DCCSP(pDCC->pRUA, master_vga, RMGenericPropertyID_Validate, NULL, 0);
	
 	enable = TRUE;
	DCCSP(pDCC->pRUA, master_vga, RMGenericPropertyID_Enable, &enable, sizeof(enable));
	
	DCCSP(pDCC->pRUA, slave_vga, RMGenericPropertyID_SyncSourceModuleID, &master_vga, sizeof(master_vga));
	DCCSP(pDCC->pRUA, slave_vga, RMGenericPropertyID_TVStandard, &standard_vga, sizeof(standard_vga));
	DCCSP(pDCC->pRUA, slave_vga, RMGenericPropertyID_Validate, NULL, 0);
	
	enable = TRUE;
	DCCSP(pDCC->pRUA, slave_vga, RMGenericPropertyID_Enable, &enable, sizeof(enable));
	
	DCCSP(pDCC->pRUA, master_video, RMGenericPropertyID_MasterClockGenerator, &video_clock_pll, sizeof(video_clock_pll));
	DCCSP(pDCC->pRUA, master_video, RMGenericPropertyID_SyncSourceModuleID, &master_video, sizeof(master_video));
	DCCSP(pDCC->pRUA, master_video, RMGenericPropertyID_TVStandard, &standard_video, sizeof(standard_video));
	DCCSP(pDCC->pRUA, master_video, RMGenericPropertyID_Validate, NULL, 0);
	DCCSP(pDCC->pRUA, master_video, RMGenericPropertyID_AddSlaveOutput, &slave_video, sizeof(slave_video));
	DCCSP(pDCC->pRUA, master_video, RMGenericPropertyID_Validate, NULL, 0);
	
 	enable = TRUE;
	DCCSP(pDCC->pRUA, master_video, RMGenericPropertyID_Enable, &enable, sizeof(enable));
	
	if (
		(standard_video == EMhwlibTVStandard_NTSC_M) || 
		(standard_video == EMhwlibTVStandard_NTSC_M_Japan) || 
		(standard_video == EMhwlibTVStandard_PAL_60) || 
		(standard_video == EMhwlibTVStandard_PAL_M) || 
		(standard_video == EMhwlibTVStandard_PAL_BG) || 
		(standard_video == EMhwlibTVStandard_PAL_N) 
	) {
		DCCSP(pDCC->pRUA, slave_video, RMGenericPropertyID_SyncSourceModuleID, &master_video, sizeof(master_video));
		DCCSP(pDCC->pRUA, slave_video, RMGenericPropertyID_TVStandard, &standard_video, sizeof(standard_video));
		DCCSP(pDCC->pRUA, slave_video, RMGenericPropertyID_Validate, NULL, 0);
		
		enable = TRUE;
		DCCSP(pDCC->pRUA, slave_video, RMGenericPropertyID_Enable, &enable, sizeof(enable));
	}
	
	disp_route.Enable = TRUE;
	disp_route.SourceModuleID = mixer_vga;
	disp_route.DestinationModuleID = master_vga;
	DCCSP(pDCC->pRUA, routing, RMDispRoutingPropertyID_Route, &disp_route, sizeof(disp_route));
	
	disp_route.Enable = TRUE;
	disp_route.SourceModuleID = mixer_vga;
	disp_route.DestinationModuleID = slave_vga;
	DCCSP(pDCC->pRUA, routing, RMDispRoutingPropertyID_Route, &disp_route, sizeof(disp_route));
	
	disp_route.Enable = TRUE;
	disp_route.SourceModuleID = mixer_video;
	disp_route.DestinationModuleID = master_video;
	DCCSP(pDCC->pRUA, routing, RMDispRoutingPropertyID_Route, &disp_route, sizeof(disp_route));
	
	if (
		(standard_video == EMhwlibTVStandard_NTSC_M) || 
		(standard_video == EMhwlibTVStandard_NTSC_M_Japan) || 
		(standard_video == EMhwlibTVStandard_PAL_60) || 
		(standard_video == EMhwlibTVStandard_PAL_M) || 
		(standard_video == EMhwlibTVStandard_PAL_BG) || 
		(standard_video == EMhwlibTVStandard_PAL_N) 
	) {
		disp_route.Enable = TRUE;
		disp_route.SourceModuleID = mixer_video;
		disp_route.DestinationModuleID = slave_video;
		DCCSP(pDCC->pRUA, routing, RMDispRoutingPropertyID_Route, &disp_route, sizeof(disp_route));
	}
	
	DCCSP(pDCC->pRUA, routing, RMGenericPropertyID_Validate, NULL, 0);
	
	enable = TRUE;
	DCCSP(pDCC->pRUA, routing, RMGenericPropertyID_Enable, &enable, sizeof(enable));
	
	return RM_OK;
}

RMstatus DCCSetTVFormat(struct DCC *pDCC, enum DCCRoute route, struct EMhwlibTVFormatDigital *fmt_d, struct EMhwlibTVFormatAnalog *fmt_a)
{
	RMbool enable;
	RMuint32 slave, slave2, slave3, master, mixer=0;
	RMuint32 bus_size = 24;
	enum EMhwlibColorSpace colorspace;
	RMuint32 routing = EMHWLIB_MODULE(DispRouting, 0); 
	struct DispRouting_Route_type disp_route;
	
	master = EMHWLIB_MODULE(DispDigitalOut, 0);
	slave = EMHWLIB_MODULE(DispMainAnalogOut, 0);
	slave2 = EMHWLIB_MODULE(DispComponentOut, 0);
	slave3 = EMHWLIB_MODULE(DispCompositeOut, 0);
	
	switch (route) {
	case DCCRoute_Main:
		mixer = EMHWLIB_MODULE(DispMainMixer, 0);
		break;
	case DCCRoute_Secondary:
#ifdef RMFEATURE_HAS_VCR_MIXER
		mixer = EMHWLIB_MODULE(DispVCRMixer, 0);
		break;
#else
		return RM_ERROR;
#endif
	case DCCRoute_ColorBars:
		mixer = EMHWLIB_MODULE(DispColorBars, 0);
		break;
	case DCCRoute_HDSD:
		return RM_ERROR;

	}

	colorspace = EMhwlibColorSpace_RGB_0_255;
	DCCSP(pDCC->pRUA, master, RMGenericPropertyID_ColorSpace, &colorspace, sizeof(colorspace));
	DCCSP(pDCC->pRUA, master, RMDispDigitalOutPropertyID_BusSize, &bus_size, sizeof(bus_size)); /* BusSize might be Pending forever if called after TVFormat without Validate inbetween */
	DCCSP(pDCC->pRUA, master, RMGenericPropertyID_DigitalTVFormat, fmt_d, sizeof(*fmt_d));
	DCCSP(pDCC->pRUA, master, RMGenericPropertyID_SyncSourceModuleID, &master, sizeof(master));
	DCCSP(pDCC->pRUA, master, RMGenericPropertyID_AddSlaveOutput, &slave, sizeof(slave));
	{
		RMbool DoubleRate = DCCGetDoubleRate(EMhwlibTVStandard_Custom);
		RMDBGLOG((LOCALDBG, "Applying DoubleRate(%s)\n", DoubleRate ? "TRUE" : "FALSE"));
		DCCSP(pDCC->pRUA, DispDigitalOut, RMDispDigitalOutPropertyID_DoubleRate, &DoubleRate, sizeof(DoubleRate));
	}
	DCCSP(pDCC->pRUA, master, RMGenericPropertyID_Validate, NULL, 0);
	
 	enable = TRUE;
	DCCSP(pDCC->pRUA, master, RMGenericPropertyID_Enable, &enable, sizeof(enable));

	DCCSP(pDCC->pRUA, slave, RMGenericPropertyID_SyncSourceModuleID, &master, sizeof(master));
	DCCSP(pDCC->pRUA, slave, RMDispMainAnalogOutPropertyID_TVFormat, fmt_a, sizeof(*fmt_a));
	DCCSP(pDCC->pRUA, slave, RMGenericPropertyID_Validate, NULL, 0);

 	enable = TRUE;
	DCCSP(pDCC->pRUA, slave, RMGenericPropertyID_Enable, &enable, sizeof(enable));

	disp_route.Enable = TRUE;
	disp_route.SourceModuleID = mixer;
	disp_route.DestinationModuleID = master;
	DCCSP(pDCC->pRUA, routing, RMDispRoutingPropertyID_Route, &disp_route, sizeof(disp_route));

	/* enable slave out */
	disp_route.Enable = TRUE;
	disp_route.SourceModuleID = mixer;
	disp_route.DestinationModuleID = slave;
	DCCSP(pDCC->pRUA, routing, RMDispRoutingPropertyID_Route, &disp_route, sizeof(disp_route));

#ifdef RMFEATURE_HAS_COMPONENT_OUT
	/* add component out on mambo configuration */
	DCCSP(pDCC->pRUA, slave2, RMGenericPropertyID_SyncSourceModuleID, &master, sizeof(master));
	DCCSP(pDCC->pRUA, slave2, RMDispComponentOutPropertyID_TVFormat, fmt_a, sizeof(*fmt_a));

	DCCSP(pDCC->pRUA, master, RMGenericPropertyID_AddSlaveOutput, &slave2, sizeof(slave2));
	DCCSP(pDCC->pRUA, master, RMGenericPropertyID_Validate, NULL, 0);

	DCCSP(pDCC->pRUA, slave2, RMGenericPropertyID_Validate, NULL, 0);

	enable = TRUE;
	DCCSP(pDCC->pRUA, slave2, RMGenericPropertyID_Enable, &enable, sizeof(enable));

	/* enable slave2 out */
	disp_route.Enable = TRUE;
	disp_route.SourceModuleID = mixer;
	disp_route.DestinationModuleID = slave2;
	DCCSP(pDCC->pRUA, routing, RMDispRoutingPropertyID_Route, &disp_route, sizeof(disp_route));
#endif  // RMFEATURE_HAS_COMPONENT_OUT

#ifdef RMFEATURE_HAS_COMPOSITE_OUT
	/* add composite out on mambo configuration */
	if (fmt_a->CompositeMode != EMhwlibCompositeMode_Disable) {
		DCCSP(pDCC->pRUA, slave3, RMGenericPropertyID_SyncSourceModuleID, &master, sizeof(master));
		DCCSP(pDCC->pRUA, slave3, RMDispCompositeOutPropertyID_TVFormat, fmt_a, sizeof(*fmt_a));
		
		DCCSP(pDCC->pRUA, master, RMGenericPropertyID_AddSlaveOutput, &slave3, sizeof(slave2));
		DCCSP(pDCC->pRUA, master, RMGenericPropertyID_Validate, NULL, 0);
		
		DCCSP(pDCC->pRUA, slave3, RMGenericPropertyID_Validate, NULL, 0);
		
		enable = TRUE;
		DCCSP(pDCC->pRUA, slave3, RMGenericPropertyID_Enable, &enable, sizeof(enable));
		
		/* enable slave3 out */
		disp_route.Enable = TRUE;
		disp_route.SourceModuleID = mixer;
		disp_route.DestinationModuleID = slave3;
		DCCSP(pDCC->pRUA, routing, RMDispRoutingPropertyID_Route, &disp_route, sizeof(disp_route));
	}
	else {
		/* disable slave3 out */
		disp_route.Enable = FALSE;
		disp_route.SourceModuleID = mixer;
		disp_route.DestinationModuleID = slave3;
		DCCSP(pDCC->pRUA, routing, RMDispRoutingPropertyID_Route, &disp_route, sizeof(disp_route));
		DCCSP(pDCC->pRUA, routing, RMGenericPropertyID_Validate, NULL, 0);

		enable = FALSE;
 		DCCSP(pDCC->pRUA, slave3, RMGenericPropertyID_Enable, &enable, sizeof(enable));

		DCCSP(pDCC->pRUA, master, RMGenericPropertyID_RemoveSlaveOutput, &slave3, sizeof(slave3));
		DCCSP(pDCC->pRUA, master, RMGenericPropertyID_Validate, NULL, 0);
	}
#endif  // RMFEATURE_HAS_COMPOSITE_OUT

	DCCSP(pDCC->pRUA, routing, RMGenericPropertyID_Validate, NULL, 0);

	enable = TRUE;
	DCCSP(pDCC->pRUA, routing, RMGenericPropertyID_Enable, &enable, sizeof(enable));

	return RM_OK;
}

RMstatus DCCSetSCART(struct DCC *pDCC, 
	enum DCCRoute route, 
	enum DCCVideoConnector connector, 
	RMbool Enable, 
	RMuint32 EnableBit, 
	RMbool EnableInvert, 
	RMuint32 WideBit, 
	RMbool WideInvert, 
	enum EMhwlibSCARTWideBitState WideState)

{
	RMstatus err;
	RMuint32 output;
	struct EMhwlibSCARTConfig conf;
	
	if (RMFAILED(err = DCCGetVideoConnectorModuleID(pDCC, route, connector, &output))) 
		return err;
	
	conf.EnableBit = EnableBit;
	conf.EnableInvert = EnableInvert;
	conf.WideBit = WideBit;
	conf.WideInvert = WideInvert;
	
	DCCSP(pDCC->pRUA, output, RMGenericPropertyID_SCARTConfig, &conf, sizeof(conf));
	DCCSP(pDCC->pRUA, output, RMGenericPropertyID_SCARTWideScreen, &WideState, sizeof(WideState));
	DCCSP(pDCC->pRUA, output, RMGenericPropertyID_SCART, &Enable, sizeof(Enable));
	
	return RM_OK;
}

RMstatus DCCEnableVideoConnector(struct DCC *pDCC, enum DCCRoute route, enum DCCVideoConnector connector, RMbool enable)
{
	RMuint32 output, mixer=0;
	RMstatus err;
	enum EMhwlibComponentMode compmode;
	enum EMhwlibColorSpace colorspace;

	switch (route) {
	case DCCRoute_Main:
		mixer = EMHWLIB_MODULE(DispMainMixer, 0);
		break;
	case DCCRoute_Secondary:
#ifdef RMFEATURE_HAS_VCR_MIXER
		mixer = EMHWLIB_MODULE(DispVCRMixer, 0);
		break;
#else
		return RM_ERROR;
#endif
	case DCCRoute_ColorBars:
		mixer = EMHWLIB_MODULE(DispColorBars, 0);
		break;
	case DCCRoute_HDSD:
		return RM_ERROR;

	}
	
	if (RMFAILED(err = DCCGetVideoConnectorModuleID(pDCC, route, connector, &output))) 
		return err;

	DCCSP(pDCC->pRUA, output, RMGenericPropertyID_Enable, &enable, sizeof(enable));
	
	switch (connector) {
	case DCCVideoConnector_DVI:
	case DCCVideoConnector_LVDS:
	case DCCVideoConnector_Digital:
		// ColorSpace has been set up already
		DCCSP(pDCC->pRUA, output, RMDispDigitalOutPropertyID_SyncControlModuleID, &output, sizeof(output));
		DCCSP(pDCC->pRUA, output, RMDispDigitalOutPropertyID_EnableSyncPAD, &enable, sizeof(enable));
		DCCSP(pDCC->pRUA, output, RMGenericPropertyID_Validate, NULL, 0);
		
		break;

	case DCCVideoConnector_VGA:
		DCCSP(pDCC->pRUA, DispDigitalOut, RMDispDigitalOutPropertyID_SyncControlModuleID, &output, sizeof(output));
		DCCSP(pDCC->pRUA, DispDigitalOut, RMDispDigitalOutPropertyID_EnableSyncPAD, &enable, sizeof(enable));
		DCCSP(pDCC->pRUA, DispDigitalOut, RMGenericPropertyID_Validate, NULL, 0);
		
		DCCSP(pDCC->pRUA, DispDigitalOut, RMGenericPropertyID_Enable, &enable, sizeof(enable));

		compmode = EMhwlibComponentMode_RGB_SCART;
		DCCSP(pDCC->pRUA, output, RMGenericPropertyID_ComponentMode, &compmode, sizeof(compmode));

		colorspace = EMhwlibColorSpace_RGB_0_255;
		DCCSP(pDCC->pRUA, output, RMGenericPropertyID_ColorSpace, &colorspace, sizeof(colorspace));
		DCCSP(pDCC->pRUA, output, RMGenericPropertyID_Validate, NULL, 0);
		break;

	case DCCVideoConnector_SCART:
		compmode = EMhwlibComponentMode_RGB_SCART;
		DCCSP(pDCC->pRUA, output, RMGenericPropertyID_ComponentMode, &compmode, sizeof(compmode));

		colorspace = EMhwlibColorSpace_RGB_0_255;
		DCCSP(pDCC->pRUA, output, RMGenericPropertyID_ColorSpace, &colorspace, sizeof(colorspace));
		DCCSP(pDCC->pRUA, output, RMGenericPropertyID_Validate, NULL, 0);
		break;
		
	case DCCVideoConnector_COMPONENT:
		// ColorSpace has been set up already for component.
		// Set up colorspace for composite also
		colorspace = EMhwlibColorSpace_YUV_601;
#ifdef RMFEATURE_HAS_DUAL_MAINANALOGOUT
 		DCCSP(pDCC->pRUA, output, RMDispMainAnalogOutPropertyID_ColorSpaceCVBS, &colorspace, sizeof(colorspace));
#endif // RMFEATURE_HAS_DUAL_MAINANALOGOUT

		DCCSP(pDCC->pRUA, output, RMGenericPropertyID_Validate, NULL, 0);
		break;
		
	case DCCVideoConnector_SVIDEO:
	case DCCVideoConnector_COMPOSITE:
		colorspace = EMhwlibColorSpace_YUV_601;
#ifdef RMFEATURE_HAS_DUAL_MAINANALOGOUT
 		DCCSP(pDCC->pRUA, output, RMDispMainAnalogOutPropertyID_ColorSpaceCVBS, &colorspace, sizeof(colorspace));
#else
 		DCCSP(pDCC->pRUA, output, RMGenericPropertyID_ColorSpace, &colorspace, sizeof(colorspace));
#endif // RMFEATURE_HAS_DUAL_MAINANALOGOUT
		
		DCCSP(pDCC->pRUA, output, RMGenericPropertyID_Validate, NULL, 0);
		break;
	}

	return RM_OK;
}

RMstatus DCCGetVideoConnectorModuleID(struct DCC *pDCC, enum DCCRoute route, enum DCCVideoConnector connector, RMuint32 *moduleID)
{
	// TODO the output connectors are board- and chip-dependent!
	// We need a board/chip table 
	// e.g. 
	//   board 716, chip 8610L, connector: vga==>DispComponentOut, cvbs,svideo,component==>DispMainAnalogOut, dvi==>DispDigitalOut 
	//   board 716, chip 8620L, connector: vga,cvbs,svideo,component==>DispMainAnalogOut, dvi==>DispDigitalOut 
	// or we need to give the user a choice, e.g. vga_component, vga_main, scart_composite etc.
	switch (route) {
	case DCCRoute_Main:
	case DCCRoute_Secondary:
	case DCCRoute_ColorBars:
	case DCCRoute_HDSD:
		switch (connector) {
		case DCCVideoConnector_DVI:
		case DCCVideoConnector_LVDS:
		case DCCVideoConnector_Digital:
			*moduleID = EMHWLIB_MODULE(DispDigitalOut, 0);
			break;
		case DCCVideoConnector_VGA:
#ifndef RMFEATURE_HAS_COMPONENT_OUT
			*moduleID = EMHWLIB_MODULE(DispMainAnalogOut, 0);
#else
			*moduleID = EMHWLIB_MODULE(DispComponentOut, 0);
#endif
			break;
		case DCCVideoConnector_SCART:
		case DCCVideoConnector_COMPONENT:
#ifndef RMFEATURE_HAS_COMPONENT_OUT
			*moduleID = EMHWLIB_MODULE(DispMainAnalogOut, 0);
#else
			*moduleID = EMHWLIB_MODULE(DispComponentOut, 0);
#endif
			break;
		case DCCVideoConnector_SVIDEO:
			*moduleID = EMHWLIB_MODULE(DispMainAnalogOut, 0);
			break;
		case DCCVideoConnector_COMPOSITE:
#ifndef RMFEATURE_HAS_COMPOSITE_OUT
			*moduleID = EMHWLIB_MODULE(DispMainAnalogOut, 0);
#else
			*moduleID = EMHWLIB_MODULE(DispCompositeOut, 0);
#endif
			break;
		}
		break;
	}
		
	return RM_OK;
}

RMstatus DCCSetDVIOutFormat(struct DCC *pDCC, enum DCCRoute route, enum EMhwlibColorSpace color_space, enum EMhwlibDigitalTimingSignal timing, RMuint32 bus_size)
{
	RMuint32 output;
	enum EMhwlibColorOrder ColorOrder = EMhwlibColorOrder_RGB;
	RMbool clipping;
	enum DispDigitalOut_ClippingLevel_type level;
	
	output = EMHWLIB_MODULE(DispDigitalOut, 0);

	clipping = FALSE;
	DCCSP(pDCC->pRUA, output, RMDispDigitalOutPropertyID_EnableClipping, &clipping, sizeof(clipping));
	level = DispDigitalOut_ClippingLevel_Clip_1_254;
	DCCSP(pDCC->pRUA, output, RMDispDigitalOutPropertyID_ClippingLevel, &level, sizeof(level));
	DCCSP(pDCC->pRUA, output, RMDispDigitalOutPropertyID_ColorOrder, &ColorOrder, sizeof(ColorOrder));
	DCCSP(pDCC->pRUA, output, RMDispDigitalOutPropertyID_TimingSignal, &timing, sizeof(timing));
	DCCSP(pDCC->pRUA, output, RMDispDigitalOutPropertyID_BusSize, &bus_size, sizeof(bus_size));
	DCCSP(pDCC->pRUA, output, RMGenericPropertyID_ColorSpace, &color_space, sizeof(color_space));
	DCCSP(pDCC->pRUA, output, RMGenericPropertyID_Validate, NULL, 0);

	return RM_OK;
}

RMstatus DCCSetComponentOutFormat(struct DCC *pDCC, enum DCCRoute route, enum EMhwlibColorSpace color_space, enum EMhwlibComponentMode component)
{
	RMuint32 output;
	RMstatus err = RM_OK;

	if (RMFAILED(err = DCCGetVideoConnectorModuleID(pDCC, route, DCCVideoConnector_COMPONENT, &output)))
		return err;

	DCCSP(pDCC->pRUA, output, RMGenericPropertyID_ColorSpace, &color_space, sizeof(color_space));
	DCCSP(pDCC->pRUA, output, RMGenericPropertyID_ComponentMode, &component, sizeof(component));
	DCCSP(pDCC->pRUA, output, RMGenericPropertyID_Validate, NULL, 0);

	return RM_OK;
}
RMstatus DCCEnableSPUSurface(struct DCC *pDCC, enum DCCRoute route, RMuint32 index, struct DCCVideoSource *pVideoSource, RMbool enable)
{
	RMuint32 spu_scaler, src_index;
	RMuint32 mixer=0;
	RMuint32 video_scaler;
	RMstatus err;
	enum EMhwlibMixerSourceState state;
	struct EMhwlibSubPictureSurface_type spu_surface;

	switch (route) {
	case DCCRoute_Main:
		mixer = EMHWLIB_MODULE(DispMainMixer, 0);
		break;
	case DCCRoute_Secondary:
#ifdef RMFEATURE_HAS_VCR_MIXER
		mixer = EMHWLIB_MODULE(DispVCRMixer, 0);
		break;
#else
		return RM_ERROR;
#endif
	case DCCRoute_ColorBars:
		RMDBGLOG((ENABLE, "No spu on colorbars route\n"));
		return RM_ERROR;
	case DCCRoute_HDSD:
		return RM_ERROR;
	}

	err = DCCGetScalerModuleID(pDCC, route, DCCSurface_SPU, index, &spu_scaler);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get spu surface scaler\n"));
		return err;
	}

	err = DCCGetScalerModuleID(pDCC, route, DCCSurface_Video, index, &video_scaler);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get video surface scaler\n"));
		return err;
	}

	err = RUAExchangeProperty(pDCC->pRUA, mixer, RMGenericPropertyID_MixerSourceIndex, &spu_scaler, sizeof(spu_scaler), &src_index, sizeof(src_index));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get spu_scaler index, %s\n", RMstatusToString(err)));
		return err;
	}
	mixer = EMHWLIB_TARGET_MODULE(DispMainMixer, 0 , src_index);

	if (enable) {
		if (pVideoSource == NULL) {
			RMDBGLOG((ENABLE, "Invalid video source\n"));
			return RM_ERROR;
		}

		if (pVideoSource->spu_surface != 0) {
			spu_surface.Scaler =  spu_scaler;
			spu_surface.Surface = pVideoSource->spu_surface;
			DCCSP(pDCC->pRUA, video_scaler, RMGenericPropertyID_SubPictureSurface, &spu_surface, sizeof(spu_surface));
			DCCSP(pDCC->pRUA, video_scaler, RMGenericPropertyID_Validate, NULL, 0);
		}

		if (pVideoSource->spu_decoder_moduleID != 0)
			DCCSP(pDCC->pRUA, pVideoSource->spu_decoder_moduleID, RMSpuDecoderPropertyID_Scaler, &spu_scaler, sizeof(spu_scaler));

		state = EMhwlibMixerSourceState_Slave;
		DCCSP(pDCC->pRUA, mixer, RMGenericPropertyID_MixerSourceState, &state, sizeof(state));
		
		DCCSP(pDCC->pRUA, mixer, RMGenericPropertyID_Validate, NULL, 0);
	}
	else {
		RMuint32 surface;
		
		spu_surface.Scaler = 0;
		spu_surface.Surface = 0;
		DCCSP(pDCC->pRUA, video_scaler, RMGenericPropertyID_SubPictureSurface, &spu_surface, sizeof(spu_surface));
		DCCSP(pDCC->pRUA, video_scaler, RMGenericPropertyID_Validate, NULL, 0);

		surface = 0;
		DCCSP(pDCC->pRUA, spu_scaler, RMGenericPropertyID_Surface, &surface, sizeof(surface));

		state = EMhwlibMixerSourceState_Slave;
		DCCSP(pDCC->pRUA, mixer, RMGenericPropertyID_MixerSourceState, &state, sizeof(state));

		DCCSP(pDCC->pRUA, mixer, RMGenericPropertyID_Validate, NULL, 0);
	}
	
	return RM_OK;
}

RMstatus DCCGetScalerModuleID(struct DCC *pDCC, enum DCCRoute route, enum DCCSurface surface, RMuint32 index, RMuint32 *scaler)
{
	RMstatus err = RM_OK;

	switch (route) {
	case DCCRoute_Main:
		switch (surface) {
		case DCCSurface_Video:
			if (index == 0) 
				*scaler = EMHWLIB_MODULE(DispMainVideoScaler, 0);
#ifdef RMFEATURE_HAS_VCR_SCALER
			else if (index == 1)
				*scaler = EMHWLIB_MODULE(DispVCRMultiScaler, 0);
			else if (index == 2)
				*scaler = EMHWLIB_MODULE(DispGFXMultiScaler, 0);
#ifdef RMFEATURE_HAS_CRT_SCALER
			else if (index == 3)
				*scaler = EMHWLIB_MODULE(DispCRTMultiScaler, 0);
#endif
#else
			else if (index == 1)
				*scaler = EMHWLIB_MODULE(DispGFXMultiScaler, 0);
#endif
			else
				err = RM_ERROR;
			break;
		case DCCSurface_OSD:
			if (index == 0)
				*scaler = EMHWLIB_MODULE(DispOSDScaler, 0); // it only supports RGB (not good for YUV in JPEGs...)
			else if (index == 1)
				*scaler = EMHWLIB_MODULE(DispGFXMultiScaler, 0);
			else if (index == 2)	
				*scaler = EMHWLIB_MODULE(DispMainVideoScaler, 0);
#ifdef RMFEATURE_HAS_VCR_SCALER
			else if (index == 3)
				*scaler = EMHWLIB_MODULE(DispVCRMultiScaler, 0);
#endif
#ifdef RMFEATURE_HAS_CRT_SCALER
			else if (index == 4)
				*scaler = EMHWLIB_MODULE(DispCRTMultiScaler, 0);
#endif
#ifdef RMFEATURE_HAS_GENERIC_SPU_SCALER
			else if (index == 5)
				*scaler = EMHWLIB_MODULE(DispSubPictureScaler, 0);
#endif
			else if (index == 6)
				*scaler = EMHWLIB_MODULE(DispVideoPlane, 0);

			else
				err = RM_ERROR;
			break;
		case DCCSurface_SPU:
#ifdef RMFEATURE_HAS_SPU_SCALER
			*scaler = EMHWLIB_MODULE(DispSubPictureScaler, 0);
#else
			*scaler = EMHWLIB_MODULE(DispGFXMultiScaler, 0);
#endif
			break;
		}
		break;

	case DCCRoute_Secondary:
		switch (surface) {
		case DCCSurface_Video:
			if (index == 0) 
				*scaler = EMHWLIB_MODULE(DispVCRMultiScaler, 0);
			else
				err = RM_ERROR;
			break;
		case DCCSurface_OSD:
			if (index == 0)
				*scaler = EMHWLIB_MODULE(DispVCRMultiScaler, 0);
			else if (index == 1)	
				*scaler = EMHWLIB_MODULE(DispCRTMultiScaler, 0);
			else
				err = RM_ERROR;
			break;
		case DCCSurface_SPU:
			err = RM_ERROR;
			break;
		}
		break;
	case DCCRoute_ColorBars:
		err = RM_ERROR;
		break;
	case DCCRoute_HDSD:
		err = RM_ERROR;
		break;
	}

	return err;
}

RMstatus DCCSetSurfaceSource(struct DCC *pDCC, RMuint32 surfaceID, struct DCCVideoSource *pVideoSource)
{
	RMuint32 surface, scaler, mixer;
	RMbool enable;

	scaler = surfaceID;

	if (pVideoSource == NULL) {
		surface = 0;
		DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Surface, &surface, sizeof(surface));
		scaler = 0;
		mixer = 0;
	}
	else {
		RMuint32 spu_scaler;

		surface = pVideoSource->surface;
		DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Surface, &surface, sizeof(surface));

		enable = FALSE;
 		DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_PersistentSurface, &enable, sizeof(enable));

		DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Validate, NULL, 0);

		mixer = get_mixer_moduleID(pDCC, scaler);

		if (pVideoSource->spu_decoder_moduleID) {
			RMstatus err;
			err = DCCGetScalerModuleID(pDCC, DCCRoute_Main, DCCSurface_SPU, 0, &(pVideoSource->spu_scaler_moduleID));
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot get SPU scaler for this video source\n"));
				return err;
			}
			spu_scaler = pVideoSource->spu_scaler_moduleID;
		}
		else
			spu_scaler = 0;
		
		if (spu_scaler != 0) {
			struct EMhwlibSubPictureSurface_type spu_surface;
			
			spu_surface.Scaler =  spu_scaler;
			spu_surface.Surface = pVideoSource->spu_surface;
			DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_SubPictureSurface, &spu_surface, sizeof(spu_surface));
			DCCSP(pDCC->pRUA, scaler, RMGenericPropertyID_Validate, NULL, 0);

			DCCSP(pDCC->pRUA, pVideoSource->spu_decoder_moduleID, RMSpuDecoderPropertyID_Scaler, &spu_scaler, sizeof(spu_scaler));
		}
		pVideoSource->scaler_moduleID = scaler;
		pVideoSource->mixer_moduleID = mixer;
	}


	return RM_OK;
} 


RMstatus DCCSetHDSDStandards(struct DCC *pDCC, enum DCCRoute route, enum EMhwlibTVStandard sd_standard, enum EMhwlibTVStandard hd_standard, enum EMhwlibHDSDConversionMode hdsd_mode)
{
#ifdef RMFEATURE_HAS_HDSD_CONVERTER

#if 1
	RMstatus err;
	err = DCCSetMasterConnector(pDCC, DCCVideoConnector_DVI, route, hd_standard);
	if(RMFAILED(err)){
		RMDBGLOG((ENABLE, "Error while setting the DVI connector\n"));
		return err;
	}
	err = DCCSetSDSlaveConnector(pDCC, DCCVideoConnector_COMPOSITE, DCCVideoConnector_DVI, sd_standard, hdsd_mode);
	if(RMFAILED(err)){
		RMDBGLOG((ENABLE, "Error while setting the COMPOSITE connector\n"));
		return err;
	}
	if (DCCGetDoubleRate(hd_standard)) {
		err = DCCSetSDSlaveConnector(pDCC, DCCVideoConnector_COMPONENT, DCCVideoConnector_DVI, sd_standard, hdsd_mode);
		if(RMFAILED(err)){
			RMDBGLOG((ENABLE, "Error while setting the COMPONENT connector\n"));
			return err;
		}
	} else {
		err = DCCSetSlaveConnector(pDCC, DCCVideoConnector_COMPONENT, DCCVideoConnector_DVI, route);
		if(RMFAILED(err)){
			RMDBGLOG((ENABLE, "Error while setting the COMPONENT connector\n"));
			return err;
		}
	}

	return RM_OK;

#else

	enum EMhwlibColorSpace colorspace;

	RMbool enable;
	RMuint32 hd_outport_id, sd_outport_id, hdslave_outport_id, mixer=0;
	RMuint32 routing = EMHWLIB_MODULE(DispRouting, 0); 
	RMuint32 dumped_lines = 0,  bus_size;
	struct DispRouting_Route_type disp_route;
	RMstatus err;

	struct EMhwlibClockGenerator sd_clock_pll;

	struct DispHDSDConverter_OnTheFlyModeParameters_in_type fly_params_in;
	struct DispHDSDConverter_OnTheFlyModeParameters_out_type fly_params_out;

	struct DispHDSDConverter_BufferedModeParameters_in_type buffer_params_in;
	struct DispHDSDConverter_BufferedModeParameters_out_type buffer_params_out;
	struct DispHDSDConverter_Open_type hdsd_open;
	struct DispComponentOut_TimingResetMaster_type reset_master;

 	sd_outport_id = EMHWLIB_MODULE(DispMainAnalogOut, 0);
	hd_outport_id = EMHWLIB_MODULE(DispDigitalOut, 0);
	hdslave_outport_id = EMHWLIB_MODULE(DispComponentOut, 0);

	/*
	  sd_outport_id: 
	                * slave of hd_outport_id
			* reset source of hd_outport_id
			* plugged to the HDSD block route
			* output standard is 'sd_standard'
	  hd_outport_id:
	                * master of sd_outport_id and hdslave_outport_id
			* uses sd_outpourt_id as reset source
			* plugged to the route specifed by the 'route' parameter
			* output standard is 'hd_standard'
	  hdslave_outport_id:
	                * slave of hd_outport_id
			* plugged to the route specifed by the 'route' parameter
			* output standard is 'hd_standard'
			* gets all timing from hd_outport_id
	*/


	switch (route) {
	case DCCRoute_Main:
		mixer = EMHWLIB_MODULE(DispMainMixer, 0);
		break;
	case DCCRoute_Secondary:
#ifdef RMFEATURE_HAS_VCR_MIXER
		mixer = EMHWLIB_MODULE(DispVCRMixer, 0);
		break;
#else
		return RM_ERROR;
#endif
	case DCCRoute_ColorBars:
		mixer = EMHWLIB_MODULE(DispColorBars, 0);
		break;
	}



	/* recover from a previous DCCSetHDSDStandards */
	{
		struct DispHDSDConverter_ConversionBuffer_type conversion_buffer;
		RMstatus err;
		reset_master.ResetSourceID = hd_outport_id;
		reset_master.DelayLines = 0;
		reset_master.DelayPixels = 0;
		DCCSP(pDCC->pRUA, hd_outport_id, RMGenericPropertyID_TimingResetMaster, &reset_master, sizeof(reset_master));
		err = RUAGetProperty(pDCC->pRUA, DispHDSDConverter, RMDispHDSDConverterPropertyID_ConversionBuffer, &conversion_buffer, sizeof(conversion_buffer));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot get HDSD converter's converison buffer info\n"));
			return err;
		}
		
		DCCSP(pDCC->pRUA, DispHDSDConverter,RMDispHDSDConverterPropertyID_Close, NULL, 0);
		if(conversion_buffer.BufferAddress){
			pDCC->rua_free(pDCC->pRUA, conversion_buffer.BufferAddress);
			RMDBGLOG((ENABLE, "Freed %ld bytes from 0x%08lx\n",conversion_buffer.BufferSize, conversion_buffer.BufferAddress));
		}
	}

	colorspace = EMhwlibColorSpace_RGB_0_255;
	DCCSP(pDCC->pRUA, hd_outport_id, RMGenericPropertyID_ColorSpace, &colorspace, sizeof(colorspace));
	bus_size = 24;
	DCCSP(pDCC->pRUA, hd_outport_id, RMDispDigitalOutPropertyID_BusSize, &bus_size, sizeof(bus_size));



	/* setup routing */
/* 	enable = FALSE; */
/* 	DCCSP(pDCC->pRUA, routing, RMGenericPropertyID_Enable, &enable, sizeof(enable)); */

	disp_route.Enable = TRUE;
	disp_route.SourceModuleID = EMHWLIB_MODULE(DispHDSDConverter, 0);
	disp_route.DestinationModuleID = sd_outport_id;
	DCCSP(pDCC->pRUA, routing, RMDispRoutingPropertyID_Route, &disp_route, sizeof(disp_route));

	disp_route.Enable = TRUE;
	disp_route.SourceModuleID = mixer;
	disp_route.DestinationModuleID = hd_outport_id;
	DCCSP(pDCC->pRUA, routing, RMDispRoutingPropertyID_Route, &disp_route, sizeof(disp_route));

	disp_route.Enable = TRUE;
	disp_route.SourceModuleID = mixer;
	disp_route.DestinationModuleID = hdslave_outport_id;
	DCCSP(pDCC->pRUA, routing, RMDispRoutingPropertyID_Route, &disp_route, sizeof(disp_route));
	
	DCCSP(pDCC->pRUA, routing, RMGenericPropertyID_Validate, NULL, 0);
 	enable = TRUE;
	DCCSP(pDCC->pRUA, routing, RMGenericPropertyID_Enable, &enable, sizeof(enable));


	sd_clock_pll.PLL = PLLGen_cd_9;
	sd_clock_pll.PLLOut = PLL_VIDEO_OUT;
 	DCCSP(pDCC->pRUA, sd_outport_id, RMGenericPropertyID_MasterClockGenerator, &sd_clock_pll, sizeof(sd_clock_pll));
	sd_clock_pll.PLL = PLLGen_cd_8;
	sd_clock_pll.PLLOut = PLL_VIDEO_OUT;
 	DCCSP(pDCC->pRUA, hd_outport_id, RMGenericPropertyID_MasterClockGenerator, &sd_clock_pll, sizeof(sd_clock_pll));

/* 	DCCSP(pDCC->pRUA, hd2_outport_id, RMGenericPropertyID_RemoveSlaveOutput, &sd_outport_id, sizeof(sd_outport_id)); */
/* 	DCCSP(pDCC->pRUA, hd2_outport_id, RMGenericPropertyID_RemoveSlaveOutput, &hd_outport_id, sizeof(hd_outport_id)); */
/* 	DCCSP(pDCC->pRUA, hd2_outport_id, RMGenericPropertyID_Validate, NULL, 0); */
/* 	enable = FALSE; */
/* 	DCCSP(pDCC->pRUA, hd2_outport_id, RMGenericPropertyID_Enable, &enable, sizeof(enable)); */



	RUAExchangeProperty(pDCC->pRUA, DisplayBlock, RMDisplayBlockPropertyID_TVFormatAnalog,
			    &hd_standard, sizeof(hd_standard), &(fly_params_in.HDFormat), sizeof(fly_params_in.HDFormat));

	RUAExchangeProperty(pDCC->pRUA, DisplayBlock, RMDisplayBlockPropertyID_TVFormatAnalog, 
			    &sd_standard, sizeof(sd_standard), &(fly_params_in.SDFormat), sizeof(fly_params_in.SDFormat));

	RUAExchangeProperty(pDCC->pRUA, DisplayBlock, RMDisplayBlockPropertyID_TVFormatAnalog, 
			    &sd_standard, sizeof(sd_standard), &(buffer_params_in.SDFormat), sizeof(buffer_params_in.SDFormat));

	RUAExchangeProperty(pDCC->pRUA, DisplayBlock, RMDisplayBlockPropertyID_TVFormatAnalog, 
			    &sd_standard, sizeof(sd_standard), &(hdsd_open.SDFormat), sizeof(hdsd_open.SDFormat));
	
	switch(hdsd_mode){
	case EMhwlibHDSDConversionMode_OnTheFly:
		err = RUAExchangeProperty(pDCC->pRUA, DispHDSDConverter, RMDispHDSDConverterPropertyID_OnTheFlyModeParameters, 
					  &fly_params_in, sizeof(fly_params_in), &(fly_params_out), sizeof(fly_params_out));
		if(RMFAILED(err)){
			RMDBGLOG((ENABLE, "Incompatible formats for on-the-fly conversion\n"));
			return RM_ERROR;
		}
		RMDBGLOG((ENABLE, "=================ON THE FLY MODE====================\n", buffer_params_out.BufferSize));
		RMDBGLOG((ENABLE, "dumped lines %ld, delay %ld\n", fly_params_out.DumpedLines, fly_params_out.DelayLines, fly_params_out.DelayPixels));

		dumped_lines = fly_params_out.DumpedLines;
		reset_master.ResetSourceID = sd_outport_id;
		reset_master.DelayLines = fly_params_out.DelayLines;
		reset_master.DelayPixels = fly_params_out.DelayPixels;
		break;
	case EMhwlibHDSDConversionMode_Buffered:

		RUAExchangeProperty(pDCC->pRUA, DispHDSDConverter, RMDispHDSDConverterPropertyID_BufferedModeParameters, 
				    &buffer_params_in, sizeof(buffer_params_in), &(buffer_params_out), sizeof(buffer_params_out));
		RMDBGLOG((ENABLE, "=================BUFFERED MODE====================\n", buffer_params_out.BufferSize));
		RMDBGLOG((ENABLE, "buffer is %ld bytes long\n", buffer_params_out.BufferSize));

		hdsd_open.BufferSize = buffer_params_out.BufferSize;
		hdsd_open.BufferAddress = pDCC->rua_malloc(pDCC->pRUA, DisplayBlock, pDCC->dram, RUA_DRAM_UNCACHED, buffer_params_out.BufferSize);
		DCCSP(pDCC->pRUA, DispHDSDConverter, RMDispHDSDConverterPropertyID_Open, &hdsd_open, sizeof(hdsd_open));

		dumped_lines = 0;
		reset_master.ResetSourceID = hd_outport_id;
		reset_master.DelayLines = 0;
		reset_master.DelayPixels = 0;
		break;
	}

	DCCSP(pDCC->pRUA, hd_outport_id, RMGenericPropertyID_TimingResetMaster, &reset_master, sizeof(reset_master));
	DCCSP(pDCC->pRUA, hd_outport_id, RMGenericPropertyID_AddSlaveOutput, &hdslave_outport_id, sizeof(hdslave_outport_id));

	DCCSP(pDCC->pRUA, DispHDSDConverter, RMDispHDSDConverterPropertyID_ConversionMode, &hdsd_mode, sizeof(hdsd_mode));

	DCCSP(pDCC->pRUA, DispHDSDConverter, RMDispHDSDConverterPropertyID_DumpedLines, &dumped_lines, sizeof(dumped_lines));
	DCCSP(pDCC->pRUA, DispHDSDConverter, RMGenericPropertyID_Validate, NULL, 0);
	enable = TRUE;
	DCCSP(pDCC->pRUA, DispHDSDConverter, RMGenericPropertyID_Enable, &enable, sizeof(enable));

	DCCSP(pDCC->pRUA, sd_outport_id, RMGenericPropertyID_SyncSourceModuleID, &sd_outport_id, sizeof(sd_outport_id));
	DCCSP(pDCC->pRUA, sd_outport_id, RMGenericPropertyID_TVStandard, &sd_standard, sizeof(sd_standard));

	DCCSP(pDCC->pRUA, hd_outport_id, RMGenericPropertyID_SyncSourceModuleID, &hd_outport_id, sizeof(hd_outport_id));
	DCCSP(pDCC->pRUA, hd_outport_id, RMGenericPropertyID_TVStandard, &hd_standard, sizeof(hd_standard));
	{
		RMbool DoubleRate = DCCGetDoubleRate(hd_standard);
		RMDBGLOG((LOCALDBG, "Applying DoubleRate(%s)\n", DoubleRate ? "TRUE" : "FALSE"));
		DCCSP(pDCC->pRUA, DispDigitalOut, RMDispDigitalOutPropertyID_DoubleRate, &DoubleRate, sizeof(DoubleRate));
	}

	DCCSP(pDCC->pRUA, hdslave_outport_id, RMGenericPropertyID_SyncSourceModuleID, &hd_outport_id, sizeof(hd_outport_id));
	DCCSP(pDCC->pRUA, hdslave_outport_id, RMGenericPropertyID_TVStandard, &hd_standard, sizeof(hd_standard));

	DCCSP(pDCC->pRUA, sd_outport_id, RMGenericPropertyID_Validate, NULL, 0);
	DCCSP(pDCC->pRUA, hd_outport_id, RMGenericPropertyID_Validate, NULL, 0);
	DCCSP(pDCC->pRUA, hdslave_outport_id, RMGenericPropertyID_Validate, NULL, 0);

	enable = TRUE;
	DCCSP(pDCC->pRUA, sd_outport_id, RMGenericPropertyID_Enable, &enable, sizeof(enable));
	DCCSP(pDCC->pRUA, hdslave_outport_id, RMGenericPropertyID_Enable, &enable, sizeof(enable));
	DCCSP(pDCC->pRUA, hd_outport_id, RMGenericPropertyID_Enable, &enable, sizeof(enable));

#endif


#endif  // RMFEATURE_HAS_HDSD_CONVERTER
	
	return RM_OK;
}





#define slaving_mode_same_timing     0x01
#define	slaving_mode_same_route      0x02
#define	slaving_mode_hdsd_on_the_fly 0x04
#define	slaving_mode_hdsd_buffered  0x08
#define slaving_mode_non_compatible  0x10

/* deprecated */
struct slaving_info{
	struct outport_info *master;
	RMuint32 mode;
	RMuint32 dumped_lines;
	RMuint32 delay_lines;
	RMuint32 delay_pixels;
	RMuint32 hd_slave;
};

struct compatibility_info{
	RMuint32 mode;
	RMuint32 dumped_lines;
	RMuint32 delay_lines;
	RMuint32 delay_pixels;
	RMbool hd_slave;
};


struct outport_info{
	struct DCCOutportConfig *config;
	struct DCCOutportConfig old_config;
	RMuint32 module_id;
	RMuint32 route_id;
	RMuint32 clean_divider;
	struct slaving_info slaving;
	RMbool disabled;
};

/* FIXME this is here because get_slaves from an outport returns a vsync bitmask!  */
#define	dcc_OUTPUT_PORT_DIGITAL (1 << 0)
#define	dcc_OUTPUT_PORT_MAIN_ANALOG (1 << 1)
#define	dcc_OUTPUT_PORT_COMPONENT (1 << 2)



#define GET_OUTPORT_NAME(x) ((x==DispDigitalOut)?"digital":((x==DispComponentOut)?"component":((x==DispMainAnalogOut)?"analog":"unknown")))
#define GET_ROUTE_NAME(x) ((x==DCCRoute_Main)?"main":((x==DCCRoute_Secondary)?"secondary":((x==DCCRoute_ColorBars)?"colorbars":"unknown")))

static RMstatus disable_outports_in_route(struct DCC *pDCC, struct outport_info *outports, enum DCCRoute route)
{
	struct RUAEvent evt;
	RMuint32 j, i;
	RMstatus err;
	RMbool enable;
	RMuint32 disable_count = 0, disable_array[RMFEATURE_OUTPORT_COUNT];

	RMDBGLOG((OUTPORTDBG, "Disabling route %s\n", GET_ROUTE_NAME(route)));

	evt.ModuleID = EMHWLIB_MODULE(DisplayBlock, 0);

	for (j = 0; j< RMFEATURE_OUTPORT_COUNT; j++){
		for (i = 0; i< RMFEATURE_OUTPORT_COUNT; i++){
			RMuint32 slaves;
			
			if (outports[i].disabled) {
				RMDBGLOG((OUTPORTDBG, "outport %s already disabled\n", GET_OUTPORT_NAME(outports[i].module_id)));
				continue;
			}
			
			if (outports[i].old_config.route != route) {
				RMDBGLOG((OUTPORTDBG, "outport %s had different route %s\n", GET_OUTPORT_NAME(outports[i].module_id), GET_ROUTE_NAME(outports[i].old_config.route)));
				continue;
			}
			
			err = RUAGetProperty(pDCC->pRUA, outports[i].module_id, RMGenericPropertyID_SlaveOutput, &slaves, sizeof(slaves));
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot get slaves from outport %s\n", GET_OUTPORT_NAME(outports[i].module_id)));
				return err;
			}

			if ((slaves & dcc_OUTPUT_PORT_DIGITAL) && (!outports[0].disabled)) {
				RMDBGLOG((OUTPORTDBG, "disable slave %s first\n", GET_OUTPORT_NAME(outports[0].module_id)));
				continue;
			}
			
			if ((slaves & dcc_OUTPUT_PORT_COMPONENT) && (!outports[1].disabled)) {
				RMDBGLOG((OUTPORTDBG, "disable slave %s first\n", GET_OUTPORT_NAME(outports[1].module_id)));
				continue;
			}
			
			if ((slaves & dcc_OUTPUT_PORT_MAIN_ANALOG)&& (!outports[2].disabled)) {
				RMDBGLOG((OUTPORTDBG, "disable slave %s first\n", GET_OUTPORT_NAME(outports[2].module_id)));
				continue;
			}
			
			RMDBGLOG((OUTPORTDBG, "Disabling %s\n", GET_OUTPORT_NAME(outports[i].module_id)));
			
			enable = FALSE;
			DCCSP(pDCC->pRUA, outports[i].module_id, RMGenericPropertyID_Enable, &enable, sizeof(enable));
			outports[i].disabled = TRUE;
			disable_array[disable_count] = outports[i].module_id;
			disable_count++;
		}
	}

	for (i=0 ; i<disable_count ; i++) {
		while (1) {
			err = RUAGetProperty(pDCC->pRUA, disable_array[i], RMGenericPropertyID_Enable, &enable, sizeof(enable));
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot get enable state from outport %s\n", GET_OUTPORT_NAME(disable_array[i])));
				return err;
			}

			if (!enable)
				break;
			
			evt.Mask = EMHWLIB_DISPLAY_EVENT_ID(disable_array[i]);
			err = RUAWaitForMultipleEvents(pDCC->pRUA, &evt, 1, 400000, &j);
			if (err == RM_ERROR) {
				RMDBGLOG((ENABLE, "Cannot wait for event\n"));
				return err;
			}
		} 
	}
	
	for (i = 0; i< disable_count ; i++){
		unbind_outport(pDCC, disable_array[i]);
	}

#ifdef WITH_NEW_VCXO
	{
		RMuint32 vcxo_module_id;
		
		/* connect the outport clock to the route VCXO */
		if (DCCGetRouteVCXO(route, &vcxo_module_id) == RM_OK) {
			for (i = 0; i< disable_count ; i++){
				DCCSP(pDCC->pRUA, vcxo_module_id, RMVCXOPropertyID_DisconnectClock, &(outports[i].module_id), sizeof(outports[i].module_id));
			}
		}
	}
#endif

	return RM_OK;
}


static RMstatus format_compatibility(struct DCC *pDCC,
				      struct outport_info *out1,
				      struct outport_info *out2,
				      struct compatibility_info *slaving,
				      RMuint32 allowed_modes)

{


	RMuint32 pixel_clock_1 = 0, active_width_1 = 0, total_width_1 = 0, active_height_1 = 0, total_height_1 = 0, y_offset_top_1 = 0, x_offset_1 = 0;
	RMuint32 pixel_clock_2 = 0, active_width_2 = 0, total_width_2 = 0, active_height_2 = 0, total_height_2 = 0, y_offset_top_2 = 0, x_offset_2 = 0;
	RMbool found_couple = FALSE;

	RMuint32 mode = 0;
	RMuint32 dumped_lines = 0;
	RMuint32 delay_lines = 0;
	RMuint32 delay_pixels = 0;
	RMbool hd_slave = FALSE;

	
	switch(out1->config->format.Type){
	case EMhwlibTVFormatType_Analog:
		pixel_clock_1 = out1->config->format.Format.Analog.PixelClock;
		active_width_1 = out1->config->format.Format.Analog.ActiveWidth;
		total_width_1 = out1->config->format.Format.Analog.Width;
		active_height_1 = out1->config->format.Format.Analog.ActiveHeight;
		total_height_1 = out1->config->format.Format.Analog.Height;
		y_offset_top_1 = out1->config->format.Format.Analog.YOffsetTop;
		x_offset_1 = out1->config->format.Format.Analog.XOffset;
		if(!out1->config->format.Format.Analog.HDTVMode){
			pixel_clock_1 /= 4;
			total_width_1 /= 4;
			x_offset_1 /= 4;
		}
		break;
	case EMhwlibTVFormatType_Digital:
		pixel_clock_1 =out1->config->format.Format.Digital.PixelClock;
		active_width_1 = out1->config->format.Format.Digital.ActiveWidth;
		total_width_1 =out1->config->format.Format.Digital.HTotalSize;
		active_height_1 =out1->config->format.Format.Digital.ActiveHeight;
		total_height_1 =out1->config->format.Format.Digital.VTotalSize;
		y_offset_top_1 =out1->config->format.Format.Digital.YOffsetTop;
		x_offset_1 = out1->config->format.Format.Digital.XOffset;
		if(out1->config->format.Format.Digital.DoubleRateMode){
#ifndef RMFEATURE_HAS_DOUBLE_RATE
			active_width_1 *= 2;
#endif
			pixel_clock_1 *= 2;
			total_width_1 *= 2;
			x_offset_1 *= 2;
		}
		break;
	}
	switch(out2->config->format.Type){
	case EMhwlibTVFormatType_Analog:
		pixel_clock_2 = out2->config->format.Format.Analog.PixelClock;
		active_width_2 = out2->config->format.Format.Analog.ActiveWidth;
		total_width_2 = out2->config->format.Format.Analog.Width;
		active_height_2 = out2->config->format.Format.Analog.ActiveHeight;
		total_height_2 = out2->config->format.Format.Analog.Height;
		y_offset_top_2 = out2->config->format.Format.Analog.YOffsetTop;
		x_offset_2 = out2->config->format.Format.Analog.XOffset;
		if(!out2->config->format.Format.Analog.HDTVMode){
			pixel_clock_2 /= 4;
			total_width_2 /= 4;
			x_offset_2 /= 4;
		}
		break;
	case EMhwlibTVFormatType_Digital:
		pixel_clock_2 = out2->config->format.Format.Digital.PixelClock;
		active_width_2 = out2->config->format.Format.Digital.ActiveWidth;
		total_width_2 = out2->config->format.Format.Digital.HTotalSize;
		active_height_2 = out2->config->format.Format.Digital.ActiveHeight;
		total_height_2 = out2->config->format.Format.Digital.VTotalSize;
		y_offset_top_2 = out2->config->format.Format.Digital.YOffsetTop;
		x_offset_2 = out2->config->format.Format.Digital.XOffset;
		if(out2->config->format.Format.Digital.DoubleRateMode){
#ifndef RMFEATURE_HAS_DOUBLE_RATE
			active_width_2 *= 2;
#endif
			pixel_clock_2 *= 2;
			total_width_2 *= 2;
			x_offset_2 *= 2;
		}
		break;
	}
	
	RMDBGLOG((DISABLE, "height %ld vs %ld\n", total_height_1, total_height_2));
	RMDBGLOG((DISABLE, "width %ld vs %ld\n", total_width_1, total_width_2));
	RMDBGLOG((DISABLE, "active height %ld vs %ld\n", active_height_1, active_height_2));
	RMDBGLOG((DISABLE, "y offset %ld vs %ld\n", y_offset_top_1, y_offset_top_2));
	RMDBGLOG((DISABLE, "pixel clock %ld vs %ld\n", pixel_clock_1, pixel_clock_2));

	if ((out1->config->flags & DCC_OUTPORT_FLAG_CONSTRAINED) || (out2->config->flags & DCC_OUTPORT_FLAG_CONSTRAINED)) {
		if (allowed_modes & slaving_mode_hdsd_buffered) {
			mode = slaving_mode_hdsd_buffered;
			found_couple = TRUE;
			RMDBGLOG((OUTPORTDBG, "I need to slave %s to %s on \"buffered\" mode\n", GET_OUTPORT_NAME(out2->module_id), GET_OUTPORT_NAME(out1->module_id)));
		}
		else {
			slaving->mode = slaving_mode_non_compatible;
			return RM_ERROR;
		}
	}		
	
	if((!found_couple)&&
	   (total_height_1 == total_height_2) &&
	   (active_height_1 == active_height_2) &&
	   (active_width_1 == active_width_2) &&
	   (y_offset_top_1 == y_offset_top_2) &&
	   /* this is to allow modes with double rate to pass the test */
	   ((RMuint64)(total_width_1 * pixel_clock_2) == (RMuint64)(total_width_2 * pixel_clock_1))){
		/* this is what we require for two outports consuming from the same route */
		if((allowed_modes & slaving_mode_same_timing)&&
		   (x_offset_1 == x_offset_2) &&
		   (total_width_1 == total_width_2) &&
		   (pixel_clock_1 == pixel_clock_2)){
			/* this is what we requite for two outports sharing the sime timing signals */
			mode = slaving_mode_same_timing;
			RMDBGLOG((OUTPORTDBG, "I can slave %s to %s on \"same timing\"\n", GET_OUTPORT_NAME(out2->module_id), GET_OUTPORT_NAME(out1->module_id)));
			found_couple = TRUE;
		}
		else if (allowed_modes & slaving_mode_same_route){
			mode = slaving_mode_same_route;
			found_couple = TRUE;
			RMDBGLOG((OUTPORTDBG, "I can slave %s to %s on \"same route\"\n", GET_OUTPORT_NAME(out2->module_id), GET_OUTPORT_NAME(out1->module_id)));
		}
	}

	/* see if we can do on-the-fly */
	if((!found_couple) && (allowed_modes & slaving_mode_hdsd_on_the_fly)){
		struct DispHDSDConverter_OnTheFlyModeParametersX_in_type fly_params_in;
		struct DispHDSDConverter_OnTheFlyModeParametersX_out_type fly_params_out;
		RMstatus err;
		RMbool require_hd_first = FALSE;
		/* if the master is reset-dependent of another outport, we cannot do on-the-fly */
		if(active_height_1 >= active_height_2){
			fly_params_in.HDFormat = out1->config->format;
			fly_params_in.SDFormat = out2->config->format;
		}
		else{
			fly_params_in.SDFormat = out1->config->format;
			fly_params_in.HDFormat = out2->config->format;
			require_hd_first = TRUE;
		}
			
		err = RUAExchangeProperty(pDCC->pRUA, DispHDSDConverter, RMDispHDSDConverterPropertyID_OnTheFlyModeParametersX, 
						  &fly_params_in, sizeof(fly_params_in), &(fly_params_out), sizeof(fly_params_out));
		if(RMSUCCEEDED(err)){
			dumped_lines = fly_params_out.DumpedLines;
			delay_lines = fly_params_out.DelayLines;
			delay_pixels = fly_params_out.DelayPixels;
			hd_slave = fly_params_out.HDFirst;
			mode = slaving_mode_hdsd_on_the_fly;
			if((require_hd_first && hd_slave) || 
			   ((!require_hd_first) && (!hd_slave))){
				   found_couple = TRUE;
				   RMDBGLOG((OUTPORTDBG, "I can slave %s to %s on \"on the fly\"\n", GET_OUTPORT_NAME(out2->module_id), GET_OUTPORT_NAME(out1->module_id)));

			}
		}
	}
	if((!found_couple) && (allowed_modes & slaving_mode_hdsd_buffered)){
		/* WARNING : we should check that the hdsd block is available */
		mode = slaving_mode_hdsd_buffered;
		found_couple = TRUE;
		RMDBGLOG((OUTPORTDBG, "I can slave %s to %s on \"buffered\" mode\n", GET_OUTPORT_NAME(out2->module_id), GET_OUTPORT_NAME(out1->module_id)));

	}

	if(found_couple){
		slaving->mode = mode;
		slaving->dumped_lines = dumped_lines;
		slaving->delay_lines =  delay_lines;
		slaving->delay_pixels = delay_pixels;
		slaving->hd_slave = hd_slave;
		return RM_OK;
	}
		
	slaving->mode = slaving_mode_non_compatible;

	
	return RM_ERROR;
}

static RMstatus do_slaving(struct DCC *pDCC, 
			   struct outport_info *outport,
			   RMbool apply_config)
{
	RMuint32 routing = EMHWLIB_MODULE(DispRouting, 0); 
	struct DispRouting_Route_type disp_route;
	struct DispComponentOut_TimingResetMaster_type reset_master;
	enum EMhwlibHDSDConversionMode hdsd_mode;
	RMbool enable;
	RMstatus err;
	struct EMhwlibClockGenerator clock_pll;

	clock_pll.PLL = outport->clean_divider;
	clock_pll.PLLOut = PLL_VIDEO_OUT;

/* 	if(apply_config){ */
/* 		unbind_outport(pDCC, outport->module_id); */
/* 	} */

	
	/* this outport is its own master */
	if(outport->slaving.master == NULL){
		RMDBGLOG((OUTPORTDBG, "Setting %s as master\n", GET_OUTPORT_NAME(outport->module_id)));
		if(outport->slaving.hd_slave == FALSE){
			if (RMFAILED(err = get_mixer_from_route(outport->config->route, &(outport->route_id)))){
				return err;
			}
		}
		else{
			outport->route_id = DispHDSDConverter;
		}

		if(!apply_config)
			return RM_OK;

		DCCSP(pDCC->pRUA, outport->module_id, RMGenericPropertyID_SyncSourceModuleID, &outport->module_id, sizeof(outport->module_id));

		DCCSP(pDCC->pRUA, outport->module_id, RMGenericPropertyID_MasterClockGenerator, &clock_pll, sizeof(clock_pll));
		switch(outport->config->format.Type){
		case EMhwlibTVFormatType_Analog:
			DCCSP(pDCC->pRUA, outport->module_id, RMGenericPropertyID_AnalogTVFormat, &(outport->config->format.Format.Analog), sizeof(outport->config->format.Format.Analog));
			break;
		case EMhwlibTVFormatType_Digital:
			DCCSP(pDCC->pRUA, outport->module_id, RMGenericPropertyID_DigitalTVFormat, &(outport->config->format.Format.Digital), sizeof(outport->config->format.Format.Digital));
		}

		DCCSP(pDCC->pRUA, outport->module_id, RMGenericPropertyID_Validate, NULL,0 );
#ifdef WITH_NEW_VCXO
		{
			RMuint32 vcxo_module_id;
			
	 		if (DCCGetRouteVCXO(outport->config->route, &vcxo_module_id) == RM_OK) {
				RMDBGLOG((OUTPORTDBG, "VCXO %lu, connectclock %lu\n", vcxo_module_id, outport->module_id));
				DCCSP(pDCC->pRUA, vcxo_module_id, RMVCXOPropertyID_ConnectClock, &(outport->module_id), sizeof(outport->module_id));
			}
		}
#endif
		
		disp_route.Enable = TRUE;
		disp_route.SourceModuleID = outport->route_id;
		disp_route.DestinationModuleID = outport->module_id;
		DCCSP(pDCC->pRUA, routing, RMDispRoutingPropertyID_Route, &disp_route, sizeof(disp_route));

		DCCSP(pDCC->pRUA, DispRouting, RMGenericPropertyID_Validate, NULL, 0);

		enable = TRUE;
		DCCSP(pDCC->pRUA, outport->module_id, RMGenericPropertyID_Enable, &enable, sizeof(enable));

		/* enable route_id (mixer, vcr scaler, colorbars, ...) */
		DCCSP(pDCC->pRUA, outport->route_id, RMGenericPropertyID_Enable, &enable, sizeof(enable));		

		return RM_OK;
	}
		
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO15)
		/* 
		   HACK: Currently on tango15, slaving does not work
		   if the master and slave pixel clocks come from 
		   different pll's. Need to investigate why.
		*/
		clock_pll.PLL = outport->slaving.master->clean_divider;
#endif

	
	switch(outport->slaving.mode){
	case slaving_mode_same_timing:
		RMDBGLOG((OUTPORTDBG, "Slaving %s to %s as \"same timing\"\n", GET_OUTPORT_NAME(outport->module_id), GET_OUTPORT_NAME(outport->slaving.master->module_id)));
		outport->route_id = outport->slaving.master->route_id;
		reset_master.ResetSourceID = outport->module_id;
		reset_master.DelayLines = outport->slaving.delay_lines;
		reset_master.DelayPixels = outport->slaving.delay_pixels;

		if(apply_config){
/* 			DCCSP(pDCC->pRUA, outport->slaving.master->module_id, RMGenericPropertyID_AddSlaveOutput, &(outport->module_id), sizeof(outport->module_id)); */
			DCCSP(pDCC->pRUA, outport->slaving.master->module_id, RMGenericPropertyID_TimingResetMaster, &reset_master, sizeof(reset_master));
			DCCSP(pDCC->pRUA, outport->module_id, RMGenericPropertyID_SyncSourceModuleID, &(outport->module_id), sizeof(outport->module_id));
/* 			DCCSP(pDCC->pRUA, outport->module_id, RMGenericPropertyID_SyncSourceModuleID, &(outport->slaving.master->module_id), sizeof(outport->slaving.master->module_id)); */

		}
		break;
	case slaving_mode_same_route:
		RMDBGLOG((OUTPORTDBG, "Slaving %s to %s as \"same route\"\n", GET_OUTPORT_NAME(outport->module_id), GET_OUTPORT_NAME(outport->slaving.master->module_id)));
		outport->route_id = outport->slaving.master->route_id;
		reset_master.ResetSourceID = outport->module_id;
		reset_master.DelayLines = outport->slaving.delay_lines;
		reset_master.DelayPixels = outport->slaving.delay_pixels;
		if(apply_config){
			DCCSP(pDCC->pRUA, outport->slaving.master->module_id, RMGenericPropertyID_TimingResetMaster, &reset_master, sizeof(reset_master));
/* 			DCCSP(pDCC->pRUA, outport->slaving.master->module_id, RMGenericPropertyID_Validate, NULL,0 ); */
			DCCSP(pDCC->pRUA, outport->module_id, RMGenericPropertyID_SyncSourceModuleID, &(outport->module_id), sizeof(outport->module_id));

		}
		break;
	case slaving_mode_hdsd_on_the_fly:
		if(outport->slaving.hd_slave == TRUE){
			RMDBGLOG((OUTPORTDBG, "Slaving %s to %s as \"inverted on the fly\"\n", GET_OUTPORT_NAME(outport->module_id), GET_OUTPORT_NAME(outport->slaving.master->module_id)));
			if (RMFAILED(err = get_mixer_from_route(outport->config->route, &(outport->route_id)))) 
				return err;
		}
		else{
			RMDBGLOG((OUTPORTDBG, "Slaving %s to %s as \"on the fly\"\n", GET_OUTPORT_NAME(outport->module_id), GET_OUTPORT_NAME(outport->slaving.master->module_id)));
			outport->route_id = DispHDSDConverter;
		}
		hdsd_mode = EMhwlibHDSDConversionMode_OnTheFly;
		reset_master.ResetSourceID = outport->module_id;
		reset_master.DelayLines = outport->slaving.delay_lines;
		reset_master.DelayPixels = outport->slaving.delay_pixels;
		if(apply_config){
			DCCSP(pDCC->pRUA, outport->slaving.master->module_id, RMGenericPropertyID_TimingResetMaster, &reset_master, sizeof(reset_master));
/* 			DCCSP(pDCC->pRUA, outport->slaving.master->module_id, RMGenericPropertyID_Validate, NULL,0 ); */
			DCCSP(pDCC->pRUA, outport->module_id, RMGenericPropertyID_SyncSourceModuleID, &outport->module_id, sizeof(outport->module_id));
		}
		break;
	case slaving_mode_hdsd_buffered:{
		struct DispHDSDConverter_BufferedModeParametersX_in_type buffer_params_in;
		struct DispHDSDConverter_BufferedModeParametersX_out_type buffer_params_out;
		struct DispHDSDConverter_OpenX_type hdsd_open;

		RMDBGLOG((OUTPORTDBG, "Slaving %s to %s as \"buffered mode\"\n", GET_OUTPORT_NAME(outport->module_id), GET_OUTPORT_NAME(outport->slaving.master->module_id)));

		outport->route_id = EMHWLIB_MODULE(DispHDSDConverter, 0);
		hdsd_mode = EMhwlibHDSDConversionMode_Buffered;

		buffer_params_in.HDFormat = outport->slaving.master->config->format;
		
		/* fake a constrained format */
		if (outport->config->flags & DCC_OUTPORT_FLAG_CONSTRAINED) {
			buffer_params_in.SDFormat.Type = EMhwlibTVFormatType_Analog;
			buffer_params_in.SDFormat.Format.Analog.Progressive  = TRUE;
			buffer_params_in.SDFormat.Format.Analog.ActiveWidth  = 720;
			buffer_params_in.SDFormat.Format.Analog.ActiveHeight = 540;
		}
		else 
			buffer_params_in.SDFormat = outport->config->format;
		
		RUAExchangeProperty(pDCC->pRUA, DispHDSDConverter, RMDispHDSDConverterPropertyID_BufferedModeParametersX,
				    &buffer_params_in, sizeof(buffer_params_in), &(buffer_params_out), sizeof(buffer_params_out));

		hdsd_open.HDFormat = buffer_params_in.HDFormat;
		hdsd_open.SDFormat = buffer_params_in.SDFormat;
		hdsd_open.BufferSize = buffer_params_out.BufferSize;
		if(apply_config){
			/* set mixer colorspace to a fixed value */
			enum EMhwlibColorSpace color_space = EMhwlibColorSpace_YUV_709;
			struct EMhwlibColor color = {128, 16, 128}; /* black */

			hdsd_open.BufferAddress = pDCC->rua_malloc(pDCC->pRUA, DisplayBlock, pDCC->dram, RUA_DRAM_UNCACHED, buffer_params_out.BufferSize);
			if(hdsd_open.BufferAddress == 0){
				RMDBGLOG((OUTPORTDBG, "Error while allocating buffer for HD->SD conversion\n"));
				return RM_FATALOUTOFMEMORY;
			}
			DCCSP(pDCC->pRUA, DispHDSDConverter, RMDispHDSDConverterPropertyID_OpenX, &hdsd_open, sizeof(hdsd_open));
			DCCSP(pDCC->pRUA, outport->module_id, RMGenericPropertyID_SyncSourceModuleID, &outport->module_id, sizeof(outport->module_id));

			/* In tango2, the HDSD block does not support on the
			   fly color space conversion, therefore, when used a
			   fixed colorspace must be used and the automatic
			   color space selection from the mixer must be
			   disabled. This is done by setting the color space
			   to EMhwlibColorSpace_YUV_709, see above.
			*/
			DCCSP(pDCC->pRUA, DispMainMixer, RMGenericPropertyID_ColorSpace, &color_space, sizeof(color_space));
			DCCSP(pDCC->pRUA, DispMainMixer, RMGenericPropertyID_BackgroundColor, &color, sizeof(color));

			enable = TRUE;
			DCCSP(pDCC->pRUA, DispMainMixer, RMGenericPropertyID_ForceBackGround, &enable, sizeof(enable));
			DCCSP(pDCC->pRUA, DispMainMixer, RMGenericPropertyID_Enable, &enable, sizeof(enable));
			DCCSP(pDCC->pRUA, DispMainMixer, RMGenericPropertyID_Validate, NULL, 0);
		}
	}

		break;
	case slaving_mode_non_compatible:
		return RM_ERROR;
		break;
	}
	
	if((outport->slaving.mode == slaving_mode_hdsd_on_the_fly) ||
	   (outport->slaving.mode == slaving_mode_hdsd_buffered)){
		if(apply_config){
			DCCSP(pDCC->pRUA, DispHDSDConverter, RMDispHDSDConverterPropertyID_ConversionMode, &hdsd_mode, sizeof(hdsd_mode));
			DCCSP(pDCC->pRUA, DispHDSDConverter, RMDispHDSDConverterPropertyID_DumpedLines, &(outport->slaving.dumped_lines), sizeof(outport->slaving.dumped_lines));
			/* FIXME: if we were already using the hdsd converter the output won't be good until we validate the outports */
			DCCSP(pDCC->pRUA, DispHDSDConverter, RMGenericPropertyID_Validate, NULL, 0);
			enable = TRUE;
			DCCSP(pDCC->pRUA, DispHDSDConverter, RMGenericPropertyID_Enable, &enable, sizeof(enable));
		}
	}

	disp_route.Enable = TRUE;
	if (outport->config->flags & DCC_OUTPORT_FLAG_CONSTRAINED) {
		RMuint32 surface;
		RMuint32 val, mixer, scaler, src_index;
		RMint8 brightness;
		RMuint8 contrast, saturation;
		RMuint32 force_interlaced_boundary;
		enum EMhwlibMixerSourceState state;
		struct EMhwlibDisplayWindow window;
	
		RMDBGLOG((ENABLE, "!!!!!setup VCR scaler!!!!\n"));

		disp_route.SourceModuleID = EMHWLIB_MODULE(DispVCRMultiScaler, 0);
		err = RUAGetProperty(pDCC->pRUA, DispHDSDConverter, RMGenericPropertyID_Surface, &surface, sizeof(surface));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot get hdsd surface\n"));
			return err;
		}
		DCCSP(pDCC->pRUA, disp_route.SourceModuleID, RMGenericPropertyID_Surface, &surface, sizeof(surface));
		enable = TRUE;
		DCCSP(pDCC->pRUA, disp_route.SourceModuleID, RMGenericPropertyID_PersistentSurface, &enable, sizeof(enable));
		
		enable = TRUE;
		DCCSP(pDCC->pRUA, disp_route.SourceModuleID, RMGenericPropertyID_Enable, &enable, sizeof(enable));

		brightness = 0;
		DCCSP(pDCC->pRUA, disp_route.SourceModuleID, RMGenericPropertyID_Brightness, &brightness, sizeof(brightness));
		contrast = 0x80;
		DCCSP(pDCC->pRUA, disp_route.SourceModuleID, RMGenericPropertyID_Contrast, &contrast, sizeof(contrast));
		saturation = 0x80;
		DCCSP(pDCC->pRUA, disp_route.SourceModuleID, RMGenericPropertyID_CbSaturation, &saturation, sizeof(saturation));
		saturation = 0x80;
		DCCSP(pDCC->pRUA, disp_route.SourceModuleID, RMGenericPropertyID_CrSaturation, &saturation, sizeof(saturation));
		
		val = 0x80;
		DCCSP(pDCC->pRUA, disp_route.SourceModuleID, RMGenericPropertyID_Alpha0, &val, sizeof(val));

		window.X = 0;
		window.Y = 0;
		window.Width = 4096;
		window.Height = 4096;
		window.XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
		window.YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
		window.XMode = EMhwlibDisplayWindowValueMode_Relative;
		window.YMode = EMhwlibDisplayWindowValueMode_Relative;
		window.WidthMode = EMhwlibDisplayWindowValueMode_Relative;
		window.HeightMode = EMhwlibDisplayWindowValueMode_Relative;
		DCCSP(pDCC->pRUA, disp_route.SourceModuleID, RMGenericPropertyID_ScalerInputWindow, &window, sizeof(window));

		force_interlaced_boundary = 0x100;
		DCCSP(pDCC->pRUA, disp_route.SourceModuleID, RMGenericPropertyID_ForceInterlacedBoundary, &force_interlaced_boundary, sizeof(force_interlaced_boundary));
	
		DCCSP(pDCC->pRUA, disp_route.SourceModuleID, RMGenericPropertyID_Validate, NULL, 0);
		
		enable = TRUE;
		DCCSP(pDCC->pRUA, DispHDSDConverter, RMDispHDSDConverterPropertyID_ConstrainedOutput, &enable, sizeof(enable));
		DCCSP(pDCC->pRUA, DispHDSDConverter, RMGenericPropertyID_Validate, NULL, 0);
		
		scaler = EMHWLIB_MODULE(DispVCRMultiScaler, 0);
		err = RUAExchangeProperty(pDCC->pRUA, DispMainMixer, RMGenericPropertyID_MixerSourceIndex, &scaler, sizeof(scaler), &src_index, sizeof(src_index));
		if (err != RM_OK) {
			RMDBGLOG((ENABLE, "Cannot get scaler index, %s\n", RMstatusToString(err)));
			return err;
		}
		mixer = EMHWLIB_TARGET_MODULE(DispMainMixer, 0 , src_index);
		
		state = EMhwlibMixerSourceState_Slave;
		DCCSP(pDCC->pRUA, mixer, RMGenericPropertyID_MixerSourceState, &state, sizeof(state));
		
		DCCSP(pDCC->pRUA, mixer, RMGenericPropertyID_Validate, NULL, 0);
	}
	else {
		disp_route.SourceModuleID = outport->route_id;
	}
	disp_route.DestinationModuleID = outport->module_id;

	if(apply_config){
		DCCSP(pDCC->pRUA, routing, RMDispRoutingPropertyID_Route, &disp_route, sizeof(disp_route));
		DCCSP(pDCC->pRUA, outport->module_id, RMGenericPropertyID_MasterClockGenerator, &clock_pll, sizeof(clock_pll));
	}
		
	switch(outport->config->format.Type){
	case EMhwlibTVFormatType_Analog:
		if(apply_config)
			DCCSP(pDCC->pRUA, outport->module_id, RMGenericPropertyID_AnalogTVFormat, &(outport->config->format.Format.Analog), sizeof(outport->config->format.Format.Analog));
		break;
	case EMhwlibTVFormatType_Digital:
		if(apply_config)
			DCCSP(pDCC->pRUA, outport->module_id, RMGenericPropertyID_DigitalTVFormat, &(outport->config->format.Format.Digital), sizeof(outport->config->format.Format.Digital));
		break;
	}

#ifdef WITH_NEW_VCXO
	{
		RMuint32 vcxo_module_id;
		
		if (DCCGetRouteVCXO(outport->config->route, &vcxo_module_id) == RM_OK) {
			RMDBGLOG((ENABLE, "VCXO %lu, connectclock %lu\n", vcxo_module_id, outport->module_id));
			DCCSP(pDCC->pRUA, vcxo_module_id, RMVCXOPropertyID_ConnectClock, &(outport->module_id), sizeof(outport->module_id));
		}
	}
#endif

	if(apply_config){
		DCCSP(pDCC->pRUA, outport->slaving.master->module_id, RMGenericPropertyID_Validate, NULL,0 );
		DCCSP(pDCC->pRUA, DispRouting, RMGenericPropertyID_Validate, NULL, 0);
		enable = TRUE;
 		DCCSP(pDCC->pRUA, outport->module_id, RMGenericPropertyID_Validate, NULL,0 );
		DCCSP(pDCC->pRUA, outport->module_id, RMGenericPropertyID_Enable, &enable, sizeof(enable));
	}
	return RM_OK;

}
				      


static RMstatus DCCSetOutportsWithApply(struct DCC *pDCC, 
					struct DCCOutportsConfig *config,
					struct DCCOutportsInfo *info,
					RMbool apply_config)
{
	RMstatus err;
	RMbool enable;
	RMuint32 i, j, r, outport_id;
	struct outport_info outports[RMFEATURE_OUTPORT_COUNT];
	struct outport_info *first = NULL, *last = NULL, *master, *slave;
	struct compatibility_info links[2], *best_link;
	enum DCCRoute routes[] = {DCCRoute_Main, DCCRoute_Secondary, DCCRoute_ColorBars};
	struct DispRouting_Routing_type current_routing;
	RMuint32 allowed_modes = 0;



	err = RUAGetProperty(pDCC->pRUA, DispRouting, RMDispRoutingPropertyID_Routing, &current_routing, sizeof(current_routing));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get routing\n"));
		return err;
	}

	outport_id = 0;
	i = 0;
	while(outport_id < RMFEATURE_OUTPORT_COUNT){
		outports[outport_id].route_id = 0;
		outports[outport_id].slaving.master = NULL;
		outports[outport_id].slaving.hd_slave = FALSE;
		outports[outport_id].disabled = FALSE;
		switch(i){
#ifdef RMFEATURE_HAS_DIGITAL_OUT
		case 0:
			outports[outport_id].module_id = DispDigitalOut;
			outports[outport_id].config = &(config->digital);
			outports[outport_id].clean_divider = PLL_VIDEO_DIGITAL;
			get_route_from_mixer(current_routing.DigitalOutputSourceModuleID, &outports[outport_id].old_config.route);
			outport_id++;
			break;
#endif
#ifdef RMFEATURE_HAS_COMPONENT_OUT
		case 1:
			outports[outport_id].module_id = DispComponentOut;
			outports[outport_id].config = &(config->component);
			outports[outport_id].clean_divider = PLL_VIDEO_COMPONENT;
			get_route_from_mixer(current_routing.ComponentOutputSourceModuleID, &outports[outport_id].old_config.route);
			outport_id++;
			break;
#endif
#ifdef RMFEATURE_HAS_MAIN_ANALOG_OUT
		case 2:
			outports[outport_id].module_id = DispMainAnalogOut;
			outports[outport_id].config = &(config->analog);
			outports[outport_id].clean_divider = PLL_VIDEO_ANALOG;
			get_route_from_mixer(current_routing.MainAnalogOutputSourceModuleID, &outports[outport_id].old_config.route);
			outport_id++;
			break;
		}
#endif
		i++;
	}
	allowed_modes = slaving_mode_same_timing;
	allowed_modes |= slaving_mode_same_route;
#ifdef RMFEATURE_HAS_HDSD_CONVERTER
	allowed_modes |= (config->allow_hdsd_on_the_fly)? slaving_mode_hdsd_on_the_fly : 0;
	allowed_modes |= (config->allow_hdsd_buffered)? slaving_mode_hdsd_buffered : 0;
#endif


#ifdef RMFEATURE_HAS_HDSD_CONVERTER
	/* remove surface before disabling the route */
	if (apply_config){
		RMuint32 surface1, surface2;
		struct DispHDSDConverter_ConversionBuffer_type conversion_buffer;

		err = RUAGetProperty(pDCC->pRUA, DispHDSDConverter, RMGenericPropertyID_Surface, &surface1, sizeof(surface1));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot get HDSD converter's surface\n"));
			return err;
		}

		err = RUAGetProperty(pDCC->pRUA, DispVCRMultiScaler, RMGenericPropertyID_Surface, &surface2, sizeof(surface2));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot get HDSD converter's surface\n"));
			return err;
		}

		/* VCR scaler was used for CIT */
		if ((surface2 != 0) && (surface1 == surface2)) {
			enable = FALSE;
			DCCSP(pDCC->pRUA, DispHDSDConverter, RMDispHDSDConverterPropertyID_ConstrainedOutput, &enable, sizeof(enable));
			DCCSP(pDCC->pRUA, DispHDSDConverter, RMGenericPropertyID_Validate, NULL, 0);

			enable = FALSE;
			DCCSP(pDCC->pRUA, DispVCRMultiScaler, RMGenericPropertyID_PersistentSurface, &enable, sizeof(enable));
			surface2 = 0;
			DCCSP(pDCC->pRUA, DispVCRMultiScaler, RMGenericPropertyID_Surface, &surface2, sizeof(surface2));
			DCCSP(pDCC->pRUA, DispVCRMultiScaler, RMGenericPropertyID_Validate, NULL, 0);
		}

		err = RUAGetProperty(pDCC->pRUA, DispHDSDConverter, RMDispHDSDConverterPropertyID_ConversionBuffer, &conversion_buffer, sizeof(conversion_buffer));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot get HDSD converter's conversion buffer info\n"));
			return err;
		}
		
		DCCSP(pDCC->pRUA, DispHDSDConverter,RMDispHDSDConverterPropertyID_Close, NULL, 0);
		DCCSP(pDCC->pRUA, DispHDSDConverter, RMGenericPropertyID_Validate, NULL, 0);
		if(conversion_buffer.BufferAddress){
			pDCC->rua_free(pDCC->pRUA, conversion_buffer.BufferAddress);
			RMDBGLOG((OUTPORTDBG, "Freed %ld bytes from 0x%08lx\n", conversion_buffer.BufferSize, conversion_buffer.BufferAddress));
		}
	}
#endif
	
	if (apply_config){
#ifdef RMFEATURE_HAS_HDSD_CONVERTER
		enable = FALSE;
		DCCSP(pDCC->pRUA, DispHDSDConverter, RMGenericPropertyID_Enable, &enable, sizeof(enable));
#endif
		enable = TRUE;
		DCCSP(pDCC->pRUA, DispRouting, RMGenericPropertyID_Enable, &enable, sizeof(enable));
	}



	for(r = 0; r < 3; r++){ 
		RMbool route_has_keeps = FALSE, route_has_changes = FALSE;
		for(i = 0; i< RMFEATURE_OUTPORT_COUNT; i++){
			if((outports[i].config->route == routes[r]) ||
			   (outports[i].old_config.route == routes[r])){
				if(outports[i].config->state == DCCOutportState_Keep){
					route_has_keeps = TRUE;
				}
				else{
					err = RUAGetProperty(pDCC->pRUA, outports[i].module_id, RMGenericPropertyID_Enable, &enable, sizeof(enable));
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Cannot get outport state for %s %ld\n", GET_OUTPORT_NAME(outports[i].module_id), i));
						return err;
					}
					if(((outports[i].old_config.route == routes[r]) && enable) ||
					   ((outports[i].config->route == routes[r]) && (outports[i].config->state == DCCOutportState_Enable))){
						route_has_changes = TRUE;
					}
				}
			}
		}
		if(route_has_changes){
			if(!route_has_keeps){
				if(apply_config) {
					disable_outports_in_route(pDCC, outports, routes[r]);
#ifdef WITH_NEW_VCXO
					{
						RMuint32 vcxo_module_id;
						
						if (DCCGetRouteVCXO(routes[r], &vcxo_module_id) == RM_OK) {
							DCCSP(pDCC->pRUA, vcxo_module_id, RMVCXOPropertyID_Reset, NULL, 0);
						}
					}
#endif
				}
			}
			else{
				RMDBGLOG((ENABLE, "Cannot handle DCCOutportState_Keep on a route that's being modified\n"));
				return RM_ERROR;
			}
		}
	}


	/* this builds a chain of outports:
	   we try to put each outport either as the slave of the last slave
	   or as master of the first master
	   this works well because there is only one hdsd converter and three outports
	   rewritting it so that it's a more generic algorithm seems too complicated
	*/
		

	for (r = 0; r < 3; r++){ 
		first = NULL;
		last = NULL;
		for(i = 0; i< RMFEATURE_OUTPORT_COUNT; i++){
			if(outports[i].config->route == routes[r]){
				if(outports[i].config->state == DCCOutportState_Enable){

					if((first == NULL) || (last == NULL)){
						first = last = &outports[i];
						continue;
					}
					err = format_compatibility(pDCC, last, &outports[i], &(links[0]), allowed_modes);
					err = format_compatibility(pDCC, &outports[i], first, &(links[1]), allowed_modes);

					if(links[1].mode < links[0].mode){
						RMDBGLOG((OUTPORTDBG, "My choice is to put %s as a master of %s\n", GET_OUTPORT_NAME(outports[i].module_id), GET_OUTPORT_NAME(first->module_id )));
						master = &outports[i];
						slave = first;
						best_link = &links[1];
						first = &outports[i];
					}
					else if(links[0].mode < slaving_mode_non_compatible){
						RMDBGLOG((OUTPORTDBG, "My choice is to put %s as a slave of %s\n", GET_OUTPORT_NAME(outports[i].module_id), GET_OUTPORT_NAME(last->module_id )));
						master = last;
						slave = &outports[i];
						best_link = &links[0];
						last = &outports[i];
					}
					else{
						RMDBGLOG((ENABLE, "Cannot handle this configuration\n"));
						return RM_ERROR;
					}
				
					slave->slaving.master = master;
					slave->slaving.mode = best_link->mode;
					slave->slaving.dumped_lines = best_link->dumped_lines;
					slave->slaving.delay_lines = best_link->delay_lines;
					slave->slaving.delay_pixels = best_link->delay_pixels;
					/* if the slave has an hd slave, we need to forward the flag to the master */
					slave->slaving.hd_slave |= best_link->hd_slave;
					master->slaving.hd_slave = slave->slaving.hd_slave;
					if(master->slaving.master && slave->slaving.hd_slave){
						master->slaving.master->slaving.hd_slave = TRUE;
					}
				}
			}
		}

	
		first = NULL;
		for(j = 0; j < RMFEATURE_OUTPORT_COUNT; j++){
			for(i = 0; i < RMFEATURE_OUTPORT_COUNT; i++){
				if(outports[i].config->route == routes[r]){
					if(outports[i].config->state == DCCOutportState_Enable){
						if(outports[i].slaving.master == first){
							do_slaving(pDCC, &outports[i], apply_config);
							first = &outports[i];
						}
					}
				}
			}
		}

	}

	/*
	  check if the HD->SD is not used in buffered mode and the main mixer used.
	   in this case we can set the main mixer color space to None
	*/
	for (i=0 ; i<3 ; i++) {
		if (outports[i].slaving.mode == slaving_mode_hdsd_buffered)
			break;
	}

	/* no hdsd_buffered mode present */
	if (i == 3) {
		for (i=0 ; i<3 ; i++) {
			if (outports[i].route_id == DispMainMixer)
				break;
		}
		
		/* main mixer used, set colorspace to none. In case it was fixed by hdsd buffered */
		if (i<3) {
			enum EMhwlibColorSpace color_space = EMhwlibColorSpace_None;
			
			DCCSP(pDCC->pRUA, DispMainMixer, RMGenericPropertyID_ColorSpace, &color_space, sizeof(color_space));
			DCCSP(pDCC->pRUA, DispMainMixer, RMGenericPropertyID_Validate, NULL, 0);
		}
	}

	if(info!=NULL){
		outport_id = 0;
#ifdef RMFEATURE_HAS_DIGITAL_OUT
		info->digital.source_id = outports[outport_id].route_id;
		outport_id++;
#endif
#ifdef RMFEATURE_HAS_COMPONENT_OUT
		info->component.source_id = outports[outport_id].route_id;
		outport_id++;
#endif

#ifdef RMFEATURE_HAS_MAIN_ANALOG_OUT
		info->analog.source_id = outports[outport_id].route_id;
		outport_id++;
#endif

#ifdef RMFEATURE_HAS_COMPOSITE_OUT
		info->composite.source_id = outports[outport_id].route_id;
		outport_id++;
#endif

	}

	return RM_OK;

}


RMstatus DCCSetOutports(struct DCC *pDCC, 
			struct DCCOutportsConfig *config,
			struct DCCOutportsInfo *info)
{
	return DCCSetOutportsWithApply(pDCC, config, info, TRUE);
}

RMstatus DCCGetOutportsInfo(struct DCC *pDCC, 
			    struct DCCOutportsConfig *config, 
			    struct DCCOutportsInfo *info)
{
	return DCCSetOutportsWithApply(pDCC, config, info, FALSE);
}



RMstatus DCCInitOutportsConfigStructure(struct DCC *pDCC,
					struct DCCOutportsConfig *config)
{

	config->digital.state = DCCOutportState_Disable;
/* 	config->digital.format  */
	config->digital.route = DCCRoute_Main;
	config->digital.flags = 0;

	config->component.state = DCCOutportState_Disable;
/* 	config->component.format  */
	config->component.route = DCCRoute_Main;
	config->component.flags = 0;

	config->analog.state = DCCOutportState_Disable;
/* 	config->analog.format  */
	config->analog.route = DCCRoute_Main;
	config->analog.flags = 0;

	config->allow_hdsd_on_the_fly = TRUE;
	config->allow_hdsd_buffered = TRUE;
 
	return RM_OK;
}
