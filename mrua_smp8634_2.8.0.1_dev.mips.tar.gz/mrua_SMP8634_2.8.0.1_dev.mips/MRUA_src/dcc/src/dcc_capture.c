/*****************************************
 Copyright © 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   dcc.c
  @brief  Decoding Chain Control API

  @author Julien Soulier
  @date   2003-10-02
*/

// to enable or disable the debug messages of this source file, put 1 or 0 below
#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

#include "dcc_common.h"

#define DCCCAPTURE_PROGRESSIVE_BUF 5  // number of picture buffers for progressive capture
#define DCCCAPTURE_INTERLACED_BUF 5   // number of picture buffers for interlaced capture without de-interlacing
#define DCCCAPTURE_DEINT_BUF 6        // number of picture buffers for interlaced capture with de-interlacing

RMstatus DCCOpenVideoInputSource(
	struct DCC *pDCC, 
	struct DCCCaptureProfile *pProfile, 
	RMuint32 TimerNumber, 
	RMuint32 dram, 
	struct DCCVideoSource **ppVideoSource)
{
	struct DispVideoInput_DRAMSize_in_type dram_in;
	struct DispVideoInput_DRAMSize_out_type dram_out;
	struct DispVideoInput_Open_type profile;
	struct DCCVideoSource *pVideoSource;
	RMuint32 surface, input;
	RMstatus err;
	
	if (ppVideoSource == NULL) {
		RMDBGLOG((ENABLE, "WARNING: DCCOpenVideoInputSource() ppVideoSource == NULL!\n"));
	}
	if (ppVideoSource && *ppVideoSource) {
		pVideoSource = *ppVideoSource;
	} else {
		pVideoSource = (struct DCCVideoSource *)RMMalloc(sizeof(struct DCCVideoSource));
		if (pVideoSource == NULL) {
			RMDBGLOG((ENABLE, "ERROR: could not allocate %lu bytes in system memory!\n", sizeof(struct DCCVideoSource)));
			return RM_FATALOUTOFMEMORY;
		}
		if (ppVideoSource) *ppVideoSource = pVideoSource;
		RMMemset((void*)pVideoSource, 0, sizeof(struct DCCVideoSource));
	}
	pVideoSource->pRUA = pDCC->pRUA;
	pVideoSource->pDCC = pDCC;

	input = EMHWLIB_MODULE(DispVideoInput, 0);
	pVideoSource->decoder_moduleID = input;
	
	pVideoSource->timer_number = TimerNumber;
	
	{
		struct DispDigitalOut_PadsControl_type ipad;
		RMMemset(&ipad, 0, sizeof(ipad));
		ipad.APIVersion = 1;
		ipad.ModifyVideoInputV2 = TRUE;
		ipad.VideoInputV2 = pProfile->UseV2Pads;
		DCCSPERR(pDCC->pRUA, DispDigitalOut, 
			RMDispDigitalOutPropertyID_PadsControl, 
			&ipad, sizeof(ipad), 
			"Failed to set property PadsControl");
		DCCSPERR(pDCC->pRUA, DispDigitalOut, 
			RMGenericPropertyID_Validate, NULL, 0, 
			"Failed to validate DispDigitalOut");
	}
	
	dram_in.ColorMode = pProfile->ColorMode;
	dram_in.ColorFormat = pProfile->ColorFormat;
	dram_in.SamplingMode = pProfile->SamplingMode;
	dram_in.Width = pProfile->Width;
	dram_in.Height = pProfile->Height;
	dram_in.NumBuffer = (pProfile->Width && pProfile->Height) ? 
		(pProfile->Interlaced ? 
			(pProfile->DeInt ? DCCCAPTURE_DEINT_BUF : DCCCAPTURE_INTERLACED_BUF) : 
			DCCCAPTURE_PROGRESSIVE_BUF) : 
		0;
	err = RUAExchangeProperty(pDCC->pRUA, input, 
		RMDispVideoInputPropertyID_DRAMSize, 
		&dram_in, sizeof(dram_in), &dram_out, sizeof(dram_out));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting property RMDispVideoInputPropertyID_DRAMSize! %s\n", RMstatusToString(err)));
		return err;
	}
	
	profile.ColorMode = dram_in.ColorMode;
	profile.ColorFormat = dram_in.ColorFormat;
	profile.SamplingMode = dram_in.SamplingMode;
	profile.Width = dram_in.Width;
	profile.Height = dram_in.Height;
	profile.NumBuffer = dram_in.NumBuffer;
	profile.ColorSpace = pProfile->ColorSpace;
	profile.PixelAspectRatio.X = pProfile->PixelAspectRatio.X;
	profile.PixelAspectRatio.Y = pProfile->PixelAspectRatio.Y;
	profile.STCIndex = TimerNumber;
	
	if (pVideoSource->uncached_address) 
		pDCC->rua_free(pDCC->pRUA, pVideoSource->uncached_address);
	profile.BufferSize = dram_out.BufferSize;
	profile.BufferAddress = pDCC->rua_malloc(pDCC->pRUA, input, dram, RUA_DRAM_UNCACHED, profile.BufferSize);
	if (! profile.BufferAddress) {
		RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in cached DRAM %lu!\n", profile.BufferSize, dram));
		return RM_FATALOUTOFMEMORY;
	}
	RMDBGLOG((LOCALDBG, "video input cached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n", 
		profile.BufferAddress, profile.BufferSize, profile.BufferAddress + profile.BufferSize));
	pVideoSource->uncached_address = profile.BufferAddress;
	
	err = RUASetProperty(pDCC->pRUA, input, 
		RMDispVideoInputPropertyID_Open, 
		&profile, sizeof(profile), 0);
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot create the video input surface, %s\n", RMstatusToString(err)));
		return err;
	}
	
	err = RUAGetProperty(pDCC->pRUA, input, 
		RMGenericPropertyID_Surface, 
		&surface, sizeof(surface));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get the video input surface, %s\n", RMstatusToString(err)));
		return err;
	}
	pVideoSource->surface = surface;
	
	return RM_OK;
}

RMstatus DCCOpenGraphicInputSource(
	struct DCC *pDCC, 
	struct DCCCaptureProfile *pProfile, 
	RMuint32 TimerNumber, 
	RMuint32 dram, 
	struct DCCVideoSource **ppVideoSource)
{
	struct DispGraphicInput_DRAMSize_in_type dram_in;
	struct DispGraphicInput_DRAMSize_out_type dram_out;
	struct DispGraphicInput_Open_type profile;
	struct DCCVideoSource *pVideoSource;
	RMuint32 surface, input;
	RMstatus err;
	
	if (ppVideoSource == NULL) {
		RMDBGLOG((ENABLE, "WARNING: DCCOpenGraphicInputSource() ppVideoSource == NULL!\n"));
	}
	if (ppVideoSource && *ppVideoSource) {
		pVideoSource = *ppVideoSource;
	} else {
		pVideoSource = (struct DCCVideoSource *)RMMalloc(sizeof(struct DCCVideoSource));
		if (pVideoSource == NULL) {
			RMDBGLOG((ENABLE, "ERROR: could not allocate %lu bytes in system memory!\n", sizeof(struct DCCVideoSource)));
			return RM_FATALOUTOFMEMORY;
		}
		if (ppVideoSource) *ppVideoSource = pVideoSource;
		RMMemset((void*)pVideoSource, 0, sizeof(struct DCCVideoSource));
	}
	pVideoSource->pRUA = pDCC->pRUA;
	pVideoSource->pDCC = pDCC;

	input = EMHWLIB_MODULE(DispGraphicInput, 0);
	pVideoSource->decoder_moduleID = input;
	
	pVideoSource->timer_number = TimerNumber;
	
	{
		struct DispDigitalOut_PadsControl_type ipad;
		RMMemset(&ipad, 0, sizeof(ipad));
		ipad.APIVersion = 1;
		ipad.ModifyGraphicInputV2 = TRUE;
		ipad.GraphicInputV2 = pProfile->UseV2Pads;
		DCCSPERR(pDCC->pRUA, DispDigitalOut, 
			RMDispDigitalOutPropertyID_PadsControl, 
			&ipad, sizeof(ipad), 
			"Failed to set property PadsControl");
		DCCSPERR(pDCC->pRUA, DispDigitalOut, 
			RMGenericPropertyID_Validate, NULL, 0, 
			"Failed to validate DispDigitalOut");
	}
	
	dram_in.ColorMode = pProfile->ColorMode;
	dram_in.ColorFormat = pProfile->ColorFormat;
	dram_in.SamplingMode = pProfile->SamplingMode;
	dram_in.Width = pProfile->Width;
	dram_in.Height = pProfile->Height;
	dram_in.NumBuffer = (pProfile->Width && pProfile->Height) ? 
		(pProfile->Interlaced ? 
			(pProfile->DeInt ? DCCCAPTURE_DEINT_BUF : DCCCAPTURE_INTERLACED_BUF) : 
			DCCCAPTURE_PROGRESSIVE_BUF) : 
		0;
	err = RUAExchangeProperty(pDCC->pRUA, input, 
		RMDispGraphicInputPropertyID_DRAMSize, 
		&dram_in, sizeof(dram_in), &dram_out, sizeof(dram_out));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting property RMDispGraphicInputPropertyID_DRAMSize! %s\n", RMstatusToString(err)));
		return err;
	}
	
	profile.ColorMode = dram_in.ColorMode;
	profile.ColorFormat = dram_in.ColorFormat;
	profile.SamplingMode = dram_in.SamplingMode;
	profile.Width = dram_in.Width;
	profile.Height = dram_in.Height;
	profile.NumBuffer = dram_in.NumBuffer;
	profile.ColorSpace = pProfile->ColorSpace;
	profile.PixelAspectRatio.X = pProfile->PixelAspectRatio.X;
	profile.PixelAspectRatio.Y = pProfile->PixelAspectRatio.Y;
	profile.STCIndex = TimerNumber;
	
	if (pVideoSource->uncached_address) 
		pDCC->rua_free(pDCC->pRUA, pVideoSource->uncached_address);
	profile.BufferSize = dram_out.BufferSize;
	profile.BufferAddress = pDCC->rua_malloc(pDCC->pRUA, input, dram, RUA_DRAM_UNCACHED, profile.BufferSize);
	if (! profile.BufferAddress) {
		RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in cached DRAM %lu!\n", profile.BufferSize, dram));
		return RM_FATALOUTOFMEMORY;
	}
	RMDBGLOG((LOCALDBG, "video input cached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n", profile.BufferAddress, profile.BufferSize, profile.BufferAddress + profile.BufferSize));
	pVideoSource->uncached_address = profile.BufferAddress;
	
	err = RUASetProperty(pDCC->pRUA, input, 
		RMDispGraphicInputPropertyID_Open, 
		&profile, sizeof(profile), 0);
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot create the graphic input surface, %s\n", RMstatusToString(err)));
		return err;
	}
	
	err = RUAGetProperty(pDCC->pRUA, input, RMGenericPropertyID_Surface, &surface, sizeof(surface));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get the graphic input surface, %s\n", RMstatusToString(err)));
		return err;
	}
	pVideoSource->surface = surface;
	
	return RM_OK;
}

/* If bussize is 8 bit, the following members of fmt have to be already doubled:
   PixelClock, ActiveWidth, XOffset, HTotalSize, HSyncWidth */
RMstatus DCCSetupVideoInputFormat(
	struct DCC *pDCC, 
	struct EMhwlibTVFormatDigital fmt,
	enum EMhwlibDigitalTimingSignal DigitalTimingSignal, 
	RMbool UseVideoValid, 
	RMuint32 bussize, 
	RMint32 over_pos_x, 
	RMint32 over_pos_y, 
	RMuint32 over_width, 
	RMuint32 over_height, 
	RMbool InvertVSync, 
	RMbool InvertHSync, 
	RMbool InvertFieldID, 
	RMbool UseGPIOFieldID)
{
	RMuint32 vo_in;
	struct DispVideoInput_InputFormat_type vi_format;
	struct Input_GPIOFieldID_type gpio;
	RMuint32 SyncSourceModuleID = 0;  // external sync
	RMbool enable = TRUE;
	
	if (DigitalTimingSignal == EMhwlibDigitalTimingSignal_601) {
		vi_format.ProtocolV = UseVideoValid; // 601 with or without vvld
		vi_format.ProtocolM = TRUE;  // 601
	} else {
		vi_format.ProtocolV = FALSE; // 656
		vi_format.ProtocolM = FALSE; // 656
	}
	vi_format.ComponentOrderReverse = FALSE; 
	vi_format.TrailingEdge = FALSE; 
	vi_format.VSyncDelay = FALSE; 
	
	gpio.GPIONumber = 2;
	gpio.Enable = UseGPIOFieldID;
	gpio.Invert = InvertFieldID;
	
	vo_in = EMHWLIB_MODULE(DispVideoInput, 0);
	
	DCCSPERR(pDCC->pRUA, vo_in, 
		RMDispVideoInputPropertyID_BusSize, &bussize, sizeof(bussize), 
		"Failed to set property DispVideoInputProperty_BusSize");
	if (- over_pos_x > (RMint32)fmt.XOffset) over_pos_x = - fmt.XOffset;
	if (- over_pos_y > (RMint32)fmt.YOffsetTop) over_pos_y = - fmt.YOffsetTop;
	if ((!fmt.Progressive) && (- over_pos_y > (RMint32)fmt.YOffsetBottom)) over_pos_y = - fmt.YOffsetBottom;
	fmt.ActiveWidth += over_width;
	fmt.ActiveHeight += over_height;
	fmt.XOffset += over_pos_x;
	fmt.YOffsetTop += over_pos_y;
	fmt.YOffsetBottom += (fmt.Progressive ? 0 : over_pos_y);
	if (InvertVSync) fmt.VSyncActiveLow = ! fmt.VSyncActiveLow;
	if (InvertHSync) fmt.HSyncActiveLow = ! fmt.HSyncActiveLow;
	DCCSPERR(pDCC->pRUA, vo_in, 
		RMGenericPropertyID_TVFormat, &fmt, sizeof(fmt), 
		"Failed to set property TVFormat");
	DCCSPERR(pDCC->pRUA, vo_in, 
		RMGenericPropertyID_SyncSourceModuleID, &SyncSourceModuleID, sizeof(SyncSourceModuleID), 
		"Failed to set property DispVideoInputProperty_SyncSourceModuleID");
	DCCSPERR(pDCC->pRUA, vo_in, 
		RMDispVideoInputPropertyID_InputFormat, &vi_format, sizeof(vi_format), 
		"Failed to set property DispVideoInputProperty_InputFormat");
	DCCSPERR(pDCC->pRUA, vo_in, 
		RMGenericPropertyID_GPIOFieldID, &gpio, sizeof(gpio), 
		"Failed to set property GPIOFieldID");
	DCCSPERR(pDCC->pRUA, vo_in, 
		RMGenericPropertyID_Validate, NULL, 0, 
		"Failed to validate input");
	DCCSPERR(pDCC->pRUA, vo_in, 
		RMGenericPropertyID_Enable, &enable, sizeof(enable), 
		"Failed to enable input");
	return RM_OK;
}

RMstatus DCCSetupVideoInput(
	struct DCC *pDCC, 
	enum EMhwlibTVStandard standard,
	enum EMhwlibDigitalTimingSignal DigitalTimingSignal, 
	RMbool UseVideoValid, 
	RMuint32 bussize, 
	RMint32 over_pos_x, 
	RMint32 over_pos_y, 
	RMuint32 over_width, 
	RMuint32 over_height, 
	RMbool InvertVSync, 
	RMbool InvertHSync, 
	RMbool InvertFieldID, 
	RMbool UseGPIOFieldID)
{
	RMstatus err;
	RMuint32 vo_in;
	struct EMhwlibTVFormatDigital fmt;
	
	vo_in = EMHWLIB_MODULE(DispVideoInput, 0);
	
	DCCSPERR(pDCC->pRUA, vo_in, 
		RMDispVideoInputPropertyID_BusSize, &bussize, sizeof(bussize), 
		"Failed to set property DispVideoInputProperty_BusSize");
	DCCSPERR(pDCC->pRUA, vo_in, 
		RMGenericPropertyID_TVStandard, &standard, sizeof(standard), 
		"Failed to set property DispVideoInputProperty_TVStandard");
	DCCSPERR(pDCC->pRUA, vo_in, 
		RMDispVideoInputPropertyID_BusSize, &bussize, sizeof(bussize), 
		"Failed to set property DispVideoInputProperty_BusSize");
	err = RUAGetProperty(pDCC->pRUA, vo_in, 
		RMGenericPropertyID_TVFormat, &fmt, sizeof(fmt));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Failed to get property TVFormat\n"));
		return err;
	}
	return DCCSetupVideoInputFormat(pDCC, fmt, DigitalTimingSignal, UseVideoValid, bussize, over_pos_x, over_pos_y, over_width, over_height, InvertVSync, InvertHSync, InvertFieldID, UseGPIOFieldID);
}

/* If bussize is 8 bit, the following members of fmt have to be already doubled:
   PixelClock, ActiveWidth, XOffset, HTotalSize, HSyncWidth */
RMstatus DCCSetupGraphicInputFormat(
	struct DCC *pDCC, 
	struct EMhwlibTVFormatDigital fmt,
	enum EMhwlibDigitalTimingSignal DigitalTimingSignal, 
	RMbool UseVideoValid, 
	RMuint32 bussize,
	RMint32 over_pos_x, 
	RMint32 over_pos_y, 
	RMuint32 over_width, 
	RMuint32 over_height, 
	RMbool DualEdge, 
	RMbool DualEdgeWidth, 
	RMbool DualEdgeInvert, 
	enum EMhwlibInputColorFormat InputColorFormat, 
	enum EMhwlibColorSpace InputColorSpace, 
	RMbool InvertVSync, 
	RMbool InvertHSync, 
	RMbool InvertFieldID, 
	RMbool UseGPIOFieldID)
{
	RMuint32 vo_in;
	struct DispGraphicInput_InputFormat_type vi_inf;
	struct DispGraphicInput_OutputFormat_type vi_outf;
	struct DispGraphicInput_KeyColor_type vi_key;
	struct Input_GPIOFieldID_type gpio;
	RMuint32 SyncSourceModuleID = 0;  // external sync
	RMuint32 SyncControlModuleID = DispGraphicInput;
	RMbool enable = TRUE;
	
	if (DigitalTimingSignal == EMhwlibDigitalTimingSignal_601) {
		vi_inf.ProtocolV = UseVideoValid; // 601 with or without vvld
		vi_inf.ProtocolP = TRUE;  // 601
	} else {
		vi_inf.ProtocolV = FALSE; // 656
		vi_inf.ProtocolP = FALSE; // 656
	}
	vi_inf.ProtocolL = FALSE;
	vi_inf.ComponentOrderRBG = FALSE; 
	vi_inf.TrailingEdge = FALSE; 
	vi_inf.VSyncDelay = FALSE; 
	vi_inf.InputColorFormat = InputColorFormat;
	
	vi_outf.OutRouteModuleID = DispGraphicInput;  // to DRAM
	vi_outf.Alpha0 = 0xFF;
	vi_outf.Alpha1 = 0xFF;
	vi_outf.FadingEnable = FALSE;
	vi_outf.DualEdgeInvert = DualEdgeInvert;
	vi_outf.DualEdgeWidth = DualEdgeWidth;
	vi_outf.DualEdge = DualEdge;
	vi_outf.BusSize = bussize;
	
	vi_key.KeyEnable = FALSE;
	vi_key.KeyColorRCr = 0;
	vi_key.KeyColorGY = 0;
	vi_key.KeyColorBCb = 0;
	vi_key.KeyColorRange = 0;
	
	gpio.GPIONumber = 3;
	gpio.Enable = UseGPIOFieldID;
	gpio.Invert = InvertFieldID;
	
	vo_in = DispGraphicInput;
	
	DCCSPERR(pDCC->pRUA, vo_in, 
		RMDispGraphicInputPropertyID_OutputFormat, &vi_outf, sizeof(vi_outf), 
		"Failed to set property DispGraphicInputProperty_OutputFormat");
	if (- over_pos_x > (RMint32)fmt.XOffset) over_pos_x = - fmt.XOffset;
	if (- over_pos_y > (RMint32)fmt.YOffsetTop) over_pos_y = - fmt.YOffsetTop;
	if ((!fmt.Progressive) && (- over_pos_y > (RMint32)fmt.YOffsetBottom)) over_pos_y = - fmt.YOffsetBottom;
	fmt.ActiveWidth += over_width;
	fmt.ActiveHeight += over_height;
	fmt.XOffset += over_pos_x;
	fmt.YOffsetTop += over_pos_y;
	fmt.YOffsetBottom += (fmt.Progressive ? 0 : over_pos_y);
	if (InvertVSync) fmt.VSyncActiveLow = ! fmt.VSyncActiveLow;
	if (InvertHSync) fmt.HSyncActiveLow = ! fmt.HSyncActiveLow;
	DCCSPERR(pDCC->pRUA, vo_in, 
		RMGenericPropertyID_TVFormat, &fmt, sizeof(fmt), 
		"Failed to set property TVFormat");
	DCCSPERR(pDCC->pRUA, vo_in, 
		RMGenericPropertyID_SyncSourceModuleID, &SyncSourceModuleID, sizeof(SyncSourceModuleID), 
		"Failed to set property DispGraphicInputProperty_SyncSourceModuleID");
	DCCSPERR(pDCC->pRUA, vo_in, 
		RMDispGraphicInputPropertyID_InputFormat, &vi_inf, sizeof(vi_inf), 
		"Failed to set property DispGraphicInputProperty_InputFormat");
	DCCSPERR(pDCC->pRUA, vo_in, 
		RMGenericPropertyID_ColorSpace, &InputColorSpace, sizeof(InputColorSpace), 
		"Failed to set property DispGraphicInputProperty_ColorSpace");
	DCCSPERR(pDCC->pRUA, vo_in, 
		RMDispGraphicInputPropertyID_OutputFormat, &vi_outf, sizeof(vi_outf), 
		"Failed to set property DispGraphicInputProperty_OutputFormat");
	DCCSPERR(pDCC->pRUA, vo_in, 
		RMDispGraphicInputPropertyID_KeyColor, &vi_key, sizeof(vi_key), 
		"Failed to set property DispGraphicInputProperty_KeyColor");
	DCCSPERR(pDCC->pRUA, vo_in, 
		RMDispGraphicInputPropertyID_SyncControlModuleID, &SyncControlModuleID, sizeof(SyncControlModuleID), 
		"Failed to set property DispGraphicInputProperty_SyncControlModuleID");
	DCCSPERR(pDCC->pRUA, vo_in, 
		RMGenericPropertyID_GPIOFieldID, &gpio, sizeof(gpio), 
		"Failed to set property GPIOFieldID");
	DCCSPERR(pDCC->pRUA, vo_in, 
		RMGenericPropertyID_Validate, NULL, 0, 
		"Failed to validate input");
	DCCSPERR(pDCC->pRUA, vo_in, 
		RMGenericPropertyID_Enable, &enable, sizeof(enable), 
		"Failed to enable input");
	return RM_OK;
}

RMstatus DCCSetupGraphicInput(
	struct DCC *pDCC, 
	enum EMhwlibTVStandard standard,
	enum EMhwlibDigitalTimingSignal DigitalTimingSignal, 
	RMbool UseVideoValid, 
	RMuint32 bussize,
	RMint32 over_pos_x, 
	RMint32 over_pos_y, 
	RMuint32 over_width, 
	RMuint32 over_height, 
	RMbool DualEdge, 
	RMbool DualEdgeWidth, 
	RMbool DualEdgeInvert, 
	enum EMhwlibInputColorFormat InputColorFormat, 
	enum EMhwlibColorSpace InputColorSpace, 
	RMbool InvertVSync, 
	RMbool InvertHSync, 
	RMbool InvertFieldID, 
	RMbool UseGPIOFieldID)
{
	RMstatus err;
	RMuint32 vo_in;
	struct DispGraphicInput_OutputFormat_type vi_outf;
	struct EMhwlibTVFormatDigital fmt;
	
	vo_in = DispGraphicInput;
	
	vi_outf.OutRouteModuleID = DispGraphicInput;  // to DRAM
	vi_outf.Alpha0 = 0xFF;
	vi_outf.Alpha1 = 0xFF;
	vi_outf.FadingEnable = FALSE;
	vi_outf.DualEdgeInvert = DualEdgeInvert;
	vi_outf.DualEdgeWidth = DualEdgeWidth;
	vi_outf.DualEdge = DualEdge;
	vi_outf.BusSize = bussize;
	
	DCCSPERR(pDCC->pRUA, vo_in, /* set first, in case it's 8 bit*/
		RMDispGraphicInputPropertyID_OutputFormat, &vi_outf, sizeof(vi_outf), 
		"Failed to set property DispGraphicInputProperty_OutputFormat");
	DCCSPERR(pDCC->pRUA, vo_in, 
		RMGenericPropertyID_TVStandard, &standard, sizeof(standard), 
		"Failed to set property DispGraphicInputProperty_TVStandard");
	err = RUAGetProperty(pDCC->pRUA, vo_in, 
		RMGenericPropertyID_TVFormat, &fmt, sizeof(fmt));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Failed to get property TVFormat\n"));
		return err;
	}
	return DCCSetupGraphicInputFormat(pDCC, fmt, DigitalTimingSignal, UseVideoValid, bussize, over_pos_x, over_pos_y, over_width, over_height, DualEdge, DualEdgeWidth, DualEdgeInvert, InputColorFormat, InputColorSpace, InvertVSync, InvertHSync, InvertFieldID, UseGPIOFieldID);
}

// specify a VBI data window into the video picture
RMstatus DCCSetupVBICapture(
	struct DCC *pDCC, 
	RMuint32 input, 
	RMuint32 x, 
	RMuint32 y, 
	RMuint32 w, 
	RMuint32 h, 
	RMuint32 buf, 
	RMuint32 size)
{
	struct Input_VBIStore_type vbi;
	
	vbi.x = x;
	vbi.y = y;
	vbi.w = w;
	vbi.h = h;
	vbi.Buffer = buf;
	vbi.BufferSize = size;
	DCCSPERR(pDCC->pRUA, input, 
		RMGenericPropertyID_VBIStore, &vbi, sizeof(vbi), 
		"Error setting property VBIStore");
	DCCSPERR(pDCC->pRUA, input, 
		RMGenericPropertyID_Validate, NULL, 0, 
		"Failed to validate input");
	return RM_OK;
}

// capture raw VBI lines from vertical blank area
RMstatus DCCSetupVBICaptureRaw(
	struct DCC *pDCC, 
	RMuint32 input, 
	RMuint32 TopVBIOffset, 
	RMuint32 TopVBILineEnable, 
	RMuint32 BottomVBIOffset, 
	RMuint32 BottomVBILineEnable, 
	RMuint32 buf, 
	RMuint32 size)
{
	struct Input_VBICaptureRaw_type vbi;
	
	vbi.TopVBIOffset = TopVBIOffset;
	vbi.TopVBILineEnable = TopVBILineEnable;
	vbi.BottomVBIOffset = BottomVBIOffset;
	vbi.BottomVBILineEnable = BottomVBILineEnable;
	vbi.Buffer = buf;
	vbi.BufferSize = size;
	DCCSPERR(pDCC->pRUA, input, 
		RMGenericPropertyID_VBICaptureRaw, &vbi, sizeof(vbi), 
		"Error setting property VBICaptureRaw");
	DCCSPERR(pDCC->pRUA, input, 
		RMGenericPropertyID_Validate, NULL, 0, 
		"Failed to validate input");
	return RM_OK;
}

// capture sliced VBI data from horizontal blank area
RMstatus DCCSetupVBICaptureANC(
	struct DCC *pDCC, 
	RMuint32 input, 
	RMbool Enable, 
	RMuint32 ActiveWidth, 
	RMuint32 ActiveHeight, 
	RMuint32 YOffsetTop, 
	RMuint32 YOffsetBottom, 
	RMuint32 buf, 
	RMuint32 size)
{
	struct Input_VBICaptureANC_type vbi;
	
	vbi.Enable = Enable;
	vbi.ActiveWidth = ActiveWidth;
	vbi.ActiveHeight = ActiveHeight;
	vbi.YOffsetTop = YOffsetTop;
	vbi.YOffsetBottom = YOffsetBottom;
	vbi.Buffer = buf;
	vbi.BufferSize = size;
	DCCSPERR(pDCC->pRUA, input, 
		RMGenericPropertyID_VBICaptureANC, &vbi, sizeof(vbi), 
		"Error setting property VBICaptureANC");
	DCCSPERR(pDCC->pRUA, input, 
		RMGenericPropertyID_Validate, NULL, 0, 
		"Failed to validate input");
	return RM_OK;
}

// get a data buffer received from the VBI
RMstatus DCCGetVBIData(
	struct DCC *pDCC, 
	RMuint32 input, 
	RMuint32 *pFlags, 
	RMuint32 *pPTS, 
	RMuint32 *pSequenceNumber, 
	RMuint32 *pDataSize, 
	RMuint16 **pData)
{
	RMstatus err;
	struct Input_VBIData_type vbi;
	
	err = RUAGetProperty(pDCC->pRUA, input, 
		RMGenericPropertyID_VBIData, 
		&vbi, sizeof(vbi));
	if (RMFAILED(err) && (err != RM_PENDING) && vbi.DataSize) 
		RMDBGLOG((ENABLE, "Error getting property VBIData! %s\n", RMstatusToString(err)));
	
	*pFlags = vbi.Flags;
	*pPTS = vbi.PTS;
	*pDataSize = vbi.DataSize;
	*pSequenceNumber = vbi.SequenceNumber;
	*pData = vbi.Data;
	
	return err;
}
