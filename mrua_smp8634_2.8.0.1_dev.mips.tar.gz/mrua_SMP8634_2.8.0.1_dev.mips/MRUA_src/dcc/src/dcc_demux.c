/*****************************************
 Copyright © 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   dcc.c
  @brief  Decoding Chain Control API

  @author Julien Soulier
  @date   2003-10-02
*/

// to enable or disable the debug messages of this source file, put 1 or 0 below
#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

#include "dcc_common.h"

static RMstatus send_demux_task_command(struct RUA *pRUA, RMuint32 demux_task, enum DemuxTask_Command_type command) 
{
	struct RUAEvent evt;
	enum DemuxTask_State_type state;
	RMuint32 index;
	RMstatus err;

	evt.ModuleID = demux_task;
	evt.Mask = RUAEVENT_COMMANDCOMPLETION;
	
	err = RUAResetEvent(pRUA, &evt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot reset demux_task command completion event, %s\n", RMstatusToString(err)));
		return err;
	}
	
	err = RUASetProperty(pRUA, demux_task, RMDemuxTaskPropertyID_Command, &command, sizeof(command), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot send demux_task command, %s\n", RMstatusToString(err)));
		return err;
	}
		
	evt.ModuleID = demux_task;
	evt.Mask = RUAEVENT_COMMANDCOMPLETION;
	err = RUAWaitForMultipleEvents(pRUA, &evt, 1, WAIT_COMMAND_TIMEOUT_US, &index);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "wait for demux_task command completion %d failed, %s\n", command, RMstatusToString(err)));
		return err;
	}
	
	err = RUAGetProperty(pRUA, demux_task, RMDemuxTaskPropertyID_State, &state, sizeof(state));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get demux_task state, %s\n", RMstatusToString(err)));
		return err;
	}
	
	RMDBGLOG((LOCALDBG, "Now DEMUXTASK state = %s\n", DEMUX_STATE_TO_STRING(state)));

	return RM_OK;
}

RMstatus DCCOpenDemuxTask(struct DCC *pDCC, struct DCCDemuxTaskProfile *dcc_profile, struct DCCDemuxTask **ppDemuxTask)
{
	RMstatus err = RM_OK;
	RMuint32 demux_task = 0;
	struct DemuxTask_DRAMSize_in_type dram_in;
	struct DemuxTask_DRAMSize_out_type dram_out;
	struct DemuxTask_Open_type profile;

	RMDBGLOG((LOCALDBG, "openDemuxTask\n"));

	*ppDemuxTask = (struct DCCDemuxTask *) RMMalloc(sizeof(struct DCCDemuxTask));
	if (*ppDemuxTask == NULL) {
		RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in system memory %lu!\n", sizeof(struct DCCDemuxTask)));
		return RM_FATALOUTOFMEMORY;
	}

	RMMemset((void*)(*ppDemuxTask), 0, sizeof(struct DCCDemuxTask));

	(*ppDemuxTask)->pRUA = pDCC->pRUA;
	(*ppDemuxTask)->pDCC = pDCC;
	
	demux_task = EMHWLIB_MODULE(DemuxTask, dcc_profile->DemuxTaskID);
	(*ppDemuxTask)->demux_task_moduleID = demux_task;
	
	dram_in.ProtectedFlags = dcc_profile->ProtectedFlags;
	dram_in.BitstreamFIFOSize = dcc_profile->BitstreamFIFOSize;
	dram_in.XferFIFOCount = dcc_profile->XferFIFOCount;
	dram_in.InbandFIFOCount = dcc_profile->InbandFIFOCount;
	err = RUAExchangeProperty(pDCC->pRUA, demux_task, RMDemuxTaskPropertyID_DRAMSize, &dram_in, sizeof(dram_in), &dram_out, sizeof(dram_out));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting property RMDemuxTaskPropertyID_DRAMSize! %s\n", RMstatusToString(err)));
		return err;
	}
	
	profile.ProtectedFlags = dram_in.ProtectedFlags;
	profile.BitstreamFIFOSize = dram_in.BitstreamFIFOSize;
	profile.XferFIFOCount = dram_in.XferFIFOCount;
	profile.InbandFIFOCount = dram_in.InbandFIFOCount;
	
	profile.InputPort = dcc_profile->InputPort;
	profile.PrimaryMPM = dcc_profile->PrimaryMPM;
	profile.SecondaryMPM = dcc_profile->SecondaryMPM;

	profile.BitstreamProtectedAddress = 0;
	profile.BitstreamProtectedSize = dram_out.BitstreamProtectedSize;
	if (profile.BitstreamProtectedSize > 0) {
		profile.BitstreamProtectedAddress = pDCC->rua_malloc(pDCC->pRUA, demux_task, pDCC->dram, RUA_DRAM_CACHED, profile.BitstreamProtectedSize);
		if (!profile.BitstreamProtectedAddress) {
			RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in cached DRAM %lu!\n", profile.BitstreamProtectedSize, 0L));
			return RM_FATALOUTOFMEMORY;
		}
		RMDBGLOG((LOCALDBG, "demux_task cached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
			profile.BitstreamProtectedAddress, profile.BitstreamProtectedSize, profile.BitstreamProtectedAddress + profile.BitstreamProtectedSize));
	}	
	(*ppDemuxTask)->protected_address = profile.BitstreamProtectedAddress;
	
	profile.UnprotectedAddress = 0;
	profile.UnprotectedSize = dram_out.UnprotectedSize;
	if (profile.UnprotectedSize > 0) {
		profile.UnprotectedAddress = pDCC->rua_malloc(pDCC->pRUA, demux_task, pDCC->dram, RUA_DRAM_UNCACHED, profile.UnprotectedSize);
		if (!profile.UnprotectedAddress) {
			RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in uncached DRAM %lu!\n", profile.UnprotectedSize, 0L));
			return RM_FATALOUTOFMEMORY;
		}
		RMDBGLOG((LOCALDBG, "demux_task uncached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
			profile.UnprotectedAddress, profile.UnprotectedSize, profile.UnprotectedAddress + profile.UnprotectedSize));
	}	
	(*ppDemuxTask)->unprotected_address = profile.UnprotectedAddress;

	DCCSP(pDCC->pRUA, demux_task, RMDemuxTaskPropertyID_Open, &profile, sizeof(profile));
	
	return RM_OK;
}

RMstatus DCCCloseDemuxTask(struct DCCDemuxTask *pDemuxTask)
{
	RMuint32 close_profile = 0;

	RMDBGLOG((LOCALDBG, "closeDemuxTask\n"));

	if (pDemuxTask->demux_task_moduleID != 0) {
		DCCSP(pDemuxTask->pRUA, pDemuxTask->demux_task_moduleID, RMDemuxTaskPropertyID_Close, &close_profile, sizeof(close_profile));
	}
	
	if (pDemuxTask->protected_address) 
		pDemuxTask->pDCC->rua_free(pDemuxTask->pRUA, pDemuxTask->protected_address);

	if (pDemuxTask->unprotected_address) 
		pDemuxTask->pDCC->rua_free(pDemuxTask->pRUA, pDemuxTask->unprotected_address);

	RMFree(pDemuxTask);

	return RM_OK;
}

RMstatus DCCGetDemuxTaskInfo(struct DCCDemuxTask *pDemuxTask, RMuint32 *demux_task)
{
	RMDBGLOG((LOCALDBG, "getDemuxTaskInfo\n"));

	*demux_task = pDemuxTask->demux_task_moduleID;

	return RM_OK;
}

RMstatus DCCPlayDemuxTask(struct DCCDemuxTask *pDemuxTask)
{
	RMstatus err;

	RMDBGLOG((LOCALDBG, "playDemuxTask\n"));

	err = send_demux_task_command(pDemuxTask->pRUA, pDemuxTask->demux_task_moduleID, DemuxTask_Command_Play);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot send demux_task command play, %s\n", RMstatusToString(err)));
		return err;
	}
	return RM_OK;
}

RMstatus DCCStopDemuxTask(struct DCCDemuxTask *pDemuxTask)
{
 	RMstatus err;

	RMDBGLOG((LOCALDBG, "stopDemuxTask\n"));

	err = send_demux_task_command(pDemuxTask->pRUA, pDemuxTask->demux_task_moduleID, DemuxTask_Command_Stop);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot send demux_task command stop, %s\n", RMstatusToString(err)));
		return err;
	}

	return RM_OK;
}

RMstatus DCCPauseDemuxTask(struct DCCDemuxTask *pDemuxTask)
{
 	RMstatus err;

	RMDBGLOG((LOCALDBG, "pauseDemuxTask\n"));

	err = send_demux_task_command(pDemuxTask->pRUA, pDemuxTask->demux_task_moduleID, DemuxTask_Command_Pause);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot send demux_task command pause, %s\n", RMstatusToString(err)));
		return err;
	}

	return err;
}

