/*****************************************
 Copyright © 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   dcc.c
  @brief  Decoding Chain Control API

  @author Julien Soulier
  @date   2003-10-02
*/

// to enable or disable the debug messages of this source file, put 1 or 0 below
#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

#define ENABLE_SPU_OP			1

#include "dcc_common.h"


static RMstatus send_video_command(struct RUA *pRUA, RMuint32 video_decoder, enum VideoDecoder_Command_type v_command) 
{
	struct RUAEvent evt;
 	enum VideoDecoder_State_type state;
	RMuint32 index;
	RMstatus err;
	RMstatus cmdStatus;

	evt.ModuleID = video_decoder;
	evt.Mask = RUAEVENT_COMMANDCOMPLETION;
	
	err = RUAResetEvent(pRUA, &evt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot reset video command completion event, %s\n", RMstatusToString(err)));
		return err;
	}

#ifdef _DEBUG

	err = RUAGetProperty(pRUA, video_decoder, RMVideoDecoderPropertyID_State, &state, sizeof(state));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get video state, %s\n", RMstatusToString(err)));
		return err;
	}
	RMDBGLOG((LOCALDBG, "current VIDEO state = %s\n", VIDEO_STATE_TO_STRING(state)));

	RMDBGLOG((LOCALDBG, "send command = %s\n", VIDEO_COMMAND_TO_STRING(v_command)));
#endif

	err = RUASetProperty(pRUA, video_decoder, RMVideoDecoderPropertyID_Command, &v_command, sizeof(v_command), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot send video command, %s\n", RMstatusToString(err)));
		return err;
	}
	
	evt.ModuleID = video_decoder;
	evt.Mask = RUAEVENT_COMMANDCOMPLETION;
	err = RUAWaitForMultipleEvents(pRUA, &evt, 1, WAIT_COMMAND_TIMEOUT_US, &index);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "wait for video command completion failed, %s\n", RMstatusToString(err)));
		return err;
	}
	
	err = RUAGetProperty(pRUA, video_decoder, RMVideoDecoderPropertyID_State, &state, sizeof(state));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get video state, %s\n", RMstatusToString(err)));
		return err;
	}
	
	RMDBGLOG((LOCALDBG, "Now VIDEO state = %s\n", VIDEO_STATE_TO_STRING(state)));

	err = RUAGetProperty(pRUA, video_decoder, RMVideoDecoderPropertyID_CommandStatus, &cmdStatus, sizeof(cmdStatus));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get command status, %s\n", RMstatusToString(err)));
		return err;
	}

	return cmdStatus;
}

static RMstatus send_spu_command(struct RUA *pRUA, RMuint32 spu_decoder, enum SpuDecoder_Command_type v_command) 
{
	struct RUAEvent evt;
	enum SpuDecoder_State_type state;
	RMuint32 index;
	RMstatus err;

	RMDBGLOG((LOCALDBG, "send_spu_command addr=0x%08lx command=%ld\n", pRUA, (int)v_command));

	evt.ModuleID = spu_decoder;
	evt.Mask = RUAEVENT_COMMANDCOMPLETION;
	
	err = RUAResetEvent(pRUA, &evt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot reset spu command completion event, %s\n", RMstatusToString(err)));
		return err;
	}
	
	err = RUASetProperty(pRUA, spu_decoder, RMSpuDecoderPropertyID_Command, &v_command, sizeof(v_command), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot send spu command, %s\n", RMstatusToString(err)));
		return err;
	}
	
	evt.ModuleID = spu_decoder;
	evt.Mask = RUAEVENT_COMMANDCOMPLETION;
	err = RUAWaitForMultipleEvents(pRUA, &evt, 1, WAIT_COMMAND_TIMEOUT_US, &index);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "wait for spu command completion failed, %s\n", RMstatusToString(err)));
		return err;
	}
	
	err = RUAGetProperty(pRUA, spu_decoder, RMSpuDecoderPropertyID_State, &state, sizeof(state));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get spu state, %s\n", RMstatusToString(err)));
		return err;
	}
	
	RMDBGLOG((LOCALDBG, "Now SPU state = %s\n", SPU_STATE_TO_STRING(state)));

	return RM_OK;
}





RMstatus DCCOpenVideoDecoderSource(struct DCC *pDCC, struct DCCVideoProfile *dcc_profile, struct DCCVideoSource **ppVideoSource)
{
	struct VideoDecoder_DRAMSize_in_type dram_in;
	struct VideoDecoder_DRAMSize_out_type dram_out;
	struct VideoDecoder_Open_type profile;
	RMuint32 surface, mpeg_engine, video_decoder;
	RMuint32 nb_mpeg_engines, nb_video_decoders;
	RMuint32 temp;
	RMstatus err;

	*ppVideoSource = (struct DCCVideoSource *) RMMalloc(sizeof(struct DCCVideoSource));
	if (*ppVideoSource == NULL) {
		RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in system memory %lu!\n", sizeof(struct DCCVideoSource)));
		return RM_FATALOUTOFMEMORY;
	}
	RMMemset((void*)(*ppVideoSource), 0, sizeof(struct DCCVideoSource));

	(*ppVideoSource)->pRUA = pDCC->pRUA;
	(*ppVideoSource)->pDCC = pDCC;

	// Get number of video engines and video decoders
	temp = MpegEngine;
	err = RUAExchangeProperty(pDCC->pRUA, Enumerator, RMEnumeratorPropertyID_CategoryIDToNumberOfInstances,
				  &temp, sizeof(temp), &nb_mpeg_engines, sizeof(nb_mpeg_engines));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting property  RMEnumeratorPropertyID_CategoryIDToNumberOfInstances %s\n", 
			  RMstatusToString(err)));
		return err;
	}
	else {
		if (dcc_profile->MpegEngineID < nb_mpeg_engines)
			RMDBGLOG((LOCALDBG, "Number of video engines: %d%s\n", (int) nb_mpeg_engines));
		else {
			RMDBGLOG((ENABLE, "Error: video engine index %d out of range!!! Should be < %d\n", 
				  (int) dcc_profile->MpegEngineID, (int) nb_mpeg_engines));
			err = RM_PARAMETER_OUT_OF_RANGE;
			return err;
		}
	}

	temp = VideoDecoder;
	err = RUAExchangeProperty(pDCC->pRUA, Enumerator, RMEnumeratorPropertyID_CategoryIDToNumberOfInstances,
				  &temp, sizeof(temp), &nb_video_decoders, sizeof(nb_video_decoders));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting property  RMEnumeratorPropertyID_CategoryIDToNumberOfInstances %s\n", 
			  RMstatusToString(err)));
		return err;
	}
	else {
		if (dcc_profile->VideoDecoderID < (nb_video_decoders / nb_mpeg_engines))
			RMDBGLOG((LOCALDBG, "Number of video decoders: %d%s\n", (int) nb_video_decoders)); 
		else {
			RMDBGLOG((ENABLE, "Error: video decoder index %d out of range!!! Should be < %d\n", 
				  (int) dcc_profile->VideoDecoderID, (int) (nb_video_decoders / nb_mpeg_engines)));
			err = RM_PARAMETER_OUT_OF_RANGE;
			return err;
		}
	}

	// Check for MPEG engine on right DRAM. Second MPEG engine on Tango 2 only. In this case, MPEG engine
	// must be the same as DRAM controller. We do not support Mambo in this branch (Mambo would have been
	// able to play MPEG Engine 0 on DRAM controller 1...). Not on Tango 2.
	if (pDCC->dram != dcc_profile->MpegEngineID) {
		RMDBGLOG((ENABLE, "Error: cannot play Video Engine %d on DRAM %d.\n", 
			  (int) dcc_profile->MpegEngineID, (int) pDCC->dram));
		return RM_ERROR;
	}

	mpeg_engine = EMHWLIB_MODULE(MpegEngine, dcc_profile->MpegEngineID);
	(*ppVideoSource)->engine_moduleID = mpeg_engine;
	RMDBGLOG((LOCALDBG, "MpegEngine: 0x%08lX\n", mpeg_engine));

	// !!Hack!! We assume there are an equal amount of decoders per engine; (nb_video_decoders / nb_mpeg_engines) 
	// gives the number of decoders per engine.
	video_decoder = EMHWLIB_MODULE(VideoDecoder, dcc_profile->MpegEngineID * (nb_video_decoders / nb_mpeg_engines) 
				       + dcc_profile->VideoDecoderID);
	(*ppVideoSource)->decoder_moduleID = video_decoder;
	RMDBGLOG((LOCALDBG, "VideoDecoder: 0x%08lX\n", video_decoder));

	profile.DemuxProgramId = dcc_profile->DemuxProgramID;
	
	profile.TimerId = dcc_profile->STCID;

	(*ppVideoSource)->timer_number = profile.TimerId;

	dram_in.MPEGProfile = dcc_profile->MPEGProfile;
	dram_in.BitstreamFIFOSize = dcc_profile->BitstreamFIFOSize;
	dram_in.XferFIFOCount = dcc_profile->XferFIFOCount;

	err = RUAExchangeProperty(pDCC->pRUA, video_decoder, RMVideoDecoderPropertyID_DRAMSize, &dram_in, sizeof(dram_in), &dram_out, sizeof(dram_out));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting property RMVideoDecoderPropertyID_DRAMSize! %s\n", RMstatusToString(err)));
		return err;
	}
	
	profile.MPEGProfile = dram_in.MPEGProfile;
	profile.BitstreamFIFOSize = dram_in.BitstreamFIFOSize;
	profile.XferFIFOCount = dram_in.XferFIFOCount;
	
	profile.CachedAddress = 0;
	profile.CachedSize = dram_out.CachedSize;
	if (profile.CachedSize > 0) {
		profile.CachedAddress = pDCC->rua_malloc(pDCC->pRUA, video_decoder, pDCC->dram, RUA_DRAM_CACHED, profile.CachedSize);
		if (!profile.CachedAddress) {
			RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in cached DRAM %lu!\n", profile.CachedSize, 0L));
			return RM_FATALOUTOFMEMORY;
		}
		RMDBGLOG((LOCALDBG, "video cached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n", profile.CachedAddress, profile.CachedSize, profile.CachedAddress + profile.CachedSize));
	} 	
	(*ppVideoSource)->cached_address = profile.CachedAddress;
	
	profile.UncachedAddress = 0;
	profile.UncachedSize = dram_out.UncachedSize;
	if (profile.UncachedSize > 0) {
		profile.UncachedAddress = pDCC->rua_malloc(pDCC->pRUA, video_decoder, pDCC->dram, RUA_DRAM_UNCACHED, profile.UncachedSize);
		if (!profile.UncachedAddress) {
			RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in uncached DRAM %lu!\n", profile.UncachedSize, 0L));
			return RM_FATALOUTOFMEMORY;
		}
		RMDBGLOG((LOCALDBG, "video uncached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n", profile.UncachedAddress, profile.UncachedSize, profile.UncachedAddress + profile.UncachedSize));
	} 	
	(*ppVideoSource)->uncached_address = profile.UncachedAddress;
	
	DCCSP(pDCC->pRUA, video_decoder, RMVideoDecoderPropertyID_Open, &profile, sizeof(profile));
	
	err = RUAGetProperty(pDCC->pRUA, video_decoder, RMGenericPropertyID_Surface, &surface, sizeof(surface));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get the video surface, %s\n", RMstatusToString(err)));
		return err;
	}

	if (dcc_profile->SPUBitstreamFIFOSize > 0) {
		struct SpuDecoder_DRAMSize_in_type dram_in;
		struct SpuDecoder_DRAMSize_out_type dram_out;
		struct SpuDecoder_Open_type profile;
		RMuint32 spu_decoder;

		spu_decoder = EMHWLIB_MODULE(SpuDecoder, dcc_profile->MpegEngineID);
		(*ppVideoSource)->spu_decoder_moduleID = spu_decoder;

		dram_in.BitstreamFIFOSize = dcc_profile->SPUBitstreamFIFOSize;
		dram_in.XferFIFOCount = dcc_profile->SPUXferFIFOCount;
		
		err = RUAExchangeProperty(pDCC->pRUA, spu_decoder, RMSpuDecoderPropertyID_DRAMSize, 
					  &dram_in, sizeof(dram_in), &dram_out, sizeof(dram_out));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error getting property RMSpuDecoderPropertyID_DRAMSize! %s\n", RMstatusToString(err)));
			return err;
		}
		
		profile.BitstreamFIFOSize = dram_in.BitstreamFIFOSize;
		profile.XferFIFOCount = dram_in.XferFIFOCount;
		
		profile.CachedAddress = 0;
		profile.CachedSize = dram_out.CachedSize;
		if (profile.CachedSize > 0) {
			profile.CachedAddress = pDCC->rua_malloc(pDCC->pRUA, spu_decoder, pDCC->dram, RUA_DRAM_CACHED, profile.CachedSize);
			if (!profile.CachedAddress) {
				RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in cached DRAM %lu!\n", profile.CachedSize, 0L));
				return RM_FATALOUTOFMEMORY;
			}
			RMDBGLOG((LOCALDBG, "subpicture cached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n", profile.CachedAddress, profile.CachedSize, profile.CachedAddress + profile.CachedSize));
		} 
		(*ppVideoSource)->spu_cached_address = profile.CachedAddress;
		
		profile.UncachedAddress = 0;
		profile.UncachedSize = dram_out.UncachedSize;
		if (profile.UncachedSize > 0) {
			profile.UncachedAddress = pDCC->rua_malloc(pDCC->pRUA, spu_decoder, pDCC->dram, RUA_DRAM_UNCACHED, profile.UncachedSize);
			if (!profile.UncachedAddress) {
				RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in uncached DRAM %lu!\n", profile.UncachedSize, 0L));
				return RM_FATALOUTOFMEMORY;
			}
			RMDBGLOG((LOCALDBG, "subpicture uncached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n", profile.UncachedAddress, profile.UncachedSize, profile.UncachedAddress + profile.UncachedSize));
		} 
		(*ppVideoSource)->spu_uncached_address = profile.UncachedAddress;
		
		profile.DemuxProgramId = dcc_profile->DemuxProgramID;
		DCCSP(pDCC->pRUA, spu_decoder, RMSpuDecoderPropertyID_Open, &profile, sizeof(profile));

		err = RUAGetProperty(pDCC->pRUA, spu_decoder, RMSpuDecoderPropertyID_VSyncSurface, &((*ppVideoSource)->spu_surface), sizeof(RMuint32));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error getting property RMSpuDecoderPropertyID_VSyncSurface! %s\n", RMstatusToString(err)));
			return err;
		}
	}

	(*ppVideoSource)->surface = surface;

	return RM_OK;
}

RMstatus DCCCloseVideoSource(struct DCCVideoSource *pVideoSource)
{
	RMbool surface_changed = FALSE;
	RMDBGLOG((LOCALDBG, "DCCCloseVideoSource()\n"));

	if (pVideoSource->spu_scaler_moduleID != 0) {
		struct EMhwlibSubPictureSurface_type val;
		val.Scaler = 0;
		val.Surface = 0;

		DCCSP(pVideoSource->pRUA, pVideoSource->scaler_moduleID, RMGenericPropertyID_SubPictureSurface, &val, sizeof(val));
		DCCSP(pVideoSource->pRUA, pVideoSource->scaler_moduleID, RMGenericPropertyID_Validate, NULL, 0);
		surface_changed = TRUE;
	}



	if (pVideoSource->scaler_moduleID != 0) {
		RMuint32 surface;
		RMstatus err;
		err = RUAGetProperty(pVideoSource->pRUA, pVideoSource->scaler_moduleID, RMGenericPropertyID_Surface, &surface, sizeof(surface));
		if (err != RM_OK) {
			RMDBGLOG((ENABLE, "Cannot get the video surface, %s\n", RMstatusToString(err)));
			return err;
		}
		if(surface != 0){
			surface = 0;
			DCCSP(pVideoSource->pRUA, pVideoSource->scaler_moduleID, RMGenericPropertyID_Surface, &surface, sizeof(surface));
			surface_changed = TRUE;
		}
	}

 	if (surface_changed) {
		RMstatus err;
		struct RUAEvent evt;											
		RMuint32 index;											

		evt.Mask = EMHWLIB_DISPLAY_EVENT_ID(pVideoSource->scaler_moduleID);								
		evt.ModuleID = EMHWLIB_MODULE(DisplayBlock, 0);							
		err = RUAWaitForMultipleEvents(pVideoSource->pRUA, &evt, 1, WAIT_COMMAND_TIMEOUT_US, &index);			
		if (RMFAILED(err)) {										
			RMDBGLOG((ENABLE, "wait for display update event completion failed, %s\n", RMstatusToString(err)));        
			return err;										
		}											
	}

	if (pVideoSource->decoder_moduleID != 0) {
		RMuint32 close_profile = 0;
		if (EMHWLIB_MODULE_CATEGORY(pVideoSource->decoder_moduleID) == DispVideoInput) {
			DCCSPERR(pVideoSource->pRUA, pVideoSource->decoder_moduleID, 
				RMDispVideoInputPropertyID_Close, &close_profile, sizeof(close_profile), 
				"Error closing video input profile");
		} else if (EMHWLIB_MODULE_CATEGORY(pVideoSource->decoder_moduleID) == DispGraphicInput) {
			DCCSPERR(pVideoSource->pRUA, pVideoSource->decoder_moduleID, 
				 RMDispGraphicInputPropertyID_Close, &close_profile, sizeof(close_profile), 
				 "Error closing graphic input profile");
		} else {
			RMDBGLOG((LOCALDBG, ">>>closing video decoder\n"));
			DCCSPERR(pVideoSource->pRUA, pVideoSource->decoder_moduleID, 
				 RMVideoDecoderPropertyID_Close, &close_profile, sizeof(close_profile), 
				 "Error closing video decoder profile");
		}
	}

	if (pVideoSource->spu_decoder_moduleID != 0) {
		RMuint32 close_profile = 0;
		DCCSP(pVideoSource->pRUA, pVideoSource->spu_decoder_moduleID, RMSpuDecoderPropertyID_Close, &close_profile, sizeof(close_profile));
	}


	if (pVideoSource->picture_protected_address) 
		pVideoSource->pDCC->rua_free(pVideoSource->pRUA, pVideoSource->picture_protected_address);
		
	if (pVideoSource->cached_address) 
		pVideoSource->pDCC->rua_free(pVideoSource->pRUA, pVideoSource->cached_address);

	if (pVideoSource->uncached_address) 
		pVideoSource->pDCC->rua_free(pVideoSource->pRUA, pVideoSource->uncached_address);

	if (pVideoSource->spu_cached_address) 
		pVideoSource->pDCC->rua_free(pVideoSource->pRUA, pVideoSource->spu_cached_address);

	if (pVideoSource->spu_uncached_address) 
		pVideoSource->pDCC->rua_free(pVideoSource->pRUA, pVideoSource->spu_uncached_address);

	if (pVideoSource->pictures != NULL)
		RMFree(pVideoSource->pictures);
	
	/* is it a video source or an OSD source ? */
	if (pVideoSource->engine_moduleID != 0) {
		/* Free the video scheduler task database table {see DCCXOpenVideoDecoderSource for allocation} */
		RMstatus err;
		RMuint32 connected_task_count;
		err = RUAGetProperty(pVideoSource->pRUA, pVideoSource->engine_moduleID, RMMpegEnginePropertyID_ConnectedTaskCount,
				     &connected_task_count, sizeof(connected_task_count));
		if (err != RM_OK) {
			RMDBGLOG((ENABLE, "Cannot get RMMpegEnginePropertyID_ConnectedTaskCount %s %lu\n", RMstatusToString(err), pVideoSource->engine_moduleID));
			return err;                                                         
		}
		if (connected_task_count == 0) {
			struct MpegEngine_SchedulerSharedMemory_type schedmem;
			struct MpegEngine_DecoderSharedMemory_type shared;
			RMuint32 address;
			
			err = RUAGetProperty(pVideoSource->pRUA, pVideoSource->engine_moduleID, RMMpegEnginePropertyID_DecoderSharedMemory,
					     &shared, sizeof(shared));
			if (err != RM_OK) {
				RMDBGLOG((ENABLE, "Cannot get DecoderSharedMemory0, %s\n", RMstatusToString(err)));
				return err;
			}
			if (shared.Address) {
				RMDBGLOG((ENABLE, "FREE %lx_DRAM VIDEO SHARED MEMORY addr=0x%lx size=0x%lx!\n",
					  EMHWLIB_MODULE_INDEX(pVideoSource->engine_moduleID), shared.Address, shared.Size));
				address = shared.Address;
				shared.Address = 0;
				shared.Size = 0;
				DCCSP(pVideoSource->pRUA, pVideoSource->engine_moduleID, RMMpegEnginePropertyID_DecoderSharedMemory,
				      &shared, sizeof(shared));
				/* Unlock the shared address */
				err = RUASetAddressID(pVideoSource->pRUA, address, 0);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "RUASetAddressID scheduler 0 ERROR %s\n", RMstatusToString(err)));
					return err;
				}
				RUAFree(pVideoSource->pRUA, address);
			}
			
			err = RUAGetProperty(pVideoSource->pRUA, pVideoSource->engine_moduleID, RMMpegEnginePropertyID_SchedulerSharedMemory,
					     &schedmem, sizeof(schedmem));
			if (err != RM_OK) {
				RMDBGLOG((ENABLE, "Cannot get SchedulerSharedMemory, %s\n", RMstatusToString(err)));
				return err;
			}
			if (schedmem.Address) {
				RMDBGLOG((ENABLE, "FREE %lx_DRAM SCHEDULER MEMORY addr=0x%lx size=0x%lx!\n",
					  EMHWLIB_MODULE_INDEX(pVideoSource->engine_moduleID), schedmem.Address, schedmem.Size));
				address = schedmem.Address;
				schedmem.Address = 0;
				schedmem.Size = 0;
				DCCSP(pVideoSource->pRUA, pVideoSource->engine_moduleID, RMMpegEnginePropertyID_SchedulerSharedMemory,
				      &schedmem, sizeof(schedmem));
				/* Unlock the schedulers's address */
				err = RUASetAddressID(pVideoSource->pRUA, address, 0);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "RUASetAddressID scheduler 0 ERROR %s\n", RMstatusToString(err)));
					return err;
				}
				RUAFree(pVideoSource->pRUA, address);
			}
		}
		else {
			RMDBGLOG((ENABLE, "CANNOT FREE %lx SCHEDULER and SHARED MEMORY. There are still %lx video tasks opened. \n",
				  EMHWLIB_MODULE_INDEX(pVideoSource->engine_moduleID), connected_task_count));
		}
	}

	RMFree(pVideoSource);
	
	return RM_OK;
}

RMstatus DCCGetVideoDecoderSourceInfo(struct DCCVideoSource *pVideoSource, RMuint32 *video_decoder, RMuint32 *spu_decoder, RMuint32 *timer)
{
	if (video_decoder) 	*video_decoder 	= pVideoSource->decoder_moduleID;
	if (timer) 			*timer 			= pVideoSource->timer_number;
	if (spu_decoder) 	*spu_decoder 	= pVideoSource->spu_decoder_moduleID;

	return RM_OK;
}


RMstatus DCCSetVideoDecoderSourceCodec(struct DCCVideoSource *pVideoSource, enum VideoDecoder_Codec_type codec)
{
	RMstatus err;

	RMDBGLOG((LOCALDBG, "DCCSetVideoSourceCodec codec=%ld\n", (int)codec));

	err = send_video_command(pVideoSource->pRUA, pVideoSource->decoder_moduleID, VideoDecoder_Command_Uninit);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot send VideoDecoder_Command_Uninit, %s\n", RMstatusToString(err)));
		return err;
	}

	/* send uninit command to spu decoder */
	if (pVideoSource->spu_decoder_moduleID != 0) {
		err = send_spu_command(pVideoSource->pRUA, pVideoSource->spu_decoder_moduleID, SpuDecoder_Command_Uninit);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot send SpuDecoder_Command_Uninit, %s\n", RMstatusToString(err)));
			return err;
		}
	}

	DCCSP(pVideoSource->pRUA, pVideoSource->decoder_moduleID, RMVideoDecoderPropertyID_Codec, &codec, sizeof(codec));
	
	err = send_video_command(pVideoSource->pRUA, pVideoSource->decoder_moduleID, VideoDecoder_Command_Init);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot send VideoDecoder_Command_Init, %s\n", RMstatusToString(err)));
		return err;
	}

	/* send init command to spu decoder */
	if (pVideoSource->spu_decoder_moduleID != 0) {
		err = send_spu_command(pVideoSource->pRUA, pVideoSource->spu_decoder_moduleID, SpuDecoder_Command_Init);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot send SpuDecoder_Command_Init, %s\n", RMstatusToString(err)));
			return err;
		}
	}

	return RM_OK;
}


RMstatus DCCPlayVideoSource(struct DCCVideoSource *pVideoSource, enum DCCVideoPlayCommand cmd)
{
	RMstatus err;

	/* 
	   IMPORTANT NOTE: 'cmd=DCCVideoPlayNextFrame' only affects the display, so the video decoder remains in the current
	   playback state, ie: playFwd, playIFrame, etc.
	*/
	if (cmd == DCCVideoPlayNextFrame) {
		if (pVideoSource->scaler_moduleID != 0) {
			DCCSP(pVideoSource->pRUA, pVideoSource->scaler_moduleID, RMGenericPropertyID_Step, NULL, 0);
		}
		
		//cmd = VideoDecoder_Command_PlayFwd;
	}
	
	if (cmd != DCCVideoPlayNextFrame) {
	
		err = send_video_command(pVideoSource->pRUA, pVideoSource->decoder_moduleID, cmd);
		
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot send video command play, %s\n", RMstatusToString(err)));
			return err;
		}
	}


	if (pVideoSource->spu_decoder_moduleID != 0) {
		err = send_spu_command(pVideoSource->pRUA, pVideoSource->spu_decoder_moduleID, SpuDecoder_Command_Play);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot send SpuDecoder_Command_Play, %s\n", RMstatusToString(err)));
			return err;
		}
	}

	return RM_OK;
}

RMstatus DCCStopVideoSource(struct DCCVideoSource *pVideoSource, enum DCCStopMode stop_mode)
{
 	RMstatus err;

	err = send_video_command(pVideoSource->pRUA, pVideoSource->decoder_moduleID, VideoDecoder_Command_Stop);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot send VideoDecoder_Command_Stop, %s\n", RMstatusToString(err)));
		return err;
	}

	if (pVideoSource->spu_decoder_moduleID != 0) {
		err = send_spu_command(pVideoSource->pRUA, pVideoSource->spu_decoder_moduleID, SpuDecoder_Command_Stop);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot send SpuDecoder_Command_Stop, %s\n", RMstatusToString(err)));
			return err;
		}
	}

	if (pVideoSource->scaler_moduleID != 0) {
		struct RUAEvent evt;

		switch (stop_mode) {
		case DCCStopMode_BlackFrame:
 			DCCSP(pVideoSource->pRUA, pVideoSource->scaler_moduleID, RMGenericPropertyID_Stop, NULL, 0);
			break;
		case DCCStopMode_LastFrame:
 			DCCSP(pVideoSource->pRUA, pVideoSource->scaler_moduleID, RMGenericPropertyID_Flush, NULL, 0);
			break;
		}

		evt.ModuleID = EMHWLIB_MODULE(DisplayBlock, 0);
		evt.Mask = EMHWLIB_DISPLAY_EVENT_ID(pVideoSource->scaler_moduleID);

		/* 
		   Safely wait for the stop/flush to be processed. 
		   The event occurs every VSYNC.
		   We may wait one extra VSYNC for safety. 
		*/
		RUAResetEvent(pVideoSource->pRUA, &evt);

		err = RUAWaitForMultipleEvents(pVideoSource->pRUA, &evt, 1, WAIT_COMMAND_TIMEOUT_US, NULL);
		if (RMFAILED(err)) {										
			RMDBGLOG((ENABLE, "wait for display update event completion failed, %s\n", RMstatusToString(err)));        
		}											
	}
	
	return RM_OK;
}

RMstatus DCCPauseVideoSource(struct DCCVideoSource *pVideoSource)
{
	return RM_OK;
}

RMstatus DCCEnableVideoSource(struct DCCVideoSource *pVideoSource, RMbool enable)
{
	RMuint32 src_index, mixer, scaler;
	RMstatus err;
	enum EMhwlibMixerSourceState state;

	mixer = pVideoSource->mixer_moduleID;
	if (mixer == 0) {
		RMDBGLOG((ENABLE, "Error No route attached to this source\n"));
		return RM_ERROR;
	}

	scaler = pVideoSource->scaler_moduleID;
	if (scaler == 0) {
		RMDBGLOG((ENABLE, "Error No surface attached to this source\n"));
		return RM_ERROR;
	}

	err = RUAExchangeProperty(pVideoSource->pRUA, mixer, RMGenericPropertyID_MixerSourceIndex, &scaler, sizeof(scaler), &src_index, sizeof(src_index));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get scaler index, %s\n", RMstatusToString(err)));
		return err;
	}
	mixer = EMHWLIB_TARGET_MODULE(EMHWLIB_MODULE_CATEGORY(mixer), 0 , src_index);
	
	if(enable)
		state = EMhwlibMixerSourceState_Master;
	else
		state = EMhwlibMixerSourceState_Disable;		
	DCCSP(pVideoSource->pRUA, mixer, RMGenericPropertyID_MixerSourceState, &state, sizeof(state));

	DCCSP(pVideoSource->pRUA, mixer, RMGenericPropertyID_Validate, NULL, 0);
	
	return RM_OK;
}

RMstatus DCCXGetBtsFIFO(struct DCCVideoSource *pVideoSource, RMuint32 *BtsFIFO)
{
	RMstatus err;
	
	err = RUAGetProperty(pVideoSource->pRUA, pVideoSource->decoder_moduleID ,
				RMVideoDecoderPropertyID_BtsFIFO, BtsFIFO, sizeof(RMuint32));

	return err;
}
	
RMstatus DCCXOpenVideoDecoderSource(struct DCC *pDCC, struct DCCXVideoProfile *dcc_profile, struct DCCVideoSource **ppVideoSource)
{
	struct VideoDecoder_DecoderDataMemory_in_type memory_in;
	struct VideoDecoder_DecoderDataMemory_out_type memory_out;
	/* Decoder share memory is required for specific codecs as VC1 etc.
	   The size of this memory depends on codec, profile, level, width, height. */
	struct MpegEngine_DecoderSharedMemory_type shared;
	/* Scheduler memory is required for video RISC in order to run one or multiple video, spu tasks.
	   The size of this memory is fixed at compile time. */
	struct MpegEngine_SchedulerSharedMemory_type schedmem;
	struct VideoDecoder_DRAMSizeX_in_type dram_in;
	struct VideoDecoder_DRAMSizeX_out_type dram_out;
	struct VideoDecoder_OpenX_type profile;
	RMuint32 surface, video_decoder = 0;
	RMuint32 nb_mpeg_engines, nb_video_decoders;
	RMuint32 mpeg_engine = 0;
	RMuint32 temp;
	RMstatus err;

	*ppVideoSource = (struct DCCVideoSource *) RMMalloc(sizeof(struct DCCVideoSource));
	if (*ppVideoSource == NULL) {
		RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in system memory %lu!\n", sizeof(struct DCCVideoSource)));
		return RM_FATALOUTOFMEMORY;
	}
	RMMemset((void*)(*ppVideoSource), 0, sizeof(struct DCCVideoSource));

	(*ppVideoSource)->pRUA = pDCC->pRUA;
	(*ppVideoSource)->pDCC = pDCC;

	// Get number of video engines and video decoders
	temp = MpegEngine;
	err = RUAExchangeProperty(pDCC->pRUA, Enumerator, RMEnumeratorPropertyID_CategoryIDToNumberOfInstances,
				  &temp, sizeof(temp), &nb_mpeg_engines, sizeof(nb_mpeg_engines));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting property  RMEnumeratorPropertyID_CategoryIDToNumberOfInstances %s\n", 
			  RMstatusToString(err)));
		return err;
	}
	else {
		if (dcc_profile->MpegEngineID < nb_mpeg_engines)
			RMDBGLOG((LOCALDBG, "Number of video engines: %d\n", (int) nb_mpeg_engines));
		else {
			RMDBGLOG((ENABLE, "Error: video engine index %d out of range!!! Should be < %d\n", 
				  (int) dcc_profile->MpegEngineID, (int) nb_mpeg_engines));
			err = RM_PARAMETER_OUT_OF_RANGE;
			return err;
		}
	}

	temp = VideoDecoder;
	err = RUAExchangeProperty(pDCC->pRUA, Enumerator, RMEnumeratorPropertyID_CategoryIDToNumberOfInstances,
				  &temp, sizeof(temp), &nb_video_decoders, sizeof(nb_video_decoders));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting property  RMEnumeratorPropertyID_CategoryIDToNumberOfInstances %s\n", 
			  RMstatusToString(err)));
		return err;
	}
	else {
		if (dcc_profile->VideoDecoderID < (nb_video_decoders / nb_mpeg_engines))
			RMDBGLOG((LOCALDBG, "Number of video decoders: %d%s\n", (int) nb_video_decoders)); 
		else {
			RMDBGLOG((ENABLE, "Error: video decoder index %d out of range!!! Should be < %d\n", 
				  (int) dcc_profile->VideoDecoderID, (int) (nb_video_decoders / nb_mpeg_engines)));
			err = RM_PARAMETER_OUT_OF_RANGE;
			return err;
		}
	}

	// Check for MPEG engine on right DRAM. Second MPEG engine on Tango 2 only. In this case, MPEG engine
	// must be the same as DRAM controller. We do not support Mambo in this branch (Mambo would have been
	// able to play MPEG Engine 0 on DRAM controller 1...). Not on Tango 2.
	if (pDCC->dram != dcc_profile->MpegEngineID) {
		RMDBGLOG((ENABLE, "Error: cannot play Video Engine %d on DRAM %d.\n", 
			  (int) dcc_profile->MpegEngineID, (int) pDCC->dram));
		return RM_ERROR;
	}

	mpeg_engine = EMHWLIB_MODULE(MpegEngine, dcc_profile->MpegEngineID);
	(*ppVideoSource)->engine_moduleID = mpeg_engine;
	RMDBGLOG((LOCALDBG, "MpegEngine: 0x%08lX\n", mpeg_engine));

	// !!Hack!! We assume there are an equal amount of decoders per engine; (nb_video_decoders / nb_mpeg_engines) 
	// gives the number of decoders per engine.
	video_decoder = EMHWLIB_MODULE(VideoDecoder, dcc_profile->MpegEngineID * (nb_video_decoders / nb_mpeg_engines) 
				       + dcc_profile->VideoDecoderID);
	(*ppVideoSource)->decoder_moduleID = video_decoder;
	RMDBGLOG((LOCALDBG, "VideoDecoder: 0x%08lX\n", video_decoder));

	profile.STCId = dcc_profile->STCID;
	(*ppVideoSource)->timer_number = profile.STCId;

	/* check if scheduler task database table is already initialized. */
	err = RUAGetProperty(pDCC->pRUA, mpeg_engine, RMMpegEnginePropertyID_SchedulerSharedMemory, &schedmem, sizeof(schedmem));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get SchedulerSharedMemory, %s\n", RMstatusToString(err)));
		return err;
	}
	if (schedmem.Address) {
		RMDBGLOG((ENABLE, "%lx_DRAM SCHEDULER MEMORY is already set addr=0x%lx size=0x%lx!\n",
			dcc_profile->MpegEngineID, schedmem.Address, schedmem.Size));
	}
	else {
		schedmem.Address = pDCC->rua_malloc(pDCC->pRUA, mpeg_engine, pDCC->dram, RUA_DRAM_UNCACHED, schedmem.Size);
		if (!schedmem.Address) {
			RMDBGLOG((ENABLE, "ERROR: could not allocate scheduler table!\n"));
			return err;
		}
		RMDBGLOG((ENABLE, "ALLOCATING %lx_DRAM SCHEDULER MEMORY addr: 0x%08lX, size 0x%08lX\n",
			dcc_profile->MpegEngineID, schedmem.Address, schedmem.Size));
		DCCSP(pDCC->pRUA, mpeg_engine, RMMpegEnginePropertyID_SchedulerSharedMemory, &schedmem, sizeof(schedmem));
	}

	/* find the memory requirements for the specified codec, profile, level, width, height and extra pictures */
	memory_in.Codec = dcc_profile->Codec;
	memory_in.Profile = dcc_profile->Profile;
	memory_in.Level = dcc_profile->Level;
	memory_in.ExtraPictureBufferCount = dcc_profile->ExtraPictureBufferCount;
	memory_in.MaxWidth = dcc_profile->MaxWidth;
	memory_in.MaxHeight = dcc_profile->MaxHeight;

	err = RUAExchangeProperty(pDCC->pRUA, video_decoder, RMVideoDecoderPropertyID_DecoderDataMemory, &memory_in, sizeof(memory_in), &memory_out, sizeof(memory_out));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting property RMVideoDecoderPropertyID_DecoderDataMemory! %s\n", RMstatusToString(err)));
		return err;
	}

	/* check if video shared memory is already set in mpeg engine */
	err = RUAGetProperty(pDCC->pRUA, mpeg_engine, RMMpegEnginePropertyID_DecoderSharedMemory, &shared, sizeof(shared));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get DecoderSharedMemory, %s\n", RMstatusToString(err)));
		return err;
	}
	if (shared.Address) {
		if (shared.Size < memory_out.DecoderSharedSize) {
			RMDBGLOG((ENABLE, "ERROR: video shared memory is already set with a smaller value than needed by DCCOpen %s\n", RMstatusToString(err)));
			return err;
		}
		else {
			RMDBGLOG((ENABLE, "%lx_DRAM VIDEO SHARED MEMORY is already set addr=0x%lx size=0x%lx\n",
				dcc_profile->MpegEngineID, shared.Address, shared.Size));
		}
	}
	else {
		/* allocate and set the shared memory used by all decoders of the same engine */
		shared.Size = memory_out.DecoderSharedSize;
		if (shared.Size) {
			shared.Address = pDCC->rua_malloc(pDCC->pRUA, mpeg_engine, pDCC->dram, RUA_DRAM_UNCACHED, shared.Size);
			if (!shared.Address) {
				RMDBGLOG((ENABLE, "ERROR: could not allocate shared 0x%08lX bytes in DRAM %lu!\n", shared.Address, 0L));
				return RM_FATALOUTOFMEMORY;
			}
		
			RMDBGLOG((ENABLE, "ALLOCATING %lx_DRAM VIDEO SHARED MEMORY addr: 0x%08lX, size 0x%08lX\n",
				dcc_profile->MpegEngineID, shared.Address, shared.Size));
			DCCSP(pDCC->pRUA, mpeg_engine, RMMpegEnginePropertyID_DecoderSharedMemory, &shared, sizeof(shared));
		}
	}

	/* find the required protected, unprotected memory */
	dram_in.ProtectedFlags = dcc_profile->ProtectedFlags;
	dram_in.BitstreamFIFOSize = dcc_profile->BitstreamFIFOSize;
	dram_in.UserDataSize = 0x1000; //TODO - it should be exposed to dcc ???
	dram_in.DecoderDataSize = memory_out.DecoderDataSize;
	dram_in.XferFIFOCount = dcc_profile->XferFIFOCount;
	dram_in.PtsFIFOCount = dcc_profile->PtsFIFOCount;
	dram_in.InbandFIFOCount = dcc_profile->InbandFIFOCount;
	dram_in.XtaskInbandFIFOCount = dcc_profile->XtaskInbandFIFOCount;

	err = RUAExchangeProperty(pDCC->pRUA, video_decoder, RMVideoDecoderPropertyID_DRAMSizeX, &dram_in, sizeof(dram_in), &dram_out, sizeof(dram_out));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting property RMVideoDecoderPropertyID_DRAMSize! %s\n", RMstatusToString(err)));
		return err;
	}
	
	/* allocate the picture protected memory for video decoder */
	profile.PictureProtectedAddress = 0;
	profile.PictureProtectedSize = dram_out.PictureProtectedSize;
	if (profile.PictureProtectedSize > 0) {
		profile.PictureProtectedAddress = pDCC->rua_malloc(pDCC->pRUA, video_decoder, pDCC->dram, RUA_DRAM_UNCACHED, profile.PictureProtectedSize);
		if (!profile.PictureProtectedAddress) {
			RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in Protected DRAM %lu!\n", profile.PictureProtectedSize, 0L));
			return RM_FATALOUTOFMEMORY;
		}
		RMDBGLOG((LOCALDBG, "video PictureProtectedAddress: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
			profile.PictureProtectedAddress, profile.PictureProtectedSize, profile.PictureProtectedAddress + profile.PictureProtectedSize));
	} 	
	(*ppVideoSource)->picture_protected_address = profile.PictureProtectedAddress;
	
	/* allocate the bitstream protected memory for video decoder */
	profile.BitstreamProtectedAddress = 0;
	profile.BitstreamProtectedSize = dram_out.BitstreamProtectedSize;
	if (profile.BitstreamProtectedSize > 0) {
		profile.BitstreamProtectedAddress = pDCC->rua_malloc(pDCC->pRUA, video_decoder, pDCC->dram, RUA_DRAM_UNCACHED, profile.BitstreamProtectedSize);
		if (!profile.BitstreamProtectedAddress) {
			RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in Protected DRAM %lu!\n", profile.BitstreamProtectedSize, 0L));
			return RM_FATALOUTOFMEMORY;
		}
		RMDBGLOG((LOCALDBG, "video BitstreamProtectedAddress: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
			profile.BitstreamProtectedAddress, profile.BitstreamProtectedSize, profile.BitstreamProtectedAddress + profile.BitstreamProtectedSize));
	} 	
	(*ppVideoSource)->cached_address = profile.BitstreamProtectedAddress;
	
	/* allocate the unprotected memory required for video decoder */
	profile.UnprotectedAddress = 0;
	profile.UnprotectedSize = dram_out.UnprotectedSize;
	if (profile.UnprotectedSize > 0) {
		profile.UnprotectedAddress = pDCC->rua_malloc(pDCC->pRUA, video_decoder, pDCC->dram, RUA_DRAM_UNCACHED, profile.UnprotectedSize);
		if (!profile.UnprotectedAddress) {
			RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in unprotected DRAM %lu!\n", profile.UnprotectedSize, 0L));
			return RM_FATALOUTOFMEMORY;
		}
		RMDBGLOG((LOCALDBG, "video UnprotectedAddress: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
			profile.UnprotectedAddress, profile.UnprotectedSize, profile.UnprotectedAddress + profile.UnprotectedSize));
	} 	
	(*ppVideoSource)->uncached_address = profile.UnprotectedAddress;
	
	/* open VideoDecoder module */
	profile.ProtectedFlags = dram_in.ProtectedFlags;
	profile.BitstreamFIFOSize = dram_in.BitstreamFIFOSize;
	profile.UserDataSize = dram_in.UserDataSize;
	profile.DecoderDataSize = dram_in.DecoderDataSize;
	profile.DecoderContextSize = memory_out.DecoderContextSize; //TODO to be removed when microcode calculates it
	profile.ExtraPictureBufferCount = dcc_profile->ExtraPictureBufferCount;
	profile.XferFIFOCount = dram_in.XferFIFOCount;
	profile.PtsFIFOCount = dram_in.PtsFIFOCount;
	profile.InbandFIFOCount = dram_in.InbandFIFOCount;
	profile.XtaskInbandFIFOCount = dram_in.XtaskInbandFIFOCount;
	profile.XtaskId = dcc_profile->XtaskID;
	
	DCCSP(pDCC->pRUA, video_decoder, RMVideoDecoderPropertyID_OpenX, &profile, sizeof(profile));
	
	err = RUAGetProperty(pDCC->pRUA, video_decoder, RMGenericPropertyID_Surface, &surface, sizeof(surface));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get the video surface, %s\n", RMstatusToString(err)));
		return err;
	}
	(*ppVideoSource)->surface = surface;

	if (dcc_profile->SPUBitstreamFIFOSize > 0) {
		struct SpuDecoder_DRAMSizeX_in_type dram_in;
		struct SpuDecoder_DRAMSizeX_out_type dram_out;
		struct SpuDecoder_DecoderDataMemory_in_type memory_in;
		struct SpuDecoder_DecoderDataMemory_out_type memory_out;
		struct SpuDecoder_OpenX_type profile;
		RMuint32 spu_decoder, nb_spu_decoders;

		RMDBGLOG((LOCALDBG, "-- Initializing SPU decoder!\n"));

		temp = SpuDecoder;
		err = RUAExchangeProperty(pDCC->pRUA, Enumerator, RMEnumeratorPropertyID_CategoryIDToNumberOfInstances,
					&temp, sizeof(temp), &nb_spu_decoders, sizeof(nb_spu_decoders));
		// !!Hack!! We assume there are an equal amount of decoders per engine
		spu_decoder = EMHWLIB_MODULE(SpuDecoder, dcc_profile->MpegEngineID * (nb_spu_decoders / nb_mpeg_engines) + 0);
		(*ppVideoSource)->spu_decoder_moduleID = spu_decoder;

		memory_in.Codec = dcc_profile->SPUCodec;
		memory_in.Profile = dcc_profile->SPUProfile;
		memory_in.Level = dcc_profile->SPULevel;
		memory_in.ExtraPictureBufferCount = dcc_profile->SPUExtraPictureBufferCount;
		memory_in.MaxWidth = dcc_profile->SPUMaxWidth;
		memory_in.MaxHeight = dcc_profile->SPUMaxHeight;

		err = RUAExchangeProperty(pDCC->pRUA, spu_decoder, RMSpuDecoderPropertyID_DecoderDataMemory, &memory_in, sizeof(memory_in), &memory_out, sizeof(memory_out));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error getting property RMVideoDecoderPropertyID_DecoderDataMemory! %s\n", RMstatusToString(err)));
			return err;
		}

		dram_in.ProtectedFlags 			= dcc_profile->ProtectedFlags;
		dram_in.BitstreamFIFOSize 		= dcc_profile->SPUBitstreamFIFOSize;
		dram_in.XferFIFOCount 			= dcc_profile->SPUXferFIFOCount;
		dram_in.DecoderDataSize 		= memory_out.DecoderDataSize;
		dram_in.PtsFIFOCount 			= dcc_profile->PtsFIFOCount;
		dram_in.InbandFIFOCount 		= dcc_profile->InbandFIFOCount;
		dram_in.XtaskInbandFIFOCount 	= dcc_profile->XtaskInbandFIFOCount;
		dram_in.HilightCount			= 3;

		err = RUAExchangeProperty(pDCC->pRUA, spu_decoder, RMSpuDecoderPropertyID_DRAMSizeX, &dram_in, sizeof(dram_in), &dram_out, sizeof(dram_out));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error getting property RMSpuDecoderPropertyID_DRAMSizeX! %s\n", RMstatusToString(err)));
			return err;
		}
	
		/* allocate the unprotected memory required for Spu decoder */
		profile.UnprotectedAddress = 0;
		profile.UnprotectedSize = dram_out.UnprotectedSize;

		if (profile.UnprotectedSize > 0) {
			profile.UnprotectedAddress = pDCC->rua_malloc(pDCC->pRUA, spu_decoder, pDCC->dram, RUA_DRAM_UNCACHED, profile.UnprotectedSize);
			if (!profile.UnprotectedAddress) {
				RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in unprotected DRAM %lu!\n", profile.UnprotectedSize, 0L));
				return RM_FATALOUTOFMEMORY;
			}
			RMDBGLOG((LOCALDBG, "SPU UnprotectedAddress: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
				profile.UnprotectedAddress, profile.UnprotectedSize, profile.UnprotectedAddress + profile.UnprotectedSize));
		} 	
		(*ppVideoSource)->spu_uncached_address = profile.UnprotectedAddress;

		/* open SpuDecoder module */
		profile.ProtectedFlags 				= dram_in.ProtectedFlags;
		profile.PictureProtectedAddress		= 0;
		profile.PictureProtectedSize 		= 0;
		profile.BitstreamProtectedAddress 	= 0;
		profile.BitstreamProtectedSize		= 0;
		profile.BitstreamFIFOSize 			= dram_in.BitstreamFIFOSize;
		profile.DecoderDataSize 			= memory_out.DecoderDataSize;
		profile.DecoderContextSize 			= memory_out.DecoderContextSize;
		profile.ExtraPictureBufferCount 	= dcc_profile->SPUExtraPictureBufferCount;
		profile.XferFIFOCount 				= dram_in.XferFIFOCount;
		profile.PtsFIFOCount 				= dram_in.PtsFIFOCount;
		profile.InbandFIFOCount 			= dram_in.InbandFIFOCount;
		profile.XtaskInbandFIFOCount 		= dram_in.XtaskInbandFIFOCount;
		profile.XtaskId 					= dcc_profile->XtaskID;
		profile.HilightCount				= dram_in.HilightCount;
		profile.STCId = dcc_profile->STCID;

		DCCSP(pDCC->pRUA, spu_decoder, RMSpuDecoderPropertyID_OpenX, &profile, sizeof(profile));

#ifdef ENABLE_SPU_OP
		err = RUAGetProperty(pDCC->pRUA, spu_decoder, RMSpuDecoderPropertyID_VSyncSurface, &((*ppVideoSource)->spu_surface), sizeof(RMuint32));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error getting property RMSpuDecoderPropertyID_VSyncSurface! %s\n", RMstatusToString(err)));
			return err;
		}
#endif
	}



	return RM_OK;
}

RMstatus DCCXSetVideoDecoderSourceCodec(struct DCCVideoSource *pVideoSource, enum EMhwlibVideoCodec Codec)
{
	RMstatus err;

	RMDBGLOG((LOCALDBG, "DCCXSetVideoDecoderSourceCodec codec = %ld\n", (int)Codec));

	err = send_video_command(pVideoSource->pRUA, pVideoSource->decoder_moduleID, VideoDecoder_Command_Uninit);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot send VideoDecoder_Command_Uninit, %s\n", RMstatusToString(err)));
		return err;
	}

	if (pVideoSource->spu_decoder_moduleID != 0) {
		err = send_spu_command(pVideoSource->pRUA, pVideoSource->spu_decoder_moduleID, SpuDecoder_Command_Uninit);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot send SpuDecoder_Command_Uninit, %s\n", RMstatusToString(err)));
			return err;
		}
	}

	DCCSP(pVideoSource->pRUA, pVideoSource->decoder_moduleID, RMVideoDecoderPropertyID_CodecX, &Codec, sizeof(enum EMhwlibVideoCodec));

	if (pVideoSource->spu_decoder_moduleID != 0) {
		Codec = EMhwlibDVDSpuCodec;
		DCCSP(pVideoSource->pRUA, pVideoSource->spu_decoder_moduleID, RMSpuDecoderPropertyID_CodecX, &Codec, sizeof(enum EMhwlibVideoCodec));
	}

	err = send_video_command(pVideoSource->pRUA, pVideoSource->decoder_moduleID, VideoDecoder_Command_Init);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot send VideoDecoder_Command_Init, %s\n", RMstatusToString(err)));
		return err;
	}

	if (pVideoSource->spu_decoder_moduleID != 0) {
		err = send_spu_command(pVideoSource->pRUA, pVideoSource->spu_decoder_moduleID, SpuDecoder_Command_Init);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot send SpuDecoder_Command_Init, %s\n", RMstatusToString(err)));
			return err;
		}
	}

	return RM_OK;
}


