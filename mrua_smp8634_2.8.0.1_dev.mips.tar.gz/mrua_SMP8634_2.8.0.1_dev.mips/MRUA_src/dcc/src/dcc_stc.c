/*****************************************
 Copyright © 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   dcc.c
  @brief  Decoding Chain Control API

  @author Julien Soulier
  @date   2003-10-02
*/

// to enable or disable the debug messages of this source file, put 1 or 0 below
#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

#if 0
#define STCDBG ENABLE
#else
#define STCDBG DISABLE
#endif

#include "dcc_common.h"


RMstatus DCCSTCOpen(struct DCC *pDCC, struct DCCStcProfile *stc_profile, struct DCCSTCSource **ppStcSource)
{
	RMstatus err;
	struct STC_Open_type stc_open;


	RMDBGLOG((STCDBG, "**********************DCCSTC Open\n"));
	*ppStcSource = (struct DCCSTCSource *) RMMalloc(sizeof(struct DCCSTCSource));
	if (*ppStcSource == NULL) {
		RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in system memory!\n", sizeof(struct DCCSTCSource)));
		return RM_FATALOUTOFMEMORY;
	}
	RMMemset((void*)(*ppStcSource), 0, sizeof(struct DCCSTCSource));

	(*ppStcSource)->pRUA = pDCC->pRUA;
	(*ppStcSource)->StcModuleId = EMHWLIB_MODULE(STC, stc_profile->STCID);

	stc_open.master = stc_profile->master;

	stc_open.stc_timer_id = stc_profile->stc_timer_id;
	stc_open.stc_time_resolution = stc_profile->stc_time_resolution;

	stc_open.video_timer_id = stc_profile->video_timer_id;
	stc_open.video_time_resolution = stc_profile->video_time_resolution;
	stc_open.video_offset = stc_profile->video_offset;

	stc_open.audio_timer_id = stc_profile->audio_timer_id;
	stc_open.audio_time_resolution = stc_profile->audio_time_resolution;
	stc_open.audio_offset = stc_profile->audio_offset;

	err = RUASetProperty(pDCC->pRUA, (*ppStcSource)->StcModuleId, RMSTCPropertyID_Open, &stc_open, sizeof(stc_open), 0);
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot open STC module %s\n", RMstatusToString(err)));
		return err;
	}
	return RM_OK;
}

RMstatus DCCSTCClose(struct DCCSTCSource *pStcSource)
{
	RMstatus err;
	RMuint32 dummy;
	
	RMDBGLOG((STCDBG, "**********************DCCSTC Close\n"));
	err = RUASetProperty(pStcSource->pRUA, pStcSource->StcModuleId, RMSTCPropertyID_Close, &dummy, sizeof(dummy), 0);
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot close STC module %s\n", RMstatusToString(err)));
	}
	RMFree(pStcSource);
	return err;
}

RMstatus DCCSTCSetTimeResolution(struct DCCSTCSource *pStcSource, enum DCCStreamType type, RMuint32 time_resolution)
{
	RMstatus err = RM_ERROR;

	RMDBGLOG((ENABLE, "**********************DCCSTC SetTimeResolution, %s res: %lu\n", 
		  ((type == DCC_Stc) ? "stc" : (type == DCC_Video) ? "video" : (type == DCC_Audio) ? "audio" : "invalid"),
		  time_resolution));

	switch(type) {
	case DCC_Stc:
		err = RUASetProperty(pStcSource->pRUA, pStcSource->StcModuleId, RMSTCPropertyID_StcTimeResolution, &time_resolution, sizeof(time_resolution), 0);
		break;
	case DCC_Video:
		err = RUASetProperty(pStcSource->pRUA, pStcSource->StcModuleId, RMSTCPropertyID_VideoTimeResolution, &time_resolution, sizeof(time_resolution), 0);
		break;
	case DCC_Audio:
		err = RUASetProperty(pStcSource->pRUA, pStcSource->StcModuleId, RMSTCPropertyID_AudioTimeResolution, &time_resolution, sizeof(time_resolution), 0);
		break;
	}
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot set tir %s\n", RMstatusToString(err)));
		return err;
	}
	return RM_OK;
}

RMstatus DCCSTCGetTimeResolution(struct DCCSTCSource *pStcSource, enum DCCStreamType type, RMuint32 *ptime_resolution)
{
	RMstatus err = RM_ERROR;


	switch(type) {
	case DCC_Stc:
		err = RUAGetProperty(pStcSource->pRUA, pStcSource->StcModuleId, RMSTCPropertyID_StcTimeResolution, ptime_resolution, sizeof(RMuint32));
		break;
	case DCC_Video:
		err = RUAGetProperty(pStcSource->pRUA, pStcSource->StcModuleId, RMSTCPropertyID_VideoTimeResolution, ptime_resolution, sizeof(RMuint32));
		break;
	case DCC_Audio:
		err = RUAGetProperty(pStcSource->pRUA, pStcSource->StcModuleId, RMSTCPropertyID_AudioTimeResolution, ptime_resolution, sizeof(RMuint32));
		break;
	}
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get STC tir %s\n", RMstatusToString(err)));
		return err;
	}

	RMDBGLOG((STCDBG, "**********************DCCSTC GetTimeResolution, %s res: %lu\n", 
		  ((type == DCC_Stc) ? "stc" : (type == DCC_Video) ? "video" : (type == DCC_Audio) ? "audio" : "invalid"),
		  *ptime_resolution));


	return RM_OK;
}

RMstatus DCCSTCSetVideoOffset(struct DCCSTCSource *pStcSource, RMint32 time, RMuint32 time_resolution)
{
	RMstatus err = RM_ERROR;
	struct STC_VideoOffset_type video_offset;
	
	video_offset.time_resolution = time_resolution;
	video_offset.time = time;

	RMDBGLOG((STCDBG, "**********************DCCSTC DCCSTCSetVideoOffset time: %ld res: %lu\n", time, time_resolution));

	err = RUASetProperty(pStcSource->pRUA, pStcSource->StcModuleId, RMSTCPropertyID_VideoOffset, &video_offset, sizeof(video_offset), 0);
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot set video time offset %s\n", RMstatusToString(err)));
		return err;
	}
	return RM_OK;
}

RMstatus DCCSTCSetAudioOffset(struct DCCSTCSource *pStcSource, RMint32 time, RMuint32 time_resolution)
{
	RMstatus err = RM_ERROR;
	struct STC_AudioOffset_type audio_offset;
	
	audio_offset.time_resolution = time_resolution;
	audio_offset.time = time;

	RMDBGLOG((STCDBG, "**********************DCCSTC DCCSTCSetAudioOffset time: %ld res: %lu\n", time, time_resolution));

	err = RUASetProperty(pStcSource->pRUA, pStcSource->StcModuleId, RMSTCPropertyID_AudioOffset, &audio_offset, sizeof(audio_offset), 0);
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot set audio time offset %s\n", RMstatusToString(err)));
		return err;
	}
	return RM_OK;
}

RMstatus DCCSTCSetTime(struct DCCSTCSource *pStcSource, RMuint64 time, RMuint32 time_resolution)
{
	RMstatus err;
	struct STC_Time_type stc;

	if (time_resolution)
		RMDBGLOG((ENABLE, "**********************DCCSTC SetTime, time: %llu/%lu = %llu sec\n", 
			  time,
			  time_resolution,
			  time / time_resolution));
	else {
		RMDBGLOG((ENABLE, "time resolution = 0!\n"));
		return RM_ERROR;
	}

	stc.time = time;
	stc.time_resolution = time_resolution;
	err = RUASetProperty(pStcSource->pRUA, pStcSource->StcModuleId, RMSTCPropertyID_Time, &stc, sizeof(stc), 0);
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot set STC time %s\n", RMstatusToString(err)));
		return err;
	}
	return RM_OK;
}

RMstatus DCCSTCGetTime(struct DCCSTCSource *pStcSource, RMuint64 *ptime, RMuint32 time_resolution)
{
	RMstatus err;

	RMDBGLOG((STCDBG, "**********************DCCSTC GetTime, res: %lu\n", time_resolution));


	err = RUAExchangeProperty(pStcSource->pRUA, pStcSource->StcModuleId, RMSTCPropertyID_TimeInfo,
		&time_resolution, sizeof(RMuint32), ptime, sizeof(RMuint64));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get STC time %s\n", RMstatusToString(err)));
		return err;
	}

	RMDBGLOG((STCDBG, "**********************DCCSTC GetTime, time: %llu res: %lu\n", 
		  *ptime,
		  time_resolution));

	return RM_OK;
}

RMstatus DCCSTCSetSpeed(struct DCCSTCSource *pStcSource, RMint32 numerator, RMuint32 denominator)
{
	RMstatus err;
	struct STC_Speed_type speed;

	RMDBGLOG((ENABLE, "**********************DCCSTC SetSpeed, N: %ld M: %lu\n", 
		  numerator,
		  denominator));

	speed.nominator = numerator;
	speed.denominator = denominator;
	speed.stc_filter = NoFilter;
	speed.stc_correction_method = NoCorrection;  // obsolete, ignored
	speed.video_correction_method = NoCorrection;  // obsolete, ignored
	speed.audio_correction_method = NoCorrection;  // obsolete, ignored
	err = RUASetProperty(pStcSource->pRUA, pStcSource->StcModuleId, RMSTCPropertyID_Speed, &speed, sizeof(speed), 0);
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot set STC speed %s\n", RMstatusToString(err)));
		return err;
	}
	return RM_OK;
}

RMstatus DCCVCXOSetSpeedAVCorrect(struct DCCSTCSource *pStcSource, RMint32 numerator, RMuint32 denominator)
{
	RMstatus err;
	struct VCXO_Speed_type vcxo_speed;
	
	vcxo_speed.N = numerator;
	vcxo_speed.M = denominator;
	err = RUASetProperty(pStcSource->pRUA, 
		EMHWLIB_MODULE(VCXO, EMHWLIB_MODULE_INDEX(pStcSource->StcModuleId)), 
		RMVCXOPropertyID_Speed, 
		&(vcxo_speed), sizeof(vcxo_speed), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Can not set VCXO Speed: %s\n", RMstatusToString(err)));
	}
	return err;
}

RMstatus DCCSTCSetSpeedCleanDiv(struct DCCSTCSource *pStcSource, RMint32 numerator, RMuint32 denominator)
{
	return DCCVCXOSetSpeedAVCorrect(pStcSource, numerator, denominator);
}

RMstatus DCCSTCSetSpeedVCXO(struct DCCSTCSource *pStcSource, RMint32 numerator, RMuint32 denominator)
{
	return DCCVCXOSetSpeedAVCorrect(pStcSource, numerator, denominator);
}

RMstatus DCCSTCGetSpeed(struct DCCSTCSource *pStcSource, RMint32 *pnumerator, RMuint32 *pdenominator)
{
	RMstatus err;
	struct STC_Speed_type speed;
	err = RUAGetProperty(pStcSource->pRUA, pStcSource->StcModuleId, RMSTCPropertyID_Speed, &speed, sizeof(speed));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get STC speed %s\n", RMstatusToString(err)));
		return err;
	}
 	*pnumerator = speed.nominator;
 	*pdenominator = speed.denominator;

	RMDBGLOG((STCDBG, "**********************DCCSTC GetSpeed, N: %ld M: %lu\n", 
		  *pnumerator,
		  *pdenominator));
	
	return RM_OK;
}

RMstatus DCCSTCPlay(struct DCCSTCSource *pStcSource)
{
	RMDBGLOG((ENABLE, "**********************DCCSTC Play\n"));
	return RUASetProperty(pStcSource->pRUA, pStcSource->StcModuleId, RMSTCPropertyID_Play, NULL, 0, 0);
}

RMstatus DCCSTCStop(struct DCCSTCSource *pStcSource)
{
	RMDBGLOG((ENABLE, "**********************DCCSTC Stop\n"));
	return RUASetProperty(pStcSource->pRUA, pStcSource->StcModuleId, RMSTCPropertyID_Stop, NULL, 0, 0);
}

RMstatus DCCSTCSetDiscontinuity(struct DCCSTCSource *pStcSource, RMuint64 time, RMuint32 time_resolution)
{
	RMstatus err;
	struct STC_Discontinuity_type discontinuity;

	RMDBGLOG((ENABLE, "**********************DCCSTC SetDiscontinuity, time: %llu res: %lu\n", 
		  time,
		  time_resolution));

	discontinuity.time = time;
	discontinuity.time_resolution = time_resolution;
	err = RUASetProperty(pStcSource->pRUA, pStcSource->StcModuleId, RMSTCPropertyID_Discontinuity, &discontinuity, sizeof(discontinuity), 0);
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot set stc discontinuity %s\n", RMstatusToString(err)));
		return err;
	}
	return RM_OK;
}

RMstatus DCCSTCGetModuleId(struct DCCSTCSource *pStcSource, RMuint32 *stc_id)
{
	*stc_id = pStcSource->StcModuleId;
	return RM_OK;
}
