/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   dcc_types.h
  @brief  describes types used in DCC API

  @author Julien Soulier
  @date   2003-10-02
*/

#ifndef __DCC_TYPES_H__
#define __DCC_TYPES_H__

#include "../../rmdef/rmdef.h"

enum DCCColorSize {
	DCCColorSize_32bits = 0,
	DCCColorSize_24bits,
	DCCColorSize_16bits_1555,
	DCCColorSize_16bits_4444,
	DCCColorSize_16bits_565
};

enum DCCColorFormat {
	DCCColorFormat_LUT_1bpp = 0,
	DCCColorFormat_LUT_2bpp,
	DCCColorFormat_LUT_4bpp,
	DCCColorFormat_LUT_8bpp,
	DCCColorFormat_TrueColor,
	DCCColorFormat_TrueColorWithKeyColor,
	DCCColorFortat_NonInterleavedYUV420,
	DCCColorFortat_NonInterleavedYUV422,
	DCCColorFortat_InterleavedYUV422
};

enum DCCColorSpace {
	DCCColorSpace_RGB = 0,
	DCCColorSpace_ITU601,
	DCCColorSpace_ITU709
};
	
struct DCCWindow {
	RMuint32 X;
	RMuint32 Y;
	RMuint32 W;
	RMuint32 H;
};

struct DCCRelativeWindow {
	RMuint32 PropX;
	RMuint32 PropY;
	RMuint32 PropW;
	RMuint32 PropH;
};

struct DCCFrame {
	RMuint32 Width;
	RMuint32 Height;
	RMuint32 MainAddress;
	RMuint32 SecondaryAddress;
	RMuint32 PixelAspectRatioX;
	RMuint32 PixelAspectRatioY;
	enum DCCColorSpace ColorSpace;
	enum DCCColorFormat ColorFormat;
	enum DCCColorSize ColorSize;
	RMbool Interlaced;
	RMuint64 PTS;
	RMuint32 PicturePeriod;
	RMuint8 CC[2];
	RMbool CCEnable;
	RMuint32 PanScanInfo;  // surely not a RMuint32, to be defined
	RMuint32 Flag;   // frame inused, ...
};

enum DCCComposeMode {
	DCCComposeMode_FullScreen = 0,
	DCCComposeMode_PanScan, 
	DCCComposeMode_LetterBox,
	DCCComposeMode_Window
};

struct DCCSingleContentSurface {
	RMuint32 FrameCount;
	struct DCCFrame *Frames;    /* array (fifo) of FrameCount frames */
	RMuint32 MaxWidth;
	RMuint32 MaxHeight;
	RMuint32 ForcePixelAspectRationX;
	RMuint32 ForcePixelAspectRationY;
	enum DCCCompositionMode compose;
	struct DCCWindow SrcWindow;
	struct DCCWindow CroppingWindow;
	RMuint32 GlobalAlpha0;
	RMuint32 GlobalAlpha1;
	RMuint32 KeyColor;
	RMuint32 Range;
	RMuint32 Brightness;
	RMuint32 Contrast;
	RMuint32 Saturation;
	RMbool Fading;
	RMuint32 ColorAntiFlickering;
	RMuint32 AlphaAntiFlickering;
	RMuint32 LUT[256];
	RMuint32 sourceID;
	RMuint32 timerID;
 	RMuint32 APS;
	RMuint32 CGMS;
};

enum DCCComposerChannelID {
	DCCComposerChannelID_OSD = 0, 
	DCCComposerChannelID_MainVideo, 
	DCCComposerChannelID_VCR,
	DCCComposerChannelID_CRT,	
	DCCComposerChannelID_GFX,
	DCCComposerChannelID_HardwareCursor,
	DCCComposerChannelID_SubPicture, 
	DCCComposerChannelID_GraphicsInput
};

enum DCCComposerID {
	DCCComposerID_Main = 0,
	DCCComposerID_VCR
};

struct DCCComposeInfo {
	struct DCCInputSurface *Input;
	struct DCCRelativeWindow DestWindow;
	enum DCCComposerChannelID ChannelID;
};

struct DCCCompositionSurface {
	enum DCCComposerID ID;
	RMuint32 Width;
	RMuint32 Height;
	RMuint32 PixelAspectRationX;
	RMuint32 PixelAspectRationY;
	enum DCCColorSpace ColorSpace;
	enum DCCColorFormat ColorFormat;
	enum DCCColorSize ColorSize;
	RMuint32 MasterSource;
	struct DCCComposeInfo Composition[NSCALER];
};

enum DCCDisplaySurfaceID {
	DCCDisplaySurfaceID_MainComposer = 0,
	DCCDisplaySurfaceID_VCRComposer,
	DCCDisplaySurfaceID_CRT, 
	DCCDisplaySurfaceID_ColorBars
};

enum DCCVideoPortID {
	VideoInput = 0,
	GraphicInput,
	DigitalOutput,
	MainAnalogOutput,
	ComponentOutput,
	CompositeOutput
};

enum DCCDigitalSignal {
	DCCDigitalSignal_OFF, 
	DCCDigitalSignal_CbYCr_601_8,
	DCCDigitalSignal_CbCrY_601_16,
	DCCDigitalSignal_CrCbY_601_24,
	DCCDigitalSignal_CbYCr_601_8,
	DCCDigitalSignal_YCbCr_601_16,
	DCCDigitalSignal_CrYCb_601_24,
	DCCDigitalSignal_CbYCr_656_8,
	DCCDigitalSignal_CbCrY_656_16,
	DCCDigitalSignal_CrCbY_656_24,
	DCCDigitalSignal_CbYCr_656_8,
	DCCDigitalSignal_YCbCr_656_16,
	DCCDigitalSignal_CrYCb_656_24,
	DCCDigitalSignal_RGB_24,
	DCCDigitalSignal_RBG_24,
};

struct DCCDigitalSyncInfo {
	/* need to be fill up */
};

struct DCCColorSpaceConversionMatrix {
	RMuint32 Coeff_00;
	RMuint32 Coeff_01;
	RMuint32 Coeff_02;
	RMuint32 Coeff_10;
	RMuint32 Coeff_11;
	RMuint32 Coeff_12;
	RMuint32 Coeff_20;
	RMuint32 Coeff_21;
	RMuint32 Coeff_22;
	RMuint32 Cst_0;
	RMuint32 Cst_1;
	RMuint32 Cst_2;
};
	
enum DCCChromaSpacePosition {
	DCCChromaSpacePosition_MPEG1,
	DCCChromaSpacePosition_MPEG2
};


/* to be defined elsewhere */
enum DCCSDTVVideoStandard {
	DCCSDTVVideoStandard_NTSC,
	DCCSDTVVideoStandard_PAL, 
};
	
/* to be defined elsewhere */
enum DCCHDTVVideoStandard {
	DCCHDTVVideoStandard_720p60,
	DCCHDTVVideoStandard_1080i60, 
};

/* to be defined elsewhere */
enum DCCDigitalVideoStandard {
	DCCDigitalVideoStandard_vesa64060,
	DCCDigitalVideoStandard_vip20_1080p60,
};
	
enum DCCVideoStandard {
	enum DCCSDTVVideoStandard SDTV;
	enum DCCHDTVVideoStandard HDTV;
	enum DCCDigitalVideoStandard Digital;
};

struct DCCDigitalOutVideoPort {
	enum DCCVideoStandard Standard;
	struct DCCDigitalSyncInfo SyncInfo;
	enum DCCVideoPortID SyncSourceID;
	enum DCCViodePortID OutputSyncID;
	enum DCCDigitalSignal Signal;
	struct DCCColorSpaceConversionMatrix Matrix;
	RMbool Clipping;
	enum DCCChromaSpacePosition ChromaPosition;
	enum DCCDisplaySurfaceID Source;
};

enum DCCMainAnalogSignal {
	DCCMainAnalogSignal_OFF,
	DCCMainAnalogSignal_CVBS_YC,
	DCCMainAnalogSignal_YUV_SMPTE,
	DCCMainAnalogSignal_YUV_BETACAM,
	DCCMainAnalogSignal_YUV_M2,
	DCCMainAnalogSignal_RGB_SMPTE,
	DCCMainAnalogSignal_RGB_SCART,
	DCCMainAnalogSignal_RGB_SOG
};

struct DCCMainAnalogOutVideoPort {
	enum DCCVideoStandard Standard;
	struct DCCMainAnalogSyncInfo SyncInfo;
	enum DCCVideoPortID SyncSourceID;
	enum DCCViodePortID OutputSyncID;
	enum DCCMainAnalogSignal Signal;
	struct DCCColorSpaceConversionMatrix Matrix;
	RMbool Clipping;
	RMbool vip2_0; /* not sure it is not redundant with the signal or standard stuff */
	enum DCCChromaSpacePosition ChromaPosition;
	enum DCCDisplaySurfaceID Source;
};	

#endif // __DCC_TYPES_H__
