/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   dcc_macros.h
  @brief  

  definitions of macros which can be used by applications

  @author Julien Soulier
  @date   2006-12-19
*/

#ifndef __DCC_MACROS_H__
#define __DCC_MACROS_H__

#include "../../rmdef/rmem86xxid.h"
#include "../../rmcore/include/rmstatustostring.h" 

#if ((defined(EM86XX_DEBUG_AUDIO) && (EM86XX_DEBUG_AUDIO == EM86XX_DEBUG_CHIP)) || \
	(defined(EM86XX_DEBUG_VIDEO) && (EM86XX_DEBUG_VIDEO==EM86XX_DEBUG_CHIP)) ||\
	(defined(EM86XX_DEBUG_DEMUX) && (EM86XX_DEBUG_DEMUX==EM86XX_DEBUG_CHIP)))
#define WAIT_COMMAND_TIMEOUT_US (1000000 * (30 * 60))
#else
#define WAIT_COMMAND_TIMEOUT_US 1000000
#endif

#define VIDEO_STATE_TO_STRING(x) \
	(x == VideoDecoder_State_Uninit)?"Uninit":\
	(x == VideoDecoder_State_UninitPending)?"UninitPending":\
	(x == VideoDecoder_State_InitPending)?"InitPending":\
	(x == VideoDecoder_State_Stop)?"Stop":\
	(x == VideoDecoder_State_StopPending)?"StopPending":\
	(x == VideoDecoder_State_PlayFwd)?"PlayFwd":\
	(x == VideoDecoder_State_PlayFwdPending)?"PlayFwdPending":\
	(x == VideoDecoder_State_PlayBwd)?"PlayBwd":\
	(x == VideoDecoder_State_PlayBwdPending)?"PlayBwdPending":\
	(x == VideoDecoder_State_PlayIFrame)?"PlayIFrame":\
	(x == VideoDecoder_State_PlayIFramePending)?"PlayIFramePending":\
	(x == VideoDecoder_State_DecodeFwdToEvent)?"DecodeFwdToEvent":\
	(x == VideoDecoder_State_DecodeFwdToEventPending)?"DecodeFwdToEventPending":"UNKNOWN"

#define VIDEO_COMMAND_TO_STRING(x)					\
	(x == VideoDecoder_Command_Uninit) ? "Uninit" :			\
	(x == VideoDecoder_Command_Init) ? "Init" :			\
	(x == VideoDecoder_Command_Stop) ? "Stop" :			\
	(x == VideoDecoder_Command_PlayFwd) ? "PlayFwd" :		\
	(x == VideoDecoder_Command_PlayBwd) ? "PlayBwd" :		\
	(x == VideoDecoder_Command_PlayIFrame) ? "PlayIFrame" :		\
	(x == VideoDecoder_Command_DecodeFwdToEvent) ? "DecodeFwdToEvent" : "UNKNOWN!"

	


#define AUDIO_STATE_TO_STRING(x) \
	(x == AudioDecoder_State_Uninitialized)?"Uninitialized":\
	(x == AudioDecoder_State_Error)?"Error":\
	(x == AudioDecoder_State_StopPending)?"StopPending":\
	(x == AudioDecoder_State_Stopped)?"Stopped":\
	(x == AudioDecoder_State_PlayPending)?"PlayPending":\
	(x == AudioDecoder_State_Playing)?"Playing":\
	(x == AudioDecoder_State_PausePending)?"PausePending":\
	(x == AudioDecoder_State_Paused)?"Paused":\
	(x == AudioDecoder_State_UninitPending)?"UninitPending":"UNKNOWN"

#define SPU_STATE_TO_STRING(x) \
	(x == SpuDecoder_State_Uninitialized)?"Uninitialized":\
	(x == SpuDecoder_State_UninitPending)?"UninitPending":\
	(x == SpuDecoder_State_InitPending)?"InitPending":\
	(x == SpuDecoder_State_Stopped)?"Stopped":\
	(x == SpuDecoder_State_StopPending)?"StopPending":\
	(x == SpuDecoder_State_Playing)?"Playing":\
	(x == SpuDecoder_State_PlayPending)?"PlayPending":"UNKNOWN"

#define DEMUX_STATE_TO_STRING(x) \
	(x == DemuxTask_State_Stopped)?"Stopped":\
	(x == DemuxTask_State_StopPending)?"StopPending":\
	(x == DemuxTask_State_Paused)?"Paused":\
	(x == DemuxTask_State_PausePending)?"PausePending":\
	(x == DemuxTask_State_Playing)?"Playing":\
	(x == DemuxTask_State_PlayPending)?"PlayPending":"UNKNOWN"

// ErrOK = 0: return err unless RM_OK
// ErrOK = RM_OK: ignore all errors
// ErrOK = RM_xxx: ignore specific RM_xxx error
#define DCCSPERROK(ErrOK, pRUA, moduleID, propertyID, pValue, ValueSize, ErrMsg)							\
        {														\
		struct RUAEvent evt;											\
		RMstatus err;												\
		RMuint32 n;												\
															\
		n = 5;													\
		do {								                                        \
			evt.Mask = EMHWLIB_DISPLAY_EVENT_ID(moduleID);							\
			if (evt.Mask > 0) {										\
				evt.ModuleID = EMHWLIB_MODULE(DisplayBlock, 0);						\
				err = RUAResetEvent(pRUA, &evt);							\
				if (RMFAILED(err)) {									\
					RMDBGLOG((ENABLE, "Cannot reset display event, %s\n", RMstatusToString(err)));	\
					return err;									\
				}											\
			}												\
															\
			err = RUASetProperty(pRUA, moduleID, propertyID, pValue, ValueSize, 0);				\
			if ((err == RM_PENDING) && (evt.Mask > 0)) {							\
				RMuint32 index;										\
															\
				err = RUAWaitForMultipleEvents(pRUA, &evt, 1, WAIT_COMMAND_TIMEOUT_US, &index);		\
				if (RMFAILED(err)) {									\
					RMDBGLOG((ENABLE, "wait for display update event completion failed, %s\n", 	\
						RMstatusToString(err)));						\
					if (err != RM_PENDING) return err;						\
				}                                                                          		\
				err = RUASetProperty(pRUA, moduleID, propertyID, pValue, ValueSize, 0);			\
			}												\
			if (err == RM_PENDING) {									\
				RMDBGLOG((ENABLE, "Property %d on module %d still pending, trying again...\n", 		\
					propertyID, moduleID));								\
			}												\
			n--;												\
		} while ((n > 0) && (err == RM_PENDING));								\
															\
		if (RMFAILED(err) && ((!(ErrOK)) || (err != (ErrOK)))) {											\
			RMDBGLOG((ENABLE, ErrMsg ": Property %d on module %d, %s\n", 					\
				propertyID, moduleID, RMstatusToString(err)));						\
			if ((ErrOK) != RM_OK) return err;											\
		}													\
	}

#define DCCSPERR(pRUA, moduleID, propertyID, pValue, ValueSize, ErrMsg) DCCSPERROK(0, pRUA, moduleID, propertyID, pValue, ValueSize, "Cannot set")
#define DCCSP(pRUA, moduleID, propertyID, pValue, ValueSize) DCCSPERR(pRUA, moduleID, propertyID, pValue, ValueSize, "Cannot set")

#endif // __DCC_MACROS_H__
