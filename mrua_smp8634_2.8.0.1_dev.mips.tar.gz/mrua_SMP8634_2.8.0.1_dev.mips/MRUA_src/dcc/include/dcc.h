/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   dcc.h
  @brief  

  @author Julien Soulier
  @date   2004-04-08
*/

#ifndef __DCC_H__
#define __DCC_H__

#include "../../rmdef/rmdef.h"
#include "../../rmcore/include/rmcore.h"
#include "../../rua/include/rua.h"
#include "../../rua/include/rua_property.h"


RM_EXTERN_C_BLOCKSTART

enum DCCMicrocode {
	DCCMicrocode_Demux = 0,
	DCCMicrocode_Audio,
	DCCMicrocode_Video
};

enum DCCInitMode {
	DCCInitMode_InitDisplay = 0,
	DCCInitMode_LeaveDisplay
};

enum DCCStopMode {
	DCCStopMode_BlackFrame = 0,
	DCCStopMode_LastFrame
};

enum DCCRoute {
	DCCRoute_Main = 0,
	DCCRoute_Secondary,
	DCCRoute_ColorBars,
	DCCRoute_HDSD, /* to be removed */
};

enum DCCSurface {
	DCCSurface_Video = 0,
	DCCSurface_OSD,
	DCCSurface_SPU
};

struct DCCAudioProfile {
	RMuint32 BitstreamFIFOSize;
	RMuint32 XferFIFOCount;
	RMuint32 DemuxProgramID;
	RMuint32 AudioEngineID;
	RMuint32 AudioDecoderID;
	RMuint32 STCID;
};

struct DCCVideoProfile {
	RMuint32 BitstreamFIFOSize;
 	RMuint32 XferFIFOCount;
	enum MPEG_Profile MPEGProfile;
	RMuint32 DemuxProgramID;
	RMuint32 MpegEngineID;
	RMuint32 VideoDecoderID;
	RMuint32 SPUBitstreamFIFOSize;
	RMuint32 SPUXferFIFOCount;
	RMuint32 STCID;
};

struct DCCCaptureProfile {
	enum EMhwlibSamplingMode SamplingMode;
	enum EMhwlibColorMode ColorMode;
	enum EMhwlibColorFormat ColorFormat;
	RMuint32 Width;
	RMuint32 Height;
	RMuint32 OrigWidth;
	RMuint32 OrigHeight;
	RMbool Interlaced;
	RMbool DeInt;
	enum EMhwlibColorSpace ColorSpace;
	struct EMhwlibAspectRatio PictureAspectRatio;
	struct EMhwlibAspectRatio PixelAspectRatio;
	RMuint32 TimerNumber;
	struct Input_GPIOFieldID_type gpio;
	RMbool UseV2Pads;
};

enum DCCVideoConnector {
	DCCVideoConnector_SVIDEO = 0,
	DCCVideoConnector_DVI,
	DCCVideoConnector_LVDS,
	DCCVideoConnector_Digital, 
	DCCVideoConnector_VGA,
	DCCVideoConnector_SCART,
	DCCVideoConnector_COMPONENT,
	DCCVideoConnector_COMPOSITE
};

enum DCCVideoPlayCommand {
	DCCVideoPlayFwd = VideoDecoder_Command_PlayFwd,
	DCCVideoPlayIFrame = VideoDecoder_Command_PlayIFrame,
	DCCVideoPlayNextFrame
};

struct DCCAudioDecoderFormat {
	enum AudioDecoder_Codec_type Codec;
};

struct DCCOSDProfile {
	enum EMhwlibSamplingMode SamplingMode;
	enum EMhwlibColorMode ColorMode;
	enum EMhwlibColorFormat ColorFormat;
	RMuint32 Width;
	RMuint32 Height;
	enum EMhwlibColorSpace ColorSpace;
	struct EMhwlibAspectRatio PixelAspectRatio;
};

struct DCC;
struct DCCAudioSource;
struct DCCVideoSource;
struct DCCDemuxSource;
struct DCCOSDPicture;
struct DCCSTCSource;

typedef RMuint32 (*DCCAllocFunc) (struct RUA *pRua, RMuint32 ModuleID, RMuint32 dramIndex, enum RUADramType dramtype, RMuint32 size); 
typedef void (*DCCFreeFunc) (struct RUA *pRUA, RMuint32 ptr);

/**
   Opens dcc library. You need to open a RUA interface prior to call this function.

   @param pRUA [IN] a valid RUA handler
   @param ppDCC [OUT] NULL, if the call failed or a valid pointer to a dcc handler otherwise
   @return RM_OK or RM_ERROR
*/
RMstatus DCCOpen(struct RUA *pRUA, struct DCC **ppDCC);

/**
   Closes the dcc library instance. This function does not change the
   hardware state.  Especially, the display is not reset.

   @param pDCC [IN] valid pointer to a previously open DCC instance
   @return RM_OK or RM_ERROR
*/
RMstatus DCCClose(struct DCC *pDCC);

/**
   Initializes the display.
   Deprecated, use DCCInitChainEx instead. 

   @param pDCC [IN] valid pointer to a previously open DCC instance
   @return RM_OK or RM_ERROR
*/
RMstatus DCCInitChain(struct DCC *pDCC);

/**
   If the display has not been initialized yet, you can choose to
   reinitialize the display or not using the init_mode argument.  
   Otherwise the display is initialized automatically.

   @param pDCC [IN] valid pointer to a previously open DCC instance
   @param init_mode [IN]  DCCInitMode_InitDisplay to force display initialization.
   @return RM_OK or RM_ERROR
*/
RMstatus DCCInitChainEx(struct DCC *pDCC, enum DCCInitMode init_mode);

/**
   Initializes the audio and video decoders and the hardware demux.
   It re-initializes also the display.
   Deprecated, use DCCInitMicrocodeEx instead. 
   
   @param pDCC [IN] valid pointer to a previously open DCC instance
   @return RM_OK or RM_ERROR
*/
RMstatus DCCInitMicroCode(struct DCC *pDCC);

/**
   Initializes the audio and video decoders and the hardware demux.
   If the display has not been initialized yet, you can choose to
   reinitialize the display or not using the init_mode argument.  
   Otherwise the display is initialized automatically.

   @param pDCC [IN] valid pointer to a previously open DCC instance
   @param init_mode [IN]  DCCInitMode_InitDisplay to force display initialization.
   @return RM_OK or RM_ERROR
*/
RMstatus DCCInitMicroCodeEx(struct DCC *pDCC, enum DCCInitMode init_mode);

/**
   Initializes the chsoen microcode only. This can be useful in case
   we need to init or reinit a particular ucode.
   
   @param pDCC [IN] valid pointer to a previously open DCC instance
   @param ucode [IN] : microcode to init.
   @return RM_OK or RM_ERROR
*/
RMstatus DCCInitSpecificMicroCode(struct DCC *pDCC, enum DCCMicrocode ucode);

/**
   Sets the display aspect ratio for the route. This is the dislay
   aspect ratio of the screen device connected to the route.
   For example: 4:3 or 16:9

   @param pDCC  [IN] valid pointer to a previously open DCC instance
   @param route [IN] one of the valid route
   @param ar_x  [IN] horizontal display aspect ratio
   @param ar_y  [IN] vertical display aspect ratio
   @return RM_OK or RM_ERROR
*/
RMstatus DCCSetRouteDisplayAspectRatio(struct DCC *pDCC, enum DCCRoute route, RMuint8 ar_x, RMuint8 ar_y);

/**
   This functions allow the route to take the display aspect ratio of
   one specific source.  This is useful in case the application wants
   the TV to perform the aspect ratio conversion (using WSS).

   @param pDCC   [IN] valid pointer to a previously open DCC instance
   @param route  [IN] one of the valid route
   @param scaler [IN} the EMhwlib ModuleID of the scaler giving the aspect ratio to the route.
   @return RM_OK or RM_ERROR
*/
RMstatus DCCSetRouteDisplayAspectRatioFromSource(struct DCC *pDCC, enum DCCRoute route, RMuint32 scaler);

/**
   Sets the video Standard for the route. This is the standard as
   output by the chip and received by the screen device connected to
   the route.

   @param pDCC  [IN] valid pointer to a previously open DCC instance
   @param route [IN] one of the valid route
   @param standard [IN] one of the valid standard
   @return RM_OK or RM_ERROR
*/
RMstatus DCCSetStandard(struct DCC *pDCC, enum DCCRoute route, enum EMhwlibTVStandard standard);

/**
   @param standard
   @return 
   
   returns TRUE if the mode requires to set the DoubleRate feature on the digital output 
*/
RMbool DCCGetDoubleRate(enum EMhwlibTVStandard standard);

/**
   @param pDCC
   @param connector
   @param route
   @param standard
   @return
*/
RMstatus DCCSetMasterConnector(struct DCC *pDCC,
			       enum DCCVideoConnector connector,
			       enum DCCRoute route,
			       enum EMhwlibTVStandard standard);


/**
   @param pDCC
   @param slave_connector
   @param master_connector
   @param route
   @return
*/
RMstatus DCCSetSlaveConnector(struct DCC *pDCC,
			      enum DCCVideoConnector slave_connector,
			      enum DCCVideoConnector master_connector,
			      enum DCCRoute route);

/**
   @param pDCC
   @param sd_connector
   @param hd_connector
   @param sd_standard
   @param hdsd_mode
   @return
*/
RMstatus DCCSetSDSlaveConnector(struct DCC *pDCC,
				enum DCCVideoConnector sd_connector,
				enum DCCVideoConnector hd_connector,
				enum EMhwlibTVStandard sd_standard,
				enum EMhwlibHDSDConversionMode hdsd_mode);



/**
   @param pDCC
   @param route_video
   @param route_vga
   @param standard_video
   @param standard_vga
   @return
*/
RMstatus DCCSetStandardDual(
	struct DCC *pDCC, 
	enum DCCRoute route_video, 
	enum DCCRoute route_vga, 
	enum EMhwlibTVStandard standard_video, 
	enum EMhwlibTVStandard standard_vga);

/**
   Sets the HD and SD video standards for the route. These are the 
   standards as output by the chip and received by the screen device 
   connected to the route.

   @param pDCC  [IN] valid pointer to a previously open DCC instance
   @param route [IN] one of the valid route
   @param sd_standard [IN] one of the valid standard
   @param hd_standard [IN] one of the valid standard
   @param hdsd_mode [IN] conversion mode
   @return RM_OK or RM_ERROR
*/
RMstatus DCCSetHDSDStandards(struct DCC *pDCC, 
			     enum DCCRoute route, 
			     enum EMhwlibTVStandard sd_standard,
			     enum EMhwlibTVStandard hd_standard,
			     enum EMhwlibHDSDConversionMode hdsd_mode);

/**
   Sets the TV format for the route. Compare to predefined standard,
   The TV format allows to setup completely the output video signal.
   Note that the digital and the analog formats must have the same
   timing (VSYNC/HSYNC).

   @param pDCC  [IN] valid pointer to a previously open DCC instance
   @param route [IN] one of the valid route
   @param fmt_d [IN] format used by digital output
   @param fmt_a [IN] format used by analog output
   @return RM_OK or RM_ERROR
*/
RMstatus DCCSetTVFormat(struct DCC *pDCC, enum DCCRoute route, struct EMhwlibTVFormatDigital *fmt_d, struct EMhwlibTVFormatAnalog *fmt_a);

/**
   Configures the SCART RGB/CVBS and aspect ratio selection pins

   @param pDCC  [IN] valid pointer to a previously open DCC instance
   @param route [IN] one of the valid route
   @param connector [IN] a valid video connector
   @param Enable [IN] TRUE=Enable SCART or FALSE=Disable SCART
   @param EnableBit [IN] GPIO number (normally 13)
   @param EnableInvert [IN] TRUE or FALSE
   @param WideBit [IN] GPIO number (normally 14)
   @param WideInvert [IN] TRUE or FALSE
   @param WideState [IN] auto, 4:3 or 16:9
   @return RM_OK or RM_ERROR
*/
RMstatus DCCSetSCART(struct DCC *pDCC, 
	enum DCCRoute route, 
	enum DCCVideoConnector connector, 
	RMbool Enable, 
	RMuint32 EnableBit, 
	RMbool EnableInvert, 
	RMuint32 WideBit, 
	RMbool WideInvert, 
	enum EMhwlibSCARTWideBitState WideState);

/**
   Enables or disables the output of a valid video connector. 

   @param pDCC  [IN] valid pointer to a previously open DCC instance
   @param route [IN] one of the valid route
   @param connector [IN] a valid video connector
   @param state [IN] TRUE or FALSE
   @return RM_OK or RM_ERROR
*/
RMstatus DCCEnableVideoConnector(struct DCC *pDCC, enum DCCRoute route, enum DCCVideoConnector connector, RMbool state);

/**
   Gets from the predefined configuration the EMhwlib moduleID
   corresponding to this video connector on the specified route. It is
   then possible to set properties directly to this module.

   @param pDCC  [IN] valid pointer to a previously open DCC instance
   @param route [IN] one of the valid route
   @param connector [IN] a valid video connector
   @param moduleID [OUT] pointer to the EMhwlib moduleID     
   @return RM_OK or RM_ERROR
*/
RMstatus DCCGetVideoConnectorModuleID(struct DCC *pDCC, enum DCCRoute route, enum DCCVideoConnector connector, RMuint32 *moduleID);

/**
   Configures the DVI output on the specified route if any.

   @param pDCC  [IN] valid pointer to a previously open DCC instance
   @param route [IN] one of the valid route
   @param color_space [IN] color_space (RGB, YUV, ...)
   @param timing [IN] 601, 656, ...       
   @param bus_size [IN] 8 bits, 16 bits, ...     
   @return RM_OK or RM_ERROR
*/
RMstatus DCCSetDVIOutFormat(struct DCC *pDCC, enum DCCRoute route, enum EMhwlibColorSpace color_space, enum EMhwlibDigitalTimingSignal timing, RMuint32 bus_size);

/**
   Configures the component output on the specified route if any.

   @param pDCC  [IN] valid pointer to a previously open DCC instance
   @param route [IN] one of the valid route
   @param color_space [IN] color_space (RGB, YUV, ...)
   @param component [IN] YUV SMPTE, RGB sync on green, ...     
   @return RM_OK or RM_ERROR
*/
RMstatus DCCSetComponentOutFormat(struct DCC *pDCC, enum DCCRoute route, enum EMhwlibColorSpace color_space, enum EMhwlibComponentMode component);

/**
   The SPU surface requires a scaler in order to be active. When the
   SPU surface is active this scaler cannot be used for something
   else, like OSD for example. It may be useful in some cases to
   enabe/disable the SPU surface to allow the application a fine
   control of the scaling resources.

   @param pDCC  [IN] valid pointer to a previously open DCC instance
   @param route [IN] one of the valid route
   @param index [IN] index of the SPU surface on the specified route
   @param enable [IN] TRUE or FALSE to enable or disable the SPU surface       
   @param pVideoSource [IN] the valid video source associated to this SPU surface.
   @return RM_OK or RM_ERROR
*/
RMstatus DCCEnableSPUSurface(struct DCC *pDCC, enum DCCRoute route, RMuint32 index, struct DCCVideoSource *pVideoSource, RMbool enable);

/**
   Gets the sacler moduleID corresponding to the specified surface and
   index on a given route. This scaler moduleID can be used to
   directly set/get propeties.

   @param pDCC  [IN] valid pointer to a previously open DCC instance
   @param route [IN] one of the valid route
   @param surface [IN] one of the valid surface
   @param index [IN] index of the surface on the specified route
   @param surfaceID [OUT] a valid pointer to a scaler module ID    
   @return RM_OK or RM_ERROR
*/
RMstatus DCCGetScalerModuleID(struct DCC *pDCC, enum DCCRoute route, enum DCCSurface surface, RMuint32 index, RMuint32 *surfaceID);

/**
   Sets the a video source to a surface. The surfaceID corresponds to
   the scaler module ID got from DCCGetScalerModuleID. Once the video
   source is connected it can be displayed if the display is well
   configured.

   @param pDCC [IN] valid pointer to a previously open DCC instance
   @param surfaceID [IN] scaler module ID 
   @param pVideoSource [IN] pointer to an opened video source. 
   @return RM_OK or RM_ERROR
*/
RMstatus DCCSetSurfaceSource(struct DCC *pDCC, RMuint32 surfaceID, struct DCCVideoSource *pVideoSource);


/**
   Opens a video decoder. This call is doing the RUA allocation
   and setting up the codec and state according to the dcc_profile. 
   If (dcc_profile->SPUBitstreamFIFOSize > 0) then a SPU decoder will
   be attached to this video decoder as well.

   @param pDCC [IN] valid pointer to a previously open DCC instance
   @param dcc_profile [IN] profile to setup the video decoder correctly.
   @param ppVideoSource [OUT] a valid pointer to a video source.
   @return RM_OK or RM_ERROR
*/
RMstatus DCCOpenVideoDecoderSource(struct DCC *pDCC, struct DCCVideoProfile *dcc_profile, struct DCCVideoSource **ppVideoSource);

/**
   Opens an OSD surface source according to the given profile. This
   call will allocate the memory needed in order to store the OSD
   bitmap.

   @param pDCC [IN] valid pointer to a previously open DCC instance
   @param profile [IN] profile to setup the OSD source correctly.
   @param ppVideoSource [OUT] a valid pointer to an OSD source.
   @return RM_OK or RM_ERROR
*/
RMstatus DCCOpenOSDVideoSource(struct DCC *pDCC, struct DCCOSDProfile *profile, struct DCCVideoSource **ppVideoSource);

/**
   @param pDCC  
   @param profile       
   @param picture_count 
   @param ppVideoSource 
   @param pStcSource
   @return RM_OK or RM_ERROR
*/
RMstatus DCCOpenMultiplePictureOSDVideoSource(struct DCC *pDCC, struct DCCOSDProfile *profile, RMuint32 picture_count, 
					      struct DCCVideoSource **ppVideoSource, struct DCCSTCSource *pStcSource);

/**
   @param pVideoSource  
   @param Index
   @param Pts
   @return RM_OK or RM_ERROR
*/
RMstatus DCCInsertPictureInMultiplePictureOSDVideoSource(struct DCCVideoSource *pVideoSource, RMuint32 Index, RMuint64 Pts);

/**
   @param pVideoSource   
   @param index   
   @param PictureAddr      
   @param LumaAddr      
   @param LumaSize      
   @param ChromaAddr    
   @param ChromaSize    
   @return RM_OK or RM_ERROR   
*/
RMstatus DCCGetOSDPictureInfo(struct DCCVideoSource *pVideoSource, RMuint32 index, RMuint32 *PictureAddr,  RMuint32 *LumaAddr, RMuint32 *LumaSize, RMuint32 *ChromaAddr, RMuint32 *ChromaSize);


/**
   Opens a video capture source. The source format is specified by the
   DCCCaptureProfile. This call will allocate the memory needed inside
   RUA.

   @param pDCC [IN] valid pointer to a previously open DCC instance
   @param pProfile [IN] profile to configure the video input block
   @param TimerNumber [IN] which timer associated to this video capture
   @param dram [IN] which dram controller to allocate the memory in
   @param ppVideoSource [OUT] a valid pointer to a video source.
   @return RM_OK or RM_ERROR
*/
RMstatus DCCOpenVideoInputSource(struct DCC *pDCC, struct DCCCaptureProfile *pProfile, RMuint32 TimerNumber, RMuint32 dram, struct DCCVideoSource **ppVideoSource);

/**
   Opens a graphics capture source. The source format is specified by
   the DCCCaptureProfile. This call will allocate the memory needed
   inside RUA.

   @param pDCC [IN] valid pointer to a previously open DCC instance
   @param pProfile [IN] profile to configure the graphics input block
   @param TimerNumber [IN] which timer associated to this graphics capture
   @param dram [IN] which dram controller to allocate the memory in
   @param ppVideoSource [OUT] a valid pointer to a video source.
   @return RM_OK or RM_ERROR
*/
RMstatus DCCOpenGraphicInputSource(struct DCC *pDCC, struct DCCCaptureProfile *pProfile, RMuint32 TimerNumber, RMuint32 dram, struct DCCVideoSource **ppVideoSource);

/**
   Closes a valid previously opened video source. This call will free
   all resources previously allocated for this video source.

   @param pVideoSource [IN] a valid pointer to a video source.
   @return RM_OK or RM_ERROR
*/
RMstatus DCCCloseVideoSource(struct DCCVideoSource *pVideoSource);

/**
   Gets informations from a prevously opened video decoder
   source. These informations allow the user to set properties
   directly to emhwlib modules (like VideoDecoer, SpuDecoder,...)

   @param pVideoSource  [IN] a valid previously opened video decoder source
   @param video_decoder [OUT] VideoDecoer emhwlib module ID
   @param spu_decoder [OUT] SpuDecoder emhwlib module ID
   @param timer [OUT] timer number associated to this source (can be used in DCCSetSystemTime...)
   @return RM_OK or RM_ERROR
*/
RMstatus DCCGetVideoDecoderSourceInfo(struct DCCVideoSource *pVideoSource, RMuint32 *video_decoder, RMuint32 *spu_decoder, RMuint32 *timer);

/**
   Gets informations from an opened OSD source.

   @param pDCC
   @param pVideoSource [IN] a valid previously opened video decoder source
   @param profile [IN] the profile used for the DCCOpenOSDS
   @param SurfaceAddr      
   @param SurfaceSize    (set only if profile is non null)    
   @return 
*/
RMstatus DCCGetOSDSurfaceInfo(struct DCC *pDCC, struct DCCVideoSource *pVideoSource, struct DCCOSDProfile *profile, RMuint32 *SurfaceAddr, RMuint32 *SurfaceSize);

/**
   @param pVideoSource
   @param codec
   @return 
*/
RMstatus DCCSetVideoDecoderSourceCodec(struct DCCVideoSource *pVideoSource, enum VideoDecoder_Codec_type codec);


/**
   @param pVideoSource  
   @param LumaAddr           (set only if non null)
   @param LumaSize           (set only if non null)
   @param ChromaAddr         (set only if non null)
   @param ChromaSize         (set only if non null)
   @return 
*/
RMstatus DCCGetOSDVideoSourceInfo(struct DCCVideoSource *pVideoSource, RMuint32 *LumaAddr, RMuint32 *LumaSize, RMuint32 *ChromaAddr, RMuint32 *ChromaSize);


/**
   @param pVideoSource  
   @return 
*/
RMstatus DCCClearOSDVideoSource(struct DCCVideoSource *pVideoSource);

/**
   @param pVideoSource  
   @param index 
   @return
*/
RMstatus DCCClearOSDPicture(struct DCCVideoSource *pVideoSource, RMuint32 index);

/**
   @param pVideoSource  
   @param pUserLuma     
   @param pUserChroma   
   @return 
*/
RMstatus DCCSetOSDVideoSource(struct DCCVideoSource *pVideoSource, RMuint8 * pUserLuma, RMuint8 * pUserChroma);

/**
   @param pVideoSource   
   @param index   
   @param pUserLuma     
   @param pUserChroma   
   @return RM_OK or RM_ERROR
*/
RMstatus DCCSetOSDPicture(struct DCCVideoSource *pVideoSource, RMuint32 index, RMuint8 * pUserLuma, RMuint8 * pUserChroma);

/**
   @param pVideoSource
   @param cmd
   @return 
*/
RMstatus DCCPlayVideoSource(struct DCCVideoSource *pVideoSource, enum DCCVideoPlayCommand cmd);

/**
   @param pVideoSource      
   @param stop_mode
   @return 
*/
RMstatus DCCStopVideoSource(struct DCCVideoSource *pVideoSource, enum DCCStopMode stop_mode);

/**
   @param pVideoSource      
   @return 
*/
RMstatus DCCPauseVideoSource(struct DCCVideoSource *pVideoSource);

/**
   @param pVideoSource  
   @param enable        
   @return 
*/
RMstatus DCCEnableVideoSource(struct DCCVideoSource *pVideoSource, RMbool enable);

/**
   @param pDCC  
   @param profile       
   @param ppAudioSource
   @return 
*/
RMstatus DCCOpenAudioDecoderSource(struct DCC *pDCC, struct DCCAudioProfile *profile, struct DCCAudioSource **ppAudioSource);

/**
   @param pAudioSource
   @return 
*/
RMstatus DCCCloseAudioSource(struct DCCAudioSource *pAudioSource);

/**
   @param pAudioSource
   @param decoder
   @param engine
   @param timer 
   @return 
*/
RMstatus DCCGetAudioDecoderSourceInfo(struct DCCAudioSource *pAudioSource, RMuint32 *decoder, RMuint32 *engine, RMuint32 *timer);

/**
   @param pAudioSource  
   @param pFormat       
   @return 
*/
RMstatus DCCSetAudioDecoderSourceFormat(struct DCCAudioSource *pAudioSource, struct DCCAudioDecoderFormat *pFormat);

/**
  Set Bts EoS to decoder
*/
RMstatus DCCSetAudioBtsThreshold(struct DCCAudioSource *pAudioSource, RMuint32 level);

/**
   @param pAudioSource
   @param pFormat
   @return
*/
RMstatus DCCSetAudioDVDAFormat(struct DCCAudioSource *pAudioSource, struct AudioDecoder_DVDAParameters_type *pFormat);

/**
   @param pAudioSource
   @param pFormat
   @return
*/
RMstatus DCCSetAudioBSACFormat(struct DCCAudioSource *pAudioSource, struct AudioDecoder_BSACParameters_type *pFormat);

/**
   @param pAudioSource  
   @param pFormat       
   @return 
*/
RMstatus DCCSetAudioAc3Format(struct DCCAudioSource *pAudioSource, struct AudioDecoder_Ac3Parameters_type *pFormat);

/**
   @param pAudioSource  
   @param pFormat       
   @return 
*/
RMstatus DCCSetAudioDtsFormat(struct DCCAudioSource *pAudioSource, struct AudioDecoder_DtsParameters_type *pFormat);

/**
   @param pAudioSource  
   @param pFormat       
   @return 
*/
RMstatus DCCSetAudioTToneFormat(struct DCCAudioSource *pAudioSource, struct AudioDecoder_TToneParameters_type *pFormat);

/**
   @param pAudioSource  
   @param pFormat       
   @return
*/
RMstatus DCCSetAudioMpegFormat(struct DCCAudioSource *pAudioSource, struct AudioDecoder_MpegParameters_type *pFormat);

/**
   @param pAudioSource
   @param pFormat
   @return
*/
RMstatus DCCSetAudioPcmxFormat(struct DCCAudioSource *pAudioSource, struct AudioDecoder_PCMXParameters_type *pFormat);
/**
   @param pAudioSource  
   @param pFormat       
   @return
*/
RMstatus DCCSetAudioPcmCdaFormat(struct DCCAudioSource *pAudioSource, struct AudioDecoder_PcmCdaParameters_type *pFormat);

/**
   @param pAudioSource  
   @param pFormat       
   @return
*/
RMstatus DCCSetAudioLpcmVobFormat(struct DCCAudioSource *pAudioSource, struct AudioDecoder_LpcmVobParameters_type *pFormat);

/**
   @param pAudioSource  
   @param pFormat       
   @return
*/
RMstatus DCCSetAudioLpcmBDFormat(struct DCCAudioSource *pAudioSource, struct AudioDecoder_LpcmBDParameters_type *pFormat);

/**
   @param pAudioSource  
   @param pFormat       
   @return
*/
RMstatus DCCSetAudioLpcmAobFormat(struct DCCAudioSource *pAudioSource, struct AudioDecoder_LpcmAobParameters_type *pFormat);

/**
   @param pAudioSource  
   @param pFormat       
   @return
*/
RMstatus DCCSetAudioWMAFormat(struct DCCAudioSource *pAudioSource, struct AudioDecoder_WMAParameters_type *pFormat);

/**
   @param pAudioSource  
   @param pFormat       
   @return
*/
RMstatus DCCSetAudioAACFormat(struct DCCAudioSource *pAudioSource, struct AudioDecoder_AACParameters_type *pFormat);

/**
   @param pAudioSource
   @return 
*/
RMstatus DCCPlayAudioSource(struct DCCAudioSource *pAudioSource);

/**
   @param pAudioSource
   @return 
*/
RMstatus DCCStopAudioSource(struct DCCAudioSource *pAudioSource);

/**
   @param pAudioSource
   @return 
*/
RMstatus DCCPauseAudioSource(struct DCCAudioSource *pAudioSource);


// for all channels
RMstatus DCCSetAudioSourceVolume(struct DCCAudioSource *pAudioSource, RMuint32 volume);
RMstatus DCCGetAudioSourceVolume(struct DCCAudioSource *pAudioSource, RMuint32 *volume);

/**
   @param pAudioSource
   @param enable_pts
   @return 
*/
RMstatus DCCEnableAudioPTS(struct DCCAudioSource *pAudioSource, RMbool enable_pts);

/**
   @param pDCC  
   @param timer 
   @param base  
   @return 
*/
RMstatus DCCSetSystemTimeBase(struct DCC *pDCC, RMuint32 timer, RMuint64 base);

/**
   @param pDCC  
   @param timer 
   @param tir   
   @return 
*/
RMstatus DCCSetSystemTimeScale(struct DCC *pDCC, RMuint32 timer, RMuint32 tir);

/**
   @param pDCC  
   @param timer 
   @param N     
   @param M     
   @return 
*/
RMstatus DCCSetSystemTimeSpeedFactor(struct DCC *pDCC, RMuint32 timer, RMint32 N, RMuint32 M);

/**
   @param pDCC  
   @param timer 
   @param offset     
   @param frequency     
   @return 
*/
RMstatus DCCSetSystemTimeSource(struct DCC *pDCC, RMuint32 timer, RMuint32 offset, RMuint32 frequency);

/**
   @param pDCC  
   @param timer 
   @param base  
   @return 
*/
RMstatus DCCGetSystemTimeBase(struct DCC *pDCC, RMuint32 timer, RMuint64 *base);

/**
   @param pDCC  
   @param timer 
   @param tir   
   @return 
*/
RMstatus DCCGetSystemTimeScale(struct DCC *pDCC, RMuint32 timer, RMuint32 *tir);

/**
   @param pDCC  
   @param timer 
   @param N     
   @param M     
   @return 
*/
RMstatus DCCGetSystemTimeSpeedFactor(struct DCC *pDCC, RMuint32 timer, RMint32 *N, RMuint32 *M);

/* If bussize is 8 bit, the following members of fmt have to be already doubled:
   PixelClock, ActiveWidth, XOffset, HTotalSize, HSyncWidth */
RMstatus DCCSetupVideoInputFormat(
	struct DCC *pDCC, 
	struct EMhwlibTVFormatDigital fmt,
	enum EMhwlibDigitalTimingSignal DigitalTimingSignal, 
	RMbool UseVideoValid, 
	RMuint32 bussize, 
	RMint32 over_pos_x, 
	RMint32 over_pos_y, 
	RMuint32 over_width, 
	RMuint32 over_height, 
	RMbool InvertVSync, 
	RMbool InvertHSync, 
	RMbool InvertFieldID, 
	RMbool UseGPIOFieldID);

RMstatus DCCSetupVideoInput(
	struct DCC *pDCC, 
	enum EMhwlibTVStandard standard,
	enum EMhwlibDigitalTimingSignal DigitalTimingSignal, 
	RMbool UseVideoValid, 
	RMuint32 bussize, 
	RMint32 over_pos_x, 
	RMint32 over_pos_y, 
	RMuint32 over_width, 
	RMuint32 over_height, 
	RMbool InvertVSync, 
	RMbool InvertHSync, 
	RMbool InvertFieldID, 
	RMbool UseGPIOFieldID);

/* If bussize is 8 bit, the following members of fmt have to be already doubled:
   PixelClock, ActiveWidth, XOffset, HTotalSize, HSyncWidth */
RMstatus DCCSetupGraphicInputFormat(
	struct DCC *pDCC, 
	struct EMhwlibTVFormatDigital fmt,
	enum EMhwlibDigitalTimingSignal DigitalTimingSignal, 
	RMbool UseVideoValid, 
	RMuint32 bussize,
	RMint32 over_pos_x, 
	RMint32 over_pos_y, 
	RMuint32 over_width, 
	RMuint32 over_height, 
	RMbool DualEdge, 
	RMbool DualEdgeWidth, 
	RMbool DualEdgeInvert, 
	enum EMhwlibInputColorFormat InputColorFormat, 
	enum EMhwlibColorSpace InputColorSpace, 
	RMbool InvertVSync, 
	RMbool InvertHSync, 
	RMbool InvertFieldID, 
	RMbool UseGPIOFieldID);

RMstatus DCCSetupGraphicInput(
	struct DCC *pDCC, 
	enum EMhwlibTVStandard standard,
	enum EMhwlibDigitalTimingSignal DigitalTimingSignal, 
	RMbool UseVideoValid, 
	RMuint32 bussize,
	RMint32 over_pos_x, 
	RMint32 over_pos_y, 
	RMuint32 over_width, 
	RMuint32 over_height, 
	RMbool DualEdge, 
	RMbool DualEdgeWidth, 
	RMbool DualEdgeInvert, 
	enum EMhwlibInputColorFormat InputColorFormat, 
	enum EMhwlibColorSpace InputColorSpace, 
	RMbool InvertVSync, 
	RMbool InvertHSync, 
	RMbool InvertFieldID, 
	RMbool UseGPIOFieldID);

/**
   specify a VBI data window into the video picture
   
   @param pDCC
   @param input ModuleID of the input to use
   @param x     horizontal position of the VBI window's left edge in the decoded video picture
   @param y     vertical position of the VBI window's top edge in the decoded video picture
   @param w     width of the VBI window in the decoded video picture, in pixel (0 to disable capture)
   @param h     height of the VBI window in the decoded video picture, in lines (0 to disable capture)
   @param buf   start address of the destination buffer in DRAM
   @param size  size of the destination buffer in DRAM @note 2 bytes per pixel are stored, plus 12 byte header information before each data block
   @return
*/
RMstatus DCCSetupVBICapture(
	struct DCC *pDCC, 
	RMuint32 input, 
	RMuint32 x, 
	RMuint32 y, 
	RMuint32 w, 
	RMuint32 h, 
	RMuint32 buf, 
	RMuint32 size);

/**
   capture raw VBI lines from vertical blank area
   
   @param pDCC
   @param input ModuleID of the input to use
   @param TopVBIOffset          first line in top field where VBI data is expected
   @param TopVBILineEnable      bit mask for lines where VBI data is expected in top field (Bit0: line TopVBIOffset, Bit1: line TopVBIOffset+1, etc., 24 Bits) (0 to disable capture)
   @param BottomVBIOffset       first line in bottom field where VBI data is expected
   @param BottomVBILineEnable   bit mask for lines where VBI data is expected in bottom field (Bit0: line BottomVBIOffset, Bit1: line BottomVBIOffset+1, etc., 24 Bits) (0 to disable capture)
   @param buf   start address of the destination buffer in DRAM
   @param size  size of the destination buffer in DRAM @note 2 bytes per pixel are stored, plus 12 byte header information before each data block
   @return
*/
RMstatus DCCSetupVBICaptureRaw(
	struct DCC *pDCC, 
	RMuint32 input, 
	RMuint32 TopVBIOffset, 
	RMuint32 TopVBILineEnable, 
	RMuint32 BottomVBIOffset, 
	RMuint32 BottomVBILineEnable, 
	RMuint32 buf, 
	RMuint32 size);

/**
   capture sliced VBI data from horizontal blank area (656 only)
   
   @param pDCC
   @param input ModuleID of the input to use
   @param Enable          TRUE enables the capture
   @param ActiveWidth     number of bytes to be captured per line, starting with the first byte after the EAV
   @param ActiveHeight    number of lines (per field) to be captured
   @param YOffsetTop      line number where the cature starts in the top field 
   @param YOffsetBottom   line number where the cature starts in the bottom field
   @param buf   start address of the destination buffer in DRAM
   @param size  size of the destination buffer in DRAM @note 2 bytes per pixel are stored, plus 12 byte header information before each data block
   @return
*/
RMstatus DCCSetupVBICaptureANC(
	struct DCC *pDCC, 
	RMuint32 input, 
	RMbool Enable, 
	RMuint32 ActiveWidth, 
	RMuint32 ActiveHeight, 
	RMuint32 YOffsetTop, 
	RMuint32 YOffsetBottom, 
	RMuint32 buf, 
	RMuint32 size);

/**
   get the next available VBI data buffer from one of the three VBI capture method above
   
   @param pDCC
   @param input ModuleID of the input to use
   @param pFlags
   @param pPTS
   @param pSequenceNumber
   @param pDataSize
   @param pData
   @return
*/
RMstatus DCCGetVBIData(
	struct DCC *pDCC, 
	RMuint32 input, 
	RMuint32 *pFlags, 
	RMuint32 *pPTS, 
	RMuint32 *pSequenceNumber, 
	RMuint32 *pDataSize, 
	RMuint16 **pData);


#define DCC_MAX_MODULE_COUNT 16


enum DCCOutportState {
	DCCOutportState_Disable,
	DCCOutportState_Enable,
	DCCOutportState_Keep,
};

#define DCC_OUTPORT_FLAG_CONSTRAINED 0x1

struct DCCOutportConfig{
	enum DCCOutportState state;
	struct EMhwlibGenericTVFormat format;
	enum DCCRoute route;  /* route HDSD should be removed from the enum */
	RMuint32 flags;
};


struct DCCOutportsConfig{
	struct DCCOutportConfig digital;
	struct DCCOutportConfig analog;
	struct DCCOutportConfig component;
	struct DCCOutportConfig composite;
	RMbool allow_hdsd_on_the_fly;
	RMbool allow_hdsd_buffered;
};

struct DCCOutportInfo{
	RMuint32 source_id;
	/* RMuint32 delay_us; */ /* adding fields is easy, removing them is painful --joe the greek */
};



struct DCCOutportsInfo {
/* 	RMuint32 dramSize; */
	struct DCCOutportInfo digital;
	struct DCCOutportInfo analog;
	struct DCCOutportInfo component;
	struct DCCOutportInfo composite;
};



/**
   Returns the curent state of the outports configuration.

   @param pDCC  
   @param info  
   @return 
*/
RMstatus DCCGetOutports(struct DCC *pDCC, struct DCCOutportsConfig *info);



/**
   Initializes the structure with default values. The default values
   are such that if the init structure is applied to DCCSetOutports,
   the call will have no effect. This function is used to allow
   backward compatibility if the structure gets new members.

   @param pDCC  
   @param config  
   @return 
*/
RMstatus DCCInitOutportsConfigStructure(struct DCC *pDCC,
					struct DCCOutportsConfig *config);

/**
   Allows the application to know before applying a setting which
   modules IDs are required for a given outports configuration.  It
   also gives the dramSize required (HDSD buffered mode for example)
   and the maximum delay between all outports in micro seconds.
   If the configuration is not supported in the hardware, returns RM_NOT_SUPPORTED.
   
   @param pDCC
   @param config
   @param info     
   @return
*/
RMstatus DCCGetOutportsInfo(struct DCC *pDCC, 
			    struct DCCOutportsConfig *config, 
			    struct DCCOutportsInfo *info);


/**
   Applies the outports description into the hardware. If the
   configuration is not supported in the hardware, returns
   RM_NOT_SUPPORTED.
   
   @param pDCC  
   @param config  
   @param info  
   @return
*/
RMstatus DCCSetOutports(struct DCC *pDCC, 
			struct DCCOutportsConfig *config,
			struct DCCOutportsInfo *info);

/**
   @param pDCC  
   @param dram  
   @return 
*/
RMstatus DCCSetMemoryManager(struct DCC *pDCC, RMuint8 dram);

/**
   Sets the rua allocation functions that DCC will use when allocating
   RUA memory.  When alloc_cb or free_cb are NULL the default function
   is respectively RUAMalloc or RUAFree. After DCCOpen, the
   allocations functions are set to their default values.

   @param pDCC  
   @param alloc_cb      
   @param free_cb       
   @return
*/
RMstatus DCCSetMemoryManagerCallbacks(struct DCC *pDCC, DCCAllocFunc alloc_cb, DCCFreeFunc free_cb);

/**
   is used to allocate RUA memory using the same method as DCC does internally.
   
   @param pDCC  
   @param dramIndex     
   @param dramtype      
   @param size  
   @return 
*/
RMuint32 DCCMalloc(struct DCC *pDCC, RMuint32 dramIndex, enum RUADramType dramtype, RMuint32 size); 

/**
   is used to free RUA memory using the same method as DCC does internally.

   @param pDCC  
   @param ptr   
*/
void DCCFree(struct DCC *pDCC, RMuint32 ptr);


/**
  Receive API
*/

struct Receive_type {
	struct RUA			*pRUA;
	RMuint32			targetModule;	// EMHWLIB_TARGET_MODULE(Demux, 0, src)
	RMuint32			buffer_count;
	RMuint32			buffer_size_log2;
	RMuint32			threshold_size;	// hw interrupt comes after writing threshold bytes in fifo
	RMbool				partial_read;	// if TRUE the buffer is completed even it is not full
};

struct ReceiveObject_type {
	struct RUA			*pRUA;
	RMuint32			targetModule;	// EMHWLIB_TARGET_MODULE(Demux, 0, src)
	RMuint32			buffer_count;
	RMuint32			buffer_size_log2;
	RMuint32			threshold_size;	// hw interrupt comes after writing threshold bytes in fifo
	RMbool				partial_read;	// if TRUE the buffer is completed even it is not full

	struct RUABufferPool		*pDMA;
	RMuint32			CachedAddr;
	RMuint32			UncachedAddr;
};

RMstatus DCCOpenReceive			(struct Receive_type *Receive, struct ReceiveObject_type **ppR, struct RUABufferPool **ppDma);
RMstatus DCCCloseReceive		(struct ReceiveObject_type *pR);
RMstatus DCCGetReceiveEvent		(struct ReceiveObject_type *pR, struct RUAEvent* pEvent);
RMstatus DCCResetReceive		(struct ReceiveObject_type *pR);

/**
  STC API
*/

enum DCCStreamType {
	DCC_Stc = 0,
	DCC_Video,
	DCC_Audio
};

struct DCCStcProfile {
	RMuint32 STCID;
	enum Master_type master;
	RMuint32 stc_timer_id;
	RMuint32 stc_time_resolution;
	RMuint32 video_timer_id;
	RMuint32 video_time_resolution;
	RMint32 video_offset;
	RMuint32 audio_timer_id;
	RMuint32 audio_time_resolution;
	RMint32 audio_offset;
};

struct DCCSTCSource;

RMstatus DCCSTCOpen(struct DCC *pDCC, struct DCCStcProfile *stc_profile, struct DCCSTCSource **ppStcSource);
RMstatus DCCSTCClose(struct DCCSTCSource *pStcSource);
RMstatus DCCSTCSetTimeResolution(struct DCCSTCSource *pStcSource, enum DCCStreamType type, RMuint32 time_resolution);
RMstatus DCCSTCGetTimeResolution(struct DCCSTCSource *pStcSource, enum DCCStreamType type, RMuint32 *ptime_resolution);
RMstatus DCCSTCSetVideoOffset(struct DCCSTCSource *pStcSource, RMint32 time, RMuint32 time_resolution);
RMstatus DCCSTCSetAudioOffset(struct DCCSTCSource *pStcSource, RMint32 time, RMuint32 time_resolution);
RMstatus DCCSTCSetTime(struct DCCSTCSource *pStcSource, RMuint64 time, RMuint32 time_resolution);
RMstatus DCCSTCGetTime(struct DCCSTCSource *pStcSource, RMuint64 *ptime, RMuint32 time_resolution);
RMstatus DCCSTCSetSpeed(struct DCCSTCSource *pStcSource, RMint32 numerator, RMuint32 denominator);  // Set STC Speed without correction of audio/video clocks (for trick modes)
RMstatus DCCVCXOSetSpeedAVCorrect(struct DCCSTCSource *pStcSource, RMint32 numerator, RMuint32 denominator);  // Set STC Speed with correction of audio/video clocks (for drift correction)
RMstatus DCCSTCSetSpeedCleanDiv(struct DCCSTCSource *pStcSource, RMint32 numerator, RMuint32 denominator);  // obsolete, calls DCCVCXOSetSpeedAVCorrect
RMstatus DCCSTCSetSpeedVCXO(struct DCCSTCSource *pStcSource, RMint32 numerator, RMuint32 denominator);  // obsolete, calls DCCVCXOSetSpeedAVCorrect
RMstatus DCCSTCGetSpeed(struct DCCSTCSource *pStcSource, RMint32 *pnumerator, RMuint32 *pdenominator);
RMstatus DCCSTCPlay(struct DCCSTCSource *pStcSource);
RMstatus DCCSTCStop(struct DCCSTCSource *pStcSource);
RMstatus DCCSTCSetDiscontinuity(struct DCCSTCSource *pStcSource, RMuint64 time, RMuint32 time_resolution);
RMstatus DCCSTCGetModuleId(struct DCCSTCSource *pStcSource, RMuint32 *stc_id);
RMstatus DCCGetRouteVCXO(enum DCCRoute route, RMuint32 *vcxo);

struct DCCXVideoProfile {
	/* parameters common for video and subpicture */
	RMuint32 MpegEngineID;
	RMuint32 STCID;
	RMuint32 XtaskID;
	RMuint32 XtaskInbandFIFOCount;
	
	/* parameters for video decoder */
	RMuint32 VideoDecoderID;
	RMuint32 ProtectedFlags;
	RMuint32 BitstreamFIFOSize;
	RMuint32 XferFIFOCount;
	RMuint32 PtsFIFOCount;
	RMuint32 InbandFIFOCount;

	/* parameters replacing for the enum MPEG_Profile*/
	enum EMhwlibVideoCodec Codec;
	RMuint32 Profile;
	RMuint32 Level;
	RMuint32 ExtraPictureBufferCount;
	RMuint32 MaxWidth;
	RMuint32 MaxHeight;
	
	/* parameters for subpicture - SPUDecoderID is 0 */
	RMuint32 SPUProtectedFlags;
	RMuint32 SPUBitstreamFIFOSize;
	RMuint32 SPUXferFIFOCount;
	RMuint32 SPUPtsFIFOCount;
	RMuint32 SPUInbandFIFOCount;
	
	enum EMhwlibVideoCodec SPUCodec;
	RMuint32 SPUProfile;
	RMuint32 SPULevel;
	RMuint32 SPUExtraPictureBufferCount;
	RMuint32 SPUMaxWidth;
	RMuint32 SPUMaxHeight;
};

RMstatus DCCXSetVideoDecoderSourceCodec(struct DCCVideoSource *pVideoSource, enum EMhwlibVideoCodec Codec);
RMstatus DCCXOpenVideoDecoderSource(struct DCC *pDCC, struct DCCXVideoProfile *dcc_profile, struct DCCVideoSource **ppVideoSource);
RMstatus DCCXGetBtsFIFO(struct DCCVideoSource *pVideoSource, RMuint32 *BtsFIFO); 

struct DCCDemuxTaskProfile {
	RMuint32 ProtectedFlags;
	RMuint32 BitstreamFIFOSize;
 	RMuint32 XferFIFOCount;
 	RMuint32 InbandFIFOCount;
	
 	RMuint32 InputPort;
 	RMuint32 PrimaryMPM;
 	RMuint32 SecondaryMPM;

	RMuint32 DemuxTaskID;
};
struct DCCDemuxTask;
RMstatus DCCOpenDemuxTask(struct DCC *pDCC, struct DCCDemuxTaskProfile *dcc_profile, struct DCCDemuxTask **ppDemuxTask);
RMstatus DCCCloseDemuxTask(struct DCCDemuxTask *pDemuxTask);
RMstatus DCCGetDemuxTaskInfo(struct DCCDemuxTask *pDemuxTask, RMuint32 *demux_task);
RMstatus DCCPlayDemuxTask(struct DCCDemuxTask *pDemuxTask);
RMstatus DCCStopDemuxTask(struct DCCDemuxTask *pDemuxTask);
RMstatus DCCPauseDemuxTask(struct DCCDemuxTask *pDemuxTask);



#define MAX_AUDIO_DECODER_INSTANCES 4

struct DCCMultipleAudioSource;

struct DCCAudioSourceHandle {
	struct DCCAudioSource *pAudioSource;
	RMuint32 moduleID;
	RMuint32 engineID;
};

RMstatus DCCOpenMultipleAudioDecoderSource(struct DCC *pDCC, struct DCCAudioProfile profiles[], RMuint32 profiles_count, struct DCCMultipleAudioSource **ppMultipleAudioSource);
RMstatus DCCCloseMultipleAudioSource(struct DCCMultipleAudioSource *pMultipleAudioSource);

RMstatus DCCMultipleAudioSourceGetNumberOfInstances(struct DCCMultipleAudioSource *pMultipleAudioSource, RMuint32 *instances);
RMstatus DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(struct DCCMultipleAudioSource *pMultipleAudioSource, RMuint32 instance, struct DCCAudioSourceHandle *pSingleAudioSourceHandle);

RMstatus DCCPlayMultipleAudioSource(struct DCCMultipleAudioSource *pMultipleAudioSource);
RMstatus DCCStopMultipleAudioSource(struct DCCMultipleAudioSource *pMultipleAudioSource);
RMstatus DCCPauseMultipleAudioSource(struct DCCMultipleAudioSource *pMultipleAudioSource);

// for all channels
RMstatus DCCSetMultipleAudioSourceVolume(struct DCCMultipleAudioSource *pMultipleAudioSource, RMuint32 volume);

RMstatus DCCSetMultipleAudioBtsThreshold(struct DCCMultipleAudioSource *pMultipleAudioSource, RMuint32 level);

RMstatus DCCMultipleAudioSendData(struct DCCMultipleAudioSource *pMultipleAudioSource,
				  struct RUABufferPool *pBufferPool, 
				  RMuint8 *pData, 
				  RMuint32 DataSize, 
				  void *pInfo, 
				  RMuint32 InfoSize,
				  RMint32 *lastOKInstance);




RM_EXTERN_C_BLOCKEND

#endif // __DCC_H__
