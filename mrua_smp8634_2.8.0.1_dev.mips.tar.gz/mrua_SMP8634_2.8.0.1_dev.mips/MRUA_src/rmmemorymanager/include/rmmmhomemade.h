/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmmm-details.h
  @brief  

  Use of the self-contained rmmm.c allows more
  features than rmdef/rmmm.h, described by this header file:

  @author Emmanuel Michon
  @date   2003-02-11
*/

#ifndef __RMMMHOMEMADE_H__
#define __RMMMHOMEMADE_H__

#include "../../rmdef/rmdef.h"

#ifdef MMGBUS
#include "../../llad/include/gbus.h"
#define MOD(x) Remote_##x
#else
#define MOD(x) x
#endif // MMGBUS

RM_EXTERN_C_BLOCKSTART

/*
  rmmemorymanager defines a convenient memory manager; inside 
  a big area called Zone you can can malloc/free-like functions.

  It replaces the operating system libc calls malloc and free.

  Advantages:
  - Each Zone can be set to return aligned data according to RMalignment choices.
  - RMFreeInZone has a valid return code, and detects bogus RMFreeInZone calls.

  Defects:
  - does not implement something like realloc.
  - memory can get really sparse when stressed with chosen catastrophic
  scenarios.

  Performances:
  Running testmemorymanager (Zone is 1MB, one thread calls RMMallocInZone
  with size = random amount of memory in [0,4KB[ and the other thread
  calls RMFreeInZone with random address in Zone) during 72 hours gives
  the following breakdown in cases:
  0       EMPTYFREELIST
  0.05%   BEFOREFIRSTNEIGHBOR
  0.1%    BEFOREFIRST
  17.0%   MIDDLEBOTH
  32.0%   MIDDLELEFT
  31.9%   MIDDLERIGHT
  18.9%   MIDDLEBOTH
  0.0002% AFTERLAST

  @author Vincent Trinh (see sdmalloc.c), Emmanuel Michon
  @date   2001-03-02
*/

struct mz;


struct memory_block {
	void *address;
	RMuint32 size;
};

/// 
/**
   RMCreateZone creates a Zone suitable for dynamic allocation operations.

   (RMCreateZone does not call RMMalloc_avoid_this_function by itself, 
   you have to give him an already allocated piece of memory, statically 
   or dynamically.)

   The pointers returned by RMMallocInZone are aligned according to
   the alignment parameter.

   RMPanic(RM_ERRORINVALIDPOINTER) if input buffer is NULL

   @param mac (Memory ACcess --- some cookie to access the memory.
               not needed (say NULL) when using regular version
	       typically set to a gbus pointer on mambo)
   @param al    
   @param pSubmittedBuffer      
   @param submittedSize	
*/
RM_LIBRARY_IMPORT_EXPORT struct mz *MOD(RMCreateZone)(void *mac,
						      RMalignment al,
						      RMuint8 *pSubmittedBuffer,
						      RMuint32 submittedSize);


#ifdef WITH_THREADS
void mzlock(void *mac,void *cookie);
void mzunlock(void *mac,void *cookie);

/// 
/**
   The memory manager will run thread-unsafe until you RMMallocInZone
   a non-NULL cookie to be used by mzlock() and mzunlock() above.
   
   @param mac   
   @param pZ 
   @param cookie        
   @return 
*/
RM_LIBRARY_IMPORT_EXPORT void MOD(RMSetSyncCookie)(void *mac,struct mz *pZ,void *cookie);

/// 
/**
   Needed to destroy the critical section.
   Once the destruction is done, you should RMSetSyncCookie(pZ,0)

   @param mac   
   @param pZ 
*/
RM_LIBRARY_IMPORT_EXPORT void *MOD(RMGetSyncCookie)(void *mac,struct mz *pZ);
#endif // WITH_THREADS

/// 
/**
   If all the allocations made in pZ have been freed,
   RMDeleteZone can be fullfilled.

   @param mac   
   @param pZ 
   @return RM_OK on success, RM_ERRORMEMORYISNOTFREE on failure
*/
RM_LIBRARY_IMPORT_EXPORT RMstatus MOD(RMDeleteZone)(void *mac,struct mz *pZ);

/// 
/**
   Returns a pointer to a free block of memory of size size.

   The pointers returned by RMMalloc are aligned according to
   the al parameter.

   Do not waste memory using this function to allocate very
   small amount of data since the implementation has a 
   ``header overhead'' of 16 bytes (and maybe lost alignment bytes).

   The submittedSize cannot be zero for obvious reasons. In this
   case RMPanic(FATALASKEDZEROSIZEMALLOC) happens.

   It is useless to test the return value of RMMalloc for nullity:
   On error (including: full memory) it calls RMPanic(RM_FATALOUTOFMEMORY).
   This differs from usual malloc() that returns NULL on full
   memory. 

   @param mac   
   @param pZ 
   @param submittedSize 
   @return the expected pointer on success.
*/
RM_LIBRARY_IMPORT_EXPORT void *MOD(RMMallocInZone)(void *mac,struct mz *pZ,RMuint32 size);

/// 
/**
   RMCalloc is intented for arrays and memory is filled
   with zeroes.

   See RMMalloc.

   @param mac   
   @param pZ 
   @param nmemb
   @param size  
   @return the expected pointer on success.
*/
RM_LIBRARY_IMPORT_EXPORT void *MOD(RMCallocInZone)(void *mac,struct mz *pZ,RMuint32 nmemb,RMuint32 size);

/// 
/**
   Frees memory pointed to by ptr.

   Unlike most free() implementation, this function will
   call RMPanic(RM_FATALINVALIDPOINTER) when trying to 
   free an invalid pointer or freeing twice.

   @param mac   
   @param pZ 
   @param ptr   
*/
RM_LIBRARY_IMPORT_EXPORT void MOD(RMFreeInZone)(void *mac,struct mz *pZ,void *ptr);

/**
   Returns the size of the previously allocated area pointed to by ptr.

   this function will call RMPanic(RM_FATALINVALIDPOINTER) when trying
   to get the size of  an invalid pointer.

   @param mac   
   @param pZ 
   @param ptr   
*/
RM_LIBRARY_IMPORT_EXPORT RMuint32 MOD(RMGetAreaSize)(void *mac,struct mz *pZ,void *ptr);

/// 
/**
   Gets some parameters from the memory manager for monitoring

   Any of pSuccessfulMallocs, pSuccessfulFrees, pOccupiedSize, pMaxSize can
   be set to NULL if the caller does not care about some stats.

   @param mac   
   @param pZ 
   @param pSuccessfulMallocs: number of successful RMMalloc() since creation (only increases)   
   @param pSuccessfulFrees: number of successful RMFree() since creation (only increases)
   @param pOccupiedSize: sum of all the bytes used to store data 
   @param pMaxSize: max of *pOccupiedSize since creation (only increases)
*/
RM_LIBRARY_IMPORT_EXPORT void MOD(RMGetZoneStats)(void *mac,
						  struct mz *pZ,
						  RMuint32 *pSuccessfulMallocs,
						  RMuint32 *pSuccessfulFrees,
						  RMint32 *pOccupiedSize,
						  RMint32 *pMaxSize);

/// 
/**
   This function is a facility to debug memory leaks.

   It just prints out the (address,size) list of the 
   malloc'ed blocks in memory.

   @param mac   
   @param pZ 
*/
RM_LIBRARY_IMPORT_EXPORT void MOD(RMDumpMallocedBlocksInZone)(void *mac,struct mz *pZ,struct memory_block *mb, RMint32 *count);

RM_LIBRARY_IMPORT_EXPORT void *MOD(RMMemsetInZone)(void *mac,struct mz *pZ,void *s, RMuint8 c, RMuint32 n);
RM_LIBRARY_IMPORT_EXPORT void *MOD(RMMemcpyInZone)(void *mac,struct mz *pZ,void *dest,const void *src,RMuint32 n);
RM_LIBRARY_IMPORT_EXPORT RMint32 MOD(RMMemcmpInZone)(void *mac,struct mz *pZ,const void *s1, const void *s2,RMuint32 n);

RM_EXTERN_C_BLOCKEND

#endif // __RMMMHOMEMADE_H__
