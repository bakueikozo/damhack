/*****************************************
 Copyright  2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#ifndef ALLOW_OS_CODE
#define ALLOW_OS_CODE
#endif
#include "../include/rmlibcw.h"

#include <stdlib.h>
#include <sys/time.h>

RMreal RMRandom(void) 
{
	static RMbool firstTimeHere=TRUE;
	double uniformlaw;

	// notice: this function as is is not reentrant.
	if (firstTimeHere) {
		struct timeval now;

		firstTimeHere=FALSE;
		gettimeofday(&now,NULL);
		srand(now.tv_usec);
	}

	uniformlaw=(RMreal)rand()/((RMreal)RAND_MAX+1.0);

	return (RMreal)(uniformlaw);
}

RMuint32 RMIntRandom(RMuint32 max)
{
	return RMRandom()*(RMreal)max;
}
