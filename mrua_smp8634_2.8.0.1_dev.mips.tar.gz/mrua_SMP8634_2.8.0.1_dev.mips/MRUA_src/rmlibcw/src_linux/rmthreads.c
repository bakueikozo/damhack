/*****************************************
 Copyright  2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#ifndef ALLOW_OS_CODE
#define ALLOW_OS_CODE
#endif
#include "../include/rmlibcw.h"
#include "rmcore/include/rmcore.h"
#ifndef PTHREADS_PRIORITY
#include <sys/time.h>
#include <sys/resource.h>
#endif

#if 0
  #define THDBG DISABLE
#else
  #define THDBG ENABLE
#endif

// _NP below means Non Posix. This code uses GNU features (recursive mutex)
#if (RMCOMPILERID==RMCOMPILERID_GCC) 
#define _GNU_SOURCE
#elif (RMCOMPILERID==RMCOMPILERID_ARMELF_GCC)
#define __USE_GNU
#endif // RMCOMPILERID

#include <pthread.h>
#include <semaphore.h>

#include "robust.h"

#include <stdlib.h>
#include <signal.h>
#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>

/* cannot include string.h */
int strlen(const char *s);

typedef struct {
	RMfunc sr;
	void *arg;
	RMascii *name;
	const RMascii *userName;
#ifndef PTHREADS_PRIORITY
	int priority;		
#endif
	// we may add other fields as time goes by.
} registeredThread;

typedef struct {
	pthread_t tid;
} _RMthread;

static pthread_key_t key;
static RMbool rmthreads_initialized=FALSE;
static sem_t sonisalive;
static char main_name[20] = "Main thread";
pthread_once_t key_once = PTHREAD_ONCE_INIT;

static void registeredThread_destroy(void *p)
{
	registeredThread *rTh = (registeredThread*)p;
	
	if(rTh != (registeredThread *)NULL){
		if(rTh->name != (RMascii*)NULL){
			RMFreeAscii((RMascii*)rTh->name);
			rTh->name = (RMascii*)NULL;
		}
		RMFree(rTh);	
		rTh = (registeredThread *)NULL;
	}
}

static void key_alloc()
{
	pthread_key_create(&key, registeredThread_destroy);
}

static void *slave_init_code(void *p)
{
	registeredThread *rTh = (registeredThread*)p;

	// we assume here the max value of a pid is 65535: on 5 characters.
	rTh->name = RMMalloc(strlen(rTh->userName)+1+1+5+1);
	RMPrintAscii(rTh->name,"%s(%d)",rTh->userName, getpid());

	pthread_once(&key_once, key_alloc);

	if(robust_pthread_setspecific(key, rTh)) {
		perror("Error pthread_setspecific");
		RMPanic(RM_FATALCREATETHREAD);
	}

	RMDBGLOG((THDBG,"I am a new thread #%08lx (pid %d)\n",(RMuint32) pthread_self(), getpid()));

	robust_sem_post(&sonisalive);
	RMDBGLOG((ENABLE, "posted semaphore\n"));

#ifndef PTHREADS_PRIORITY		
	if (rTh->priority)
		setpriority(PRIO_PROCESS, 0, rTh->priority);
#endif

	(* rTh->sr) (rTh->arg);

	rTh = (registeredThread*)robust_pthread_getspecific(key);
	
	return NULL;
}

RMthread RMCreateThread(const RMascii *name, RMfunc StartAddress, void * Parameter)
{
	return RMCreateThreadWithPriority(name, StartAddress, Parameter, 0);
}


RMthread RMCreateThreadWithPriority(const RMascii *name, RMfunc StartAddress, void * Parameter, int priorityDelta)
{
	pthread_t tid;
	registeredThread *rTh;
	int rc = 0;

	if (!rmthreads_initialized) {
		robust_sem_init(&sonisalive,0,0);		
		rmthreads_initialized=TRUE;
		
	}
	rTh = RMMalloc(sizeof(registeredThread));
	rTh->sr = StartAddress;
	rTh->arg = Parameter;
	rTh->userName = name;
	rTh->name = (RMascii*)NULL;

	if (priorityDelta)
	{
#ifdef PTHREADS_PRIORITY		
		pthread_attr_t attr;
		struct sched_param param = {0,};
		int priority = 50 + priorityDelta;

		RMDBGLOG((ENABLE, "create thread %s with PTHREADS priority %d (min=%d, max=%d)\n", (char*)name, priority, sched_get_priority_min(SCHED_RR), sched_get_priority_max(SCHED_RR)));

		rc = pthread_attr_init(&attr);
		RMDBGLOG((ENABLE, "pthread_attr_init returned %ld\n", rc));
	
		rc = pthread_attr_setinheritsched(&attr, PTHREAD_EXPLICIT_SCHED);
		RMDBGLOG((ENABLE, "pthread_attr_setinheritsched returned %ld\n", rc));
	
		rc = pthread_attr_setschedpolicy(&attr, SCHED_RR);
		RMDBGLOG((ENABLE, "pthread_attr_setschedpolicy returned %ld\n", rc));
	
		param.sched_priority = priority;
		rc = pthread_attr_setschedparam(&attr, &param);
		RMDBGLOG((ENABLE, "pthread_attr_setschedparam returned %ld\n", rc));
	
		rc = pthread_create(&tid, &attr, slave_init_code, rTh);
#else
		RMASSERT((priorityDelta >= -19) && (priorityDelta <=20));
		RMDBGLOG((ENABLE, "create thread %s with PROCESS priority %d (min=%d, max=%d\n", (char*)name, -priorityDelta, 19, -20));
		
		rTh->priority = -priorityDelta;
		rc = pthread_create(&tid, NULL, slave_init_code, rTh);
#endif
	}
	else
	{
		RMDBGLOG((ENABLE, "create thread %s with default priority\n", (char*)name));
		
#ifndef PTHREADS_PRIORITY
		rTh->priority = 0;
#endif
		rc = pthread_create(&tid, NULL, slave_init_code, rTh);
	}
	
	if (rc) {
		perror("Error rmthread");
		RMPanic(RM_FATALCREATETHREAD);
	}
	
	RMDBGLOG((ENABLE, "waiting for my son...\n"));
	robust_sem_wait(&sonisalive);

	RMDBGLOG((THDBG,"Father started new son #%08lx:\"%s\" at (%p,%p)\n",(RMuint32)tid, (char *)name, StartAddress, Parameter));

	return (RMthread)tid;
}


RMthread RMGetCurrentThread(void)
{
	return (RMthread) pthread_self();
}

const RMascii *RMGetCurrentThreadName(void)
{
	registeredThread *rTh;

	errno = 0;
	rTh = (registeredThread*)robust_pthread_getspecific(key);
	
	if( !rmthreads_initialized ||
	   (rTh == (registeredThread *)NULL)){
		return (const RMascii *)main_name;
	}

	return (const RMascii *) rTh->name;
}

void RMWaitForThreadToFinish(RMthread hThread)
{
	RMDBGLOG((THDBG,"Thread waiting for #%08lx to finish\n",hThread /*,(char *)reg->name*/));
	
	pthread_join((pthread_t)hThread,NULL);
}

void cancelallotherthreads(void);

void cancelallotherthreads(void)
{
}
