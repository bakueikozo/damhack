#ifndef ALLOW_OS_CODE
#define ALLOW_OS_CODE
#endif
#include "../include/rmlibcw.h"
#include <stdlib.h>
#include <unistd.h>

void RMexit_avoid_this_function(RMstatus reason);

void RMexit_avoid_this_function(RMstatus reason)
{
        exit(reason);
}
