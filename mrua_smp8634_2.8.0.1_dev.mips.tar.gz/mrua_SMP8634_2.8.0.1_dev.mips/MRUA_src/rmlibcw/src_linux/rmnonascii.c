/*****************************************
 Copyright  2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#ifndef ALLOW_OS_CODE
#define ALLOW_OS_CODE
#endif
#include "../include/rmlibcw.h"
#include <string.h>

/* We do not support unicode characters on Linux. 
 * Furthermore, we know that the types RMascii and RMnonAscii are compatible
 * and (almost, that is, to the exception of signed-ness) interchangeable.
 */

RMnonAscii *RMnonAsciiFromAscii (const RMascii *string)
{
	RMascii *x;

	x=RMMalloc(strlen(string)+1);
	strcpy(x,string);

	return (RMnonAscii *)x;
}

void RMFreeNonAscii (RMnonAscii *string)
{
	RMFree (string);
}

RMnonAscii *RMMallocAndDuplicateNonAscii (const RMnonAscii *s)
{
	const RMascii *string = (const RMascii *)s;
	RMascii *x;

	x=RMMalloc(strlen(string)+1);
	strcpy(x,string);

	return (RMnonAscii *)x;
}

RMuint32 RMnonAsciiLength (const RMnonAscii *string)
{
	return strlen((RMascii *)string)+1;
}

RMascii *RMnonAsciiToAscii (const RMnonAscii *s)
{
	const RMascii *string = (const RMascii *)s;
	RMascii *x;

	x=RMMalloc(strlen(string)+1);
	strcpy(x,string);

	return x;
}
