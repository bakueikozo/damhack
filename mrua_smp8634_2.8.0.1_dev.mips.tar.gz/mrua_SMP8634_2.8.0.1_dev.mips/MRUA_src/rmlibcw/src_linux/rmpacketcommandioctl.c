/*****************************************
 Copyright  2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#ifndef ALLOW_OS_CODE
#define ALLOW_OS_CODE
#endif
#include "../../rmlibcw/include/rmlibcw.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/cdrom.h>
#include <stdio.h>

		
#if ((EM86XX_CHIP==EM86XX_CHIPID_TANGO2) && (EM86XX_MODE==EM86XX_MODEID_STANDALONE))
#define IOCTL_ENABLE_DMA            //for UDF user library 
#endif

void *RMOpenPacketCommand(const RMnonAscii *naname)
{
	int fd=0;
	/* on the linux platform, we KNOW that RMnonAscii and RMascii
	 * are compatible (except for signedness) */
	fd = open((RMascii *)naname,O_RDONLY|O_NONBLOCK);
	if (fd < 0) {
		perror("Error opening device");
		RMDBGLOG ((ENABLE, "fail to open device:%s: fd=%ld...\n",naname,fd));
		return NULL;
	} else {
		return (void *)fd;
	}
}

void RMClosePacketCommand(void *handle)
{
	close((int)handle);
}

RMint32 RMIoctlPacketCommand(void *handle,RMpacketCommand *pP)
{
	struct cdrom_generic_command command;
	struct request_sense sense;
	int rc;
	
	RMMemset(&command,0,sizeof(struct cdrom_generic_command));
	RMMemset(&sense,0,sizeof(struct request_sense));
	
	RMMemcpy(&command.cmd,&pP->cmd,sizeof(command.cmd));
	command.buffer = pP->buffer;
	command.buflen = pP->buflen;
	command.sense = &sense;
	command.data_direction = pP->packetDataDirection;

#ifdef  IOCTL_ENABLE_DMA	// on PC do_dma is not defined
	if (command.cmd[0] == 0x28)
	{
		command.do_dma = 1;
	}
#endif

#if (EM86XX_MODE == EM86XX_MODEID_WITHHOST)
	if ( (command.cmd[0] == 0x43) && ((command.cmd[2] & 0x7) == 0) ) {	// TOC read
		int i;
		struct cdrom_tocentry tocentry;
		struct cdrom_tochdr tochdr;
		RMuint8 *pByte;
		RMuint32 len = 0;

		rc = ioctl((int)handle,CDROMREADTOCHDR,(void *)&tochdr);
		if (rc < 0) {
			RMDBGLOG ((ENABLE, "CDROM_READ_TOC_HDR error\n"));
			return rc;
		}
		
		if ( (command.buffer == NULL) || (pP->buflen < (unsigned int)(4+8+8*(tochdr.cdth_trk1+1-tochdr.cdth_trk0))) ) {
			RMDBGLOG ((ENABLE, "TOC buffer NULL or too small = 0x%lx size=0x%lx\n",  pP->buffer, pP->buflen));
			return -1;
		}

		pByte = command.buffer;
		*(pByte+2) = tochdr.cdth_trk0;						// first track number
		*(pByte+3) = tochdr.cdth_trk1;						// last track number
		len += 2;
		pByte += 4;
		for (i = RMmax(tochdr.cdth_trk0, command.cmd[6]); i < (tochdr.cdth_trk1+1); i++) {
			tocentry.cdte_track = i;
			tocentry.cdte_format = CDROM_LBA;
			rc = ioctl((int)handle,CDROMREADTOCENTRY,(void *)&tocentry);
			if (rc < 0) {
				RMDBGLOG ((ENABLE, "CDROM_READ_TOC_ENTRY %ld error\n", i));
				return rc;
			}
			*(pByte+0) = 0;							// reserved
			*(pByte+1) = (tocentry.cdte_adr << 4) | tocentry.cdte_ctrl;	// ADR | Control
			*(pByte+2) = i;							// track number
			*(pByte+3) = 0;							// reserved
			*(pByte+4) = (tocentry.cdte_addr.lba >> 24) & 0xff;
			*(pByte+5) = (tocentry.cdte_addr.lba >> 16) & 0xff;
			*(pByte+6) = (tocentry.cdte_addr.lba >>  8) & 0xff;
			*(pByte+7) = tocentry.cdte_addr.lba & 0xff;
			pByte += 8;
			len += 8;
		}
		tocentry.cdte_track = 0xAA;
		tocentry.cdte_format = CDROM_LBA;
		rc = ioctl((int)handle,CDROMREADTOCENTRY,(void *)&tocentry);
		if (rc < 0)
			RMDBGLOG ((ENABLE, "CDROMREADTOCENTRY error\n"));
		*(pByte+0) = 0;								// reserved
		*(pByte+1) = (tocentry.cdte_adr << 4) | tocentry.cdte_ctrl;		// ADR | Control
		*(pByte+2) = 0xAA;							// track number
		*(pByte+3) = 0;								// reserved
		*(pByte+4) = (tocentry.cdte_addr.lba >> 24) & 0xff;
		*(pByte+5) = (tocentry.cdte_addr.lba >> 16) & 0xff;
		*(pByte+6) = (tocentry.cdte_addr.lba >>  8) & 0xff;
		*(pByte+7) = tocentry.cdte_addr.lba & 0xff;
		len += 8;
		pByte = command.buffer;
		*pByte = (len >> 8) & 0xff;						// TOC data lenght
		*(pByte+1) = len & 0xff;						// TOC data lenght
	}
	else
#endif // EM86XX_MODE = ...
		rc = ioctl((int)handle,CDROM_SEND_PACKET,(void *)&command);

	if (rc < 0) {
		RMDBGLOG ((ENABLE, "Ioctl Packet Command fail = %d, sense_key = %d, asc = %d, ascq = %d\n",
			command.stat, sense.sense_key, sense.asc, sense.ascq));
		pP->packetError.senseKey = sense.sense_key;
		pP->packetError.asc = sense.asc;
		pP->packetError.ascq = sense.ascq;
	}
	return rc;
}
