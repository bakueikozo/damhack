/*****************************************
 Copyright (c) 2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#ifndef ALLOW_OS_CODE
#define ALLOW_OS_CODE
#endif
#include "../include/rmlibcw.h"

#include <string.h>


int RMMatchAscii(RMascii *str1, RMascii *str2)
{
	return strcmp(str1,str2);
}

int RMMatchNAscii(RMascii *str1, RMascii *str2, RMuint32 size)
{
	return strncmp(str1,str2,size);
}

