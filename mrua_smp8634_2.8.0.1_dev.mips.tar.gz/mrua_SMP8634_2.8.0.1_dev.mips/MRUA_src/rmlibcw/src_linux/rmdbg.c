/*****************************************
 Copyright � 2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE
#include "../include/rmlibcw.h"

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>

#define DBG_MAX_STRING 2048

void RMDBGLOG_implementation(RMbool active,const RMascii *filename,RMint32 line,const RMascii *text,...)
{  
        if (active) {
		va_list ap;
		char str[DBG_MAX_STRING];
		
#ifdef WITH_THREADS
                snprintf((char *)str,
			 DBG_MAX_STRING,
			 "["F64U":%s:%s:%ld] ",
			 RMGetTimeInMicroSeconds(),
			 (char *)RMGetCurrentThreadName(),
			 (char *)filename,
			 line);
#else  
		snprintf((char *)str,
			 DBG_MAX_STRING,
			 "["F64U":%s:%ld] ",
			 RMGetTimeInMicroSeconds(),
			 (char *)filename,
			 line);
#endif // WITH_THREADS
		
                va_start(ap, text);
                vsnprintf((char *)(str+strlen(str)), DBG_MAX_STRING-strlen(str), text, ap); 
                va_end(ap);
                
		fprintf(stderr,str);
		
        }
}

void RMDBGPRINT_implementation(RMbool active,const RMascii *filename,RMint32 line,const RMascii *text,...)
{
        if (active) {
		va_list ap;
		char str[DBG_MAX_STRING];
		
                va_start(ap, text);
                vsnprintf((char *)str,DBG_MAX_STRING,text,ap); 
                va_end(ap);
                
               	fprintf(stderr,str);
        }
}
