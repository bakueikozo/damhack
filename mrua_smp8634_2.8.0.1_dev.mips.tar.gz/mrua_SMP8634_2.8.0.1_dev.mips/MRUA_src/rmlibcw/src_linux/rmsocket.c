/*****************************************
 Copyright  2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define RM_LIBRARY_SELF_COMPILING 1

#ifndef ALLOW_OS_CODE
#define ALLOW_OS_CODE
#endif
#include "../include/rmlibcw.h"

#include <sys/time.h>
#include <unistd.h>

#include "noforksockhelp.h"
#include <netinet/in.h>

#include <netinet/ip_icmp.h>
#if !defined(ICMP_FILTER)
/*  XXX swiped from 2.2.5-8 <linux/icmp.h> */
#define	ICMP_FILTER	1
struct icmp_filter {
	u_int32_t	data;
};

#endif
#if 1
  #define RMSOCKETDBG DISABLE
#else
  #define RMSOCKETDBG ENABLE
#endif

typedef struct
{
	int s;
}_RMsocket;

RMbool Ping(RMascii *hostAddr);
int checksum(u_short *addr, int len);

RMsocket RMSocketOpenStream(const RMascii *ip, RMuint16 port)
{ 
	int bufSize = 1024*1024*4;

	RMsocket answer=(RMsocket)make_connection(port,SOCK_STREAM,(char *)ip);
	
	RMDBGLOG((RMSOCKETDBG,
		  "RMSocketOpenStream (acting as TCP client): returning #%d\n",
		  answer));
	
	if(answer != (RMsocket)-1){
		if(setsockopt((int) answer,  SOL_SOCKET, SO_RCVBUF, (void*)&bufSize, sizeof(bufSize)) < 0)
			RMDBGLOG((ENABLE,"Can't change system network size (wanted size = %d) \n", bufSize));		
	}
	else
		answer = 0;

	return answer;
}

RMsocket RMSocketOpenStreamWithTimeout(const RMascii *ip, RMuint16 port, RMuint32 connect_timeout)
{ 
	int bufSize = 1024*1024*4;

	RMsocket answer=(RMsocket)make_connection_WithTimeout(port,SOCK_STREAM,(char *)ip, (int)connect_timeout);
	
	RMDBGLOG((RMSOCKETDBG,
		  "RMSocketOpenStream (acting as TCP client): returning #%d\n",
		  answer));
	
	if(answer != (RMsocket)-1){
		if(setsockopt((int) answer,  SOL_SOCKET, SO_RCVBUF, (void*)&bufSize, sizeof(bufSize)) < 0)
			RMDBGLOG((ENABLE,"Can't change system network size (wanted size = %d) \n", bufSize));		
	}
	else
		answer = 0;

	return answer;
}

RMsocket RMSocketOpenDgram(const RMascii *ip, RMuint16 port)
{
	int bufSize = 1024*1024*4;
	int newBufSize;
	int sizeofBufSize;

	RMsocket answer=(RMsocket)get_connection(SOCK_DGRAM,port, (char*)ip);

	RMDBGLOG((RMSOCKETDBG,
		  "RMSocketDgram (acting as UDP server): returning #%d\n",
		  answer));

	if(setsockopt((int) answer,  SOL_SOCKET, SO_RCVBUF, (void*)&bufSize, sizeof(bufSize)) < 0)
		RMDBGLOG((ENABLE,"Can't change system network size (wanted size = %d) \n", bufSize));

	getsockopt((int) answer,  SOL_SOCKET, SO_RCVBUF, (void*)&newBufSize, (void *)&sizeofBufSize);
	if (newBufSize != bufSize)
		RMDBGLOG((ENABLE, "buffer size is %lu, wanted was %lu\n", newBufSize, bufSize));


	if(answer == (RMsocket)-1)
		answer = 0;

	return answer;
}

RMint16 RMSocketSelect(RMsocket *tabSocket, 
		       RMuint8 nbEltInTabSocket, 
		       RMuint32 nbMicroSecondsTimeOut, 
		       RMsocket *tabSocketRes)
{
	fd_set tabSocketToWait;
	RMint16 res;
	int biggestfd=0;
	struct timeval timeout;
	int i,j;
	
	if(
	   (tabSocket==NULL)
	   ||
	   (tabSocketRes==NULL)
	   )
		RMPanic(RM_FATALSOCKET);
	
	FD_ZERO(&tabSocketToWait);

	for(i=0;i<nbEltInTabSocket;i++) 
	{
		if ((int)(tabSocket[i])>biggestfd) 
			biggestfd=(int)(tabSocket[i]);
		
		FD_SET((int)(tabSocket[i]),&tabSocketToWait);
	}

	errno = 0;
	while(1)
	{
		if (nbMicroSecondsTimeOut!=0) {
			timeout.tv_sec = nbMicroSecondsTimeOut/1000000;
			timeout.tv_usec = nbMicroSecondsTimeOut%1000000;
			res = (RMint16)select(biggestfd+1, &tabSocketToWait, (fd_set *)0, (fd_set *)0, &timeout);
		}
		else {
			timeout.tv_sec = 0;
			timeout.tv_usec = 0;
			res = (RMint16)select(biggestfd+1, &tabSocketToWait, (fd_set *)0, (fd_set *)0, &timeout);
		}

		if(!((res==-1)&&(errno==EINTR))) break;
	}
	
	if (res) {
		j=0;
		for(i=0;i<nbEltInTabSocket;i++) {
			if(FD_ISSET((int)(tabSocket[i]),&tabSocketToWait)) {
				tabSocketRes[j] = tabSocket[i];
				j++;
			}
		}
	}

	if (res==-1) RMDBGLOG((RMSOCKETDBG,"RMSocketSelect on %d sockets: failed\n",nbEltInTabSocket)); 
	if (res==0) RMDBGLOG((RMSOCKETDBG,"RMSocketSelect on %d sockets: %dusec timeout expired\n",nbEltInTabSocket,nbMicroSecondsTimeOut)); 
	if (res==1) RMDBGLOG((RMSOCKETDBG,"RMSocketSelect on %d sockets: data ready on #%d\n",nbEltInTabSocket,tabSocketRes[0])); 
	if (res>1) RMDBGLOG((RMSOCKETDBG,"RMSocketSelect on %d sockets: data ready on multiple sockets\n",nbEltInTabSocket)); 
	
	return res;
}

RMstatus RMSocketSend(RMsocket sock, RMuint8 * request, RMuint32 sizeOFRequest)
{
	int flags;
	int res;
	RMstatus answer;

	flags = 0;

	res= send((int)sock,request,sizeOFRequest,flags);

	if (res==(int)sizeOFRequest)
		answer=RM_OK;
	else
		answer=RM_ERROR;

	RMDBGLOG((RMSOCKETDBG,
		  "RMSocketSend on #%d: sending %d bytes %s\n",
		  sock,
		  sizeOFRequest,
		  (answer==RM_OK)?"ok":"failed"));
	
	return answer;
}

RMstatus RMSocketSendto(RMsocket sock, RMuint8 * request, RMuint32 sizeOFRequest, const RMascii *ip, RMuint16 port)
{
	struct sockaddr_in	myAddress;
	int res;
	RMstatus answer;
	
	myAddress.sin_family		= AF_INET;
	myAddress.sin_port			= htons(port);
	myAddress.sin_addr.s_addr	= inet_addr(ip);

	res = sendto((int)sock, (char*)request, sizeOFRequest, 0, (struct sockaddr *) &myAddress, sizeof(myAddress));
	
	if (res==(int)sizeOFRequest)
		answer=RM_OK;
	else
		answer=RM_ERROR;

	RMDBGLOG((RMSOCKETDBG,
		  "RMSocketSendto on #%d: sending %d bytes to %s %s\n",
		  sock,
		  sizeOFRequest,
		  ip,
		  (answer=RM_OK)?"ok":"failed"));
	
	return answer;
}


RMint32 RMSocketRecv(RMsocket sock, RMuint8 * buffer, RMuint32 maxSizeOfBuffer)
{
	int flags=0;
	int actuallyReceived = -1;
	
	actuallyReceived=recv((int)sock,buffer,maxSizeOfBuffer,flags);

	if(actuallyReceived <0)
		perror("++++++++++++++++++++++++++++ socket Recv");

	RMDBGLOG((RMSOCKETDBG,
		  "RMSocketRecv on #%d: asked %d bytes, got %d bytes\n",
		  sock,
		  maxSizeOfBuffer,
		  actuallyReceived));
	
	return actuallyReceived;
}

RMstatus RMSocketClose(RMsocket sock)
{
	RMDBGLOG((RMSOCKETDBG,
		  "RMSocketClose: closing #%d\n",
		  sock));

	if (close((int)sock)==0)
		return RM_OK;
	else
		return RM_ERROR;
}

RMstatus RMSocketJoinMulticastSession(RMsocket sock, const RMascii *ip, RMuint32 ttl)
{
	struct ip_mreq mreq; 
	
	mreq.imr_multiaddr.s_addr = inet_addr(ip);
	mreq.imr_interface.s_addr = htonl(INADDR_ANY);
	
	if (setsockopt((int)sock, IPPROTO_IP, IP_ADD_MEMBERSHIP, &mreq, sizeof(mreq)) < 0) {
		perror("setsockopt");
		return RM_ERROR;
	}

	if(ttl > 0) {
		if (setsockopt((int)sock, IPPROTO_IP, IP_MULTICAST_TTL, (char*)&ttl, sizeof(ttl)) < 0) {
			perror("setsockopt");
			return RM_ERROR;
		}
	}

	return RM_OK;
}

RMbool RMSocketIsAlive(RMsocket sock)
{
	fd_set tabSocketToWait;
	RMint16 res;
	struct timeval timeout;
	
	FD_ZERO(&tabSocketToWait);
	FD_SET((int)(sock),&tabSocketToWait);

	timeout.tv_sec = 0;
	timeout.tv_usec = 1000;

	errno = 0;
	res = (RMint16)select((int)sock,
			      &tabSocketToWait,
			      (fd_set *)0,
			      (fd_set *)0,
			      &timeout);
	
	if((res==-1) &&
	   (errno==EINTR)){
		perror("IsAlive");
		return FALSE;
	}

	return TRUE;
}

RMascii * RMSocketGetAddressFromName(RMascii *hname) 
{
	RMascii *stringToReturn = (RMascii*)NULL;
	struct hostent *hent;
	struct in_addr iaddr;

	if(hname == (RMascii*)NULL){
		perror("Can't resolve IP address : address null");
		return (RMascii*)NULL;
	}

	hent = gethostbyname(hname);
	if (hent == NULL) {
		perror("Can't resolve IP address");
		return (RMascii*)NULL;
	}

	memcpy(&iaddr.s_addr, hent->h_addr, sizeof(iaddr.s_addr));
	stringToReturn=RMMalloc(strlen(inet_ntoa(iaddr))+1);
	strcpy(stringToReturn,inet_ntoa(iaddr));
	return stringToReturn;
}

RMascii * RMSocketGetHostAddress(void) 
{
#define MAXHNAME 50

	char *hname;
	struct hostent *hent;
	RMascii *stringToReturn = (RMascii*)NULL;

	hname = (char*)RMCalloc(MAXHNAME, sizeof(char));

	if (gethostname(hname,MAXHNAME) != 0) {
		perror("gethostname");
		goto error;
	}

	hent = gethostbyname(hname);
	if (hent == NULL) {
		perror("Can't resolve IP address");
		goto error;
	}

	stringToReturn=RMMalloc(strlen(inet_ntoa(*((struct in_addr*) hent->h_addr)))+1);
	strcpy(stringToReturn,inet_ntoa(*((struct in_addr*) hent->h_addr)));
	RMFree(hname);
	return stringToReturn;

 error:
	RMFree(hname);
	return (RMascii*)NULL;
}

RMuint32 RMSocketInetAddr(RMascii *ip)
{
	if(ip == (RMascii *)NULL)
		return 0;

	return inet_addr((char*)ip);
}
