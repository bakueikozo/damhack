/*****************************************
 Copyright  2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#ifndef ALLOW_OS_CODE
#define ALLOW_OS_CODE
#endif
#include "../include/rmlibcw.h"

#include <stdlib.h>

RMascii *RMGetEnv(const RMascii *var)
{
	return getenv(var);
}
