/*****************************************
 Copyright � 2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE 1
#include "rmdef/rmdef.h"

// _NP below means Non Posix. This code uses GNU features (recursive mutex)
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <pthread.h>
#include <semaphore.h>

#include "robust.h"

#include <errno.h>

/* a good trick to debug semop (blocked is blocked!) */
#define MAXEINTRFAILURES 10000

#define EINTRPROOF( type , name , argswithparsandtypes, argswithoutparsandtypes... ) 						     \
type robust_ ## name argswithparsandtypes  											     \
{ 										  						     \
	int rc,failurecount=0; 													     \
	while (1) { 													    	     \
		errno = 0;                                                                                                           \
		rc= name ( argswithoutparsandtypes ) ; 									    	     \
		if ((rc!=0)&&(errno==EINTR)) { 										             \
			failurecount++; 									    		     \
			if (failurecount==MAXEINTRFAILURES) {                                                                        \
                                RMDBGLOG ((ENABLE, "Max EINTR Failures in " # name "\n"));					     \
                                RMPanic(RM_ERROREINTR);						    		                     \
                        }                                                                                                            \
		} 													    	     \
		else break; 												    	     \
	} 														    	     \
        return rc; 													    	     \
} 

EINTRPROOF(int,pthread_mutex_init,(pthread_mutex_t *mutex,const pthread_mutexattr_t *mutexattr),mutex,mutexattr)
EINTRPROOF(int,pthread_mutex_lock,(pthread_mutex_t *mutex),mutex)
EINTRPROOF(int,pthread_mutex_unlock,(pthread_mutex_t *mutex),mutex)
EINTRPROOF(int,pthread_mutex_destroy,(pthread_mutex_t *mutex),mutex)
EINTRPROOF(int,pthread_mutexattr_init,(pthread_mutexattr_t *attr),attr)
EINTRPROOF(int,pthread_mutexattr_destroy,(pthread_mutexattr_t *attr),attr)
EINTRPROOF(int,pthread_mutexattr_settype,(pthread_mutexattr_t *attr, int kind),attr,kind)
EINTRPROOF(int,pthread_setspecific,(pthread_key_t key, void *attr),key,attr)

EINTRPROOF(int,sem_init,(sem_t *sem, int pshared, unsigned int value),sem,pshared,value)
EINTRPROOF(int,sem_wait,(sem_t * sem),sem)
EINTRPROOF(int,sem_trywait,(sem_t * sem),sem)
EINTRPROOF(int,sem_post,(sem_t * sem),sem)
EINTRPROOF(int,sem_getvalue,(sem_t * sem, int * sval),sem,sval)
EINTRPROOF(int,sem_destroy,(sem_t * sem),sem)

EINTRPROOF(int,pthread_cond_init,(pthread_cond_t *cond, pthread_condattr_t *cond_attr), cond, cond_attr)
EINTRPROOF(int,pthread_cond_destroy, (pthread_cond_t *cond), cond)
EINTRPROOF(int,pthread_cond_timedwait,(pthread_cond_t *cond, pthread_mutex_t *mutex, const struct timespec *abstime), cond, mutex, abstime)
EINTRPROOF(int,pthread_cond_wait,(pthread_cond_t *cond, pthread_mutex_t *mutex), cond, mutex)
EINTRPROOF(int,pthread_cond_broadcast,(pthread_cond_t *cond), cond)

void *robust_pthread_getspecific(pthread_key_t key)
{
	void *rc;
	int failurecount=0; 

	while (1) {
		errno = 0;
		rc= pthread_getspecific (key) ;
		if ((rc==NULL)&&(errno==EINTR)) {
			failurecount++;
			if (failurecount==MAXEINTRFAILURES) {
                                RMDBGLOG ((ENABLE, "Max EINTR Failures in pthread_getspecific\n"));
                                RMPanic(RM_ERROREINTR);	
                        }
		} 
		else break;
	} 
        return rc;
}
