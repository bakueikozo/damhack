/*****************************************
 Copyright � 2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE 1
#include "../include/rmlibcw.h"

// _NP below means Non Posix. This code uses GNU features (recursive mutex)
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <pthread.h>
#include <semaphore.h>

#include "robust.h"

#include <errno.h>

struct _RMcriticalsection {
	pthread_mutex_t pmt;
};

RMcriticalsection RMPlacementCreateCriticalSection(RMuint8 *p)
{
	struct _RMcriticalsection *x;
	
	x=(struct _RMcriticalsection *)p;
	
	{
		pthread_mutexattr_t attr;
		
		robust_pthread_mutexattr_init(&attr);
		robust_pthread_mutexattr_settype(&attr,PTHREAD_MUTEX_RECURSIVE_NP);
		robust_pthread_mutex_init(&(x->pmt),&attr);
		robust_pthread_mutexattr_destroy(&attr);
		
	}

	return x;
}

RMcriticalsection RMCreateCriticalSection(void)
{
	struct _RMcriticalsection *x=(struct _RMcriticalsection *)RMMalloc(sizeof(struct _RMcriticalsection));
	
	return RMPlacementCreateCriticalSection((RMuint8 *)x);
}

void RMPlacementDeleteCriticalSection(RMcriticalsection v)
{
	robust_pthread_mutex_destroy(&(v->pmt));
}

void RMDeleteCriticalSection(RMcriticalsection v)
{
	robust_pthread_mutex_destroy(&(v->pmt));
	RMFree(v);
}

void RMEnterCriticalSection(RMcriticalsection v)
{
	robust_pthread_mutex_lock(&(v->pmt));
}     

void RMLeaveCriticalSection(RMcriticalsection v)
{
	if ((robust_pthread_mutex_unlock(&(v->pmt))!=0)&&(errno==EPERM)) 
		RMPanic(RM_FATALINCONSISTENTCRITICALSECTIONCALL);
}

RMcriticalsectionOps g_critsec_ops={
	Create:RMCreateCriticalSection,
	Delete:RMDeleteCriticalSection,
	Enter:RMEnterCriticalSection,
	Leave:RMLeaveCriticalSection,
};
