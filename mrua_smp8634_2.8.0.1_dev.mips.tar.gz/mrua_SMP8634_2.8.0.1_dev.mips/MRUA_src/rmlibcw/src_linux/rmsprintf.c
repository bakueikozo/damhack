/*****************************************
 Copyright  2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#ifndef ALLOW_OS_CODE
#define ALLOW_OS_CODE
#endif
#include "../include/rmlibcw.h"

#include <stdarg.h>
#include <stdio.h>

void RMPrintAscii(RMascii *dest, const RMascii *fmt, ...)
{
	va_list ap;
	va_start(ap, fmt);
	vsprintf(dest,fmt, ap);
	va_end(ap);
}

RMint32 RMPrintNAscii(RMascii *dest, RMuint32 size, const RMascii *fmt, ...)
{
	va_list ap;
	int rc;
	unsigned long n = (unsigned long)size;
	va_start(ap, fmt);
	rc = vsnprintf(dest, n, fmt, ap);
	va_end(ap);
	return (RMint32) rc;
}
