/*****************************************
 Copyright � 2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE
#include "../include/rmlibcw.h"

#if 0
  #define LOADDBG ENABLE
#else
  #define LOADDBG DISABLE
#endif

#include <dlfcn.h>
#include <stdio.h>

RMstatus RMOpenDynamicLibrary(const RMnonAscii *filename,RMdll *library)
{
	/*
	  We resolve lazyly to allow different dlls to cross reference each other.
	  This also means that we CANNOT NEVER EVER use any symbol coming from any 
	  dll implictely by relying on the loader. We must use 
	  RMGetSymbolFromDynamicLibrary.
	  This is also why we have the CreateInstance rmframework: this allows us to
	  have simple entry points into each object. Then, we can use the object's 
	  virtual methods (only the virtual ones because that way, you never resolve 
	  them: you just do jump base + offset and base is known by CreateInstance
	  and offset is known at compile time.
	 */
	*library=(void *)dlopen((const char *)filename,RTLD_LAZY);
	if (*library==NULL) {
		RMDBGLOG((LOADDBG, "open dll failed : %s\n", dlerror()));
		return RM_ERRORDYNAMICLIBOPEN;
	} else {
		RMDBGLOG((LOADDBG, "open dynamic Library \"%s\"\n", filename));
		return RM_OK;
	}
}

RMstatus RMGetSymbolFromDynamicLibrary(RMdll library,const RMascii *symbol,void * *theSymbol)
{
	*theSymbol=dlsym(library,symbol);
	if (*theSymbol==NULL) {
		RMDBGLOG((LOADDBG, "Failed to load symbol \"%s\"\n", symbol));
		return RM_ERRORDYNAMICLIBGETSYMBOL;
	} else {
		RMDBGLOG((LOADDBG, "Suceeded to load symbol \"%s\"\n", symbol));
		return RM_OK;
	}
}

RMstatus RMCloseDynamicLibrary(RMdll library)
{
	// the man page does not explain dlclose return values.
	if (library == NULL) {
		RMDBGLOG((LOADDBG, "Impossible to close dynamic library\n")); 
		return RM_ERRORDYNAMICLIBCLOSE;
	}
	dlclose(library);
	RMDBGLOG((LOADDBG, "Dynamic library closed \n")); 

	return RM_OK;
}

size_t strlen(const char *s);

RMnonAscii *RMForgeDLLNameFromModuleName(const RMascii *moduleName)
{
	char *result;
	RMuint32 i;

	result=(char *) RMMalloc(strlen(moduleName)+strlen("module.so") + 2);
	sprintf(result, "%smodule.so", moduleName);
	i = 0;
        while (result[i] != '\0') {
		if (('A'<= result[i]) && (result[i] <= 'Z')) {
			result[i] = (result[i] - 'A') + 'a';
		}
		i++;
        }
	return (RMnonAscii *) result;
}
