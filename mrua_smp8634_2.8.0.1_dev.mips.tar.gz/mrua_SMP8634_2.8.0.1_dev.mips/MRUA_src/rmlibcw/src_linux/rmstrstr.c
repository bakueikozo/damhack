/*****************************************
 Copyright (c) 2006
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
#define ALLOW_OS_CODE 1

#include "../include/rmlibcw.h"

#include <string.h>

RMascii* RMSearchAscii(RMascii *region, RMascii *searchStr)
{
	return (char*)strstr((const char*)region,(const char*)searchStr);
}

