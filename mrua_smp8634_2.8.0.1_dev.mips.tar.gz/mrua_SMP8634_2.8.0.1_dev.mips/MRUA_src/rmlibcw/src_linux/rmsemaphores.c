/*****************************************
 Copyright  2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#ifndef ALLOW_OS_CODE
#define ALLOW_OS_CODE
#endif
#include "../include/rmlibcw.h"

// _NP below means Non Posix. This code uses GNU features (recursive mutex)
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <pthread.h>
#include <semaphore.h>

#include "robust.h"

typedef struct {
	sem_t s;
} _RMsemaphore;

RMsemaphore RMCreateSemaphore(RMuint32 lInitialCount)
{
	sem_t *x=(sem_t *)RMMalloc(sizeof(sem_t));
	if (robust_sem_init(x,0,lInitialCount)!=0) RMPanic(RM_FATALSEMAPHORE);
	return (RMsemaphore)x;
}

void RMDeleteSemaphore(RMsemaphore x)
{
	if (robust_sem_destroy((sem_t *)x)!=0) RMPanic(RM_FATALSEMAPHORE);
	RMFree(x);
}
       
void RMWaitForSemaphore(RMsemaphore x)
{
	if (robust_sem_wait((sem_t *)x)!=0) RMPanic(RM_FATALSEMAPHORE);
}

RMstatus RMTryWaitForSemaphore(RMsemaphore x)
{
	return (robust_sem_trywait((sem_t *)x)==0)?RM_OK:RM_SEMAPHORELOCKED;
}

void RMReleaseSemaphore(RMsemaphore x, RMuint32 lReleaseCount)
{
	RMuint32 i;

	// if (lReleaseCount > 1) { THIS IS NOT ATOMIC }
	for (i=0;i<lReleaseCount;i++) 
		if (robust_sem_post((sem_t *)x)!=0) RMPanic(RM_FATALSEMAPHORE);
}

RMuint32 RMGetSemaphoreValue(RMsemaphore x)
{
	RMuint32 val;

	if (robust_sem_getvalue((sem_t *)x,(int *)(&val))!=0) RMPanic(RM_FATALSEMAPHORE);
	return (RMuint32)val;
}

RMsemaphoreOps g_sem_ops={
	Create:RMCreateSemaphore,
	Delete:RMDeleteSemaphore,
	WaitFor:RMWaitForSemaphore,
	TryWaitFor:RMTryWaitForSemaphore,
	Release:RMReleaseSemaphore,
	GetValue:RMGetSemaphoreValue,
};
