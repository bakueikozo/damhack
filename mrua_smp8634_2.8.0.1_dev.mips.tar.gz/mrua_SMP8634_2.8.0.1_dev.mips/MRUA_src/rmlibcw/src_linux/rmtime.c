/*****************************************
 Copyright  2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#ifndef ALLOW_OS_CODE
#define ALLOW_OS_CODE
#endif
#include "../include/rmlibcw.h"

#include <unistd.h>
#include <sys/time.h>

RMuint32 RMCyclesElapsed32(RMuint32 ref0, RMuint32 ref1)
{
	return (ref1 > ref0) ? ref1 - ref0 : 0xFFFFFFFF - ref0 + ref1 + 1;
}

RMuint64 RMCyclesElapsed64(RMuint64 ref0, RMuint64 ref1)
{
	return (ref1 > ref0) ? ref1 - ref0 : 0xFFFFFFFFFFFFFFFFLL - ref0 + ref1 + 1;
}

void RMMicroSecondSleep(RMuint64 microsec)
{
	if (microsec>=20000) {
		RMuint64 sec=microsec/1000000ULL;

		while (sec>0) sec=sleep(sec);
		// don't use usleep with arg>=1000000 (see man page)
		usleep(microsec%1000000ULL);
	}
	else {
		RMuint64 startedat=RMGetTimeInMicroSeconds();

		// busy wait, no other way.
		while ((RMGetTimeInMicroSeconds()-startedat)<microsec);
	}
}

RMuint64 RMGetTimeInMicroSeconds(void)
{
	static RMbool firsttimehere=TRUE;
	static struct timeval timeorigin;

	struct timeval now;

	// the first time, set the origin.
	if (firsttimehere) {
		gettimeofday(&timeorigin,NULL);
		firsttimehere=FALSE;
	}

	gettimeofday(&now,NULL);

	return 
		(RMuint64)(
		 (
		  (RMint64)now.tv_sec
		  -(RMint64)timeorigin.tv_sec
		  )*1000000LL
		 +
		 ( 
		  (RMint64)now.tv_usec
		  -(RMint64)timeorigin.tv_usec
		  )
		 );
}

RMuint64 RMGetTimeInSCR(void)
{
	return RMGetTimeInMicroSeconds()*9ULL/100ULL;
}

void RMRandomMicroSecondSleep(RMuint32 microsec)
{
	RMuint32 x;

	x = (RMuint32) ((RMreal)microsec*RMRandom());
	RMMicroSecondSleep((RMuint64) x);
}
