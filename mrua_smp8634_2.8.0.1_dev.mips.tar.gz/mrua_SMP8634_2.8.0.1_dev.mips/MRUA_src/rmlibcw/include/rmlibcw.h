/*****************************************
 Copyright © 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmlibcw.h
  @brief  

  long description

  @author Emmanuel Michon
  @date   2002-12-06
*/

#ifndef __RMLIBCW_H__
#define __RMLIBCW_H__

#include "rmdef/rmdef.h"

// we do implement RMDBGLOG_implementation as a function at this level
#undef RMDBGLOG_implementation

#include "rmnonascii.h"

#ifdef WITH_THREADS
#include "rmsemaphores.h"
#include "rmcriticalsections.h"
#include "rmtimeoutsemaphore.h"
#include "rmthreads.h"
#endif // WITH_THREADS

#include "rmrandom.h"
#include "rmtime.h"
#include "rmsprintf.h"
#include "rmfile.h"
#include "rmenv.h"
#include "rmsocket.h"
#include "rmpacketcommandioctl.h"
#include "rmdynamicloader.h"
#include "rmstrcmp.h"
#include "rmstrstr.h"

#endif // __RMLIBCW_H__
