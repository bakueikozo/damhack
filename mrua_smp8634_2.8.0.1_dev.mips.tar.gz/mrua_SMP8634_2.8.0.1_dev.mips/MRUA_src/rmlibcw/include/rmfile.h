/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   rmfile.h
  @ingroup types
  @brief  standard libc IO API.

  @author Mathieu Lacage
  @date   2001-09-07
*/

#ifndef __RMFILE_H__
#define __RMFILE_H__

RM_EXTERN_C_BLOCKSTART

/** type used to manipulate TEXT file */
typedef struct _RMfile *RMfile;


/** Standard file descriptors */
extern struct _RMfile _RMstdin;
extern struct _RMfile _RMstdout;
extern struct _RMfile _RMstderr;

#define RMstdin  (&_RMstdin)
#define RMstdout (&_RMstdout)
#define RMstderr (&_RMstderr)

typedef struct _RMdirectory *RMdirectory;

typedef struct {
	const RMnonAscii *name;
} RMdirectoryEntry;

typedef enum {
	// read if exists. Fails otherwise
	RM_FILE_OPEN_READ,
	// creates if not exists. Overwrite otherwise
	RM_FILE_OPEN_WRITE,
	// read, write file if exists
	RM_FILE_OPEN_READ_WRITE,
	// read, write file ( also create if does not exist)
	RM_FILE_OPEN_READ_WRITE_CREATE,
	
} RMfileOpenMode;

typedef enum {
	// seek from start of file.
	RM_FILE_SEEK_START,
	// seek from current position in the file.
	RM_FILE_SEEK_CURRENT,
	// seek from end of file.
	RM_FILE_SEEK_END,
} RMfileSeekPos;

/**
   For custom files, read operation : Your function should transfer up to size
   bytes into the buffer, and return the number of bytes read, or zero to
   indicate end-of-file. You can return a value of -1 to indicate an error.
*/
typedef RMint32 (*RMReadOp) (void *cookie, RMuint8 *buffer, RMuint32 size);

/** 
   For custom files, write operation : Your function should transfer up to size
   bytes from the buffer, and return the number of bytes written. You can
   return a value of -1 to indicate an error.
*/
typedef RMint32 (*RMWriteOp) (void *cookie, const RMuint8 *buffer, RMuint32 size);

/**
   For custom files, seek operation : After doing the seek operation, your
   function should store the resulting file position relative to the beginning
   of the file in position. Your function should return a value of 0 on success
   and -1 to indicate an error.
*/
typedef RMint32 (*RMSeekOp) (void *cookie, RMint64 *position, RMfileSeekPos whence);

/**
   For custom files, close operation : Your function should return -1 to
   indicate an error, and 0 otherwise.
*/
typedef RMint32 (*RMCloseOp) (void *cookie);


/**
   For custom files, file operations struct
*/
typedef struct {
	RMReadOp read;
	RMWriteOp write;
	RMSeekOp seek;
	RMCloseOp close;
} RMFileOps;

/**
   For custom directories, read operation : Your function should read one directory entry.
   Should return RM_OK on success, RM_ERRORNODIRECTORYENTRY if it cannot return a new entry,
   RM_ERROR on error.
   @remark the field entry should be valid till the user either call RMReadDirectory
           or RMCloseDirectory. The user don't free this field himself.
*/
typedef RMstatus (*RMReadDirectoryOp) ( void*cookie, RMdirectoryEntry *const entry );

/**
   For custom directories, close operation.
   Should return RM_OK on success, RM_ERROR on erMror.
*/
typedef RMstatus (*RMCloseDirectoryOp) ( void*cookie );

/**
   For custom directories, directory operations struct
*/
typedef struct {
	RMReadDirectoryOp read;
	RMCloseDirectoryOp close;
} RMDirectoryOps;

/**
   Returns the size of the specified filename (doesn't work with custom files).

   The file should not already be open when calling RMSizeOfFile.

   This size is the number of bytes needed to store the file [whatever the file
   content is (unicode,...), and if the operating system needs some file
   termination character it includes these characters]

   @param filename      
   @param pSize the size
   @return: does not return RM_OK on failure (non existent file...)
*/
RM_LIBRARY_IMPORT_EXPORT RMstatus RMSizeOfFile(const RMnonAscii *filename,RMint64 *pSize);


/**
   Returns the size of the given file handle (works with customs files).

   The file should already be open when calling RMSizeOfFile.

   This size is the number of bytes needed to store the file [whatever the file
   content is (unicode,...), and if the operating system needs some file
   termination character it includes these characters]

   @param f
   @param pSize the size
   @return: does not return RM_OK on failure (non existent file...)
*/
RM_LIBRARY_IMPORT_EXPORT RMstatus RMSizeOfOpenFile(RMfile f, RMint64 *pSize);


/**
   Opens a file with the rights specified in the mode.

   @param filename : name of the file to open.      
   @param mode : rights applied to the file. Valid modes are:
                 RM_FILE_OPEN_READ (read if exists. Fails otherwise)
		 RM_FILE_OPEN_WRITE (creates if not exists. Overwrite otherwise)
		 RM_FILE_OPEN_READ_WRITE (read, write file if exists)
   @return handle to the file opened, (RMfile)NULL on error.
*/
RM_LIBRARY_IMPORT_EXPORT RMfile RMOpenFile(const RMnonAscii *filename, RMfileOpenMode mode);


/**
   Opens a file with the rights specified in the mode, and use the given cookie
   and fileops to communicate with the underlying media. A read on this RMfile
   will call the read callback given in the RMFileOps structure. A write will
   call the write callback, seek will call the seek callback and close will
   call the close callback.  Each time a callback is called, the cookie will be
   passed to it, so it can be used to store private data.

   @param cookie : cookie to pass to file ops functions.      
   @param mode : rights applied to the file. Valid modes are:
                 RM_FILE_OPEN_READ (read if exists. Fails otherwise)
		 RM_FILE_OPEN_WRITE (creates if not exists. Overwrite otherwise)
		 RM_FILE_OPEN_READ_WRITE (read, write file if exists)
   @param ops : pointer to the fileops for this custom stream.
   @return handle to the file opened, (RMfile)NULL on error.
*/
RM_LIBRARY_IMPORT_EXPORT RMfile RMOpenFileCookie(void *cookie, RMfileOpenMode mode, RMFileOps *ops);


/**
   Creates a temporary file.

   @param void  
   @return handle to the file or NULL if the call failed.
*/
RM_LIBRARY_IMPORT_EXPORT RMfile RMCreateTmpFile(void);


/**
   Closes the filehandle.
   This call CANNOT fail.

   @param f filehandle to close.
   @return RM_ERRORCLOSEFILE or RM_ERRORFILELOCKED
*/
RM_LIBRARY_IMPORT_EXPORT RMstatus RMCloseFile(const RMfile f);


/**
   Reads size bytes from filehandle f and stores them in buffer pbuffer.

   Don't expect *preadSize to always match size of course.

   @param f filehandle to read in.
   @param pbuffer buffer to store data into.
   @param size number of bytes the caller wants to read.
   @param preadSize number of bytes actually read.
   @return RM_OK if succesful, RM_ERRORENDOFFILE if end of file 
           or RM_ERRORREADFILE is unsuccessful.
*/
RM_LIBRARY_IMPORT_EXPORT RMstatus RMReadFile (const RMfile f, RMuint8 *pbuffer, RMuint32 size, RMuint32 *preadSize);


/**
   Writes size bytes to filehandle f.

   @param f filehandle to write in.
   @param pbuffer buffer to read data from.
   @param size number of bytes to write.
   @param pwrittenSize number of bytes written.
   @return RM_OK if succesful, RM_ERRORENDOFFILE if end of file 
           or RM_ERRORWRITEFILE is unsuccessful.
*/
RM_LIBRARY_IMPORT_EXPORT RMstatus RMWriteFile (const RMfile f, const RMuint8 *pbuffer, RMuint32 size, RMuint32 *const pwrittenSize);


/**
   Copy the entire src file in the dest file. The current file
   position is not modified.

   @param dest  
   @param src   
   @return RM_OK or RM_ERROR
*/
RM_LIBRARY_IMPORT_EXPORT RMstatus RMCopyFile(const RMfile dest, const RMfile src);


/**
   Prints a string in a file.

   @param f     
   @param fmt   
   @param  ...  
   @return RM_OK if successful or RM_ERRORWRITEFILE is unsuccesful.
*/
RM_LIBRARY_IMPORT_EXPORT RMstatus RMPrintFile(RMfile f, const RMascii *fmt, ...);


/**
   Move the position of the file handle f to offset starting at position.

   @param f file handle.
   @param offset offset to move to.
   @param position starting position.
 */
RM_LIBRARY_IMPORT_EXPORT RMstatus RMSeekFile (const RMfile f, RMint64 offset, RMfileSeekPos position);


/**
   tests end of file.

   @param f file handle to test.
   @return TRUE is end of file, FALSE otherwise.
 */
RM_LIBRARY_IMPORT_EXPORT RMbool RMEndOfFile (const RMfile f);


/**
   flushes the file to the HD.

   @param f file to flush.
 */
RM_LIBRARY_IMPORT_EXPORT RMstatus RMFlushFile (RMfile f);


/**
   reads one line in the file. Read at most maxsize bytes.

   @param f     
   @param line  
   @param maxsize       
   @return RM_OK upon success.
*/
RM_LIBRARY_IMPORT_EXPORT RMstatus RMReadLineFile(RMfile f, RMascii *line, RMuint32 maxsize);

/**
   Lock the file to the current thread. This thread and only this one
   hase full access to the file. However, it cannot close it until it
   unlocks the file. To allow another thread to access the file, the
   thread must call unlock.

   @param f     
   @return 
*/
RM_LIBRARY_IMPORT_EXPORT RMstatus RMLockFile(RMfile f);


/**
   Unlock the file to allow other threads to access it.
   @param f
   @return 
*/
RM_LIBRARY_IMPORT_EXPORT RMstatus RMUnLockFile(RMfile f);


/**
   Sets the current working directory.

   @param directory to change to.

   @returns RM_OK on success.
            RM_ERROROPENFILE in case of error.
 */
RM_LIBRARY_IMPORT_EXPORT RMstatus RMChangeCurrentDirectory(const RMnonAscii *const directory);


/**
   Open current directory.

   @param dir a pointer to the structure representing a directory.
   @returns RM_OK on success.
            RM_ERROROPENFILE in case of error.
*/
RM_LIBRARY_IMPORT_EXPORT RMstatus RMOpenCurrentDirectory (RMdirectory *const dir);

/**
   Open directory to browse its entries.

   @param directory the name of the directory to open.
   @param dir a pointer to the returned directory.
   @return RM_OK on success. 
           RM_ERROROPENFILE in case of error.
 */
RM_LIBRARY_IMPORT_EXPORT RMstatus RMOpenDirectory (const RMnonAscii *const directory, RMdirectory *const dir);

/**
   Open a custom directory to browse its entries and use the given cookie
   and directoryops to communicate with the underlying media. A read (or close) on 
   this RMdirectory will call the read (or close) callback given in the RMDirectoryOps 
   structure. Each time a callback is called, the cookie will be
   passed to it, so it can be used to store private data.
   @param dir a pointer to the returned directory.
   @param cookie : cookie to pass to directory ops functions.      
   @param ops : pointer to the directory ops for this custom directory.
   @return RM_OK. 
 */
RM_LIBRARY_IMPORT_EXPORT RMstatus RMOpenDirectoryCookie (RMdirectory *const dir, void* cookie, RMDirectoryOps *ops);

/**
   Read one directory entry.

   @param directory the directory to read entries from.
   @param entry pointer where to store the next entry.
   @return RM_OK on success.
           RM_ERRORNODIRECTORYENTRY if it cannot return a new entry.

   @remark the fields in entry are valid till the user either call RMReadDirectory
           or RMCloseDirectory. The user should _not_ free these fields himself.
 */
RM_LIBRARY_IMPORT_EXPORT RMstatus RMReadDirectory (RMdirectory directory, RMdirectoryEntry *const entry);

/**
   Close a directory opened with RMOpenDirectory

   @return RM_OK on success. 
           RM_ERRORCLOSEFILE in case of error.
 */
RM_LIBRARY_IMPORT_EXPORT RMstatus RMCloseDirectory (RMdirectory directory);

/**
   Rename a file from oldpath to newpath. 

   @param oldpath       
   @param newpath       
   @return RM_OK on success 
           RM_ERROR on failure
*/
RM_LIBRARY_IMPORT_EXPORT RMstatus RMFileRename(RMnonAscii *oldpath,RMnonAscii *newpath);

/**
   Create a directory with write, read and execute access

   @param pathname      
   @return RM_OK on success 
           RM_ERROR on failure
*/
RM_LIBRARY_IMPORT_EXPORT RMstatus RMFileMkdir(RMnonAscii *pathname);

/**
   deletes a name from the filesystem. 

   @param pathname      
   @return RM_OK on success 
           RM_ERROR on failure
*/
RM_LIBRARY_IMPORT_EXPORT RMstatus RMFileUnlink(RMnonAscii *pathname);

/**
   Get the current poision in the file (offset from the beginning)�

   @param f : file handle
   @param position : current position
   @return RM_OK on success 
           RM_ERROR on failure
*/
RM_LIBRARY_IMPORT_EXPORT RMstatus RMGetCurrentPositionOfFile (const RMfile f, RMint64 *position);

RM_EXTERN_C_BLOCKEND

#endif // __RMFILE_H__ 
