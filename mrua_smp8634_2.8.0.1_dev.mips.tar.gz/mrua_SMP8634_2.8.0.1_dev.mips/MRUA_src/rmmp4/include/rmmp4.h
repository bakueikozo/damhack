/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   rmmp4.h
  @brief  Main class for the MP4 file reader

  @author Julien Soulier
  @date   2001-10-08
*/

#ifndef __RMMP4_H__
#define __RMMP4_H__

#include "../../rmdef/rmdef.h"
#include "../../rmmpeg4_framework/include/rmmpeg4client.h"
#include "../../rmmpeg4_framework/include/rmmpeg4track.h"
#include "../../rmmp4core/include/rmmp4core.h"
#include "../../rmmp4core/include/rmmp4corefile.h"
#include "../../rmdescriptordecoder/include/rmdescriptordecoder.h"

#include "rmmp4track.h"

class FileTypeBox;
class MovieBox;

RM_EXTERN_C void *rmdescriptordecoder_createinstance(void);

/** Class to read a mp4 file */
class RMmp4FileReader: public RMmpeg4Client
{
 public:
        /**
           Default constructor.

           @param name	
	*/
	RMmp4FileReader(const RMascii *name);


	/**
	   Default destructor.
	   
	   @param void	
	*/
	virtual ~RMmp4FileReader(void);


	/**
	   Opens the filereader on the file specified.
	   
	   @param mp4file       
	   @return RM_OK if success
	*/
	virtual RMstatus OpenFile(const RMnonAscii *mp4file);

	virtual RMstatus OpenUrl(const RMascii *url);

	virtual RMstatus OpenExternalFile(RMfile file);

	/**
	   Prints information about the mp4 file structure on stdout.
	   
	   @param void	
	*/
	virtual void Print(void);


	/**
	   Opens the track with the specified trackID. 
	   
	   @param trackID	
	   @return the track handle or NULL if track does not exist.
	*/
	virtual RMmpeg4Track *OpenTrack(RMuint32 trackID);


	/**
	   Closes the previously opened track.
	   
	   @param track 
	   @return RM_OK if success
	*/
	virtual RMstatus CloseTrack(RMmpeg4Track *track);


	/**
	   Gives the decoded Initial Object descriptor of the presentation.
	   
	   @param void
	   @return the initialObjectDescriptor
	*/
	virtual void *GetIOD(void);


	/**
	   Gives the video track ID of the presentation.
	   
	   @param void  
	   @return trackID
	*/
	virtual RMuint32 GetVideoTrackID(void);


	/**
	   Gives the audio track ID of the presentation.

	   @param void  
	   @return trackID
	*/
	virtual RMuint32 GetAudioTrackID(void);


        /**
           Seeks all the tracks to the time in seconds.

           @param time  
           @return time position where we really seeked to.
	*/
	virtual RMstatus Seek(RMuint32 time, RMuint32 *actualTime_ms);


        /**
           Stops playing the mp4 file.

           @param void  
           @return RM_OK on success RM_ERROR otherwise
	*/
	virtual RMstatus Stop(void);

        /**
           Starts playing the mp4 file.
	   
           @param void  
           @return RM_OK on success RM_ERROR otherwise
	*/
	virtual RMstatus Play(void);

	

#ifndef BASIC_MPEG4_FRAMEWORK
	/**
	   gets a property from the mp4 file client 
	   
	   @param propId
	   @param data
	   @param size
	 */

	virtual RMstatus GetProperty(RMpropertyId propId, void *data, RMuint32 size);

	/**
	   sets a property from the mp4 file client 
	   
	   @param propId
	   @param data
	   @param size
	 */
	virtual RMstatus SetProperty(RMpropertyId propId, void *data, RMuint32 size);

#endif
	/* Get property direct access */
	virtual RMstatus GetVideoWidth(void *data, RMuint32 size);
	virtual RMstatus GetVideoHeight(void *data, RMuint32 size);
	virtual RMstatus GetVideoDuration(void *data, RMuint32 size);
	virtual RMstatus GetMonitoringCheckBitrate(void *data, RMuint32 size);
	virtual RMstatus GetMonitoringVideoBitrate(void *data, RMuint32 size);
	virtual RMstatus GetMonitoringVideoAvgBitrate(void *data, RMuint32 size);
	virtual RMstatus GetMonitoringAudioBitrate(void *data, RMuint32 size);
	virtual RMstatus GetMonitoringAudioAvgBitrate(void *data, RMuint32 size);

	/* Set property direct access */
	virtual RMstatus SetMonitoringUpdateCheckBitrate();
	virtual RMstatus SetMP4CacheSize(void *data, RMuint32 size);

	virtual RMuint32 GetNumberOfVideoTracks(void);
	virtual RMuint32 GetNumberOfAudioTracks(void);
	virtual RMuint32 GetNumberOfSPUTracks(void);
	virtual RMuint32 GetNumberOfSubtitleTracks(void);
	virtual RMstatus GetVideoTrackIDByIndex(RMuint32 index, RMuint32 *trackID);
	virtual RMstatus GetAudioTrackIDByIndex(RMuint32 index, RMuint32 *trackID);
	virtual RMstatus GetSPUTrackIDByIndex(RMuint32 index, RMuint32 *trackID);
	virtual RMstatus GetSubtitleTrackIDByIndex(RMuint32 index, RMuint32 *trackID);
	virtual RMstatus SeekTrack(RMuint32 time_ms, RMuint32 *actualTime_ms, RMmpeg4Track *mp4t);
	virtual RMbool isNero(void);

	/* nero specific */
	virtual RMstatus GetClosestChapter(RMuint64 currentTime_100ns, RMuint64 *nextChapterTime_100ns, RMuint8 *chapterName, RMuint32 maxNameLen, RMint32 chapter);
	virtual RMstatus GetChapterByIndex(RMuint32 index, RMuint64 *ChapterTime_100ns, RMuint8 *chapterName, RMuint32 maxNameLen);
	virtual RMbool canBePlayed(void);


 private:
	struct rmmp4corefile *m_mp4file;
	RMuint32     m_nOpenedTracks;
	RMmp4Track   *m_tracks[MP4_MAXTRACKS];

	RMint64 m_timeBitRateViewer;
	RMuint64 m_nbSec;
	RMuint64 m_lastNumBytesAudio;
	RMuint64 m_lastNumBytesVideo;
	RMuint64 m_totalBytesAudioReceived;
	RMuint64 m_totalBytesVideoReceived;
	RMuint32 m_cacheSize;
};



#endif // __RMMP4_H__
