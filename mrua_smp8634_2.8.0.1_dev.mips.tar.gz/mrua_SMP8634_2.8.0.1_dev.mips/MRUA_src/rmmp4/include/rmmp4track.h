
/*****************************************************************
*** Copyright (c) 2001 Sigma Designs Inc. All rights reserved. ***
*****************************************************************/

/**
   @file   rmmp4track.h
   @brief  describes the mp4 track
   
   @author Julien Soulier
   @date   2001-12-21
*/

#ifndef __RMMP4TRACK_H__
#define __RMMP4TRACK_H__

struct rmmp4coretrack;

/** Track as seen in a mp4 file. */
class RMmp4Track : public RMmpeg4Track
{
 public:

	RMmp4Track(const RMascii *name, struct rmmp4coretrack *mp4track);

	/**
	   Default destructor
	   
	   @param 	
	*/
	virtual ~RMmp4Track(void);


	/**
	   Dumps the track in a file.
	   
	   @param filename file to write	
	*/
	virtual RMstatus Dump(const RMnonAscii *filename);

	
	/**
	   Prints information concerning the track in stdout.
	   @param void	
	*/
	virtual void Print(void);

	/**
	   This call is used to get the next sample from the track. It
	   does not allocate the buffer contained in sample. maxSize
	   is used to limit the size of the allocated buffer. You can
	   use this call in 2 ways: 

	     -# getting entire AU: if maxSize is greater than the size
	     of the AU, you will get the entire AU. To allocate the
	     buffer you can call the GetSampleMaxSize or
	     GetNextSampleSize.

	     -# getting part of an AU: if maxSize is lesser than the
	     size of the AU then you will have only maxSize bytes of
	     it. Then in sample you can check the flag to test if it
	     is the start of an AU or the end of an AU. 

	   @param sample        
	   @param maxSize       
	   @return TRUE or FALSE if the sample is not valid (end of track)
	*/
	virtual RMstatus GetNextSample(RMmp4Sample *sample, RMuint32 maxSize);


	virtual RMstatus GetNextRandomAccessPoint(RMmp4Sample *mp4Sample, RMuint32 maxSize);

	virtual RMstatus GetPreviousRandomAccessPoint(RMmp4Sample *mp4Sample, RMuint32 maxSize);


	/**
	   Returns the DSI of the track. You don't need to free the
	   returned buffer. It will last until you close the track.
	   
	   @param size	size of the DSI
	   @return pointer to the DSI bitstream.
	*/
	virtual RMuint8 *GetDSI(RMuint32 *size);

        /**
           Set the current position in the track to sampleIndex. 

           @param sampleIndex   
           @return new samplePosition
	*/
	virtual RMstatus GoToSampleIndex(RMuint32 sampleIndex);


        /**
           Seeks to the nearest sample which CTS corresponds to time
           in second.

           @param time  
           @return the actual seek position in second.
	*/
	virtual RMstatus Seek(RMuint32 time, RMuint32 *actualTime_ms);


        /**
           stops the reading of the track

           @param void  
           @return RM_OK on success, RM_ERROR otherwise
	*/
	virtual RMstatus Stop(void);

        /**
           start playing the track

           @param void  
           @return RM_OK on success, RM_ERROR otherwise
	*/
	virtual RMstatus Play(void);

        /**
           @param void  
           @return FALSE if all samples are seek positions, TRUE otherwise.
	*/
	virtual RMbool IsNotRandomSeekable(void);
	

	/**
           Enters critical section to avoid other threads to modify the
           track state.

           @param void	
	*/
	virtual void Lock(void);

	/**
           Leaves critical section to allow other threads to modify the
           track state.

           @param void	
	*/
	virtual void UnLock(void);

#ifndef BASIC_MPEG4_FRAMEWORK
	virtual RMstatus GetProperty(RMpropertyId propId, void *data, RMuint32 size);
	virtual RMstatus SetProperty(RMpropertyId propId, void *data, RMuint32 size);
#endif

	/* Get property direct access */
	virtual RMstatus GetTrackType(void *data);
	virtual RMstatus GetTrackDuration(void *data, RMuint32 size);
	virtual RMstatus GetTrackVOPTimeIncrement(void *data, RMuint32 size);
	virtual RMstatus GetTrackSampleCount(void *data, RMuint32 size);
	virtual RMstatus GetTrackTimeScale(void *data, RMuint32 size);
	virtual RMstatus GetTrackRandomAccessSampleCount(void *data, RMuint32 size);
	virtual RMstatus GetTrackNextSampleSize(void *data, RMuint32 size);
	virtual RMstatus GetTrackTotalDataReceived(void *data, RMuint32 size);

	virtual RMstatus GetTrackWidth(RMuint32 *width);
	virtual RMstatus GetTrackHeight(RMuint32 *height);
	virtual RMstatus GetTrackSize(RMuint32 *trackSize, RMuint32 *sampleCount);
	virtual RMstatus GetNextSampleReadPos(RMuint64 *nextReadPos);

	virtual RMbool   isH264Track(void);
	virtual RMstatus GetH264Level(RMuint32 *level);
	virtual RMstatus GetH264Profile(RMuint32 *profile);
	virtual RMstatus GetH264LengthSize(RMuint32 *lengthSize);

	virtual RMstatus GetTrackSampleRate(RMuint32 *sampleRate);
	virtual RMstatus GetTrackChannelCount(RMuint32 *channelCount);
	virtual RMstatus GetTrackBitPerSample(RMuint32 *bitPerSample);

	/* Set property direct access */
	virtual RMstatus SetTrackType(void *data, RMuint32 size);


 private:
	
	struct rmmp4coretrack *m_mp4track;
	RMuint64 m_totalDataRead;	
	ES_Descriptor *m_ESDescriptor;
	RMuint32 lengthSize;
};	

#endif // __RMMP4TRACK_H__
