/****************************************************************************
* Copyright (c) Sigma Designs, Inc. 2005. All rights reserved.
*/
/**
*	@file     xtask_args.c
*
*	@brief    Common argument interface for CPU-Xtask communication.
* 
*   @version  0.1
*
*   @buglog   First revision.
*
*	@author   Alan Liddeke
*	
****************************************************************************/


/*---------------------------------------------------------------------------
                                 INCLUDES
 ---------------------------------------------------------------------------*/

#include "xtask_args.h"



/*---------------------------------------------------------------------------
                                 CONSTANTS
 ---------------------------------------------------------------------------*/

#if 0 
#define LOCALDBG       ENABLE
#else
#define LOCALDBG       DISABLE 
#endif



/*---------------------------------------------------------------------------
                                 FUNCTIONS
 ---------------------------------------------------------------------------*/


/***************************************************************
*      Method Name                                             *
*         xtask_pull_args                                      *
*                                                              *
*      Description:                                            *
*         Pull the output args from the FIFO (XPU->CPU).       *
*                                                              *
*                                                              *
***************************************************************/
RMstatus xtask_pull_args( struct gbus* pgbus, struct XtaskFIFO* fifo, struct XtaskArgs* inArgs )
{
	RMstatus err = RM_OK;
	RMuint32 bytesReturned;
	
	/* Initialization */
	inArgs->size = 0;
	
	RMDBGLOG((LOCALDBG,"Pulling Args from the FIFO.\n"));
	
	if( inArgs->data == NULL ) {
		RMDBGLOG((LOCALDBG,"Invalid Output buffer specified. (NULL)!"));
		return RM_ERROR;
	}
	
	/* Get return count */
	bytesReturned = gbus_read_uint32( pgbus, (RMuint32)&fifo->argSize );
	
	RMDBGLOG((LOCALDBG,"BytesToPull = %d from loc 0x%08lx\n",bytesReturned, (RMuint32)&fifo->argSize));
	
	if( bytesReturned == 0 ) {
		RMDBGLOG((LOCALDBG, "No input arguments returned.\n"));
		return RM_OK;	
	}
	else if( bytesReturned > RPC2XTASK_MAX_ARG_LENGTH ) {
		RMDBGLOG((LOCALDBG,"Invalid byteCount for return parameters\n"));
		return RM_ERROR;
	}
	
	
	/* Set the byteCount */
	inArgs->size = bytesReturned;
	
	
	/* Everything is sane, perform the xfer */
	RMDBGLOG((LOCALDBG,"Pulling %d bytes from location 0x%08lx\n",inArgs->size, (RMuint32)&fifo->argData ));
	gbus_read_data8( pgbus, (RMuint32)&fifo->argData, (RMuint8*)inArgs->data, inArgs->size );
	
	return err;
}



/***************************************************************
*      Method Name                                             *
*         xtask_push_args                                      *
*                                                              *
*      Description:                                            *
*         Push the arguments onto the FIFO (CPU->XPU).         *
*                                                              *
*                                                              *
***************************************************************/
RMstatus xtask_push_args( struct gbus* pgbus, struct XtaskFIFO* fifo, struct XtaskArgs* outArgs )
{	
	
	RMDBGLOG((LOCALDBG,"Pushing Args onto FIFO.\n"));
	
	/* Initialize argc to 0 */	
	gbus_write_uint32( pgbus, (RMuint32)&fifo->argSize, 0 );	
	
	/* Check to see if there is any data to push */	
	if( outArgs->size == 0 ) {
		RMDBGLOG((LOCALDBG, "No output arguments specified.\n"));
		return RM_OK;
	}
	
	
	/* Ensure the output arg size is sane */
	if( outArgs->size > RPC2XTASK_MAX_ARG_LENGTH ) {
		RMDBGLOG((LOCALDBG, "Invalid output size (%d > %d)\n",
		                     outArgs->size, RPC2XTASK_MAX_ARG_LENGTH ));
		return RM_ERROR;
	}
	/* Make sure that output pointer has been set */
	if( outArgs->data == NULL ) {
		RMDBGLOG((LOCALDBG,"Invalid Input buffer specified. (NULL) with length specified!"));
		return RM_ERROR;
	}
	
	/* Everything is sane, perform the xfer */
	
	/* Set the size of the data pushed onto the FIFO */
	RMDBGLOG((LOCALDBG,"Pushing %d bytes (loc=0x%lx)\n",outArgs->size, (RMuint32)&fifo->argSize));
	gbus_write_uint32( pgbus, (RMuint32)&fifo->argSize, outArgs->size );
	
	/*  Push the data onto the FIFO */
	RMDBGLOG((LOCALDBG,"Writing %d bytes to location 0x%lx\n",outArgs->size, (RMuint32)&fifo->argData));
	gbus_write_data8(  pgbus, (RMuint32)&fifo->argData, (RMuint8*)outArgs->data, outArgs->size );
	
	
	return RM_OK;
}


