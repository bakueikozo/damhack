
#include "vsync.h"
#include "llad/include/gbus.h"
#include "emhwlib/include/emhwlib_event.h"
#include "emhwlib_hal/include/emhwlib_registers.h"
#include "emhwlib_hal/include/emhwlib_lram.h"

#include "delay.h"


#if 0 
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

// TODO: FIX the addresses below!
#define VSYNC_HEARTBEAT_ADDR     (REG_BASE_cpu_block+LR_HB_VSYNC)
#define TIMER_27MHZ_ADDR         (REG_BASE_system_block+SYS_xtal_in_cnt)


#define THRESHOLD_MS             (5) // 5ms is 1/3 of the start of the period for 60hz refresh rate
				     // this yields ~10ms until next vsync.

#define TICKS_PER_MS             (27000)
#define TIME_INTERVAL_TICKS      (THRESHOLD_MS * TICKS_PER_MS)
		
#define WITHIN_TIME_INTERVAL() \
	((cur_time> prev_time)? \
		(((cur_time - prev_time) < TIME_INTERVAL_TICKS)?TRUE:FALSE)\
		:(((0xFFFFFFFF - prev_time) + cur_time + 1) < TIME_INTERVAL_TICKS )?TRUE:FALSE)

#define MAX_RETRIES 20 
#define RETRIES_EXCEEDED(first,cur) \
	((cur > first)?\
	(((cur - first) >= MAX_RETRIES)?TRUE:FALSE)\
		:(((0xFFFFFFFF - first) + cur + 1) >= MAX_RETRIES)?TRUE:FALSE)

void wait_for_vsync(struct gbus *pgbus)
{
	RMuint32 prev_vsync;
	RMuint32 cur_vsync;
	RMuint32 first_vsync;
	
	RMuint32 prev_time;
	RMuint32 cur_time;

	RMDBGLOG((LOCALDBG,"Wait For VSYNC Called! pgbus=%08lx, ADDR=%08lx, ADDR2=%08lx\n",pgbus,VSYNC_HEARTBEAT_ADDR,TIMER_27MHZ_ADDR));
	prev_vsync  = gbus_read_uint32( pgbus, VSYNC_HEARTBEAT_ADDR );
	prev_time   = gbus_read_uint32( pgbus, TIMER_27MHZ_ADDR );
	first_vsync = prev_vsync;
	
	while(1) {
		cur_vsync = gbus_read_uint32( pgbus, VSYNC_HEARTBEAT_ADDR );
		cur_time  = gbus_read_uint32( pgbus, TIMER_27MHZ_ADDR );
	
		RMDBGLOG((LOCALDBG,"vsync_hb=%08lx, prev_vsynch_hb=%08lx, time=%08lx, prev_time=%08lx\n",cur_vsync, prev_vsync, cur_time, prev_time));
	
		if( ((cur_vsync != prev_vsync) && (WITHIN_TIME_INTERVAL())) || RETRIES_EXCEEDED(first_vsync, cur_vsync) ){
			RMDBGLOG((LOCALDBG,"Finished waiting for vsync -> prev=%08lx, cur=%08lx\n",prev_vsync, cur_vsync));
			break;
		}
		
		prev_vsync = cur_vsync;
		prev_time  = cur_time;
		
		RMDBGLOG((LOCALDBG,"Looping for vsync change!\n"));
		DELAY_MS(1); // Don't run too often.
	}
}

