
#include "delay.h"

#define CLOCK_FREQ_MHZ  (300)  // 8634 CPU clock speed

RMuint32 g_cpu_freq = CLOCK_FREQ_MHZ;

/* DELAY Method:
 *
 *  Assumes that the inner loop will take 2 cycles
 *    - 1 for conditional check
 *    - 1 for the increment.
 *
 *    The clock_freq is hard-coded , TODO: determine clock frequency
 *    from using the 27MHz timer.
 *
 *    Be careful.  This delay has potential overflow problems depending
 *    on the frequency of the CPU, ...  It is recommended to not exceed
 *    1000000 for the input argument (x) => 1 second worth of delay.
 */
void delay_us(RMuint32 period_us)
{
	RMuint32 ct= 0;
	RMuint32 period_ct = g_cpu_freq * period_us/5;

	for(;ct< period_ct; ct++) {
		asm("nop");
	}
}

/* 
 * delay_set_cpu_freq_mhz
 *
 * Sets the internal CPU frequency for use by 
 *
 */
void delay_set_cpu_freq_mhz(RMuint32 freq)
{
	g_cpu_freq = freq;
}

