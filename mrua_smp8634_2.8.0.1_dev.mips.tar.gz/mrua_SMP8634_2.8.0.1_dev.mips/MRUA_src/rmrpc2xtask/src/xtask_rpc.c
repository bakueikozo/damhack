/****************************************************************************
* Copyright (c) Sigma Designs, Inc. 2005. All rights reserved.
*/
/**
*	@file     xtask_rpc.c
*
*	@brief    RPC interface between CPU/Xtask.
* 
*
*	@author   Alan Liddeke
*	
****************************************************************************/


/*---------------------------------------------------------------------------
                                 INCLUDES
 ---------------------------------------------------------------------------*/

#include "llad/include/gbus.h"
#include "emhwlib/include/emhwlib_event.h"
#include "xos/include/xos_xrpc.h"

#include "xtask_rpc.h"

#include "delay.h"


#ifdef USE_WAIT_FOR_VSYNC
#include "vsync.h"
#endif


/*---------------------------------------------------------------------------
                           CONSTANT LITERALS
 ---------------------------------------------------------------------------*/

#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

#if 0
#define VERBOSE_DEBUG
#endif


#define XTASK_EVENT_KILL 0xFFFFFFFF


#define HW_TIMER_ADDR  REG_BASE_system_block+SYS_xtal_in_cnt


#define US_PER_S                 (1000000)
#define SYNC_TIMEOUT_US          (10*US_PER_S) // 10 Second timeout for sync
#define TICKS_PER_US             (27.0)
#define MAX_TIMEOUT              ((0xFFFFFFFF / TICKS_PER_US)/2)

/*---------------------------------------------------------------------------
                              FUNCTIONS 
 ---------------------------------------------------------------------------*/


/* Get an initial value for use of the HW 27MHZ counter register
 * This counter is a 32-bit register and thus overflows ((2^32) - 1) / 27 Mhz
 * => 159 seconds.  This requires that the interval for which the timer will
 * be used is less than or equal to 159 seconds.  This timer is only available
 * on TANGO2 (TODO: add for TANGO3) 
 */
static RMuint32 timer_start(struct gbus* pgbus)
{
#if (EM86XX_CHIP == EM86XX_CHIPID_TANGO2)
	return gbus_read_uint32(pgbus,HW_TIMER_ADDR);
#else
	return 0;
#endif
}

static RMbool timer_interval_complete(struct gbus* pgbus, RMuint32 startTime, RMuint32 timeInterval_us)
{
#if (EM86XX_CHIP == EM86XX_CHIPID_TANGO2)
	RMuint32 currentTime = gbus_read_uint32(pgbus,HW_TIMER_ADDR);
	RMuint32 ticksElapsed;

	if( timeInterval_us > (0xFFFFFFFF / TICKS_PER_US) )
		RMDBGLOG((ENABLE,"ERROR:  Timer Interval can never be reached !\n"));
		
	if( currentTime < startTime ) {
		/* Handle overflow condition */
		ticksElapsed = (currentTime) + (0xFFFFFFFF - startTime) + 1;
	}
	else {
		ticksElapsed = currentTime - startTime;
	}
	
	if( ((ticksElapsed)/(TICKS_PER_US)) >= timeInterval_us )
		return TRUE;
	else 
		return FALSE;
#else
	/* Always return true, no timer present */
	return TRUE;
#endif
}



/***************************************************************
*      Method Name                                             *
*         xtask_rpc_start                                      *
*                                                              *
*      Description:                                            *
*         Call -xstart on the given xtask image.               *
*                                                              *
*                                                              *
***************************************************************/
RMstatus xtask_rpc_start( struct XtaskAPI* context,struct XstartParams* params )
{	
	
	struct xrpc_block_header *pB = context->pB;
	struct gbus *pgbus = context->pgbus;
	RMuint32 base_addr = context->base_addr;
	RMuint32 image     = context->image;
	int xPid;

	
	
	RMDBGLOG((LOCALDBG,"Starting Xtask.\n"));
	
	/* Start the xtask on the selected image */
	gbus_write_uint32(pgbus, (RMuint32)&pB->xrpcid,XRPC_ID_XSTART);
	gbus_write_uint32(pgbus, (RMuint32)&pB->param0, image); 

	/* If no params are specified (NULL) then all are set to '0' and
	 * the communication area is set to the top half of the debug fifo.*/
	if( params != NULL ) {
		/* The following get passed into Xtask_entry(a0,a1,a2,a3) in order 
		 * a0 = ruaCommAddr,
		 * a1 = flashPageNum
		 * a2 = User defined.
		 * a3 = User defined.
		 * */
		gbus_write_uint32(pgbus, (RMuint32)&pB->param1, params->ruaCommAddr); 
		gbus_write_uint32(pgbus, (RMuint32)&pB->param2, params->flashPageNum);
		gbus_write_uint32(pgbus, (RMuint32)&pB->param3, params->a2);
		gbus_write_uint32(pgbus, (RMuint32)&pB->param4, params->a3);
	
	}
	else {
		gbus_write_uint32(pgbus, (RMuint32)&pB->param1, 0);
		gbus_write_uint32(pgbus, (RMuint32)&pB->param2, 0);
		gbus_write_uint32(pgbus, (RMuint32)&pB->param3, 0);
		gbus_write_uint32(pgbus, (RMuint32)&pB->param4, 0);
	}
	
	/* This is mandatory: */
	gbus_write_uint32(pgbus, (RMuint32)&pB->headerandblocksize, sizeof(struct xrpc_block_header));

#ifdef USE_WAIT_FOR_VSYNC
	wait_for_vsync(pgbus);
#endif
	if (doxrpc(pgbus,base_addr) != RM_OK) {
		RMDBGLOG((ENABLE,"xrpc failed\n"));
		
		RMDBGLOG((ENABLE,": pgbus=%lld\n"
				 ": image=%d\n", pgbus,image));
		return RM_ERROR;
	}
	
	/* Determine the PID of the new xtask */
	xPid = gbus_read_uint32(pgbus,(RMuint32)&pB->param0);
	context->xPid = xPid;
	if( params ) {
		context->fifo = (struct XtaskFIFO*)(params->ruaCommAddr);

	}
	else { // By default use the top half of the Debug fifo for rpc communication
	        context->fifo = (struct XtaskFIFO*)rpc2xtask_fifo_base_addr[xPid];
	}
	
	/* Semaphore must be initialized before making any calls. */
	xtask_semaphore_release(context); // Set to zero!
	
	/* Zero the procedure register to prevent unwanted call to the xtask at startup */
	gbus_write_uint32( pgbus,(RMuint32)&(context->fifo->procedureFd), 0x00000000);
	
	
	if( xPid == -1 ) {
		RMDBGLOG((ENABLE, "Unable to launch Xtask, too many running.\n"));
		return RM_ERROR;
	}
	else {
		RMDBGLOG((LOCALDBG,"Xtask Started.\n"));
		return RM_OK;
	}
}

/***************************************************************
*      Method Name                                             *
*         xtask_rpc_preloadxtask                               *
*                                                              *
*      Description:                                            *
*         Indicate that the xtask was preloaded                *
*         Returns RM_OK for success, RM_ERROR for failure.     *
*                                                              *
***************************************************************/
RMstatus xtask_rpc_preloadxtask( struct XtaskAPI* context, RMuint32 slot)
{
	/* Copy back the image number the xtask was loaded to */
	context->image = slot;
	
	return RM_OK;	
}

/***************************************************************
*      Method Name                                             *
*         xtask_rpc_loadxtask                                  *
*                                                              *
*      Description:                                            *
*         Load the given XLOAD binary                          *
*         Returns RM_OK for success, RM_ERROR for failure.     *
*                                                              *
***************************************************************/
RMstatus xtask_rpc_loadxtask( struct XtaskAPI* context, RMuint8* pXload, RMuint32 xloadSize)
{
	struct xrpc_block_header *pB = context->pB;
	struct gbus *pgbus = context->pgbus;
	RMuint32 base_addr = context->base_addr;
	RMuint32 size      = xloadSize;
	
	/* Make sure that the binary will fit within the buffer */
	if( context->size < sizeof(struct xrpc_block_header) + xloadSize ) {
		RMDBGLOG((ENABLE,"xtask_rpc_loadxtask: ERROR ! xrpc memory area not large enough to load xtask!\n"));
		return RM_ERROR;
	}
	
	/** Sanity Checks **/
	
	/* Make sure that the chip is of valid type */
	if ((gbus_read_uint16(pgbus, REG_BASE_host_interface + PCI_REG0) & ~0xf) != 0x8630) {
		RMDBGLOG((ENABLE, "for tango2 only.\n"));
		return RM_ERROR;
	}
	
	/* Make sure that local RAM is available */
	if (gbus_read_uint32(pgbus, REG_BASE_cpu_block + G2L_RESET_CONTROL) == 3) {
		RMDBGLOG((ENABLE, "cpu in reset 3, I can't access local ram\n"));
		return RM_ERROR;
	}

	
	
	/** Write out the Block Header and Data **/
	
	/* Set the XRPC header */
	gbus_write_uint32(pgbus,(RMuint32)&pB->callerid,XRPC_CALLERID_IGNORED);
	gbus_write_uint32(pgbus,(RMuint32)&pB->headerandblocksize,(sizeof(struct xrpc_block_header)+63)&~63);

	
	/* Write the binary xtask data to the XRPC data location */
	RMDBGLOG((ENABLE,"Xtask Load size = %ld\n",xloadSize));
	gbus_write_data8(pgbus, (RMuint32)(pB+1), pXload, xloadSize);
	gbus_write_uint32(pgbus,(RMuint32)&pB->xrpcid,XRPC_ID_XLOAD);
	
	/* ! Write out the size */
	if ((gbus_read_uint32(pgbus,(RMuint32)(pB+1))>>24)==XLOAD_SEKID_CLEAR)
		gbus_write_uint32(pgbus,(RMuint32)&pB->param0,size-XLOAD_CLEAR_HEADERSIZE);
	else
		gbus_write_uint32(pgbus,(RMuint32)&pB->param0,size-XLOAD_CIPHERED_HEADERSIZE);

	// by putting garbage here, you can crash Maa. Fixed with Mac.
	gbus_write_uint32(pgbus,(RMuint32)&pB->param1,0);
	gbus_write_uint32(pgbus,(RMuint32)&pB->param2,0);
	gbus_write_uint32(pgbus,(RMuint32)&pB->param3,0);
	gbus_write_uint32(pgbus,(RMuint32)&pB->param4,0);
	gbus_write_uint32(pgbus,(RMuint32)&pB->headerandblocksize,sizeof(struct xrpc_block_header)+size);
	
	
	
#ifdef VERBOSE_DEBUG
	//DEBUG: Print out header and XLOAD binary:
	{
		RMuint32 i;

		/* write the block header out */
		RMDBGLOG((LOCALDBG," block header: "));
		for(i=0; i< 8;i++ ) {
			RMDBGPRINT(( LOCALDBG, "0x%08lx, ", gbus_read_uint32( pgbus, ((RMuint32)(pB))+(RMuint32)(4*i) ) ));
		}
		
		/* Write the rest */
		RMDBGPRINT((ENABLE,"\n\ngbus read of the XLOAD binary: \n"));
		for(i=0; i<xloadSize; i++) {
			if( i%32 == 0 && i != 0) {
				RMDBGPRINT((LOCALDBG,"\n"));
			}
			RMDBGPRINT(( LOCALDBG, "%02X",  gbus_read_uint8(pgbus, (RMuint32)( ((RMuint32)pB) + sizeof(struct xrpc_block_header)+i)) ));
		}
		RMDBGPRINT((LOCALDBG,"\n\n\nActual xload binary: \n"));
		
		/* Write out the actual values */
		for(i=0; i< xloadSize; i++) {
			if(i%32 == 0 && i != 0) {
				RMDBGPRINT((LOCALDBG,"\n"));
			}
			RMDBGPRINT((LOCALDBG, "%02X", ((RMuint8*)pXload)[i]));
		}
		RMDBGPRINT((ENABLE,"\n\n\n"));
	}
#endif
	/** Perform XRPC **/
	
	if ( doxrpc(pgbus,base_addr) == RM_OK ) {
		RMDBGLOG((LOCALDBG,"xrpc Load succeeded\n"));
	}
	else {
#ifdef VERBOSE_DEBUG
		{
			RMuint32 i;

			/* write the block header out */
			RMDBGLOG((LOCALDBG," block header: "));
			for(i=0; i< 8;i++ ) {
				RMDBGPRINT(( LOCALDBG, "0x%08lx, ", gbus_read_uint32( pgbus, ((RMuint32)(pB))+(RMuint32)(4*i) ) ));
			}
		
			/* Write the rest */
			RMDBGPRINT((ENABLE,"\n\ngbus read of the XLOAD binary: \n"));
			for(i=0; i<xloadSize; i++) {
				if( i%32 == 0 && i != 0) {
					RMDBGPRINT((LOCALDBG,"\n"));
				}
				RMDBGPRINT(( LOCALDBG, "%02X",  gbus_read_uint8(pgbus, (RMuint32)( ((RMuint32)pB) + sizeof(struct xrpc_block_header)+i)) ));
				}
			RMDBGPRINT((LOCALDBG,"\n\n\nActual xload binary: \n"));
		
			/* Write out the actual values */
			for(i=0; i< xloadSize; i++) {
				if(i%32 == 0 && i != 0) {
					RMDBGPRINT((LOCALDBG,"\n"));
				}
				RMDBGPRINT((LOCALDBG, "%02X", ((RMuint8*)pXload)[i]));
			}
			RMDBGPRINT((ENABLE,"\n\n\n"));
		}
#endif
		RMDBGLOG((ENABLE,"\nxrpc failed --- if a xtask is using a cipher or if you reboot\n"
		                     "            --- xrpc will fail with RM_BUSY\n"));
		return RM_ERROR;
	}
	
	/* Copy back the image number the xtask was loaded to */
	context->image = gbus_read_uint32(pgbus,(RMuint32)&pB->param0);
	
	return RM_OK;	
}

/***************************************************************
*      Method Name                                             *
*         xtask_rpc_unloadxtask                                *
*                                                              *
*      Description:                                            *
*         UnLoad the given xtask using the XUNLOAD binary      *
*         retruns RM_OK for success, RM_ERROR for failure.     *
*                                                              *
***************************************************************/
RMstatus xtask_rpc_unloadxtask( struct XtaskAPI* context, RMuint8* pXUnload, RMuint32 xunloadSize, RMuint32 xunloadBinSize)
{
	struct xrpc_block_header *pB = context->pB;
	struct gbus *pgbus = context->pgbus;
	RMuint32 base_addr = context->base_addr;
	RMuint32 image = context->image;
	RMstatus err;

	/* Make sure that the binary will fit within the buffer */
	if( context->size < sizeof(struct xrpc_block_header) + xunloadSize ) {
		RMDBGLOG((ENABLE,"xtask_rpc_unloadxtask: ERROR ! xrpc memory area not large enough to unload xtask!\n"));
		return RM_ERROR;
	}
	
	/** Sanity Checks **/
	
	/* Make sure that the chip is valid type is valid */
	if ((gbus_read_uint16(pgbus, REG_BASE_host_interface + PCI_REG0) & ~0xf) != 0x8630) {
		RMDBGLOG((ENABLE, "for tango2 only.\n"));
		return RM_ERROR;
	}
	
	/* Make sure that local RAM is available */
	if (gbus_read_uint32(pgbus, REG_BASE_cpu_block + G2L_RESET_CONTROL) == 3) {
		RMDBGLOG((ENABLE, "cpu in reset 3, I can't access local ram\n"));
		return RM_ERROR;
	}

	
	/** Write out the Block Header and Data **/
	
	/* Set the XRPC header */
	gbus_write_uint32(pgbus,(RMuint32)&pB->callerid,XRPC_CALLERID_IGNORED);

	/* Write XRPC action type */
	gbus_write_uint32(pgbus,(RMuint32)&pB->xrpcid,XRPC_ID_XUNLOAD);

	/* Write Data, image and size*/
	gbus_write_data8(pgbus, (RMuint32)(pB+1),pXUnload, xunloadSize);
	gbus_write_uint32(pgbus,(RMuint32)&pB->param1,image);
	gbus_write_uint32(pgbus,(RMuint32)&pB->param0,xunloadBinSize);

	/* Clear all unused registers */
	gbus_write_uint32(pgbus,(RMuint32)&pB->param2, 0);
	gbus_write_uint32(pgbus,(RMuint32)&pB->param3, 0);
	gbus_write_uint32(pgbus,(RMuint32)&pB->param4, 0);

	/* Write out total size of xrpc */
	gbus_write_uint32(pgbus,(RMuint32)&pB->headerandblocksize,sizeof(struct xrpc_block_header)+xunloadSize);
	

	RMDBGLOG((LOCALDBG,"base_addr = 0x%08lx, pB = 0x%08lx, xunload: size=%d, image=%d, binSize=%d\n",base_addr, pB, xunloadSize, image, xunloadBinSize ));
#ifdef VERBOSE_DEBUG
	//DEBUG: Print out header and XLOAD binary:
	{
		RMuint32 i;

		/* write the block header out */
		RMDBGLOG((LOCALDBG," block header: "));
		for(i=0; i< 8;i++ ) {
			RMDBGPRINT(( LOCALDBG, "0x%08lx, ", gbus_read_uint32( pgbus, ((RMuint32)(pB))+(RMuint32)(4*i) ) ));
		}
		
		/* Write the rest */
		RMDBGPRINT((ENABLE,"\n\ngbus read of the XLOAD binary: \n"));
		for(i=0; i<xunloadSize; i++) {
			if( i%32 == 0 && i != 0) {
				RMDBGPRINT((LOCALDBG,"\n"));
			}
			RMDBGPRINT(( LOCALDBG, "%02X",  gbus_read_uint8(pgbus, (RMuint32)( ((RMuint32)pB) + sizeof(struct xrpc_block_header)+i)) ));
		}
		RMDBGPRINT((LOCALDBG,"\n\n\nActual xload binary: \n"));
		
		/* Write out the actual values */
		for(i=0; i< xunloadSize; i++) {
			if(i%32 == 0 && i != 0) {
				RMDBGPRINT((ENABLE,"\n"));
			}
			RMDBGPRINT((LOCALDBG, "%02X", ((RMuint8*)pXUnload)[i]));
		}
		RMDBGPRINT((ENABLE,"\n\n\n"));
	}
#endif
	
	/** Perform XRPC **/
	if ( (err=doxrpc(pgbus,base_addr)) == RM_OK ) {
		RMDBGLOG((LOCALDBG,"Xunload succeeded\n"));
	}
	else {

		RMDBGLOG((ENABLE,"\nXUNLOAD failed! (%d)", err));

#ifdef VERBOSE_DEBUG // PRINT THE block header and XLOAD binary upon failure! 
		{
			RMuint32 i;		
			/* write the block header out */
			RMDBGLOG((ENABLE," block header: "));
			for(i=0; i< 8;i++ ) {
				RMDBGPRINT(( ENABLE, "0x%08lx, ", gbus_read_uint32( pgbus, ((RMuint32)(pB))+(RMuint32)(4*i) ) ));
			}
			
			/* Write the rest */
			RMDBGPRINT((ENABLE,"\n\nthe rest: \n"));
			for(i=0; i<xunloadSize; i++) {
				if( i%32 == 0 && i != 0) {
					RMDBGPRINT((ENABLE,"\n"));
				}
				RMDBGPRINT(( ENABLE, "%02X",  gbus_read_uint8(pgbus, (RMuint32)( ((RMuint32)pB) + sizeof(struct xrpc_block_header)+i)) ));
			}
			RMDBGPRINT((ENABLE,"\n\n\nActual Values: "));
		
			/* Write out the actual values */
			for(i=0; i< xunloadSize; i++) {
				if(i%32 == 0 && i != 0) {
					RMDBGPRINT((ENABLE,"\n"));
				}
				RMDBGPRINT((ENABLE, "%02X", ((RMuint8*)pXUnload)[i]));
			}
			RMDBGPRINT((ENABLE,"\n\n\n"));
		}
#endif	
		return RM_ERROR;
		
	}

	return RM_OK;
}

	

/***************************************************************
*      Method Name                                             *
*         xtask_rpc_stop                                       *
*                                                              *
*      Description:                                            *
*         Tell the xtask to stop.  This is different than a    *
*         xrpc -xstop ( ).                                     *
*                                                              *
***************************************************************/
RMstatus xtask_rpc_stop( struct XtaskAPI* context ) 
{
	struct gbus *pgbus             =  context->pgbus;
	int    xPid                    =  context->xPid;
	struct xrpc_block_header *pB   =  context->pB;
	RMuint32 base_addr             =  context->base_addr;
	
	RMDBGLOG((LOCALDBG,"Stopping Xtask.\n"));
	
	if (gbus_read_uint32(pgbus, REG_BASE_cpu_block + G2L_RESET_CONTROL) == 3) {
		RMDBGLOG((ENABLE, "cpu in reset 3, I can't access local ram\n"));
		return RM_ERROR;
	}

	/* Write out total size of xrpc */
	gbus_write_uint32(pgbus, (RMuint32) &pB->callerid, XRPC_CALLERID_IGNORED);
	gbus_write_uint32(pgbus, (RMuint32) &pB->headerandblocksize, (sizeof(struct xrpc_block_header) + 63) & ~63);

	
	/* Stop the xtask by the XKILL signal with '-1' as signal */
	gbus_write_uint32(pgbus,(RMuint32)&pB->xrpcid,XRPC_ID_XKILL);
	gbus_write_uint32(pgbus,(RMuint32)&pB->param0,xPid);
	gbus_write_uint32(pgbus,(RMuint32)&pB->param1,XTASK_EVENT_KILL);
	gbus_write_uint32(pgbus,(RMuint32)&pB->param2,0);
	gbus_write_uint32(pgbus,(RMuint32)&pB->param3,0);
	gbus_write_uint32(pgbus,(RMuint32)&pB->param4,0);

#ifdef USE_WAIT_FOR_VSYNC
	wait_for_vsync(pgbus);
#endif
	if (doxrpc(pgbus,base_addr) != RM_OK) {
	
		RMDBGLOG((ENABLE,"xrpc failed\n"));
		return RM_ERROR;
	}

	RMDBGLOG((LOCALDBG,"Xtask stopped.\n"));
	
	return RM_OK;
}



/***************************************************************
*      Method Name                                             *
*         xtask_rpc_get_status                                 *
*                                                              *
*      Description:                                            *
*         Retreive the procedure call status.                  *
*                                                              *
***************************************************************/
RMstatus xtask_rpc_get_status( struct XtaskAPI* context )
{

	struct gbus *pgbus = context->pgbus;
	RMstatus err;
	
	/* Get status |  */
	err = (RMstatus)gbus_read_uint32( pgbus, (RMuint32)&context->fifo->status );
	if( err != RM_OK ) {
		RMDBGLOG((LOCALDBG,"Error: Status returned %d\n",err));
	}
	
	return err;
}



/***************************************************************
*      Method Name                                             *
*         xtask_ioctl                                          *
*                                                              *
*      Description:                                            *
*         Push args, make the call, then return status as well *
*         as the return arguments.                             *
*                                                              *
***************************************************************/
RMstatus xtask_ioctl( struct XtaskAPI* context, RMuint8 procFd, struct XtaskArgs* args)
{
	RMstatus err;
	RMuint32 base_addr     =  context->base_addr;
	int      xPid          =  context->xPid;

	struct   gbus              *pgbus  =  context->pgbus;
	struct   xrpc_block_header *pB     =  context->pB;

	/* Make sure that procLoc == 0, and !xtaskBusy */
	
	//RMDBGLOG((LOCALDBG,"Pushing ARGS! args.data = 0x%lx, args.size = %ld\n",args->data, args->size));
	/* Write args onto the FIFO */
	if( (err = xtask_push_args(pgbus, context->fifo, args) ) != RM_OK ) {
		return err;
	}
	
	/* For new event driven mode we still must set ProcFd, this is required so that we know
	 * when the xtask has returned (by setting ProcFd = 0)*/
	gbus_write_uint32( pgbus,(RMuint32)&(context->fifo->procedureFd), procFd );

	
	/* Call procedure */
	RMDBGLOG((LOCALDBG,"Invoking procedure %d\n",procFd));

	if( context->events_enabled ) {
		/* Send an event to the xos to wake up the xtask. */
		
		gbus_write_uint32( pgbus, (RMuint32)&pB->xrpcid, XRPC_ID_XKILL);
		gbus_write_uint32( pgbus, (RMuint32)&pB->param0, xPid);
		gbus_write_uint32( pgbus, (RMuint32)&pB->param1, procFd);

		if (doxrpc(pgbus,base_addr) != RM_OK) {
			
			RMDBGLOG((ENABLE,"xrpc failed\n"));
			return RM_ERROR;
		}
	}
	
	RMDBGLOG((LOCALDBG,"complete.\n"));
	
	return err;
}


/***************************************************************
*      Method Name                                             *
*         xtask_rpc_call                                       *
*                                                              *
*      Description:                                            *
*         Make the call specified by proc_index                *
*                                                              *
***************************************************************/
RMstatus xtask_rpc_call( struct XtaskAPI* context, RMuint8 procIndex, struct XtaskArgs* args )
{
	struct gbus *pgbus = context->pgbus;
	RMstatus err; 

	RMDBGLOG((LOCALDBG,"Xtask RPC Call \'%ld\'\n",procIndex));
	
	/* Get Semaphore */
	xtask_semaphore_lock( context );
	
	/* Call procedure */
	if( xtask_ioctl(context,procIndex,args) != RM_OK ) {
		err = RM_ERROR;
		goto safe_exit;
	}
	
#ifdef USE_RPC_TIMEOUT
	if( args->timeout_us ) {
		err = xtask_rpc_wait_for_completion_wtimeout(context,args->timeout_us);
		if( RMFAILED(err) )
			goto safe_exit;
	}
	else {
		/* Timeout val of (0) waits forever! */
		xtask_rpc_wait_for_completion(context);
	}
#else
	/* Wait for procedure to finish */
	xtask_rpc_wait_for_completion(context);
#endif	
	/* Get return args and return result */
	if( (err = xtask_pull_args( pgbus, context->fifo, args )) != RM_OK ) {
		err = RM_ERROR;
		goto safe_exit;
	}
	
	/* get the return status */
	err = xtask_rpc_get_status(context);
	
safe_exit:
	
	/* release the semaphore */
	xtask_semaphore_release( context );
	
	return err;
}


/***************************************************************
*      Method Name                                             *
*         xtask_rpc_wait_for_completion                        *
*                                                              *
*      Description:                                            *
*         Wait until the procedure has finished.               *
*                                                              *
***************************************************************/
RMstatus xtask_rpc_wait_for_completion_wtimeout( struct XtaskAPI* context, RMuint32 timeout_us )
{
	struct gbus *pgbus = context->pgbus;
	RMuint32 startTime = timer_start(pgbus);
	
	/* Maximum timer value is 159072861 us ( 2 ^ 32 ticks / 27,000,000 ticks/second ) 
	 * The effective range provided by the rpc call is cut in half as to prevent the
	 * chance of an infinite loop where the timer interval is not read in time before
	 * a rollover.  So the effective maximum timeout is '159072861/2'
	 *    => 79536430 us (79 seconds)
	 *
	 *    This is much larger than what should be needed.
	 * */
	if( timeout_us > MAX_TIMEOUT )
		timeout_us = MAX_TIMEOUT;

	while( gbus_read_uint32( pgbus, (RMuint32)&context->fifo->procedureFd) != 0 ){
		if( timer_interval_complete( pgbus, startTime, timeout_us) ) {
			RMDBGLOG((ENABLE,"xtask rpc operation timed out!\n"));
			return RM_TIMEOUT;
		}
		/* Don't read GBUS too often! */
		delay_us(5);
	}
	return RM_OK;
}

/***************************************************************
*      Method Name                                             *
*         xtask_rpc_wait_for_completion                        *
*                                                              *
*      Description:                                            *
*         Wait until the procedure has finished.               *
*                                                              *
***************************************************************/
RMstatus xtask_rpc_wait_for_completion( struct XtaskAPI* context /*RMuint32 timeout_us*/ )
{
	struct gbus *pgbus = context->pgbus;
	
	/* TODO: Implement Timeout, by adding (int timeout) in ms to the call list. */
	while( gbus_read_uint32( pgbus, (RMuint32)&context->fifo->procedureFd) != 0 ){
	
		/* Don't read GBUS too often! */
		delay_us(5);
	}
	return RM_OK;
}



/***************************************************************
*      Method Name                                             *
*         xtask_rpc_sync                                       *
*                                                              *
*      Description:                                            *
*         This procedure prevents a race condition with the    *
*         xtask.  Basically, the xtask signals it has ended    *
*         its initialization, and ready to go by constantly    *
*         changing an agreed upon memory location in the PID   *
*         rpc2xtask zone.  Once this procedure sees a change   *
*         in  the memory location, it signals an ack to the    *
*         xtask by resetting a different agreed upon memory    *
*         location.                                            *
*                                                              *
***************************************************************/
RMstatus xtask_rpc_sync(struct XtaskAPI* context)
{
	
	RMuint32 first, second, third;
	struct gbus *pgbus = context->pgbus;
	RMuint32 xPid;
	RMuint32 startTime;

	xPid = context->xPid;
	RMDBGLOG((ENABLE,"Syncing to xPid %d\n",xPid));
	
	
	/* DEBUG */
	RMDBGLOG((LOCALDBG, "GBUS_ADDR(xPid_FIFO_SYNC) = 0x%lx\n", (RMuint32)(&context->fifo->xtaskToCPUSignal) ));

	/* Get initial timer value */
	startTime = timer_start(pgbus);
	
	/* Remember the first value in the agreed upon memory location */
	/* Added robustness: Xtask is looping on {0:255} interval only */
	while((first = gbus_read_uint32(pgbus, (RMuint32)&context->fifo->xtaskToCPUSignal)) > 255 ) {
		RMDBGLOG((LOCALDBG, "Waiting on first == 0x%lx\n",first));
		if( timer_interval_complete(pgbus, startTime, SYNC_TIMEOUT_US) ){
			RMDBGLOG((ENABLE,"Sync Timeout!\n"));
			return RM_TIMEOUT;
		}

	}
	/* Wait for this value to change */
	while ( ((second = gbus_read_uint32(pgbus, (RMuint32)&context->fifo->xtaskToCPUSignal)) == first) || (second>255)) {
		RMDBGLOG((LOCALDBG,"Waiting on second == 0x%lx\n",second));
		if( timer_interval_complete(pgbus, startTime, SYNC_TIMEOUT_US) ){
			RMDBGLOG((ENABLE,"Sync Timeout!\n"));
			return RM_TIMEOUT;
		}
	}
	
	/* Wait for this value to change for the second time*/
	while ( ((third = gbus_read_uint32(pgbus, (RMuint32)&context->fifo->xtaskToCPUSignal)) == second) || (third>255)) {
		RMDBGLOG((LOCALDBG,"Waiting on third == 0x%lx\n",third));
		if( timer_interval_complete(pgbus, startTime, SYNC_TIMEOUT_US) ){
			RMDBGLOG((ENABLE,"Sync Timeout!\n"));
			return RM_TIMEOUT;
		}
	}
	
	RMDBGLOG((ENABLE,"Rcvd signal from xtask.\n"));
	
	/* Signal acknowledgement to the xtask */
	gbus_write_uint32(pgbus, (RMuint32)&context->fifo->cpuToXtaskSignal, 0);
	RMDBGLOG((ENABLE,"Sent signal to xtask\n"));
	
	return RM_OK;
}



/***************************************************************
*      Method Name                                             *
*         xtask_rpc_init                                       *
*                                                              *
*      Description:                                            *
*         Initialize the xtas_api context.  This includes      *
*         opening the gbus/llad, initializing the base         * 
*         address for communication with the xtask.            *
*                                                              *
***************************************************************/
RMstatus xtask_rpc_init( struct XtaskAPI* context, RMascii device[MAX_DEVICE_STRING], RMuint32 xrpc_base_addr, RMuint32 xrpc_size )
{	
	/* Local Temp variables */
	struct llad *pllad = 0;
	struct gbus *pgbus = 0;
	struct xrpc_block_header *pB;
	

	RMDBGLOG((ENABLE,"Open the llad with string \'%s\', xrpc_base_addr = 0x%08lx\n",device, xrpc_base_addr));

	if( !xrpc_base_addr ) {
		RMDBGLOG((ENABLE,"xrpc_base_address is NULL ! \n"));
		return RM_ERROR;
	}
	if( xrpc_size < sizeof(struct xrpc_block_header) ) {
		RMDBGLOG((ENABLE,"memory allocated is too small. \n"));
		return RM_ERROR;
	}
	
	/* Open the llad */        
	pllad = llad_open(device);
	if (pllad == NULL) {
		RMDBGLOG((ENABLE, "unable to access device\n"));
		return RM_ERROR;
	}

	
	/* Open the gbus */
	pgbus = gbus_open(pllad);
	if( pgbus == 0 ) { 
		RMDBGLOG((ENABLE,"Failed to initialize the GBUS context\n"));
		return RM_ERROR;
	}
	
	
	/* Make sure that xrpc header is on 32-byte aligment for
	   Cache boundary issue in XOS !!! */
	if( xrpc_base_addr % 16 != 0 ) {
		RMDBGLOG((ENABLE, "xrpc_base_addr(0x%08lx) is not on a 16 byte cache boundary!\n",xrpc_base_addr ));
		return RM_ERROR;
	}
	
	pB = (struct xrpc_block_header *)xrpc_base_addr;
	
	
	/* update the xtaskContext */
	context->pgbus     =  pgbus;
	context->pllad     =  pllad;
	context->pB        =  pB;
	context->base_addr =  xrpc_base_addr;
	context->size      =  xrpc_size;

	/* By default events are enabled (backwards compatability) */
	context->events_enabled = TRUE;
	
	return RM_OK;
}



/***************************************************************
*      Method Name                                             *
*         xtask_rpc_close                                      *
*                                                              *
*      Description:                                            *
*         Cleanup, reclaim memory occupied by  the llad/gbus.  *
*                                                              *
***************************************************************/
void xtask_rpc_close( struct XtaskAPI *context )
{
	
	RMDBGLOG((LOCALDBG,"Closing Xtask API ref!\n"));
	/* Close the gbus and the llad */
	if( context->pgbus )
		gbus_close(context->pgbus);
	if( context->pllad )
		llad_close(context->pllad);        
	
}



/***************************************************************
*      Method Name                                             *
*         xtask_semaphore_lock                                 *
*                                                              *
*      Description:                                            *
*         Attempt to grab the semaphore, busy wait until it is *
*         available.  **Not atomic **                          *
*                                                              *
***************************************************************/
RMstatus xtask_semaphore_lock( struct XtaskAPI* context /*, int timeout_ms */ )
{
	struct gbus *pgbus = context->pgbus;
	
	//RMDBGLOG((ENABLE,":::::::: Xtask_Semaphore_Lock()         ..."));
	/* Busy wait for semahpore - maybe perform yeild here instead.*/
	while( gbus_read_uint32( pgbus, (RMuint32)&context->fifo->semaphore) != 0 );
	
	/* Acquire the semaphore */
	gbus_write_uint32( pgbus, (RMuint32)&context->fifo->semaphore, 1 );
	
	//RMDBGPRINT((ENABLE," locked!\n"));
	
	return RM_OK;
}



/***************************************************************
*      Method Name                                             *
*         xtask_sempahore_release                              *
*                                                              *
*      Description:                                            *
*         Release the semaphore.                               *
*                                                              *
*                                                              *
***************************************************************/
RMstatus xtask_semaphore_release( struct XtaskAPI* context )
{
	struct gbus *pgbus = context->pgbus;
	
	gbus_write_uint32( pgbus, (RMuint32)&context->fifo->semaphore, 0 );
	
	//RMDBGLOG((ENABLE,":::::::: Xtask_Semaphore_Released()!\n"));

	return RM_OK;
	
}

/***************************************************************
*      Method Name                                             *
*         xtasl_rpc_enable_event_mode                          *
*                                                              *
*      Description:                                            *
*         Enable/Disable event mode.                           *
*                                                              *
*                                                              *
***************************************************************/
void xtask_rpc_enable_event_mode( struct XtaskAPI* context, RMbool enable)
{
	context->events_enabled = enable;
}
