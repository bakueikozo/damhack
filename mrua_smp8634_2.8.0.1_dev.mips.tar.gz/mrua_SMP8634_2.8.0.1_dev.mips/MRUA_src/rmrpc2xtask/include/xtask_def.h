/****************************************************************************
* Copyright (c) Sigma Designs, Inc. 2005. All rights reserved.
*/
/**
*	@file     xtask_def.h
*
*	@brief    Shared constants, definitions used by xtask and CPU->xtask rpc.
* 
*  @version   0.1
*
*  @buglog    First revision.
*
*	@author   Alan Liddeke
*	
****************************************************************************/


#ifndef __XTASK_DEF_H__
#define __XTASK_DEF_H__

/*---------------------------------------------------------------------------
                                 INCLUDES
 ---------------------------------------------------------------------------*/

#include "rmdef/rmdef.h"
#include "emhwlib_hal/include/emhwlib_registers.h"
#include "emhwlib/include/emhwlib_dram.h"



/*---------------------------------------------------------------------------
                           CONSTANT LITERALS
 ---------------------------------------------------------------------------*/


/* Reserve space from the top of a PID's debug fifo */
/* This is the maximum number of bytes that can be transferred
 * between the CPU and the xtask + all registers used for rpc
 * communication defined below (rpc call area):
 */
#define RPC2XTASK_FIFO_SIZE              (2048+64+16)

/* TODO:   Make RPC2XTASK_FIFO_SIZE variable, based upon the information
 *         passed to xtask_rpc_init. */

/* Xtask RPC Call constants */
/* Used for syncing xtask to CPU */
#define XTASK_TO_CPU_SIGNAL              (60)
#define CPU_TO_XTASK_SIGNAL              (56)


/* reserve space at the top of the rpc call area */

/*-----------------------------------------------
 Per-Pid Fifo start -> *========================*
 (local 0x0000)        |    Actual DBG Fifo     |
                       |  for RMDBGLOG() calls  |
 RPC_START          -> --------------------------
 (FIFO_SIZE - RPC_LEN) |       Semaphore        |
                       |       4 Bytes          |
 RPC_START + 0x04   -> --------------------------
                       |       Context          |
                       |       4 Bytes          | 
 RPC_START + 0x08   -> --------------------------
                       |    Procedure Fd        |
                       |       4 Bytes          |
 RPC_START + 0x0C   -> --------------------------
                       |   Status Register      |
                       |       4 Bytes          |
 RPC_START + 0x10   -> --------------------------
                       |   Argument Byte Count  |
                       |       4 Bytes          |
 RPC_START + 0x14   -> --------------------------
                       |   Argument Data Area   |
                       | (The Rest of the FIFO) |
                       *========================*
 -----------------------------------------------*/ 

struct XtaskFIFO {
	
	RMuint32   semaphore;
	RMuint32   context;
	RMuint32   procedureFd;
	RMuint32   status;
	RMuint32   xtaskToCPUSignal;
	RMuint32   cpuToXtaskSignal;
	RMuint32   argSize; /* Total number of bytes of all combined args */
	RMuint32   argData;
};


/* The max amount of data that can be sent to/from an xtask */
#define RPC2XTASK_MAX_ARG_LENGTH         (RPC2XTASK_FIFO_SIZE - 28)



/* Maintain an array of rpc2xtask start addresses for each PID.  
 * Valid PIDs are 1, 2, 3, and 4. The 0th element of this array 
 * should never be accessed. */
static const RMuint32 rpc2xtask_fifo_base_addr [] = { 0,
				MEM_BASE_dram_controller_0 + FM_XTASK2DBG - RPC2XTASK_FIFO_SIZE,
				MEM_BASE_dram_controller_0 + FM_XTASK3DBG - RPC2XTASK_FIFO_SIZE,
				MEM_BASE_dram_controller_0 + FM_XTASK4DBG - RPC2XTASK_FIFO_SIZE,
				MEM_BASE_dram_controller_0 + FM_SCRATCH2  - RPC2XTASK_FIFO_SIZE 
			};




/* Safe Indexing into the constant array */
#define RPC2XTASK_FIFO_BASE_ADDR(x)     (((x>=1)&&(x<=4))?rpc2xtask_fifo_base_addr[x]:0)



			
#endif /* __XTASK_DEF_H__ */
