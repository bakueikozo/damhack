/****************************************************************************
* Copyright (c) Sigma Designs, Inc. 2005. All rights reserved.
*/
/**
*	@file     xtask_rpc_api.h
*
*	@brief    Interface for calling Xtask through procedure calls.
* 
*  @version  0.1
*
*  @buglog   First revision.
*
*	@author   Alan Liddeke
*	
****************************************************************************/

#ifndef __XTASK_RPC_H__
#define __XTASK_RPC_H__

/*---------------------------------------------------------------------------
                                 INCLUDES
 ---------------------------------------------------------------------------*/

#include "rmdef/rmdef.h"
#include "xtask_def.h"
#include "xtask_args.h"

/*---------------------------------------------------------------------------
                           CONSTANT LITERALS
 ---------------------------------------------------------------------------*/


#define MAX_DEVICE_STRING          1024
#define ARG_WIDTH                  4



/*---------------------------------------------------------------------------
                            TYPES / CLASSES
 ---------------------------------------------------------------------------*/


/* Xtask Context, stores all necessary info for starting,
 * initializing, communicating and terminating a given
 * Xtask. */
struct XtaskAPI{

	struct     gbus *pgbus;
	int        xPid;  /* Xtask Process Identifier {1:4} */
	struct     llad *pllad;
	struct     xrpc_block_header *pB;
	RMuint32   image;
	RMuint32   base_addr;
	RMuint32   size;
	struct     XtaskFIFO *fifo;
	RMbool     events_enabled;  /* used to specify the mode of communicating
				       a new procedure call to the xtask.  If enabled
				       (by default) the xtask will wake up immediately
				       whenever a procedure is invoked.  If disabled 
				       the xtask will have to wait its timeslice 
				       before it receives the procedure call. */
	
};

/* Xstart parameters to be passed to the xtask_rpc_start() command */
struct XstartParams {
	RMuint32 ruaCommAddr;   // a0
	RMuint32 flashPageNum;  // a1
	RMuint32 a2;
	RMuint32 a3;
};


/*---------------------------------------------------------------------------
                          FUNCTION PROTOTYPES 
 ---------------------------------------------------------------------------*/


/* Xtask CPU call API */
RMstatus xtask_rpc_init( struct XtaskAPI *context, RMascii device[MAX_DEVICE_STRING], RMuint32 xrpc_base_addr, RMuint32 xrpc_size);
void     xtask_rpc_close( struct XtaskAPI *context );
RMstatus xtask_rpc_sync( struct XtaskAPI *context );
RMstatus xtask_ioctl( struct XtaskAPI *context, RMuint8 procFd, struct XtaskArgs *args );
void     xtask_rpc_enable_event_mode( struct XtaskAPI *context, RMbool enable);

RMstatus xtask_rpc_call( struct XtaskAPI* context, RMuint8 procIndex, struct XtaskArgs* args );
RMstatus xtask_rpc_wait_for_completion( struct XtaskAPI* context /*, int timeout */ );
RMstatus xtask_rpc_wait_for_completion_wtimeout( struct XtaskAPI* context, RMuint32 timeout_us );


RMstatus xtask_rpc_stop( struct XtaskAPI *context );
RMstatus xtask_rpc_start( struct XtaskAPI *context, struct XstartParams* params );
RMstatus xtask_rpc_get_status( struct XtaskAPI *context );


RMstatus xtask_semaphore_lock( struct XtaskAPI *context);
RMstatus xtask_semaphore_release( struct XtaskAPI *context );

RMstatus xtask_rpc_preloadxtask( struct XtaskAPI* context, RMuint32 slot);
RMstatus xtask_rpc_loadxtask( struct XtaskAPI* context, RMuint8* pXload, RMuint32 xloadSize);
RMstatus xtask_rpc_unloadxtask( struct XtaskAPI* context, RMuint8* pXunload, RMuint32 xunloadSize, RMuint32 xunloadBinSize);
#endif /* __XTASK_RPC_H__ */
