#ifndef __VSYNC_H__
#define __VSYNC_H__

#include "rmdef/rmdef.h"

#define DELAY_US(x) delay_us(x);
#define DELAY_MS(x)    DELAY_US((x*1000));

struct gbus;


/** Wait for vsync
 *
 *   Utilizes the localram symbol 'LR_HB_VSYNC' to
 *   know when the last vsync has been completed 
 *   and it is safe to issue xrpc commands.
 */
void wait_for_vsync(struct gbus *pgbus);

#define WAIT_FOR_VSYNC(pgbus)   wait_for_vsync(pgbus);

#endif
