/****************************************************************************
* Copyright (c) Sigma Designs, Inc. 2005. All rights reserved.
*/
/**
*	@file      xtask_rpc_args.h
*
*	@brief     Common argument interface for CPU->Xtask communication(RPC).
*  
*   @version   0.1
*
*   @buglog    First revision.
*
*	@author    Alan Liddeke
*	
****************************************************************************/

#ifndef __XTASK_RPC_ARGS_H__
#define __XTASK_RPC_ARGS_H__

/*---------------------------------------------------------------------------
                                 INCLUDES
 ---------------------------------------------------------------------------*/

#include "xtask_def.h"
#include "gbuslib/include/gbus_list.h"


/*---------------------------------------------------------------------------
                            CONSTANT LITERALS
 ---------------------------------------------------------------------------*/

#define DIRECTION_XTASK_TO_CPU          1
#define DIRECTION_CPU_TO_XTASK          2


/*---------------------------------------------------------------------------
                            TYPES / CLASSES
 ---------------------------------------------------------------------------*/

/* IO Interface for Xtasks */
struct XtaskArgs{
	RMuint8   *data;
	RMuint32   size;
#ifdef USE_RPC_TIMEOUT
	RMuint32   timeout_us;	// Optional timeout register
#endif
};



/*---------------------------------------------------------------------------
                         FUNCTIONS PROTOTYPES
 ---------------------------------------------------------------------------*/

RMstatus xtask_pull_args( struct gbus* pgbus, struct XtaskFIFO* fifo, struct XtaskArgs* inArgs );
RMstatus xtask_push_args( struct gbus* pgbus, struct XtaskFIFO *fifo, struct XtaskArgs* outArgs );


#endif
