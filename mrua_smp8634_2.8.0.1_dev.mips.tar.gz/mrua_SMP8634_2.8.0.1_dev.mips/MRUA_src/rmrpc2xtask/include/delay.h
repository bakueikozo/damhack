#ifndef __DELAY_H___
#define __DELAY_H__

#include "rmdef/rmdef.h"

/* DELAY Method:
 *
 *  Assumes that the inner loop will take 2 cycles
 *    - 1 for conditional check
 *    - 1 for the increment.
 *
 *    Be careful.  This delay has potential overflow problems depending
 *    on the frequency of the CPU, ...  It is recommended to not exceed
 *    1000000 for the input argument (x) => 1 second worth of delay.
 */
#define DELAY_US(x) delay_us(x);
#define DELAY_MS(x)    DELAY_US((x*1000));

void delay_set_cpu_freq_mhz(RMuint32 freq);
void delay_us(RMuint32 period_us);

#endif

