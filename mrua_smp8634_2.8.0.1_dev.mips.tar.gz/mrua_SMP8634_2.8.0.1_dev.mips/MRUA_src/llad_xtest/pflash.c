/*****************************************
 Copyright (c) 2003-2004
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/*
 * pflash.c 
 */
#include <string.h>

#ifdef YAMON
#include <stdarg.h>
#include <util.h>
#else
#define ALLOW_OS_CODE 1
#include "../llad/include/gbus.h"
#include "../emhwlib_hal/include/emhwlib_registers.h"
#endif

#include <pflash.h>

/************************************************************************
 *      Definitions
 ************************************************************************/
//for dqx_wait
#define FLASH_WAIT_DIV	2 /* 1 for the board without IORDY lifted, it'll try the full cycle; or more than 1 for others*/

// to enable or disable the debug messages of this source file, put 1 or 0 below
#if 1
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

/*
 * based on CFI (Common Flash Memory Interface) Specification 2.0
 * supports multiple flashes, supports command set 2 (AMD standard)
 *
 * Parallel flash memory base should be remapped address base,
 * no cpu remap register be used inside this program.
 */

#define CFIDEV_INTERLEAVE   1   // paired device. unused (no pair)
#define CFIDEV_DEVTYPE	  2   // type : x8 = 1, x16 = 2, x32 = 4 //==2 (16 bits capable device)

#define CFIDEV_UNLOCK_BYPASS	// Using unlock bypass 

#define PB_cs_config_CS2_8bit	4//PB_cs_config CS2 8/16bit

/************************************************************************
 *  Macro Definitions
*************************************************************************/

// for matching endian between CPU and CFI interface
// CFI and HOST use same endian
#define cpu_to_cfi8(x)				 (x)
#define cfi8_to_cpu(x)				 (x)
#define cpu_to_cfi16(x)				 (x)
#define cfi16_to_cpu(x)				 (x)
#define cpu_to_cfi32(x)				 (x)
#define cfi32_to_cpu(x)				 (x)

/************************************************************************
 *  Public variables
 ************************************************************************/
#define MAXREGIONSIZE 0x20000 //AMD:0x10000, STRARA:0x20000

/************************************************************************
 *  Static variables
 ************************************************************************/

/* Use DQx toggling bit to detect programming status */
/* flash_use_DQX defined when R12 is not on the board, so IORDY disconnected*/
static RMuint8 flash_use_DQX; 

static RMuint32  flash_wait_div = FLASH_WAIT_DIV;

/************************************************************************
 *  Static function prototypes
 ************************************************************************/
#ifdef YAMON
#define gbus_read_remapped_uint8(h,x) gbus_read_uint8(h,sigmaremap(x))
#define gbus_read_remapped_uint16(h,x) gbus_read_uint16(h,sigmaremap(x))
#define gbus_read_remapped_uint32(h,x) gbus_read_uint32(h,sigmaremap(x))
#define gbus_write_remapped_uint8(h,x,y) gbus_write_uint8(h,sigmaremap(x),y)
#define gbus_write_remapped_uint16(h,x,y) gbus_write_uint16(h,sigmaremap(x),y)
#define gbus_write_remapped_uint32(h,x,y) gbus_write_uint32(h,sigmaremap(x),y)
#else
#define gbus_read_remapped_uint8(h,x) gbus_read_uint8(h,x)
#define gbus_read_remapped_uint16(h,x) gbus_read_uint16(h,x)
#define gbus_read_remapped_uint32(h,x) gbus_read_uint32(h,x)
#define gbus_write_remapped_uint8(h,x,y) gbus_write_uint8(h,x,y)
#define gbus_write_remapped_uint16(h,x,y) gbus_write_uint16(h,x,y)
#define gbus_write_remapped_uint32(h,x,y) gbus_write_uint32(h,x,y)
#endif

static void dqx_wait(struct gbus *h, RMuint32 addr, RMuint32 buswidth, RMuint32 datum, RMuint32 wait, void(*cb_usleep)(struct gbus *,RMuint32));

// CFI basic I/O -- base on CFIDEV_BUSWIDTH, read/write data
static RMuint32 cfi_read(struct gbus  *h, RMuint32 addr, RMuint32 bwidth);
static void cfi_write(struct gbus  *h, RMuint32 bwidth, RMuint32 val, RMuint32 addr);

// CFI advanced I/O
//base on CFIDEV_DEVTYPE,CFIDEV_INTERLEAVE
static RMuint32 cfi_build_cmd_addr(RMuint32 addr);
//base on CFIDEV_BUSWIDTH,CFIDEV_INTERLEAVE
static RMuint32 cfi_build_cmd(RMuint32 cmd, RMuint32 bwidth);
static void cfi_send_cmd(struct gbus  *h, RMuint32 bwidth, RMuint32 cmd, RMuint32 cmd_addr, RMuint32 base);

// probing & setup
static RMstatus cfi_probe_chip(struct gbus  *h, cfi_info *pcfi);
static RMstatus cfi_query_present(struct gbus  *h, RMuint32 base, RMuint32 bwidth);
static RMstatus cfi_chip_setup(struct gbus  *h, cfi_info *pcfi);
static void cfi_cmdset_0002(cfi_info *pcfi);

// others
#if (defined _DEBUG) || (defined YAMON)
static char *cfi_get_idname(RMuint32 vendor);
#endif
static RMint32 flash_erase_oneblock(struct gbus *h, cfi_info *pcfi, RMuint32 addr,void(*cb_usleep)(struct gbus *,RMuint32));

static RMstatus flash_writable(struct gbus *h, RMuint32 addr, RMint32 len);
static RMstatus flash_write_onebyte(struct gbus  *h, cfi_info *pcfi, RMuint32 addr, RMuint32 data, void(*cb_usleep)(struct gbus *,RMuint32));
static RMstatus flash_write_data_internal(struct gbus *h, RMuint32 addr, RMuint16 *data, RMint32 nwords, cfi_info *pcfi, void(*cb_usleep)(struct gbus*,RMuint32));

static void flash_list(cfi_info *pcfi);

/************************************************************************
 *      Implementation : Public functions
 ************************************************************************/

/******************************************
* RMstatus flash_init(struct gbus *h, cfi_info *pcfi, RMuint32 gbus_addr, RMuint32 buswidth, RMuint8 dq56mark, RMbool disp)
*
* Description :
* Initialization parallel flash  
* This function will modify CPU_remap4 register.
* Only one parallel flash can be use at same time.
*
* Input parameters:
* pcfi: Pointer to parallel flash structure;
* gbus_addr: Parallel flash address;
* buswidth: Parallel flash bus width, 8 or 16;
*
* Return values:
* RMstatus 
******************************************/
RMstatus flash_init(struct gbus *h, cfi_info *pcfi, RMuint32 gbus_addr, RMuint32 buswidth, RMuint8 dq56mark, RMbool disp)
{
	RMint32 ret;
	RMint32 data;

	if ( (buswidth == CFIDEV_BUSWIDTH_8) || (buswidth == CFIDEV_BUSWIDTH_16) ) {
		pcfi->buswidth = buswidth; 

		data = gbus_read_uint32(h,REG_BASE_host_interface + PB_CS_config);
		if( (buswidth == CFIDEV_BUSWIDTH_8) && ((data & PB_cs_config_CS2_8bit)==0) ) {
			data |= PB_cs_config_CS2_8bit;
			gbus_write_uint32(h,REG_BASE_host_interface + PB_CS_config, data);
		} else if( (buswidth == CFIDEV_BUSWIDTH_16) && ((data & PB_cs_config_CS2_8bit)!=0) ){
			data &= (~PB_cs_config_CS2_8bit);
			gbus_write_uint32(h,REG_BASE_host_interface + PB_CS_config, data);
		}
	} else
		return RM_ERROR;

	flash_use_DQX = dq56mark;

#if (RMARCHID==RMARCHID_MIPS)
	if(disp)
		RMDBGLOG((ENABLE,"CPU_remap4 map to 0x%08lx\n",gbus_addr));
	gbus_write_uint32(h, REG_BASE_cpu_block + CPU_remap4, gbus_addr);
#endif
	pcfi->gbus_address = gbus_addr;

	if ((ret = cfi_probe_chip(h, pcfi)) != RM_OK) {
		RMDBGLOG((LOCALDBG,"flash does not exist at address 0x%08x, bus width 0x%x\n", pcfi->gbus_address, pcfi->buswidth));
		return RM_ERROR;
	}

	if(disp)
		flash_list(pcfi);

	pcfi->exist = 1;

	return RM_OK;
}

/******************************************
* RMstatus flash_erase_chip(struct gbus *h,  cfi_info *pcfi, void(*cb_usleep)(struct gbus*, RMuint32))
*
* Description :
* Erase specified parallel flash chip
*
* Input parameters:
* pcfi: Pointer to parallel flash structure
*
* Return values:
* OK: operation successful; 
* fail: error message
******************************************/
RMstatus flash_erase_chip(struct gbus *h,  cfi_info *pcfi, void(*cb_usleep)(struct gbus*, RMuint32))
{
	if (!pcfi->exist)
		return RM_NOT_FOUND;

	cfi_send_cmd(h, pcfi->buswidth, 0xaa, pcfi->addr_unlock1, pcfi->gbus_address);
	cfi_send_cmd(h, pcfi->buswidth, 0x55, pcfi->addr_unlock2, pcfi->gbus_address);
	cfi_send_cmd(h, pcfi->buswidth, 0x80, pcfi->addr_unlock1, pcfi->gbus_address);
	cfi_send_cmd(h, pcfi->buswidth, 0xaa, pcfi->addr_unlock1, pcfi->gbus_address);
	cfi_send_cmd(h, pcfi->buswidth, 0x55, pcfi->addr_unlock2, pcfi->gbus_address);
	cfi_send_cmd(h, pcfi->buswidth, 0x10, pcfi->addr_unlock1, pcfi->gbus_address);

	if ( flash_use_DQX ) {
		if (pcfi->ident.timeout_chip_erase != 0)
			dqx_wait(h, pcfi->gbus_address, pcfi->buswidth, 0xff, 1000*(1<<pcfi->ident.timeout_chip_erase), cb_usleep);
		else 
			dqx_wait(h, pcfi->gbus_address, pcfi->buswidth, 0xff, 1000*40, cb_usleep); //40ms
	} else {
		if (pcfi->ident.timeout_chip_erase != 0)
			(*cb_usleep)(h, 1000*(1<<pcfi->ident.max_timeout_chip_erase)*(1<<pcfi->ident.timeout_chip_erase));
		else {
			RMint32 j, delay = 0;
			for (j = 0; j < pcfi->ident.num_erase_regions; ++j) 
				delay += pcfi->erase_regions[j].blocks;

			RMDBGPRINT((LOCALDBG,"Please wait %d ms...\n",delay*(1<<pcfi->ident.timeout_block_erase)));
			(*cb_usleep)(h, 1000*delay*(1<<pcfi->ident.timeout_block_erase));
		}
	}
	
	if ((cfi_read(h, pcfi->gbus_address, pcfi->buswidth) & 0xff) != 0xff) {
		RMDBGPRINT((LOCALDBG," erase chip fail.\n"));
		return RM_ERROR;
	}

	return RM_OK;
}

/******************************************
* RMstatus flash_erase_region(struct gbus *h, cfi_info *pcfi, RMuint32 addroffs, RMuint32 length, void(*cb_usleep)(struct gbus*, RMuint32))
*
* Description :
* Erase a region of specified parallel flash chip 
*
* Input parameters:
* pcfi: Pointer to parallel flash structure
* addroffs: start offset address of parallel flash erase region  (0 - pflash size)
* length: erase length
*
* Return values:
* OK: operation successful; 
* fail: error message
******************************************/
RMstatus flash_erase_region(struct gbus *h, cfi_info *pcfi, RMuint32 addroffs, RMuint32 length, void(*cb_usleep)(struct gbus*, RMuint32))
{
	RMuint32 start, blocksize;

	if (length == 0)
		return RM_OK;
	if (!pcfi->exist)
		return RM_NOT_FOUND;

	if (flash_calcblock(h, pcfi, addroffs, &start, &blocksize) < 0)
		return RM_NOT_FOUND;

	do {
		//RMDBGLOG((LOCALDBG,"erasing offset 0x%08lx (%dbytes)\n",start,blocksize));
		flash_erase_oneblock(h, pcfi, start + pcfi->gbus_address, cb_usleep);

		start += blocksize;
		if (flash_calcblock(h, pcfi, start, &start, &blocksize) < 0)
			break;
	} while (start < addroffs + length);

	return RM_OK;
}

static RMuint8 savebuf[MAXREGIONSIZE];
RMstatus flash_save_erase_region(struct gbus *h,cfi_info *pcfi,RMuint32 addroffs, RMuint32 length,void(*cb_usleep)(struct gbus*,RMuint32))
{
	RMuint32 start, blocksize;
	RMuint32 wraddr,wrlen;

	if (length == 0)
		return RM_OK;
	if (!pcfi->exist)
		return RM_NOT_FOUND;

	if (flash_calcblock(h, pcfi, addroffs, &start, &blocksize) < 0)
		return RM_NOT_FOUND;

	do {
		wraddr = addroffs - start;
		wrlen = (length <= blocksize - wraddr ? length : blocksize - wraddr );
		if(addroffs > start || length < blocksize) {
			//read & save first
			if (blocksize > MAXREGIONSIZE) {
				RMDBGPRINT((LOCALDBG,"Please increase save buffer size!!\n"));
				return !RM_OK;
			}

			flash_read_data(h, pcfi, start, savebuf, blocksize);
			memset( &savebuf[wraddr], 0xff, wrlen);

			if( flash_erase_oneblock(h, pcfi, start + pcfi->gbus_address, cb_usleep) != RM_OK)
				return RM_ERROR;

			if( flash_write_data(h, pcfi, start, savebuf, blocksize, cb_usleep) != RM_OK)
				return RM_ERROR;
		} else {
			//just erase
			if( flash_erase_oneblock(h, pcfi, start + pcfi->gbus_address, cb_usleep) != RM_OK)
				return RM_ERROR;
		}

		start += blocksize;
		if (flash_calcblock(h, pcfi, start, &start, &blocksize) < 0)
			break;

		addroffs += wrlen;
		length -= wrlen;

	} while (start < addroffs + length);

	return RM_OK;
}

// read / writing (suppose 16 bits writing)
/******************************************
* RMint32 flash_read_data(struct gbus  *h, cfi_info *pcfi, RMuint32 addroffs, void *data, RMuint32 length)
*
* Description :
* Read a region of specified parallel flash chip 
*
* Input parameters:
* pcfi: Pointer to parallel flash structure
* addroffs: start offset address of parallel flash read region  (0 - pflash size)
* *data: destination address of read data
* length: read length
*
* Return values:
* OK: operation successful; 
* fail: error message
******************************************/
RMstatus flash_read_data(struct gbus  *h, cfi_info *pcfi, RMuint32 addroffs, void *data, RMuint32 length)
{
	RMuint32 ii;

	if (!pcfi->exist)
		return RM_NOT_FOUND;

	if( (addroffs & 0x3) != ((RMuint32)data & 0x3) ) {
		for (ii = 0; ii < length; ii++) {
			*(RMuint8 *)(data + ii) = gbus_read_remapped_uint8(h, pcfi->gbus_address + addroffs + ii );
		}
	} else {
		while (addroffs & 0x3) {
			*(RMuint8 *)(data++) = gbus_read_remapped_uint8(h, pcfi->gbus_address + addroffs);
			addroffs++; 
			length--;
		}

		for (ii = 0; ii < (length-3); ii+=4, data+=4) {
			*(RMuint32 *)data = gbus_read_remapped_uint32(h, pcfi->gbus_address + addroffs) ;
			addroffs+=4; 
		}

		while ((length & 0x3) > 0) {
			*(RMuint8 *)(data++) = gbus_read_remapped_uint8(h, pcfi->gbus_address + addroffs);
			addroffs++;
			length--;
		}
	}

	return RM_OK;
}

/******************************************
* RMstatus flash_write_data(struct gbus *h,  cfi_info *pcfi, RMuint32 addroffs, RMuint8 *data, RMuint32 length, void(*cb_usleep)(struct gbus*, RMuint32))
*
* Description :
* Write a region of specified parallel flash chip 
*
* Input parameters:
* pcfi: Pointer to parallel flash structure
* addroffs: start offset address of parallel flash write region  (0 - pflash size)
* *data: source address of write data
* length: write length
*
* Return values:
* OK: operation successful; 
* fail: error message
******************************************/
#define UNLOCKBYPASSPROGRAM_UNITBITS	12	  // 2^12 = 4KB
RMstatus flash_write_data(struct gbus *h,  cfi_info *pcfi, RMuint32 addroffs, RMuint8 *data, RMuint32 length, void(*cb_usleep)(struct gbus*, RMuint32))
{
	RMint32 len = length;
	RMint32 maxbufwords, nwords;
	RMuint32 addr = addroffs + pcfi->gbus_address;
	RMstatus rc; 
	RMint32 prtloop=0;

	if (!pcfi->exist)
		return RM_NOT_FOUND;

	rc = flash_writable(h, addr, len);
	if( rc != RM_OK)
		return rc ;

	if (addr & 0x01) {
		rc = flash_write_onebyte(h, pcfi, addr++, *data++, cb_usleep);
		if( rc != RM_OK)
			return rc ;
		--len;
	}

	if (pcfi->ident.max_multibyte_write == 0)
		maxbufwords = 1 << (UNLOCKBYPASSPROGRAM_UNITBITS - 1);
	else 
		maxbufwords = 1 << (pcfi->ident.max_multibyte_write - 1);

	//prints '.' after this block is written, 0x1000
	RMDBGPRINT((LOCALDBG,"."));
	while (len > 1) {
		//RMDBGPRINT((LOCALDBG,"$"));

		nwords = (len >> 1); //((len + 1) >> 1);
		if (nwords > maxbufwords)
			nwords = maxbufwords;

		rc = flash_write_data_internal(h, addr, (RMuint16 *) data, nwords, pcfi, cb_usleep);
		if( rc != RM_OK)
			return rc ;

		nwords <<= 1;
		addr += nwords;
		data += nwords;
		len -= nwords;

		prtloop += nwords;
		if(prtloop >= 0x800) {
			RMDBGPRINT((LOCALDBG,"."));
			prtloop -= 0x800;
		}
	}

	if (len == 1) {
		rc = flash_write_onebyte(h, pcfi, addr, *data, cb_usleep);
		if( rc != RM_OK)
			return rc ;
	}

	return RM_OK;
}

RMstatus flash_save_write_data(struct gbus *h, cfi_info *pcfi, RMuint32 addroffs, RMuint32 ramaddr, RMuint32 length, void(*cb_usleep)(struct gbus*, RMuint32))
{
	RMuint32 start, blocksize;
	RMuint32 wraddr,wrlen;
	RMuint32 prtloop=0;

	if (length == 0)
		return RM_OK;
	if (!pcfi->exist)
		return RM_NOT_FOUND;

	if( flash_writable(h, pcfi->gbus_address + addroffs, length) == RM_OK) {
		if( flash_write_data(h, pcfi, addroffs, (RMuint8 *)ramaddr, length, cb_usleep) != RM_OK)
			return RM_ERROR;
		else 
			return RM_OK;
	}

	// need erase first
	if (flash_calcblock(h, pcfi, addroffs, &start, &blocksize) < 0)
		return RM_NOT_FOUND;

	do {
		if (blocksize > MAXREGIONSIZE) {
			RMDBGPRINT((LOCALDBG,"Please increase save buffer size!!\n"));
			return !RM_OK;
		}

		flash_read_data(h, pcfi, start, savebuf, blocksize);
		wraddr = addroffs - start;
		wrlen = (length <= blocksize - wraddr ? length : blocksize - wraddr );
		memcpy( &savebuf[wraddr], (RMuint8 *)ramaddr, wrlen);

		if( flash_erase_oneblock(h, pcfi, start + pcfi->gbus_address, cb_usleep) != RM_OK)
			return RM_ERROR;

		if( flash_write_data(h, pcfi, start, savebuf, blocksize, cb_usleep) != RM_OK)
			return RM_ERROR;

		start += blocksize;
		if (flash_calcblock(h, pcfi, start, &start, &blocksize) < 0)
			break;

		ramaddr += wrlen;
		addroffs += wrlen;
		length -= wrlen;

		prtloop += blocksize;
		if(prtloop >= 0x40000) {
			RMDBGPRINT((LOCALDBG,"\n"));
			prtloop -= 0x40000;
		}

	} while (start < addroffs + length);

	return RM_OK;
}

/******************************************
* RMint32 flash_calcblock(struct gbus *h, cfi_info *pcfi, RMuint32 addroffs, RMuint32 *pstart, RMuint32 *plen)
*
* Description :
* Calculate the block start address and length of parallel flash at given address offset
* It can be used to calculate the block address and length that will be erased.
*
* Input parameters:
* pcfi: Pointer to parallel flash structure
* addroffs: offset address of parallel flash 
* *pstart: point to block start address
* *plen: point to block length
*
* Return values:
* OK: operation successful; 
* fail: error message
******************************************/
RMint32 flash_calcblock(struct gbus *h, cfi_info *pcfi, RMuint32 addroffs, RMuint32 *pstart, RMuint32 *plen)
{
	RMint32 i;

	if (!pcfi->exist)
		return RM_NOT_FOUND;

	*pstart = 0;
	*plen = 0;

	for (i = pcfi->ident.num_erase_regions - 1; i >= 0; --i) {
		if (addroffs >= pcfi->erase_regions[i].start) {
			*pstart = pcfi->erase_regions[i].start;
			*plen = pcfi->erase_regions[i].size;
			addroffs -= *pstart;
			while (addroffs >= *plen) {
				addroffs -= *plen;
				*pstart += *plen;
			}
			return 0;
		}
	}

	return -1;
}

/************************************************************************
 *  Implementation : Static functions
 ************************************************************************/
static void dqx_wait(struct gbus *h, RMuint32 addr, RMuint32 buswidth, RMuint32 datum, RMuint32 wait, void(*cb_usleep)(struct gbus *,RMuint32))
{
	RMuint32 dq6, dq5;
	RMuint32 status, oldstatus, res;
	unsigned int waitloop=0;

	dq6 = cfi_build_cmd(1<<6,buswidth);
	dq5 = cfi_build_cmd(1<<5,buswidth);

	(*cb_usleep)(h,wait);

	oldstatus = cfi_read(h,addr,buswidth);
	status = cfi_read(h,addr,buswidth);

	if((buswidth==CFIDEV_BUSWIDTH_16) && (datum==0xff)) {
		oldstatus &= 0xff;
		status &= 0xff;
	}

	if (flash_wait_div <= 1) 
		res = wait;
	else
		res = wait/flash_wait_div;

	while ((status != datum) || 
		(((status & dq6) != (oldstatus & dq6)) && ((status & dq5) != dq5))) {
		(*cb_usleep)(h,res);

		oldstatus = cfi_read(h,addr,buswidth);
		status = cfi_read(h,addr,buswidth);
		if(waitloop==5) {
			RMDBGPRINT((LOCALDBG,"pflash write/erase timeout fails.\n"));
			break;
		} else {
			RMDBGPRINT((LOCALDBG,"*"));
			waitloop++;
		}
	}
}

//
// CFI basic I/O
//

static RMuint32 cfi_read(struct gbus  *h,  RMuint32 addr, RMuint32 bwidth)
{
	RMuint32 data;

	switch (bwidth) {
	case CFIDEV_BUSWIDTH_8 : 
		data = gbus_read_remapped_uint8(h, addr);
		break;
	case CFIDEV_BUSWIDTH_16 : 
		data = gbus_read_remapped_uint16(h, addr);
		break;
	case CFIDEV_BUSWIDTH_32 :
		data = gbus_read_remapped_uint32(h, addr);
		break;
	default :
		return 0;
	}

	RMDBGLOG((DISABLE,"FLASH Read addr = 0x%x, data = 0x%x\n", addr, data));

	return data;
}

static void cfi_write(struct gbus  *h, RMuint32 bwidth, RMuint32 val, RMuint32 addr)
{
	RMDBGLOG((DISABLE,"FLASH Write addr = %08lx, data = 0x%x\n", addr, val));

	switch (bwidth) { 
	case CFIDEV_BUSWIDTH_8 : 
		gbus_write_remapped_uint8(h, addr, val);
		break;
	case CFIDEV_BUSWIDTH_16 : 
		gbus_write_remapped_uint16(h, addr, val);
		break;
	case CFIDEV_BUSWIDTH_32 :
		gbus_write_remapped_uint32(h, addr, val);
		break;
	default :
		return;
	}
}

// 
// CFI advanced I/O
//

// bus width address => byte address
static RMuint32 cfi_build_cmd_addr(RMuint32 addr)
{
	return addr * CFIDEV_DEVTYPE * CFIDEV_INTERLEAVE;
}

static RMuint32 cfi_build_cmd(RMuint32 cmd, RMuint32 bwidth)
{
	RMuint32 val = 0;

	switch (bwidth) {
	case CFIDEV_BUSWIDTH_8 : 
		val = cmd;
		break;

	case CFIDEV_BUSWIDTH_16 : 
		if (CFIDEV_INTERLEAVE == 1)
			val = cpu_to_cfi16(cmd);
		else if (CFIDEV_INTERLEAVE == 2)
			val = cpu_to_cfi16((cmd << 8) | cmd);
		break;

	case CFIDEV_BUSWIDTH_32 : 
		if (CFIDEV_INTERLEAVE == 1)
			val = cpu_to_cfi32(cmd);
		else if (CFIDEV_INTERLEAVE == 2)
			val = cpu_to_cfi32((cmd << 16) | cmd);
		else if (CFIDEV_INTERLEAVE == 4) {
			val = (cmd << 16) | cmd;
			val = cpu_to_cfi32((val << 8) | val);
		}
		break;

	default :
		break;
	}

	return val;
}

static void cfi_send_cmd(struct gbus  *h, RMuint32 bwidth, RMuint32 cmd, RMuint32 cmd_addr, RMuint32 base)
{
	cfi_write(h, bwidth, cfi_build_cmd(cmd,bwidth), base + cmd_addr);
}

//
// probing & setup
// 

static RMstatus cfi_probe_chip(struct gbus  *h, cfi_info *pcfi)
{
	RMint32 ret;
	RMuint32 addr_probe1, addr_probe2;
	RMuint32 data_probe1, data_probe2;

	addr_probe1 = pcfi->gbus_address + cfi_build_cmd_addr(0);
	addr_probe2 = pcfi->gbus_address + cfi_build_cmd_addr(0x55);

	data_probe1 = cfi_read(h,  addr_probe1, pcfi->buswidth);
	data_probe2 = cfi_read(h,  addr_probe2, pcfi->buswidth);

	// Reset
	cfi_send_cmd(h, pcfi->buswidth, 0xf0, 0, pcfi->gbus_address);

	// Enter CFI Query mode
	cfi_send_cmd(h, pcfi->buswidth, 0x98, cfi_build_cmd_addr(0x55), pcfi->gbus_address);

	if ((ret = cfi_query_present(h, pcfi->gbus_address, pcfi->buswidth)) != RM_OK) {
		cfi_write(h, pcfi->buswidth, data_probe1, addr_probe1);
		cfi_write(h, pcfi->buswidth, data_probe2, addr_probe2);
		return ret;
	}

	if ((ret = cfi_chip_setup(h, pcfi)) != RM_OK)
		return ret;

	// Reset
	cfi_send_cmd(h, pcfi->buswidth, 0xf0, 0, pcfi->gbus_address);

	// internal settings: command set 0002
	if (pcfi->ident.primary_id == 0x2)
		cfi_cmdset_0002(pcfi);

	return RM_OK;
}

static RMstatus cfi_query_present(struct gbus  *h, RMuint32 base, RMuint32 bwidth)
{
	RMuint32 c1=cfi_read(h,  base + cfi_build_cmd_addr(0x10), bwidth) == cfi_build_cmd('Q',bwidth),
	c2=cfi_read(h,  base + cfi_build_cmd_addr(0x11), bwidth) == cfi_build_cmd('R',bwidth),
	c3=cfi_read(h,  base + cfi_build_cmd_addr(0x12), bwidth) == cfi_build_cmd('Y',bwidth);

	// garbled by sdio --- force true
	return  (c1&c2&c3) ? RM_OK:RM_NOT_FOUND;
}

static RMstatus cfi_chip_setup(struct gbus  *h, cfi_info *pcfi)
{
	RMuint32 i;
	RMuint32 num_erase_regions = cfi_read(h,  pcfi->gbus_address + cfi_build_cmd_addr(0x2c), pcfi->buswidth);
	RMuint32 start;

	if (num_erase_regions == 0)
		return RM_NOT_SUPPORTED;

	for (i = 0; i < (sizeof pcfi->ident) - (sizeof pcfi->ident.erase_region_info) + (num_erase_regions * 4); ++i) {
		((RMuint8 *) &pcfi->ident)[i] = cfi_read(h,  pcfi->gbus_address + cfi_build_cmd_addr(0x10 + i), pcfi->buswidth);
	}
	//((RMuint8 *) &pcfi->ident)[0]='Q';
	//((RMuint8 *) &pcfi->ident)[1]='R';

	if (pcfi->ident.primary_id != 0x2) /* Not using command set 0002 */
		RMDBGLOG((LOCALDBG,"warning: not using command set 0002\n"));

	for (i = 0, start = 0; i < num_erase_regions; ++i) {
		pcfi->erase_regions[i].start = start;
		pcfi->erase_regions[i].size = 0x100 * ((pcfi->ident.erase_region_info[i] >> 16) & 0xffff);
		pcfi->erase_regions[i].blocks = (pcfi->ident.erase_region_info[i] & 0xffff) + 1;
		start += pcfi->erase_regions[i].size * pcfi->erase_regions[i].blocks;
	}

	pcfi->size = 1 << pcfi->ident.device_size;

	return RM_OK;
}

static void cfi_cmdset_0002(cfi_info *pcfi)
{
	switch (CFIDEV_DEVTYPE) {
	case 1 : 
		pcfi->addr_unlock1 = 0x555;
		pcfi->addr_unlock2 = 0x2aa;
		break;
	case 2 : 
		pcfi->addr_unlock1 = 0xaaa;
		if (pcfi->buswidth == CFIDEV_BUSWIDTH_8)
			pcfi->addr_unlock2 = 0x555;
		else //(CFIDEV_BUSWIDTH_16 )
			pcfi->addr_unlock2 = 0x554;
		break;
	case 4 :
		pcfi->addr_unlock1 = 0x1555;
		pcfi->addr_unlock2 = 0xaaa;
		break;
	}
}

//other
static RMint32 flash_erase_oneblock(struct gbus *h, cfi_info *pcfi, RMuint32 addr,void(*cb_usleep)(struct gbus *,RMuint32))
{
	cfi_send_cmd(h, pcfi->buswidth, 0xaa, pcfi->addr_unlock1, pcfi->gbus_address);
	cfi_send_cmd(h, pcfi->buswidth, 0x55, pcfi->addr_unlock2, pcfi->gbus_address);
	cfi_send_cmd(h, pcfi->buswidth, 0x80, pcfi->addr_unlock1, pcfi->gbus_address);
	cfi_send_cmd(h, pcfi->buswidth, 0xaa, pcfi->addr_unlock1, pcfi->gbus_address);
	cfi_send_cmd(h, pcfi->buswidth, 0x55, pcfi->addr_unlock2, pcfi->gbus_address);
	cfi_send_cmd(h, pcfi->buswidth, 0x30, addr - pcfi->gbus_address, pcfi->gbus_address);

	if ( flash_use_DQX )
		dqx_wait(h, addr, pcfi->buswidth, 0xff, 1000*(1<<pcfi->ident.timeout_block_erase), cb_usleep);
	else {
		if(pcfi->ident.timeout_block_erase > 0)
			(*cb_usleep)(h,1000*(1 << pcfi->ident.timeout_block_erase)); 
		else //not support pcfi->ident.timeout_block_erase. 
			(*cb_usleep)(h,2*1000*1000); // 2 sec
	}

	if ((cfi_read(h, addr, pcfi->buswidth) & 0xff) != 0xff)
		return RM_ERROR;
	
	return RM_OK;
}

// writing :suppose 16 bits writing

static RMstatus flash_writable(struct gbus *h, RMuint32 addr, RMint32 len)
{
	RMint32 i;

	while (addr & 0x3) {
		if ( gbus_read_remapped_uint8(h, addr++) != 0xff) {
			RMDBGLOG((DISABLE,"Unwritable: 0x%x = 0x%x\n",addr-1,gbus_read_remapped_uint8(h, addr-1)));
			return RM_ERROR;
		}
		--len;
	}

	for (i = 0; i < (len-3); i+=4, addr+=4) {
		if ( gbus_read_remapped_uint32(h, addr) != 0xffffffff) {
			RMDBGLOG((DISABLE,"Unwritable: 0x%x = 0x%x\n",addr,gbus_read_remapped_uint32(h, addr)));
			return RM_ERROR;
		}
	}

	while ((len & 0x3) > 0) {
		if ( gbus_read_remapped_uint8(h, addr++) != 0xff) {
			RMDBGLOG((DISABLE,"Unwritable: 0x%x = 0x%x\n",addr-1,gbus_read_remapped_uint8(h, addr-1)));
			return RM_ERROR;
		}
		--len;
	}

	return RM_OK;
}

static RMstatus flash_write_onebyte(struct gbus  *h, cfi_info *pcfi, RMuint32 addr, RMuint32 data, void(*cb_usleep)(struct gbus *,RMuint32))
{
	RMuint32 curdata;
	RMuint32 olddata=0, newaddr=0, newdata=0;

	if(pcfi->buswidth == CFIDEV_BUSWIDTH_8) {
		newaddr = addr;
		olddata = curdata = cfi_read(h,  newaddr, pcfi->buswidth);
		newdata = data;
	} else if (pcfi->buswidth == CFIDEV_BUSWIDTH_16) {
		newaddr = addr & ~0x01;
		curdata = cfi_read(h,  newaddr, pcfi->buswidth);

		if (addr & 0x01) {
			olddata = (curdata & 0xff00) >> 8;
			newdata = (curdata & 0x00ff) | ((data & 0xff) << 8);
		} else {
			olddata = (curdata & 0x00ff);
			newdata = (curdata & 0xff00) | (data & 0xff);
		}
	}

	if (~olddata & data) 
		return RM_ERROR;

	cfi_send_cmd(h, pcfi->buswidth, 0xaa, pcfi->addr_unlock1, pcfi->gbus_address);
	cfi_send_cmd(h, pcfi->buswidth, 0x55, pcfi->addr_unlock2, pcfi->gbus_address);
	cfi_send_cmd(h, pcfi->buswidth, 0xa0, pcfi->addr_unlock1, pcfi->gbus_address);
	cfi_write(h, pcfi->buswidth, newdata, newaddr);

	if( flash_use_DQX )
		dqx_wait(h, newaddr, pcfi->buswidth, newdata, 1<<pcfi->ident.timeout_single_write, cb_usleep);
	else 
		(*cb_usleep)(h, 1 << pcfi->ident.timeout_single_write);

	if (cfi_read(h, newaddr, pcfi->buswidth) != newdata)
		return RM_ERROR;

	return RM_OK;
}

static RMstatus flash_write_data_internal(struct gbus *h, RMuint32 addr, RMuint16 *data, RMint32 nwords, cfi_info *pcfi, void(*cb_usleep)(struct gbus*,RMuint32))
{
	RMint32 i;

#ifdef CFIDEV_UNLOCK_BYPASS
	cfi_send_cmd(h, pcfi->buswidth, 0xaa, pcfi->addr_unlock1, pcfi->gbus_address);
	cfi_send_cmd(h, pcfi->buswidth, 0x55, pcfi->addr_unlock2, pcfi->gbus_address);
	cfi_send_cmd(h, pcfi->buswidth, 0x20, pcfi->addr_unlock1, pcfi->gbus_address);

	if (pcfi->buswidth == CFIDEV_BUSWIDTH_8) {

		for (i = 0; i < (nwords << 1); ++i) {
			cfi_send_cmd(h, pcfi->buswidth, 0xa0, 0, pcfi->gbus_address);
			cfi_write(h, pcfi->buswidth, ((RMuint8 *) data)[i], addr + i);
			if(flash_use_DQX) 
				dqx_wait(h, addr + i, pcfi->buswidth, ((unsigned char *)data)[i], 1<<pcfi->ident.timeout_single_write, cb_usleep);
			else 
				(*cb_usleep)(h, (1<<pcfi->ident.timeout_single_write));

			if (cfi_read(h, addr + i, pcfi->buswidth) != ((unsigned char *)data)[i])
				return RM_ERROR;
		}
	} else if (pcfi->buswidth == CFIDEV_BUSWIDTH_16) {
		for (i = 0; i < nwords; ++i) {
			cfi_send_cmd(h, pcfi->buswidth, 0xa0, 0, pcfi->gbus_address);
			cfi_write(h, pcfi->buswidth, data[i], addr + (i << 1));
			if(flash_use_DQX) 
				dqx_wait(h, addr + (i<<1), pcfi->buswidth, data[i], 1<<pcfi->ident.timeout_single_write, cb_usleep);
			else 
				(*cb_usleep)(h, (1<<pcfi->ident.timeout_single_write));

			if (cfi_read(h, addr + (i<<1), pcfi->buswidth) != data[i])
				return RM_ERROR;
		}
	}

	cfi_send_cmd(h, pcfi->buswidth, 0x90, 0, pcfi->gbus_address);
	cfi_send_cmd(h, pcfi->buswidth, 0x00, 0, pcfi->gbus_address);

#else //CFIDEV_UNLOCK_BYPASS
	if (pcfi->buswidth == CFIDEV_BUSWIDTH_8) {
		for (i = 0; i < (nwords << 1); ++i) {
			cfi_send_cmd(h, pcfi->buswidth, 0xaa, pcfi->addr_unlock1, pcfi->gbus_address);
			cfi_send_cmd(h, pcfi->buswidth, 0x55, pcfi->addr_unlock2, pcfi->gbus_address);
			cfi_send_cmd(h, pcfi->buswidth, 0xa0, pcfi->addr_unlock1, pcfi->gbus_address);
			cfi_write(h, pcfi->buswidth, ((RMuint8 *) data)[i], addr + i);

			if(flash_use_DQX) 
				dqx_wait(h, addr + i, pcfi->buswidth, ((unsigned char *)data)[i], 1<<pcfi->ident.timeout_single_write, cb_usleep);
			else 
				(*cb_usleep)(h, (1<<pcfi->ident.timeout_single_write));

			if (cfi_read(h, addr + i, pcfi->buswidth) != ((unsigned char *)data)[i])
				return RM_ERROR;
		}
	} else if (pcfi->buswidth == CFIDEV_BUSWIDTH_16) {
		for (i = 0; i < nwords; ++i) {
			cfi_send_cmd(h, pcfi->buswidth, 0xaa, pcfi->addr_unlock1, pcfi->gbus_address);
			cfi_send_cmd(h, pcfi->buswidth, 0x55, pcfi->addr_unlock2, pcfi->gbus_address);
			cfi_send_cmd(h, pcfi->buswidth, 0xa0, pcfi->addr_unlock1, pcfi->gbus_address);
			cfi_write(h, pcfi->buswidth, data[i], addr + (i << 1));

			if(flash_use_DQX)
				dqx_wait(h, addr + (i<<1), pcfi->buswidth, ((unsigned char *)data)[i], 1<<pcfi->ident.timeout_single_write, cb_usleep);
			else 
				(*cb_usleep)(h, (1<<pcfi->ident.timeout_single_write));
			
			if (cfi_read(h, addr + (i<<1), pcfi->buswidth) != ((unsigned char *)data)[i])
				return RM_ERROR;
		}
	}
#endif //CFIDEV_UNLOCK_BYPASS

	return RM_OK;
}

//
// miscellaneous
//
#if (defined _DEBUG) || (defined YAMON)
static char *cfi_get_idname(RMuint32 vendor)
{
	switch (vendor) {
	case CFI_PRIMARY_ID_NULL :
		return "None";
	case CFI_PRIMARY_ID_INTEL_EXT :
		return "Intel/Sharp Extended";
	case CFI_PRIMARY_ID_AMD_STD :
		return "AMD/Fujitsu Standard";
	case CFI_PRIMARY_ID_INTEL_STD :
		return "Intel/Sharp Standard";
	case CFI_PRIMARY_ID_AMD_EXT :
		return "AMD/Fujitsu Extended";
	case CFI_PRIMARY_ID_MITSUBISHI_STD :
		return "Mitsubishi Standard";
	case CFI_PRIMARY_ID_MITSUBISHI_EXT :
		return "Mitsubishi Extended";
	case CFI_PRIMARY_ID_SST :
		return "Page Write Command Set";
	case CFI_PRIMARY_ID_RESERVED :
		return "Not Allowed / Reserved for Future Use";

	default:
		return "Unknown";
	}
}
#endif

static void flash_list(cfi_info *pcfi)
{
	RMint32 j;

	RMDBGLOG((ENABLE,"Parallel Flash address: 0x%x, bus width: %d\n", pcfi->gbus_address, pcfi->buswidth));
	RMDBGLOG((ENABLE,"  ID : %s\n", cfi_get_idname(pcfi->ident.primary_id)));
	RMDBGLOG((ENABLE,"  Size : %d KB (0x%x)\n", pcfi->size >> 10, pcfi->size)); 
	RMDBGLOG((ENABLE,"  Buffer Size : %d\n", pcfi->ident.max_multibyte_write));
	RMDBGLOG((ENABLE,"  Regions : %d\n", pcfi->ident.num_erase_regions));
	for (j = 0; j < pcfi->ident.num_erase_regions; ++j) {
		RMDBGLOG((ENABLE,"	%d : 0x%x - 0x%x * 0x%x\n", j, pcfi->erase_regions[j].start, pcfi->erase_regions[j].size,
		pcfi->erase_regions[j].blocks));
	}
#if 0
	RMDBGLOG((ENABLE,"\n"));
	RMDBGLOG((ENABLE,"  timeout_single_write(typical*max)(us) : "));
	if(pcfi->ident.timeout_single_write)
		RMDBGLOG((ENABLE,"%d * %d\n", 1<<pcfi->ident.timeout_single_write, 1<<pcfi->ident.max_timeout_single_write));
	else
		RMDBGLOG((ENABLE,"not supported\n"));

	RMDBGLOG((ENABLE,"  timeout_block_erase(typical*max)(ms) : "));
	if(pcfi->ident.timeout_block_erase)
		RMDBGLOG((ENABLE,"%d * %d\n", 1<<pcfi->ident.timeout_block_erase, 1<<pcfi->ident.max_timeout_block_erase));
	else
		RMDBGLOG((ENABLE,"not supported\n"));

	RMDBGLOG((ENABLE,"  timeout_chip_erase(typical*max)(ms) : "));
	if(pcfi->ident.timeout_chip_erase)
		RMDBGLOG((ENABLE,"%d * %d\n", 1<<pcfi->ident.timeout_chip_erase, 1<<pcfi->ident.max_timeout_chip_erase));
	else
		RMDBGLOG((ENABLE,"not supported\n"));
#endif
}

#ifdef YAMON 
//emdbg.c
#define RM_MAX_STRING 512

extern int vsprintf(char *buf, const char *fmt, va_list ap);

#ifndef RMDBGLOG_implementation
void RMDBGLOG_implementation(RMbool active,const RMascii *filename,RMint32 line,const RMascii *text,...)
{  
	if (active) {
		va_list ap;
		char str[RM_MAX_STRING];
		
		//snprintf((char *)str,RM_MAX_STRING,"[%s:%ld] ",(char *)filename,line);
		va_start(ap, text);
		//vsnprintf((char *)(str+strlen(str)), RM_MAX_STRING-strlen(str), text, ap); 
		vsprintf((char *)(str), text, ap); 
		va_end(ap);
				
		//fprintf(stderr,str);
		emprintk("%s",str);
	}
}
#endif // RMDBGLOG_implementation

#ifndef RMDBGPRINT_implementation
void RMDBGPRINT_implementation(RMbool active,const RMascii *filename,RMint32 line,const RMascii *text,...)
{
	if (active) {
		va_list ap;
		char str[RM_MAX_STRING];
		
		va_start(ap, text);
		//vsnprintf((char *)str,RM_MAX_STRING,text,ap); 
		vsprintf((char *)str,text,ap); 
		va_end(ap);
		
		//fprintf(stderr,str);
		emprintk("%s",str);
	}
}
#endif // RMDBGPRINT_implementation
#endif

