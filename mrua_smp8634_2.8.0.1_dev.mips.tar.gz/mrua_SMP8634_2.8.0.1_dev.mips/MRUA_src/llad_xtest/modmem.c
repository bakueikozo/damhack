/*****************************************
 Copyright � 2004-2005
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE 1
#include "../llad/include/gbus.h"
#include "../emhwlib_hal/include/emhwlib_registers.h"
#include "../emhwlib/include/emhwlib_dram.h"
#include "../emhwlib/include/emhwlib_versions.h"
#include "../gbuslib/include/gbus_fifo.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "getargs.h"

#define RM_MAX_STRING 1024

#define PAGE_SIZE 4096
#define MRK 0x7d4

static void check(struct gbus *pgbus,RMuint32 *ref_buf,RMuint32 *i,RMuint32 start,RMuint32 size)
{
	RMuint32 cur_buf[PAGE_SIZE/4];
	RMuint32 cur;
	RMbool matches=1;

	RMDBGLOG((ENABLE,"checking [%p..%p[\n",start,start+size));
	
	for (cur=start;cur<start+size;cur+=PAGE_SIZE) {
		RMuint32 offset;
		
		//RMDBGLOG((ENABLE,"reading %p\n",cur));
		ref_buf[MRK/4]=(*i)++;
		gbus_read_data32(pgbus,cur,cur_buf,PAGE_SIZE/4);

		for (offset=0;offset<PAGE_SIZE/4;offset++) {
			if (matches) {
				if (cur_buf[offset]!=ref_buf[offset]) {
					RMDBGLOG((ENABLE,"!!!!!!!!!!! [%p..",cur+offset*4));
					matches=0;
				}
			}
			else {
				if (cur_buf[offset]==ref_buf[offset]) {
					RMDBGPRINT((ENABLE,"%p[\n",cur+offset*4));
					matches=1;
				}
			}
		}
	}

	if (matches==0)
		RMDBGPRINT((ENABLE,"%p[\n",cur));
}

int main(int argc,char **argv) 
{
	int rc=-1;

	RMascii device[RM_MAX_STRING];

	RMuint32 ref_addr;
	RMuint32 ref_buf[PAGE_SIZE/4];
	RMuint32 i=0;

	struct llad *pllad;
	struct gbus *pgbus;

	CheckArgCount (argc, 1, 1, argv, 
		       "<ref_addr>\n\n"
		       "Report modifications on all 8630 mem areas against <ref_addr>.\n"
		       "\n[version " EMHWLIB_VERSION_S "]"
		       );

	GetDeviceServer(argv, device, RM_MAX_STRING);
	pllad = llad_open(device);
	if (pllad == NULL) {
		fprintf(stderr, "unable to access device\n");
		return -1;
	}

	ref_addr = GetUL(argv[1], 4, argv, "<ref_addr>");
	
	pgbus = gbus_open(pllad);

	gbus_read_data32(pgbus,ref_addr,ref_buf,PAGE_SIZE/4);

	{
		volatile memcfg_t *pm=(memcfg_t *)(MEM_BASE_dram_controller_0+FM_MEMCFG);
		{
			RMuint32 dram0_size=gbus_read_uint32(pgbus,(RMuint32)&pm->dram0_size);
			check(pgbus,ref_buf,&i,MEM_BASE_dram_controller_0,dram0_size);
		}
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2) && (EM86XX_REVISION>=4)
		{
			RMuint32 dram1_size=gbus_read_uint32(pgbus,(RMuint32)&pm->dram1_size);
			check(pgbus,ref_buf,&i,MEM_BASE_dram_controller_1,dram1_size);
		}
#endif
	}
	check(pgbus,ref_buf,&i,REG_BASE_cpu_block,CPU_LOCALRAM_SIZE);
	check(pgbus,ref_buf,&i,PMEM_BASE_mpeg_engine_0,MPEG_PM_SIZE);

	// cannot check this way. check(pgbus,ref_buf,&i,DMEM_BASE_mpeg_engine_0,MPEG_DM_SIZE);
	RMDBGLOG((ENABLE,"not checking %p\n",DMEM_BASE_mpeg_engine_0));
	i+=MPEG_DM_SIZE/PAGE_SIZE;

#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2) && (EM86XX_REVISION>=4)
	check(pgbus,ref_buf,&i,PMEM_BASE_mpeg_engine_1,MPEG_PM_SIZE);

	// cannot check this way. check(pgbus,ref_buf,&i,DMEM_BASE_mpeg_engine_0,MPEG_DM_SIZE);
	RMDBGLOG((ENABLE,"not checking %p\n",DMEM_BASE_mpeg_engine_1));
	i+=MPEG_DM_SIZE/PAGE_SIZE;
#endif

	check(pgbus,ref_buf,&i,PMEM_BASE_demux_engine,DEMUX_PM_SIZE);
	check(pgbus,ref_buf,&i,DMEM_BASE_demux_engine,DEMUX_DM_SIZE);
	check(pgbus,ref_buf,&i,PMEM_BASE_audio_engine_0,AUDIO_PM_SIZE);
	check(pgbus,ref_buf,&i,DMEM_BASE_audio_engine_0,AUDIO_DM_SIZE);

#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2) && (EM86XX_REVISION>=4)
	check(pgbus,ref_buf,&i,PMEM_BASE_audio_engine_1,AUDIO_PM_SIZE);
	check(pgbus,ref_buf,&i,DMEM_BASE_audio_engine_1,AUDIO_DM_SIZE);
#endif

	gbus_close(pgbus);
	llad_close(pllad);
	
	return rc;
}
