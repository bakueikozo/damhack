/*****************************************
 Copyright � 2004-2005
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE 1
#include "../llad/include/gbus.h"
#include "../emhwlib_hal/include/emhwlib_registers.h"
#include "../emhwlib/include/emhwlib_versions.h"
#include "../gbuslib/include/gbus_fifo.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <sched.h>

#include "getargs.h"

#define RM_MAX_STRING 1024

int main(int argc,char **argv) 
{
	int rc=-1;

	RMascii device[RM_MAX_STRING];

	struct llad *pllad;
	struct gbus *pgbus;

	CheckArgCount (argc, 3, 3, argv, 
		       "<fifo_addr> <data_addr> <data_size>\n\n"
		       "\n"
		       "as a shortcut: <data_addr>=0 is same as <fifo_addr>+sizeof(struct gbus_fifo)\n"
		       "(data immediately follow the struct gbus_fifo).\n"
		       "\n"
		       "Termination on stdin EOF\n"
		       "\n[version " EMHWLIB_VERSION_S "]"
		       );

	GetDeviceServer(argv, device, RM_MAX_STRING);
	pllad = llad_open(device);
	if (pllad == NULL) {
		fprintf(stderr, "unable to access device\n");
		return -1;
	}

	pgbus = gbus_open(pllad);
	
	{
		RMuint32 fifo_addr=GetUL(argv[1], 4, argv, "<fifo_addr>"),
			data_addr=GetUL(argv[2], 4, argv, "<data_addr>"),
			data_size=GetUL(argv[3], 4, argv, "<data_size>");

		if (data_addr==0) {
			data_addr=fifo_addr+sizeof(struct gbus_fifo);
			printf("data_addr is 0x%08lx then.\n",data_addr);
		}
		
		gbus_fifo_open(pgbus,data_addr,data_size,fifo_addr);
		rc=0;
	}
	
	gbus_close(pgbus);
	llad_close(pllad);
	
	return rc;
}
