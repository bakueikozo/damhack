#include "getargs.h"

#include <stdio.h>
#include <stdlib.h>

char *strcpy(char *dest, const char *src);

void CheckArgCount (int argc, int min, int max, char* argv[], char* usage) 
{
	if ((argc - 1 < min) || (argc - 1 > max)) {
		fprintf(stderr, "Usage: %s %s\n", argv[0], usage);
		exit(1);
	}
}

unsigned long GetUL (char* arg, int align, char* argv[], char* usage) 
{
	unsigned long address;
	char *error_pos;
	
	address = strtoul(arg, &error_pos, 0);
	if (error_pos[0] != '\0') {
		fprintf(stderr, "Error: %s: %s must be decimal, octal or hexadecimal number\n", argv[0], usage);
		exit(1);
	}
	if ((address%align) != 0) {
		fprintf(stderr, "%s: Error: %s must be multiple of %d\n", argv[0], usage, align);
		exit(1);
	}
	
	return address;
}

void GetDeviceServer(char *argv[], char *server, int maxsize)
{
	char *env_str;

	if (server == NULL)
		return;
	
	env_str = getenv("EM8XXX_SERVER");

	if (env_str == NULL) {
#ifdef _REMOTE_
		fprintf(stderr, "Error: %s: the environment variable %s must be set for remote access.\n"
			"Syntax: %s=machine.address or %s=machine.address:device_index\n", 
			argv[0], "EM8XXX_SERVER", "EM8XXX_SERVER", "EM8XXX_SERVER");
		exit(1);
#endif // _REMOTE_

#ifdef _LOCAL_
		fprintf(stderr, "Warning: %s: environment variable %s not set. Using device 0\n", argv[0], "EM8XXX_SERVER");
		strcpy(server, "0");
#endif //_LOCAL_
	}
	else {
#ifdef _REMOTE_
		strcpy(server, env_str);
#endif // _REMOTE_

#ifdef _LOCAL_
		if (env_str[0] != ':') {
			fprintf(stderr, "Error: %s: the environment variable %s not set correctly for local access.\n"
				"Syntax: %s=:device_index\n", argv[0], "EM8XXX_SERVER", "EM8XXX_SERVER");
			
			exit(1);
		}
		else {
			strcpy(server, env_str + 1);
		}
#endif // _LOCAL_
	}
}
	
	
