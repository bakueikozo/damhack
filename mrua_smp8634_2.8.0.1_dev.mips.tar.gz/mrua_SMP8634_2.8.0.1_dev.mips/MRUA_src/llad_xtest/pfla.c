/*****************************************
 Copyright � 2004-2005
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE 1
#include "../llad/include/gbus.h"
#include "../emhwlib_hal/include/emhwlib_registers.h"
#include "../emhwlib/include/emhwlib_versions.h"

#include "pflash.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#include "getargs.h"

#define RM_MAX_STRING 1024
#define PFLA_MAX_SIZE 0x20000//(128*1024)

#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
#define PB_CS0_OFFSET 0x00000000
#define PB_CS1_OFFSET 0x04000000
#define PB_CS2_OFFSET 0x08000000
#define PB_CS3_OFFSET 0x0c000000
#else

#if (EM86XX_CHIP<EM86XX_CHIPID_TANGO3) //sc 07may22 to compile xrpc for tango3.
#define PB_CS0_OFFSET 0x04000000
#define PB_CS1_OFFSET 0x05000000
#define PB_CS2_OFFSET 0x06000000
#define PB_CS3_OFFSET 0x07000000
#endif

#endif

static RMbool quickturn_clock=0;

#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
static const RMuint32 fl_mask = 0xfc000000;
#else
static const RMuint32 fl_mask = 0xff000000;
#endif

//callback function
static void flash_cb_usleep_at_least(struct gbus *h, RMuint32 usec)
{
    RMuint32 start, end;

	if( quickturn_clock ) {
		if(usec>=1000)
			usleep(usec);
	}
	else { //em86xx_usleep
		start = gbus_read_uint32(h, REG_BASE_system_block + SYS_xtal_in_cnt);
		end = start + (usec * 27);

		if (end > start)
			while (gbus_read_uint32(h, REG_BASE_system_block + SYS_xtal_in_cnt) < end);
		else {
			while (gbus_read_uint32(h, REG_BASE_system_block + SYS_xtal_in_cnt) > start);
			while (gbus_read_uint32(h, REG_BASE_system_block + SYS_xtal_in_cnt) < end);
		}
	}
}

int main(int argc,char **argv) 
{
	RMstatus rc = RM_OK;
	RMascii device[RM_MAX_STRING];
	RMascii *command;
	struct llad *pllad;
	struct gbus *pgbus;
	RMuint32 flash_buswidth = CFIDEV_BUSWIDTH_8;
	RMuint8 dq56mk;
	cfi_info F;
	RMint32 i;

	CheckArgCount (argc, 1, 5, argv, 
		"clear all [<gbus_addr>] [-q|16] | clear <gbus_addr>|<offset> <len> [-q|16] | \n write <gbus_addr>|<offset> img.bin [-q|16] | read <gbus_addr>|<offset> <len> [-16]\n"
		"\n[version " EMHWLIB_VERSION_S "]"
		);
	command=argv[1];

	GetDeviceServer(argv, device, RM_MAX_STRING);
	pllad = llad_open(device);
	if (pllad == NULL) {
		fprintf(stderr, "unable to access device\n");
		return -1;
	}

	pgbus = gbus_open(pllad);
	if (pgbus == NULL) {
		fprintf(stderr, "unable to access device\n");
		llad_close(pllad);
		return -1;
	}

	for(i=0; i<argc; i++) {
		if (argv[i][0]=='-') {
			if((argv[i][1]=='q'))
				quickturn_clock = 1;
			else if((argv[i][1]=='1') && (argv[i][2]=='6'))
				flash_buswidth = 16;
		}
	}

	dq56mk=1;

	if (strcmp(command,"clear")==0) {
		if (strcmp(argv[2],"all")==0) {
			RMuint32 addr=0;
			if (argv[3])
				addr = GetUL(argv[3], 1, argv, "<address>");
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
			if( quickturn_clock && (flash_buswidth==16)) //for palladium
				dq56mk=0;
#endif
			if ((addr & fl_mask) == 0)
				rc = flash_init(pgbus,&F, MEM_BASE_host_interface+PB_CS2_OFFSET, flash_buswidth, dq56mk, TRUE); 
			else
				rc = flash_init(pgbus,&F, addr&fl_mask, flash_buswidth, dq56mk, TRUE); 

			if ( rc != RM_OK) {
				fprintf(stderr, "flash not found at 0x%x, bus-width %d\n",
						(int)addr, (int)flash_buswidth);
				goto handled;
			}
 
			rc = flash_erase_chip(pgbus,&F,flash_cb_usleep_at_least);
			if (  rc == RM_OK )
				printf("clearall OK (0x%08lx).\n", addr);
			else
				printf("clearall falied (0x%08lx).\n", addr);

		} else {
			RMuint32 addr=0, save_addr=0;
			RMuint32 length = 0x20;

			if (argv[2])
				save_addr = addr = GetUL(argv[2], 1, argv, "<address>");
			if (argv[3])
				length = GetUL(argv[3], 1, argv, "<length>");

#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
			if( quickturn_clock && (flash_buswidth==16)) //for palladium
				dq56mk=0;
#endif

			if ((addr & fl_mask) == 0)
				rc = flash_init(pgbus,&F,MEM_BASE_host_interface+PB_CS2_OFFSET, flash_buswidth, dq56mk, TRUE); 
			else
				rc = flash_init(pgbus,&F, addr&fl_mask, flash_buswidth, dq56mk, TRUE); 
			addr &= (~fl_mask);

			if ( rc != RM_OK) {
				fprintf(stderr, "flash not found at 0x%x, bus-width %d\n",
						(int)save_addr,(int)flash_buswidth);
				goto handled;
			}
			rc = flash_save_erase_region(pgbus,&F,addr,length,flash_cb_usleep_at_least);

			if ( rc != RM_OK) {
				printf("\nclear 0x%08x, length 0x%x fail\n",(int)save_addr,(int)length);
				fprintf(stderr,"clear fails\n");
				return rc;
			}	
				
			printf("\nclear 0x%08x, length 0x%x OK\n",(int)save_addr,(int)length);

		}
		goto handled;
	}

	if (strcmp(command,"write")==0)  {
		RMint32 fd;
		RMascii buf[PFLA_MAX_SIZE];
		RMint32 offset, readtotal;
		RMint32 loop=0;

		RMuint32 addr = GetUL(argv[2], 1, argv, "<address>");
		RMuint32 save_addr = addr;
		
		if (strcmp(argv[3],"-")==0)
			fd=0; // stdin
		else {
			fd=open(argv[3],O_RDONLY|O_LARGEFILE);
			
			if (fd==-1) {
				fprintf(stderr,"cannot open %s\n",argv[3]);
				rc = RM_ERROR;
				goto handled;
			}
		}
		
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
		if( quickturn_clock && (flash_buswidth==16)) //for palladium
			dq56mk=0;
#endif

		if ((addr & fl_mask) == 0)
			rc = flash_init(pgbus,&F, MEM_BASE_host_interface+PB_CS2_OFFSET, flash_buswidth, dq56mk, TRUE); 
		else
			rc = flash_init(pgbus,&F, addr&fl_mask, flash_buswidth, dq56mk, TRUE); 
		addr &= (~fl_mask);

		if ( rc != RM_OK) {
			fprintf(stderr, "flash not found at 0x%x, bus-width %d\n",
					(int)save_addr,(int)flash_buswidth);
			goto handled;
		}
		offset=0;
		readtotal=0;
		while (1) {
			RMint32 x=read(fd,buf,PFLA_MAX_SIZE);
			if (x==0) break;

			rc = flash_save_write_data(pgbus,&F,addr+offset,(RMuint32)buf,x,flash_cb_usleep_at_least);

			if ( rc != RM_OK) {
				printf("\nwrite data fail at 0x%08lx - 0x%08lx\n",save_addr+offset, x+save_addr+offset);
				fprintf(stderr,"write fails\n");
				goto handled;
			}	
			
			if((loop++) & 0x1)
				printf("\n");

			readtotal += x;
			offset += x;
		}
		
		printf("\nwriting %d(0x%x) bytes at 0x%08lx\n",(int)readtotal,(int)readtotal,save_addr);
		close(fd);

		goto handled;
	}

	if (strcmp(command,"read")==0) { 
		RMuint32 ii;
		RMuint32 addr=0, save_addr=0;
		RMuint32 length = 0x20;
		RMuint8 data[4];

		if (argv[2])
			save_addr = addr = GetUL(argv[2], 1, argv, "<address>");
		if (argv[3])
			length = GetUL(argv[3], 1, argv, "<length>");

#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
		if( quickturn_clock && (flash_buswidth==16)) //for palladium
			dq56mk=0;
#endif

		if ((addr & fl_mask) == 0)
			rc = flash_init(pgbus,&F, MEM_BASE_host_interface+PB_CS2_OFFSET, flash_buswidth, dq56mk, TRUE); 
		else
			rc = flash_init(pgbus,&F, addr&fl_mask, flash_buswidth, dq56mk, TRUE); 
		addr &= (~fl_mask);

		if ( rc != RM_OK) {
			fprintf(stderr, "flash not found at 0x%x, bus-width %d\n",
					(int)save_addr,(int)flash_buswidth);
			goto handled;
		}

		printf("addr=0x%lx, length=0x%lx\n", F.gbus_address + addr, length);
		for (ii = 0; ii < length; ii+=4) {
			if ( ii%16 == 0)
				printf("0x%08x :  ", (int)(F.gbus_address + addr + ii ));

			flash_read_data(pgbus,&F, addr+ii, data, 4);
			printf("%02x %02x %02x %02x ",*data, *(data+1), *(data+2), *(data+3) );

			if ((ii+4)%16 == 0)
				printf("\n");
		}
		printf("\n");

		goto handled;
	}

	fprintf(stderr,"unknown command\n");

 handled:
	gbus_close(pgbus);
	llad_close(pllad);
	
	return (rc==RM_OK)?0:-1;
}

