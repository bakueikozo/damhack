/*****************************************
 Copyright � 2004-2005
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE 1
#include "../llad/include/gbus.h"

#include "../emhwlib_hal/include/emhwlib_registers.h"
#include "../emhwlib/include/emhwlib_dram.h"
#include "../emhwlib_hal/include/emhwlib_lram.h"
#include "../emhwlib/include/emhwlib_event.h"
#include "../emhwlib/include/emhwlib_versions.h"

#if (EM86XX_CHIP<EM86XX_CHIPID_TANGO3) //sc 07may22
#include "../xos/include/xos_xrpc.h"
#else
// hack.
#define LR_XPU_STAGE 0x1ffc
#include "../xos/include2/xos2_xrpc.h"
#endif

#include "../emhwlib/include/emhwlib_chipspecific.h"

#include "../rua/emhwlib_kernel/include/em8xxx_uk.h"

#define ac_G3r (1<<31)
#define ac_G3w (1<<30)
#define ac_G2r (1<<29)
#define ac_G2w (1<<28)
#define ac_G1r (1<<27)
#define ac_G1w (1<<26)
#define ac_G0r (1<<25)
#define ac_G0w (1<<24)
#define ac_D3r (1<<23)
#define ac_D3w (1<<22)
#define ac_D2r (1<<21)
#define ac_D2w (1<<20)
#define ac_D1r (1<<19)
#define ac_D1w (1<<18)
#define PMEM_BASE_xpu_block 0x400000

#define ac_Gr   (ac_G3r|ac_G2r|ac_G1r|ac_G0r)
#define ac_Grw  (ac_G3w|ac_G2w|ac_G1w|ac_G0w|ac_Gr)

#if (EM86XX_CHIP<EM86XX_CHIPID_TANGO3)
#define ac_Dr   (ac_D3r|ac_D2r|ac_D1r)
#define ac_Drw  (ac_D3w|ac_D2w|ac_D1w|ac_Dr)
#else
#define ac_D0r (1<<17)
#define ac_D0w (1<<16)

#define ac_Dr   (ac_D3r|ac_D2r|ac_D1r|ac_D0r)
#define ac_Drw  (ac_D3w|ac_D2w|ac_D1w|ac_D0w|ac_Dr)
#endif

/* memory protection */
#define dc_mem_access_0 0xff80
#define dc_mem_access_1 0xff84
#define dc_mem_access_2 0xff88
#define dc_mem_access_3 0xff8c
#define dc_mem_access_4 0xff90 /* only for dram */
#define dc_mem_access_5 0xff94 /* only for dram */

#define dc_reg_access_0 0xffc0
#define dc_reg_access_1 0xffc4
#define dc_reg_access_2 0xffc8 /* only for dram controller regs and xpu regs */
#define dc_reg_access_3 0xffcc /* only for xpu regs */
#define dc_reg_access_4 0xffd0 /* only for xpu regs */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

#include "getargs.h"

// to enable or disable the debug messages of this source file, put 1 or 0 below
#if 1
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

#define RM_MAX_STRING 1024
#define RMasciiToUInt32(str,value) do { *(value)=strtoul(str,NULL,0); } while (0)

#if (EM86XX_CHIP<EM86XX_CHIPID_TANGO3) //sc 07may22
#define xrpc_xload_pbusopen_ES4 xrpc_xload_pbusopen
#define xrpc_xload_formatall_ES4 xrpc_xload_formatall
#include "xrpc_xload_pbusopen_ES4.h"
#include "xrpc_xload_formatall_ES4.h"
#else
// hack: naming is inconsistent. Wrong files under /utils/signed_items?
#define xrpc_pbusopen_8644_ES1_dev_000a xrpc_xload_pbusopen
#define xrpc_formatall_8644_ES1_dev_000a xrpc_xload_formatall
#include "xrpc_pbusopen_8644_ES1_dev_000a.h"
#include "xrpc_formatall_8644_ES1_dev_000a.h"
#endif

#if (EM86XX_MODE != EM86XX_MODEID_WITHHOST)
static void stop_ethernet(struct gbus *pgbus);
static void stop_ethernet(struct gbus *pgbus)
{
	gbus_write_uint32(pgbus,REG_BASE_host_interface+0x7018,0); /* ENET_DMA_CR = 0 */
	gbus_write_uint32(pgbus,REG_BASE_host_interface+0x701c,0); /* ENET_DMA_IER = 0 */
	gbus_write_uint32(pgbus,REG_BASE_host_interface+0x7014,
			gbus_read_uint32(pgbus,REG_BASE_host_interface+0x7014)); /* ENET_DMA_SR */
}

static void stop_pci_host(struct gbus *pgbus);
static void stop_pci_host(struct gbus *pgbus)
{
	/* set arbitration to IDLE mode */
	gbus_write_uint32(pgbus,REG_BASE_host_interface+PCI_host_reg4, 1);
}

static void stop_usb(struct gbus *pgbus);
static void stop_usb(struct gbus *pgbus)
{
	RMuint32 ehci_cmd, ohci_ctl;

	ehci_cmd = gbus_read_uint32(pgbus,REG_BASE_host_interface+0x1410); /* EHCI_CMD */
	ehci_cmd &= ~1; /* ~CMD_RUN */
	gbus_write_uint32(pgbus,REG_BASE_host_interface+0x1410,ehci_cmd);

	ohci_ctl = gbus_read_uint32(pgbus,REG_BASE_host_interface+0x1504); /* OHCI_CTRL */
	gbus_write_uint32(pgbus,REG_BASE_host_interface+0x1504,ohci_ctl|(3<<6)); /* HCCONTROL_HCFS */
	gbus_write_uint32(pgbus,REG_BASE_host_interface+0x1514,1<<31); /* OHCI_INTR_MIE */
}
#endif

int gbus_write_file(	RMuint8 *base,	char *filename);
int gbus_write_file(	RMuint8 *base,	char *filename)
{
	int fd,size=0,i=0;
	
	fd=open(filename, O_RDONLY|O_LARGEFILE);
	if (fd<0) {
		perror("");
		return -1;
	}
	
	// portable way to get a file's size
	size=lseek(fd,0,SEEK_END);
	if (size>XRPC_MAXSIZE) {
		fprintf(stderr,"exceeds usable memory range...\n");
		return -1;
	}
	
	lseek(fd,0,SEEK_SET);
	
	while (1) {
		RMuint8 s[4];
		
		if (read(fd,&s,4)!=4) {
			perror("");
			return -1;
		}
		
		*base=s[0];
		base++;
		*base=s[1];
		base++;
		*base=s[2];
		base++;
		*base=s[3];
		base++;
		
		i+=4;
		if (i==size) break;
	}
	
	close(fd);
	
	return size;
}

static void printprot(RMuint32 v)
{
	RMint32 relevant=v&(ac_Grw|ac_Drw);
	
	/* shortcuts */

	if (relevant==0) {
		printf(" denied\n"); // no one can access even xpu. Used for hw with looping effect (end of dram)
		return;
	}
	
	if (relevant==(ac_Grw|ac_Drw)) {
		printf(" noprot\n"); // not protected at all
		return;
	}
	
	if (relevant==ac_Grw) {
		printf(" nogprot\n"); // not protected from gbus access
		return;
	}

	if (relevant==(ac_G0r|ac_G0w)) {
		printf(" xpurwonly\n");
		return;
	}

	/* in full... */
	
#undef DO
#define DO(i)					\
	do {					\
		if (v&i) {			\
			printf(" "#i);		\
		}				\
	} while (0)

	DO(ac_G3r);
	DO(ac_G3w);
	DO(ac_G2r);
	DO(ac_G2w);
	DO(ac_G1r);
	DO(ac_G1w);
	DO(ac_G0r);
	DO(ac_G0w);
	DO(ac_D3r);
	DO(ac_D3w);
	DO(ac_D2r);
	DO(ac_D2w);
	DO(ac_D1r);
	DO(ac_D1w);
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO3) 
	DO(ac_D0r);
	DO(ac_D0w);

	/*
	  minor bug here:
	  on blocks where D0r / D0w does not make sense, but where bits16/17 are relevant as address,
	  you get a spurious indication:
	  [0x00160000,0x00174564[ is ac_G2r ac_D0w
	 */
#endif
	
	printf("\n");
}

int main(int argc,char **argv) 
{
	RMstatus rc=RM_ERROR;
	RMascii device[RM_MAX_STRING];
	struct llad *pllad;
	struct gbus *pgbus;
	RMuint8 revid;
#if (EM86XX_MODE != EM86XX_MODEID_WITHHOST)
	RMascii *xrpc_bin = NULL;
	RMint32 kill_eth = 0, kill_pci = 0, kill_usb = 0;
#endif
	
	CheckArgCount (argc, 1, 6, argv,
		        "<see details below>\n\n"
		        "<xrpc.bin>           Run provided xrpc\n"
		        "\n"
		        "xtask/ucode:\n"
		        " -xload <*.xload>\n"
		        " -xunload <image> <xload_size> <unload.xload>\n"
		        "           (<xload_size> is ignored, only here for backward compatibility)\n"
		        "\n"
		        " -xstart <image> <a0> <a1> <a2> <a3>\n"
		        "                     Start an xtask instance from this image, returns pid\n"
		        " -xkill <tid> <val>  Signal a xtask. <val>=-1 causes immediate termination\n"
		        "\n"
		        " -ustart <image> <target>\n"
		        "                     Start ucode image <image> on dsp <target> (0 mpeg0 / 1 mpeg1 / 2 audio0 / 3 audio1 / 4 demux)\n"
		        " -ukill <tid> <val>  Signal a ucode. <val>=-1 causes immediate termination, other soft reset\n"
		        "\n"
		        "binding:\n"
		        " -xbind <*.xload>\n"
		        "\n"
		        "other:\n"
		        " -bc                 Bonding comment (dev/prod)\n"
		        " -v                  Display xos SHA-1\n"
		        " -V                  Display xos version (xos>=Mcc only)\n"
		        " -s                  Display serial#\n"
		        " -d                  Dump protection registers\n"
		        " -b <certtype>       Dump certificate binding for type <certtype>\n"
		        " -o <sector>         Dump sector owner\n"
			" -e <ign> 22 21 0 0  Enhanced security mode (shown parameters are the xos defaults)\n"
#if (EM86XX_MODE == EM86XX_MODEID_WITHHOST)
		        " -r                  Soft reboot\n"
#endif
		        " -c                  Cache dump (debug builds only)\n"
		        " -a <address>        Directly at address\n"
		        "sensitive ones:\n"
		        " -P                  pbusopen\n"
		        " -F                  formatall (blank all environment)\n"
		        "other helpers\n"
		        " -f                  unlock xrpc mutex\n"
		        " -u                  unload irq handler\n"
		        " -z                  zero ih api block\n"	       
#if (EM86XX_MODE != EM86XX_MODEID_WITHHOST)
			"stopping DMA operations (only with xrpc.bin)\n"
			" -kp                 stop PCI devices\n"
			" -ku                 stop built-in USB\n"
			" -ke                 stop built-in ethernet\n"
#endif
		        "\n"
		        "xrpc uses the llad dma pool\n"
		        "\n[version " EMHWLIB_VERSION_S "]"
		       );
	
	GetDeviceServer(argv, device, RM_MAX_STRING);

	/*
	  hack

	  we could at least support "1" "2"... but execve call is more complicated,
	  you have to change argv[] to carry -m 1 -m 2...
	 */
	if (strcmp(device,"0")==0) {
		char device_filename[RM_MAX_STRING];
		int fd;

		sprintf(device_filename, "/dev/" EM8XXX_DEVICE_NAME "%s",device);
		printf("open() attempt on %s... ",device_filename);
		
		fd=open(device_filename, O_RDWR);
		if (fd>0) {
			close(fd);
			printf("present\n");

			// successful execve does not return.
			execvp("ruaxrpc",argv);

			fprintf(stderr, "ruaxrpc not in PATH\n");
			return -1;
		}
		else
			printf("absent\n");

	}

	pllad = llad_open(device);
	if (pllad == NULL) {
		return -1;
	}
	
	pgbus = gbus_open(pllad);
	
	revid=gbus_read_uint8(pgbus,REG_BASE_host_interface+PCI_REG1);

#if (EM86XX_CHIP<EM86XX_CHIPID_TANGO3) //sc 07may22
	if ((gbus_read_uint16(pgbus,REG_BASE_host_interface+PCI_REG0)&~0xf)!=0x8630) {
		fprintf(stderr, "for Tango2 only.\n");
		return -1;
	}
#else
	if ((gbus_read_uint16(pgbus,REG_BASE_host_interface+PCI_REG0)&~0xf)!=0x8640) {
		fprintf(stderr, "for Tango3 only.\n");
		return -1;
	}
#endif

#if (EM86XX_MODE != EM86XX_MODEID_WITHHOST)
	{
		int i;
		for (i = 0; i < argc; i++) {
			if (strcmp(argv[i],"-kp")==0)
				kill_pci = 1;
			else if (strcmp(argv[i],"-ke")==0)
				kill_eth = 1;
			else if (strcmp(argv[i],"-ku")==0)
				kill_usb = 1;
			else if (argv[i][0] != '-')
				xrpc_bin = argv[i];
		}
		if (!(kill_pci || kill_eth || kill_usb))
			xrpc_bin = NULL;
	}
#endif
	
	{
		RMuint32 dram_addr;
		RMuint8 *base_addr;
		volatile struct xrpc_block_header *pB;
		
		if (strcmp(argv[1],"-u")==0) {
			printf("unload irq handler...\n");
			gbus_write_uint32(pgbus,REG_BASE_irq_handler_block+CPU_irq_softset,SOFT_IRQ_IH_UNINSTALL);
			rc=RM_OK;
			goto wayout2;
		}
		
		if (strcmp(argv[1],"-f")==0) {
			printf("force unlock xrpc mutex...\n");
			unlock_xrpc(pgbus);
			rc=RM_OK;
			goto wayout2;
		}

		if (strcmp(argv[1],"-z")==0) {
			RMuint32 p;
			
			printf("zero irq handler api...\n");
			for (p=MEM_BASE_dram_controller_0+FM_IRQHANDLER_API;
			     p<MEM_BASE_dram_controller_0+FM_XTASK_API;p+=4) 
				gbus_write_uint32(pgbus,p,0);
			rc=RM_OK;
			goto wayout2;
		}
		
		// you need to use localram.
		if (gbus_read_uint32(pgbus,REG_BASE_cpu_block+G2L_RESET_CONTROL)==3) {
			fprintf(stderr, "cpu in reset 3, but xrpc requires access to local ram\n");
			return -1;
		}

		// you need some dram
		dram_addr=MEM_BASE_dram_controller_0+
			gbus_read_uint32(pgbus,(RMuint32)&((memcfg_t *)(MEM_BASE_dram_controller_0+FM_MEMCFG))->kernel_end);
		
#if (EM86XX_MODE == EM86XX_MODEID_WITHHOST)
		if (gbus_read_uint32(pgbus,REG_BASE_cpu_block+G2L_RESET_CONTROL)==0) {
			printf("!!! running withhost, but 863x cpu is running (YAMON?). Going ahead using 0x%08lx; but I suggest you stop it\n",dram_addr);
		}
#endif	
	
		{
			RMuint32 index,count,offset;

			index=0; // important
			
			
			if (
			    (gbus_lock_area(pgbus, &index,dram_addr,XRPC_MAXSIZE, &count, &offset)!=RM_OK)
			    ||
			    (gbus_get_locked_area(pgbus,dram_addr,XRPC_MAXSIZE,&index,&count,&offset)!=RM_OK)
			    ||
			    ((base_addr=gbus_map_region(pgbus,index,count))==NULL)
			    ) {
				fprintf(stderr,"cannot map\n");
				rc=RM_ERROR;
				goto wayout2;
			}

			base_addr += offset;
		}
		
		printf("[XRPC map ok] dram_addr=0x%08lx base_addr=%p size=%d\n",dram_addr,base_addr,XRPC_MAXSIZE);
		
		pB=(volatile struct xrpc_block_header *)base_addr; /* hack! endianness! e.m. */

		
		if (argv[1][0]!='-') {
			// FIXME: spaghettis
 			if(gbus_write_file(base_addr, argv[1])<0)
				goto wayout;
			
			goto runit;
		} 
#if (EM86XX_MODE != EM86XX_MODEID_WITHHOST)
		else if ((xrpc_bin != NULL) && (kill_pci || kill_eth || kill_usb)) {
			// FIXME: spaghettis
 			if(gbus_write_file(base_addr, xrpc_bin)<0)
				goto wayout;
			
			if (kill_pci)
				stop_pci_host(pgbus);
			if (kill_eth)
				stop_ethernet(pgbus);
			if (kill_usb)
				stop_usb(pgbus);

			usleep(16*125); /* need to wait for 16*125us */

			goto runit;
		}
#endif
		else {
			memset((void *)pB, 0, sizeof(struct xrpc_block_header));
			
			pB->callerid=XRPC_CALLERID_IGNORED;
			pB->headerandblocksize=(sizeof(struct xrpc_block_header)+63)&~63;
			
			if (argc==3) {
 				if ( (strcmp(argv[1],"-xload")==0) || (strcmp(argv[1],"-xbind")==0) ) {
 					RMuint32 size;
 					
 					if((size=gbus_write_file( (RMuint8 *)(pB+1), argv[2]))<0)
 						goto wayout;
					
 					if (strcmp(argv[1],"-xload")==0) 
						pB->xrpcid=XRPC_ID_XLOAD;
					else
						pB->xrpcid=XRPC_ID_XBIND;
					
 					/* ! */
 					if (((*(RMuint32 *)(pB+1))>>24)==XLOAD_SEKID_CLEAR)
 						pB->param0=size-XLOAD_CLEAR_HEADERSIZE;
 					else
 						pB->param0=size-XLOAD_CIPHERED_HEADERSIZE;
 					
 					pB->param1=0; // by putting garbage here, you can crash Maa. Fixed with Mac.
 					pB->param2=0;
 					pB->param3=0;
 					pB->param4=0;
					pB->headerandblocksize=sizeof(struct xrpc_block_header)+size;
 					goto runit;
 				}	
				if (strcmp(argv[1],"-o")==0) {
					RMuint32 arg;

					pB->xrpcid=XRPC_ID_GETOWNER;
					RMasciiToUInt32(argv[2],&arg);
					pB->param0=arg;
 					pB->param1=0; 
 					pB->param2=0;
 					pB->param3=0;
 					pB->param4=0;
					
					pB->headerandblocksize=sizeof(struct xrpc_block_header);
 					goto runit;
				}
				
				if (strcmp(argv[1],"-b")==0) {
					RMuint32 arg;

					pB->xrpcid=XRPC_ID_GETBINDING;
					RMasciiToUInt32(argv[2],&arg);
					pB->param0=arg;
 					pB->param1=0; 
 					pB->param2=0;
 					pB->param3=0;
 					pB->param4=0;
					
					pB->headerandblocksize=sizeof(struct xrpc_block_header);
 					goto runit;
				}
			}

			if (argc==4) {
				if (strcmp(argv[1],"-xkill")==0) {
					RMuint32 arg;
					pB->xrpcid=XRPC_ID_XKILL;
					RMasciiToUInt32(argv[2],&arg);
					pB->param0=arg;
					RMasciiToUInt32(argv[3],&arg);
					pB->param1=arg; 
					goto runit;
				}
				if (strcmp(argv[1],"-ustart")==0) {
					RMuint32 arg;
					pB->xrpcid=XRPC_ID_XSTART;
					RMasciiToUInt32(argv[2],&arg);
					pB->param0=arg+UCODE_ONES;
					RMasciiToUInt32(argv[3],&arg);
					pB->param1=arg;
					goto runit;
				}
				if (strcmp(argv[1],"-ukill")==0) {
					RMuint32 arg;
					pB->xrpcid=XRPC_ID_XKILL;
					RMasciiToUInt32(argv[2],&arg);
					pB->param0=arg+UCODE_ONES;
					RMasciiToUInt32(argv[3],&arg);
					pB->param1=arg;
					goto runit;
				}
			}
			else if (argc==5) {
				if (strcmp(argv[1],"-xunload")==0) {
					RMuint32 arg;
					RMuint32 size;
					
					if((size=gbus_write_file( (RMuint8 *)(pB+1), argv[4]))<0)
						goto wayout;
					
					pB->xrpcid=XRPC_ID_XUNLOAD;
					RMasciiToUInt32(argv[2],&arg);
					pB->param1=arg;
					RMasciiToUInt32(argv[3],&arg);
					pB->param0=arg;
					pB->headerandblocksize=sizeof(struct xrpc_block_header)+size;
					goto runit;
				}
			}
			else if (argc==7) {
				if (strcmp(argv[1],"-xstart")==0) {
					RMuint32 arg;
					pB->xrpcid=XRPC_ID_XSTART;
					RMasciiToUInt32(argv[2],&arg);
					pB->param0=arg;
					RMasciiToUInt32(argv[3],&arg);
					pB->param1=arg;
					RMasciiToUInt32(argv[4],&arg);
					pB->param2=arg;
					RMasciiToUInt32(argv[5],&arg);
					pB->param3=arg;
					RMasciiToUInt32(argv[6],&arg);
					pB->param4=arg;
					goto runit;
				}
				if (strcmp(argv[1],"-e")==0) {
					RMuint32 arg;
					pB->xrpcid=XRPC_ID_SETENHANCEDMODE;
					RMasciiToUInt32(argv[2],&arg);
					pB->param0=arg; /* it is ignored (xos<=Me0) 2007jan16 e.m. */
					RMasciiToUInt32(argv[3],&arg);
					pB->param1=arg;
					RMasciiToUInt32(argv[4],&arg);
					pB->param2=arg;
					RMasciiToUInt32(argv[5],&arg);
					pB->param3=arg;
					RMasciiToUInt32(argv[6],&arg);
					pB->param4=arg;
					goto runit;
				}
			}
			else {
				if (strcmp(argv[1],"-v")==0) {
					pB->xrpcid=XRPC_ID_SHA1XOS;
					if ((rc=doxrpc(pgbus,dram_addr))==RM_OK) {
						printf("xos SHA-1 = %08lx%08lx%08lx%08lx%08lx\n",
						       pB->param4,
						       pB->param3,
						       pB->param2,
						       pB->param1,
						       pB->param0);
					}
					else 
						fprintf(stderr,"xrpc failed\n");
					
					goto wayout;
				}

				if (strcmp(argv[1],"-V")==0) {
					pB->xrpcid=XRPC_ID_VERSION;
					if ((rc=doxrpc(pgbus,dram_addr))==RM_OK) {
						printf("xos Version = %08lx (xos%c%lx)\n",
						       pB->param0,
						       (char) pB->param0>>24,
						       pB->param0&0xFFFFFF);
					}
					else 
						fprintf(stderr,"xrpc failed\n");
					
					goto wayout;
				}
				
				if (strcmp(argv[1],"-s")==0) {
					pB->xrpcid=XRPC_ID_GETSERIAL;
					if ((rc=doxrpc(pgbus,dram_addr))==RM_OK) {
						printf("serial# = %08lx%08lx%08lx%08lx\n",
						       pB->param3,
						       pB->param2,
						       pB->param1,
						       pB->param0);
					}
					else 
						fprintf(stderr,"xrpc failed\n");
					
					goto wayout;
				}

				if (strcmp(argv[1],"-d")==0) {
					RMuint32 last;

					pB->xrpcid=XRPC_ID_GETPROTECTION;

					/*
					  in this dump, the first match is to be understood as
					  the good match.

					  Also: http://mordred/web/bugzilla/show_bug.cgi?id=55
					 */

					printf("\n");
					
#undef DO

#if (EM86XX_CHIP<EM86XX_CHIPID_TANGO3) //sc 07may22

#define DO(i,j)								\
					do {	\
					        RMuint32 cur;			\
									\
						pB->param1=REG_BASE_dram_controller_ ##i+dc_mem_access_ ##j; \
						doxrpc(pgbus,dram_addr); \
						cur=(pB->param0&(ac_D1w-1))<<12; \
						if (cur==0) { \
							printf("(%d) [0x%08lx,...       [ is",j,last); \
							printprot(pB->param0); \
				                } \
					        else { \
							cur+=MEM_BASE_dram_controller_ ##i; \
							        printf("(%d) [0x%08lx,0x%08lx[ (%9lu bytes) is",j,last,cur,cur-last); \
								printprot(pB->param0); \
								last=cur; \
						} \
					} while (0)


#else

#define DO(i,j)								\
					do {	\
					        RMuint32 cur,v=0;		\
									\
						v=gbus_read_uint32(pgbus,REG_BASE_dram_controller_ ##i+dc_mem_access_ ##j); \
						cur=(v&(ac_D0w-1))<<14;	\
						if (cur==0) { \
							RMDBGPRINT((LOCALDBG,"(%d) [0x%08lx,...       [ is",j,last)); \
							printprot(v); \
				                } \
					        else { \
							cur+=MEM_BASE_dram_controller_ ##i; \
								RMDBGPRINT((LOCALDBG,"(%d) [0x%08lx,0x%08lx[ is",j,last,cur)); \
								printprot(v); \
								last=cur; \
						} \
					} while (0)

#endif

					printf("DRAM0 data\n");
					last=MEM_BASE_dram_controller_0;
					DO(0,0);
					DO(0,1);
					DO(0,2);
					DO(0,3);
					DO(0,4);
					DO(0,5);

					printf("DRAM1 data\n");
					last=MEM_BASE_dram_controller_1;
					DO(1,0);
					DO(1,1);
					DO(1,2);
					DO(1,3);
					DO(1,4);
					DO(1,5);
					
#undef DO
#define DO(i,j)								\
					do {	\
					        RMuint32 cur;			\
									\
						pB->param1=REG_BASE_ ##i+dc_mem_access_ ##j; \
						doxrpc(pgbus,dram_addr); \
						cur=pB->param0&(ac_D1w-1); \
						if (cur==0) { \
							printf("(%d) [0x%08lx,...       [ is",j,last); \
							printprot(pB->param0); \
				                } \
					        else { \
							cur+=PMEM_BASE_ ##i; \
							printf("(%d) [0x%08lx,0x%08lx[ (%9lu bytes) is",j,last,cur,cur-last); \
							printprot(pB->param0); \
							last=cur;	\
						} \
					} while (0)

#undef DO2
#define DO2(x) \
					do {				\
						printf(#x " data\n");	\
						last=PMEM_BASE_ ##x;	\
						DO(x,0);		\
						DO(x,1);		\
						DO(x,2);		\
						DO(x,3);		\
					} while (0)

					DO2(mpeg_engine_0);
					DO2(mpeg_engine_1);
					DO2(audio_engine_0);
					DO2(audio_engine_1);
					DO2(demux_engine);
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO3)
					DO2(demux_engine_1);
					DO2(display_block);
#endif
					DO2(xpu_block);

					printf("\n");

#undef DO
#define DO(i,j)								\
					do {	\
					        RMuint32 cur;			\
									\
						pB->param1=REG_BASE_ ##i+dc_reg_access_ ##j; \
						doxrpc(pgbus,dram_addr); \
						cur=pB->param0&(ac_D1w-1); \
						if (cur==0) { \
							printf("(%d) [0x%08lx,...       [ is",j,last); \
							printprot(pB->param0); \
				                } \
					        else { \
							cur+=REG_BASE_ ##i; \
							printf("(%d) [0x%08lx,0x%08lx[ is",j,last,cur); \
							printprot(pB->param0); \
							last=cur;	\
						} \
					} while (0)

#undef DO2
#define DO2(x) \
					do {				\
						printf(#x " regs\n");	\
						last=REG_BASE_ ##x;	\
						DO(x,0);		\
						DO(x,1);		\
						DO(x,2);		\
						DO(x,3);		\
						DO(x,4);		\
					} while (0)

					DO2(system_block);
					/* DO2(host_interface); HAS NONE YET. */
					DO2(dram_controller_0);
					DO2(dram_controller_1);
					DO2(cpu_block);

					DO2(display_block);
					DO2(mpeg_engine_0);
					DO2(mpeg_engine_1);
					DO2(audio_engine_0);
					DO2(audio_engine_1);
					DO2(demux_engine);
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO3)
					DO2(demux_engine_1);
#endif
					DO2(xpu_block);
#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO3)
					DO2(ipu_block);
#endif

					printf("\n");

					goto wayout;
				}

				if (strcmp(argv[1],"-r")==0) {
#if (EM86XX_MODE == EM86XX_MODEID_WITHHOST)
					printf("reboot...\n");
					pB->xrpcid=XRPC_ID_REBOOT;
					goto runit;
#else
					printf("\"-r\" is not supported in standalone mode, ");
					printf("please use \"reboot\" instead.\n");
					goto wayout;
#endif
				}

				if (strcmp(argv[1],"-bc")==0) {
					printf("Bonding Comment\n");
					pB->xrpcid=XRPC_ID_BONDINGCOMMENT;
					pB->param0=0;
 					pB->param1=0; 
 					pB->param2=0;
 					pB->param3=0;
 					pB->param4=0;
					pB->headerandblocksize=sizeof(struct xrpc_block_header);
					goto runit;
				}

				if (strcmp(argv[1],"-c")==0) {
					printf("cache dump... (use xboot/gen/cacha,v scripts)\n");
					pB->xrpcid=XRPC_ID_CACHEDUMP;
					goto runit;
				}	

				if (strcmp(argv[1],"-P")==0) {
					//pB->param0=sizeof(xrpc_xload_pbusopen);
					printf("pbusopen...\n");
					memcpy(base_addr,xrpc_xload_pbusopen,sizeof(xrpc_xload_pbusopen));
					goto runit;
				}
				
				if (strcmp(argv[1],"-F")==0) {
					printf("formatall...\n");
					memcpy(base_addr,xrpc_xload_formatall,sizeof(xrpc_xload_formatall));
					goto runit;
				}
			}
		}
		
		fprintf(stderr,"inconsistent command line\n");
		goto wayout;
	
	runit:

		//printf("pB=0x%x, dram_addr=0x%x\n",(unsigned int)pB,(unsigned int)dram_addr);
		if ((rc=doxrpc(pgbus,dram_addr))==RM_OK) {
			printf("xrpc succeeded\n");
		}
		else {
			fprintf(stderr,
				"xrpc failed (%d) --- if a xtask is using a cipher or if you reboot\n"
				"                 --- xrpc will fail with RM_BUSY\n", rc);
		}
		
		printf("output = %08lx%08lx%08lx%08lx%08lx\n",
		       pB->param4,
		       pB->param3,
		       pB->param2,
		       pB->param1,
		       pB->param0);
		
	wayout:
		{
			RMuint32 index,count,offset;
			RMuint32 i;
			
			gbus_get_locked_area(pgbus, dram_addr, XRPC_MAXSIZE, &index, &count, &offset);

 			for (i=index ; i<index+count ; i++) 
				gbus_unlock_region(pgbus, i);
			
			gbus_unmap_region(pgbus, base_addr, XRPC_MAXSIZE);
		}
		
	wayout2:
		{}
	}
	
	gbus_close(pgbus);
	llad_close(pllad);
	
	return (rc==RM_OK)?0:-1;
}
