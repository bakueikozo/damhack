/*****************************************
 Copyright � 2004-2005
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE 1
#include "../llad/include/gbus.h"
#include "../mbus/include/mbus.h"
#include "../emhwlib_hal/include/emhwlib_registers.h"
#include "../emhwlib/include/emhwlib_versions.h"
#include "../gbuslib/include/gbus_fifo.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <sched.h>
#include <string.h>

#include "getargs.h"

#define RM_MAX_STRING 1024
#define MAX_PCI_COUNT 65532

int main(int argc,char **argv) 
{
	int rc=-1;
	int dowait=0;

	RMascii device[RM_MAX_STRING];

	struct llad *pllad;
	struct gbus *pgbus;

	CheckArgCount (argc, 1, 2, argv, 
		       "<fifo_addr> [-e]\n\n"
		       "Given a 32bit gbus data fifo at fifo_addr, feed it with stdin\n"
		       "Fifo should already exist (no check).\n"
		       "\n"
		       "-e: once all data has been fed, wait for emptiness before leaving.\n"
		       "\n"
		       "Termination on stdin EOF\n"
		       "\n[version " EMHWLIB_VERSION_S "]"
		       );

	GetDeviceServer(argv, device, RM_MAX_STRING);
	pllad = llad_open(device);
	if (pllad == NULL) {
		fprintf(stderr, "unable to access device\n");
		return -1;
	}

	pgbus = gbus_open(pllad);
	
	{
		RMuint32 fifo_addr=GetUL(argv[1], 4, argv, "<address>");
		RMuint32 wr_ptr1,wr_size1,drop;
		
		struct gbus_fifo *pf=(struct gbus_fifo *)fifo_addr;
		
		if (argc==3) 
			dowait = (strcmp(argv[2],"-e")==0);

		while (1) {
			gbus_fifo_get_writable_size(pgbus,pf,&wr_ptr1,&wr_size1,&drop);
			
			if (wr_size1>0) {
				RMuint8 buf[MAX_PCI_COUNT];
				int x;
				
				wr_size1=RMmin(wr_size1,sizeof(buf));
				x=read(STDIN_FILENO,buf,wr_size1);
				
				if (x<0) {
					perror("");
					return -1;
				}
				
				wr_size1=x;
				
				if (wr_size1==0) {
					rc=0;
					goto wayout;
				}
				else {
#if 1
					gbus_write_data8(pgbus,wr_ptr1,buf,wr_size1);
#else
			    		mbus_write_dram(pllad,wr_ptr1,buf,wr_size1,MAX_PCI_COUNT);
#endif
					gbus_fifo_incr_write_ptr(pgbus,pf,wr_size1);
				}
			}
			else
				sched_yield();
		}
	
	wayout:
		if (dowait) 
			while (!gbus_fifo_is_empty(pgbus,pf));
	}
		
	gbus_close(pgbus);
	llad_close(pllad);
	
	return rc;
}
