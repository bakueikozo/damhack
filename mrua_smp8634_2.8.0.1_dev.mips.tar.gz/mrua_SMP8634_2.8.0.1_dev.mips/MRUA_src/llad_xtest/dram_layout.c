/*****************************************
 Copyright � 2004-2005
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE 1
#include "../llad/include/gbus.h"
#include "../emhwlib_hal/include/emhwlib_registers.h"
#include "../emhwlib/include/emhwlib_dram.h"
#include "../emhwlib/include/emhwlib_versions.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "getargs.h"

#define RM_MAX_STRING 1024

int main(int argc,char **argv) 
{
	int rc=-1;

	RMascii device[RM_MAX_STRING];

	struct llad *pllad;
	struct gbus *pgbus;

	CheckArgCount (argc, 0, 0, argv, 
		       "Report dram layout\n"
		       "\n[version " EMHWLIB_VERSION_S "]"
		       );
	
	GetDeviceServer(argv, device, RM_MAX_STRING);
	pllad = llad_open(device);
	if (pllad == NULL) {
		fprintf(stderr, "unable to access device\n");
		return -1;
	}

	pgbus = gbus_open(pllad);
	
	{
		memcfg_t m;
		void *a,*b;
		RMuint32 curtainA1,curtainB1;

		gbus_read_data32(pgbus,MEM_BASE_dram_controller_0+FM_MEMCFG,(RMuint32 *)&m,sizeof(memcfg_t)/4);
		
		if (m.curtainC+m.dram0_fixed_topreserved!=m.dram0_size) {
			fprintf(stderr, "memcfg inconsistent\n");
			return -1;
		}

		printf("Controller 0: %d MBytes\n",m.dram0_size/1024/1024);
		a=(void *)MEM_BASE_dram_controller_0;
		b=(void *)(MEM_BASE_dram_controller_0+FM_RESERVED);
		printf(" %p - %p (%9d bytes). <refer to emhwlib/include/emhwlib_dram_tango2.h>\n",a,b,b-a);
		a=b;
		b=(void *)(MEM_BASE_dram_controller_0+m.kernel_end);
		printf(" %p - %p (%9d bytes). Linux kernel\n",a,b,b-a);
		a=b;
		b=(void *)(MEM_BASE_dram_controller_0+m.curtainA0);
		printf(" %p - %p (%9d bytes). RUA MM#0\n",a,b,b-a);
		a=b;
		b=(void *)(MEM_BASE_dram_controller_0+m.curtainB0);
		printf(" %p - %p (%9d bytes). RiscZoneA0 (picture buffers)\n",a,b,b-a);
		a=b;
		b=(void *)(MEM_BASE_dram_controller_0+m.curtainC);
		printf(" %p - %p (%9d bytes). RiscZoneB0 (bitstream buffers)\n",a,b,b-a);
		a=b;
		b=(void *)(MEM_BASE_dram_controller_0+m.dram0_size);
		printf(" %p - %p (%9d bytes). RiscZoneC + XPU Zone (use xrpc -d for the details)\n",a,b,b-a);
		
		printf("\nController 1: %d MBytes\n",m.dram1_size/1024/1024);
		
		curtainA1=m.dram1_size-m.dram1_fixed_topreserved-m.dram1_removable_topreserved;
		curtainB1=m.dram1_size-m.dram1_fixed_topreserved;
		
		a=(void *)MEM_BASE_dram_controller_1;
		b=(void *)(MEM_BASE_dram_controller_1+m.dram1_kernel_end);
		printf(" %p - %p (%9d bytes). Linux kernel, again\n",a,b,b-a);
		a=b;
		b=(void *)(MEM_BASE_dram_controller_1+curtainA1);
		printf(" %p - %p (%9d bytes). RUA MM#1\n",a,b,b-a);
		a=b;
		b=(void *)(MEM_BASE_dram_controller_1+curtainB1);
		printf(" %p - %p (%9d bytes). RiscZoneA1 (picture buffers)\n",a,b,b-a);
		a=b;
		b=(void *)(MEM_BASE_dram_controller_1+m.dram1_size);
		printf(" %p - %p (%9d bytes). RiscZoneB1 (bitstream buffers)\n",a,b,b-a);
		
		printf("\nAs soon as you use enhanced mode, use xrpc -d to get geometry.\n");
		printf("The above will be wrong excepted kernel/rua boundaries (xosMe0, 2007jan16th, e.m.)\n");
	}
	
	gbus_close(pgbus);
	llad_close(pllad);
	
	return rc;
}
