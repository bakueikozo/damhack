/*****************************************
 Copyright � 2004-2005
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE 1
#include "../llad/include/gbus.h"
#include "../mbus/include/mbus.h"
#include "../emhwlib_hal/include/emhwlib_registers.h"
#include "../emhwlib/include/emhwlib_versions.h"
#include "../gbuslib/include/gbus_fifo.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <string.h>
#include <sched.h>

#include "getargs.h"

#define RM_MAX_STRING 1024
#define MAX_PCI_COUNT 65532

static RMbool RMKeyAvailable(void)
{
        struct timeval tv;
        fd_set readfds;
        
        tv.tv_sec = 0;
        tv.tv_usec = 0;
        FD_ZERO(&readfds);
        FD_SET(STDIN_FILENO, &readfds);
        return (select(STDIN_FILENO + 1, &readfds, NULL, NULL, &tv) > 0);
}

int main(int argc,char **argv) 
{
	int rc=-1;
	int docheck=0;

	RMascii device[RM_MAX_STRING];

	struct llad *pllad;
	struct gbus *pgbus;

	CheckArgCount (argc, 1, 2, argv, 
		       "<fifo_addr> [-c]\n\n"
		       "Given a 32bit gbus data fifo at fifo_addr, consume data and dump as is to stdout.\n"
		       "Fifo should already exist.\n"
		       "\n"
		       "-c: additional checks on fifo consistency; also filters non-printable.\n"
		       "\n"
		       "Press <enter> to leave.\n"
		       "\n[version " EMHWLIB_VERSION_S "]"
		       );

	GetDeviceServer(argv, device, RM_MAX_STRING);
	pllad = llad_open(device);
	if (pllad == NULL) {
		fprintf(stderr, "unable to access device\n");
		return -1;
	}

	pgbus = gbus_open(pllad);
	
	{
		RMuint32 fifo_addr = GetUL(argv[1], 4, argv, "<address>");
		RMuint32 rd_ptr1,rd_size1,drop;
		struct gbus_fifo *pf=(struct gbus_fifo *)fifo_addr;
		
		if (argc==3) 
			docheck = (strcmp(argv[2],"-c")==0);
		
		if (docheck) { // check fifo mostly ok:
			RMuint32 base, size, rd_ptr, wr_ptr;
			gbus_fifo_get_pointer(pgbus, pf, 
					      &base, &size, &rd_ptr, &wr_ptr);
			if((rd_ptr>size) || (wr_ptr>size)
			   || (base==(RMuint32)-1) || (size==(RMuint32)-1)
			   || (base==0) || (size==0) ) {
				fprintf(stderr, "This doesnt seem to be a valid fifo?\n");
				fprintf(stderr, "fifo: base=0x%08lx, size=0x%08lx, rd_ptr=0x%08lx, wr_ptr=0x%08lx\n",
					base, size, rd_ptr, wr_ptr);
				return -1;
			}
		}
		
		while (!RMKeyAvailable()) {
			gbus_fifo_get_readable_size(pgbus,pf,&rd_ptr1,&rd_size1,&drop);
			
			if (rd_size1>0) {
				RMuint8 buf[MAX_PCI_COUNT];
				
				if (docheck) {
					unsigned int i;
					
					for(i=0; i<rd_size1; i++) {
						int c;
						c=(int)gbus_read_uint8(pgbus, rd_ptr1+i);

						if (c=='\004') { /* /usr/include/php/regex/cname.h */
							printf("<eot>\n");
							gbus_fifo_incr_read_ptr(pgbus,pf,i+1);
							goto wayout;
						}

						if (isprint(c)||isspace(c)) 
							write(STDOUT_FILENO,&c,1);
						else 
							printf("<%02x>",c);
						fflush(stdout);
					}
				}
				else {
					rd_size1=RMmin(rd_size1,sizeof(buf));
					
#if 1
					gbus_read_data8(pgbus,rd_ptr1,buf,rd_size1);
#else
					mbus_read_dram(pllad,rd_ptr1,buf,rd_size1,MAX_PCI_COUNT);
#endif
					if (write(STDOUT_FILENO,buf,rd_size1)!=(int)rd_size1) {
						perror("short write not handled");
						return -1;
					}
					
					fflush(stdout);
				}
				
				gbus_fifo_incr_read_ptr(pgbus,pf,rd_size1);
			}
			else
				sched_yield();
		}
		
		read(STDIN_FILENO,&drop,1);

	wayout:
		rc=0;
	}
	
	gbus_close(pgbus);
	llad_close(pllad);
	
	return rc;
}
