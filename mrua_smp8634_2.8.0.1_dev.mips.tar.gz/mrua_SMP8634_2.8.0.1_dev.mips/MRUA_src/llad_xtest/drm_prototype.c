/*****************************************
 Copyright � 2005
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE 1
#include "../llad/include/gbus.h"
#include "../emhwlib/include/emhwlib_event.h"

#if (EM86XX_CHIP<EM86XX_CHIPID_TANGO3) //sc 07may22
#include "../xos/include/xos_xrpc.h"
#else
#include "../xos/include2/xos2_xrpc.h"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <sched.h>

#include "getargs.h"

#define RM_MAX_STRING 1024

// Reserve 64 bytes off the top of a PID's debug fifo
#define RPC2XTASK_SIZE 64

// Maintain an array of rpc2xtask start addresses
// for each PID.  Valid PIDs are 1, 2, 3, and 4.
// The 0th element of this array should never be accessed.
const RMuint32 rpc2xtask_base[]={
	0,
	MEM_BASE_dram_controller_0 + FM_XTASK2DBG - RPC2XTASK_SIZE,
	MEM_BASE_dram_controller_0 + FM_XTASK3DBG - RPC2XTASK_SIZE,
	MEM_BASE_dram_controller_0 + FM_XTASK4DBG - RPC2XTASK_SIZE,
	MEM_BASE_dram_controller_0 + FM_SCRATCH2  - RPC2XTASK_SIZE
};

// This is an example DRM initialization function
static int invoke_drm_prototype_init(struct gbus *pgbus, int pid, int x)
{
	// Pass the sole argument
	gbus_write_uint32(pgbus, rpc2xtask_base[pid] + 4, x);

	// Initiate the init function (procedure index is 1)
	gbus_write_uint32(pgbus, rpc2xtask_base[pid], 1);

	// Wait for function completion (procedure index reset to 0)
	while (gbus_read_uint32(pgbus, rpc2xtask_base[pid]))
		sched_yield();

	// Return function result
	return(gbus_read_uint32(pgbus, rpc2xtask_base[pid] + 60));
}

// This is an example DRM setup function.
// For example, DTCP-IP must do an AKE,
// and JANUS must process a header.
static int invoke_drm_prototype_setup(struct gbus *pgbus, int pid, int x, int y, int z)
{
	// Pass three arguments
	gbus_write_uint32(pgbus, rpc2xtask_base[pid] + 12, z);
	gbus_write_uint32(pgbus, rpc2xtask_base[pid] +  8, y);
	gbus_write_uint32(pgbus, rpc2xtask_base[pid] +  4, x);

	// Initiate the setup function (procedure index is 2)
	gbus_write_uint32(pgbus, rpc2xtask_base[pid], 2);

	// Wait for function completion (procedure index reset to 0)
	while (gbus_read_uint32(pgbus, rpc2xtask_base[pid]))
		sched_yield();

	// Return function result
	return(gbus_read_uint32(pgbus, rpc2xtask_base[pid] + 60));
}

// This is an example DRM decryption function
static int invoke_drm_prototype_decrypt(struct gbus *pgbus, int pid, int x, int y)
{
	// Pass two arguments
	gbus_write_uint32(pgbus, rpc2xtask_base[pid] + 8, y);
	gbus_write_uint32(pgbus, rpc2xtask_base[pid] + 4, x);

	// Initiate the decrypt function (procedure index is 3)
	gbus_write_uint32(pgbus, rpc2xtask_base[pid], 3);

	// Wait for function completion (procedure index reset to 0)
	while (gbus_read_uint32(pgbus, rpc2xtask_base[pid]))
		sched_yield();

	// Return function result
	return(gbus_read_uint32(pgbus, rpc2xtask_base[pid] + 60));
}

// This is an example DRM termination function
static int invoke_drm_prototype_term(struct gbus *pgbus, int pid, int x)
{
	// Pass the sole argument
	gbus_write_uint32(pgbus, rpc2xtask_base[pid] + 4, x);

	// Initiate the term function (procedure index is 4)
	gbus_write_uint32(pgbus, rpc2xtask_base[pid], 4);

	// Wait for function completion (procedure index reset to 0)
	while (gbus_read_uint32(pgbus, rpc2xtask_base[pid]))
		sched_yield();

	// Return function result
	return(gbus_read_uint32(pgbus, rpc2xtask_base[pid] + 60));
}

// This procedure prevents a race condition with the xtask.
// Basically, the xtask signals that it is alive, initialized,
// and ready to go by constantly changing an agreed upon memory
// location in the PID's rpc2xtask zone.  Once this procedure
// sees the changing memory location, it signals an
// acknowledgement to the xtask by resetting a different agreed
// upon memory location.
static int rpc2xtask_sync(struct gbus *pgbus, RMuint32 pid)
{
	RMuint32 first;

	// Remember the first value in the agreed upon memory location
	first = gbus_read_uint32(pgbus, rpc2xtask_base[pid] + 60);

	// Wait for this value to change
	while (gbus_read_uint32(pgbus, rpc2xtask_base[pid] + 60) == first);

	// Signal acknowledgement to the xtask
	gbus_write_uint32(pgbus, rpc2xtask_base[pid] + 56, 0);

	return 0;
}

int main(int argc,char **argv) 
{
	RMascii device[RM_MAX_STRING];
	struct llad *pllad;
	struct gbus *pgbus;
	RMuint32 image = 0;
	RMuint32 pid;
	RMuint32 base_addr;
	struct xrpc_block_header *pB;

	// Select an xtask image (default is zero)
	CheckArgCount(argc, 0, 1, argv, "[image]");
	if (argc == 2)
		image = strtoul(argv[1], NULL, 0);

	// Open the llad
	GetDeviceServer(argv, device, RM_MAX_STRING);
	pllad = llad_open(device);
	if (pllad == NULL) {
		fprintf(stderr, "unable to access device\n");
		return -1;
	}

	// Open the gbus
	pgbus = gbus_open(pllad);

	// Assign the XRPC block header
	base_addr = DMEM_BASE_audio_engine_0;
	pB = (struct xrpc_block_header *)base_addr;

	// Start the xtask on the selected image
	gbus_write_uint32(pgbus, (RMuint32)&pB->xrpcid,XRPC_ID_XSTART);
	gbus_write_uint32(pgbus, (RMuint32)&pB->param0, image);
	gbus_write_uint32(pgbus, (RMuint32)&pB->param1, 0);
	gbus_write_uint32(pgbus, (RMuint32)&pB->param2, 0);
	gbus_write_uint32(pgbus, (RMuint32)&pB->param3, 0);
	gbus_write_uint32(pgbus, (RMuint32)&pB->param4, 0);
	if (doxrpc(pgbus,base_addr) != RM_OK) {
		fprintf(stderr, "xrpc failed\n");
		return -1;
	}

	// Determine the PID of the new xtask
	pid = gbus_read_uint32(pgbus,(RMuint32)&pB->param0);

	// Sync up with the xtask to prevent a race condition
	rpc2xtask_sync(pgbus, pid);

	// Do a sequence of application-level function calls
	printf("drm_prototype_init(11)          -> %d\n", invoke_drm_prototype_init(pgbus, pid, 11));
	printf("drm_prototype_setup(21, 22, 23) -> %d\n", invoke_drm_prototype_setup(pgbus, pid, 21, 22, 23));
	printf("drm_prototype_decrypt(31, 32)   -> %d\n", invoke_drm_prototype_decrypt(pgbus, pid, 31, 32));
	printf("drm_prototype_decrypt(33, 34)   -> %d\n", invoke_drm_prototype_decrypt(pgbus, pid, 33, 34));
	printf("drm_prototype_decrypt(35, 36)   -> %d\n", invoke_drm_prototype_decrypt(pgbus, pid, 35, 36));
	printf("drm_prototype_term(41)          -> %d\n", invoke_drm_prototype_term(pgbus, pid, 41));

	// Stop the xtask by specifying a negative procedure index
	gbus_write_uint32(pgbus, rpc2xtask_base[pid], -1);

	// Close the gbus and the llad
	gbus_close(pgbus);
	llad_close(pllad);

	return 0;
}

