#ifndef __GETARGS_H__
#define __GETARGS_H__

void CheckArgCount (int argc, int min, int max, char* arg[], char* usage);
unsigned long GetUL (char* arg, int align, char* argv[], char* usage);
void GetDeviceServer(char *argv[], char *server, int maxsize);

#endif  // __GETARGS_H__
