/*****************************************
 Copyright (c) 2003-2004
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/*
 * pflash.h
 */

#ifndef __PFLASH_H
#define __PFLASH_H

#ifdef YAMON
#include <tango2.h>
#endif

#define CFIDEV_BUSWIDTH_8	8
#define CFIDEV_BUSWIDTH_16	16
#define CFIDEV_BUSWIDTH_32	32 // not support yet

//#define FLASH_BUS_WIDTH		CFIDEV_BUSWIDTH_8 //8//16//

// CFI Query Identification
// Vendor command set & control interface ID code assignment(CFI Publication 100)
#define CFI_PRIMARY_ID_NULL			 0   // none is specified
#define CFI_PRIMARY_ID_INTEL_EXT		1   // Intel/Sharp Extended command set
#define CFI_PRIMARY_ID_AMD_STD		  2   // AMD/Fujitsu Standard command set
#define CFI_PRIMARY_ID_INTEL_STD		3   // Intel Standard command set
#define CFI_PRIMARY_ID_AMD_EXT		  4   // AMD/Fujitsu Extended command set
#define CFI_PRIMARY_ID_MITSUBISHI_STD   256 // Mitsubishi Standard command set
#define CFI_PRIMARY_ID_MITSUBISHI_EXT   257 // Mitsubishi Extended command set
#define CFI_PRIMARY_ID_SST			  258 // Page Write command set
#define CFI_PRIMARY_ID_RESERVED		 65535

#define CFI_MAX_ERASE_REGIONS	8

// Query ID structure
struct cfi_query_id {
    unsigned char query[3];                 // 0x10 - 0x12 : query-unique ACSII string "QRY"
    unsigned short primary_id;              // 0x13 - 0x14 : primary vendor command set and control interface ID code
    unsigned short primary_table_addr;      // 0x15 - 0x16 : address for primary algorithm extended query table
    unsigned short alternate_id;            // 0x17 - 0x18 : alternate vendor command set and control interface ID code
    unsigned short alternate_table_addr;    // 0x19 - 0x1a : address for alternate algorithm extended query table
    unsigned char vcc_min;                  // 0x1b : Vcc logic supply minimum voltage
    unsigned char vcc_max;                  // 0x1c : Vcc logic supply maximum voltage
    unsigned char vpp_min;                  // 0x1d : Vpp logic supply minimum voltage
    unsigned char vpp_max;                  // 0x1e : Vpp logic supply maximum voltage
    unsigned char timeout_single_write;     // 0x1f : typical timeout per single byte/word write
    unsigned char timeout_buffer_write;     // 0x20 : typical timeout for minimum-size buffer write
    unsigned char timeout_block_erase;      // 0x21 : typical timeout for individual block erase
    unsigned char timeout_chip_erase;       // 0x22 : typical timeout for full chip erase
    unsigned char max_timeout_single_write; // 0x23 : maximum timeout per single byte/word write
    unsigned char max_timeout_buffer_write; // 0x24 : maximum timeout for minimum-size buffer write
    unsigned char max_timeout_block_erase;  // 0x25 : maximum timeout for individual block erase
    unsigned char max_timeout_chip_erase;   // 0x26 : maximum timeout for full chip erase
    unsigned char device_size;              // 0x27 : device size = 2^n in number of bytes
    unsigned short interface_desc;          // 0x28 - 0x29 : flash device interface description
    unsigned short max_multibyte_write;     // 0x2a - 0x2b : maximum number of bytes in multi-byte write = 2^n
    unsigned char num_erase_regions;        // 0x2c : number of erase block regions within device
    unsigned int erase_region_info[CFI_MAX_ERASE_REGIONS];  // erase block region information
                                            // bits 31-16 : 
                                            // bits 15-0 : 
} __attribute__((packed));

struct cfi_eraseregions {
    RMuint32 start;
    RMuint32 size;
    RMuint32 blocks;
};

// CFI information block used by this driver
typedef struct{
    RMuint32 gbus_address;
	RMuint32 size;
    RMuint32 buswidth;	// support mode : 8, 16, 32(not yet) //==8 
    RMuint32 addr_unlock1, addr_unlock2; //base on CFIDEV_DEVTYPE
    struct cfi_query_id ident;
    struct cfi_eraseregions erase_regions[CFI_MAX_ERASE_REGIONS];
    int exist; 
    int chip_state;
} cfi_info;

#ifdef YAMON
typedef enum
{
	RM_ERROR_FIRST__ = 5, // don't rely on any supposed value of RM_OK.
#undef RM_DEFINE_ERROR
#define RM_DEFINE_ERROR(x) RM_ ## x,

RM_DEFINE_ERROR(OK)
//no error, but action is still pending
RM_DEFINE_ERROR(PENDING)
//used in case of synchronous transfer 
RM_DEFINE_ERROR(XFER_DONE)
// generic errors 
RM_DEFINE_ERROR(ERROR)
RM_DEFINE_ERROR(FATAL)
RM_DEFINE_ERROR(NOTIMPLEMENTED)
// if a set-only property is used in get mode for instance 
RM_DEFINE_ERROR(INVALIDMODE)
RM_DEFINE_ERROR(DEPRECATED)
RM_DEFINE_ERROR(PARAMETER_OUT_OF_RANGE)
RM_DEFINE_ERROR(INVALID_PARAMETER)
RM_DEFINE_ERROR(ACCESS_VIOLATION)
RM_DEFINE_ERROR(INSUFFICIENT_SIZE)
RM_DEFINE_ERROR(NOT_FOUND)
RM_DEFINE_ERROR(NOT_SUPPORTED)

#undef RM_DEFINE_ERROR
	RM_ERROR_LAST__
} RMstatus;

#define ENABLE TRUE, __FILE__, __LINE__
#define DISABLE FALSE, __FILE__, __LINE__

void RMDBGLOG_implementation(RMbool active,const RMascii *filename,RMint32 line,const RMascii *text,...);
void RMDBGPRINT_implementation(RMbool active,const RMascii *filename,RMint32 line,const RMascii *text,...);

#if 1//def _DEBUG
#define RMDBGLOG(x) RMDBGLOG_implementation x
#define RMDBGPRINT(x) RMDBGPRINT_implementation x
#else
#define RMDBGLOG(x) do {} while (0)
#define RMDBGPRINT(x) do {} while (0)
#endif // _DEBUG

extern cfi_info g_pcfi;

UINT32 FLASH_TANGO2_probe(UINT8 disp, UINT32 pflash_gbus_addr, UINT32 pflash_bus_width, UINT8 dq56mark);

INT32 FLASH_AMD_install( void );
#endif /* YAMON */

/* function prototypes */
// init & basic
RMstatus flash_init(struct gbus *h, cfi_info *pcfi, RMuint32 gbus_addr, RMuint32 buswidth, RMuint8 dq56mark, RMbool disp);

// erase
RMstatus flash_erase_chip(struct gbus *h,  cfi_info *pcfi, void(*cb_usleep)(struct gbus*, RMuint32));

RMstatus flash_erase_region(struct gbus *h, cfi_info *pcfi, RMuint32 addroffs, RMuint32 length, void(*cb_usleep)(struct gbus*, RMuint32));

RMstatus flash_save_erase_region(struct gbus *h,cfi_info *pcfi,RMuint32 addroffs, RMuint32 length,void(*cb_usleep)(struct gbus*,RMuint32));

// read / write
RMstatus flash_read_data(struct gbus *h,  cfi_info *pcfi, RMuint32 addroffs, void *data, RMuint32 length);

RMstatus flash_write_data(struct gbus *h,  cfi_info *pcfi, RMuint32 addroffs, RMuint8 *data, RMuint32 length, void(*cb_usleep)(struct gbus*, RMuint32));

RMstatus flash_save_write_data(struct gbus *h,cfi_info *pcfi,RMuint32 addroffs,RMuint32 ramaddr,RMuint32 length,void(*cb_usleep)(struct gbus*,RMuint32));

//utility
RMint32 flash_calcblock(struct gbus *h, cfi_info *pcfi, RMuint32 addroffs, RMuint32 *pstart, RMuint32 *plen);

#endif
