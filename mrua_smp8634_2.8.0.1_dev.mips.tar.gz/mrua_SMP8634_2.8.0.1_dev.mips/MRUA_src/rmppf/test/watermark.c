/*
 *
 * Copyright (c) Sigma Designs, Inc. 2002. All rights reserved.
 *
 */

/**
	@file dcc_demo.c
	@brief sample application to access the Mambo chip and test DMA transfers
	
	@author Julien Soulier
   	@ingroup dccsamplecode
*/

/*
  ****************************************************************************************
  This file is part of libsamples library, therefore no static variables should be defined
  ****************************************************************************************
*/

#include "../../samples/sample_os.h"


//#define SEND_IBC

#define ALLOW_OS_CODE 1
#include "../../dcc/include/dcc.h"
#include "../../rmlibcw/include/rmfile.h"
#include "../../samples/common.h"

#include "../filters/bridge/include/ppf_bridge.h"
#include "../include/rmppf.h"



#define COMMON_TIMEOUT_US    (TIMEOUT_10MS)
#define DMA_BUFFER_SIZE_LOG2 15
#define DMA_BUFFER_COUNT     32
#define REPACK_SIZE (4096)

#define VIDEO_FIFO_SIZE (1024*1024)
#define XFER_FIFO_COUNT (1024) // 32

#define KEYFLAGS (SET_KEY_DISPLAY | SET_KEY_PLAYBACK | SET_KEY_DEBUG)
#define ALLOW_OS_CODE 1

#define MAXHEADERSIZE 4095

#define RM_DEVICES_STC 0x1
#define RM_DEVICES_VIDEO 0x2

#define DEBUG	ENABLE

#define START_IN_IFRAME_MODE 0

#ifdef	SEND_IBC
#define HARDCODE_BYTECOUNT	0x100000
#endif

#if 0
#define SENDDBG ENABLE
#else
#define SENDDBG DISABLE
#endif

#define ENABLE_MONITOR 0

#define FORCE_IFRAME_FWD_COMMAND 1

/* 0 the decoder will remember the seqHeader, 
   1 we must store it locally and resend it (trickmodes not supported) */
#define STORE_SEQ_HEADER_LOCALLY 0 


RMuint32 output1_surface_addr, output2_surface_addr, input_surface_addr, filter_slot = 0;

struct RMppf *pppf;



struct video_context {
	struct RUABufferPool *pDMA;
	RMbool FirstSystemTimeStamp;
	RMuint32 FirstPTS;
	struct dcc_context *dcc_info;
	struct RM_PSM_Context *PSMcontext;

	RMfile f_bitstream;
	RMint64 fileSize;
	RMbool video_decoder_initialized;
	RMbool initVideo;

	RMbool trickMode;
	RMbool iframeMode;
	RMbool ResyncTimer;

	RMuint64 lastSTC;
	RMuint64 lastVideoPTS;
	RMuint64 lastDecoded;
	RMbool highSpeedIFrameMode;
	RMuint32 highSpeedIFrameSpeed;

	RMuint32 prebuf_level;
	RMuint32 byte_counter;

	RMbool monitor;
	RMuint32 bitrate;
	RMuint64 meanBitrate;
	RMuint32 meanCount;

	RMuint64 last_video_pts;

	RMuint32 NTimes;

	struct timeval last;

	struct playback_cmdline *play_opt;
	struct video_cmdline *video_opt;
#ifndef WITH_MONO
	struct display_cmdline *disp_opt;
#endif

};


#define GET_DATA_FIFO_INFO(pRUA, ModuleId)				\
	{								\
		struct DataFIFOInfo DataFIFOInfo;			\
		RMreal fullness;					\
		RUAGetProperty(pRUA, ModuleId, RMGenericPropertyID_DataFIFOInfo, &DataFIFOInfo, sizeof(DataFIFOInfo)); \
		fullness = (RMreal)((100./DataFIFOInfo.Size)*DataFIFOInfo.Readable); \
		fprintf(stderr, "Data %lx: st=%08lx sz=%ld wr=%ld rd=%ld --> f : %.02f\n", ModuleId, DataFIFOInfo.StartAddress,	\
			DataFIFOInfo.Size, DataFIFOInfo.Writable,  DataFIFOInfo.Readable, fullness); \
	}								\


#define GET_XFER_FIFO_INFO(pRUA, ModuleId)				\
	{								\
		struct XferFIFOInfo_type XferFIFOInfo;			\
		RMreal fullness;					\
		RUAGetProperty(pRUA, ModuleId, RMGenericPropertyID_XferFIFOInfo, &XferFIFOInfo, sizeof(XferFIFOInfo)); \
		fullness = (RMreal)((100./XferFIFOInfo.Size)*XferFIFOInfo.Readable); \
		fprintf(stderr, "XFER %lx: st=%08lx sz=%ld wr=%ld rd=%ld er=%lx --> f : %.02f	\n", ModuleId, XferFIFOInfo.StartAddress, \
			XferFIFOInfo.Size, XferFIFOInfo.Writable,  XferFIFOInfo.Readable, XferFIFOInfo.Erasable, fullness); \
	}


#define MONITOR_INTERVAL_US 250000

static void monitor(struct video_context *context, RMbool alwaysShow)
{	
	/* the bitrate reading of this probe is accurate only if the blocking call is RUASendData */

	struct timeval now;	
	static int first = 1;
	RMuint64 elapsed; 	
	RMuint64 ptime; 	
	struct dcc_context *dcc_info = context->dcc_info;

	gettimeofday(&now, NULL);
	elapsed = (now.tv_sec - context->last.tv_sec) * 1000000;		
	elapsed += (now.tv_usec - context->last.tv_usec);
	if (elapsed > MONITOR_INTERVAL_US || first || alwaysShow){
		RMuint64 bitrate = (RMuint64)context->bitrate * 1000000;
		bitrate /= elapsed;

		context->meanBitrate += bitrate;
		context->meanCount++;

		DCCSTCGetTime(dcc_info->pStcSource, &ptime, 90000);			
		fprintf(stderr, "\n*****************************\n");			
		fprintf(stderr, "STC = %llu (%llu secs)\n", ptime, (ptime/90000));
		/* sample code to get fifo info */
		fprintf(stderr, "Video :\n"); 			
		GET_DATA_FIFO_INFO(dcc_info->pRUA, dcc_info->video_decoder);
		GET_XFER_FIFO_INFO(dcc_info->pRUA, dcc_info->video_decoder);			
		fprintf(stderr, "bitrate: mean %llu bit/sec, pseudo-instantaneus %llu bit/sec (%lu bytes/%llu us)\n", 
			context->meanBitrate / context->meanCount,
			bitrate, 
			context->bitrate >> 3, 
			elapsed);
		fprintf(stderr, "*****************************\n");			
		gettimeofday(&context->last, NULL);
		first = 0;
		context->bitrate = 0;
		fflush(stderr);
		
	}					        

	return;
}




static RMuint32 trickBuffersToSend = 0;
static RMuint32 trickSizeToSend = 0;
static RMuint32 trickBuffersSent = 0;

static struct RM_PSM_Actions actions;

#define PROCESS_KEY(release, getkey)					\
do	{								\
		RMDBGLOG((DISABLE, "process_key\n"));			\
		if (getkey) {						\
		        FSMstate = RM_PSM_GetState(context.PSMcontext, &(context.dcc_info));			\
                        if ((FSMstate == RM_PSM_Stopped) || (FSMstate == RM_PSM_Paused)) {			\
			        switch (context.play_opt->disk_ctrl_state) {						\
			        case DISK_CONTROL_STATE_DISABLE:						\
			        case DISK_CONTROL_STATE_SLEEPING:						\
				        break;									\
			        case DISK_CONTROL_STATE_RUNNING:						\
						if(context.play_opt->disk_ctrl_callback && context.play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_SLEEP) == RM_OK) \
					        context.play_opt->disk_ctrl_state = DISK_CONTROL_STATE_SLEEPING;	\
				        break;									\
			        }										\
		        }						\
			err = process_command(context.PSMcontext, &(context.dcc_info), &actions); \
			if (RMFAILED(err)) {				\
				fprintf(stderr, "Error while processing key %d\n", err); \
				goto cleanup;				\
			}						\
		}							\
		if (((RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Slow) || \
		     (RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Fast) || \
		     (RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_NextPic)) && \
		    (actions.cmdProcessed) && (!context.trickMode)) {	\
			RMDBGLOG((ENABLE, ">> trick mode\n"));		\
			if (release) {					\
				RUAReleaseBuffer(pDMA, buf);		\
				buf = NULL;				\
			}						\
			context.trickMode = TRUE;			\
			context.FirstSystemTimeStamp = TRUE;		\
		}							\
		if (actions.toDoActions & RM_PSM_FLUSH_VIDEO) {		\
			RMDBGLOG((ENABLE, "flushVIDEO\n"));		\
			Stop(&context, RM_DEVICES_VIDEO);		\
			context.video_decoder_initialized = FALSE;	\
			context.initVideo = TRUE;			\
			actions.toDoActions &= ~RM_PSM_FLUSH_VIDEO;	\
		}							\
		if (actions.toDoActions & RM_PSM_FIRST_PTS) {		\
			RMDBGLOG((ENABLE, "firstPTS\n"));		\
			context.FirstSystemTimeStamp = TRUE;		\
			actions.toDoActions &= ~RM_PSM_FIRST_PTS;	\
		}							\
		if (actions.toDoActions & RM_PSM_RESYNC_TIMER) {	\
			RMDBGLOG((ENABLE, "resyncTimer\n"));		\
			context.ResyncTimer = TRUE;			\
			actions.toDoActions &= ~RM_PSM_RESYNC_TIMER;	\
		}							\
		if (actions.performedActions & RM_PSM_VIDEO_STOPPED) {	\
			RMDBGLOG((ENABLE, "video stopped\n"));		\
			context.video_decoder_initialized = FALSE;	\
			context.initVideo = TRUE;			\
			actions.performedActions &= ~RM_PSM_VIDEO_STOPPED; \
			/* needed for no dram copy version on standalone */ \
			err = RUAResetPool(pDMA);			\
			if (RMFAILED(err)) {				\
				RMDBGLOG((ENABLE, "Error cannot reset dmapool\n")); \
				goto cleanup;				\
			}						\
		}							\
		if (actions.performedActions & RM_PSM_STC_STOPPED) {	\
			RMDBGLOG((ENABLE, "stc stopped\n"));		\
			actions.performedActions &= ~RM_PSM_STC_STOPPED; \
		}							\
		if (actions.toDoActions & RM_PSM_DEMUX_IFRAME) {	\
			RMDBGLOG((ENABLE, "demuxIFrame\n"));		\
			Play(&context, RM_DEVICES_VIDEO, DCCVideoPlayIFrame); \
			context.iframeMode = TRUE;			\
			actions.toDoActions &= ~RM_PSM_DEMUX_IFRAME;	\
		}							\
		if (actions.toDoActions & RM_PSM_DEMUX_NORMAL) {	\
			RMDBGLOG((ENABLE, "demuxNormal\n"));		\
			context.iframeMode = FALSE;			\
			RMDBGLOG((ENABLE, "flushing fifos\n")); \
			Stop(&context, RM_DEVICES_VIDEO);		\
			Play(&context, RM_DEVICES_VIDEO, DCCVideoPlayFwd); \
			context.highSpeedIFrameMode = FALSE;		\
			actions.toDoActions &= ~RM_PSM_DEMUX_NORMAL;	\
		}							\
		if ((RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Playing) && \
		    (context.trickMode))	{			\
			RMDBGLOG((ENABLE, "got play after trickmode\n")); \
			if (release) {					\
				RUAReleaseBuffer(pDMA, buf);		\
				buf = NULL;				\
			}						\
			context.trickMode = FALSE;			\
		}							\
		if ((RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Stopped) && (actions.cmdProcessed)) { \
			RMDBGLOG((ENABLE,"Got stop command\n"));	\
			if (release) {					\
				RUAReleaseBuffer(pDMA, buf);		\
				buf = NULL;				\
			}						\
			context.trickMode = FALSE;			\
			context.iframeMode = FALSE;			\
			context.highSpeedIFrameMode = FALSE;		\
			context.video_decoder_initialized = FALSE;	\
			context.initVideo = TRUE;			\
			context.byte_counter = 0;			\
			goto mainloop_no_seek;				\
		}							\
		if ((actions.cmd == RM_QUIT) && (!actions.cmdProcessed)) { \
			RMDBGLOG((ENABLE, "Got quit command\n"));	\
			if (release) {					\
				RUAReleaseBuffer(pDMA, buf);		\
				buf = NULL;				\
			}						\
			goto cleanup;					\
		}							\
		if ((actions.cmd == RM_STOP_SEEK_ZERO) && (!actions.cmdProcessed)) { \
			RMDBGLOG((ENABLE,"Got stop seek zero command\n")); \
			Stop(&context, RM_DEVICES_VIDEO | RM_DEVICES_STC); \
			RM_PSM_SetState(context.PSMcontext, &(context.dcc_info), RM_PSM_Stopped); \
			if (release) {					\
				RUAReleaseBuffer(pDMA, buf);		\
				buf = NULL;				\
			}						\
			context.trickMode = FALSE;			\
			context.iframeMode = FALSE;			\
			context.highSpeedIFrameMode = FALSE;		\
			context.video_decoder_initialized = FALSE;	\
			/*context.initVideo = TRUE;*/			\
			goto mainloop;					\
		}							\
		if ((actions.cmd == RM_SEEK) && (!actions.cmdProcessed)){ \
			RMDBGLOG((ENABLE,"Got seek command\n"));	\
			if (release) {					\
				RUAReleaseBuffer(pDMA, buf);		\
				buf = NULL;				\
			}						\
			if (dcc_info.seek_supported)			\
				seek(&context, context.dcc_info->seek_time); \
			else						\
				fprintf(stderr, "Unsuported command\n"); \
			context.trickMode = FALSE;			\
			context.iframeMode = FALSE;			\
			context.highSpeedIFrameMode = FALSE;		\
			RM_PSM_SetState(context.PSMcontext, &(context.dcc_info), RM_PSM_Playing); \
			goto mainloop_no_seek;				\
		}							\
		computeSpeed(&context);					\
		if (context.monitor)					\
			monitor(&context, FALSE);			\
} while(0)




static RMstatus computeSpeed(struct video_context *pSendContext);

static RMuint64 round_int_div(RMuint64 numerator, RMuint32 divisor) {
	RMuint64 temp;
	temp = numerator / divisor;
	if ((numerator % divisor) * 2 > divisor)
		temp++;
	return temp;
}

#ifndef WITH_MONO

static void show_usage(char *progname)
{
	show_playback_options();
	show_display_options();
	show_video_options();
	fprintf(stderr, "--------------------------------\n");
	fprintf(stderr, "Minimum cmd line: %s <file name>\n", progname);
	fprintf(stderr, "--------------------------------\n");

	exit(1);
}

static void parse_cmdline(struct video_context *pSendContext, int argc, char *argv[])
{
	int i;
	RMstatus err;

	if (argc < 2) 
		show_usage(argv[0]);
	
	i = 1;
	while ((argc > i)) {
		if (argv[i][0] != '-') {
			if (pSendContext->play_opt->filename == NULL) {
				pSendContext->play_opt->filename = argv[i];
				i++;
			}
			else
				show_usage(argv[0]);
		}
		else {
			err = parse_playback_cmdline(argc, argv, &i, pSendContext->play_opt);
			if (err == RM_ERROR) 
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_display_cmdline(argc, argv, &i, pSendContext->disp_opt);
			if (err == RM_ERROR) 
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_video_cmdline(argc, argv, &i, pSendContext->video_opt);
			if (RMFAILED(err))
				show_usage(argv[0]);
		}
	}

	if (pSendContext->play_opt->filename == NULL)
		show_usage(argv[0]);
}
#endif //WITH_MONO

static RMstatus WaitForEOS(struct video_context *pSendContext, struct RM_PSM_Actions *pActions)
{
	RMuint32 eos_bit_field = 0;

	if (pSendContext == NULL || pActions == NULL)
		return RM_ERROR;


#if 1
	if (pSendContext->video_opt->vcodec == EMhwlibVideoCodec_WMV) {
		struct video_context *context = pSendContext;
		// Hack: send last PTS again so that video ucode can get the EOS. The problem is that
		// there is still data in the FIFO and the next inband command is not read by the video microcode.
		struct emhwlib_info Info;
		RMuint8 *buffer;
		
		RMDBGLOG((ENABLE, "video is WMV, hack EOS\n"));
		
		while(RUAGetBuffer(context->pDMA, &buffer, TIMEOUT_10MS) != RM_OK) {
			/* should never happen since we released an empty buffer before getting here */
			RMDBGLOG((ENABLE,"Cannot get buffer for EOS\n"));
		}
		
		buffer[0] = 0;
		
		Info.ValidFields = TIME_STAMP_INFO;
		Info.TimeStamp = context->last_video_pts;
		while (RUASendData(context->dcc_info->pRUA, context->dcc_info->video_decoder, context->pDMA, buffer, 1, &Info, sizeof(Info)) != RM_OK) {
			usleep(TIMEOUT_10MS); // Should rarelly happen...
		}
		
		RUAReleaseBuffer(context->pDMA, buffer);
	}
#endif

	pSendContext->NTimes++;
	fprintf(stderr, "File ready %ld times, waiting for EOS\n", pSendContext->NTimes);

	eos_bit_field |= EOS_BIT_FIELD_VIDEO;
		
	return WaitForEOSWithCommand(pSendContext->PSMcontext, &(pSendContext->dcc_info), pActions, eos_bit_field);
}


#if STORE_SEQ_HEADER_LOCALLY
static RMbool StoreHeader(struct video_context *pSendContext, RMuint8 *buffer, RMuint8 *seqhead, RMint32 *HeaderSize, RMint32 BufSize)
{
  
	RMint32 i, size, start;
	
	
	i = 0;
	if ((pSendContext->video_opt->MPEGProfile == Profile_MPEG2_HD) ||		
	    (pSendContext->video_opt->MPEGProfile == Profile_MPEG2_SD) ||		
	    (pSendContext->video_opt->MPEGProfile == Profile_MPEG2_DVD) ||		
	    (pSendContext->video_opt->MPEGProfile == Profile_MPEG2_SD_DeInt) ||	
	    (pSendContext->video_opt->MPEGProfile == Profile_MPEG2_HD_DeInt) ||	
	    (pSendContext->video_opt->MPEGProfile == Profile_MPEG2_DVD_DeInt) ) 	{
		while (1) {
			if ((buffer[i] == 0) && (buffer[i+1] == 0) && (buffer[i+2] == 1) && (buffer[i+3] == 0xB3))
				break;
			i++;
			if (i >= BufSize-3)
				return FALSE;
		}

		
/*		fprintf(stderr, "\nMPEG2 escape sequence found at: %ld\n", i); */

		start = i;
		i++;

		while (1) {
			if ((buffer[i] == 0) && (buffer[i+1] == 0) && (buffer[i+2] == 1) && (buffer[i+3] == 0xB8))
				break;
			i++;
			if (i >= BufSize-3)
				return FALSE;
		}
	
		size = i - start;
		
/*		fprintf(stderr, "size %ld, i=%ld, byte at: %02X, next byte %02X\n", size, i, buffer[i], buffer[i+3]); */
   
		if (size > MAXHEADERSIZE) {
			fprintf(stderr, "header found exceeded maximum header allowed length\n");
			return FALSE;
		}


		i = 0;
		for (i = 0; i < size; i++) {
				seqhead[i] = buffer[start + i];
			}

  
		*HeaderSize = size;


		return TRUE;


	}
	
	if ((pSendContext->video_opt->MPEGProfile == Profile_MPEG4_SD) ||		
	    (pSendContext->video_opt->MPEGProfile == Profile_MPEG4_HD) ||		
	    (pSendContext->video_opt->MPEGProfile == Profile_MPEG4_SD_Padding) ||	
	    (pSendContext->video_opt->MPEGProfile == Profile_MPEG4_HD_Padding) ||	
	    (pSendContext->video_opt->MPEGProfile == Profile_MPEG4_SD_DeInt) ||	
	    (pSendContext->video_opt->MPEGProfile == Profile_MPEG4_HD_DeInt) ||	
	    (pSendContext->video_opt->MPEGProfile == Profile_MPEG4_SD_DeInt_Padding) || 
	    (pSendContext->video_opt->MPEGProfile == Profile_MPEG4_HD_DeInt_Padding)) 	{
		while (1) {
			if ((buffer[i] == 0) && (buffer[i+1] == 0) && (buffer[i+2] == 1) && 
			    ((buffer[i+3] == 0xB5) || (((RMint8)buffer[i+3] >= 0) && ((RMint8)buffer[i+3] <= 0x1F))))
				break;
			i++;
			if (i >= BufSize-3)
				return FALSE;
		}

/*		fprintf(stderr, "\nMPEG4 escape sequence found at: %ld\n", i); */

		start = i;
		i++;

		while (1) {
			if ((buffer[i] == 0) && (buffer[i+1] == 0) && (buffer[i+2] == 1) && (buffer[i+3] == 0xB6))
				break;
			i++;
			if (i >= BufSize-3)
				return FALSE;
		}
	
		size = i - start;
  
/*		fprintf(stderr, "size %ld, i=%ld, byte at: %02X, next byte %02X\n", size, i, buffer[i], buffer[i+3]); */
   
		if (size > MAXHEADERSIZE) {
			fprintf(stderr, "header found exceeded maximum header allowed length\n");
			return FALSE;
		}
		
		i = 0;
		for (i = 0; i < size; i++) {
				seqhead[i] = buffer[start+i];
			}

		*HeaderSize = size;

		return TRUE;


	}

	return FALSE;


}

#endif // STORE_SEQ_HEADER_LOCALLY

static RMstatus Stop(struct video_context *pSendContext, RMuint32 devices)
{
	RMstatus err = RM_OK;

	

	
	enum ppf_bridge_cmd cmd = ppf_bridge_cmd_stop;
	
	RMPPFSetCommand(pppf, filter_slot, &cmd, sizeof(cmd), NULL, 0);

/* 	err = RUAExchangeProperty(pSendContext->dcc_info->pRUA, ppf_id, RMPPFPropertyID_Command, &cmd, sizeof(cmd), NULL, 0); */
/* 	if (RMFAILED(err)){ */
/* 		RMDBGLOG((ENABLE, "Error stopping video source %d\n", err)); */
/* 		return err; */
/* 	} */




	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "STOP: stc\n"));
		DCCSTCStop(pSendContext->dcc_info->pStcSource);
	}

	if (devices & RM_DEVICES_VIDEO) {
		if (pSendContext->dcc_info->pVideoSource) {
			RMDBGLOG((ENABLE, "STOP: video decoder\n"));
			err = DCCStopVideoSource(pSendContext->dcc_info->pVideoSource, DCCStopMode_LastFrame);
			if (RMFAILED(err)){
				RMDBGLOG((ENABLE, "Error stopping video source %d\n", err));
				return err;
			}

			pSendContext->video_decoder_initialized = FALSE;
			pSendContext->FirstSystemTimeStamp = TRUE;
			//pSendContext->initVideo = TRUE;

			err = RUAResetPool(pSendContext->pDMA);	// needed for no dram copy version on standalone
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error cannot reset dmapool\n"));
				return err;
			}

		}
	}

	

	return err;

}

static RMstatus Pause(struct video_context * pSendContext, RMuint32 devices)
{
	RMstatus err;
	
	enum ppf_bridge_cmd cmd = ppf_bridge_cmd_stop;
	RMPPFSetCommand(pppf, filter_slot, &cmd, sizeof(cmd), NULL, 0);

/* 	err = RUAExchangeProperty(pSendContext->dcc_info->pRUA, ppf_id, RMPPFPropertyID_Command, &cmd, sizeof(cmd), NULL, 0); */
/* 	if (RMFAILED(err)){ */
/* 		RMDBGLOG((ENABLE, "Error stopping video source %d\n", err)); */
/* 		return err; */
/* 	} */

	if ((devices & RM_DEVICES_VIDEO) && (pSendContext->dcc_info->pVideoSource)) {
		RMDBGLOG((ENABLE, "pausing video decoder\n"));
		err = DCCPauseVideoSource(pSendContext->dcc_info->pVideoSource);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot pause video decoder %d\n", err);
			return err;
		}
	}
	
	if ((devices & RM_DEVICES_STC) && (pSendContext->dcc_info->pStcSource)) {
		RMDBGLOG((ENABLE, "stop stc\n"));
		err = DCCSTCStop(pSendContext->dcc_info->pStcSource);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot stop STC %d\n", err);
			return err;
		}
	}

	return RM_OK;
}

static RMstatus Play(struct video_context * pSendContext, RMuint32 devices, enum DCCVideoPlayCommand mode)
{

	RMstatus err = RM_OK;

	
	enum ppf_bridge_cmd cmd = ppf_bridge_cmd_play;
	RMPPFSetCommand(pppf, filter_slot, &cmd, sizeof(cmd), NULL, 0);

/* 	err = RUAExchangeProperty(pSendContext->dcc_info->pRUA, ppf_id, RMPPFPropertyID_Command, &cmd, sizeof(cmd), NULL, 0); */
/* 	if (RMFAILED(err)){ */
/* 		RMDBGLOG((ENABLE, "Error stopping video source %d\n", err)); */
/* 		return err; */
/* 	} */

	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "PLAY: stc\n"));
		DCCSTCPlay(pSendContext->dcc_info->pStcSource);
	}

	if (devices & RM_DEVICES_VIDEO) {
		if (pSendContext->dcc_info->pVideoSource) {
			if (pSendContext->initVideo) { /*(!pSendContext->video_decoder_initialized) {*/
				RMbool keep_sequence = TRUE;
				RMDBGLOG((ENABLE, "PLAY: initDecoder\n"));
				err = RUASetProperty(pSendContext->dcc_info->pRUA, pSendContext->dcc_info->video_decoder,
						RMVideoDecoderPropertyID_StorePreviousVideoHeader, &keep_sequence, sizeof(keep_sequence), 0);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Error setting video decoder to keep sequence header on Stop %d\n", err));
					return err;
				}
		
				pSendContext->video_decoder_initialized = TRUE;
				pSendContext->initVideo = FALSE;
			}

			RMDBGLOG((ENABLE, "PLAY: video decoder %s\n", (mode == DCCVideoPlayIFrame ? "(iframe)":"")));
			err = DCCPlayVideoSource(pSendContext->dcc_info->pVideoSource, mode);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot play video decoder %d\n", err));
				return err;
			}
		}
	}

	return err;
}

static RMstatus seek(struct video_context *pSendContext, RMuint32 time_sec)
{
	RMuint64 bytesSec = pSendContext->fileSize / (pSendContext->play_opt->duration / 1000);
	RMuint32 timeSec = 0;
	RMuint64 seekPos;

	timeSec = pSendContext->dcc_info->seek_time;
	seekPos = timeSec * bytesSec;

	RMDBGLOG((ENABLE, "seek to %lu s \n", timeSec));

	Stop(pSendContext, RM_DEVICES_VIDEO);
	pSendContext->initVideo = TRUE;

	RMDBGLOG((ENABLE, ">> %llu bytes/sec, seekto %lu sec => pos %llu, pts %lu\n", bytesSec, timeSec, seekPos, (timeSec*90000)));
	RMSeekFile(pSendContext->f_bitstream, seekPos, RM_FILE_SEEK_START);
	pSendContext->byte_counter = seekPos;

	pSendContext->FirstPTS = timeSec*90000;
	Play(pSendContext, RM_DEVICES_VIDEO, DCCVideoPlayFwd);

	RM_PSM_SetState(pSendContext->PSMcontext, &(pSendContext->dcc_info), RM_PSM_Playing);

	return RM_OK;
}


/* highspeed iframe mode works only when using STC timers */

#define MEAN_DEPTH 7
#define DIVERGENCE_TRIGGER 10
static RMint64 shiftReg1[MEAN_DEPTH];
static RMint64 shiftReg2[MEAN_DEPTH];
static RMint32 count1 = 0, count2 = 0;

static RMstatus computeSpeed(struct video_context *pSendContext)
{
	RMuint32 samplingT = 200; // 1/5 sec
	RMuint64 stc;
	RMstatus err;
	enum RM_PSM_State PlaybackStatus = RM_PSM_GetState(pSendContext->PSMcontext, &(pSendContext->dcc_info));

	if (!pSendContext->dcc_info->seek_supported)
		return RM_OK;

	if ((PlaybackStatus == RM_PSM_IForward) || (PlaybackStatus == RM_PSM_IRewind)) {

		RMint32 N;
		RMuint32 M;
		RMuint32 speedX, speedX2;
		RMint64 currentPTS, diff1, diff2, currentDecoded, delta = 0;
		RMint64 speed1 = 0, speed2 = 0, sum1, sum2;
		RMuint32 i;
		RMbool skip = TRUE;

		DCCSTCGetTime(pSendContext->dcc_info->pStcSource, &stc, 1000);
		DCCSTCGetSpeed(pSendContext->dcc_info->pStcSource, &N, &M);

		if (N > 0) {

			samplingT *= N;
			samplingT = (RMuint32) round_int_div((RMuint64)samplingT, M);

			if (stc > pSendContext->lastSTC + samplingT) {
		
				delta = stc - pSendContext->lastSTC;
				pSendContext->lastSTC = stc;
				err = RUAGetProperty(pSendContext->dcc_info->pRUA, pSendContext->dcc_info->SurfaceID, RMGenericPropertyID_CurrentDisplayPTS, &currentPTS, sizeof(currentPTS));
				err = RUAGetProperty(pSendContext->dcc_info->pRUA, pSendContext->dcc_info->video_decoder, RMVideoDecoderPropertyID_LastDecodedPTS, &currentDecoded, sizeof(currentDecoded));
				diff1 = (RMint64)stc - (RMint64)(currentPTS / 45);
				diff2 = (RMint64)stc - (RMint64)(currentDecoded / 45);
				speed1 = diff1;
				speed2 = diff2;

				skip = FALSE;
			}
		}
		else {
			N *= -1;
			samplingT *= N;
			samplingT = (RMuint32) round_int_div((RMuint64)samplingT, M);

			if (stc < pSendContext->lastSTC - samplingT) {
				

				delta = pSendContext->lastSTC - stc;
				pSendContext->lastSTC = stc;
				err = RUAGetProperty(pSendContext->dcc_info->pRUA, pSendContext->dcc_info->SurfaceID, RMGenericPropertyID_CurrentDisplayPTS, &currentPTS, sizeof(currentPTS));
				err = RUAGetProperty(pSendContext->dcc_info->pRUA, pSendContext->dcc_info->video_decoder, RMVideoDecoderPropertyID_LastDecodedPTS, &currentDecoded, sizeof(currentDecoded));
				diff1 = (RMint64)(currentPTS / 45) - (RMint64)stc;
				diff2 = (RMint64)(currentDecoded / 45) - (RMint64)stc;
				speed1 = diff1;
				speed2 = diff2;
				
				skip = FALSE;
			}
		}

		if (skip == FALSE) {
			sum1 = sum2 = 0;
			for (i = 0; i < MEAN_DEPTH; i++) {
				if (shiftReg1[0] < shiftReg1[i])
					sum1++;
				if (shiftReg2[0] < shiftReg2[i])
					sum2++;
			}
		
			if (sum1 > MEAN_DEPTH/2)
				count1++;
			else
				count1 = 0;
		
			if (sum2 > MEAN_DEPTH/2)
				count2++;
			else
				count2 = 0;
		
			speedX = (RMuint32)round_int_div((RMuint64)N, M);
			speedX2 = (RMuint32)round_int_div((RMuint64)delta, 200);
		
			RMDBGLOG((ENABLE, "time %llu (%ld/%lu=%lux, %lu), sampling %lu, delta %4llu, sum1 %lld, sum2 %lld, diff3 %lld(%ld), diff4 %lld(%ld) %s\n", 
				  stc,
				  N,
				  M,
				  speedX,
				  speedX2,
				  samplingT,
				  delta,
				  sum1,
				  sum2,
				  speed1,
				  count1,
				  speed2,
				  count2,
				  ((count1 > DIVERGENCE_TRIGGER) && (count2 > DIVERGENCE_TRIGGER)) ? "DIVERGE!":""));
		
			pSendContext->lastVideoPTS = currentPTS;
			pSendContext->lastDecoded = currentDecoded;
		
			for (i = 0 ; i < MEAN_DEPTH-1 ; i++)
				shiftReg1[i] = shiftReg1[i+1];
			shiftReg1[MEAN_DEPTH-1] = speed1;
		
			for (i = 0 ; i < MEAN_DEPTH-1 ; i++)
				shiftReg2[i] = shiftReg2[i+1];
			shiftReg2[MEAN_DEPTH-1] = speed2;
		
			if ((count1 > DIVERGENCE_TRIGGER) && 
			    (count2 > DIVERGENCE_TRIGGER) &&
			    (!pSendContext->highSpeedIFrameMode)) {
				RMDBGLOG((ENABLE, "enable high speed iframe mode\n"));
				pSendContext->highSpeedIFrameMode = TRUE;
			}
			pSendContext->highSpeedIFrameSpeed = speedX;
		}
	}
	

	return RM_OK;
}

static void check_prebuf_state(struct video_context *pSendContext, RMuint32 buffersize)
{
	RMbool quit_prebuf;
	enum RM_PSM_State PlaybackStatus = RM_PSM_GetState(pSendContext->PSMcontext, &(pSendContext->dcc_info));
	
	if (PlaybackStatus != RM_PSM_Prebuffering)
		return;

	/* if fail in getbuffer force quitting prebuffering state */
	quit_prebuf = ((buffersize == 0) || ((pSendContext->play_opt->prebuf_max > 0) && (pSendContext->prebuf_level >= pSendContext->play_opt->prebuf_max))) ? TRUE : FALSE;

	pSendContext->prebuf_level += buffersize;
		
	if (quit_prebuf) {
		RMDBGLOG((ENABLE, "exit prebuffering state\n"));
		RMDBGLOG((ENABLE, "setting play state\n"));
		RM_PSM_SetState(pSendContext->PSMcontext, &(pSendContext->dcc_info), RM_PSM_Playing);

#if START_IN_IFRAME_MODE
		Play(pSendContext, RM_DEVICES_VIDEO | RM_DEVICES_STC, DCCVideoPlayIFrame);
#else
		Play(pSendContext, RM_DEVICES_VIDEO | RM_DEVICES_STC, DCCVideoPlayFwd);
		RMDBGLOG((ENABLE, "============start playing\n"));
		
#endif

	}
}

#ifdef	SEND_IBC
static RMbool SendInbandCommand(struct video_context* context) {
	struct InbandCommandX_type 	ibcx;
	RMbool						result = FALSE;
	RMstatus					err;

	RMDBGLOG((ENABLE, "Sending action stop inband command!\n"));

	/* test pts offset */
	ibcx.flags_tag 		= INBAND_COMMAND_TAG_PTS_OFFSET|INBAND_COMMAND_ACTION_STOP;
	ibcx.offset_value 	= 0; // byte_cnt[state]; /* ignored */
	ibcx.output_mask 	= 0; /* no need to propagate it to the outputs */
	ibcx.offset_control = EMhwlibInbandOffset_Absolute;

	err = RUASetProperty(context->dcc_info->pRUA, context->dcc_info->video_decoder,
			RMGenericPropertyID_InbandCommandX, &ibcx, sizeof(ibcx), 0);

	if ( RMSUCCEEDED(err) ) {
		result = TRUE;
	}

	return result;
}
#endif

#ifdef WITH_MONO
int main_video(struct mono_info *mono)
{
#else
int main(int argc, char *argv[])
{
	/*for MONO compatibility, always access these variables through the global pointers*/
	struct playback_cmdline playback_options; /*access through play_opt*/
	struct display_cmdline  display_options;/*not accessible*/
	struct video_cmdline video_options; /*access through video_opt*/
	struct display_context disp_info;
	struct dh_context dh_info = {0,};
#ifdef	SEND_IBC
	RMbool ibc_sent = FALSE;
#endif

#endif

	struct DCCVideoSource *pVideoSource = NULL;
	struct RUABufferPool *pDMA = NULL;
	RMstatus err;
	RMfile file = NULL;
	static struct dcc_context dcc_info = {0,};
	RMuint32  videoscaler_id = 0;
	struct RM_PSM_Context PSMContext;
	void **dmabuffer_array = (void **) NULL;
	RMuint32 dmabuffer_index = 0;
	RMuint64 MSPts = 0LL;
	RMuint32 MSLength = 0L;

#if STORE_SEQ_HEADER_LOCALLY
	RMuint8 header[MAXHEADERSIZE];
	RMbool headerread = FALSE;
	RMbool resendheader = FALSE;
	RMint32 HeaderSize = 0;
#endif //STORE_SEQ_HEADER_LOCALLY

	struct video_context context = {0,};

#ifdef WITH_MONO
	/*make the mono arguments global*/
	context.play_opt = mono->play_opt;
	context.video_opt = mono->video_opt;
	dcc_info.pRUA = mono->pRUA;
	dcc_info.pDCC = mono->pDCC;
	dcc_info.disp_info = NULL;
	videoscaler_id = mono->video_scaler;
	dcc_info.route = DCCRoute_Main;

#else
	context.play_opt = &playback_options;
	context.disp_opt = &display_options;
	context.video_opt = &video_options;
	dcc_info.disp_info = &disp_info;

	init_display_options(context.disp_opt);
	init_playback_options(context.play_opt);
	init_video_options(context.video_opt);
	context.disp_opt->dh_info = &dh_info;
	context.dcc_info = &dcc_info;
	context.PSMcontext = &PSMContext;


	parse_cmdline(&context, argc, argv);
	dcc_info.route = context.disp_opt->route;
	videoscaler_id = context.disp_opt->video_scaler;


	err =  RMPPFCreateInstance(&pppf);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error creating ppf instance! %d\n", err));
		return -1;
	}
	
	{
		struct EMhwlibMemoryBlockList requiredmemblocks;
		err =  RMPPFGetEngineMem(pppf, 0, &requiredmemblocks);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error creating ppf instance! %d\n", err));
			return -1;
		}

	}



	err = RUACreateInstance(&(dcc_info.pRUA), context.play_opt->chip_num);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error creating RUA instance! %d\n", err));
		return -1;
	}

	err = DCCOpen(dcc_info.pRUA, &(dcc_info.pDCC));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error Opening DCC! %d\n", err));
		return -1;
	}

	if (!context.play_opt->noucode) {
		err = DCCInitMicroCodeEx(dcc_info.pDCC, context.disp_opt->init_mode);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot initialize microcode %d\n", err));
			return -1;
		}
	}
	else
		RMDBGLOG((ENABLE, "microcode not loaded\n"));

#endif

	if (context.video_opt->auto_detect_codec) {
		fprintf(stderr, "you must specify the codec, '-pv auto' is not valid for this application\n");
		return -1;
	}

	context.dcc_info = &dcc_info;

	dcc_info.chip_num = context.play_opt->chip_num;

	/* if HD control is enabled and mode is auto, setup parameters */
	if ((context.play_opt->disk_ctrl_low_level) &&
	    (context.play_opt->disk_ctrl_log2_block_size) &&
	    (context.play_opt->disk_ctrl_max_mem)) {
		RMuint32 bufferSize = 0;
		RMuint32 bufferCount = 0;
		RMuint32 log2BlockSize = context.play_opt->disk_ctrl_log2_block_size;
		RMuint32 maxBufferingMem = context.play_opt->disk_ctrl_max_mem;

		bufferSize = (1 << log2BlockSize);
		bufferCount = maxBufferingMem >> log2BlockSize;
	
		context.play_opt->dmapool_count = bufferCount;
		context.play_opt->dmapool_log2size = log2BlockSize;
	
		/* from #4005
		   
		videoOpt.fifo_size = 4*1024*1024; 
		videoOpt.xfer_count = (1<<playOpt.dmapool_log2size)/1024*playOpt.dmapool_count;
		audioOpt.fifo_size = 1*1024*1024; 
		audioOpt.xfer_count = (1<<playOpt.dmapool_log2size)/512*playOpt.dmapool_count;
		
		*/

		if (context.play_opt->disk_ctrl_low_level >= bufferCount)
			context.play_opt->disk_ctrl_low_level = bufferCount >> 1;
	
		context.video_opt->fifo_size = 4 * (1024 * 1024);

		fprintf(stderr, ">> low level %lu => %lu bytes bufferized (+ bitstreamFIFO)\n", 
			context.play_opt->disk_ctrl_low_level,
			context.play_opt->disk_ctrl_low_level * bufferSize);

	
		context.video_opt->xfer_count = bufferCount * 2;


		err = setup_disk_control_parameters(&dcc_info, context.play_opt, NULL, context.video_opt, NULL);
		if (err != RM_OK) {
			fprintf(stderr, "Error %d trying to setup HD control params\n", err);
			return -1;
		}

	}

	/* update fifo and xfer size */
	if (context.video_opt->fifo_size == 0) 
		context.video_opt->fifo_size = VIDEO_FIFO_SIZE;

	if (context.video_opt->xfer_count == 0)
		context.video_opt->xfer_count = XFER_FIFO_COUNT;

	/* update dmapool size and count */
	if (context.play_opt->dmapool_count == 0)
		context.play_opt->dmapool_count = DMA_BUFFER_COUNT;

	if (context.play_opt->dmapool_log2size == 0)
		context.play_opt->dmapool_log2size = DMA_BUFFER_SIZE_LOG2;


	RMDBGLOG((ENABLE, "Video:\n\tBitstreamFIFOSize: %lu\n\tFIFOXFERCount: %lu\n", 
		  context.video_opt->fifo_size , 
		  context.video_opt->xfer_count));
	RMDBGLOG((ENABLE, "DMA Pool:\n\tSize: %ld\n\tBufferCount: %ld\n\tBufferSize: %ld\n", 
		  (context.play_opt->dmapool_count << context.play_opt->dmapool_log2size), 
		  context.play_opt->dmapool_count, 
		  (1 << context.play_opt->dmapool_log2size)));

	switch (context.play_opt->disk_ctrl_state) {
	case DISK_CONTROL_STATE_DISABLE:
		break;
	case DISK_CONTROL_STATE_SLEEPING:
	case DISK_CONTROL_STATE_RUNNING:
		dmabuffer_array = (void **) RMMalloc(sizeof(void*) * context.play_opt->dmapool_count);
		dmabuffer_index = 0;
		if (dmabuffer_array == NULL) {
			RMDBGLOG((ENABLE, "Cannot allocate dmapool array! Disable disk control\n"));
			context.play_opt->disk_ctrl_state = DISK_CONTROL_STATE_DISABLE;
		}
		break;
	}

	err = apply_playback_options(&dcc_info, context.play_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set playback options %d\n", err));
		return -1;
	}



	{
		// open first stc module
		struct DCCStcProfile stc_profile;
		RMuint32 timeScale;

		if (context.video_opt->vcodec == EMhwlibVideoCodec_WMV)
			timeScale = 1000;
		else
			timeScale = 90000;

		RMDBGLOG((ENABLE, "using STC ID %lu\n", context.play_opt->STCid));
		stc_profile.STCID = context.play_opt->STCid;
		stc_profile.master = Master_STC;
	
		stc_profile.stc_timer_id = 0;
		stc_profile.stc_time_resolution = timeScale;
		
		stc_profile.video_timer_id = 1;
		stc_profile.video_time_resolution = timeScale;
		stc_profile.video_offset = -(context.play_opt->video_delay_ms * (RMint32)stc_profile.video_time_resolution / 1000);
		
		stc_profile.audio_timer_id = NO_TIMER;
		stc_profile.audio_time_resolution = 0;
		stc_profile.audio_offset = 0;
		
		err = DCCSTCOpen(dcc_info.pDCC, &stc_profile, &dcc_info.pStcSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot open stc module %d\n", err));
			goto cleanup;
		}
	}

	{
		struct DCCXVideoProfile video_profile;
		enum EMhwlibVideoCodec vcodec;
		RMuint32 block;
		struct EMhwlibMemoryBlockList requiredmemblocks;



		video_profile.ProtectedFlags = 0;
		video_profile.BitstreamFIFOSize = context.video_opt->fifo_size;
		video_profile.XferFIFOCount = context.video_opt->xfer_count;
		video_profile.PtsFIFOCount = 180;
		video_profile.InbandFIFOCount = 16;
		video_profile.XtaskInbandFIFOCount = 0;
		video_profile.MpegEngineID = context.video_opt->MpegEngineID;
		video_profile.VideoDecoderID = context.video_opt->VideoDecoderID;
		video_profile.SPUBitstreamFIFOSize = 0;
		video_profile.SPUXferFIFOCount = 0;
		video_profile.STCID = 0;


		/* set codec based on command line options either "-pv" or "-vcodec" */
		if (context.video_opt->vcodec_max_width) {
			video_profile.Codec = context.video_opt->vcodec;
			video_profile.Profile = context.video_opt->vcodec_profile;
			video_profile.Level = context.video_opt->vcodec_level;
			video_profile.ExtraPictureBufferCount = context.video_opt->vcodec_extra_pictures;
			video_profile.MaxWidth = context.video_opt->vcodec_max_width;
			video_profile.MaxHeight = context.video_opt->vcodec_max_height;
		}
		else {
			err = video_profile_to_codec(context.video_opt->Codec, 
						     &video_profile.Codec,
						     &video_profile.Profile, 
						     &video_profile.Level, 
						     &video_profile.ExtraPictureBufferCount,
						     &video_profile.MaxWidth, 
						     &video_profile.MaxHeight);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Unknown video decoder codec \n"));
				goto cleanup;
			}
		}

		err = DCCXOpenVideoDecoderSource(dcc_info.pDCC, &video_profile, &pVideoSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot open video decoder %d\n", err));
			goto cleanup;
		}
		
		vcodec = video_profile.Codec;
		err = DCCXSetVideoDecoderSourceCodec(pVideoSource, vcodec);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set video decoder codec %d\n", err));
			goto cleanup;
		}

		err = DCCGetOSDSurfaceInfo(dcc_info.pDCC, pVideoSource, NULL, &input_surface_addr, NULL);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot get canvas surface info %d\n", err));
			return err;
		}
		


		RMPPFSetInputSurface(pppf, filter_slot, 0, input_surface_addr);

		RMPPFGetEngineMem(pppf, filter_slot,  &requiredmemblocks);
		for(block = 0; block < requiredmemblocks.BlockCount; block++){
			requiredmemblocks.Blocks[block].Address = RUAMalloc(dcc_info.pRUA, 0, RUA_DRAM_UNCACHED, requiredmemblocks.Blocks[block].Size);
		}
		RMDBGLOG((ENABLE, "calling set engine mem\n"));
		RMPPFSetEngineMem(pppf, filter_slot, &requiredmemblocks);

		RMPPFGetOutputMem(pppf, filter_slot, 0, &requiredmemblocks);
		for(block = 0; block < requiredmemblocks.BlockCount; block++){
			requiredmemblocks.Blocks[block].Address = RUAMalloc(dcc_info.pRUA, 0, RUA_DRAM_UNCACHED, requiredmemblocks.Blocks[block].Size);
		}
		RMPPFSetOutputMem(pppf, filter_slot, 0, &requiredmemblocks);
		RMPPFGetOutputSurface(pppf, filter_slot, 0, &output2_surface_addr);
		RMDBGLOG((ENABLE, "I got surface 0x%08lx\n", output2_surface_addr));

		/* connect the created surface to the scaler */
		while(RUASetProperty(dcc_info.pRUA, DispMainVideoScaler, RMGenericPropertyID_Surface,
				     &output2_surface_addr, sizeof(output2_surface_addr), 0) == RM_PENDING);

		while(RUASetProperty(dcc_info.pRUA, DispMainVideoScaler, RMGenericPropertyID_Validate,
				     NULL, 0, 0) == RM_PENDING);


/* 		/\* connect the created surface to the scaler *\/ */
/* 		while(RUASetProperty(dcc_info.pRUA, DispVCRMultiScaler, RMGenericPropertyID_Surface, */
/* 				     &output1_surface_addr, sizeof(output1_surface_addr), 0) == RM_PENDING); */

/* 		while(RUASetProperty(dcc_info.pRUA, DispVCRMultiScaler, RMGenericPropertyID_Validate, */
/* 				     NULL, 0, 0) == RM_PENDING); */


	}

	err = DCCGetScalerModuleID(dcc_info.pDCC, dcc_info.route, DCCSurface_Video, videoscaler_id, &(dcc_info.SurfaceID));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get surface to display video source %d\n", err));
		goto cleanup;
	}


/* 	err = DCCSetSurfaceSource(dcc_info.pDCC, dcc_info.SurfaceID, pVideoSource); */
/* 	if (RMFAILED(err)) { */
/* 		RMDBGLOG((ENABLE, "Cannot set the surface source %d\n", err)); */
/* 		goto cleanup; */
/* 	} */

	err = DCCGetVideoDecoderSourceInfo(pVideoSource, &(dcc_info.video_decoder), &(dcc_info.spu_decoder), &(dcc_info.video_timer));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting video decoder source information %d\n", err));
		goto cleanup;
	}

	dcc_info.pVideoSource = pVideoSource;
	
	
	dcc_info.seek_supported = FALSE;
	dcc_info.iframe_supported = FALSE;

	switch (context.video_opt->MPEGProfile) {
	case Profile_FIRST_:
	case Profile_LAST_:
		break;
		
	case Profile_MPEG2_SD:
	case Profile_MPEG2_DVD:
	case Profile_MPEG2_HD:
	case Profile_MPEG2_SD_Packed:
	case Profile_MPEG2_HD_Packed:
	case Profile_MPEG2_DVD_Packed:
	case Profile_MPEG2_SD_DeInt:
	case Profile_MPEG2_DVD_DeInt:
	case Profile_MPEG2_HD_DeInt:
	case Profile_MPEG2_SD_Packed_DeInt:
	case Profile_MPEG2_DVD_Packed_DeInt:
	case Profile_MPEG2_HD_Packed_DeInt:
		RMDBGLOG((ENABLE, "MPEG 2 video\n"));
		break;
		
	case Profile_DIVX3_SD:
	case Profile_DIVX3_HD:
	case Profile_DIVX3_SD_Packed:
 	case Profile_DIVX3_HD_Packed:
		RMDBGLOG((ENABLE, "DIVX3 video\n"));
		break;
		
	case Profile_WMV_SD:
	case Profile_WMV_816P:
	case Profile_WMV_HD:
		RMDBGLOG((ENABLE, "WMV9 video\n"));
		break;
		
	case Profile_MPEG4_SD:
	case Profile_MPEG4_HD:
	case Profile_MPEG4_SD_Packed:
	case Profile_MPEG4_HD_Packed:
	case Profile_MPEG4_SD_DeInt:
	case Profile_MPEG4_HD_DeInt:
	case Profile_MPEG4_SD_Packed_DeInt:
	case Profile_MPEG4_HD_Packed_DeInt:
	case Profile_MPEG4_SD_Padding:
	case Profile_MPEG4_HD_Padding:
	case Profile_MPEG4_SD_DeInt_Padding:
	case Profile_MPEG4_HD_DeInt_Padding:
		RMDBGLOG((ENABLE, "MPEG4 video. Set video timescale\n"));
		if (!context.video_opt->vtimescale.enable) {
			context.video_opt->vtimescale.enable = TRUE;
			context.video_opt->vtimescale.time_resolution = 90000;
		}
		break;

	case Profile_VC1_SD:
	case Profile_VC1_HD:
		RMDBGLOG((ENABLE, "WMV9 video\n"));
		break;
		
	case Profile_H264_SD:
	case Profile_H264_HD:
	case Profile_H264_SD_DeInt:
	case Profile_H264_HD_DeInt:
		RMDBGLOG((ENABLE, "H264 video\n"));
	default:
		break;
	}

	// apply the fixed vop rate if required
	err = apply_video_decoder_options(&dcc_info, context.video_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error applying video_decoder_options %d\n", err));
		goto cleanup;
	}

#ifndef WITH_MONO
	set_default_out_window(&(dcc_info.disp_info->out_window));
	set_default_out_window(&(dcc_info.disp_info->osd_window[0]));
	set_default_out_window(&(dcc_info.disp_info->osd_window[1]));
	dcc_info.disp_info->active_window = &(dcc_info.disp_info->out_window);
	dcc_info.disp_info->video_enable = TRUE;

	err = apply_display_options(&dcc_info, context.disp_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set display options %d\n", err));
		goto cleanup;
	}

	display_key_usage(KEYFLAGS);

#endif /*WITH_MONO*/

	/* dmapool must be created after the module open in case we do no copy transfers */
 	err = RUAOpenPool(dcc_info.pRUA, dcc_info.video_decoder, context.play_opt->dmapool_count, context.play_opt->dmapool_log2size, RUA_POOL_DIRECTION_SEND, &pDMA);
	if (RMFAILED(err)) {
		RMuint32 poolSize = context.play_opt->dmapool_count << context.play_opt->dmapool_log2size;

		fprintf(stderr, "Error cannot open dmapool %d\n\n"
			"requested %lu bytes of dmapool (%lu buffers of %lu bytes), make sure you\n"
			"loaded llad with the right parameters. For example:\n"
			"max_dmapool_memory_size >= %lu max_dmabuffer_log2_size >= %lu\n\n",
			err,
			poolSize,
			context.play_opt->dmapool_count,
			(RMuint32)(1 << context.play_opt->dmapool_log2size),
			poolSize,
			context.play_opt->dmapool_log2size);

		goto cleanup;
	}


	context.pDMA = pDMA;

	file = open_stream(context.play_opt->filename, RM_FILE_OPEN_READ, 0);
	if (file == NULL) {
		RMDBGLOG((ENABLE, "Cannot open file %s\n", context.play_opt->filename));
		goto cleanup;
	}

	context.f_bitstream = file;
	RMSizeOfOpenFile(file, &context.fileSize);

#if !(STORE_SEQ_HEADER_LOCALLY)
	
	RMDBGLOG((ENABLE, "file: %s, size %llu, duration %llu s \n", context.play_opt->filename, context.fileSize, context.play_opt->duration / 1000));

	if (context.play_opt->duration)
		fprintf(stderr, "duration %llu secs\n", context.play_opt->duration / 1000);

	dcc_info.RM_PSM_commands = RM_PSM_ENABLE_PLAY;
	dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_STOP;
	dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_PAUSE;

	dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_SPEED;
	dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_FASTER;
	dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_SLOWER;
	dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_NEXTPIC;

	dcc_info.trick_supported = TRUE;

	if ((context.play_opt->duration > 1000) && (context.fileSize > 0)) {
		RMDBGLOG((ENABLE, "seek, ffwd and iframe modes enabled\n"));
		
		dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_SEEK;
		
		dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_IFWD;

		dcc_info.seek_supported = TRUE;
		dcc_info.iframe_supported = TRUE;
	}

#endif //STORE_SEQ_HEADER_LOCALLY

#if FORCE_IFRAME_FWD_COMMAND
	RMDBGLOG((ENABLE, "\n\n\nIFrame forward command forced to enabled. Use ']' key to enter IFrameFwd state\n\n"));
	dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_IFWD;
#endif


	/* initialize the external close caption source */

	context.PSMcontext = &PSMContext;
	PSMContext.validPSMContexts = 1;
	PSMContext.currentActivePSMContext = 1;
	PSMContext.keyflags = KEYFLAGS;

	/* Send WMV9 parameters */
	if (context.video_opt->vcodec == EMhwlibVideoCodec_WMV) {
		struct VideoDecoder_WMV9VSProp_type wmv9_prop;
		RMuint32 Image_Width, Image_Height;

		RMDBGLOG((ENABLE, "Setting WMV9 parameters...size is %lu x %lu\n", context.video_opt->vcodec_max_width, context.video_opt->vcodec_max_height));

		Image_Width = context.video_opt->vcodec_max_width;
		Image_Height = context.video_opt->vcodec_max_height;

		wmv9_prop.Sequence = context.video_opt->wmv9_seq;
		wmv9_prop.Image_Width = Image_Width;
		wmv9_prop.Image_Height = Image_Height;
		wmv9_prop.MB_Width = (Image_Width + 15) / 16;
		wmv9_prop.MB_Height = (Image_Height + 15) / 16;

		err = RUASetProperty(dcc_info.pRUA, dcc_info.video_decoder, RMVideoDecoderPropertyID_WMV9VSProp, &wmv9_prop, sizeof(wmv9_prop), 0);
	}
	
       



#if ENABLE_MONITOR
	context.monitor = TRUE;
#endif


#ifndef WITH_MONO
	RMTermInit(TRUE);    // don't allow ctrl-C and the like ...
	RMSignalInit(NULL, NULL);  // ... but catch other termination signals to call RMTermExit()
#endif
	do {
		enum RM_PSM_State FSMstate;
		RMuint8 *buf;
		
		if (context.play_opt->start_pause) {
			RMDBGLOG((ENABLE, "start in pause mode!\n"));
			/* required, because if we do 'next' the decoder *must* be running */
			err = Play(&context, RM_DEVICES_VIDEO, /*DCCVideoPlayIFrame*/DCCVideoPlayFwd);
			if (RMFAILED(err)) {
				fprintf(stderr, "Cannot start decoders %d\n", err);
				goto cleanup;
			}
			
			err = Pause(&context, RM_DEVICES_VIDEO);
			if (RMFAILED(err)) {
				fprintf(stderr, "Cannot pause decoders %d\n", err);
				goto cleanup;
			}
			RM_PSM_SetState(context.PSMcontext, &(context.dcc_info), RM_PSM_Paused);
		}
		else 
			RM_PSM_SetState(context.PSMcontext, &(context.dcc_info), RM_PSM_Playing);
		context.play_opt->start_pause = FALSE;

	mainloop:
		RMDBGLOG((ENABLE, "mainloop\n"));
		if (RMSeekFile(file, 0, RM_FILE_SEEK_START) == RM_ERRORSEEKFILE) {
			RMDBGLOG((ENABLE,"seeking file to beginning\n"));
			goto cleanup;
		}
		context.byte_counter = 0;
		context.FirstPTS = 0;
		
	mainloop_no_seek:
		RMDBGLOG((ENABLE, "mainloop_no_seek\n"));


		/* do not set this property when start for the first time */
		if (context.initVideo == TRUE) {
#if STORE_SEQ_HEADER_LOCALLY
			resendheader = TRUE;
#else
			RMbool keep_sequence = TRUE;
			err = RUASetProperty(dcc_info.pRUA, dcc_info.video_decoder, RMVideoDecoderPropertyID_StorePreviousVideoHeader, &keep_sequence, sizeof(keep_sequence), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error setting video decoder to keep sequence header on Stop %d\n", err));
				return err;
			}
			RMDBGLOG((ENABLE, "init video decoder\n"));
			context.initVideo = FALSE;
#endif //STORE_SEQ_HEADER_LOCALLY
		}


		context.FirstSystemTimeStamp = TRUE;

		context.highSpeedIFrameMode = FALSE;
		context.trickMode = FALSE;
		context.iframeMode = FALSE;

		FSMstate = RM_PSM_GetState(context.PSMcontext, &(context.dcc_info));
		if ((FSMstate != RM_PSM_Paused) && (FSMstate != RM_PSM_Stopped)) {	
			RM_PSM_SetState(context.PSMcontext, &(context.dcc_info), RM_PSM_Playing);
		}
		else {
			PROCESS_KEY(FALSE, TRUE);
		}

		RMDBGLOG((ENABLE, "DCCSTCSetSpeed %lx %lx\n", context.play_opt->speed_N, context.play_opt->speed_M));
		DCCSTCSetSpeed(dcc_info.pStcSource, context.play_opt->speed_N, context.play_opt->speed_M);

		/* do prebufferization only when in playing state */
		FSMstate = RM_PSM_GetState(context.PSMcontext, &(context.dcc_info));
		if (FSMstate == RM_PSM_Playing) {
			/* required, because if we start straight into pause mode, we cant send buffers (weird)	*/
			err = Play(&context, RM_DEVICES_VIDEO, DCCVideoPlayFwd);
			if (RMFAILED(err)) {
				fprintf(stderr, "Cannot start decoders %d\n", err);
				goto cleanup;
			}
			
			/* ...for prebuffering */
			err = Pause(&context, RM_DEVICES_VIDEO | RM_DEVICES_STC);
			if (RMFAILED(err)) {
				fprintf(stderr, "Cannot pause decoders %d\n", err);
				goto cleanup;
			}
			
			RM_PSM_SetState(context.PSMcontext, &(context.dcc_info), RM_PSM_Prebuffering);
			context.prebuf_level = 0;
		}

#ifdef WITH_MONO
		RMDCCInfo(&dcc_info); // pass DCC context to application
#endif

		/* wake up disks if necessary */
		switch (context.play_opt->disk_ctrl_state) {
		case DISK_CONTROL_STATE_DISABLE:
		case DISK_CONTROL_STATE_RUNNING:
			break;
		case DISK_CONTROL_STATE_SLEEPING:
			if(context.play_opt->disk_ctrl_callback && context.play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_RUN) == RM_OK)
				context.play_opt->disk_ctrl_state = DISK_CONTROL_STATE_RUNNING;
			break;
		}

		while (1) { // additional 'while' used for taking care of commands issued during EOSWait
			while (1) {

				RMuint32 count;
				RMstatus status;
				struct emhwlib_info Info;

			
#ifdef	SEND_IBC
				if (!ibc_sent && (context.byte_counter >= HARDCODE_BYTECOUNT)) {
					SendInbandCommand(&context);
					ibc_sent = TRUE;
				}
#endif

				/* first, try to fill up the CC fifo */
			
#ifndef WITH_MONO
				update_hdmi(&dcc_info, context.disp_opt, NULL);
#endif
				
				PROCESS_KEY(FALSE, TRUE);
				
			get_buffer:
				switch (context.play_opt->disk_ctrl_state) {
				case DISK_CONTROL_STATE_DISABLE:
				case DISK_CONTROL_STATE_SLEEPING:
					break;
				case DISK_CONTROL_STATE_RUNNING:
					if (dmabuffer_index > 0) {
						dmabuffer_index--;
						buf = dmabuffer_array[dmabuffer_index];
						goto fill_buffer;
					}
					break;
				}
				
				while (RUAGetBuffer(pDMA, &buf,  COMMON_TIMEOUT_US) != RM_OK) {
					/* this has a double purpose: 
					   1) in mpeg4 elementary streams, the video decoder is able to recover the PTS from the
					   stream. When doing Stop/Play, after the Play the video decoder will find the correct PTS, 
					   since we cant set the STC to that value because it's unknown to us, there would be a delay
					   until STC (set to zero) meets the PTS the decoder got.
					   The solution is to prebufferize (thus the decoder will get the PTS and we can obtain it
					   thru a property, and then set the STC accordingly)
					   2) prebuffering, because we dont start playing until fifo's are full (unintended purpose) */
					check_prebuf_state(&context, 0);

					switch (context.play_opt->disk_ctrl_state) {
					case DISK_CONTROL_STATE_DISABLE:
					case DISK_CONTROL_STATE_SLEEPING:
						break;
					case DISK_CONTROL_STATE_RUNNING:
						if(context.play_opt->disk_ctrl_callback && context.play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_SLEEP) == RM_OK)
							context.play_opt->disk_ctrl_state = DISK_CONTROL_STATE_SLEEPING;
						break;
					}

					PROCESS_KEY(FALSE, TRUE);
				}
				
				check_prebuf_state(&context, (RMuint32) (1 << context.play_opt->dmapool_log2size));
	
				switch (context.play_opt->disk_ctrl_state) {
				case DISK_CONTROL_STATE_DISABLE:
				case DISK_CONTROL_STATE_RUNNING:
					break;
				case DISK_CONTROL_STATE_SLEEPING:
					dmabuffer_array[dmabuffer_index] = buf;
					dmabuffer_index ++;
					if (dmabuffer_index + context.play_opt->disk_ctrl_low_level >= context.play_opt->dmapool_count) {
						if(context.play_opt->disk_ctrl_callback && context.play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_RUN) == RM_OK)
							context.play_opt->disk_ctrl_state = DISK_CONTROL_STATE_RUNNING;
					}
					goto get_buffer;
				}
				
			fill_buffer:
				if ((!trickSizeToSend) && (dcc_info.seek_supported)) {
					trickSizeToSend = (RMuint32) (context.fileSize / (context.play_opt->duration / 500)); //there are roughly 2 iframes per second
					trickBuffersToSend = trickSizeToSend >> context.play_opt->dmapool_log2size;
					RMDBGLOG((ENABLE, "size %llu, duration %lu s, iframeSize %lu, buffers %lu (of %lu bytes)\n", 
						  context.fileSize, 
						  (RMuint32)(context.play_opt->duration / 1000), 
						  trickSizeToSend,
						  trickBuffersToSend,
						  (1 << context.play_opt->dmapool_log2size)));
					
				}
				
#if STORE_SEQ_HEADER_LOCALLY
				/* 
				   if we have to resend the sequence header, we copy it into the buffer
				   before sending it to the video decoder and then read from the file
				   till filling the buffer, otherwise, we just read the file into the
				   buffer.
				*/
				if (resendheader == TRUE && headerread == TRUE) {
					RMint32 i;
					
					for (i = 0; i < HeaderSize ; i++) { 
						*(buf+i) = header[i]; 
					}
					status = RMReadFile(file, buf+HeaderSize, (1 << context.play_opt->dmapool_log2size)-(HeaderSize), &count);
					
					resendheader = FALSE;
				} 
				else {
#endif //STORE_SEQ_HEADER_LOCALLY
					
					if (context.highSpeedIFrameMode) {
						RMint64 position;
						RMuint64 seekto;
						
						
						if (trickBuffersSent >= trickBuffersToSend)
							trickBuffersSent = 0;
						
						if (trickBuffersSent == 0) {
							RMGetCurrentPositionOfFile(file, &position);
							seekto = position + (RMuint64) context.highSpeedIFrameSpeed * trickBuffersToSend * (1<<(context.play_opt->dmapool_log2size));
							RMDBGLOG((DISABLE, "pos %llu, seekto %llu\n", position, seekto));
							status = RMSeekFile(file, seekto, RM_FILE_SEEK_START);
							if (status != RM_OK) {
								perror("error seeking in fwd trickmode, assume EOS\n");
								if (buf != NULL) {
									RUAReleaseBuffer(pDMA, buf);
									buf = NULL;
								}
								break;
							}
						}
						status = RMReadFile(file, buf, (1 << context.play_opt->dmapool_log2size), &count);
						
						trickBuffersSent++;
						RMDBGLOG((ENABLE, "sent buffer %lu, speed %lux\n", trickBuffersSent, context.highSpeedIFrameSpeed));
						
					}
					else {
						if (context.video_opt->MSflag) {
							RMint64 position;
							RMuint64 dummy;
							RMuint8 *buffer = (RMuint8*)&dummy;

							RMGetCurrentPositionOfFile (file, &position);

							status = RMReadFile(file, buffer, sizeof(RMuint64), &count);
							if (status == RM_ERRORENDOFFILE) {
								if (buf != NULL) {
									RUAReleaseBuffer(pDMA, buf);
									buf = NULL;
								}
								break;
							}
							else if ((status != RM_OK) || (count != sizeof(RMuint64))) {
								fprintf(stderr, "read error while reading pts!\n");
								if (buf != NULL) {
									RUAReleaseBuffer(pDMA, buf);
									buf = NULL;
								}
								goto cleanup;
							}
							MSPts = RMleBufToUint64(buffer);

							status = RMReadFile(file, buffer, sizeof(RMuint32), &count);
							if (status == RM_ERRORENDOFFILE) {
								if (buf != NULL) {
									RUAReleaseBuffer(pDMA, buf);
									buf = NULL;
								}
								break;
							}
							else if ((status != RM_OK) || (count != sizeof(RMuint32))) {
								fprintf(stderr, "read error while reading frame length!\n");
								if (buf != NULL) {
									RUAReleaseBuffer(pDMA, buf);
									buf = NULL;
								}
								goto cleanup;
							}
							MSLength = RMleBufToUint32(buffer);

							RMDBGLOG((DISABLE, "pos %llu (%llx); MSLength= %ld ; MSPts = %lld (bufferSize %ld) \n",
								  position, 
								  position,
								  MSLength, 
								  MSPts, 
								  (RMuint32)(1 << context.play_opt->dmapool_log2size) ));

							//MSPts *= 90000;
							//MSPts /= 1000;
							
							if (MSLength > (RMuint32)(1 << context.play_opt->dmapool_log2size)) {
								RMDBGLOG((ENABLE, "Buffer overflow!\n"));
								if (buf != NULL) {
									RUAReleaseBuffer(pDMA, buf);
									buf = NULL;
								}
								goto cleanup;
							}
							
							status = RMReadFile(file, buf, MSLength, &count);
						

						} else {
							status = RMReadFile(file, buf, (1 << context.play_opt->dmapool_log2size), &count);
						}
					}
#if STORE_SEQ_HEADER_LOCALLY
				}
#endif //STORE_SEQ_HEADER_LOCALLY
				
				if (status == RM_ERRORREADFILE) {
					RMDBGLOG((ENABLE, "reading file"));
					if (buf != NULL) {
						RUAReleaseBuffer(pDMA, buf);
						buf = NULL;
					}
					goto cleanup;
				}
				
				if (status == RM_ERRORENDOFFILE) {
					if (buf != NULL) {
						RUAReleaseBuffer(pDMA, buf);
						buf = NULL;
					}
					break;
				}
				
#if STORE_SEQ_HEADER_LOCALLY
				/* parse the buffer and store the header */
				if (headerread == FALSE) {
					headerread = StoreHeader(&context, buf, header, &HeaderSize, (1 << context.play_opt->dmapool_log2size));
					if (headerread)
						RMDBGLOG((ENABLE, "stored SeqHeader, %lu bytes\n", HeaderSize));
				}
#endif //STORE_SEQ_HEADER_LOCALLY
				
				/* fast forward may have been too fast for the decoder. Must set the STC
				   to the current picture in display to avoid skipping frames to catch STC 
				*/

				if (context.byte_counter == 0) {
					/* set the VopInfo property */
					if (context.video_opt->MSflag == TRUE) {
						RMuint32 timeScale;

						DCCSTCGetTimeResolution(dcc_info.pStcSource, DCC_Video, &timeScale);

						DCCSTCSetTime(dcc_info.pStcSource, context.play_opt->send_video_pts ? MSPts : 0, timeScale);

					} else {
						DCCSTCSetTime(dcc_info.pStcSource, context.play_opt->STC_initial_value, 90000);
						
						Info.ValidFields = 0;
						/* Info.TimeStamp = 0; */
						
						/* one shouldn't admit that first decoded picture has a PTS equal to 0 */
						/* for instance, closed gops starting with IB...BP (B frames only have backward references)  */
						/* give decoding order B....B I P */
						/* where I is the first decoded picture AND however doesn't have PTS = 0 */
					}

				} else if ((context.ResyncTimer) && (!context.FirstPTS)) {
					RMuint64 stc;
					RMuint32 timeScale;
					RMuint64 currentSTC;
					
					err = RUAGetProperty(dcc_info.pRUA, dcc_info.SurfaceID, RMGenericPropertyID_CurrentDisplayPTS, &stc, sizeof(stc));
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Cannot get video PTS\n"));
					}
					
					DCCSTCGetTimeResolution(dcc_info.pStcSource, DCC_Video, &timeScale);

					if (timeScale == 90000)
						stc *= 2;

					DCCSTCGetTime(dcc_info.pStcSource, &currentSTC, timeScale);

					RMDBGLOG((ENABLE, "resync STC(%llu) to %llu, timeScale %lu\n", currentSTC, stc, timeScale));

					DCCSTCSetTime(dcc_info.pStcSource, stc, timeScale);
					
					context.ResyncTimer = FALSE;
				} else if (context.FirstPTS) { //after a seek
					RMDBGLOG((ENABLE, "first pts %lu\n", context.FirstPTS));
					DCCSTCSetTime(dcc_info.pStcSource, context.FirstPTS, 90000);
					Info.ValidFields = TIME_STAMP_INFO;
					Info.TimeStamp = context.FirstPTS;
					context.FirstPTS = 0;
					context.FirstSystemTimeStamp = FALSE;
				} else {
					Info.ValidFields = 0;
					Info.TimeStamp = 0;
				}				

				if (RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Prebuffering) {
					RMDBGPRINT((ENABLE, "."));
				}
				
				if (context.video_opt->MSflag == TRUE) {
					if ((RMint64) MSPts != -1) {
						Info.ValidFields = context.play_opt->send_video_pts ? TIME_STAMP_INFO:0;
						Info.TimeStamp = MSPts;
					} else
						Info.ValidFields = 0;

					RMDBGLOG((DISABLE, "MSPts = %lld (0x%llx) pts= %lld (0x%llx) (valid %lu) byte_counter=0x%lx\n", 
						  MSPts, 
						  MSPts,
						  Info.TimeStamp, 
						  Info.TimeStamp,
						  Info.ValidFields,
						  context.byte_counter));
				}

				RMDBGLOG((SENDDBG, "sending %lu bytes, pts %llu, valid %lu\n", count, Info.TimeStamp, (RMuint32)Info.ValidFields));
				if (Info.ValidFields)
					context.last_video_pts = Info.TimeStamp;

				while (RUASendData(dcc_info.pRUA, dcc_info.video_decoder, pDMA, buf, count, &Info, sizeof(Info)) != RM_OK) {
					struct RUAEvent e;

					/* see previous comment on RUAGetBuffer */
					check_prebuf_state(&context, 0);

					PROCESS_KEY(TRUE, TRUE);
					
					e.ModuleID = dcc_info.video_decoder;
					e.Mask = RUAEVENT_XFER_FIFO_READY;
					RUAWaitForMultipleEvents(dcc_info.pRUA, &e, 1, COMMON_TIMEOUT_US, NULL);
				}

				context.bitrate += count * 8;

				context.byte_counter += count;

				/* sendind data may fill-up the xfer fifo, so we reset the event */
				{
					struct RUAEvent e;
					
					e.ModuleID = dcc_info.video_decoder;
					e.Mask = RUAEVENT_XFER_FIFO_READY;
					RUAResetEvent(dcc_info.pRUA, &e);
				}
				
				RUAReleaseBuffer(pDMA, buf);
				buf = NULL;
				
			} //while(1)

			check_prebuf_state(&context, 0);

			switch (context.play_opt->disk_ctrl_state) {
			case DISK_CONTROL_STATE_DISABLE:
			case DISK_CONTROL_STATE_SLEEPING:
				break;
			case DISK_CONTROL_STATE_RUNNING:
				if(context.play_opt->disk_ctrl_callback && context.play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_SLEEP) == RM_OK)
					context.play_opt->disk_ctrl_state = DISK_CONTROL_STATE_SLEEPING;
				break;
			}
			
			if(0){ /* don't wait for eos, won't work well with ppf yet */
				err = WaitForEOS(&context, &actions);
				{
					RMuint64 stc;
					DCCSTCGetTime(dcc_info.pStcSource, &stc, 90000);
				
					RMDBGLOG((ENABLE, "Timer duration %llu s\n", stc/90000));
				}
				if (err == RM_KEY_WHILE_WAITING_EOS) {
					RMDBGLOG((ENABLE, "command while waiting for EOS\n"));
					err = RM_OK;
					PROCESS_KEY(FALSE, FALSE);
				}
				else {
#ifdef WITH_MONO
					/* callback to signal EOS to curacao/mono */
					RMEOSCallback(); 
					break;
#else
					break;	// EOS
#endif
				}
			}
			else
				break;
		} // additional while
		
		if (context.play_opt->loop_count > 0)
			context.play_opt->loop_count --;

		/* if there is another loop, stop devices */
		if ((context.play_opt->loop_count > 0) || (context.play_opt->waitexit != TRUE) || (context.play_opt->infinite_loop))
			Stop(&context, RM_DEVICES_VIDEO | RM_DEVICES_STC);


	} while ((context.play_opt->loop_count > 0) || (context.play_opt->infinite_loop));
	
 cleanup:
	if (file)
		RMCloseFile(file);

	if( context.play_opt->waitexit ) {
		RMascii key;
		Stop(&context, RM_DEVICES_STC);
		fprintf(stderr, "press q key again if you really want to stop & quit\n");
		while ( !(RMGetKeyNoWait(&key) && ((key == 'q') || (key =='Q'))) );
		Stop(&context, RM_DEVICES_VIDEO | RM_DEVICES_STC);
	}
#ifndef WITH_MONO	
	RMTermExit();
#endif

	if (dmabuffer_index) {
		RMuint32 i;
		for (i = 0; i < dmabuffer_index; i++) {
			RUAReleaseBuffer(pDMA, dmabuffer_array[i]);
			RMDBGLOG((ENABLE, "released buffer[%lu] @ 0x%08lx\n", i, dmabuffer_array[i]));
		}
		RMFree(dmabuffer_array);
	}

	
	if (dcc_info.pStcSource) {
		Stop(&context, RM_DEVICES_STC);
		RMDBGLOG((DEBUG, "Closing STC...\n"));
		err = DCCSTCClose(dcc_info.pStcSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error cannot close STC %d\n", err));
		}
		RMDBGLOG((DEBUG, "Done closing STC.\n"));
	}
 
	

	if (pVideoSource) {
		RMDBGLOG((DEBUG, "Stopping video source...\n"));
		err = DCCStopVideoSource(pVideoSource, DCCStopMode_LastFrame);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot stop video decoder %d\n", err));
		}
		RMDBGLOG((DEBUG, "Done stopping video source.\n"));

		RMDBGLOG((DEBUG, "Closing video source...\n"));
		err = DCCCloseVideoSource(pVideoSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error cannot close video decoder %d\n", err));
		}
		RMDBGLOG((DEBUG, "Done closing video source.\n"));
#ifndef WITH_MONO
		clear_display_options(&dcc_info, context.disp_opt);
#endif /*WITH_MONO*/
	}

	clear_video_options(&dcc_info, context.video_opt);
	
	if (pDMA) {
		RMDBGLOG((DEBUG, "Closing RUA DMA pool...\n"));
		err = RUAClosePool(pDMA);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error cannot close dmapool %d\n", err));
		}
		RMDBGLOG((DEBUG, "Done closing RUA DMA pool.\n"));
	}
#ifndef WITH_MONO
	err = DCCClose(dcc_info.pDCC);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot close DCC %d\n", err));
	}

	err = RUADestroyInstance(dcc_info.pRUA);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot destroy RUA instance %d\n", err));
		return -1;
	}
#endif /*WITH_MONO*/
	


	return 0;
}
