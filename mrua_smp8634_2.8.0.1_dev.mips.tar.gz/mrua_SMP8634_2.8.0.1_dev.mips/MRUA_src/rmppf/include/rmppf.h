/*****************************************
 Copyright © 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   rmrtk.h
  @brief  RealMagic picture post-filtering API

  
  @author Oriol Prieto
  @date   2007-01-09
*/

#ifndef __RMPPF_H__
#define __RMPPF_H__


struct RMppf;


RMstatus RMPPFCreateInstance(struct RMppf **ppInstance);


/*    This function fills up a list with the sizes of DRAM blocks that are */
/*    required for proper functioning of the ppf module (e.g needed for */
/*    GFX engine control structures if the filter requires gfx */
/*    operation). Note that in the requiredmemblocks, only the size of */
/*    each block is written. */


RMstatus RMPPFGetEngineMem(struct RMppf *pPPF, RMuint32 filter_slot, struct EMhwlibMemoryBlockList* requiredmemblocks);

/* RMstatus RMPPFGetEngineMem(struct EMhwlibMemoryBlockList *requiredmemblocks); */

/*    This is used to tell the ppf module that the requested memory */
/*    blocks have been allocated (and their position). Both size and */
/*    address are valid for each block on allocatedmemblocks. */

RMstatus RMPPFSetEngineMem(struct RMppf *pPPF, RMuint32 filter_slot, struct EMhwlibMemoryBlockList *allocatedmemblocks);

/*    This function returns a list with DRAM blocks that are required for */
/*    proper functioning of the ppf module (e.g needed for GFX engine */
/*    control structures if the filter requires gfx operation). In */
/*    requiredmemblocks, only the size of each block is filled up.  */

RMstatus RMPPFGetOutputMem(struct RMppf *pPPF, RMuint32 filter_slot, RMuint32 output_slot, struct EMhwlibMemoryBlockList *requiredmemblocks);
  
/*    This is used to tell the ppf module that the requested memory */
/*    blocks to create an output surface have been allocated (and their  */
/*    position). Both size and address are valid for each block. The ppf */
/*    module will typically create the surface on this function.         */

RMstatus RMPPFSetOutputMem(struct RMppf *pPPF, RMuint32 filter_slot, RMuint32 output_slot, struct EMhwlibMemoryBlockList *allocatedmemblocks);

/*    Retrieves the address of the output surface created by the ppf  */
/*    module (using the memory provided by set_output_mem()).         */

RMstatus RMPPFGetOutputSurface(struct RMppf *pPPF, RMuint32 filter_slot, RMuint32 output_slot, RMuint32 *output_surface);
	 
/*    Used to set the address of one of the input surfaces. The input */
/*    surfaces are not allocated by the ppf module, but by their */
/*    respective producers (e.g. a video decoder or a different ppf */
/*    module). */

RMstatus RMPPFSetInputSurface(struct RMppf *pPPF, RMuint32 filter_slot, RMuint32 input_slot, RMuint32 input_surface);

/*    It can be used to pass a buffer of arbitrary size to the ppf module */
/*    (command param) and/or to retrieve a buffer of arbitrary size from */
/*    the ppf module. This is needed in some particular cases where the */
/*    applications needs a finer degree of interaction with the ppf */
/*    module, that cannot be achieved with the generic functions */
/*    described above. An application may want to change the way the ppf */
/*    module processes pictures based on a user command (e.g move that */
/*    window to the left). Or get information on the status of the module */
/*    (e.g. how many pictures have you processed?). Of course, this */
/*    implies that both the application and the ppf module agree on a */
/*    syntax for command param and result_param (this syntax to be */
/*    defined on a public header file from the module). */

RMstatus RMPPFSetCommand(struct RMppf *pPPF, RMuint32 filter_slot, void *command_param, RMuint32 param_size, void *command_result, RMuint32 result_size);


#endif
