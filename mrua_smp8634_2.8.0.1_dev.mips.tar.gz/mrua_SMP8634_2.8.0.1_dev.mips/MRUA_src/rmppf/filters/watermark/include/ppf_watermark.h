/****************************************
 Copyright © 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   emhwlib_displaytypes.h
  @brief  

  long description

*/

#ifndef __PPF_WATERMARK_H__
#define __PPF_WATERMARK_H__

enum ppf_watermark_cmd{
	ppf_watermark_cmd_play,
	ppf_watermark_cmd_stop,
};


#endif
