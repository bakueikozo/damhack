#define ALLOW_OS_CODE 1


#include "../../../../emhwlib/include/emhwlib.h"
#include "../../../../emhwlib/include/emhwlib_displaytypes.h"


/* it seems weird that this is not included from the emhwlib.h */
#include "../../../../emhwlib/include/emhwlib_properties_1000.h"


#include "../../../dock/include/filters.h"

#include "../include/ppf_watermark.h"

#define PPFDBG DISABLE

#define GFX_COMMAND_COUNT (32)
#define CARBON_MAX_PIC_WIDTH (1920)
#define CARBON_MAX_PIC_HEIGHT (1088)
#define CARBON_PICTURE_COUNT (7)

extern unsigned long module_id;
extern unsigned long pE;
extern unsigned long pEm;

/* Ignored anyway */
#define PGBUS ((struct gbus *)1)


/*
  TODO
 * Check that gfx commands could be sent, and retry again later if they didn't.
*/


#define SEND_GFX_COMMAND(propertyID, pValue, ValueSize)	   								\
{															\
	if(RMFAILED(EMhwlibSetProperty((struct EMhwlib *)pEm, context.gfx_task, propertyID, pValue, ValueSize)))	\
		RMDBGLOG((ENABLE, "COULD NOT SEND COMMAND!!\n"));							\
}

/* 
   Let's avoid including any rua files by now.
   After cleanup, ppf modules should be 
   EMhwlib-dependent only
*/

typedef RMuint32 (*Event_callback) (void *pEm,RMuint32 ModuleID,RMuint32 mask);
RMstatus krua_register_event_callback(void *pEm, RMuint32 ModuleID, RMuint32 mask, Event_callback callback);
RMstatus krua_unregister_event_callback(void *pEm, RMuint32 ModuleID,  Event_callback callback);


/* This filter has only two state: "play" and "stop" */
enum ppf_watermark_state{
	ppf_watermark_state_play,
	ppf_watermark_state_stop
};



struct ppf_watermark_context{
	struct EMhwlibSurfaceReader input;
	RMuint32 carbon_output;
	RMuint32 marked_output;
	enum ppf_watermark_state state;
	RMuint32 on_display_pics;
	RMuint32 gfx_task;
	RMuint32 carbon_pictures[CARBON_PICTURE_COUNT];
	RMuint32 carbon_pictures_parent[CARBON_PICTURE_COUNT];
	RMuint32 carbon_buffers[CARBON_PICTURE_COUNT];
};
static struct ppf_watermark_context context;

RMstatus watermark_get_engine_mem(struct EMhwlibMemoryBlockList *requiredmemblocks);
RMstatus watermark_set_engine_mem(struct EMhwlibMemoryBlockList *allocatedmemblocks);
RMstatus watermark_get_output_mem(RMuint32 output_slot, struct EMhwlibMemoryBlockList *requiredmemblocks);
RMstatus watermark_set_output_mem(RMuint32 output_slot, struct EMhwlibMemoryBlockList *allocatedmemblocks);
RMstatus watermark_get_output(RMuint32 output_slot, RMuint32 *output_surface);
RMstatus watermark_set_input(RMuint32 input_slot, RMuint32 input_surface);
RMstatus watermark_set_command(void *command_param, RMuint32 param_size, void *command_result, RMuint32 result_size);

/* these are not part of the handler */
RMstatus watermark_run_filter(RMuint32 dummy);
RMstatus watermark_init(void);
RMstatus watermark_deinit(void);

/* This is defined in common.c */
int ppf_schedule_filter(void *pE, RMuint32 ModuleID, RMuint32 mask);

RMstatus (*ppf_init)(void) = watermark_init;
RMstatus (*ppf_deinit)(void) = watermark_deinit;
RMstatus (*ppf_run_filter)(RMuint32 dummy) = watermark_run_filter;


/* Filters functions */

RMstatus watermark_get_engine_mem(struct EMhwlibMemoryBlockList *requiredmemblocks)
{
	/* this module does not require any DRAM memory */
	RMstatus err;
		
	struct GFXEngine_DRAMSize_in_type  dramSizeIn;
	struct GFXEngine_DRAMSize_out_type dramSizeOut;
		
	RMDBGLOG((ENABLE, "at watermark set engine mem \n"));

	dramSizeIn.CommandFIFOCount = GFX_COMMAND_COUNT;
	err = EMhwlibExchangeProperty((struct EMhwlib *)pEm, EMHWLIB_MODULE(GFXEngine,0), RMGFXEnginePropertyID_DRAMSize,
				  &dramSizeIn, sizeof(dramSizeIn), &dramSizeOut, sizeof(dramSizeOut));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting required size for GFX engine\n"));
		return RM_ERROR;
	}

	requiredmemblocks->BlockCount = 1;
	requiredmemblocks->Blocks[0].Size = dramSizeOut.UncachedSize;
	
	return RM_OK;
}

RMstatus watermark_set_engine_mem(struct EMhwlibMemoryBlockList *allocatedmemblocks)
{

	RMuint32 gfx_count; 
	RMuint32 i;
	struct GFXEngine_Open_type gfx_profile;
	RMstatus err;


	RMDBGLOG((ENABLE, "at watermark set engine mem \n"));
	if(allocatedmemblocks->BlockCount != 1){
		RMDBGLOG((ENABLE, "WARNING: Expecting 1 allocated mem block, got %ld!\n", allocatedmemblocks->BlockCount));
		return RM_ERROR;
	}

	/* we don't need any memory here */
	gfx_profile.CommandFIFOCount = GFX_COMMAND_COUNT;
	gfx_profile.Priority = 1;
	gfx_profile.CachedSize = 0;
	gfx_profile.UncachedSize = allocatedmemblocks->Blocks[0].Size;
	gfx_profile.UncachedAddress = allocatedmemblocks->Blocks[0].Address;
	
	context.gfx_task = GFXEngine;

	err = EMhwlibExchangeProperty((struct EMhwlib *)pEm, EMHWLIB_MODULE(Enumerator,0),  RMEnumeratorPropertyID_CategoryIDToNumberOfInstances, 
				  &(context.gfx_task), sizeof(context.gfx_task), &gfx_count, sizeof(gfx_count));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting gfx engine count\n"));
		return RM_ERROR;
	}
	
	for (i=0 ; i<(RMint32) gfx_count ; i++) {
		context.gfx_task = EMHWLIB_MODULE(GFXEngine, i);
		err = EMhwlibSetProperty((struct EMhwlib *)pEm, context.gfx_task, RMGFXEnginePropertyID_Open, &gfx_profile, sizeof(gfx_profile));
		if (err == RM_OK){
			RMDBGLOG((ENABLE, "OK, using task %ld (module id %ld)\n", i, context.gfx_task));
			break;
		}
	}
	
	
	if (i==(RMint32)gfx_count) {
		RMDBGLOG((ENABLE, "Could not open a gfx engine task\n"));
		return -1;
	}

	return RM_OK;
}

RMstatus watermark_get_output_mem(RMuint32 output_slot, struct EMhwlibMemoryBlockList *requiredmemblocks)
{
	RMuint32 surface_size;
	RMstatus err;
	RMuint32 picture_count = CARBON_PICTURE_COUNT;

	/* 
	   The pictures are allocated by the creator of the input surfaces
	   (i.e.) no new pictures are needed for the output surfaces.
	   We only need enough memory to create the surface structure.
	*/
	if(output_slot != 0){
		RMDBGLOG((ENABLE, "Invalid slot!\n"));
		return RM_ERROR;
	}

		

	err = EMhwlibExchangeProperty((struct EMhwlib *)pEm,DisplayBlock, RMDisplayBlockPropertyID_MultiplePictureSurfaceSize,
				      &picture_count, sizeof(picture_count), &surface_size, sizeof(surface_size));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get the size of a surface\n"));
		return err;
	}
	requiredmemblocks->BlockCount = 3;
	requiredmemblocks->Blocks[0].Size = surface_size;
	requiredmemblocks->Blocks[0].Address = 0;
	requiredmemblocks->Blocks[1].Size = surface_size;
	requiredmemblocks->Blocks[1].Address = 0; 
	requiredmemblocks->Blocks[2].Size = (CARBON_PICTURE_COUNT*(CARBON_MAX_PIC_WIDTH*CARBON_MAX_PIC_HEIGHT + sizeof(struct EMhwlibNewPicture)));
	requiredmemblocks->Blocks[2].Address = 0; 

	RMDBGLOG((ENABLE, "sizeof picture is %ld\n", sizeof(struct EMhwlibNewPicture)));

	return RM_OK;
}

RMstatus watermark_set_output_mem(RMuint32 output_slot, struct EMhwlibMemoryBlockList *allocatedmemblocks)
{
	struct DisplayBlock_InitMultiplePictureSurfaceX_type surface_init;
	RMstatus err;
	RMuint32 i;
	RMstatus pic_buffer_ptr;
	if(output_slot != 0){
		RMDBGLOG((ENABLE, "Invalid slot!\n"));
		return RM_ERROR;
	}


	if((allocatedmemblocks->BlockCount == 0)
	   ||(allocatedmemblocks->Blocks[0].Address == 0)){
		RMDBGLOG((PPFDBG, "Unsetting carbon output slot %ld\n", output_slot));
		context.carbon_output = 0;
		return RM_ERROR;
	}
		
	if(context.carbon_output != 0){
		RMDBGLOG((ENABLE, "This slot is used already!\n"));
		return RM_ERROR;
	}

	if(context.marked_output != 0){
		RMDBGLOG((ENABLE, "This slot is used already!\n"));
		return RM_ERROR;
	}

	if(allocatedmemblocks->BlockCount != 3){
		RMDBGLOG((ENABLE, "Requested 3 blocks, got %ld\n",
			  allocatedmemblocks->BlockCount));
		return RM_ERROR;
	}
	
	surface_init.Address = allocatedmemblocks->Blocks[0].Address;
	surface_init.ColorMode = EMhwlibColorMode_VideoNonInterleaved;
	surface_init.ColorFormat = EMhwlibColorFormat_24BPP;
	surface_init.SamplingMode = EMhwlibSamplingMode_420;
	surface_init.ColorSpace = EMhwlibColorSpace_YUV_601;
	surface_init.PixelAspectRatio.X = 1;
	surface_init.PixelAspectRatio.Y = 1;
	surface_init.PictureCount = CARBON_PICTURE_COUNT;
	surface_init.STCModuleId = EMHWLIB_MODULE(STC, 0); /* hope */
	surface_init.Tiled = 1;
	err = EMhwlibSetProperty((struct EMhwlib *)pEm, DisplayBlock, RMDisplayBlockPropertyID_InitMultiplePictureSurfaceX,
				 &surface_init, sizeof(surface_init));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error Cannot initialize surface\n"));
		return err;
	}

	context.carbon_output = surface_init.Address;

	surface_init.Address = allocatedmemblocks->Blocks[1].Address;
	surface_init.ColorMode = EMhwlibColorMode_VideoNonInterleaved;
	surface_init.ColorFormat = EMhwlibColorFormat_24BPP;
	surface_init.SamplingMode = EMhwlibSamplingMode_420;
	surface_init.ColorSpace = EMhwlibColorSpace_YUV_601;
	surface_init.PixelAspectRatio.X = 1;
	surface_init.PixelAspectRatio.Y = 1;
	surface_init.PictureCount = CARBON_PICTURE_COUNT;
	surface_init.STCModuleId = EMHWLIB_MODULE(STC, 0); /* hope */
	surface_init.Tiled = 1;
	
	err = EMhwlibSetProperty((struct EMhwlib *)pEm, DisplayBlock, RMDisplayBlockPropertyID_InitMultiplePictureSurfaceX,
				 &surface_init, sizeof(surface_init));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error Cannot initialize surface\n"));
		return err;
	}

	context.marked_output = surface_init.Address;

	pic_buffer_ptr = allocatedmemblocks->Blocks[2].Address;

	for(i = 0; i < CARBON_PICTURE_COUNT; i++){
		/* TODO: Check that size is correct */
		context.carbon_pictures[i] = pic_buffer_ptr;
		pic_buffer_ptr += sizeof(struct EMhwlibNewPicture);
	}

	pic_buffer_ptr = (pic_buffer_ptr + 4095) & (~4095); /* align to 4k */

	for(i = 0; i < CARBON_PICTURE_COUNT; i++){
		context.carbon_buffers[i] = pic_buffer_ptr;
		pic_buffer_ptr += CARBON_MAX_PIC_WIDTH*CARBON_MAX_PIC_HEIGHT;

		
	}

	for(i = 0; i < CARBON_PICTURE_COUNT; i++){
		struct EMhwlibNewPicture *carbon_pic;
		carbon_pic = (struct EMhwlibNewPicture*)context.carbon_pictures[i];
		gbus_write_uint32(PGBUS, (RMuint32) & (carbon_pic->picture_display_status), 0);
		RMDBGLOG((ENABLE, "final: 0x%08lx:0x%08lx\n", context.carbon_pictures[i], context.carbon_buffers[i]));
	}


	RMDBGLOG((ENABLE, "Initialized output surface at 0x%08lx\n", context.carbon_output));
	return RM_OK;
}


RMstatus watermark_get_output(RMuint32 output_slot, RMuint32 *output_surface)
{
	if(output_slot != 0){
		RMDBGLOG((ENABLE, "Invalid slot!\n"));
		return RM_ERROR;
	}

	*output_surface = context.marked_output;
	
	return RM_OK;
}



RMstatus watermark_set_input(RMuint32 input_slot, RMuint32 input_surface)
{
	RMuint32 reader_id;
	RMstatus err  = RM_OK;

	/* This filter only support one input slot */
	if(input_slot!=0){
		RMDBGLOG((ENABLE, "Invalid slot\n"));
		return RM_ERROR;
	}
	
	if(input_surface == 0){
		RMDBGLOG((ENABLE, "Unseting input surface slot\n"));
		context.input.SurfaceAddress = 0;
		return RM_OK;
	}

	if(context.input.SurfaceAddress != 0){
		RMDBGLOG((ENABLE, "Input Surface already used!\n"));
		return RM_ERROR;
	}

	context.input.SurfaceAddress = input_surface;

	/* TODO: We should check that the input surface is
	 * compatible with the output surface 
	 */

	/* 
	   The ConnectReader API says that we can put the "desired" reader id here
	   but it may change during the call
	*/
	context.input.ReaderID = 0; /* 0 = input slot - Only one in this case */

	err = EMhwlibExchangeProperty((struct EMhwlib *)pEm, DisplayBlock, RMDisplayBlockPropertyID_ConnectReader,
				      &context.input, sizeof(context.input), &reader_id, sizeof(reader_id));
	if(RMFAILED(err)){
		RMDBGLOG((ENABLE, "Connect reader failed: unsetting input\n"));
		context.input.SurfaceAddress = 0;
		return RM_ERROR;
	}
	
	/* This is the one to use */
	context.input.ReaderID = reader_id;

	RMDBGLOG((PPFDBG,"connected to surface 0x%08lx with reader_id %ld\n", input_surface, reader_id));

	/* Surface properties : */
	
	{	
		/* HACK: there is no property, so we do this ugly typecasting to look at
		 * the real structure behind the opaque address */
		
		struct EMhwlibSurface *s;

		s = (struct EMhwlibSurface *)input_surface;
	
		RMDBGLOG((ENABLE,
			  "Surface: module id=%08x, video_timer=%08x, tiled=%08x\n",
			  gbus_read_uint32(PGBUS, (RMuint32)&s->module_id),
			  gbus_read_uint32(PGBUS, (RMuint32)&s->video_timer_index),
			  gbus_read_uint32(PGBUS, (RMuint32)&s->tiled)
			  ));
	}


	

	return RM_OK;
}

RMstatus watermark_set_command(void *command_param, RMuint32 param_size, void *command_result, RMuint32 result_size)
{
	enum ppf_watermark_cmd cmd;
	RMDBGLOG((ENABLE, "at command param\n"));
	if(param_size != sizeof(enum ppf_watermark_cmd)){
		RMDBGLOG((ENABLE, "Invalid param size!\n"));
		return RM_ERROR;
	}

	if(command_param == NULL){
		RMDBGLOG((ENABLE, "Invalid param address!\n"));
		return RM_ERROR;
	}

	/* 
	   Most ppf modules will need to handle play/stop
	   commands. We did not add a generic function for
	   this because in the near future the aim is to pass
	   those commands via the input surfaces.
	   So temporarily this is implemented here as a custom
	   command of each ppf module.
	*/

	cmd = *(enum ppf_watermark_cmd *)command_param;
	switch(cmd){
	case ppf_watermark_cmd_play:
		context.state = ppf_watermark_state_play;
		break;
	case ppf_watermark_cmd_stop:
		context.state = ppf_watermark_state_stop;
		break;
	}

	return RM_OK;
}



/*
  Video pictures are relased when the associated carbon pictures
  are released by the display.
  We cannot release them before because the carbon pictures use
  the video pictures' chroma buffers.
*/

static void free_video_pictures()
{
	RMuint32 i;
	RMuint32 released = 0;
	for(i = 0; i < CARBON_PICTURE_COUNT; i++){
		struct EMhwlibNewPicture *pic = (struct EMhwlibNewPicture*)context.carbon_pictures[i];
		if((context.carbon_pictures_parent[i] != 0) &&
		   (gbus_read_uint32(PGBUS, (RMuint32) & (pic->picture_display_status)) == 0)){
			struct EMhwlibNewPicture *parent_pic = (struct EMhwlibNewPicture*)context.carbon_pictures_parent[i];
			gbus_write_uint32(PGBUS, (RMuint32) & (parent_pic->picture_display_status), 0);
			context.carbon_pictures_parent[i] = 0;
			released++;
		}/* else */
/* 			RMDBGLOG((ENABLE, "no because %ld and %ld\n", (context.carbon_pictures_parent[i] != 0),(gbus_read_uint32(PGBUS, (RMuint32) & (pic->picture_display_status)) == 0) )); */
	}
	
}


/* 
   Returns the index of an available carbon picture.
   If the return value is CARBON_PICTURE_COUNT, it
   means that no pictures are available
*/
static RMuint32 get_carbon_picture()
{
	RMuint32 i;
	for(i = 0; i < CARBON_PICTURE_COUNT; i++){
		struct EMhwlibNewPicture *pic = (struct EMhwlibNewPicture*)context.carbon_pictures[i];
		
		if((context.carbon_pictures_parent[i] == 0) &&
		   (gbus_read_uint32(PGBUS, (RMuint32) & (pic->picture_display_status)) == 0)){
			break;
		}
	}
	return i;
}

static void copy_luma(struct EMhwlibNewPicture *src_pic, struct EMhwlibNewPicture *dst_pic)
{
	struct GFXEngine_Surface_type surface_param;
	struct GFXEngine_ColorFormat_type format_param;
	struct GFXEngine_MoveReplaceRectangle_type move_param;

	format_param.MainMode = EMhwlibColorMode_LUT_8BPP;
	format_param.SubMode = EMhwlibColorFormat_32BPP;
		
	surface_param.StartAddress = dst_pic->luma_address;
	surface_param.TotalWidth = dst_pic->luma_total_width;
	surface_param.Tiled = TRUE;


	surface_param.SurfaceID = GFX_SURFACE_ID_NX;
	format_param.SurfaceID = GFX_SURFACE_ID_NX;
	SEND_GFX_COMMAND(RMGFXEnginePropertyID_Surface, &surface_param, sizeof(surface_param));
	SEND_GFX_COMMAND(RMGFXEnginePropertyID_ColorFormat, &format_param, sizeof(format_param));

	surface_param.StartAddress = src_pic->luma_address;
	surface_param.TotalWidth = src_pic->luma_total_width;
	surface_param.Tiled = TRUE;

	surface_param.SurfaceID = GFX_SURFACE_ID_Y;
	format_param.SurfaceID = GFX_SURFACE_ID_Y;
	SEND_GFX_COMMAND(RMGFXEnginePropertyID_Surface, &surface_param, sizeof(surface_param));
	SEND_GFX_COMMAND(RMGFXEnginePropertyID_ColorFormat, &format_param, sizeof(format_param));

	move_param.SrcX = 0;
	move_param.SrcY = 0;
	move_param.Width = src_pic->luma_position_in_buffer.width;
	move_param.Height = src_pic->luma_position_in_buffer.height;

	move_param.Width = RMmin(src_pic->luma_position_in_buffer.width, CARBON_MAX_PIC_WIDTH);
	move_param.Height = RMmin(src_pic->luma_position_in_buffer.height, CARBON_MAX_PIC_HEIGHT);

	move_param.DstX = 0;
	move_param.DstY = 0;
	move_param.AlphaX = 0;
	move_param.AlphaY = 0;
	move_param.Merge = FALSE;

	SEND_GFX_COMMAND(RMGFXEnginePropertyID_MoveRectangle, &move_param, sizeof(move_param));

}



/* 
   1) Get one picture from the video surface
   2) Create a picture using a copy of the video picture's luma buffer and the original chroma buffers.
   3) Insert that picture into the carbon_output surface
*/

static RMstatus video_to_carbon(void)
{




	struct GFXEngine_DisplayPicture_type display_pic;
	struct EMhwlibPictureInfo video_pic;
	struct EMhwlibNewPicture carbon_pic;
	RMuint32 carbon_pic_id;
	RMstatus err;
	err = EMhwlibExchangeProperty((struct EMhwlib *)pEm, DisplayBlock,
				      RMDisplayBlockPropertyID_PeekNextPicture,
				      &(context.input), sizeof(context.input),
				      &video_pic, sizeof(video_pic));


	if((err == RM_OK) && video_pic.PictureAddress){
		carbon_pic_id = get_carbon_picture();
		if(carbon_pic_id < CARBON_PICTURE_COUNT){
			carbon_pic = video_pic.Picture;
			carbon_pic.luma_address = context.carbon_buffers[carbon_pic_id];
			carbon_pic.picture_display_status = 1;

			gbus_write_data32(PGBUS, context.carbon_pictures[carbon_pic_id], (RMuint32*)&carbon_pic, sizeof(struct EMhwlibNewPicture)/sizeof(RMuint32));
			copy_luma(&video_pic.Picture, &carbon_pic);
			context.carbon_pictures_parent[carbon_pic_id] = video_pic.PictureAddress;

			display_pic.Surface = context.carbon_output;
			display_pic.Picture = context.carbon_pictures[carbon_pic_id];
			display_pic.Pts = (RMuint64)video_pic.Picture.first_pts_lo | ((RMuint64) video_pic.Picture.first_pts_hi)<<32;
			SEND_GFX_COMMAND(RMGFXEnginePropertyID_DisplayPicture, &display_pic, sizeof(display_pic));
			context.input.emhwlibReserved = video_pic.PictureAddress;
			err = EMhwlibSetProperty((struct EMhwlib *)pEm, DisplayBlock, RMDisplayBlockPropertyID_AcquirePicture,
						 &(context.input), sizeof(context.input));
			
			
		}
		else{
			RMDBGLOG((ENABLE, "cant get a carbon picture\n"));
			return RM_PENDING;
		}


	}else{
		return RM_PENDING;
	}

	return RM_OK;

}

static void watermark_picture(struct EMhwlibNewPicture *Picture)
{
	RMuint32 x,y,x0,y0,w,h;

	RMDBGLOG((DISABLE, "luma:%p, luma_width:%08x, frame:%08x, win: %08x:%08x-%08x*%08x\n", 
		Picture->luma_address, Picture->luma_total_width, Picture->frame_count,
		Picture->luma_position_in_buffer.x, Picture->luma_position_in_buffer.y,
		Picture->luma_position_in_buffer.width, Picture->luma_position_in_buffer.height));


	w = 256;
	h = 128;
	x0 = 8;
	y0 = 8;


	for(y = y0; y < y0+h; y++) {
		for(x=x0; x<x0+w; x++) {
			RMuint32 addr, luma;
			addr = Picture->luma_address + 128*y + x;
			addr=Picture->luma_address + (x/128)*4096+(y/32)*Picture->luma_total_width*32+(x%128)+((y%32)*128);
			luma = gbus_read_uint8(PGBUS, addr);
			luma = (luma < 128) ? ((luma < 64) ? 32 : 96) : ((luma < 192) ? 160: 224);
			gbus_write_uint8(PGBUS, addr, luma);

		}
	}
}



/* 
   1) Get one picture from the carbon surface
   2) Modify its luma (watermark it)
   3) Insert that picture into the marked_output surface
*/
static RMstatus carbon_to_marked()
{
	struct EMhwlibPictureInfo carbon_pic_info;
	struct EMhwlibSurfaceReader carbon_surface_reader;
	struct DisplayBlock_InsertPictureInSurfaceFifo_type insert_pic;
	RMstatus err;


	carbon_surface_reader.ReaderID = 0;
	carbon_surface_reader.SurfaceAddress = context.carbon_output;

		
	err = EMhwlibExchangeProperty((struct EMhwlib *)pEm, DisplayBlock,
				      RMDisplayBlockPropertyID_PeekNextPicture,
				      &(carbon_surface_reader), sizeof(carbon_surface_reader),
				      &carbon_pic_info, sizeof(carbon_pic_info));
		
		
	if((err == RM_OK) && carbon_pic_info.PictureAddress){
		insert_pic.Surface = context.marked_output;
		insert_pic.Picture = carbon_pic_info.PictureAddress;
		watermark_picture(&carbon_pic_info.Picture);
		

		err = EMhwlibSetProperty((struct EMhwlib *)pEm, DisplayBlock, RMDisplayBlockPropertyID_InsertPictureInSurfaceFifo,
					 &insert_pic, sizeof(insert_pic));
		if(err == RM_OK){
			
			carbon_surface_reader.emhwlibReserved = carbon_pic_info.PictureAddress;
			err = EMhwlibSetProperty((struct EMhwlib *)pEm, DisplayBlock, RMDisplayBlockPropertyID_AcquirePicture,
						 &(carbon_surface_reader), sizeof(carbon_surface_reader));
		}
		else{
			RMDBGLOG((ENABLE, "cannot insert yet, try again later\n"));
			return RM_PENDING;
		}
			
			
	}else{
		return RM_PENDING;
	}
	return RM_OK;
		

}



RMstatus watermark_run_filter(RMuint32 dummy)
{
	RMstatus err;
	RMuint32 vtc = 0;

	if(context.input.SurfaceAddress == 0){
		RMDBGLOG((PPFDBG, "Not doing anything because no input\n"));
		goto done;
	}

	if((context.carbon_output == 0) || (context.marked_output == 0)){
		RMDBGLOG((PPFDBG, "Not doing anything because no output\n"));
		goto done;
	}

	if(context.state == ppf_watermark_state_stop){
		RMDBGLOG((PPFDBG, "Not doing anything because on stop mode\n"));
		goto done;
	}

	free_video_pictures();

	do{
		err = video_to_carbon();
		vtc++;
	}while(err == RM_OK);

	vtc = 0;
	do{
		err = carbon_to_marked();
		vtc++;
	}while(err == RM_OK);

		


 done:
	{
		/* hack, this function should get the actual mask that triggered its calling and clear it */
		
		RMuint32 mask = EMHWLIB_DISPLAY_EVENT_ID(DispMainAnalogOut);
		err = EMhwlibSetProperty((struct EMhwlib *)pEm, DisplayBlock, RMGenericPropertyID_ClearEventMask,
					 &(mask), sizeof(mask));
		
	}
	

	return RM_OK;
}


RMstatus watermark_init(void)
{

	struct PPFHandle handle = {NULL,}; /* for forward portability */
	RMuint32 i;

	context.input.SurfaceAddress = 0;
	context.carbon_output = 0;
	context.gfx_task = 0;
	context.state = ppf_watermark_state_stop;
	context.on_display_pics = 0;

	for(i = 0; i < CARBON_PICTURE_COUNT; i++){
		context.carbon_pictures_parent[i] = 0;
		context.carbon_pictures[i] = 0;
		context.carbon_buffers[i] = 0;
	}


	handle.get_engine_mem = watermark_get_engine_mem;
	handle.set_engine_mem = watermark_set_engine_mem;
	handle.get_output_mem = watermark_get_output_mem;
	handle.set_output_mem = watermark_set_output_mem;
	handle.get_output = watermark_get_output;
	handle.set_input = watermark_set_input;
	handle.set_command = watermark_set_command;

	RMDBGLOG((ENABLE, "calling register filter\n"));
	PPFDockRegisterFilter(0, &handle);

	/* 
	   this should probably not be done here
	   but let's wait until we cleanup
	   the regiset_event_callback mechanism
	*/ 

	krua_register_event_callback((void*)pE, DisplayBlock, EMHWLIB_DISPLAY_EVENT_ID(DispMainAnalogOut), ppf_schedule_filter);

	return RM_OK;
}


RMstatus watermark_deinit(void)
{
	/* register within the emhwlib */

	krua_unregister_event_callback((void*)pE, DisplayBlock, ppf_schedule_filter);

	return RM_OK;
}

