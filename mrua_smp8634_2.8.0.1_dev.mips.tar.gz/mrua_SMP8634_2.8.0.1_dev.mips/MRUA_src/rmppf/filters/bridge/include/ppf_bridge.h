/****************************************
 Copyright © 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   emhwlib_displaytypes.h
  @brief  

  long description

*/

#ifndef __PPF_BRIDGE_H__
#define __PPF_BRIDGE_H__

enum ppf_bridge_cmd{
	ppf_bridge_cmd_play,
	ppf_bridge_cmd_stop,
};


#endif
