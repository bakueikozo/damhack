#define ALLOW_OS_CODE 1
#include "../../../rmdef/rmdef.h"

#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/version.h>
#include <linux/moduleparam.h>
#include <linux/fs.h>
#include <linux/sched.h>
#include <linux/interrupt.h>
#include <linux/poll.h>
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,18)
#include <linux/devfs_fs_kernel.h>
#endif

RMuint32 slot_id;
RMuint32 chip_id;

RMuint32 pE;
RMuint32 pEm;

RMstatus krua_get_pointers(RMuint32 chip_id, RMuint32 *pe, RMuint32 *pem);



module_param(slot_id, long, 0);
module_param(chip_id, long, 0);


extern RMstatus (*ppf_init)(void);
extern RMstatus (*ppf_deinit)(void);
extern RMstatus (*ppf_run_filter)(RMuint32 dummy);

struct tasklet_struct tasklet;

int ppf_schedule_filter(void *pE, RMuint32 ModuleID, RMuint32 mask)
{
	tasklet_schedule(&tasklet);
	return mask;
}


int init_module(void)
{  
	tasklet_init(&tasklet, ppf_run_filter, 0);

	krua_get_pointers(chip_id, &pE, &pEm);

	ppf_init();
	return 0;
}

void cleanup_module(void)
{
	ppf_deinit();

}


