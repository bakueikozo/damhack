/*****************************************
 Copyright © 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   ppfdock_k.h
  @brief  

  long description

  @author Oriol Prieto
  @date   2007-01-10
*/

#ifndef __PPFDOCK_K_H__
#define __PPFDOCK_K_H__

typedef RMstatus (*ppf_get_engine_mem_func)(struct EMhwlibMemoryBlockList *requiredmemblocks);
typedef RMstatus (*ppf_set_engine_mem_func)(struct EMhwlibMemoryBlockList *allocatedmemblocks);
typedef RMstatus (*ppf_get_output_mem_func)(RMuint32 output_slot, struct EMhwlibMemoryBlockList *requiredmemblocks);
typedef RMstatus (*ppf_set_output_mem_func)(RMuint32 output_slot, struct EMhwlibMemoryBlockList *allocatedmemblocks);
typedef RMstatus (*ppf_get_output_func)(RMuint32 output_slot, RMuint32 *output_surface);
typedef RMstatus (*ppf_set_input_func)(RMuint32 input_slot, RMuint32 input_surface);
typedef RMstatus (*ppf_set_command_func)(void *command_param, RMuint32 param_size, void *command_result, RMuint32 result_size);
/* these are not part of the handler */
/* typedef RMuint32 (*ppf_run_filter_func)(void *pE, RMuint32 ModuleID, RMuint32 mask); */
/* typedef RMstatus (*ppf_init_func)(void); */
/* typedef RMstatus (*ppf_deinit_func)(void); */

struct PPFHandle {
	ppf_get_engine_mem_func get_engine_mem;
	ppf_set_engine_mem_func set_engine_mem;
	ppf_get_output_mem_func get_output_mem;
	ppf_set_output_mem_func set_output_mem;
	ppf_set_input_func set_input;
	ppf_get_output_func get_output;
	ppf_set_command_func set_command;
/* 	ppf_run_filter_func run_filter; */
/* 	ppf_init_func init; */
/* 	ppf_deinit_func deinit; */
};




RMstatus PPFDockRegisterFilter(RMuint32 slot_id, struct PPFHandle *filter);

#endif
