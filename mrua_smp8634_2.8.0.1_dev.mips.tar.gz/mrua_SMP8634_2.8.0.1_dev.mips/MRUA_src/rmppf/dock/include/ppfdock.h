/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmppf_uk.h
  @brief  

  long description

  @author Oriol Prieto
  @date   2007-01-10
*/

#ifndef __RMPPF_UK_H__
#define __RMPPF_UK_H__

#define PPFDOCK_MAJOR 122  // manual selection of major device number
#define PPFDOCK_DEVICE_NAME "ppfdock"
#define PPFDOCK_VERSION 1

#define PPFDOCK_IOCTL_MAGIC 'G'


#define PPFDOCK_IOCTL_GET_ENGINE_MEM        _IOWR(PPFDOCK_IOCTL_MAGIC, 1, struct ppfdock_get_engine_mem_type)
#define PPFDOCK_IOCTL_SET_ENGINE_MEM        _IOWR(PPFDOCK_IOCTL_MAGIC, 2, struct ppfdock_set_engine_mem_type)
#define PPFDOCK_IOCTL_GET_OUTPUT_MEM        _IOWR(PPFDOCK_IOCTL_MAGIC, 3, struct ppfdock_get_output_mem_type)
#define PPFDOCK_IOCTL_SET_OUTPUT_MEM        _IOWR(PPFDOCK_IOCTL_MAGIC, 4, struct ppfdock_set_output_mem_type)
#define PPFDOCK_IOCTL_GET_OUTPUT            _IOWR(PPFDOCK_IOCTL_MAGIC, 5, struct ppfdock_get_output_type)
#define PPFDOCK_IOCTL_SET_INPUT             _IOWR(PPFDOCK_IOCTL_MAGIC, 6, struct ppfdock_set_input_type)
#define PPFDOCK_IOCTL_SET_COMMAND           _IOWR(PPFDOCK_IOCTL_MAGIC, 7, struct ppfdock_set_command)

#define MAX_PROPSIZE 0x1000

struct ppfdock_get_engine_mem_type{
	RMuint32 filter_slot;
	struct EMhwlibMemoryBlockList *requiredmemblocks;
	RMstatus status;
};

struct ppfdock_set_engine_mem_type{
	RMuint32 filter_slot;
	struct EMhwlibMemoryBlockList *allocatedmemblocks;
	RMstatus status;
};

struct ppfdock_get_output_mem_type{
	RMuint32 filter_slot;
	RMuint32 output_slot;
	struct EMhwlibMemoryBlockList *requiredmemblocks;
	RMstatus status;
};

struct ppfdock_set_output_mem_type{
	RMuint32 filter_slot;
	RMuint32 output_slot;
	struct EMhwlibMemoryBlockList *allocatedmemblocks;
	RMstatus status;
};

struct ppfdock_get_output_type{
	RMuint32 filter_slot;
	RMuint32 output_slot;
	RMuint32 *output_surface;
	RMstatus status;
};

struct ppfdock_set_input_type{
	RMuint32 filter_slot;
	RMuint32 input_slot;
	RMuint32 input_surface;
	RMstatus status;
};

struct ppfdock_set_command{
	RMuint32 filter_slot;
	void *command_param;
	RMuint32 param_size;
	void *command_result;
	RMuint32 result_size;
	RMstatus status;

};

enum ppfdock_cmd_id{
	ppf_dock_cmd_id_get_engine_mem = 1,
	ppf_dock_cmd_id_set_engine_mem,
	ppf_dock_cmd_id_get_output_mem,
	ppf_dock_cmd_id_set_output_mem,
	ppf_dock_cmd_id_set_input,
	ppf_dock_cmd_id_get_output,
	ppf_dock_cmd_id_set_command
};

#endif // __RMPPF_UK_H__
