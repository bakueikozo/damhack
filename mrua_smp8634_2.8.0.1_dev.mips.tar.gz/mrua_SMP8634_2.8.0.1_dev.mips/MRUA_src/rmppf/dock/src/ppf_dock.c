/*****************************************
 Copyright � 2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/*
  @file   em8xxx.c
  See licensing details in LICENSING file  
*/

#define ALLOW_OS_CODE 1

#include "../../../emhwlib/include/emhwlib.h"
#include "../include/ppfdock.h"
#include "../include/filters.h"

#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/version.h>
#include <linux/vmalloc.h>

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,17)
#include <linux/moduleparam.h>
#endif

#include <linux/fs.h>
#include <linux/sched.h>
#include <linux/interrupt.h>
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,18)
#include <linux/devfs_fs_kernel.h>
#endif
#include <linux/poll.h>


MODULE_DESCRIPTION("PPF interface module for EM86 chips");
MODULE_AUTHOR("Oriol Prieto <oriol@sdesigns.com>");
#ifdef MODULE_LICENSE
MODULE_LICENSE("Proprietary");  // parsed keyword, don't change!
#endif // MODULE_LICENSE


#define MAX_FILTER_SLOTS 16

struct ppfdockprivate{
	struct PPFHandle filters[MAX_FILTER_SLOTS];

};

struct ppfdockprivate ppfprivate;

RMstatus PPFDockRegisterFilter(RMuint32 slot_id, struct PPFHandle *filter)
{
	RMDBGLOG((ENABLE, "One filter is trying to register on slot %ld\n", slot_id));
	if(slot_id >= MAX_FILTER_SLOTS){
		RMDBGLOG((ENABLE, "Invalid slot id (too big)\n"));
		return RM_ERROR;
	}
	/* TODO make sure that the slot is not used yet...*/
	ppfprivate.filters[slot_id] = *filter;
	return RM_OK;

}



static int ppfdock_ioctl(struct inode *i_node, struct file *filp, unsigned int cmd, unsigned long arg)
{
	int rc = 0;
	struct PPFHandle *filter;
	switch (cmd) {
	case PPFDOCK_IOCTL_GET_ENGINE_MEM:
		{
			struct ppfdock_get_engine_mem_type param;
			struct EMhwlibMemoryBlockList requiredmemblocks;

			RMDBGLOG((ENABLE, "get mem\n"));
			if (copy_from_user(&param, (char *)arg, sizeof(param)) > 0)
				return -EFAULT;

			filter = &ppfprivate.filters[param.filter_slot];

			param.status = filter->get_engine_mem(&requiredmemblocks);
			RMDBGLOG((ENABLE, "called the filter's thing\n"));
		
			if (copy_to_user(param.requiredmemblocks, &requiredmemblocks, sizeof(requiredmemblocks)) > 0) {
				return -EFAULT;
			}
			if (copy_to_user((char *) arg, &param, sizeof(param)) > 0)
				return -EFAULT;
		
			rc = 0;
			break;
		}

	case PPFDOCK_IOCTL_SET_ENGINE_MEM:
		{
			struct ppfdock_set_engine_mem_type param;
			struct EMhwlibMemoryBlockList allocatedmemblocks;
			RMDBGLOG((ENABLE, "get mem\n"));

			
			if (copy_from_user(&param, (char *)arg, sizeof(param)) > 0)
				return -EFAULT;
			
			if (copy_from_user(&allocatedmemblocks, param.allocatedmemblocks, sizeof(allocatedmemblocks)) > 0)
				return -EFAULT;

			filter = &ppfprivate.filters[param.filter_slot];
			param.status = filter->set_engine_mem(&allocatedmemblocks);

			if (copy_to_user((char *) arg, &param, sizeof(param)) > 0)
				return -EFAULT;
		
			rc = 0;
			break;
		}

	case PPFDOCK_IOCTL_GET_OUTPUT_MEM:
		{
			struct ppfdock_get_output_mem_type param;
			struct EMhwlibMemoryBlockList requiredmemblocks;
			RMDBGLOG((ENABLE, "get mem\n"));

			if (copy_from_user(&param, (char *)arg, sizeof(param)) > 0)

				return -EFAULT;
			RMDBGLOG((ENABLE, "get mem\n"));

			RMDBGLOG((ENABLE, "get mem\n"));
			filter = &ppfprivate.filters[param.filter_slot];
			RMDBGLOG((ENABLE, "get mem\n"));

			param.status = filter->get_output_mem(param.output_slot, &requiredmemblocks);
			RMDBGLOG((ENABLE, "get mem\n"));


			if (copy_to_user(param.requiredmemblocks, &requiredmemblocks, sizeof(requiredmemblocks)) > 0) {
				return -EFAULT;
			}

			RMDBGLOG((ENABLE, "get mem\n"));

			if (copy_to_user((char *) arg, &param, sizeof(param)) > 0)
				return -EFAULT;
			RMDBGLOG((ENABLE, "get mem done\n"));

		
			rc = 0;
			break;

		}

	case PPFDOCK_IOCTL_SET_OUTPUT_MEM:
		{
			struct ppfdock_set_output_mem_type param;
			struct EMhwlibMemoryBlockList allocatedmemblocks;
			RMDBGLOG((ENABLE, "get mem\n"));


			if (copy_from_user(&param, (char *)arg, sizeof(param)) > 0)
				return -EFAULT;

			if (copy_from_user(&allocatedmemblocks, param.allocatedmemblocks, sizeof(allocatedmemblocks)) > 0)
				return -EFAULT;

			filter = &ppfprivate.filters[param.filter_slot];
			param.status = filter->set_output_mem(param.output_slot, &allocatedmemblocks);

			if (copy_to_user((char *) arg, &param, sizeof(param)) > 0)
				return -EFAULT;
		
			rc = 0;
			break;
		}
	case PPFDOCK_IOCTL_GET_OUTPUT:
		{
			struct ppfdock_get_output_type param;
			RMuint32 output_surface;
			RMDBGLOG((ENABLE, "get mem\n"));

			if (copy_from_user(&param, (char *)arg, sizeof(param)) > 0)
				return -EFAULT;
			filter = &ppfprivate.filters[param.filter_slot];
			param.status = filter->get_output(param.output_slot, &output_surface);
			if (copy_to_user(param.output_surface, &output_surface, sizeof(output_surface)) > 0) {
				return -EFAULT;
			}
			if (copy_to_user((char *) arg, &param, sizeof(param)) > 0)
				return -EFAULT;
			break;
		}
	case PPFDOCK_IOCTL_SET_INPUT:
		{
			struct ppfdock_set_input_type param;
			RMDBGLOG((ENABLE, "get mem\n"));

			if (copy_from_user(&param, (char *)arg, sizeof(param)) > 0)
				return -EFAULT;
			filter = &ppfprivate.filters[param.filter_slot];
			param.status = filter->set_input(param.input_slot, param.input_surface);
			if (copy_to_user((char *) arg, &param, sizeof(param)) > 0)
				return -EFAULT;
			break;
		}
	case PPFDOCK_IOCTL_SET_COMMAND:
		{
			struct ppfdock_set_command param;
			void *command_param; 
			void *command_result; 
			RMDBGLOG((ENABLE, "get mem\n"));


			if (copy_from_user(&param, (char *)arg, sizeof(param)) > 0)
				return -EFAULT;

			command_param = vmalloc(param.param_size);
			command_result = vmalloc(param.result_size);
			
			if (copy_from_user(command_param, param.command_param, param.param_size) > 0){
				vfree(command_param);
				vfree(command_result);
				return -EFAULT;
			}
			
			filter = &ppfprivate.filters[param.filter_slot];
			
			param.status = filter->set_command(command_param, param.param_size, command_result, param.result_size);
			
			if (copy_to_user(param.command_result, command_result, param.result_size) > 0) {
				vfree(command_param);
				vfree(command_result);

				return -EFAULT;
			}
			if (copy_to_user((char *) arg, &param, sizeof(param)) > 0){
				vfree(command_param);
				vfree(command_result);
				return -EFAULT;
			}
			vfree(command_param);
			vfree(command_result);
			break;
		}
	default:
		rc = -EINVAL;
	}

	return rc;
}


static int ppfdock_open(struct inode *i_node, struct file *filp)
{
	filp->private_data = &ppfprivate; /* usless by now... */
	return 0;
}

static int ppfdock_release(struct inode *i_node, struct file *filp)
{
	return 0;
}


struct file_operations ppfdock_fops = 
{
	// this replaces MOD_INC_USE_COUNT/MOD_DEC_USE_COUNT pain
	owner: THIS_MODULE,
	ioctl:   ppfdock_ioctl, 
	open:    ppfdock_open, 
	release: ppfdock_release, 
};


int init_module(void)
{
	RMDBGLOG((ENABLE, "at init module\n"));

	if (register_chrdev(PPFDOCK_MAJOR, PPFDOCK_DEVICE_NAME, &ppfdock_fops)<0) {
		RMDBGLOG((ENABLE,"init_module: Can't register module!\n"));
		return -EINVAL;
	}

	return 0;
}

void cleanup_module(void)
{
	unregister_chrdev(PPFDOCK_MAJOR, PPFDOCK_DEVICE_NAME);

}


EXPORT_SYMBOL(PPFDockRegisterFilter);
