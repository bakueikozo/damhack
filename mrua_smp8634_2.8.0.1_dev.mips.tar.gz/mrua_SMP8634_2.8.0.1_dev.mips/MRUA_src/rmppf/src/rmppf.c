/*****************************************
 Copyright  2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE 
#include "../../rmdef/rmdef.h"
#include "../../emhwlib/include/emhwlib.h"    /* for blocklist */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
/* #include <sys/time.h> */
/* #include <sys/select.h> */


#include "../include/rmppf.h"
#include "../dock/include/ppfdock.h"


struct RMppf {
	int fd;
};



RMstatus RMPPFCreateInstance(struct RMppf **ppInstance)
{
	char device_filename[2048];
	struct RMppf *pPPF;
	

	if (ppInstance == NULL) return RM_FATALINVALIDPOINTER;

	/* malloc is temporarily used here insted of RMMalloc to allow RMF MM
	 * to be in RUA memory when running on standalone pt110, do not remove
	 * */
	pPPF = (struct RMppf *) malloc(sizeof(struct RMppf));
	if (pPPF == NULL) {
		RMDBGLOG((ENABLE, "cannot allocate handler\n"));

		return RM_FATALOUTOFMEMORY;
	}
	
	sprintf(device_filename, "/dev/" PPFDOCK_DEVICE_NAME);

	pPPF->fd = open(device_filename, O_RDWR);
	if (pPPF->fd == -1) {
		free(pPPF);
		fprintf(stderr, "rua/" __FILE__ ": Unable to open %s\n", device_filename);
		RMDBGLOG((ENABLE, "cannot open the device file %s\n", device_filename));
		return RM_ERROR;
	}
	
	*ppInstance = pPPF;
	
	return RM_OK;
}
RMstatus RMPPFDestroyInstance(struct RMppf *pPPF);

RMstatus RMPPFDestroyInstance(struct RMppf *pPPF)
{
	RMASSERT(pPPF);

	close(pPPF->fd);
	free(pPPF);

	return RM_OK;
}

RMstatus RMPPFGetEngineMem(struct RMppf *pPPF, RMuint32 filter_slot, struct EMhwlibMemoryBlockList* requiredmemblocks)
{
	struct ppfdock_get_engine_mem_type param;

	RMASSERT(pPPF);

	param.filter_slot = filter_slot;
	param.requiredmemblocks = requiredmemblocks;

	RMDBGLOG((ENABLE, "at get engine mem, sending ioctl\n"));

	if (ioctl(pPPF->fd, PPFDOCK_IOCTL_GET_ENGINE_MEM, &param) < 0){
		RMDBGLOG((ENABLE, "IOCTL FAILED!\n"));
		return RM_ERROR;
	}
		
	return param.status;
}



RMstatus RMPPFSetEngineMem(struct RMppf *pPPF, RMuint32 filter_slot, struct EMhwlibMemoryBlockList *allocatedmemblocks)
{
	struct ppfdock_set_engine_mem_type param;

	RMASSERT(pPPF);

	param.filter_slot = filter_slot;
	param.allocatedmemblocks = allocatedmemblocks;
	RMDBGLOG((ENABLE, "at set engine mem\n"));

	if (ioctl(pPPF->fd, PPFDOCK_IOCTL_SET_ENGINE_MEM, &param) < 0){
		RMDBGLOG((ENABLE, "IOCTL FAILED!\n"));
		return RM_ERROR;
	}
		
	return param.status;


}

RMstatus RMPPFGetOutputMem(struct RMppf *pPPF, RMuint32 filter_slot, RMuint32 output_slot, struct EMhwlibMemoryBlockList *requiredmemblocks)
{
	struct ppfdock_get_output_mem_type param;

	RMASSERT(pPPF);

	param.filter_slot = filter_slot;
	param.output_slot = output_slot;
	param.requiredmemblocks = requiredmemblocks;

	if (ioctl(pPPF->fd, PPFDOCK_IOCTL_GET_OUTPUT_MEM, &param) < 0){
		RMDBGLOG((ENABLE, "IOCTL FAILED!\n"));
		return RM_ERROR;
	}
	RMDBGLOG((ENABLE, "ppf:here I have %ld bytes\n", requiredmemblocks->Blocks[0].Size));
		
	return param.status;


}

RMstatus RMPPFSetOutputMem(struct RMppf *pPPF, RMuint32 filter_slot, RMuint32 output_slot, struct EMhwlibMemoryBlockList *allocatedmemblocks)
{
	struct ppfdock_set_output_mem_type param;

	RMASSERT(pPPF);

	param.filter_slot = filter_slot;
	param.output_slot = output_slot;
	param.allocatedmemblocks = allocatedmemblocks;

	if (ioctl(pPPF->fd, PPFDOCK_IOCTL_SET_OUTPUT_MEM, &param) < 0){
		RMDBGLOG((ENABLE, "IOCTL FAILED!\n"));
		return RM_ERROR;
	}
		
	return param.status;

}

RMstatus RMPPFGetOutputSurface(struct RMppf *pPPF, RMuint32 filter_slot, RMuint32 output_slot, RMuint32 *output_surface)
{	
	struct ppfdock_get_output_type param;
	RMASSERT(pPPF);

	param.filter_slot = filter_slot;
	param.output_slot = output_slot;
	param.output_surface = output_surface;

	if (ioctl(pPPF->fd, PPFDOCK_IOCTL_GET_OUTPUT, &param) < 0){
		RMDBGLOG((ENABLE, "IOCTL FAILED!\n"));
		return RM_ERROR;
	}
		
	return param.status;

}

RMstatus RMPPFSetInputSurface(struct RMppf *pPPF, RMuint32 filter_slot, RMuint32 input_slot, RMuint32 input_surface)
{
	struct ppfdock_set_input_type param;

	RMASSERT(pPPF);

	param.filter_slot = filter_slot;
	param.input_slot = input_slot;
	param.input_surface = input_surface;

	if (ioctl(pPPF->fd, PPFDOCK_IOCTL_SET_INPUT, &param) < 0){
		RMDBGLOG((ENABLE, "IOCTL FAILED!\n"));
		return RM_ERROR;
	}
		
	return param.status;

}

RMstatus RMPPFSetCommand(struct RMppf *pPPF, RMuint32 filter_slot, void *command_param, RMuint32 param_size, void *command_result, RMuint32 result_size)
{
	struct ppfdock_set_command param;

	RMASSERT(pPPF);

	param.filter_slot = filter_slot;
	param.command_param = command_param;
	param.param_size = param_size;

	param.command_result = command_result;
	param. result_size = result_size;

	if (ioctl(pPPF->fd, PPFDOCK_IOCTL_SET_COMMAND, &param) < 0){
		RMDBGLOG((ENABLE, "IOCTL FAILED!\n"));
		return RM_ERROR;
	}
		
	return param.status;


}
