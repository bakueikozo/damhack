/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   rmwmaprodecoderapi.h
  @brief  describes the WMAPRO decoder C -> C++ interface

  @author Sebastian Frias Feltrer
  @date   2005-01-13
*/

#ifndef __RMWMAPROVDECODERAPI_H__
#define __RMWMAPROVDECODERAPI_H__

#include "../../rmdef/rmdef.h"
#include "../../rmproperties/include/rmmetaproperties.h"

typedef void *ExternWMAProVdecoder;

RM_EXTERN_C RMstatus RMCreateWMAProVDecoder(ExternWMAProVdecoder *pDecoderObject_C_API);
RM_EXTERN_C RMstatus RMDeleteWMAProVDecoder(ExternWMAProVdecoder pDecoderObject_C_API);

RM_EXTERN_C RMstatus RMWMAProVDecoderOpen(ExternWMAProVdecoder pDecoderObject_C_API);

RM_EXTERN_C RMstatus RMWMAProVDecoderInit(ExternWMAProVdecoder pDecoderObject_C_API, RMuint32 encoder_options, RMuint32 packet_length, RMMetaWMAParameters *wma_params);

RM_EXTERN_C RMstatus RMWMAProVDecoderResetParser(ExternWMAProVdecoder pDecoderObject_C_API, RMuint8 *packet_buf, RMuint32 nByte_in_buf);

RM_EXTERN_C RMstatus RMWMAProVDecoderFlushParser(ExternWMAProVdecoder pDecoderObject_C_API);

RM_EXTERN_C RMstatus RMWMAProVDecoderGetFrame(ExternWMAProVdecoder pDecoderObject_C_API, void **ppBuffer);

RM_EXTERN_C RMstatus RMWMAProVDecoderDecode(ExternWMAProVdecoder pDecoderObject_C_API, RMuint8 *pinBuffer, RMuint8 *poutBuffer, RMuint32 *pUncompSize);

RM_EXTERN_C RMstatus RMWMAProVDecoderClose(ExternWMAProVdecoder pDecoderObject_C_API);

RM_EXTERN_C RMuint32 RMWMAProVDecodeGetFlag(ExternWMAProVdecoder pDecoderObject_C_API, RMuint32 FlagType);

RM_EXTERN_C void RMWMAProVDecodeResetPacket(ExternWMAProVdecoder pDecoderObject_C_API);

RM_EXTERN_C RMbool RMWMAProVDecodeIsPacket2Decode(ExternWMAProVdecoder pDecoderObject_C_API);

RM_EXTERN_C void RMWMAProVDecodeAdjustPayload(ExternWMAProVdecoder pDecoderObject_C_API);

#endif // __RMWMAPROVDECODERAPI_H__
