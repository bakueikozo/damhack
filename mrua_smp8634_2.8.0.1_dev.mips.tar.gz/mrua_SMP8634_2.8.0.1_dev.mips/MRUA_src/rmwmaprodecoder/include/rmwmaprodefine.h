// WMAPRO decoder define
// David, 2005

#ifndef __RMWMAPRODEFINE_H__
#define __RMWMAPRODEFINE_H__

#define INQUIRE_BROKEN_FRAME_FLAG	100

#endif
