/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   rmwmaprodecoder.h
  @brief  describes the WMAPRO decoder class

  @author Sebastian Frias Feltrer
  @date   2004-12-10
*/

#define ALLOW_OS_CODE

#ifndef __RMWMAPRODECODER_H__
#define __RMWMAPRODECODER_H__

#include "../../rmdef/rmdef.h"

#include "../../sigm_wma9/include/wmaprodec.h"
#include "../../sigm_wma9/include/bitreader.h"
#include "../../sigm_wma9/include/bitwriter.h"
#include "../../rmproperties/include/rmmetaproperties.h"

static inline RMint32 LOG2(RMuint32 i)
{   // returns n where n = log2(2^n) = log2(2^(n+1)-1)
    RMuint32 iLog2 = 0;    
    
    while ((i >> iLog2) > 1)
        iLog2++;
	
    return iLog2;
}

#define NBITS_PACKET_CNT				4
#define NBITS_PACKET_EMPTYNESS	        1
#define NBITS_FORCE_PACKETLOSS	        1
#define BITS_PER_DWORD					32
#define ENCOPT3_WRITE_FRAMESIZE_IN_HDR  0x0040

#define TEMP_PACKET_BUFFER_SIZE         40*1024
#define FRAME_BUFFER_SIZE		128*1024
#define AUDIO_SEQ_HDR_BUFFER_SIZE	64


/* used for C -> C++ API */
typedef void *tpExternWMAProVdecoder;

typedef struct {
	RMuint32 m_cFrameCount;
	RMuint32 m_cPacket_number;
	RMuint32 m_Encoder_opt;
	RMuint32 m_cSeekableFrmInPacket;
	RMuint32 m_cSplicedPacket;
	RMuint32 m_cBitSeekToNextPacket;
	RMuint32 m_cBitsOverCurrPkt;
	RMuint32 m_cBitPackedFrameSize;
	RMuint32 m_cFrmInPacket;
	RMuint32 m_fPacketLoss;
	RMuint32 m_cBitPacketLength;
	RMuint32 m_cFrameSizeBits;
	RMuint32 m_fBrokenFrame;
	RMuint32 m_fWriteFrameSize;
	RMuint32 m_cByteSave4Packet;

	RMuint32 m_cPacketHdrSize;

	RMuint32 m_cBitCount4Packet;	
	RMuint32 m_cBitCount4Frame;

	RMuint32 m_cNextFrameStartBit;	

	RMuint32 m_cBitsInFrameBuffer;
	RMint32  m_cPayload_size;
	RMint64  m_iValidSamples;

	RMuint8  m_cNextFrameStartByte;

	RMuint8  *m_pPacketBuf;
	RMuint8  *m_pFrameBuf;
	RMuint8  *m_pTempPacketBuf;

} tPACKET_PARSER;


class RMwmaProDecoder 
{
 public:
	RMwmaProDecoder(const RMascii *name);
	virtual ~RMwmaProDecoder();

	virtual RMstatus Open();
	virtual RMstatus Init(RMuint32 encoder_options, RMuint32 packet_length, RMMetaWMAParameters *wma_params);
	virtual RMstatus ResetParser(RMuint8 *packet_buf, RMuint32 nByte_in_buf);
	virtual RMstatus GetFrame(void **ppBuffer);

	// Added by David, 2005
	virtual void	ResetPacket();
	virtual RMbool	IsPacket2Decode();
	virtual void	AdjustPayload();
	virtual RMuint32 InquireParser(RMuint32 Flag2BeInquired);
	virtual RMstatus FlushParser();

	virtual RMstatus Decode(RMuint8 *pinBuffer, RMuint8 *poutBuffer, RMuint32 *pUncompSize);

	virtual RMstatus Close();


 private:

	tPACKET_PARSER *m_pParser;
	void *m_pAudec;
	void *m_pMemWmapro;
	RMuint32 m_encoderOptions;
	RMuint32 m_packetLength;
	RMbool m_decoderInitialized;
	RMuint8 *m_pSequenceHeaderBuffer;
	RMuint32 m_WMAPROSequenceHeaderSize;
	RMMetaWMAParameters *m_wmaParams;

	BitReader *m_br;
	BitWriter *m_bw;

};

#endif // __RMWMAPRODECODER_H__
