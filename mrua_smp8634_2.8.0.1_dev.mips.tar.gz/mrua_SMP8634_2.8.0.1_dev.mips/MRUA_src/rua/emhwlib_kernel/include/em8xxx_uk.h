/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   em8xxx_uk.h
  @brief  

  long description

  @author Julien Soulier
  @date   2003-03-18
*/

#ifndef __EM8XXX_UK_H__
#define __EM8XXX_UK_H__

#define EM8XXX_MAJOR 127  // manual selection of major device number
#define EM8XXX_DEVICE_NAME "em8xxx"
#define EM8XXX_VERSION 2

#define EM8XXX_IOCTL_MAGIC 'E'

#define EM8XXX_IOCTL_SET_PROPERTY          _IOWR( EM8XXX_IOCTL_MAGIC,  1, struct em8xxx_property)
#define EM8XXX_IOCTL_GET_PROPERTY          _IOWR( EM8XXX_IOCTL_MAGIC,  2, struct em8xxx_property)
#define EM8XXX_IOCTL_EXCHANGE_PROPERTY     _IOWR( EM8XXX_IOCTL_MAGIC,  3, struct em8xxx_property)
#define EM8XXX_IOCTL_SEND_DATA             _IOR ( EM8XXX_IOCTL_MAGIC,  4, struct em8xxx_data)
#define EM8XXX_IOCTL_RECEIVE_DATA          _IOR ( EM8XXX_IOCTL_MAGIC,  5, struct em8xxx_data)
#define EM8XXX_IOCTL_PREPARE_DATA          _IOR ( EM8XXX_IOCTL_MAGIC,  6, struct em8xxx_data)
#define EM8XXX_IOCTL_WAIT                  _IOWR( EM8XXX_IOCTL_MAGIC,  7, struct em8xxx_wait)
#define EM8XXX_IOCTL_RESET_EVENT           _IOR ( EM8XXX_IOCTL_MAGIC,  8, struct em8xxx_event)
#define EM8XXX_IOCTL_ACQUIRE_ADDRESS       _IOR ( EM8XXX_IOCTL_MAGIC,  9, RMuint32)
#define EM8XXX_IOCTL_RELEASE_ADDRESS       _IOR ( EM8XXX_IOCTL_MAGIC, 10, RMuint32)
#define EM8XXX_IOCTL_SET_EVENT             _IOR ( EM8XXX_IOCTL_MAGIC, 11, RMuint32)
#define EM8XXX_IOCTL_SET_ADDRESS_ID        _IOR ( EM8XXX_IOCTL_MAGIC, 12, struct em8xxx_address_id)
#define EM8XXX_IOCTL_GET_ADDRESS_ID        _IOWR( EM8XXX_IOCTL_MAGIC, 13, struct em8xxx_address_id)


#define EM8XXX_EVENTCOUNT_MAX 32

struct em8xxx_property {
	RMuint32 moduleId;
	RMuint32 propId;
	void *propInVal;
	RMuint32 propInSize;
	void *propOutVal;
	RMuint32 propOutSize;
	RMstatus status;
};

struct em8xxx_data {
	RMuint32 moduleId;
	RMuint32 poolId;
	RMuint32 bus_addr;
	RMuint32 dataSize;
	void *info;
	RMuint32 infoSize;
};

struct em8xxx_event {
	RMuint32 module_id;
	RMuint32 event_mask;
};

struct em8xxx_address_id {
	RMuint32 address;
	RMuint32 id;
};

struct em8xxx_wait {
	// in
	RMuint32 TimeOut_us;
	RMuint32 EventCount;
	struct em8xxx_event pEvents[EM8XXX_EVENTCOUNT_MAX];

	// out
	RMuint32 EventNum;
};

#endif // __EM8XXX_UK_H__
