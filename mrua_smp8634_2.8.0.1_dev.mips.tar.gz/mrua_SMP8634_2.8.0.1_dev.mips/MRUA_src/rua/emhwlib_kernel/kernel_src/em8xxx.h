/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   em8xxx.h
  @brief  

  @author Julien Soulier
  @date   2002-11-13
*/

#ifndef __EM8XXX_H__
#define __EM8XXX_H__

extern int logboard;
#define PE_RMDBGLOG(x)					\
do {							\
	logboard=pE-Etable; 				\
	RMDBGLOG(x);					\
	logboard=-1; 					\
} while (0)

#define MAX_PROPSIZE 1024
#define MAX_WAITERS  32
#define MAX_OPENERS 8
#define MAX_CLEANABLE 128
#define MAX_MEMORY_AREA 128
#define MAX_EVENT_CALLBACKS 32

struct em8xxx_opener {
	RMuint32 em8xxx_id;
	RMuint32 open_count;
};

struct em8xxx_cleanable {
	int em8xxx_id;
	RMuint32 ModuleID;
	RMuint32 PropertyID;
	RMuint32 value;
};

struct em8xxx_memory_area {
	int em8xxx_id;
	RMuint32 ModuleID;
	RMuint32 PropertyID;
	RMuint32 address_start;
	RMuint32 address_end;   /* first byte outside area */
	RMint32 refcount;
	RMuint32 id;
};

typedef int (*Alsa_callback) (void *pE , RMuint32 bus_address);
typedef RMuint32 (*Event_callback) (void *pE,RMuint32 ModuleID,RMuint32 mask);

struct em8xxx_event_callback_entry {
	RMuint32 ModuleID;
	RMuint32 mask;
	Event_callback callback;
};	
		
struct em8xxxprivate {
	int insmod_em8xxx_id;

      	Alsa_callback data_callback;

	struct kc_devfs_handle_t *devfs_handle;
	struct EMhwlib *pemhwlib;
	struct llad *pllad;
	struct gbus * pgbus;
	struct kc_spinlock_t *lock;
	RMuint32 total_open_count;

	struct kc_tasklet_struct *tasklet;
	RMuint32 tasklet_irq_status;
	RMuint8 *buf1;
	RMuint8 *buf2;
	
	struct kc_wait_queue_head_t *wq;
	RMuint32 event_count;
	struct em8xxx_event event_array[MAX_WAITERS];
	struct em8xxx_event_callback_entry event_callback_array[MAX_EVENT_CALLBACKS];
	struct em8xxx_opener openers[MAX_OPENERS];
	struct em8xxx_cleanable cl[MAX_CLEANABLE];
	struct em8xxx_memory_area mem_area[MAX_MEMORY_AREA];
};

#endif // __EM8XXX_H__
