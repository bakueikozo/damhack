/*
 *  @file em8xxx_fb.c
 *  @author Sylvain Garrigues
 *  @short Frame buffer driver for EM8xxx chips
 *
 *  The following code is based on the virtual frame buffer driver.
 *
 *  Copyright (C) 2002 James Simmons
 *  Copyright (C) 1997 Geert Uytterhoeven
 *
 *  This file is subject to the terms and conditions of the GNU General Public
 *  License.
 */

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/string.h>
#include <linux/mm.h>
#include <linux/tty.h>
#include <linux/slab.h>
#include <linux/vmalloc.h>
#include <linux/delay.h>
#include <linux/interrupt.h>
#include <linux/platform_device.h>

#include <asm/uaccess.h>
#include <linux/fb.h>
#include <linux/init.h>

#define ALLOW_OS_CODE 1

#include "kernelcalls.h"
#include "gbus.h"

static unsigned long videomemory;
module_param(videomemory, ulong, 0);

static unsigned long videomemorysize;
module_param(videomemorysize, ulong, 0);

static unsigned long palette;
module_param(palette, ulong, 0);

static char *mode;
module_param(mode, charp, 0);

static struct fb_var_screeninfo em8xxxfb_default __initdata = {
	.xres =		  640,
	.yres =		  480,
	.xres_virtual =	  640,
	.yres_virtual =	  480,
	.bits_per_pixel = 32,
	.red =		  {16, 8, 0},
      	.green =	  {8, 8, 0},
      	.blue =		  {0, 8, 0},
      	.transp =	  {24, 8, 0},
      	.activate =	  FB_ACTIVATE_NOW,
      	.height =	  -1,
      	.width =	  -1,
      	.pixclock =	  20000,
      	.left_margin =	  64,
      	.right_margin =	  64,
      	.upper_margin =	  32,
      	.lower_margin =	  32,
      	.hsync_len =	  64,
      	.vsync_len =	  2,
      	.vmode =	  FB_VMODE_NONINTERLACED,
};

static struct fb_fix_screeninfo em8xxxfb_fix __initdata = {
	.id =		"EM8xxx FB",
	.type =		FB_TYPE_PACKED_PIXELS,
	.visual =	FB_VISUAL_PSEUDOCOLOR,
	.xpanstep =	1,
	.ypanstep =	1,
	.ywrapstep =	1,
	.accel =	FB_ACCEL_NONE,
};

static struct osd_descriptor{
	RMuint32 region_index;          //First region used to map the OSD buffer
	RMuint32 region_count;          //How many regions for the OSD buffer
	RMuint32 offset;                //offset from the base address of the first region
} osd;

static struct llad *p_llad;
static struct gbus *p_gbus;

static int em8xxxfb_check_var(struct fb_var_screeninfo *var, struct fb_info *info);
static int em8xxxfb_set_par(struct fb_info *info);
static int em8xxxfb_setcolreg(u_int regno, u_int red, u_int green, u_int blue, u_int transp, struct fb_info *info);
static int em8xxxfb_pan_display(struct fb_var_screeninfo *var, struct fb_info *info);
static int em8xxxfb_mmap(struct fb_info *info, struct file *file, struct vm_area_struct *vma);
static int em8xxxfb_blank(int blank, struct fb_info *info);

static struct fb_ops em8xxxfb_ops = {
	.fb_check_var	= em8xxxfb_check_var,
	.fb_set_par	= em8xxxfb_set_par,
	.fb_setcolreg	= em8xxxfb_setcolreg,
	.fb_pan_display	= em8xxxfb_pan_display,
	.fb_fillrect	= cfb_fillrect,
	.fb_copyarea	= cfb_copyarea,
	.fb_imageblit	= cfb_imageblit,
	.fb_mmap	= em8xxxfb_mmap,
        .fb_blank       = em8xxxfb_blank,
};

    /*
     *  Internal routines
     */

static u_long get_line_length(int xres_virtual, int bpp)
{
	u_long length;

	length = xres_virtual * bpp;
	length = (length + 31) & ~31;
	length >>= 3;
	return (length);
}

    /*
     *  Setting the video mode has been split into two parts.
     *  First part, xxxfb_check_var, must not write anything
     *  to hardware, it should only verify and adjust var.
     *  This means it doesn't alter par but it does use hardware
     *  data from it to check this var. 
     */

static int em8xxxfb_check_var(struct fb_var_screeninfo *var,
			 struct fb_info *info)

{
	u_long line_length;
	printk("mambolfb in checkvar\n");


	/*
	 *  FB_VMODE_CONUPDATE and FB_VMODE_SMOOTH_XPAN are equal!
	 *  as FB_VMODE_SMOOTH_XPAN is only used internally
	 */

	if (var->vmode & FB_VMODE_CONUPDATE) {
		var->vmode |= FB_VMODE_YWRAP;
		var->xoffset = info->var.xoffset;
		var->yoffset = info->var.yoffset;
	}

	/*
	 *  Some very basic checks
	 */
	if (!var->xres)
		var->xres = 1;
	if (!var->yres)
		var->yres = 1;
	if (var->xres > var->xres_virtual)
		var->xres_virtual = var->xres;
	if (var->yres > var->yres_virtual)
		var->yres_virtual = var->yres;
	if (var->bits_per_pixel <= 1)
		var->bits_per_pixel = 1;
	else if (var->bits_per_pixel <= 8)
		var->bits_per_pixel = 8;
	else if (var->bits_per_pixel <= 16)
		var->bits_per_pixel = 16;
	else if (var->bits_per_pixel <= 24)
		var->bits_per_pixel = 24;
	else if (var->bits_per_pixel <= 32)
		var->bits_per_pixel = 32;
	else
		return -EINVAL;

	if (var->xres_virtual < var->xoffset + var->xres)
		var->xres_virtual = var->xoffset + var->xres;
	if (var->yres_virtual < var->yoffset + var->yres)
		var->yres_virtual = var->yoffset + var->yres;

	/*
	 *  Memory limit
	 */
	line_length =
	    get_line_length(var->xres_virtual, var->bits_per_pixel);
	if (line_length * var->yres_virtual > videomemorysize)
		return -ENOMEM;

	/*
	 * Now that we checked it we alter var. The reason being is that the video
	 * mode passed in might not work but slight changes to it might make it 
	 * work. This way we let the user know what is acceptable.
	 */
	switch (var->bits_per_pixel) {
	case 1:
	case 8:
		var->red.offset = 0;
		var->red.length = 8;
		var->green.offset = 0;
		var->green.length = 8;
		var->blue.offset = 0;
		var->blue.length = 8;
		var->transp.offset = 0;
		var->transp.length = 0;
		break;
	case 16:		/* RGBA 5551 */
		if (var->transp.length) {
			var->red.offset = 0;
			var->red.length = 5;
			var->green.offset = 5;
			var->green.length = 5;
			var->blue.offset = 10;
			var->blue.length = 5;
			var->transp.offset = 15;
			var->transp.length = 1;
		} else {	/* RGB 565 */
			var->red.offset = 0;
			var->red.length = 5;
			var->green.offset = 5;
			var->green.length = 6;
			var->blue.offset = 11;
			var->blue.length = 5;
			var->transp.offset = 0;
			var->transp.length = 0;
		}
		break;
	case 24:		/* RGB 888 */
		var->red.offset = 0;
		var->red.length = 8;
		var->green.offset = 8;
		var->green.length = 8;
		var->blue.offset = 16;
		var->blue.length = 8;
		var->transp.offset = 0;
		var->transp.length = 0;
		break;
	case 32:		/* RGBA 8888 */
		var->red.offset = 0;
		var->red.length = 8;
		var->green.offset = 8;
		var->green.length = 8;
		var->blue.offset = 16;
		var->blue.length = 8;
		var->transp.offset = 24;
		var->transp.length = 8;
		break;
	}
	var->red.msb_right = 0;
	var->green.msb_right = 0;
	var->blue.msb_right = 0;
	var->transp.msb_right = 0;

	return 0;
}

/* This routine actually sets the video mode. It's in here where we
 * the hardware state info->par and fix which can be affected by the 
 * change in par. For this driver it doesn't do much. 
 */
static int em8xxxfb_set_par(struct fb_info *info)
{
	printk("mambolfb in setpar\n");
	info->fix.line_length = get_line_length(info->var.xres_virtual,
						info->var.bits_per_pixel);
	return 0;
}

    /*
     *  Set a single color register. The values supplied are already
     *  rounded down to the hardware's capabilities (according to the
     *  entries in the var structure). Return != 0 for invalid regno.
     */

static int em8xxxfb_setcolreg(u_int regno, u_int red, u_int green, u_int blue,
			 u_int transp, struct fb_info *info)
{
        RMuint32 color;
        
	if (regno > 255)	/* no. of hw registers */
		return -1;

	red >>= 8;
	green >>= 8;
	blue >>= 8;
	
	color = 0xFF << 24 | red << 16 | green << 8 | blue;
	gbus_write_uint32(p_gbus,palette+regno*4,color);
        
	return 0;
}

    /*
     *  Pan or Wrap the Display
     *
     *  This call looks only at xoffset, yoffset and the FB_VMODE_YWRAP flag
     */

static int em8xxxfb_pan_display(struct fb_var_screeninfo *var,
			   struct fb_info *info)
{
	printk("mambolfb in pandisplay\n");
	if (var->vmode & FB_VMODE_YWRAP) {
		if (var->yoffset < 0
		    || var->yoffset >= info->var.yres_virtual
		    || var->xoffset)
			return -EINVAL;
	} else {
		if (var->xoffset + var->xres > info->var.xres_virtual ||
		    var->yoffset + var->yres > info->var.yres_virtual)
			return -EINVAL;
	}
	info->var.xoffset = var->xoffset;
	info->var.yoffset = var->yoffset;
	if (var->vmode & FB_VMODE_YWRAP)
		info->var.vmode |= FB_VMODE_YWRAP;
	else
		info->var.vmode &= ~FB_VMODE_YWRAP;
	return 0;
}

    /*
     *  Most drivers don't need their own mmap function 
     */

/* Some RedHat systems have CONFIG_HIGHPTE, so pte_offset is renamed */
#ifndef pte_offset
#define pte_offset pte_offset_kernel
#endif

/* This is used to get the physical address or cookie associated to an iomapped area 
 *  See http://www.xml.com/ldd/chapter/book/ch13.html */
#if EM86XX_CHIP==EM86XX_CHIPID_TANGO2 && EM86XX_MODE==EM86XX_MODEID_STANDALONE
#define io_virt_to_phys(v) kc_virt_to_phys(v)
#else
#define io_virt_to_phys(v) (pte_val(*(pte_t *)pte_offset(pmd_offset(pgd_offset_k((v)), (v)), (v))) & PAGE_MASK) + ((v) & ~PAGE_MASK)
#endif

static int em8xxxfb_mmap(struct fb_info *info, struct file *file,
		    struct vm_area_struct *vma)
{
	//	printk("mambolfb in mmap\n");
#ifndef __arm__
	unsigned long phys = io_virt_to_phys(videomemory);
	printk("mambolfb_mmap: OSD videomemory asked:0x%08lx\n",videomemory);

#if (RMPLATFORM==RMPLATFORMID_AOE6_SH4)
	/*
	* This code is highly SH processor dependent.
	*
	* Suggested by ronen.bidany@flextronicssemi.com
	*                                       */
	if (kc_remap_page_range((struct kc_vm_area_struct *) vma,
	                        vma->vm_start, videomemory,
	                        vma->vm_end-vma->vm_start,
	                        (struct kc_pgprot_t *) &vma->vm_page_prot)) 
		return -EAGAIN;
#else /* default platforms */
	/* This should really be kc_io_remap_range, but as long as we don't
	 * port on alpha or sparc, it's enough */
	if (kc_remap_page_range((struct kc_vm_area_struct *) vma,
	                        vma->vm_start, phys,
	                        vma->vm_end-vma->vm_start,
	                        (struct kc_pgprot_t *) &vma->vm_page_prot)) 
		return -EAGAIN;
#endif

	printk("mambolfb_mmap remapped %ld bytes in userland of process %d at address vma_start0x%08lx to phys=0x%08lx\n",
	       vma->vm_end-vma->vm_start,current->pid,vma->vm_start, phys); 
	
#else /* __arm__ */

#if (RMPLATFORM==RMPLATFORMID_IXDP425)
	/* In the IXP425 architecture, the 'videomemory' is located on PCI MEM
	 * and not mapped to virtual address, so treat 'videomemory' as physical memory. */
	if (kc_remap_page_range((struct kc_vm_area_struct *) vma,
				vma->vm_start, videomemory,
				vma->vm_end-vma->vm_start,
				(struct kc_pgprot_t *) &vma->vm_page_prot))
		return -EAGAIN;
	printk("mambolfb_mmap remapped %ld bytes in userland of process %d at address vma_start0x%08lx to phys=0x%08lx\n",
		vma->vm_end-vma->vm_start,current->pid,vma->vm_start, videomemory);
#endif
	
#endif /* __arm__ */ 

return 0;
}

static int em8xxxfb_blank(int blank, struct fb_info *info) {
	printk("mambolfb in blank\n");
        return 0;
}

    /*
     *  Initialisation
     */

static void em8xxxfb_platform_release(struct device *device)
{
	// This is called when the reference count goes to zero.
}

static int __init em8xxxfb_probe(struct platform_device *device)
{
	struct fb_info *info;
	int retval = -ENOMEM;

	info = framebuffer_alloc(sizeof(u32) * 256, &device->dev);
	if (!info)
		return -1;

	info->screen_base = (char __iomem *)videomemory;
	info->fbops = &em8xxxfb_ops;

	info->var = em8xxxfb_default;
	info->fix = em8xxxfb_fix;
	//--- set some other necessary parameters...
	info->fix.smem_start = videomemory;
	info->fix.smem_len  = videomemorysize;
	info->fix.line_length = get_line_length( info->var.xres_virtual, info->var.bits_per_pixel );

	info->pseudo_palette = info->par;
	info->par = NULL;
	info->flags = FBINFO_FLAG_DEFAULT;

	retval = fb_alloc_cmap(&info->cmap, 256, 0);
	if (retval < 0)
		goto err1;

	retval = register_framebuffer(info);
	if (retval < 0)
		goto err2;
	platform_set_drvdata(device, info);

	printk(KERN_INFO
	       "fb%d: em8xxxfb frame buffer device, using %ldK of video memory\n",
	       info->node, videomemorysize >> 10);
	return 0;
err2:
	fb_dealloc_cmap(&info->cmap);
err1:
	framebuffer_release(info);
	return retval;
}

static int em8xxxfb_remove(struct platform_device *device)
{
	struct fb_info *info = platform_get_drvdata(device);

	if (info) {
		unregister_framebuffer(info);
		framebuffer_release(info);
	}
	return 0;
}

static struct platform_driver em8xxxfb_driver = {
	.probe	= em8xxxfb_probe,
	.remove = em8xxxfb_remove,
        .driver =  {
           .name = "em8xxxfb",
        },
};

static struct platform_device em8xxxfb_device = {
	.name	= "em8xxxfb",
	.id	= 0,
	.dev	= {
		.release = em8xxxfb_platform_release,
	}
};


static int __init parse(char *video_mode)
{
	char *token;
	
	token = strsep(&video_mode, ":");
	if (!token || !video_mode)
		return 0;
	em8xxxfb_default.xres = simple_strtoul(token,&token,0);
	em8xxxfb_default.xres_virtual = em8xxxfb_default.xres;

	token = strsep(&video_mode, ":");
	if (!token || !video_mode)
		return 0;
	em8xxxfb_default.yres = simple_strtoul(token,&token,0);
	em8xxxfb_default.yres_virtual = em8xxxfb_default.yres;
	em8xxxfb_default.bits_per_pixel = simple_strtoul(video_mode,&video_mode,0);

	return 1;
}

static int __init em8xxxfb_init(void)
{
	int ret = 0;
	RMstatus status;

   	printk(KERN_INFO "Opening em8xxxfb on 0x%08lX (%lu bytes).\n", videomemory, videomemorysize); 
	if (!videomemory || !videomemorysize || !palette)
		return -EINVAL;
	
	if (mode){
		if (parse(mode) == 0){
			return -EINVAL;
		}
	}
	
	/* to do: multiple instances */
	p_llad = llad_open("0");
	if (p_llad == NULL){
		printk(KERN_ERR "em8xxxfb: error, cannot open llad 0\n");
		return -EINVAL;
	}

	p_gbus = gbus_open(p_llad);
	if (p_gbus == NULL){
		llad_close(p_llad);
		printk(KERN_ERR "em8xxxfb: error, cannot open gbus 0\n");
		return -EINVAL;
	}

	/* lock the regions we need */
	status = gbus_lock_area(p_gbus, &osd.region_index, videomemory, videomemorysize, &osd.region_count, &osd.offset);
	if (RMFAILED(status)){
		printk(KERN_ERR "em8xxxfb: error locking PCI chunks\n");
		return -EINVAL;
	}
	printk(KERN_INFO "em8xxxfb: locked %ld regions, starting from region %ld at offset 0x%08lx\n", osd.region_count, osd.region_index, osd.offset);

	/* Update video address to the mapped OSD buffer */
	videomemory = (u_long) gbus_map_region(p_gbus, osd.region_index, osd.region_count);
	if (videomemory == (u_long) NULL){
		printk(KERN_ERR "em8xxxfb: error mapping OSD buffer in kernel space\n");
		status = gbus_unlock_region(p_gbus, osd.region_index);
		if (RMFAILED(status))
			printk(KERN_ERR "em8xxxfb: error unlocking regions\n");
		return -EINVAL;
	}
	videomemory += osd.offset;
	printk(KERN_INFO "OSD videomemory = 0x%lX (%lu bytes)\n",videomemory,videomemorysize);
        
	ret = platform_driver_register(&em8xxxfb_driver);
	if (!ret) {
		ret = platform_device_register(&em8xxxfb_device);
		if (ret)
			platform_driver_unregister(&em8xxxfb_driver);
	}
	return ret;
}

module_init(em8xxxfb_init);

static void __exit em8xxxfb_exit(void)
{
	RMstatus status;
	int i;
        
	for (i = 0; i < osd.region_count; i++) {
		status = gbus_unlock_region(p_gbus, osd.region_index + i);
		if (RMFAILED(status))
			printk(KERN_ERR "em8xxxfb: error unlocking regions.\n");
	}

	gbus_close(p_gbus);
	llad_close(p_llad);
        
	platform_device_unregister(&em8xxxfb_device);
	platform_driver_unregister(&em8xxxfb_driver);
}

module_exit(em8xxxfb_exit);

MODULE_LICENSE("GPL");
