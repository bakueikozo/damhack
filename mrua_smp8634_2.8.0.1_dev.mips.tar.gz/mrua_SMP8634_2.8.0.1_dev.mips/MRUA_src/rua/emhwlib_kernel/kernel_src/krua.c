/*****************************************
 Copyright © 2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/*
  @file   em8xxx.c
  See licensing details in LICENSING file  
*/

#define ALLOW_OS_CODE 1

#include "../../../emhwlib/include/emhwlib.h"
#include "../../../emhwlib/include/emhwlib_properties_1000.h"

#include "../../../emhwlib/include/emhwlib_event.h"
#include "../../../emhwlib/include/emhwlib_chipspecific.h"
#include "../include/em8xxx_uk.h"
#include "../../../llad/kinclude/kernelcalls.h"
#include "../../../llad/kinclude/mum_kk.h"
#include "../../../llad/include/kdmapool.h"

#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/version.h>

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,17)
#include <linux/moduleparam.h>
#endif

#include <linux/fs.h>
#include <linux/sched.h>
#include <linux/interrupt.h>
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,18)
#include <linux/devfs_fs_kernel.h>
#endif
#include <linux/poll.h>

#include "em8xxx.h"
#include "em8xxx_proc.h"

#include "../../../gbuslib/include/gbus_time.h"
#include "../../../gbuslib/include/gbus_host_interrupt.h"

// to enable or disable the debug related to cleanup messages of this source file, put 1 or 0 below
#if 0
#define CLEANDBG ENABLE
#else
#define CLEANDBG DISABLE
#endif

// to enable or disable the debug related event messages of this source file, put 1 or 0 below
#if 0
#define EVENTDBG ENABLE
#else
#define EVENTDBG DISABLE
#endif

// to enable or disable the debug messages of this source file, put 1 or 0 below
#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

MODULE_DESCRIPTION("rua kernel module for em8xxx chips");
MODULE_AUTHOR("Julien Soulier <julien_soulier@realmagic.fr>, Emmanuel Michon <em@sdesigns.com>");
#ifdef MODULE_LICENSE
MODULE_LICENSE("Proprietary");  // parsed keyword, don't change!
#endif // MODULE_LICENSE
static int major = EM8XXX_MAJOR;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,17)
module_param(major, int,0);
#else
MODULE_PARM(major, "i");
#endif

MODULE_PARM_DESC(major, "Sets the major number");

RMstatus krua_register_event_callback(void *pE, RMuint32 ModuleID, RMuint32 mask, Event_callback callback);
RMstatus krua_unregister_event_callback(void *pE, RMuint32 ModuleID, Event_callback callback);
RMstatus krua_register_sendcomplete_callback(void *pE, Alsa_callback callback);
RMstatus krua_unregister_sendcomplete_callback(void *pE);

#define MAXDMAPOOL 32

struct condition_cookie_type {
	struct em8xxxprivate *pE;
	RMuint32 event_count;
	struct em8xxx_event *pEvents;
	RMint32 event_num;
};	

/*
  em8xxx_id is an id identifying a unique memore space. All threads
  within a same process should have the same em8xxx_id. The tgid
  corresponds to this id, unfortunately on 2.4 linux kernels it is not
  implemented this way and we cannot use it. Instead we use the
  process group id, which behaves as expected. 2.6 kernels do not have
  the pgrp on the current task structure. Therefore we need the switch
  below.
*/
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0) 
#define CURRENT_EM8XXX_ID (current->pgrp) 
#else
#define CURRENT_EM8XXX_ID (current->signal->pgrp) 
#endif

struct em8xxxprivate Etable[MAXLLAD]={ { 0 } };

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
/* the major number for devfs is local to this file */
static unsigned long devfs_major;
#endif

static inline void kc_atomic_clear_mask(RMuint32 *addr, RMuint32 mask)
{
	RMuint32 bit = 0;
	while (mask) {
		if (1 & mask)
			kc_clear_bit(bit, addr);
		
		bit ++;
		mask >>= 1;
	}
}

static inline void kc_atomic_set_mask(RMuint32 *addr, RMuint32 mask)
{
	RMuint32 bit = 0;
	while (mask) {
		if (1 & mask)
			kc_set_bit(bit, addr);
		
		bit ++;
		mask >>= 1;
	}
}
 
int emergency_exit(struct em8xxxprivate *pE)
{
	RMuint32 i,processedentries=0;

	// first the standard properties
	for (i=0 ; i<MAX_CLEANABLE ; i++) {
		if ((pE->cl[i].PropertyID!=0) && (pE->cl[i].em8xxx_id==CURRENT_EM8XXX_ID)) {
			PE_RMDBGLOG((CLEANDBG,"emergency_exit: #%d %d-%d-%d-0x%08lx\n",
				     i,
				     CURRENT_EM8XXX_ID,
				     pE->cl[i].ModuleID,
				     pE->cl[i].PropertyID,
				     pE->cl[i].value));
			
			// note: this call normally calls EMhwlibUnregisterCleanable
			if (EMhwlibSetProperty(pE->pemhwlib, pE->cl[i].ModuleID, pE->cl[i].PropertyID,
					       &pE->cl[i].value, sizeof(RMuint32)) != RM_OK) {
				PE_RMDBGLOG((CLEANDBG,"emergency_exit: cannot set property %lu for module 0x%lx\n",
					pE->cl[i].PropertyID, pE->cl[i].ModuleID));
				return -1;
			}
			
			processedentries++;
		}
	}	
	
	// then RMFree ...
	for (i=0 ; i<MAX_MEMORY_AREA ; i++) {
		if ((pE->mem_area[i].PropertyID!=0) && ((pE->mem_area[i].em8xxx_id == 0) || (pE->mem_area[i].em8xxx_id==CURRENT_EM8XXX_ID) || (pE->mem_area[i].em8xxx_id==pE->insmod_em8xxx_id))) {
			/*
			if (pE->mem_area[i].id) {
				//RUASetAddressID marked the memory to not be freed 
				PE_RMDBGLOG((CLEANDBG,"emergency_exit: do not free address 0x%08x with refcount %lu and id %lu\n",
					pE->mem_area[i].address_start, pE->mem_area[i].refcount, pE->mem_area[i].id));
				continue;
			} 

			*/
	
			if (pE->mem_area[i].refcount > 0) {
				PE_RMDBGLOG((CLEANDBG,"emergency_exit: address 0x%08x with refcount %lu > 0 do not free\n", pE->mem_area[i].address_start, pE->mem_area[i].refcount));
				pE->mem_area[i].em8xxx_id = 0; /* this area is not attached to a process anymore */
			}
			else {
				RMuint32 module_id = pE->mem_area[i].ModuleID;
				// note: RMMMPropertyID_Free fails for MM module with index not NULL - filter it
				if ((EMHWLIB_MODULE_CATEGORY(module_id) == MM) && (pE->mem_area[i].PropertyID == RMMMPropertyID_Free))
					module_id = MM;
				PE_RMDBGLOG((CLEANDBG,"emergency_exit: freeing entry %d, address 0x%08x.\n", i, pE->mem_area[i].address_start));
				
				// note: this call normally calls EMhwlibUnregisterCleanable
				if (EMhwlibSetProperty(pE->pemhwlib, module_id, pE->mem_area[i].PropertyID,
						       &pE->mem_area[i].address_start, sizeof(RMuint32)) != RM_OK) {
					PE_RMDBGLOG((CLEANDBG,"emergency_exit: cannot set property %lu for module 0x%lx address=0x%lx\n",
						pE->mem_area[i].PropertyID, pE->mem_area[i].ModuleID, pE->mem_area[i].address_start));
					return -1;
				}
				
				processedentries++;
			}
		}
	}

	PE_RMDBGLOG((CLEANDBG,"emergency_exit: %d entries processed\n", processedentries));

	return processedentries;
}

static inline RMint32 find_and_clear_event(struct em8xxxprivate *pE, RMuint32 EventCount, struct em8xxx_event *pEvents)
{
	RMuint32 i,j;
	RMstatus rc;

       	for (j=0 ; j<EventCount ; j++) {
		for (i=0 ; i<pE->event_count ; i++) {
			if (pEvents[j].module_id != pE->event_array[i].module_id) 
				continue;

			if (!(pEvents[j].event_mask & pE->event_array[i].event_mask)) 
				break;
			
			/* takes only bits present inside rua */
			pEvents[j].event_mask &= pE->event_array[i].event_mask;

			/* clear mask inside rua address space */
			kc_atomic_clear_mask(&(pE->event_array[i].event_mask), pEvents[j].event_mask);

			/* 0 means application only event */
			if (pEvents[j].module_id != 0) {
				/* clear mask inside emhwlib */
				kc_spin_lock_bh(pE->lock);
				rc = EMhwlibSetProperty(pE->pemhwlib, pEvents[j].module_id,
							RMGenericPropertyID_ClearEventMask, 
							&(pEvents[j].event_mask), sizeof(pEvents[j].event_mask));
				kc_spin_unlock_bh(pE->lock);
				
				if (rc != RM_OK)
					PE_RMDBGLOG((ENABLE, "Cannot clear event inside emhwlib %lu 0x%08lx\n", 
						     pEvents[j].module_id, pEvents[j].event_mask));
			}

			/* 
			   we could decrease the pE->event_count, if pE->event_array[i].event_mask == 0, 
			   because no more event is set for this index.
			   However, this implies more locking that what we currently do and the code 
			   will be less efficient. If an event occurs for a given module (and application 
			   waits for it), it is very likely that this event will occur again and therefore, 
			   we may end-up by constantly removing and adding entries in the event array for 
			   no gain.
			   The event array is cleared on the last close of the process, and therefore during
			   the lifetime of a process, the array can only grow.
			   This could be a problem only if the same process was doing one after the other
			   two tasks with completely different set of events. We could end up by not having
			   enough space inside the event array while if would have been possible to handle
			   it, if we have decremented the event count here
			*/

			PE_RMDBGLOG((EVENTDBG, "find and clear event %lu 0x%08lx\n", 
				     pEvents[j].module_id, pEvents[j].event_mask));
			return j;
		}
	}
	
	return -1;
}

static unsigned int wait_condition(void *cookie) 
{
	struct condition_cookie_type *param = (struct condition_cookie_type *) cookie;
	
	param->event_num = find_and_clear_event(param->pE, param->event_count, param->pEvents);
	return (param->event_num >= 0);
}

static int em8xxx_ioctl(struct inode *i_node, struct file *filp,unsigned int cmd, unsigned long arg)
{
	struct em8xxxprivate *pE = (struct em8xxxprivate *) filp->private_data; 
	int rc;

	if (pE->pllad == NULL) return -EINVAL;

	switch (cmd) {
	case EM8XXX_IOCTL_SET_PROPERTY:
		{
			struct em8xxx_property param;
			void *propIn;

			if (kc_logging_copy_from_user(&param, (char *)arg, sizeof(param)) > 0)
				return -EFAULT;
						
			if (param.propInSize > MAX_PROPSIZE)
				propIn = kc_vmalloc(param.propInSize);
			else
				propIn = pE->buf1;

			if (kc_logging_copy_from_user(propIn, param.propInVal, param.propInSize) > 0) {
				if (param.propInSize > MAX_PROPSIZE) kc_vfree(propIn);
				return -EFAULT;
			}
			
			PE_RMDBGLOG((LOCALDBG,"set property moduleId %lu,  propId %lu \n", param.moduleId, param.propId)); 
			kc_spin_lock_bh(pE->lock);
			param.status = EMhwlibSetProperty(pE->pemhwlib, param.moduleId, param.propId, propIn, param.propInSize);
			kc_spin_unlock_bh(pE->lock);
			if (param.propInSize > MAX_PROPSIZE) kc_vfree(propIn);

			if (kc_logging_copy_to_user((char *) arg, &param, sizeof(param)) > 0) 
				return -EFAULT;

			rc = 0;
		}
		break;

	case EM8XXX_IOCTL_GET_PROPERTY:
		{
			struct em8xxx_property param;
			void *propOut;

			if (kc_logging_copy_from_user(&param, (char *)arg, sizeof(param)) > 0)
				return -EFAULT;
			
			if (param.propOutSize > MAX_PROPSIZE)
				propOut = kc_vmalloc(param.propOutSize);
			else
				propOut = pE->buf1;

			PE_RMDBGLOG((LOCALDBG,"get property moduleId %lu,  propId %lu \n", param.moduleId, param.propId)); 
			kc_spin_lock_bh(pE->lock);
			param.status = EMhwlibGetProperty(pE->pemhwlib, param.moduleId, param.propId, propOut, param.propOutSize);
			kc_spin_unlock_bh(pE->lock);
			if (kc_logging_copy_to_user(param.propOutVal, propOut, param.propOutSize) > 0) {
				if (param.propOutSize > MAX_PROPSIZE) kc_vfree(propOut);
				return -EFAULT;
			}
			if (param.propOutSize > MAX_PROPSIZE) kc_vfree(propOut);

			if (kc_logging_copy_to_user((char *) arg, &param, sizeof(param)) > 0) 
				return -EFAULT;

			rc = 0;
		}
		break;

	case EM8XXX_IOCTL_EXCHANGE_PROPERTY:
		{
			struct em8xxx_property param;
			void *propOut, *propIn;

			if (kc_logging_copy_from_user(&param, (char *)arg, sizeof(param)) > 0)
				return -EFAULT;
			
			if (param.propInSize > MAX_PROPSIZE)
				propIn = kc_vmalloc(param.propInSize);
			else
				propIn = pE->buf1;

			if (kc_logging_copy_from_user(propIn, param.propInVal, param.propInSize) > 0) {
				if (param.propInSize > MAX_PROPSIZE) kc_vfree(propIn);
				return -EFAULT;
			}

			if (param.propOutSize > MAX_PROPSIZE)
				propOut = kc_vmalloc(param.propOutSize);
			else
				propOut = pE->buf2;
			
			kc_spin_lock_bh(pE->lock);
			param.status = EMhwlibExchangeProperty(pE->pemhwlib, param.moduleId, param.propId, propIn, param.propInSize, propOut, param.propOutSize);
			kc_spin_unlock_bh(pE->lock);
			if (param.propInSize > MAX_PROPSIZE) kc_vfree(propIn);

			if (kc_logging_copy_to_user(param.propOutVal, propOut, param.propOutSize) > 0) {
				if (param.propOutSize > MAX_PROPSIZE) kc_vfree(propOut);
				return -EFAULT;
			}
			if (param.propOutSize > MAX_PROPSIZE) kc_vfree(propOut);

			if (kc_logging_copy_to_user((char *) arg, &param, sizeof(param)) > 0) 
				return -EFAULT;
			
			rc = 0;
		}
		break;

	case EM8XXX_IOCTL_SEND_DATA:
		{
			struct em8xxx_data param;
			void *info;
			RMuint32 context;

			if (kc_logging_copy_from_user(&param, (char *)arg, sizeof(param)) > 0)
				return -EFAULT;

			if (param.infoSize > MAX_PROPSIZE)
				info = kc_vmalloc(param.infoSize);
			else
				info = pE->buf1;

			if (kc_logging_copy_from_user(info, param.info, param.infoSize) > 0) {
				if (param.infoSize > MAX_PROPSIZE) kc_vfree(info);
				return -EFAULT;
			}
			
			context = ((pE-Etable) << 16) + param.poolId + 1;
			kc_spin_lock_bh(pE->lock);
			rc = EMhwlibSendBuffer(pE->pemhwlib, param.moduleId, param.bus_addr, param.dataSize, info, param.infoSize, (void *) context);
			kc_spin_unlock_bh(pE->lock);

			rc = (rc == RM_OK) ? 0 : -EINVAL;

			if (param.infoSize > MAX_PROPSIZE) kc_vfree(info);
		}
		break;

	case EM8XXX_IOCTL_RECEIVE_DATA:
		{
			struct em8xxx_data param;
			void *info;
			void *context;

			if (kc_logging_copy_from_user(&param, (char *)arg, sizeof(param)) > 0)
				return -EFAULT;

			if (param.infoSize > MAX_PROPSIZE)
				info = kc_vmalloc(param.infoSize);
			else
				info = pE->buf1;
			
			kc_spin_lock_bh(pE->lock);
			rc = EMhwlibReceiveBuffer(pE->pemhwlib, param.moduleId, &(param.bus_addr), &(param.dataSize), info, &(param.infoSize), &context);
			kc_spin_unlock_bh(pE->lock);

			rc = (rc == RM_OK) ? 0 : -EINVAL;

			if ((RMuint32) context != (((pE-Etable) << 16) | (param.poolId + 1))) {
				PE_RMDBGLOG((LOCALDBG,"Receive data error. bufferpool %lu is not correct, moduleId %lu\n", param.poolId, param.moduleId));
				rc = -EINVAL;
			}

			if (kc_logging_copy_to_user(param.info, info, param.infoSize) > 0) 
				rc = -EFAULT;
			
			if (kc_logging_copy_to_user((char *)arg, &param, sizeof(param)) > 0)
				rc = -EFAULT;
			
			if (param.infoSize > MAX_PROPSIZE) kc_vfree(info);
		}
		break;

	case EM8XXX_IOCTL_PREPARE_DATA:
		{
			struct em8xxx_data param;
			struct ReadBufferInfo prop;

			if (kc_logging_copy_from_user(&param, (char *)arg, sizeof(param)) > 0)
				return -EFAULT;

			prop.address = param.bus_addr;
			prop.size = param.dataSize;
			prop.context = (void *) (((pE-Etable) << 16) | (param.poolId + 1));

			kc_spin_lock_bh(pE->lock);
			rc = EMhwlibSetProperty(pE->pemhwlib, param.moduleId, RMGenericPropertyID_AddReadBuffer, &prop, sizeof(prop));
			kc_spin_unlock_bh(pE->lock);

			rc = (rc == RM_OK) ? 0 : -EINVAL;
		}
		break;

	case EM8XXX_IOCTL_WAIT:
		{
			struct condition_cookie_type cookie;
			struct em8xxx_wait param;

			if (kc_logging_copy_from_user(&param, (char *)arg, sizeof(struct em8xxx_wait)) > 0) 
				return -EFAULT;

			RMDBGLOG((EVENTDBG, "Wait Event\n"));
			cookie.pE = pE;
			cookie.event_count = param.EventCount;
			cookie.pEvents = param.pEvents;
			kc_wait_event_interruptible_timeout(pE->wq,
							    wait_condition,
							    US_TO_JIFFIES(param.TimeOut_us),
							    &cookie);
			param.EventNum = cookie.event_num;
			
			if (kc_logging_copy_to_user((char *)arg, &param, sizeof(struct em8xxx_wait)) > 0) 
				return -EFAULT;
			
			rc=0; // proper handling of return codes is done in user_src/rua.c
		}
		break;

	case EM8XXX_IOCTL_RESET_EVENT:
		{
			struct em8xxx_event param;

			if (kc_logging_copy_from_user(&param, (char *)arg, sizeof(struct em8xxx_event)) > 0) 
				return -EFAULT;
			RMDBGLOG((EVENTDBG, "Reset Event\n"));
			find_and_clear_event(pE, 1, &param);
			/* reset event cannot fails */
			rc = 0;
		}
		break;
		
	case EM8XXX_IOCTL_SET_EVENT:
		{
			RMuint32 mask;
			
			if (kc_logging_copy_from_user(&mask, (char *)arg, sizeof(mask)) > 0)
				return -EFAULT;
						
			kc_spin_lock_bh(pE->lock);
			rc = EMhwlibEventComplete((void *) pE, 0, &mask);
			kc_spin_unlock_bh(pE->lock);
			
			kc_wake_up_interruptible(pE->wq);
			rc = (rc == RM_OK) ? 0 : -EINVAL;
		}
		break;

	case EM8XXX_IOCTL_ACQUIRE_ADDRESS:
		{
			RMuint32 address;
			
			if (kc_logging_copy_from_user(&address, (char *)arg, sizeof(address)) > 0)
				return -EFAULT;
						
			kc_spin_lock_bh(pE->lock);
			rc = EMhwlibAcquireAddress(pE->pemhwlib, address);
			kc_spin_unlock_bh(pE->lock);

			rc = (rc == RM_OK) ? 0 : -EINVAL;
		}
		break;
			
	case EM8XXX_IOCTL_RELEASE_ADDRESS:
		{
			RMuint32 address;
			
			if (kc_logging_copy_from_user(&address, (char *)arg, sizeof(address)) > 0)
				return -EFAULT;
						
			kc_spin_lock_bh(pE->lock);
			rc = EMhwlibReleaseAddress(pE->pemhwlib, address);
			kc_spin_unlock_bh(pE->lock);
			
			rc = (rc == RM_OK) ? 0 : -EINVAL;
		}
		break;

	case EM8XXX_IOCTL_SET_ADDRESS_ID:
		{
			struct em8xxx_address_id param;
			RMuint32 i;
			RMuint32 ID_already_found=0;
			
			if (kc_logging_copy_from_user(&param, (char *)arg, sizeof(param)) > 0)
				return -EFAULT;
						
			rc = 0;
			for (i=0 ; i<MAX_MEMORY_AREA ; i++) {
				if (pE->mem_area[i].PropertyID == 0)
					continue;
				if (pE->mem_area[i].id==param.id && param.id!=0) { //when id=0, ruasetaddressid resets id of mem_area with corresponding address_start 
					ID_already_found=1;
					break;
				}
			}
			if (ID_already_found==1){
				PE_RMDBGLOG((LOCALDBG,"id %u already found for address address 0x%08lx\n", param.id, pE->mem_area[i].address_start));
				rc=-EINVAL;
			}
			else {
				for (i=0 ; i<MAX_MEMORY_AREA ; i++) {
					if (pE->mem_area[i].PropertyID == 0)
						continue;
					
					if (param.address == pE->mem_area[i].address_start) {
						pE->mem_area[i].id = param.id;
						
					break;
					}
				}
			
				if (i==MAX_MEMORY_AREA) {
					rc = -EINVAL;
				}	
			}
		}
		break;

	case EM8XXX_IOCTL_GET_ADDRESS_ID:
		{
			struct em8xxx_address_id param;
			RMuint32 i;
			

			if (kc_logging_copy_from_user(&param, (char *)arg, sizeof(param)) > 0)
				return -EFAULT;
						
			rc = 0;
			if (param.id==0)
				rc=-EINVAL;
			else 				{
				for (i=0 ; i<MAX_MEMORY_AREA ; i++) {
					if (pE->mem_area[i].PropertyID == 0)
						continue;
					
					if (param.id == pE->mem_area[i].id) {
						param.address = pE->mem_area[i].address_start;
						PE_RMDBGLOG((LOCALDBG,"get id %lu from address 0x%08lx\n", param.id, param.address));
						break;
					}
				}
				
				if (i==MAX_MEMORY_AREA) {
					rc = -EINVAL;
				}	
				else {
					if (kc_logging_copy_to_user((char *)arg, &param, sizeof(param)) > 0) 
						return -EFAULT;
				}
			}
		}
		break;
	default:
		rc = -EINVAL;
	}

	return rc;
}

static unsigned int em8xxx_poll(struct file *filp, struct poll_table_struct *wait)
{
	struct em8xxxprivate *pE = (struct em8xxxprivate *) filp->private_data; 
	unsigned int mask = 0;

	kc_poll_wait(filp, pE->wq, wait);
	if (pE->event_count > 0) 
		mask = POLLPRI;

	return mask;
}

static int em8xxx_open(struct inode *i_node, struct file *filp)
{
	struct em8xxxprivate *pE; 
	int rc=-EINVAL;
	RMuint32 i;

	/* in case we do not use devfs, fills private_data here */
	if (filp->private_data == NULL) {
		int minor=MINOR(i_node->i_rdev);
		
		if (minor >= MAXLLAD) return -EINVAL; 
		
		filp->private_data = Etable + minor;
	}

	pE = (struct em8xxxprivate *) filp->private_data; 
	if (pE->pllad == NULL) return -EINVAL;
	
	kc_spin_lock_bh(pE->lock);
#if (RMPLATFORM!=RMPLATFORMID_AOE6_SH4)
	// find em8xxx_id in the table
	for (i=0;i<MAX_OPENERS;i++) if (pE->openers[i].em8xxx_id==CURRENT_EM8XXX_ID) break;
	if (i==MAX_OPENERS) {
		// find empty entry
		for (i=0;i<MAX_OPENERS;i++) if (pE->openers[i].em8xxx_id==0) break;

		if (i==MAX_OPENERS) {
			PE_RMDBGLOG((ENABLE,"em8xxx_open: too many openers (increase MAX_OPENERS)\n"));
			goto over;
		}
			
		pE->openers[i].em8xxx_id=CURRENT_EM8XXX_ID;
		PE_RMDBGLOG((LOCALDBG,"em8xxx_open: #%d new em8xxx_id %d\n",
			     i,pE->openers[i].em8xxx_id));
	}
	
	pE->openers[i].open_count++;
#endif
	pE->total_open_count++;
	rc=0;

#if (RMPLATFORM!=RMPLATFORMID_AOE6_SH4)
	PE_RMDBGLOG((LOCALDBG,"em8xxx_open: #%d em8xxx_id %d open_count=%d\n",
		     i,pE->openers[i].em8xxx_id,pE->openers[i].open_count));
#endif
	
 over:
	kc_spin_unlock_bh(pE->lock);

	return rc;
}

static int em8xxx_release(struct inode *i_node, struct file *filp)
{
	struct em8xxxprivate *pE = (struct em8xxxprivate *) filp->private_data; 
	RMuint32 i;
		
	if (pE->pllad == NULL) return -EINVAL;

	kc_spin_lock_bh(pE->lock);
	
#if (RMPLATFORM!=RMPLATFORMID_AOE6_SH4)
	// find em8xxx_id in the table
	for (i=0 ; i<MAX_OPENERS ; i++) 
		if (pE->openers[i].em8xxx_id==CURRENT_EM8XXX_ID) 
			break;

	if (i>=MAX_OPENERS) {
		PE_RMDBGLOG((ENABLE,"em8xxx_release: too many openers (increase MAX_OPENERS)\n"));
		kc_spin_unlock_bh(pE->lock);
		return -EINVAL;
	}
	
	pE->openers[i].open_count--;
	
	PE_RMDBGLOG((LOCALDBG,"em8xxx_release: #%d em8xxx_id %d open_count=%d\n",
		     i,pE->openers[i].em8xxx_id,pE->openers[i].open_count));
	
	if (pE->openers[i].open_count==0) {
		// free entry
		PE_RMDBGLOG((LOCALDBG,"em8xxx_release: #%d em8xxx_id %d disappears\n",i,pE->openers[i].em8xxx_id));
		pE->openers[i].em8xxx_id=0;
		
		if (emergency_exit(pE)>0)
			PE_RMDBGLOG((ENABLE,"em8xxx_release: unclean exit\n"));
		
	}
#endif 
	pE->total_open_count--;
	if (pE->total_open_count == 0) {
		/* if no process accesses the driver clear the event array */
		for (i=0 ; i<pE->event_count ; i++) {
			/* clear mask inside emhwlib */
			EMhwlibSetProperty(pE->pemhwlib, pE->event_array[i].module_id,
					   RMGenericPropertyID_ClearEventMask,
					   &(pE->event_array[i].event_mask), sizeof(pE->event_array[i].event_mask));
		}
		
		pE->event_count = 0;
	}		
	
	kc_spin_unlock_bh(pE->lock);

	return 0;
}

static void em8xxx_tasklet(unsigned long data)
{
	struct em8xxxprivate *pE = (struct em8xxxprivate *) data;
	RMuint32 irq_status;
	unsigned long flags;

	/* 
	   Get the status and clear it atomically.
	   If the same event comes during EMhwlibProcessInterrupt, we do not lose it.
	*/
	kc_spin_lock_irqsave(pE->lock, &flags);
	irq_status = pE->tasklet_irq_status;
	pE->tasklet_irq_status = 0;
	kc_spin_unlock_irqrestore(pE->lock, flags);

	PE_RMDBGLOG((LOCALDBG,"irq_status = 0x%08lx\n", irq_status));

	kc_spin_lock(pE->lock);
	EMhwlibProcessInterrupt(pE->pemhwlib, irq_status, (void *) pE);
	kc_spin_unlock(pE->lock);
}

RMstatus krua_register_event_callback(void *pE, RMuint32 ModuleID, RMuint32 mask, Event_callback callback)
{
	RMuint32 i;
	struct em8xxxprivate *real_pE = (struct em8xxxprivate *) pE;

	for (i=0;i<MAX_EVENT_CALLBACKS;i++) {
		struct em8xxx_event_callback_entry * entry = &(real_pE->event_callback_array[i]);
		if (entry->callback == NULL)
			break;
	}
	if (i == MAX_EVENT_CALLBACKS) {
		RMDBGLOG((ENABLE,"Cannot register event callback : event callback array is full !\n"));
		return RM_ERROR;
	}
	else {
		RMDBGLOG((ENABLE,"Registering event callback with module_id %lu and mask 0x%08x \n",ModuleID,mask));
		real_pE->event_callback_array[i] = (struct em8xxx_event_callback_entry) { ModuleID , mask , callback };
	}

	return RM_OK;
}

RMstatus krua_unregister_event_callback(void *pE, RMuint32 ModuleID, Event_callback callback)
{
	RMuint32 i;
	RMbool found=FALSE;
	struct em8xxxprivate *real_pE = (struct em8xxxprivate *) pE;

	for (i=0;i<MAX_EVENT_CALLBACKS;i++) {
		struct em8xxx_event_callback_entry * entry = &(real_pE->event_callback_array[i]);
		if ((entry->callback == callback) && (entry->ModuleID == ModuleID)) {
			RMDBGLOG((ENABLE,"Unregistering callback for module_id %lu and mask 0x%08x \n",entry->ModuleID,entry->mask));
			found = TRUE;
			real_pE->event_callback_array[i].ModuleID = 0;
			real_pE->event_callback_array[i].mask = 0;
			real_pE->event_callback_array[i].callback = NULL;
			break;
		}
	}
	
	if (!found) {
		RMDBGLOG((ENABLE,"Cannot find event callback to unregister for moduleID %lu\n",ModuleID));
		return RM_ERROR;
	}
	
	return RM_OK;
}

RMstatus krua_register_sendcomplete_callback(void *pE, Alsa_callback callback)
{
	struct em8xxxprivate *real_pE = (struct em8xxxprivate *) pE;

	real_pE->data_callback = callback;
	return RM_OK;
}

RMstatus krua_unregister_sendcomplete_callback(void *pE)
{

	struct em8xxxprivate *real_pE = (struct em8xxxprivate *) pE;

	real_pE->data_callback = NULL;
	return RM_OK;
}


/* ran from tasklet */
RMstatus EMhwlibSendBufferComplete (void *context, RMuint32 bus_address)
{
	RMuint32 minor = ((RMuint32) context) >> 16;
	RMuint32 poolId = ((RMuint32) context) & 0xffff;
	struct em8xxxprivate *pE;
	int err;
	
	if (minor >= MAXLLAD) return -EINVAL; 
	pE= &(Etable[minor]);
	if (pE->pllad == NULL) return -EINVAL;
	
	poolId --;
	if (poolId == MAXDMAPOOL) {
		if (pE->data_callback != NULL) {
			pE->data_callback(pE, bus_address);
			return RM_OK;
		}
		else
			return RM_ERROR;
	}

	/* make sure the dmapool is valid before accessing it */
	err = kdmapool_check_opened(pE->pllad, poolId);
	if (err != 0)
		return RM_ERROR;
	
	PE_RMDBGLOG((LOCALDBG,"release bus address 0x%08x in pool ID %lu\n", bus_address, poolId));
	err = kdmapool_release(pE->pllad, poolId, bus_address);
	if (err != 0) {
		RMDBGLOG((ENABLE, "ERROR: %d, EMhwlibSendBufferComplete() dmapool_release(pool = %lu, phys_addr = 0x%08lx)\n", err, poolId,bus_address));
		return RM_ERROR;
	}

	return RM_OK;
}
 
/* ran from tasklet */
RMstatus EMhwlibEventComplete(void *context, RMuint32 ModuleID, RMuint32 *Status)
{
	RMuint32 i;
	struct em8xxxprivate *pE = (struct em8xxxprivate *) context;
	RMuint32 kernel_processed_interrupts=0;
	RMstatus err=RM_OK;

	for (i=0; i<MAX_EVENT_CALLBACKS ;i++) {
		struct em8xxx_event_callback_entry * entry = &(pE->event_callback_array[i]);
		if ((ModuleID==entry->ModuleID) && (entry->mask & *Status) && (entry->callback != NULL)) {
			RMDBGLOG((EVENTDBG,"Processing event callback for module %lu and mask 0x%08x\n",entry->ModuleID,entry->mask & *Status));
			kernel_processed_interrupts |= entry->callback(pE,ModuleID,*Status & entry->mask);
		}
	}

	/* The interrupts processed by registered kernel event
	 * callbacks will be cleared by the waiter, otherwise the Hardware
	 * librayr is reeentrant
	 * Do not propagate those interrupts to user space */
	*Status &= ~kernel_processed_interrupts;
	if (*Status == 0)
		return err;

	for (i=0 ; i<pE->event_count ; i++) {
		if (pE->event_array[i].module_id == ModuleID) {
			RMuint32 new_events, old_events;

			old_events = pE->event_array[i].event_mask;
			new_events =  (old_events | *Status) ^ (old_events);
			kc_atomic_set_mask(&(pE->event_array[i].event_mask), new_events);
			*Status &= ~(new_events);

			if (new_events)
				kc_wake_up_interruptible(pE->wq);
	
			PE_RMDBGLOG((EVENTDBG, "Adding event 0x%lx to module %lu in array index (%lu)\n", new_events, ModuleID, i));
			return RM_OK;
		}
	}

	if (i < MAX_WAITERS) {
		/* non atomicity is OK here since we validate the index only after event_count is incremented */
		pE->event_array[i].module_id = ModuleID;
		pE->event_array[i].event_mask = *Status;
		PE_RMDBGLOG((EVENTDBG, "Adding event 0x%lx to module %lu in array index (%lu)\n", *Status, ModuleID, i));

		*Status = 0;
		pE->event_count ++;

		kc_wake_up_interruptible(pE->wq);

		return RM_OK;
	}

	RMDBGLOG((ENABLE, "Not enough space to store all modules generating events (%lu)\n", i));
	return RM_ERROR;
}

RMstatus EMhwlibRegisterCleanable(struct EMhwlib *pemhwlib, RMuint32 ModuleID, RMuint32 PropertyID, RMuint32 value)
{
	RMuint32 i;
	RMuint32 em8xxx_id;
	struct em8xxxprivate *pE;

	for (i=0;i<MAXLLAD;i++) 
		if (Etable[i].pemhwlib==pemhwlib) break;

	if (i==MAXLLAD) {
		RMDBGLOG((ENABLE, "Cannot find emhwlib 0x%p\n", pemhwlib));
		return RM_ERROR;
	}

	pE=&Etable[i];

	for (i=0;i<MAX_OPENERS;i++) if (pE->openers[i].em8xxx_id==CURRENT_EM8XXX_ID) break;
	em8xxx_id = (i==MAX_OPENERS) ? 0 : CURRENT_EM8XXX_ID; 
	
	if (PropertyID == RMMMPropertyID_Free) {
		for (i=0 ; i<MAX_MEMORY_AREA ; i++) 
			if (pE->mem_area[i].PropertyID==0) break;
		
		if (i==MAX_MEMORY_AREA) {
			PE_RMDBGLOG((ENABLE, "EMhwlibRegisterCleanable: no room left for address 0x%08lx in mem_area\n", value));
			return RM_ERROR;
		}	
		
		pE->mem_area[i].em8xxx_id=em8xxx_id;
		pE->mem_area[i].refcount = 0;
		pE->mem_area[i].ModuleID=ModuleID;
		pE->mem_area[i].PropertyID=PropertyID;
		pE->mem_area[i].address_start=value;
		pE->mem_area[i].address_end=0;
		pE->mem_area[i].id = 0;
	}
	else {
		// empty entries are found by PropertyID=0
		for (i=0;i<MAX_CLEANABLE;i++) 
			if (pE->cl[i].PropertyID==0) break;
		
		if (i==MAX_CLEANABLE) {
			PE_RMDBGLOG((ENABLE, "EMhwlibRegisterCleanable: no room left for ModuleID %lu PropertyID %lu.\n", ModuleID, PropertyID));
			return RM_ERROR;
		}		
		
		pE->cl[i].em8xxx_id=em8xxx_id;
		pE->cl[i].ModuleID=ModuleID;
		pE->cl[i].PropertyID=PropertyID;
		pE->cl[i].value=value;
		
	}

	PE_RMDBGLOG((CLEANDBG,"EMhwlibRegisterCleanable: #%d %d-%d-%d-0x%08lx\n",
		     i,
		     em8xxx_id,
		     ModuleID,
		     PropertyID,
		     value));
	
	return RM_OK;
}

RMstatus EMhwlibUnregisterCleanable(struct EMhwlib *pemhwlib, RMuint32 ModuleID, RMuint32 PropertyID, RMuint32 value)
{ 
	RMuint32 i;
	struct em8xxxprivate *pE;
	
	for (i=0;i<MAXLLAD;i++) 
		if (Etable[i].pemhwlib==pemhwlib) break;

	if (i==MAXLLAD) {
		RMDBGLOG((ENABLE, "Cannot find emhwlib 0x%p\n", pemhwlib));
		return RM_ERROR;
	}

	pE=&Etable[i];

	if (PropertyID == RMMMPropertyID_Free) {
		for (i=0 ; i<MAX_MEMORY_AREA ; i++) {
			if ((pE->mem_area[i].ModuleID == ModuleID) 
			    && 
			    (pE->mem_area[i].PropertyID == PropertyID)
			    &&
			    (pE->mem_area[i].address_start == value)
			    &&
			    ((pE->mem_area[i].em8xxx_id == 0) || (pE->mem_area[i].em8xxx_id == CURRENT_EM8XXX_ID))) 
				break;
		}
		
		if (i==MAX_MEMORY_AREA) {
			PE_RMDBGLOG((ENABLE,"EMhwlibUnregisterCleanable mem_area (0x%08x) (from rmmod em8xxx_id %d): not found\n",value, CURRENT_EM8XXX_ID));
			return RM_ERROR;
		}	

		if (pE->mem_area[i].refcount > 0) {
			PE_RMDBGLOG((LOCALDBG,"EMhwlibUnregisterCleanable mem_area (0x%08x) (from rmmod em8xxx_id %d): refcount %d.\n",value, CURRENT_EM8XXX_ID, pE->mem_area[i].refcount));
			return RM_ERROR;
		}
		else {
			pE->mem_area[i].PropertyID=0; // mark entry as empty
			pE->mem_area[i].id=0; // mark custom id entry as empty
		}
	}
	else {
		for (i=0;i<MAX_CLEANABLE;i++) {
			if ((pE->cl[i].ModuleID == ModuleID) 
			    && 
			    (pE->cl[i].PropertyID == PropertyID)
			    &&
			    (pE->cl[i].value == value)
			    &&
			    ((pE->cl[i].em8xxx_id == 0) || (pE->cl[i].em8xxx_id == CURRENT_EM8XXX_ID))) 
				break;
		}
		
		if (i==MAX_CLEANABLE) {
			// hack should we really call cleanup_module -> Exit -> CRCExit -> _Close unconditionally?
			PE_RMDBGLOG((ENABLE,"EMhwlibUnregisterCleanable module %lu, prop %lu (from rmmod em8xxx_id %d): not found\n", ModuleID, PropertyID, CURRENT_EM8XXX_ID));
			return RM_ERROR;
		}
		
		pE->cl[i].PropertyID=0; // mark entry as empty
		pE->mem_area[i].id=0; // mark custom id entry as empty
	}

	PE_RMDBGLOG((CLEANDBG,"EMhwlibUnregisterCleanable: #%d\n",i));
	return RM_OK;
}

static int mem_area_add_refcount(struct em8xxxprivate *pE, RMuint32 address, int incr)
{
	RMuint32 i;

	for (i=0 ; i<MAX_MEMORY_AREA ; i++) {
		if (pE->mem_area[i].PropertyID == 0)
			continue;
		
		if (pE->mem_area[i].address_end == 0) {
			struct MM_AreaSize_in_type valueIn;
			struct MM_AreaSize_out_type valueOut;
			RMstatus status;
			
			valueIn.Address = (void *) pE->mem_area[i].address_start;
			status = EMhwlibExchangeProperty(pE->pemhwlib, pE->mem_area[i].ModuleID, RMMMPropertyID_AreaSize, 
							 &valueIn, sizeof(valueIn), &valueOut, sizeof(valueOut));
			if (status == RM_OK)
				pE->mem_area[i].address_end = pE->mem_area[i].address_start + valueOut.Size;	
		}
		
		if ((address >= pE->mem_area[i].address_start) && (address < pE->mem_area[i].address_end)) {
			pE->mem_area[i].refcount += incr;
			if (pE->mem_area[i].refcount < 0) {
 				PE_RMDBGLOG((ENABLE,"!!!! ERROR !!!!: mem_area_add_refcount address 0x%08x, is negative\n",address));
				pE->mem_area[i].refcount = 0;
			}
			PE_RMDBGLOG((CLEANDBG,"mem_area_add_refcount address 0x%08x, incr %d, refcount %lu\n",address, incr, pE->mem_area[i].refcount));
			break;
		}
	}
	
	if (i==MAX_MEMORY_AREA) {
		return -1;
	}	
	
	return 0;
}

/* EMhwlib callback so do not spinlock */
RMstatus EMhwlibAcquireAddress(struct EMhwlib *pEMhwlib, RMuint32 address)
{
	RMuint32 i;
	struct em8xxxprivate *pE;
	
	for (i=0;i<MAXLLAD;i++) 
		if (Etable[i].pemhwlib==pEMhwlib) break;

	if (i==MAXLLAD) {
		RMDBGLOG((ENABLE, "Cannot find emhwlib 0x%p\n", pEMhwlib));
		return RM_ERROR;
	}
	
	pE=&Etable[i];

	if (mem_area_add_refcount(pE, address, 1) < 0) {
		PE_RMDBGLOG((ENABLE,"EMhwlibAcquireAddress address 0x%08x not found\n",address));
		return RM_ERROR;
	}	
	
	PE_RMDBGLOG((CLEANDBG,"EMhwlibAcquireAddress address 0x%08x\n",address));

	return RM_OK;
}

/* EMhwlib callback so do not spinlock */
RMstatus EMhwlibReleaseAddress(struct EMhwlib *pEMhwlib, RMuint32 address)
{
	RMuint32 i;
	struct em8xxxprivate *pE;
	
	for (i=0;i<MAXLLAD;i++) 
		if (Etable[i].pemhwlib==pEMhwlib) break;
	
	if (i==MAXLLAD) {
		RMDBGLOG((ENABLE, "Cannot find emhwlib 0x%p\n", pEMhwlib));
		return RM_ERROR;
	}
	
	pE=&Etable[i];

	if (mem_area_add_refcount(pE, address, -1) < 0) {
		PE_RMDBGLOG((ENABLE,"EMhwlibReleaseAddress address 0x%08x not found\n",address));
		return RM_ERROR;
	}	
	
	return RM_OK;
}

struct file_operations em8xxx_fops = 
{
	// this replaces MOD_INC_USE_COUNT/MOD_DEC_USE_COUNT pain
	owner: THIS_MODULE,
	
	ioctl:em8xxx_ioctl, 
	open:em8xxx_open, 
	release:em8xxx_release, 
	poll: em8xxx_poll
};

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
// hack this must be related to smallapps/burnsflash/config-* and mambo_project/loader/config.h line 38

static inline void patch_pci_config(RMascii *str)
{
  RMascii a1[3], a2[3], a3[2], a4[7], a5[5], a6[5], a7[5], a8[5], a9[3];
  sscanf(str, "%2s:%2s.%1s %6s %4s:%4s %4s:%4s %2s\n", a1, a2, a3, a4, a5, a6, a7, a8, a9);
  sprintf(str, "0%s:0%s.0%s 0%s 0%s:0%s 0%s:0%s 0%s\n", a1, a2, a3, a4, a5, a6, a7, a8, a9);
}

/*
  Differenciate between the signature of the serial flash (cannot be reread it at 0x40000000)
  and the MAMB signature coming shortly after
 */
#define MAMBO_CONFIGSIGN_OFFSET     0xc
#define MAMBO_CONFIGSIGN            0x424d414d
#define MAMBO_FLASH_OFFSET          0x06000000
static int identify(struct em8xxxprivate *pE)
{
	RMuint32 device,subid;
	RMascii pci_config[256];
	int tmp, ret, revid;

#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
	// hack: no verification
#else
	if (gbus_read_uint32(pE->pgbus,MEM_BASE_host_interface+MAMBO_CONFIGSIGN_OFFSET)!=MAMBO_CONFIGSIGN) {
		PE_RMDBGLOG((ENABLE,"identify: board has no valid serial flash signature. Skipping.\n"));
		if (gbus_read_uint32(pE->pgbus,MEM_BASE_host_interface+MAMBO_CONFIGSIGN_OFFSET + MAMBO_FLASH_OFFSET)!=MAMBO_CONFIGSIGN) {
			PE_RMDBGLOG((ENABLE,"identify: board has no valid parallel flash signature. Skipping.\n"));
			return -1;
		}
	}
#endif

	llad_get_config(pE->pllad, pci_config, 256);
	/* some 2.4 kernels have a buggy sscanf, numbers have to start with a decimal digit :-( */
	patch_pci_config(pci_config);
	ret = kc_sscanf(pci_config, "%x:%x.%x %x %x:%x %x:%x %x",
		     &tmp, &tmp, &tmp, &tmp, &tmp, &device, &tmp, &subid, &revid);

	if (ret != 9) {
		PE_RMDBGLOG((ENABLE,"cannot parse llad pci configuration: %s on item %d\n", pci_config, ret));
		return -1;
	}

	switch (subid) {
	case 0:
		PE_RMDBGLOG((ENABLE,"identify: board is design #711 (odyssey)\n"));
		break;
	case 1:
		PE_RMDBGLOG((ENABLE,"identify: board is design #706 (mstv)\n"));
		break;
	case 2:
		PE_RMDBGLOG((ENABLE,"identify: board is design #716 (no name) (ONLY ONE DRAM CHIP!!!)\n"));
		break;
	default:
		PE_RMDBGLOG((ENABLE,"identify: board as unknown subid\n"));
		break;
	}
	
#if ( (EM86XX_CHIP==EM86XX_CHIPID_MAMBOLIGHT) || (EM86XX_CHIP==EM86XX_CHIPID_MAMBO) )

	if ( ! ( ((device & 0xf0) == 0x00) || ((device & 0xf0) == 0x10) ) ) {
		RMDBGLOG((ENABLE,"identify: " S_EM86XX_CHIPID " software inserted on other hardware (0x%04x)\n",device));
		return -1;
	}

	// e.m. do not weaken this to a warning
#if (EM86XX_REVISION=='C')
	if (revid!=3) {
		RMDBGLOG((ENABLE,"identify: " S_EM86XX_CHIPID S_EM86XX_REVISION " software on older revid=0x%x\n",revid));
		return -1;
	}
#else
#error unsupported revision
#endif

#elif (EM86XX_CHIP==EM86XX_CHIPID_TANGOLIGHT)

	if ( ! (((device & 0xff) == 0x20) || ((device & 0xff) == 0x21)) ) {
		RMDBGLOG((ENABLE,"identify: " S_EM86XX_CHIPID " software inserted on other hardware (0x%04x)\n",device));
		return -1;
	}

	// e.m. do not weaken this to a warning
#if (EM86XX_REVISION=='C')
	if (revid!=0x82) {
		RMDBGLOG((ENABLE,"identify: " S_EM86XX_CHIPID S_EM86XX_REVISION " software on older revid=0x%x\n",revid));
		return -1;
	}
#else
#error unsupported revision
#endif

#elif (EM86XX_CHIP==EM86XX_CHIPID_TANGO15)
	if ( ! (((device & 0xff) == 0x22) || ((device & 0xff) == 0x23) || ((device & 0xff) == 0x24) || ((device & 0xff) == 0x25)) ) {
		RMDBGLOG((ENABLE,"identify: " S_EM86XX_CHIPID " software inserted on other hardware (0x%04x)\n",device));
		return -1;
	}

	// e.m. do not weaken this to a warning
#if (EM86XX_REVISION<='A')
	if ((revid!=0x81) && (revid!=0x82)) {
		RMDBGLOG((ENABLE,"identify: " S_EM86XX_CHIPID S_EM86XX_REVISION " software on revid=0x%x\n",revid));
		return -1;
	}
#elif (EM86XX_REVISION=='B')
	if (revid!=0x82) {
		RMDBGLOG((ENABLE,"identify: " S_EM86XX_CHIPID S_EM86XX_REVISION " software on revid=0x%x\n",revid));
		return -1;
	}
#else
#error unsupported revision
#endif

#elif (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)

	if ( ! ((device & 0xf0) == 0x30) ) {
		RMDBGLOG((ENABLE,"identify: " S_EM86XX_CHIPID " software inserted on other hardware (0x%04x)\n",device));
		return -1;
	}
	
	// e.m. do not weaken this to a warning
#if (EM86XX_REVISION<=3)
	if (revid!=0x81) {
		RMDBGLOG((ENABLE,"identify: " S_EM86XX_CHIPID S_EM86XX_REVISION " software on revid=%#x\n",revid));
		return -1;
	}
#elif (EM86XX_REVISION==4)
	if ((revid!=0x82) || !isES4(pE->pgbus)) {
		RMDBGLOG((ENABLE,"identify: " S_EM86XX_CHIPID S_EM86XX_REVISION " software on revid %#x\n",revid));
		return -1;
	}
#elif (EM86XX_REVISION==5)
	if ((revid!=0x82) || isES4(pE->pgbus)) {
		RMDBGLOG((ENABLE,"identify: " S_EM86XX_CHIPID S_EM86XX_REVISION " software on revid %#x\n",revid));
		return -1;
	}
#elif ((EM86XX_REVISION==6)||(EM86XX_REVISION==7)||(EM86XX_REVISION=='A')||(EM86XX_REVISION=='B'))
	/* 2006dec5: accept to load the driver build for ES6 and ES7 on ES4, ES5, ES6, ES7, ES8. See bug #4472 */
	if (revid<0x82) {
		RMDBGLOG((ENABLE,"identify: " S_EM86XX_CHIPID S_EM86XX_REVISION " software on revid %#x\n",revid));
		return -1;
	}
#elif ((EM86XX_REVISION==8)||(EM86XX_REVISION==9)||(EM86XX_REVISION=='C'))
	/* 2006dec5: you want explicitely an ES8/ES9 build, accept only ES8/ES9 */
	if ((revid!=0x85)&&(revid!=0x86)) {
		RMDBGLOG((ENABLE,"identify: " S_EM86XX_CHIPID S_EM86XX_REVISION " software on revid %#x\n",revid));
		return -1;
	}
#else
#error unsupported revision
#endif
	
#else
#error EM86XX_CHIP is not set in RMCFLAGS: refer to emhwlib/include/emhwlib_chips.h.
#endif

	RMDBGLOG((ENABLE,
		  "identify: device 0x%04x 0x%x accepted with software " 
		  S_EM86XX_CHIPID S_EM86XX_REVISION "\n",device,revid));
	
	return 0;
}
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

int init_module(void)
{  
	char dev[3];
	RMuint32 number_of_probed_em8xxx = 0, minor = 0;
	RMuint32 InterruptEnableMask;

	RMDBGLOG((ENABLE,"init_module: begun\n"));

	/* add the em8xxx driver entry */
	add_driver_proc_entry();

	while (minor < MAXLLAD) {
		memset(&Etable[minor],0,sizeof(struct em8xxxprivate));

		kc_spin_lock_init(&Etable[minor].lock);
		
		kc_sprintf(dev, "%d", minor);
		Etable[minor].pllad = llad_open(dev);
		if (Etable[minor].pllad == NULL) break;
		
		Etable[minor].pgbus = gbus_open(Etable[minor].pllad);
		if (Etable[minor].pgbus ==  NULL) {
			RMDBGLOG((ENABLE,"Cannot open gbus\n"));
			goto clean_llad;
		}
		
		if (identify(&Etable[minor]) != 0) {
			RMDBGLOG((ENABLE,"software/hardware conflict --- cannot go on\n"));
			goto clean_gbus;
		}
		
		Etable[minor].pemhwlib = (struct EMhwlib *) kc_vmalloc(EMhwlibGetSize());
		if (Etable[minor].pemhwlib == NULL) {
			RMDBGLOG((ENABLE,"Cannot allocate %lu bytes for emhwlib\n", EMhwlibGetSize()));
			goto clean_gbus;
		}

		Etable[minor].insmod_em8xxx_id = CURRENT_EM8XXX_ID;
		kc_init_waitqueue_head(&Etable[minor].wq);
		
		if (EMhwlibCreate(Etable[minor].pgbus, Etable[minor].pemhwlib) != RM_OK) {
			RMDBGLOG((ENABLE,"Cannot create emhwlib for device %lu\n", minor));
			goto clean_emhwlib_allocation;
		}

		// Enable the PCI interrupts (They are disabled by default)
		InterruptEnableMask = 0xFFFFFFFF;
		EMhwlibSetProperty(Etable[minor].pemhwlib, CPUBlock, RMCPUBlockPropertyID_PCIEnableInterrupt,
				   &InterruptEnableMask, sizeof(InterruptEnableMask));

		/* some interrupts may have already be sent */
		EMhwlibProcessInterrupt(Etable[minor].pemhwlib, LLAD_SOFT_INTERRUPT, (void *) &(Etable[minor]));

		Etable[minor].buf1 = (RMuint8 *) kc_vmalloc(2 * MAX_PROPSIZE);
		if (Etable[minor].buf1 == NULL) {
			RMDBGLOG((ENABLE,"Cannot allocate ioctl temporary buffers\n"));
			goto clean_emhwlib_creation;
		}
		
		Etable[minor].buf2 = Etable[minor].buf1 + MAX_PROPSIZE;
		kc_tasklet_init(&(Etable[minor].tasklet), em8xxx_tasklet, (unsigned long) &(Etable[minor]));
		mumk_register_tasklet(Etable[minor].pgbus, Etable[minor].tasklet, &(Etable[minor].tasklet_irq_status), LLAD_SOFT_INTERRUPT | LLAD_WAIT_WRITE_COMPLETE);
		
		// Add the /proc/driver/em8xxx/[minor] where [minor] is 0..
		add_board_proc_entry(minor);
		
		// Add the /proc/driver/em8xxx/[minor]/resources
		add_board_proc_files(minor, &(Etable[minor]));

		number_of_probed_em8xxx ++;
		goto next_device;
		
	clean_emhwlib_creation:
		EMhwlibDestroy(Etable[minor].pemhwlib);
		
	clean_emhwlib_allocation:
		kc_vfree(Etable[minor].pemhwlib);
		Etable[minor].pemhwlib = NULL;
		
	clean_gbus:
		gbus_close(Etable[minor].pgbus);
		Etable[minor].pgbus = NULL;
		
	clean_llad:
		llad_close(Etable[minor].pllad);
 		Etable[minor].pllad = NULL;

	next_device:
		minor++;
	}
		
	if (number_of_probed_em8xxx==0) goto wayout;
	
	if (register_chrdev(major, EM8XXX_DEVICE_NAME, &em8xxx_fops)<0) {
		RMDBGLOG((ENABLE,"init_module: Can't register module!\n"));
		goto wayout;
	}

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
	{
		char devfs_name[64];
		
		/* call will return -1 if CONFIG_DEVFS_FS is undefined */
		devfs_major = devfs_alloc_major(DEVFS_SPECIAL_CHR);
		
		/* does nothing if CONFIG_DEVFS_FS is undefined */
		for (minor=0 ; minor<MAXLLAD; minor++) {
			if (Etable[minor].pllad == NULL)
				continue;
			
			sprintf(devfs_name, "%s%lu", EM8XXX_DEVICE_NAME, minor);
			Etable[minor].devfs_handle = kc_devfs_register(NULL, devfs_name, 
								       DEVFS_FL_DEFAULT, (devfs_major>0) ? devfs_major : major, minor,
								       S_IFCHR | S_IRUGO | S_IWUGO,
								       &em8xxx_fops, Etable + minor);
			if (Etable[minor].devfs_handle == NULL) 
				RMDBGLOG((ENABLE,"init_module: cannot register devfs for device %s\n", devfs_name));
		}
	}
#else
	// see post-halloween document: devfs will be obsoleted in favour of udev (E.M.)
#endif


	RMDBGLOG((ENABLE,"init_module: done. Found %lu em8xxx\n", number_of_probed_em8xxx));
	return 0;
	
 wayout:
	RMDBGLOG((ENABLE,"init_module: no valid board found\n"));
	return -EINVAL;
}

void cleanup_module(void)
{
	RMuint32 minor;
	RMDBGLOG((ENABLE,"cleanup_module: begun\n"));

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
	/* does nothing if CONFIG_DEVFS_FS is undefined */
	for (minor=0 ; minor<MAXLLAD ; minor++) {
		if (Etable[minor].devfs_handle != NULL) {
			kc_devfs_unregister(Etable[minor].devfs_handle);
		}
	}	

	/* does nothing if CONFIG_DEVFS_FS is undefined */
	if (devfs_major > 0) 
		devfs_dealloc_major(DEVFS_SPECIAL_CHR, devfs_major); 
#endif

	unregister_chrdev(major, EM8XXX_DEVICE_NAME);

	for (minor=0 ; minor<MAXLLAD ; minor++) {
		if (Etable[minor].pllad != NULL) {
			kc_tasklet_disable(Etable[minor].tasklet);
			mumk_unregister_tasklet(Etable[minor].pgbus, Etable[minor].tasklet);
			kc_tasklet_deinit(Etable[minor].tasklet);
			kc_deinit_waitqueue_head(Etable[minor].wq);
			kc_vfree(Etable[minor].buf1);
			
			// remove the /proc/driver/em8xxx/[minor]/...
			rm_board_proc_files(minor);
			
			// remove the /proc/driver/em8xxx/[minor]
			rm_board_proc_entry(minor);

			EMhwlibDestroy(Etable[minor].pemhwlib);

			Etable[minor].insmod_em8xxx_id = 0;

			kc_vfree(Etable[minor].pemhwlib);
			gbus_close(Etable[minor].pgbus);
			llad_close(Etable[minor].pllad);
			kc_spin_lock_deinit(Etable[minor].lock);
		}
	}

	// remove the /proc/driver/em8xxx
	rm_driver_proc_entry();

	RMDBGLOG((ENABLE,"cleanup_module: done\n"));
}


 
RMstatus krua_get_pointers(RMuint32 chip_id, RMuint32 *pe, RMuint32 *pem)
{
	
	if(chip_id>=MAXLLAD){
	return RM_ERROR;
	}
	
	*pe = (RMuint32)&Etable[chip_id];
	
	*pem = (RMuint32)Etable[chip_id].pemhwlib;
	RMDBGLOG((ENABLE, "I have pe %ld and pem %ld\n", pe, pem));
	
	return RM_OK;
}


RMstatus krua_set_property(void*pE,RMuint32 ModuleID, RMuint32 PropertyID, void *pValue,RMuint32 ValueSize)
{

	RMstatus rc;
	struct em8xxxprivate *pe= (struct em8xxxprivate *)pE; 

	//RMDBGLOG((ENABLE,"krua_set_property: enable BH spinlock\n"));
	kc_spin_lock_bh(pe->lock);
	
	rc = EMhwlibSetProperty(pe->pemhwlib, ModuleID, PropertyID, pValue, ValueSize);
	
	kc_spin_unlock_bh(pe->lock);
	//RMDBGLOG((ENABLE,"krua_set_property: disable BH spinlock\n"));
	
	return rc;
}


RMstatus krua_get_property(void*pE,RMuint32 ModuleID, RMuint32 PropertyID, void *pValue,RMuint32 ValueSize)
{
	RMstatus rc;
	struct em8xxxprivate *pe= (struct em8xxxprivate *)pE; 
	
	//RMDBGLOG((ENABLE,"krua_get_property: enable BH spinlock\n"));
	kc_spin_lock_bh(pe->lock);
	
	rc = EMhwlibGetProperty(pe->pemhwlib, ModuleID, PropertyID, pValue, ValueSize);
	
	kc_spin_unlock_bh(pe->lock);
	//RMDBGLOG((ENABLE,"krua_get_property: disable BH spinlock\n"));
 	
	
	return rc;

}


RMstatus krua_exchange_property(void*pE,RMuint32 ModuleID, RMuint32 PropertyID, void *pValueIn,RMuint32 ValueInSize,void *pValueOut,RMuint32 ValueOutSize)
{

	RMstatus rc;
	struct em8xxxprivate *pe= (struct em8xxxprivate *)pE; 

	//RMDBGLOG((ENABLE,"krua_exchange_property: enable BH spinlock\n"));
	kc_spin_lock_bh(pe->lock);
	
	rc=EMhwlibExchangeProperty(pe->pemhwlib, ModuleID, PropertyID, pValueIn, ValueInSize,pValueOut, ValueOutSize);
	kc_spin_unlock_bh(pe->lock);
	//RMDBGLOG((ENABLE,"krua_exchange_property: disable BH spinlock\n"));
	
	return rc;
 
}



RMstatus krua_set_property_from_bh(void*pE,RMuint32 ModuleID, RMuint32 PropertyID, void *pValue,RMuint32 ValueSize)
{
	RMstatus rc;
	struct em8xxxprivate *pe= (struct em8xxxprivate *)pE; 
	//RMDBGLOG((ENABLE,"krua_set_property_from_bh: enable spinlock\n"));
	kc_spin_lock(pe->lock);	
	
	rc = EMhwlibSetProperty(pe->pemhwlib, ModuleID, PropertyID, pValue, ValueSize);
	kc_spin_unlock(pe->lock);
	//RMDBGLOG((ENABLE,"krua_set_property_from_bh: disable spinlock\n"));
	
	return rc;
}


RMstatus krua_get_property_from_bh(void*pE,RMuint32 ModuleID, RMuint32 PropertyID, void *pValue,RMuint32 ValueSize)
{
	RMstatus rc;
	struct em8xxxprivate *pe= (struct em8xxxprivate *)pE; 
	//RMDBGLOG((ENABLE,"krua_get_property_from_bh: enable spinlock\n"));
	  
	kc_spin_lock(pe->lock);
	
	rc = EMhwlibGetProperty(pe->pemhwlib, ModuleID, PropertyID, pValue, ValueSize);
	
	kc_spin_unlock(pe->lock);
	
	//RMDBGLOG((ENABLE,"krua_get_property_from_bh: disable spinlock\n"));
	
	return rc;
}


RMstatus krua_exchange_property_from_bh(void*pE,RMuint32 ModuleID, RMuint32 PropertyID, void *pValueIn,RMuint32 ValueInSize,void *pValueOut,RMuint32 ValueOutSize)
{
	struct em8xxxprivate *pe= (struct em8xxxprivate *)pE; 
	RMstatus rc;
	//RMDBGLOG((ENABLE,"krua_exchange_property_from_bh: enable spinlock\n"));
	kc_spin_lock(pe->lock);
	
	rc=EMhwlibExchangeProperty(pe->pemhwlib, ModuleID, PropertyID, pValueIn, ValueInSize,pValueOut, ValueOutSize);
	kc_spin_unlock(pe->lock);
	//  RMDBGLOG((ENABLE,"krua_exchange_property_from_bh: disable spinlock\n"));
	
return rc;
}


EXPORT_SYMBOL(Etable);
EXPORT_SYMBOL(EMhwlibExchangeProperty);
EXPORT_SYMBOL(EMhwlibSendBuffer);
EXPORT_SYMBOL(EMhwlibReceiveBuffer);
EXPORT_SYMBOL(EMhwlibSetProperty);
EXPORT_SYMBOL(EMhwlibGetProperty);
EXPORT_SYMBOL(RMDBGLOG_implementation);
EXPORT_SYMBOL(EMhwlibReleaseAddress);
EXPORT_SYMBOL(RMDBGPRINT_implementation);
EXPORT_SYMBOL(EMhwlibUnregisterCleanable);
EXPORT_SYMBOL(EMhwlibAcquireAddress);
EXPORT_SYMBOL(EMhwlibSendBufferComplete);
EXPORT_SYMBOL(EMhwlibRegisterCleanable);
EXPORT_SYMBOL(krua_register_sendcomplete_callback);
EXPORT_SYMBOL(krua_unregister_sendcomplete_callback);
EXPORT_SYMBOL(krua_register_event_callback);
EXPORT_SYMBOL(krua_unregister_event_callback);
EXPORT_SYMBOL(krua_get_pointers);
EXPORT_SYMBOL(EMhwlibEventComplete);

EXPORT_SYMBOL(krua_set_property);
EXPORT_SYMBOL(krua_exchange_property);
EXPORT_SYMBOL(krua_set_property_from_bh);
EXPORT_SYMBOL(krua_exchange_property_from_bh);

/* HACK : There is a problem when EXPORT_SYMBOL_NOVERS are done on 8624 (too many exports? kernel memory full?).
   For now, since they are not used anywhere yet,  following symbols are not exported.*/ 

/* 
EXPORT_SYMBOL(krua_get_property_from_bh);
EXPORT_SYMBOL(krua_get_property);
*/

