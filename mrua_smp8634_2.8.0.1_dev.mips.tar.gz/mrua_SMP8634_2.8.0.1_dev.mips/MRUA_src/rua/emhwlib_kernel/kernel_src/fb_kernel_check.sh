#!/bin/bash
# test if kernel is > 2.6.15

echo "fb_kernel_check.sh: Checking version of kernel headers located in ${1}."

if [ -z "$1" ]
then
	echo "Error: you must pass the path to your Linux kernel headers as argument (e.g: ./fb_kernel_check.sh /usr/src/linux-2.6)"
	exit 1
fi

BASENAME=`basename $1`

if [[ -e ${1}/Makefile ]]
then
	exec < ${1}/Makefile
	read VERSION
	read PATCHLEVEL
	read SUBLEVEL	
	V=`sed 's/[^0-9]*//' <<< $VERSION`
	P=`sed 's/[^0-9]*//' <<< $PATCHLEVEL`
	S=`sed 's/[^0-9]*//' <<< $SUBLEVEL`
else
	echo "                    WARNING - Could not find Makefile in your Kernel headers, using pathname"
	echo "                              of Kernel headers to determine version number instead."

	if [[ ! `sed 's/[^0-9]*[0-9]*\.[0-9]*\.[0-9]*.*//' <<< $BASENAME` ]]
	then
		V=`sed 's/[^0-9]*\([0-9]*\)\.[0-9]*\.[0-9]*.*/\1/' <<< $BASENAME`
		P=`sed 's/[^0-9]*[0-9]*\.\([0-9]*\)\.[0-9]*.*/\1/' <<< $BASENAME`
		S=`sed 's/[^0-9]*[0-9]*\.[0-9]*\.\([0-9]*\).*/\1/' <<< $BASENAME`
	else
		echo "                             The pathname of your Kernel headers does not contain a version number of the form 2.XX.YY"
		echo "                             (e.g. /../linux-headers-2.6.17-xxx, beware if you are using symbolic links !)."
		echo ""
		echo "                    UNDEFINED Frame Buffer support."
		exit 1
	fi
fi
echo "                    --> Found version number $V.$P.$S of Kernel headers."
if [ $V -eq 2 ] && ( [ $P -gt 6 ] || ( [ $P -eq 6 ] && [ $S -ge 15 ] )) || [ $V -gt 2 ]
then
	echo "                    PASSED Frame Buffer support."
	exit 0
else
	echo "                    FAILED Frame Buffer support, you need Kernel headers 2.6.15 or newer."
	exit 1
fi
