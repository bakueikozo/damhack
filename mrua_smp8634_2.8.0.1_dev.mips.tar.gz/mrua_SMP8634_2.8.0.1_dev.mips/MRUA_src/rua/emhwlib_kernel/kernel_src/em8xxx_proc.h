/*****************************************
 Copyright � 2001-2004
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   em8xxx_proc.h
  @brief  

  long description
  Implements the /proc/driver/em8xxx/[board]/[info_file] where
  	[board] is the board number (minor driver number)
	[info_file] is the file you can "cat" to retrieve info	

  See licensing details in LICENSING file  
  
  @author Jacques Mahe
  @date   2004-04-30
*/

#ifndef __EM8XXX_PROC_H__
#define __EM8XXX_PROC_H__

#ifdef WITH_PROC

/* Add and remove the /proc/driver/em8xxx */
void add_driver_proc_entry(void);
void rm_driver_proc_entry(void);

/* Add and remove the /proc/driver/em8xxx/0 .. X (where X is the number of boards - 1 */
void add_board_proc_entry(unsigned int minor);
void rm_board_proc_entry(unsigned int minor);

void add_board_proc_files(unsigned int minor, void *data);
void rm_board_proc_files(unsigned int minor);

#else // WITH_PROC

static inline void add_driver_proc_entry(void) {}
static inline void rm_driver_proc_entry(void) {}

/* Add and remove the /proc/driver/em8xxx/0 .. X (where X is the number of boards - 1 */
static inline void add_board_proc_entry(unsigned int minor) {}
static inline void rm_board_proc_entry(unsigned int minor) {}

static inline void add_board_proc_files(unsigned int minor, void *cookie) {}
static inline void rm_board_proc_files(unsigned int minor) {}

#endif // WITH_PROC

#endif

