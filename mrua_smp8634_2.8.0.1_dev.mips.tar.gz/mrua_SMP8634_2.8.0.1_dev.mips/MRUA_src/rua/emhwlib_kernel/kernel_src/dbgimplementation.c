/*****************************************
 Copyright � 2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
	@file dbgimplementation.c
	@brief kernel module debugging print implementation.
*/

#define ALLOW_OS_CODE
#include "../../../rmdef/rmdef.h"

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/string.h>

/*
  Avoid to allocate string buffers on stack because stack is limited.

  Doing as below causes the logging function to be not reentrant, both
  because of static str and because of logboard.

  When concurrency occurs, only consequence is that logging becomes 
  incorrect: no big deal.

  [Informative: there is a `str' and `logboard' symbol in mum.o as well,
  but they do not conflict: logging functions are separate]
 */

#define RM_MAX_STRING 1000
static char str[RM_MAX_STRING];
int logboard=-1;

#ifndef RMDBGLOG_implementation
void RMDBGLOG_implementation(RMbool active,const RMascii *filename,RMint32 line,const RMascii *text,...)
{  
        if (active) {
		va_list ap;
		
		if (logboard==-1) 
			snprintf(str,RM_MAX_STRING,"em8xxx [%s:%ld] ",(char *)filename,line);
		else
			snprintf(str,RM_MAX_STRING,"em8xxx%d [%s:%ld] ",logboard,(char *)filename,line);
		
                va_start(ap, text);
                vsnprintf(str+strlen(str), RM_MAX_STRING-strlen(str), text, ap);
		va_end(ap);
                
		printk(str);
        }
}
#endif // RMDBGLOG_implementation

#ifndef RMDBGPRINT_implementation
void RMDBGPRINT_implementation(RMbool active,const RMascii *filename,RMint32 line,const RMascii *text,...)
{
        if (active) {
		va_list ap;
		
                va_start(ap, text);
                vsnprintf(str,RM_MAX_STRING,text,ap);
                va_end(ap);
                
               	printk(str);
        }
}
#endif // RMDBGPRINT_implementation
