/*****************************************
 Copyright � 2004-2005
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   em8xxxoss.h
  @brief  

  OSS sound driver for em8xxx

  @author Yoann Walther, Julien Soulier
  @date   2005-07-13
*/

#ifndef __EM8XXXOSS_H__
#define __EM8XXXOSS_H__

#define ALLOW_OS_CODE 1
#define MAXDMAPOOL 32
#define VOLUME_0DB		0x10000000
#define VOLUME_INDEX_0DB	49
#define AUDIO_DMA_BUFFER_SIZE_LOG2 12 // (1 << 12) == 4 KBytes
#define AUDIO_DMA_BUFFER_COUNT 32
#define SERIALIN_DMA_BUFFER_SIZE_LOG2 12 // (1 << 12) == 4 KBytes
#define SERIALIN_DMA_BUFFER_COUNT 32
#define AUDIO_PCI_FIFO_BUFFER_COUNT AUDIO_DMA_BUFFER_COUNT
#define SERIALIN_FIFO_SIZE 32*(1024)
#define AUDIO_BITSTREAM_FIFO_SIZE 32*(1024)
#define MAXAREABUFFERCOUNT (1024)
#define MAXCHANNELOUTCOUNT  10
#define PCMLINECOUNT 0x800
#define BLKSIZE 4096
#define PTS_FIRST_DELAY 28800 // this should be a multiple of the nb_bits_per_sample (16)
#define INFO_SIZE   1024
#define RECEIVEDATA_TIMEOUT_US 1000000 // 1 sec
#define AUDIO_BTS_THRESHOLD 4096


#include "../../../emhwlib/include/emhwlib.h"
#include "../../../emhwlib/include/emhwlib_properties_1000.h"


#include "../../../emhwlib/include/emhwlib_event.h"
#include "../../../emhwlib/include/emhwlib_chipspecific.h"

#include "../../../llad/kinclude/kernelcalls.h"
#include "../../../llad/kinclude/mum_kk.h"
#include "../../../llad/include/kdmapool.h"
#include "../include/em8xxx_uk.h"
#include "em8xxx.h"
#include "em8xxx_proc.h"


#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/version.h>

#include <linux/fs.h>
#include <linux/sched.h>
#include <linux/interrupt.h>
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,18)
#include <linux/devfs_fs_kernel.h>
#endif
#include <linux/poll.h>

#if EM86XX_MODE==EM86XX_MODEID_WITHHOST
#include <linux/pci.h>
#endif // EM86XX_MODE
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,17)
#include <linux/moduleparam.h>
#endif


#include <linux/sound.h>
#include <linux/soundcard.h>

#include "../../../gbuslib/include/gbus_time.h"


#define EM8XXXSNDSP(pE,moduleID,propertyID,pValue,valueSize)		\
	do {								\
		kc_spin_lock_bh(pE->lock);				\
		err = EMhwlibSetProperty(pE->pemhwlib,moduleID,propertyID,pValue,valueSize); \
		kc_spin_unlock_bh(pE->lock);				\
	} while (0)						

#define EM8XXXSNDEXP(pE,moduleID,propertyID,pValue_in,valueSize_in,pValue_out,valueSize_out)	\
	do {								\
		kc_spin_lock_bh(pE->lock);				\
		err = EMhwlibExchangeProperty(pE->pemhwlib,moduleID,propertyID,pValue_in,valueSize_in,pValue_out,valueSize_out); \
		kc_spin_unlock_bh(pE->lock);				\
	} while (0)
	
#define EM8XXXSNDGP(pE,moduleID,propertyID,pValue,valueSize)		\
	do {								\
		kc_spin_lock_bh(pE->lock);				\
		err = EMhwlibGetProperty(pE->pemhwlib,moduleID,propertyID,pValue,valueSize); \
		kc_spin_unlock_bh(pE->lock);				\
	} while (0)
	

static RMuint32 VolumeTable[VOLUME_INDEX_0DB+1+24] = {
	0x00000000,								// mute
	0x00100000, 0x0011f59c, 0x001428a4, 0x0016a09f, 0x001965ff, 0x001c823e, // -48dB ... -43dB
	0x00200000, 0x0023eb35, 0x00285145, 0x002d413c, 0x0032cbfc, 0x0039047b, // -42dB ... -37dB
	0x00400000, 0x0047d66a, 0x0050a28b, 0x005a8279, 0x006597fa, 0x007208f8, // -36dB ... -31dB
	0x00800000, 0x008facd6, 0x00a14518, 0x00b504f3, 0x00cb2ff5, 0x00e411f0, // -30dB ... -25dB
	0x01000000, 0x011f59ac, 0x01428a2f, 0x016a09e6, 0x01965fea, 0x01c823e0, // -24dB ... -19dB
	0x02000000, 0x023eb358, 0x0285145f, 0x02d413cd, 0x032cbfd5, 0x039047c1, // -18dB ... -13dB
	0x04000000, 0x047d66b1, 0x050a28be, 0x05a82799, 0x06597fa9, 0x07208f82, // -12dB ...  -7dB
	0x08000000, 0x08facd62, 0x0a14517d, 0x0b504f34, 0x0cb2ff53, 0x0e411f04, //  -6dB ...  -1dB
	0x10000000, 0x11f59ac4, 0x1428a2fa, 0x16a09e67, 0x1965fea6, 0x1c823e08, //   0dB ...   5dB
	0x20000000, 0x23eb3589, 0x285145f5, 0x2d413ccf, 0x32cbfd4c, 0x39047c10, //   6dB ...  11dB
	0x40000000, 0x47d66b10, 0x50a28be7, 0x5a82799a, 0x6597fa95, 0x7208f81d, //  12dB ...  17dB
	0x80000000, 0x8facd61c, 0xa14517c9, 0xb504f32f, 0xcb2ff523, 0xe411f032, //  18dB ...  23dB
	0xffffffff  // ~24dB
};



struct sndprivate {

	/* mixer specific variables */


	int mixer_dev;
	int mixer_open_count;
	
	/* dsp specific variables */
	int dsp_dev;
	int dsp_open_count;
	
	int sample_rate;
	int channel_count;
	int format;
	int nb_bits_per_sample;
	RMbool MSBFirst;
	wait_queue_head_t sound_queue;
	struct kc_wait_queue_head_t * sq;
	RMuint32 dmapool_id;
	RMuint32 capture_dmapool_id;
	RMuint32 capture_readable;
	RMuint32 capture_buffer_bus_addr;
	RMuint32 capture_buffer_size;
	RMuint32 capture_read;
	RMuint32 capture_written;
	RMuint32 i_start;
	RMuint32 j_start;
	RMuint32 k;
	RMuint32 last_i;
	RMuint32 last_j;
	RMuint32 state;

	struct tasklet_struct event_tq;
	RMuint32 event_mask;

	RMuint8 *pBuf;
	RMuint8 *capture_pBuf;
	
	RMuint32 AudioUCodeAddr;
	RMuint32 AudioProfileCachedAddr; 
	RMuint32 AudioProfileUncachedAddr;
	RMuint32 SerialinProfileCachedAddr; 
	RMuint32 SerialinProfileUncachedAddr;

	int sndprivate_active;
	int weight;
	int weight_l;
	int weight_r;
	int volume;
	RMbool capture_enable;
	RMbool playback_enable;
	RMbool firstPTS;

};

struct sndprivate Stable[MAXLLAD];

#endif // __EM8XXXOSS_H__
