/*****************************************
 Copyright  2004-2005
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   em8xxx_oss.c
  @brief  

  OSS sound driver for em8xxx series.

  @author Yoann Walther
  @date   2005-07-12
*/

#include "em8xxxoss.h"

static u_long audio_capture_index; 
static u_long audio_decoder_index=1;
static u_long audio_engine_index;
static u_long audio_mmID = 0;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,17)
module_param(audio_decoder_index, ulong,0);
module_param(audio_mmID, ulong,0);
#else
MODULE_PARM(audio_decoder_index, "l");
MODULE_PARM(audio_mmID, "l");
#endif
MODULE_PARM_DESC(audio_decoder_index, "Audio Decoder in use\n");
MODULE_PARM_DESC(audio_mmID, "Audio Memory Manager in use\n");

MODULE_DESCRIPTION("EM8XXX Sound OSS Driver");
MODULE_AUTHOR("Yoann Walther <yoann_walther@sdesigns.eu>");
#ifdef MODULE_LICENSE
MODULE_LICENSE("Proprietary");
#endif


extern struct em8xxxprivate Etable[MAXLLAD];
RMstatus krua_register_event_callback(void *pE,RMuint32 ModuleID,RMuint32 mask, Event_callback callback);
RMstatus krua_unregister_event_callback(void *pE,RMuint32 ModuleID,Event_callback callback);
static RMstatus prepare_data(struct sndprivate *pS);
static RMuint32 bytes_to_samples(struct sndprivate *pS,RMuint32 count);
static RMstatus start_capture(struct em8xxxprivate *pE);
static RMstatus start_playback(struct em8xxxprivate *pE);

/* mixer file operations */

static int rm_open_mixer(struct inode *inode, struct file *file);
static int rm_release_mixer(struct inode *inode, struct file *file);
static int rm_ioctl_mixer(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg);
static int process_ioctl_mixer(struct em8xxxprivate *pE, unsigned int cmd, unsigned long arg);

static struct file_operations rm_mixer_fops = {
	owner:		THIS_MODULE,

	ioctl:		rm_ioctl_mixer,
	open:		rm_open_mixer,
	release:	rm_release_mixer,
};


/* dsp file operations */
static ssize_t rm_read_dsp(struct file *file, char *buffer, size_t count, loff_t *ppos);
static ssize_t rm_write_dsp(struct file *file, const char *buffer, size_t count, loff_t *ppos);
static unsigned int rm_poll_dsp(struct file *file, struct poll_table_struct *wait);
static int rm_mmap_dsp(struct file *file, struct vm_area_struct *vma);
static int rm_ioctl_dsp(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg);
static int rm_open_dsp(struct inode *inode, struct file *file);
static int rm_release_dsp(struct inode *inode, struct file *file);
static int process_ioctl_dsp(struct sndprivate *pS, unsigned int cmd, unsigned long arg);
//static RMstatus set_audio_parameters(struct em8xxxprivate *pE, int format, int sampleRate, int channelCount);
static RMstatus init_audio(struct sndprivate *pS);
static RMstatus cleanup_audio(struct sndprivate *pS);
static int rm_free_ptr(struct em8xxxprivate *pE,RMuint32 ptr);

static /*const*/ struct file_operations rm_dsp_fops = {
	// this replaces MOD_INC_USE_COUNT/MOD_DEC_USE_COUNT pain
	owner:		THIS_MODULE,

	read:		rm_read_dsp,
	write:		rm_write_dsp,
	poll:		rm_poll_dsp,
	ioctl:		rm_ioctl_dsp,
	mmap:		rm_mmap_dsp,
	open:		rm_open_dsp,
	release:	rm_release_dsp,
};

static int sndprivate_init(struct em8xxxprivate *pE)
{
	struct sndprivate *pS=Stable+(pE-Etable);
	
	if (pS->sndprivate_active == 0) {
		memset(pS,0,sizeof(struct sndprivate));
		
		if ((pS->mixer_dev = register_sound_mixer(&rm_mixer_fops, -1)) < 0) {
			printk("Cannot register em8xxx sound mixer device\n");
			goto error_mixer;
		}
		if ((pS->dsp_dev = register_sound_dsp(&rm_dsp_fops, -1)) < 0) {
			printk("Cannot register em8xxx sound dsp device\n");
			goto error_dsp;
		}
	}
	else {
		printk("em8xxx sound driver (/dev/mixer%d, /dev/dsp%d) already registered\n", pS->mixer_dev, pS->dsp_dev);
		return -EINVAL;
	}
	
	pS->sndprivate_active = 1;
	printk("em8xxx sound driver (/dev/mixer%d, /dev/dsp%d) registered.\n", pS->mixer_dev, pS->dsp_dev);

	return 0;
	
 error_dsp:
	unregister_sound_mixer(pS->mixer_dev);
	
 error_mixer:
	return -EINVAL;

}

static int sndprivate_cleanup(struct em8xxxprivate *pE)
{
	struct sndprivate *pS=Stable+(pE-Etable);

	
	// unregister dsp & mixer
	
	if (pS->sndprivate_active == 1) {
		if ((pS->mixer_open_count == 0) && 
		    (pS->dsp_open_count == 0)) {
			unregister_sound_mixer(pS->mixer_dev);
			unregister_sound_dsp(pS->dsp_dev);
		}
		else {
			if (pS->mixer_open_count > 0) 
				printk("cannot unregistered (/dev/mixer%d). device is opened %d times\n", pS->mixer_dev, pS->mixer_open_count);
			
			if (pS->dsp_open_count > 0)
				printk("cannot unregistered (/dev/dsp%d). device is opened %d times\n", pS->dsp_dev, pS->dsp_open_count);

			return -EINVAL;
		}
	}
	else {
		printk("no em8xxx sound mixer device registered\n");
		return -EINVAL;
	}
		
	printk("em8xxx sound mixer (/dev/mixer%d, /dev/dsp%d) unregistered\n", pS->mixer_dev, pS->dsp_dev);
	pS->sndprivate_active = 0;

	return 0;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////                                   MIXER FILE OPERATIONS                                       ///////
////////////////////////////////////////////////////////////////////////////////////////////////////////////


static int rm_open_mixer(struct inode *inode, struct file *file)
{
	int i;
	int minor = MINOR(inode->i_rdev);
	struct em8xxxprivate *pE = (struct em8xxxprivate *) NULL; 
	struct sndprivate *pS = (struct sndprivate *) NULL;
	
 	for (i=0 ; i<MAXLLAD ; i++) {
		pE = &Etable[i];
		pS = Stable+(pE-Etable);
		if (pS->sndprivate_active == 1) {
			if (pS->mixer_dev == minor) 
				break;
		}
	}
	
	if (i == MAXLLAD) { // can't find corresponding realmagic device
		printk("Cannot open em8xxx sound mixer device\n");
		return -EINVAL;
	}
	
	printk("Opens em8xxx sound mixer (/dev/mixer%d)\n", minor);
	pS->mixer_open_count ++;
	
	file->private_data = pS;
	return 0;
}

static int rm_release_mixer(struct inode *inode, struct file *file)
{
	struct sndprivate *pS=(struct sndprivate *)file->private_data;
	struct em8xxxprivate *pE;
	
	pE=Etable+(pS-Stable);
	
	printk("closes em8xxx sound mixer (/dev/mixer%d)\n", pS->mixer_dev);
	if(pS->mixer_open_count) pS->mixer_open_count --;
	return 0;
}

static int rm_ioctl_mixer(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg)
{
	struct sndprivate *pS=(struct sndprivate *)file->private_data;
	struct em8xxxprivate *pE=Etable+(pS-Stable);
	int rc;

	rc = process_ioctl_mixer(pE, cmd, arg);

	return rc;
}
static int process_ioctl_mixer(struct em8xxxprivate *pE, unsigned int cmd, unsigned long arg)
{
	int val, i,volume_index;
	int r,l;
	int rc = -EINVAL;
	struct sndprivate *pS=Stable+(pE-Etable);
	struct AudioEngine_Volume_type volume;
	struct AudioDecoder_MixerWeight_type cmdblock;
	RMstatus err;
	RMuint32 audio_decoder = EMHWLIB_MODULE(AudioDecoder,audio_decoder_index);

	if (_IOC_TYPE(cmd) != 'M' || _SIOC_SIZE(cmd) != sizeof(int)) {
		return -EINVAL;
	}
	
        if (_SIOC_DIR(cmd) == _SIOC_READ) {
                switch (_IOC_NR(cmd)) {
                case SOUND_MIXER_DEVMASK: /* Arg contains a bit for each supported device */
			val = SOUND_MASK_VOLUME | SOUND_MASK_PCM;
			rc = kc_logging_copy_to_user((int *) arg, &val, sizeof(int));
			return rc;

		case SOUND_MIXER_STEREODEVS: /* Mixer channels supporting stereo */
			val = SOUND_MASK_VOLUME | SOUND_MASK_PCM;
			rc = kc_logging_copy_to_user((int *) arg, &val, sizeof(int));
			return rc;

		case SOUND_MIXER_RECMASK:
		case SOUND_MIXER_CAPS:
		case SOUND_MIXER_RECSRC:
			val = 0;
			rc =kc_logging_copy_to_user((int *) arg, &val, sizeof(int));
			return rc;
			
		default:
			i = _IOC_NR(cmd);
			switch(i){
			case SOUND_MIXER_PCM:
				
				val = pS->weight;
				
				rc =kc_logging_copy_to_user((int *) arg, &val, sizeof(int));
				return rc;			
	

			case SOUND_MIXER_VOLUME:
								
				val = pS->volume;
				
				rc =kc_logging_copy_to_user((int *) arg, &val, sizeof(int));
				return rc;			
			default:
				return -EINVAL;
			}
		}
	}

	
        if (_SIOC_DIR(cmd) != (_SIOC_READ|_SIOC_WRITE)) {
		return -EINVAL;
	}
	
	switch (_IOC_NR(cmd)) {
	case SOUND_MIXER_RECSRC: /* Arg contains a bit for each recording source */
		return 0;
		
	default: 
		i = _IOC_NR(cmd);
		switch(i){
		case SOUND_MIXER_PCM:

			rc =kc_logging_copy_from_user(&val, (int *) arg, sizeof(int));
			if (rc != 0)
				break;
	
			// Mixer weight initialization
		
			l = val & 0xff;
		
			volume_index=l*74/100;
			volume_index=volume_index % 75;
			cmdblock.MixerValue_ch0=VolumeTable[volume_index] ;
			
			EM8XXXSNDSP( pE, audio_decoder,RMAudioDecoderPropertyID_MixerWeight,&cmdblock,sizeof(cmdblock));
			r = (val >> 8) & 0xff;
			
			volume_index=r*74/100;
			volume_index=volume_index % 75;	
			cmdblock.MixerValue_ch2=VolumeTable[volume_index] ;
			
			EM8XXXSNDSP( pE, audio_decoder,RMAudioDecoderPropertyID_MixerWeight,&cmdblock,sizeof(cmdblock));
			
			pS->weight = val;
			
			rc =kc_logging_copy_to_user((int *) arg, &val, sizeof(int));
			return rc;
		case SOUND_MIXER_VOLUME:
			
			rc =kc_logging_copy_from_user(&val, (int *) arg, sizeof(int));
			if (rc != 0)
				break;
			
			/* sets the left volume */
			
			l = val & 0xff;
			
			volume_index=l*74/100;
			volume_index=volume_index % 75;
			volume.Channel=0;
			volume.Volume=VolumeTable[volume_index];
			
			EM8XXXSNDSP(pE,EMHWLIB_MODULE(AudioEngine,audio_engine_index),RMAudioEnginePropertyID_Volume,&volume,sizeof(volume));
			if (RMFAILED(err)){
				printk("error while setting volume \n");
			}
			
			/* sets the right volume */
			r = (val >> 8) & 0xff;
			
			volume_index=r*74/100;
			volume_index=volume_index % 75;
			volume.Channel=2;
			volume.Volume=VolumeTable[volume_index];
			
			EM8XXXSNDSP(pE,EMHWLIB_MODULE(AudioEngine,audio_engine_index),RMAudioEnginePropertyID_Volume,&volume,sizeof(volume));
			if (RMFAILED(err)){
				printk("error while setting volume \n");
			}
			
			pS->volume = val;
			rc =kc_logging_copy_to_user((int *) arg, &val, sizeof(int));
			return rc;
		default:
			return -EINVAL;
		}
	}
	return rc;
}



/////////////////////////////////////////////////////////////////////////////////////////////////////////
////////                              /DEV/DSP FILE OPERATIONS                                 //////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////
static RMuint32 bytes_to_samples(struct sndprivate *pS,RMuint32 count)
{
	RMuint32 samples;
	RMuint32 nb_bits_per_sample = pS->nb_bits_per_sample;
	RMuint32 channel_count = pS->channel_count;

	samples = (count*8) / (nb_bits_per_sample*channel_count);
	return samples;
}

static RMstatus prepare_data(struct sndprivate *pS)
{
	struct em8xxx_data param;
	struct em8xxxprivate *pE = Etable + (pS-Stable);
	RMuint8 *buffer=NULL;
	RMuint32 timeout = 0;
	RMstatus err=RM_OK;
	RMuint32 audio_capture = EMHWLIB_MODULE(AudioCapture,audio_capture_index);
	struct ReadBufferInfo prop;
	RMuint32 nb_buf = 0;
	
	while (1) {
		
		timeout=0;
		
		buffer=kdmapool_getbuffer(pE->pllad,pS->capture_dmapool_id,&timeout);
				
		if (buffer==NULL){
			break;
		}	
		nb_buf ++;
	
		param.moduleId = audio_capture;
		param.poolId = pS->capture_dmapool_id;
		param.bus_addr = kdmapool_get_bus_address(pE->pllad,pS->capture_dmapool_id,buffer, 0);
		param.dataSize = (1<<SERIALIN_DMA_BUFFER_SIZE_LOG2);
		
		prop.address = param.bus_addr;
		prop.size = param.dataSize;
		prop.context = (void *) ((pE-Etable) + param.poolId + 1);
		EM8XXXSNDSP(pE, param.moduleId, RMGenericPropertyID_AddReadBuffer, &prop, sizeof(prop));
		
		buffer=NULL;
	}
	
	printk("prepared %ld buffers \n",nb_buf);
	return err;
	
}
void em8xxx_snd_clear_event_mask(unsigned long private_data)
{
	struct sndprivate *pS = (struct sndprivate *) private_data;
	struct em8xxxprivate *pE = Etable + (pS-Stable);
	RMuint32 status=0;
	RMuint32 mask;

	kc_spin_lock(pE->lock);
	mask = pS->event_mask;
	kc_spin_unlock(pE->lock);

	if (mask & SOFT_IRQ_EVENT_XFER_RECEIVE_READY) {
		kc_wake_up_interruptible(pS->sq);
		status |= SOFT_IRQ_EVENT_XFER_RECEIVE_READY;
	}

	kc_spin_lock(pE->lock);
	EMhwlibSetProperty(pE->pemhwlib,EMHWLIB_MODULE(AudioCapture,audio_capture_index),RMGenericPropertyID_ClearEventMask,&status,sizeof(status));
	pS->event_mask = 0;
	kc_spin_unlock(pE->lock);

}

static RMuint32 event_callback(void *pE,RMuint32 ModuleID,RMuint32 mask)
{
	struct em8xxxprivate *real_pE = (struct em8xxxprivate *) pE;
	struct sndprivate *pS = Stable + (real_pE-Etable);

	kc_spin_lock(real_pE->lock);
	pS->event_mask |= mask;
	kc_spin_unlock(real_pE->lock);
	tasklet_hi_schedule(&pS->event_tq);

	return mask;
}

static int rm_open_dsp(struct inode *inode, struct file *file)
{
	int i;
	int minor = MINOR(inode->i_rdev);
	struct em8xxxprivate *pE = (struct em8xxxprivate *) NULL; 
	struct sndprivate *pS = (struct sndprivate *) NULL;
	
 	for (i=0 ; i<MAXLLAD ; i++) {
		pE = &Etable[i];
		pS=Stable+(pE-Etable);		
		if (pS->sndprivate_active==1) {
			if (pS->dsp_dev==minor) break;
		}
	}
	
	if (i == MAXLLAD) { // can't find corresponding realmagic device
		printk("Cannot open em8xxx sound dsp device\n");
		return -EINVAL;
	}

	printk("Opens em8xxx sound device (/dev/dsp%d)\n", minor);

	/*Only one process can used oss device*/
	if(pS->dsp_open_count != 0){
		RMDBGLOG((ENABLE, "/dev/dsp already opened\n"));
		return -EMFILE;
	}
	pS->dsp_open_count ++;

	file->private_data = pS;

	init_waitqueue_head(&pS->sound_queue);
	kc_init_waitqueue_head(&pS->sq);

	if(init_audio(pS) != RM_OK)
	{
		printk("Audio initialisation error.\n");
		cleanup_audio(pS);
		pS->dsp_open_count --;
		return -EINVAL;
	}
	
	printk("Open the pools\n");

	//open the pools	

 	pS->dmapool_id=kdmapool_open(pE->pllad,NULL,AUDIO_DMA_BUFFER_COUNT,AUDIO_DMA_BUFFER_SIZE_LOG2);
	printk("dmapool id = %ld\n", pS->dmapool_id);
	{
	RMuint32 timeout = 0;
	pS->pBuf=kdmapool_getbuffer(pE->pllad,pS->dmapool_id,&timeout);
	}
	pS->capture_dmapool_id=kdmapool_open(pE->pllad,NULL,SERIALIN_DMA_BUFFER_COUNT,SERIALIN_DMA_BUFFER_SIZE_LOG2); 
	printk("capture_dmapool id = %ld\n", pS->capture_dmapool_id);
	prepare_data(pS);
	
	tasklet_init(&pS->event_tq,em8xxx_snd_clear_event_mask,(unsigned long) pS);
	krua_register_event_callback(pE,EMHWLIB_MODULE(AudioCapture,audio_capture_index),SOFT_IRQ_EVENT_XFER_RECEIVE_READY,event_callback);
	
	return 0;
}

static RMstatus cleanup_audio(struct sndprivate *pS)
{
	RMuint32 profile;
	struct em8xxxprivate *pE = Etable +(pS-Stable);
	RMstatus err;
	
	// close audio profile

	profile=0;

	EM8XXXSNDSP(pE,EMHWLIB_MODULE(AudioDecoder,audio_decoder_index), RMAudioDecoderPropertyID_Close, &profile, sizeof(profile));

	EM8XXXSNDSP(pE,EMHWLIB_MODULE(AudioCapture,audio_capture_index), RMAudioCapturePropertyID_Close, &profile, sizeof(profile));

	// close serialin dma pool

	kdmapool_close(pE->pllad,pS->capture_dmapool_id);

	// close STC
	
	EM8XXXSNDSP(pE,EMHWLIB_MODULE(STC,audio_decoder_index),RMSTCPropertyID_Close, NULL,sizeof(RMuint32));

	// free SharedMemory
	if (EMHWLIB_MODULE(AudioDecoder,audio_decoder_index) != 0) {
		/* Free the audio shared memory per engine */
		RMstatus err;
		RMuint32 connected_task_count;

		EM8XXXSNDGP(pE, EMHWLIB_MODULE(AudioEngine,audio_engine_index), RMAudioEnginePropertyID_ConnectedTaskCount, 
					&connected_task_count, sizeof(connected_task_count));
		if (err != RM_OK) {
			RMDBGLOG((ENABLE, "Cannot get RMAudioEnginePropertyID_ConnectedTaskCount %lu\n", EMHWLIB_MODULE(AudioEngine,audio_engine_index)));
			return err;                                                         
		}
		if (connected_task_count == 0) {
			struct AudioEngine_DecoderSharedMemory_type shared;
			RMuint32 address;
			EM8XXXSNDGP(pE, EMHWLIB_MODULE(AudioEngine,audio_engine_index), RMAudioEnginePropertyID_DecoderSharedMemory,
					     &shared, sizeof(shared));
				if (err != RM_OK) {
				RMDBGLOG((ENABLE, "Cannot get DecoderSharedMemory0\n"));
				return err;
			}
			if (shared.Address) {
				RMDBGLOG((ENABLE, "FREE %lx_DRAM AUDIO SHARED MEMORY addr=0x%lx size=0x%lx!\n",
					  audio_decoder_index, shared.Address, shared.Size));
				address = shared.Address;
				shared.Address = 0;
				shared.Size = 0;
				
				EM8XXXSNDSP(pE, EMHWLIB_MODULE(AudioEngine,audio_engine_index), RMAudioEnginePropertyID_DecoderSharedMemory, &shared, sizeof(shared));
				/* Unlock the shared address */
				rm_free_ptr (pE, address);
			}
		}
		else {
			RMDBGLOG((ENABLE, "CANNOT FREE AUDIO SHARED MEMORY. There are still %lx audio tasks opened. \n",
				  connected_task_count));
		}
	}

	// free resources
#if !defined(WITH_UCODE_BOOTLOADER) && !defined(WITH_XLOADED_UCODE)
	if (pS->AudioUCodeAddr);
		rm_free_ptr (pE,pS->AudioUCodeAddr);
#endif //  WITH_UCODE_BOOTLOADER
	if (pS->AudioProfileCachedAddr);
		rm_free_ptr (pE,pS->AudioProfileCachedAddr);
	if (pS->AudioProfileUncachedAddr);
		rm_free_ptr (pE,pS->AudioProfileUncachedAddr);
	if (pS->SerialinProfileCachedAddr);
		rm_free_ptr (pE,pS->SerialinProfileCachedAddr);
	if (pS->SerialinProfileUncachedAddr);
		rm_free_ptr (pE,pS->SerialinProfileUncachedAddr);

	return RM_OK;
}

static RMstatus init_audio(struct sndprivate *pS)
{
	struct em8xxxprivate *pE=Etable+(pS-Stable);
	RMstatus err;
	enum ProcessorState run;
	struct AudioDecoder_DRAMSizeX_in_type dram_in;
	struct AudioDecoder_DRAMSizeX_out_type dram_out;
	struct AudioDecoder_OpenX_type profile; 
	struct AudioCapture_DRAMSize_in_type capture_dram_in;
	struct AudioCapture_DRAMSize_out_type capture_dram_out;
	struct AudioCapture_Open_type capture_profile;
	RMuint32 audio_capture=EMHWLIB_MODULE(AudioCapture,audio_capture_index);
	RMuint32 audio_decoder=EMHWLIB_MODULE(AudioDecoder,audio_decoder_index);
	RMuint32 audio_engine=EMHWLIB_MODULE(AudioEngine,audio_engine_index);
	struct MM_Malloc_in_type in;
	struct MM_Malloc_out_type out;
	struct AudioEngine_DecoderSharedMemory_type shared;
	struct AudioEngine_DecoderSharedMemoryInfo_in_type info_in; 
	struct AudioEngine_DecoderSharedMemoryInfo_out_type info_out;
#if !defined(WITH_UCODE_BOOTLOADER) && !defined(WITH_XLOADED_UCODE)
	struct AudioEngine_MicrocodeDRAMSize_in_type size_in;
	struct AudioEngine_MicrocodeDRAMSize_out_type size_out;
	struct AudioEngine_Microcode_type ucode;
#endif // WITH_UCODE_BOOTLOADER
	
	printk("initializing audio parameters \n");

#if !defined(WITH_UCODE_BOOTLOADER) && !defined(WITH_XLOADED_UCODE)

	// Loading AudioEngine Module

	run = CPU_RESET;

	EM8XXXSNDSP(pE, audio_engine, RMAudioEnginePropertyID_State, &run, sizeof(run));

	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error while resetting CPU! \n"));
		return err;
	}
	
	run = CPU_STOPPED;

	EM8XXXSNDSP(pE, audio_engine, RMAudioEnginePropertyID_State, &run, sizeof(run));
	
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error while stopping CPU! \n"));
		return err;
	} 
	
	// Loading MicroCode for AudioEngine Module


	size_in.MicrocodeVersion = 1;
	
	// memory allocation for the microcode

	EM8XXXSNDEXP( pE, audio_engine, RMAudioEnginePropertyID_MicrocodeDRAMSize, &size_in, sizeof(size_in), &size_out, sizeof(size_out));

	if (RMFAILED(err)) { 
		RMDBGLOG((ENABLE, "Error while allocating memory for audio microcode! \n"));
		return err;
	} 


	ucode.MicrocodeVersion = size_in.MicrocodeVersion;
	
	in.dramtype=RUA_DRAM_CACHED;
	in.Size=size_out.Size;
	

	EM8XXXSNDEXP(pE,
		     EMHWLIB_MODULE(MM,audio_mmID),
		     RMMMPropertyID_Malloc,
		     &in,sizeof(in),
		     &out,sizeof(out));
	if(err==RM_OK) 
		ucode.Address= (RMuint32)out.Address;
	else {
		RMDBGLOG((ENABLE," memory manager not existent\n"));
		return 0;
	}
	
	printk("audio ucode cached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
	       ucode.Address,
	       size_out.Size,
	       ucode.Address + size_out.Size);
	
	pS->AudioUCodeAddr = ucode.Address;
	
	//  microcode loading

	EM8XXXSNDSP( pE, audio_engine, RMAudioEnginePropertyID_Microcode, &ucode, sizeof(ucode));

	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error while loading audio microcode! \n"));
       		return err;
	} 
#endif // WITH_UCODE_BOOTLOADER
	// Get the information for DRAM parameters for AudioCapture Module 
	capture_dram_in.SerialInFIFOSize = SERIALIN_FIFO_SIZE; 
	capture_dram_in.XferFIFOCount = SERIALIN_DMA_BUFFER_COUNT;
	
	// Memory allocation for AudioCapture Module

	EM8XXXSNDEXP(pE, audio_capture, RMAudioCapturePropertyID_DRAMSize, &capture_dram_in, sizeof(capture_dram_in), &capture_dram_out, sizeof(capture_dram_out));

	// Creation of the audio capture profile

	capture_profile.CaptureMode = 0; // File mode
	capture_profile.Delay=0;
	capture_profile.SI_CONF=0x107 | (1 << 3);
	capture_profile.SerialInFIFOSize = capture_dram_in.SerialInFIFOSize;
	capture_profile.XferFIFOCount = capture_dram_in.XferFIFOCount;
	capture_profile.CachedSize = capture_dram_out.CachedSize;
	
	if (capture_profile.CachedSize > 0){
		in.dramtype=RUA_DRAM_CACHED;
		in.Size=capture_profile.CachedSize;
		
		EM8XXXSNDEXP(pE,
			     EMHWLIB_MODULE(MM,audio_mmID),
			     RMMMPropertyID_Malloc,
			     &in,sizeof(in),
			     &out,sizeof(out));
		if(err==RM_OK) 
			capture_profile.CachedAddress= (RMuint32)out.Address;
		else {
			RMDBGLOG((ENABLE," memory manager not existent\n"));
			return 0;
		}
	
		printk("audio capture cached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
		       capture_profile.CachedAddress,
		       capture_profile.CachedSize,
		       capture_profile.CachedAddress + capture_profile.CachedSize);
	}
	else { capture_profile.CachedAddress = 0; }
	
	pS->SerialinProfileCachedAddr = capture_profile.CachedAddress;
	
	capture_profile.UncachedSize = capture_dram_out.UncachedSize;
	if (capture_profile.UncachedSize > 0){
		in.dramtype=RUA_DRAM_UNCACHED;
		in.Size=capture_profile.UncachedSize;
		
	
		EM8XXXSNDEXP(pE,
			     EMHWLIB_MODULE(MM,audio_mmID),
			     RMMMPropertyID_Malloc,
			     &in,sizeof(in),
			     &out,sizeof(out));
		if(err==RM_OK) 
			capture_profile.UncachedAddress = (RMuint32)out.Address;
		else {
			RMDBGLOG((ENABLE," memory manager not existent\n"));
			return 0;
		}
	
		printk("audio capture uncached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
		       capture_profile.UncachedAddress,
		       capture_profile.UncachedSize,
		       capture_profile.UncachedAddress + capture_profile.UncachedSize);
	}
	else { capture_profile.UncachedAddress = 0; }

	pS->SerialinProfileUncachedAddr = capture_profile.UncachedAddress;
	EM8XXXSNDSP(pE, audio_capture, RMAudioCapturePropertyID_Open, &capture_profile, sizeof(capture_profile));

	// Shared memory allocation

	info_in.Reserved1 = 0;
	info_in.Reserved2 = 0;
	EM8XXXSNDEXP(pE, audio_engine, RMAudioEnginePropertyID_DecoderSharedMemoryInfo, &info_in, sizeof(info_in), &info_out, sizeof(info_out));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting property RMAudioDecoderPropertyID_DecoderDataMemory!\n"));
		return err;
	}

	/* check if audio shared memory is already set in audio engine */
	EM8XXXSNDGP(pE, audio_engine, RMAudioEnginePropertyID_DecoderSharedMemory, &shared, sizeof(shared));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get DecoderSharedMemory\n"));
		return err;
	}
	if (shared.Address) {
		printk("=================%lx_DRAM AUDIO SHARED MEMORY is already set addr=0x%lx size=0x%lx\n",
			audio_engine, shared.Address, shared.Size);
	}
	else {
		/* allocate and set the shared memory used by all decoders of the same engine */
		shared.Size = info_out.DecoderSharedSize;
		if (shared.Size) {
			in.dramtype=RUA_DRAM_CACHED;
			in.Size=shared.Size;

			EM8XXXSNDEXP(pE, EMHWLIB_MODULE(MM,audio_mmID), 
			     RMMMPropertyID_Malloc,
			     &in,sizeof(in),
			     &out,sizeof(out));
			
			if(err == RM_OK)
				shared.Address = (RMuint32)out.Address;
			else {
				shared.Address = 0;
				RMDBGLOG((ENABLE, "ERROR: could not allocate shared 0x%08lX bytes in DRAM %lu!\n", shared.Address, 0L));
				return RM_FATALOUTOFMEMORY;
			}

			RMDBGPRINT((ENABLE, "===============ALLOCATING %lx_DRAM AUDIO SHARED MEMORY addr: 0x%08lX, size 0x%08lX\n", audio_engine, shared.Address, shared.Size));

			EM8XXXSNDSP(pE, audio_engine, RMAudioEnginePropertyID_DecoderSharedMemory, &shared, sizeof(shared));
		}
	}

	// Get the information for DRAM parameters for AudioDecoder Module
	
	dram_in.MaxChannelOutCount = MAXCHANNELOUTCOUNT;
	dram_in.PCMLineCount = PCMLINECOUNT;
	dram_in.BitstreamFIFOSize = (1 << AUDIO_DMA_BUFFER_SIZE_LOG2) * AUDIO_DMA_BUFFER_COUNT; // DMA total buffer size
	dram_in.XferFIFOCount = AUDIO_DMA_BUFFER_COUNT;
	dram_in.ProtectedFlags = 0;
	dram_in.PtsFIFOCount = 30*60;
	dram_in.InbandFIFOCount = 128;
	dram_in.XtaskInbandFIFOCount = 0;

	// Memory allocation for AudioDecoder Module

	EM8XXXSNDEXP(pE, audio_decoder, RMAudioDecoderPropertyID_DRAMSizeX, &dram_in, sizeof(dram_in), &dram_out, sizeof(dram_out));
	
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "No memory available for Audio RISC Processor! \n"));
		return err;
	}
	
	// Creation of the audio profile
	profile.ProtectedFlags = 0; /*All memory is unprotected*/
	profile.MaxChannelOutCount = dram_in.MaxChannelOutCount;
	profile.PtsFIFOCount = dram_in.PtsFIFOCount;//PTS_FIFO_COUNT;
	profile.InbandFIFOCount = dram_in.InbandFIFOCount;//INBAND_FIFO_COUNT;
	profile.PCMLineCount = dram_in.PCMLineCount;
	profile.BitstreamFIFOSize = dram_in.BitstreamFIFOSize;
	profile.XferFIFOCount = dram_in.XferFIFOCount;
	profile.XtaskInbandFIFOCount = 0;
	profile.XtaskId = 0;
	profile.OutputSamplesProtectedAddress = 0;
	profile.OutputSamplesProtectedSize = 0;
	profile.BitstreamProtectedAddress = 0;
	profile.BitstreamProtectedSize = 0;

	pS->AudioProfileCachedAddr = 0;

	profile.UnprotectedSize = dram_out.UnprotectedSize;
	if (profile.UnprotectedSize > 0){
		in.dramtype=RUA_DRAM_UNCACHED;
		in.Size = profile.UnprotectedSize;
	
		EM8XXXSNDEXP(pE,
			     EMHWLIB_MODULE(MM,audio_mmID),
			     RMMMPropertyID_Malloc,
			     &in,sizeof(in),
			     &out,sizeof(out));
		if(err==RM_OK)
			profile.UnprotectedAddress = (RMuint32)out.Address;
		else {
			RMDBGLOG((ENABLE," memory manager not existent\n"));
			return 0;
		}
	
		printk("audio uncached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
		       profile.UnprotectedAddress,
		       profile.UnprotectedSize,
		       profile.UnprotectedAddress + profile.UnprotectedSize);
	}
	else { profile.UnprotectedAddress = 0; }

	pS->AudioProfileUncachedAddr = profile.UnprotectedAddress;
	profile.STCId = audio_decoder_index;
	
	EM8XXXSNDSP(pE, audio_decoder, RMAudioDecoderPropertyID_OpenX, &profile, sizeof(profile));

	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error while creating audio profile! \n"));
		return err;
	}

	// starting the Audio RISC 
	run = CPU_RUNNING;

	EM8XXXSNDSP(pE, audio_engine, RMAudioEnginePropertyID_State, &run, sizeof(run));

	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error while starting CPU! \n"));
		return err;
	}
	
	pS->capture_enable = FALSE;
	pS->playback_enable = FALSE;

	return RM_OK;  
}

static int rm_free_ptr(struct em8xxxprivate *pE,RMuint32 ptr)
{
	RMuint32 dramIndex=0xffffffff;
	RMstatus err;
	
	if ((MEM_BASE_dram_controller_0<=ptr)&&(ptr<MEM_BASE_dram_controller_1)) dramIndex=0;
	if ((MEM_BASE_dram_controller_1<=ptr)&&(ptr<MEM_BASE_dram_controller_1+(512*1024*1024))) dramIndex=1;

	RMDBGLOG((ENABLE,"Trying to free %08lx with memory manager %d \n",ptr,dramIndex));
	if (dramIndex<=1) {
		EM8XXXSNDSP(pE,
			    EMHWLIB_MODULE(MM,0),
			    RMMMPropertyID_Free,
			    (void *)(&ptr),sizeof(void *));
		if(err!=RM_OK) 
			RMDBGLOG((ENABLE,"rm_ptr_free: pointer 0x%08lx cannot be freed\n",ptr));
	}
	else
		RMDBGLOG((ENABLE,"rm_ptr_free: pointer %p not in a dram controller\n",ptr));
	
	return 0;
}

static int rm_release_dsp(struct inode *inode, struct file *file)
{
	struct sndprivate *pS=(struct sndprivate *)file->private_data;
	struct em8xxxprivate *pE;
	RMstatus err;
	enum AudioCapture_Capture_type cmd;
	RMuint32 audio_capture = EMHWLIB_MODULE(AudioCapture,audio_capture_index);
	enum AudioDecoder_Command_type command;
	RMuint32 bus_addr;

	printk("closes em8xxx sound device (/dev/dsp%d)\n", pS->dsp_dev);
	pE=Etable+(pS-Stable);
	pS->format = 0;
	pS->sample_rate = 0;
	pS->channel_count = 0;
	pS->i_start=0;
	pS->j_start=0;
	pS->last_i=0;
	pS->last_j=0;
	pS->capture_readable=0;
	pS->capture_buffer_size=0;
	pS->capture_read=0;
	pS->capture_enable = FALSE;
	pS->playback_enable = FALSE;
	pS->state=0;
	

	//	send off command to audio capture
	cmd = AudioCapture_Capture_Off;
	EM8XXXSNDSP(pE, audio_capture,RMAudioCapturePropertyID_Capture, &cmd, sizeof(cmd));
	prepare_data(pS);
	
	command = AudioDecoder_Command_Stop;
	EM8XXXSNDSP(pE,EMHWLIB_MODULE(AudioDecoder,audio_decoder_index), RMAudioDecoderPropertyID_Command, &command, sizeof(command));

	krua_unregister_event_callback(pE,EMHWLIB_MODULE(AudioCapture,audio_capture_index),event_callback);
	tasklet_kill(&pS->event_tq);
	
	if(pS->pBuf != NULL){
		// release buffer
		
		bus_addr = kdmapool_get_bus_address(pE->pllad,pS->dmapool_id,pS->pBuf,0);
		kdmapool_release(pE->pllad,pS->dmapool_id,bus_addr);
	}
	// close dma pool
	
	kdmapool_close(pE->pllad,pS->dmapool_id);

	cleanup_audio(pS);
	pS->dsp_open_count --;

	return 0;
}

static ssize_t rm_read_dsp(struct file *file, char *buffer, size_t count, loff_t *ppos){
	RMstatus rc,err;
	RMuint32 audio_capture = EMHWLIB_MODULE(AudioCapture,audio_capture_index);
	struct em8xxx_data param;
	void *context;
	RMuint8 info[INFO_SIZE];
	RMuint32 infoSize = INFO_SIZE;
	size_t to_read;
	struct sndprivate *pS=(struct sndprivate *)file->private_data;
	struct em8xxxprivate *pE=Etable+(pS-Stable);
	RMuint32 samples;
	RMint32 i,j;
	printk("rm_read_dsp \n");
	samples = bytes_to_samples(pS,count);
	to_read = samples * 6; // in the microcode we capture in 24 bits, 2 channels.


	if(!pS->capture_enable){
		rc=start_capture(pE);

		if(RMFAILED(rc)){
			printk("error while starting capture \n");
			return -EINVAL;
		}
	}
	

	while(1){
		
		RMuint32 it=0;
		
		if(pS->capture_pBuf == NULL){
			
			// Receive buffer
			printk("receive buffer \n");
			param.moduleId = audio_capture;
			param.poolId = pS->capture_dmapool_id;
			param.infoSize = infoSize;

			err=RM_INSUFFICIENT_SIZE;
			while(err==RM_INSUFFICIENT_SIZE){
				it ++;
				if(it >= 10){
					printk("forced to quit loop \n");
					return -EINVAL;
				}

				kc_spin_lock_bh(pE->lock);	      
				err=EMhwlibReceiveBuffer(pE->pemhwlib, param.moduleId, &(param.bus_addr), &(param.dataSize), info, &(param.infoSize), &context);
				kc_spin_unlock_bh(pE->lock);	      
				if((err != RM_OK) && (err != RM_INSUFFICIENT_SIZE)){
					printk("fatal arror while receiving buffer. abort, err = %d \n",err);
					return -EINVAL;
				}
				
				if(err == RM_INSUFFICIENT_SIZE){
					rc=kc_interruptible_sleep_on_timeout(pS->sq,US_TO_JIFFIES(RECEIVEDATA_TIMEOUT_US));
					if (kc_signal_pending_current()){
						return -EINVAL;
					}
				}
			}
			
			pS->capture_buffer_bus_addr = param.bus_addr;
			pS->capture_pBuf=kdmapool_get_virt_address(pE->pllad,pS->capture_dmapool_id,pS->capture_buffer_bus_addr, 0);
			pS->capture_buffer_size = param.dataSize;
			pS->capture_readable = param.dataSize;
			pS->capture_read=0;
			pS->i_start = 0;
		}
		
		else {
			pS->i_start = pS->last_i;
		}
		
		pS->j_start = pS->last_j;
		
		i=pS->i_start;
		j=pS->j_start;
		printk("i = %ld , j = %ld \n, nb_bits_per_sample = %d, channel_count = %d \n",i,j,pS->nb_bits_per_sample,pS->channel_count);
		while (j<count){
			
			if(i>=pS->capture_buffer_size){
				break;
			}
			
			switch(pS->state){
			case 0:
				if(pS->nb_bits_per_sample==8)
					buffer[j]=pS->capture_pBuf[i]+128;
				else
					buffer[j]=pS->capture_pBuf[i];
				j++;
				break;
		
			case 1:
				if(pS->nb_bits_per_sample==16){
					buffer[j]=pS->capture_pBuf[i];
					j++;
				}
				break;
			default:
				break;
			}
			
			i++;	
			pS->state ++;
			
			if(pS->channel_count==1)
				pS->state %= 6;
			else
				pS->state %= 3;
		}
		
		
		pS->last_i = i;
		pS->last_j = j;
		
		if (i >= pS->capture_buffer_size){
			
		 	/* Release buffer */
			printk("release buffer \n");
			if(pS->capture_pBuf != NULL){
				kdmapool_release(pE->pllad,pS->capture_dmapool_id,pS->capture_buffer_bus_addr);
				pS->capture_pBuf = NULL;
				prepare_data(pS);
			}
		}

		if (j == count){
			pS->last_j = 0;
			break;
		}
		
	}
 	if(pS->nb_bits_per_sample==16){
 		// byte-swap
 		RMuint32 l;
 		RMint8 temp;
 		for (l=0;l<count;l+=2){
 			temp = buffer[l];
 			buffer[l] = buffer[l+1];
 			buffer[l+1] = temp;
 		}
	}
	return count;
}

static ssize_t rm_write_dsp(struct file *file, const char *buffer, size_t count, loff_t *ppos){
	
	struct emhwlib_info Info;
	struct emhwlib_info *pInfo = &Info;
	struct em8xxx_data param;
	int rc;
	RMuint32 Info_size;
	RMuint32 time_resolution;
	RMuint64 time;
	struct sndprivate *pS=(struct sndprivate *)file->private_data;
	struct em8xxxprivate *pE;
	RMstatus err;
	void * context;
	long timeout;
	RMuint32 it=0,timeout_buffer = 0;
	size_t length = count;
	size_t played_size=0;

	pE=Etable+(pS-Stable);

	if(!pS->playback_enable){
		rc=start_playback(pE);

		if(RMFAILED(rc)){
			printk("error while starting playback \n");
			return -EINVAL;
		}
	}

	while (length > 0) {
		size_t chunk_size;

		if (pS->pBuf==NULL){
			timeout=0;
			while (timeout < 1000000) {

				pS->pBuf=kdmapool_getbuffer(pE->pllad,pS->dmapool_id,&timeout_buffer);

				if (pS->pBuf)
					break;
				timeout += kc_interruptible_sleep_on_timeout(pE->wq,US_TO_JIFFIES(10000));
				if (signal_pending(current)) {
					rc=-ERESTARTSYS;
					break;
				}
			}
		}

		if (length > (1 << AUDIO_DMA_BUFFER_SIZE_LOG2))
			chunk_size = (1 << AUDIO_DMA_BUFFER_SIZE_LOG2);
		else
			chunk_size = length;

		kc_logging_copy_from_user(pS->pBuf,buffer+played_size,chunk_size);

		if (pS->firstPTS) {
			pS->firstPTS = FALSE;
			Info.ValidFields = TIME_STAMP_INFO;
			EM8XXXSNDGP(pE,EMHWLIB_MODULE(STC,audio_decoder_index),RMSTCPropertyID_AudioTimeResolution,&time_resolution,sizeof(time_resolution));
			EM8XXXSNDEXP(pE, EMHWLIB_MODULE(STC,audio_decoder_index),RMSTCPropertyID_TimeInfo,&time_resolution,sizeof(time_resolution),&time,sizeof(time));
			
			Info.TimeStamp = time;
			pInfo = &Info;
			Info_size = sizeof(Info);
		}
		else {
			pInfo = NULL;
			Info_size = 0;
		}

		param.moduleId = EMHWLIB_MODULE(AudioDecoder,audio_decoder_index);
		param.poolId = pS->dmapool_id;
		param.dataSize = chunk_size;
		param.bus_addr = kdmapool_get_bus_address(pE->pllad,pS->dmapool_id,pS->pBuf,chunk_size);
		kc_flush_cache((void *)param.bus_addr,chunk_size);

		context =(void *) (((pE-Etable) << 16) + param.poolId + 1);

		err=RM_INSUFFICIENT_SIZE;
		while(err==RM_INSUFFICIENT_SIZE){
			it ++;
			if(it >= 1000){
				printk("forced to quit loop \n");
				return -EINVAL;
			}
		
			kc_spin_lock_bh(pE->lock);
			err = EMhwlibSendBuffer(pE->pemhwlib, param.moduleId, param.bus_addr, param.dataSize, pInfo, Info_size, context);
			kc_spin_unlock_bh(pE->lock);

			if((err != RM_OK) && (err != RM_INSUFFICIENT_SIZE)){
				printk("fatal error while receiving buffer. abort, err = %d \n",err);
				return -EINVAL;
			}
			
		}
		
		timeout=0;
		while (timeout < 1000000) {
			pS->pBuf=kdmapool_getbuffer(pE->pllad,pS->dmapool_id,&timeout_buffer);

			if (pS->pBuf)
				break;
			timeout += kc_interruptible_sleep_on_timeout(pE->wq,US_TO_JIFFIES(10000));
			if (signal_pending(current)) {
				rc=-ERESTARTSYS;
				break;
			}
		}

		length -= chunk_size;
		played_size += chunk_size;

	}

	return count;
}

static unsigned int rm_poll_dsp(struct file *file, struct poll_table_struct *wait){return 0;}
static int rm_mmap_dsp(struct file *file, struct vm_area_struct *vma){return 0;}

static int rm_ioctl_dsp(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg)
{
	struct sndprivate *pS=(struct sndprivate *)file->private_data;
	int rc;
	
	rc = process_ioctl_dsp(pS, cmd, arg);

	return rc;
	
}
static RMstatus start_capture(struct em8xxxprivate *pE)
{
	enum AudioCapture_Capture_type cmd;
	struct sndprivate *pS = Stable + (pE-Etable);
	RMstatus err;
	RMuint32 audio_capture = EMHWLIB_MODULE(AudioCapture,audio_capture_index);

	printk("start capture \n");
	
	//  Enabling audio capture
	cmd = AudioCapture_Capture_On;
	EM8XXXSNDSP(pE, audio_capture,RMAudioCapturePropertyID_Capture, &cmd, sizeof(cmd));

	pS->capture_enable = TRUE;

	return err;
}

static RMstatus start_playback(struct em8xxxprivate *pE)
{
	struct sndprivate *pS = Stable + (pE-Etable);
	enum AudioDecoder_Command_type command;
	RMuint32 audio_decoder = EMHWLIB_MODULE(AudioDecoder,audio_decoder_index);
	RMstatus err=RM_OK;
	enum AudioDecoder_State_type state;
	int rc;
  	long timeout;
	long timeout_jiffies = (unsigned long long) 100000*(unsigned long long)HZ/1000000ULL; //10^-1 sec
/* 	RMuint32 pts_delay = PTS_FIRST_DELAY; */
	RMuint32 AudioBtsThreshold=AUDIO_BTS_THRESHOLD;

	EM8XXXSNDSP(pE,audio_decoder, RMAudioDecoderPropertyID_AudioBtsThreshold, &AudioBtsThreshold,sizeof(RMuint32));

	// Change the decoder status to Play Mode
	
	command = AudioDecoder_Command_Play;

	EM8XXXSNDSP(pE, audio_decoder, RMAudioDecoderPropertyID_Command, &command, sizeof(command));

	if (RMFAILED(err)){
		RMDBGLOG((ENABLE, "Error while sending Play command to Audio Decoder! \n"));
		return err;
	}
	else printk("play command sended to the audio decoder \n");
	timeout=0;
	while (timeout < 100000) {
		EM8XXXSNDGP(pE, audio_decoder,RMAudioDecoderPropertyID_State, &state, sizeof(state));
		if (state == AudioDecoder_State_Playing)
			break;
		timeout += kc_interruptible_sleep_on_timeout(pE->wq,timeout_jiffies);
		if (signal_pending(current)) {
			rc=-ERESTARTSYS;
			break;
		}
	}
	
	pS->playback_enable = TRUE;
	return err;
}

#if 0
static RMstatus set_audio_parameters(struct em8xxxprivate *pE, int format, int sampleRate, int channelCount)
{
	int rc;
       	long timeout;
	long timeout_jiffies = (unsigned long long) 100000*(unsigned long long)HZ/1000000ULL; //10^-1 sec
	enum AudioDecoder_Command_type command;
	enum AudioDecoder_State_type state;
	enum AudioDecoder_Codec_type codec;
	RMuint32 audio_decoder = EMHWLIB_MODULE(AudioDecoder,audio_decoder_index);
	RMuint32 audio_engine = EMHWLIB_MODULE(AudioEngine,audio_engine_index);
	struct sndprivate *pS=Stable+(pE-Etable);
	enum AudioEngine_SerialOut_type serialOutStatus;
	struct AudioEngine_SampleFrequencyFromSource_type sf;
	struct AudioEngine_I2SConfig_type i2s;
	enum AudioEngine_SpdifOut_type spdif_out;
	RMstatus err;
	struct AudioDecoder_PcmCdaParameters_type pcm_parameters;
	struct AudioEngine_Volume_type volume;
	int i,closed;
	struct AudioDecoder_AudioPlayTime_type play_time;
	struct AudioDecoder_MixerWeight_type cmdblock;

	if ((!format) || (!sampleRate) || (!channelCount))
		return 0;
	
	pS->capture_enable = FALSE;
	
	// Volume Initialization
	for (i = 0; i <= 9; i++){
		volume.Channel = i;
		volume.Volume = 0x10000000;
	
		EM8XXXSNDSP(pE, audio_engine, RMAudioEnginePropertyID_Volume, &volume, sizeof(volume));
	
		if (RMFAILED(err)){
			RMDBGLOG((ENABLE, "Error while setting audio volume! \n"));
			return err;
		}
	}
	
	pS->volume = 70 + (70<<8);
	// Mixer weight initialization

	cmdblock.MixerValue_ch0=0x10000000;
	cmdblock.MixerValue_ch1=0x10000000;
	cmdblock.MixerValue_ch2=0x10000000;
	cmdblock.MixerValue_ch3=0x10000000;
	cmdblock.MixerValue_ch4=0x10000000;
	cmdblock.MixerValue_ch5=0x10000000;
	cmdblock.MixerValue_ch6=0x10000000;
	cmdblock.MixerValue_ch7=0x10000000;
	
	EM8XXXSNDSP( pE, audio_decoder,RMAudioDecoderPropertyID_MixerWeight,&cmdblock,sizeof(cmdblock));
	
	
	pS->weight = 70 + (70<<8);

	// We have to know if the other decoder is working

	closed=1;

#ifdef RMFEATURE_HAS_AUDIO_ENGINE_1
	switch(audio_engine_index){
	case 0:
		state = 0;
		EM8XXXSNDGP(pE,EMHWLIB_MODULE(AudioDecoder,1-audio_decoder_index),RMAudioDecoderPropertyID_State,&state,sizeof(state));
		if (state != AudioDecoder_State_Closed) closed=0;
		break;
	case 1:
		if (audio_decoder_index==2){
			EM8XXXSNDGP(pE,EMHWLIB_MODULE(AudioDecoder,3),RMAudioDecoderPropertyID_State,&state,sizeof(state));
		}
		else
			EM8XXXSNDGP(pE,EMHWLIB_MODULE(AudioDecoder,2),RMAudioDecoderPropertyID_State,&state,sizeof(state));
		if (state != AudioDecoder_State_Closed) closed=0;
		break;
	}
	
#else
	EM8XXXSNDGP(pE,EMHWLIB_MODULE(AudioDecoder,1-audio_decoder_index),RMAudioDecoderPropertyID_State,&state,sizeof(state));
	if (state != AudioDecoder_State_Closed) closed=0;
	
#endif // RMFEATURE_HAS_AUDIO_ENGINE_1		
	
	if(closed==1){
		// Setting the sample freqency
		EM8XXXSNDSP(pE, audio_engine, RMAudioEnginePropertyID_SampleFrequency, &sampleRate, sizeof(sampleRate));

		if (RMFAILED(err)){
			printk("Error while setting the sample frequency\n");
			return err;
		}

		// Applying AudioEngine Module Options
		spdif_out = AudioEngine_SpdifOut_Active;
		
		EM8XXXSNDSP(pE, audio_engine, RMAudioEnginePropertyID_SpdifOut, &spdif_out, sizeof(spdif_out));
		
		if (RMFAILED (err)) {
			RMDBGLOG((ENABLE, "Error setting spdif_out property! \n"));
			return err;
		}
		
		
		sf.GeneratorNumber = 3;
		sf.SampleFrequency = sampleRate;
		sf.Source = 1;
		sf.SourceFrequency = 27000000;
		sf.IntermediateFrequency = 148500000;
		
		EM8XXXSNDSP(pE, audio_engine, RMAudioEnginePropertyID_SampleFrequencyFromSource, &sf, sizeof(sf));
		
		if (RMFAILED (err)) {
			RMDBGLOG((ENABLE, "Error setting sf property! \n"));
			return err;
		}
		
		i2s.DataAlignment = 1;
		i2s.SClkInvert = TRUE;
		i2s.FrameInvert = TRUE;
		i2s.MSBFirst = TRUE;
		i2s.SampleSize16Bit = FALSE;
		
		EM8XXXSNDSP(pE, audio_engine, RMAudioEnginePropertyID_I2SConfig, &i2s, sizeof(i2s));
		
		if (RMFAILED (err)) {
			RMDBGLOG((ENABLE, "Error setting i2s property! \n"));
			return err;
		}
		
		
		serialOutStatus = AudioEngine_SerialOut_SO_ENABLE;
		
		EM8XXXSNDSP(pE, audio_engine, RMAudioEnginePropertyID_SerialOut, &serialOutStatus, sizeof(serialOutStatus));
		
		if (RMFAILED (err)) {
			RMDBGLOG((ENABLE, "Error setting serialOut property! \n"));
			return err;
		}
	}	
	codec = pS->format;

	//   Uninit
	timeout = 0;
	command = AudioDecoder_Command_Uninit;

	EM8XXXSNDSP(pE,audio_decoder,RMAudioDecoderPropertyID_Command,&command,sizeof(command));

	if (RMFAILED(err)){
		RMDBGLOG((ENABLE, "Unable to Uninit \n"));
		return err;
	}
	while (timeout < 1000000) {
		
		EM8XXXSNDGP(pE, audio_decoder,RMAudioDecoderPropertyID_State, &state, sizeof(state));
		
		if (state == AudioDecoder_State_Uninitialized)
			break;
		timeout += kc_interruptible_sleep_on_timeout(pE->wq,timeout_jiffies);
		if (signal_pending(current)) {
			rc=-ERESTARTSYS;
			break;
		}
	}
	if (timeout >= 1000000) {
		RMDBGLOG((ENABLE, "Error setting uninit state! \n"));
		return -EINVAL;
	}

	//  Format

	EM8XXXSNDSP(pE, audio_decoder, RMAudioDecoderPropertyID_Codec, &codec, sizeof(codec));

	if (RMFAILED(err)){
		RMDBGLOG((ENABLE, "Error setting codec property! \n"));
		return err;
	}

	// PCM Parameters
	
	switch(channelCount) {
	case 1:
		pcm_parameters.ChannelAssign = PcmCda1_C;
		break;
	case 2:
		pcm_parameters.ChannelAssign = PcmCda2_LR;
		break;
	default:
		pcm_parameters.ChannelAssign = PcmCda2_LR;
		break;
	}
	pcm_parameters.BitsPerSample = pS->nb_bits_per_sample;
	pcm_parameters.SamplingFrequency = sampleRate;
	pcm_parameters.MsbFirst = pS->MSBFirst;
	pcm_parameters.OutputDualMode = DualMode_Stereo;
	pcm_parameters.OutputSpdif = OutputSpdif_Disable;
	pcm_parameters.OutputChannels = Audio_Out_Ch_LR;
	pcm_parameters.OutputLfe = FALSE;
	pcm_parameters.SignedPCM = (pS->nb_bits_per_sample==16) ? TRUE : FALSE;
	pcm_parameters.BassMode = 0;


	EM8XXXSNDSP(pE, audio_decoder, RMAudioDecoderPropertyID_PcmCdaParameters, &pcm_parameters, sizeof(pcm_parameters));

	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error setting pcm parameters! \n"));
	}
	
	play_time.PlayMode = 0;
	play_time.PlayStartPTS = 0;
	play_time.PlayEndPTS = 0;
	EM8XXXSNDSP(pE, audio_decoder, RMAudioDecoderPropertyID_AudioPlayTime, &play_time, sizeof(play_time));
	if (RMFAILED(err)){
		printk("Error while setting the play time\n");
		return err;
	}

	EM8XXXSNDGP(pE, audio_engine, RMAudioEnginePropertyID_SampleFrequency, &sampleRate, sizeof(sampleRate));
	if (RMFAILED(err)){
		printk("Error while getting the sample frequency\n");
		return err;
	}

	//Init

	command = AudioDecoder_Command_Init;

	EM8XXXSNDSP(pE, audio_decoder, RMAudioDecoderPropertyID_Command, &command, sizeof(command));

	if (RMFAILED(err)){
		RMDBGLOG((ENABLE, "Error while initializing audio decoder! \n"));
		return err;
	}
	timeout =0;
	while (timeout < 1000000) {
		static RMuint32 count = 0;
	
		EM8XXXSNDGP(pE, audio_decoder,RMAudioDecoderPropertyID_State, &state, sizeof(state));
		if (state == AudioDecoder_State_Stopped)
			break;
		kc_interruptible_sleep_on_timeout(pE->wq,US_TO_JIFFIES(10000));
		timeout += 10000;
		count ++;
		printk("count : %lu, timeout = %ld\n", count, timeout);
		if (signal_pending(current)) {
			rc=-ERESTARTSYS;
			break;
		}
	}
	if (timeout >= 1000000) {
		RMDBGLOG((ENABLE, "Error setting init state! \n"));
		return -EINVAL;
	}

/* 	start_playback(pE); */

       		
	printk("audio parameters are set : samplerate = %d, nb_bits_per_sample = %d, channelcount = %d\n", sampleRate,pS->nb_bits_per_sample, channelCount);
	
	return err;
}
#endif

static int process_ioctl_dsp(struct sndprivate *pS, unsigned int cmd, unsigned long arg)
{
	struct em8xxxprivate *pE=Etable+(pS-Stable);
	int val, rc,closed;
	audio_buf_info abinfo;
	long timeout;
	RMuint32 audio_decoder = EMHWLIB_MODULE(AudioDecoder,audio_decoder_index);
	RMuint32 audio_engine = EMHWLIB_MODULE(AudioEngine,audio_engine_index);
	struct DataFIFOInfo data_info;
	RMstatus err;
	RMbool enablesync=0; // Disable AV Sync from SNDCTL_DSP_GETBLKSIZE
	enum AudioDecoder_State_type state;

	rc = 0;
	
	switch (cmd) {
	case OSS_GETVERSION:
		printk("OSS_GETVERSION\n");
		val = SOUND_VERSION;
		rc = kc_logging_copy_to_user((int *) arg, &val, sizeof(int));
		break;

	case SNDCTL_DSP_SYNC:
		printk("SND_DSP_SYNC\n");
		timeout = 0;
		rc = 0;
		while (timeout < 1000000) {// 1 sec
			EM8XXXSNDGP(pE, audio_decoder,RMGenericPropertyID_DataFIFOInfo, &data_info, sizeof(data_info));
			val = (int) data_info.Readable % data_info.Size;
			if (val == 0)
				break;
			timeout += 10000;
			if (signal_pending(current)) {
				rc=-ERESTARTSYS;
				break;
			}
		}
		break;
		
	case SNDCTL_DSP_SETDUPLEX:
		printk("SND_DSP_SETDUPLEX\n");
		rc = 0;
		break;

	case SNDCTL_DSP_GETCAPS:
		printk("SND_DSP_GETCAPS\n");
		val = DSP_CAP_DUPLEX;
		rc = kc_logging_copy_to_user((int *) arg, &val, sizeof(int));
		break;
		
        case SNDCTL_DSP_RESET:
		printk("SND_DSP_RESET\n");
		break;
        case SNDCTL_DSP_SPEED:
                rc = kc_logging_copy_from_user(&val, (int *) arg, sizeof(int));
		if (rc != 0)
			break;

		printk("SND_DSP_SPEED %d\n", val);
		
		pS->sample_rate = val;
		closed=1;

#ifdef RMFEATURE_HAS_AUDIO_ENGINE_1
		switch(audio_engine_index){
		case 0:
			EM8XXXSNDGP(pE,EMHWLIB_MODULE(AudioDecoder,1-audio_decoder_index),RMAudioDecoderPropertyID_State,&state,sizeof(state));
			if (state != AudioDecoder_State_Closed) closed=0;
			break;
		case 1:
			if (audio_decoder_index==2){
				EM8XXXSNDGP(pE,EMHWLIB_MODULE(AudioDecoder,3),RMAudioDecoderPropertyID_State,&state,sizeof(state));
			}
			else
				EM8XXXSNDGP(pE,EMHWLIB_MODULE(AudioDecoder,2),RMAudioDecoderPropertyID_State,&state,sizeof(state));
			if (state != AudioDecoder_State_Closed) closed=0;
			break;
		}
	
#else
		EM8XXXSNDGP(pE,EMHWLIB_MODULE(AudioDecoder,1-audio_decoder_index),RMAudioDecoderPropertyID_State,&state,sizeof(state));
		if (state != AudioDecoder_State_Closed) closed=0;
	
#endif // RMFEATURE_HAS_AUDIO_ENGINE_1		
	
		if(closed==1){
			EM8XXXSNDSP(pE, audio_engine, RMAudioEnginePropertyID_SampleFrequency, &val, sizeof(val));
			if (RMFAILED(err)){
				printk("Error while setting the sample frequency\n");
				return err;
			}
		}
		else{
			RMDBGLOG((ENABLE,"Impossible to change sample rate because the other decoder is in use\n"));
		}

		rc = kc_logging_copy_to_user((int *) arg, &val, sizeof(int));
		break;
		
        case SNDCTL_DSP_STEREO:
		printk("SND_DSP_STEREO\n");
                rc = kc_logging_copy_from_user(&val, (int *) arg, sizeof(int));
		if (rc != 0)
			break;
		
		pS->channel_count = (val) ? 2 : 1;

		break;

        case SNDCTL_DSP_CHANNELS:
                rc = kc_logging_copy_from_user(&val, (int *) arg, sizeof(int));
		if (rc != 0)
			break;

		printk("SND_DSP_CHANNELS %d\n", val);
		
		if ((val == 1) || (val == 2)) {
			pS->channel_count = val;
			rc = 0;
			break;
		}
		else {
			rc = -EINVAL;
		}
		break;
		
	case SNDCTL_DSP_GETFMTS: 
		printk("SND_DSP_GETFMTS\n");
		/* this should be only AFMT_S16_BE. But some applications
		   don't use this flag correctly */
		val = AFMT_S16_BE | AFMT_S16_LE | AFMT_U8;
		rc = kc_logging_copy_to_user((int *) arg, &val, sizeof(int));
		break;
		
	case SNDCTL_DSP_SETFMT: 
                rc = kc_logging_copy_from_user(&val, (int *) arg, sizeof(int));
		if (rc != 0)
			break;

		printk("SND_DSP_SETFMT %d\n", val);

		switch (val) {
		case AFMT_S16_LE:
			pS->format = AudioDecoder_Codec_PCM;
			pS->nb_bits_per_sample = 16;
			pS->MSBFirst = FALSE;
			break;
		case AFMT_S16_BE:
			pS->format = AudioDecoder_Codec_PCM;
			pS->nb_bits_per_sample = 16;
			pS->MSBFirst = TRUE;
			break;
		case AFMT_U8:
			pS->format = AudioDecoder_Codec_PCM;
			pS->nb_bits_per_sample = 8;
			break;
		case AFMT_QUERY:
			val = (pS->format == AudioDecoder_Codec_PCM) ? AFMT_S16_BE : AFMT_S16_LE;
			break;
		default:
			pS->format = AudioDecoder_Codec_PCM;
			val = AFMT_S16_LE;
			pS->nb_bits_per_sample = 16;
			pS->MSBFirst = FALSE;
			break;
		}

		{
		//   Uninit
		long timeout = 0;
		enum AudioDecoder_Command_type command = AudioDecoder_Command_Uninit;
		enum AudioDecoder_Codec_type codec = pS->format;
		struct AudioDecoder_PcmCdaParameters_type pcm_parameters;
		long timeout_jiffies = (unsigned long long) 100000*(unsigned long long)HZ/1000000ULL; //10^-1 sec

		EM8XXXSNDSP(pE,audio_decoder,RMAudioDecoderPropertyID_Command,&command,sizeof(command));

		if (RMFAILED(err)){
			RMDBGLOG((ENABLE, "Unable to Uninit \n"));
			return err;
		}
		while (timeout < 1000000) {
		
			EM8XXXSNDGP(pE, audio_decoder,RMAudioDecoderPropertyID_State, &state, sizeof(state));
		
			if (state == AudioDecoder_State_Uninitialized)
				break;
			timeout += kc_interruptible_sleep_on_timeout(pE->wq,timeout_jiffies);
			if (signal_pending(current)) {
				rc=-ERESTARTSYS;
				break;
		}
		}
		if (timeout >= 1000000) {
			RMDBGLOG((ENABLE, "Error setting uninit state! \n"));
			return -EINVAL;
		}

		//  Format

		EM8XXXSNDSP(pE, audio_decoder, RMAudioDecoderPropertyID_Codec, &codec, sizeof(codec));

		if (RMFAILED(err)){
			RMDBGLOG((ENABLE, "Error setting codec property! \n"));
			return err;
		}

		// PCM Parameters
	
		switch(pS->channel_count) {
		case 1:
			pcm_parameters.ChannelAssign = PcmCda1_C;
			break;
		case 2:
			pcm_parameters.ChannelAssign = PcmCda2_LR;
			break;
		default:
			pcm_parameters.ChannelAssign = PcmCda2_LR;
			break;
		}
		pcm_parameters.BitsPerSample = pS->nb_bits_per_sample;
		pcm_parameters.SamplingFrequency = pS->sample_rate;
		pcm_parameters.MsbFirst = pS->MSBFirst;
		pcm_parameters.OutputDualMode = DualMode_Stereo;
		pcm_parameters.OutputSpdif = OutputSpdif_Uncompressed;
		pcm_parameters.OutputChannels = Audio_Out_Ch_LR;
		pcm_parameters.OutputLfe = FALSE;
		pcm_parameters.SignedPCM = (pS->nb_bits_per_sample==16) ? TRUE : FALSE;
		pcm_parameters.BassMode = 0;
	
		EM8XXXSNDSP(pE, audio_decoder, RMAudioDecoderPropertyID_PcmCdaParameters, &pcm_parameters, sizeof(pcm_parameters));
	
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error setting pcm parameters! \n"));
		}

		//Init

		command = AudioDecoder_Command_Init;

		EM8XXXSNDSP(pE, audio_decoder, RMAudioDecoderPropertyID_Command, &command, sizeof(command));

		if (RMFAILED(err)){
			RMDBGLOG((ENABLE, "Error while initializing audio decoder! \n"));
			return err;
		}
		timeout =0;
		while (timeout < 1000000) {
			RMuint32 count = 0;
	
			EM8XXXSNDGP(pE, audio_decoder,RMAudioDecoderPropertyID_State, &state, sizeof(state));
			if (state == AudioDecoder_State_Stopped)
				break;
			kc_interruptible_sleep_on_timeout(pE->wq,US_TO_JIFFIES(10000));
			timeout += 10000;
			count ++;
			printk("count : %lu, timeout = %ld\n", count, timeout);
			if (signal_pending(current)) {
				rc=-ERESTARTSYS;
				break;
			}
		}
		if (timeout >= 1000000) {
			RMDBGLOG((ENABLE, "Error setting init state! \n"));
			return -EINVAL;
		}

		}
		
		rc = kc_logging_copy_to_user((int *) arg, &val, sizeof(int));
		break;
		
        case SOUND_PCM_READ_RATE:
		printk("SOUND_PCM_READ_RATE\n");
			
		EM8XXXSNDGP(pE, audio_engine, RMAudioEnginePropertyID_SampleFrequency, &val, sizeof(val));
		
		if (RMFAILED(err)){
			printk("Error while setting the sample frequency\n");
			break;
		}
		
		rc = kc_logging_copy_to_user((int *) arg, &val, sizeof(int));
		break;
		
        case SOUND_PCM_READ_CHANNELS:
		printk("SOUND_PCM_READ_CHANNELS\n");
		
		val = pS->channel_count;
		rc = kc_logging_copy_to_user((int *) arg, &val, sizeof(int));
		break;

        case SOUND_PCM_READ_BITS:
		printk("SOUND_PCM_READ_BITS\n");
		val = pS->nb_bits_per_sample;
		rc = kc_logging_copy_to_user((int *) arg, &val, sizeof(int));
		break;

        case SNDCTL_DSP_GETBLKSIZE:
		printk("SNDCTL_DSP_GETBLKSIZE\n");
		val = BLKSIZE;
		rc = kc_logging_copy_to_user((int *) arg, &val, sizeof(int));
		//Remove AV Sync form here
		printk("\nDisable AV Sync....module 0x%lx ad 0x%lx\n",(RMuint32)EMHWLIB_MODULE(AudioDecoder,audio_decoder_index),(RMuint32)audio_decoder_index);
		
		EM8XXXSNDSP(pE,EMHWLIB_MODULE(AudioDecoder,audio_decoder_index),RMAudioDecoderPropertyID_SyncSTCEnable, &enablesync, sizeof(RMbool));
		break;

	case SNDCTL_DSP_GETOSPACE:

		EM8XXXSNDGP(pE, audio_decoder,RMGenericPropertyID_DataFIFOInfo, &data_info, sizeof(data_info));

		val = (int) ((data_info.Size + data_info.Writable - data_info.Readable) % data_info.Size);
		printk("SNDCTL_DSP_GETOSPACE %d\n", val);
		abinfo.fragsize = 1<<AUDIO_DMA_BUFFER_SIZE_LOG2;
                abinfo.bytes = val;
                abinfo.fragstotal = AUDIO_DMA_BUFFER_COUNT;
                abinfo.fragments = val /(1<<AUDIO_DMA_BUFFER_SIZE_LOG2);

		rc = kc_logging_copy_to_user((void *)arg, &abinfo, sizeof(abinfo));
		break;

	case SNDCTL_DSP_POST:
		printk("SNDCTL_DSP_POST\n");
		rc = 0;
		break;

        case SNDCTL_DSP_SETFRAGMENT:
		printk("SNDCTL_DSP_SETFRAGMENT\n");
		/* this call may be ignored */
                rc = 0;
		break;
 
	case SNDCTL_DSP_GETODELAY:
	
		EM8XXXSNDGP(pE, audio_decoder,RMGenericPropertyID_DataFIFOInfo, &data_info, sizeof(data_info));
	
		val = (int) ((data_info.Size + data_info.Writable - data_info.Readable) % data_info.Size);
		printk("SNDCTL_DSP_GETODELAY %d\n", val);
		rc = kc_logging_copy_to_user((int *) arg, &val, sizeof(int));
		break;

         case SNDCTL_DSP_GETTRIGGER:
		printk("SNDCTL_DSP_GETTRIGGER\n");
                rc = -EINVAL;
		break;
	case SNDCTL_DSP_SETTRIGGER:
		printk("SNDCTL_DSP_SETTRIGGER\n");
                rc = -EINVAL;
		break;
	case SNDCTL_DSP_GETISPACE:
		printk("SNDCTL_DSP_GETISPACE\n");
                rc = -EINVAL;
		break;
        case SNDCTL_DSP_GETIPTR:
		printk("SNDCTL_DSP_GETIPTR\n");
                rc = -EINVAL;
		break;
        case SNDCTL_DSP_GETOPTR:
		printk("SNDCTL_DSP_GETOPTR\n");
                rc = -EINVAL;
		break;
        case SNDCTL_DSP_SUBDIVIDE:
		printk("SNDCTL_DSP_SUBDIVIDE\n");
                rc = -EINVAL;
		break;
        case SOUND_PCM_WRITE_FILTER:
		printk("SOUND_PCM_WRITE_FILTER\n");
                rc = -EINVAL;
		break;
        case SNDCTL_DSP_SETSYNCRO:
		printk("SNDCTL_DSP_SETSYNCRO\n");
                rc = -EINVAL;
		break;
        case SOUND_PCM_READ_FILTER:
		printk("SOUND_PCM_READ_FILTER\n");
                rc = -EINVAL;
		break;
        case SNDCTL_DSP_NONBLOCK:
		printk("SNDCTL_DSP_NONBLOCK\n");
                rc = -EINVAL;
		break;

	default:
		printk("try mixer ioctl\n");
		rc = process_ioctl_mixer(pE, cmd, arg);
		break;
	}

	return rc;
}

int init_module(void)
{
	int i,enabled_count=0;

	printk("begun\n");
	
	switch(audio_decoder_index){
	case 0:
	case 1:
		audio_engine_index=0;
		break;
#ifdef RMFEATURE_HAS_AUDIO_ENGINE_1
 	case 2:
	case 3:
		audio_engine_index=1;
		break;
#endif // RMFEATURE_HAS_AUDIO_ENGINE_1
	default:
		printk("invalid parameter \n");
		return -EINVAL;
	}
	audio_capture_index = audio_engine_index;

	for (i=0 ; i<MAXLLAD ; i++) {
		if (&((&Etable[i])->pllad) != NULL) {
			if (Etable[i].pllad != NULL){
				if (sndprivate_init(&Etable[i]) != 0) 
					return -EINVAL;
				enabled_count++;
			}
		}
	}

	if ( ((&Etable[0])->pllad != NULL) && (enabled_count == 0)) {
		printk("default behavior, enabling sound on device #0\n");
		if (sndprivate_init(&Etable[0]) != 0) 
			return -EINVAL;
	}
	printk("done\n");
	
        return 0;		    
	
}

void cleanup_module(void)
{
	int i;
	
	printk("begun\n");
	
	for (i=0 ; i<MAXLLAD ; i++) {
		if (Stable[i].sndprivate_active) {
			sndprivate_cleanup(&Etable[i]);
		}
	}
	
	printk("done\n");
}


