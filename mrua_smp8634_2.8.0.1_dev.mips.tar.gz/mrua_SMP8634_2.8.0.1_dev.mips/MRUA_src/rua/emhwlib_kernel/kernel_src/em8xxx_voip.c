/*****************************************
 Copyright � 2004-2005
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   em8xxx_voip.c
  @brief  

  Driver of the Voip function of the board. Implements the Linux Kernel Telephony API.

  @author Yoann Walther
  @date   2005-11-29
*/

#include "em8xxxvoip.h"

/* to enable or disable the debug messages of this source file, put 1 or 0 below */
#if 1
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

#if 0
#define DTMF_DBG ENABLE
#else
#define DTMF_DBG DISABLE
#endif

#if 0
#define AEC_DBG ENABLE
#else
#define AEC_DBG DISABLE
#endif

static u_long audio_capture_index; 
static u_long audio_decoder_index;
static u_long audio_engine_index;
static char * audioin_channel;

MODULE_PARM(audio_decoder_index, "l");
MODULE_PARM_DESC(audio_decoder_index, "Audio Decoder in use\n");

MODULE_PARM(audioin_channel, "s");
MODULE_PARM_DESC(audioin_channel, "Audio In Channel on ADC input : L or R\n");

MODULE_DESCRIPTION("EM8XXX Linux Telephony Driver");
MODULE_AUTHOR("Yoann Walther <yoann_walther@realmagic.fr>");
#ifdef MODULE_LICENSE
MODULE_LICENSE("Proprietary");
#endif

extern struct em8xxxprivate Etable[MAXLLAD];
RMstatus krua_register_event_callback(void *pE,RMuint32 ModuleID,RMuint32 mask, Event_callback callback);
RMstatus krua_unregister_event_callback(void *pE,RMuint32 ModuleID,Event_callback callback);

static int gpio_set_dir(struct em8xxxprivate *pE,int gpio_number,int dir);
static int read_gpio(struct em8xxxprivate *pE,int gpio_number);
static int write_gpio(struct em8xxxprivate *pE,int gpio_number, int val);
static int init_gpio(struct em8xxxprivate *pE);
static int SlicSetState(struct voipprivate *pV,enum SLIC_STATES State);
static void em8xxx_voip_init_timer(struct voipprivate *pV);
static void em8xxx_voip_add_timer(struct voipprivate *pV);
static void em8xxx_voip_check_hookstate(struct voipprivate *pV);
static void em8xxx_voip_check_dtmf(struct voipprivate *pV);
static void em8xxx_voip_timeout(unsigned long private);

RMint16 ulaw2linear(RMuint8 ulawbyte);
static RMuint32 bytes_to_samples(struct voipprivate *pV,RMuint32 count);
int dtmf_decode(int N,unsigned char *sample,int pct);
int * goertzel(int N,unsigned char * sample_buf);

static RMstatus init_audio(struct voipprivate *pV);
static RMstatus prepare_data(struct voipprivate *pV);
static RMstatus start_playback(struct em8xxxprivate *pE);
static RMstatus start_capture(struct em8xxxprivate *pE);
static void stop_capture(struct em8xxxprivate *pE);
static RMstatus set_audio_parameters(struct voipprivate *pV);
static int rm_free_ptr(struct em8xxxprivate *pE,RMuint32 ptr);
static RMstatus cleanup_audio(struct voipprivate *pV);
static void set_cadence_parameters(struct voipprivate *pV);
static int read_dtmf(struct voipprivate *pV);
static int send_dial_tone(struct voipprivate *pV);
static int send_ringback_tone(struct voipprivate *pV);
static int send_busy_tone(struct voipprivate *pV);
static int send_ring_tone(struct voipprivate *pV);

static int em8xxx_voip_init(struct em8xxxprivate *pE);
static int em8xxx_voip_cleanup(struct em8xxxprivate *pE);
static int em8xxx_voip_open(struct phone_device *p, struct file *file_p);
static ssize_t em8xxx_voip_read(struct file * file_p, char *buf, size_t length,loff_t * ppos);
static ssize_t em8xxx_voip_write(struct file * file_p, const char *buf, size_t count, loff_t * ppos);
static unsigned int em8xxx_voip_poll(struct file *file_p, poll_table * wait);
static int em8xxx_voip_ioctl(struct inode *inode, struct file *file_p, unsigned int cmd, unsigned long arg);
static int em8xxx_voip_release(struct inode *inode, struct file *file_p);
static int em8xxx_voip_fasync(int fd, struct file *file_p, int mode);

struct file_operations em8xxx_voip_fops =
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
	NULL,			/* lseek */
	em8xxx_voip_read,
	em8xxx_voip_write,
	NULL,			/* readdir */
	em8xxx_voip_poll,
	em8xxx_voip_ioctl,
	NULL,			/* mmap */
	NULL,			/* open */
	NULL,			/* flush */
	em8xxx_voip_release,
	NULL,			/* fsync */
	em8xxx_voip_fasync,		/* fasync */
	NULL,			/* media change */
	NULL,			/* revalidate */
	NULL			/* lock */
#else
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
	owner:          THIS_MODULE,
	read:           em8xxx_voip_read,
	write:          em8xxx_voip_write,
	poll:           em8xxx_voip_poll,
	ioctl:          em8xxx_voip_ioctl,
	release:        em8xxx_voip_release,
	fasync:         em8xxx_voip_fasync
#else
	.owner        = THIS_MODULE,
	.read         = em8xxx_voip_read,
	.write        = em8xxx_voip_write,
	.poll         = em8xxx_voip_poll,
	.ioctl        = em8xxx_voip_ioctl,
	.release      = em8xxx_voip_release,
	.fasync       = em8xxx_voip_fasync
#endif
#endif
};

int * goertzel(int N,unsigned char * sample_buf)
{
	int i, j, q0, q1, q2, *result;

	/* Allocate memory for result based on how many frequencies are in
	   goertzel_const[][] */
	for(i = 0; goertzel_const[i][FREQ] != -1; i++);
	if((result = vmalloc((i + 1) * sizeof(int))) == NULL) {
		RMDBGLOG((DTMF_DBG,"error in goertzel vmalloc()"));
		return(NULL);
	}

	/* Process each frequency */
	for(i = 0; goertzel_const[i][FREQ] != -1; i++) {
		
		q0 = q1 = q2 = 0;
		
		/* Process each sample */
		for(j = 0; j < N; j++) {
			
			q0 = ((long long) goertzel_const[i][COEFF] * q1)/32768 - q2 + sample_buf[j];
			q2 = q1;
			q1 = q0;
			
		}
		
		/* Store the result */
		
		result[i] = (q1 * q1) + (q2 * q2) - (q1 * q2 * goertzel_const[i][COEFF])/32768;

	}
	
  result[i + 1] = -1;
  
  return(result);
}

int dtmf_decode(int N,unsigned char *sample,int pct) 
{
	
	int flag, group, grp[2] = {-1, -1}, i, j, *result, thres;
	
	/* If goertzel() fails */
	if((result = goertzel(N, sample)) == NULL) {
		return(-1);
	}
	
	/* Check each DTMF digit. The threshold is the passed percentage of the
	   frequency set for each digit. This should improve detection in very
	   high-noise environments such as radio. */
	for(i = 0; goertzel_const[i][FREQ] != -1; i++) {
		
		/* Wether or not i is the loudest frequency */
		flag = 1;
		
		/* Set the threshold based on the percentage of the loudest tone */
		thres = ((result[i] * pct) / 100);
	       
		/* Set the group we're dealing with (hi/lo) */
		group = goertzel_const[i][GROUP];
		
		/* Process each frequency if the loudest frequency for the group has not 
		   been found */
		if(grp[group] == -1) {
			for(j = 0; goertzel_const[j][FREQ] != -1; j++) {
				
				/* If they're in the same group, check to see wether one is pct louder
				   than the other */
				if(goertzel_const[i][GROUP] == goertzel_const[j][GROUP] && i != j) {
					if(result[j] > thres) {
						/* i is not the frequency */
						flag = 0;
					}
				}
				
			}
			
			/* If flag is still set, i is the correct frequency */
			if(flag) {
				grp[group] = goertzel_const[i][FREQ];
			}
			
		}
	}
	
	/* Free result memory */
	vfree(result);
	
	/* Return the DTMF digit corresponding with the detected frequencies */
	for(i = 0; dtmf_decode_tones[i][DIGIT] != -1; i++) {
		if(dtmf_decode_tones[i][FREQ1] == grp[0] && dtmf_decode_tones[i][FREQ2] == grp[1]) {
			return(dtmf_decode_tones[i][DIGIT]);
		}
	}
	
	/* Otherwise, return a comma (pause) */
	return(',');
	
}

short ulaw2linear(unsigned char ulawbyte)
{
	static short exp_lut[8] = {0,132,396,924,1980,4092,8316,16764};
	short sign, exponent, mantissa, sample;
	
	ulawbyte = ~ulawbyte;
	sign = (ulawbyte & 0x80);
	exponent = (ulawbyte >> 4) & 0x07;
	mantissa = ulawbyte & 0x0F;
	sample = exp_lut[exponent] + (mantissa << (exponent + 3));
	if (sign != 0) sample = -sample;
	
	return(sample);
}

static RMuint32 bytes_to_samples(struct voipprivate *pV,RMuint32 count)
{
	RMuint32 samples;
	RMuint32 nb_bits_per_sample = pV->nb_bits_per_sample;

	samples = (count*8) / (nb_bits_per_sample);
	return samples;
}

static int gpio_set_dir(struct em8xxxprivate *pE,int gpio_number,int dir)
{
	RMuint32 gpio_dir;
	RMuint32 gpio_dir_addr;
	int nb;

	if(gpio_number > 16){
		gpio_dir_addr = ETH_GPIO_DIR;
		nb = gpio_number - 16;
	}
	else {
		gpio_dir_addr = SYS_GPIO_DATA;
		nb = gpio_number;
	}

	gpio_dir = gbus_read_uint32(pE->pgbus,gpio_dir_addr);
	RMsetConsecutiveBitsVar(&gpio_dir,nb+16,nb+16,1);
	RMsetConsecutiveBitsVar(&gpio_dir,nb,nb,dir);
	
	gbus_write_uint32(pE->pgbus,gpio_dir_addr,gpio_dir);
	gpio_dir = gbus_read_uint32(pE->pgbus,gpio_dir_addr);
	if (dir == ((gpio_dir >> nb) & 1))
		return 0;
	else 
		return -1;
	
}

static int read_gpio(struct em8xxxprivate *pE,int gpio_number)
{
	RMuint32 gpio_data;
	RMuint32 gpio_data_addr;
	int val;
	int nb;

	if(gpio_number > 16){
		gpio_data_addr = ETH_GPIO_DATA;
		nb = gpio_number - 16;
	}
	else {
		gpio_data_addr = SYS_GPIO_DATA;
		nb = gpio_number;
	}
	
	gpio_data = gbus_read_uint32(pE->pgbus,gpio_data_addr);
	val = (gpio_data >> nb) & 1;

	return val;
	
}

static int write_gpio(struct em8xxxprivate *pE,int gpio_number, int val)
{
	RMuint32 gpio_data;
	RMuint32 gpio_data_addr;
	int nb;
	
	if(gpio_number > 16){
		gpio_data_addr = ETH_GPIO_DATA;
		nb = gpio_number - 16;
	}
	else{
		gpio_data_addr = SYS_GPIO_DATA;
		nb = gpio_number;
	}

	gpio_data = gbus_read_uint32(pE->pgbus,gpio_data_addr);

	RMsetConsecutiveBitsVar(&gpio_data,nb+16,nb+16,1);
	RMsetConsecutiveBitsVar(&gpio_data,nb,nb,val);

	gbus_write_uint32(pE->pgbus,gpio_data_addr,gpio_data);

	gpio_data = gbus_read_uint32(pE->pgbus,gpio_data_addr);
	if (val == ((gpio_data >> nb) & 1))
		return 0;
	else 
		return -1;
}

static int init_gpio(struct em8xxxprivate *pE)
{
	gpio_set_dir(pE,GPIO_SLIC_COMP,GPIO_DIR_OUTPUT);
	gpio_set_dir(pE,GPIO_SLIC_CTL1,GPIO_DIR_OUTPUT);
	gpio_set_dir(pE,GPIO_SLIC_CTL2,GPIO_DIR_OUTPUT);
	gpio_set_dir(pE,GPIO_SLIC_MUTE,GPIO_DIR_OUTPUT);
	gpio_set_dir(pE,GPIO_HDS_MUTE,GPIO_DIR_OUTPUT);
	gpio_set_dir(pE,GPIO_LOOP_DETECT,GPIO_DIR_INPUT);
	gpio_set_dir(pE,GPIO_FAULT_DETECT,GPIO_DIR_INPUT);

	return 0;
}

static int receive_callback(void *pE)
{
	struct em8xxxprivate *real_pE = (struct em8xxxprivate *) pE;
	struct voipprivate *pV = VOIPtable + (real_pE-Etable);

	kc_wake_up_interruptible(pV->read_q);

	return 0;
}

static int send_callback(void *pE)
{
	struct em8xxxprivate *real_pE = (struct em8xxxprivate *) pE;
	struct voipprivate *pV = VOIPtable + (real_pE-Etable);

	kc_wake_up_interruptible(pV->write_q);

	return 0;
}

static int SlicSetState(struct voipprivate *pV,enum SLIC_STATES State)
{
	struct em8xxxprivate *pE = Etable + (pE - Etable);
	
	switch(State){
	case LOW_POWER_STANDBY:
		write_gpio(pE,GPIO_SLIC_COMP,0);
		write_gpio(pE,GPIO_SLIC_CTL1,0);
		write_gpio(pE,GPIO_SLIC_CTL2,0);
		pV->slic_state = LOW_POWER_STANDBY;
		break;
	case REVERSE_POLARITY:
		write_gpio(pE,GPIO_SLIC_COMP,0);
		write_gpio(pE,GPIO_SLIC_CTL1,1);
		write_gpio(pE,GPIO_SLIC_CTL2,0);
		pV->slic_state = REVERSE_POLARITY;
		break;
	case NORMAL_ACTIVE:
		write_gpio(pE,GPIO_SLIC_COMP,0);
		write_gpio(pE,GPIO_SLIC_CTL1,0);
		write_gpio(pE,GPIO_SLIC_CTL2,1);
		pV->slic_state = NORMAL_ACTIVE;
		break;
	case RINGING:
		write_gpio(pE,GPIO_SLIC_COMP,0);
		write_gpio(pE,GPIO_SLIC_CTL1,1);
		write_gpio(pE,GPIO_SLIC_CTL2,1);
		pV->slic_state = RINGING;
		break;
	case DISCONNECT:
		write_gpio(pE,GPIO_SLIC_COMP,1);
		write_gpio(pE,GPIO_SLIC_CTL1,0);
		write_gpio(pE,GPIO_SLIC_CTL2,0);
		pV->slic_state = DISCONNECT;
		break;
	}

	return 0;
}

static void em8xxx_voip_check_hookstate(struct voipprivate *pV)
{
	struct em8xxxprivate *pE = Etable + (pV - VOIPtable);
	enum AudioDecoder_Command_type command;
	RMstatus err;
	
	pV->hookstate = !read_gpio(pE,GPIO_LOOP_DETECT);

	if(pV->hookstate != pV->last_hookstate){
		pV->hook_cnt ++;
		if(pV->hook_cnt>=10){
			if(pV->hookstate){
				pV->ring_stop=TRUE;
				if(pV->ringing){
					/* Stop ringing and flush audio fifo */
					RMDBGLOG((LOCALDBG,"stop to ring \n"));
					pV->ringing = 0;
					SlicSetState(pV,NORMAL_ACTIVE);
					command = AudioDecoder_Command_Stop;
					EM8XXXVOIPSP(pE,EMHWLIB_MODULE(AudioDecoder,audio_decoder_index), RMAudioDecoderPropertyID_Command, &command, sizeof(command));
					kc_udelay(1000);
				}
			}
			else
				pV->ring_stop=FALSE;
			if(pV->hookstate && !pV->capture_enable){
				pV->nb_bits_per_sample=16;
				start_capture(pE);
				pV->dtmf_enable=1;
			}
			pV->hook_cnt = 0;
			
			RMDBGLOG((LOCALDBG,"detecting hook state change pV->hook_cnt = %d ! \n",pV->hook_cnt));
			pV->last_hookstate = pV->hookstate;
			pV->exc.bits.hookstate = 1;
			RMDBGLOG((LOCALDBG,"exc.bytes = %d \n",pV->exc.bytes));
		}
	}
}

static void em8xxx_voip_check_dtmf(struct voipprivate *pV)
{
	RMuint32 readable_dtmf;
	
	/* Get readable size in dtmf buffer */
	if(pV->dtmf_wr_ptr >= pV->dtmf_rd_ptr)
		readable_dtmf = pV->dtmf_wr_ptr - pV->dtmf_rd_ptr;
	else
		readable_dtmf = DTMF_BUFFER_SIZE - pV->dtmf_rd_ptr + pV->dtmf_wr_ptr;

	/* If readable > 0 raise an exception */

	if (readable_dtmf > 0){
		pV->exc.bits.dtmf_ready = 1;
	}
	
}

static void set_cadence_parameters(struct voipprivate *pV)
{
	int i;
	RMuint16 cadence;
	RMuint32 nb_off = 0;
	RMuint32 nb_on = 0;
	int first = 0;

	cadence = pV->cadence;

	/* First count the number of consecutive 0 bits */
	
	for(i=0;i<16;i++){
		if ((cadence & 0x0001) == 0){
			if (first == 0){
				first = 1;
				nb_off ++;
			}
			else nb_off ++;
		}
		else {
			if (first){
				break;
			}
		}
		cadence >>= 1;
	}

	/* Then count the number of consecutive 1 bits */
	first = 0;
	cadence = pV->cadence;

	for(i=0;i<16;i++){
		if ((cadence & 0x0001) == 1){
			if (first == 0){
				first = 1;
				nb_on ++;
			}
			else nb_on ++;
		}
		else {
			if (first){
				break;
			}
		}
		cadence >>= 1;
	}
	
	pV->ring_time.ring_on = nb_on*10;
	pV->ring_time.ring_off = nb_off*10;

	pV->ringback_time.ringback_on = nb_on*10;
	pV->ringback_time.ringback_off = nb_off*10;

	pV->busy_time.busy_on = 10;
	pV->busy_time.busy_off= 10;

	RMDBGLOG((LOCALDBG,"Ring cadence is now : %d s on, %d s off !\n",nb_on/2,nb_off/2));
		
	return;
}

static int read_dtmf(struct voipprivate *pV)
{
	RMstatus rc,err;
	RMuint32 audio_capture = EMHWLIB_MODULE(AudioCapture,audio_capture_index);
	struct em8xxx_data param;
	void *context;
	RMuint8 info[INFO_SIZE];
	RMuint32 infoSize = INFO_SIZE;
	size_t to_read;
	struct em8xxxprivate *pE=Etable+(pV-VOIPtable);
	struct ReadBufferInfo prop;
	RMuint32 event_mask;
	RMuint32 samples;
	RMint32 i,j;
	size_t length = FRAME_SIZE;
	RMuint8 buf[FRAME_SIZE];
	samples = bytes_to_samples(pV,length);
	to_read = samples * 6; // in the microcode we capture in 24 bits, 2 channels.
	RMint32 k,l;
	int ch;

	if(!pV->voip_open_count){
		return -EINVAL;
	}

	if(!pV->capture_enable){
		return 1;
	}
	
	while(1){
		
		RMuint32 it=0;

		if(pV->capture_pBuf == NULL){
			
			// Receive buffer
			param.moduleId = audio_capture;
			param.poolId = pV->capture_dmapool_id;
			param.infoSize = infoSize;

			err=RM_INSUFFICIENT_SIZE;
			while(err==RM_INSUFFICIENT_SIZE){
				it ++;
				if(it >= 10){
					return -EINVAL;
				}

				kc_spin_lock_bh(pE->lock);	      
				err=EMhwlibReceiveBuffer(pE->pemhwlib, param.moduleId, &(param.bus_addr), &(param.dataSize), info, &(param.infoSize), &context);
				kc_spin_unlock_bh(pE->lock);	      
				if((err != RM_OK) && (err != RM_INSUFFICIENT_SIZE)){
					RMDBGLOG((LOCALDBG,"fatal arror while receiving buffer. abort, err = %d \n",err));
					return -EINVAL;
				}
				
			}
			
			event_mask = SOFT_IRQ_EVENT_XFER_RECEIVE_READY;
			kc_spin_lock_bh(pE->lock);	      
			rc=EMhwlibSetProperty(pE->pemhwlib,audio_capture,RMGenericPropertyID_ClearEventMask,&event_mask, sizeof(event_mask));
			kc_spin_unlock_bh(pE->lock);	      


			pV->capture_buffer_bus_addr = param.bus_addr;
			pV->capture_pBuf=kdmapool_get_virt_address(pE->pllad,pV->capture_dmapool_id,pV->capture_buffer_bus_addr, 0);
			pV->capture_buffer_size = param.dataSize;
			pV->capture_readable = param.dataSize;
			pV->capture_read=0;
			pV->i_start = 0;
		}
		
		else {
			pV->i_start = pV->last_i;
		}
		
		pV->j_start = pV->last_j;
		
		i=pV->i_start;
		j=pV->j_start;
		while (j<length){
			
			if(i>=pV->capture_buffer_size){
				break;
			}
			
			switch(pV->state){
			case 0:
				if(audioin_channel=="L"){
					if(pV->nb_bits_per_sample==8)
						buf[j]=pV->capture_pBuf[i]+128;
					else
						buf[j]=pV->capture_pBuf[i];
					j++;
				}
				break;
		
			case 1:
				if(audioin_channel=="L"){
					if(pV->nb_bits_per_sample==16){
						buf[j]=pV->capture_pBuf[i];
						j++;
					}
				}
				break;
			case 3:
				if(audioin_channel=="R"){
					if(pV->nb_bits_per_sample==8)
						buf[j]=pV->capture_pBuf[i]+128;
					else
						buf[j]=pV->capture_pBuf[i];
					j++;
				}
				break;
		
			case 4:
				if(audioin_channel=="R"){
					if(pV->nb_bits_per_sample==16){
						buf[j]=pV->capture_pBuf[i];
						j++;
					}
				}
				break;
			default:
				break;
			}
			
			i++;
			pV->state ++;
			pV->state %= 6;
		}
		
		
		pV->last_i = i;
		pV->last_j = j;
		
		if (i >= pV->capture_buffer_size){
		
			prop.address = pV->capture_buffer_bus_addr;
			prop.size = pV->capture_buffer_size;
			prop.context = (void *) ((pE-Etable) + pV->capture_dmapool_id + 1);
			EM8XXXVOIPSP(pE,audio_capture, RMGenericPropertyID_AddReadBuffer, &prop, sizeof(prop));
			if(RMFAILED(err)){
				RMDBGLOG((LOCALDBG,"error %d while adding read buffer \n"));
			}
			pV->capture_pBuf = NULL;
			
		}

		if (j == length){
			pV->last_j = 0;
			break;
		}
		
	}

 	if(pV->nb_bits_per_sample==16){
 		// byte-swap
 		RMuint32 l;
 		RMint8 temp;
 		for (l=0;l<length;l+=2){
 			temp = buf[l];
 			buf[l] = buf[l+1];
 			buf[l+1] = temp;
 		}
	}
	
 	/* Process DTMF on buffer */
	
	while(1){
		
		if((length - pV->dtmf_decoded) < (2*GOERTZEL_N)){
			pV->dtmf_offset = length - pV->dtmf_decoded;
			
			for( k = 0,l = 0 ; k < pV->dtmf_offset ; k += 2,l++ ) {
				if(pV->nb_bits_per_sample ==16){
					pV->goertzel_buffer[l]=buf[k+1]+128;
				}
				else
					pV->goertzel_buffer[l] = buf[k];
			}
			
			pV->dtmf_decoded = 0;
			break;
		}
		
		if(pV->dtmf_offset != 0){
			RMuint32 size = 2*GOERTZEL_N - pV->dtmf_offset;
			
			for(k=0,l=0;k<size;k+=2,l++){
				if(pV->nb_bits_per_sample ==16){
					pV->goertzel_buffer[l+pV->dtmf_offset]=buf[k+1]+128;
				}
				else
					pV->goertzel_buffer[l+pV->dtmf_offset] = buf[k];
			}
			pV->dtmf_offset = 0;
			pV->dtmf_decoded += size;
		}
		else {
			for(k=0,l=0;k<2*GOERTZEL_N;k+=2,l++){
				if(pV->nb_bits_per_sample ==16){
					pV->goertzel_buffer[l+pV->dtmf_offset]=buf[k+1]+128;
				}
				else
					pV->goertzel_buffer[l+pV->dtmf_offset] = buf[k];
			}
			pV->dtmf_decoded += 2*GOERTZEL_N;
		}
		
		ch = dtmf_decode(GOERTZEL_N,pV->goertzel_buffer,DEFAULT_DECODER_PCT);
		if (ch == pV->dup_ch){
			if(ch != ','){
				if(ch != pV->last_ch){
					RMuint8 *wr_ptr = pV->dtmf_buffer + pV->dtmf_wr_ptr;
					
					RMDBGLOG((DTMF_DBG,"Detected DTMF %c \n",ch));
					*wr_ptr = ch;
					pV->dtmf_wr_ptr ++;
					if(pV->dtmf_wr_ptr >= DTMF_BUFFER_SIZE)
						pV->dtmf_wr_ptr -= DTMF_BUFFER_SIZE;
					RMDBGLOG((DTMF_DBG,"wr = %d, rd = %d \n",pV->dtmf_wr_ptr,pV->dtmf_rd_ptr));
				}
			}
		}
		if(pV->dup_ch == ch){
			pV->last_ch = ch;
		}
		pV->dup_ch = ch;
	}
	
	return length;
}

static int send_ring_tone(struct voipprivate *pV)
{
	struct em8xxxprivate *pE = Etable + (pV - VOIPtable);
	struct emhwlib_info Info;
	struct emhwlib_info *pInfo = &Info;
	struct em8xxx_data param;
	RMuint32 Info_size;
	RMuint32 time_resolution;
	RMuint64 time;
	RMstatus err;
	RMuint32 size;
	void * context;
	RMuint32 it=0,timeout_buffer=0;
	
	if (pV->decoder_pBuf==NULL){
		
		/* As we are in a kernel timer we can not go to sleep, and thus we can not fail in the case get_buffer go to sleep^*/
		if(kdmapool_get_available_buffer_count(pE->pllad,pV->decoder_dmapool_id)>0){
			pV->decoder_pBuf=kdmapool_getbuffer(pE->pllad,pV->decoder_dmapool_id,&timeout_buffer);
		}
	}
	
	if (pV->decoder_pBuf==NULL){
		return 0;
	}

	size = RING_BUFFER_SIZE*2;

	switch(pV->ring_time.ring_state){
	case Ring_state_On:
		memcpy(pV->decoder_pBuf,Ring,size);
		pV->ring_time.ring_cnt ++;
		if(pV->ring_time.ring_cnt >= pV->ring_time.ring_on){
			pV->ring_time.ring_state = Ring_state_Off;
			pV->ring_time.ring_cnt = 0;
		}
		break;
	case Ring_state_Off:
		memset(pV->decoder_pBuf,0,size);
		pV->ring_time.ring_cnt ++;
		if(pV->ring_time.ring_cnt >= pV->ring_time.ring_off){
			pV->ring_time.ring_state = Ring_state_On;
			pV->ring_time.ring_cnt = 0;
		}
		break;
	}

	if (pV->firstPTS) {
		pV->firstPTS = FALSE;
		Info.ValidFields = TIME_STAMP_INFO;
		
		EM8XXXVOIPGP(pE,EMHWLIB_MODULE(STC,audio_decoder_index),RMSTCPropertyID_AudioTimeResolution,&time_resolution,sizeof(time_resolution));
		EM8XXXVOIPEXP(pE, EMHWLIB_MODULE(STC,audio_decoder_index),RMSTCPropertyID_TimeInfo,&time_resolution,sizeof(time_resolution),&time,sizeof(time));
		
		Info.TimeStamp = time;
		pInfo = &Info;
		Info_size = sizeof(Info);
	}
	else {
		pInfo = NULL;
		Info_size = 0;
	}

	param.moduleId = EMHWLIB_MODULE(AudioDecoder,audio_decoder_index);
	param.poolId = pV->decoder_dmapool_id;
	param.dataSize = size;
	param.bus_addr = kdmapool_get_bus_address(pE->pllad,pV->decoder_dmapool_id,pV->decoder_pBuf,param.dataSize);
	kc_flush_cache((void *)param.bus_addr,param.dataSize);

	context =(void *) (((pE-Etable) << 16) + param.poolId + 1);

	err=RM_INSUFFICIENT_SIZE;
	while(err==RM_INSUFFICIENT_SIZE){
		it ++;
		if(it >= 10){
			RMDBGLOG((LOCALDBG,"forced to quit loop \n"));
			return -EINVAL;
		}
	
		kc_spin_lock_bh(pE->lock);
		err = EMhwlibSendBuffer(pE->pemhwlib, param.moduleId, param.bus_addr, param.dataSize, pInfo, Info_size, context);
		kc_spin_unlock_bh(pE->lock);

		if((err != RM_OK) && (err != RM_INSUFFICIENT_SIZE)){
			RMDBGLOG((LOCALDBG,"fatal error while sending buffer. abort, err = %d \n",err));
			return -EINVAL;
		}
	}

	// Release is done by the Send buffer

	pV->decoder_pBuf = NULL;

	return 0;
}

static int send_busy_tone(struct voipprivate *pV)
{
	struct em8xxxprivate *pE = Etable + (pV - VOIPtable);
	struct emhwlib_info Info;
	struct emhwlib_info *pInfo = &Info;
	struct em8xxx_data param;
	RMuint32 Info_size;
	RMuint32 time_resolution;
	RMuint64 time;
	RMstatus err;
	RMuint32 size;
	void * context;
	RMuint32 it=0,timeout_buffer=0;
	
	if (pV->decoder_pBuf==NULL){
		
		/* As we are in a kernel timer we can not go to sleep, and thus we can not fail in the case get_buffer go to sleep^*/
		if(kdmapool_get_available_buffer_count(pE->pllad,pV->decoder_dmapool_id)>0){
			pV->decoder_pBuf=kdmapool_getbuffer(pE->pllad,pV->decoder_dmapool_id,&timeout_buffer);
		}
	}
	
	if (pV->decoder_pBuf==NULL){
		return 0;
	}

	size = BUSY_BUFFER_SIZE*2;

	switch(pV->busy_time.busy_state){
	case Busy_state_On:
		memcpy(pV->decoder_pBuf,Busy,size);
		pV->busy_time.busy_cnt ++;
		if(pV->busy_time.busy_cnt >= pV->busy_time.busy_on){
			pV->busy_time.busy_state = Busy_state_Off;
			pV->busy_time.busy_cnt = 0;
		}
		break;
	case Busy_state_Off:
		memset(pV->decoder_pBuf,0,size);
		pV->busy_time.busy_cnt ++;
		if(pV->busy_time.busy_cnt >= pV->busy_time.busy_off){
			pV->busy_time.busy_state = Busy_state_On;
			pV->busy_time.busy_cnt = 0;
		}
		break;
	}

 	if(pV->nb_bits_per_sample==16){
 		// byte-swap
 		RMuint32 l;
 		RMint8 temp;
 		for (l=0;l<size;l+=2){
 			temp = pV->decoder_pBuf[l];
 			pV->decoder_pBuf[l] = pV->decoder_pBuf[l+1];
 			pV->decoder_pBuf[l+1] = temp;
 		}
	}
		
	if (pV->firstPTS) {
		pV->firstPTS = FALSE;
		Info.ValidFields = TIME_STAMP_INFO;
		
		EM8XXXVOIPGP(pE,EMHWLIB_MODULE(STC,audio_decoder_index),RMSTCPropertyID_AudioTimeResolution,&time_resolution,sizeof(time_resolution));
		EM8XXXVOIPEXP(pE, EMHWLIB_MODULE(STC,audio_decoder_index),RMSTCPropertyID_TimeInfo,&time_resolution,sizeof(time_resolution),&time,sizeof(time));
		
		Info.TimeStamp = time;
		pInfo = &Info;
		Info_size = sizeof(Info);
	}
	else {
		pInfo = NULL;
		Info_size = 0;
	}

	param.moduleId = EMHWLIB_MODULE(AudioDecoder,audio_decoder_index);
	param.poolId = pV->decoder_dmapool_id;
	param.dataSize = size;
	param.bus_addr = kdmapool_get_bus_address(pE->pllad,pV->decoder_dmapool_id,pV->decoder_pBuf,param.dataSize);
	kc_flush_cache((void *)param.bus_addr,param.dataSize);

	context =(void *) (((pE-Etable) << 16) + param.poolId + 1);

	err=RM_INSUFFICIENT_SIZE;
	while(err==RM_INSUFFICIENT_SIZE){
		it ++;
		if(it >= 10){
			RMDBGLOG((LOCALDBG,"forced to quit loop \n"));
			return -EINVAL;
		}
	
		kc_spin_lock_bh(pE->lock);
		err = EMhwlibSendBuffer(pE->pemhwlib, param.moduleId, param.bus_addr, param.dataSize, pInfo, Info_size, context);
		kc_spin_unlock_bh(pE->lock);

		if((err != RM_OK) && (err != RM_INSUFFICIENT_SIZE)){
			RMDBGLOG((LOCALDBG,"fatal error while sending buffer. abort, err = %d \n",err));
			return -EINVAL;
		}
	}

	// Release is done by the Send buffer

	pV->decoder_pBuf = NULL;

	return 0;
}

static int send_ringback_tone(struct voipprivate *pV)
{
	struct em8xxxprivate *pE = Etable + (pV - VOIPtable);
	struct emhwlib_info Info;
	struct emhwlib_info *pInfo = &Info;
	struct em8xxx_data param;
	RMuint32 Info_size;
	RMuint32 time_resolution;
	RMuint64 time;
	RMstatus err;
	RMuint32 size;
	void * context;
	RMuint32 it=0,timeout_buffer=0;
	
	if (pV->decoder_pBuf==NULL){
		
		/* As we are in a kernel timer we can not go to sleep, and thus we can not fail in the case get_buffer go to sleep^*/
		if(kdmapool_get_available_buffer_count(pE->pllad,pV->decoder_dmapool_id)>0){
			pV->decoder_pBuf=kdmapool_getbuffer(pE->pllad,pV->decoder_dmapool_id,&timeout_buffer);
		}
	}
	
	if (pV->decoder_pBuf==NULL){
		return 0;
	}

	size = RING_BUFFER_SIZE*2;

	switch(pV->ringback_time.ringback_state){
	case Ringback_state_On:
		memcpy(pV->decoder_pBuf,Ringback,size);
		pV->ringback_time.ringback_cnt ++;
		if(pV->ringback_time.ringback_cnt >= pV->ringback_time.ringback_on){
			pV->ringback_time.ringback_state = Ringback_state_Off;
			pV->ringback_time.ringback_cnt = 0;
		}
		break;
	case Ringback_state_Off:
		memset(pV->decoder_pBuf,0,size);
		pV->ringback_time.ringback_cnt ++;
		if(pV->ringback_time.ringback_cnt >= pV->ringback_time.ringback_off){
			pV->ringback_time.ringback_state = Ringback_state_On;
			pV->ringback_time.ringback_cnt = 0;
		}
		break;
	}

 	if(pV->nb_bits_per_sample==16){
 		// byte-swap
 		RMuint32 l;
 		RMint8 temp;
 		for (l=0;l<size;l+=2){
 			temp = pV->decoder_pBuf[l];
 			pV->decoder_pBuf[l] = pV->decoder_pBuf[l+1];
 			pV->decoder_pBuf[l+1] = temp;
 		}
	}
		
		
	if (pV->firstPTS) {
		pV->firstPTS = FALSE;
		Info.ValidFields = TIME_STAMP_INFO;
		
		EM8XXXVOIPGP(pE,EMHWLIB_MODULE(STC,audio_decoder_index),RMSTCPropertyID_AudioTimeResolution,&time_resolution,sizeof(time_resolution));
		EM8XXXVOIPEXP(pE, EMHWLIB_MODULE(STC,audio_decoder_index),RMSTCPropertyID_TimeInfo,&time_resolution,sizeof(time_resolution),&time,sizeof(time));
		
		Info.TimeStamp = time;
		pInfo = &Info;
		Info_size = sizeof(Info);
	}
	else {
		pInfo = NULL;
		Info_size = 0;
	}

	param.moduleId = EMHWLIB_MODULE(AudioDecoder,audio_decoder_index);
	param.poolId = pV->decoder_dmapool_id;
	param.dataSize = size;
	param.bus_addr = kdmapool_get_bus_address(pE->pllad,pV->decoder_dmapool_id,pV->decoder_pBuf,param.dataSize);
	kc_flush_cache((void *)param.bus_addr,param.dataSize);

	context =(void *) (((pE-Etable) << 16) + param.poolId + 1);

	err=RM_INSUFFICIENT_SIZE;
	while(err==RM_INSUFFICIENT_SIZE){
		it ++;
		if(it >= 10){
			RMDBGLOG((LOCALDBG,"forced to quit loop \n"));
			return -EINVAL;
		}
	
		kc_spin_lock_bh(pE->lock);
		err = EMhwlibSendBuffer(pE->pemhwlib, param.moduleId, param.bus_addr, param.dataSize, pInfo, Info_size, context);
		kc_spin_unlock_bh(pE->lock);

		if((err != RM_OK) && (err != RM_INSUFFICIENT_SIZE)){
			RMDBGLOG((LOCALDBG,"fatal error while sending buffer. abort, err = %d \n",err));
			return -EINVAL;
		}
	}

	// Release is done by the Send buffer

	pV->decoder_pBuf = NULL;

	return 0;
}

static int send_dial_tone(struct voipprivate *pV)
{
	struct em8xxxprivate *pE = Etable + (pV - VOIPtable);
	struct emhwlib_info Info;
	struct emhwlib_info *pInfo = &Info;
	struct em8xxx_data param;
	RMuint32 Info_size;
	RMuint32 time_resolution;
	RMuint64 time;
	RMstatus err;
	RMuint32 size;
	void * context;
	RMuint32 it=0,timeout_buffer=0;
	
	if (pV->decoder_pBuf==NULL){
		
		/* As we are in a kernel timer we can not go to sleep, and thus we can not fail in the case get_buffer go to sleep^*/
		if(kdmapool_get_available_buffer_count(pE->pllad,pV->decoder_dmapool_id)>0){
			pV->decoder_pBuf=kdmapool_getbuffer(pE->pllad,pV->decoder_dmapool_id,&timeout_buffer);
		}
	}
	
	if (pV->decoder_pBuf==NULL){
		return 0;
	}

	size = DIAL_BUFFER_SIZE*2;

	memcpy(pV->decoder_pBuf,Dial,size);
	
 	if(pV->nb_bits_per_sample==16){
 		// byte-swap
 		RMuint32 l;
 		RMint8 temp;
 		for (l=0;l<size;l+=2){
 			temp = pV->decoder_pBuf[l];
 			pV->decoder_pBuf[l] = pV->decoder_pBuf[l+1];
 			pV->decoder_pBuf[l+1] = temp;
 		}
	}
		
		
	if (pV->firstPTS) {
		pV->firstPTS = FALSE;
		Info.ValidFields = TIME_STAMP_INFO;
		
		EM8XXXVOIPGP(pE,EMHWLIB_MODULE(STC,audio_decoder_index),RMSTCPropertyID_AudioTimeResolution,&time_resolution,sizeof(time_resolution));
		EM8XXXVOIPEXP(pE, EMHWLIB_MODULE(STC,audio_decoder_index),RMSTCPropertyID_TimeInfo,&time_resolution,sizeof(time_resolution),&time,sizeof(time));
		
		Info.TimeStamp = time;
		pInfo = &Info;
		Info_size = sizeof(Info);
	}
	else {
		pInfo = NULL;
		Info_size = 0;
	}

	param.moduleId = EMHWLIB_MODULE(AudioDecoder,audio_decoder_index);
	param.poolId = pV->decoder_dmapool_id;
	param.dataSize = size;
	param.bus_addr = kdmapool_get_bus_address(pE->pllad,pV->decoder_dmapool_id,pV->decoder_pBuf,param.dataSize);
	kc_flush_cache((void *)param.bus_addr,param.dataSize);

	context =(void *) (((pE-Etable) << 16) + param.poolId + 1);

	err=RM_INSUFFICIENT_SIZE;
	while(err==RM_INSUFFICIENT_SIZE){
		it ++;
		if(it >= 10){
			RMDBGLOG((LOCALDBG,"forced to quit loop \n"));
			return -EINVAL;
		}
	
		kc_spin_lock_bh(pE->lock);
		err = EMhwlibSendBuffer(pE->pemhwlib, param.moduleId, param.bus_addr, param.dataSize, pInfo, Info_size, context);
		kc_spin_unlock_bh(pE->lock);

		if((err != RM_OK) && (err != RM_INSUFFICIENT_SIZE)){
			RMDBGLOG((LOCALDBG,"fatal error while sending buffer. abort, err = %d \n",err));
			return -EINVAL;
		}
	}

	// Release is done by the Send buffer

	pV->decoder_pBuf = NULL;

	return 0;
}

static void em8xxx_voip_timeout(unsigned long private)
{
	struct voipprivate *pV = (struct voipprivate *) private;
	struct em8xxxprivate *pE = Etable + (pV - VOIPtable);
	struct XferFIFOInfo_type xfer_info;
	
	
	em8xxx_voip_check_hookstate(pV);
	em8xxx_voip_check_dtmf(pV);
	
	if(pV->dtmf_enable){
		read_dtmf(pV);
	}

	if(pV->ringing){
		send_ring_tone(pV);
	}

	if(pV->busy){
		send_busy_tone(pV);
	}

	if(pV->ringback){
		send_ringback_tone(pV);
	}

	if(pV->dialtone){
		send_dial_tone(pV);
	}

	EMhwlibGetProperty(pE->pemhwlib,EMHWLIB_MODULE(AudioCapture,audio_capture_index),RMGenericPropertyID_XferFIFOInfo,&xfer_info,sizeof(xfer_info));

	if(xfer_info.Erasable > 0){
		kc_wake_up_interruptible(pV->poll_q);
	}

	EMhwlibGetProperty(pE->pemhwlib,EMHWLIB_MODULE(AudioDecoder,audio_decoder_index),RMGenericPropertyID_XferFIFOInfo,&xfer_info,sizeof(xfer_info));

	if(xfer_info.Writable > 0){
		kc_wake_up_interruptible(pV->poll_q);
	}

	if (pV->exc.bytes) {
		/* Wake any blocked selects */
		kc_wake_up_interruptible(pV->poll_q);
	}
	if(pV->voip_open_count)
		em8xxx_voip_add_timer(pV);
	return;
}

static void em8xxx_voip_init_timer(struct voipprivate *pV)
{
	init_timer(&pV->timer);
	pV->timer.function = em8xxx_voip_timeout;

	pV->timer.data = (unsigned long)pV;
}

static void em8xxx_voip_add_timer(struct voipprivate *pV)
{
	pV->timer.expires = jiffies + pV->check_interval;
	add_timer(&pV->timer);
}


static RMstatus init_audio(struct voipprivate *pV)
{
	struct em8xxxprivate *pE=Etable+(pV-VOIPtable);
	RMstatus err; 
	enum ProcessorState run;
	struct AudioDecoder_DRAMSize_in_type decoder_dram_in;
	struct AudioDecoder_DRAMSize_out_type decoder_dram_out;
	struct AudioDecoder_Open_type decoder_profile; 
	enum AudioDecoder_State_type state;
	struct AudioCapture_DRAMSize_in_type capture_dram_in;
	struct AudioCapture_DRAMSize_out_type capture_dram_out;
	struct AudioCapture_Open_type capture_profile;
	RMuint32 audio_capture=EMHWLIB_MODULE(AudioCapture,audio_capture_index);
	RMuint32 audio_decoder=EMHWLIB_MODULE(AudioDecoder,audio_decoder_index);
	RMuint32 audio_engine=EMHWLIB_MODULE(AudioEngine,audio_engine_index);
	enum AudioEngine_SerialOut_type serialOutStatus;
	struct AudioEngine_SampleFrequencyFromSource_type sf;
	struct AudioEngine_I2SConfig_type i2s;
	enum AudioEngine_SpdifOut_type spdif_out;
	struct AudioEngine_Volume_type volume;
	int i,closed;
	int sampleRate = DEFAULT_SAMPLE_RATE;
	struct AudioDecoder_MixerWeight_type cmdblock;
	struct STC_Open_type stc_open;
	struct MM_Malloc_in_type in;
	struct MM_Malloc_out_type out;
#ifndef WITH_UCODE_BOOTLOADER
	struct DemuxEngine_MicrocodeDRAMSize_in_type demux_size_in;
	struct DemuxEngine_MicrocodeDRAMSize_out_type demux_size_out;
	struct DemuxEngine_Microcode_type demux_ucode;
	RMuint32 demux_engine=EMHWLIB_MODULE(DemuxEngine,0);
	struct AudioEngine_MicrocodeDRAMSize_in_type size_in;
	struct AudioEngine_MicrocodeDRAMSize_out_type size_out;
	struct AudioEngine_Microcode_type ucode;
#endif // WITH_UCODE_BOOTLOADER
	
	RMDBGLOG((LOCALDBG,"initializing audio parameters \n"));
	//  STC Opening

	stc_open.master=Master_STC;
	if(audio_engine_index==0)
		stc_open.stc_timer_id=audio_decoder_index*2;
	else
		if (audio_decoder_index==2)
			stc_open.stc_timer_id=0;
		else
			stc_open.stc_timer_id=2;

	stc_open.stc_time_resolution=90000;
	stc_open.video_timer_id=NO_TIMER;
	stc_open.video_time_resolution=0;
	stc_open.video_offset=0;
	if(audio_engine_index==0)
		stc_open.audio_timer_id=audio_decoder_index*2+1;
	else
		if (audio_decoder_index==2)
			stc_open.audio_timer_id=1;
		else
			stc_open.audio_timer_id=3;
	stc_open.audio_time_resolution=90000;
	stc_open.audio_offset=0;
	

	EM8XXXVOIPSP(pE,EMHWLIB_MODULE(STC,audio_decoder_index),RMSTCPropertyID_Open,&stc_open,sizeof(stc_open));

	if (RMFAILED(err)){
		RMDBGLOG((LOCALDBG,"Error while opening STC Module! \n"));
		return err;
	}
	
	pV->firstPTS = TRUE;

#ifndef WITH_UCODE_BOOTLOADER
	// Loading Demux module
	
 	run = CPU_RESET;

	EM8XXXVOIPSP(pE, demux_engine, RMDemuxEnginePropertyID_State, &run, sizeof(run));

	if (RMFAILED(err)){
		RMDBGLOG((ENABLE, "Error while resetting CPU! \n"));
		return err;
	}

       
	run = CPU_STOPPED;

	EM8XXXVOIPSP(pE, demux_engine, RMDemuxEnginePropertyID_State, &run, sizeof(run));

	if (RMFAILED(err)){
		RMDBGLOG((ENABLE, "Error while stopping CPU! \n"));
		return err;
	}
	
	// Loading Microcode for Demux Module
	
	demux_size_in.MicrocodeVersion = 1;

	EM8XXXVOIPEXP(pE, demux_engine, RMDemuxEnginePropertyID_MicrocodeDRAMSize,
		     &demux_size_in, sizeof(demux_size_in), &demux_size_out, sizeof(demux_size_out));
	
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting property RMDemuxEnginePropertyID_MicrocodeDRAMSize! %s\n"));
		return err;
	}
	
	demux_ucode.MicrocodeVersion = demux_size_in.MicrocodeVersion;
	
	if (demux_size_out.Size){
		in.dramtype=RUA_DRAM_CACHED;
		in.Size=demux_size_out.Size;
	
		EM8XXXVOIPEXP(pE,
			     EMHWLIB_MODULE(MM,0),
			     RMMMPropertyID_Malloc,
			     &in,sizeof(in),
			     &out,sizeof(out));
		if(err==RM_OK) 
			demux_ucode.Address= (RMuint32)out.Address;
		else {
			RMDBGLOG((ENABLE," memory manager not existent\n"));
			return 0;
		}
			
		RMDBGLOG((ENABLE, "demux ucode cached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n", demux_ucode.Address, demux_size_out.Size, demux_ucode.Address + demux_size_out.Size));
	}
	else {
		demux_ucode.Address = 0;
		RMDBGLOG((ENABLE, "demux ucode doesn't need DRAM\n"));
	}

	EM8XXXVOIPSP(pE, demux_engine, RMDemuxEnginePropertyID_Microcode, &demux_ucode, sizeof(demux_ucode));

	if (RMFAILED(err)){
		RMDBGLOG((ENABLE, "Error while loading microcode for Demux Module! \n"));
		return err;
	}


	// starting the DemuxEngine Module
	
	run = CPU_RUNNING;

	EM8XXXVOIPSP(pE, demux_engine, RMDemuxEnginePropertyID_State, &run, sizeof(run));

	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error setting property DemuxEngineProperty_State! \n"));
		return err;
	}
	

	// Loading AudioEngine Module

	run = CPU_RESET;

	EM8XXXVOIPSP(pE, audio_engine, RMAudioEnginePropertyID_State, &run, sizeof(run));

	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error while resetting CPU! \n"));
		return err;
	}
	
	run = CPU_STOPPED;

	EM8XXXVOIPSP(pE, audio_engine, RMAudioEnginePropertyID_State, &run, sizeof(run));
	
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error while stopping CPU! \n"));
		return err;
	} 
	
	// Loading MicroCode for AudioEngine Module


	size_in.MicrocodeVersion = 1;
	
	// memory allocation for the microcode

	EM8XXXVOIPEXP( pE, audio_engine, RMAudioEnginePropertyID_MicrocodeDRAMSize, &size_in, sizeof(size_in), &size_out, sizeof(size_out));

	if (RMFAILED(err)) { 
		RMDBGLOG((ENABLE, "Error while allocating memory for audio microcode! \n"));
		return err;
	} 

	ucode.MicrocodeVersion = size_in.MicrocodeVersion;
	
	in.dramtype=RUA_DRAM_CACHED;
	in.Size=size_out.Size;
	

	EM8XXXVOIPEXP(pE,
		     EMHWLIB_MODULE(MM,0),
		     RMMMPropertyID_Malloc,
		     &in,sizeof(in),
		     &out,sizeof(out));
	if(err==RM_OK) 
		ucode.Address= (RMuint32)out.Address;
	else {
		RMDBGLOG((ENABLE," memory manager not existent\n"));
		return 0;
	}
	
	RMDBGLOG((LOCALDBG,"audio ucode cached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
	       ucode.Address,
	       size_out.Size,
	       ucode.Address + size_out.Size));
	
	pV->AudioUCodeAddr = ucode.Address;
	
	//  microcode loading

	EM8XXXVOIPSP( pE, audio_engine, RMAudioEnginePropertyID_Microcode, &ucode, sizeof(ucode));

	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error while loading audio microcode! \n"));
       		return err;
	} 
#endif // WITH_UCODE_BOOTLOADER

	// starting the Audio RISC 
	
	run = CPU_RUNNING;

	EM8XXXVOIPSP(pE, audio_engine, RMAudioEnginePropertyID_State, &run, sizeof(run));

	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error while starting CPU! \n"));
		return err;
	}

	
	// Volume Initialization
	for (i = 0; i <= 9; i++){
		volume.Channel = i;
		volume.Volume = 0x01965fea; // -20 dB //0x10000000;
	
		EM8XXXVOIPSP(pE, audio_engine, RMAudioEnginePropertyID_Volume, &volume, sizeof(volume));
	
		if (RMFAILED(err)){
			RMDBGLOG((ENABLE, "Error while setting audio volume! \n"));
			return err;
		}
	}
	
	pV->volume = 70 + (70<<8);
	// Mixer weight initialization
	cmdblock.MixerValue_ch0=0x10000000;
	cmdblock.MixerValue_ch1=0x10000000;
	cmdblock.MixerValue_ch2=0x10000000;
	cmdblock.MixerValue_ch3=0x10000000;
	cmdblock.MixerValue_ch4=0x10000000;
	cmdblock.MixerValue_ch5=0x10000000;
	cmdblock.MixerValue_ch6=0x10000000;
	cmdblock.MixerValue_ch7=0x10000000;
	EM8XXXVOIPSP( pE, audio_decoder,RMAudioDecoderPropertyID_MixerWeight,&cmdblock,sizeof(cmdblock));
	      
	pV->weight = 70 + (70<<8);

	// We have to know if the other decoder is working

	closed=1;

#ifdef RMFEATURE_HAS_AUDIO_ENGINE_1
	switch(audio_engine_index){
	case 0:
		EM8XXXVOIPGP(pE,EMHWLIB_MODULE(AudioDecoder,1-audio_decoder_index),RMAudioDecoderPropertyID_State,&state,sizeof(state));
		if (state != AudioDecoder_State_Closed) closed=0;
		break;
	case 1:
		if (audio_decoder_index==2){
			EM8XXXVOIPGP(pE,EMHWLIB_MODULE(AudioDecoder,3),RMAudioDecoderPropertyID_State,&state,sizeof(state));
		}
		else
			EM8XXXVOIPGP(pE,EMHWLIB_MODULE(AudioDecoder,2),RMAudioDecoderPropertyID_State,&state,sizeof(state));
		if (state != AudioDecoder_State_Closed) closed=0;
		break;
	}
	
#else
	EM8XXXVOIPGP(pE,EMHWLIB_MODULE(AudioDecoder,1-audio_decoder_index),RMAudioDecoderPropertyID_State,&state,sizeof(state));
	if (state != AudioDecoder_State_Closed) closed=0;
	
#endif // RMFEATURE_HAS_AUDIO_ENGINE_1		
	
	if(closed==1){
	
		// Setting the sample freqency
		
		
		EM8XXXVOIPSP(pE, audio_engine, RMAudioEnginePropertyID_SampleFrequency, &sampleRate, sizeof(sampleRate));
		
		if (RMFAILED(err)){
			RMDBGLOG((LOCALDBG,"Error while setting the sample frequency\n"));
			return err;
		}
		
		// Applying AudioEngine Module Options
		
		spdif_out = AudioEngine_SpdifOut_Active;
		
		EM8XXXVOIPSP(pE, audio_engine, RMAudioEnginePropertyID_SpdifOut, &spdif_out, sizeof(spdif_out));
		
		if (RMFAILED (err)) {
			RMDBGLOG((ENABLE, "Error setting spdif_out property! \n"));
			return err;
		}
		
		
		sf.GeneratorNumber = 3;
		sf.SampleFrequency = sampleRate;
		sf.Source = 1;
		sf.SourceFrequency = 27000000;
		sf.IntermediateFrequency = 148500000;
		
		EM8XXXVOIPSP(pE, audio_engine, RMAudioEnginePropertyID_SampleFrequencyFromSource, &sf, sizeof(sf));
		
		if (RMFAILED (err)) {
			RMDBGLOG((ENABLE, "Error setting sf property! \n"));
			return err;
		}
		
		
		i2s.DataAlignment = 1;
		i2s.SClkInvert = TRUE;
		i2s.FrameInvert = TRUE;
		i2s.MSBFirst = TRUE;
		i2s.SampleSize16Bit = FALSE;
		
		EM8XXXVOIPSP(pE, audio_engine, RMAudioEnginePropertyID_I2SConfig, &i2s, sizeof(i2s));
		
		if (RMFAILED (err)) {
			RMDBGLOG((ENABLE, "Error setting i2s property! \n"));
			return err;
		}
		
		
		serialOutStatus = AudioEngine_SerialOut_SO_ENABLE;
		
		EM8XXXVOIPSP(pE, audio_engine, RMAudioEnginePropertyID_SerialOut, &serialOutStatus, sizeof(serialOutStatus));
		
		if (RMFAILED (err)) {
			RMDBGLOG((ENABLE, "Error setting serialOut property! \n"));
			return err;
		}
	}	
	
	// Get the information for DRAM parameters for AudioDecoder Module
	
	decoder_dram_in.MaxChannelOutCount = MAXCHANNELOUTCOUNT;
	decoder_dram_in.PCMLineCount = PCMLINECOUNT;
	decoder_dram_in.BitstreamFIFOSize = BTS_FIFO_SIZE;//4*(1024);//(1<<AUDIO_DMA_BUFFER_SIZE_LOG2) * AUDIO_DMA_BUFFER_COUNT;
	decoder_dram_in.XferFIFOCount = AUDIO_DMA_BUFFER_COUNT;

	// Memory allocation for AudioDecoder Module


	EM8XXXVOIPEXP(pE, audio_decoder, RMAudioDecoderPropertyID_DRAMSize, &decoder_dram_in, sizeof(decoder_dram_in), &decoder_dram_out, sizeof(decoder_dram_out));
	
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "No memory available for Audio RISC Processor! \n"));
		return err;
	}

	
	// Creation of the audio profile
	
	decoder_profile.MaxChannelOutCount = decoder_dram_in.MaxChannelOutCount;
	decoder_profile.PCMLineCount = decoder_dram_in.PCMLineCount;
	decoder_profile.BitstreamFIFOSize = decoder_dram_in.BitstreamFIFOSize;
	decoder_profile.XferFIFOCount = decoder_dram_in.XferFIFOCount;
	decoder_profile.CachedSize = decoder_dram_out.CachedSize;
	if (decoder_profile.CachedSize > 0){
		in.dramtype=RUA_DRAM_CACHED;
		in.Size=decoder_profile.CachedSize;
	
		EM8XXXVOIPEXP(pE,
			     EMHWLIB_MODULE(MM,0),
			     RMMMPropertyID_Malloc,
			     &in,sizeof(in),
			     &out,sizeof(out));
		if(err==RM_OK)
			decoder_profile.CachedAddress= (RMuint32)out.Address;
		else {
			RMDBGLOG((ENABLE," memory manager not existent\n"));
			return 0;
		}
	
	
		RMDBGLOG((LOCALDBG,"audio cached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
		       decoder_profile.CachedAddress,
		       decoder_profile.CachedSize,
		       decoder_profile.CachedAddress + decoder_profile.CachedSize));
	}
	else { decoder_profile.CachedAddress = 0; }
	
	pV->AudioProfileCachedAddr = decoder_profile.CachedAddress;
	decoder_profile.UncachedSize = decoder_dram_out.UncachedSize;
	if (decoder_profile.UncachedSize > 0){
		in.dramtype=RUA_DRAM_UNCACHED;
		in.Size=decoder_profile.UncachedSize;
	
		EM8XXXVOIPEXP(pE,
			     EMHWLIB_MODULE(MM,0),
			     RMMMPropertyID_Malloc,
			     &in,sizeof(in),
			     &out,sizeof(out));
		if(err==RM_OK)
			decoder_profile.UncachedAddress = (RMuint32)out.Address;
		else {
			RMDBGLOG((ENABLE," memory manager not existent\n"));
			return 0;
		}
	
		RMDBGLOG((LOCALDBG,"audio uncached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
		       decoder_profile.UncachedAddress,
		       decoder_profile.UncachedSize,
		       decoder_profile.UncachedAddress + decoder_profile.UncachedSize));
	}
	else { decoder_profile.UncachedAddress = 0; }

	pV->AudioProfileUncachedAddr = decoder_profile.UncachedAddress;
	decoder_profile.DemuxProgramId = audio_decoder_index;
	decoder_profile.TimerId = audio_decoder_index;
	

	EM8XXXVOIPSP(pE, audio_decoder, RMAudioDecoderPropertyID_Open, &decoder_profile, sizeof(decoder_profile));

	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error while creating audio profile! \n"));
		return err;
	}
	

	// Get the information for DRAM parameters for AudioCapture Module 

	capture_dram_in.SerialInFIFOSize = SERIALIN_FIFO_SIZE; 
	capture_dram_in.XferFIFOCount = SERIALIN_DMA_BUFFER_COUNT;

	// Memory allocation for AudioCapture Module

	EM8XXXVOIPEXP(pE, audio_capture, RMAudioCapturePropertyID_DRAMSize, &capture_dram_in, sizeof(capture_dram_in), &capture_dram_out, sizeof(capture_dram_out));

	// Creation of the audio capture profile

	capture_profile.CaptureMode = 0; // File mode
	capture_profile.Delay=0;
	capture_profile.SI_CONF=0x107 | (1 << 3);
	capture_profile.SerialInFIFOSize = capture_dram_in.SerialInFIFOSize;
	capture_profile.XferFIFOCount = capture_dram_in.XferFIFOCount;
	capture_profile.CachedSize = capture_dram_out.CachedSize;
	
	if (capture_profile.CachedSize > 0){
		in.dramtype=RUA_DRAM_CACHED;
		in.Size=capture_profile.CachedSize;
		
		EM8XXXVOIPEXP(pE,
			     EMHWLIB_MODULE(MM,0),
			     RMMMPropertyID_Malloc,
			     &in,sizeof(in),
			     &out,sizeof(out));
		if(err==RM_OK) 
			capture_profile.CachedAddress= (RMuint32)out.Address;
		else {
			RMDBGLOG((ENABLE," memory manager not existent\n"));
			return 0;
		}
	
		RMDBGLOG((LOCALDBG,"audio capture cached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
		       capture_profile.CachedAddress,
		       capture_profile.CachedSize,
 		       capture_profile.CachedAddress + capture_profile.CachedSize));
	}
	else { capture_profile.CachedAddress = 0; }
	
	pV->SerialinProfileCachedAddr = capture_profile.CachedAddress;
	
	capture_profile.UncachedSize = capture_dram_out.UncachedSize;
	if (capture_profile.UncachedSize > 0){
		in.dramtype=RUA_DRAM_UNCACHED;
		in.Size=capture_profile.UncachedSize;
		
	
		EM8XXXVOIPEXP(pE,
			     EMHWLIB_MODULE(MM,0),
			     RMMMPropertyID_Malloc,
			     &in,sizeof(in),
			     &out,sizeof(out));
		if(err==RM_OK) 
			capture_profile.UncachedAddress = (RMuint32)out.Address;
		else {
			RMDBGLOG((ENABLE," memory manager not existent\n"));
			return 0;
		}
	
		RMDBGLOG((LOCALDBG,"audio capture uncached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
		       capture_profile.UncachedAddress,
		       capture_profile.UncachedSize,
		       capture_profile.UncachedAddress + capture_profile.UncachedSize));
	}
	else { capture_profile.UncachedAddress = 0; }

	pV->SerialinProfileUncachedAddr = capture_profile.UncachedAddress;

	EM8XXXVOIPSP(pE, audio_capture, RMAudioCapturePropertyID_Open, &capture_profile, sizeof(capture_profile));
	
	pV->prepared = FALSE;
	pV->capture_enable = FALSE;
	pV->playback_enable = FALSE;
	return RM_OK;  
}

static RMstatus start_capture(struct em8xxxprivate *pE)
{
	enum AudioCapture_Capture_type cmd;
	struct voipprivate *pV = VOIPtable + (pE-Etable);
	RMstatus err;
	RMuint32 audio_capture = EMHWLIB_MODULE(AudioCapture,audio_capture_index);

	RMDBGLOG((LOCALDBG,"start capture \n"));
	
	//  Enabling audio capture
	cmd = AudioCapture_Capture_On;
	EM8XXXVOIPSP(pE, audio_capture,RMAudioCapturePropertyID_Capture, &cmd, sizeof(cmd));

	pV->capture_enable = TRUE;
 
	return err;
}

static RMstatus start_playback(struct em8xxxprivate *pE)
{
	struct voipprivate *pV = VOIPtable + (pE-Etable);
	enum AudioDecoder_Command_type command;
	RMuint32 audio_decoder = EMHWLIB_MODULE(AudioDecoder,audio_decoder_index);
	RMstatus err=RM_OK;
	enum AudioDecoder_State_type state;
	struct STC_Speed_type speed;
	RMuint32 AudioBtsThreshold=AUDIO_BTS_THRESHOLD;
	int rc;
  	long timeout;
	long timeout_jiffies = (unsigned long long) 100000*(unsigned long long)HZ/1000000ULL; //10^-1 sec
	
	EM8XXXVOIPSP(pE,audio_decoder, RMAudioDecoderPropertyID_AudioBtsThreshold, &AudioBtsThreshold,sizeof(RMuint32));

	// Change the decoder status to Play Mode
	
	command = AudioDecoder_Command_Play;

	EM8XXXVOIPSP(pE, audio_decoder, RMAudioDecoderPropertyID_Command, &command, sizeof(command));

	if (RMFAILED(err)){
		RMDBGLOG((ENABLE, "Error while sending Play command to Audio Decoder! \n"));
		return err;
	}
	else RMDBGLOG((LOCALDBG,"play command sended to the audio decoder \n"));
	timeout=0;
	while (timeout < 100000) {
		EM8XXXVOIPGP(pE, audio_decoder,RMAudioDecoderPropertyID_State, &state, sizeof(state));
		if (state == AudioDecoder_State_Playing)
			break;
		timeout += kc_interruptible_sleep_on_timeout(pE->wq,timeout_jiffies);
		if (signal_pending(current)) {
			rc=-ERESTARTSYS;
			break;
		}
	}
	
	// start STC
	
	speed.nominator = 1;
	speed.denominator = 1;
	
	EM8XXXVOIPSP(pE, EMHWLIB_MODULE(STC,audio_decoder_index), RMSTCPropertyID_Speed, &speed, sizeof(speed));
	
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error while setting STC speed! \n"));
		return err;
	}

	EM8XXXVOIPSP(pE, EMHWLIB_MODULE(STC,audio_decoder_index), RMSTCPropertyID_Play, NULL, 0);

	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error while sending Play command to STC! \n"));
			return err;
	}

	pV->playback_enable = TRUE;
	return err;
}

static RMstatus set_audio_parameters(struct voipprivate *pV)
{
	struct em8xxxprivate *pE=Etable+(pV-VOIPtable);
	int rc;
       	long timeout;
	long timeout_jiffies = (unsigned long long) 100000*(unsigned long long)HZ/1000000ULL; //10^-1 sec
	enum AudioDecoder_Command_type command;
	enum AudioDecoder_Codec_type codec;
	RMuint32 audio_decoder = EMHWLIB_MODULE(AudioDecoder,audio_decoder_index);
	RMstatus err;
	struct AudioDecoder_PcmCdaParameters_type pcm_parameters;
	enum AudioDecoder_State_type state;
	int sampleRate = DEFAULT_SAMPLE_RATE;
	int channelCount = DEFAULT_CHANNEL_COUNT;

	if (!pV->nb_bits_per_sample)
		return 0;
	
	//   Uninit
	timeout = 0;
	command = AudioDecoder_Command_Uninit;

	EM8XXXVOIPSP(pE,audio_decoder,RMAudioDecoderPropertyID_Command,&command,sizeof(command));

	if (RMFAILED(err)){
		RMDBGLOG((ENABLE, "Unable to Uninit \n"));
		return err;
	}
	while (timeout < 1000000) {
		
		EM8XXXVOIPGP(pE, audio_decoder,RMAudioDecoderPropertyID_State, &state, sizeof(state));
		
		if (state == AudioDecoder_State_Uninitialized)
			break;
		timeout += kc_interruptible_sleep_on_timeout(pE->wq,timeout_jiffies);
		if (signal_pending(current)) {
			rc=-ERESTARTSYS;
			break;
		}
	}
	if (timeout >= 1000000) {
		RMDBGLOG((ENABLE, "Error setting uninit state! \n"));
		return -EINVAL;
	}

	//  Format

	codec = DEFAULT_CODEC;

	EM8XXXVOIPSP(pE, audio_decoder, RMAudioDecoderPropertyID_Codec, &codec, sizeof(codec));

	if (RMFAILED(err)){
		RMDBGLOG((ENABLE, "Error setting codec property! \n"));
		return err;
	}

	// PCM Parameters
	
	pcm_parameters.ChannelAssign = PcmCda1_C;
	pcm_parameters.BitsPerSample = pV->nb_bits_per_sample;
	pcm_parameters.SamplingFrequency = sampleRate;
	pcm_parameters.MsbFirst = TRUE;
	pcm_parameters.OutputDualMode = DualMode_Stereo;
	pcm_parameters.OutputSpdif = OutputSpdif_Disable;
	pcm_parameters.OutputChannels = Audio_Out_Ch_LR;
	pcm_parameters.OutputLfe = FALSE;
	pcm_parameters.SignedPCM = (pV->nb_bits_per_sample==16) ? TRUE : FALSE;
	pcm_parameters.BassMode = 0;
	

	EM8XXXVOIPSP(pE, audio_decoder, RMAudioDecoderPropertyID_PcmCdaParameters, &pcm_parameters, sizeof(pcm_parameters));

	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error setting pcm parameters! \n"));
	}
	
	//Init

	command = AudioDecoder_Command_Init;

	EM8XXXVOIPSP(pE, audio_decoder, RMAudioDecoderPropertyID_Command, &command, sizeof(command));

	if (RMFAILED(err)){
		RMDBGLOG((ENABLE, "Error while initializing audio decoder! \n"));
		return err;
	}
	timeout =0;
	while (timeout < 1000000) {
		static RMuint32 count = 0;
	
		EM8XXXVOIPGP(pE, audio_decoder,RMAudioDecoderPropertyID_State, &state, sizeof(state));
		if (state == AudioDecoder_State_Stopped)
			break;
		kc_interruptible_sleep_on_timeout(pE->wq,US_TO_JIFFIES(10000));
		timeout += 10000;
		count ++;
		RMDBGLOG((LOCALDBG,"count : %lu, timeout = %ld\n", count, timeout));
		if (signal_pending(current)) {
			rc=-ERESTARTSYS;
			break;
		}
	}
	if (timeout >= 1000000) {
		RMDBGLOG((ENABLE, "Error setting init state! \n"));
		return -EINVAL;
	}

	pV->prepared = TRUE;
	RMDBGLOG((LOCALDBG,"audio parameters are set : samplerate = %d, nb_bits_per_sample = %ld, channelcount = %d\n", sampleRate,pV->nb_bits_per_sample, channelCount));
	
	// Initialize the AEC context

/* 	RMaec_open(pV->pAEC); */

	return err;
}

static void stop_capture(struct em8xxxprivate *pE)
{
	enum AudioCapture_Capture_type cmd;
	struct voipprivate *pV = VOIPtable + (pE-Etable);
	RMstatus err;
	RMuint32 audio_capture = EMHWLIB_MODULE(AudioCapture,audio_capture_index);

	cmd = AudioCapture_Capture_Off;
	EM8XXXVOIPSP(pE, audio_capture,RMAudioCapturePropertyID_Capture, &cmd, sizeof(cmd));

	if (pV->capture_pBuf != NULL){
		struct ReadBufferInfo prop;
		
		prop.address = pV->capture_buffer_bus_addr;
		prop.size = pV->capture_buffer_size;
		
		prop.context = (void *) ((pE-Etable) + pV->capture_dmapool_id + 1);
		EM8XXXVOIPSP(pE,audio_capture, RMGenericPropertyID_AddReadBuffer, &prop, sizeof(prop));
		if(RMFAILED(err)){
			RMDBGLOG((LOCALDBG,"error %d while adding read buffer \n"));
			kdmapool_release(pE->pllad,pV->capture_dmapool_id,prop.address);
		}
	}
	
	pV->i_start=0;
	pV->j_start=0;
	pV->last_i=0;
	pV->last_j=0;
	pV->capture_readable=0;
	pV->capture_pBuf=NULL;
	pV->capture_buffer_size=0;
	pV->capture_read=0;
	pV->capture_enable = FALSE;
	pV->dtmf_offset = 0;
	pV->dtmf_decoded = 0;
	pV->last_ch = 0;
	pV->dup_ch = 0;
	pV->state = 0;
	pV->aec_fifo_ready = FALSE;
	pV->aec_skip_count = 0;
	pV->aec_skip_offset = 0;
	pV->aec_rd_count=0;


/* 	RMaec_close(pV->pAEC); */
	prepare_data(pV);

	return;
}

static RMstatus prepare_data(struct voipprivate *pV)
{
	struct em8xxx_data param;
	struct em8xxxprivate *pE = Etable + (pV-VOIPtable);
	RMuint8 *buffer=NULL;
	RMuint32 timeout = 0;
	RMstatus err=RM_OK;
	RMuint32 audio_capture = EMHWLIB_MODULE(AudioCapture,audio_capture_index);
	struct ReadBufferInfo prop;
	RMuint32 nb_buf = 0;

	while (1) {
		
		timeout=0;

		buffer=kdmapool_getbuffer(pE->pllad,pV->capture_dmapool_id,&timeout);
				
		if (buffer==NULL){
			break;
		}	
		nb_buf ++;
	
		param.moduleId = audio_capture;
		param.poolId = pV->capture_dmapool_id;
		param.bus_addr = kdmapool_get_bus_address(pE->pllad,pV->capture_dmapool_id,buffer, 0);
		param.dataSize = FRAME_SIZE_24B2C;
		
		prop.address = param.bus_addr;
		prop.size = param.dataSize;
		prop.context = (void *) ((pE-Etable) + param.poolId + 1);
		err=EMhwlibSetProperty(pE->pemhwlib, param.moduleId, RMGenericPropertyID_AddReadBuffer, &prop, sizeof(prop));
		if(RMFAILED(err)){
			RMDBGLOG((ENABLE,"Cannot prepare data for this buffer \n"));
			kdmapool_release(pE->pllad,pV->capture_dmapool_id,prop.address);
		}

		buffer=NULL;
	}
	
	RMDBGLOG((LOCALDBG,"prepared %ld buffers \n",nb_buf));
	return err;
	
}

static int rm_free_ptr(struct em8xxxprivate *pE,RMuint32 ptr)
{
	RMuint32 dramIndex=0xffffffff;
	RMstatus err;
	
	if ((MEM_BASE_dram_controller_0<=ptr)&&(ptr<MEM_BASE_dram_controller_1)) dramIndex=0;
	if ((MEM_BASE_dram_controller_1<=ptr)&&(ptr<MEM_BASE_dram_controller_1+(512*1024*1024))) dramIndex=1;

	if (dramIndex<=1) {
		EM8XXXVOIPSP(pE,
			    EMHWLIB_MODULE(MM,dramIndex),
			    RMMMPropertyID_Free,
			    (void *)(&ptr),sizeof(void *));
		if(err!=RM_OK) 
			RMDBGLOG((ENABLE,"rm_ptr_free: pointer 0x%08lx cannot be freed\n",ptr));
	}
	else
		RMDBGLOG((ENABLE,"rm_ptr_free: pointer %p not in a dram controller\n",ptr));
	
	return 0;
}

static RMstatus cleanup_audio(struct voipprivate *pV)
{
	RMuint32 profile;
	struct em8xxxprivate *pE = Etable +(pV-VOIPtable);
	RMstatus err;
	RMuint32 bus_addr;

	// close audio decoder pool

	if(pV->decoder_pBuf != NULL){
		
		bus_addr = kdmapool_get_bus_address(pE->pllad,pV->decoder_dmapool_id,pV->decoder_pBuf,0);
		kdmapool_release(pE->pllad,pV->decoder_dmapool_id,bus_addr);
	}
	
	kdmapool_close(pE->pllad,pV->decoder_dmapool_id);

	// close audio profile

	profile=0;

	EM8XXXVOIPSP(pE,EMHWLIB_MODULE(AudioDecoder,audio_decoder_index), RMAudioDecoderPropertyID_Close, &profile, sizeof(profile));
	EM8XXXVOIPSP(pE,EMHWLIB_MODULE(AudioCapture,audio_capture_index), RMAudioCapturePropertyID_Close, &profile, sizeof(profile));

	kdmapool_close(pE->pllad,pV->capture_dmapool_id);

	// close STC
	
	EM8XXXVOIPSP(pE,EMHWLIB_MODULE(STC,audio_decoder_index),RMSTCPropertyID_Close, NULL,sizeof(RMuint32));

	// free resources
#ifndef WITH_UCODE_BOOTLOADER	
	rm_free_ptr (pE,pV->AudioUCodeAddr);
#endif //  WITH_UCODE_BOOTLOADER
	rm_free_ptr (pE,pV->AudioProfileCachedAddr);
	rm_free_ptr (pE,pV->AudioProfileUncachedAddr);
	rm_free_ptr (pE,pV->SerialinProfileCachedAddr);
	rm_free_ptr (pE,pV->SerialinProfileUncachedAddr);

	return RM_OK;
}

static int em8xxx_voip_open(struct phone_device *p, struct file *file_p)
{
	struct voipprivate *pV = VOIPtable + p->board;

	file_p->private_data = pV;
	
	RMDBGLOG((LOCALDBG,"open pV = %p \n",pV));

	pV->voip_open_count++;

	if(pV->voip_open_count==1)
		em8xxx_voip_add_timer(pV);
	

	RMDBGLOG((LOCALDBG,"Em8xxx VOIP Opening board %d\n", pV->board));

	
	return 0;
}

static ssize_t em8xxx_voip_read(struct file * file_p, char *buf, size_t length,loff_t * ppos)
{
	RMstatus rc,err;
	RMuint32 audio_capture = EMHWLIB_MODULE(AudioCapture,audio_capture_index);
	struct em8xxx_data param;
	void *context;
	RMuint8 info[INFO_SIZE];
	RMuint32 infoSize = INFO_SIZE;
	size_t to_read;
	struct voipprivate *pV=(struct voipprivate *) file_p->private_data;
	struct em8xxxprivate *pE=Etable+(pV-VOIPtable);
	struct ReadBufferInfo prop;
	RMuint32 event_mask;
	RMuint32 samples;
	RMint32 i,j;
	samples = bytes_to_samples(pV,length);
	to_read = samples * 6; // in the microcode we capture in 24 bits, 2 channels.
	RMint32 k,l;
	int ch;
	RMuint8 *aec_rd1;
	RMuint8 *aec_rd2;
	RMuint32 aec_readable,aec_rdsize1;

	if(!pV->voip_open_count){
		return -EINVAL;
	}

	if(!pV->capture_enable){
		return 1;
	}
	

/* 	/\* Skip the first read samples to wait for the bts fifo to be consumed *\/ */

/* 	if ((pV->aec_skip_count < pV->aec_fifo_skip) && pV->write_ready){ */

/* 		pV->aec_skip_count += length; */
/* 		if (pV->aec_skip_count >= pV->aec_fifo_skip){ */
/* 			pV->aec_fifo_ready = TRUE; */
/* 			pV->first_aec=TRUE; */
/* 			pV->delay=0; */
/* 			pV->aec_skip_offset = pV->aec_skip_count - pV->aec_fifo_skip; */
/* 			pV->aec_skip_offset = FRAME_SIZE - pV->aec_skip_offset; */
/* 			RMDBGLOG((ENABLE,"aec_skip_offset = %d \n",pV->aec_skip_offset)); */
/* 		}		 */
/* 	} */

	/* Main loop : Convert captured samples from 24 bits two channels to 16 bit one channel */

	while(1){
		
		RMuint32 it=0;

		if(pV->capture_pBuf == NULL){
			
			/* Receive buffer */

			param.moduleId = audio_capture;
			param.poolId = pV->capture_dmapool_id;
			param.infoSize = infoSize;

			err=RM_INSUFFICIENT_SIZE;
			while(err==RM_INSUFFICIENT_SIZE){
				it ++;
				if(it >= 10){
					return -EINVAL;
				}

				kc_spin_lock_bh(pE->lock);
				err=EMhwlibReceiveBuffer(pE->pemhwlib, param.moduleId, &(param.bus_addr), &(param.dataSize), info, &(param.infoSize), &context);
				kc_spin_unlock_bh(pE->lock);
				if((err != RM_OK) && (err != RM_INSUFFICIENT_SIZE)){
					RMDBGLOG((LOCALDBG,"fatal arror while receiving buffer. abort, err = %d \n",err));
					return -EINVAL;
				}
				
				if(err == RM_INSUFFICIENT_SIZE){
					rc=kc_interruptible_sleep_on_timeout(pV->read_q,US_TO_JIFFIES(RECEIVEDATA_TIMEOUT_US));
				}
			}
			
			event_mask = SOFT_IRQ_EVENT_XFER_RECEIVE_READY;
			kc_spin_lock_bh(pE->lock);
			rc=EMhwlibSetProperty(pE->pemhwlib,audio_capture,RMGenericPropertyID_ClearEventMask,&event_mask, sizeof(event_mask));
			kc_spin_unlock_bh(pE->lock);


			pV->capture_buffer_bus_addr = param.bus_addr;
			pV->capture_pBuf=kdmapool_get_virt_address(pE->pllad,pV->capture_dmapool_id,pV->capture_buffer_bus_addr, 0);
			pV->capture_buffer_size = param.dataSize;
			pV->capture_readable = param.dataSize;
			pV->capture_read=0;
			pV->i_start = 0;
			
		       			
		}
		
		else {
			pV->i_start = pV->last_i;
		}
		
		pV->j_start = pV->last_j;
		
		i=pV->i_start;
		j=pV->j_start;
		RMDBGLOG((DISABLE,"i = %ld , j = %ld \n, nb_bits_per_sample = %ld, channel_count = 1 \n",i,j,pV->nb_bits_per_sample));

		while (j<length){
			
			if(i>=pV->capture_buffer_size){
				break;
			}
			
			switch(pV->state){
			case 0:
				if(audioin_channel=="L"){
					if(pV->nb_bits_per_sample==8)
						buf[j]=pV->capture_pBuf[i]+128;
					else
						buf[j]=pV->capture_pBuf[i];
					j++;
				}
				break;
		
			case 1:
				if(audioin_channel=="L"){
					if(pV->nb_bits_per_sample==16){
						buf[j]=pV->capture_pBuf[i];
						j++;
					}
				}
				break;
			case 3:
				if(audioin_channel=="R"){
					if(pV->nb_bits_per_sample==8)
						buf[j]=pV->capture_pBuf[i]+128;
					else
						buf[j]=pV->capture_pBuf[i];
					j++;
				}
				break;
		
			case 4:
				if(audioin_channel=="R"){
					if(pV->nb_bits_per_sample==16){
						buf[j]=pV->capture_pBuf[i];
						j++;
					}
				}
				break;
			default:
				break;
			}
			
			i++;
			pV->state ++;
			pV->state %= 6;
			RMDBGLOG((DISABLE,"pV->state = %d \n",pV->state));
		}
		
		
		pV->last_i = i;
		pV->last_j = j;
		
		if (i >= pV->capture_buffer_size){
		
			prop.address = pV->capture_buffer_bus_addr;
			prop.size = pV->capture_buffer_size;

			prop.context = (void *) ((pE-Etable) + pV->capture_dmapool_id + 1);
			EM8XXXVOIPSP(pE,audio_capture, RMGenericPropertyID_AddReadBuffer, &prop, sizeof(prop));
			if(RMFAILED(err)){
				RMDBGLOG((LOCALDBG,"error %d while adding read buffer \n"));
				kdmapool_release(pE->pllad,pV->capture_dmapool_id,prop.address);
			}
			pV->capture_pBuf = NULL;
			
		}

		if (j == length){
			pV->last_j = 0;
			break;
		}
		
	}
	
	/* Byte-swap the samples if necessary */

 	if(pV->nb_bits_per_sample==16){
 		RMuint32 l;
 		RMint8 temp;
 		for (l=0;l<length;l+=2){
 			temp = buf[l];
 			buf[l] = buf[l+1];
 			buf[l+1] = temp;
 		}
	}


/* 	/\* Process Echo cancellation on the buffer *\/ */

/*  	if(pV->aec_fifo_ready){ */

/* 		aec_rd1 = pV->aec_fifo + pV->aec_rd; */
		
/* 		if (pV->aec_wr >= pV->aec_rd) { */
/* 			aec_rdsize1 = pV->aec_wr - pV->aec_rd; */
/* 			aec_rd2 = 0; */
/* 			aec_readable = aec_rdsize1; */
/* 		} */
/* 		else { */
/* 			aec_rdsize1 = pV->aec_size - pV->aec_rd; */
/* 			aec_rd2 = pV->aec_fifo; */
/* 			aec_readable = aec_rdsize1 + pV->aec_wr; */
/* 		} */
		
/* 		if(pV->first_aec){ */
/* 			RMuint32 count = length - pV->aec_skip_offset; */
/* 			//we still have to skip pV->aec_skip_offset */
/* 			pV->first_aec=FALSE; */
			
/* 			if(aec_readable >= count){ */
/* 				if(aec_rdsize1 >= count){ */
/* 					RMDBGLOG((AEC_DBG,"processing one buffer...\n")); */
					
/* 					RMaec_process_buffer(pV->pAEC,pV->aec_fifo+pV->aec_rd,buf+pV->aec_skip_offset,pV->aec_out,count); */
					
/* 					RMDBGLOG((AEC_DBG,"aec_rd = %d , length = %d\n",pV->aec_rd,count)); */
/* 					pV->aec_rd += count; */
/* 					if (pV->aec_rd >= pV->aec_size) */
/* 						pV->aec_rd -= pV->aec_size; */
/* 					kc_logging_copy_to_user(buf+pV->aec_skip_offset,pV->aec_out,count); */
/* 				} */
/* 				else{ */
/* 					RMDBGLOG((AEC_DBG,"processing one buffer in two times...\n")); */
/* 					kc_memcpy(pV->temp_buffer,aec_rd1,aec_rdsize1); */
/* 					kc_memcpy(pV->temp_buffer+aec_rdsize1,aec_rd2,count-aec_rdsize1); */
					
/* 					RMaec_process_buffer(pV->pAEC,pV->temp_buffer,buf+pV->aec_skip_offset,pV->aec_out,count); */
					
/* 					RMDBGLOG((AEC_DBG,"aec_rd = %d , length = %d\n",pV->aec_rd,count)); */
/* 					pV->aec_rd += count; */
/* 					if (pV->aec_rd >= pV->aec_size) */
/* 						pV->aec_rd -= pV->aec_size; */
/* 					kc_logging_copy_to_user(buf+pV->aec_skip_offset,pV->aec_out,count); */
/* 				} */
/* 			} */
/* 			else{ */
/* 				RMDBGLOG((AEC_DBG,"WARNING : readable size too short...\n")); */
/* 			} */
			
		
/* 		} */
		
/* 		else{ */
/* 			RMDBGLOG((AEC_DBG,"aec_readable = %ld , capture buffer size = %ld , aec_rdsize1 = %ld \n",aec_readable,pV->capture_buffer_size,aec_rdsize1)); */
			
/* 			if(aec_readable >= length){ */
/* 				if(aec_rdsize1 >= length){ */
/* 					RMDBGLOG((AEC_DBG,"processing one buffer...\n")); */
					
/* 					RMaec_process_buffer(pV->pAEC,pV->aec_fifo+pV->aec_rd,buf,pV->aec_out,length); */
					
/* 					RMDBGLOG((AEC_DBG,"aec_rd = %d , length = %d\n",pV->aec_rd,length)); */
/* 					pV->aec_rd += length; */
/* 					if (pV->aec_rd >= pV->aec_size) */
/* 						pV->aec_rd -= pV->aec_size; */
/* 					kc_logging_copy_to_user(buf,pV->aec_out,length); */
/* 				} */
/* 				else{ */
/* 					RMDBGLOG((AEC_DBG,"processing one buffer in two times...\n")); */
/* 					kc_memcpy(pV->temp_buffer,aec_rd1,aec_rdsize1); */
/* 					kc_memcpy(pV->temp_buffer+aec_rdsize1,aec_rd2,length-aec_rdsize1); */
					
/* 					RMaec_process_buffer(pV->pAEC,pV->temp_buffer,buf,pV->aec_out,length); */
					
/* 					RMDBGLOG((AEC_DBG,"aec_rd = %d , length = %d\n",pV->aec_rd,length)); */
/* 					pV->aec_rd += length; */
/* 					if (pV->aec_rd >= pV->aec_size) */
/* 						pV->aec_rd -= pV->aec_size; */
/* 					kc_logging_copy_to_user(buf,pV->aec_out,length); */
/* 				} */
/* 			} */
/* 			else{ */
/* 				RMDBGLOG((AEC_DBG,"WARNING : readable size too short...\n")); */
/* 			} */
/* 		} */
/* 	} */
        /* Process DTMF on buffer */
	
	while(1){
		
		if((length - pV->dtmf_decoded) < (2*GOERTZEL_N)){
			pV->dtmf_offset = length - pV->dtmf_decoded;
			
			RMDBGLOG((DTMF_DBG,"wrote %d samples to dtmf buffer \n",pV->dtmf_offset/2));
			for( k = 0,l = 0 ; k < pV->dtmf_offset ; k += 2,l++ ) {
				if(pV->nb_bits_per_sample ==16){
					pV->goertzel_buffer[l]=buf[k+1]+128;
				}
				else
					pV->goertzel_buffer[l] = buf[k];
			}
			
			pV->dtmf_decoded = 0;
			break;
		}
		
		if(pV->dtmf_offset != 0){
			RMuint32 size = 2*GOERTZEL_N - pV->dtmf_offset;
			
			RMDBGLOG((DTMF_DBG,"wrote %d samples to dtmf buffer \n",size/2));
			for(k=0,l=0;k<size;k+=2,l++){
				if(pV->nb_bits_per_sample ==16){
					pV->goertzel_buffer[l+pV->dtmf_offset]=buf[k+1]+128;
				}
				else
					pV->goertzel_buffer[l+pV->dtmf_offset] = buf[k];
			}
			pV->dtmf_offset = 0;
			pV->dtmf_decoded += size;
		}
		else {
			for(k=0,l=0;k<2*GOERTZEL_N;k+=2,l++){
				if(pV->nb_bits_per_sample ==16){
					pV->goertzel_buffer[l+pV->dtmf_offset]=buf[k+1]+128;
				}
				else
					pV->goertzel_buffer[l+pV->dtmf_offset] = buf[k];
			}
			pV->dtmf_decoded += 2*GOERTZEL_N;
		}
		
		RMDBGLOG((DTMF_DBG,"Process one buffer of 205 samples\n"));
		ch = dtmf_decode(GOERTZEL_N,pV->goertzel_buffer,DEFAULT_DECODER_PCT);
		if (ch == pV->dup_ch){
			if(ch != ','){
				if(ch != pV->last_ch){
					RMuint8 *wr_ptr = pV->dtmf_buffer + pV->dtmf_wr_ptr;
					
					RMDBGLOG((DTMF_DBG,"Detected DTMF %c \n",ch));
					*wr_ptr = ch;
					pV->dtmf_wr_ptr ++;
					if(pV->dtmf_wr_ptr >= DTMF_BUFFER_SIZE)
						pV->dtmf_wr_ptr -= DTMF_BUFFER_SIZE;
					RMDBGLOG((DTMF_DBG,"wr = %d, rd = %d \n",pV->dtmf_wr_ptr,pV->dtmf_rd_ptr));
				}
			}
		}
		if(pV->dup_ch == ch){
			pV->last_ch = ch;
		}
		pV->dup_ch = ch;
	}

	
	return length;
}

static ssize_t em8xxx_voip_write(struct file * file_p, const char *buf, size_t count, loff_t * ppos)
{
	struct emhwlib_info Info;
	struct emhwlib_info *pInfo = &Info;
	struct em8xxx_data param;
	struct STC_Time_type stc;
	int rc;
	RMuint32 Info_size;
	struct voipprivate *pV=(struct voipprivate *)file_p->private_data;
	struct em8xxxprivate *pE;
	RMstatus err;
	void * context;
	RMuint32 event_mask;
	RMuint32 it=0,timeout_buffer = RECEIVEDATA_TIMEOUT_US;
	RMuint8 * aec_wr1;
	RMuint8 * aec_wr2;
	RMuint32 aec_wrsize1,aec_writable;

	if(!pV->voip_open_count){
		return -EINVAL;
	}

	/* Skip the first write samples otherwise the bts fifo will be full. This is done to lower latency */

	if (pV->write_skip_count < pV->write_skip){
		pV->write_skip_count += count;
		return count;
	}
	
	/* Get a buffer */

	pE=Etable + (pV-VOIPtable);
	
	if (pV->decoder_pBuf==NULL){
		pV->decoder_pBuf=kdmapool_getbuffer(pE->pllad,pV->decoder_dmapool_id,&timeout_buffer);
		if (pV->decoder_pBuf == NULL)
			return 0;
	}
	
	if (count > (1 << AUDIO_DMA_BUFFER_SIZE_LOG2)) {
		RMDBGLOG((LOCALDBG,"count > buffersize \n"));
		return -1;
	}
	 
	 kc_logging_copy_from_user(pV->temp_buffer,buf,count);
	 kc_logging_copy_from_user(pV->decoder_pBuf,buf,count);

/* 	Byte-swap the samples if necessary */

 	if(pV->nb_bits_per_sample==16){
 		RMuint32 l;
 		RMint8 temp;
 		for (l=0;l<count;l+=2){
 			temp = pV->temp_buffer[l];
 			pV->temp_buffer[l] = pV->temp_buffer[l+1];
 			pV->temp_buffer[l+1] = temp;
 			temp = pV->decoder_pBuf[l];
 			pV->decoder_pBuf[l] = pV->decoder_pBuf[l+1];
 			pV->decoder_pBuf[l+1] = temp;
 		}
	}

/*  	 /\* Write the buffer to the aec fifo *\/ */
	 
/* 	 RMDBGLOG((AEC_DBG,"write buffer to aec fifo\n")); */
	 
/* 	 aec_wr1 = pV->aec_fifo+pV->aec_wr; */
/* 	 if (pV->aec_wr >= pV->aec_rd) { */
/* 		 if (pV->aec_rd > 0) { */
/* 			 aec_wrsize1 = pV->aec_size - pV->aec_wr; */
/* 			 aec_wr2 = pV->aec_fifo; */
/* 			 aec_writable = aec_wrsize1 + pV->aec_rd - 1; */
/* 		 } */
/* 		 else { */
/* 			 aec_wrsize1 = pV->aec_size - 1 - pV->aec_wr; */
/* 			 aec_wr2 = 0; */
/* 			 aec_writable = aec_wrsize1; */
/* 		 } */
/* 	 } */
/* 	 else { */
/* 		 aec_wrsize1 = pV->aec_rd - 1 - pV->aec_wr; */
/* 		 aec_wr2 = 0; */
/* 		 aec_writable = aec_wrsize1; */
/* 	 } */
/* 	 RMDBGLOG((AEC_DBG,"aec_writable = %d , aec_wrsize1 = %d count = %d \n",aec_writable,aec_wrsize1,count)); */
	 
/* 	 if (aec_writable >= count){ */
/* 		 if (aec_wrsize1 >= count){ */
/* 			 RMDBGLOG((AEC_DBG,"Writing to aec fifo! \n")); */
/* 			 kc_memcpy(aec_wr1,pV->temp_buffer,count); */
/* 			 pV->aec_wr += count; */
/* 			 if (pV->aec_wr >= pV->aec_size) */
/* 				 pV->aec_wr -= pV->aec_size; */
/* 		 } */
/* 		 else{ */
			 
/* 			 RMDBGLOG((AEC_DBG,"Writing to aec fifo in two times! \n")); */
			 
/* 			 kc_memcpy(aec_wr1,pV->temp_buffer,aec_wrsize1); */
/* 			 kc_memcpy(aec_wr2,pV->temp_buffer+aec_wrsize1,count-aec_wrsize1); */
/* 			 pV->aec_wr += count; */
/* 			 if (pV->aec_wr >= pV->aec_size) */
/* 				 pV->aec_wr -= pV->aec_size; */
/* 		 } */
/* 	 } */
/* 	 else{ */
/* 		 RMDBGLOG((AEC_DBG,"WARNING : AEC FIFO IS FULL !!! aec_size = %ld \n",pV->aec_size)); */
/* 	 } */

/* 	Byte-swap the samples if necessary */

 	if(pV->nb_bits_per_sample==16){
 		RMuint32 l;
 		RMint8 temp;
 		for (l=0;l<count;l+=2){
 			temp = pV->temp_buffer[l];
 			pV->temp_buffer[l] = pV->temp_buffer[l+1];
 			pV->temp_buffer[l+1] = temp;
 			temp = pV->decoder_pBuf[l];
 			pV->decoder_pBuf[l] = pV->decoder_pBuf[l+1];
 			pV->decoder_pBuf[l+1] = temp;
 		}
	}
	 
	 
	 if(pV->first_write){
		 stc.time = 0;
		 stc.time_resolution = 90000;
		 EM8XXXVOIPSP(pE,EMHWLIB_MODULE(STC,audio_decoder_index), RMSTCPropertyID_Time, &stc, sizeof(stc));
		 if(RMFAILED(err)){
			 RMDBGLOG((LOCALDBG,"setting stc to 0 failed \n"));
			 return -EINVAL;
		 }
		 Info.ValidFields = TIME_STAMP_INFO;
		 Info.TimeStamp = 0;
		 pInfo = &Info;
		 Info_size = sizeof(Info);
	 }
	else {
		pInfo = NULL;
		Info_size = 0;
	}

	param.moduleId = EMHWLIB_MODULE(AudioDecoder,audio_decoder_index);
	param.poolId = pV->decoder_dmapool_id;
	param.dataSize = (pV->codec == ULAW) ? 2*count : count;
	param.bus_addr = kdmapool_get_bus_address(pE->pllad,pV->decoder_dmapool_id,pV->decoder_pBuf,param.dataSize);
	kc_flush_cache((void *)param.bus_addr,param.dataSize);

	context =(void *) (((pE-Etable) << 16) + param.poolId + 1);

	err=RM_INSUFFICIENT_SIZE;
	while(err==RM_INSUFFICIENT_SIZE){
		it ++;
		if(it >= 1000){
			RMDBGLOG((LOCALDBG,"forced to quit loop \n"));
			return -EINVAL;
		}
	
		kc_spin_lock_bh(pE->lock);
		err = EMhwlibSendBuffer(pE->pemhwlib, param.moduleId, param.bus_addr, param.dataSize, pInfo, Info_size, context);
		kc_spin_unlock_bh(pE->lock);
		
		if((err != RM_OK) && (err != RM_INSUFFICIENT_SIZE)){
			RMDBGLOG((LOCALDBG,"fatal error while sending buffer. abort, err = %d \n",err));
			return -EINVAL;
		}
		
		if(err == RM_INSUFFICIENT_SIZE){
			rc=kc_interruptible_sleep_on_timeout(pV->write_q,US_TO_JIFFIES(RECEIVEDATA_TIMEOUT_US));
			if (kc_signal_pending_current()){
				return -EINVAL;
			}
		}
	}

	event_mask = SOFT_IRQ_EVENT_XFER_FIFO_READY;
	kc_spin_lock_bh(pE->lock);
	rc=EMhwlibSetProperty(pE->pemhwlib,param.moduleId,RMGenericPropertyID_ClearEventMask,&event_mask, sizeof(event_mask));
	kc_spin_unlock_bh(pE->lock);
	
	 if(pV->first_write){
		 struct DataFIFOInfo fifo_info;
		 struct XferFIFOInfo_type xfer_fifo_info;

		 pV->first_write=FALSE;

		 EM8XXXVOIPGP(pE,EMHWLIB_MODULE(AudioCapture,audio_capture_index),RMGenericPropertyID_DataFIFOInfo,&fifo_info,sizeof(fifo_info));
		 EM8XXXVOIPGP(pE,EMHWLIB_MODULE(AudioCapture,audio_capture_index),RMGenericPropertyID_XferFIFOInfo,&xfer_fifo_info,sizeof(xfer_fifo_info));
		 
		 pV->aec_fifo_skip = AEC_FIXED_THRESHOLD + ((fifo_info.Readable + xfer_fifo_info.Erasable*FRAME_SIZE_24B2C)/3);
		 pV->write_ready = TRUE;
		 RMDBGLOG((ENABLE,"skipping %d bytes : fifo_readable = %d , xfer_erasable = %d \n",pV->aec_fifo_skip,fifo_info.Readable/3,xfer_fifo_info.Erasable));
	 }

	/* Release is done by the Send buffer */

	pV->decoder_pBuf = NULL;
	
	return count;
}

static unsigned int em8xxx_voip_poll(struct file *file_p, poll_table * wait)
{
	unsigned int mask = 0;
	struct voipprivate *pV = VOIPtable + MINOR(file_p->f_dentry->d_inode->i_rdev);
	struct em8xxxprivate *pE = Etable + (pV-VOIPtable);
	struct XferFIFOInfo_type xfer_info;
	RMstatus err;

	kc_poll_wait(file_p, pV->poll_q, wait);
	
	EM8XXXVOIPGP(pE,EMHWLIB_MODULE(AudioDecoder,audio_decoder_index),RMGenericPropertyID_XferFIFOInfo,&xfer_info,sizeof(xfer_info));

	if(xfer_info.Writable > 0){
		mask |= POLLOUT | POLLWRNORM;
	}
	
	EM8XXXVOIPGP(pE,EMHWLIB_MODULE(AudioCapture,audio_capture_index),RMGenericPropertyID_XferFIFOInfo,&xfer_info,sizeof(xfer_info));
	
	if((xfer_info.Erasable > 0) && !pV->dtmf_enable){
		mask |= POLLIN | POLLRDNORM;
	}
	
	if (pV->exc.bytes) {
		mask |= POLLPRI; 
	}
	
	return mask;
}

static int em8xxx_voip_ioctl(struct inode *inode, struct file *file_p, unsigned int cmd, unsigned long arg)
{
	struct voipprivate *pV = file_p->private_data;
	struct em8xxxprivate *pE = Etable + (pV - VOIPtable);
	struct STC_Time_type stc;
	RMstatus err;
	int retval = 0;
	int i;
	enum AudioDecoder_Command_type command;
	enum AudioDecoder_State_type state;
	struct AudioEngine_Volume_type volume;
	RMuint32 audio_engine = EMHWLIB_MODULE(AudioEngine,audio_engine_index);
	
	switch(cmd) {
	case PHONE_DTMF_READY:
		RMDBGLOG((LOCALDBG,"PHONE_DTMF_READY \n"));
		retval = pV->exc.bits.dtmf_ready;
		break;
	case PHONE_RING_CADENCE:
		RMDBGLOG((LOCALDBG,"PHONE_RING_CADENCE \n"));
		kc_logging_copy_from_user(&pV->cadence, (RMuint16 *) arg, sizeof(RMuint16));
		set_cadence_parameters(pV);
		break;
	case OLD_PHONE_RING_START:
		RMDBGLOG((LOCALDBG,"OLD_PHONE_RING_START \n"));
		break;
	case PHONE_RING_START:
		RMDBGLOG((LOCALDBG,"PHONE_RING_START \n"));
	
		// Volume Initialization
		for (i = 0; i <= 9; i++){
			volume.Channel = i;
			volume.Volume = 0x10000000;
			
			EM8XXXVOIPSP(pE, audio_engine, RMAudioEnginePropertyID_Volume, &volume, sizeof(volume));
			
			if (RMFAILED(err)){
				RMDBGLOG((ENABLE, "Error while setting audio volume! \n"));
				return err;
			}
		}
		pV->nb_bits_per_sample=16;
		set_audio_parameters(pV);
		pV->codec = LINEAR16;
		stc.time = 0;
		stc.time_resolution = 90000;
		EM8XXXVOIPSP(pE,EMHWLIB_MODULE(STC,audio_decoder_index), RMSTCPropertyID_Time, &stc, sizeof(stc));
		if(RMFAILED(err)){
			RMDBGLOG((LOCALDBG,"setting stc to 0 failed \n"));
			return -EINVAL;
		}
		start_playback(pE);
		SlicSetState(pV,RINGING);
		pV->ring_time.ring_state=Ring_state_On;
		pV->ring_time.ring_cnt=0;
		pV->ringing = 1;
		break;
	case PHONE_RING_STOP:
		pV->ringing = 0;
		RMDBGLOG((LOCALDBG,"stop to ring \n"));
		SlicSetState(pV,NORMAL_ACTIVE);
		EM8XXXVOIPGP(pE,EMHWLIB_MODULE(AudioDecoder,audio_decoder_index), RMAudioDecoderPropertyID_State,&state,sizeof(state));
		if (state != AudioDecoder_State_StopPending){
			command = AudioDecoder_Command_Stop;
			EM8XXXVOIPSP(pE,EMHWLIB_MODULE(AudioDecoder,audio_decoder_index), RMAudioDecoderPropertyID_Command, &command, sizeof(command));
			kc_udelay(1000);
		}
		break;	
	case PHONE_RING:        
		RMDBGLOG((LOCALDBG,"PHONE_RING \n"));
		break;
	case PHONE_EXCEPTION:
		RMDBGLOG((LOCALDBG,"PHONE_EXCEPTION \n"));
		retval = pV->exc.bytes;
		pV->exc.bytes = 0; 

		/* If dtmf readable > 0 raise an exception */
		if (pV->dtmf_wr_ptr != pV->dtmf_rd_ptr){
			pV->exc.bits.dtmf_ready = 1;
		}
		break;
	case PHONE_HOOKSTATE:
		RMDBGLOG((LOCALDBG,"PHONE_HOOKSTATE \n"));
		pV->exc.bits.hookstate = 0;
		retval = !read_gpio(pE,GPIO_LOOP_DETECT);
		break;
	case PHONE_FRAME:
		RMDBGLOG((LOCALDBG,"PHONE_FRAME \n"));
		break;
	case PHONE_REC_CODEC:
		RMDBGLOG((LOCALDBG,"PHONE_REC_CODEC \n"));
		switch(arg){
		case G723_63:
			break;
		case G723_53:
			break;
		case TS85:
			break;
		case TS48:
			break;
		case TS41:
			break;
		case G728:
			break;
		case G729:
			break;
		case ULAW:
			pV->nb_bits_per_sample = 16;
			RMDBGLOG((LOCALDBG,"ULAW  rec codec accepted ! \n"));
			break;
		case ALAW:
			break;
		case LINEAR16:
			pV->nb_bits_per_sample = 16;
			RMDBGLOG((LOCALDBG,"LINEAR16 rec codec accepted ! \n"));
			break;
		case LINEAR8:
			pV->nb_bits_per_sample = 8;
			RMDBGLOG((LOCALDBG,"LINEAR8 rec codec accepted ! \n"));
			break;
		}
		break;
	case PHONE_VAD:
		RMDBGLOG((LOCALDBG,"PHONE_VAD \n"));
		break;
	case PHONE_REC_START:
		RMDBGLOG((LOCALDBG,"PHONE_REC_START \n"));
		pV->read_time = kc_gettimems();
		pV->first_read = TRUE;
		pV->dtmf_enable = 0;
		kc_udelay(1000);
		start_capture(pE);
		break;
	case PHONE_REC_STOP:
		RMDBGLOG((LOCALDBG,"PHONE_REC_STOP \n"));
		if(!pV->hookstate){
			stop_capture(pE);
			pV->state=0;
		}
		break;
	case PHONE_REC_DEPTH:
		RMDBGLOG((LOCALDBG,"PHONE_REC_DEPTH \n"));
		break;
	case PHONE_REC_VOLUME:
		RMDBGLOG((LOCALDBG,"PHONE_REC_VOLUME \n"));
		break;
	case PHONE_REC_VOLUME_LINEAR:
		RMDBGLOG((LOCALDBG,"PHONE_REC_VOLUME_LINEAR \n"));
		break;
	case PHONE_REC_LEVEL:
		RMDBGLOG((LOCALDBG,"PHONE_REC_LEVEL \n"));
		break;

	case PHONE_PLAY_CODEC:
		RMDBGLOG((LOCALDBG,"PHONE_PLAY_CODEC \n"));

		switch(arg){
		case G723_63:
			break;
		case G723_53:
			break;
		case TS85:
			break;
		case TS48:
			break;
		case TS41:
			break;
		case G728:
			break;
		case G729:
			break;
		case ULAW:
			pV->nb_bits_per_sample = 16;
			pV->codec = ULAW;
			set_audio_parameters(pV);
			RMDBGLOG((LOCALDBG,"ULAW codec accepted ! \n"));
			break;
		case ALAW:
			break;
		case LINEAR16:
			pV->nb_bits_per_sample = 16;
			pV->codec=LINEAR16;
			set_audio_parameters(pV);
			RMDBGLOG((LOCALDBG,"LINEAR16 codec accepted ! \n"));
			break;
		case LINEAR8:
			pV->nb_bits_per_sample = 8;
			pV->codec=LINEAR8;
			set_audio_parameters(pV);
			RMDBGLOG((LOCALDBG,"LINEAR8 codec accepted ! \n"));
			break;
		}
		break;

	case PHONE_PLAY_START:
		RMDBGLOG((LOCALDBG,"PHONE_PLAY_START \n"));

		// Volume Initialization
		for (i = 0; i <= 9; i++){
			volume.Channel = i;
			volume.Volume = 0x01965fea; // -20 dB //0x10000000;
			
			EM8XXXVOIPSP(pE, audio_engine, RMAudioEnginePropertyID_Volume, &volume, sizeof(volume));
			
			if (RMFAILED(err)){
				RMDBGLOG((ENABLE, "Error while setting audio volume! \n"));
				return err;
			}
		}
		pV->write_ready = FALSE;
		pV->first_write=TRUE;
		start_playback(pE);
		break;
	case PHONE_PLAY_STOP:
		RMDBGLOG((LOCALDBG,"PHONE_PLAY_STOP \n"));
		pV->ringing=0;
		pV->ringback=0;
		pV->busy = 0;
		pV->dialtone = 0;
		command = AudioDecoder_Command_Stop;
		EM8XXXVOIPSP(pE,EMHWLIB_MODULE(AudioDecoder,audio_decoder_index), RMAudioDecoderPropertyID_Command, &command, sizeof(command));
		kc_mdelay(500);
		pV->write_skip_count = 0;
		pV->write_ready = FALSE;
		break;
	case PHONE_PLAY_DEPTH:
		RMDBGLOG((LOCALDBG,"PHONE_PLAY_DEPTH \n"));
		break;
	case PHONE_PLAY_VOLUME:
		RMDBGLOG((LOCALDBG,"PHONE_PLAY_VOLUME \n"));
		break;
	case PHONE_PLAY_VOLUME_LINEAR:
		RMDBGLOG((LOCALDBG,"PHONE_PLAY_VOLUME_LINEAR \n"));
		break;
	case PHONE_PLAY_LEVEL:
		RMDBGLOG((LOCALDBG,"PHONE_PLAY_LEVEL \n"));
		break;
	case PHONE_MAXRINGS:   /* this ioctl is superseeded, and not relevant.*/
		RMDBGLOG((LOCALDBG,"PHONE_MAXRINGS \n"));
		break;
	case PHONE_SET_TONE_ON_TIME:
		RMDBGLOG((LOCALDBG,"PHONE_SET_TONE_ON_TIME \n"));
		break;
	case PHONE_SET_TONE_OFF_TIME:
		RMDBGLOG((LOCALDBG,"PHONE_SET_TONE_OFF_TIME \n"));
		break;
	case PHONE_GET_TONE_ON_TIME:
		RMDBGLOG((LOCALDBG,"PHONE_GET_TONE_ON_TIME \n"));
		break;
	case PHONE_GET_TONE_OFF_TIME:
		RMDBGLOG((LOCALDBG,"PHONE_GET_TONE_OFF_TIME \n"));
		break;
	case PHONE_PLAY_TONE:
		RMDBGLOG((LOCALDBG,"PHONE_PLAY_TONE \n"));
		break;
	case PHONE_GET_TONE_STATE:
		RMDBGLOG((LOCALDBG,"PHONE_GET_TONE_STATE \n"));
		break;
	case PHONE_GET_DTMF:
		RMDBGLOG((LOCALDBG,"PHONE_GET_DTMF \n"));
		break;
	case PHONE_GET_DTMF_ASCII:
		RMDBGLOG((LOCALDBG,"PHONE_GET_DTMF_ASCII \n"));
		retval = *(pV->dtmf_buffer + pV->dtmf_rd_ptr);
		pV->dtmf_rd_ptr ++;
		if(pV->dtmf_rd_ptr >= DTMF_BUFFER_SIZE)
			pV->dtmf_rd_ptr -= DTMF_BUFFER_SIZE;
		if(pV->dtmf_rd_ptr == pV->dtmf_wr_ptr)
			pV->exc.bits.dtmf_ready = 0;
		RMDBGLOG((LOCALDBG,"returns ascii character %c \n",retval));
		break;
	case PHONE_DTMF_OOB:
		RMDBGLOG((LOCALDBG,"PHONE_DTMF_OOB \n"));
		break;
	case PHONE_DIALTONE:
		RMDBGLOG((LOCALDBG,"PHONE_DIALTONE \n"));
		// Volume Initialization
		for (i = 0; i <= 9; i++){
			volume.Channel = i;
			volume.Volume = 0x04000000; // -12 dB //0x10000000;
			
			EM8XXXVOIPSP(pE, audio_engine, RMAudioEnginePropertyID_Volume, &volume, sizeof(volume));
			
			if (RMFAILED(err)){
				RMDBGLOG((ENABLE, "Error while setting audio volume! \n"));
				return err;
			}
		}
		pV->nb_bits_per_sample=16;
		set_audio_parameters(pV);
		pV->codec = LINEAR16;
		stc.time = 0;
		stc.time_resolution = 90000;
		EM8XXXVOIPSP(pE,EMHWLIB_MODULE(STC,audio_decoder_index), RMSTCPropertyID_Time, &stc, sizeof(stc));
		if(RMFAILED(err)){
			return -EINVAL;
		}
		start_playback(pE);
		pV->dialtone = 1;
		break;
	case PHONE_BUSY:
		RMDBGLOG((LOCALDBG,"PHONE_BUSY \n"));
		pV->nb_bits_per_sample=16;
		set_audio_parameters(pV);
		pV->codec = LINEAR16;
		stc.time = 0;
		stc.time_resolution = 90000;
		EM8XXXVOIPSP(pE,EMHWLIB_MODULE(STC,audio_decoder_index), RMSTCPropertyID_Time, &stc, sizeof(stc));
		if(RMFAILED(err)){
			return -EINVAL;
		}
		start_playback(pE);
		pV->busy_time.busy_state=Busy_state_On;
		pV->busy_time.busy_cnt=0;
		pV->busy = 1;
		break;
	case PHONE_RINGBACK:
		RMDBGLOG((LOCALDBG,"PHONE_RINGBACK \n"));
		pV->nb_bits_per_sample=16;
		set_audio_parameters(pV);
		pV->codec = LINEAR16;
		stc.time = 0;
		stc.time_resolution = 90000;
		EM8XXXVOIPSP(pE,EMHWLIB_MODULE(STC,audio_decoder_index), RMSTCPropertyID_Time, &stc, sizeof(stc));
		if(RMFAILED(err)){
			return -EINVAL;
		}
		start_playback(pE);
		pV->ringback_time.ringback_state=Ringback_state_On;
		pV->ringback_time.ringback_cnt=0;
		pV->ringback = 1;
		break;
	case PHONE_WINK:
		RMDBGLOG((LOCALDBG,"PHONE_WINK \n"));
		break;
	case PHONE_CPT_STOP:
		RMDBGLOG((LOCALDBG,"PHONE_CPT_STOP \n"));
		break;
	case PHONE_QUERY_CODEC:
		RMDBGLOG((LOCALDBG,"PHONE_QUERY_CODEC \n"));
		break;
	case PHONE_CAPABILITIES:
		RMDBGLOG((LOCALDBG,"PHONE_CAPABILITIES \n"));
		break;
	case PHONE_CAPABILITIES_LIST:
		RMDBGLOG((LOCALDBG,"PHONE_CAPABILITIES_LIST \n"));
		break;
	case PHONE_CAPABILITIES_CHECK:
		RMDBGLOG((LOCALDBG,"PHONE_CAPABILITIES_CHECK \n"));
		return 1;
		break;
	case PHONE_PSTN_SET_STATE:
		RMDBGLOG((LOCALDBG,"PHONE_PSTN_SET_STATE \n"));
		switch(arg){
		case PSTN_ON_HOOK:
			break;
		case PSTN_RINGING:
			break;
		case PSTN_OFF_HOOK:
			break;
		case PSTN_PULSE_DIAL:
			break;
		}
		break;
	case PHONE_PSTN_GET_STATE:
		RMDBGLOG((LOCALDBG,"PHONE_PSTN_GET_STATE \n"));
		break;
	}
	return retval;
}

static int em8xxx_voip_release(struct inode *inode, struct file *file_p)
{
	struct voipprivate *pV = (struct voipprivate *) file_p->private_data;

	RMDBGLOG((LOCALDBG,"release pV = %p \n",pV));
		
	pV->voip_open_count --;
	pV->exc.bytes = 0;

	file_p->private_data = NULL;

	pV->hook_cnt=0;
	pV->i_start=0;
	pV->j_start=0;
	pV->last_i=0;
	pV->last_j=0;
	pV->capture_readable=0;
	pV->capture_buffer_size=0;
	pV->capture_read=0;
	pV->playback_enable = FALSE;
	pV->state=0;
	pV->ringing=0;
	pV->busy = 0;
	pV->ringback = 0;

	RMDBGLOG((LOCALDBG,"end release \n"));
	
	return 0;
}

static int em8xxx_voip_fasync(int fd, struct file *file_p, int mode)
{
	struct voipprivate *pV = file_p->private_data;

	return fasync_helper(fd, file_p, mode, &pV->async_queue);
}

static int em8xxx_voip_init(struct em8xxxprivate *pE)
{
	struct voipprivate *pV=VOIPtable+(pE-Etable);
	RMuint32 timeout = 0;

	if (pV->voip_active == 0) {
		memset(pV,0,sizeof(struct voipprivate));
		
			/* Register with the Telephony for Linux subsystem */
		pV->p_dev.f_op = &em8xxx_voip_fops;
		pV->p_dev.open = em8xxx_voip_open;
		pV->board = pE-Etable;
		pV->p_dev.board = pV->board;
		phone_register_device(&pV->p_dev, PHONE_UNIT_ANY);

	}
	else {
		RMDBGLOG((LOCALDBG,"em8xxx voip driver already registered\n"));
		return -EINVAL;
	}
	
	pV->voip_active = 1;

	kc_init_waitqueue_head(&pV->poll_q);
	kc_init_waitqueue_head(&pV->read_q);
	kc_init_waitqueue_head(&pV->write_q);

	init_audio(pV);
	init_gpio(pE);

	SlicSetState(pV,NORMAL_ACTIVE);

	//open the decoder pool and allocate one buffer	
		
	pV->decoder_dmapool_id=kdmapool_open(pE->pllad,NULL,AUDIO_DMA_BUFFER_COUNT,AUDIO_DMA_BUFFER_SIZE_LOG2);
	RMDBGLOG((LOCALDBG,"decoder dmapool id = %d\n", pV->decoder_dmapool_id));

	pV->decoder_pBuf=kdmapool_getbuffer(pE->pllad,pV->decoder_dmapool_id,&timeout);

	//open the capture pool and prepare the buffers to be readable

	pV->capture_dmapool_id=kdmapool_open(pE->pllad,NULL,SERIALIN_DMA_BUFFER_COUNT,SERIALIN_DMA_BUFFER_SIZE_LOG2);
	RMDBGLOG((LOCALDBG,"capture_dmapool id = %d\n", pV->capture_dmapool_id));
	
	prepare_data(pV);

	pV->cadence = USA_RING_CADENCE;

	set_cadence_parameters(pV);

	pV->check_interval = HZ / DEFAULT_CHECK_FREQ;
	
	em8xxx_voip_init_timer(pV);
	em8xxx_voip_add_timer(pV);

	pV->temp_buffer = vmalloc(((1<<AUDIO_DMA_BUFFER_SIZE_LOG2)/2)*sizeof(RMuint8));
	pV->capture_temp = vmalloc(((1<<AUDIO_DMA_BUFFER_SIZE_LOG2)/2)*sizeof(RMuint8));
	pV->goertzel_buffer = vmalloc(GOERTZEL_N*sizeof(RMuint8));

	pV->pAEC = vmalloc(sizeof(struct RMaec));
	pV->aec_size = AEC_FIFO_SIZE;


	RMDBGLOG((AEC_DBG,"Initializing AEC fifo with size %d \n",pV->aec_size));
	pV->aec_fifo = vmalloc(pV->aec_size);
	pV->aec_out = vmalloc(pV->aec_size);
	pV->aec_buffer = vmalloc(pV->aec_size);
	pV->aec_wr=0;
	pV->aec_rd=0;
	pV->aec_offset=0;
	pV->aec_skip_offset=0;
	pV->aec_fifo_ready = FALSE;
	pV->write_skip = WRITE_THRESHOLD;
	pV->write_skip_count = 0;
	pV->aec_rd_count=0;

	krua_register_event_callback(pE,EMHWLIB_MODULE(AudioCapture,audio_capture_index),SOFT_IRQ_EVENT_XFER_RECEIVE_READY,receive_callback);
	krua_register_event_callback(pE,EMHWLIB_MODULE(AudioDecoder,audio_decoder_index),SOFT_IRQ_EVENT_XFER_FIFO_READY,send_callback);

	RMDBGLOG((LOCALDBG,"em8xxx voip driver registered.\n"));
	
	return 0;

}


static int em8xxx_voip_cleanup(struct em8xxxprivate *pE)
{
	struct voipprivate *pV=VOIPtable+(pE-Etable);

	cleanup_audio(pV);

	del_timer(&pV->timer);
	kc_deinit_waitqueue_head(pV->poll_q);
	kc_deinit_waitqueue_head(pV->read_q);
	kc_deinit_waitqueue_head(pV->write_q);

	krua_unregister_event_callback(pE,EMHWLIB_MODULE(AudioCapture,audio_capture_index),receive_callback);
	krua_unregister_event_callback(pE,EMHWLIB_MODULE(AudioDecoder,audio_decoder_index),send_callback);

	vfree(pV->temp_buffer);
	vfree(pV->capture_temp);
	vfree(pV->goertzel_buffer);
	vfree(pV->pAEC);
	vfree(pV->aec_fifo);
 	vfree(pV->aec_out);
 	vfree(pV->aec_buffer);

	if (pV->voip_active == 1) {
		if (pV->voip_open_count == 0) {
			phone_unregister_device(&pV->p_dev);
		}
		else {
			RMDBGLOG((LOCALDBG,"cannot unregister /dev/phone, device is opened \n"));
			return -EINVAL;
		}
	}
	else {
		RMDBGLOG((LOCALDBG,"no voip device registered\n"));
		return -EINVAL;
	}
		
	RMDBGLOG((LOCALDBG,"em8xxx voip driver unregistered\n"));
	pV->voip_active = 0;

	return 0;
}


int init_module(void)
{
	int i,enabled_count=0;

	RMDBGLOG((LOCALDBG,"Begin initialisation of the VOIP Board\n"));

	switch(audio_decoder_index){
	case 0:
	case 1:
		audio_engine_index=0;
		break;
#ifdef RMFEATURE_HAS_AUDIO_ENGINE_1
 	case 2:
	case 3:
		audio_engine_index=1;
		break;
#endif // RMFEATURE_HAS_AUDIO_ENGINE_1
	default:
		return -EINVAL;
	}
	audio_capture_index = audio_engine_index;

	if((audioin_channel != "R") && (audioin_channel != "L")){
		RMDBGLOG((LOCALDBG,"using default audio in channel R on ADC \n"));
		audioin_channel = "R";
	}
	
	
	for (i=0 ; i<MAXLLAD ; i++) {
		if (&((&Etable[i])->pllad) != NULL) {
			if (Etable[i].pllad != NULL){
				if (em8xxx_voip_init(&Etable[i]) != 0) 
					return -EINVAL;
				enabled_count++;
			}
		}
	}
	
	if ( ((&Etable[0])->pllad != NULL) && (enabled_count == 0)) {
		RMDBGLOG((LOCALDBG,"default behavior, enabling voip on device #0\n"));
		if (em8xxx_voip_init(&Etable[0]) != 0) 
			return -EINVAL;
	}
	
        return 0;		    
	
}

void cleanup_module(void)
{
	int i;
	
	RMDBGLOG((LOCALDBG,"Removing voip module\n"));
	
	for (i=0 ; i<MAXLLAD ; i++) {
		if (VOIPtable[i].voip_active) {
			em8xxx_voip_cleanup(&Etable[i]);
		}
	}
	
}

