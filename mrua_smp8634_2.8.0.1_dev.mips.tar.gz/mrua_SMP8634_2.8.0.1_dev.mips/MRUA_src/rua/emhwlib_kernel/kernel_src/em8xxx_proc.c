/*****************************************
 Copyright � 2001-2004
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   em8xxx_proc.c
  @brief  

  long description
  Implements the /proc/driver/em8xxx/[board]/[info_file] where
  	[board] is the board number (minor driver number)
	[info_file] is the file you can "cat" to retrieve info	

  See licensing details in LICENSING file  
  
  @author Jacques Mahe
  @date   2004-04-30
*/

#define ALLOW_OS_CODE 1
#include "../../../emhwlib/include/emhwlib.h"
/* #include "../../../emhwlib_hal/include/emhwlib_registers.h" */
#include "../../../emhwlib/include/emhwlib_dram.h"
#include "../../../emhwlib/include/emhwlib_properties_1000.h"
#include "../../../emhwlib/include/emhwlib_versions.h"
#include "../include/em8xxx_uk.h"

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/version.h>
#ifdef WITH_PROC

#include <linux/proc_fs.h>
#include <linux/fs.h>
#include <linux/sched.h>
#include <linux/interrupt.h>
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,18)
#include <linux/devfs_fs_kernel.h>
#endif

#include "em8xxx.h"
#include "em8xxx_proc.h"

#ifdef WITH_MONITORING
#define MAX_VIDEO_DECODERS 32
#define MAX_AUDIO_DECODERS 4
#define MAX_STC 6
#define MAX_AUDIO_CAPTURE 2
#ifdef WITH_VOIP
#define MAX_VOIP 1
#endif // WITH_VOIP
#define STC_TIME_RESOLUTION 1000

void add_monitoring_entries(unsigned int, void *);
void rm_monitoring_entries(unsigned int);
        
struct monitoring_data {
        RMuint32 index;
      	struct em8xxxprivate *pE;
};
#endif

/* to enable or disable the debug messages of this source file, put 1 or 0 below */
#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif
/*****************************************
 Declaration of all our "proc" routines
 *****************************************/

static int get_human_readable_value(RMuint32 value, RMuint32 *m, RMuint32 *n, char *str)
{
	if (value > 1024*1024) {
		*m = value >> 20;
		*n = ((value - (*m << 20)) * 10) >> 20;
		*str = 'M';
		return 1;
	}
	else if (value > 1024) {
		*m = value >> 10;
		*n = ((value - (*m << 10)) * 10) >> 10;
		*str = 'K';
		return 1;
	}

	return 0;
}

static int proc_read_resources(char *page, char **start, off_t off, int count, int *eof, void *data)
{
	struct em8xxxprivate *pE = (struct em8xxxprivate *) data;
	int len = 0;
	RMuint32 i;
	MMBlockArray blocks;
	RMstatus err;
	RMuint32 category = MM;
	RMuint32 mm_instances = 0;
	
	err = EMhwlibExchangeProperty(pE->pemhwlib, EMHWLIB_MODULE(Enumerator, 0), 
				      RMEnumeratorPropertyID_CategoryIDToNumberOfInstances, 
				      &category, sizeof(category), &mm_instances, sizeof(mm_instances));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get memory manager count %d\n", err));
		goto exit_read_resources;
	}

	for (i = 0; i < mm_instances; i++) {
		RMuint32 j=0;
		RMuint32 max_size = 0;
		struct MM_MemoryArea_type mm_area;
		struct MM_Stats_type mm_stats;
		RMuint32 m,n;
		char c;

		RMDBGLOG((ENABLE,"proc_read_resources: dumping blocks of MM #%d\n",i));

		err = EMhwlibGetProperty(pE->pemhwlib, EMHWLIB_MODULE(MM, i), RMMMPropertyID_MemoryArea, &mm_area, sizeof(mm_area));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot get memory area\n"));
			continue;
		}

		len += snprintf(page + off + len, count - len, "*[MM%lu]* Memory Area [0x%08lx, %lu", i, mm_area.Address, mm_area.Size);
		if (len >= count) break;
		
		if (get_human_readable_value(mm_area.Size, &m, &n, &c)) 
			len += snprintf(page + off + len, count - len, " (%lu.%lu %cB)] ***\n", m,n,c);
		else
			len += snprintf(page + off + len, count - len, "] ***\n");
		if (len >= count) goto exit_read_resources;

		err = EMhwlibGetProperty(pE->pemhwlib, EMHWLIB_MODULE(MM, i), RMMMPropertyID_DumpMallocedBlocks, &blocks, sizeof(blocks));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot get allocated blocks\n"));
			continue;
		}

		while (blocks[j].Address != 0) {
			len += snprintf(page + off + len, count - len, "*[MM%lu]* %lu [0x%08lx, %lu", i, j, blocks[j].Address, blocks[j].Size);
			if (len >= count) goto exit_read_resources;
			
			if (get_human_readable_value(blocks[j].Size, &m, &n, &c)) 
				len += snprintf(page + off + len, count - len, " (%lu.%lu %cB)] ***\n", m,n,c);
			else
				len += snprintf(page + off + len, count - len, "] ***\n");
			if (len >= count) goto exit_read_resources;
			
			max_size += blocks[j].Size;
			j++;
		}
		
		len += snprintf(page + off + len, count - len, "*[MM%lu]* total allocation count: %lu, %lu", i, j, max_size);
		if (len >= count) break;
		
		if (get_human_readable_value(max_size, &m, &n, &c)) 
			len += snprintf(page + off + len, count - len, " (%lu.%lu %cB) ***\n", m,n,c);
		else
			len += snprintf(page + off + len, count - len, " ***\n");
		if (len >= count) goto exit_read_resources;
		
		len += snprintf(page + off + len, count - len, "*[MM%lu]* Free memory: %lu", i, mm_area.Size - max_size);
		if (len >= count) break;
		
		if (get_human_readable_value(mm_area.Size - max_size, &m, &n, &c)) 
			len += snprintf(page + off + len, count - len, " (%lu.%lu %cB) ***\n", m,n,c);
		else
			len += snprintf(page + off + len, count - len, " ***\n");
		if (len >= count) goto exit_read_resources;
		
		err = EMhwlibGetProperty(pE->pemhwlib, EMHWLIB_MODULE(MM, i), RMMMPropertyID_Stats, &mm_stats, sizeof(mm_stats));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot get stats\n"));
			continue;
		}

		len += snprintf(page + off + len, count - len, "*[MM%lu]* Total malloc count: %lu, free count: %lu ***\n", i, mm_stats.TotalMallocCount, mm_stats.TotalFreeCount);
		if (len >= count) goto exit_read_resources;
		
		len += snprintf(page + off + len, count - len, "*[MM%lu]* Maximum memory used: %ld", i, mm_stats.MaximumBytesUsed);
		if (len >= count) goto exit_read_resources;

		if (get_human_readable_value(mm_stats.MaximumBytesUsed, &m, &n, &c)) 
			len += snprintf(page + off + len, count - len, " (%lu.%lu %cB) ***\n", m,n,c);
		else
			len += snprintf(page + off + len, count - len, " ***\n");
		if (len >= count) goto exit_read_resources;
	}
	
 exit_read_resources:
	/* signal end of file */
	*eof = 1;

	return len;
}

static int proc_read_events(char *page, char **start, off_t off, int count, int *eof, void *data)
{
	struct em8xxxprivate *pE = (struct em8xxxprivate *) data;
	int len = 0, i;
	
	len += snprintf(page + off + len, count - len, "*******************\n");
	if (len >= count) goto exit_read_events;
	len += snprintf(page + len, count - len, "Event count %lu\n", pE->event_count);
	if (len >= count) goto exit_read_events;
	for (i=0 ; i<pE->event_count ; i++) {
		len += snprintf(page + len, count - len, "event %d: [0x%lx = 0x%08lx]\n", 
				i, pE->event_array[i].module_id, pE->event_array[i].event_mask);
		if (len >= count)
			goto exit_read_events;
	};	
	
	len += snprintf(page + len, count - len, "*******************\n");

 exit_read_events:
	/* signal end of file */
	*eof = 1;

	return len;
}

static int proc_read_cleanables(char *page, char **start,off_t off, int count, int *eof,void *data)
{
	struct em8xxxprivate *pE = (struct em8xxxprivate *) data;
	int len =0,i;

	len += snprintf(page + off + len, count - len, "*******************\n");
	if (len >= count) goto exit_read_cleanables;
	
	for (i=0;i<MAX_CLEANABLE;i++){
		/* empty entry is found by zero proerty ID */
		if (pE->cl[i].PropertyID==0) continue;

		len += snprintf(page + off + len, count - len, "*** i = %d \n\n em8xxx_id = %d \n ModuleID = %ld \n PropertyID = %ld \n value = %ld \n \n",i,pE->cl[i].em8xxx_id,pE->cl[i].ModuleID,pE->cl[i].PropertyID,pE->cl[i].value);
		if (len >= count) goto exit_read_cleanables;
	}

 exit_read_cleanables:
	/* signal end of file */
	*eof = 1;

	return len;
	
}

static int proc_read_version(char *page, char **start, off_t off, int count, int *eof, void *data)
{
	int len = 0;

	len += snprintf(page + off + len, count - len, "Release version: %s\n", EMHWLIB_VERSION_S);
	return len;
}

#ifdef WITH_MONITORING
static int proc_read_video_decoder(char *page, char **start, off_t off, int count, int *eof, void *mdata)
{
	int len = 0;
	struct monitoring_data *mD = (struct monitoring_data *) mdata;
	struct em8xxxprivate *pE = ((struct monitoring_data *) mdata)->pE;
        RMstatus err;
        enum VideoDecoder_State_type vd_state;
#ifdef WITH_MONITORING_SIGMA
        RMuint16 ui16 = 0;
#endif
        RMuint32 ui32 = 0;
        RMint64 lastPTS = 0;
       	struct DataFIFOInfo DataFIFOInfo = {0, 0, 0};
       	struct XferFIFOInfo_type XferFIFOInfo = {0, 0, 0, 0};
        char *vd_states[] = {"Uninit", "UninitPending", "InitPending", "Stop", "StopPending", "PlayFwd", "PlayFwdPending", "PlayBwd", "PlayBwdPending", "PlayIFrame", "PlayIFramePending", "DecodeFwdToEvent", "DecodeFwdToEventPending"};

	if (off != 0) return((int) off);

	RMDBGLOG((DISABLE, "Read video_decoder%d page=%p start=%p off=%d count=%d eof=%p mdata=%p\n", mD->index, page, *start, off, count, eof, mdata));

	err = EMhwlibGetProperty(pE->pemhwlib, EMHWLIB_MODULE(VideoDecoder, mD->index), RMVideoDecoderPropertyID_State, &vd_state, sizeof(vd_state));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get video_decoder%d state.\n", mD->index));
	}

#if ((EM86XX_CHIP == EM86XX_CHIPID_TANGO2) && (EM86XX_MODE==EM86XX_MODEID_STANDALONE))
	// STANDALONE -- read proc may cause "Unhandled kernel unaligned access" fault
	//		 it is caused by DataFIFOInfo failed because DataFIFO has not initialed yet or have already closed.
        if ((vd_state == 0) || (vd_state == 1)) {
		len += snprintf(page + off + len, count - len, "vd%ld state: %s\n", mD->index, vd_states[vd_state]);
		len += snprintf(page + off + len, count - len, "vd%lu frame counter: 0\n", mD->index);
		len += snprintf(page + off + len, count - len, "vd%ld last PTS: 0\n", mD->index);
        	len += snprintf(page + off + len, count - len, "vd%ld data FIFO size: 0KB, 0%% used\n", mD->index);
	        len += snprintf(page + off + len, count - len, "vd%ld Xfer FIFO size: - entries, - used\n", mD->index);
		len += snprintf(page + off + len, count - len, "vd%ld skip: 0\n", mD->index);
		return len;
	}
#endif

	len += snprintf(page + off + len, count - len, "vd%ld state: %s\n", mD->index, vd_states[vd_state]);
        
	err = EMhwlibGetProperty(pE->pemhwlib, EMHWLIB_MODULE(VideoDecoder, mD->index), RMVideoDecoderPropertyID_FrameCounter, &ui32, sizeof(ui32));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get video_decoder%ld frame count.\n", mD->index));
	}
        if (vd_state == 0) // Uninit
		len += snprintf(page + off + len, count - len, "vd%lu frame counter: 0\n", mD->index);
	else
		len += snprintf(page + off + len, count - len, "vd%lu frame counter: %lu\n", mD->index, ui32);

	err = EMhwlibGetProperty(pE->pemhwlib, EMHWLIB_MODULE(VideoDecoder, mD->index), RMVideoDecoderPropertyID_LastDecodedPTS, &lastPTS, sizeof(lastPTS));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get video_decoder%ld last decoded PTS.\n", mD->index));
	}
        if (vd_state == 0) // Uninit
		len += snprintf(page + off + len, count - len, "vd%ld last PTS: 0\n", mD->index);
	else
		len += snprintf(page + off + len, count - len, "vd%ld last PTS: %lld\n", mD->index, lastPTS);

       	EMhwlibGetProperty(pE->pemhwlib, EMHWLIB_MODULE(VideoDecoder, mD->index), RMGenericPropertyID_DataFIFOInfo, &DataFIFOInfo, sizeof(DataFIFOInfo));
        if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get videoo_decoder%ld data FIFO info.\n", mD->index));
	}
        if ((DataFIFOInfo.Size == 0) || (vd_state == 0)/*Uninit*/)
        	len += snprintf(page + off + len, count - len, "vd%ld data FIFO size: 0KB, 0%% used\n", mD->index);
        else
	        len += snprintf(page + off + len, count - len, "vd%ld data FIFO size: %ldKB, %ld%% used\n", mD->index, DataFIFOInfo.Size / 1024, 100 - (DataFIFOInfo.Writable + 1) * 100 / DataFIFOInfo.Size);
        
       	EMhwlibGetProperty(pE->pemhwlib, EMHWLIB_MODULE(AudioDecoder, mD->index), RMGenericPropertyID_XferFIFOInfo, &XferFIFOInfo, sizeof(XferFIFOInfo));
        if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get video_decoder%d Xfer FIFO info.\n", mD->index));
	}
        if ((XferFIFOInfo.Size == 0) || (vd_state == 0)/*Uninit*/)
	        len += snprintf(page + off + len, count - len, "vd%ld Xfer FIFO size: - entries, - used\n", mD->index);
        else
	        len += snprintf(page + off + len, count - len, "vd%ld Xfer FIFO size: %ld entries, %ld used\n", mD->index, XferFIFOInfo.Size, XferFIFOInfo.Size - XferFIFOInfo.Writable - 1);
        
	err = EMhwlibGetProperty(pE->pemhwlib, EMHWLIB_MODULE(VideoDecoder, mD->index), RMVideoDecoderPropertyID_Skip, &ui32, sizeof(ui32));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get video_decoder%d skip.\n", mD->index));
	}
	len += snprintf(page + off + len, count - len, "vd%ld skip: 0x%lx\n", mD->index, ui32);

#ifdef WITH_MONITORING_SIGMA
        ui16 = 0;
	err = EMhwlibGetProperty(pE->pemhwlib, EMHWLIB_MODULE(VideoDecoder, mD->index), RMVideoDecoderPropertyID_Error, &ui16, sizeof(ui16));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get video_decoder%d error.\n", mD->index));
	}
	len += snprintf(page + off + len, count - len, "vd%d error: 0x%x\n", mD->index, ui16);
        
	err = EMhwlibGetProperty(pE->pemhwlib, EMHWLIB_MODULE(VideoDecoder, mD->index), RMVideoDecoderPropertyID_Overlay, &ui32, sizeof(ui32));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get video_decoder%d overlay.\n", mD->index));
	}
	len += snprintf(page + off + len, count - len, "vd%d overlay: 0x%x\n", mD->index, ui32);
#endif

	return len;
}

static int proc_read_audio_capture(char *page,char **start,off_t off,int count,int *eof,void *mdata)
{
	int len = 0;
	struct monitoring_data *mD = (struct monitoring_data *) mdata;
	struct em8xxxprivate *pE = ((struct monitoring_data *) mdata)->pE;
	RMstatus err;
       	struct DataFIFOInfo DataFIFOInfo = {0, 0, 0};
       	struct XferFIFOInfo_type XferFIFOInfo = {0, 0, 0, 0};

	if (off != 0) return((int) off);

	RMDBGLOG((DISABLE, "Read audio_capture%d page=%p start=%p off=%d count=%d eof=%p mdata=%p\n", mD->index, page, *start, off, count, eof, mdata));

	len += snprintf(page + off + len, count - len, "Audio Capture ----------\n");

       	err = EMhwlibGetProperty(pE->pemhwlib, EMHWLIB_MODULE(AudioCapture,mD->index), RMGenericPropertyID_DataFIFOInfo, &DataFIFOInfo, sizeof(DataFIFOInfo));
        if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get audio_capture data FIFO info.\n"));
	}
        if (DataFIFOInfo.Size == 0)
        	len += snprintf(page + off + len, count - len, "capture data FIFO size: 0KB, 0%% used\n");
        else
        	len += snprintf(page + off + len, count - len, "capture data FIFO size: %ldKB, %ld%% used\n", DataFIFOInfo.Size / 1024, 100 - (DataFIFOInfo.Writable + 1) * 100 / DataFIFOInfo.Size);
                
       	err = EMhwlibGetProperty(pE->pemhwlib, EMHWLIB_MODULE(AudioCapture,mD->index), RMGenericPropertyID_XferFIFOInfo, &XferFIFOInfo, sizeof(XferFIFOInfo));
        if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get audio_capture Xfer FIFO info.\n"));
	}
        if (XferFIFOInfo.Size == 0)
	        len += snprintf(page + off + len, count - len, "capture Xfer FIFO size: - entries, - used\n");
        else
        	len += snprintf(page + off + len, count - len, "capture Xfer FIFO size: %ld entries, %ld used\n", XferFIFOInfo.Size, XferFIFOInfo.Size - XferFIFOInfo.Writable - 1);

	len += snprintf(page + off + len, count - len, "capture Xfer FIFO Info  : StartAdress = %ld, Size = %ld, Writable = %ld, Readable = %ld, Erasable = %ld \n",XferFIFOInfo.StartAddress, XferFIFOInfo.Size, XferFIFOInfo.Writable,XferFIFOInfo.Readable,XferFIFOInfo.Erasable);

	return len;

}

#ifdef WITH_VOIP
static int proc_read_voip(char *page,char **start,off_t off,int count,int *eof,void *mdata)
{
	int len = 0;
	struct monitoring_data *mD = (struct monitoring_data *) mdata;
	struct em8xxxprivate *pE = ((struct monitoring_data *) mdata)->pE;
	RMstatus err;
       	struct DataFIFOInfo DataFIFOInfo = {0, 0, 0};

	if (off != 0) return((int) off);

	RMDBGLOG((DISABLE, "Read voip%d page=%p start=%p off=%d count=%d eof=%p mdata=%p\n", mD->index, page, *start, off, count, eof, mdata));

	len += snprintf(page + off + len, count - len, "\nVoip Encoder ----------\n\n");

       	err = EMhwlibGetProperty(pE->pemhwlib, EMHWLIB_TARGET_MODULE(VoipCodec,mD->index,0), RMGenericPropertyID_DataFIFOInfo, &DataFIFOInfo, sizeof(DataFIFOInfo));
        if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get BTS_IN data FIFO info.\n"));
	}
        if (DataFIFOInfo.Size == 0)
        	len += snprintf(page + off + len, count - len, "BTS_IN data FIFO @0x%08lx size: 0KB, 0%% used\n",DataFIFOInfo.StartAddress);
        else
        	len += snprintf(page + off + len, count - len, "BTS_IN data FIFO @0x%08lx size: %ldKB, %ld%% used\n",DataFIFOInfo.StartAddress, DataFIFOInfo.Size / 1024, 100 - (DataFIFOInfo.Writable + 1) * 100 / DataFIFOInfo.Size);
                
       	err = EMhwlibGetProperty(pE->pemhwlib, EMHWLIB_TARGET_MODULE(VoipCodec,mD->index,4), RMGenericPropertyID_DataFIFOInfo, &DataFIFOInfo, sizeof(DataFIFOInfo));
        if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get Serial_IN data FIFO info.\n"));
	}
        if (DataFIFOInfo.Size == 0)
        	len += snprintf(page + off + len, count - len, "Serial_IN data FIFO @0x%08lx size: 0KB, 0%% used\n",DataFIFOInfo.StartAddress);
        else
        	len += snprintf(page + off + len, count - len, "Serial_IN data FIFO @0x%08lx size: %ldKB, %ld%% used\n",DataFIFOInfo.StartAddress, DataFIFOInfo.Size / 1024, 100 - (DataFIFOInfo.Writable + 1) * 100 / DataFIFOInfo.Size);

	len += snprintf(page + off + len, count - len, "\nVoip Decoder ----------\n\n");

       	err = EMhwlibGetProperty(pE->pemhwlib, EMHWLIB_TARGET_MODULE(VoipCodec,mD->index,1), RMGenericPropertyID_DataFIFOInfo, &DataFIFOInfo, sizeof(DataFIFOInfo));
        if (RMFAILED(err)) {
		RMDBGLOG((LOCALDBG, "Cannot get BTS_OUT data FIFO info.\n"));
	}
        if (DataFIFOInfo.Size == 0)
        	len += snprintf(page + off + len, count - len, "BTS_OUT data FIFO @0x%08lx size: 0KB, 0%% used\n",DataFIFOInfo.StartAddress);
        else
        	len += snprintf(page + off + len, count - len, "BTS_OUT data FIFO @0x%08lx size: %ldKB, %ld%% used\n",DataFIFOInfo.StartAddress, DataFIFOInfo.Size / 1024, 100 - (DataFIFOInfo.Writable + 1) * 100 / DataFIFOInfo.Size);
                
       	err = EMhwlibGetProperty(pE->pemhwlib, EMHWLIB_TARGET_MODULE(VoipCodec,mD->index,3), RMGenericPropertyID_DataFIFOInfo, &DataFIFOInfo, sizeof(DataFIFOInfo));
        if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get Serial_OUT data FIFO info.\n"));
	}
        if (DataFIFOInfo.Size == 0)
        	len += snprintf(page + off + len, count - len, "Serial_OUT data FIFO @0x%08lx size: 0KB, 0%% used\n",DataFIFOInfo.StartAddress);
        else
        	len += snprintf(page + off + len, count - len, "Serial_OUT data FIFO @0x%08lx size: %ldKB, %ld%% used\n",DataFIFOInfo.StartAddress, DataFIFOInfo.Size / 1024, 100 - (DataFIFOInfo.Writable + 1) * 100 / DataFIFOInfo.Size);

	len += snprintf(page + off + len, count - len, "\nDTMF  -------------\n\n");

       	err = EMhwlibGetProperty(pE->pemhwlib, EMHWLIB_TARGET_MODULE(VoipCodec,mD->index,5), RMGenericPropertyID_DataFIFOInfo, &DataFIFOInfo, sizeof(DataFIFOInfo));
        if (RMFAILED(err)) {
		RMDBGLOG((LOCALDBG, "Cannot get DTMF data FIFO info.\n"));
	}
        if (DataFIFOInfo.Size == 0)
        	len += snprintf(page + off + len, count - len, "DTMF data FIFO @0x%08lx size: 0KB, 0%% used\n",DataFIFOInfo.StartAddress);
        else
        	len += snprintf(page + off + len, count - len, "DTMF data FIFO @0x%08lx size: %ldKB, %ld%% used\n",DataFIFOInfo.StartAddress, DataFIFOInfo.Size / 1024, 100 - (DataFIFOInfo.Writable + 1) * 100 / DataFIFOInfo.Size);

	len += snprintf(page + off + len, count - len, "\nCID  -------------\n\n");

       	err = EMhwlibGetProperty(pE->pemhwlib, EMHWLIB_TARGET_MODULE(VoipCodec,mD->index,6), RMGenericPropertyID_DataFIFOInfo, &DataFIFOInfo, sizeof(DataFIFOInfo));
        if (RMFAILED(err)) {
		RMDBGLOG((LOCALDBG, "Cannot get CID In data FIFO info.\n"));
	}
        if (DataFIFOInfo.Size == 0)
        	len += snprintf(page + off + len, count - len, "CID In data FIFO @0x%08lx size: 0KB, 0%% used\n",DataFIFOInfo.StartAddress);
        else
        	len += snprintf(page + off + len, count - len, "CID In data FIFO @0x%08lx size: %ldB, %ld%% used\n",DataFIFOInfo.StartAddress, DataFIFOInfo.Size , 100 - (DataFIFOInfo.Writable + 1) * 100 / DataFIFOInfo.Size);

       	err = EMhwlibGetProperty(pE->pemhwlib, EMHWLIB_TARGET_MODULE(VoipCodec,mD->index,7), RMGenericPropertyID_DataFIFOInfo, &DataFIFOInfo, sizeof(DataFIFOInfo));
        if (RMFAILED(err)) {
		RMDBGLOG((LOCALDBG, "Cannot get CID Out data FIFO info.\n"));
	}
        if (DataFIFOInfo.Size == 0)
        	len += snprintf(page + off + len, count - len, "CID Out data FIFO @0x%08lx size: 0KB, 0%% used\n",DataFIFOInfo.StartAddress);
        else
        	len += snprintf(page + off + len, count - len, "CID Out data FIFO @0x%08lx size: %ldKB, %ld%% used\n",DataFIFOInfo.StartAddress, DataFIFOInfo.Size / 1024, 100 - (DataFIFOInfo.Writable + 1) * 100 / DataFIFOInfo.Size);
	return len;

}
#endif //WITH_VOIP

static int proc_read_audio_decoder(char *page, char **start, off_t off, int count, int *eof, void *mdata)
{
	int len = 0;
	struct monitoring_data *mD = (struct monitoring_data *) mdata;
	struct em8xxxprivate *pE = ((struct monitoring_data *) mdata)->pE;
        RMstatus err;
        enum AudioDecoder_State_type ad_state;
        RMuint32 ui32 = 0;
       	struct DataFIFOInfo DataFIFOInfo = {0, 0, 0};
       	struct XferFIFOInfo_type XferFIFOInfo = {0, 0, 0, 0};
	char *ad_states[] = {"Uninit", "Error", "StopPending", "Stopped", "PlayPending", "Playing", "PausePending", "Paused", "UninitPending", "Closed"};

	if (off != 0) return((int) (off));

	RMDBGLOG((DISABLE, "Read audio_decoder%d page=%p start=%p off=%d count=%d eof=%p mdata=%p\n", mD->index, page, *start, off, count, eof, mdata));

	err = EMhwlibGetProperty(pE->pemhwlib, EMHWLIB_MODULE(AudioDecoder, mD->index), RMAudioDecoderPropertyID_State, &ad_state, sizeof(ad_state));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get audio_decoder%d state.\n", mD->index));
	}

#if ((EM86XX_CHIP == EM86XX_CHIPID_TANGO2) && (EM86XX_MODE==EM86XX_MODEID_STANDALONE))
	// STANDALONE -- read proc may cause "Unhandled kernel unaligned access" fault
	//		 it is caused by DataFIFOInfo failed because DataFIFO has not initialed yet.
        if (ad_state == 9) {
		len += snprintf(page + off + len, count - len, "ad%ld state: %s\n", mD->index, ad_states[ad_state]);
		len += snprintf(page + off + len, count - len, "ad%ld current PTS: 0\n", mD->index);
        	len += snprintf(page + off + len, count - len, "ad%ld data FIFO size: 0KB, 0%% used\n", mD->index);
	        len += snprintf(page + off + len, count - len, "ad%ld Xfer FIFO size: - entries, - used\n", mD->index);
		len += snprintf(page + off + len, count - len, "ad%ld Xfer FIFO Info: StartAdress = 0, Size = 0, Writable = 0, Readable = 0, Erasable = 0\n", mD->index);
		return(len);
	}
#endif

	len += snprintf(page + off + len, count - len, "ad%ld state: %s\n", mD->index, ad_states[ad_state]);
        
	err = EMhwlibGetProperty(pE->pemhwlib, EMHWLIB_MODULE(AudioDecoder, mD->index), RMAudioDecoderPropertyID_CurrentPTS, &ui32, sizeof(ui32));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get audio_decoder%ld last PTS.\n", mD->index));
	}
        if (ad_state == 9) // Closed
		len += snprintf(page + off + len, count - len, "ad%ld current PTS: 0\n", mD->index);
	else
		len += snprintf(page + off + len, count - len, "ad%ld current PTS: %ld\n", mD->index, ui32);

       	EMhwlibGetProperty(pE->pemhwlib, EMHWLIB_MODULE(AudioDecoder, mD->index), RMGenericPropertyID_DataFIFOInfo, &DataFIFOInfo, sizeof(DataFIFOInfo));
        if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get audio_decoder%ld data FIFO info.\n", mD->index));
	}
        if ((DataFIFOInfo.Size == 0) || (ad_state == 9) /*Closed*/)
        	len += snprintf(page + off + len, count - len, "ad%ld data FIFO size: 0KB, 0%% used\n", mD->index);
        else
        	len += snprintf(page + off + len, count - len, "ad%ld data FIFO size: %ldKB, %ld%% used\n", mD->index, DataFIFOInfo.Size / 1024, 100 - (DataFIFOInfo.Writable + 1) * 100 / DataFIFOInfo.Size);
                
       	EMhwlibGetProperty(pE->pemhwlib, EMHWLIB_MODULE(AudioDecoder, mD->index), RMGenericPropertyID_XferFIFOInfo, &XferFIFOInfo, sizeof(XferFIFOInfo));
        if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get audio_decoder%ld Xfer FIFO info.\n", mD->index));
	}
        if ((XferFIFOInfo.Size == 0) || (ad_state == 9) /*Closed*/)
	        len += snprintf(page + off + len, count - len, "ad%ld Xfer FIFO size: - entries, - used\n", mD->index);
        else
        	len += snprintf(page + off + len, count - len, "ad%ld Xfer FIFO size: %ld entries, %ld used\n", mD->index, XferFIFOInfo.Size, XferFIFOInfo.Size - XferFIFOInfo.Writable - 1);

	len += snprintf(page + off + len, count - len, "ad%ld Xfer FIFO Info: StartAdress = %ld, Size = %ld, Writable = %ld, Readable = %ld, Erasable = %ld \n", mD->index,XferFIFOInfo.StartAddress, XferFIFOInfo.Size, XferFIFOInfo.Writable,XferFIFOInfo.Readable,XferFIFOInfo.Erasable);
        
#ifdef WITH_MONITORING_SIGMA
        err = EMhwlibGetProperty(pE->pemhwlib, EMHWLIB_MODULE(AudioDecoder, mD->index), RMAudioDecoderPropertyID_Overlay, &ui32, sizeof(ui32));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get audio_decoder%d overlay.\n", mD->index));
	}
	len += snprintf(page + off + len, count - len, "ad%d overlay: 0x%x\n", mD->index, ui32);
#endif

	return len;

}

static int proc_read_stc(char *page, char **start, off_t off, int count, int *eof, void *mdata)
{
	int len = 0;
	struct monitoring_data *mD = (struct monitoring_data *) mdata;
	struct em8xxxprivate *pE = ((struct monitoring_data *) mdata)->pE;
        RMint64 time = 0;
        RMuint32 time_resolution = STC_TIME_RESOLUTION;
        RMstatus err;
        
	if (off != 0) return((int) (off));

	RMDBGLOG((DISABLE, "Read STC%d page=%p start=%p off=%d count=%d eof=%p mdata=%p\n", mD->index, page, *start, off, count, eof, mdata));

	err = EMhwlibExchangeProperty(pE->pemhwlib, EMHWLIB_MODULE(STC, mD->index), 
				      RMSTCPropertyID_TimeInfo, 
				      &time_resolution, sizeof(time_resolution), &time, sizeof(time));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get STC%ld time.\n", mD->index));
	}
	len += snprintf(page + off + len, count - len, "STC%ld time: %lld\n", mD->index, time);

	return len;
}
#endif

struct proc_file_info {
	char *name;
	read_proc_t *callback;
} proc_files[] =
{
	{ "resources", proc_read_resources }, 
	{ "events", proc_read_events },
	{ "version", proc_read_version },
	{ "cleanables",proc_read_cleanables }
};

struct em8xxx_proc_private {
	struct proc_dir_entry *proc_dir;
	struct proc_dir_entry *proc_files[sizeof(proc_files)/sizeof(struct proc_file_info)];
#ifdef WITH_MONITORING
        struct proc_dir_entry *proc_monitoring_base_dir;
        struct proc_dir_entry *proc_video_monitoring_dir;
        struct proc_dir_entry *proc_audio_monitoring_dir;
        struct proc_dir_entry *proc_stc_monitoring_dir;
#ifdef WITH_VOIP
	struct proc_dir_entry *proc_voip_monitoring_dir;
	RMuint32 voip_codec_instances;
	struct monitoring_data voip_mdata[MAX_VOIP];
#endif //WITH_VOIP
        RMuint32 video_decoder_instances, audio_decoder_instances, stc_instances,audio_capture_instances;
        struct monitoring_data video_mdata[MAX_VIDEO_DECODERS], audio_mdata[MAX_AUDIO_DECODERS], stc_mdata[MAX_STC],audioin_mdata[MAX_AUDIO_CAPTURE];
#endif
};

static struct em8xxx_proc_private proc_table[MAXLLAD];
static struct proc_dir_entry *proc_base_dir = (struct proc_dir_entry *) NULL;



// ****************************************

#define TEXT_DRIVER_PROC_ENTRY "driver/"
#define PROC_ENTRY_FILE_ACCESS 0444

void add_driver_proc_entry(void)
{
	proc_base_dir = proc_mkdir(TEXT_DRIVER_PROC_ENTRY EM8XXX_DEVICE_NAME, NULL);
	proc_base_dir->owner = THIS_MODULE;
}

void rm_driver_proc_entry(void)
{
	remove_proc_entry(TEXT_DRIVER_PROC_ENTRY EM8XXX_DEVICE_NAME, NULL);
}

void add_board_proc_entry(unsigned int minor)
{
	struct em8xxx_proc_private *pP = &(proc_table[minor]);
	char temp_string[3];

	sprintf(temp_string, "%d", (int) minor);
	
	pP->proc_dir = proc_mkdir(temp_string, proc_base_dir);
	pP->proc_dir->owner = THIS_MODULE;
}

void rm_board_proc_entry(unsigned int minor)
{
	char temp_string[3];

	sprintf(temp_string, "%d", (int) minor);
	remove_proc_entry(temp_string, proc_base_dir);
}

void add_board_proc_files(unsigned int minor, void *data)
{
	struct em8xxx_proc_private *pP = &(proc_table[minor]);
	int i;

	for (i=0 ; i<sizeof(proc_files)/sizeof(struct proc_file_info) ; i++) {
		pP->proc_files[i] = create_proc_read_entry(proc_files[i].name,
							   PROC_ENTRY_FILE_ACCESS, 
							   pP->proc_dir,
							   proc_files[i].callback,
							   data);
		(pP->proc_files[i])->owner = THIS_MODULE;
	}
#ifdef WITH_MONITORING
        add_monitoring_entries(minor, data);
#endif
}

void rm_board_proc_files(unsigned int minor)
{
	struct em8xxx_proc_private *pP = &(proc_table[minor]);
	int i;

	for (i=0 ; i<sizeof(proc_files)/sizeof(struct proc_file_info) ; i++) {
		remove_proc_entry(proc_files[i].name, pP->proc_dir);
	}
#ifdef WITH_MONITORING
        rm_monitoring_entries(minor);
#endif
	
}

#ifdef WITH_MONITORING
void add_monitoring_entries(unsigned int minor, void *data)
{
	struct em8xxx_proc_private *pP = &(proc_table[minor]);
	struct em8xxxprivate *pE = (struct em8xxxprivate *) data;
	RMuint32 i;
	RMstatus err;
	RMuint32 category;
	char temp_string[16]; /* 16 = strlen(video_decoder) + 2 bytes for number of instances + 1 byte for '\0' */
        
   	pP->proc_monitoring_base_dir = proc_mkdir("monitoring", pP->proc_dir);
	pP->proc_monitoring_base_dir->owner = THIS_MODULE;
   	pP->proc_video_monitoring_dir = proc_mkdir("video", pP->proc_monitoring_base_dir);
	pP->proc_video_monitoring_dir->owner = THIS_MODULE;
   	pP->proc_audio_monitoring_dir = proc_mkdir("audio", pP->proc_monitoring_base_dir);
	pP->proc_audio_monitoring_dir->owner = THIS_MODULE;
   	pP->proc_stc_monitoring_dir = proc_mkdir("STC", pP->proc_monitoring_base_dir);
	pP->proc_stc_monitoring_dir->owner = THIS_MODULE;
#ifdef WITH_VOIP
   	pP->proc_voip_monitoring_dir = proc_mkdir("voip", pP->proc_monitoring_base_dir);
	pP->proc_voip_monitoring_dir->owner = THIS_MODULE;
#endif //WITH_VOIP
        category = VideoDecoder;	
	err = EMhwlibExchangeProperty(pE->pemhwlib, EMHWLIB_MODULE(Enumerator, 0), 
				      RMEnumeratorPropertyID_CategoryIDToNumberOfInstances, 
				      &category, sizeof(category), &pP->video_decoder_instances, sizeof(&pP->video_decoder_instances));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get video decoder count %d\n", err));
	}

	RMDBGLOG((ENABLE, "I found %d video decoders.\n", pP->video_decoder_instances));
        for (i=0 ; i < pP->video_decoder_instances ; i++) {
                
                pP->video_mdata[i].index = i;
                pP->video_mdata[i].pE = (struct em8xxxprivate *) data;
                sprintf(temp_string, "video_decoder%ld", i);
		create_proc_read_entry(temp_string, PROC_ENTRY_FILE_ACCESS, pP->proc_video_monitoring_dir, proc_read_video_decoder, &pP->video_mdata[i]);
        }

        category = AudioDecoder;	
	err = EMhwlibExchangeProperty(pE->pemhwlib, EMHWLIB_MODULE(Enumerator, 0), 
				      RMEnumeratorPropertyID_CategoryIDToNumberOfInstances, 
				      &category, sizeof(category), &pP->audio_decoder_instances, sizeof(&pP->audio_decoder_instances));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get audio decoder count %d\n", err));
	}

	RMDBGLOG((ENABLE, "I found %d audio decoders.\n", pP->audio_decoder_instances));
        for (i=0 ; i < pP->audio_decoder_instances ; i++) {
                
                pP->audio_mdata[i].index = i;
                pP->audio_mdata[i].pE = (struct em8xxxprivate *) data;
                sprintf(temp_string, "audio_decoder%ld", i);
		create_proc_read_entry(temp_string, PROC_ENTRY_FILE_ACCESS, pP->proc_audio_monitoring_dir, proc_read_audio_decoder, &pP->audio_mdata[i]);
        }
	
        category = AudioCapture;	
	err = EMhwlibExchangeProperty(pE->pemhwlib, EMHWLIB_MODULE(Enumerator, 0), 
				      RMEnumeratorPropertyID_CategoryIDToNumberOfInstances, 
				      &category, sizeof(category), &pP->audio_capture_instances, sizeof(&pP->audio_capture_instances));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get audio capture count %d\n", err));
	}

	RMDBGLOG((ENABLE, "I found %d audio capture modules.\n", pP->audio_capture_instances));
        for (i=0 ; i < pP->audio_capture_instances ; i++) {
                
                pP->audioin_mdata[i].index = i;
                pP->audioin_mdata[i].pE = (struct em8xxxprivate *) data;
                sprintf(temp_string, "audio_capture%ld", i);
		create_proc_read_entry(temp_string, PROC_ENTRY_FILE_ACCESS, pP->proc_audio_monitoring_dir, proc_read_audio_capture, &pP->audioin_mdata[i]);
        }

        category = STC;	
	err = EMhwlibExchangeProperty(pE->pemhwlib, EMHWLIB_MODULE(Enumerator, 0), 
				      RMEnumeratorPropertyID_CategoryIDToNumberOfInstances, 
				      &category, sizeof(category), &pP->stc_instances, sizeof(&pP->stc_instances));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get stc count %d\n", err));
	}

	RMDBGLOG((ENABLE, "I found %d STC.\n", pP->stc_instances));
        for (i=0 ; i < pP->stc_instances ; i++) {
                
                pP->stc_mdata[i].index = i;
                pP->stc_mdata[i].pE = (struct em8xxxprivate *) data;
                sprintf(temp_string, "STC%ld", i);
		create_proc_read_entry(temp_string, PROC_ENTRY_FILE_ACCESS, pP->proc_stc_monitoring_dir, proc_read_stc, &pP->stc_mdata[i]);
        }

#ifdef WITH_VOIP
        category = VoipCodec;	
	err = EMhwlibExchangeProperty(pE->pemhwlib, EMHWLIB_MODULE(Enumerator, 0), 
				      RMEnumeratorPropertyID_CategoryIDToNumberOfInstances, 
				      &category, sizeof(category), &pP->voip_codec_instances, sizeof(&pP->voip_codec_instances));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get voip count %d\n", err));
	}

	RMDBGLOG((ENABLE, "I found %d voip codec modules.\n", pP->voip_codec_instances));
        for (i=0 ; i < pP->voip_codec_instances ; i++) {
                
                pP->voip_mdata[i].index = i;
                pP->voip_mdata[i].pE = (struct em8xxxprivate *) data;
                sprintf(temp_string, "voip%ld", i);
		create_proc_read_entry(temp_string, PROC_ENTRY_FILE_ACCESS, pP->proc_voip_monitoring_dir, proc_read_voip, &pP->voip_mdata[i]);
        }
#endif // WITH_VOIP
}

void rm_monitoring_entries(unsigned int minor)
{
	struct em8xxx_proc_private *pP = &(proc_table[minor]);
	RMuint32 i;
	char temp_string[16]; /* 16 = strlen(video_decoder) + 2 bytes for number of instances + 1 byte for '\0' */

        for (i=0 ; i < pP->video_decoder_instances ; i++) {
                sprintf(temp_string, "video_decoder%ld", i);
		remove_proc_entry(temp_string, pP->proc_video_monitoring_dir);
        }
        remove_proc_entry("video", pP->proc_monitoring_base_dir);
        
        for (i=0 ; i < pP->audio_decoder_instances ; i++) {
                sprintf(temp_string, "audio_decoder%ld", i);
		remove_proc_entry(temp_string, pP->proc_audio_monitoring_dir);
        }
        for (i=0 ; i < pP->audio_capture_instances ; i++) {
                sprintf(temp_string, "audio_capture%ld", i);
		remove_proc_entry(temp_string, pP->proc_audio_monitoring_dir);
        }
        remove_proc_entry("audio", pP->proc_monitoring_base_dir);
        
        for (i=0 ; i < pP->stc_instances ; i++) {
                sprintf(temp_string, "STC%ld", i);
		remove_proc_entry(temp_string, pP->proc_stc_monitoring_dir);
        }
        remove_proc_entry("STC", pP->proc_monitoring_base_dir);
        
#ifdef WITH_VOIP
        for (i=0 ; i < pP->voip_codec_instances ; i++) {
                sprintf(temp_string, "voip%ld", i);
		remove_proc_entry(temp_string, pP->proc_voip_monitoring_dir);
        }
        remove_proc_entry("voip", pP->proc_monitoring_base_dir);
#endif // WITH_VOIP
        remove_proc_entry("monitoring", pP->proc_dir);
}
#endif

#endif
