/* dummy file in order to have the module named
 * em86xxfb when compiling for 2.6 linux kernels
 */
