/*****************************************
 Copyright @ 2005, 2006, 2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   em8xxxvoip_new.h
  @brief  

  New linux kernel telephony driver of our Voip Board

  @author Yoann Walther 
  @date   2006-11-07
*/

#ifndef __EM8XXXVOIP_NEW_H__
#define __EM8XXXVOIP_NEW_H__

#define SYS_GPIO_DATA REG_BASE_system_block + SYS_gpio_data
#define SYS_GPIO_DIR REG_BASE_system_block + SYS_gpio_dir
#define ETH_GPIO_DATA REG_BASE_host_interface + ETH_gpio_data2
#define ETH_GPIO_DIR REG_BASE_host_interface+ ETH_gpio_dir2
#define GPIO_DIR_INPUT 0
#define GPIO_DIR_OUTPUT 1

#define GPIO_SLIC_COMP    24
#define GPIO_SLIC_CTL1    25
#define GPIO_SLIC_CTL2    26
#define GPIO_LOOP_DETECT  27
#define GPIO_FAULT_DETECT 28
#define GPIO_SLIC_MUTE    29
#define GPIO_HDS_MUTE     30

#define ALLOW_OS_CODE 1

#define DEFAULT_CHECK_FREQ 500
#define DEFAULT_SAMPLE_RATE 8000
#define BTS_IN_FIFO_SIZE 1024
#define BTS_OUT_FIFO_SIZE 1024
#define DTMF_FIFO_SIZE 64
#define VOIP_EVENT_TIMEOUT_US 5000000 // 5 s
#define VOIP_MAX_FRAME_SIZE 480

#include "../../../emhwlib/include/emhwlib.h"
#include "../../../emhwlib/include/emhwlib_properties_1000.h"

#include "../../../emhwlib/include/emhwlib_event.h"
#include "../../../emhwlib/include/emhwlib_chipspecific.h"
#include "../include/em8xxx_uk.h"
#include "../../../llad/kinclude/kernelcalls.h"
#include "../../../llad/kinclude/mum_kk.h"
#include "../../../llad/include/kdmapool.h"
#include "../../../llad/include/gbus.h"
#include "../../../gbuslib/include/gbus_fifo.h"
#include "../../../rmaec/include/rmaec.h"

#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/version.h>

#include <linux/devfs_fs_kernel.h>
#include <linux/sched.h>
#include <linux/interrupt.h>
#include <linux/timer.h>
#include <linux/fs.h>
#include <linux/poll.h>
#include <linux/mm.h>
#include <linux/slab.h>
#include <linux/vmalloc.h>

#include <linux/telephony.h>
#include <linux/phonedev.h>

#include "em8xxx.h"
#include "em8xxx_proc.h"

#define EM8XXXVOIPSP(pE,moduleID,propertyID,pValue,valueSize)		\
	do {								\
		kc_spin_lock_bh(pE->lock);				\
		err = EMhwlibSetProperty(pE->pemhwlib,moduleID,propertyID,pValue,valueSize); \
		kc_spin_unlock_bh(pE->lock);				\
	} while (0)						

#define EM8XXXVOIPEXP(pE,moduleID,propertyID,pValue_in,valueSize_in,pValue_out,valueSize_out)	\
	do {								\
		kc_spin_lock_bh(pE->lock);				\
		err = EMhwlibExchangeProperty(pE->pemhwlib,moduleID,propertyID,pValue_in,valueSize_in,pValue_out,valueSize_out); \
		kc_spin_unlock_bh(pE->lock);				\
	} while (0)
	
#define EM8XXXVOIPGP(pE,moduleID,propertyID,pValue,valueSize)		\
	do {								\
		kc_spin_lock_bh(pE->lock);				\
		err = EMhwlibGetProperty(pE->pemhwlib,moduleID,propertyID,pValue,valueSize); \
		kc_spin_unlock_bh(pE->lock);				\
	} while (0)

enum SLIC_STATES {
	LOW_POWER_STANDBY=0,
	REVERSE_POLARITY,
	NORMAL_ACTIVE,
	RINGING,
	DISCONNECT
};

struct voipprivate {
	int voip_active;
	int voip_open_count;
	
	struct phone_device p_dev;
	struct fasync_struct *async_queue;
	union telephony_exception exc;
	
	RMbool hookstate;
	RMbool last_hookstate;
	int hook_cnt;

	struct timer_list timer;
	unsigned int check_interval;

	struct kc_wait_queue_head_t *command_q;
	struct kc_wait_queue_head_t *poll_q;
	struct kc_wait_queue_head_t *read_q;
	struct kc_wait_queue_head_t *write_q;
	struct tasklet_struct event_tq;
	RMuint32 event_mask;

	RMuint32 VoipUCodeAddr;
	RMuint32 VoipProfileCachedAddr;
	RMuint32 VoipProfileUncachedAddr;
};

static struct voipprivate VOIPtable[MAXLLAD];

#endif  //  __EM8XXXVOIP_NEW_H__

