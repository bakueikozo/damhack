/*****************************************
 Copyright � 2004-2005
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   em8xxx_alsa.c
  @brief  

  Alsa driver for the EM8xxx serie.
  Strategy :
  The main sound cards do not have their proper DRAM, and the sound engine just reads data
  from the DRAM of the computer and sends them to the DAC.
  We have an external harware buffer, and the strategy is to make an intermediate buffer and copy/set the data from it to the external hardware buffer in tasklets.
  We handle the interrupt which occurs when the send_data is complete, and in the tasklet we transfer another block of data.
  
  @author Yoann Walther
  @date   2005-07-21
*/

#ifndef __SNDEM8XXX_C__
#define __SNDEM8XXX_C__

#include "em8xxxalsa.h"

extern struct em8xxxprivate Etable[MAXLLAD];

RMstatus krua_register_sendcomplete_callback(void *pE, Alsa_callback callback);
RMstatus krua_unregister_sendcomplete_callback(void *pE);
RMstatus krua_register_event_callback(void *pE, RMuint32 ModuleID, RMuint32 mask,Event_callback callback);
RMstatus krua_unregister_event_callback(void *pE,RMuint32 ModuleID,Event_callback callback);
 
static u_long audio_decoder_index = 1;
static u_long audio_engine_index;
static u_long audio_capture_index;
static u_long audio_mmID = 0;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,17)
module_param(audio_decoder_index, ulong,0 );
module_param(audio_mmID, ulong,0);
#else
MODULE_PARM(audio_decoder_index, "l");
MODULE_PARM(audio_mmID, "l");
#endif

MODULE_PARM_DESC(audio_decoder_index, "Audio Decoder in use\n");
MODULE_PARM_DESC(audio_mmID, "Audio Memory Manager in use\n");

MODULE_DESCRIPTION("EM8XXX Sound Alsa Driver");
MODULE_AUTHOR("Yoann Walther <yoann_walther@realmagic.fr>");
MODULE_LICENSE("Proprietary");


static int snd_em8xxx_free(em8xxx_t *chip);
static int snd_em8xxx_dev_free(snd_device_t *device);
#if EM86XX_MODE==EM86XX_MODEID_WITHHOST
static int __devinit snd_em8xxx_create(snd_card_t * card,struct pci_dev * pci,em8xxx_t * chip);
#else
static int __devinit snd_em8xxx_create(snd_card_t * card,em8xxx_t * chip);
#endif
static int sndprivate_init(struct em8xxxprivate *pE);
static int sndprivate_cleanup(struct em8xxxprivate *pE);
static int snd_em8xxx_info_hw_volume(snd_kcontrol_t *kcontrol, snd_ctl_elem_info_t * uinfo);
static int snd_em8xxx_get_hw_volume(snd_kcontrol_t * kcontrol, snd_ctl_elem_value_t * ucontrol);
static int snd_em8xxx_put_hw_volume(snd_kcontrol_t * kcontrol, snd_ctl_elem_value_t * ucontrol);
static void snd_em8xxx_hwv_free(snd_kcontrol_t *kcontrol);
static int snd_em8xxx_info_weight(snd_kcontrol_t *kcontrol, snd_ctl_elem_info_t * uinfo);
static int snd_em8xxx_get_weight(snd_kcontrol_t * kcontrol, snd_ctl_elem_value_t * ucontrol);
static int snd_em8xxx_put_weight(snd_kcontrol_t * kcontrol, snd_ctl_elem_value_t * ucontrol);
static void snd_em8xxx_weight_free(snd_kcontrol_t *kcontrol);
static int __devinit snd_em8xxx_mixer(em8xxx_t *chip);
static int snd_em8xxx_capture_open(snd_pcm_substream_t * substream);
static int snd_em8xxx_playback_open(snd_pcm_substream_t * substream);
static int snd_em8xxx_capture_close(snd_pcm_substream_t * substream);
static int snd_em8xxx_playback_close(snd_pcm_substream_t * substream);
static int snd_em8xxx_pcm_hw_params(snd_pcm_substream_t *substream,snd_pcm_hw_params_t * hw_params);
static int snd_em8xxx_pcm_hw_free(snd_pcm_substream_t *substream);
static int snd_em8xxx_playback_prepare(snd_pcm_substream_t * substream);
static int snd_em8xxx_capture_prepare(snd_pcm_substream_t * substream);
static int snd_em8xxx_playback_trigger(snd_pcm_substream_t * substream,int cmd);
static int snd_em8xxx_capture_trigger(snd_pcm_substream_t * substream,int cmd);
static snd_pcm_uframes_t snd_em8xxx_playback_pointer(snd_pcm_substream_t * substream);
static snd_pcm_uframes_t snd_em8xxx_capture_pointer(snd_pcm_substream_t * substream);
static int snd_em8xxx_playback_ack(snd_pcm_substream_t * substream);
static int snd_em8xxx_capture_ack(snd_pcm_substream_t * substream);
static void snd_em8xxx_free_pcm(snd_pcm_t *pcm);
static int __devinit snd_em8xxx_new_pcm(em8xxx_t *chip, int device, snd_pcm_t ** rpcm);
static RMstatus init_audio(em8xxx_t *pS);
static RMstatus open_audio_capture(em8xxx_t *pS);
static RMstatus open_audio_decoder(em8xxx_t *pS);
static RMstatus set_audio_parameters(em8xxx_t *pS);
static RMstatus prepare_audio_decoder(em8xxx_t *pS);
static int send_data_callback(void *pE,RMuint32 bus_address);
static RMuint32 receive_data_callback(void *pE,RMuint32 ModuleID,RMuint32 mask);
static void em8xxx_playback_start_interrupt(unsigned long private_data);
static void em8xxx_capture_start_interrupt(unsigned long private_data);
static int em8xxx_pcm_playback_update (em8xxx_t *chip);
static int em8xxx_pcm_capture_update (em8xxx_t *chip);
static int playback_update_position (em8xxx_t *chip);
static int capture_update_position (em8xxx_t *chip);
static void em8xxx_playback_setaudio_interrupt(unsigned long private_data);
static void em8xxx_capture_setaudio_interrupt(unsigned long private_data);
static RMstatus start_stc(em8xxx_t *chip);
static int snd_em8xxx_free_ptr(struct em8xxxprivate *pE,RMuint32 ptr);
static void em8xxx_playback_stop_interrupt(unsigned long private_data);
static void em8xxx_playback_stop_interrupt(unsigned long private_data);
static int snd_em8xxx_spdif_mask_info(snd_kcontrol_t *kcontrol,snd_ctl_elem_info_t *uinfo);
static int snd_em8xxx_spdif_mask_get(snd_kcontrol_t * kcontrol,snd_ctl_elem_value_t *ucontrol);
static int snd_em8xxx_spdif_default_info(snd_kcontrol_t *kcontrol,snd_ctl_elem_info_t *uinfo);
static int snd_em8xxx_spdif_default_get(snd_kcontrol_t *kcontrol,snd_ctl_elem_value_t *ucontrol);
static int snd_em8xxx_spdif_default_put(snd_kcontrol_t * kcontrol,snd_ctl_elem_value_t * ucontrol);
static void snd_em8xxx_spdif_default_free(snd_kcontrol_t *kcontrol);
static void snd_em8xxx_spdif_mask_free(snd_kcontrol_t *kcontrol);
static int snd_em8xxx_uswitch_info(snd_kcontrol_t *kcontrol, snd_ctl_elem_info_t *uinfo);
static int snd_em8xxx_spdout_enable_get(snd_kcontrol_t *kcontrol, snd_ctl_elem_value_t *ucontrol);
static int snd_em8xxx_spdout_enable_put(snd_kcontrol_t *kcontrol, snd_ctl_elem_value_t *ucontrol);
static void snd_em8xxx_spdif_switch_free(snd_kcontrol_t *kcontrol);
static RMstatus prepare_data(em8xxx_t *pS);



/* *******************************************************************
************             SPDIF PART DRIVER                 ***********
**********************************************************************/

static int snd_em8xxx_spdif_mask_info(snd_kcontrol_t *kcontrol,snd_ctl_elem_info_t *uinfo)
{
	uinfo->type = SNDRV_CTL_ELEM_TYPE_IEC958;
	uinfo->count = 1;
	return 0;
}

static int snd_em8xxx_spdif_mask_get(snd_kcontrol_t * kcontrol,snd_ctl_elem_value_t *ucontrol)
{
	int i;
	RMuint32 mask;
	em8xxx_t * chip = snd_kcontrol_chip(kcontrol);
	struct em8xxxprivate * pE = Etable + (chip-Stable);
	struct AudioEngine_ChannelStatus_type channel_status;
	RMstatus err;

	EM8XXXSNDGP(pE,EMHWLIB_MODULE(AudioEngine,audio_engine_index),RMAudioEnginePropertyID_ChannelStatus,&channel_status,sizeof(channel_status));
	channel_status.Mask=0xffffffff;

	/* When changing the value of the Channel Bit Status the hwlib do an and logic with the mask. This one was initialized to zero by default. */

	EM8XXXSNDSP(pE,EMHWLIB_MODULE(AudioEngine,audio_engine_index),RMAudioEnginePropertyID_ChannelStatus,&channel_status,sizeof(channel_status));
	mask=channel_status.Mask;
	kc_spin_lock_bh(pE->lock);
	for (i = 0; i < 4; i++)
		ucontrol->value.iec958.status[i] = (mask >> (i * 8)) & 0xff;
	kc_spin_unlock_bh(pE->lock);

	return 0;
}

static void snd_em8xxx_spdif_mask_free(snd_kcontrol_t *kcontrol)
{
	em8xxx_t *chip = (em8xxx_t *) snd_kcontrol_chip(kcontrol);
	chip->spdif_mask_ctl = NULL;
}

static int snd_em8xxx_spdif_default_info(snd_kcontrol_t *kcontrol,snd_ctl_elem_info_t *uinfo)
{
	uinfo->type = SNDRV_CTL_ELEM_TYPE_IEC958;
	uinfo->count = 1;
	return 0;
}

static int snd_em8xxx_spdif_default_get(snd_kcontrol_t *kcontrol,snd_ctl_elem_value_t *ucontrol)
{
	int i;
	RMuint32 val;
	em8xxx_t * chip = snd_kcontrol_chip(kcontrol);
	struct em8xxxprivate * pE = Etable + (chip-Stable);
	struct AudioEngine_ChannelStatus_type channel_status;
	RMstatus err;

	EM8XXXSNDGP(pE,EMHWLIB_MODULE(AudioEngine,audio_engine_index),RMAudioEnginePropertyID_ChannelStatus,&channel_status,sizeof(channel_status));
	val = channel_status.Value;

	kc_spin_lock_bh(pE->lock);
	for (i = 0; i < 4; i++)
		ucontrol->value.iec958.status[i] = (val >> (i * 8)) & 0xff;
	kc_spin_unlock_bh(pE->lock);
	return 0;
}

static int snd_em8xxx_spdif_default_put(snd_kcontrol_t * kcontrol,snd_ctl_elem_value_t * ucontrol)
{
	em8xxx_t *chip = snd_kcontrol_chip(kcontrol);
	int i, change;
	unsigned int val;
	struct em8xxxprivate * pE = Etable + (chip-Stable);
	struct AudioEngine_ChannelStatus_type channel_status;
	RMstatus err;
	RMuint32 value;

	EM8XXXSNDGP(pE,EMHWLIB_MODULE(AudioEngine,audio_engine_index),RMAudioEnginePropertyID_ChannelStatus,&channel_status,sizeof(channel_status));
	value = channel_status.Value;

	val = 0;
	kc_spin_lock_bh(pE->lock);
	for (i = 0; i < 4; i++)
		val |= (unsigned int)ucontrol->value.iec958.status[i] << (i * 8);
	change = val != value;
       	channel_status.Value=val;
	channel_status.Mask=0xffffffff;
	EMhwlibSetProperty(pE->pemhwlib,EMHWLIB_MODULE(AudioEngine,audio_engine_index),RMAudioEnginePropertyID_ChannelStatus,&channel_status,sizeof(channel_status));
	if(RMFAILED(err)){
		printk("error while setting S/PDIF Channel Bit Status");
	}
	kc_spin_unlock_bh(pE->lock);
	return change;
}

static void snd_em8xxx_spdif_default_free(snd_kcontrol_t *kcontrol)
{
	em8xxx_t *chip = (em8xxx_t *) snd_kcontrol_chip(kcontrol);
	chip->spdif_default_ctl = NULL;
}

static int snd_em8xxx_uswitch_info(snd_kcontrol_t *kcontrol, snd_ctl_elem_info_t *uinfo)
{
	uinfo->type = SNDRV_CTL_ELEM_TYPE_BOOLEAN;
	uinfo->count = 1;
	uinfo->value.integer.min = 0;
	uinfo->value.integer.max = 1;
	return 0;
}

static int snd_em8xxx_spdout_enable_get(snd_kcontrol_t *kcontrol, snd_ctl_elem_value_t *ucontrol)
{
	em8xxx_t *chip = snd_kcontrol_chip(kcontrol);
	struct em8xxxprivate *pE = Etable +(chip-Stable);
	enum AudioEngine_SpdifOut_type spdif_out;
	RMstatus err;
	RMuint32 audio_engine = EMHWLIB_MODULE(AudioEngine,audio_engine_index);
	
	EM8XXXSNDGP(pE, audio_engine, RMAudioEnginePropertyID_SpdifOut, &spdif_out, sizeof(spdif_out));
	if (spdif_out==AudioEngine_SpdifOut_Active){
		ucontrol->value.integer.value[0]=1;
	}
	else {
		ucontrol->value.integer.value[0]=0;
	}
	return 0;
}

static int snd_em8xxx_spdout_enable_put(snd_kcontrol_t *kcontrol, snd_ctl_elem_value_t *ucontrol)
{
	em8xxx_t *chip = snd_kcontrol_chip(kcontrol);
	struct em8xxxprivate *pE = Etable +(chip-Stable);
	enum AudioEngine_SpdifOut_type spdif_out;
	RMstatus err;
	RMuint32 audio_engine = EMHWLIB_MODULE(AudioEngine,audio_engine_index);
	int changed=0;
	
	if (ucontrol->value.integer.value[0]!=chip->spdif_enable){
		changed=1;
		if (ucontrol->value.integer.value[0]) {
			spdif_out= AudioEngine_SpdifOut_Active;
			EM8XXXSNDSP(pE, audio_engine, RMAudioEnginePropertyID_SpdifOut, &spdif_out, sizeof(spdif_out));
			chip->spdif_enable=1;
		} 
		else {
			spdif_out= AudioEngine_SpdifOut_ActiveData0;
			EM8XXXSNDSP(pE, audio_engine, RMAudioEnginePropertyID_SpdifOut, &spdif_out, sizeof(spdif_out));
			chip->spdif_enable=0;
		}
	}
	return changed;
}


static void snd_em8xxx_spdif_switch_free(snd_kcontrol_t *kcontrol)
{
	em8xxx_t *chip = (em8xxx_t *) snd_kcontrol_chip(kcontrol);
	chip->spdif_switch_ctl = NULL;
}


/* *******************************************************************
 *************            MIXER PART DRIVER             *************
 ******************************************************************* */


static int snd_em8xxx_info_hw_volume(snd_kcontrol_t *kcontrol, snd_ctl_elem_info_t * uinfo)
{
	uinfo->type = SNDRV_CTL_ELEM_TYPE_INTEGER;
	uinfo->count = 2;
	uinfo->value.integer.min = 0;
	uinfo->value.integer.max = 73;
	return 0;
}

static int snd_em8xxx_info_weight(snd_kcontrol_t *kcontrol, snd_ctl_elem_info_t * uinfo)
{
	uinfo->type = SNDRV_CTL_ELEM_TYPE_INTEGER;
	uinfo->count = 2;
	uinfo->value.integer.min = 0;
	uinfo->value.integer.max = 73;
	return 0;
}
static int snd_em8xxx_get_hw_volume(snd_kcontrol_t * kcontrol, snd_ctl_elem_value_t * ucontrol)
{
	em8xxx_t * chip = snd_kcontrol_chip(kcontrol);
	struct em8xxxprivate * pE = Etable + (chip-Stable);
	struct AudioEngine_QueryVolume_in_type volume_in;
	struct AudioEngine_QueryVolume_out_type volume_out;
	RMstatus err;
	int l,r,volume_index;


	/* gets the left volume */
	
	volume_in.Channel=0;
	
	EM8XXXSNDEXP(pE,EMHWLIB_MODULE(AudioEngine,audio_engine_index),RMAudioEnginePropertyID_QueryVolume,&volume_in,sizeof(volume_in),&volume_out,sizeof(volume_out));
		
	l=volume_out.Volume;
	volume_index=0;
	while((l)>(VolumeTable[volume_index])){
		volume_index++;
	}
	ucontrol->value.integer.value[0] = volume_index;;	

	/* gets the right volume */
	
	volume_in.Channel=2;
	
	EM8XXXSNDEXP(pE,EMHWLIB_MODULE(AudioEngine,audio_engine_index),RMAudioEnginePropertyID_QueryVolume,&volume_in,sizeof(volume_in),&volume_out,sizeof(volume_out));
	
	r=volume_out.Volume;
	volume_index=0;
	while((r)>(VolumeTable[volume_index])){
		volume_index++;
	}
	ucontrol->value.integer.value[1] = volume_index; 
	
	return 0;
}

static int snd_em8xxx_get_weight(snd_kcontrol_t * kcontrol, snd_ctl_elem_value_t * ucontrol)
{
	em8xxx_t * chip = snd_kcontrol_chip(kcontrol);

	ucontrol->value.integer.value[0] = chip->weight_l;	
	ucontrol->value.integer.value[1] = chip->weight_r; 
	
	return 0;
}

static int snd_em8xxx_put_hw_volume(snd_kcontrol_t * kcontrol, snd_ctl_elem_value_t * ucontrol)
{
	em8xxx_t *chip = snd_kcontrol_chip(kcontrol);
	struct em8xxxprivate * pE = Etable + (chip-Stable);
	struct AudioEngine_Volume_type volume;
	int volume_index;
	RMstatus err;

	/* sets the left volume */

	volume_index=ucontrol->value.integer.value[0];
	volume.Channel=0;
	volume.Volume=VolumeTable[volume_index];
	
	EM8XXXSNDSP(pE,EMHWLIB_MODULE(AudioEngine,audio_engine_index),RMAudioEnginePropertyID_Volume,&volume,sizeof(volume));
	if (RMFAILED(err)){
		printk("error while setting volume \n");
	}
	
	/* sets the right volume */

	volume_index=ucontrol->value.integer.value[1];
	volume.Channel=2;
	volume.Volume=VolumeTable[volume_index];
	
	EM8XXXSNDSP(pE,EMHWLIB_MODULE(AudioEngine,audio_engine_index),RMAudioEnginePropertyID_Volume,&volume,sizeof(volume));
	if (RMFAILED(err)){
		printk("error while setting volume \n");
	}
	
	return 0;
}
static int snd_em8xxx_put_weight(snd_kcontrol_t * kcontrol, snd_ctl_elem_value_t * ucontrol)
{
	em8xxx_t *chip = snd_kcontrol_chip(kcontrol);
	struct em8xxxprivate * pE = Etable + (chip-Stable);
	struct AudioDecoder_MixerWeight_type cmdblock;
	int volume_index;
	RMstatus err;

	/* sets the left volume */

	volume_index=ucontrol->value.integer.value[0];
	chip->weight_l=volume_index;

	cmdblock.MixerValue_ch0=VolumeTable[volume_index];
	
	EM8XXXSNDSP(pE,EMHWLIB_MODULE(AudioDecoder,audio_decoder_index),RMAudioDecoderPropertyID_MixerWeight,&cmdblock,sizeof(cmdblock));
	if (RMFAILED(err)){
		printk("error while setting decoder weight \n");
	}
	
	/* sets the right volume */

	volume_index=ucontrol->value.integer.value[1];
	chip->weight_r=volume_index;

	cmdblock.MixerValue_ch2=VolumeTable[volume_index];
	
	EM8XXXSNDSP(pE,EMHWLIB_MODULE(AudioDecoder,audio_decoder_index),RMAudioDecoderPropertyID_MixerWeight,&cmdblock,sizeof(cmdblock));
	if (RMFAILED(err)){
		printk("error while setting decoder weight \n");
	}
	
	return 0;
}

static void snd_em8xxx_hwv_free(snd_kcontrol_t *kcontrol)
{
	em8xxx_t *chip = (em8xxx_t *) snd_kcontrol_chip(kcontrol);
	chip->master_volume = NULL;
}

static void snd_em8xxx_weight_free(snd_kcontrol_t *kcontrol)
{
	em8xxx_t *chip = (em8xxx_t *) snd_kcontrol_chip(kcontrol);
	chip->decoder_weight = NULL;
}

static snd_kcontrol_new_t snd_em8xxx_control[]  = {
	{
		.iface = SNDRV_CTL_ELEM_IFACE_MIXER,
		.name = "Hardware Master Playback Volume",
		.index = 0,
		.access = SNDRV_CTL_ELEM_ACCESS_READWRITE,
		.private_value = 0xffff,
		.info = snd_em8xxx_info_hw_volume,
		.get = snd_em8xxx_get_hw_volume,
		.put = snd_em8xxx_put_hw_volume,
	},
	{
		.iface =	SNDRV_CTL_ELEM_IFACE_PCM,
		.name =		SNDRV_CTL_NAME_IEC958("",PLAYBACK,DEFAULT),
		.info =		snd_em8xxx_spdif_default_info,
		.get =		snd_em8xxx_spdif_default_get,
		.put =		snd_em8xxx_spdif_default_put
	},
	{
		.access =	SNDRV_CTL_ELEM_ACCESS_READ,
		.iface =	SNDRV_CTL_ELEM_IFACE_MIXER,
		.name =		SNDRV_CTL_NAME_IEC958("",PLAYBACK,CON_MASK),
		.info =		snd_em8xxx_spdif_mask_info,
		.get =		snd_em8xxx_spdif_mask_get,
	},
	{ 
		.name = SNDRV_CTL_NAME_IEC958("",PLAYBACK,SWITCH),
		.iface = SNDRV_CTL_ELEM_IFACE_MIXER,
		.info = snd_em8xxx_uswitch_info,
		.get = snd_em8xxx_spdout_enable_get,
		.put = snd_em8xxx_spdout_enable_put,
	},
	{
		.iface = SNDRV_CTL_ELEM_IFACE_MIXER,
		.name = "Decoder Weight",
		.index = 0,
		.access = SNDRV_CTL_ELEM_ACCESS_READWRITE,
		.private_value = 0xffff,
		.info = snd_em8xxx_info_weight,
		.get = snd_em8xxx_get_weight,
		.put = snd_em8xxx_put_weight,
	}
};

static int __devinit snd_em8xxx_mixer(em8xxx_t *chip)
{
	snd_card_t *card;
	int err,idx;
	card = chip->card;
	
	strcpy(card->mixername, "EM8xxx");
	
	for (idx = 0; idx < ARRAY_SIZE(snd_em8xxx_control); idx++) {
		snd_kcontrol_t *kctl;
		kctl = snd_ctl_new1(&snd_em8xxx_control[idx], chip);
		if ((err = snd_ctl_add(card, kctl)) < 0){
			printk("error adding control ! \n");
			return err;
		}
		switch (idx) {
		case 0:
			chip->master_volume = kctl;
			kctl->private_free = snd_em8xxx_hwv_free;
			break;
		case 1:
			chip->spdif_default_ctl = kctl;
			kctl->private_free = snd_em8xxx_spdif_default_free;
			break;
		case 2:
			chip->spdif_mask_ctl = kctl;
			kctl->private_free = snd_em8xxx_spdif_mask_free;
			break;
		case 3:
			chip->spdif_switch_ctl = kctl;
			kctl->private_free = snd_em8xxx_spdif_switch_free;
			break;
		case 4:
			chip->decoder_weight = kctl;
			kctl->private_free = snd_em8xxx_weight_free;
			break;
		}	

	}
	
	return 0;
}



/* ********************************************************************
 *************           PCM PART DRIVER                **************
 ******************************************************************** */

static snd_pcm_ops_t snd_em8xxx_playback_ops = {
	.open =		snd_em8xxx_playback_open,
	.close =	snd_em8xxx_playback_close,
	.ioctl =	snd_pcm_lib_ioctl,
	.hw_params =	snd_em8xxx_pcm_hw_params,
	.hw_free =	snd_em8xxx_pcm_hw_free,
	.prepare =	snd_em8xxx_playback_prepare,
	.trigger =	snd_em8xxx_playback_trigger,
	.pointer =	snd_em8xxx_playback_pointer,
	.ack =          snd_em8xxx_playback_ack,
};

static snd_pcm_ops_t snd_em8xxx_capture_ops = {
	.open =		snd_em8xxx_capture_open,
	.close =	snd_em8xxx_capture_close,
	.ioctl =	snd_pcm_lib_ioctl,
	.hw_params =	snd_em8xxx_pcm_hw_params,
	.hw_free =	snd_em8xxx_pcm_hw_free,
	.prepare =	snd_em8xxx_capture_prepare,
	.trigger =	snd_em8xxx_capture_trigger,
	.pointer =	snd_em8xxx_capture_pointer,
	.ack =          snd_em8xxx_capture_ack,
};
static snd_pcm_hardware_t snd_em8xxx_playback = {
	.info =		   (SNDRV_PCM_INFO_INTERLEAVED | SNDRV_PCM_INFO_PAUSE),
	.formats =          SNDRV_PCM_FMTBIT_U8 | SNDRV_PCM_FMTBIT_S16_LE,
	.rates =            SNDRV_PCM_RATE_CONTINUOUS | SNDRV_PCM_RATE_8000_96000,
	.rate_min =         8000,
	.rate_max =         96000,
	.channels_min =     1,
	.channels_max =     2,
	.buffer_bytes_max = 32*(1024),
	.period_bytes_min = 2048,
	.period_bytes_max = 32*(1024),
	.periods_min =      2,
	.periods_max =      32,
	.fifo_size =        8000,
};

static snd_pcm_hardware_t snd_em8xxx_capture = {
	.info =		   (SNDRV_PCM_INFO_INTERLEAVED | SNDRV_PCM_INFO_PAUSE),
	.formats =          (SNDRV_PCM_FMTBIT_S16_LE | SNDRV_PCM_FMTBIT_U8),
	.rates =            SNDRV_PCM_RATE_CONTINUOUS | SNDRV_PCM_RATE_8000_96000,
	.rate_min =         8000,
	.rate_max =         96000,
	.channels_min =     1,
	.channels_max =     2,
	.buffer_bytes_max = 32*(1024),
	.period_bytes_min = 4096,
	.period_bytes_max = 32*(1024),
	.periods_min =      2,
	.periods_max =      32,
	.fifo_size =        8000,
};

static RMstatus init_audio(em8xxx_t *pS)
{
	struct em8xxxprivate *pE=Etable+(pS-Stable);
	RMstatus err; 
	struct MM_Malloc_in_type in;
	enum ProcessorState run;
	RMuint32 audio_engine=EMHWLIB_MODULE(AudioEngine,audio_engine_index);
	struct MM_Malloc_out_type out;
#if !defined(WITH_UCODE_BOOTLOADER) && !defined(WITH_XLOADED_UCODE)
	struct DemuxEngine_MicrocodeDRAMSize_in_type demux_size_in;
	struct DemuxEngine_MicrocodeDRAMSize_out_type demux_size_out;
	struct DemuxEngine_Microcode_type demux_ucode;
	RMuint32 demux_engine=EMHWLIB_MODULE(DemuxEngine,0);
	struct AudioEngine_MicrocodeDRAMSize_in_type size_in;
	struct AudioEngine_MicrocodeDRAMSize_out_type size_out;
	struct AudioEngine_Microcode_type ucode;

	// Loading Demux module
	
 	run = CPU_RESET;

	EM8XXXSNDSP(pE, demux_engine, RMDemuxEnginePropertyID_State, &run, sizeof(run));

	if (RMFAILED(err)){
		RMDBGLOG((ENABLE, "Error while resetting CPU! \n"));
		return err;
	}

       
	run = CPU_STOPPED;

	EM8XXXSNDSP(pE, demux_engine, RMDemuxEnginePropertyID_State, &run, sizeof(run));

	if (RMFAILED(err)){
		RMDBGLOG((ENABLE, "Error while stopping CPU! \n"));
		return err;
	}
	
	// Loading Microcode for Demux Module
	
	demux_size_in.MicrocodeVersion = 1;

	EM8XXXSNDEXP(pE, demux_engine, RMDemuxEnginePropertyID_MicrocodeDRAMSize,
		     &demux_size_in, sizeof(demux_size_in), &demux_size_out, sizeof(demux_size_out));
	
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting property RMDemuxEnginePropertyID_MicrocodeDRAMSize! %s\n"));
		return err;
	}
	
	demux_ucode.MicrocodeVersion = demux_size_in.MicrocodeVersion;
	
	if (demux_size_out.Size){
		in.dramtype=RUA_DRAM_CACHED;
		in.Size=demux_size_out.Size;
	
		EM8XXXSNDEXP(pE,
			     EMHWLIB_MODULE(MM,0),
			     RMMMPropertyID_Malloc,
			     &in,sizeof(in),
			     &out,sizeof(out));
		if(err==RM_OK) 
			demux_ucode.Address= (RMuint32)out.Address;
		else {
			RMDBGLOG((ENABLE," memory manager not existent\n"));
			return 0;
		}
	
		
		
		
		RMDBGLOG((ENABLE, "demux ucode cached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n", demux_ucode.Address, demux_size_out.Size, demux_ucode.Address + demux_size_out.Size));
	}
	else {
		demux_ucode.Address = 0;
		RMDBGLOG((ENABLE, "demux ucode doesn't need DRAM\n"));
	}

	EM8XXXSNDSP(pE, demux_engine, RMDemuxEnginePropertyID_Microcode, &demux_ucode, sizeof(demux_ucode));

	if (RMFAILED(err)){
		RMDBGLOG((ENABLE, "Error while loading microcode for Demux Module! \n"));
		return err;
	}


	// starting the DemuxEngine Module
	
	run = CPU_RUNNING;

	EM8XXXSNDSP(pE, demux_engine, RMDemuxEnginePropertyID_State, &run, sizeof(run));

	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error setting property DemuxEngineProperty_State! \n"));
		return err;
	}
	

	// Loading AudioEngine Module

	run = CPU_RESET;

	EM8XXXSNDSP(pE, audio_engine, RMAudioEnginePropertyID_State, &run, sizeof(run));

	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error while resetting CPU! \n"));
		return err;
	}
	
	run = CPU_STOPPED;

	EM8XXXSNDSP(pE, audio_engine, RMAudioEnginePropertyID_State, &run, sizeof(run));
	
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error while stopping CPU! \n"));
		return err;
	} 
	
	// Loading MicroCode for AudioEngine Module


	size_in.MicrocodeVersion = 1;
	
	// memory allocation for the microcode

	EM8XXXSNDEXP( pE, audio_engine, RMAudioEnginePropertyID_MicrocodeDRAMSize, &size_in, sizeof(size_in), &size_out, sizeof(size_out));

	if (RMFAILED(err)) { 
		RMDBGLOG((ENABLE, "Error while allocating memory for audio microcode! \n"));
		return err;
	} 

	ucode.MicrocodeVersion = size_in.MicrocodeVersion;
	
	in.dramtype=RUA_DRAM_CACHED;
	in.Size=size_out.Size;
	

	EM8XXXSNDEXP(pE,
		     EMHWLIB_MODULE(MM,0),
		     RMMMPropertyID_Malloc,
		     &in,sizeof(in),
		     &out,sizeof(out));
	if(err==RM_OK) 
		ucode.Address= (RMuint32)out.Address;
	else {
		RMDBGLOG((ENABLE," memory manager not existent\n"));
		return 0;
	}
	
	printk("audio ucode cached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
	       ucode.Address,
	       size_out.Size,
	       ucode.Address + size_out.Size);
	
	pS->AudioUCodeAddr = ucode.Address;
	
	//  microcode loading

	EM8XXXSNDSP( pE, audio_engine, RMAudioEnginePropertyID_Microcode, &ucode, sizeof(ucode));

	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error while loading audio microcode! \n"));
       		return err;
	}
#else
	EM8XXXSNDSP(pE, DemuxEngine, RMDemuxEnginePropertyID_TimerInit, NULL, 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error while launching STC code inside TDMX %d\n", err));
		return err;
	}
#endif // WITH_UCODE_BOOTLOADER
	RMDBGLOG((ENABLE, "End of audio init! \n"));
	return RM_OK;  
}

static RMstatus open_audio_decoder(em8xxx_t *pS)
{
	struct em8xxxprivate *pE=Etable+(pS-Stable);
	RMstatus err; 
	struct AudioDecoder_DRAMSizeX_in_type dram_in;
	struct AudioDecoder_DRAMSizeX_out_type dram_out;
	struct AudioDecoder_OpenX_type profile; 
	enum ProcessorState run;
	RMuint32 audio_engine=EMHWLIB_MODULE(AudioEngine,audio_engine_index);
	RMuint32 audio_decoder=EMHWLIB_MODULE(AudioDecoder,audio_decoder_index);
	struct MM_Malloc_in_type in;
	struct MM_Malloc_out_type out;
	struct STC_Open_type stc_open;
	struct AudioEngine_DecoderSharedMemory_type shared;
	struct AudioEngine_DecoderSharedMemoryInfo_in_type info_in; 
	struct AudioEngine_DecoderSharedMemoryInfo_out_type info_out;
	
	printk("opening STC \n");
	//  STC Opening

	stc_open.master=Master_STC;
	if(audio_engine_index==0)
		stc_open.stc_timer_id=audio_decoder_index*1;
	else
		if (audio_decoder_index==2)
			stc_open.stc_timer_id=0;
		else
			stc_open.stc_timer_id=2;
	stc_open.stc_time_resolution=90000;
	stc_open.video_timer_id=NO_TIMER;
	stc_open.video_time_resolution=0;
	stc_open.video_offset=0;
	if(audio_engine_index==0)
		stc_open.audio_timer_id=audio_decoder_index*1+1;
	else
		if (audio_decoder_index==2)
			stc_open.audio_timer_id=1;
		else
			stc_open.audio_timer_id=3;
	stc_open.audio_time_resolution=90000;
	stc_open.audio_offset=0;

	EM8XXXSNDSP(pE,EMHWLIB_MODULE(STC,audio_decoder_index),RMSTCPropertyID_Open,&stc_open,sizeof(stc_open));

	if (RMFAILED(err)){
		printk("Error while opening STC Module! \n");
		return err;
	}
	
	pS->firstPTS = TRUE;
	pS->audio_set = FALSE;

	/*Allocation of Shared memory*/
		
	info_in.Reserved1 = 0;
	info_in.Reserved2 = 0;
	EM8XXXSNDEXP(pE, audio_engine, RMAudioEnginePropertyID_DecoderSharedMemoryInfo, &info_in, sizeof(info_in), &info_out, sizeof(info_out));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting property RMAudioDecoderPropertyID_DecoderDataMemory!\n"));
		return err;
	}

	/* check if audio shared memory is already set in audio engine */
	EM8XXXSNDGP(pE, audio_engine, RMAudioEnginePropertyID_DecoderSharedMemory, &shared, sizeof(shared));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get DecoderSharedMemory\n"));
		return err;
	}
	if (shared.Address) {
		printk("=================%lx_DRAM AUDIO SHARED MEMORY is already set addr=0x%lx size=0x%lx\n",
			audio_engine, shared.Address, shared.Size);
	}
	else {
		/* allocate and set the shared memory used by all decoders of the same engine */
		shared.Size = info_out.DecoderSharedSize;
		if (shared.Size) {
			in.dramtype=RUA_DRAM_CACHED;
			in.Size=shared.Size;

			EM8XXXSNDEXP(pE, EMHWLIB_MODULE(MM,audio_mmID), 
			     RMMMPropertyID_Malloc,
			     &in,sizeof(in),
			     &out,sizeof(out));
			
			if(err == RM_OK)
				shared.Address = (RMuint32)out.Address;
			else {
				shared.Address = 0;
				RMDBGLOG((ENABLE, "ERROR: could not allocate shared 0x%08lX bytes in DRAM %lu!\n", shared.Address, 0L));
				return RM_FATALOUTOFMEMORY;
			}

			RMDBGPRINT((ENABLE, "===============ALLOCATING %lx_DRAM AUDIO SHARED MEMORY addr: 0x%08lX, size 0x%08lX\n", audio_engine, shared.Address, shared.Size));

			EM8XXXSNDSP(pE, audio_engine, RMAudioEnginePropertyID_DecoderSharedMemory, &shared, sizeof(shared));
		}
	}

	// Get the information for DRAM parameters for AudioDecoder Module 
	dram_in.ProtectedFlags = 0;
	dram_in.MaxChannelOutCount = MAXCHANNELOUTCOUNT; 
	dram_in.PtsFIFOCount = 30*60;
	dram_in.PCMLineCount = PCMLINECOUNT;
	dram_in.InbandFIFOCount = 128;
	dram_in.BitstreamFIFOSize = AUDIO_BITSTREAM_FIFO_SIZE; // DMA total buffer size
	dram_in.XferFIFOCount = AUDIO_DMA_BUFFER_COUNT;
	dram_in.XtaskInbandFIFOCount = 0;

	// Memory allocation for AudioDecoder Module

	EM8XXXSNDEXP(pE, audio_decoder, RMAudioDecoderPropertyID_DRAMSizeX, &dram_in, sizeof(dram_in), &dram_out, sizeof(dram_out));
	
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "No memory available for Audio RISC Processor! \n"));
		return err;
	} 
		
	// Creation of the audio profile
	profile.ProtectedFlags = 0; /*All memory is unprotected*/
	profile.MaxChannelOutCount = dram_in.MaxChannelOutCount;
	profile.PtsFIFOCount = dram_in.PtsFIFOCount;
	profile.InbandFIFOCount = dram_in.InbandFIFOCount;
	profile.PCMLineCount = dram_in.PCMLineCount;
	profile.BitstreamFIFOSize = dram_in.BitstreamFIFOSize;
	profile.XferFIFOCount = dram_in.XferFIFOCount;
	profile.XtaskInbandFIFOCount = 0;
	profile.XtaskId = 0;
	profile.OutputSamplesProtectedAddress = 0;
	profile.OutputSamplesProtectedSize = 0;
	profile.BitstreamProtectedAddress = 0;
	profile.BitstreamProtectedSize = 0;
	profile.UnprotectedSize = dram_out.UnprotectedSize;
	pS->AudioProfileCachedAddr = 0;

	if (profile.UnprotectedSize > 0){
		in.dramtype=RUA_DRAM_UNCACHED;
		in.Size=profile.UnprotectedSize;
	
		EM8XXXSNDEXP(pE,
			     EMHWLIB_MODULE(MM,0),
			     RMMMPropertyID_Malloc,
			     &in,sizeof(in),
			     &out,sizeof(out));
		if(err==RM_OK) 
			profile.UnprotectedAddress = (RMuint32)out.Address;
		else {
			RMDBGLOG((ENABLE," memory manager not existent\n"));
			return 0;
		}
	
		printk("audio uncached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
		       profile.UnprotectedAddress,
		       profile.UnprotectedSize,
		       profile.UnprotectedAddress + profile.UnprotectedSize);
	}
	else { profile.UnprotectedAddress = 0; }

	pS->AudioProfileUncachedAddr = profile.UnprotectedAddress;
	profile.STCId = audio_decoder_index;

	EM8XXXSNDSP(pE, audio_decoder, RMAudioDecoderPropertyID_OpenX, &profile, sizeof(profile));

	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error while creating audio profile! \n"));
		return err;
	}
	else RMDBGLOG((ENABLE, "Audio profile created! \n"));
	// starting the Audio RISC 
	
	run = CPU_RUNNING;

	EM8XXXSNDSP(pE, audio_engine, RMAudioEnginePropertyID_State, &run, sizeof(run));

	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error while starting CPU! \n"));
		return err;
	}
	else RMDBGLOG((ENABLE, "CPU now running! \n"));
	
	pS->prepared = FALSE;
	return err;
}

static RMstatus open_audio_capture(em8xxx_t *pS)
{
	struct em8xxxprivate *pE=Etable+(pS-Stable);
	RMstatus err; 
	struct AudioCapture_DRAMSize_in_type capture_dram_in;
	struct AudioCapture_DRAMSize_out_type capture_dram_out;
	struct AudioCapture_Open_type capture_profile; 
	enum ProcessorState run;
	RMuint32 audio_engine=EMHWLIB_MODULE(AudioEngine,audio_engine_index);
	RMuint32 audio_capture=EMHWLIB_MODULE(AudioCapture,audio_capture_index);
	struct MM_Malloc_in_type in;
	struct MM_Malloc_out_type out;
		
	// Get the information for DRAM parameters for AudioCapture Module 

	capture_dram_in.SerialInFIFOSize = SERIALIN_FIFO_SIZE; 
	capture_dram_in.XferFIFOCount = SERIALIN_DMA_BUFFER_COUNT;

	// Memory allocation for AudioCapture Module

	EM8XXXSNDEXP(pE, audio_capture, RMAudioCapturePropertyID_DRAMSize, &capture_dram_in, sizeof(capture_dram_in), &capture_dram_out, sizeof(capture_dram_out));

	// Creation of the audio capture profile

	capture_profile.CaptureMode = 0; // File mode
	capture_profile.Delay=0;
	capture_profile.SI_CONF=0x107 | (1 << 3);
	capture_profile.SerialInFIFOSize = capture_dram_in.SerialInFIFOSize;
	capture_profile.XferFIFOCount = capture_dram_in.XferFIFOCount;
	capture_profile.CachedSize = capture_dram_out.CachedSize;
	
	if (capture_profile.CachedSize > 0){
		in.dramtype=RUA_DRAM_CACHED;
		in.Size=capture_profile.CachedSize;
		
		EM8XXXSNDEXP(pE,
			     EMHWLIB_MODULE(MM,0),
			     RMMMPropertyID_Malloc,
			     &in,sizeof(in),
			     &out,sizeof(out));
		if(err==RM_OK) 
			capture_profile.CachedAddress= (RMuint32)out.Address;
		else {
			RMDBGLOG((ENABLE," memory manager not existent\n"));
			return 0;
		}
	
		printk("audio capture cached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
		       capture_profile.CachedAddress,
		       capture_profile.CachedSize,
		       capture_profile.CachedAddress + capture_profile.CachedSize);
	}
	else { capture_profile.CachedAddress = 0; }
	
	pS->SerialinProfileCachedAddr = capture_profile.CachedAddress;
	
	capture_profile.UncachedSize = capture_dram_out.UncachedSize;
	if (capture_profile.UncachedSize > 0){
		in.dramtype=RUA_DRAM_UNCACHED;
		in.Size=capture_profile.UncachedSize;
		
	
		EM8XXXSNDEXP(pE,
			     EMHWLIB_MODULE(MM,0),
			     RMMMPropertyID_Malloc,
			     &in,sizeof(in),
			     &out,sizeof(out));
		if(err==RM_OK) 
			capture_profile.UncachedAddress = (RMuint32)out.Address;
		else {
			RMDBGLOG((ENABLE," memory manager not existent\n"));
			return 0;
		}
	
		printk("audio capture uncached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
		       capture_profile.UncachedAddress,
		       capture_profile.UncachedSize,
		       capture_profile.UncachedAddress + capture_profile.UncachedSize);
	}
	else { capture_profile.UncachedAddress = 0; }

	pS->SerialinProfileUncachedAddr = capture_profile.UncachedAddress;

	EM8XXXSNDSP(pE, audio_capture, RMAudioCapturePropertyID_Open, &capture_profile, sizeof(capture_profile));
	
	// starting the Audio RISC 
	
	run = CPU_RUNNING;

	EM8XXXSNDSP(pE, audio_engine, RMAudioEnginePropertyID_State, &run, sizeof(run));

	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error while starting CPU! \n"));
		return err;
	}

	/* Open the capture dma pool  */

	pS->capture_dmapool_id=kdmapool_open(pE->pllad,NULL,SERIALIN_DMA_BUFFER_COUNT,SERIALIN_DMA_BUFFER_SIZE_LOG2); 
	printk("capture_dmapool id = %ld\n", pS->capture_dmapool_id);
	prepare_data(pS);

	return err;
}

static RMstatus set_audio_parameters(em8xxx_t *pS)
{
	RMuint32 audio_engine = EMHWLIB_MODULE(AudioEngine,audio_engine_index);
        struct em8xxxprivate *pE = Etable +(pS-Stable);
	enum AudioEngine_SerialOut_type serialOutStatus;
	struct AudioEngine_SampleFrequencyFromSource_type sf;
	struct AudioEngine_I2SConfig_type i2s;
	enum AudioEngine_SpdifOut_type spdif_out;
	RMstatus err;
	struct AudioEngine_Volume_type volume;
	int i,closed;
       	enum AudioDecoder_State_type state;

	printk("set audio parameters \n");

	// Volume Initialization
	for (i = 0; i <= 9; i++){
		volume.Channel = i;
		volume.Volume = 0x10000000;
		
		EM8XXXSNDSP(pE, audio_engine, RMAudioEnginePropertyID_Volume, &volume, sizeof(volume));
		
		if (RMFAILED(err)){
			RMDBGLOG((ENABLE, "Error while setting audio volume! \n"));
			return err;
		}
	}

	// We have to know if the other decoder is working
	
	closed=1;

#ifdef RMFEATURE_HAS_AUDIO_ENGINE_1
	switch(audio_engine_index){
	case 0:
		EM8XXXSNDGP(pE,EMHWLIB_MODULE(AudioDecoder,1-audio_decoder_index),RMAudioDecoderPropertyID_State,&state,sizeof(state));
		if (state != AudioDecoder_State_Closed) closed=0;
		break;
	case 1:
		if (audio_decoder_index==2){
			EM8XXXSNDGP(pE,EMHWLIB_MODULE(AudioDecoder,3),RMAudioDecoderPropertyID_State,&state,sizeof(state));
		}
		else
			EM8XXXSNDGP(pE,EMHWLIB_MODULE(AudioDecoder,2),RMAudioDecoderPropertyID_State,&state,sizeof(state));
		if (state != AudioDecoder_State_Closed) closed=0;
		break;
	}
	
#else
	EM8XXXSNDGP(pE,EMHWLIB_MODULE(AudioDecoder,1-audio_decoder_index),RMAudioDecoderPropertyID_State,&state,sizeof(state));
	if (state != AudioDecoder_State_Closed) closed=0;
	
#endif // RMFEATURE_HAS_AUDIO_ENGINE_1
	if(closed==1){
		/* Setting the sample freqency */
		
		EM8XXXSNDSP(pE, audio_engine, RMAudioEnginePropertyID_SampleFrequency, &pS->sample_rate, sizeof(pS->sample_rate));
		
		if (RMFAILED(err)){
			printk("Error while setting the sample frequency\n");
			return err;
		}
		
		// Applying AudioEngine Module Options
		
		spdif_out = AudioEngine_SpdifOut_Active;
		
		EM8XXXSNDSP(pE, audio_engine, RMAudioEnginePropertyID_SpdifOut, &spdif_out, sizeof(spdif_out));
		
		if (RMFAILED (err)) {
			RMDBGLOG((ENABLE, "Error setting spdif_out property! \n"));
			return err;
		}
		pS->spdif_enable=1;
		
		sf.GeneratorNumber = 3;
		sf.SampleFrequency = pS->sample_rate;
		sf.Source = 1;
		sf.SourceFrequency = 27000000;
		sf.IntermediateFrequency = 148500000;
		
		EM8XXXSNDSP(pE, audio_engine, RMAudioEnginePropertyID_SampleFrequencyFromSource, &sf, sizeof(sf));
		
		if (RMFAILED (err)) {
			RMDBGLOG((ENABLE, "Error setting sf property! \n"));
			return err;
		}
		
		
		i2s.DataAlignment = 1;
		i2s.SClkInvert = TRUE;
		i2s.FrameInvert = TRUE;
		i2s.MSBFirst = TRUE;
		i2s.SampleSize16Bit = FALSE;
		
		EM8XXXSNDSP(pE, audio_engine, RMAudioEnginePropertyID_I2SConfig, &i2s, sizeof(i2s));
		
		if (RMFAILED (err)) {
			RMDBGLOG((ENABLE, "Error setting i2s property! \n"));
			return err;
		}
	
		
		serialOutStatus = AudioEngine_SerialOut_SO_ENABLE;
		
		EM8XXXSNDSP(pE, audio_engine, RMAudioEnginePropertyID_SerialOut, &serialOutStatus, sizeof(serialOutStatus));
		
		if (RMFAILED (err)) {
			RMDBGLOG((ENABLE, "Error setting serialOut property! \n"));
			return err;
		}
	}
	 RMDBGLOG((ENABLE, "Audio Engine properties set \n"));

	pS->prepared=TRUE;

	return RM_OK;
}

static RMstatus prepare_audio_decoder(em8xxx_t *pS)
{
       	long timeout;
	enum AudioDecoder_Command_type command;
	enum AudioDecoder_Codec_type codec;
	RMuint32 audio_decoder = EMHWLIB_MODULE(AudioDecoder,audio_decoder_index);
	struct em8xxxprivate *pE=Etable+(pS-Stable);
	RMstatus err;
	struct AudioDecoder_PcmCdaParameters_type pcm_parameters;
	struct AudioDecoder_MixerWeight_type cmdblock;
	RMuint32 pts_delay = PTS_FIRST_DELAY;

	// Weight Initialisation

	// Mixer weight initialization
	
	cmdblock.MixerValue_ch0=0x10000000;
	cmdblock.MixerValue_ch1=0x10000000;
	cmdblock.MixerValue_ch2=0x10000000;
	cmdblock.MixerValue_ch3=0x10000000;
	cmdblock.MixerValue_ch4=0x10000000;
	cmdblock.MixerValue_ch5=0x10000000;
	cmdblock.MixerValue_ch6=0x10000000;
	cmdblock.MixerValue_ch7=0x10000000;
	EM8XXXSNDSP( pE, audio_decoder,RMAudioDecoderPropertyID_MixerWeight,&cmdblock,sizeof(cmdblock));
      
	pS->weight_l=VOLUME_INDEX_0DB;
	pS->weight_r=VOLUME_INDEX_0DB;

	 codec = pS->format;
	 
	
	 //   Uninit
	 timeout = 0;
	command = AudioDecoder_Command_Uninit;

	EM8XXXSNDSP(pE,audio_decoder,RMAudioDecoderPropertyID_Command,&command,sizeof(command));

	if (RMFAILED(err)){
		RMDBGLOG((ENABLE, "Unable to Uninit \n"));
		return err;
	}
	kc_udelay(1000);

	//  Format

	EM8XXXSNDSP(pE, audio_decoder, RMAudioDecoderPropertyID_Codec, &codec, sizeof(codec));

	if (RMFAILED(err)){
		RMDBGLOG((ENABLE, "Error setting codec property! \n"));
		return err;
	}

	// PCM Parameters
	
	switch(pS->channel_count) {
	case 1:
		pcm_parameters.ChannelAssign = PcmCda1_C;
		break;
	case 2:
	default:
		pcm_parameters.ChannelAssign = PcmCda2_LR;
		break;
	}
	pcm_parameters.BitsPerSample = pS->nb_bits_per_sample;
	pcm_parameters.SamplingFrequency = pS->sample_rate;
	pcm_parameters.MsbFirst = pS->MSBFirst;
	pcm_parameters.OutputDualMode = DualMode_Stereo;
	pcm_parameters.OutputSpdif = OutputSpdif_Uncompressed;
	pcm_parameters.OutputChannels = Audio_Out_Ch_LR;
	pcm_parameters.OutputLfe = FALSE;
	pcm_parameters.SignedPCM = (pS->nb_bits_per_sample==16) ? TRUE : FALSE;
	pcm_parameters.BassMode = 0;


	EM8XXXSNDSP(pE, audio_decoder, RMAudioDecoderPropertyID_PcmCdaParameters, &pcm_parameters, sizeof(pcm_parameters));

	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error setting pcm parameters! \n"));	
		return err;
	}
	
	//Init

	command = AudioDecoder_Command_Init;

	EM8XXXSNDSP(pE, audio_decoder, RMAudioDecoderPropertyID_Command, &command, sizeof(command));

	if (RMFAILED(err)){
		RMDBGLOG((ENABLE, "Error while initializing audio decoder! \n"));
		return err;
	}
	timeout =0;
	kc_udelay(1000);
	
	printk("audio parameters are set : samplerate = %d, nb_bits_per_sample = %d, channelcount = %d\n", pS->sample_rate,pS->nb_bits_per_sample ,pS->channel_count);

/* 		Pre fill Buffer to avoid underrun */

	EM8XXXSNDSP(pE,EMHWLIB_MODULE(AudioDecoder,audio_decoder_index),RMAudioDecoderPropertyID_PreFillBuffer,&pts_delay,sizeof(pts_delay));
	if (RMFAILED(err)){
		printk("error while prefilling buffer");
	}

	pS->audio_set=TRUE;

	
	return RM_OK;
}

static RMstatus start_stc(em8xxx_t *chip)
{
	struct STC_Speed_type speed;
	RMstatus err;
	struct em8xxxprivate *pE = Etable + (chip-Stable);
	enum AudioDecoder_Command_type command;
	enum AudioDecoder_State_type state;
	RMuint32 audio_decoder = EMHWLIB_MODULE(AudioDecoder,audio_decoder_index);
	RMuint32 AudioBtsThreshold=AUDIO_BTS_THRESHOLD;
	

	if(!chip->STCStarted){
		chip->STCStarted = TRUE;
		/* To avoid the DAC to play non-valid data we start/stop the stc in the same time we do a Pause/Play on the AudioDecoder */		
		EM8XXXSNDGP(pE, audio_decoder, RMAudioDecoderPropertyID_State, &state, sizeof(state));
		if(state!=AudioDecoder_State_Playing){

			EM8XXXSNDSP(pE,audio_decoder, RMAudioDecoderPropertyID_AudioBtsThreshold, &AudioBtsThreshold,sizeof(RMuint32));

			command = AudioDecoder_Command_Play;
			EM8XXXSNDSP(pE, audio_decoder, RMAudioDecoderPropertyID_Command, &command, sizeof(command));
			
			if (RMFAILED(err)){
				RMDBGLOG((ENABLE, "Error while sending play command to audio decoder! \n"));
			}
			kc_udelay(100000);
			
		}
		
		// Run STC
	
		speed.nominator = 1;
		speed.denominator = 1;
		
		EM8XXXSNDSP(pE, EMHWLIB_MODULE(STC,audio_decoder_index), RMSTCPropertyID_Speed, &speed, sizeof(speed));
		
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error while setting STC speed! \n"));
			return err;
		}
		
		EM8XXXSNDSP(pE, EMHWLIB_MODULE(STC,audio_decoder_index), RMSTCPropertyID_Play,NULL,0);
		
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error while sending Play command to STC! \n"));
			return err;
		}
		
	
	}
	return RM_OK;
}


static int em8xxx_pcm_playback_update (em8xxx_t *chip)
{
	snd_pcm_substream_t *substream = chip->playback_substream;
	snd_pcm_runtime_t *runtime = substream->runtime;

	/* We send at each interrupt a block which size is equal to period_size.
	 Thus, we have to notify the Alsa Pcm middle layer that the period is elapsed, 
	and it can the update the appl-ptr. */

	playback_update_position(chip);
	if(chip->last_count==frames_to_bytes(runtime,runtime->period_size))
		snd_pcm_period_elapsed(substream);

	return 0;
}

static int em8xxx_pcm_capture_update (em8xxx_t *chip)
{
	snd_pcm_substream_t *substream = chip->capture_substream;
	
	/* We send at each interrupt a block which size is equal to period_size.
	 Thus, we have to notify the Alsa Pcm middle layer that the period is elapsed, 
	and it can the update the appl-ptr. */

	capture_update_position(chip);
	snd_pcm_period_elapsed(substream);

	return 0;
}

static int playback_update_position (em8xxx_t *chip)
{
	int last_ptr,size;
	snd_pcm_substream_t *substream = chip->playback_substream;
	snd_pcm_runtime_t *runtime = substream->runtime;

	last_ptr = chip->hw_ptr+bytes_to_frames(runtime,chip->last_count);
	size = last_ptr - chip->hw_ptr;
	chip->hw_ptr = last_ptr;
	chip->transferred += size;
	if (chip->hw_ptr >= (int)runtime->buffer_size)
		chip->hw_ptr %= runtime->buffer_size;
	return 0;
}

static int capture_update_position (em8xxx_t *chip)
{
	int last_ptr,size;
	snd_pcm_substream_t *substream = chip->capture_substream;
	snd_pcm_runtime_t *runtime = substream->runtime;

	last_ptr = chip->capture_hw_ptr+runtime->period_size;
	size = last_ptr - chip->capture_hw_ptr;
	chip->capture_hw_ptr = last_ptr;
	chip->capture_transferred += size;
	if (chip->capture_hw_ptr >= (int)runtime->buffer_size)
		chip->capture_hw_ptr %= runtime->buffer_size;
	return 0;
}


static int send_data_callback(void *pE,RMuint32 bus_address)
{
	struct em8xxxprivate * real_pE = (struct em8xxxprivate *) pE;
	em8xxx_t *chip = Stable+(real_pE-Etable);
	struct emhwlib_info Info;
	struct emhwlib_info *pInfo = &Info;
	struct em8xxx_data param;
	RMuint32 Info_size;
	snd_pcm_substream_t * substream = chip->playback_substream;
	snd_pcm_runtime_t *runtime = substream->runtime;
	RMstatus err=RM_PENDING;
	void * context;
	size_t count;

	RMDBGLOG((DISABLE,"Send_data_callback\n"));

	if (chip->running){
		if(bus_address!=0)
			em8xxx_pcm_playback_update(chip);

		count=frames_to_bytes(runtime,runtime->period_size);
		chip->last_count=count;
		
		pInfo = NULL;
		Info_size = 0;
		
		param.moduleId = EMHWLIB_MODULE(AudioDecoder,audio_decoder_index);
		param.poolId = MAXDMAPOOL;
		param.dataSize = count;
		
		param.bus_addr = kc_virt_to_bus((unsigned long)runtime->dma_area+frames_to_bytes(runtime,chip->hw_ptr));
		
		kc_flush_cache((void *) (kc_virt_to_phys((unsigned long)runtime->dma_area+frames_to_bytes(runtime,chip->hw_ptr))), count);
		context =(void *) (((real_pE-Etable) << 16) + param.poolId + 1);
	
		// here we are in tasklet mode, so we have to lock for SMP case
 		kc_spin_lock(real_pE->lock); 
		err=EMhwlibSendBuffer(real_pE->pemhwlib, param.moduleId, param.bus_addr, param.dataSize, pInfo, Info_size, context);
 		kc_spin_unlock(real_pE->lock); 

	}
	return 0;
}

static RMstatus prepare_data(em8xxx_t *pS)
{
	struct em8xxx_data param;
	struct em8xxxprivate *pE = Etable + (pS-Stable);
	RMuint8 *buffer=NULL;
	RMuint32 timeout = 0;
	RMstatus err=RM_OK;
	RMuint32 audio_capture = EMHWLIB_MODULE(AudioCapture,audio_capture_index);
	struct ReadBufferInfo prop;
	RMuint32 nb_buf=0;

	while (1) {

		timeout=0;
	
		buffer=kdmapool_getbuffer(pE->pllad,pS->capture_dmapool_id,&timeout);
				
		if (buffer==NULL){
			break;
		}
		nb_buf++;
	
		param.moduleId = audio_capture;
		param.poolId = pS->capture_dmapool_id;
		param.bus_addr = kdmapool_get_bus_address(pE->pllad,pS->capture_dmapool_id,buffer, 0);
		param.dataSize = (1<<SERIALIN_DMA_BUFFER_SIZE_LOG2);
		
		prop.address = param.bus_addr;
		prop.size = param.dataSize;
		prop.context = (void *) ((pE-Etable) + param.poolId + 1);

		EM8XXXSNDSP(pE, param.moduleId, RMGenericPropertyID_AddReadBuffer, &prop, sizeof(prop));
		
		buffer=NULL;
	}
	printk("prepared %ld buffers \n",nb_buf);
	return err;
	
}

static RMuint32 receive_data_callback(void *pE,RMuint32 ModuleID,RMuint32 mask)
{
	struct em8xxxprivate *real_pE = (struct em8xxxprivate *) pE;
	em8xxx_t *chip = Stable + (real_pE-Etable);
	RMuint32 status=0;

	RMDBGLOG((DISABLE,"receive_data_callabck\n"));

	if (mask & SOFT_IRQ_EVENT_XFER_RECEIVE_READY) {
		tasklet_schedule(&chip->receive_data_tq);
		status |= SOFT_IRQ_EVENT_XFER_RECEIVE_READY;
	}

	return status;
}
static void receive_data_interrupt(unsigned long private_data)
{
	em8xxx_t *chip = (em8xxx_t *) private_data;
	struct em8xxxprivate *pE = Etable +(chip-Stable);
	RMstatus err;
	RMuint32 audio_capture = EMHWLIB_MODULE(AudioCapture,audio_capture_index);
	struct em8xxx_data param;
	void *context;
	RMuint8 info[INFO_SIZE];
	RMuint32 infoSize = INFO_SIZE;
	RMuint32 event_mask;
	RMuint32 i,j;
	snd_pcm_substream_t * substream = chip->capture_substream;
	snd_pcm_runtime_t *runtime = substream->runtime;
	struct ReadBufferInfo prop;

	/* Clear Event */
	RMDBGLOG((ENABLE,"Receive_data_interrupt\n"));

	event_mask = SOFT_IRQ_EVENT_XFER_RECEIVE_READY;
	
	// we are in tasklet mode, we have to lock for SMP
	kc_spin_lock(pE->lock);
	EMhwlibSetProperty(pE->pemhwlib,audio_capture,RMGenericPropertyID_ClearEventMask,&event_mask, sizeof(event_mask));
	kc_spin_unlock(pE->lock);

	while(1){

		if(chip->capture_pBuf==NULL){
			
			/* Receive buffer */
			param.moduleId = audio_capture;
			param.poolId = chip->capture_dmapool_id;
			param.infoSize = infoSize;
			printk("receive buffer \n");
		
			// we are in tasklet mode, so we have to lock for SMP
			kc_spin_lock(pE->lock);
			err=EMhwlibReceiveBuffer(pE->pemhwlib, param.moduleId, &(param.bus_addr), &(param.dataSize), info, &(param.infoSize), &context);
			kc_spin_unlock(pE->lock);

			if (RMFAILED(err)){
				break;
			}

			chip->capture_buffer_bus_addr = param.bus_addr;
			chip->capture_pBuf=kdmapool_get_virt_address(pE->pllad,chip->capture_dmapool_id,chip->capture_buffer_bus_addr, 0);
			chip->capture_buffer_size = param.dataSize;
			chip->capture_readable = param.dataSize;
			chip->i_start=0;
		}
		else{
			chip->i_start=chip->last_i;
		}
		
		i=chip->i_start;
		j=chip->j_start;
		
		while(j<frames_to_bytes(runtime,runtime->period_size)){
			if (i>=chip->capture_buffer_size){
				break;
			}
			switch(chip->state){
			case 0:
				if(chip->nb_bits_per_sample==8)
					runtime->dma_area[(j+frames_to_bytes(runtime,chip->capture_hw_ptr))]=chip->capture_pBuf[i]+128;
				else
					runtime->dma_area[(j+1+frames_to_bytes(runtime,chip->capture_hw_ptr))]=chip->capture_pBuf[i];
				j++;
				break;
			case 1:
				if(chip->nb_bits_per_sample==16){
					runtime->dma_area[(j-1+frames_to_bytes(runtime,chip->capture_hw_ptr))]=chip->capture_pBuf[i];
					j++;
				}
				break;
			default:
				break;
			}
			i++;
			chip->state++;
			if(chip->channel_count==1)
				chip->state %= 6;
			else
				chip->state %= 3;
		}
		
		chip->last_i = i;
		chip->last_j = j;
		
		if(j==frames_to_bytes(runtime,runtime->period_size)){
			em8xxx_pcm_capture_update(chip);
			chip->j_start=0;
		}
		else{
			chip->j_start=chip->last_j;
		}
		
		if (i>=chip->capture_buffer_size){
		
			prop.address = chip->capture_buffer_bus_addr;
			prop.size = chip->capture_buffer_size;
			prop.context = (void *) ((pE-Etable) + chip->capture_dmapool_id + 1);
			printk("add read buffer \n");
			//we are in tasklet mode, so we have to lock for SMP
			kc_spin_lock(pE->lock);
			EMhwlibSetProperty(pE->pemhwlib, param.moduleId, RMGenericPropertyID_AddReadBuffer, &prop, sizeof(prop));
			kc_spin_unlock(pE->lock);
			chip->capture_pBuf = NULL;
		}
	}
	return;
}
static int snd_em8xxx_free_ptr(struct em8xxxprivate *pE,RMuint32 ptr)
{
	RMuint32 dramIndex=0xffffffff;
	RMstatus err;
	
	if ((MEM_BASE_dram_controller_0<=ptr)&&(ptr<MEM_BASE_dram_controller_1)) dramIndex=0;
	if ((MEM_BASE_dram_controller_1<=ptr)&&(ptr<MEM_BASE_dram_controller_1+(512*1024*1024))) dramIndex=1;

	if (dramIndex<=1) {
		EM8XXXSNDSP(pE,
			    EMHWLIB_MODULE(MM,dramIndex),
			    RMMMPropertyID_Free,
			    (void *)(&ptr),sizeof(void *));
		if(err!=RM_OK) 
			RMDBGLOG((ENABLE,"rm_ptr_free: pointer 0x%08lx cannot be freed\n",ptr));
	}
	else
		RMDBGLOG((ENABLE,"rm_ptr_free: pointer %p not in a dram controller\n",ptr));
	
	return 0;
}

static void em8xxx_playback_stop_interrupt(unsigned long private_data)
{
	em8xxx_t *chip = (em8xxx_t *) private_data;
	struct em8xxxprivate *pE = Etable +(chip-Stable);
	RMstatus err;
/* 	enum AudioDecoder_Command_type command; */
	RMDBGLOG((DISABLE,"em8xxx_playback_stop_interrupt\n"));


	krua_unregister_sendcomplete_callback(pE);


/* 	command = AudioDecoder_Command_Pause; */

/* 	EM8XXXSNDSP(pE, EMHWLIB_MODULE(AudioDecoder,audio_decoder_index), RMAudioDecoderPropertyID_Command, &command, sizeof(command)); */

	chip->transferred=0;
	chip->STCStarted=FALSE;
	EM8XXXSNDSP(pE,EMHWLIB_MODULE(STC,audio_decoder_index),RMSTCPropertyID_Stop, NULL,0);
}

static void em8xxx_capture_stop_interrupt(unsigned long private_data)
{
	em8xxx_t *chip = (em8xxx_t *) private_data;
	struct em8xxxprivate *pE = Etable +(chip-Stable);
	enum AudioCapture_Capture_type cmd;
	RMstatus err;
	
	RMDBGLOG((DISABLE,"em8xxx_capture_stop_interrupt\n"));

	krua_unregister_event_callback(pE,EMHWLIB_MODULE(AudioCapture,audio_capture_index),receive_data_callback);

	//  Disabling audio capture
	cmd = AudioCapture_Capture_Off;
	EM8XXXSNDSP(pE,EMHWLIB_MODULE(AudioCapture,audio_capture_index),RMAudioCapturePropertyID_Capture, &cmd, sizeof(cmd));

}


static void em8xxx_playback_setaudio_interrupt(unsigned long private_data)
{
	em8xxx_t *chip = (em8xxx_t *) private_data;
	snd_pcm_substream_t * substream = chip->playback_substream;
	snd_pcm_runtime_t *runtime = substream->runtime;

	RMDBGLOG((DISABLE,"em8xxx_playback_setaudio_interrupt\n"));
	
	if (!chip->prepared) {
		chip->hw_ptr=0;
		chip->appl_ptr=0;
		chip->format = AudioDecoder_Codec_PCM;
		chip->nb_bits_per_sample = runtime->sample_bits;
		chip->MSBFirst = FALSE;
		chip->sample_rate = runtime->rate;
		chip->channel_count = runtime->channels;
		set_audio_parameters(chip);
		prepare_audio_decoder(chip);
		start_stc(chip);
	}

	return;
}

static void em8xxx_capture_setaudio_interrupt(unsigned long private_data)
{
	em8xxx_t *chip = (em8xxx_t *) private_data;
	snd_pcm_substream_t * substream = chip->capture_substream;
	snd_pcm_runtime_t *runtime = substream->runtime;

	RMDBGLOG((DISABLE,"em8xxx_capture_setaudio_interrupt\n"));

	if (!chip->prepared) {
		chip->capture_hw_ptr=0;
		chip->capture_appl_ptr=0;
		chip->format = AudioDecoder_Codec_PCM;
		chip->nb_bits_per_sample = runtime->sample_bits;
		chip->MSBFirst = FALSE;
		chip->sample_rate = runtime->rate;
		chip->channel_count = runtime->channels;
		printk("em8xxx_capture_setaudio_interrupt chip = %p \n",chip);
		set_audio_parameters(chip);
	}

	return;
}

static void em8xxx_playback_start_interrupt(unsigned long private_data)
{
	em8xxx_t *chip = (em8xxx_t *) private_data;
	struct em8xxxprivate *pE = Etable +(chip-Stable);

	RMDBGLOG((DISABLE,"em8xxx_playback_start_interrupt\n"));

	
	/*Even if the pcm instance is already close, there might still be interruptions.
	 This avoid to enter non-valid code.*/
	if(chip->pcm_open_count==0)
		return;
	if(pE->data_callback==NULL)
		krua_register_sendcomplete_callback(pE, send_data_callback);
	send_data_callback(pE,0);

}

static void em8xxx_capture_start_interrupt(unsigned long private_data)
{
	em8xxx_t *chip = (em8xxx_t *) private_data;
	struct em8xxxprivate *pE = Etable +(chip-Stable);
	enum AudioCapture_Capture_type cmd;
	RMstatus err;

	RMDBGLOG((DISABLE,"em8xxx_capture_start_interrupt\n"));

	/*Even if the pcm instance is already close, there might still be interruptions.
	 This avoid to enter non-valid code.*/
	if(chip->pcm_open_count==0)
		return;

	krua_register_event_callback(pE,EMHWLIB_MODULE(AudioCapture,audio_capture_index),SOFT_IRQ_EVENT_XFER_RECEIVE_READY,receive_data_callback);
	//  Enabling audio capture
	cmd = AudioCapture_Capture_On;
	
	EM8XXXSNDSP(pE,EMHWLIB_MODULE(AudioCapture,audio_capture_index),RMAudioCapturePropertyID_Capture, &cmd, sizeof(cmd));
	
	receive_data_callback(pE,EMHWLIB_MODULE(AudioCapture,audio_capture_index),SOFT_IRQ_EVENT_XFER_RECEIVE_READY);

}

static int snd_em8xxx_playback_open(snd_pcm_substream_t * substream)
{
	em8xxx_t *chip = snd_pcm_substream_chip(substream);
	snd_pcm_runtime_t *runtime = substream->runtime;

	RMDBGLOG((DISABLE,"em8xxx_playback_open\n"));

	chip->playback_substream = substream;

	runtime->hw = snd_em8xxx_playback;

	chip->position = 0;
	chip->transferred = 0;
	chip->hw_ptr = 0;
	chip->appl_ptr=0;
	chip->pcm_open_count++;	

	open_audio_decoder(chip);

	return 0;
}

static int snd_em8xxx_capture_open(snd_pcm_substream_t * substream)
{
	em8xxx_t *chip = snd_pcm_substream_chip(substream);
	snd_pcm_runtime_t *runtime = substream->runtime;

	RMDBGLOG((DISABLE,"em8xxx_capture_open_interrupt\n"));

	chip->capture_substream = substream;

	runtime->hw = snd_em8xxx_capture;

	chip->capture_hw_ptr = 0;
	chip->capture_appl_ptr=0;
	chip->i_start=0;
	chip->j_start=0;
	chip->last_i=0;
	chip->last_j=0;
	chip->state = 0;
	chip->capture_pBuf=NULL;

	chip->pcm_open_count++;	
	
	open_audio_capture(chip);

	return 0;
}

static int snd_em8xxx_playback_close(snd_pcm_substream_t * substream)
{
	em8xxx_t *chip = snd_pcm_substream_chip(substream);
	struct em8xxxprivate *pE = Etable + (chip-Stable);
	RMuint32 profile;
	RMstatus err;
	
	printk("snd_em8xxx_playback_close \n");
	chip->pcm_open_count--;
	krua_unregister_sendcomplete_callback(pE);
	chip->playback_substream = NULL;

	chip->format = 0;
	chip->sample_rate = 0;
	chip->channel_count = 0;
	chip->prepared = FALSE;
		
	// close audio profile

	profile=0;

	EM8XXXSNDSP(pE,EMHWLIB_MODULE(AudioDecoder,audio_decoder_index), RMAudioDecoderPropertyID_Close, &profile, sizeof(profile));
	
	// free resources

	snd_em8xxx_free_ptr (pE,chip->AudioProfileCachedAddr);
	snd_em8xxx_free_ptr (pE,chip->AudioProfileUncachedAddr);

       
 	// stop stc 
	
	chip->firstPTS = TRUE;

	EM8XXXSNDSP(pE,EMHWLIB_MODULE(STC,audio_decoder_index),RMSTCPropertyID_Close, NULL,sizeof(RMuint32));

	if (EMHWLIB_MODULE(AudioDecoder,audio_decoder_index) != 0) {
		/* Free the audio shared memory per engine */
		RMstatus err;
		RMuint32 connected_task_count;

		EM8XXXSNDGP(pE, EMHWLIB_MODULE(AudioEngine,audio_engine_index), RMAudioEnginePropertyID_ConnectedTaskCount, 
					&connected_task_count, sizeof(connected_task_count));
		if (err != RM_OK) {
			RMDBGLOG((ENABLE, "Cannot get RMAudioEnginePropertyID_ConnectedTaskCount %lu\n", EMHWLIB_MODULE(AudioEngine,audio_engine_index)));
			return err;                                                         
		}
		if (connected_task_count == 0) {
			struct AudioEngine_DecoderSharedMemory_type shared;
			RMuint32 address;
			EM8XXXSNDGP(pE, EMHWLIB_MODULE(AudioEngine,audio_engine_index), RMAudioEnginePropertyID_DecoderSharedMemory,
					     &shared, sizeof(shared));
				if (err != RM_OK) {
				RMDBGLOG((ENABLE, "Cannot get DecoderSharedMemory0\n"));
				return err;
			}
			if (shared.Address) {
				RMDBGLOG((ENABLE, "FREE %lx_DRAM AUDIO SHARED MEMORY addr=0x%lx size=0x%lx!\n",
					  audio_decoder_index, shared.Address, shared.Size));
				address = shared.Address;
				shared.Address = 0;
				shared.Size = 0;
				
				EM8XXXSNDSP(pE, EMHWLIB_MODULE(AudioEngine,audio_engine_index), RMAudioEnginePropertyID_DecoderSharedMemory, &shared, sizeof(shared));
				snd_em8xxx_free_ptr (pE, address);
			}
		}
		else {
			RMDBGLOG((ENABLE, "CANNOT FREE AUDIO SHARED MEMORY. There are still %lx audio tasks opened. \n",
				  connected_task_count));
		}
	}
	return 0;
}

static int snd_em8xxx_capture_close(snd_pcm_substream_t * substream)
{
	em8xxx_t *chip = snd_pcm_substream_chip(substream);
	struct em8xxxprivate *pE = Etable + (chip-Stable);
	RMuint32 profile;
	RMstatus err;

	RMDBGLOG((DISABLE,"em8xxx_capture_close\n"));

	chip->pcm_open_count--;
	krua_unregister_event_callback(pE,EMHWLIB_MODULE(AudioCapture,audio_capture_index),receive_data_callback);
	chip->playback_substream = NULL;

	chip->format = 0;
	chip->sample_rate = 0;
	chip->channel_count = 0;
	chip->prepared = FALSE;

	// close audio capture profile

	profile=0;

	EM8XXXSNDSP(pE,EMHWLIB_MODULE(AudioCapture,audio_capture_index), RMAudioCapturePropertyID_Close, &profile, sizeof(profile));

	// close dma pool

	kdmapool_close(pE->pllad,chip->capture_dmapool_id);
	
	// free resources

	snd_em8xxx_free_ptr (pE,chip->SerialinProfileCachedAddr);
	snd_em8xxx_free_ptr (pE,chip->SerialinProfileUncachedAddr);

	return 0;
}

static int snd_em8xxx_pcm_hw_params(snd_pcm_substream_t *substream,
				    snd_pcm_hw_params_t * hw_params)
{
	int err;
	/* In this callback the Alsa Pcm middle layer allocate the memory for the dmapool  */
	RMDBGLOG((DISABLE,"snd_em8xxx_pcm_hw_params\n"));
	if ((err = snd_pcm_lib_malloc_pages(substream,32*(1024))) < 0)
		return err;

	return 0;
}


static int snd_em8xxx_pcm_hw_free(snd_pcm_substream_t *substream)
{
	
	return snd_pcm_lib_free_pages(substream);
}

static int snd_em8xxx_playback_prepare(snd_pcm_substream_t * substream)
{
	em8xxx_t *chip = snd_pcm_substream_chip(substream);

	RMDBGLOG((DISABLE,"snd_em8xxx_playback_prepare\n"));

	/*For backward compatibility, it is better to schedule a tasklet here, 
	  because this callback might be atomic, and we can't lock. */
	tasklet_hi_schedule(&chip->playback_setaudio_tq);
	return 0;
}
static int snd_em8xxx_capture_prepare(snd_pcm_substream_t * substream)
{
	em8xxx_t *chip = snd_pcm_substream_chip(substream);

	RMDBGLOG((DISABLE,"snd_em8xxx_capture_prepare\n"));

/* 	/\*For backward compatibility, it is better to schedule a tasklet here,  */
/* 	  because this callback might be atomic, and we can't lock. *\/ */
	tasklet_schedule(&chip->capture_setaudio_tq);
	return 0;
}

static int snd_em8xxx_playback_trigger(snd_pcm_substream_t * substream,
				       int cmd)
{
	em8xxx_t *chip = snd_pcm_substream_chip(substream);

	RMDBGLOG((DISABLE,"snd_em8xxx_playback_trigger\n"));

	switch (cmd) {
	case SNDRV_PCM_TRIGGER_PAUSE_RELEASE:
	case SNDRV_PCM_TRIGGER_START:
		chip->running=TRUE;

		/* We have to schedule this tasklet with the lowest priority,
		   unless the em8xxx tasklet that process the 
		   state change will probably not be processed */

		tasklet_schedule(&chip->playback_start_tq);
		break;
	case SNDRV_PCM_TRIGGER_PAUSE_PUSH:
	case SNDRV_PCM_TRIGGER_STOP:
		chip->running=FALSE;
		tasklet_schedule(&chip->playback_stop_tq);
		break;
	default:
		return -EINVAL;
	}
	return 0;
}

static int snd_em8xxx_capture_trigger(snd_pcm_substream_t * substream,
				       int cmd)
{
	em8xxx_t *chip = snd_pcm_substream_chip(substream);
	
	RMDBGLOG((DISABLE,"snd_em8xxx_capture_trigger\n"));

	switch (cmd) {
	case SNDRV_PCM_TRIGGER_START:
		chip->running=TRUE;

		/* We have to schedule this tasklet with the lowest priority,
		   unless the em8xxx tasklet that process the 
		   state change will probably not be processed */

		tasklet_schedule(&chip->capture_start_tq);
		break;
	case SNDRV_PCM_TRIGGER_STOP:
		chip->running=FALSE;
		tasklet_hi_schedule(&chip->capture_stop_tq);
		break;
	default:
		return -EINVAL;
	}
	return 0;
}

static snd_pcm_uframes_t snd_em8xxx_playback_pointer(snd_pcm_substream_t * substream)
{
	em8xxx_t *chip = snd_pcm_substream_chip(substream);
	return chip->hw_ptr;
}

static snd_pcm_uframes_t snd_em8xxx_capture_pointer(snd_pcm_substream_t * substream)
{
	em8xxx_t *chip = snd_pcm_substream_chip(substream);
	return chip->capture_hw_ptr;
}

static int snd_em8xxx_playback_ack(snd_pcm_substream_t * substream)
{
	snd_pcm_runtime_t *runtime = substream->runtime;
	em8xxx_t *chip = snd_pcm_substream_chip(substream);
	/*This callback is used to track the current appl_ptr. It is called from the Alsa Pcm
	 middle layer when it updates the appl_ptr after a write operation.*/

	chip->appl_ptr=runtime->control->appl_ptr;
	return 0;
}

static int snd_em8xxx_capture_ack(snd_pcm_substream_t * substream)
{
	snd_pcm_runtime_t *runtime = substream->runtime;
	em8xxx_t *chip = snd_pcm_substream_chip(substream);
	/*This callback is used to track the current appl_ptr. It is called from the Alsa Pcm
	 middle layer when it updates the appl_ptr after a read operation.*/

	chip->capture_appl_ptr=runtime->control->appl_ptr;
	return 0;
}

static void snd_em8xxx_free_pcm(snd_pcm_t *pcm)
{
	em8xxx_t *chip = pcm->private_data;
	struct em8xxxprivate *pE = Etable + (chip - Stable);
	
	snd_em8xxx_free_ptr (pE,chip->AudioUCodeAddr);

	snd_pcm_lib_preallocate_free_for_all(pcm);
}

static int __devinit snd_em8xxx_new_pcm(em8xxx_t *chip, int device, snd_pcm_t ** rpcm)
{
	snd_pcm_t *pcm;
	int err;

	if (rpcm)
		*rpcm = NULL;
	if ((err = snd_pcm_new(chip->card, "em8xxx", device, 2, 1, &pcm)) < 0)
		return err;
	
	snd_pcm_set_ops(pcm, SNDRV_PCM_STREAM_PLAYBACK, &snd_em8xxx_playback_ops);
	snd_pcm_set_ops(pcm, SNDRV_PCM_STREAM_CAPTURE, &snd_em8xxx_capture_ops);

	pcm->private_data = chip;
	pcm->private_free = snd_em8xxx_free_pcm;
	pcm->info_flags = 0;
	strcpy(pcm->name, "EM8xxx");

	/*This fonction preallocate a big area of memory to make contiguous buffers
	 in hw_params callback.*/	
#if EM86XX_MODE==EM86XX_MODEID_STANDALONE
	snd_pcm_lib_preallocate_pages_for_all(pcm, SNDRV_DMA_TYPE_CONTINUOUS,
					      snd_dma_continuous_data(GFP_KERNEL), 32*1024, 32*1024);
#else
	snd_pcm_lib_preallocate_pages_for_all(pcm, SNDRV_DMA_TYPE_DEV,
					      snd_dma_pci_data(chip->pci), 32*1024, 32*1024);

#endif
	init_audio(chip);
	
	if (rpcm)
		*rpcm = pcm;
	return 0;
}




/************************************************************************
 *********                    LOW LEVEL DRIVER                   ********
 ************************************************************************/

static int snd_em8xxx_free(em8xxx_t *chip)
{
	return 0;
}

static int snd_em8xxx_dev_free(snd_device_t *device)
{
	em8xxx_t *chip = (em8xxx_t *) device->device_data;
	return snd_em8xxx_free(chip);
}

#if EM86XX_MODE==EM86XX_MODEID_STANDALONE
static int __devinit snd_em8xxx_create(snd_card_t * card,em8xxx_t * chip)
#else
static int __devinit snd_em8xxx_create(snd_card_t * card,struct pci_dev * pci,em8xxx_t * chip)
#endif
{
	int err;
	static snd_device_ops_t ops = {
		.dev_free =	snd_em8xxx_dev_free,
	};
	
	chip->card = card;
#if EM86XX_MODE==EM86XX_MODEID_WITHHOST
	chip->pci = pci;
#endif
	
 	chip->sndprivate_active = 1; 
	init_waitqueue_head(&chip->sound_queue);

	tasklet_init(&chip->playback_start_tq,em8xxx_playback_start_interrupt,(unsigned long) chip);
	tasklet_init(&chip->playback_setaudio_tq,em8xxx_playback_setaudio_interrupt,(unsigned long) chip);
	tasklet_init(&chip->playback_stop_tq,em8xxx_playback_stop_interrupt,(unsigned long) chip);
	tasklet_init(&chip->capture_start_tq,em8xxx_capture_start_interrupt,(unsigned long) chip);
	tasklet_init(&chip->capture_setaudio_tq,em8xxx_capture_setaudio_interrupt,(unsigned long) chip);
	tasklet_init(&chip->capture_stop_tq,em8xxx_capture_stop_interrupt,(unsigned long) chip);
	tasklet_init(&chip->receive_data_tq,receive_data_interrupt,(unsigned long) chip);

	if ((err = snd_device_new(card, SNDRV_DEV_LOWLEVEL, chip, &ops)) < 0) {
		snd_em8xxx_free(chip);
		return err;
	}

#if EM86XX_MODE==EM86XX_MODEID_WITHHOST
	snd_card_set_dev(card, &pci->dev);
#endif

	return 0;
}


static int sndprivate_init(struct em8xxxprivate *pE)
{
	snd_card_t *card;
	em8xxx_t *chip = Stable+(pE-Etable);
  	snd_pcm_t *pcm;  
	int err;
#if EM86XX_MODE==EM86XX_MODEID_WITHHOST
	struct pci_dev *pci= (struct pci_dev *) mumk_get_pcidev(pE-Etable);
#endif

	printk("pE %p index %d\n", pE, (int) (chip-Stable));

	if (chip->sndprivate_active == 0) {
		memset(chip,0,sizeof(struct sndprivate));
		
		card = snd_card_new(-1,"EM8XXX", THIS_MODULE, 0);
		if (card == NULL){
			printk("Error while creating new card\n");
			return -ENOMEM;
		}
#if EM86XX_MODE==EM86XX_MODEID_STANDALONE
		if ((err = snd_em8xxx_create(card, chip)) < 0) {
#else
		if ((err = snd_em8xxx_create(card,pci,chip)) < 0) {
#endif
			snd_card_free(card);
			printk("error while creating device em8xxx\n");
			return err;
		}
		
		strcpy(card->driver, "EM8xxx");
		strcpy(card->shortname, "EM8xxx card");
		sprintf(card->longname, "EM8xxx card");
		
		if ((err = snd_em8xxx_new_pcm(chip, 0, &pcm)) < 0) {
			snd_card_free(card);
			printk("error while adding pcm component\n");
			return err;
		}
		if ((err = snd_em8xxx_mixer(chip)) < 0) {
			snd_card_free(card);
			printk("error while adding mixer component\n");
			return err;
		}
		if ((err = snd_card_register(card)) < 0) {
			printk("error while registering card\n");
			snd_card_free(card);
			return err;
		}
		
		printk("Em8xxx sound driver successfully registered\n");
	}
	else {
		printk("em8xxx sound driver already registered\n");
		return 0;
	}
	
	chip->sndprivate_active = 1;
	
	
	return 0;
}

static int sndprivate_cleanup(struct em8xxxprivate *pE)
{
	em8xxx_t *chip=Stable+(pE-Etable);

	if (chip->sndprivate_active == 1) { 
		snd_card_free(chip->card);
 	} 

 	chip->sndprivate_active = 0; 

	return 0;
}


int init_module(void)
{
	int i,enabled_count=0;
	printk("begun\n");

	switch(audio_decoder_index){
	case 0:
	case 1:
		audio_engine_index=0;
		audio_capture_index=0;
		break;
#ifdef RMFEATURE_HAS_AUDIO_ENGINE_1
 	case 2:
	case 3:
		audio_engine_index=1;
		audio_capture_index=1;
		break;
#endif // RMFEATURE_HAS_AUDIO_ENGINE_1
	default:
		printk("invalid parameter \n");
		return -EINVAL;
	}

	for (i=0 ; i<MAXLLAD ; i++) {
		if ((&Etable[i])->pllad != NULL) {
			if (sndprivate_init(&Etable[i]) != 0) 
				break;
			enabled_count++;
		}
	}
	
	printk("done\n");
	
        return 0;		    
	
}

void cleanup_module(void)
{
	int i;
	
	printk("begun\n");
	
	for (i=0 ; i<MAXLLAD ; i++) {
		if (Stable[i].sndprivate_active) {
			sndprivate_cleanup(&Etable[i]);
		}
	}
	
	printk("done\n");
}




#endif // __SNDEM8XXX_C__
