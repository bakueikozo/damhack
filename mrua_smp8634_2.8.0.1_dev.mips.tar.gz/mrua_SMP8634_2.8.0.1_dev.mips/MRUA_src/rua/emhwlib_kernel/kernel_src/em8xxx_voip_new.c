/*****************************************
 Copyright @ 2005, 2006, 2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   em8xxx_voip_new.c
  @brief  

  New linux kernel telephony driver of the em8xxx boards

  @author Yoann Walther 
  @date   2006-11-07
*/

/* to enable or disable the debug messages of this source file, put 1 or 0 below */
#if 1
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

#include "em8xxxvoip_new.h"

MODULE_DESCRIPTION("EM8XXX New Linux Telephony Driver");
MODULE_AUTHOR("Yoann Walther <yoann_walther@sdesigns.eu>");
#ifdef MODULE_LICENSE
MODULE_LICENSE("Proprietary");
#endif

extern struct em8xxxprivate Etable[MAXLLAD];
static RMuint32 em8xxx_voip_event_callback(void *pE,RMuint32 ModuleID,RMuint32 mask);
RMstatus krua_register_event_callback(void *pE,RMuint32 ModuleID,RMuint32 mask, Event_callback callback);
RMstatus krua_unregister_event_callback(void *pE,RMuint32 ModuleID,Event_callback callback);
static int rm_free_ptr(struct em8xxxprivate *pE,RMuint32 ptr);

static int gpio_set_dir(struct em8xxxprivate *pE,int gpio_number,int dir);
static int read_gpio(struct em8xxxprivate *pE,int gpio_number);
static int write_gpio(struct em8xxxprivate *pE,int gpio_number, int val);
static int init_gpio(struct em8xxxprivate *pE);
static int SlicSetState(struct voipprivate *pV,enum SLIC_STATES State);
static void em8xxx_voip_check_hookstate(struct voipprivate *pV);

static void em8xxx_voip_init_timer(struct voipprivate *pV);
static void em8xxx_voip_add_timer(struct voipprivate *pV);
static void em8xxx_voip_timeout(unsigned long private);

static int em8xxx_voip_init(struct em8xxxprivate *pE);
static int em8xxx_voip_cleanup(struct em8xxxprivate *pE);
static int em8xxx_voip_open(struct phone_device *p, struct file *file_p);
static ssize_t em8xxx_voip_read(struct file * file_p, char *buf, size_t length,loff_t * ppos);
static ssize_t em8xxx_voip_write(struct file * file_p, const char *buf, size_t count, loff_t * ppos);
static unsigned int em8xxx_voip_poll(struct file *file_p, poll_table * wait);
static int em8xxx_voip_ioctl(struct inode *inode, struct file *file_p, unsigned int cmd, unsigned long arg);
static int em8xxx_voip_release(struct inode *inode, struct file *file_p);
static int em8xxx_voip_fasync(int fd, struct file *file_p, int mode);

struct file_operations em8xxx_voip_fops =
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
	NULL,			/* lseek */
	em8xxx_voip_read,
	em8xxx_voip_write,
	NULL,			/* readdir */
	em8xxx_voip_poll,
	em8xxx_voip_ioctl,
	NULL,			/* mmap */
	NULL,			/* open */
	NULL,			/* flush */
	em8xxx_voip_release,
	NULL,			/* fsync */
	em8xxx_voip_fasync,		/* fasync */
	NULL,			/* media change */
	NULL,			/* revalidate */
	NULL			/* lock */
#else
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
	owner:          THIS_MODULE,
	read:           em8xxx_voip_read,
	write:          em8xxx_voip_write,
	poll:           em8xxx_voip_poll,
	ioctl:          em8xxx_voip_ioctl,
	release:        em8xxx_voip_release,
	fasync:         em8xxx_voip_fasync
#else
	.owner        = THIS_MODULE,
	.read         = em8xxx_voip_read,
	.write        = em8xxx_voip_write,
	.poll         = em8xxx_voip_poll,
	.ioctl        = em8xxx_voip_ioctl,
	.release      = em8xxx_voip_release,
	.fasync       = em8xxx_voip_fasync
#endif
#endif
};

static int rm_free_ptr(struct em8xxxprivate *pE,RMuint32 ptr)
{
	RMuint32 dramIndex=0xffffffff;
	RMstatus err;
	
	if ((MEM_BASE_dram_controller_0<=ptr)&&(ptr<MEM_BASE_dram_controller_1)) dramIndex=0;
	if ((MEM_BASE_dram_controller_1<=ptr)&&(ptr<MEM_BASE_dram_controller_1+(512*1024*1024))) dramIndex=1;

	if (dramIndex<=1) {
		EM8XXXVOIPSP(pE,
			    EMHWLIB_MODULE(MM,dramIndex),
			    RMMMPropertyID_Free,
			    (void *)(&ptr),sizeof(void *));
		if(err!=RM_OK) 
			RMDBGLOG((ENABLE,"rm_ptr_free: pointer 0x%08lx cannot be freed\n",ptr));
	}
	else
		RMDBGLOG((ENABLE,"rm_ptr_free: pointer %p not in a dram controller\n",ptr));
	
	return 0;
}

static void em8xxx_voip_clear_event_mask(unsigned long private_data)
{
	struct voipprivate *pV = (struct voipprivate *) private_data;
	struct em8xxxprivate *pE = Etable + (pV-VOIPtable);
	RMuint32 status = 0;
	RMuint32 mask;
	kc_spin_lock(pE->lock);
	mask = pV->event_mask;
	kc_spin_unlock(pE->lock);

	if (mask & SOFT_IRQ_EVENT_COMMANDCOMPLETION) {
		kc_wake_up_interruptible(pV->command_q);
		status |= SOFT_IRQ_EVENT_COMMANDCOMPLETION;
	}

	if (mask & SOFT_IRQ_EVENT_VOIP_DTMF_READY) {
		pV->exc.bits.dtmf_ready = 1;
		kc_wake_up_interruptible(pV->poll_q);
		status |= SOFT_IRQ_EVENT_VOIP_DTMF_READY;
	}

	if (mask & SOFT_IRQ_EVENT_VOIP_FRAME_ENCODED) {
		kc_wake_up_interruptible(pV->read_q);
		status |= SOFT_IRQ_EVENT_VOIP_FRAME_ENCODED;
	}

	if (mask & SOFT_IRQ_EVENT_VOIP_FRAME_DECODED) {
		kc_wake_up_interruptible(pV->write_q);
		status |= SOFT_IRQ_EVENT_VOIP_FRAME_DECODED;
	}

	kc_spin_lock(pE->lock);
	EMhwlibSetProperty(pE->pemhwlib,VoipCodec,RMGenericPropertyID_ClearEventMask,&status,sizeof(status));
	pV->event_mask = 0;
	kc_spin_unlock(pE->lock);
}

static RMuint32 em8xxx_voip_event_callback(void *pE,RMuint32 ModuleID,RMuint32 mask)
{
	struct em8xxxprivate *real_pE = (struct em8xxxprivate *) pE;
	struct voipprivate *pV = VOIPtable + (real_pE - Etable);

	kc_spin_lock(real_pE->lock);
	pV->event_mask |= mask;
	kc_spin_unlock(real_pE->lock);
	tasklet_hi_schedule(&pV->event_tq);

	return mask;
}

static int gpio_set_dir(struct em8xxxprivate *pE,int gpio_number,int dir)
{
	RMuint32 gpio_dir;
	RMuint32 gpio_dir_addr;
	int nb;

	if(gpio_number > 16){
		gpio_dir_addr = ETH_GPIO_DIR;
		nb = gpio_number - 16;
	}
	else {
		gpio_dir_addr = SYS_GPIO_DATA;
		nb = gpio_number;
	}

	gpio_dir = gbus_read_uint32(pE->pgbus,gpio_dir_addr);
	RMsetConsecutiveBitsVar(&gpio_dir,nb+16,nb+16,1);
	RMsetConsecutiveBitsVar(&gpio_dir,nb,nb,dir);
	
	gbus_write_uint32(pE->pgbus,gpio_dir_addr,gpio_dir);
	gpio_dir = gbus_read_uint32(pE->pgbus,gpio_dir_addr);
	if (dir == ((gpio_dir >> nb) & 1))
		return 0;
	else 
		return -1;
	
}

static int read_gpio(struct em8xxxprivate *pE,int gpio_number)
{
	RMuint32 gpio_data;
	RMuint32 gpio_data_addr;
	int val;
	int nb;

	if(gpio_number > 16){
		gpio_data_addr = ETH_GPIO_DATA;
		nb = gpio_number - 16;
	}
	else {
		gpio_data_addr = SYS_GPIO_DATA;
		nb = gpio_number;
	}
	
	gpio_data = gbus_read_uint32(pE->pgbus,gpio_data_addr);
	val = (gpio_data >> nb) & 1;

	return val;
	
}

static int write_gpio(struct em8xxxprivate *pE,int gpio_number, int val)
{
	RMuint32 gpio_data;
	RMuint32 gpio_data_addr;
	int nb;
	
	if(gpio_number > 16){
		gpio_data_addr = ETH_GPIO_DATA;
		nb = gpio_number - 16;
	}
	else{
		gpio_data_addr = SYS_GPIO_DATA;
		nb = gpio_number;
	}

	gpio_data = gbus_read_uint32(pE->pgbus,gpio_data_addr);

	RMsetConsecutiveBitsVar(&gpio_data,nb+16,nb+16,1);
	RMsetConsecutiveBitsVar(&gpio_data,nb,nb,val);

	gbus_write_uint32(pE->pgbus,gpio_data_addr,gpio_data);

	gpio_data = gbus_read_uint32(pE->pgbus,gpio_data_addr);
	if (val == ((gpio_data >> nb) & 1))
		return 0;
	else 
		return -1;
}

static int init_gpio(struct em8xxxprivate *pE)
{
	gpio_set_dir(pE,GPIO_SLIC_COMP,GPIO_DIR_OUTPUT);
	gpio_set_dir(pE,GPIO_SLIC_CTL1,GPIO_DIR_OUTPUT);
	gpio_set_dir(pE,GPIO_SLIC_CTL2,GPIO_DIR_OUTPUT);
	gpio_set_dir(pE,GPIO_SLIC_MUTE,GPIO_DIR_OUTPUT);
	gpio_set_dir(pE,GPIO_HDS_MUTE,GPIO_DIR_OUTPUT);
	gpio_set_dir(pE,GPIO_LOOP_DETECT,GPIO_DIR_INPUT);
	gpio_set_dir(pE,GPIO_FAULT_DETECT,GPIO_DIR_INPUT);

	return 0;
}

static int SlicSetState(struct voipprivate *pV,enum SLIC_STATES State)
{
	struct em8xxxprivate *pE = Etable + (pV - VOIPtable);
	
	switch(State){
	case LOW_POWER_STANDBY:
		write_gpio(pE,GPIO_SLIC_COMP,0);
		write_gpio(pE,GPIO_SLIC_CTL1,0);
		write_gpio(pE,GPIO_SLIC_CTL2,0);
		break;
	case REVERSE_POLARITY:
		write_gpio(pE,GPIO_SLIC_COMP,0);
		write_gpio(pE,GPIO_SLIC_CTL1,1);
		write_gpio(pE,GPIO_SLIC_CTL2,0);
		break;
	case NORMAL_ACTIVE:
		write_gpio(pE,GPIO_SLIC_COMP,0);
		write_gpio(pE,GPIO_SLIC_CTL1,0);
		write_gpio(pE,GPIO_SLIC_CTL2,1);
		break;
	case RINGING:
		write_gpio(pE,GPIO_SLIC_COMP,0);
		write_gpio(pE,GPIO_SLIC_CTL1,1);
		write_gpio(pE,GPIO_SLIC_CTL2,1);
		break;
	case DISCONNECT:
		write_gpio(pE,GPIO_SLIC_COMP,1);
		write_gpio(pE,GPIO_SLIC_CTL1,0);
		write_gpio(pE,GPIO_SLIC_CTL2,0);
		break;
	}

	return 0;
}

static void em8xxx_voip_check_hookstate(struct voipprivate *pV)
{
	struct em8xxxprivate *pE = Etable + (pV - VOIPtable);
	
	pV->hookstate = !read_gpio(pE,GPIO_LOOP_DETECT);

	if(pV->hookstate != pV->last_hookstate){
		pV->hook_cnt ++;
		if(pV->hook_cnt>=10){
			pV->hook_cnt = 0;
			
			RMDBGLOG((LOCALDBG,"detecting hook state change pV->hook_cnt = %d ! \n",pV->hook_cnt));
			pV->last_hookstate = pV->hookstate;
			pV->exc.bits.hookstate = 1;
			kc_wake_up_interruptible(pV->poll_q);
			RMDBGLOG((LOCALDBG,"exc.bytes = %d \n",pV->exc.bytes));
		}
	}
}

static void em8xxx_voip_timeout(unsigned long private)
{
	struct voipprivate *pV = (struct voipprivate *) private;
	struct em8xxxprivate *pE = Etable + (pV - VOIPtable);
	struct XferFIFOInfo_type xfer_info;
	
	em8xxx_voip_check_hookstate(pV);

	kc_spin_lock(pE->lock);
	EMhwlibGetProperty(pE->pemhwlib,EMHWLIB_TARGET_MODULE(VoipCodec,0,0),RMGenericPropertyID_XferFIFOInfo,&xfer_info,sizeof(xfer_info));
	kc_spin_unlock(pE->lock);

	if (xfer_info.Erasable > 0) {
		kc_wake_up_interruptible(pV->poll_q);
	}

	kc_spin_lock(pE->lock);
	EMhwlibGetProperty(pE->pemhwlib,EMHWLIB_TARGET_MODULE(VoipCodec,0,1),RMGenericPropertyID_XferFIFOInfo,&xfer_info,sizeof(xfer_info));
	kc_spin_unlock(pE->lock);

	if (xfer_info.Writable > 0) {
		kc_wake_up_interruptible(pV->poll_q);
	}

	if(pV->voip_open_count)
		em8xxx_voip_add_timer(pV);
	return;
}

static void em8xxx_voip_init_timer(struct voipprivate *pV)
{
	init_timer(&pV->timer);
	pV->timer.function = em8xxx_voip_timeout;

	pV->timer.data = (unsigned long)pV;
}

static void em8xxx_voip_add_timer(struct voipprivate *pV)
{
	pV->timer.expires = jiffies + pV->check_interval;
	add_timer(&pV->timer);
}

static RMstatus init_voip(struct voipprivate *pV)
{
	struct em8xxxprivate *pE = Etable + (pV-VOIPtable);
	struct MM_Malloc_in_type in;
	struct MM_Malloc_out_type out;
	enum AudioEngine_SpdifOut_type spdif_out;
	struct AudioEngine_I2SConfig_type i2s;
	enum AudioEngine_SerialOut_type serialOutStatus;
	struct VoipCodec_DRAMSize_in_type dram_in;
	struct VoipCodec_DRAMSize_out_type dram_out;
	struct VoipCodec_Open_type profile;
	enum VoipCodec_Command_type command;
	RMuint32 volume;
	RMstatus err;
	int rc;

#ifndef WITH_XLOADED_UCODE
	enum ProcessorState run;
	struct AudioEngine_MicrocodeDRAMSize_in_type size_in;
	struct AudioEngine_MicrocodeDRAMSize_out_type size_out;
	struct AudioEngine_Microcode_type ucode;

	run = CPU_RESET;

	EM8XXXVOIPSP(pE,EMHWLIB_MODULE(AudioEngine,1),RMAudioEnginePropertyID_State,&run,sizeof(run));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE,"Error while resetting Audio RISC\n"));
		return err;
	}

	run = CPU_STOPPED;

	EM8XXXVOIPSP(pE,EMHWLIB_MODULE(AudioEngine,1),RMAudioEnginePropertyID_State,&run,sizeof(run));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE,"Error while stopping Audio RISC\n"));
		return err;
	}

	size_in.MicrocodeVersion = 2;
	EM8XXXVOIPEXP(pE,EMHWLIB_MODULE(AudioEngine,1),RMAudioEnginePropertyID_MicrocodeDRAMSize, &size_in, sizeof(size_in), &size_out, sizeof(size_out));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE,"Error while getting memory needed for audio microcode!\n"));
		return err;
	}

	if (size_out.Size == 0) {
		RMDBGLOG((LOCALDBG,"Voip microcode does not need DRAM\n"));
		ucode.Address = 0;
	}
	else {
		in.dramtype=RUA_DRAM_CACHED;
		in.Size=size_out.Size;

		EM8XXXVOIPEXP(pE,EMHWLIB_MODULE(MM,0),RMMMPropertyID_Malloc,&in,sizeof(in),&out,sizeof(out));
		if (err == RM_OK){
			ucode.Address = (RMuint32) out.Address;
			RMDBGLOG((LOCALDBG,"Voip ucode cached addr : 0x%08lx, size 0x%08lx, end: 0x%08lx\n",ucode.Address,size_out.Size,ucode.Address+size_out.Size));
			pV->VoipUCodeAddr = ucode.Address;
		}
		else {
			RMDBGLOG((ENABLE,"Memory manager not existent\n"));
			return err;
		}
	}
	ucode.MicrocodeVersion = size_in.MicrocodeVersion;
	EM8XXXVOIPSP(pE,EMHWLIB_MODULE(AudioEngine,1),RMAudioEnginePropertyID_Microcode,&ucode,sizeof(ucode));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE,"Error while loading audio microcode!\n"));
		return err;
	}

 	run = CPU_RUNNING;

	EM8XXXVOIPSP(pE, EMHWLIB_MODULE(AudioEngine,1), RMAudioEnginePropertyID_State, &run, sizeof(run));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE,"Error while starting Audio RISC\n"));
		return err;
	}
#endif // WITH_XLOADED_UCODE


	spdif_out = AudioEngine_SpdifOut_Disabled;
	EM8XXXVOIPSP(pE,EMHWLIB_MODULE(AudioEngine,1),RMAudioEnginePropertyID_SpdifOut, &spdif_out, sizeof(spdif_out));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE,"Error while setting spdif_out property \n"));
		return err;
	}
	
	i2s.DataAlignment = 1;
	i2s.SClkInvert = TRUE;
	i2s.FrameInvert = TRUE;
	i2s.MSBFirst = TRUE;
	i2s.SampleSize16Bit = FALSE;
	EM8XXXVOIPSP(pE,EMHWLIB_MODULE(AudioEngine,1),RMAudioEnginePropertyID_I2SConfig, &i2s,sizeof(i2s));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE,"Error setting i2s property !\n"));
		return err;
	}
	
	serialOutStatus = AudioEngine_SerialOut_SO_ENABLE;
	EM8XXXVOIPSP(pE,EMHWLIB_MODULE(AudioEngine,1),RMAudioEnginePropertyID_SerialOut, &serialOutStatus, sizeof(serialOutStatus));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE,"Error while setting serialOut property!\n"));
		return err;
	}

	dram_in.BTSInFIFOSize = BTS_IN_FIFO_SIZE;
	dram_in.BTSOutFIFOSize = BTS_OUT_FIFO_SIZE;
	dram_in.DTMFCharFIFOSize = DTMF_FIFO_SIZE;
	EM8XXXVOIPEXP(pE,VoipCodec,RMVoipCodecPropertyID_DRAMSize,&dram_in,sizeof(dram_in),&dram_out,sizeof(dram_out));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE,"Can't get DRAM size to allocate for VoipCodec Profile\n"));
		return err;
	}

	profile.BTSInFIFOSize = dram_in.BTSInFIFOSize;
	profile.BTSOutFIFOSize = dram_in.BTSOutFIFOSize;
	profile.DTMFCharFIFOSize = dram_in.DTMFCharFIFOSize;
	profile.CachedSize = dram_out.CachedSize;
	if (profile.CachedSize > 0) {
		in.dramtype=RUA_DRAM_CACHED;
		in.Size = profile.CachedSize;
		EM8XXXVOIPEXP(pE,EMHWLIB_MODULE(MM,0),RMMMPropertyID_Malloc,&in,sizeof(in),&out,sizeof(out));
		if (err == RM_OK) {
			profile.CachedAddress = (RMuint32) out.Address;
			RMDBGLOG((LOCALDBG,"Voip cached address : 0x%08lx, size 0x%08lx, end 0x%08lx\n",profile.CachedAddress,profile.CachedSize,profile.CachedAddress + profile.CachedSize));
		}
		else {
			RMDBGLOG((ENABLE,"memory manager not existent\n"));
			return err;
		}
	}
	else {
		profile.CachedAddress = 0;
	}
	pV->VoipProfileCachedAddr = profile.CachedAddress;

	profile.UncachedSize = dram_out.UncachedSize;
	if (profile.UncachedSize > 0) {
		in.dramtype=RUA_DRAM_UNCACHED;
		in.Size = profile.UncachedSize;

		EM8XXXVOIPEXP(pE,EMHWLIB_MODULE(MM,0),RMMMPropertyID_Malloc,&in,sizeof(in),&out,sizeof(out));
		if (err == RM_OK) {
			profile.UncachedAddress = (RMuint32) out.Address;
			RMDBGLOG((LOCALDBG,"Voip uncached address : 0x%08lx, size 0x%08lx, end 0x%08lx\n",profile.UncachedAddress,profile.UncachedSize,profile.UncachedAddress+profile.UncachedSize));
		}
		else {
			RMDBGLOG((ENABLE,"memory manager not existent \n"));
			return err;
		}
	}
	else {
		profile.UncachedAddress = 0;
	}
	pV->VoipProfileUncachedAddr = profile.UncachedAddress;
	EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Open,&profile,sizeof(profile));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE,"Error while creating voip profile!\n"));
		return err;
	}
	
	volume = 0x100;
	EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Recording_volume,&volume,sizeof(volume));
	volume = 0x20;
	EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Playback_volume,&volume,sizeof(volume));

	command = VoipCodec_Command_Capture_Start;
	EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
	rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
	if (rc == 0) {
		RMDBGLOG((LOCALDBG,"Timeout while waiting for Capture Start Command Completion\n"));
		return RM_PENDING;
	}
	else if (kc_signal_pending_current()) {
		RMDBGLOG((LOCALDBG,"Interrupted while waiting for Capture Start Command Completion\n"));
		return RM_PENDING;
	}
	else {
		RMDBGLOG((LOCALDBG,"Capture Start Command acknoledged rc = %d\n",rc));
	}

	command = VoipCodec_Command_Playback_Start;
	EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
	rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
	if (rc == 0) {
		RMDBGLOG((LOCALDBG,"Timeout while waiting for Playback Start Command Completion\n"));
		return RM_PENDING;
	}
	else if (kc_signal_pending_current()) {
		RMDBGLOG((LOCALDBG,"Interrupted while waiting for Playback Start Command Completion\n"));
		return RM_PENDING;
	}
	else {
		RMDBGLOG((LOCALDBG,"Playback Start Command acknoledged rc = %d\n",rc));
	}

	return RM_OK;
}

static RMstatus cleanup_voip(struct voipprivate *pV)
{
	RMuint32 profile = 0;
	struct em8xxxprivate *pE = Etable +(pV-VOIPtable);
	enum VoipCodec_Command_type command;
	RMstatus err;
	int rc;

	command = VoipCodec_Command_Capture_Stop;
	EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
	rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
	if (rc == 0) {
		RMDBGLOG((LOCALDBG,"Timeout while waiting for Capture Stop Command Completion\n"));
		return RM_PENDING;
	}
	else if (kc_signal_pending_current()) {
		RMDBGLOG((LOCALDBG,"Interrupted while waiting for Capture Stop Command Completion\n"));
		return RM_PENDING;
	}
	else {
		RMDBGLOG((LOCALDBG,"Capture stop Command acknoledged rc = %d\n",rc));
	}

	command = VoipCodec_Command_Playback_Stop;
	EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
	rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
	if (rc == 0) {
		RMDBGLOG((LOCALDBG,"Timeout while waiting for Playback Stop Command Completion\n"));
		return RM_PENDING;
	}
	else if (kc_signal_pending_current()) {
		RMDBGLOG((LOCALDBG,"Interrupted while waiting for Playback Stop Command Completion\n"));
		return RM_PENDING;
	}
	else {
		RMDBGLOG((LOCALDBG,"Playback Stop Command acknoledged rc = %d\n",rc));
	}

	EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Close,&profile,sizeof(profile));

	if (pV->VoipUCodeAddr)
		rm_free_ptr(pE,pV->VoipUCodeAddr);
	if (pV->VoipProfileCachedAddr)
		rm_free_ptr(pE,pV->VoipProfileCachedAddr);
	if (pV->VoipProfileUncachedAddr)
		rm_free_ptr(pE,pV->VoipProfileUncachedAddr);
	
	return RM_OK;
}

static int em8xxx_voip_open(struct phone_device *p, struct file *file_p)
{
	struct voipprivate *pV = VOIPtable + p->board;
	struct em8xxxprivate *pE = Etable + (pV-VOIPtable);
	enum VoipCodec_Command_type command;
	RMstatus err;
	int rc;

	file_p->private_data = pV;
	
	pV->voip_open_count++;

	if(pV->voip_open_count==1)
		em8xxx_voip_add_timer(pV);

	command = VoipCodec_Command_DTMF_Init;
	EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
	rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
	if (rc == 0) {
		RMDBGLOG((LOCALDBG,"Timeout while waiting for DTMF Init Command Completion\n"));
		return RM_PENDING;
	}
	else if (kc_signal_pending_current()) {
		RMDBGLOG((LOCALDBG,"Interrupted while waiting for DTMF Init Command Completion\n"));
		return RM_PENDING;
	}
	else {
		RMDBGLOG((LOCALDBG,"DTMF Init Command acknoledged rc = %d\n",rc));
	}

	command = VoipCodec_Command_DTMF_Start;
	EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
	rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
	if (rc == 0) {
		RMDBGLOG((LOCALDBG,"Timeout while waiting for DTMF Start Command Completion\n"));
		return RM_PENDING;
	}
	else if (kc_signal_pending_current()) {
		RMDBGLOG((LOCALDBG,"Interrupted while waiting for DTMF Start Command Completion\n"));
		return RM_PENDING;
	}
	else {
		RMDBGLOG((LOCALDBG,"DTMF Start Command acknoledged rc = %d\n",rc));
	}

	command = VoipCodec_Command_Aec_Init;
	EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
	rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
	if (rc == 0) {
		RMDBGLOG((LOCALDBG,"Timeout while waiting for AEC Init Command Completion\n"));
		return RM_PENDING;
	}
	else if (kc_signal_pending_current()) {
		RMDBGLOG((LOCALDBG,"Interrupted while waiting for AEC Init Command Completion\n"));
		return RM_PENDING;
	}
	else {
		RMDBGLOG((LOCALDBG,"AEC Init Command acknoledged rc = %d\n",rc));
	}

	RMDBGLOG((LOCALDBG,"Em8xxx VOIP Opening board %d\n", p->board));
	
	return 0;
}

static ssize_t em8xxx_voip_read(struct file *file_p, char *buf,size_t length,loff_t *ppos)
{
	struct voipprivate *pV=(struct voipprivate *) file_p->private_data;
	struct em8xxxprivate *pE= Etable + (pV-VOIPtable);
	struct VoipCodec_ReadChunk_in_type in;
	struct VoipCodec_ReadChunk_out_type out;
	RMstatus err = RM_PENDING;
	int rc;
	RMuint32 count = 0;

	if (!pV->voip_open_count) {
		return -EINVAL;
	}
	
	while (length > 0) {
		if (length >= sizeof(out.Chunk.data)) {
			in.Size = sizeof(out.Chunk.data);
			length -= sizeof(out.Chunk.data);
		}
		else {
			in.Size = length;
			length = 0;
		}

		while (err == RM_PENDING) {
			EM8XXXVOIPEXP(pE,VoipCodec,RMVoipCodecPropertyID_ReadChunk,&in,sizeof(in),&out,sizeof(out));	
			if (err == RM_PENDING) {
				rc = kc_interruptible_sleep_on_timeout(pV->read_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
				if (rc == 0) {
					RMDBGLOG((LOCALDBG,"Timeout in read chunk\n"));
					return -EAGAIN;
				}
				else if (kc_signal_pending_current()) {
					RMDBGLOG((LOCALDBG,"Interrupted while waiting for reading chunk\n"));
					return -EINTR;
				}
			}
		}

		kc_logging_copy_to_user(buf+count,out.Chunk.data,out.Chunk.size);
		count += out.Chunk.size;
	}

	return count;
}

static ssize_t em8xxx_voip_write(struct file * file_p,const char *buf, size_t count,loff_t * ppos)
{
	struct voipprivate *pV = (struct voipprivate *)file_p->private_data;
	struct em8xxxprivate *pE = Etable + (pV-VOIPtable);
	struct VoipCodec_WriteChunk_in_type in;
	struct VoipCodec_WriteChunk_out_type out;
	RMuint32 written=0;
	RMstatus err = RM_PENDING;
	int rc;

	if (!pV->voip_open_count) {
		return -EINVAL;
	}

	while (count > 0) {
		if (count >= sizeof(in.Chunk.data)) {
			in.Chunk.size = sizeof(in.Chunk.data);
			count -= sizeof(in.Chunk.data);
		}
		else {
			in.Chunk.size = count;
			count = 0;
		}
	
		kc_logging_copy_from_user(in.Chunk.data,buf+written,in.Chunk.size);

		while (err == RM_PENDING) {
			EM8XXXVOIPEXP(pE,VoipCodec,RMVoipCodecPropertyID_WriteChunk,&in,sizeof(in),&out,sizeof(out));
			if (err == RM_PENDING) {
				rc = kc_interruptible_sleep_on_timeout(pV->write_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
				if (rc == 0) {
					RMDBGLOG((LOCALDBG,"Timeout in write chunk\n"));
					return -EAGAIN;
				}
				else if (kc_signal_pending_current()) {
					RMDBGLOG((LOCALDBG,"Interrupted while waiting for writing chunk\n"));
					return -EINTR;
				}
			}
		}
		

		written += out.WrittenSize;
	}

	return written;
}

static unsigned int em8xxx_voip_poll(struct file *file_p, poll_table * wait)
{
	unsigned int mask = 0;
	struct voipprivate *pV = VOIPtable + MINOR(file_p->f_dentry->d_inode->i_rdev);
	struct em8xxxprivate *pE = Etable + (pV-VOIPtable);
	struct DataFIFOInfo fifo_info;
	RMstatus err;

	kc_poll_wait(file_p,pV->poll_q, wait);

	if (pV->exc.bytes) {
		mask |= POLLPRI;
	}

	EM8XXXVOIPGP(pE,EMHWLIB_TARGET_MODULE(VoipCodec,0,1),RMGenericPropertyID_DataFIFOInfo,&fifo_info,sizeof(fifo_info));
	if (fifo_info.Writable > 0) {
		mask |= POLLOUT | POLLWRNORM;
	}

	EM8XXXVOIPGP(pE,EMHWLIB_TARGET_MODULE(VoipCodec,0,0),RMGenericPropertyID_DataFIFOInfo,&fifo_info,sizeof(fifo_info));
	if (fifo_info.Readable > 0) {
		mask |= POLLIN | POLLRDNORM;
	}

	return mask;
}

static int em8xxx_voip_ioctl(struct inode *inode, struct file *file_p, unsigned int cmd, unsigned long arg)
{
	struct voipprivate *pV = file_p->private_data;
	struct em8xxxprivate *pE = Etable + (pV - VOIPtable);
	int retval = 0;
	RMstatus err;
	RMint8 dtmf_ascii;
	enum VoipCodec_Encoder_Codec_type enc_codec;
	enum VoipCodec_Decoder_Codec_type dec_codec;
	enum VoipCodec_Command_type command;
	struct VoipCodec_Tone tg;
	struct VoipCodec_Cid cid;
//	PHONE_CID pcid;
	int rc;

	switch(cmd) {
	case PHONE_DTMF_READY:
		RMDBGLOG((LOCALDBG,"PHONE_DTMF_READY \n"));
		retval = pV->exc.bits.dtmf_ready;
		break;
	case PHONE_RING_CADENCE:
		RMDBGLOG((LOCALDBG,"PHONE_RING_CADENCE \n"));
		break;
	case OLD_PHONE_RING_START:
		RMDBGLOG((LOCALDBG,"OLD_PHONE_RING_START \n"));
		break;
	case PHONE_RING_START:
		RMDBGLOG((LOCALDBG,"PHONE_RING_START \n"));
//		kc_logging_copy_from_user(&pcid,(PHONE_CID *) arg,sizeof(PHONE_CID));
	//	snprintf(cid.month,sizeof(cid.month),pcid.month);
	//	snprintf(cid.day,sizeof(cid.day),pcid.day);
	//	snprintf(cid.hour,sizeof(cid.hour),pcid.hour);
	//	snprintf(cid.min,sizeof(cid.min),pcid.min);
	//	cid.numlen = pcid.numlen;
	//	snprintf(cid.number,sizeof(cid.number),pcid.number);
	//	cid.namelen = pcid.namelen;
	//	snprintf(cid.name,sizeof(cid.name),pcid.name);
		snprintf(cid.month,sizeof(cid.month),"11");
		snprintf(cid.day,sizeof(cid.day),"17");
		snprintf(cid.hour,sizeof(cid.hour),"17");
		snprintf(cid.min,sizeof(cid.min),"10");
		cid.numlen = 4;
		snprintf(cid.number,sizeof(cid.number),"7777");
		cid.namelen = 5;
		snprintf(cid.name,sizeof(cid.name),"yoann");
		RMDBGLOG((ENABLE,"Setting Caller id parameters : month : %s day : %s hour : %s min : %s numlen : %d number : %s namelen : %d name : %s\n",cid.month,cid.day,cid.hour,cid.min,cid.numlen,cid.number,cid.namelen,cid.name));
		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Cid_parameters,&cid,sizeof(cid));
		command = VoipCodec_Command_Cid_Init;
		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
		rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
		if (rc == 0) {
			RMDBGLOG((LOCALDBG,"Timeout while waiting for CidGen Init Command Completion\n"));
			return RM_PENDING;
		}
		else if (kc_signal_pending_current()) {
			RMDBGLOG((LOCALDBG,"Interrupted while waiting for CidGen Init Command Completion\n"));
			return RM_PENDING;
		}
		else {
			RMDBGLOG((LOCALDBG,"CidGen Init Command acknoledged rc = %d\n",rc));
		}
		command = VoipCodec_Command_Cid_Start;
		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
		rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
		if (rc == 0) {
			RMDBGLOG((LOCALDBG,"Timeout while waiting for CidGen Start Command Completion\n"));
			return RM_PENDING;
		}
		else if (kc_signal_pending_current()) {
			RMDBGLOG((LOCALDBG,"Interrupted while waiting for CidGen Start Command Completion\n"));
			return RM_PENDING;
		}
		else {
			RMDBGLOG((LOCALDBG,"CidGen Start Command acknoledged rc = %d\n",rc));
		}

		tg.freq1 = 17;
		tg.freq2 = 0;
		tg.time_on = 12000;
		tg.time_off = 28000;
		tg.level = 1;
		tg.ring = 1;
		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Tone_parameters,&tg,sizeof(tg));
		
		command = VoipCodec_Command_ToneGen_Init;
		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
		rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
		if (rc == 0) {
			RMDBGLOG((LOCALDBG,"Timeout while waiting for ToneGen Init Command Completion\n"));
			return RM_PENDING;
		}
		else if (kc_signal_pending_current()) {
			RMDBGLOG((LOCALDBG,"Interrupted while waiting for ToneGen Init Command Completion\n"));
			return RM_PENDING;
		}
		else {
			RMDBGLOG((LOCALDBG,"ToneGen Init Command acknoledged rc = %d\n",rc));
		}

		command = VoipCodec_Command_ToneGen_Start;
		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
		rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
		if (rc == 0) {
			RMDBGLOG((LOCALDBG,"Timeout while waiting for ToneGen Start Command Completion\n"));
			return RM_PENDING;
		}
		else if (kc_signal_pending_current()) {
			RMDBGLOG((LOCALDBG,"Interrupted while waiting for ToneGen Start Command Completion\n"));
			return RM_PENDING;
		}
		else {
			RMDBGLOG((LOCALDBG,"ToneGen Start Command acknoledged rc = %d\n",rc));
		}
		break;
	case PHONE_RING_STOP:
		RMDBGLOG((LOCALDBG,"PHONE_RING_STOP \n"));
		SlicSetState(pV,NORMAL_ACTIVE);
		command = VoipCodec_Command_ToneGen_Stop;
		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
		rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
		if (rc == 0) {
			RMDBGLOG((LOCALDBG,"Timeout while waiting for ToneGen Stop Command Completion\n"));
			return RM_PENDING;
		}
		else if (kc_signal_pending_current()) {
			RMDBGLOG((LOCALDBG,"Interrupted while waiting for ToneGen Stop Command Completion\n"));
			return RM_PENDING;
		}
		else {
			RMDBGLOG((LOCALDBG,"ToneGen Stop Command acknoledged rc = %d\n",rc));
		}
		command = VoipCodec_Command_Cid_Stop;
		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
		rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
		if (rc == 0) {
			RMDBGLOG((LOCALDBG,"Timeout while waiting for CidGen Stop Command Completion\n"));
			return RM_PENDING;
		}
		else if (kc_signal_pending_current()) {
			RMDBGLOG((LOCALDBG,"Interrupted while waiting for CidGen Stop Command Completion\n"));
			return RM_PENDING;
		}
		else {
			RMDBGLOG((LOCALDBG,"CidGen Stop Command acknoledged rc = %d\n",rc));
		}
		break;	
	case PHONE_RING:        
		RMDBGLOG((LOCALDBG,"PHONE_RING \n"));
		break;
	case PHONE_EXCEPTION:
		RMDBGLOG((LOCALDBG,"PHONE_EXCEPTION \n"));
		retval = pV->exc.bytes;
		pV->exc.bytes = 0;
		break;
	case PHONE_HOOKSTATE:
		RMDBGLOG((LOCALDBG,"PHONE_HOOKSTATE \n"));
		pV->exc.bits.hookstate = 0;
		retval = !read_gpio(pE,GPIO_LOOP_DETECT);
		break;
	case PHONE_FRAME:
		RMDBGLOG((LOCALDBG,"PHONE_FRAME \n"));
		break;
	case PHONE_REC_CODEC:
		RMDBGLOG((LOCALDBG,"PHONE_REC_CODEC \n"));
		switch(arg){
		case G723_63:
			break;
		case G723_53:
			break;
		case TS85:
			break;
		case TS48:
			break;
		case TS41:
			break;
		case G728:
			break;
		case G729:
			RMDBGLOG((ENABLE,"Recording codec : G729\n"));
			enc_codec = VoipCodec_Encoder_Codec_G729;
			EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Encoder_Codec,&enc_codec,sizeof(enc_codec));
			command = VoipCodec_Command_Encoder_Init;
			EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
			rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
			if (rc == 0) {
				RMDBGLOG((LOCALDBG,"Timeout while waiting for Encoder Init Command Completion\n"));
				return RM_PENDING;
			}
			else if (kc_signal_pending_current()) {
				RMDBGLOG((LOCALDBG,"Interrupted while waiting for Encoder Init Command Completion\n"));
				return RM_PENDING;
			}
			else {
				RMDBGLOG((LOCALDBG,"Encoder Init Command acknoledged rc = %d\n",rc));
			}
			break;
		case ULAW:
			RMDBGLOG((ENABLE,"Recording codec : ULAW\n"));
			enc_codec = VoipCodec_Encoder_Codec_G711_ULAW;
			EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Encoder_Codec,&enc_codec,sizeof(enc_codec));
			command = VoipCodec_Command_Encoder_Init;
			EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
			rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
			if (rc == 0) {
				RMDBGLOG((LOCALDBG,"Timeout while waiting for Encoder Init Command Completion\n"));
				return RM_PENDING;
			}
			else if (kc_signal_pending_current()) {
				RMDBGLOG((LOCALDBG,"Interrupted while waiting for Encoder Init Command Completion\n"));
				return RM_PENDING;
			}
			else {
				RMDBGLOG((LOCALDBG,"Encoder Init Command acknoledged rc = %d\n",rc));
			}
			break;
		case ALAW:
			RMDBGLOG((ENABLE,"Recording codec : ALAW\n"));
			enc_codec = VoipCodec_Encoder_Codec_G711_ALAW;
			EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Encoder_Codec,&enc_codec,sizeof(enc_codec));
			command = VoipCodec_Command_Encoder_Init;
			EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
			rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
			if (rc == 0) {
				RMDBGLOG((LOCALDBG,"Timeout while waiting for Encoder Init Command Completion\n"));
				return RM_PENDING;
			}
			else if (kc_signal_pending_current()) {
				RMDBGLOG((LOCALDBG,"Interrupted while waiting for Encoder Init Command Completion\n"));
				return RM_PENDING;
			}
			else {
				RMDBGLOG((LOCALDBG,"Encoder Init Command acknoledged rc = %d\n",rc));
			}
			break;
		case LINEAR16:
			RMDBGLOG((ENABLE,"Recording codec : S16_LINEAR\n"));
			enc_codec = VoipCodec_Encoder_Codec_G711_LINEAR;
			EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Encoder_Codec,&enc_codec,sizeof(enc_codec));
			command = VoipCodec_Command_Encoder_Init;
			EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
			rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
			if (rc == 0) {
				RMDBGLOG((LOCALDBG,"Timeout while waiting for Encoder Init Command Completion\n"));
				return RM_PENDING;
			}
			else if (kc_signal_pending_current()) {
				RMDBGLOG((LOCALDBG,"Interrupted while waiting for Encoder Init Command Completion\n"));
				return RM_PENDING;
			}
			else {
				RMDBGLOG((LOCALDBG,"Encoder Init Command acknoledged rc = %d\n",rc));
			}
			break;
		case LINEAR8:
			break;
		}
		break;
	case PHONE_VAD:
		RMDBGLOG((LOCALDBG,"PHONE_VAD \n"));
		break;
	case PHONE_REC_START:
		RMDBGLOG((LOCALDBG,"PHONE_REC_START \n"));
//		command = VoipCodec_Command_Aec_Start;
//		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
//		rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
//		if (rc == 0) {
//			RMDBGLOG((LOCALDBG,"Timeout while waiting for AEC Start Command Completion\n"));
//			return RM_PENDING;
//		}
//		else if (kc_signal_pending_current()) {
//			RMDBGLOG((LOCALDBG,"Interrupted while waiting for AEC Start Command Completion\n"));
//			return RM_PENDING;
//		}
//		else {
//			RMDBGLOG((LOCALDBG,"AEC Start Command acknoledged rc = %d\n",rc));
//		}
		command = VoipCodec_Command_Encoder_Start;
		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
		rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
		if (rc == 0) {
			RMDBGLOG((LOCALDBG,"Timeout while waiting for Encoder Start Command Completion\n"));
			return RM_PENDING;
		}
		else if (kc_signal_pending_current()) {
			RMDBGLOG((LOCALDBG,"Interrupted while waiting for Encoder Start Command Completion\n"));
			return RM_PENDING;
		}
		else {
			RMDBGLOG((LOCALDBG,"Encoder Start Command acknoledged rc = %d\n",rc));
		}
		break;
	case PHONE_REC_STOP:
		RMDBGLOG((LOCALDBG,"PHONE_REC_STOP \n"));
		command = VoipCodec_Command_Aec_Stop;
		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
		rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
		if (rc == 0) {
			RMDBGLOG((LOCALDBG,"Timeout while waiting for AEC Stop Command Completion\n"));
			return RM_PENDING;
		}
		else if (kc_signal_pending_current()) {
			RMDBGLOG((LOCALDBG,"Interrupted while waiting for AEC Stop Command Completion\n"));
			return RM_PENDING;
		}
		else {
			RMDBGLOG((LOCALDBG,"AEC Stop Command acknoledged rc = %d\n",rc));
		}
		command = VoipCodec_Command_Encoder_Stop;
		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
		rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
		if (rc == 0) {
			RMDBGLOG((LOCALDBG,"Timeout while waiting for Encoder Stop Command Completion\n"));
			return RM_PENDING;
		}
		else if (kc_signal_pending_current()) {
			RMDBGLOG((LOCALDBG,"Interrupted while waiting for Encoder Stop Command Completion\n"));
			return RM_PENDING;
		}
		else {
			RMDBGLOG((LOCALDBG,"Encoder Stop Command acknoledged rc = %d\n",rc));
		}
		break;
	case PHONE_REC_DEPTH:
		RMDBGLOG((LOCALDBG,"PHONE_REC_DEPTH \n"));
		break;
	case PHONE_REC_VOLUME:
		RMDBGLOG((LOCALDBG,"PHONE_REC_VOLUME \n"));
		break;
	case PHONE_REC_VOLUME_LINEAR:
		RMDBGLOG((LOCALDBG,"PHONE_REC_VOLUME_LINEAR \n"));
		break;
	case PHONE_REC_LEVEL:
		RMDBGLOG((LOCALDBG,"PHONE_REC_LEVEL \n"));
		break;
	case PHONE_PLAY_CODEC:
		RMDBGLOG((LOCALDBG,"PHONE_PLAY_CODEC \n"));
		switch(arg){
		case G723_63:
			break;
		case G723_53:
			break;
		case TS85:
			break;
		case TS48:
			break;
		case TS41:
			break;
		case G728:
			break;
		case G729:
			RMDBGLOG((ENABLE,"Playback codec : G729\n"));
			dec_codec = VoipCodec_Decoder_Codec_G729;
			EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Decoder_Codec,&dec_codec,sizeof(dec_codec));
			command = VoipCodec_Command_Decoder_Init;
			EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
			rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
			if (rc == 0) {
				RMDBGLOG((LOCALDBG,"Timeout while waiting for Decoder Init Command Completion\n"));
				return RM_PENDING;
			}
			else if (kc_signal_pending_current()) {
				RMDBGLOG((LOCALDBG,"Interrupted while waiting for Decoder Init Command Completion\n"));
				return RM_PENDING;
			}
			else {
				RMDBGLOG((LOCALDBG,"Decoder Init Command acknoledged rc = %d\n",rc));
			}
			break;
		case ULAW:
			RMDBGLOG((ENABLE,"Playback codec : ULAW\n"));
			dec_codec = VoipCodec_Decoder_Codec_G711_ULAW;
			EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Decoder_Codec,&dec_codec,sizeof(dec_codec));
			command = VoipCodec_Command_Decoder_Init;
			EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
			rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
			if (rc == 0) {
				RMDBGLOG((LOCALDBG,"Timeout while waiting for Decoder Init Command Completion\n"));
				return RM_PENDING;
			}
			else if (kc_signal_pending_current()) {
				RMDBGLOG((LOCALDBG,"Interrupted while waiting for Decoder Init Command Completion\n"));
				return RM_PENDING;
			}
			else {
				RMDBGLOG((LOCALDBG,"Decoder Init Command acknoledged rc = %d\n",rc));
			}
			break;
		case ALAW:
			RMDBGLOG((ENABLE,"Playback codec : ALAW\n"));
			dec_codec = VoipCodec_Decoder_Codec_G711_ALAW;
			EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Decoder_Codec,&dec_codec,sizeof(dec_codec));
			command = VoipCodec_Command_Decoder_Init;
			EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
			rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
			if (rc == 0) {
				RMDBGLOG((LOCALDBG,"Timeout while waiting for Decoder Init Command Completion\n"));
				return RM_PENDING;
			}
			else if (kc_signal_pending_current()) {
				RMDBGLOG((LOCALDBG,"Interrupted while waiting for Decoder Init Command Completion\n"));
				return RM_PENDING;
			}
			else {
				RMDBGLOG((LOCALDBG,"Decoder Init Command acknoledged rc = %d\n",rc));
			}
			break;
		case LINEAR16:
			RMDBGLOG((ENABLE,"Playback codec : S16_LINEAR\n"));
			dec_codec = VoipCodec_Decoder_Codec_G711_LINEAR;
			EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Decoder_Codec,&dec_codec,sizeof(dec_codec));
			command = VoipCodec_Command_Decoder_Init;
			EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
			rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
			if (rc == 0) {
				RMDBGLOG((LOCALDBG,"Timeout while waiting for Decoder Init Command Completion\n"));
				return RM_PENDING;
			}
			else if (kc_signal_pending_current()) {
				RMDBGLOG((LOCALDBG,"Interrupted while waiting for Decoder Init Command Completion\n"));
				return RM_PENDING;
			}
			else {
				RMDBGLOG((LOCALDBG,"Decoder Init Command acknoledged rc = %d\n",rc));
			}
			break;
		case LINEAR8:
			break;
		}
		break;
	case PHONE_PLAY_START:
		RMDBGLOG((LOCALDBG,"PHONE_PLAY_START \n"));
		SlicSetState(pV,NORMAL_ACTIVE);
		command = VoipCodec_Command_ToneGen_Stop;
		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
		rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
		if (rc == 0) {
			RMDBGLOG((LOCALDBG,"Timeout while waiting for ToneGen Stop Command Completion\n"));
			return RM_PENDING;
		}
		else if (kc_signal_pending_current()) {
			RMDBGLOG((LOCALDBG,"Interrupted while waiting for ToneGen Stop Command Completion\n"));
			return RM_PENDING;
		}
		else {
			RMDBGLOG((LOCALDBG,"ToneGen Stop Command acknoledged rc = %d\n",rc));
		}
		command = VoipCodec_Command_Cid_Stop;
		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
		rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
		if (rc == 0) {
			RMDBGLOG((LOCALDBG,"Timeout while waiting for CidGen Stop Command Completion\n"));
			return RM_PENDING;
		}
		else if (kc_signal_pending_current()) {
			RMDBGLOG((LOCALDBG,"Interrupted while waiting for CidGen Stop Command Completion\n"));
			return RM_PENDING;
		}
		else {
			RMDBGLOG((LOCALDBG,"CidGen Stop Command acknoledged rc = %d\n",rc));
		}
		command = VoipCodec_Command_Decoder_Start;
		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
		rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
		if (rc == 0) {
			RMDBGLOG((LOCALDBG,"Timeout while waiting for Decoder Start Command Completion\n"));
			return RM_PENDING;
		}
		else if (kc_signal_pending_current()) {
			RMDBGLOG((LOCALDBG,"Interrupted while waiting for Decoder Start Command Completion\n"));
			return RM_PENDING;
		}
		else {
			RMDBGLOG((LOCALDBG,"Decoder Start Command acknoledged rc = %d\n",rc));
		}
		break;
	case PHONE_PLAY_STOP:
		RMDBGLOG((LOCALDBG,"PHONE_PLAY_STOP \n"));
		command = VoipCodec_Command_Decoder_Stop;
		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
		rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
		if (rc == 0) {
			RMDBGLOG((LOCALDBG,"Timeout while waiting for Decoder Stop Command Completion\n"));
			return RM_PENDING;
		}
		else if (kc_signal_pending_current()) {
			RMDBGLOG((LOCALDBG,"Interrupted while waiting for Decoder Stop Command Completion\n"));
			return RM_PENDING;
		}
		else {
			RMDBGLOG((LOCALDBG,"Decoder Stop Command acknoledged rc = %d\n",rc));
		}
		command = VoipCodec_Command_ToneGen_Stop;
		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
		rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
		if (rc == 0) {
			RMDBGLOG((LOCALDBG,"Timeout while waiting for ToneGen Stop Command Completion\n"));
			return RM_PENDING;
		}
		else if (kc_signal_pending_current()) {
			RMDBGLOG((LOCALDBG,"Interrupted while waiting for ToneGen Stop Command Completion\n"));
			return RM_PENDING;
		}
		else {
			RMDBGLOG((LOCALDBG,"ToneGen Stop Command acknoledged rc = %d\n",rc));
		}
		break;
	case PHONE_PLAY_DEPTH:
		RMDBGLOG((LOCALDBG,"PHONE_PLAY_DEPTH \n"));
		break;
	case PHONE_PLAY_VOLUME:
		RMDBGLOG((LOCALDBG,"PHONE_PLAY_VOLUME \n"));
		break;
	case PHONE_PLAY_VOLUME_LINEAR:
		RMDBGLOG((LOCALDBG,"PHONE_PLAY_VOLUME_LINEAR \n"));
		break;
	case PHONE_PLAY_LEVEL:
		RMDBGLOG((LOCALDBG,"PHONE_PLAY_LEVEL \n"));
		break;
	case PHONE_MAXRINGS:   /* this ioctl is superseeded, and not relevant.*/
		RMDBGLOG((LOCALDBG,"PHONE_MAXRINGS \n"));
		break;
	case PHONE_SET_TONE_ON_TIME:
		RMDBGLOG((LOCALDBG,"PHONE_SET_TONE_ON_TIME \n"));
		break;
	case PHONE_SET_TONE_OFF_TIME:
		RMDBGLOG((LOCALDBG,"PHONE_SET_TONE_OFF_TIME \n"));
		break;
	case PHONE_GET_TONE_ON_TIME:
		RMDBGLOG((LOCALDBG,"PHONE_GET_TONE_ON_TIME \n"));
		break;
	case PHONE_GET_TONE_OFF_TIME:
		RMDBGLOG((LOCALDBG,"PHONE_GET_TONE_OFF_TIME \n"));
		break;
	case PHONE_PLAY_TONE:
		RMDBGLOG((LOCALDBG,"PHONE_PLAY_TONE \n"));
		break;
	case PHONE_GET_TONE_STATE:
		RMDBGLOG((LOCALDBG,"PHONE_GET_TONE_STATE \n"));
		break;
	case PHONE_GET_DTMF:
		RMDBGLOG((LOCALDBG,"PHONE_GET_DTMF \n"));
		break;
	case PHONE_GET_DTMF_ASCII:
		RMDBGLOG((LOCALDBG,"PHONE_GET_DTMF_ASCII \n"));
		EM8XXXVOIPGP(pE,VoipCodec,RMVoipCodecPropertyID_DTMF_Ascii,&dtmf_ascii,sizeof(dtmf_ascii));
		retval = dtmf_ascii;
		RMDBGLOG((LOCALDBG,"returns ascii character %c \n",retval));
		break;
	case PHONE_DTMF_OOB:
		RMDBGLOG((LOCALDBG,"PHONE_DTMF_OOB \n"));
		break;
	case PHONE_DIALTONE:
		RMDBGLOG((LOCALDBG,"PHONE_DIALTONE \n"));
		tg.freq1 = 440;
		tg.freq2 = 0;
		tg.time_on = 8000;
		tg.time_off = 0;
		tg.level = 2;
		tg.ring = 0;
		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Tone_parameters,&tg,sizeof(tg));
		
		command = VoipCodec_Command_ToneGen_Init;
		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
		rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
		if (rc == 0) {
			RMDBGLOG((LOCALDBG,"Timeout while waiting for ToneGen Init Command Completion\n"));
			return RM_PENDING;
		}
		else if (kc_signal_pending_current()) {
			RMDBGLOG((LOCALDBG,"Interrupted while waiting for ToneGen Init Command Completion\n"));
			return RM_PENDING;
		}
		else {
			RMDBGLOG((LOCALDBG,"ToneGen Init Command acknoledged rc = %d\n",rc));
		}

		command = VoipCodec_Command_ToneGen_Start;
		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
		rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
		if (rc == 0) {
			RMDBGLOG((LOCALDBG,"Timeout while waiting for ToneGen Start Command Completion\n"));
			return RM_PENDING;
		}
		else if (kc_signal_pending_current()) {
			RMDBGLOG((LOCALDBG,"Interrupted while waiting for ToneGen Start Command Completion\n"));
			return RM_PENDING;
		}
		else {
			RMDBGLOG((LOCALDBG,"ToneGen Start Command acknoledged rc = %d\n",rc));
		}

		break;
	case PHONE_BUSY:
		RMDBGLOG((LOCALDBG,"PHONE_BUSY \n"));
		tg.freq1 = 440;
		tg.freq2 = 0;
		tg.time_on = 4000;
		tg.time_off = 4000;
		tg.level = 2;
		tg.ring = 0;
		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Tone_parameters,&tg,sizeof(tg));
		
		command = VoipCodec_Command_ToneGen_Init;
		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
		rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
		if (rc == 0) {
			RMDBGLOG((LOCALDBG,"Timeout while waiting for ToneGen Init Command Completion\n"));
			return RM_PENDING;
		}
		else if (kc_signal_pending_current()) {
			RMDBGLOG((LOCALDBG,"Interrupted while waiting for ToneGen Init Command Completion\n"));
			return RM_PENDING;
		}
		else {
			RMDBGLOG((LOCALDBG,"ToneGen Init Command acknoledged rc = %d\n",rc));
		}

		command = VoipCodec_Command_ToneGen_Start;
		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
		rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
		if (rc == 0) {
			RMDBGLOG((LOCALDBG,"Timeout while waiting for ToneGen Start Command Completion\n"));
			return RM_PENDING;
		}
		else if (kc_signal_pending_current()) {
			RMDBGLOG((LOCALDBG,"Interrupted while waiting for ToneGen Start Command Completion\n"));
			return RM_PENDING;
		}
		else {
			RMDBGLOG((LOCALDBG,"ToneGen Start Command acknoledged rc = %d\n",rc));
		}

		break;
	case PHONE_RINGBACK:
		RMDBGLOG((LOCALDBG,"PHONE_RINGBACK \n"));
		tg.freq1 = 400;
		tg.freq2 = 0;
		tg.time_on = 13200;
		tg.time_off = 26800;
		tg.level = 2;
		tg.ring = 0;
		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Tone_parameters,&tg,sizeof(tg));
		
		command = VoipCodec_Command_ToneGen_Init;
		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
		rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
		if (rc == 0) {
			RMDBGLOG((LOCALDBG,"Timeout while waiting for ToneGen Init Command Completion\n"));
			return RM_PENDING;
		}
		else if (kc_signal_pending_current()) {
			RMDBGLOG((LOCALDBG,"Interrupted while waiting for ToneGen Init Command Completion\n"));
			return RM_PENDING;
		}
		else {
			RMDBGLOG((LOCALDBG,"ToneGen Init Command acknoledged rc = %d\n",rc));
		}

		command = VoipCodec_Command_ToneGen_Start;
		EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
		rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
		if (rc == 0) {
			RMDBGLOG((LOCALDBG,"Timeout while waiting for ToneGen Start Command Completion\n"));
			return RM_PENDING;
		}
		else if (kc_signal_pending_current()) {
			RMDBGLOG((LOCALDBG,"Interrupted while waiting for ToneGen Start Command Completion\n"));
			return RM_PENDING;
		}
		else {
			RMDBGLOG((LOCALDBG,"ToneGen Start Command acknoledged rc = %d\n",rc));
		}

		break;
	case PHONE_WINK:
		RMDBGLOG((LOCALDBG,"PHONE_WINK \n"));
		break;
	case PHONE_CPT_STOP:
		RMDBGLOG((LOCALDBG,"PHONE_CPT_STOP \n"));
		break;
	case PHONE_QUERY_CODEC:
		RMDBGLOG((LOCALDBG,"PHONE_QUERY_CODEC \n"));
		break;
	case PHONE_CAPABILITIES:
		RMDBGLOG((LOCALDBG,"PHONE_CAPABILITIES \n"));
		break;
	case PHONE_CAPABILITIES_LIST:
		RMDBGLOG((LOCALDBG,"PHONE_CAPABILITIES_LIST \n"));
		break;
	case PHONE_CAPABILITIES_CHECK:
		RMDBGLOG((LOCALDBG,"PHONE_CAPABILITIES_CHECK \n"));
		return 1;
		break;
	case PHONE_PSTN_SET_STATE:
		RMDBGLOG((LOCALDBG,"PHONE_PSTN_SET_STATE \n"));
		switch(arg){
		case PSTN_ON_HOOK:
			break;
		case PSTN_RINGING:
			break;
		case PSTN_OFF_HOOK:
			break;
		case PSTN_PULSE_DIAL:
			break;
		}
		break;
	case PHONE_PSTN_GET_STATE:
		RMDBGLOG((LOCALDBG,"PHONE_PSTN_GET_STATE \n"));
		break;
	}
	return retval;
}

static int em8xxx_voip_fasync(int fd, struct file *file_p, int mode)
{
	struct voipprivate *pV = file_p->private_data;

	return fasync_helper(fd, file_p, mode, &pV->async_queue);
}

static int em8xxx_voip_release(struct inode *inode, struct file *file_p)
{
	struct voipprivate *pV = (struct voipprivate *) file_p->private_data;
	struct em8xxxprivate *pE = Etable + (pV - VOIPtable);
	enum VoipCodec_Command_type command;
	RMstatus err;
	int rc;

	pV->voip_open_count --;
	pV->exc.bytes = 0;

	file_p->private_data = NULL;
	
	command = VoipCodec_Command_DTMF_Stop;
	EM8XXXVOIPSP(pE,VoipCodec,RMVoipCodecPropertyID_Command,&command,sizeof(command));
	rc = kc_interruptible_sleep_on_timeout(pV->command_q,US_TO_JIFFIES(VOIP_EVENT_TIMEOUT_US));
	if (rc == 0) {
		RMDBGLOG((LOCALDBG,"Timeout while waiting for DTMF Stop Command Completion\n"));
		return RM_PENDING;
	}
	else if (kc_signal_pending_current()) {
		RMDBGLOG((LOCALDBG,"Interrupted while waiting for DTMF Stop Command Completion\n"));
		return RM_PENDING;
	}
	else {
		RMDBGLOG((LOCALDBG,"DTMF Stop Command acknoledged rc = %d\n",rc));
	}

	return 0;
}

static int em8xxx_voip_init(struct em8xxxprivate *pE)
{
	struct voipprivate *pV=VOIPtable+(pE-Etable);
	RMuint32 mask = SOFT_IRQ_EVENT_COMMANDCOMPLETION |
			SOFT_IRQ_EVENT_VOIP_DTMF_READY |
			SOFT_IRQ_EVENT_VOIP_FRAME_ENCODED | 
			SOFT_IRQ_EVENT_VOIP_FRAME_DECODED;

	if (pV->voip_active == 0) {
		memset(pV,0,sizeof(struct voipprivate));

		/* Register with the Telephony for Linux subsystem */

		pV->p_dev.f_op = &em8xxx_voip_fops;
		pV->p_dev.open = em8xxx_voip_open;
		pV->p_dev.board = pE-Etable;
		phone_register_device(&pV->p_dev, PHONE_UNIT_ANY);
	}
	else {
		RMDBGLOG((LOCALDBG,"Em8xxx Voip Driver already registered ! \n"));
		return -EINVAL;
	}

	pV->voip_active = 1;

	kc_init_waitqueue_head(&pV->command_q);
	kc_init_waitqueue_head(&pV->poll_q);
	kc_init_waitqueue_head(&pV->read_q);
	kc_init_waitqueue_head(&pV->write_q);

	tasklet_init(&pV->event_tq,em8xxx_voip_clear_event_mask,(unsigned long) pV);
	krua_register_event_callback(pE,VoipCodec,mask,em8xxx_voip_event_callback);

	init_gpio(pE);
	init_voip(pV);

	SlicSetState(pV,NORMAL_ACTIVE);

	pV->check_interval = HZ / DEFAULT_CHECK_FREQ;
	
	em8xxx_voip_init_timer(pV);
	em8xxx_voip_add_timer(pV);

	RMDBGLOG((ENABLE,"Em8xxx Voip driver registered\n"));

	return 0;
}

static int em8xxx_voip_cleanup(struct em8xxxprivate *pE)
{
	struct voipprivate *pV=VOIPtable+(pE-Etable);

	cleanup_voip(pV);

	del_timer(&pV->timer);
	kc_deinit_waitqueue_head(pV->command_q);
	kc_deinit_waitqueue_head(pV->poll_q);
	kc_deinit_waitqueue_head(pV->read_q);
	kc_deinit_waitqueue_head(pV->write_q);

	krua_unregister_event_callback(pE,VoipCodec,em8xxx_voip_event_callback);
	tasklet_kill(&pV->event_tq);

	if (pV->voip_active == 1) {
		if (pV->voip_open_count == 0) {
			phone_unregister_device(&pV->p_dev);
		}
		else {
			RMDBGLOG((LOCALDBG,"Cannot unregister telephony driver, device is opened \n"));
			return -EINVAL;
		}
	}
	else {
		RMDBGLOG((LOCALDBG,"No Voip device registered\n"));
		return -EINVAL;
	}

	RMDBGLOG((LOCALDBG,"Em8xxx Voip Driver unregistered\n"));
	pV->voip_active = 0;

	return 0;
}

int init_module(void)
{
	int i,enabled_count=0;

	for (i=0;i<MAXLLAD;i++) {
		if (&((&Etable[i])->pllad) != NULL) {
			if (Etable[i].pllad != NULL) {
				if (em8xxx_voip_init(&Etable[i]) != 0)
					return -EINVAL;
				enabled_count ++;
			}
		}
	}

	if (((&Etable[0])->pllad != NULL) && (enabled_count == 0)) {
		RMDBGLOG((LOCALDBG,"Default behaviour, enabling Voip on device #0\n"));
		if (em8xxx_voip_init(&Etable[0]) != 0)
			return -EINVAL;
	}

	return 0;
}

void cleanup_module(void)
{
	int i;

	RMDBGLOG((LOCALDBG,"Removing voip module\n"));

	for (i=0;i<MAXLLAD;i++) {
		if (VOIPtable[i].voip_active) {
			em8xxx_voip_cleanup(&Etable[i]);
		}
	}
}
