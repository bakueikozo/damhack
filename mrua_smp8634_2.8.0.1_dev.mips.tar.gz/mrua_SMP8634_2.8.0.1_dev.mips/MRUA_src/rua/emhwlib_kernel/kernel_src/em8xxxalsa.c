// for linux-2.6.x: dummy source file having the same name as the final module em8xxxalsa.ko
