/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rua_property.h
  @brief  

  Describes the OS independent api used by an application to access
  the hardware.

  @author Christian Wolff
  @date   2003-03-24
*/

#ifndef __RUA_PROPERTY_H__
#define __RUA_PROPERTY_H__

// The property definitions
#include "../../emhwlib/include/emhwlib_properties_1000.h"
#include "../../emhwlib/include/emhwlib_propertytypes.h"

#endif  // __RUA_PROPERTY_H__
