/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rua.h
  @brief  

  Describes the OS independent api used by an application to access
  the hardware.

  @author Julien Soulier
  @date   2003-03-18
  @ingroup mruaapi
*/

#ifndef __RUA_H__
#define __RUA_H__


#include "../../rmdef/rmdef.h"
#include "../../emhwlib/include/emhwlib_categories.h"
#include "../../emhwlib/include/emhwlib_event.h"
#include "../../emhwlib/include/emhwlib_globaltypes.h"
#include "../../emhwlib/include/emhwlib_enumerator.h"
#include "../../emhwlib/include/emhwlib_displaytypes.h"

RM_EXTERN_C_BLOCKSTART

#define RUA_POOL_FORCE_DRAM_COPY 0x80000000

/**
   When creating a pool decides whether the pool will be used to send
   data to the hardware or to receive data from it
*/
enum RUAPoolDirection {
	RUA_POOL_DIRECTION_SEND = 54, 
	RUA_POOL_DIRECTION_RECEIVE,
};

enum RUAEventId {
	RUAEVENT_COMMANDCOMPLETION = SOFT_IRQ_EVENT_COMMANDCOMPLETION,
	RUAEVENT_COMMANDCOMPLETION_DISPLAY = SOFT_IRQ_EVENT_COMMANDCOMPLETION_DISPLAY,
	RUAEVENT_ENDOFSEQUENCE = SOFT_IRQ_EVENT_ENDOFSEQUENCE,
	RUAEVENT_INBAND_COMMAND = SOFT_IRQ_EVENT_INBAND_COMMAND,
	RUAEVENT_LAST_FRAME_DISPLAYED = SOFT_IRQ_EVENT_LAST_FRAME_DISPLAYED,
	RUAEVENT_XFER_FIFO_READY = SOFT_IRQ_EVENT_XFER_FIFO_READY,
	RUAEVENT_AU_DECODED = SOFT_IRQ_EVENT_AU_DECODED,
	RUAEVENT_AU_VIDEO_ERROR = SOFT_IRQ_EVENT_VIDEO_ERROR
};

struct RUAEvent {
	RMuint32 ModuleID;
	RMuint32 Mask;
};


#define RUA_ADDRESS_ID_VIDEO_UCODE 0x1
#define RUA_ADDRESS_ID_AUDIO_UCODE 0x2
#define RUA_ADDRESS_ID_DEMUX_UCODE 0x3
#define RUA_ADDRESS_ID_OSDBUF      0x4

#define RUA_ADDRESS_ID_USER1       0x1000
#define RUA_ADDRESS_ID_USER2       0x2000
#define RUA_ADDRESS_ID_USER3       0x3000
#define RUA_ADDRESS_ID_USER4       0x4000
#define RUA_ADDRESS_ID_USER5       0x5000
#define RUA_ADDRESS_ID_USER6       0x6000
#define RUA_ADDRESS_ID_USER7       0x7000
#define RUA_ADDRESS_ID_USER8       0x8000

#define RUA_SELECT_READ            0x1
#define RUA_SELECT_WRITE           0x2 
#define RUA_SELECT_EVENT           0x4

struct RUA;
struct RUABufferPool;

struct RUASelectEntry {
	RMuint32 handle;
	RMuint32 select;
};

/**
   Creates an instance of a rua handle.

   @param ppRua    
   @param ChipNumber    
   @return RM_OK if success, otherwise returns an error code.
*/
RMstatus RUACreateInstance(struct RUA **ppRua, RMuint32 ChipNumber);

/**
   Destroys a previously created rua instance.

   @param pRua     
   @return RM_OK if success, otherwise returns an error code.
*/
RMstatus RUADestroyInstance(struct RUA *pRua);

/**
   Sets a property to a RUA module. The call can block at most
   TimeOut_us microseconds. If the timeout has been reached and the
   setproperty action cannot be completed, the function returns
   RM_PENDING and a RUAevent will be sent as soon as the action is
   completed. Therefore to wait for a property completion one can use
   RUAWaitForMultipleEvents call.
   
   @param pRua  
   @param ModuleID      
   @param PropertyID    
   @param pValue        
   @param ValueSize     
   @param TimeOut_us    
   @return RM_OK if success, otherwise returns an error code.
*/
RMstatus RUASetProperty(struct RUA *pRua, 
			RMuint32 ModuleID,
			RMuint32 PropertyID, 
			void *pValue, RMuint32 ValueSize, 
			RMuint32 TimeOut_us);

/** 
   Gets a property to a RUA module. The call cannot be blocking. If it
   cannot be executed it returns RM_ERROR.

   @param pRua  
   @param ModuleID      
   @param PropertyID    
   @param pValue        
   @param ValueSize     
   @return RM_OK if success, otherwise returns an error code.
*/
RMstatus RUAGetProperty(struct RUA *pRua, 
			RMuint32 ModuleID,
			RMuint32 PropertyID, 
			void *pValue, RMuint32 ValueSize);


/**
   Gets and Sets a property to a RUA module. The call cannot be
   blocking. If it cannot be executed it returns RM_ERROR.

   @param pRua  
   @param ModuleID      
   @param PropertyID    
   @param pValueIn      
   @param ValueInSize   
   @param pValueOut     
   @param ValueOutSize  
   @return RM_OK if success, otherwise returns an error code.
*/
RMstatus RUAExchangeProperty(struct RUA *pRua, 
			     RMuint32 ModuleID,
			     RMuint32 PropertyID, 
			     void *pValueIn, RMuint32 ValueInSize, 
			     void *pValueOut, RMuint32 ValueOutSize);

/**
   Creates a pool of buffers used for sending data. 
   ModuleID is used to associate the bufferpool with a ruamodule.  
   When creating a pool not linked with any ruamodule, set it to
   0. This is the case when doing software demux.
   log2BufferSize is the 2 logarithm of the byte size of each buffer.
   The minimum allowable value is 12. (15 => 4 kB)
   BufferCount is the number of buffers contained in the pool.

   @param pRua 
   @param ModuleID 
   @param BufferCount 
   @param log2BufferSize 
   @param direction
   @param ppBufferPool 
   @return RM_OK if success, otherwise returns an error code.
*/
RMstatus RUAOpenPool(struct RUA *pRua, RMuint32 ModuleID,
		     RMuint32 BufferCount, 
		     RMuint32 log2BufferSize,
 		     enum RUAPoolDirection direction,
		     struct RUABufferPool **ppBufferPool);

/**
   Closes a pool previously opened with RUAOpenPool.
   
   @param pBufferPool      
   @return RM_OK if success, otherwise returns an error code.
*/
RMstatus RUAClosePool(struct RUABufferPool *pBufferPool);


/**
   Resets the state of the RUABufferPool.

   @param pBufferPool   
   @return 
*/
RMstatus RUAResetPool(struct RUABufferPool *pBufferPool);

/**
   Cleans a region of data cache. This call is used before sending
   data using a DMA transfer in case the data were written through the
   cache. Address is the virtual buffer address.

   @param pBufferPool
   @param pData
   @param DataSize 
   @return 
*/
RMstatus RUACleanCache(struct RUABufferPool *pBufferPool, RMuint8 *pData, RMuint32 DataSize);

/**
   Invalidates a region of data cache. This call is used before
   reading data coming from a DMA transfer in case the region is read
   through the cache. Address is the buffer virtual address.

   @param pBufferPool
   @param pData       
   @param DataSize 
   @return 
*/
RMstatus RUAInvalidateCache(struct RUABufferPool *pBufferPool, RMuint8 *pData, RMuint32 DataSize);

/**
   Gets physical address of DMA pool buffer

   @param pBufferPool
   @param pData
   @param DataSize
   @param pPhysicalAddress
   @return
*/
RMstatus RUAGetPhysicalAddress(struct RUABufferPool *pBufferPool, RMuint8 *pData, RMuint32 DataSize, RMuint32 *pPhysicalAddress);

/**
   marks the buffer in the pool ready to receive data.  This method
   must be called before allowing the source to output data.  For
   example after a flush of the module, you need to call
   RUAPreparePoolForReceiveData before running again the module,
   otherwise you may lose data if the input buffe is not large enough.

   @param pBufferPool   
   @return 
*/
RMstatus RUAPreparePoolForReceiveData(struct RUABufferPool *pBufferPool);

/**
   Waits at most TimeOut_us microseconds for a buffer to be available. 
   
   @param pBufferPool      
   @param ppBuffer      
   @param TimeOut_us    
   @return RM_OK if success, otherwise returns an error code.
*/
RMstatus RUAGetBuffer(struct RUABufferPool *pBufferPool, 
		      RMuint8 **ppBuffer, 
		      RMuint32 TimeOut_us);

/**
   returns the number of buffers in the pool ready to be got.
   A positive value means that next RUAGetBuffer will return
   immediately.

   @param pBufferPool @return
*/

RMuint32 RUAGetAvailableBufferCount(struct RUABufferPool *pBufferPool);

/**
   Sends part of a buffer obtained by RUAGetBuffer on pBufferPool to the
   rua module referenced by pModule. The data segment
   [ptr,ptr+dataSize[ must stand within [pBuffer,pBuffer+BufferSize[.

   pInfo contains side information associated with the data (as PTS
   for example)

   @param pRua       
   @param ModuleID       
   @param pBufferPool      
   @param pData
   @param DataSize    
   @param pInfo 
   @param InfoSize      
   @return RM_OK if success, otherwise returns an error code.
*/
RMstatus RUASendData(struct RUA *pRua, 
		     RMuint32 ModuleID,
		     struct RUABufferPool *pBufferPool, 
		     RMuint8 *pData, 
		     RMuint32 DataSize, 
		     void *pInfo, 
		     RMuint32 InfoSize);

/**
   Receives data from a module. Data are received using dma transfers.
   Before receiving data a bufferpool must be created with the
   RUA_POOL_DIRECTION_RECEIVE direction. After a call to
   RUAReceiveData, you get a buffer with a refcount equal to 1,
   therefore once the application has finished to process the buffer
   it needs to release it. Once the buffer reached a refcount equal to
   0, the buffer will be assigned if possible in the receive data
   buffer fifo automatically. Some data comes along with some specific
   information. If you want to get it as well you need to provide
   valid pInfo and InfoSize parameters. If pInfo is NULL then no side
   information will be fetched even if one is present.

   @param pRua  
   @param ModuleID      
   @param pBufferPool      
   @param pData 
   @param DataSize      
   @param pInfo 
   @param InfoSize      
   @return 
*/
RMstatus RUAReceiveData(struct RUA *pRua, 
			RMuint32 ModuleID,
			struct RUABufferPool *pBufferPool, 
			RMuint8 **pData, 
			RMuint32 *DataSize, 
			void *pInfo, 
			RMuint32 *InfoSize);

/**
   Releases a buffer obtain by RUAGetBuffer. This decreases the buffer
   refcount by 1, this is needed when no more data contained in it
   needs to be send.

   @param pBufferPool      
   @param pBuffer       
   @return RM_OK if success, otherwise returns an error code.
*/
RMstatus RUAReleaseBuffer(struct RUABufferPool *pBufferPool, 
			  RMuint8 *pBuffer);

/**
   Acquires a buffer obtain by RUAGetBuffer. It increase the refcount
   on the buffer by 1.

   @param pBufferPool      
   @param pBuffer       
   @return RM_OK if success, otherwise returns an error code.
*/
RMstatus RUAAcquireBuffer(struct RUABufferPool *pBufferPool, 
			  RMuint8 *pBuffer);

/**
   Waits at most TimeOut_us microseconds for at least one event from
   the array of rua events pEvents to occur.

   If one happens, returns RM_OK and *pEventNum is set to the index
   (in case EventCount=1 it is safe to have pEventNum=NULL)
   pEvents[i].event may be set to multiple bits. It will be updated to
   the signalled bit.
   
   If timeout or signal interruption, does not return RM_OK, and
   *pEventNum is set to 0xffffffff

   Specifying an origin risc that does run at the time of the call
   will fail silently from user point of view but log a message in
   emhwlib.

   Two threads waiting on the same event.ModuleID and the same
   event.Mask will produce unpredictable behavior. Application must
   ensure to avoid doing so.

   @param pRua  
   @param pEvents       
   @param EventCount    
   @param TimeOut_us: truncated to an entire number of timeslices.
    If less than one timeslice (usually 10ms), treated as zero.
   @param pEventNum     
   @return RM_OK if success, otherwise returns an error code.
*/
RMstatus RUAWaitForMultipleEvents(struct RUA *pRua, 
				  struct RUAEvent *pEvents, 
				  RMuint32 EventCount, 
				  RMuint32 TimeOut_us, 
				  RMuint32 *pEventNum);
/**
   Resets an event in order to be sure not to catch an old event when
   waiting on it.

   @param pRUA  
   @param pEvent        
   @return 
*/
RMstatus RUAResetEvent(struct RUA *pRUA, struct RUAEvent *pEvent);

/**
   Sets an event on the RUAEvent with ModuleID 0.  

   mask is a bit field of events. This allows to create at most 32
   distinct events which can be used to wake up at most 32 distincts
   threads. Each thread must wait on one specific bit.

   @param pRUA  
   @param mask
   @return RM_OK if success, otherwise returns an error code.
*/
RMstatus RUASetEvent(struct RUA *pRUA, RMuint32 mask);

/**
   Implements a linux select function. It is used to wait on a file
   being readable, writable simultaneously as waiting for an event to
   occur on RUA. This can be used to read from a socket as fast as
   possible without using threads. The handles array is updated
   accordingly.

   @param pRUA  
   @param n     
   @param entries
   @param timeout_us    
   @return RM_OK if success, otherwise returns an error code.
*/
RMstatus RUASelect(struct RUA *pRUA, RMuint32 n, struct RUASelectEntry *entries, RMuint32 timeout_us);

/**
   Tries to allocate size bytes in dram with index dramIndex.  

   returns NULL if the allocation fails (out of memory). 
   dramType tells the memory manager if the allocated block is 
   cached or not from pT110 point of view.

   863x and above: dramtype parameter is ignored; the returned address is a gbus address.

   @param pRua  
   @param dramIndex     
   @param dramtype
   @param size  
   @return
*/
RMuint32 RUAMalloc(struct RUA *pRua, RMuint32 dramIndex, enum RUADramType dramtype, RMuint32 size); 

/**
   Frees a previously allocated pointer from DRAM.

   @param pRUA  
   @param ptr   
*/
void RUAFree(struct RUA *pRUA, RMuint32 ptr);

/**
   returns the amount of free RUA memory for the given dramIndex and dramType

   @param pRua  
   @param dramIndex     
   @param dramtype
   @param pAvailSize  
   @return
*/
RMstatus RUAGetAvailableMemory(struct RUA *pRUA, RMuint32 dramIndex, enum RUADramType dramtype, RMuint32 *pAvailSize);

/**
   Maps a locked area [address, address+size[ in caller address sapce.
   If the area is not already locked (with RUALock) return NULL.

   @param pRua  
   @param address       
   @param size  
*/
RMuint8 *RUAMap(struct RUA *pRua, RMuint32 address, RMuint32 size);

/**
   Unmaps a previously mapped area.
   
   @param pRua  
   @param ptr   
   @param size  
*/
void RUAUnMap(struct RUA *pRua, RMuint8 *ptr, RMuint32 size);

/**
   Loks an area in pci. This prevent the pci region to be modified,
   thus it allows to when mapped to access directly the chip DRAM by
   accessing regular addresses. 

   In case emhwlib is in kernel mode, a locked area will not be
   automatically unlocked on application exit. This may be useful to
   control a permanent OSD or frame buffer.

   An application needs therefore to call explicitely RUAMUnLock to
   free the pci region.

   @param pRua  
   @param address       
   @param size  
   @return 
*/
RMstatus RUALock(struct RUA *pRua, RMuint32 address, RMuint32 size);

/**
   Unlocks an area previously locked by RUALock.

   @param pRua  
   @param address       
   @param size  
   @return 
*/
RMstatus RUAUnLock(struct RUA *pRua, RMuint32 address, RMuint32 size);


/**
   Sets an ID to a previously allocated address. This ID can be used
   with RUAGetAddressID to retrieve the address attached to the ID.
   A valid ID must not equal 0.

   @param pRua  
   @param address       
   @param ID    
   @return 
*/
RMstatus RUASetAddressID(struct RUA *pRua, RMuint32 address, RMuint32 ID); 

/**
   Returns the address attached to the specified ID. Return 0, if the
   ID is not found.

   @param pRua  
   @param ID    
   @return 
*/
RMuint32 RUAGetAddressID(struct RUA *pRua, RMuint32 ID); 

/**
   Increment the reference counter for the address.
   Useful when you do not want that the hardware library frees a 
   specific address when the application exits.

   @param pRua
   @param address
   @return
*/
RMstatus RUAAcquireAddress(struct RUA *pRua, RMuint32 address);

/**
make -   Decrement the reference counter for the address.
   If the reference counter is not null, you cannot free the address.

   @param pRua
   @param address
   @return
*/
RMstatus RUAReleaseAddress(struct RUA *pRua, RMuint32 address);


RM_EXTERN_C_BLOCKEND



#endif  // __RUA_H__
