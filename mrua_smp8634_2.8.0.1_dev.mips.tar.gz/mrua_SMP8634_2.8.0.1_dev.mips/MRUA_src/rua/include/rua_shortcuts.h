/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rua_shortcuts.h
  @brief  

  Scalar properties can be set/get in one line 
  Price is a painful macro but final code is more readable

  @author Emmanuel Michon
  @date   2003-07-16
*/

#ifndef __RUA_SHORTCUTS_H__
#define __RUA_SHORTCUTS_H__

#define RUASP(pRua,moduleID,propertyID,type,val,to)				\
do {										\
	type tmp=(val);								\
										\
	if (RUASetProperty(pRua,						\
			   moduleID,						\
			   propertyID,						\
			   &tmp,						\
			   sizeof(type),to)!=RM_OK) RMPanic(RM_FATAL);		\
} while (0)
     
#define RUAGP(pRua,moduleID,propertyID,type)					\
({										\
	type val;								\
										\
	if (RUAGetProperty(pRua,						\
			   moduleID,						\
			   propertyID,						\
			   &val,						\
			   sizeof(type))!=RM_OK) RMPanic(RM_FATAL);		\
										\
	val;									\
})
     
#endif // __RUA_SHORTCUTS_H__
