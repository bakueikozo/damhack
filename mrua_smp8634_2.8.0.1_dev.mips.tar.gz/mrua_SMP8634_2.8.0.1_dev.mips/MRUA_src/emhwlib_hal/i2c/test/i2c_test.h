/*
 *
 * Copyright (c) Sigma Designs, Inc. 2002. All rights reserved.
 *
 */

/**
	@file i2c_test.h
	@brief test application for i2c
	@author Aurelia Popa-Radu
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>

#define ALLOW_OS_CODE 1
#define EM86XX_CHIP_NUMBER 0

#include "../../../rmdef/rmdef.h"
#include "../../../llad/include/gbus.h"
#include "../../../emhwlib_hal/include/emhwlib_registers.h"
#include "../../../rmcore/include/rmcore.h"
#include "../../../emhwlib/include/emhwlib_chipspecific.h"

//#if (EM86XX_CHIP>=EM86XX_CHIPID_TANGOLIGHT)
//	#define USE_HWI2C
//#else
//	#undef USE_HWI2C
//#endif

#include "../include/i2c_hw.h"
#include "../include/i2c_hal.h"

