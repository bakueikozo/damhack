/*
 *
 * Copyright (c) Sigma Designs, Inc. 2002. All rights reserved.
 *
 */

/**
	@file i2c_test.c
	@brief test application for i2c using SII168 - DVI transmitter
	@author Aurelia Popa-Radu
*/

#include "i2c_test.h"	// both (os + i2c) prototypes
#include <unistd.h>

#define SII168_WRITE_ADDR	0x70
#define SII168_READ_ADDR	0x71 
#define SII168_DELAY		2	//microseconds

RMbool i2c_id = 0;

#define MYI2C(x) EmhwI2C##x

#define I2C_SCANPARAM(x)\
do {\
	argi++;\
	if (argi < argc) {\
		param = strtoul(argv[argi], &endptr, 0);\
		if (endptr[0] == '\0') x = param;\
		else argi = argc;\
	}\
} while(0)

static void show_sub_adr(const int no_sub_addr) {
	printf("using subaddress for read/write is: %s\n", no_sub_addr ? "off" : "on");
}

static void show_commands(void) {
	printf("waiting for command...\n");
	printf("  toggle subaddress <A>\n");
	printf("  read <R [hexaddr] bytes>\n");
	printf("  write <W [hexaddr] hexdata bytes>\n"); 
	printf("  download <L hexaddr filename>\n");
	printf("  upload <U hexaddr filename>\n"); 
	printf("  test <T hexaddr hexdata>\n"); 
	printf("  enable/disable DVI <E>/<D>\n");
	printf("  reset <X>\n");
	printf("  quit <Q>\n");
}

int main(int argc, char *argv[])
{
	struct llad *pLLAD;
	struct gbus *pGBus;
	RMascii device[10];
	RMint32 argi = 1;
	RMuint32 param;
	char *endptr;
	struct emhwi2c I2CHW;
	struct i2c I2C;
	RMstatus status;
	int no_sub_addr = 0;

	// defaults
	RMuint8 I2C_WrAddr = SII168_WRITE_ADDR;
	RMuint8 I2C_RdAddr = SII168_READ_ADDR;
	RMuint32 Delay = SII168_DELAY;
	RMuint8 PioClock = 0;
	RMuint8 PioData = 1;
	RMuint32 RegBase = REG_BASE_system_block;

#ifdef USE_HWI2C
	i2c_id = 1;
	puts("i2c_test (using hwi2c)");
	puts("======================");
#else
	puts("i2c_test (using softi2c)");
	puts("========================");
#endif
	
	while ((argi < argc) && (argv[argi][0] == '-')) {
		if (argv[argi][1] == 'A') {
			I2C_SCANPARAM(I2C_WrAddr);
			I2C_RdAddr = I2C_WrAddr + 1;
		} else if (argv[argi][1] == 'B') {
			I2C_SCANPARAM(I2C_RdAddr);
			I2C_WrAddr = I2C_RdAddr - 1;
		} else if (argv[argi][1] == 'C') {
			I2C_SCANPARAM(PioClock);
		} else if (argv[argi][1] == 'D') {
			I2C_SCANPARAM(PioData);
		} else if (argv[argi][1] == 'S') {
			printf("Using secondary hw_i2c for HDMI core\n");
			RegBase = 0x73840;
		} else if (argv[argi][1] == 'd') {
			I2C_SCANPARAM(Delay);
		}
		argi++;
	}
	
	if (argc < argi) {
		printf("usage: i2c_test [-A] <I2CAddr> [-C] <PIOClock> [-D] <PIOData> [-d] <delay>\n");
		printf("  -A <addr>    : device write address (default SII168: 0x%02x)\n", I2C_WrAddr);
		printf("  -B <addr>    : device read  address (default SII168: 0x%02x)\n", I2C_RdAddr);
		printf("  -C <PioClock>: PIO clock (default: %d)\n", PioClock);
		printf("  -D <PioData> : PIO data  (default: %d)\n", PioData);
		printf("  -S           : use secondari hardware I2C bus\n");
		printf("  -d <delay>   : delay     (default: %lu us)\n", Delay);
		exit(1);
	} else {
		printf("  device write address: 0x%02x\n", I2C_WrAddr);
		printf("  device read  address: 0x%02x\n", I2C_RdAddr);
		printf("  PIO clock           : %d\n", PioClock);
		printf("  PIO data            : %d\n", PioData);
		printf("  delay               : %lu us\n", Delay);
	}

	usleep(50000);
	
	snprintf(device, 10, "%d", EM86XX_CHIP_NUMBER);
	pLLAD = llad_open(device);
	if (pLLAD == NULL)
		return RM_ERROR;
	pGBus = gbus_open(pLLAD);
	
	if (RegBase == 0x73840) {
		// activate HDMI core
		gbus_write_uint32(pGBus, REG_BASE_display_block + VO_run, 1 << VO_hdmi_reset_bit);
	}
	
	I2C.pGBus=pGBus;
	I2C.RegBase=RegBase;
	I2C.PioClock=PioClock;
	I2C.PioData=PioData;
	I2C.DelayUs=Delay;
	I2C.WrAddr=I2C_WrAddr;
	I2C.RdAddr=I2C_RdAddr;
	
	I2CHW.pGBus = pGBus;
	I2CHW.RegBase = RegBase;
	I2CHW.APIVersion = 1;
	I2CHW.DelayUs = 0;
	I2CHW.Speed = 100;
	I2CHW.DevAddr = I2C_WrAddr;
	I2CHW.SysClk = 166000000; //pll_get_sysclk(pGBus);

	usleep(50000);

	show_sub_adr(no_sub_addr);
	show_commands();

	while (1) {
		char c = 0;
		scanf("%c", &c);
		if(c == 0 || c == '\n')
			continue;
		if(c == 'q' || c == 'Q')
			break;

		switch (c) {
		case 'a':
		case 'A':
			no_sub_addr = !no_sub_addr;
			show_sub_adr(no_sub_addr);
			break;
		case 'x':
		case 'X': {
			if(RMFAILED(EmhwI2CDisable(&I2CHW)))
				puts("error: reset failed");
			else
				puts("reset succeeded");
			break;
		}
		case 'r':
		case 'R': {
			int i;
			RMuint8 data[128];
			RMuint32 temp;
			RMuint8 addr = 0;
			RMuint8 bytes = 1;

			if(!no_sub_addr) {
				scanf("%lx",&temp);
				addr = (RMuint8)temp;
			}
			scanf("%lu",&temp);
			bytes = (RMuint8)temp;

			if(bytes > sizeof(data)) {
				printf("error: bytes > sizeof(data)\n");
				break;
			}

			if (i2c_id == 0) {
				status = no_sub_addr ? I2C_Read_NoSubAddr(&I2C, data, bytes) : I2C_Read(&I2C, addr, data, bytes);
			} else {
				status = EmhwI2CRead(&I2CHW, ! no_sub_addr, addr, data, bytes);
			}

			if(RMFAILED(status))
				printf("error: read at addr=0x%02x failed\n", addr);
			else {
				printf("read %d bytes at addr=0x%02x:", bytes, addr);
				for(i = 0; i < bytes; i++) {
					if((i % 8) == 0)
						puts("");
					printf(" 0x%02x", data[i]);
				}
				puts("");
			}
			break;
		}
		case 'w':
		case 'W': {
			RMuint8 fill, data[128];
			RMuint32 temp;
			RMuint8 addr = 0;
			RMuint8 bytes = 1;

			if(!no_sub_addr) {
				scanf("%lx",&temp);
				addr = (RMuint8)temp;
			}
			scanf("%lx",&temp);
			fill = (RMuint8)temp;
			scanf("%lu",&temp);
			bytes = (RMuint8)temp;

			if(bytes > sizeof(data)) {
				printf("error: bytes > sizeof(data)\n");
				break;
			}
			memset(data, fill, sizeof(data));

			if (i2c_id == 0) {
				status = no_sub_addr ? I2C_Write_NoSubAddr(&I2C, data, bytes) : I2C_Write(&I2C, addr, data, bytes);
			} else {
				status = EmhwI2CWrite(&I2CHW, ! no_sub_addr, addr, data, bytes);
			}

			if(RMFAILED(status))
				printf("error: write at addr=0x%02x failed\n", addr);
			else
				printf("write %d bytes at addr=0x%02x (data=0x%02x)\n", bytes, addr, fill);
			break;
		}
		case 'l':
		case 'L': {
			RMuint8 addr, data[256];
			RMuint32 temp, size;
			RMascii fname[256];
			FILE *fp;
			scanf("%lx", &temp);
			addr = (RMuint8)temp;
			scanf("%s", fname);

			if (i2c_id == 0) {
				status = I2C_Read(&I2C, addr, data, 256 - addr);
			} else {
				status = EmhwI2CRead(&I2CHW, TRUE, addr, data, 256 - addr);
			}
			if(RMFAILED(status)) {
				printf("error: read at addr=0x%02x failed\n", addr);
				break;
			}

			printf("read at addr=0x%02x\n", addr);
			fp = fopen(fname, "w");
			if (fp == NULL) {
				printf("can't open file %s!\n", fname);
				break;
			}
			size = fwrite(data, 1, 256 - addr, fp);
			printf("write %lu bytes to file %s\n", size, fname);
			fclose(fp);
			break;
		}
		case 'u':
		case 'U': {
			RMuint8 addr, data[256];
			RMuint32 temp, size;
			RMascii fname[256];
			FILE *fp;
			scanf("%lx",&temp);
			addr = (RMuint8)temp;
			scanf("%s", fname);
			fp = fopen(fname, "r");
			if (fp == NULL) {
				printf("can't open file %s!\n", fname);
				break;
			}
			size = fread(data, 1, 256 - addr, fp);
			fclose(fp);
			if (c == 'u') {
				if (i2c_id == 0) {
					status = I2C_Write(&I2C, addr, data, size);
				} else {
					status = EmhwI2CWrite(&I2CHW, TRUE, addr, data, size);
				}
				if(RMFAILED(status)) {
					printf("error: write at addr=0x%02x failed\n", addr);
					break;
				}
			} else {
				RMuint32 i;
				for (i = addr; i < RMmin(256, addr + size); i++) {
					printf("write 0x%02X to 0x%02lX\n", data[i - addr], i);

					if (i2c_id == 0) {
						status = I2C_Write(&I2C, i, &data[i - addr], 1);
					} else {
						status = EmhwI2CWrite(&I2CHW, TRUE, i, &data[i - addr], 1);
					}
					if(RMFAILED(status)) {
						printf("error: write at addr=0x%02x failed\n", addr);
						break;
					}
				}
			}
			printf("write %lu bytes at addr=0x%02x\n", size, addr);
			break;
		}
		case 't':
		case 'T': {
			RMuint8 addr, data;
			RMuint32 temp;
			RMuint32 wradr, rdadr, i;
			scanf("%lx",&temp);
			addr = (RMuint8)temp;
			scanf("%lx",&temp);
			wradr = I2C.WrAddr;
			rdadr = I2C.RdAddr;
			printf("probe at different Read/Write Addresses: write at addr=0x%02x data=0x%02x, read from addr=0x%02x\n", addr, data, addr);
			for (i = 0; i < 127; i++) {
				data = (RMuint8)temp;
				printf("\rTesting Rd/Wr address 0x%02lX", i);
				fflush(stdout);

				I2C.WrAddr = i << 1;
				if (i2c_id == 0) {
					status = I2C_Write(&I2C, addr, &data, 1);
				} else {
					status = EmhwI2CWrite(&I2CHW, TRUE, addr, &data, 1);
				}
				if(RMFAILED(status)) {
					printf("\nerror: write at addr=0x%02x failed\n", addr);
					break;
				}
				printf("\nwrite at WrAddr=0x%02X addr=0x%02x data=0x%02x OK\n",
					 I2C.WrAddr, addr, data);

				I2C.RdAddr = (i << 1) | 1;
				if (i2c_id == 0) {
					status = I2C_Read(&I2C, addr, &data, 1);
				} else {
					status = EmhwI2CRead(&I2CHW, TRUE, addr, &data, 1);
				}
				if(RMFAILED(status)) {
					printf("\nerror: read at addr=0x%02x failed\n",	addr);
					break;
				}
				printf("\nread at RdAddr=0x%02X addr=0x%02x data=0x%02x OK\n",
					 I2C.RdAddr, addr, data);
			}
			printf("\n");
			I2C.WrAddr = wradr;
			I2C.RdAddr = rdadr;
			break;
		}
		case 'e':
		case 'E': {
			// set state on - power on, 24 bits, Input H,VSync enable
			RMuint8 Byte = 0x37;
			if (i2c_id == 0) I2C_Write(&I2C, 0x08, &Byte, 1);
			else  EmhwI2CWrite(&I2CHW, TRUE, 0x08, &Byte, 1);
			Byte = 0x00;
			if (i2c_id == 0) I2C_Write(&I2C, 0x09, &Byte, 1);
			else  EmhwI2CWrite(&I2CHW, TRUE, 0x09, &Byte, 1);
			Byte = 0xf0;
			if (i2c_id == 0) I2C_Write(&I2C, 0x0a, &Byte, 1);
			else  EmhwI2CWrite(&I2CHW, TRUE, 0x0a, &Byte, 1);
			Byte = 0x89;
			if (i2c_id == 0) I2C_Write(&I2C, 0x0c, &Byte, 1);
			else  EmhwI2CWrite(&I2CHW, TRUE, 0x0c, &Byte, 1);
			Byte = 0x00;
			if (i2c_id == 0) I2C_Write(&I2C, 0x0d, &Byte, 1);
			else  EmhwI2CWrite(&I2CHW, TRUE, 0x0d, &Byte, 1);
			Byte = 0x00;
			if (i2c_id == 0) I2C_Write(&I2C, 0x0e, &Byte, 1);
			else  EmhwI2CWrite(&I2CHW, TRUE, 0x0e, &Byte, 1);
			Byte = 0x00;
			if (i2c_id == 0) I2C_Write(&I2C, 0x0f, &Byte, 1);
			else  EmhwI2CWrite(&I2CHW, TRUE, 0x0f, &Byte, 1);
			printf("enable DVI\n");
			break;
		}
		case 'd':
		case 'D': {
			// set state off
			RMuint8 Byte = 0x06;
			if (i2c_id == 0) I2C_Write(&I2C, 0x08, &Byte, 1);// power off
			else  EmhwI2CWrite(&I2CHW, TRUE, 0x08, &Byte, 1);
			Byte = 0x0A;
			if (i2c_id == 0) I2C_Write(&I2C, 0x0c, &Byte, 1);// PLL filter disable
			else  EmhwI2CWrite(&I2CHW, TRUE, 0x0c, &Byte, 1);
			Byte = 0x01;
			if (i2c_id == 0) I2C_Write(&I2C, 0x33, &Byte, 1);// DE enable
			else  EmhwI2CWrite(&I2CHW, TRUE, 0x33, &Byte, 1);
			printf("disable DVI\n");
			break;
		}
		default:
			printf("unvalid command - ");
			show_commands();
		}
	}

	printf("exit\n");
 
	gbus_close(pGBus);
	llad_close(pLLAD);
	return 0;
}
