/*****************************************
 Copyright � 2001-2004  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   i2c_hw.h

  @brief implemetation for I2C - using hardware I2C block
  @author YH Lin
  @date   2004-08-17
*/

#ifndef __I2C_HW_H__
#define __I2C_HW_H__

#ifdef RMFEATURE_HAS_HWI2C

struct emhwi2c {
	RMuint32 APIVersion;  // Set to 1 (used for future extensions)
	struct gbus *pGBus;   // register access pointer
	RMuint32 RegBase;  // base address for hardware registers
	RMuint32 DelayUs;  // I2C delay, in uSec
	RMuint32 SysClk;   // frequency of the I2C block (system clock), in Hz
	RMuint32 Speed;    // frequency of the I2C bit transfer, in kHz (e.g. 100 or 400)
	RMuint8 DevAddr;   // I2C device address (write uses DevAddr, read uses DevAddr + 1)
};

RMstatus EmhwI2CWrite(struct emhwi2c* pI2C, RMbool UseSubAddr, RMuint8 SubAddr, RMuint8* pData, RMuint32 n);
RMstatus EmhwI2CRead(struct emhwi2c* pI2C, RMbool UseSubAddr, RMuint8 SubAddr, RMuint8* pData, RMuint32 n);
RMstatus EmhwI2CSelectSegment(struct emhwi2c* pI2C, RMuint8 SegmentAddr, RMuint8 Segment);
RMstatus EmhwI2CDisable(struct emhwi2c* pI2C);  // disconnect from the I2C bus







// obsolete, kept for backwards compatibility
struct hwi2c {
	struct gbus *pGBus;
	RMuint32 RegBase;	// base address for hardware registers
	RMuint32 DelayUs;
	RMuint8 WrAddr;
	RMuint8 RdAddr;
};

RMstatus HWI2C_Write( struct hwi2c* pI2C, RMuint8 addr, RMuint8* pData, RMuint32 n );
RMstatus HWI2C_Read( struct hwi2c* pI2C, RMuint8 addr, RMuint8* pData, RMuint32 n );
RMstatus HWI2C_Write_NoSubAddr( struct hwi2c* pI2C, RMuint8* pData, RMuint32 n );
RMstatus HWI2C_Read_NoSubAddr( struct hwi2c* pI2C, RMuint8* pData, RMuint32 n );
RMstatus HWI2C_Select_Segment( struct hwi2c* pI2C, RMuint8 SegmentAddr, RMuint8 Segment );
RMstatus HWI2C_Disable( struct hwi2c* pI2C );

#endif

#endif // __I2C_HW_H__
