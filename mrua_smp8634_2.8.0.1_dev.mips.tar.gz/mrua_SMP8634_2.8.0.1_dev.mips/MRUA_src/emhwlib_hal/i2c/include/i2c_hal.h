/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   i2c_hal.h

  @brief implemetation for I2C - using PIOs
  @author Aurelia Popa-Radu
  @date   2003-07-01
*/

#ifndef __I2C_HAL_H__
#define __I2C_HAL_H__

struct i2c {
	struct gbus *pGBus;
	RMuint32 RegBase;	// base address for hardware registers
	RMuint8 PioClock;
	RMuint8 PioData;
	RMuint32 DelayUs;
	RMuint8 WrAddr;
	RMuint8 RdAddr;
};

RMstatus I2C_Write( struct i2c* pI2C, RMuint8 addr, RMuint8* pData, RMuint32 n );
RMstatus I2C_Read( struct i2c* pI2C, RMuint8 addr, RMuint8* pData, RMuint32 n );
RMstatus I2C_Write_NoSubAddr( struct i2c* pI2C, RMuint8* pData, RMuint32 n );
RMstatus I2C_Read_NoSubAddr( struct i2c* pI2C, RMuint8* pData, RMuint32 n );
RMstatus I2C_Select_Segment( struct i2c* pI2C, RMuint8 SegementAddr, RMuint8 Segment );

#endif // __I2C_HAL_H__
