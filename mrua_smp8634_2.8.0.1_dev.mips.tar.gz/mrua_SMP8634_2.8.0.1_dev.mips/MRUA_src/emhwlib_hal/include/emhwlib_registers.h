/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   emhwlib_registers.h
  @brief  

  long description

  @author Emmanuel Michon
  @date   2004-01-23
*/

#ifndef __EMHWLIB_REGISTERS_H__
#define __EMHWLIB_REGISTERS_H__

#if (EM86XX_CHIP==EM86XX_CHIPID_MAMBOLIGHT)
#include "mambolight/emhwlib_registers_mambolight.h"
#elif (EM86XX_CHIP==EM86XX_CHIPID_MAMBO)
#include "mambo/emhwlib_registers_mambo.h"
#elif (EM86XX_CHIP==EM86XX_CHIPID_TANGOLIGHT)
#include "tangolight/emhwlib_registers_tangolight.h"
#elif (EM86XX_CHIP==EM86XX_CHIPID_TANGO15)
#include "tango15/emhwlib_registers_tango15.h"
#elif (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
#include "tango2/emhwlib_registers_tango2.h"
#elif (EM86XX_CHIP==EM86XX_CHIPID_TANGO3)
#include "tango3/emhwlib_registers_tango3.h"
#else
#error EM86XX_CHIP is not set in RMCFLAGS: refer to rmdef/rmem86xxid.h.
#endif

#endif // __EMHWLIB_REGISTERS_H__
