/*
 *
 * Copyright (c) Sigma Designs, Inc. 2002. All rights reserved.
 *
 */

/**
	@file dcc_demo.c
	@brief sample application to access the Mambo chip and test DMA transfers
	
	@author Julien Soulier
   	@ingroup dccsamplecode
*/

/*
  ******************************************************************************************
  This file is part of libsamples library, therefore *NO* static variables should be defined
  ******************************************************************************************
*/



#define USE_TWO_INSTANCES 1

#include <ctype.h>
#include "sample_os.h"


#define ALLOW_OS_CODE 1
#include "../rua/include/rua.h"
#include "../rua/include/rua_property.h"
#include "../rmcore/include/rmstatustostring.h"
#include "../emhwlib_hal/pll/include/pll_hal.h"
#include "../rmlibcw/include/rmtime.h"

#include "../dcc/include/dcc.h"
#include "common.h"

#include "../rmec3transcoder/include/rmec3transcoderapi.h"

#define NUM_DBC 4  // how many DBCs to allocate

#define GETBUFFER_TIMEOUT_US (TIMEOUT_10MS * 10)
#define SENDDATA_TIMEOUT_US  (TIMEOUT_10MS * 10)

#define DMA_BUFFER_SIZE_LOG2 15
#define DMA_BUFFER_COUNT     32


#define AUDIO_FIFO_SIZE ((1<<DMA_BUFFER_SIZE_LOG2)*DMA_BUFFER_COUNT) // 1Mb, matches dma_buffer_count * 2^dma_buffer_size_log2 which is a requirement in standalone
#define XFER_FIFO_COUNT (32)

#define KEYFLAGS (SET_KEY_PLAYBACK | SET_KEY_AUDIO)

#define DUMP_DATA 0

#define RM_DEVICES_STC 0x1
#define RM_DEVICES_AUDIO 0x4

#ifdef WITH_BSAC
#include "../libbsac/porting_typedef.h"
#include "../libbsac/porting.h"
#define BSAC_NCH                      2
#define BSAC_DSP_LENGTH               sizeof(BSAC_DSP_Info)
#endif // WITH_BSAC


struct audio_context {
	struct RUABufferPool *pDMA;
	RMbool FirstSystemTimeStamp;
	RMuint32 FirstPTS;
	struct dcc_context *dcc_info;

	struct RM_PSM_Context *PSMcontext;
	struct RM_PSM_Actions actions;

	RMuint32 NTimes;

	struct playback_cmdline *play_opt;
	struct audio_cmdline *audio_opt;
	RMuint32 audioInstances;

	RMfile f_bitstream;
	RMint64 fileSize;
	RMbool audio_decoder_initialized;
	RMbool trickMode;
	RMuint32 audio_vop_tir;
	RMuint64 Duration;
	RMuint64 lastSTC;

	RMuint32 prebufferedBytes;
	RMuint32 PCMblockSize;

	RMuint32 skipFirstNBytes;
	RMuint32 sendNBytes;

	RMbool transcodeEC3toAC3;
	RMEC3TranscoderHandle ec3TranscoderHandle;
	RMuint8 *readBuffer;
	RMbool getNewBufferForEC3;

#ifdef WITH_BSAC
	RMuint8 bsac_bts_buf[4096];
	RMuint32 bsac_bitrate, bsac_profile;
#endif


#if DUMP_DATA
	FILE *saveFile;
#endif

	void **dmabuffer_array;
	RMuint32 dmabuffer_index;

	RMuint32 capture_cached_addr;
	RMuint32 capture_uncached_addr;
	FILE *fp_capture;

};

#define PROCESS_KEY(release, getkey)					\
do	{								\
		RMDBGLOG((DISABLE, "process_key\n"));			\
		if (getkey) {						\
			enum RM_PSM_State FSMstate = RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)); \
                        if ((FSMstate == RM_PSM_Stopped) || (FSMstate == RM_PSM_Paused)) { \
			        switch (context.play_opt->disk_ctrl_state) { \
			        case DISK_CONTROL_STATE_DISABLE:	\
			        case DISK_CONTROL_STATE_SLEEPING:	\
				        break;				\
			        case DISK_CONTROL_STATE_RUNNING:	\
					if(context.play_opt->disk_ctrl_callback && context.play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_SLEEP) == RM_OK) \
						context.play_opt->disk_ctrl_state = DISK_CONTROL_STATE_SLEEPING; \
					break;				\
			        }					\
		        }						\
			err = process_command(context.PSMcontext, &(context.dcc_info), &(context.actions)); \
			if (RMFAILED(err)) {				\
				fprintf(stderr, "Error while processing key %d\n", err); \
				goto cleanup;				\
			}						\
		}							\
		if (context.actions.toDoActions & RM_PSM_FIRST_PTS) {	\
			RMDBGLOG((ENABLE, "firstPTS\n"));		\
			context.FirstSystemTimeStamp = TRUE;		\
		}							\
		if (context.actions.performedActions & RM_PSM_AUDIO_STOPPED) { \
			RMDBGLOG((ENABLE, "audio stopped\n"));		\
			context.audio_decoder_initialized = FALSE;	\
			if ((release) && (buf)) {			\
				RUAReleaseBuffer(context.pDMA, buf);	\
				RMDBGLOG((ENABLE, "release a buffer\n")); \
				buf = NULL;				\
				/* needed for no dram copy version on standalone */ \
				err = RUAResetPool(context.pDMA);	\
				if (RMFAILED(err)) {			\
					RMDBGLOG((ENABLE, "Error cannot reset dmapool\n")); \
					goto cleanup;			\
				}					\
			}						\
		}							\
		if (context.actions.performedActions & RM_PSM_STC_STOPPED) { \
			RMDBGLOG((ENABLE, "stc stopped\n"));		\
			context.actions.performedActions &= ~RM_PSM_STC_STOPPED; \
		}							\
		if ((RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Playing) && \
		    (context.trickMode))	{			\
			RMDBGLOG((ENABLE, "got play after trickmode\n")); \
			if ((release) && (buf)) {			\
				RUAReleaseBuffer(context.pDMA, buf);	\
				RMDBGLOG((ENABLE, "release a buffer\n")); \
				buf = NULL;				\
				/* needed for no dram copy version on standalone */ \
				err = RUAResetPool(context.pDMA);	\
				if (RMFAILED(err)) {			\
					RMDBGLOG((ENABLE, "Error cannot reset dmapool\n")); \
					goto cleanup;			\
				}					\
			}						\
			resumeFromTrick(&context);			\
			context.trickMode = FALSE;			\
		}							\
		if (((RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Slow) || \
		     (RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Fast) || \
		     (RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_NextPic) || \
		     (RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Rewind)) && \
		    (context.actions.cmdProcessed) && (!context.trickMode)) { \
			RMDBGLOG((ENABLE, ">> trick mode\n"));		\
			if ((release) && (buf)) {			\
				RUAReleaseBuffer(context.pDMA, buf);	\
				RMDBGLOG((ENABLE, "release a buffer\n")); \
				buf = NULL;				\
				/* needed for no dram copy version on standalone */ \
				err = RUAResetPool(context.pDMA);	\
				if (RMFAILED(err)) {			\
					RMDBGLOG((ENABLE, "Error cannot reset dmapool\n")); \
					goto cleanup;			\
				}					\
			}						\
			context.trickMode = TRUE;			\
			context.FirstSystemTimeStamp = TRUE;		\
		}							\
		if ((RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Stopped) && (context.actions.cmdProcessed)) { \
			RMDBGLOG((ENABLE,"Got stop command\n"));	\
			if ((release) && (buf)) {			\
				RUAReleaseBuffer(context.pDMA, buf);	\
				RMDBGLOG((ENABLE, "release a buffer\n")); \
				buf = NULL;				\
				/* needed for no dram copy version on standalone */ \
				err = RUAResetPool(context.pDMA);	\
				if (RMFAILED(err)) {			\
					RMDBGLOG((ENABLE, "Error cannot reset dmapool\n")); \
					goto cleanup;			\
				}					\
			}						\
			context.trickMode = FALSE;			\
			goto mainloop_no_seek;				\
		}							\
		if ((context.actions.cmd == RM_QUIT) && (!context.actions.cmdProcessed)) { \
			RMDBGLOG((ENABLE, "Got quit command\n"));	\
			if ((release) && (buf)) {			\
				RUAReleaseBuffer(context.pDMA, buf);	\
				RMDBGLOG((ENABLE, "release a buffer\n")); \
				buf = NULL;				\
				/* needed for no dram copy version on standalone */ \
				err = RUAResetPool(context.pDMA);	\
				if (RMFAILED(err)) {			\
					RMDBGLOG((ENABLE, "Error cannot reset dmapool\n")); \
					goto cleanup;			\
				}					\
			}						\
			goto cleanup;					\
		}							\
		if ((context.actions.cmd == RM_STOP_SEEK_ZERO) && (!context.actions.cmdProcessed)) { \
			RMDBGLOG((ENABLE, "Got stop seek zero command\n")); \
			if ((release) && (buf)) {			\
				RUAReleaseBuffer(context.pDMA, buf);	\
				RMDBGLOG((ENABLE, "release a buffer\n")); \
				buf = NULL;				\
				/* needed for no dram copy version on standalone */ \
				err = RUAResetPool(context.pDMA);	\
				if (RMFAILED(err)) {			\
					RMDBGLOG((ENABLE, "Error cannot reset dmapool\n")); \
					goto cleanup;			\
				}					\
			}						\
			Stop(&context, RM_DEVICES_AUDIO | RM_DEVICES_STC); \
			RM_PSM_SetState(context.PSMcontext, &(context.dcc_info), RM_PSM_Stopped); \
			context.trickMode = FALSE;			\
			goto mainloop;					\
		}							\
		if ((context.actions.cmd == RM_SEEK) && (!context.actions.cmdProcessed)){ \
			RMDBGLOG((ENABLE, "Got seek command\n"));	\
			if ((release) && (buf)) {			\
				RUAReleaseBuffer(context.pDMA, buf);	\
				RMDBGLOG((ENABLE, "release a buffer\n")); \
				buf = NULL;				\
				/* needed for no dram copy version on standalone */ \
				err = RUAResetPool(context.pDMA);	\
				if (RMFAILED(err)) {			\
					RMDBGLOG((ENABLE, "Error cannot reset dmapool\n")); \
					goto cleanup;			\
				}					\
			}						\
									\
			if (dcc_info.seek_supported)			\
				seek(&context, context.dcc_info->seek_time); \
			else						\
				fprintf(stderr, "Unsuported command\n"); \
			context.trickMode = FALSE;			\
			goto mainloop_seek;				\
		}							\
		if(context.actions.cmd == RM_DUALMODE_CHANGE) {		\
			fprintf(stderr, "Changing DualMode to :");	\
			switch(context.audio_opt[0].OutputDualMode) {	\
			case DualMode_LeftMono:				\
				fprintf(stderr, " RightMono\n");	\
				context.audio_opt[0].OutputDualMode = DualMode_RightMono; \
				break;					\
			case DualMode_RightMono:			\
				fprintf(stderr, " MixMono\n");		\
				context.audio_opt[0].OutputDualMode = DualMode_MixMono; \
				break;					\
			case DualMode_MixMono:				\
				fprintf(stderr, " Stereo\n");		\
				context.audio_opt[0].OutputDualMode = DualMode_Stereo; \
				break;					\
			case DualMode_Stereo:				\
				fprintf(stderr, " LeftMono\n");		\
				context.audio_opt[0].OutputDualMode = DualMode_LeftMono; \
				break;					\
			default:					\
				fprintf(stderr, " Unknown dual mode\n"); \
				break;					\
			}						\
			for (i = 0; i < context.audioInstances; i++) {	\
				context.audio_opt[i].OutputDualMode = context.audio_opt[0].OutputDualMode; \
									\
				err = apply_audio_decoder_options_onthefly(&dcc_info, &(context.audio_opt[i])); \
				if (RMFAILED(err)) {			\
					fprintf(stderr, "Error applying audio decoder options on the fly %d\n", err); \
				}					\
			}						\
		}							\
} while(0)



#ifndef WITH_MONO
static void show_usage(char *progname)
{
	show_playback_options();
	show_audio_options();
	fprintf(stderr, "--------------------------------\n");
	fprintf(stderr, "Minimum cmd line: %s <file name>\n", progname);
	fprintf(stderr, "--------------------------------\n");

	exit(1);
}

static void parse_cmdline(struct audio_context *pSendContext, int argc, char *argv[], RMuint32 *currentInstance)
{
	int i;
	RMstatus err;

	if (argc < 2) 
		show_usage(argv[0]);
	
	i = 1;

	while ((argc > i)) {
		if (argv[i][0] != '-') {
			if (pSendContext->play_opt->filename == NULL) {
				pSendContext->play_opt->filename = argv[i];
				i++;
			}
			else
				show_usage(argv[0]);
		}
		else {
			err = parse_playback_cmdline(argc, argv, &i, pSendContext->play_opt);
			if (err == RM_ERROR) 
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			RMDBGLOG((ENABLE, "option[%lu] %s\n", i, argv[i]));
			err = parse_audio_cmdline2(argc, argv, &i, pSendContext->audio_opt, MAX_AUDIO_DECODER_INSTANCES, currentInstance);
			if (RMFAILED(err))
				show_usage(argv[0]);
		}
	}
	
	if ((pSendContext->play_opt->filename == NULL) && (! pSendContext->audio_opt[0].AudioIn))
		show_usage(argv[0]);
}
#endif


static RMstatus WaitForEOS(struct audio_context *pSendContext, struct RM_PSM_Actions *pActions)
{
	RMuint32 eos_bit_field = 0;
	enum RM_PSM_State PlaybackStatus = RM_PSM_GetState(pSendContext->PSMcontext, &(pSendContext->dcc_info));

	if (pSendContext == NULL || pActions == NULL)
		return RM_ERROR;
	
	if ((PlaybackStatus == RM_PSM_Playing) || (PlaybackStatus == RM_PSM_Prebuffering))
		eos_bit_field |= EOS_BIT_FIELD_AUDIO;
		
	return WaitForEOSWithCommand(pSendContext->PSMcontext, &(pSendContext->dcc_info), pActions, eos_bit_field);
}



static RMstatus StartAudioCapture(struct dcc_context *dcc_info, 
				  RMuint32 audio_capture, 
				  struct audio_cmdline *audio_opt, 
				  struct audio_context* p_context)
{
	struct AudioCapture_Open_type capture_open;
	enum AudioCapture_Source_type capture_source;
	enum AudioCapture_SpdifDataType_type capture_type;
	enum AudioCapture_Capture_type cmd = AudioCapture_Capture_On;
	struct AudioCapture_DRAMSize_in_type dram_in;
	struct AudioCapture_DRAMSize_out_type dram_out;
	RMstatus err;
	RMuint32 capture_mode;

	// check if this is for pass through or file capture
	if( (p_context->audio_opt[0].AudioIn) && (p_context->play_opt->filename ) ){
		capture_mode = 0; // file capture
		p_context->fp_capture = fopen(p_context->play_opt->filename, "w+b");
	}else{
		capture_mode = 1; // pass through
	}

#if (EM86XX_CHIP == EM86XX_CHIPID_TANGO2)
{
	struct PLL_Frequency_type f;
	RMuint32 SampleClock;

	//printf("start set RCLK2...\n");
	SampleClock = 48000;
	f.PLL = PLLGen_cd_6;
	f.PLLOutput = PLLOut_1; // or _1 or _2
	f.MaxM = 31;
	f.Clock = ClockSignal_RClk2;
	f.Frequency = SampleClock * 256;
	RUASetProperty(dcc_info->pRUA, PLL, RMPLLPropertyID_Frequency, &f, sizeof(f), 0);
	//printf("finish set RCLK2...\n");
}
#endif

	// Query Memory needed for AudioCapture Module
	dram_in.SerialInFIFOSize = AUDIO_FIFO_SIZE; 
	dram_in.XferFIFOCount = XFER_FIFO_COUNT; 
	err = RUAExchangeProperty(dcc_info->pRUA, audio_capture, RMAudioCapturePropertyID_DRAMSize, &dram_in, sizeof(dram_in), &dram_out, sizeof(dram_out));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "No memory available for Audio RISC Processor! %s\n", RMstatusToString(err)));
		return err;
	} 

	// construct open profile
	memset(&capture_open, 0, sizeof(struct AudioCapture_Open_type));
	capture_open.CaptureMode = capture_mode;
	capture_open.Delay = ((audio_opt->CaptureDelay) ? audio_opt->CaptureDelay : 1824) / 2; // Delay is 45000 Hz based start PTS
	if (audio_opt->CaptureSource == 0) {
		// Capture from I2S, 32 bit frames
		//capture_open.SI_CONF = 0x109;  // 16 bit I2S frames
		capture_open.SI_CONF = 0x107 |  // SerialIn Configuration, 32 bit frames
			(audio_opt->AudioInAlign << 3) | 
			(audio_opt->AudioInLSBfirst ? 0x200 : 0x000);
		capture_source = AudioCapture_Source_I2S;
	} else {
		// Capture from SPDIF, always 16 bit frames
		if (audio_opt->CaptureSource == 1) {
#if (EM86XX_CHIP >= EM86XX_CHIPID_TANGO15)  // in 8622/24 Tango 1.5 and 8634 Tango 2 spdif is dedicated line, use it with source=1
			capture_open.SI_CONF = 0x900;  // capture from SI_SPDIF
		} else if (audio_opt->CaptureSource == 2) {
#endif
			capture_open.SI_CONF = 0x100;  // capture from SI_DATA
		} else {
			fprintf(stderr, "Error, wrong audio source: %lu\n", audio_opt->CaptureSource);
			return RM_ERROR;
		}
		capture_source = AudioCapture_Source_SPDIF;
	}
	
	capture_open.SI_CONF |= 0x80000000;  // extended info in unused bits of SI_CONF
	if ((audio_opt->CaptureSource == 0) && (audio_opt->Codec == AudioDecoder_Codec_PCM)) {
		RMuint32 BitsPerSample;
		switch (audio_opt->SubCodec) {
			default: BitsPerSample = audio_opt->PcmCdaParams.BitsPerSample; break;
			case 1: BitsPerSample = audio_opt->LpcmVobParams.BitsPerSample; break;
			case 2: BitsPerSample = audio_opt->LpcmAobParams.BitsPerSampleGroup1; break;
			case 3: BitsPerSample = audio_opt->PcmCdaParams.BitsPerSample; break;
		}
		if (BitsPerSample >= 24) {
			capture_open.SI_CONF |= 0x40000000;  // don't truncate 24 bit PCM samples to 16 bits
		}
	}
	
	// allocate memory only when it is file mode
	if(!capture_mode){
		// memory allocation for capture module
		capture_open.SerialInFIFOSize = dram_in.SerialInFIFOSize;
		capture_open.XferFIFOCount = dram_in.XferFIFOCount;
		
		// allocate cached memory
		capture_open.CachedSize = dram_out.CachedSize;
		if (capture_open.CachedSize > 0){
			capture_open.CachedAddress = RUAMalloc(dcc_info->pRUA, 0, RUA_DRAM_CACHED, capture_open.CachedSize);
			printf("audio capture cached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
			       capture_open.CachedAddress,
			       capture_open.CachedSize,
			       capture_open.CachedAddress + capture_open.CachedSize);
			p_context->capture_cached_addr = (RMuint32)capture_open.CachedAddress;
		}
		else { capture_open.CachedAddress = 0; }
		
		// allocate uncached memory
		capture_open.UncachedSize = dram_out.UncachedSize;
		if (capture_open.UncachedSize > 0){
			capture_open.UncachedAddress = RUAMalloc(dcc_info->pRUA, 0, RUA_DRAM_UNCACHED, capture_open.UncachedSize);
			printf("audio capture uncached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
			       capture_open.UncachedAddress,
			       capture_open.UncachedSize,
			       capture_open.UncachedAddress + capture_open.UncachedSize);
			p_context->capture_uncached_addr = capture_open.UncachedAddress;
		}
		else { capture_open.UncachedAddress = 0; }
	}

	err = RUASetProperty(dcc_info->pRUA, audio_capture, 
		RMAudioCapturePropertyID_Open, 
		&capture_open, sizeof(capture_open), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error opening audio capture module!\n");
		return err;
	}
	
	err = RUASetProperty(dcc_info->pRUA, audio_capture, 
		RMAudioCapturePropertyID_Source, 
		&capture_source, sizeof(capture_source), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error setting audio capture source!.\n");
		return err;
	}
	
	capture_type = audio_opt->CaptureType;
	err = RUASetProperty(dcc_info->pRUA, audio_capture, 
		RMAudioCapturePropertyID_SpdifDataType, 
		&capture_type, sizeof(capture_type), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error setting audio capture type!.\n");
		return err;
	}
	
	err = RUASetProperty(dcc_info->pRUA, audio_capture,
		RMAudioCapturePropertyID_Capture, 
		&cmd, sizeof(cmd), 0);
	if (RMFAILED(err)) 
		fprintf(stderr, "Error sending capture ON command.\n");

	// open buffer pool only when file capture mode
	if(!capture_mode){
		err = RUAOpenPool(dcc_info->pRUA, 
				  audio_capture, 
				  p_context->play_opt->dmapool_count, 
				  p_context->play_opt->dmapool_log2size, 
				  RUA_POOL_DIRECTION_RECEIVE, 
				  &(p_context->pDMA));
		if (RMFAILED(err)){
			RMDBGLOG((ENABLE, "Error while creating DMA Pool for receiving! %s\n", RMstatusToString(err)));
		}
	}
	
	return err;
}

static RMstatus StopAudioCapture(struct dcc_context *dcc_info, RMuint32 audio_capture, struct audio_context* p_context)
{
	enum AudioCapture_Capture_type cmd = AudioCapture_Capture_Off;
	RMuint32 temp = 0;
	RMstatus err;

	err = RUASetProperty(dcc_info->pRUA, audio_capture,
			     RMAudioCapturePropertyID_Capture, &cmd, sizeof(cmd), 0);
	if (RMFAILED(err)) 
		fprintf(stderr, "Error sending capture OFF command.\n");

	err = RUASetProperty(dcc_info->pRUA, audio_capture, RMAudioCapturePropertyID_Close, 
			     &temp, sizeof(temp), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error closing capture module!\n");
		return err;
	}

	if(p_context->capture_cached_addr){
		RUAFree(dcc_info->pRUA, p_context->capture_cached_addr);
		p_context->capture_cached_addr = 0;
	}
	
	if(p_context->capture_uncached_addr){
		RUAFree(dcc_info->pRUA, p_context->capture_uncached_addr);
		p_context->capture_uncached_addr = 0;
	}

	if(p_context->fp_capture){
		fclose(p_context->fp_capture);
		p_context->fp_capture = NULL;
	}
	return err;
}


static RMstatus Stop(struct audio_context *pSendContext, RMuint32 devices)
{
	RMstatus err = RM_OK;

	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "STOP: stc\n"));
		DCCSTCStop(pSendContext->dcc_info->pStcSource);
	}

	if (devices & RM_DEVICES_AUDIO) {
		if (pSendContext->dcc_info->pMultipleAudioSource) {

			if (pSendContext->play_opt->disk_ctrl_state != DISK_CONTROL_STATE_DISABLE) {
				while (pSendContext->dmabuffer_index > 0) {
					pSendContext->dmabuffer_index--;
					if (pSendContext->dmabuffer_array[pSendContext->dmabuffer_index]) {
						RMDBGLOG((ENABLE, "releasing buffer index %lu buffer %p\n", pSendContext->dmabuffer_index, pSendContext->dmabuffer_array[pSendContext->dmabuffer_index]));
						RUAReleaseBuffer(pSendContext->pDMA, pSendContext->dmabuffer_array[pSendContext->dmabuffer_index]);
					}
				}
			}


			RMDBGLOG((ENABLE, "STOP: multiple audio decoders\n"));
			err = DCCStopMultipleAudioSource(pSendContext->dcc_info->pMultipleAudioSource);
			if (RMFAILED(err)){
				RMDBGLOG((ENABLE, "Error stopping audio source %d\n", err));
				return err;
			}

			pSendContext->audio_decoder_initialized = FALSE;
			pSendContext->FirstSystemTimeStamp = TRUE;
			pSendContext->FirstPTS = 0;

			/* because DMAPool and BitstreamFIFO are the same in standalone when using elementary streams
			   we need to reset the pool */
			err = RUAResetPool(pSendContext->pDMA);	// needed for no dram copy version on standalone
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error cannot reset dmapool\n"));
				return err;
			}

		}
	}

	return err;

}

static RMstatus Play(struct audio_context * pSendContext, RMuint32 devices)
{

	RMstatus err = RM_OK;

	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "PLAY: stc\n"));
		DCCSTCPlay(pSendContext->dcc_info->pStcSource);
	}

	if (devices & RM_DEVICES_AUDIO) {
		if (pSendContext->dcc_info->pMultipleAudioSource) {
			if (!pSendContext->audio_decoder_initialized) {
		
				pSendContext->audio_decoder_initialized = TRUE;
			}

			RMDBGLOG((ENABLE, "PLAY: multiple audio decoders\n"));
			err = DCCPlayMultipleAudioSource(pSendContext->dcc_info->pMultipleAudioSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot play audio decoder %d\n", err));
				return err;
			}
		}
	}

	return err;
}


// used for prebuffering
static RMstatus Pause(struct audio_context * pSendContext, RMuint32 devices)
{

	RMstatus err = RM_OK;
	
	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "PAUSE: stc\n"));
		DCCSTCStop(pSendContext->dcc_info->pStcSource);
	}

	if (devices & RM_DEVICES_AUDIO) {
		if (pSendContext->dcc_info->pMultipleAudioSource) {
			RMDBGLOG((ENABLE, "PAUSE: multiple audio decoders\n"));
			err = DCCPauseMultipleAudioSource(pSendContext->dcc_info->pMultipleAudioSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot play audio decoder %d\n", err));
				return err;
			}
		}
	}


	return err;

}



static RMstatus seek(struct audio_context *pSendContext, RMuint32 time_sec)
{
	RMuint64 bytesSec = pSendContext->fileSize / pSendContext->Duration;
	RMuint32 timeSec = 0;
	RMuint64 seekPos;
	RMuint32 audioPTS;
	RMstatus err;
	struct DCCAudioSourceHandle audioHandle;

	timeSec = time_sec;
		
	seekPos = timeSec * bytesSec;

	RMDBGLOG((ENABLE, "seek to %lu s\n", timeSec));

	// we assume multiple decoders are in sync
	DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(pSendContext->dcc_info->pMultipleAudioSource, 0, &audioHandle);

	err = RUAGetProperty(pSendContext->dcc_info->pRUA, audioHandle.moduleID, RMAudioDecoderPropertyID_CurrentPTS, &audioPTS, sizeof(audioPTS));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "error getting current pts property for audio, error %lu\n", (RMuint32)err));
		return RM_ERROR;
	}
	RMDBGLOG((ENABLE, "current audio pts %lu(0x%08lx)\n", audioPTS, audioPTS));

	Stop(pSendContext, RM_DEVICES_AUDIO);

	RMDBGLOG((ENABLE, ">> %llu bytes/sec, seekto %lu sec => pos %llu\n", bytesSec, timeSec, seekPos));

	// pcm should start at the correct sample position
	if (pSendContext->audio_opt[0].Codec == AudioDecoder_Codec_PCM) {
		
		seekPos -= seekPos % pSendContext->PCMblockSize;
		
		RMDBGLOG((ENABLE, "PCM audio blockSize %lu, new seekPos %lld\n", pSendContext->PCMblockSize, seekPos));
	}

	if (pSendContext->skipFirstNBytes) {
		RMDBGLOG((ENABLE, "adjust seek pos due to skipping of %lu bytes\n", pSendContext->skipFirstNBytes));
		seekPos += pSendContext->skipFirstNBytes;
	}
	

	RMSeekFile(pSendContext->f_bitstream, seekPos, RM_FILE_SEEK_START);

	DCCSTCSetTime(pSendContext->dcc_info->pStcSource, timeSec*pSendContext->audio_vop_tir, pSendContext->audio_vop_tir);

	pSendContext->FirstSystemTimeStamp = TRUE;
	pSendContext->FirstPTS = timeSec*pSendContext->audio_vop_tir;
	Play(pSendContext, RM_DEVICES_AUDIO);

	RM_PSM_SetState(pSendContext->PSMcontext, &(pSendContext->dcc_info), RM_PSM_Playing);

	return RM_OK;
}


static RMstatus resumeFromTrick(struct audio_context *pSendContext)
{
	RMuint64 stc;
	RMuint32 timeSec;
	
	DCCSTCGetTime(pSendContext->dcc_info->pStcSource, &stc, pSendContext->audio_vop_tir);
			
	RMDBGLOG((ENABLE, "resume from trick at %llu s\n", stc/pSendContext->audio_vop_tir));
	timeSec = (RMuint32) (stc / pSendContext->audio_vop_tir);
       
	seek(pSendContext, timeSec);
	
	return RM_OK;
}

static void check_prebuf_state(struct audio_context *pSendContext, RMuint32 buffersize)
{
	RMbool quit_prebuf;
	enum RM_PSM_State PlaybackStatus = RM_PSM_GetState(pSendContext->PSMcontext, &(pSendContext->dcc_info));
	
	if (PlaybackStatus != RM_PSM_Prebuffering)
		return;

	/* if fail in getbuffer/senddata force quitting prebuffering state */
	quit_prebuf = ((buffersize == 0) || ((pSendContext->play_opt->prebuf_max > 0) && (pSendContext->prebufferedBytes >= pSendContext->play_opt->prebuf_max))) ? TRUE : FALSE;

	pSendContext->prebufferedBytes += buffersize;
		
	if (quit_prebuf) {
		RMDBGLOG((ENABLE, "exit prebuffering state, enter play state (bufsize %lu, prebuffered %lu)\n", buffersize, pSendContext->prebufferedBytes));
		fprintf(stderr, "now playing\n");
		RM_PSM_SetState(pSendContext->PSMcontext, &(pSendContext->dcc_info), RM_PSM_Playing);
		Play(pSendContext, RM_DEVICES_STC | RM_DEVICES_AUDIO);
		pSendContext->prebufferedBytes = 0;
	}
}





#ifdef WITH_MONO
int main_audio(struct mono_info *mono)
{
#else
int main(int argc, char *argv[])
{
	/*for MONO compatibility, always access these variables through the global pointers*/
	struct playback_cmdline playback_options; /*access through play_opt*/
	struct audio_cmdline audio_options[MAX_AUDIO_DECODER_INSTANCES]; /*access through audio_opt*/
	struct dh_context dh_info = {0,};

#endif

	RMstatus err = RM_ERROR;
	RMfile file = NULL; // Error code for open
	struct dcc_context dcc_info = {0,};

	RMuint32 file_offset = 0;
	RMuint32 audio_capture;

	struct audio_context context = {0,};
	struct RM_PSM_Context PSMContext;

	RMuint8 *buf = NULL; //dma buffers

	RMuint32 i;
	RMuint32 size = 0;
	RMascii key;

#ifdef WITH_BSAC
	// this allow the first audio decoder to play BSAC
	RMuint32 bsac_frame_size;
	RMuint32 DMA_buf_size;
	RMuint32 bsac_get_info_done;
#endif // WITH_BSAC
	
#ifdef WITH_MONO
	/*make the mono arguments global*/
	context.play_opt = mono->play_opt;
	context.audio_opt = mono->audio_opt;
	context.audioInstances = context.audio_opt[0].audioInstances;

	RMDBGLOG((ENABLE, "audio instances %lu, %lu\n", context.audioInstances, context.audio_opt[0].audioInstances));

	print_parsed_audio_options(context.audio_opt);

	dcc_info.pRUA = mono->pRUA;
	dcc_info.pDCC = mono->pDCC;
	
#else
	context.play_opt = &playback_options;
	context.audio_opt = audio_options;

	init_audio_options2(context.audio_opt, MAX_AUDIO_DECODER_INSTANCES);

	init_playback_options(context.play_opt);

	for (i = 0; i < MAX_AUDIO_DECODER_INSTANCES; i++)
		context.audio_opt[i].dh_info = &dh_info;

	parse_cmdline(&context, argc, argv, &context.audioInstances);
	context.audioInstances++;

	RMDBGLOG((ENABLE, "audio instances %lu, %lu\n", context.audioInstances, context.audio_opt[0].audioInstances));

	print_parsed_audio_options(context.audio_opt);

	err = RUACreateInstance(&(dcc_info.pRUA), context.play_opt->chip_num);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error creating RUA instance! %d\n", err);
		return -1;
	}

	err = DCCOpen(dcc_info.pRUA, &(dcc_info.pDCC));
	if (RMFAILED(err)) {
		fprintf(stderr, "Error Opening DCC! %d\n", err);
		return -1;
	}

	if (!context.play_opt->noucode) {
		err = DCCInitMicroCodeEx(dcc_info.pDCC, DCCInitMode_LeaveDisplay);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot initialize microcode %d\n", err);
			return -1;
		}
	}
	else
		RMDBGLOG((ENABLE, "microcode not loaded\n"));

	display_key_usage(KEYFLAGS);

/* 	dcc_info.pRUA = pRUA; */
/* 	dcc_info.pDCC = pDCC; */
#endif


	audio_capture = EMHWLIB_MODULE(AudioCapture, context.audio_opt->AudioEngineID);
	
	/* if HD control is enabled and mode is auto, setup parameters */
	if ((context.play_opt->disk_ctrl_low_level) &&
	    (context.play_opt->disk_ctrl_log2_block_size) &&
	    (context.play_opt->disk_ctrl_max_mem)) {
		RMuint32 bufferSize = 0;
		RMuint32 bufferCount = 0;
		RMuint32 log2BlockSize = context.play_opt->disk_ctrl_log2_block_size;
		RMuint32 maxBufferingMem = context.play_opt->disk_ctrl_max_mem;

		bufferSize = (1 << log2BlockSize);
		bufferCount = maxBufferingMem >> log2BlockSize;
	
		context.play_opt->dmapool_count = bufferCount;
		context.play_opt->dmapool_log2size = log2BlockSize;
	
		/* from #4005
		   
		videoOpt.fifo_size = 4*1024*1024; 
		videoOpt.xfer_count = (1<<playOpt.dmapool_log2size)/1024*playOpt.dmapool_count;
		audioOpt.fifo_size = 1*1024*1024; 
		audioOpt.xfer_count = (1<<playOpt.dmapool_log2size)/512*playOpt.dmapool_count;
		
		*/

		if (context.play_opt->disk_ctrl_low_level >= bufferCount)
			context.play_opt->disk_ctrl_low_level = bufferCount >> 1;
	
		context.audio_opt[0].fifo_size = 2 * (1024 * 1024);

		fprintf(stderr, ">> low level %lu => %lu bytes bufferized (+ bitstreamFIFO)\n", 
			context.play_opt->disk_ctrl_low_level,
			context.play_opt->disk_ctrl_low_level * bufferSize);

	
		context.audio_opt[0].xfer_count = bufferCount * 2;


		err = setup_disk_control_parameters(&dcc_info, context.play_opt, &(context.audio_opt[0]), NULL, NULL);

		if (err != RM_OK) {
			fprintf(stderr, "Error %d trying to setup HD control params\n", err);
			return -1;
		}

	}


	/* update fifo and xfer size */
	for (i = 0; i < context.audioInstances; i++) {

		if (!context.audio_opt[i].fifo_size) 
			context.audio_opt[i].fifo_size = AUDIO_FIFO_SIZE;
		
		if (!context.audio_opt[i].xfer_count)
			context.audio_opt[i].xfer_count = XFER_FIFO_COUNT;
	}

	/* update dmapool size and count */
	if (!context.play_opt->dmapool_count)
		context.play_opt->dmapool_count = DMA_BUFFER_COUNT;

	if (!context.play_opt->dmapool_log2size)
		context.play_opt->dmapool_log2size = DMA_BUFFER_SIZE_LOG2;

	for (i = 0; i < context.audioInstances; i++) {
		RMDBGLOG((ENABLE, "Audio[%lu]:\n\tBitstreamFIFOSize: %lu\n\tFIFOXFERCount: %lu\n", 
			  i,
			  context.audio_opt[i].fifo_size, 
			  context.audio_opt[i].xfer_count));
	}

	RMDBGLOG((ENABLE, "DMA Pool:\n\tSize: %ld\n\tBufferCount: %ld\n\tBufferSize: %ld\n", 
		  (context.play_opt->dmapool_count << context.play_opt->dmapool_log2size), 
		  context.play_opt->dmapool_count, 
		  (1<<context.play_opt->dmapool_log2size)));

	context.dmabuffer_array = (void **) NULL;
	context.dmabuffer_index = 0;

	switch (context.play_opt->disk_ctrl_state) {
	case DISK_CONTROL_STATE_DISABLE:
		break;
	case DISK_CONTROL_STATE_SLEEPING:
	case DISK_CONTROL_STATE_RUNNING:
		context.dmabuffer_array = (void **) RMMalloc(sizeof(void*) * context.play_opt->dmapool_count);
		context.dmabuffer_index = 0;
		if (context.dmabuffer_array == NULL) {
			RMDBGLOG((ENABLE, "Cannot allocate dmapool array! Disable disk control\n"));
			context.play_opt->disk_ctrl_state = DISK_CONTROL_STATE_DISABLE;
		}
		break;
	}


	err = apply_playback_options(&dcc_info, context.play_opt);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot set playback options %d\n", err);
		return -1;
	}

	{
		// open first stc module
		struct DCCStcProfile stc_profile;

		RMDBGLOG((ENABLE, "using STC ID %lu\n", context.play_opt->STCid));
		stc_profile.STCID = context.play_opt->STCid;
		stc_profile.master = Master_STC;
		
		stc_profile.stc_timer_id = 3*stc_profile.STCID+0;
		stc_profile.stc_time_resolution = 90000;
		
		stc_profile.video_timer_id = NO_TIMER;
		stc_profile.video_time_resolution = 0;
		stc_profile.video_offset = 0;
	
		stc_profile.audio_timer_id = 3*stc_profile.STCID+1;
		stc_profile.audio_time_resolution = 90000;
		stc_profile.audio_offset = -(context.play_opt->audio_delay_ms * (RMint32)stc_profile.audio_time_resolution / 1000);
		
		err = DCCSTCOpen(dcc_info.pDCC, &stc_profile, &dcc_info.pStcSource);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot open stc module %d\n", err);
			return -1;
		}
	}
		
	if (context.audio_opt[0].AudioIn) { // Audio pass-through
		struct AudioEngine_STC_type ae_stc;
		
		// Start Audio STC (has to be done before opening the AudioDecoder)
		ae_stc.Enable = TRUE;
		ae_stc.time_resolution = 90000;
		ae_stc.time = 0;
		err = RUASetProperty(dcc_info.pRUA, 
				     EMHWLIB_MODULE(AudioEngine, context.audio_opt[0].AudioEngineID), 
				     RMAudioEnginePropertyID_STC, 
				     &ae_stc, sizeof(ae_stc), 0);
	}

	{
		struct DCCAudioProfile audio_profiles[MAX_AUDIO_DECODER_INSTANCES];

		for (i = 0; i < context.audioInstances; i++) {
			audio_profiles[i].BitstreamFIFOSize = context.audio_opt[i].fifo_size;
			audio_profiles[i].XferFIFOCount = context.audio_opt[i].xfer_count;
			audio_profiles[i].DemuxProgramID = context.audio_opt[i].AudioEngineID * 2;
			audio_profiles[i].AudioEngineID = context.audio_opt[i].AudioEngineID;
			audio_profiles[i].AudioDecoderID = context.audio_opt[i].AudioDecoderID;
			audio_profiles[i].STCID = context.play_opt->STCid;
		}

		err = DCCOpenMultipleAudioDecoderSource(dcc_info.pDCC, audio_profiles, context.audioInstances, &(dcc_info.pMultipleAudioSource));

		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot open multiple audio decoder %d\n", err);
			goto cleanup;
		}
	}

	// apply the sample rate, serial out status
	for (i = 0; i < context.audioInstances; i++) {
		err = apply_audio_engine_options(&dcc_info, &(context.audio_opt[i]));
		if (RMFAILED(err)) {
			fprintf(stderr, "Error applying audio engine options %d\n", err);
			goto cleanup;
		}
	}
	apply_dvi_hdmi_audio_options(&dcc_info, &(context.audio_opt[0]), 0, FALSE, FALSE, FALSE);
	RMMicroSecondSleep(250 * 1000);  // Give HDMI sink 1/4 Sec to set up audio, as audio-only content should be audible from the beginning on

	if (!context.audio_opt[0].AudioIn) { 
		/* when capture, send buffer are not needed */
		/* dmapool must be created after the module open in case we do no copy transfers */
		err = RUAOpenPool(dcc_info.pRUA, 0, context.play_opt->dmapool_count, context.play_opt->dmapool_log2size, RUA_POOL_DIRECTION_SEND, &(context.pDMA));
	}

#ifndef WITH_BSAC
#else
	RMDBGLOG((ENABLE, "BSAC decoding is enabled\n"));
#endif //WITH_BSAC
//	if(context.audio_opt[0]->Codec != AudioDecoder_Codec_BSAC)
//		err = RUAOpenPool(dcc_info.pRUA, dcc_info.audio_decoder, DMA_BUFFER_COUNT, DMA_BUFFER_SIZE_LOG2, RUA_POOL_DIRECTION_SEND, &(context.pDMA));
//	else
//		err = RUAOpenPool(dcc_info.pRUA, 0, DMA_BUFFER_COUNT, DMA_BUFFER_SIZE_LOG2, RUA_POOL_DIRECTION_SEND, &(context.pDMA));

	if (RMFAILED(err)) {
		RMuint32 poolSize = context.play_opt->dmapool_count << context.play_opt->dmapool_log2size;

		fprintf(stderr, "Error cannot open dmapool %d\n\n"
			"requested %lu bytes of dmapool (%lu buffers of %lu bytes), make sure you\n"
			"loaded llad with the right parameters. For example:\n"
			"max_dmapool_memory_size >= %lu max_dmabuffer_log2_size >= %lu\n\n",
			err,
			poolSize,
			context.play_opt->dmapool_count,
			(RMuint32)(1<<context.play_opt->dmapool_log2size),
			poolSize,
			context.play_opt->dmapool_log2size);

		goto cleanup;
	}


	/* TODO update the code with MULTIPLE AUDIO SUPPORT */
#if 0
	if( (context.audio_opt[0].Codec == AudioDecoder_Codec_WMA) || (context.audio_opt[0].Codec == AudioDecoder_Codec_WMAPRO) ) {
		// add code just for debug wma spdif - all parameters are harcoded here: 
		struct AudioDecoder_WMAParameters_type wma_params;

		wma_params.VersionNumber = 0x162;// WMA PRO
		wma_params.SamplingFrequency = 48000;
		wma_params.NumberOfChannels = 6;
		wma_params.Bitrate = 384000;
		wma_params.PacketSize = 0x2000;
		wma_params.BitsPerSample = 24;
		wma_params.EncoderOptions = 0xe0;
		wma_params.WMAProVersionNumber = 0;
		wma_params.WMAProValidBitsPerSample = 24;
		wma_params.WMAProChannelMask = 0x3f;
		wma_params.OutputDualMode = context.audio_opt[0].OutputDualMode;
		wma_params.OutputSpdif = context.audio_opt[0].Spdif;

#if 1
		/*	Open the file and read parameters from intermediate format */

		file = open_stream(context.play_opt->filename, RM_FILE_OPEN_READ, 0);
		if (file == NULL) {
			fprintf(stderr, "Cannot open file %s\n", context.play_opt->filename);
			goto cleanup;
		}
		
		if (RMFAILED(parse_wmapro_intermediate(file, &wma_params))) {
			fprintf(stderr, "Cannot find sequence header!\n");
			goto cleanup;
		}

		RMCloseFile(file);
#endif // 1

		DCCSetAudioWMAFormat(dcc_info.pAudioSource, &wma_params); 
		// wma_params.SamplingFrequency
		fprintf(stdout, " set audio_freq = %ldHz (ignore any audio_freq in cmdline)\n", wma_params.SamplingFrequency);
		RUASetProperty(dcc_info.pRUA, EMHWLIB_MODULE(AudioEngine, context.audio_opt[0].AudioEngineID), RMAudioEnginePropertyID_SampleFrequency,
			&wma_params.SamplingFrequency, sizeof(wma_params.SamplingFrequency), 0);
		
		context.audio_opt[0].SampleRate = wma_params.SamplingFrequency;
		apply_dvi_hdmi_audio_options(&dcc_info, &(context.audio_opt[0]), wma_params.NumberOfChannels, TRUE, TRUE, FALSE);
	} else 
#endif // 0
	{
		// apply the audio format - uninit, set codec, set specific parameters, init
		for (i = 0; i < context.audioInstances; i++) {
			err = apply_audio_decoder_options(&dcc_info, &(context.audio_opt[i]));
			if (RMFAILED(err)) {
				fprintf(stderr, "Error applying audio_decoder_options %d\n", err);
				goto cleanup;
			}
		}
	}


#ifndef WITH_MONO	
	RMTermInit(TRUE);    // don't allow ctrl-C and the like ...
	RMSignalInit(NULL, NULL);  // ... but catch other termination signals to call RMTermExit()
#endif



	// pcm should start at the correct sample position
	if (context.audio_opt[0].Codec == AudioDecoder_Codec_PCM) {
		RMuint32 BitsPerSample = 0;
		RMuint32 channels = 0;
		
		if ( context.audio_opt[0].SubCodec == 0 || context.audio_opt[0].SubCodec == 3) {
			BitsPerSample = context.audio_opt[0].PcmCdaParams.BitsPerSample;
			
			if (context.audio_opt[0].PcmCdaParams.ChannelAssign == PcmCda1_C)
				channels = 1; 
			else if (context.audio_opt[0].PcmCdaParams.ChannelAssign == PcmCda2_LR)
				channels = 2;
			else if (context.audio_opt[0].PcmCdaParams.ChannelAssign == PcmCda6_LfRfCLfeLsRs)
				channels = 6;
			else
				channels = 2; // choose a default value
			RMDBGLOG((ENABLE, "pcmcda (-pcmN_M) with M=%lu chan and N=%lu bits, subcodec %lu\n", channels, BitsPerSample, context.audio_opt[0].SubCodec));
		} 
		else if ( context.audio_opt[0].SubCodec == 1 ) {
			BitsPerSample = context.audio_opt[0].LpcmVobParams.BitsPerSample;
			
			if (context.audio_opt[0].LpcmVobParams.ChannelAssign == LpcmVob1_C)
				channels = 1;
			else 
				channels = 2;

			RMDBGLOG((ENABLE, "lpcm with %lu chan and %lu bits, subcodec %lu\n", channels, BitsPerSample, context.audio_opt[0].SubCodec));
		} 
		else if ( context.audio_opt[0].SubCodec == 2 ) {
			BitsPerSample = context.audio_opt[0].LpcmAobParams.BitsPerSampleGroup1;
			
			if (context.audio_opt[0].LpcmAobParams.ChannelAssign == LpcmAob10_C)
				channels = 1;
			else 
				channels = 2;

			RMDBGLOG((ENABLE, "lpcmAOB with %lu chan and %lu bits, subcodec %lu\n", channels, BitsPerSample, context.audio_opt[0].SubCodec));
		}
		else
			RMDBGLOG((ENABLE, "unknown subcodec %lu\n", context.audio_opt[0].SubCodec));
		
		
		context.PCMblockSize = (BitsPerSample * channels) >> 3;
		context.PCMblockSize *= 2; //this makes the rule generic and fixes #4434
			
		RMDBGLOG((ENABLE, ">> audio is PCM %lu bits, %lu channels, blockSize %lu\n", BitsPerSample, channels, context.PCMblockSize));
	}


	////////////////////////////////////////////////////////////////////////
	// audio capture start when requested
	////////////////////////////////////////////////////////////////////////
	if (context.audio_opt[0].AudioIn) { // Audio pass-through
		// apply the audio format - uninit, set codec, set specific parameters, init
		err = apply_audio_decoder_options(&dcc_info, &(context.audio_opt[0]));
		if (RMFAILED(err)) {
			fprintf(stderr, "Error applying audio_decoder_options %d\n", err);
			goto cleanup;
		}

		RMDBGLOG((ENABLE, "\n****************\nAUDIO_IN enabled\n***************\n"));

		DCCSTCSetTime(dcc_info.pStcSource, 0, 90000);
		DCCSTCPlay(dcc_info.pStcSource);

 		// Send Play command to audio playback
		err = DCCPlayMultipleAudioSource(dcc_info.pMultipleAudioSource);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot play audio decoder %d\n", err);
			goto cleanup;
		}
		
		if (1) {			
			RMbool AVSyncEnable = FALSE;
			struct DCCAudioSourceHandle audioHandle1;
			
			// wait until audio decoder has started the delayed playback
			RMMicroSecondSleep(context.audio_opt[0].CaptureDelay * 200 / 9);  // actual delay in uSec: CaptureDelay * 100 / 9
			
			// Disable AV-Sync (for now, because STC is running on asynchronous clock, which breaks the passthrough after some time.)
			err = DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(dcc_info.pMultipleAudioSource, 0, &audioHandle1);
			if (RMFAILED(err)) {
				audioHandle1.moduleID = dcc_info.audio_decoder;
			}
			err = RUASetProperty(dcc_info.pRUA, audioHandle1.moduleID, 
				RMAudioDecoderPropertyID_SyncSTCEnable, 
				&AVSyncEnable, sizeof(AVSyncEnable), 0);
			if (RMFAILED(err)) {
				fprintf(stderr, "Error disabling AV-Sync! %s\n", RMstatusToString(err));
				return err;
			} else {
				RMDBGLOG((ENABLE, "\n*********\n AUDIO sync is %s\n*********\n", AVSyncEnable ? "enabled" : "disabled"));
			}
		}
		
		// Start audio capture
		err = StartAudioCapture(&dcc_info, audio_capture, &(context.audio_opt[0]), &context);
		if (RMFAILED(err)) {
			fprintf(stderr, "Error starting audio capture! %s\n", RMstatusToString(err));
			goto cleanup;
		}
		
		context.play_opt->waitexit = TRUE; // Force wait on exit			
		
		if(!context.fp_capture){
			goto cleanup;
		}else{
			goto capture_loop;
		}
	} else {
		file = open_stream(context.play_opt->filename, RM_FILE_OPEN_READ, 0);

		if (file == NULL) {
			fprintf(stderr, "Cannot open file %s\n", context.play_opt->filename);
			goto cleanup;
		}

		context.f_bitstream = file;
		RMSizeOfOpenFile(file, &context.fileSize);

		if (context.audio_opt[0].skip_first_n_bytes) {
			context.skipFirstNBytes = context.audio_opt[0].skip_first_n_bytes;
			RMDBGLOG((ENABLE, ">> skip first %lu bytes, adjust file size from %llu to %llu\n",
				  context.skipFirstNBytes,
				  context.fileSize,
				  context.fileSize - context.skipFirstNBytes));

			context.fileSize -= context.skipFirstNBytes;
		}
			
		if (context.audio_opt[0].send_n_bytes) {
			context.sendNBytes = context.audio_opt[0].send_n_bytes;
			RMDBGLOG((ENABLE, ">> send up to %lu bytes only, adjust file size from %llu to %lu\n",
				  context.sendNBytes,
				  context.fileSize,
				  context.sendNBytes));

			// pcm should start at the correct sample position
			if (context.audio_opt[0].Codec == AudioDecoder_Codec_PCM) {
				context.sendNBytes -= context.sendNBytes % context.PCMblockSize;

				RMDBGLOG((ENABLE, "aligned to %lu\n", context.sendNBytes));
			}
				  
			context.fileSize = context.sendNBytes;
		}
	  

		RMDBGLOG((ENABLE, "file: %s, size %llu, duration %llu\n", context.play_opt->filename, context.fileSize, context.play_opt->duration / 1000));
		context.Duration = context.play_opt->duration / 1000;
		context.audio_vop_tir = 90000;

		dcc_info.RM_PSM_commands = RM_PSM_ENABLE_PLAY;
		dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_STOP;
		dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_PAUSE;

		if (context.Duration)
			fprintf(stderr, "duration %llu secs\n", context.Duration);

		if ((context.play_opt->duration > 1000) && (context.fileSize > 0)) {
			RMDBGLOG((ENABLE, "seek and ffwd trick mode enabled\n"));
			dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_SPEED;
			dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_FASTER;
			dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_SLOWER;
			dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_SEEK;
			dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_REWIND;

			dcc_info.seek_supported = TRUE;
		}
	}

	context.dcc_info = &dcc_info;
	context.PSMcontext = &PSMContext;
	PSMContext.validPSMContexts = 1;
	PSMContext.currentActivePSMContext = 1;
	PSMContext.keyflags = KEYFLAGS;




#if DUMP_DATA
	RMDBGLOG((ENABLE, "\t\t\t***** OPEN SAVE DATA FILE ****\n"));
	context.saveFile = fopen("ec3_transcoded_ac3.with_pushLibrary.dump", "wb");
#endif


	if (context.audio_opt[0].transcode_ec3_to_ac3) {
		struct RMEC3subParams_struct subParams;
		RMuint32 ch;

		RMDBGLOG((ENABLE, "init ec3 transcoding lib\n"));
		context.transcodeEC3toAC3 = TRUE;


		subParams.compMode = RMEC3_COMP_LINE;
		subParams.outLFE = RMEC3_LFEOUT_ON;
		subParams.outChanConfig = RMEC3_MODE32;
		subParams.pcmScale = RMEC3_DEFAULTSCALEFACTOR;
		subParams.stereoMode = RMEC3_STEREOMODE_AUTO;
		subParams.dualMode = RMEC3_DUAL_STEREO;
		subParams.dynScaleHigh = RMEC3_DEFAULTSCALEFACTOR;
		subParams.dynScaleLow = RMEC3_DEFAULTSCALEFACTOR;

		for (ch = 0; ch < RMEC3_MAXPCMCHANS; ch++)
			subParams.chanRouting[ch] = ch;

		subParams.subStream = RMEC3_DEFAULTSUBSTREAMID;

#if defined(KCAPABLE)
		subParams.karaokeMode = RMEC3_BOTH_VOCALS;
#endif /* defined(KCAPABLE) */

		context.ec3TranscoderHandle = RMEC3OpenTranscoder(subParams);
		if (!context.ec3TranscoderHandle) {
			fprintf(stderr, "couldnt init ec3 transcoding library\n");
			goto cleanup;
		}

		context.readBuffer = (RMuint8*)RMMalloc((1<<context.play_opt->dmapool_log2size) * sizeof(RMuint8));
		if (!context.readBuffer) {
			fprintf(stderr, "couldnt init read buffer required by ec3 lib\n");
			goto cleanup;
		}
		RMDBGLOG((ENABLE, "allocated %lu bytes of read buffer\n", (1<<context.play_opt->dmapool_log2size)));
	}

	/***************************************************************
	Play_audio does NOT have PTS to sync	
	****************************************************************/
	// Disable AV-Sync (for now, because STC is running on asynchronous clock, which breaks the passthrough after some time.)
	{
		struct DCCAudioSourceHandle audioHandle1;
		RMbool sync_stc = FALSE;
		err = DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(dcc_info.pMultipleAudioSource, 0, &audioHandle1);
		if (RMSUCCEEDED(err))  {
			err = RUASetProperty(dcc_info.pRUA, audioHandle1.moduleID, RMAudioDecoderPropertyID_SyncSTCEnable, &sync_stc, sizeof(RMbool), 0);
		}
		else
		{
			err = RUASetProperty(dcc_info.pRUA, dcc_info.audio_decoder, RMAudioDecoderPropertyID_SyncSTCEnable, &sync_stc, sizeof(RMbool), 0);
		}
		if (RMFAILED(err)) {
			fprintf(stderr, "Error disabling AV-Sync! %s\n", RMstatusToString(err));
			return err;
		}
	}

	////////////////////////////////////////////////////////////////////////
	// main playback loop
	////////////////////////////////////////////////////////////////////////
	do {
		enum RM_PSM_State PlaybackStatus;

		RMDBGLOG((ENABLE, "do-while\n"));
		if (context.play_opt->start_pause) 
			RM_PSM_SetState(context.PSMcontext, &(context.dcc_info), RM_PSM_Paused);
		else
			RM_PSM_SetState(context.PSMcontext, &(context.dcc_info), RM_PSM_Playing);
		context.play_opt->start_pause = FALSE;

	mainloop:
		RMDBGLOG((ENABLE, "mainloop\n"));

		file_offset = 0;
		if (RMSeekFile(file, context.skipFirstNBytes, RM_FILE_SEEK_START) != RM_OK) {
			perror("seeking file to beginning\n");
			goto cleanup;
		}

	mainloop_no_seek:
		RMDBGLOG((ENABLE, "mainloop no seek\n"));
		

		context.FirstPTS = 0;

		// pcm should start at the correct sample position
		if ((context.audio_opt[0].Codec == AudioDecoder_Codec_PCM) && (!context.skipFirstNBytes)) {
			RMint64 filePos = 0;
			RMint64 seekPos;

			RMGetCurrentPositionOfFile(file, &filePos);

			seekPos = filePos;

			seekPos -= seekPos % context.PCMblockSize;

			RMDBGLOG((ENABLE, "filePos %lld, blockSize %lu, new seekPos %lld\n", filePos, context.PCMblockSize, seekPos));
			RMSeekFile(file, seekPos, RM_FILE_SEEK_START);
		}

	mainloop_seek:

		
		context.lastSTC = 0;
		context.FirstSystemTimeStamp = TRUE;
		context.trickMode = FALSE;
		context.dcc_info->state = RM_PLAYING;


		DCCSTCSetSpeed(dcc_info.pStcSource, 1, 1);


		PlaybackStatus = RM_PSM_GetState(context.PSMcontext, &(context.dcc_info));
		if ((PlaybackStatus != RM_PSM_Paused) && (PlaybackStatus != RM_PSM_Stopped)) {
			RMDBGLOG((ENABLE, "setting play state\n"));
			RM_PSM_SetState(context.PSMcontext, &(context.dcc_info), RM_PSM_Playing);	
		}
		else 
			PROCESS_KEY(FALSE, TRUE);

		

		// the following call will configure the decoders, after that we can 'pause' them
		err = Play(&context, RM_DEVICES_AUDIO);
		if (err != RM_OK)
			goto cleanup;

		/* do prebufferization only when in playing state */
		if (RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Playing) {

			Pause(&context, RM_DEVICES_STC | RM_DEVICES_AUDIO);
		
			RM_PSM_SetState(context.PSMcontext, &(context.dcc_info), RM_PSM_Prebuffering);
			fprintf(stderr, "prebuffering\n");
		}



#ifdef WITH_MONO
		RMDCCInfo(&dcc_info); // pass DCC context to application
#endif

		/* wake up disks if necessary */
		switch (context.play_opt->disk_ctrl_state) {
		case DISK_CONTROL_STATE_DISABLE:
		case DISK_CONTROL_STATE_RUNNING:
			break;
		case DISK_CONTROL_STATE_SLEEPING:
			if(context.play_opt->disk_ctrl_callback && context.play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_RUN) == RM_OK)
				context.play_opt->disk_ctrl_state = DISK_CONTROL_STATE_RUNNING;
			break;
		}

#ifdef WITH_BSAC
		bsac_frame_size = 0;
		DMA_buf_size = 0;
		bsac_get_info_done = 0;
#endif

		while (1) { // additional 'while' used for taking care of commands issued during EOSWait
			while (1) {

				RMuint32 count;
				RMuint32 bufferSize = (1<<context.play_opt->dmapool_log2size);
				RMstatus status = RM_OK;
				struct emhwlib_info Info;
				struct emhwlib_info *pInfo = &Info;
				RMuint32 Info_size = sizeof(Info);
				RMint32 lastOKinstance = -1;

				if ((context.sendNBytes) && (!context.trickMode)) {
					RMint64 current_file_offset;
					
					RMGetCurrentPositionOfFile(file, &current_file_offset);

					if (current_file_offset - context.skipFirstNBytes > context.sendNBytes) {
						RMDBGLOG((ENABLE, "a seek beyond the sendable data occurred\n"));
						RMDBGLOG((ENABLE, "stop sending data at %llu (sendNBytes %lu, skipNBytes %lu)\n", 
							  current_file_offset,
							  context.sendNBytes,
							  context.skipFirstNBytes));
						break;
					}

					bufferSize = context.sendNBytes - (RMuint32)current_file_offset - context.skipFirstNBytes;
					
					bufferSize = RMmin( (RMuint32)(1<<context.play_opt->dmapool_log2size), (RMuint32)bufferSize);

					if (!bufferSize) {
						RMDBGLOG((ENABLE, "stop sending data at %llu (sendNBytes %lu, skipNBytes %lu)\n", 
							  current_file_offset,
							  context.sendNBytes,
							  context.skipFirstNBytes));
						break;
					}
				}
				else
					bufferSize = (1<<context.play_opt->dmapool_log2size);
				
				
				PROCESS_KEY(FALSE, TRUE);
			
				update_hdmi_audio(context.dcc_info, &(context.audio_opt[0]));
				
				if (buf)
					RMDBGLOG((ENABLE, "*************unreleased buffer found!\n"));


				


			get_buffer:

				switch (context.play_opt->disk_ctrl_state) {
				case DISK_CONTROL_STATE_DISABLE:
				case DISK_CONTROL_STATE_SLEEPING:
					break;
				case DISK_CONTROL_STATE_RUNNING:
					if (context.dmabuffer_index > 0) {
						context.dmabuffer_index--;
						buf = context.dmabuffer_array[context.dmabuffer_index];
						RMDBGLOG((ENABLE, "fill buffer phase: got buffer %p (index %lu, level %lu, count %lu)\n", 
							  buf,
							  context.dmabuffer_index,
							  context.play_opt->disk_ctrl_low_level,
							  context.play_opt->dmapool_count));
						
						goto fill_buffer;
					}
					break;
				}
		      
				while (RUAGetBuffer(context.pDMA, &buf,  GETBUFFER_TIMEOUT_US) != RM_OK) {

					check_prebuf_state(&context, 0);

					/* fprintf(stderr, "Wait for a buffer\n"); */


					switch (context.play_opt->disk_ctrl_state) {
					case DISK_CONTROL_STATE_DISABLE:
					case DISK_CONTROL_STATE_SLEEPING:
						break;
					case DISK_CONTROL_STATE_RUNNING:
						if(context.play_opt->disk_ctrl_callback && context.play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_SLEEP) == RM_OK)
							context.play_opt->disk_ctrl_state = DISK_CONTROL_STATE_SLEEPING;
						break;
					}

					PROCESS_KEY(FALSE, TRUE);

					update_hdmi_audio(context.dcc_info, &(context.audio_opt[0]));
				}
		
				check_prebuf_state(&context, bufferSize);

				switch (context.play_opt->disk_ctrl_state) {
				case DISK_CONTROL_STATE_DISABLE:
				case DISK_CONTROL_STATE_RUNNING:
					break;
				case DISK_CONTROL_STATE_SLEEPING:
					context.dmabuffer_array[context.dmabuffer_index] = buf;
					context.dmabuffer_index ++;
					if (context.dmabuffer_index + context.play_opt->disk_ctrl_low_level >= context.play_opt->dmapool_count) {
						if(context.play_opt->disk_ctrl_callback && context.play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_RUN) == RM_OK)
							context.play_opt->disk_ctrl_state = DISK_CONTROL_STATE_RUNNING;
					}
					RMDBGLOG((ENABLE, "recycle buffer phase: got buffer %p (index %lu, level %lu, count %lu)\n", 
						  buf,
						  context.dmabuffer_index,
						  context.play_opt->disk_ctrl_low_level,
						  context.play_opt->dmapool_count));

					goto get_buffer;
				}
				
			fill_buffer:

				{
					RMint64 currentTime;
					RMuint64 stc;
				
					DCCSTCGetTime(context.dcc_info->pStcSource, &stc, context.audio_vop_tir);
					currentTime = (RMint64)stc;

					if ((currentTime > (RMint64)(context.lastSTC + context.audio_vop_tir)) ||
					    (currentTime < (RMint64)(context.lastSTC - context.audio_vop_tir))){
						context.lastSTC = currentTime;
						currentTime /= context.audio_vop_tir;
						if (context.Duration) {
							RMDBGLOG((ENABLE, "stc time = %llu/%llu secs (%lld/100)\n", currentTime, context.Duration, (currentTime * 100)/context.Duration));
						}
						else
							RMDBGLOG((ENABLE, "stc time = %llu secs\n", currentTime));
					}
				}

				if (context.trickMode) {
					RMint64 currentTime;
					RMuint64 stc;

					DCCSTCGetTime(context.dcc_info->pStcSource, &stc, context.audio_vop_tir);
					currentTime = (RMint64)stc;

					status = RM_SKIP_DATA; // dont send the buffers

					if ((currentTime > (RMint64)(context.lastSTC + context.audio_vop_tir)) ||
					    (currentTime < (RMint64)(context.lastSTC - context.audio_vop_tir))){
						context.lastSTC = currentTime;
					}

					currentTime /= context.audio_vop_tir;

					if ((currentTime > (RMint64)context.Duration) || (currentTime < 0)) {
						fprintf(stderr, "end of file\n");
						status = RM_ERRORENDOFFILE;
					}
					usleep(100000); // to prevent high CPU usage

				}
				else {
					if (!context.transcodeEC3toAC3) {
#ifndef WITH_BSAC
						status = RMReadFile(file, buf, bufferSize, &count);
#else // WITH_BSAC
						if(context.audio_opt[0].Codec != AudioDecoder_Codec_BSAC)
							status = RMReadFile(file, buf, bufferSize, &count);
						else {
								RMuint32 val;
								RMuint8 *bsac_buf = buf;
								RMuint8 *bsac_bts_buf = context.bsac_bts_buf;
								bsac_bts_buf = (RMuint8*)(((RMuint32)bsac_bts_buf+3) & (~0x3));//libbsac only work with dword aligned buf
								
								status = RMReadFile(file, bsac_bts_buf, 2, &count);
								//fprintf(stdout, "%ld bytes are read  ", count);
								if (status == RM_ERRORREADFILE || status == RM_ERRORENDOFFILE)
									goto audio_file_eos;
								
								file_offset += count;
								val = ((RMuint32)bsac_bts_buf[0]<<3) | (((RMuint32)bsac_bts_buf[1]>>5) & 0x07);    // get 11 bits frame_length
								// fprintf(stdout, "Frame length = %lu\n", val);
								
								status = RMReadFile(file, bsac_bts_buf+2, val-2, &count);    // get one frame data,
								if (status == RM_ERRORREADFILE)
									goto audio_file_eos;
								
								file_offset += count;
								bsac_frame_size = val;
								
								if(!bsac_get_info_done)	{
									GetBitstreamInfo(bsac_bts_buf, context.audio_opt[0].SampleRate, (int*)&context.bsac_bitrate, (int*)&context.bsac_profile);
									RMDBGLOG((ENABLE, "MPEG-4 BSAC format\n sample_rate = %ld\t bit_rate = %ld kbps\n Profile = %ld \n",
										  (RMuint32)context.audio_opt[0].SampleRate, (RMuint32)context.bsac_bitrate, (RMuint32)context.bsac_profile));
									
									AllocDecBuff(BSAC_NCH);                 // BSAC init...
									bsac_get_info_done = 1;
								}
								// !!! One frame bit BSAC bits should be in bsac_bts_buf
								Mp4AudioDecodeFrame(bsac_bts_buf, context.bsac_bitrate, context.bsac_profile, BSAC_NCH, (BSAC_DSP_Info *)bsac_buf); 
								DMA_buf_size = BSAC_DSP_LENGTH;
								//fprintf(stdout, "buf available = %ld bytes\n", DMA_buf_size);
						}
#endif // WITH_BSAC
					}
					else if (!context.getNewBufferForEC3)
						status = RMReadFile(file, context.readBuffer, bufferSize, &count);
					else
						status = RM_OK;
				}

#ifdef WITH_BSAC
audio_file_eos:
#endif // WITH_BSAC
				if (status == RM_ERRORREADFILE) {
					perror("reading file");
					RUAReleaseBuffer(context.pDMA, buf);
					buf = NULL;
					goto cleanup;
				}
				else if (status == RM_ERRORENDOFFILE) {
					RMDBGLOG((ENABLE, "end of file\n"));
					RUAReleaseBuffer(context.pDMA, buf);
					buf = NULL;
					break;
				}
				else if (status == RM_SKIP_DATA) {
					RMDBGLOG((DISABLE, "skip data\n"));
					RUAReleaseBuffer(context.pDMA, buf);
					buf = NULL;
					continue;
				}
				else if (status != RM_OK) {
					RMDBGLOG((ENABLE, "unhandled error %s\n", RMstatusToString(status)));
					RUAReleaseBuffer(context.pDMA, buf);
					buf = NULL;
					break;
				}

				file_offset += count;

				if (context.FirstSystemTimeStamp) {
					RMDBGLOG((ENABLE, "first PTS : %lu\n", context.FirstPTS));
					DCCSTCSetTime(dcc_info.pStcSource, context.FirstPTS, 90000);
					//DCCSTCPlay(dcc_info.pStcSource);
					
					context.FirstSystemTimeStamp = FALSE;
					Info.ValidFields = TIME_STAMP_INFO;
					Info.TimeStamp = context.FirstPTS;
				}
				else {
					pInfo = NULL;
					Info_size = 0;
				}
				
				if (RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Prebuffering)
					RMDBGPRINT((ENABLE, "."));
				
				if (context.transcodeEC3toAC3) {
					RMuint32 offset = 0;
					RMuint32 bufSize = (1<<context.play_opt->dmapool_log2size);
					RMuint32 sizeLeft = bufSize;
					RMuint32 frames = 0;
					
					if (!context.getNewBufferForEC3) {
						status = RMEC3SetInputBuffer(context.ec3TranscoderHandle, context.readBuffer, count);
						if (status == RM_ERROR) {
							RMDBGLOG((ENABLE, "error preparing data for ec3 transcoding lib\n"));
							goto cleanup;
						}
						else if (status == RM_SKIP_DATA) {
							RMDBGLOG((ENABLE, "not in sync yet\n"));
							goto fill_buffer;
						}
						else if (status == RM_NEED_MORE_DATA) {
							RMDBGLOG((ENABLE, "inputBuffer requires more data\n"));
							goto fill_buffer;
						}
					}
					
					context.getNewBufferForEC3 = FALSE;

					while(1) {
						RMuint32 frameSize = 0;
						
						frames++;
						
						status = RMEC3GetTranscodedFrame(context.ec3TranscoderHandle, buf + offset, sizeLeft, &frameSize, &count); 
						RMDBGLOG((DISABLE, "status = (%s)\n", RMstatusToString(status)));

						RMDBGLOG((ENABLE, "[%lu] transcoded size %lu\n", frames, count));

						offset += count;
						sizeLeft -= count;

						if (status == RM_BUFFERTOOSMALL) {
							RMDBGLOG((ENABLE, "buffer too small\n"));
							context.getNewBufferForEC3 = TRUE;
							break;
						}
						else if (status == RM_NEED_MORE_DATA) {
							RMDBGLOG((ENABLE, "incomplete frame\n"));
							break;
						}
						else if (status != RM_OK) {
							RMDBGLOG((ENABLE, "no more frames\n"));
							break;
						}
						
						PROCESS_KEY(TRUE, TRUE);
						
						update_hdmi_audio(context.dcc_info, &(context.audio_opt[0]));
					}
					RMDBGLOG((ENABLE, "total transcoded size %lu\n", offset));
					count = offset;
				}

				if (!count)
					goto fill_buffer;

				
#if DUMP_DATA
				RMDBGLOG((ENABLE, "dumping %lu bytes\n", count));
				fwrite(buf, count, 1, context.saveFile);
#else					
				RMDBGLOG((DISABLE, "sending %lu bytes\n", count));


#ifdef WITH_BSAC
				if(context.audio_opt[0].Codec == AudioDecoder_Codec_BSAC)
					count = DMA_buf_size;
#endif
				
				//RMDBGLOG((ENABLE, "############## Audio audioInstances = %lu\n", context.audioInstances));
				//RMDBGLOG((ENABLE, "############## Audio lsbfirst = %s\n", context.audio_opt->PcmCdaParams.MsbFirst?"FALSE":"TRUE"));
				// This is just an example to do byte swapping from 16bit little endian to big endian
				// Note: Apply it to AC3 and DTS test vectors, they are usually in little endian format.
				// David, 5/9/2007
				if(context.audio_opt->Codec != AudioDecoder_Codec_PCM && context.audio_opt->PcmCdaParams.MsbFirst == FALSE)
				{
					RMuint32 i;
					for(i=0; i<count; i+=2)
					{
						RMuint8 tmp = buf[i];
						buf[i] = buf[i+1];
						buf[i+1] = tmp;
					}
				}

				while (DCCMultipleAudioSendData(dcc_info.pMultipleAudioSource, context.pDMA, buf, count, pInfo, Info_size, &lastOKinstance) != RM_OK) {
					struct RUAEvent e;
					struct DCCAudioSourceHandle audioHandle;

					check_prebuf_state(&context, 0);						
					
					PROCESS_KEY(TRUE, TRUE);
					
					update_hdmi_audio(context.dcc_info, &(context.audio_opt[0]));
					
					if (lastOKinstance == -1) {
						fprintf(stderr, "cant wait on unknown instance!!\n");
						goto cleanup;
					}

					status = DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(dcc_info.pMultipleAudioSource, lastOKinstance, &audioHandle);
					if (status != RM_OK)
							goto cleanup;
						
					e.ModuleID = audioHandle.moduleID;
					e.Mask = RUAEVENT_XFER_FIFO_READY;

					while (RUAWaitForMultipleEvents(dcc_info.pRUA, &e, 1, SENDDATA_TIMEOUT_US, NULL) != RM_OK) {
						PROCESS_KEY(TRUE, TRUE);
						fprintf(stderr, "wait for xfer fifo ready\n");
						update_hdmi_audio(context.dcc_info, &(context.audio_opt[0]));
					}
				}
				
#endif
					
				/* Get profiling value */
				{					
					RMuint32 profile;
					struct DCCAudioSourceHandle audioHandle1;

					DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(dcc_info.pMultipleAudioSource, 0, &audioHandle1);
					err = RUAGetProperty(dcc_info.pRUA,
							     audioHandle1.moduleID,
							     RMGenericPropertyID_Profile,
							     &profile,
							     sizeof(profile));
					if (err == RM_OK) 
						RMDBGLOG((ENABLE,"DSP Usage = %lu%%\n", profile));
					
				}

				RUAReleaseBuffer(context.pDMA, buf);
				buf = NULL;
			} // while(1)


			check_prebuf_state(&context, 0);
			
			switch (context.play_opt->disk_ctrl_state) {
			case DISK_CONTROL_STATE_DISABLE:
			case DISK_CONTROL_STATE_SLEEPING:
				break;
			case DISK_CONTROL_STATE_RUNNING:
				if(context.play_opt->disk_ctrl_callback && context.play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_SLEEP) == RM_OK)
					context.play_opt->disk_ctrl_state = DISK_CONTROL_STATE_SLEEPING;
				break;
			}

			// in case we're still in pause state, wait for a key
			PROCESS_KEY(FALSE, TRUE);
			update_hdmi_audio(context.dcc_info, &(context.audio_opt[0]));

			//wait_eos: // fix bugct 1956 but will hurt HDD optimisation, find another way
			fprintf(stderr, "File ready %ld times, waiting for EOS\n", context.NTimes+1);
			err = WaitForEOS(&context, &context.actions);
			{
				RMuint64 stc;
				DCCSTCGetTime(dcc_info.pStcSource, &stc, 90000);
				
				RMDBGLOG((ENABLE, "Timer duration %llu ms\n", stc/90));
			}
			if (err == RM_KEY_WHILE_WAITING_EOS) {
				RMDBGLOG((ENABLE, "command while waiting for EOS\n"));
				err = RM_OK;
				PROCESS_KEY(FALSE, FALSE);
				update_hdmi_audio(context.dcc_info, &(context.audio_opt[0]));
				//goto wait_eos;
			}
			else 
				break; // EOS
		}
		if (context.play_opt->loop_count > 0)
			context.play_opt->loop_count --;

		/* if there is another loop, stop devices... */
		if ((context.play_opt->loop_count > 0) || (context.play_opt->waitexit != TRUE) || (context.play_opt->infinite_loop))
			Stop(&context, RM_DEVICES_AUDIO | RM_DEVICES_STC);

		context.NTimes++;

	} while ((context.play_opt->loop_count > 0) || (context.play_opt->infinite_loop));
	
	goto cleanup;


	////////////////////////////////////////////////////////////////////////
	// capture loop
	////////////////////////////////////////////////////////////////////////
 capture_loop:
	// file capture loop
	while(1) {
		err = process_command(context.PSMcontext, &(context.dcc_info), &(context.actions));
		if (RMFAILED(err)) {
			fprintf(stderr, "Error while processing key %d\n", err);
			break;
		}
		if ((context.actions.cmd == RM_QUIT) && (!context.actions.cmdProcessed)) {
			RMDBGLOG((ENABLE, "Got quit command\n"));
			break;
		}
		
		update_hdmi_audio(context.dcc_info, &(context.audio_opt[0]));
		
		while(RUAReceiveData(dcc_info.pRUA,audio_capture, context.pDMA, &buf, &size,NULL,NULL) != RM_OK) {
			struct RUAEvent e;
			e.ModuleID = audio_capture;
			e.Mask = SOFT_IRQ_EVENT_XFER_RECEIVE_READY;
			err = RUAWaitForMultipleEvents(dcc_info.pRUA, &e, 1, 1000 /*RECEIVEDATA_TIMEOUT_US*/, NULL);
			if (RMFAILED(err)){
				//RMDBGLOG((ENABLE, "%d, %p 0x%x %d\n", audio_capture, context.pDMA, buf, size));
			}
		}
		
		if(!buf) {
			RMDBGLOG((ENABLE, "error, RUAReceiveData returned no buffer!\n"));
			continue;
		}else{
			
			if ((size > 0) && (context.fp_capture >= 0)) {
				fwrite(buf, size, 1, context.fp_capture);
			}
			RUAReleaseBuffer(context.pDMA, buf);
		}
	
	}
	goto cleanup_2;

 cleanup:
	if (file != NULL) 
		RMCloseFile(file);

#if DUMP_DATA
	RMDBGLOG((ENABLE, "\t\t\t***** CLOSE SAVE DATA FILE ****\n"));
	fclose(context.saveFile);
#endif

	if (context.transcodeEC3toAC3) {
		if (context.ec3TranscoderHandle)
			RMEC3CloseTranscoder(context.ec3TranscoderHandle);
		if (context.readBuffer)
			RMFree(context.readBuffer);
	}


	if( context.play_opt->waitexit ) {
		if (context.audio_opt[0].AudioIn) {
			fprintf(stderr, "press q key to stop & quit, 's' to stop capture...\n");
		} else {
			fprintf(stderr, "press q key again if you really want to stop & quit\n");
		}
		
		while(1) {
			if (RMGetKeyNoWait(&key)) {
				err = handle_key(context.dcc_info, &(context.actions.cmd), KEYFLAGS, key);
				if ((context.actions.cmd == RM_QUIT) && (!context.actions.cmdProcessed)) break;
				if (err == RM_PENDING) {
					if (context.audio_opt[0].AudioIn) {
						if (toupper(key) == 'S') {
							// StopAudioCapture should be called first
							err = StopAudioCapture(&dcc_info, audio_capture, &context);
							if (RMFAILED(err)) {
								fprintf(stderr, "ERROR : Unable to stop audio capture!\n");
								goto cleanup_2;
							}
							
							DCCSTCStop(dcc_info.pStcSource);
							
							err = DCCStopMultipleAudioSource(dcc_info.pMultipleAudioSource);
							if (RMFAILED(err)) {
								fprintf(stderr, "ERROR: Unable to stop audio source!\n");
								goto cleanup_2;
							}
						}
						
						if (toupper(key) == 'G') {
							// file mode capture
							
							DCCSTCSetTime(dcc_info.pStcSource, 0, 90000);
							DCCSTCPlay(dcc_info.pStcSource);
							
							err = DCCPlayMultipleAudioSource(dcc_info.pMultipleAudioSource);
							if (RMFAILED(err)) {
								fprintf(stderr, "ERROR: Unable to play audio source\n");
								goto cleanup_2;
							}
							
							err = StartAudioCapture(&dcc_info, audio_capture, &(context.audio_opt[0]), &context);
							if (RMFAILED(err)) {
								fprintf(stderr, "ERROR: Unable to start audio capture!\n");
								goto cleanup_2;
							}
						}
					}
				}
			}
			key = 0;
			update_hdmi_audio(context.dcc_info, &(context.audio_opt[0]));
		}
	}

 cleanup_2:
#ifndef WITH_MONO	
 	RMTermExit();
#endif

	if (err != RM_OK) {
		fprintf(stderr, "quitting due to error %s (%d)...\n", RMstatusToString(err), err);
		//error = err; //exit with error
	}

	RMDBGLOG((ENABLE, "closing...\n"));

#ifdef WITH_MONO
	RMDCCInfo(NULL); // invalidate DCC context
#endif

 	
	for (i = 0; i < context.audioInstances; i++) {

		// Restore internal audio engine clock		
		if (context.audio_opt[i].ExternalClk) {
			RMDBGLOG((ENABLE, "restoring internal audio engine clock for instance %lu\n", i));
			context.audio_opt[i].ExternalClk = FALSE;
			err = apply_audio_engine_options(&dcc_info, &(context.audio_opt[i]));
		}
	}

	if (context.audio_opt[0].AudioIn) { // Audio pass-through
		struct AudioEngine_STC_type ae_stc;
		
		// stop and disable STC in audio engine
		ae_stc.Enable = FALSE;
		ae_stc.time_resolution = 0;
		ae_stc.time = 0;
		err = RUASetProperty(dcc_info.pRUA, 
			EMHWLIB_MODULE(AudioEngine, context.audio_opt[0].AudioEngineID), 
			RMAudioEnginePropertyID_STC, 
			&ae_stc, sizeof(ae_stc), 0);
		
		err = StopAudioCapture(&dcc_info, audio_capture, &context);
	}

	if(context.fp_capture){
		fclose(context.fp_capture);
		context.fp_capture = NULL;
	}
	
	if (dcc_info.pStcSource) {
		DCCSTCStop(dcc_info.pStcSource);
		DCCSTCClose(dcc_info.pStcSource);
	}

	if (context.dmabuffer_array) {
		RMuint32 i;
		for (i = 0; i < context.dmabuffer_index; i++) {
			RUAReleaseBuffer(context.pDMA, context.dmabuffer_array[i]);
			RMDBGLOG((ENABLE, "released buffer[%lu] @ 0x%08lx\n", i, context.dmabuffer_array[i]));
		}
		RMFree(context.dmabuffer_array);
		context.dmabuffer_index = 0;
		context.dmabuffer_array = NULL;
	}
	
#ifdef WITH_BSAC
	if(context.audio_opt[0].Codec == AudioDecoder_Codec_BSAC)
		FreeDecBuff(BSAC_NCH);
#endif

	if (dcc_info.pMultipleAudioSource) {
		err = DCCStopMultipleAudioSource(dcc_info.pMultipleAudioSource);
		if (RMFAILED(err)) {
			fprintf(stderr, "Error cannot stop audio decoder %d\n", err);
		}		

		err = DCCCloseMultipleAudioSource(dcc_info.pMultipleAudioSource);
		if (RMFAILED(err)) {
			fprintf(stderr, "Error cannot close audio decoder %d\n", err);
		}
	}

	if (context.pDMA != NULL) {
		err = RUAClosePool(context.pDMA);
		if (RMFAILED(err)) {
			fprintf(stderr, "Error cannot close dmapool %d\n", err);
		}
	}

#ifndef WITH_MONO
	err = DCCClose(dcc_info.pDCC);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot close DCC %d\n", err);
	}

	err = RUADestroyInstance(dcc_info.pRUA);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot destroy RUA instance %d\n", err);
		return -1;
	}
#endif /*WITH_MONO*/



	return 0;
}
