/*
 *
 * Copyright (c) Sigma Designs, Inc. 2002. All rights reserved.
 *
 */

/**
	@file play_audio.h
	
	@author Christian Wolff
   	@ingroup mruasamplecode
*/

#define MICROCODE_FILE "../ucode_lib/ucode_audio/microcode_release.bin"

