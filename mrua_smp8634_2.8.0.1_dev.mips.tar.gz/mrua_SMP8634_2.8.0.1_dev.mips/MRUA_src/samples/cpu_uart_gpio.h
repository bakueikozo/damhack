#ifndef _CPU_UART_GPIO_H
#define _CPU_UART_GPIO_H
#include <stdio.h>
#include "../rmdef/rmdef.h"
#include "../emhwlib_hal/include/emhwlib_registers.h"
#include "../llad/include/gbus.h"

enum UART_type{
	UART_RX = 0,
		UART_CTS,
		UART_DSR,
		UART_DCD,
		UART_TXD,
		UART_RTS,
		UART_DTR
};

//void Write_Gpio(enum GPIOId_type pin,RMbool val);
void Write_Gpio_Uart1(enum UART_type pin, RMuint8 ishigh);
void Write_Gpio_Uart0(enum UART_type pin, RMuint8 ishigh);
#endif
