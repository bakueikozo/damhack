



extern void c_malloc_init(struct RUA * rua);
extern void c_malloc_uninit(struct RUA * rua);
extern void * c_malloc( RMuint32 numofbytes );
extern void c_free( void * ptr );

// these are needed for libjpeg in case of tango15
extern void * rua_malloc_large(size_t size);
extern void rua_free_large(void *ptr);



