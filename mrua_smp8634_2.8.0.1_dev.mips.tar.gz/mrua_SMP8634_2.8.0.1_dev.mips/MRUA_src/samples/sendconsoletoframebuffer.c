/*****************************************
 Copyright � 2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>

#include <linux/fb.h>

int main(int argc,char **argv)
{
	int fd;
	int rc;
	struct fb_con2fbmap map;
	char *c;
	
	if (argc<3) {
		fprintf(stderr,"Usage : %s <console> /dev/fb[/]<fb index>\n",argv[0]);
		fprintf(stderr,"        <console> : console to switch (from 1 to 63, 0 for all)\n");
		fprintf(stderr,"        <fbindex> : destination frame buffer\n");
		fprintf(stderr,"Example : %s 5 /dev/fb/1\n",argv[0]);
		return -1;
	}
 
	map.console=atoi(argv[1]);
	c = argv[2]+strlen(argv[2]);
	while (c > argv[2] && (*(c-1)) != 'b' && (*(c-1)) != '/')
		c--;
	map.framebuffer=atoi(c);

	fd=open(argv[2],O_RDONLY);
	if (fd < 0){
		fprintf(stderr, " Error opening %s : %s\n", argv[2], strerror(errno));
		return -1;
	}

	rc=ioctl(fd,FBIOPUT_CON2FBMAP,&map);
	close(fd);

	fprintf(stderr,"con#%d to fb#%d: %s",map.console,map.framebuffer,(rc==0)?"ok\n":"failed");
	if (rc)
		fprintf(stderr, " (%s)\n", strerror(errno));

	return rc;
}
