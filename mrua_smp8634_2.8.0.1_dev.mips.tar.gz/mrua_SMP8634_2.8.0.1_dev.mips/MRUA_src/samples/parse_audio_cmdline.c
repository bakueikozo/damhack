#include "sample_os.h"

#define ALLOW_OS_CODE 1
#include "../rua/include/rua.h"
#include "../dcc/include/dcc.h"
#include "../emhwlib_hal/pll/include/pll_hal.h"
#include "common.h"

// to enable or disable the debug messages of this source file, put 1 or 0 below
#if 1
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

#define NUM_DBC 4  // how many DBCs to allocate

extern RMbool manutest;

typedef struct _chanEntry {
	const char*					szEntryName;
	enum AudioOutputChannels_type	eEntryType;
} CHANNEL_ENTRY;

static CHANNEL_ENTRY	channelTable[] = {
	{	"C",		Audio_Out_Ch_C, },
	{	"LR",		Audio_Out_Ch_LR, },
	{	"LCR",		Audio_Out_Ch_LCR, },
	{	"LRS",		Audio_Out_Ch_LRS, },
	{	"LCRS",		Audio_Out_Ch_LCRS, },
	{	"LRLsRs",	Audio_Out_Ch_LRLsRs, },
	{	"LCRLsRs",	Audio_Out_Ch_LCRLsRs, },
	{	"LCRLsRsSs",	Audio_Out_Ch_LCRLsRsSs, },
	{	"LRLsRsLssRss",	Audio_Out_Ch_LRLsRsLssRss, },
	{	"LCRLsRsLssRss",	Audio_Out_Ch_LCRLsRsLssRss, },
};

#define CHANNELTABLE_NUM_ELEM	(sizeof(channelTable)/sizeof(CHANNEL_ENTRY))
#if 1
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// example of customized downmixing table
// 5.1ch to LoRo output
// Please refer to PostProcInterface.doc
RMuint32 dmx_table_5dot1_to_LR[64] =
{
	0x6A09E66, 0x4AFB0CC*2, 0, 0x4AFB0CC, 0, 0, 0, 0,	//L
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0x4AFB0CC*2, 0x6A09E66, 0, 0x4AFB0CC,	0, 0, 0, //R
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0x6A09E66, 0, 0, //lfe
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0,	
};

// initialize downmixing table
// David
// 4/29/2007
static struct AudioEngine_Downmixing_tables_type audio_dmx_5dot1_to_LR = {
	AudioEngine_dmx_tables_LCRLsRs_2_LoRo,
	(RMuint32)dmx_table_5dot1_to_LR,
};
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#endif

enum AudioOutputChannels_type get_channel_mask(const RMascii* szValue) {
	enum AudioOutputChannels_type	type = Audio_Out_Ch_LR;
	size_t						i;
	RMbool						bFound = FALSE;
	
	for (i = 0 ; i < CHANNELTABLE_NUM_ELEM ; i++) {
		if (strcmp(szValue, channelTable[i].szEntryName) == 0) {
			type = channelTable[i].eEntryType;
			bFound = TRUE;

			break;
		}		
	}

	if (!bFound) {
		fprintf(stderr, "WARNING: Invalid channel mask. Using default [LR]!\n");
	}

	RMDBGLOG((LOCALDBG, "type = %d\n", (int)type));
	
	return type;
}

void show_audio_options(void)
{
	fprintf(stderr, "AUDIO OPTIONS (default values inside brackets)\n"
		"\t-ae audio engine: selects the audio engine (DSP) to be used, 0 or 1 [0]\n"
		"\t-ad audio decoder: selects the audio decoder on the DSP to use. [0]\n"
		"\t-c codec: Sets the codec\n"
		"\t\t[ac3=ac3_20] ac3_32 ec3\n"
		"\t\tbsac\n"
		"\t\tmpeg\n"		
		"\t\t[aac0=adif] [aac1=adts] [aac2=dsi] [aac3=latm]\n"
		"\t\twma wmapro wmats\n"		
		"\t\tdvda\n"
		"\t\t[dts] dts_cd\n"
		"\t\tpcm[24,20,16 = bit per sample]_[1,2,... = channel assign]\n"
		"\t\tlpcm[24,20,16 = bit per sample]_[1,2,... = channel assign]\n"
		"\t\tlpcma[24,20,16 = bit per sample]_[1,2,..= channel assign], \n"
		"\t\tbdlpcm[Bluray LPCM audio]\n"
		"\t\tttone[test tone]\n"
		"\t\tauto\n"
		"\t-lsbfirst used only for audio pcm wave\n"
		"\t-afreq: Sets the output audio frequency [44100]\n"
		"\t-sfg1: Sets sampling frequency of PCM group1 [output frequency].\n"
		"\t-audioin: Configures for pcm audioin function [FALSE]\n"
		"\t-extclk: take audio playback clock from RClk0 input (useful with\n"
		"\t\t-audioin) [FALSE]\n"
		"\t-aialign alignment: align value for the audio input (e.g. 1 for 24\n"
		"\t\tbit, 0 for 32 bit)[1]\n"
		"\t-ailsbfirst: LSB first instead of MSB first on audio input [FALSE]\n"
		"\t-source: capture_source: [0=I2S] 1=SPDIF 2=SPDIF from I2S data pin\n"
		"\t-capture_bts: bitstream number in captured SPDIF stream, [0]..7\n"
		"\t-delay capture_delay: Delay to start capturing [1824]\n"
		"\t-type capture type: 0=Not Specified, 1=PCM, 2=Compressed [PCM]\n"
		"\t-spdif mode: Sets the spdif mode\n"
		"\t\tn=no [u=uncompressed] c=compressed cnd=compressed no decode\n"
		"\t-hdmi_pass: Enable HDMI passthrough mode (compressed audio on I2S)\n"
		"\t-hdmi_lines lines: Set the number of I2S lines to be used for HDMI passthrough, [1]..4\n"
		"\t-hdmi_hbr [<ID>]: Enable HDMI HighBitRate audio, ID: optional 4 bit HBR packet header ID\n"
		"\t-dual mode: [stereo] left right mix\n"
		"\t-lfe: enable LFE channel - for AC3 codec\n"
		"\t-acmod2dual: dual mode for acmod2 - for AC3/AAC/MPEG codec\n"
		"\t-so: Enables/Disables the serial out [1=enable] 0=disable\n"
		"\t-i2salign alignment: align value for the i2s audio output (e.g. 1\n"
		"\t\tfor 24 bit, 0 for 32 bit)[1]\n"
		"\t-i2ssclknormal: don't invert SClk on i2s audio output [FALSE]\n"
		"\t-i2sframenormal: don't invert frame on i2s audio output [FALSE]\n"
		"\t-i2slsbfirst: LSB first instead of MSB first on i2s audio output [FALSE]\n"
		"\t-i2s16bit: 16 bit sample width instead of 32 bit on i2s audio output [FALSE]\n"
		"\t-chan: Sets the channel mask\n"
		"\t\tC [LR] LCR LRS LCRS LRLsRs LCRLsRs\n"
		"\t-unsigned: Unsigned PCM data\n"
		"\t-downsample: For DVD PCM playback protection by converting 24 bit to 16 bit PCM Format\n"
		"\t-afifo size: select the audio bitstream fifo size in KB. Default is application dependent\n"
		"\t-axfer count: select the audio xfer fifo count. Default is application dependent\n"
		"\t-rclkmclk n: provide the current MClk on RClkOut n (0..3)\n"
		"\t-askip_first_n_bytes: bytes to skip when reading the file from the beginning\n"
		"\t-asend_n_bytes: bytes to send\n"
		"\t-bassmode: [0] 0 1 2 3 4 5 6 7\n"
		"\t-afs [0] 1:  let audio uCode parse and set sample frequency from stream\n"
		"\t-channel_delay: [0] 0...7 [0] 0...33, e.g., '-channel 1 23' means put 2.3 ms delay for channel 1\n"
		"\t-audio_cp: set audio copy protection 'C' bit in SPDIF and HDMI audio header\n"
		"\t-channel_status mask value: [0] [0] used to set all bits, including 'C' bit in SPDIF and HDMI audio header\n"
		"\t-mclk <x>: 128 [256] Audio Master Clock factor, either 128*fs or 256*fs\n"
		"\t-audio_hdmi2c: OBSOLETE, do not use.\n"
		"\t\tspeed: optional, I2C bus speed in kHz\n"
		"\t-aplay n: [0] 0-3:0=disable,1=play_from,2=play_to,3=play_from_to\n"
		"\t\t-astart n: [0] 0...MAX(uint64) play start PTS\n"
		"\t\t-astop n: [0] 0...MAX(uint64) play stop PTS\n"
		"\t-ltrt: force LtRt downmix mode\n"
		"\t-ppdmx: to for PostProcessing module to do downmixing\n"
		"\t-centerup: boost 6dB up in certer channel\n"
        "\t-i2s_spdif n: [0] 1,2,3,4 copy i2s data to SPDIF 0=no copy 1=LR 2=CLfe 3=LsRs 4=LssRss\n"
		"\t-ac3compmode mode: 0=analog, 1=digital, 2=line out, 3=RF [line_out]\n"
		"\t-ac3dynhi scale: Dynamic scale hi 4.28 hex representation\n"
		"\t-ac3dynlo scale: Dynamic scale lo 4.28 hex representation\n"
		"\t-ac3pcmscale scale: pcm scale lo 4.28 hex representation\n"
		"\t-x n: [2] 6 8 Channel Config [TrueHD] \n"
		"\t-drc n: [1] 1 2 DRC Enable [TrueHD]\n"
		"\t-boost n: [100] 0-100 DRC Boost [TrueHD]\n"
		"\t-cut n: [100] 0-100  DRC Cut [TrueHD]\n"
		"\t-dialref n: [-31] 1 to -31 DRC DialRef [TrueHD]\n"
		"\t-lossless: Lossless mode [TrueHD]\n"
		"\t-pl2x_mode: ProLogic IIx mode: [3] 0=PLE 1=VC 2=Music 3=Movie 4=Matrix 4=DDEX\n"
		"\t-mute <gpio> <H|L>: GPIO number of the audio mute and polarity when muted\n"
		"\t-cdmx: customized downmixing enable\n"
		"\t-nosync: To disable sync to STC per decoder\n"
		"\t-ttone_type n:[0],1, 0=white noise, 1=other\n"
		"\t-ttone_mask h:[0],Hex, 0=disable, mask in hex, 0x1=left, 0x2=right, 0x4=center 0x8=lfe 0x10=Lss 0x20=Rss 0x40=Lss 0x80=Rss\n"
		);
}

#define DEFAULT_ENGINE  0
#define DEFAULT_DECODER 0
#define DEFAULT_CODEC AudioDecoder_Codec_AC3
#define DEFAULT_SUBCODEC 0xFF
#define DEFAULT_SAMPLE_RATE 44100
#define DEFAULT_SAMPLING_FREQ 0
#define DEFAULT_FORCE_SAMPLE_RATE FALSE
#define DEFAULT_CAPTURE_SOURCE 0
#define DEFAULT_CAPTURE_BITSTREAM 0
#define DEFAULT_CAPTURE_TYPE 1
#define DEFAULT_CAPTURE_DELAY 0
#define DEFAULT_SERIAL_OUT TRUE
#define DEFAULT_EXTERNAL_CLK FALSE
#define DEFAULT_AUDIO_IN FALSE
#define DEFAULT_AUDIO_IN_ALIGN 1
#define DEFAULT_AUDIO_IN_LSB_FIRST FALSE
#define DEFAULT_I2S_ALIGN 1
#define DEFAULT_I2S_SCLK_NORMAL FALSE
#define DEFAULT_I2S_FRAME_NORMAL FALSE
#define DEFAULT_I2S_LSB_FIRST FALSE
#define DEFAULT_I2S_16BIT FALSE
#define DEFAULT_OUTPUT_CHANNEL_EXPLICIT_ASSIGN FALSE
#define DEFAULT_OUTPUT_CHANNELS Audio_Out_Ch_LR
#define DEFAULT_OUTPUT_DUALMODE DualMode_Stereo
#define DEFAULT_SPDIF OutputSpdif_Uncompressed
#define DEFAULT_OUTPUT_LFE FALSE
#define DEFAULT_SIGNED_PCM TRUE
#define DEFAULT_BASSMODE 0

#define DEFAULT_AAC_INPUT_FORMAT 0
#define DEFAULT_AAC_OUTPUT_CHANNELS Aac_LR
#define DEFAULT_AAC_OUTPUT_SURROUND20 SurroundAsStream

#define DEFAULT_AC3_OUTPUT_SURROUND20 SurroundAsStream
#define DEFAULT_AC3_OUTPUT_LFE FALSE
#define DEFAULT_AC3_OUTPUT_CHANNELS Ac3_LR
#define DEFAULT_AC3_ACMOD2DUALMODE FALSE
#define DEFAULT_AC3_COMPMODE CompMode_line_out
#define DEFAULT_AC3_DYN_SCALE_HI 0x10000000
#define DEFAULT_AC3_DYN_SCALE_LO 0x10000000
#define DEFAULT_AC3_PCM_SCALE 0x10000000

#define DEFAULT_PCMCDA_CHANNELS_ASSIGN PcmCda2_LR
#define DEFAULT_PCMCDA_BITS_PER_SAMPLE 24
#define DEFAULT_PCMCDA_MSB_FIRST TRUE
#define DEFAULT_PCMCDA_OUTPUT_SOURROUND20 SurroundAsStream

#define DEFAULT_LPCMVOB_CHANNEL_ASSIGN LpcmVob2_LR
#define DEFAULT_LPCMVOB_BITS_PER_SAMPLE 24
#define DEFAULT_LPCMVOB_DOWNMIX FALSE
#define DEFAULT_LPCMVOB_OUTPUT_SOURROUND20 SurroundAsStream 

#define DEFAULT_LPCMAOB_CHANNEL_ASSIGN LpcmAob20_LR
#define DEFAULT_LPCMAOB_BITS_PER_SAMPLE_GROUP1 24
#define DEFAULT_LPCMAOB_BITS_PER_SAMPLE_GROUP2 24
#define DEFAULT_LPCMAOB_DOWNMIX FALSE
#define DEFAULT_LPCMAOB_GROUP2SHIFT 0
#define DEFAULT_LPCMAOB_PHASELR 0
#define DEFAULT_LPCMAOB_DOWNSAMPLE 0
#define DEFAULT_LPCMAOB_OUTPUT_SOURROUND20 SurroundAsStream

#define DEFAULT_LPCMBD_CHANNEL_ASSIGN PcmCda2_LR
#define DEFAULT_LPCMBD_BITS_PER_SAMPLE 16
#define DEFAULT_LPCMBD_OUTPUT_SOURROUND20 SurroundAsStream

#define DEFAULT_WMA_OUTPUT_CHANNELS Audio_Out_Ch_LR
#define DEFAULT_WMA_VALID_DOWNMIX_COEF FALSE
#define DEFAULT_WMA_DYNAMIC_RANGE_CONTROL Drc_high
#define DEFAULT_WMA_OUTPUT_SOURROUND20 SurroundAsStream

#define DEFAULT_MPEG_OUTPUTSOURROUND20 SurroundAsStream

#define DEFAULT_DTS_OUTPOUT_CHANNELS Dts_LR

#define DEFAULT_FIFO_SIZE 0
#define DEFAULT_XFER_COUNT 0
#define DEFAULT_SKIP_FIRST_N_BYTES 0
#define DEFAULT_MCLK_ON_RCLK 0
#define DEFAULT_TRANSCODE_EC3_TO_AC3 FALSE
#define DEFAULT_AUDIO_FREQ_FROM_STREAM -1
#define DEFAULT_AUTO_DETECT_CODEC FALSE
#define DEFAULT_AUDIO_CP FALSE
#define DEFAULT_INDEPENDENT_PDH FALSE
#define DEFAULT_USE_HDMI FALSE
#define DEFAULT_I2C_MODULE 0
#define DEFAULT_AUDIO_INSTANCES 1


RMstatus init_audio_options(struct audio_cmdline *options)
{
	RMDBGLOG((LOCALDBG, "init_audio_options\n"));

	RMMemset(options, 0, sizeof(struct audio_cmdline));
	
	options->AudioEngineID = 0;
	options->AudioDecoderID = 0;
	options->Codec = AudioDecoder_Codec_AC3;
	options->SubCodec = 0xFF;
	options->SampleRate = 44100;
	options->SamplingFrequency = 0;
	options->ForceSampleRate = FALSE;
	options->CaptureSource = DEFAULT_CAPTURE_SOURCE;
	options->CaptureBitstream = DEFAULT_CAPTURE_BITSTREAM;
	options->CaptureType = DEFAULT_CAPTURE_TYPE;
	options->CaptureDelay = DEFAULT_CAPTURE_DELAY;
	options->SerialOut = TRUE;
	
	options->ExternalClk = FALSE;
	options->ExternalClkFreq = 0;
 	options->AudioIn = FALSE;
 	options->AudioInAlign = 1;
 	options->AudioInLSBfirst = FALSE;
 	
 	options->I2SAlign = 1;
 	options->I2SSClkNormal = FALSE;
 	options->I2SFrameNormal = FALSE;
 	options->I2SLSBFirst = FALSE;
 	options->I2S16Bit = FALSE;

	options->OutputChannelsExplicitAssign = FALSE;
 	options->OutputChannels = Audio_Out_Ch_LR;
	options->OutputDualMode = DualMode_Stereo;
	options->Spdif 		= OutputSpdif_Uncompressed;
	options->dh_info = NULL;
	options->dh_check = TRUE;
	options->HDMIPassThrough = FALSE;
	options->HDMIPassThroughI2SLines = 1;
	options->HBR_Enable = FALSE;  // TRUE if HDMI HighBitRate audio is used (for Dolby TrueHD, e.g.)
	options->HBR_Compressed = TRUE;
	options->HBR_HeaderID = 0x09;  // 4 bit HBR packet header ID
	options->OutputLfe 	= FALSE;
	options->SignedPCM 	= TRUE;
	options->BassMode	= 0;
	options->DownSample = FALSE;	
	
	options->AACParams.InputFormat 		= 0;	// adif, no sync word
//	options->AACParams.OutputLfe 		= FALSE;
	options->AACParams.OutputChannels	= Aac_LR;
	options->AACParams.OutputSurround20 = SurroundAsStream;
	options->AACParams.Acmod2DualMode = FALSE;	

//	options->BSACParams.InputFormat 	= 0;   // similar to AAC
	options->BSACParams.OutputChannels	= Aac_LR;
			
	options->Ac3Params.OutputSurround20 = SurroundAsStream;
	options->Ac3Params.OutputLfe = FALSE;
	options->Ac3Params.OutputChannels = Ac3_LR;
	options->Ac3Params.Acmod2DualMode = FALSE;
	options->Ac3Params.CompMode = CompMode_line_out;
	options->Ac3Params.DynScaleHi = 0x10000000;
	options->Ac3Params.DynScaleLo = 0x10000000;
	options->Ac3Params.PcmScale = 0x10000000;

	options->DtsParams.dts_CD = FALSE;

	options->PcmCdaParams.ChannelAssign = PcmCda2_LR;
	options->PcmCdaParams.BitsPerSample = 24;
	options->PcmCdaParams.MsbFirst = TRUE;
	options->PcmCdaParams.OutputSurround20 = SurroundAsStream;

	options->LpcmVobParams.ChannelAssign = LpcmVob2_LR;
	options->LpcmVobParams.BitsPerSample = 24;
	options->LpcmVobParams.DownMix = FALSE;	// downmixing not yet implemented
	RMMemset(options->LpcmVobParams.CoefLR, 0, sizeof(options->LpcmVobParams.CoefLR));
	options->LpcmVobParams.OutputSurround20 = SurroundAsStream;


	options->LpcmAobParams.ChannelAssign = LpcmAob20_LR;
	options->LpcmAobParams.BitsPerSampleGroup1 = 24;
	options->LpcmAobParams.BitsPerSampleGroup2 = 24;
	options->LpcmAobParams.DownMix = FALSE;	// downmixing not yet implemented
	options->LpcmAobParams.Group2Shift = 0;
	options->LpcmAobParams.PhaseLR = 0;
	options->LpcmAobParams.DownSample = 0; //no downsampling
	RMMemset(options->LpcmAobParams.CoefLR, 0, sizeof(options->LpcmAobParams.CoefLR));
	options->LpcmAobParams.OutputSurround20 = SurroundAsStream;

	options->LpcmBDParams.ChannelAssign = PcmCda2_LR;
	options->LpcmBDParams.BitsPerSample = 16;
	options->LpcmBDParams.OutputSurround20 = SurroundAsStream;

	options->WmaParams.OutputChannels = Audio_Out_Ch_LR;
	options->WmaParams.ValidDownMixCoef = FALSE;
	RMMemset(options->WmaParams.DownMixCoef, 0, sizeof(options->WmaParams.DownMixCoef));
	options->WmaParams.DynamicRangeControl = Drc_high;
	options->WmaParams.OutputSurround20 = SurroundAsStream;
	
	options->MpegParams.OutputSurround20 = SurroundAsStream;
	options->MpegParams.Acmod2DualMode = FALSE;

	options->TToneParams.TToneType = Ttone_WhiteNoise;
	options->TToneParams.TToneChannelMask = 0xff;

	options->DtsParams.OutputChannels = Dts_LR;
	options->DtsParams.OutputSurround20 = SurroundAsStream;

	options->fifo_size = 0;
	options->xfer_count = 0;

	options->skip_first_n_bytes = 0;
	options->send_n_bytes = 0;

	options->mclk_on_rclk = 0;

	options->transcode_ec3_to_ac3 = FALSE;
	
	options->AudioFreqFromStream = 0;  // force afreq

	options->auto_detect_codec = FALSE;
	options->OutputSurround20 = SurroundAsStream;	

	options->AudioCP = FALSE;
	options->mclk = MClkFactor_256Xfs;
	
	options->chconfig=2;
	options->drcenable=1;
	options->drcboost=100;
	options->drccut=100;
	options->drcdialref=-31;
	options->lossless=FALSE;
	options->audio_play_time.PlayMode = 0;
	options->audio_play_time.PlayStartPTS = 0;
	options->audio_play_time.PlayEndPTS = 0;		
	
	options->ppdmx = FALSE;
	options->centerup = FALSE;

  options->PL2xParams.mode = 3;
  options->PL2xParams.a = 0;
  options->PL2xParams.f = 0;
  options->PL2xParams.r = 0;
  options->PL2xParams.t = 0;
  options->PL2xParams.w = 3;
  options->PL2xParams.d = 7;
  options->PL2xParams.x = 0;
  options->PL2xParams.on = 0;
  options->PL2xParams.autoEX = 0;
                                                                                                            
	options->i2s_spdif = 0;

	options->spdifChannelStatus.Mask = 0;   
	options->spdifChannelStatus.Value = 0;
	
	options->mute_enable = FALSE;
	options->ChannelDelay.Delay_ch0 = 0;
	options->ChannelDelay.Delay_ch1 = 0;
	options->ChannelDelay.Delay_ch2 = 0;
	options->ChannelDelay.Delay_ch3 = 0;
	options->ChannelDelay.Delay_ch4 = 0;
	options->ChannelDelay.Delay_ch5 = 0;
	options->ChannelDelay.Delay_ch6 = 0;
	options->ChannelDelay.Delay_ch7 = 0;
	options->mute_gpio = 0;
	options->mute_polarity = FALSE;
	options->thisAudioInstance = 0;
	options->audioInstances = 1;
	options->cdmx_enable = FALSE;
	options->sync_stc = TRUE;
	
	return RM_OK;
}

RMstatus parse_audio_cmdline(int argc, char **argv, int *index, struct audio_cmdline *options)
{
	RMstatus err = RM_PENDING;
	int i = *index;

	if ( ! strcmp(argv[i], "-afs")) {
		if (argc > i+1) {
			options->AudioFreqFromStream = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-ae")) {
		if (argc > i+1) {
			options->AudioEngineID = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-ad")) {
		if (argc > i+1) {
			options->AudioDecoderID = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	} else if ( ! strcmp(argv[i], "-chan")) {
		if (argc > i+1) {

			options->OutputChannels =  get_channel_mask(argv[i+1]);

			options->OutputChannelsExplicitAssign = TRUE;

			i += 2;
			err = RM_OK;
		} else
			err = RM_ERROR;
	} else if (! strcmp(argv[i], "-ac3compmode")) {
		if (argc > i+1) {
			options->Ac3Params.CompMode = (enum Ac3CompMode_type)atoi(argv[i+1]);
			i+=2;
			err = RM_OK;
		} else 
			err = RM_ERROR;
	} else if (! strcmp(argv[i], "-ac3dynhi")) {
		if (argc > i+1) {
			RMuint32	dynhi;
			sscanf((const char*)argv[i+1], (const char*)"0x%08lx", &dynhi);
			options->Ac3Params.DynScaleHi = dynhi;
			i += 2;
			err = RM_OK;
		} else
			err = RM_ERROR;
	} else if (! strcmp(argv[i], "-ac3dynlo")) {
		if (argc > i+1) {
			RMuint32	dynlo;
			sscanf((const char*)argv[i+1], (const char*)"0x%08lx", &dynlo);
			options->Ac3Params.DynScaleLo = dynlo;
			i += 2;
			err = RM_OK;
		} else
			err = RM_ERROR;
	} else if (! strcmp(argv[i], "-ac3pcmscale")) {
		if (argc > i+1) {
			RMuint32	PcmScale;
			sscanf((const char*)argv[i+1], (const char*)"0x%08lx", &PcmScale);
			options->Ac3Params.PcmScale = PcmScale;
			i += 2;
			err = RM_OK;
		} else
			err = RM_ERROR;
	} else if (! strcmp(argv[i], "-ttone_type")){
		if(argc > i+1) {
			RMuint32 ttone_type;
			sscanf((const char*)argv[i+1], (const char*)"0x%lx", &ttone_type);
			options->TToneParams.TToneType = ttone_type;
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (! strcmp(argv[i], "-ttone_mask")){
		if(argc > i+1) {
			RMuint32 ttone_chmask;
			sscanf((const char*)argv[i+1], (const char*)"0x%lx", &ttone_chmask);
			options->TToneParams.TToneChannelMask = ttone_chmask;
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (! strcmp(argv[i], "-c")) {
		if (argc > i+1) {
			if ( !(strcmp(argv[i+1], "auto"))) {
				options->auto_detect_codec = TRUE;
				RMDBGLOG((LOCALDBG, "\n\n\n\n\n********************** AUDIO CODEC: AUTO ***************\n\n\n\n"));
			}
			else if ( ! (strcmp(argv[i+1], "ac3")) || ! (strcmp(argv[i+1], "ac3_20"))) {
				options->Codec = AudioDecoder_Codec_AC3;
				options->Ac3Params.OutputChannels = Ac3_LR;

				if (!options->OutputChannelsExplicitAssign)
					options->OutputChannels	= Audio_Out_Ch_LR;
			} 
			else if ( ! (strcmp(argv[i+1], "ac3_32"))) {
				options->Codec = AudioDecoder_Codec_AC3;
				options->Ac3Params.OutputChannels = Ac3_LCRLsRs;

				if (!options->OutputChannelsExplicitAssign)
					options->OutputChannels	= Audio_Out_Ch_LCRLsRs;
			} 
			else if ( ! (strcmp(argv[i+1], "ec3"))) {
				RMDBGLOG((LOCALDBG, "ec3 codec: will set codec to ac3 and use rmec3transcode lib\n"));
				options->Codec = AudioDecoder_Codec_AC3;
				options->Ac3Params.OutputChannels = Ac3_LR;

				if (!options->OutputChannelsExplicitAssign)
					options->OutputChannels	= Audio_Out_Ch_LR;

				options->transcode_ec3_to_ac3 = TRUE;
			} 
			else if ( ! (strcmp(argv[i+1], "mpeg"))) {
				options->Codec = AudioDecoder_Codec_MPEG1;
			}			
			else if ( ! (strcmp(argv[i+1], "aac0")) || ! (strcmp(argv[i+1], "aac0_20"))) {
				options->Codec = AudioDecoder_Codec_AAC;
				options->AACParams.InputFormat = 0;	// adif, no sync word
				options->AACParams.OutputChannels = Aac_LR;

				if (!options->OutputChannelsExplicitAssign)
					options->OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "aac0_32"))) {
				options->Codec = AudioDecoder_Codec_AAC;
				options->AACParams.InputFormat = 0;	// adif, no sync word
				options->AACParams.OutputChannels = Aac_LCRLsRs;

				if (!options->OutputChannelsExplicitAssign)
					options->OutputChannels	= Audio_Out_Ch_LCRLsRs;
			}
			else if ( ! (strcmp(argv[i+1], "aac1")) || ! (strcmp(argv[i+1], "aac1_20"))) {
				options->Codec = AudioDecoder_Codec_AAC;
				options->AACParams.InputFormat = 1;	// adts, with sync word per frame
				options->AACParams.OutputChannels = Aac_LR;

				if (!options->OutputChannelsExplicitAssign)
					options->OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "aac1_32"))) {
				options->Codec = AudioDecoder_Codec_AAC;
				options->AACParams.InputFormat = 1;	// adts, with sync word per frame
				options->AACParams.OutputChannels = Aac_LCRLsRs;

				if (!options->OutputChannelsExplicitAssign)
					options->OutputChannels	= Audio_Out_Ch_LCRLsRs;
			}

			else if ( ! (strcmp(argv[i+1], "aac2")) || ! (strcmp(argv[i+1], "aac2_20"))) {
				options->Codec = AudioDecoder_Codec_AAC;
				options->AACParams.InputFormat = 2;	// dsi, no sync word
				options->AACParams.OutputChannels = Aac_LR;

				if (!options->OutputChannelsExplicitAssign)
					options->OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "aac2_32"))) {
				options->Codec = AudioDecoder_Codec_AAC;
				options->AACParams.InputFormat = 2;	// dsi, no sync word
				options->AACParams.OutputChannels = Aac_LCRLsRs;

				if (!options->OutputChannelsExplicitAssign)
					options->OutputChannels	= Audio_Out_Ch_LCRLsRs;
			}
			else if ( ! (strcmp(argv[i+1], "aac3")) || ! (strcmp(argv[i+1], "aac3_20"))) {
				options->Codec = AudioDecoder_Codec_AAC;
				options->AACParams.InputFormat = 3;	// latm, with sync word per multi-frames
				options->AACParams.OutputChannels = Aac_LR;

				if (!options->OutputChannelsExplicitAssign)
					options->OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "bsac"))) {
				options->Codec = AudioDecoder_Codec_BSAC;
				options->BSACParams.OutputChannels = Aac_LR;
			}
			else if ( ! (strcmp(argv[i+1], "pcm24")) || ! (strcmp(argv[i+1], "pcm24_2"))) {
				options->Codec = AudioDecoder_Codec_PCM;
				options->SubCodec = 0;
				options->PcmCdaParams.ChannelAssign = PcmCda2_LR;
				options->PcmCdaParams.BitsPerSample = 24;

				if (!options->OutputChannelsExplicitAssign)
					options->OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "pcmx"))) { //pcmx codec, all information need to be written in header
				options->Codec = AudioDecoder_Codec_PCMX;
			}
			else if ( ! (strcmp(argv[i+1], "pcm24_6"))) {
				options->Codec = AudioDecoder_Codec_PCM;
				options->SubCodec = 0;
				options->PcmCdaParams.ChannelAssign = PcmCda6_LfRfCLfeLsRs;
				options->PcmCdaParams.BitsPerSample = 24;

				if (!options->OutputChannelsExplicitAssign)
					options->OutputChannels	= Audio_Out_Ch_LCRLsRs;
			}
			else if ( ! (strcmp(argv[i+1], "pcm16_2"))) {
				options->Codec = AudioDecoder_Codec_PCM;
				options->SubCodec = 0;
				options->PcmCdaParams.ChannelAssign = PcmCda2_LR;
				options->PcmCdaParams.BitsPerSample = 16;

				if (!options->OutputChannelsExplicitAssign)
					options->OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "pcm16_1"))) {
				options->Codec = AudioDecoder_Codec_PCM;
				options->SubCodec = 0;
				options->PcmCdaParams.ChannelAssign = PcmCda1_C;
				options->PcmCdaParams.BitsPerSample = 16;

				if (!options->OutputChannelsExplicitAssign)
					options->OutputChannels	= Audio_Out_Ch_LR;
			}
		 	else if ( ! (strcmp(argv[i+1], "pcm16_6"))) {
				options->Codec = AudioDecoder_Codec_PCM;
				options->SubCodec = 0;
				options->PcmCdaParams.ChannelAssign = PcmCda6_LfRfCLfeLsRs;
				options->PcmCdaParams.BitsPerSample = 16;

				if (!options->OutputChannelsExplicitAssign)
					options->OutputChannels	= Audio_Out_Ch_LCRLsRs;
			}
			else if ( ! (strcmp(argv[i+1], "pcm8_2"))) {
				options->Codec = AudioDecoder_Codec_PCM;
				options->SubCodec = 0;
				options->PcmCdaParams.ChannelAssign = PcmCda2_LR;
				options->PcmCdaParams.BitsPerSample = 8;

				if (!options->OutputChannelsExplicitAssign)
					options->OutputChannels = Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "pcm8_1"))) {
				options->Codec = AudioDecoder_Codec_PCM;
				options->SubCodec = 0;
				options->PcmCdaParams.ChannelAssign = PcmCda1_C;
				options->PcmCdaParams.BitsPerSample = 8;

				if (!options->OutputChannelsExplicitAssign)
					options->OutputChannels	= Audio_Out_Ch_LR;							
			}
			else if ( ! (strcmp(argv[i+1], "lpcm24")) || ! (strcmp(argv[i+1], "lpcm24_2"))) {
				options->Codec = AudioDecoder_Codec_PCM;
				options->SubCodec = 1;
				options->LpcmVobParams.ChannelAssign = LpcmVob2_LR;
				options->LpcmVobParams.BitsPerSample = 24;

				if (!options->OutputChannelsExplicitAssign)
					options->OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "lpcm20")) || ! (strcmp(argv[i+1], "lpcm20_2"))) {
				options->Codec = AudioDecoder_Codec_PCM;
				options->SubCodec = 1;
				options->LpcmVobParams.ChannelAssign = LpcmVob2_LR;
				options->LpcmVobParams.BitsPerSample = 20;

				if (!options->OutputChannelsExplicitAssign)
					options->OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "lpcm16")) || ! (strcmp(argv[i+1], "lpcm16_2"))) {
				options->Codec = AudioDecoder_Codec_PCM;
				options->SubCodec = 1;
				options->LpcmVobParams.ChannelAssign = LpcmVob2_LR;
				options->LpcmVobParams.BitsPerSample = 16;

				if (!options->OutputChannelsExplicitAssign) {
					options->OutputChannels	= Audio_Out_Ch_LR;
					RMDBGLOG((LOCALDBG, ">>>>>>>>>>>>lpcm16_2 Cmdline Speaker Configure = %0x\n", options->OutputChannels));
				}
			}
			else if ( ! (strcmp(argv[i+1], "lpcm16_1"))) {
				options->Codec = AudioDecoder_Codec_PCM;
				options->SubCodec = 1;
				options->LpcmVobParams.ChannelAssign = LpcmVob1_C;
				options->LpcmVobParams.BitsPerSample = 16;

				if (!options->OutputChannelsExplicitAssign)
					options->OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "lpcma24")) || ! (strcmp(argv[i+1], "lpcma24_2"))) {
				options->Codec = AudioDecoder_Codec_PCM;
				options->SubCodec = 2;
				options->LpcmAobParams.ChannelAssign = LpcmAob20_LR;
				options->LpcmAobParams.BitsPerSampleGroup1 = 24;
				options->LpcmAobParams.BitsPerSampleGroup2 = 0;

				if (!options->OutputChannelsExplicitAssign)
					options->OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "lpcma16_2"))) {
				options->Codec = AudioDecoder_Codec_PCM;
				options->SubCodec = 2;
				options->LpcmAobParams.ChannelAssign = LpcmAob20_LR;
				options->LpcmAobParams.BitsPerSampleGroup1 = 16;
				options->LpcmAobParams.BitsPerSampleGroup2 = 0;

				if (!options->OutputChannelsExplicitAssign)
					options->OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "lpcma16_1"))) {
				options->Codec = AudioDecoder_Codec_PCM;
				options->SubCodec = 2;
				options->LpcmAobParams.ChannelAssign = LpcmAob10_C;
				options->LpcmAobParams.BitsPerSampleGroup1 = 16;
				options->LpcmAobParams.BitsPerSampleGroup2 = 0;

				if (!options->OutputChannelsExplicitAssign)
					options->OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "bdlpcm")) ) {
				// Bluray LPCM audio
				options->Codec = AudioDecoder_Codec_PCM;
				options->SubCodec = 3;
				options->PcmCdaParams.ChannelAssign = PcmCda2_LR;
				options->PcmCdaParams.BitsPerSample = 16;

				if (!options->OutputChannelsExplicitAssign)
					options->OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "wmapro")) ) {
				options->Codec = AudioDecoder_Codec_WMAPRO;
			} 
			else if ( ! (strcmp(argv[i+1], "wma"))) {
				options->Codec = AudioDecoder_Codec_WMA;
			} 
			else if ( ! (strcmp(argv[i+1], "wmats"))) {
				options->Codec = AudioDecoder_Codec_WMA;
				options->WmaParams.VersionNumber = 0x7a23;
			} 
			else if ( ! (strcmp(argv[i+1], "dts"))) {
				options->Codec = AudioDecoder_Codec_DTS;
			} 
			else if ( ! (strcmp(argv[i+1], "dts_cd"))) {
				options->Codec = AudioDecoder_Codec_DTS;
				options->DtsParams.dts_CD	= TRUE;
			} 
			else if ( ! (strcmp(argv[i+1], "dts_20"))) {
				options->Codec = AudioDecoder_Codec_DTS;
/* 				options->OutputChannels = Channel_LR; */
				options->DtsParams.OutputChannels	= Dts_LR;
			}
			else if ( ! (strcmp(argv[i+1], "dts_32"))) {
				options->Codec = AudioDecoder_Codec_DTS;
/* 				options->OutputChannels = Audio_Out_Ch_LCRLsRs; */
				options->DtsParams.OutputChannels = Dts_LCRLsRs;
			}
			else if ( ! (strcmp(argv[i+1], "dvda"))) {
				options->Codec = AudioDecoder_Codec_DVDA;
			} 
			else if ( ! (strcmp(argv[i+1], "ttone"))) {
				RMDBGLOG((ENABLE, "\n&&&&&\nTTONE select\n&&&&&\n"));
				options->Codec = AudioDecoder_Codec_TTONE;
			}
			else {
				err = RM_ERROR;
			}
		}
		else
			err = RM_ERROR;
		
		if (err != RM_ERROR)
			err = RM_OK;
		i+=2;
	}
	else if ( ! strcmp(argv[i], "-afreq")) {
		if (argc > i+1) {
			options->SampleRate = strtol(argv[i+1], NULL, 10);
			/* if the user specified the samplerate at cmdline, we force it over the value found on the dsi */
			options->ForceSampleRate = TRUE;
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-sfg1")) {
		if (argc > i+1) {
			options->SamplingFrequency = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-extclk")) {
		options->ExternalClk = TRUE;
		i++;
		if ((i < argc) && (argv[i][0] != '-')) {
			options->ExternalClkFreq = strtol(argv[i], NULL, 10);
			i++;
		}
		err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-aplay")) {
			if (argc > i+1) {
				options->audio_play_time.PlayMode = strtol(argv[i+1], NULL, 10);
				i+=2;
				err = RM_OK;
			}
			else
				err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-astart")) {
			if (argc > i+1) {
			  RMuint64 startPTS;
			  sscanf((const char*)argv[i+1], (const char*)"%llu", &startPTS);
			  options->audio_play_time.PlayStartPTS = startPTS; 
				i+=2;
				err = RM_OK;
			}
			else
				err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-astop")) {
			if (argc > i+1) {
			  RMuint64 stopPTS;
			  sscanf((const char*)argv[i+1], (const char*)"%llu", &stopPTS);
				options->audio_play_time.PlayEndPTS = stopPTS;
				i+=2;
				err = RM_OK;
			}
			else
				err = RM_ERROR;
	}

	else if ( ! strcmp(argv[i], "-ppdmx")) {
				options->ppdmx = TRUE;
				i++;
				err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-centerup")) {
				options->centerup = TRUE;
				i++;
				err = RM_OK;
	}
    else if ( ! strcmp(argv[i], "-i2s_spdif")) {
                if (argc > i+1) {
                        RMuint32 nI2S = strtol(argv[i+1], NULL, 10);
                        if (nI2S > 4)
                                nI2S = 0;
                        options->i2s_spdif = nI2S;
                                                                                                                                 
                        i+=2;
                        err = RM_OK;
                }
                else
                        err = RM_ERROR;
        }
	else if ( ! strcmp(argv[i], "-ltrt")) {
				options->OutputSurround20 = SurroundEnable;
				i++;		
				err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-cdmx")) {
				options->cdmx_enable = TRUE;
				i++;		
				err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-nosync")) {
				options->sync_stc = FALSE;
				i++;		
				err = RM_OK;
	}
  	else if (RMCompareAscii(argv[i], "-x")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options->chconfig));
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-drc")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options->drcenable));
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-boost")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options->drcboost));
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-cut")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options->drccut));
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-dialref")) {
		if (argc > i+1) {
			RMasciiToInt32(argv[i+1], &(options->drcdialref));
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-lossless")) {
		options->lossless = TRUE;
		i++;
		err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-audioin")) {
		printf("(((((((((((((********************* 2 *******************))))))))\n");

		options->AudioIn = TRUE;
		options->Codec = AudioDecoder_Codec_PCM;
		options->SubCodec = 0;
		options->PcmCdaParams.ChannelAssign = PcmCda2_LR;
		options->PcmCdaParams.BitsPerSample = 16;	//24;
		options->PcmCdaParams.MsbFirst = TRUE;
		i++;
		err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-aialign")) {
		if (argc > i+1) {
			options->AudioInAlign = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-ailsbfirst")) {
		options->AudioInLSBfirst = TRUE;
		i++;
		err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-i2salign")) {
		if (argc > i+1) {
			options->I2SAlign = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-i2ssclknormal")) {
		options->I2SSClkNormal = TRUE;
		i++;
		err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-i2sframenormal")) {
		options->I2SFrameNormal = TRUE;
		i++;
		err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-i2slsbfirst")) {
		options->I2SLSBFirst = TRUE;
		i++;
		err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-i2s16bit")) {
		options->I2S16Bit = TRUE;
		i++;
		err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-source")) {
		if (argc > i+1) {
			options->CaptureSource = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-capture_bts")) {
		if (argc > i+1) {
			options->CaptureBitstream = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
  	else if ( ! strcmp(argv[i], "-channel_delay")) {
		if (argc > i+2) {
			RMint32 ch = strtol(argv[i+1], NULL, 10);
			if(ch < 0 || ch > 7){
				err = RM_ERROR;
			}
			else{
				switch(ch){
				  case 0:
					options->ChannelDelay.Delay_ch0 = strtol(argv[i+2], NULL, 10);
					RMDBGLOG((LOCALDBG, "DELAY for CH0 is %d\n", options->ChannelDelay.Delay_ch0));
					break;
				  case 1:
					options->ChannelDelay.Delay_ch1 = strtol(argv[i+2], NULL, 10); break;
				  case 2:
					options->ChannelDelay.Delay_ch2 = strtol(argv[i+2], NULL, 10); break;
				  case 3:
					options->ChannelDelay.Delay_ch3 = strtol(argv[i+2], NULL, 10); break;
				  case 4:
					options->ChannelDelay.Delay_ch4 = strtol(argv[i+2], NULL, 10); break;
				  case 5:
					options->ChannelDelay.Delay_ch5 = strtol(argv[i+2], NULL, 10); break;
				  case 6:
					options->ChannelDelay.Delay_ch6 = strtol(argv[i+2], NULL, 10); break;
				  case 7:
					options->ChannelDelay.Delay_ch7 = strtol(argv[i+2], NULL, 10); break;
				}
			  i+=3;
			  err = RM_OK;
			}
		}
		else
			err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-pl2x_mode")) {
		if (argc > i+1) {
		options->PL2xParams.mode = strtol(argv[i+1], NULL, 10);
		i+=2;
		err = RM_OK;
		}
		else 
			err = RM_ERROR;
	} 
	else if ( ! strcmp(argv[i], "-pl2x")) {
		options->PL2xParams.on = TRUE;
		i++;
		err = RM_OK;
	} 
	else if ( ! strcmp(argv[i], "-pl2x_autoEX")) {
		options->PL2xParams.autoEX = TRUE;
		i++;
		err = RM_OK;
	} 
	else if ( ! strcmp(argv[i], "-pl2x_autobal_off")) {
		options->PL2xParams.a = TRUE;
		i++;
		err = RM_OK;
	} 
	else if ( ! strcmp(argv[i], "-pl2x_ShelfFilter")) {
		options->PL2xParams.f = TRUE;
		i++;
		err = RM_OK;
	} 
	else if ( ! strcmp(argv[i], "-pl2x_RsPolarity")) {
		options->PL2xParams.r = TRUE;
		i++;
		err = RM_OK;
	} 
	else if ( ! strcmp(argv[i], "-pl2x_Panorama")) {
		options->PL2xParams.t = TRUE;
		i++;
		err = RM_OK;
	} 
	else if ( ! strcmp(argv[i], "-pl2x_CenterWidth")) {
		if (argc > i+1) {
		options->PL2xParams.w = strtol(argv[i+1], NULL, 10);
		i+=2;
		err = RM_OK;
		}
		else 
			err = RM_ERROR;
	} 
	else if ( ! strcmp(argv[i], "-pl2x_InvMatrix")) {
		options->PL2xParams.x = TRUE;
		i++;
		err = RM_OK;
	} 
	else if ( ! strcmp(argv[i], "-pl2x_DimCtrl")) {
		if (argc > i+1) {
		options->PL2xParams.d = strtol(argv[i+1], NULL, 10);
		i+=2;
		err = RM_OK;
		}
		else 
			err = RM_ERROR;
	} 
	else if ( ! strcmp(argv[i], "-type")) {
		if (argc > i+1) {
			options->CaptureType = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-delay")) {
		if (argc > i+1) {
			options->CaptureDelay = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-spdif")) {
		if (argc > i+1) {
			if      (! strcmp(argv[i+1], "n"))   options->Spdif = OutputSpdif_Disable;
			else if (! strcmp(argv[i+1], "u"))   options->Spdif = OutputSpdif_Uncompressed;
			else if (! strcmp(argv[i+1], "c"))   options->Spdif = OutputSpdif_Compressed;
			else if (! strcmp(argv[i+1], "cnd")) options->Spdif = OutputSpdif_NoDecodeCompressed;
			else 
				err = RM_ERROR;
		}
		else
			err = RM_ERROR;

		if (err != RM_ERROR)
			err = RM_OK;
		i+=2;
	}
	else if ( ! strcmp(argv[i], "-hdmi_pass")) {
		options->HDMIPassThrough = TRUE;
		options->Spdif = OutputSpdif_Compressed;
		i++;
		err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-hdmi_lines")) {
		if (argc > i+1) {
			options->HDMIPassThroughI2SLines = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-hdmi_hbr")) {
		options->HBR_Enable = TRUE;
		options->HBR_Compressed = TRUE;
		i++;
		if ((argc > i) && (argv[i][0] != '-')) {
			options->HBR_HeaderID = strtol(argv[i], NULL, 10);
			i++;
		}
		err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-so")) {
		if (argc > i+1) {
			options->SerialOut = (strtol(argv[i+1], NULL, 10)) ? TRUE : FALSE;
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if ( ! (strcmp(argv[i], "-dual"))) {
		if (argc > i+1) {
			if ( ! (strcmp(argv[i+1], "stereo"))) {
				options->OutputDualMode = DualMode_Stereo;
			} 
			else if ( ! (strcmp(argv[i+1], "left"))) {
				options->OutputDualMode = DualMode_LeftMono;
			} 
			else if ( ! (strcmp(argv[i+1], "right"))) {
				options->OutputDualMode = DualMode_RightMono;
			} 
			else if ( ! (strcmp(argv[i+1], "mix"))) {
				options->OutputDualMode = DualMode_MixMono;
			}
			else 
				err = RM_ERROR;
		}
		else
			err = RM_ERROR;

		if (err != RM_ERROR)
			err = RM_OK;
		i+=2;
	}
	else if ( ! (strcmp(argv[i], "-lsbfirst"))) {
		options->PcmCdaParams.MsbFirst = FALSE;
		i++;
		err = RM_OK;
	}
	else if ( ! (strcmp(argv[i], "-lfe"))) {
//		options->Ac3Params.OutputLfe = TRUE;
		options->OutputLfe = TRUE;
		i++;
		err = RM_OK;
	}
	else if ( ! (strcmp(argv[i], "-acmod2dual"))) {
		options->Ac3Params.Acmod2DualMode = TRUE;
		options->MpegParams.Acmod2DualMode = TRUE;
		options->AACParams.Acmod2DualMode = TRUE;

		RMDBGLOG((LOCALDBG, "!!!!!!!!!!!!! Set acmod2dual \n"));
		i++;
		err = RM_OK;
	}
	else if ( ! (strcmp(argv[i], "-downsample"))) {
		options->LpcmAobParams.DownSample = TRUE;	
		options->DownSample = TRUE;	
		i++;
		err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-unsigned")) {
		RMDBGLOG((LOCALDBG, ">>>>>>>>>>>>Unsigned PCM is set\n"));
		options->SignedPCM = FALSE;
		i++;
		err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-bassmode")) {
		RMDBGLOG((LOCALDBG, ">>>>>>>>>>>>BassMode is set\n"));
		if (argc > i+1) {
			options->BassMode = strtol(argv[i+1], NULL, 10);
		}
		else 
			err = RM_ERROR;
		
		i+=2;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-afifo")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options->fifo_size));
			options->fifo_size *= 1024;
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-axfer")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options->xfer_count));
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-askip_first_n_bytes")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options->skip_first_n_bytes));
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-asend_n_bytes")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options->send_n_bytes));
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-rclkmclk")) {
		if (argc > i+1) {
			RMuint32 n;
			RMasciiToUInt32(argv[i+1], &n);
			options->mclk_on_rclk = (enum ClockSignal)(ClockSignal_RClk0 + n);
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-audio_cp")) {
		options->AudioCP = TRUE;
		i++;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-channel_status")) {
		if (argc > i+2) {
			RMuint32 mask;
			RMuint32 value;

			RMasciiToUInt32(argv[i+1], &mask);
			RMDBGLOG((LOCALDBG, "***SPDIF*** MASK = 0x%08x\n", mask));

			RMasciiToUInt32(argv[i+2], &value);
			RMDBGLOG((LOCALDBG, "***SPDIF*** VALUE = 0x%08x\n", value));

			options->spdifChannelStatus.Mask = mask;
			options->spdifChannelStatus.Value = value;			

			i += 3;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-mclk")) {
		if (argc > i+1) {
			RMuint32 n;
			RMasciiToUInt32(argv[i+1], &n);
			options->mclk = (n == 128) ? MClkFactor_128Xfs : MClkFactor_256Xfs;
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-audio_hdmi2c")) {
		fprintf(stderr, "WARNING: -audio_hdmi2c is OBSOLETE. Do not use it anymore.\n");
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-mute")) {
		if (argc > i + 2) {
			RMuint32 gpio;
			options->mute_enable = TRUE;
			RMasciiToUInt32(argv[i+1], &gpio);
			options->mute_gpio = (enum GPIOId_type)gpio;
			options->mute_polarity = ((argv[i+2][0]=='1')||(argv[i+2][0]=='h')||(argv[i+2][0]=='H'));
			i += 3;
			err = RM_OK;
		}
		else err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-audio_hdmi_ddc_tx")) {
		fprintf(stderr, "WARNING: -audio_hdmi_ddc_tx is OBSOLETE. Do not use it anymore.\n");
		err = RM_OK;
	}
	
	*index = i;

	RMDBGLOG((LOCALDBG, ">>>>>>>>>>>>Cmdline Speaker Configure = %0x\n", options->OutputChannels));
	
	return err;
}



RMstatus init_audio_options2(struct audio_cmdline options[], RMuint32 entries)
{
	RMuint32 i;
	
	for (i = 0; i < entries; i++) {
		RMDBGLOG((LOCALDBG, "set default options for instance %lu (@0x%lx)\n", i, (RMuint32)(options + i)));

		init_audio_options( (options + i) );

		options[i].thisAudioInstance = i; // this, while handy, forces you to be carefull when copying this data structure...
		options[i].audioInstances = 1;
	}
	
	return RM_OK;
}

RMstatus print_parsed_audio_options(struct audio_cmdline options[])
{
	RMuint32 instances = options[0].audioInstances;
	RMuint32 i;

	RMDBGPRINT((ENABLE, "print_parsed_audio_options\n"));

	for (i = 0; i < instances; i++) {
		RMDBGPRINT((ENABLE, "audio options for instance %lu (id %lu, total %lu)\n", i, options[i].thisAudioInstance, options[i].audioInstances));
		RMDBGPRINT((ENABLE, "\tengine 0x%lx %s\n", options[i].AudioEngineID, options[i].AudioEngineID == DEFAULT_ENGINE ? "(default)":""));

		RMDBGPRINT((ENABLE, "\tdecoder 0x%lx %s\n", options[i].AudioDecoderID, options[i].AudioDecoderID == DEFAULT_DECODER ? "(default)":""));

		RMDBGPRINT((ENABLE, "fifo size %lu\n", options[i].fifo_size));
		RMDBGPRINT((ENABLE, "fifo count %lu\n", options[i].xfer_count));

		RMDBGPRINT((ENABLE, "\tcodec 0x%lx %s\n", options[i].Codec, options[i].Codec == DEFAULT_CODEC ? "(default)":""));
		RMDBGPRINT((ENABLE, "\tsubCodec 0x%lx %s\n", options[i].SubCodec, options[i].SubCodec == DEFAULT_SUBCODEC ? "(default)":""));
		RMDBGPRINT((ENABLE, "\tsampleRate 0x%lx (%lu) %s\n", options[i].SampleRate, options[i].SampleRate, options[i].SampleRate == DEFAULT_SAMPLE_RATE ? "(default)":""));

		RMDBGPRINT((ENABLE, "\tsamplingFreq 0x%lx %s\n", options[i].SamplingFrequency, options[i].SamplingFrequency == DEFAULT_SAMPLING_FREQ ? "(default)":""));
		RMDBGPRINT((ENABLE, "\tforceSampleRate 0x%lx %s\n", options[i].ForceSampleRate, options[i].ForceSampleRate == DEFAULT_FORCE_SAMPLE_RATE ? "(default)":""));
		RMDBGPRINT((ENABLE, "\tcaptureSource 0x%lx %s\n", options[i].CaptureSource, options[i].CaptureSource == DEFAULT_CAPTURE_SOURCE ? "(default)":""));
		RMDBGPRINT((ENABLE, "\tcaptureBitstream 0x%lx %s\n", options[i].CaptureBitstream, options[i].CaptureBitstream == DEFAULT_CAPTURE_BITSTREAM ? "(default)":""));
		RMDBGPRINT((ENABLE, "\tcaptureType 0x%lx %s\n", options[i].CaptureType, options[i].CaptureType == DEFAULT_CAPTURE_TYPE ? "(default)":""));
		RMDBGPRINT((ENABLE, "\tcaptureDelay 0x%lx %s\n", options[i].CaptureDelay, options[i].CaptureDelay == DEFAULT_CAPTURE_DELAY ? "(default)":""));
		RMDBGPRINT((ENABLE, "\tserialOut 0x%lx %s\n", options[i].SerialOut, options[i].SerialOut == DEFAULT_SERIAL_OUT ? "(default)":""));
		RMDBGPRINT((ENABLE, "\texternalClk 0x%lx %s\n", options[i].ExternalClk, options[i].ExternalClk == DEFAULT_EXTERNAL_CLK ? "(default)":""));
		RMDBGPRINT((ENABLE, "\taudioIn 0x%lx %s\n", options[i].AudioIn, options[i].AudioIn == DEFAULT_AUDIO_IN ? "(default)":""));
		RMDBGPRINT((ENABLE, "\taudioInAlign 0x%lx %s\n", options[i].AudioInAlign, options[i].AudioInAlign == DEFAULT_AUDIO_IN_ALIGN ? "(default)":""));
		RMDBGPRINT((ENABLE, "\taudioInLSBFirst 0x%lx %s\n", options[i].AudioInLSBfirst, options[i].AudioInLSBfirst == DEFAULT_AUDIO_IN_LSB_FIRST ? "(default)":""));
		RMDBGPRINT((ENABLE, "\tI2SAlign 0x%lx %s\n", options[i].I2SAlign, options[i].I2SAlign == DEFAULT_I2S_ALIGN ? "(default)":""));
		RMDBGPRINT((ENABLE, "\tI2SSClkNormal 0x%lx %s\n", options[i].I2SSClkNormal, options[i].I2SSClkNormal == DEFAULT_I2S_SCLK_NORMAL ? "(default)":""));
		RMDBGPRINT((ENABLE, "\tI2SFrameNormal 0x%lx %s\n", options[i].I2SFrameNormal, options[i].I2SFrameNormal == DEFAULT_I2S_FRAME_NORMAL ? "(default)":""));
		RMDBGPRINT((ENABLE, "\tI2SLSBFirst 0x%lx %s\n", options[i].I2SLSBFirst, options[i].I2SLSBFirst == DEFAULT_I2S_LSB_FIRST ? "(default)":""));


#if 0
		options[i].I2SAlign = 1;
		options[i].I2SSClkNormal = FALSE;
		options[i].I2SFrameNormal = FALSE;
		options[i].I2SLSBFirst = FALSE;
		options[i].I2S16Bit = FALSE;
		
		options[i].OutputChannelsExplicitAssign = FALSE;
		options[i].OutputChannels = Audio_Out_Ch_LR;
		options[i].OutputDualMode = DualMode_Stereo;
		options[i].Spdif 		= OutputSpdif_Uncompressed;
		options[i].HDMIPassThrough = FALSE;
		options[i].HDMIPassThroughI2SLines = 1;
		options[i].HBR_Enable = FALSE;  // TRUE if HDMI HighBitRate audio is used (for Dolby TrueHD, e.g.)
		options[i].HBR_Compressed = TRUE;
		options[i].HBR_HeaderID = 0x09;  // 4 bit HBR packet header ID
		options[i].OutputLfe 	= FALSE;
		options[i].SignedPCM 	= TRUE;
		options[i].BassMode	= 0;
		
		options[i].AACParams.InputFormat 		= 0;	// adif, no sync word
		//	options[i].AACParams.OutputLfe 		= FALSE;
		options[i].AACParams.OutputChannels	= Aac_LR;
		options[i].AACParams.OutputSurround20 = SurroundAsStream;
		options[i].AACParams.Acmod2DualMode = FALSE;

		options[i].Ac3Params.OutputSurround20 = SurroundAsStream;
		options[i].Ac3Params.OutputLfe = FALSE;
		options[i].Ac3Params.OutputChannels = Ac3_LR;
		options[i].Ac3Params.Acmod2DualMode = FALSE;
		options[i].Ac3Params.CompMode = CompMode_line_out;
		options[i].Ac3Params.DynScaleHi = 0x10000000;
		options[i].Ac3Params.DynScaleLo = 0x10000000;
		options[i].Ac3Params.PcmScale = 0x10000000;
		
		options[i].PcmCdaParams.ChannelAssign = PcmCda2_LR;
		options[i].PcmCdaParams.BitsPerSample = 24;
		options[i].PcmCdaParams.MsbFirst = TRUE;
		options[i].PcmCdaParams.OutputSurround20 = SurroundAsStream;
		
		options[i].LpcmVobParams.ChannelAssign = LpcmVob2_LR;
		options[i].LpcmVobParams.BitsPerSample = 24;
		options[i].LpcmVobParams.DownMix = FALSE;	// downmixing not yet implemented
		RMMemset(options[i].LpcmVobParams.CoefLR, 0, sizeof(options[i].LpcmVobParams.CoefLR));
		options[i].LpcmVobParams.OutputSurround20 = SurroundAsStream;
		
		
		options[i].LpcmAobParams.ChannelAssign = LpcmAob20_LR;
		options[i].LpcmAobParams.BitsPerSampleGroup1 = 24;
		options[i].LpcmAobParams.BitsPerSampleGroup2 = 24;
		options[i].LpcmAobParams.DownMix = FALSE;	// downmixing not yet implemented
		options[i].LpcmAobParams.Group2Shift = 0;
		options[i].LpcmAobParams.PhaseLR = 0;
		options[i].LpcmAobParams.DownSample = 0; //no downsampling
		RMMemset(options[i].LpcmAobParams.CoefLR, 0, sizeof(options[i].LpcmAobParams.CoefLR));
		options[i].LpcmAobParams.OutputSurround20 = SurroundAsStream;
		
		options[i].LpcmBDParams.ChannelAssign = PcmCda2_LR;
		options[i].LpcmBDParams.BitsPerSample = 16;
		options[i].LpcmBDParams.OutputSurround20 = SurroundAsStream;
		
		options[i].WmaParams.OutputChannels = Audio_Out_Ch_LR;
		options[i].WmaParams.ValidDownMixCoef = FALSE;
		RMMemset(options[i].WmaParams.DownMixCoef, 0, sizeof(options[i].WmaParams.DownMixCoef));
		options[i].WmaParams.DynamicRangeControl = Drc_high;
		options[i].WmaParams.OutputSurround20 = SurroundAsStream;
		
		
		options[i].MpegParams.OutputSurround20 = SurroundAsStream;
		options[i].MpegParams.Acmod2DualMode = FALSE;
		
		options[i].DtsParams.OutputChannels = Dts_LR;
		options[i].fifo_size = 0;
		options[i].xfer_count = 0;
		
		options[i].skip_first_n_bytes = 0;
		
		options[i].mclk_on_rclk = 0;
		
		options[i].transcode_ec3_to_ac3 = FALSE;
		
		options[i].AudioFreqFromStream = 0;  // force afreq
		
		options[i].auto_detect_codec = FALSE;
		
		options[i].AudioCP = FALSE;
		options[i].mclk = MClkFactor_256Xfs;
		
		options[i].thisAudioInstance = i;
		options[i].audioInstances = 1;
#endif

	}
	return RM_OK;
}

/* *****************************
   this api will soon change to:
   RMstatus parse_audio_cmdline(int argc, char **argv, int *index, struct audio_cmdline *options, RMuint32 optionsCount, RMuint32 *currentInstance)
*/

RMstatus parse_audio_cmdline2(int argc, char **argv, int *index, struct audio_cmdline options[], RMuint32 optionsCount, RMuint32 *currentInstance)
{
	RMstatus err = RM_PENDING;
	int i = *index;

	RMDBGLOG((DISABLE, "parsing option[%lu]='%s'\n", i, argv[i]));

	if ( ! strcmp(argv[i], "-audio_instance")) {
		if (argc > i+1) {
			RMuint32 instance;

			instance = strtol(argv[i+1], NULL, 10);
			i += 2;

			if (*currentInstance != instance) {
				RMuint32 j, totalInstances;

				totalInstances = options[0].audioInstances;
				totalInstances++;

				if (totalInstances > optionsCount)
					err = RM_ERROR;
				else {
					for (j = 0; j < totalInstances; j++)
						options[j].audioInstances = totalInstances;
					
					*currentInstance = instance;
					RMDBGLOG((LOCALDBG, "parsing instance %lu\n", *currentInstance));
				}
			}
			else
				RMDBGLOG((LOCALDBG, "already parsing instance %lu\n", *currentInstance));
			
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}	
	else if ( ! strcmp(argv[i], "-afs")) {
		if (argc > i+1) {
			options[*currentInstance].AudioFreqFromStream = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-ae")) {
		if (argc > i+1) {
			options[*currentInstance].AudioEngineID = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-ad")) {
		if (argc > i+1) {
			options[*currentInstance].AudioDecoderID = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	} else if ( ! strcmp(argv[i], "-chan")) {
		if (argc > i+1) {

			options[*currentInstance].OutputChannels =  get_channel_mask(argv[i+1]);

			options[*currentInstance].OutputChannelsExplicitAssign = TRUE;

			i += 2;
			err = RM_OK;
		} else
			err = RM_ERROR;
	} else if (! strcmp(argv[i], "-ac3compmode")) {
		if (argc > i+1) {
			options[*currentInstance].Ac3Params.CompMode = (enum Ac3CompMode_type)atoi(argv[i+1]);
			i+=2;
			err = RM_OK;
		} else 
			err = RM_ERROR;
	} else if (! strcmp(argv[i], "-ac3dynhi")) {
		if (argc > i+1) {
			RMuint32	dynhi;
			sscanf((const char*)argv[i+1], (const char*)"0x%08lx", &dynhi);
			options[*currentInstance].Ac3Params.DynScaleHi = dynhi;
			i += 2;
			err = RM_OK;
		} else
			err = RM_ERROR;
	} else if (! strcmp(argv[i], "-ac3dynlo")) {
		if (argc > i+1) {
			RMuint32	dynlo;
			sscanf((const char*)argv[i+1], (const char*)"0x%08lx", &dynlo);
			options[*currentInstance].Ac3Params.DynScaleLo = dynlo;
			i += 2;
			err = RM_OK;
		} else
			err = RM_ERROR;
	} else if (! strcmp(argv[i], "-ac3pcmscale")) {
		if (argc > i+1) {
			RMuint32	PcmScale;
			sscanf((const char*)argv[i+1], (const char*)"0x%08lx", &PcmScale);
			options[*currentInstance].Ac3Params.PcmScale = PcmScale;
			i += 2;
			err = RM_OK;
		} else
			err = RM_ERROR;
	} 
	else if (! strcmp(argv[i], "-ttone_type")){
		if(argc > i+1) {
			RMuint32 ttone_type;
			sscanf((const char*)argv[i+1], (const char*)"0x%lx", &ttone_type);
			options[*currentInstance].TToneParams.TToneType = ttone_type;
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (! strcmp(argv[i], "-ttone_mask")){
		if(argc > i+1) {
			RMuint32 ttone_chmask;
			sscanf((const char*)argv[i+1], (const char*)"0x%lx", &ttone_chmask);
			options[*currentInstance].TToneParams.TToneChannelMask = ttone_chmask;
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (! strcmp(argv[i], "-c")) {
		if (argc > i+1) {
			if ( !(strcmp(argv[i+1], "auto"))) {
				options[*currentInstance].auto_detect_codec = TRUE;
				RMDBGLOG((LOCALDBG, "\n\n\n\n\n********************** AUDIO CODEC: AUTO ***************\n\n\n\n"));
			}
			else if ( ! (strcmp(argv[i+1], "ac3")) || ! (strcmp(argv[i+1], "ac3_20"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_AC3;
				options[*currentInstance].Ac3Params.OutputChannels = Ac3_LR;

				if (!options[*currentInstance].OutputChannelsExplicitAssign)
					options[*currentInstance].OutputChannels	= Audio_Out_Ch_LR;
			} 
			else if ( ! (strcmp(argv[i+1], "ac3_32"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_AC3;
				options[*currentInstance].Ac3Params.OutputChannels = Ac3_LCRLsRs;

				if (!options[*currentInstance].OutputChannelsExplicitAssign)
					options[*currentInstance].OutputChannels	= Audio_Out_Ch_LCRLsRs;
			} 
			else if ( ! (strcmp(argv[i+1], "ec3"))) {
				RMDBGLOG((LOCALDBG, "ec3 codec: will set codec to ac3 and use rmec3transcode lib\n"));
				options[*currentInstance].Codec = AudioDecoder_Codec_AC3;
				options[*currentInstance].Ac3Params.OutputChannels = Ac3_LR;

				if (!options[*currentInstance].OutputChannelsExplicitAssign)
					options[*currentInstance].OutputChannels	= Audio_Out_Ch_LR;

				options[*currentInstance].transcode_ec3_to_ac3 = TRUE;
			} 
			else if ( ! (strcmp(argv[i+1], "mpeg"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_MPEG1;
			}			
			else if ( ! (strcmp(argv[i+1], "aac0")) || ! (strcmp(argv[i+1], "aac0_20"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_AAC;
				options[*currentInstance].AACParams.InputFormat = 0;	// adif, no sync word
				options[*currentInstance].AACParams.OutputChannels = Aac_LR;

				if (!options[*currentInstance].OutputChannelsExplicitAssign)
					options[*currentInstance].OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "aac0_32"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_AAC;
				options[*currentInstance].AACParams.InputFormat = 0;	// adif, no sync word
				options[*currentInstance].AACParams.OutputChannels = Aac_LCRLsRs;

				if (!options[*currentInstance].OutputChannelsExplicitAssign)
					options[*currentInstance].OutputChannels	= Audio_Out_Ch_LCRLsRs;
			}
			else if ( ! (strcmp(argv[i+1], "aac1")) || ! (strcmp(argv[i+1], "aac1_20"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_AAC;
				options[*currentInstance].AACParams.InputFormat = 1;	// adif, no sync word
				options[*currentInstance].AACParams.OutputChannels = Aac_LR;

				if (!options[*currentInstance].OutputChannelsExplicitAssign)
					options[*currentInstance].OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "aac1_32"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_AAC;
				options[*currentInstance].AACParams.InputFormat = 1;	// adif, no sync word
				options[*currentInstance].AACParams.OutputChannels = Aac_LCRLsRs;

				if (!options[*currentInstance].OutputChannelsExplicitAssign)
					options[*currentInstance].OutputChannels	= Audio_Out_Ch_LCRLsRs;
			}
			else if ( ! (strcmp(argv[i+1], "aac2")) || ! (strcmp(argv[i+1], "aac2_20"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_AAC;
				options[*currentInstance].AACParams.InputFormat = 2;	// adif, no sync word
				options[*currentInstance].AACParams.OutputChannels = Aac_LR;

				if (!options[*currentInstance].OutputChannelsExplicitAssign)
					options[*currentInstance].OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "aac2_32"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_AAC;
				options[*currentInstance].AACParams.InputFormat = 2;	// adif, no sync word
				options[*currentInstance].AACParams.OutputChannels = Aac_LCRLsRs;

				if (!options[*currentInstance].OutputChannelsExplicitAssign)
					options[*currentInstance].OutputChannels	= Audio_Out_Ch_LCRLsRs;
			}
			else if ( ! (strcmp(argv[i+1], "aac3")) || ! (strcmp(argv[i+1], "aac3_20"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_AAC;
				options[*currentInstance].AACParams.InputFormat = 3;	// adif, no sync word
				options[*currentInstance].AACParams.OutputChannels = Aac_LR;

				if (!options[*currentInstance].OutputChannelsExplicitAssign)
					options[*currentInstance].OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "aac3_32"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_AAC;
				options[*currentInstance].AACParams.InputFormat = 3;	// adif, no sync word
				options[*currentInstance].AACParams.OutputChannels = Aac_LCRLsRs;

				if (!options[*currentInstance].OutputChannelsExplicitAssign)
					options[*currentInstance].OutputChannels	= Audio_Out_Ch_LCRLsRs;
			}
			else if ( ! (strcmp(argv[i+1], "bsac"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_BSAC;
				options[*currentInstance].BSACParams.InputFormat = 1;	// adif, no sync word
				options[*currentInstance].BSACParams.OutputChannels = Dts_LR;       // need to be updated !!!
			}
			else if ( ! (strcmp(argv[i+1], "pcm24")) || ! (strcmp(argv[i+1], "pcm24_2"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_PCM;
				options[*currentInstance].SubCodec = 0;
				options[*currentInstance].PcmCdaParams.ChannelAssign = PcmCda2_LR;
				options[*currentInstance].PcmCdaParams.BitsPerSample = 24;

				if (!options[*currentInstance].OutputChannelsExplicitAssign)
					options[*currentInstance].OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "pcmx"))) { //pcmx codec, all information need to be written in header
				options[*currentInstance].Codec = AudioDecoder_Codec_PCMX;
			}
			else if ( ! (strcmp(argv[i+1], "pcm24_6"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_PCM;
				options[*currentInstance].SubCodec = 0;
				options[*currentInstance].PcmCdaParams.ChannelAssign = PcmCda6_LfRfCLfeLsRs;
				options[*currentInstance].PcmCdaParams.BitsPerSample = 24;

				if (!options[*currentInstance].OutputChannelsExplicitAssign)
					options[*currentInstance].OutputChannels	= Audio_Out_Ch_LCRLsRs;
			}
			else if ( ! (strcmp(argv[i+1], "pcm16_2"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_PCM;
				options[*currentInstance].SubCodec = 0;
				options[*currentInstance].PcmCdaParams.ChannelAssign = PcmCda2_LR;
				options[*currentInstance].PcmCdaParams.BitsPerSample = 16;

				if (!options[*currentInstance].OutputChannelsExplicitAssign)
					options[*currentInstance].OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "pcm16_1"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_PCM;
				options[*currentInstance].SubCodec = 0;
				options[*currentInstance].PcmCdaParams.ChannelAssign = PcmCda1_C;
				options[*currentInstance].PcmCdaParams.BitsPerSample = 16;

				if (!options[*currentInstance].OutputChannelsExplicitAssign)
					options[*currentInstance].OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "pcm16_6"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_PCM;
				options[*currentInstance].SubCodec = 0;
				options[*currentInstance].PcmCdaParams.ChannelAssign = PcmCda6_LfRfCLfeLsRs;
				options[*currentInstance].PcmCdaParams.BitsPerSample = 16;

				if (!options[*currentInstance].OutputChannelsExplicitAssign)
					options[*currentInstance].OutputChannels	= Audio_Out_Ch_LCRLsRs;
			}
			else if ( ! (strcmp(argv[i+1], "pcm8_2"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_PCM;
				options[*currentInstance].SubCodec = 0;
				options[*currentInstance].PcmCdaParams.ChannelAssign = PcmCda2_LR;
				options[*currentInstance].PcmCdaParams.BitsPerSample = 8;

				if (!options[*currentInstance].OutputChannelsExplicitAssign)
					options[*currentInstance].OutputChannels = Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "pcm8_1"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_PCM;
				options[*currentInstance].SubCodec = 0;
				options[*currentInstance].PcmCdaParams.ChannelAssign = PcmCda1_C;
				options[*currentInstance].PcmCdaParams.BitsPerSample = 8;

				if (!options[*currentInstance].OutputChannelsExplicitAssign)
					options[*currentInstance].OutputChannels	= Audio_Out_Ch_LR;							
			}
			else if ( ! (strcmp(argv[i+1], "lpcm24")) || ! (strcmp(argv[i+1], "lpcm24_2"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_PCM;
				options[*currentInstance].SubCodec = 1;
				options[*currentInstance].LpcmVobParams.ChannelAssign = LpcmVob2_LR;
				options[*currentInstance].LpcmVobParams.BitsPerSample = 24;

				if (!options[*currentInstance].OutputChannelsExplicitAssign)
					options[*currentInstance].OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "lpcm20")) || ! (strcmp(argv[i+1], "lpcm20_2"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_PCM;
				options[*currentInstance].SubCodec = 1;
				options[*currentInstance].LpcmVobParams.ChannelAssign = LpcmVob2_LR;
				options[*currentInstance].LpcmVobParams.BitsPerSample = 20;

				if (!options[*currentInstance].OutputChannelsExplicitAssign)
					options[*currentInstance].OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "lpcm16")) || ! (strcmp(argv[i+1], "lpcm16_2"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_PCM;
				options[*currentInstance].SubCodec = 1;
				options[*currentInstance].LpcmVobParams.ChannelAssign = LpcmVob2_LR;
				options[*currentInstance].LpcmVobParams.BitsPerSample = 16;

				if (!options[*currentInstance].OutputChannelsExplicitAssign) {
					options[*currentInstance].OutputChannels	= Audio_Out_Ch_LR;
					RMDBGLOG((LOCALDBG, ">>>>>>>>>>>>lpcm16_2 Cmdline Speaker Configure = %0x\n", options[*currentInstance].OutputChannels));
				}
			}
			else if ( ! (strcmp(argv[i+1], "lpcm16_1"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_PCM;
				options[*currentInstance].SubCodec = 1;
				options[*currentInstance].LpcmVobParams.ChannelAssign = LpcmVob1_C;
				options[*currentInstance].LpcmVobParams.BitsPerSample = 16;

				if (!options[*currentInstance].OutputChannelsExplicitAssign)
					options[*currentInstance].OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "lpcma24")) || ! (strcmp(argv[i+1], "lpcma24_2"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_PCM;
				options[*currentInstance].SubCodec = 2;
				options[*currentInstance].LpcmAobParams.ChannelAssign = LpcmAob20_LR;
				options[*currentInstance].LpcmAobParams.BitsPerSampleGroup1 = 24;
				options[*currentInstance].LpcmAobParams.BitsPerSampleGroup2 = 0;

				if (!options[*currentInstance].OutputChannelsExplicitAssign)
					options[*currentInstance].OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "lpcma16_2"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_PCM;
				options[*currentInstance].SubCodec = 2;
				options[*currentInstance].LpcmAobParams.ChannelAssign = LpcmAob20_LR;
				options[*currentInstance].LpcmAobParams.BitsPerSampleGroup1 = 16;
				options[*currentInstance].LpcmAobParams.BitsPerSampleGroup2 = 0;

				if (!options[*currentInstance].OutputChannelsExplicitAssign)
					options[*currentInstance].OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "lpcma16_1"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_PCM;
				options[*currentInstance].SubCodec = 2;
				options[*currentInstance].LpcmAobParams.ChannelAssign = LpcmAob10_C;
				options[*currentInstance].LpcmAobParams.BitsPerSampleGroup1 = 16;
				options[*currentInstance].LpcmAobParams.BitsPerSampleGroup2 = 0;

				if (!options[*currentInstance].OutputChannelsExplicitAssign)
					options[*currentInstance].OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "bdlpcm")) ) {
				// Bluray LPCM audio
				options[*currentInstance].Codec = AudioDecoder_Codec_PCM;
				options[*currentInstance].SubCodec = 3;
				options[*currentInstance].PcmCdaParams.ChannelAssign = PcmCda2_LR;
				options[*currentInstance].PcmCdaParams.BitsPerSample = 16;

				if (!options[*currentInstance].OutputChannelsExplicitAssign)
					options[*currentInstance].OutputChannels	= Audio_Out_Ch_LR;
			}
			else if ( ! (strcmp(argv[i+1], "wmapro")) ) {
				options[*currentInstance].Codec = AudioDecoder_Codec_WMAPRO;
			} 
			else if ( ! (strcmp(argv[i+1], "wma"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_WMA;
			} 
			else if ( ! (strcmp(argv[i+1], "wmats"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_WMA;
				options[*currentInstance].WmaParams.VersionNumber = 0x7a23;
			} 
			else if ( ! (strcmp(argv[i+1], "dts"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_DTS;
			} 
			else if ( ! (strcmp(argv[i+1], "dts_cd"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_DTS;
				options[*currentInstance].DtsParams.dts_CD	= TRUE;
			} 
			else if ( ! (strcmp(argv[i+1], "dts_20"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_DTS;
/* 				options[*currentInstance].OutputChannels = Channel_LR; */
				options[*currentInstance].DtsParams.OutputChannels	= Dts_LR;
			}
			else if ( ! (strcmp(argv[i+1], "dts_32"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_DTS;
/* 				options[*currentInstance].OutputChannels = Audio_Out_Ch_LCRLsRs; */
				options[*currentInstance].DtsParams.OutputChannels = Dts_LCRLsRs;
			}
			else if ( ! (strcmp(argv[i+1], "dvda"))) {
				options[*currentInstance].Codec = AudioDecoder_Codec_DVDA;
			} 
			else if ( ! (strcmp(argv[i+1], "ttone"))) {
                options[*currentInstance].Codec = AudioDecoder_Codec_TTONE;
				RMDBGLOG((ENABLE, "\n&&&&&\nTTONE select\n&&&&&\n"));
			}
			else {
				err = RM_ERROR;
			}
		}
		else
			err = RM_ERROR;
		
		if (err != RM_ERROR)
			err = RM_OK;
		i+=2;
	}
	else if ( ! strcmp(argv[i], "-afreq")) {
		if (argc > i+1) {
			options[*currentInstance].SampleRate = strtol(argv[i+1], NULL, 10);
			/* if the user specified the samplerate at cmdline, we force it over the value found on the dsi */
			options[*currentInstance].ForceSampleRate = TRUE;
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-sfg1")) {
		if (argc > i+1) {
			options[*currentInstance].SamplingFrequency = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-extclk")) {
		options[*currentInstance].ExternalClk = TRUE;
		i++;
		if ((i < argc) && (argv[i][0] != '-')) {
			options[*currentInstance].ExternalClkFreq = strtol(argv[i], NULL, 10);
			i++;
		}
		err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-aplay")) {
			if (argc > i+1) {
				options[*currentInstance].audio_play_time.PlayMode = strtol(argv[i+1], NULL, 10);
				i+=2;
				err = RM_OK;
			}
			else
				err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-astart")) {
			if (argc > i+1) {
			  RMuint64 startPTS;
			  sscanf((const char*)argv[i+1], (const char*)"%llu", &startPTS);
			    options[*currentInstance].audio_play_time.PlayStartPTS = startPTS;
				RMDBGLOG((LOCALDBG, "\n*****\nSTART PTS[%lu]=%llu\n*****\n", *currentInstance, options[*currentInstance].audio_play_time.PlayStartPTS));
				i+=2;
				err = RM_OK;
			}
			else
				err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-astop")) {
			if (argc > i+1) {
			  RMuint64 stopPTS;
			  sscanf((const char*)argv[i+1], (const char*)"%llu", &stopPTS);
			  options[*currentInstance].audio_play_time.PlayEndPTS = stopPTS;
				RMDBGLOG((LOCALDBG, "\n*****\nSTOP PTS[%lu]=%llu\n*****\n", *currentInstance, options[*currentInstance].audio_play_time.PlayEndPTS));
				i+=2;
				err = RM_OK;
			}
			else
				err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-ppdmx")) {
				options[*currentInstance].ppdmx = TRUE;
				i++;
				err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-centerup")) {
				options[*currentInstance].centerup = TRUE;
				i++;
				err = RM_OK;
	}
        else if ( ! strcmp(argv[i], "-i2s_spdif")) {
                if (argc > i+1) {
                        RMuint32 nI2S = strtol(argv[i+1], NULL, 10);
                        if (nI2S > 4)
                                nI2S = 0;
                        options[*currentInstance].i2s_spdif = nI2S;
                                                                                                                                 
                        i+=2;
                        err = RM_OK;
                }
                else
                        err = RM_ERROR;
        }
	else if ( ! strcmp(argv[i], "-ltrt")) {
				options[*currentInstance].OutputSurround20 = SurroundEnable;
				i++;		
				err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-cdmx")) {
				options[*currentInstance].cdmx_enable = TRUE;
				i++;		
				err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-nosync")) {
				options[*currentInstance].sync_stc = FALSE;
				i++;		
				err = RM_OK;
	}
  	else if (RMCompareAscii(argv[i], "-x")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options[*currentInstance].chconfig));
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-drc")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options[*currentInstance].drcenable));
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-boost")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options[*currentInstance].drcboost));
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-cut")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options[*currentInstance].drccut));
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-dialref")) {
		if (argc > i+1) {
			RMasciiToInt32(argv[i+1], &(options[*currentInstance].drcdialref));
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-lossless")) {
		options[*currentInstance].lossless = TRUE;
		i++;
		err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-audioin")) {
		printf("(((((((((((((********************* 1 *******************))))))))\n");
		options[*currentInstance].AudioIn = TRUE;
		options[*currentInstance].Codec = AudioDecoder_Codec_PCM;
		options[*currentInstance].SubCodec = 0;
		options[*currentInstance].PcmCdaParams.ChannelAssign = PcmCda2_LR;
		options[*currentInstance].PcmCdaParams.BitsPerSample = 16;	//24;
		options[*currentInstance].PcmCdaParams.MsbFirst = TRUE;
		i++;
		err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-aialign")) {
		if (argc > i+1) {
			options[*currentInstance].AudioInAlign = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-ailsbfirst")) {
		options[*currentInstance].AudioInLSBfirst = TRUE;
		i++;
		err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-i2salign")) {
		if (argc > i+1) {
			options[*currentInstance].I2SAlign = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-i2ssclknormal")) {
		options[*currentInstance].I2SSClkNormal = TRUE;
		i++;
		err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-i2sframenormal")) {
		options[*currentInstance].I2SFrameNormal = TRUE;
		i++;
		err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-i2slsbfirst")) {
		options[*currentInstance].I2SLSBFirst = TRUE;
		i++;
		err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-i2s16bit")) {
		options[*currentInstance].I2S16Bit = TRUE;
		i++;
		err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-source")) {
		if (argc > i+1) {
			options[*currentInstance].CaptureSource = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-capture_bts")) {
		if (argc > i+1) {
			options[*currentInstance].CaptureBitstream = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
  	else if ( ! strcmp(argv[i], "-channel_delay")) {
		if (argc > i+2) {
			RMint32 ch = strtol(argv[i+1], NULL, 10);
			if(ch < 0 || ch > 7){
				err = RM_ERROR;
			}
			else{
				switch(ch){
				  case 0:
					options[*currentInstance].ChannelDelay.Delay_ch0 = strtol(argv[i+2], NULL, 10);
					RMDBGLOG((LOCALDBG, "DELAY for CH0 is %d\n", options[*currentInstance].ChannelDelay.Delay_ch0));
					break;
				  case 1:
					options[*currentInstance].ChannelDelay.Delay_ch1 = strtol(argv[i+2], NULL, 10); break;
				  case 2:
					options[*currentInstance].ChannelDelay.Delay_ch2 = strtol(argv[i+2], NULL, 10); break;
				  case 3:
					options[*currentInstance].ChannelDelay.Delay_ch3 = strtol(argv[i+2], NULL, 10); break;
				  case 4:
					options[*currentInstance].ChannelDelay.Delay_ch4 = strtol(argv[i+2], NULL, 10); break;
				  case 5:
					options[*currentInstance].ChannelDelay.Delay_ch5 = strtol(argv[i+2], NULL, 10); break;
				  case 6:
					options[*currentInstance].ChannelDelay.Delay_ch6 = strtol(argv[i+2], NULL, 10); break;
				  case 7:
					options[*currentInstance].ChannelDelay.Delay_ch7 = strtol(argv[i+2], NULL, 10); break;
				}
			  i+=3;
			  err = RM_OK;
			}
		}
		else
			err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-pl2x_mode")) {
		if (argc > i+1) {
		options[*currentInstance].PL2xParams.mode = strtol(argv[i+1], NULL, 10);
		i+=2;
		err = RM_OK;
		}
		else 
			err = RM_ERROR;
	} 
	else if ( ! strcmp(argv[i], "-pl2x")) {
		options[*currentInstance].PL2xParams.on = TRUE;
		i++;
		err = RM_OK;
	} 
	else if ( ! strcmp(argv[i], "-pl2x_autoEX")) {
		options[*currentInstance].PL2xParams.autoEX = TRUE;
		i++;
		err = RM_OK;
	} 
	else if ( ! strcmp(argv[i], "-pl2x_Autobal_Off")) {
		options[*currentInstance].PL2xParams.a = TRUE;
		i++;
		err = RM_OK;
	} 
	else if ( ! strcmp(argv[i], "-pl2x_ShelfFilter")) {
		options[*currentInstance].PL2xParams.f = TRUE;
		i++;
		err = RM_OK;
	} 
	else if ( ! strcmp(argv[i], "-pl2x_RsPolarity")) {
		options[*currentInstance].PL2xParams.r = TRUE;
		i++;
		err = RM_OK;
	} 
	else if ( ! strcmp(argv[i], "-pl2x_Panorama")) {
		options[*currentInstance].PL2xParams.t = TRUE;
		i++;
		err = RM_OK;
	} 
	else if ( ! strcmp(argv[i], "-pl2x_CenterWidth")) {
		if (argc > i+1) {
		options[*currentInstance].PL2xParams.w = strtol(argv[i+1], NULL, 10);
		i+=2;
		err = RM_OK;
		}
		else 
			err = RM_ERROR;
	} 
	else if ( ! strcmp(argv[i], "-pl2x_InvMatrix")) {
		options[*currentInstance].PL2xParams.x = TRUE;
		i++;
		err = RM_OK;
	} 
	else if ( ! strcmp(argv[i], "-pl2x_DimCtrl")) {
		if (argc > i+1) {
		options[*currentInstance].PL2xParams.d = strtol(argv[i+1], NULL, 10);
		i+=2;
		err = RM_OK;
		}
		else 
			err = RM_ERROR;
	} 
	else if ( ! strcmp(argv[i], "-type")) {
		if (argc > i+1) {
			options[*currentInstance].CaptureType = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-delay")) {
		if (argc > i+1) {
			options[*currentInstance].CaptureDelay = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-spdif")) {
		if (argc > i+1) {
			if      (! strcmp(argv[i+1], "n"))   options[*currentInstance].Spdif = OutputSpdif_Disable;
			else if (! strcmp(argv[i+1], "u"))   options[*currentInstance].Spdif = OutputSpdif_Uncompressed;
			else if (! strcmp(argv[i+1], "c"))   options[*currentInstance].Spdif = OutputSpdif_Compressed;
			else if (! strcmp(argv[i+1], "cnd")) options[*currentInstance].Spdif = OutputSpdif_NoDecodeCompressed;
			else 
				err = RM_ERROR;
		}
		else
			err = RM_ERROR;

		if (err != RM_ERROR)
			err = RM_OK;
		i+=2;
	}
	else if ( ! strcmp(argv[i], "-hdmi_pass")) {
		options[*currentInstance].HDMIPassThrough = TRUE;
		options[*currentInstance].Spdif = OutputSpdif_Compressed;
		i++;
		err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-hdmi_lines")) {
		if (argc > i+1) {
			options[*currentInstance].HDMIPassThroughI2SLines = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if ( ! strcmp(argv[i], "-hdmi_hbr")) {
		options[*currentInstance].HBR_Enable = TRUE;
		options[*currentInstance].HBR_Compressed = TRUE;
		i++;
		if ((argc > i) && (argv[i][0] != '-')) {
			options[*currentInstance].HBR_HeaderID = strtol(argv[i], NULL, 10);
			i++;
		}
		err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-so")) {
		if (argc > i+1) {
			options[*currentInstance].SerialOut = (strtol(argv[i+1], NULL, 10)) ? TRUE : FALSE;
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if ( ! (strcmp(argv[i], "-dual"))) {
		if (argc > i+1) {
			if ( ! (strcmp(argv[i+1], "stereo"))) {
				options[*currentInstance].OutputDualMode = DualMode_Stereo;
			} 
			else if ( ! (strcmp(argv[i+1], "left"))) {
				options[*currentInstance].OutputDualMode = DualMode_LeftMono;
			} 
			else if ( ! (strcmp(argv[i+1], "right"))) {
				options[*currentInstance].OutputDualMode = DualMode_RightMono;
			} 
			else if ( ! (strcmp(argv[i+1], "mix"))) {
				options[*currentInstance].OutputDualMode = DualMode_MixMono;
			}
			else 
				err = RM_ERROR;
		}
		else
			err = RM_ERROR;

		if (err != RM_ERROR)
			err = RM_OK;
		i+=2;
	}
	else if ( ! (strcmp(argv[i], "-lsbfirst"))) {
		options[*currentInstance].PcmCdaParams.MsbFirst = FALSE;
		i++;
		err = RM_OK;
	}
	else if ( ! (strcmp(argv[i], "-lfe"))) {
//		options[*currentInstance].Ac3Params.OutputLfe = TRUE;
		options[*currentInstance].OutputLfe = TRUE;
		i++;
		err = RM_OK;
	}
	else if ( ! (strcmp(argv[i], "-acmod2dual"))) {
		options[*currentInstance].Ac3Params.Acmod2DualMode = TRUE;
		options[*currentInstance].MpegParams.Acmod2DualMode = TRUE;
		options[*currentInstance].AACParams.Acmod2DualMode = TRUE;
		RMDBGLOG((LOCALDBG, "!!!!!!!!!!!!! Set acmod2dual \n"));

		i++;
		err = RM_OK;
	}
	
	else if ( ! (strcmp(argv[i], "-downsample"))) {
		options[*currentInstance].LpcmAobParams.DownSample = TRUE;	
		options[*currentInstance].DownSample = TRUE;
		i++;
		err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-unsigned")) {
		RMDBGLOG((LOCALDBG, ">>>>>>>>>>>>Unsigned PCM is set\n"));
		options[*currentInstance].SignedPCM = FALSE;
		i++;
		err = RM_OK;
	}
	else if ( ! strcmp(argv[i], "-bassmode")) {
		RMDBGLOG((LOCALDBG, ">>>>>>>>>>>>BassMode is set\n"));
		if (argc > i+1) {
			options[*currentInstance].BassMode = strtol(argv[i+1], NULL, 10);
		}
		else 
			err = RM_ERROR;
		
		i+=2;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-afifo")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options[*currentInstance].fifo_size));
			options[*currentInstance].fifo_size *= 1024;
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-axfer")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options[*currentInstance].xfer_count));
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-askip_first_n_bytes")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options[*currentInstance].skip_first_n_bytes));
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-asend_n_bytes")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options[*currentInstance].send_n_bytes));
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-rclkmclk")) {
		if (argc > i+1) {
			RMuint32 n;
			RMasciiToUInt32(argv[i+1], &n);
			options[*currentInstance].mclk_on_rclk = (enum ClockSignal)(ClockSignal_RClk0 + n);
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-audio_cp")) {
		options[*currentInstance].AudioCP = TRUE;
		i++;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-channel_status")) {
		if (argc > i+2) {
			RMuint32 mask;
			RMuint32 value;

			RMasciiToUInt32(argv[i+1], &mask);
			RMDBGLOG((LOCALDBG, "***SPDIF*** MASK = 0x%08x\n", mask));

			RMasciiToUInt32(argv[i+2], &value);
			RMDBGLOG((LOCALDBG, "***SPDIF*** VALUE = 0x%08x\n", value));

			options[*currentInstance].spdifChannelStatus.Mask = mask;
			options[*currentInstance].spdifChannelStatus.Value = value;			

			i += 3;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-mclk")) {
		if (argc > i+1) {
			RMuint32 n;
			RMasciiToUInt32(argv[i+1], &n);
			options[*currentInstance].mclk = (n == 128) ? MClkFactor_128Xfs : MClkFactor_256Xfs;
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-audio_hdmi2c")) {
		fprintf(stderr, "WARNING: -audio_hdmi2c is OBSOLETE. Do not use it anymore.\n");
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-mute")) {
		if (argc > i + 2) {
			RMuint32 gpio;
			options[*currentInstance].mute_enable = TRUE;
			RMasciiToUInt32(argv[i+1], &gpio);
			options[*currentInstance].mute_gpio = (enum GPIOId_type)gpio;
			options[*currentInstance].mute_polarity = ((argv[i+2][0]=='1')||(argv[i+2][0]=='h')||(argv[i+2][0]=='H'));
			i += 3;
			err = RM_OK;
		}
		else err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-audio_hdmi_ddc_tx")) {
		fprintf(stderr, "WARNING: -audio_hdmi_ddc_tx is OBSOLETE. Do not use it anymore.\n");
		err = RM_OK;
	}
	
	*index = i;

	RMDBGLOG((LOCALDBG, ">>>>>>>>>>>>Cmdline Speaker Configure = %0x\n", options[*currentInstance].OutputChannels));
	
	return err;
}

/** 
	@param dcc_info
	@param options      The audio options
	@param AudioCP      TRUE: set copy protection bit in SPDIF and HDMI IEC 60958-3 header (Bit 2, 'C')
	@param engine
*/
RMstatus set_audio_cp_bit(struct dcc_context *dcc_info, struct audio_cmdline *options, RMbool AudioCP, RMuint32 engine)
{
	struct AudioEngine_ChannelStatus_type cs;

	if (options->spdifChannelStatus.Mask & 0x00000004) {
		RMDBGLOG((LOCALDBG, "audioCP bit set by mask, ignore this call\n"));
		return RM_OK;
	}

	options->AudioCP = AudioCP;
	
	if (options->dh_info && options->dh_info->pDH) {
		DHSetAudioCP(options->dh_info->pDH, options->AudioCP);
	}
	
	cs.Mask =  0x00000004;
	cs.Value = (options->AudioCP) ? 0x00000004 : 0x00000000;

	RMDBGLOG((LOCALDBG, "set_audio_cp_bit(mask 0x%08lx, value 0x%08lx)\n", cs.Mask, cs.Value));

	return set_audio_channel_status(dcc_info, cs, engine);

}


RMstatus set_audio_channel_status(struct dcc_context *dcc_info, struct AudioEngine_ChannelStatus_type cs, RMuint32 engine)
{
	RMDBGLOG((LOCALDBG, "set_audio_channel_status(mask 0x%08lx, value 0x%08lx)\n", cs.Mask, cs.Value));

	return RUASetProperty(dcc_info->pRUA, engine, RMAudioEnginePropertyID_ChannelStatus, &cs, sizeof(cs), 0);
}



/** 
	@param dcc_info
	@param options      The audio options
	@param NumChannel   Number of audio channels (2..8: force channel number, 0: detect from options->OutputChannels)
	@param LowFreqChannel_3  TRUE if Low Frequency Effect audio is on channel 3
	@param FrontCenterChannel_4  TRUE if Front Center audio is on channel 4
	@param FrontLeftRightCenterChannels_7_8  If LeftCenter/RightCenter channels exist, are they in the Front(TRUE) or Rear(FALSE)?
	See EIA/CEA-861-B Table 22 for possible channel assignments
*/

RMstatus apply_dvi_hdmi_audio_options(
	struct dcc_context *dcc_info, 
	struct audio_cmdline *options, 
	RMuint32 NumChannel, 
	RMbool LowFreqChannel_3, 
	RMbool FrontCenterChannel_4, 
	RMbool FrontLeftRightCenterChannels_7_8)
{
	RMstatus err;
	struct DH_AudioFormat AudioFormat;
	struct DH_AudioInfoFrame AudioInfoFrame;
	RMbool Supports_AI;
	struct AudioEngine_ChannelStatus_type cs;
	RMuint32 ChannelStat = 0, ChannelMask = 0;
	
	if (options->dh_info == NULL) {
		RMDBGPRINT((ENABLE, "HDMI Audio: no dh_info struct available!\n"));
		return RM_ERROR;  // no HDMI, nothing to do
	}
	
	if (options->dh_info->pDH == NULL) {
		RMDBGPRINT((ENABLE, "HDMI Audio: no HDMI handle available!\n"));
		return RM_ERROR;  // no HDMI, nothing to do
	}
	
	// copy current category code from audio engine
	err = RUAGetProperty(dcc_info->pRUA, 
		EMHWLIB_MODULE(AudioEngine, options->AudioEngineID), 
		RMAudioEnginePropertyID_ChannelStatus, 
		&cs, sizeof(cs));
	if (RMSUCCEEDED(err)) {
		RMDBGLOG((LOCALDBG, "Channel Status from SPDIF: 0x%04lX\n", cs.Value & 0xFFFF));
		if (((cs.Value & 0x04) ? TRUE : FALSE) != options->AudioCP) {
			//RMDBGLOG((LOCALDBG, "Mismatch of COPY PROTECTION bit in audio header! Please investigate!!!\n"));
			//DHSetAudioCP(pDH, (cs.Value & 0x04) ? TRUE : FALSE);
		}
		ChannelStat = cs.Value;
		ChannelMask = 0x0000FFF9;
	}
	
	err = convert_hdmi_audio_options(
		options->SampleRate, options->mclk, 
		options->OutputChannels, options->OutputLfe, 
		options->Spdif, options->Codec, 
		options->HDMIPassThrough, options->HDMIPassThroughI2SLines, 
		options->HBR_Enable, (options->HDMIPassThrough && (options->Codec != AudioDecoder_Codec_PCM)), options->HBR_HeaderID, 
		options->dh_info->pDBC, options->dh_info->nDBC, 
		NumChannel, LowFreqChannel_3, FrontCenterChannel_4, FrontLeftRightCenterChannels_7_8, 
		&AudioFormat, &AudioInfoFrame, &Supports_AI);
	if (RMFAILED(err)) return err;
	
	return apply_hdmi_audio(options->dh_info->pDH, 
		&AudioFormat, &AudioInfoFrame, Supports_AI, 
		options->AudioCP, ChannelStat, ChannelMask);
}

/* Maintain HDCP integrity and check for HDMI monitor plug/unplug, audio-only apps*/
/* video mode will not be changed on monitor changes! */
RMstatus update_hdmi_audio(struct dcc_context *dcc_info, struct audio_cmdline *audio_opt)
{
	RMstatus err;
	
	if (audio_opt->dh_info && audio_opt->dh_info->pDH) {
		RMuint32 SampleRate;
		
		// Perform HotPlug/HDCP checks (can be disabled, if main app already performs this in different thread)
		if (audio_opt->dh_check) {
			RMbool HDMI_display = FALSE;
			struct DH_HDMI_state HDMIState;
			HDMIState.ReceiverSignal = FALSE;  // only set to TRUE if Rx signal is supported by hardware
			err = DHCheckHDMI(audio_opt->dh_info->pDH, &HDMIState);
			if (RMSUCCEEDED(err) || (err == RM_DRM_INVALID_KEY)) {
				if (err == RM_DRM_INVALID_KEY) {
					if (! manutest) fprintf(stderr, "\n    #### HDCP #### failed, the display's key has been revoked!\n\n");
				}
				if (HDMIState.HDCPLost) {
					if (! manutest) fprintf(stderr, "\n    #### HDCP #### has been lost, do not play protected content.\n\n");
				}
				if (HDMIState.HDCPState != audio_opt->dh_info->HDMIState.HDCPState) {
					if (HDMIState.HDCPState) {
						if (! manutest) fprintf(stderr, "\n    #### HDCP #### is now on, OK to play protected content.\n\n");
					} else {
						if (! manutest) fprintf(stderr, "\n    #### HDCP #### is now off, do not play protected content.\n\n");
					}
				}
				if (
					(HDMIState.HotPlugChanged || HDMIState.ReceiverChanged) && // HPD or Rx has changed
					(HDMIState.HotPlugState && (HDMIState.ReceiverSignal == HDMIState.ReceiverState)) // both HPD and Rx are on, or just HPD, if Rx is not supported
				) {
					if (! manutest) fprintf(stderr, "\n"
						"  HH  HH  HHHHH   HH   HH  HHHH      HHHH   HH   HH\n"
						"  HH  HH  HH  HH  HHH HHH   HH      HH  HH  HHH  HH\n"
						"  HHHHHH  HH  HH  HH H HH   HH      HH  HH  HH H HH\n"
						"  HH  HH  HH  HH  HH   HH   HH      HH  HH  HH  HHH\n"
						"  HH  HH  HHHHH   HH   HH  HHHH      HHHH   HH   HH\n"
						"\n");
					audio_opt->dh_info->nDBC = NUM_DBC;
					if (audio_opt->dh_info->pDBC == NULL) {
						audio_opt->dh_info->pDBC = (struct CEA861BDataBlockCollection *)RMMalloc(audio_opt->dh_info->nDBC * sizeof(struct CEA861BDataBlockCollection));
						if (audio_opt->dh_info->pDBC == NULL) audio_opt->dh_info->nDBC = 0;
					}
					err = DHGetHDMIModeFromEDID(audio_opt->dh_info->pDH, &HDMI_display);
					if (RMFAILED(err)) {
						audio_opt->dh_info->nDBC = 0;
					} else {
						DHSetHDMIMode(audio_opt->dh_info->pDH, HDMI_display);
					}
					// re-enable output after hotplug, with previous settings
					DHEnableOutput(audio_opt->dh_info->pDH);
					if (HDMI_display) {
						RMDBGLOG((ENABLE, "Monitor is HDMI\n"));
						apply_dvi_hdmi_audio_options(dcc_info, audio_opt, 0, FALSE, FALSE, FALSE);
					} else {
						RMDBGLOG((ENABLE, "Monitor is DVI / VGA\n"));
					}
				} else 
				// Display has been switched off or has been disconnected
				if (
					(HDMIState.HotPlugChanged && ! HDMIState.HotPlugState) || 
					(HDMIState.ReceiverSignal && HDMIState.ReceiverChanged && ! HDMIState.ReceiverState)
				) {
					// turn off HDMI, leave analog on
					if (! manutest) fprintf(stderr, "\n"
						"  HH  HH  HHHHH   HH   HH  HHHH      HHHH   HHHHHH  HHHHHH\n"
						"  HH  HH  HH  HH  HHH HHH   HH      HH  HH  HH      HH    \n"
						"  HHHHHH  HH  HH  HH H HH   HH      HH  HH  HHHHH   HHHHH \n"
						"  HH  HH  HH  HH  HH   HH   HH      HH  HH  HH      HH    \n"
						"  HH  HH  HHHHH   HH   HH  HHHH      HHHH   HH      HH    \n"
						"\n");
				}
				audio_opt->dh_info->HDMIState = HDMIState;
			}
		}
		
		// Update HDMI audio sample clock, if audio engine output clock has changed
		err = RUAGetProperty(dcc_info->pRUA, 
			EMHWLIB_MODULE(AudioEngine, audio_opt->AudioEngineID), 
			RMAudioEnginePropertyID_SampleFrequency, 
			&(SampleRate), sizeof(SampleRate));
		if (RMSUCCEEDED(err) && (SampleRate != audio_opt->SampleRate)) {
			RMDBGLOG((ENABLE, "\n\n\nSetting new Audio Sample Clock while polling in update_hdmi_audio(): %lu Hz\n\n\n", SampleRate));
			audio_opt->SampleRate = SampleRate;
			apply_dvi_hdmi_audio_options(dcc_info, audio_opt, 0, FALSE, FALSE, FALSE);
		}
		
		// Update dh_info states (legacy compatibility)
		DHGetState(audio_opt->dh_info->pDH, &(audio_opt->dh_info->dvi_hdmi_state), &(audio_opt->dh_info->dvi_hdmi_cable));
	}
	
	return RM_OK;
}


RMstatus apply_audio_engine_options_with_handle(struct dcc_context *dcc_info, struct audio_cmdline *options, struct DCCAudioSourceHandle *pSingleAudioSourceHandle)
{
	RMstatus err;
	enum  AudioEngine_SerialOut_type serialOutStatus;
	struct AudioEngine_SampleFrequencyFromSource_type sf;
	struct AudioEngine_I2SConfig_type i2s;
	enum AudioEngine_SpdifOut_type spdif_out;
	RMuint32 engine = pSingleAudioSourceHandle->engineID;

	RMDBGLOG((LOCALDBG, "apply_audio_engine_options_with_handle for instance %lu\n", options->thisAudioInstance));

	RMDBGLOG((LOCALDBG, "sampleFreq %lu\n", options->SampleRate));

#ifdef WITH_NEW_VCXO
	{
		RMuint32 vcxo_id;
		
		err = DCCGetRouteVCXO(dcc_info->route, &(vcxo_id));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot get VCXO from route %d\n", err));
			return err;
		}
		
		/* if the audio was used in another VCXO it will be disconnected from its previous VCXO */
		err = RUASetProperty(dcc_info->pRUA, vcxo_id, RMVCXOPropertyID_ConnectClock, &engine, sizeof(engine), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot connect audio clock %d\n", err));
			return err;
		}
	}
#endif // WITH_NEW_VCXO

	spdif_out = AudioEngine_SpdifOut_Active;
	err = RUASetProperty(dcc_info->pRUA, engine, RMAudioEnginePropertyID_SpdifOut, &spdif_out, sizeof(spdif_out), 0);
	
	RMDBGLOG((LOCALDBG, "<<<<<<<<<<<<Force S/PDIF 16bit = %lu\n", options->DownSample));
	err = RUASetProperty(dcc_info->pRUA, engine, RMAudioEnginePropertyID_SpdifForce16Bit, &options->DownSample, sizeof(RMbool), 0);
	
	RMDBGLOG((LOCALDBG, "<<<<<<<<<<<<Force downmixing in Post Processing Module = %lu\n", options->ppdmx));
	err = RUASetProperty(dcc_info->pRUA, engine, RMGenericPropertyID_ForcePostProcessingDownmixing, &options->ppdmx, sizeof(RMbool), 0);

	RMDBGLOG((LOCALDBG, "<<<<<<<<<<<<Center Channel boost up 6dB = %lu\n", options->centerup));
	err = RUASetProperty(dcc_info->pRUA, engine, RMGenericPropertyID_OutputCenterUp, &options->centerup, sizeof(RMbool), 0);

	if(options->cdmx_enable)
	{
	  RMDBGLOG((ENABLE, "<<<<<<<<<<<<Writing 5.1ch to 2ch LoRo downmixing table\n"));
	  err = RUASetProperty(dcc_info->pRUA, engine, RMAudioEnginePropertyID_Downmixing_tables, &audio_dmx_5dot1_to_LR, sizeof(struct AudioEngine_Downmixing_tables_type), 0);

	  RMDBGLOG((ENABLE, "<<<<<<<<<<<<Customized downmixing = %lu\n", options->cdmx_enable));
	  err = RUASetProperty(dcc_info->pRUA, engine, RMAudioEnginePropertyID_CustomizedDownmixing, &options->cdmx_enable, sizeof(RMbool), 0);
	}

	dcc_info->volume_index = 0;	// 0 dB

	if(options->i2s_spdif)
	{
	  RMDBGLOG((LOCALDBG, "<<<<<<<<<<<<Copy I2S #%u to SPDIF\n", options->i2s_spdif));
	  err = RUASetProperty(dcc_info->pRUA, engine, RMGenericPropertyID_I2S_SEL, &options->i2s_spdif, sizeof(RMuint32), 0);	
	}
	
	if (options->spdifChannelStatus.Mask)
		set_audio_channel_status(dcc_info, options->spdifChannelStatus, engine);

	set_audio_cp_bit(dcc_info, options, options->AudioCP, engine);
	
	if (options->AudioFreqFromStream != 1) {
		sf.GeneratorNumber = 3;
		sf.SampleFrequency = options->SampleRate;
		if (options->ExternalClk) {  // external clock source
			sf.Source = 4;  // RClkIn0
			if (options->ExternalClkFreq) {
				sf.SourceFrequency = options->ExternalClkFreq;
			} else {
				sf.SourceFrequency = sf.SampleFrequency * ((options->mclk == MClkFactor_256Xfs) ? 256 : 128);
			}
			sf.IntermediateFrequency = sf.SourceFrequency * 8;
		} else {  // internal clock source
			sf.Source = 1;  // XTalIn
			sf.SourceFrequency = 27000000;
			sf.IntermediateFrequency = 148500000;
		}
		RUASetProperty(dcc_info->pRUA, engine, RMAudioEnginePropertyID_SampleFrequencyFromSource, &sf, sizeof(sf), 0);
	}
	
	if (options->AudioFreqFromStream >= 0) {
		RMbool afs;
		afs = (options->AudioFreqFromStream > 0) ? TRUE : FALSE;
		RMDBGLOG((LOCALDBG, "APPLY options->afs = %u\n", afs ? 1 : 0));
		RUASetProperty(dcc_info->pRUA, engine, RMAudioEnginePropertyID_SampleFrequencyFromStream, &afs, sizeof(afs), 0);
	}
	
	RMDBGLOG((LOCALDBG, "APPLY options->mclk = %u\n", (options->mclk == MClkFactor_256Xfs) ? 256 : 128));
	RUASetProperty(dcc_info->pRUA, engine, RMAudioEnginePropertyID_MasterClockFactor, 
		&(options->mclk), sizeof(options->mclk), 0);
	
   	RMDBGLOG((LOCALDBG, "APPLY options->ChannelDelay.Delay_ch0 = %lu\n", options->ChannelDelay.Delay_ch0));
	options->ChannelDelay.sample_frequency = options->SampleRate;
	RUASetProperty(dcc_info->pRUA, engine, RMAudioEnginePropertyID_Delay, &options->ChannelDelay, sizeof(struct AudioEngine_Delay_type), 0);
	
   	RMDBGLOG((ENABLE, "APPLY options->PL2xParams = %lu\n", options->PL2xParams.mode));	
	RUASetProperty(dcc_info->pRUA, engine, RMAudioEnginePropertyID_PL2x, &options->PL2xParams, sizeof(struct AudioEngine_PL2x_type), 0);
	
	if (options->mclk_on_rclk) {
#if ((EM86XX_CHIP>EM86XX_CHIPID_TANGO2) || ((EM86XX_CHIP==EM86XX_CHIPID_TANGO2) && (EM86XX_REVISION<4)))
		struct PLL_CD_type cd;
		struct PLL_RouteClockFromPLL_type rt;
		
		cd.PLL = (enum PLLGen)(PLLGen_cd_4 + options->mclk_on_rclk - ClockSignal_RClk0);
		cd.Frequency = options->SampleRate * ((options->mclk == MClkFactor_256Xfs) ? 256 : 128) * 2;  // CD = MClk * 2
		err = RUASetProperty(dcc_info->pRUA, PLL, RMPLLPropertyID_CD, &cd, sizeof(cd), 0);
		if (RMFAILED(err)) RMDBGLOG((ENABLE, "Failed to set %lu Hz on CD %u\n", cd.Frequency, cd.PLL - PLLGen_cd_0));
		rt.PLL = cd.PLL;
		rt.PLLOutput = PLLOut_1; // RClkX = CD / 2
		rt.Clock = options->mclk_on_rclk;
		err = RUASetProperty(dcc_info->pRUA, PLL, RMPLLPropertyID_RouteClockFromPLL, &rt, sizeof(rt), 0);
		if (RMFAILED(err)) RMDBGLOG((ENABLE, "Failed to route CD %u to RClk %u\n", cd.PLL - PLLGen_cd_0, options->mclk_on_rclk - ClockSignal_RClk0));
#endif
	}
	
	i2s.DataAlignment = options->I2SAlign;
	i2s.SClkInvert = ! options->I2SSClkNormal;
	i2s.FrameInvert = ! options->I2SFrameNormal;
	i2s.MSBFirst = ! options->I2SLSBFirst;
	i2s.SampleSize16Bit = options->I2S16Bit;
	RUASetProperty(dcc_info->pRUA, engine, RMAudioEnginePropertyID_I2SConfig, &i2s, sizeof(i2s), 0);
	
	if (options->mute_enable) {
		struct SystemBlock_GPIO_type gpio;
		
		gpio.Bit = options->mute_gpio;
		gpio.Data = ! options->mute_polarity;  // unmute
		err = RUASetProperty(dcc_info->pRUA, SystemBlock, RMSystemBlockPropertyID_GPIO, &gpio, sizeof(gpio), 0);
		if (RMFAILED(err)) RMDBGLOG((ENABLE, "Failed to un-mute audio with GPIO #%u\n", options->mute_gpio));
	}
	
	serialOutStatus = (options->SerialOut) ? AudioEngine_SerialOut_SO_ENABLE : AudioEngine_SerialOut_SO_DISABLE;
	err = RUASetProperty(dcc_info->pRUA, engine, RMAudioEnginePropertyID_SerialOut, &serialOutStatus, sizeof(serialOutStatus), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot set serial out state %d\n", err);
		return err;
	}
	
	return RM_OK;

}


RMstatus apply_audio_engine_options(struct dcc_context *dcc_info, struct audio_cmdline *options)
{
	RMstatus status;
	struct DCCAudioSourceHandle audioHandle;

	RMDBGLOG((LOCALDBG, "apply_audio_engine_options\n"));

	if (dcc_info->pAudioSource) {

		audioHandle.pAudioSource = dcc_info->pAudioSource;
		audioHandle.engineID = dcc_info->audio_engine;
		audioHandle.moduleID = dcc_info->audio_decoder;

		return apply_audio_engine_options_with_handle(dcc_info, options, &audioHandle);
	}
	else if (dcc_info->pMultipleAudioSource) {

		status = DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(dcc_info->pMultipleAudioSource, options->thisAudioInstance, &audioHandle);
		if (status != RM_OK)
			return status;

		return apply_audio_engine_options_with_handle(dcc_info, options, &audioHandle);
	}

	
	return RM_ERROR;
}

RMstatus apply_audio_decoder_options_onthefly_with_handle(struct dcc_context *dcc_info, struct audio_cmdline *options, struct DCCAudioSourceHandle *pSingleAudioSourceHandle)
{
	RMstatus err = RM_ERROR;
	RMuint32 moduleID = pSingleAudioSourceHandle->moduleID;

	RMDBGLOG((LOCALDBG, "apply_audio_decoder_options_onthefly_with_handle for instance %lu\n", options->thisAudioInstance));

	if ( options->Codec == AudioDecoder_Codec_PCM ) {
		if ( options->SubCodec == 0 ) {
			options->PcmCdaParams.SamplingFrequency = options->SamplingFrequency;
			options->PcmCdaParams.OutputDualMode = options->OutputDualMode;
			options->PcmCdaParams.OutputSpdif = options->Spdif | (options->HDMIPassThrough ? 0x100 : 0);

			err = RUASetProperty(dcc_info->pRUA, moduleID, RMAudioDecoderPropertyID_PcmCdaParameters,
					     &(options->PcmCdaParams), sizeof(struct AudioDecoder_PcmCdaParameters_type), 0);
		} else if ( options->SubCodec == 1 ) {
			options->LpcmVobParams.SamplingFrequency = options->SamplingFrequency;
			options->LpcmVobParams.OutputDualMode = options->OutputDualMode;
			options->LpcmVobParams.OutputSpdif = options->Spdif | (options->HDMIPassThrough ? 0x100 : 0);

			err = RUASetProperty(dcc_info->pRUA, moduleID, RMAudioDecoderPropertyID_LpcmVobParameters,
					     &(options->LpcmVobParams), sizeof(struct AudioDecoder_LpcmVobParameters_type), 0);
		} else if ( options->SubCodec == 2 ) {
			options->LpcmAobParams.SamplingFrequencyGroup1 = options->SamplingFrequency;
			options->LpcmAobParams.SamplingFrequencyGroup2 = 0;
			options->LpcmAobParams.OutputDualMode = options->OutputDualMode;
			options->LpcmAobParams.OutputSpdif = options->Spdif | (options->HDMIPassThrough ? 0x100 : 0);

			err = RUASetProperty(dcc_info->pRUA, moduleID, RMAudioDecoderPropertyID_LpcmAobParameters,
					     &(options->LpcmAobParams), sizeof(struct AudioDecoder_LpcmAobParameters_type), 0);
		} else if ( options->SubCodec == 3 ) {
			options->PcmCdaParams.SamplingFrequency = options->SamplingFrequency;
			options->PcmCdaParams.OutputDualMode = options->OutputDualMode;
			options->PcmCdaParams.OutputSpdif = options->Spdif | (options->HDMIPassThrough ? 0x100 : 0);

			err = RUASetProperty(dcc_info->pRUA, moduleID, RMAudioDecoderPropertyID_LpcmBDParameters,
					     &(options->LpcmBDParams), sizeof(struct AudioDecoder_LpcmBDParameters_type), 0);
		}
	} 
	else if ( options->Codec == AudioDecoder_Codec_AC3 ) {
		options->Ac3Params.OutputDualMode = options->OutputDualMode;
		options->Ac3Params.OutputSpdif = options->Spdif | (options->HDMIPassThrough ? 0x100 : 0);

		err = RUASetProperty(dcc_info->pRUA, moduleID, RMAudioDecoderPropertyID_Ac3Parameters,
					   &(options->Ac3Params), sizeof(struct AudioDecoder_Ac3Parameters_type), 0);
		options->WmaParams.OutputChannels	= options->OutputChannels;
		RMDBGLOG((LOCALDBG,">>>>>>>>options->OutputChannels = 0x%x\n", options->OutputChannels));
	} 
	else if ( options->Codec == AudioDecoder_Codec_DTS ) {
		
		options->DtsParams.OutputDualMode 	= options->OutputDualMode;
		options->DtsParams.OutputSpdif 		= options->Spdif | (options->HDMIPassThrough ? 0x100 : 0);
		options->DtsParams.OutputChannels	= options->OutputChannels;

		err = RUASetProperty(dcc_info->pRUA, moduleID, RMAudioDecoderPropertyID_DtsParameters,
				     &(options->DtsParams), sizeof(struct AudioDecoder_DtsParameters_type), 0);
	} 
	else if ( options->Codec == AudioDecoder_Codec_MPEG1 ) {

		options->MpegParams.OutputDualMode 	= options->OutputDualMode;
		options->MpegParams.OutputSpdif 	= options->Spdif | (options->HDMIPassThrough ? 0x100 : 0);
		
		err = RUASetProperty(dcc_info->pRUA, moduleID, RMAudioDecoderPropertyID_MpegParameters,
				     &(options->MpegParams), sizeof(struct AudioDecoder_MpegParameters_type), 0);
	} 
	else if ( options->Codec == AudioDecoder_Codec_AAC ) {
		options->AACParams.OutputDualMode       = options->OutputDualMode;
		options->AACParams.OutputSpdif 		= options->Spdif | (options->HDMIPassThrough ? 0x100 : 0);

		err = RUASetProperty(dcc_info->pRUA, moduleID, RMAudioDecoderPropertyID_AACParameters,
				     &(options->AACParams), sizeof(struct AudioDecoder_AACParameters_type), 0);
	}
	else if ( options->Codec == AudioDecoder_Codec_BSAC ) {
		options->BSACParams.OutputDualMode      = options->OutputDualMode;
		options->BSACParams.OutputSpdif         = options->Spdif | (options->HDMIPassThrough ? 0x100 : 0);
		options->BSACParams.OutputChannels       = Dts_LR;                       // need to be updated !!!

		err = RUASetProperty(dcc_info->pRUA, dcc_info->audio_decoder, RMAudioDecoderPropertyID_BSACParameters,
					&(options->BSACParams), sizeof(struct AudioDecoder_BSACParameters_type), 0);
	}	 
	else if ( (options->Codec == AudioDecoder_Codec_WMA) || (options->Codec == AudioDecoder_Codec_WMAPRO) ) {

		options->WmaParams.OutputDualMode 	= options->OutputDualMode;
		options->WmaParams.OutputSpdif 		= options->Spdif | (options->HDMIPassThrough ? 0x100 : 0);

		err = RUASetProperty(dcc_info->pRUA, moduleID, RMAudioDecoderPropertyID_WMAParameters,
					&(options->WmaParams), sizeof(struct AudioDecoder_WMAParameters_type), 0);
	}
	
	RMDBGLOG((LOCALDBG, "audio playMode [%lu]: audio in [%llu].....audio out [%llu]\n", 
			options->audio_play_time.PlayMode,
			options->audio_play_time.PlayStartPTS,
			options->audio_play_time.PlayEndPTS));

	RUASetProperty(dcc_info->pRUA, moduleID, RMAudioDecoderPropertyID_AudioPlayTime, &options->audio_play_time, sizeof(struct AudioDecoder_AudioPlayTime_type), 0);

	return err;
}

RMstatus apply_audio_decoder_options_onthefly(struct dcc_context *dcc_info, struct audio_cmdline *options)
{
	RMstatus status;
	struct DCCAudioSourceHandle audioHandle;

	if (dcc_info->pAudioSource) {
		
		audioHandle.pAudioSource = dcc_info->pAudioSource;
		audioHandle.engineID = dcc_info->audio_engine;
		audioHandle.moduleID = dcc_info->audio_decoder;

		return apply_audio_decoder_options_onthefly_with_handle(dcc_info, options, &audioHandle);
	}
	else if (dcc_info->pMultipleAudioSource) {

		status = DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(dcc_info->pMultipleAudioSource, options->thisAudioInstance, &audioHandle);
		if (status != RM_OK)
			return status;

		return apply_audio_decoder_options_onthefly_with_handle(dcc_info, options, &audioHandle);
	}

	return RM_ERROR;

}


RMstatus apply_audio_decoder_options_with_handle(struct dcc_context *dcc_info, struct audio_cmdline *options, struct DCCAudioSourceHandle *pSingleAudioSourceHandle)
{
	RMstatus err;
	struct DCCAudioSource *pAudioSource = pSingleAudioSourceHandle->pAudioSource;

	RMDBGLOG((LOCALDBG, "apply_audio_decoder_options_with_handle(codec %lu) instance %lu\n", options->Codec, options->thisAudioInstance));

  	if ( options->Codec == AudioDecoder_Codec_PCMX ) {
		if (manutest == FALSE) {
                printf("++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
                printf("decoder = PCMX\n");
	        }
  		if(options->SamplingFrequency == 0)
	  		options->SamplingFrequency = options->SampleRate;
			options->PCMXParams.SamplingFrequency = options->SamplingFrequency;
			options->PCMXParams.OutputDualMode = options->OutputDualMode;
			options->PCMXParams.OutputSpdif = options->Spdif | (options->HDMIPassThrough ? 0x100 : 0);
			RMDBGLOG((LOCALDBG, "************\n***PCMX SPDIF=0x%lX\n*************\n", options->PCMXParams.OutputSpdif));
			options->PCMXParams.OutputChannels = options->OutputChannels;
			options->PCMXParams.OutputLfe 		= options->OutputLfe;
			options->PCMXParams.SignedPCM 		= options->SignedPCM;
			options->PCMXParams.BassMode 		= options->BassMode;
			options->PCMXParams.OutputSurround20 = options->OutputSurround20;

			err = DCCSetAudioPcmxFormat(pAudioSource, &options->PCMXParams);
      err = RM_OK;
	} else if ( options->Codec == AudioDecoder_Codec_PCM ) {
		if (manutest == FALSE) {
                printf("++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
                printf("decoder = PCM\n");
		}
		if(options->SamplingFrequency == 0)
			options->SamplingFrequency = options->SampleRate;
		if ( options->SubCodec == 0 ) {
			options->PcmCdaParams.SamplingFrequency = options->SamplingFrequency;
			options->PcmCdaParams.OutputDualMode = options->OutputDualMode;
			options->PcmCdaParams.OutputSpdif = options->Spdif | (options->HDMIPassThrough ? 0x100 : 0);
			options->PcmCdaParams.OutputChannels = options->OutputChannels;
			options->PcmCdaParams.OutputLfe 		= options->OutputLfe;
			options->PcmCdaParams.SignedPCM 		= options->SignedPCM;
			options->PcmCdaParams.BassMode 		= options->BassMode;
			options->PcmCdaParams.OutputSurround20 = options->OutputSurround20;

			err = DCCSetAudioPcmCdaFormat(pAudioSource, &options->PcmCdaParams);
		} else if ( options->SubCodec == 1 ) {
			options->LpcmVobParams.SamplingFrequency = options->SamplingFrequency;
			options->LpcmVobParams.OutputDualMode = options->OutputDualMode;
			options->LpcmVobParams.OutputSpdif = options->Spdif | (options->HDMIPassThrough ? 0x100 : 0);
			options->LpcmVobParams.OutputChannels = options->OutputChannels;
			options->LpcmVobParams.BassMode 		= options->BassMode;
			options->LpcmVobParams.OutputLfe 		= options->OutputLfe;
			options->LpcmVobParams.OutputSurround20 = options->OutputSurround20;

			err = DCCSetAudioLpcmVobFormat(pAudioSource, &options->LpcmVobParams);
		} else if ( options->SubCodec == 2 ) {
			options->LpcmAobParams.SamplingFrequencyGroup1 = options->SamplingFrequency;
			options->LpcmAobParams.SamplingFrequencyGroup2 = 0;
			options->LpcmAobParams.OutputDualMode = options->OutputDualMode;
			options->LpcmAobParams.OutputSpdif = options->Spdif | (options->HDMIPassThrough ? 0x100 : 0);
			options->LpcmAobParams.OutputChannels = options->OutputChannels;
			options->LpcmAobParams.BassMode 		= options->BassMode;
			options->LpcmAobParams.OutputLfe 		= options->OutputLfe;	
			options->LpcmAobParams.OutputSurround20 = options->OutputSurround20;

			err = DCCSetAudioLpcmAobFormat(pAudioSource, &options->LpcmAobParams);
		} else if ( options->SubCodec == 3 ) {
			options->LpcmBDParams.SamplingFrequency = options->SamplingFrequency;
			options->LpcmBDParams.OutputDualMode	= options->OutputDualMode;
			options->LpcmBDParams.OutputSpdif		= options->Spdif | (options->HDMIPassThrough ? 0x100 : 0);
			options->LpcmBDParams.OutputChannels	= options->OutputChannels;
			options->LpcmBDParams.BassMode 			= options->BassMode;
			options->LpcmBDParams.OutputLfe 		= options->OutputLfe;
			options->LpcmBDParams.OutputSurround20 	= options->OutputSurround20;

			err = DCCSetAudioLpcmBDFormat(pAudioSource, &options->LpcmBDParams);
		}else
			goto generic_audio_format;
	} else if ( options->Codec == AudioDecoder_Codec_AC3 ) {

		if (manutest == FALSE) {
                printf("++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
                printf("decoder = AC3\n");
		}
		options->Ac3Params.OutputDualMode 	= options->OutputDualMode;
		options->Ac3Params.OutputSpdif 		= options->Spdif | (options->HDMIPassThrough ? 0x100 : 0);
		options->Ac3Params.OutputLfe 		= options->OutputLfe;
		options->Ac3Params.OutputChannels	= options->OutputChannels;
		options->Ac3Params.BassMode 		= options->BassMode;
		options->Ac3Params.OutputSurround20 	= options->OutputSurround20;
		
		err = DCCSetAudioAc3Format(pAudioSource, &options->Ac3Params);
	} else if ( options->Codec == AudioDecoder_Codec_DTS ) {

		options->DtsParams.OutputDualMode 	= options->OutputDualMode;
		options->DtsParams.OutputChannels	= options->OutputChannels;
		options->DtsParams.OutputLfe 		= options->OutputLfe;
		options->DtsParams.BassMode 		= options->BassMode;
		options->DtsParams.OutputSurround20 	= options->OutputSurround20;

		RMDBGLOG((LOCALDBG,">>>>>>>>options->OutputChannels = 0x%x\n", options->OutputChannels));
		options->DtsParams.OutputSpdif 		= options->Spdif | (options->HDMIPassThrough ? 0x100 : 0);

		err = DCCSetAudioDtsFormat(pAudioSource, &options->DtsParams);
	} else if ( options->Codec == AudioDecoder_Codec_TTONE ) {

                options->TToneParams.OutputDualMode       = options->OutputDualMode;
                options->TToneParams.OutputChannels       = options->OutputChannels;
                options->TToneParams.OutputLfe            = options->OutputLfe;
                options->TToneParams.BassMode             = options->BassMode;
                RMDBGLOG((ENABLE,">>>>>>>>TToneType = 0x%x, TTone_chMask = 0x%x\n<<<<<\n", options->TToneParams.TToneType, options->TToneParams.TToneChannelMask));
                options->TToneParams.OutputSpdif          = options->Spdif | (options->HDMIPassThrough ? 0x100 : 0);

                err = DCCSetAudioTToneFormat(pAudioSource, &options->TToneParams);
        } else if ( options->Codec == AudioDecoder_Codec_MPEG1 ) {

		options->MpegParams.OutputDualMode 	= options->OutputDualMode;
		options->MpegParams.OutputSpdif 	= options->Spdif | (options->HDMIPassThrough ? 0x100 : 0);
		options->MpegParams.OutputChannels = options->OutputChannels;
		options->MpegParams.BassMode 		= options->BassMode;
		options->MpegParams.OutputLfe 		= options->OutputLfe;
		options->MpegParams.OutputSurround20 	= options->OutputSurround20;

		err = DCCSetAudioMpegFormat(pAudioSource, &options->MpegParams);
	}
 	else if ( options->Codec == AudioDecoder_Codec_DVDA ) {
		options->DVDAParams.Chconfig = options->chconfig;
		options->DVDAParams.DRCenable = options->drcenable;
		options->DVDAParams.DRCboost = options->drcboost;
		options->DVDAParams.DRCcut = options->drccut;
		options->DVDAParams.DRCdialref = options->drcdialref;
		options->DVDAParams.Lossless = options->lossless;
		options->DVDAParams.OutputDualMode 	= options->OutputDualMode;
		options->DVDAParams.OutputSpdif 	= options->Spdif | (options->HDMIPassThrough ? 0x100 : 0);
		options->DVDAParams.OutputChannels = options->OutputChannels;
		options->DVDAParams.BassMode 		= options->BassMode;
		options->DVDAParams.OutputLfe 		= options->OutputLfe;
		options->DVDAParams.OutputSurround20 	= options->OutputSurround20;

		err = DCCSetAudioDVDAFormat(pAudioSource, &options->DVDAParams);

	}

  else if ( options->Codec == AudioDecoder_Codec_AAC ) {

		options->AACParams.OutputSpdif 		= options->Spdif | (options->HDMIPassThrough ? 0x100 : 0);
		options->AACParams.OutputDualMode 	= options->OutputDualMode;
		options->AACParams.OutputLfe		= options->OutputLfe;
		options->AACParams.OutputChannels	= options->OutputChannels;
		options->AACParams.BassMode 		= options->BassMode;
		options->AACParams.OutputSurround20 = options->OutputSurround20;
		
		err = DCCSetAudioAACFormat(pAudioSource, &options->AACParams);
	} else if ( options->Codec == AudioDecoder_Codec_BSAC ) {

		options->BSACParams.OutputDualMode      = options->OutputDualMode;
		options->BSACParams.OutputSpdif         = options->Spdif | (options->HDMIPassThrough ? 0x100 : 0);
		options->BSACParams.OutputLfe           = options->OutputLfe;
		options->BSACParams.OutputChannels      = options->OutputChannels;
		options->BSACParams.OutputSurround20	= options->OutputSurround20;

		err = DCCSetAudioBSACFormat(pAudioSource, &options->BSACParams);

	} else if ( options->Codec == AudioDecoder_Codec_WMAPRO || options->Codec == AudioDecoder_Codec_WMA ) {

		options->WmaParams.OutputDualMode = options->OutputDualMode;
		options->WmaParams.OutputSpdif = options->Spdif | (options->HDMIPassThrough ? 0x100 : 0);
		options->WmaParams.OutputLfe		= options->OutputLfe;
		options->WmaParams.OutputChannels	= options->OutputChannels;
		options->WmaParams.BassMode 		= options->BassMode;
		options->WmaParams.OutputSurround20	= options->OutputSurround20;

		RMDBGLOG((LOCALDBG,">>>>>>>>options->OutputChannels = 0x%x\n", options->OutputChannels));

		err = DCCSetAudioWMAFormat(pAudioSource, &options->WmaParams);
	} else {
generic_audio_format:
		{
		struct DCCAudioDecoderFormat audio_format;
		audio_format.Codec = options->Codec;
		err = DCCSetAudioDecoderSourceFormat(pAudioSource, &audio_format); 
		}
	}
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot set audio decoder format %s\n", RMstatusToString(err));
		return err;
	}
	
	{
		struct DCCAudioSourceHandle audioHandle1;

		err = DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(dcc_info->pMultipleAudioSource, options->thisAudioInstance, &audioHandle1);
		if (RMSUCCEEDED(err))  {
#ifndef WITH_OLD_AUDIO_COMMON_CODE
			RMDBGLOG((LOCALDBG, "audio playMode2 [%lu]: audio in [%llu].....audio out [%llu]\n", 
				options->audio_play_time.PlayMode,
				options->audio_play_time.PlayStartPTS,
				options->audio_play_time.PlayEndPTS));
		
			err = RUASetProperty(dcc_info->pRUA, audioHandle1.moduleID, RMAudioDecoderPropertyID_AudioPlayTime, &options->audio_play_time, sizeof(struct AudioDecoder_AudioPlayTime_type), 0);
			if (RMFAILED(err)) {
				fprintf(stderr, "Cannot set audio decoder RMAudioDecoderPropertyID_AudioPlayTime %s\n", RMstatusToString(err));				
			}

	RMDBGLOG((ENABLE, "\n*********\n AUDIO sync is %s\n*********\n", options->sync_stc?"enabled":"disabled"));
	RUASetProperty(dcc_info->pRUA, audioHandle1.moduleID, RMAudioDecoderPropertyID_SyncSTCEnable, &options->sync_stc, sizeof(RMbool), 0);

#endif
		}
		else
		{
#ifndef WITH_OLD_AUDIO_COMMON_CODE
			RMDBGLOG((LOCALDBG, "audio playMode2 [%lu]: audio in [%llu].....audio out [%llu]\n", 
				options->audio_play_time.PlayMode,
				options->audio_play_time.PlayStartPTS,
				options->audio_play_time.PlayEndPTS));
		
			err = RUASetProperty(dcc_info->pRUA, pSingleAudioSourceHandle->moduleID, RMAudioDecoderPropertyID_AudioPlayTime, &options->audio_play_time, sizeof(struct AudioDecoder_AudioPlayTime_type), 0);
			if (RMFAILED(err)) {
				fprintf(stderr, "Cannot set audio decoder RMAudioDecoderPropertyID_AudioPlayTime %s\n", RMstatusToString(err));				
			}

	RMDBGLOG((ENABLE, "\n*********\n AUDIO sync is %s\n*********\n", options->sync_stc?"enabled":"disabled"));
	RUASetProperty(dcc_info->pRUA, pSingleAudioSourceHandle->moduleID, RMAudioDecoderPropertyID_SyncSTCEnable, &options->sync_stc, sizeof(RMbool), 0);
#endif
		}
	}

	return RM_OK;
}



RMstatus apply_audio_decoder_options(struct dcc_context *dcc_info, struct audio_cmdline *options)
{
	RMstatus status;
	struct DCCAudioSourceHandle audioHandle;

	RMDBGLOG((LOCALDBG, "apply_audio_decoder_options\n"));

	if (dcc_info->pAudioSource) {

		audioHandle.pAudioSource = dcc_info->pAudioSource;
		audioHandle.engineID = dcc_info->audio_engine;
		audioHandle.moduleID = dcc_info->audio_decoder;

		return apply_audio_decoder_options_with_handle(dcc_info, options, &audioHandle);
	}
	else if (dcc_info->pMultipleAudioSource) {

		status = DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(dcc_info->pMultipleAudioSource, options->thisAudioInstance, &audioHandle);
		if (status != RM_OK)
			return status;

		return apply_audio_decoder_options_with_handle(dcc_info, options, &audioHandle);
	}
	
	return RM_ERROR;

}





RMstatus parse_wmapro_intermediate(RMfile file, struct AudioDecoder_WMAParameters_type *options)
{
	RMstatus 			err = RM_ERROR;
	SEQUENCE_HEADER		hdr;
	
	/* Table used to look up sample frequency */
	static unsigned int sampleFreqTable[] = {	
		8000,
		11025,
		12000,
		16000,
		22050,
		24000,
		32000,
		44100,
		48000,
		64000,
		88200,
		96000,
		128000,
		176300,
		192000,
	};

	if (file) {
		RMuint32 	data;
		RMbool		bFoundSeqHdr = FALSE;
		RMuint32	bytesRead = sizeof(RMuint32);
		int			nIndex = 0;
		RMstatus status = RM_OK;

		memset(&hdr, 0, sizeof(SEQUENCE_HEADER));

/*	Find the sequence header */

		while ((bytesRead == sizeof(RMuint32)) && (bFoundSeqHdr == FALSE)) {
			status = RMReadFile(file, (RMuint8 *) &data, sizeof(RMuint32), &bytesRead);
			if (RMSUCCEEDED(status) &&
			    (SWAP_DWORD(data) == SEQUENCE_START_CODE)) {
				fprintf(stderr, "-- found start code!\n");
				bFoundSeqHdr = TRUE;
			}
		}

		if (bFoundSeqHdr) {
			status = RMReadFile(file,  (RMuint8 *)&hdr, sizeof(SEQUENCE_HEADER), &bytesRead);

			if (RMSUCCEEDED(status) &&
			    (bytesRead == sizeof(SEQUENCE_HEADER))) {
				options->VersionNumber				= 0x162;
#ifdef	_DEBUG
				printf("nChannels = %ld sps = %d bitsPerSample = %ld channelMask = %ld\n",
						hdr.nChannels, sampleFreqTable[SWAP_DWORD(hdr.nSamplesPerSec)], hdr.nValidBitsPerSample, hdr.nChannelMask);
#endif	
				options->NumberOfChannels			= SWAP_DWORD(hdr.nChannels);
				nIndex								= SWAP_DWORD(hdr.nSamplesPerSec);
				if ((nIndex >= 0) && (nIndex <= 14)) {
					options->SamplingFrequency		= sampleFreqTable[nIndex];
				}
				options->PacketSize					= SWAP_DWORD(hdr.nSampleFrame);
				options->WMAProValidBitsPerSample	= SWAP_DWORD(hdr.nValidBitsPerSample);
				options->WMAProChannelMask			= SWAP_DWORD(hdr.nChannelMask);
				options->EncoderOptions				= SWAP_DWORD(hdr.encoder_options);

				err = RM_OK;
			} else {
				fprintf(stderr, "ERROR: Unable to read sequence header!\n");
			}
		} else {
			fprintf(stderr, "ERROR: Unable to locate sequence header!\n");
		}
	} else {
		fprintf(stderr, "ERROR: Invalid file handle [%p]\n", file);
	}

	return err;
}
