/*
 *
 * Copyright (c) Sigma Designs, Inc. 2002. All rights reserved.
 *
 */

/**
	@file dcc_demo.c
	@brief sample application to access the Mambo chip and test DMA transfers
	
	@author Julien Soulier
	@ingroup dccsamplecode
*/
#include "sample_os.h"

#define ENABLE_SPU_OP 1

#define ALLOW_OS_CODE 1
#include "../dcc/include/dcc.h"
#include "../rmvdemux/include/rmvdemuxapi.h"
#include "common.h"
#include "../gbuslib/include/gbus_fifo.h"

#define PTS_DISCONTINUITY_DETECTION	/* defined for files with pts discontinuities */

#define GETBUFFER_TIMEOUT_US (TIMEOUT_10MS)
#define SENDDATA_TIMEOUT_US  (TIMEOUT_10MS)

#define DMA_BUFFER_SIZE_LOG2 15
#define DMA_BUFFER_COUNT     32

#define REPACK_SIZE (4096)

#define VIDEO_FIFO_SIZE (1792*1024)
#define AUDIO_FIFO_SIZE (128*1024)
#define SPU_FIFO_SIZE   (256*1024)
#define XFER_FIFO_COUNT (32)
#define VIDEO_PTS_FIFO_COUNT (512) /* ~8 sec fifo for 60 frames/sec */
#define VIDEO_INBAND_FIFO_COUNT (16)

#define RM_DEVICES_STC 0x1
#define RM_DEVICES_VIDEO 0x2
#define RM_DEVICES_AUDIO 0x4

#define KEYFLAGS (SET_KEY_DISPLAY | SET_KEY_PLAYBACK | SET_KEY_AUDIO | SET_KEY_DEBUG)

#define PTS_DISCONTINUITY_RANGE	0x20000	// ~1.4sec

#if 0
  #define SENDDBG ENABLE
#else
  #define SENDDBG DISABLE
#endif

#if 0
#define KEYDBG ENABLE
#else
#define KEYDBG DISABLE
#endif

#define WAIT_KEY()						\
{								\
	RMascii key;						\
	fprintf(stderr, "press key to continue\n");	        \
	while ( !(RMGetKeyNoWait(&key)) );			\
}							


#define GET_XFER_FIFO_INFO(pRUA, ModuleId)										\
{															\
	struct XferFIFOInfo_type XferFIFOInfo;										\
	fprintf(stderr, "( %lx: 0x%08lx %ld %ld %ld %ld ) ", ModuleId, XferFIFOInfo.StartAddress,          		\
		    XferFIFOInfo.Size, XferFIFOInfo.Writable,  XferFIFOInfo.Readable, XferFIFOInfo.Erasable);		\
	RUAGetProperty(pRUA, ModuleId, RMGenericPropertyID_XferFIFOInfo, &XferFIFOInfo, sizeof(XferFIFOInfo));		\
}														



extern int verbose_stdout;
extern int verbose_stderr;
extern RMbool manutest;

static RMbool enable_spu = FALSE;
static RMuint32 NTimes = 0;
static RMuint32 file_offset = 0;
static struct llad *pllad = NULL;
static struct gbus *pgbus = NULL;

enum user_data_application_mode {
	no_user_data,                       /* no user data saving; default behavior */
	user_data_dma_full_buffer,          /* complete the dma buffer when it is full; default behavior */
	user_data_dma_no_delay,             /* complete the dma buffer as soon as the microcode sends data */
	user_data_dma_minimum_size,         /* complete the dma buffer when the buffer has more than the threshold value */
	user_data_dma_exact_size,           /* complete the dma buffer when the buffer has exact size of the threshold value */
	user_data_get_chunk256_without_dma, /* get directly from user data fifo */
	user_data_rua_mapping_without_dma,  /* get directly from user data fifo */
};
static enum user_data_application_mode user_data_app_mode = user_data_dma_no_delay;

static RMuint32 trickBuffersToSend = 0;
static RMuint32 trickSizeToSend = 0;
static RMuint32 trickBuffersSent = 0;
//static RMuint32 prev_trickmode;

static struct playback_cmdline *play_opt;
static struct video_cmdline *video_opt;
static struct display_cmdline *disp_opt;
static struct audio_cmdline *audio_opt;
static struct demux_cmdline *demux_opt;

static RMuint32 manutest_res = 0;

struct demux_context {
	struct RUA *pRUA;
	struct RUABufferPool *pDMA;
	RMbool FirstSystemTimeStamp;
	RMbool ResumeFromTrickMode;

	RMuint32 audio_byte_counter;
	RMuint32 video_byte_counter;
	RMbool repack_sample;
	RMuint8 *audio_repack_buf;
	RMuint8 *video_repack_buf;
	RMuint8 *spu_repack_buf;
	RMuint32 audio_repack_offset;
	RMuint32 video_repack_offset;
	RMuint32 spu_repack_offset;
	RMuint32 audio_repack_size;
	RMuint32 video_repack_size;
	RMuint32 spu_repack_size;
	RMuint64 audio_repack_pts;
	RMuint64 video_repack_pts;
	RMuint64 spu_repack_pts;
	RMbool audio_repack_pts_valid;
	RMbool video_repack_pts_valid;
	RMbool spu_repack_pts_valid;
	RMbool enable_spu;

	struct dcc_context *dcc_info;
	struct RM_PSM_Context   *PSMcontext;

	RMbool isTrickMode;
	RMbool isIFrameMode;
	RMbool initVideo;
	RMbool initAudio;

	RMbool waitForValidAudioPTS;
	RMbool waitForValidVideoPTS;

	RMuint32 cmd;
	RMuint32 audio_first_access_unit_pointer;	// a value of 0 is invalid - see DVD VI.5.2.4
	RMbool audio_first_access_unit_pointer_valid;
	
	RMuint32 start_90khz;
	RMint64 file_size;
	// test user data receive
	struct ReceiveObject_type *pReceive;
	struct RUABufferPool *pDmaUserData;
	FILE *f_record;
	RMuint32 f_record_size;
	/* variables needed to get user data directly from fifo, without DMA transfers */
	RMuint8	*pmapped_user_data_fifo_base;
	RMuint32 user_data_fifo_container;
	RMuint32 user_data_fifo_base;
	RMuint32 user_data_fifo_size;

	RMbool ignoreCallback;
	RMbool fakePrevPts;

	RMuint32 prebufferedBytes;
	RMint64 realFirstPTS;
};

static RMstatus SyncTimerWithDecoderPTS(struct demux_context *pSendContext);

#define REPACK_AUDIO  1
#define REPACK_VIDEO  2
#define REPACK_SPU    4
#define REPACK_ALL    7

static void release_repacked_buffers(void *context, RMuint32 flag)
{
	struct demux_context *pSendContext = (struct demux_context *) context;
	
	if ((flag & REPACK_VIDEO) & (pSendContext->video_repack_buf != NULL)) {
		RUAReleaseBuffer(pSendContext->pDMA, pSendContext->video_repack_buf);
		pSendContext->video_repack_buf = (RMuint8 *) NULL;
		pSendContext->video_repack_offset = 0;
		pSendContext->video_repack_size = 0;
		pSendContext->video_repack_pts = 0;
		pSendContext->video_repack_pts_valid = FALSE;
	}

	if ((flag & REPACK_AUDIO) && (pSendContext->audio_repack_buf != NULL)) {
		RUAReleaseBuffer(pSendContext->pDMA, pSendContext->audio_repack_buf);
		pSendContext->audio_repack_buf = (RMuint8 *) NULL;
		pSendContext->audio_repack_offset = 0;
		pSendContext->audio_repack_size = 0;
		pSendContext->audio_repack_pts = 0;
		pSendContext->audio_repack_pts_valid = FALSE;
	}

	if ((flag & REPACK_SPU) && (pSendContext->spu_repack_buf != NULL)) {
		RUAReleaseBuffer(pSendContext->pDMA, pSendContext->spu_repack_buf);	
		pSendContext->spu_repack_buf = (RMuint8 *) NULL;
		pSendContext->spu_repack_offset = 0;
		pSendContext->spu_repack_size = 0;
		pSendContext->spu_repack_pts = 0;
		pSendContext->spu_repack_pts_valid = FALSE;
	}
}



static struct RM_PSM_Actions actions;

#define PROCESS_KEY(release, getkey)					\
do {								        \
	RMDBGLOG((KEYDBG, "processkey(%lu, %lu)\n", release, getkey));		\
	if (getkey) {							\
		PlaybackStatus = RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)); \
		if ((PlaybackStatus == RM_PSM_Stopped) || (PlaybackStatus == RM_PSM_Paused)) { \
			switch (play_opt->disk_ctrl_state) {		\
			case DISK_CONTROL_STATE_DISABLE:		\
			case DISK_CONTROL_STATE_SLEEPING:		\
				break;					\
			case DISK_CONTROL_STATE_RUNNING:		\
				if(play_opt->disk_ctrl_callback && play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_SLEEP) == RM_OK) \
					play_opt->disk_ctrl_state = DISK_CONTROL_STATE_SLEEPING; \
				break;					\
			}						\
		}							\
		err = process_command(&PSMContext, &(context.dcc_info), &actions); \
		if (RMFAILED(err)) {					\
			fprintf(stderr, "Error processing key %d\n", err); \
			goto cleanup;					\
		}							\
	}								\
	if (actions.toDoActions & RM_PSM_FLUSH_VIDEO) {			\
		RMDBGLOG((ENABLE, "flushVIDEO\n"));			\
		Stop(&context, RM_DEVICES_VIDEO, DCCStopMode_LastFrame); \
		actions.toDoActions &= ~RM_PSM_FLUSH_VIDEO;		\
	}								\
	if (actions.toDoActions & RM_PSM_FIRST_PTS) {			\
		RMDBGLOG((ENABLE, "firstPTS\n"));			\
		/*context.FirstSystemTimeStamp = TRUE;*/		\
		actions.toDoActions &= ~RM_PSM_FIRST_PTS;		\
	}								\
	if (actions.performedActions & RM_PSM_VIDEO_STOPPED) {		\
		RMDBGLOG((ENABLE, "video stopped\n"));			\
		context.initVideo = TRUE;				\
		actions.performedActions &= ~RM_PSM_VIDEO_STOPPED;	\
	}								\
	if (actions.performedActions & RM_PSM_AUDIO_STOPPED) {		\
		RMDBGLOG((ENABLE, "audio stopped\n"));			\
		if (release) {						\
			if (context.repack_sample) {			\
				RMDBGLOG((ENABLE, "release audio buffers\n")); \
				release_repacked_buffers(&context, REPACK_AUDIO); \
			}						\
			else  {						\
				RMDBGLOG((ENABLE, "release a buffer\n")); \
				RUAReleaseBuffer(pDMA, buf);		\
				buf = NULL;				\
			}						\
		}							\
		context.initAudio = TRUE;				\
		context.waitForValidAudioPTS = TRUE;			\
		actions.performedActions &= ~RM_PSM_AUDIO_STOPPED;	\
	}								\
	if ((actions.cmd == RM_QUIT) && (!actions.cmdProcessed)) {	\
		RMDBGLOG((ENABLE, "quit\n"));				\
		actions.cmdProcessed = TRUE;				\
		if (manutest == TRUE)                                   \
		        manutest_res = RM_QUIT;                         \
		if (release) {						\
			if (context.repack_sample) {			\
				RMDBGLOG((ENABLE, "release audio buffers\n")); \
				release_repacked_buffers(&context, REPACK_ALL); \
			}						\
			else  {						\
				RMDBGLOG((ENABLE, "release a buffer\n")); \
				RUAReleaseBuffer(pDMA, buf);		\
				buf = NULL;				\
			}						\
		}							\
		goto cleanup;						\
	}								\
	if ((manutest == TRUE) && (actions.cmd == RM_MANU_QUIT_OK) && (!actions.cmdProcessed)) { \
		if (manutest == TRUE)                                   \
		        manutest_res = RM_MANU_QUIT_OK;                 \
		if (release) {						\
			if (context.repack_sample) {			\
				RMDBGLOG((ENABLE, "release audio buffers\n")); \
				release_repacked_buffers(&context, REPACK_ALL); \
			}						\
			else  {						\
				RMDBGLOG((ENABLE, "release a buffer\n")); \
				RUAReleaseBuffer(pDMA, buf);		\
				buf = NULL;				\
			}						\
		}							\
		goto cleanup;						\
	}								\
	if (((RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Slow) || \
	     (RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Fast) || \
	     (RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_NextPic)) && \
	    (actions.cmdProcessed) && (!context.isTrickMode)) {		\
		RMDBGLOG((ENABLE, ">> trick mode all frames\n"));	\
		context.isTrickMode = TRUE;				\
	}								\
	if ((RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Playing) && \
	    (context.isTrickMode) &&					\
	    (actions.cmdProcessed)) {					\
		RMDBGLOG((ENABLE, ">> resume from trickmode\n"));	\
		context.isTrickMode = FALSE;				\
	}								\
	if (actions.toDoActions & RM_PSM_DEMUX_NORMAL) {		\
		RMDBGLOG((ENABLE, "demuxNormal\n"));			\
		context.isTrickMode = FALSE;				\
		Play(&context, RM_DEVICES_VIDEO, DCCVideoPlayFwd);	\
		actions.toDoActions &= ~RM_PSM_DEMUX_NORMAL;		\
	}								\
	if (actions.toDoActions & RM_PSM_DEMUX_IFRAME) {		\
		RMDBGLOG((ENABLE, "demuxIFrame\n"));			\
		Play(&context, RM_DEVICES_VIDEO | RM_DEVICES_STC, DCCVideoPlayIFrame);	\
		context.isIFrameMode = TRUE;				\
		if (context.ignoreCallback)				\
			context.ignoreCallback = FALSE;			\
		actions.toDoActions &= ~RM_PSM_DEMUX_IFRAME;		\
	}								\
	if (actions.toDoActions & RM_PSM_RESYNC_TIMER) {		\
		RMDBGLOG((ENABLE, "resyncTimer\n"));			\
		SyncTimerWithDecoderPTS(&context);			\
		actions.toDoActions &= ~RM_PSM_RESYNC_TIMER;		\
	}								\
	if ((RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Stopped) && (actions.cmdProcessed)) { \
		RMDBGLOG((ENABLE,"Got stop command\n"));		\
		if (release) {						\
			if (context.repack_sample) {			\
				RMDBGLOG((ENABLE, "release audio buffers\n")); \
				release_repacked_buffers(&context, REPACK_ALL); \
			}						\
			else  {						\
				RMDBGLOG((ENABLE, "release a buffer\n")); \
				RUAReleaseBuffer(pDMA, buf);		\
				buf = NULL;				\
			}						\
		}							\
		context.isIFrameMode = FALSE;				\
		context.FirstSystemTimeStamp = TRUE;			\
		goto mainloop_no_seek;					\
	}								\
	if ((actions.cmd == RM_STOP_SEEK_ZERO) && (!actions.cmdProcessed)) {	\
		RMDBGLOG((ENABLE,"Got stop seek zero command\n"));	\
		Stop(&context, RM_DEVICES_VIDEO | RM_DEVICES_AUDIO | RM_DEVICES_STC, DCCStopMode_BlackFrame); \
		RM_PSM_SetState(context.PSMcontext, &(context.dcc_info), RM_PSM_Stopped); \
		context.isIFrameMode = FALSE;				\
		context.FirstSystemTimeStamp = TRUE;				\
		actions.cmdProcessed = TRUE;				\
		if (release) {						\
			if (context.repack_sample) {			\
				RMDBGLOG((ENABLE, "release audio buffers\n")); \
				release_repacked_buffers(&context, REPACK_ALL); \
			}						\
			else  {						\
				RMDBGLOG((ENABLE, "release a buffer\n")); \
				RUAReleaseBuffer(pDMA, buf);		\
				buf = NULL;				\
			}						\
		}							\
		goto mainloop;						\
	}								\
	if ((actions.cmd == RM_SEEK) && (!actions.cmdProcessed)) {	\
		RMDBGLOG((ENABLE, "got seek command\n"));		\
		Stop(&context, RM_DEVICES_AUDIO | RM_DEVICES_VIDEO | RM_DEVICES_STC, DCCStopMode_LastFrame); \
		context.isIFrameMode = FALSE;				\
		context.FirstSystemTimeStamp = TRUE;			\
		context.ignoreCallback = FALSE;				\
		if (release) {						\
			if (context.repack_sample) {			\
				RMDBGLOG((ENABLE, "release audio buffers\n")); \
				release_repacked_buffers(&context, REPACK_ALL); \
			}						\
			else  {						\
				RMDBGLOG((ENABLE, "release a buffer\n")); \
				RUAReleaseBuffer(pDMA, buf);		\
				buf = NULL;				\
			}						\
		}							\
		goto mainloop_no_seek;					\
	}								\
	if ((actions.cmd == RM_DUALMODE_CHANGE) && (!actions.cmdProcessed)) { \
		RMDBGLOG((ENABLE, "got dualmode change\n"));		\
		fprintf(stderr, "Changing DualMode to :");		\
		switch(audio_opt->OutputDualMode) {								\
		case DualMode_LeftMono:										\
			fprintf(stderr, " RightMono\n");							\
			audio_opt->OutputDualMode = DualMode_RightMono;						\
			break;											\
		case DualMode_RightMono:									\
			fprintf(stderr, " MixMono\n");								\
			audio_opt->OutputDualMode = DualMode_MixMono;						\
			break;											\
		case DualMode_MixMono:										\
			fprintf(stderr, " Stereo\n");								\
			audio_opt->OutputDualMode = DualMode_Stereo;						\
			break;											\
		case DualMode_Stereo:										\
			fprintf(stderr, " LeftMono\n");								\
			audio_opt->OutputDualMode = DualMode_LeftMono;						\
			break;											\
		default:											\
			fprintf(stderr, " Unknown dual mode\n");						\
			break;											\
		}												\
		err = apply_audio_decoder_options_onthefly(&dcc_info,audio_opt);				\
		if (RMFAILED(err)) {										\
			fprintf(stderr, "Error applying audio decoder options on the fly %d\n", err);		\
		}												\
	}													\
} while (0)


#define PROCESS_KEY_INSIDE_FUNCTION()					\
do	{								\
	RMstatus err;							\
	enum RM_PSM_State PlaybackStatus;				\
									\
	RMDBGLOG((KEYDBG, "processkey_inside_function\n"));		\
	err = process_command(pSendContext->PSMcontext, &(pSendContext->dcc_info), &actions); \
	if (RMFAILED(err)) {						\
		RMDBGLOG((ENABLE, "Error while processing key %d\n", err)); \
		goto return_from_callback;				\
	}								\
	PlaybackStatus = RM_PSM_GetState(pSendContext->PSMcontext, &(pSendContext->dcc_info)); \
	if (actions.toDoActions & RM_PSM_RESYNC_TIMER) {		\
		RMDBGLOG((ENABLE, "resyncTimer\n"));			\
		SyncTimerWithDecoderPTS(pSendContext);			\
		actions.toDoActions &= ~RM_PSM_RESYNC_TIMER;		\
	}								\
	if ((actions.cmd == RM_QUIT) && (!actions.cmdProcessed)) {	\
		RMDBGLOG((ENABLE, "quit during callback\n"));		\
		pSendContext->ignoreCallback = TRUE;			\
		if (manutest == TRUE)                                   \
		    manutest_res = RM_QUIT;                             \
		goto return_from_callback;				\
	} 								\
	if ((manutest == TRUE) && (actions.cmd == RM_MANU_QUIT_OK) && (!actions.cmdProcessed)) {	\
		RMDBGLOG((ENABLE, "quit during callback\n"));		\
		pSendContext->ignoreCallback = TRUE;			\
		if (manutest == TRUE)                                   \
		    manutest_res = RM_MANU_QUIT_OK;                     \
		goto return_from_callback;				\
	} 								\
	if ((PlaybackStatus == RM_PSM_Stopped) && (actions.cmdProcessed)) { \
		RMDBGLOG((ENABLE, "stop during callback\n"));		\
		pSendContext->ignoreCallback = TRUE;			\
		goto return_from_callback;				\
	}								\
	if ((actions.cmd == RM_STOP_SEEK_ZERO) && (!actions.cmdProcessed)) { \
		RMDBGLOG((ENABLE, "seekzero during callback\n"));	\
		pSendContext->ignoreCallback = TRUE;			\
		goto return_from_callback;				\
	}								\
	if ((actions.cmd == RM_SEEK) && (!actions.cmdProcessed)){	\
		RMDBGLOG((ENABLE, "seek during callback\n"));		\
		pSendContext->ignoreCallback = TRUE;			\
		goto return_from_callback;				\
	}								\
	if (((PlaybackStatus == RM_PSM_IForward) ||			\
	    (PlaybackStatus == RM_PSM_IRewind)) && (actions.cmdProcessed)) {	\
		RMDBGLOG((ENABLE, "iframe trick during callback\n"));	\
		pSendContext->ignoreCallback = TRUE;			\
		goto return_from_callback;				\
	}								\
	if (((PlaybackStatus == RM_PSM_Slow) ||		\
	     (PlaybackStatus == RM_PSM_Fast)) && (actions.cmdProcessed)) { \
		RMDBGLOG((ENABLE,"trickmodes during callback\n"));	\
		pSendContext->isTrickMode = TRUE;			\
		pSendContext->ignoreCallback = FALSE;			\
	}								\
} while(0)




#ifndef WITH_MONO


static RMstatus parse_demux_type(char *demuxstr)
{
	if ((bcmp(demuxstr, "mpeg1", 3)) == 0) {
		if (verbose_stderr != 0)
			fprintf(stderr, "file is mpeg1 system\n");
		demux_opt->system_type = RM_SYSTEM_MPEG1;
		return RM_OK;
	}
	
	if ((bcmp(demuxstr, "dvd", 3)) == 0) {
		if (verbose_stderr != 0)
			fprintf(stderr, "file is vob\n");
		demux_opt->system_type = RM_SYSTEM_MPEG2_DVD;
		return RM_OK;
	}

	if ((bcmp(demuxstr, "aob", 3)) == 0) {
		if (verbose_stderr != 0)
			fprintf(stderr, "file is aob\n");
		demux_opt->system_type = RM_SYSTEM_MPEG2_DVD_AUDIO;
		return RM_OK;
	}

	if ((bcmp(demuxstr, "m2t192", 6)) == 0) {
		if (verbose_stderr != 0)
			fprintf(stderr, "file is m2t192\n");
		demux_opt->system_type = RM_SYSTEM_MPEG2_TRANSPORT_192;
		return RM_OK;
	}
	
	if ((bcmp(demuxstr, "m2t", 3)) == 0) {
		if (verbose_stderr != 0)
			fprintf(stderr, "file is m2t\n");
		demux_opt->system_type = RM_SYSTEM_MPEG2_TRANSPORT;
		return RM_OK;
	}
	
	if ((bcmp(demuxstr, "m2p", 3)) == 0) {
		if (verbose_stderr != 0)
			fprintf(stderr, "file is m2p\n");
		demux_opt->system_type = RM_SYSTEM_MPEG2_PROGRAM;
		return RM_OK;
	}

	if ((bcmp(demuxstr, "vbs", 3)) == 0) {
		if (verbose_stderr != 0)
			fprintf(stderr, "file is elementary video\n");
		demux_opt->system_type = RM_SYSTEM_UNKNOWN;
		demux_opt->data_type = RMVDEMUX_VIDEO;
		return RM_OK;
	}
	
	if ((bcmp(demuxstr, "abs", 3)) == 0) {
		if (verbose_stderr != 0)
			fprintf(stderr, "file is elementary audio\n");
		demux_opt->system_type = RM_SYSTEM_UNKNOWN;
		demux_opt->data_type = RMVDEMUX_AUDIO;
		return RM_OK;
	}
	
	return RM_ERROR;
}

static void show_usage(char *progname)
{
	fprintf(stderr, "DEMUX OPTIONS (default values inside brackets)\n"
		"\t-y <demux type>: Selects the demux type\n"
		"\t\t[mpeg1], m2p, m2t, m2t192, dvd, vbs, abs, aob\n"
		"\t-vpid: video PID (else, first video stream will be played)\n"
		"\t-apid: audio PID (else, first audio stream will be played)\n"
		"\t-asubid: audio substream id (else, first audio substream will be played)\n"
		"\t-ssubid: spu substream id (else, first spu substream will be played)\n"
		"\t-z: Repacketizes packets (needed for transport streams) [FALSE]\n"
		"\t-spu: Enables subpicture [FALSE]\n"
		"\t-dur: Specifies the duration of the stream, on ms. Required for seeking\n"
		);
	
	show_playback_options();
	show_display_options();
	show_video_options();
	show_audio_options();
	
	fprintf(stderr, "--------------------------------\n");
	fprintf(stderr, "Minimum cmd line: %s <file name>\n", progname);
	fprintf(stderr, "--------------------------------\n");
	
	exit(1);
}

static void parse_cmdline(int argc, char *argv[])
{
	int i;
	RMstatus err;
	/* init default demux_opt */
	demux_opt->system_type = RM_SYSTEM_MPEG1;
	demux_opt->data_type = RMVDEMUX_VIDEO;
	demux_opt->repack_sample = FALSE;
	demux_opt->video_pid = 0;
	demux_opt->audio_pid = 0;
	demux_opt->audio_subid = 0;
	demux_opt->spu_subid = 0;
	
	if (argc < 2) 
		show_usage(argv[0]);
	
	i = 1;
	while ((argc > i)) {
		if (argv[i][0] != '-') {
			if (play_opt->filename == NULL) {
				play_opt->filename = argv[i];
				i++;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-y")) {
			if (argc > i+1) { 
				err = parse_demux_type(argv[i+1]);
				if (RMFAILED(err))
					show_usage(argv[0]);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-z")) {
			demux_opt->repack_sample = TRUE;
			i++;
		}
		else if ( ! strcmp(argv[i], "-spu")) {
			enable_spu = TRUE;
			i++;
		}
		else if ( ! strcmp(argv[i], "-vpid")) {
			if (argc > i+1) {
				demux_opt->video_pid = strtol(argv[i+1], NULL, 0);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-apid")) {
			if (argc > i+1) {
				/* permitted values should be 0xC0-0xDF, 0xBD, (decimal 192-223, 189) */
				demux_opt->audio_pid = strtol(argv[i+1], NULL, 0);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-asubid")) {
			if (argc > i+1) {
				demux_opt->audio_subid = strtol(argv[i+1], NULL, 0);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-ssubid")) {
			if (argc > i+1) {
				demux_opt->spu_subid = strtol(argv[i+1], NULL, 0);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-dur")) {
			if (argc > i+1) {
				play_opt->duration = strtol(argv[i+1], NULL, 10);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else {
			err = parse_playback_cmdline(argc, argv, &i, play_opt);
			if (err == RM_ERROR)
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_display_cmdline(argc, argv, &i, disp_opt);
			if (err == RM_ERROR)
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_video_cmdline(argc, argv, &i, video_opt);
			if (err == RM_ERROR)
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_audio_cmdline(argc, argv, &i, audio_opt);
			if (RMFAILED(err))
				show_usage(argv[0]);
		}
	}

	if (play_opt->filename == NULL)
		show_usage(argv[0]);

	if (manutest == TRUE) {
		if (demux_opt->data_type == RMVDEMUX_VIDEO) {
			switch(disp_opt->connector) {
				case DCCVideoConnector_COMPOSITE:
					fprintf(stdout, "Please check Composite output ..");
					break;
				case DCCVideoConnector_COMPONENT:
					fprintf(stdout, "Please check Component output ..");
					break;
				case DCCVideoConnector_SVIDEO:
					fprintf(stdout, "Please check S-Video output ..");
					break;
				case DCCVideoConnector_DVI:
					fprintf(stdout, "Please check DVI-A output ..");
					break;
				case DCCVideoConnector_Digital:
					fprintf(stdout, "Please check DVI-D output ..");
					break;
				case DCCVideoConnector_VGA:
					fprintf(stdout, "Please check VGA output ..");
					break;
				case DCCVideoConnector_SCART:
					fprintf(stdout, "Please check SCART output ..");
					break;
				case DCCVideoConnector_LVDS:
					fprintf(stdout, "Please check LVDS output ..");
					break;
				default:
					fprintf(stdout, "Please check default output ..");
					break;
			}
		} else if (demux_opt->data_type == RMVDEMUX_AUDIO) {
			fprintf(stdout, "Please check audio output ..");
		}
	}
}
#endif


static RMstatus Stop(struct demux_context * pSendContext, RMuint32 devices, enum DCCStopMode mode)
{
	RMstatus err = RM_OK;
	struct dcc_context *dcc_info = pSendContext->dcc_info;
	
	if (devices & RM_DEVICES_VIDEO) {
		if (pSendContext->dcc_info->pVideoSource) {
			RMDBGLOG((ENABLE, "STOP: video decoder\n"));
			err = DCCStopVideoSource(dcc_info->pVideoSource, mode);
			if (RMFAILED(err)){
				RMDBGLOG((ENABLE, "Error stopping video source %d\n", err));
				return err;
			}
			pSendContext->initVideo = TRUE;

		}
	}

	if (devices & RM_DEVICES_AUDIO) {
		if (pSendContext->dcc_info->pAudioSource) {
			RMDBGLOG((ENABLE, "STOP: audio decoder\n"));
			err = DCCStopAudioSource(dcc_info->pAudioSource);
			if (RMFAILED(err)){
				RMDBGLOG((ENABLE,"Error stopping audio source %d\n", err));
				return err;
			}
		}
	}

	if ((devices & RM_DEVICES_AUDIO) && (devices & RM_DEVICES_VIDEO)) {
		pSendContext->FirstSystemTimeStamp = TRUE;
	}

	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "STOP: stc\n"));
		DCCSTCStop(dcc_info->pStcSource);
	}

	return err;

}

static RMstatus Play(struct demux_context * pSendContext, RMuint32 devices, enum DCCVideoPlayCommand mode)
{

	RMstatus err = RM_OK;
	struct dcc_context *dcc_info = pSendContext->dcc_info;
	
	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "PLAY: stc\n"));
		DCCSTCPlay(dcc_info->pStcSource);
	}

	if (devices & RM_DEVICES_VIDEO) {
		if (pSendContext->dcc_info->pVideoSource) {
			if (pSendContext->initVideo) {
				RMbool keep_sequence = TRUE;
				RMDBGLOG((ENABLE, "PLAY: initDecoder\n"));
				err = RUASetProperty(pSendContext->dcc_info->pRUA, pSendContext->dcc_info->video_decoder, RMVideoDecoderPropertyID_StorePreviousVideoHeader, &keep_sequence, sizeof(keep_sequence), 0);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Error setting video decoder to keep sequence header on Stop %d\n", err));
					return err;
				}
				pSendContext->initVideo = FALSE;
			}

			RMDBGLOG((ENABLE, "PLAY: video decoder %s\n", (mode == DCCVideoPlayIFrame ? "(iframe)":"")));
			err = DCCPlayVideoSource(pSendContext->dcc_info->pVideoSource, mode);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot play video decoder %d\n", err));
				return err;
			}
		}
	}

	if (devices & RM_DEVICES_AUDIO) {
		if (pSendContext->dcc_info->pAudioSource) {
			RMDBGLOG((ENABLE, "PLAY: audio decoder\n"));
			err = DCCPlayAudioSource(dcc_info->pAudioSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot play video decoder %d\n", err));
				return err;
			}
		}
	}


	return err;

}



// used for prebuffering
static RMstatus Pause(struct demux_context * pSendContext, RMuint32 devices)
{

	RMstatus err = RM_OK;
	
	if (devices & RM_DEVICES_VIDEO) {
		if (pSendContext->dcc_info->pVideoSource) {
			RMDBGLOG((ENABLE, "PAUSE: video decoder\n"));
			err = DCCPauseVideoSource(pSendContext->dcc_info->pVideoSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot pause video decoder %d\n", err));
				return err;
			}
		}
	}

	if (devices & RM_DEVICES_AUDIO) {
		if (pSendContext->dcc_info->pAudioSource) {
			RMDBGLOG((ENABLE, "PAUSE: audio decoder\n"));
			err = DCCPauseAudioSource(pSendContext->dcc_info->pAudioSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot pause video decoder %d\n", err));
				return err;
			}
		}
	}

	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "PAUSE: stc\n"));
		DCCSTCStop(pSendContext->dcc_info->pStcSource);
	}

	return err;

}


static RMstatus SyncTimerWithDecoderPTS(struct demux_context *pSendContext)
{
	RMuint64 videoPTS;
	RMuint64 CurrentSTC;
	RMstatus err = RM_OK;
	RMuint32 timeScale;

	/* we have to obtain the timeScale because in mpeg4 elementary 
	   streams, the time scale is not guaranteed to be 90KHz 
	*/
	DCCSTCGetTimeResolution(pSendContext->dcc_info->pStcSource, DCC_Video, &timeScale);

	DCCSTCGetTime(pSendContext->dcc_info->pStcSource, &CurrentSTC, timeScale);

	err = RUAGetProperty(pSendContext->pRUA, pSendContext->dcc_info->SurfaceID, RMGenericPropertyID_CurrentDisplayPTS, &videoPTS, sizeof(videoPTS));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "error %d while getting CurrentDisplayPTS\n", err));
		return err;
	}

	/* for MPEG1/2, timeScale 90000, videoPTS unit is 45000 always,
	   for MPEG4, timeScale is the same than videoPTS unit.
	   Note however, that we're just checking the value of timeScale, so
	   if we're in MPEG4 and timeScale 90000, this wont work. Also note that
	   this happens with elementary streams which are to be handled by
	   play_video not play_demux. 
	*/
	if (timeScale == 90000)
		videoPTS *= 2;
	

	RMDBGLOG((ENABLE, ">> resync timer (%llu) with videoDecoder current PTS (%llu), unit %lu\n", CurrentSTC, videoPTS, timeScale));
	DCCSTCSetTime(pSendContext->dcc_info->pStcSource, videoPTS, timeScale);

#ifdef PTS_DISCONTINUITY_DETECTION
	pSendContext->fakePrevPts = TRUE;
#endif


	return RM_OK;
	
}


static RMbool check_prebuf_state(struct demux_context *pSendContext, RMuint32 buffersize)
{
	RMbool quit_prebuf;
	enum RM_PSM_State PlaybackStatus = RM_PSM_GetState(pSendContext->PSMcontext, &(pSendContext->dcc_info));
	
	if (PlaybackStatus != RM_PSM_Prebuffering)
		return FALSE;

	/* if fail in getbuffer/senddata force quitting prebuffering state */
	quit_prebuf = ((buffersize == 0) || ((play_opt->prebuf_max > 0) && (pSendContext->prebufferedBytes >= play_opt->prebuf_max))) ? TRUE : FALSE;

	pSendContext->prebufferedBytes += buffersize;
		
	if (quit_prebuf) {
		RMDBGLOG((ENABLE, "exit prebuffering state, enter play state (bufsize %lu, prebuffered %lu)\n", buffersize, pSendContext->prebufferedBytes));
		if (manutest != TRUE)
			fprintf(stderr, "now playing\n");
		RM_PSM_SetState(pSendContext->PSMcontext, &(pSendContext->dcc_info), RM_PSM_Playing);
		DCCSTCSetTime(pSendContext->dcc_info->pStcSource, pSendContext->realFirstPTS, 90000);
		Play(pSendContext, RM_DEVICES_STC | RM_DEVICES_VIDEO | RM_DEVICES_AUDIO, DCCVideoPlayFwd);
		pSendContext->prebufferedBytes = 0;
		return TRUE;
	}
	return FALSE;
}



static void flush_repacked_sample(void *context)
{
	struct demux_context *pSendContext = (struct demux_context *) context;
	RMuint8 *send_buffer = (RMuint8 *) NULL;
	RMuint32 send_length = 0;
	RMuint32 decoder;
	struct emhwlib_info Info;

	/* flush video data */
	if ( ! play_opt->send_video)
		goto flush_audio;

	if (pSendContext->video_repack_buf == NULL)
		goto flush_audio;

	decoder = pSendContext->dcc_info->video_decoder;
	send_buffer = pSendContext->video_repack_buf + pSendContext->video_repack_offset;
	send_length = pSendContext->video_repack_size;
	Info.ValidFields = (pSendContext->video_repack_pts_valid) ? TIME_STAMP_INFO : 0;
	Info.TimeStamp = pSendContext->video_repack_pts;

	while (RUASendData(pSendContext->pRUA, decoder, pSendContext->pDMA, send_buffer, send_length, (void*)&Info, sizeof(Info)) != RM_OK) {
		struct RUAEvent e;

		PROCESS_KEY_INSIDE_FUNCTION();

		e.ModuleID = decoder;
		e.Mask = RUAEVENT_XFER_FIFO_READY;
		RUAWaitForMultipleEvents(pSendContext->pRUA, &e, 1, SENDDATA_TIMEOUT_US, NULL);
	}

	RUAReleaseBuffer(pSendContext->pDMA, send_buffer);

	pSendContext->video_repack_buf = NULL;
		
 flush_audio:
	/* flush audio data */
	if ( ! play_opt->send_audio)
		goto flush_spu;

	if (pSendContext->audio_repack_buf == NULL)
		goto flush_spu;

	if (pSendContext->isTrickMode)
		goto flush_spu;
	
	decoder = pSendContext->dcc_info->audio_decoder;
	send_buffer = pSendContext->audio_repack_buf + pSendContext->audio_repack_offset;
	send_length = pSendContext->audio_repack_size;
	Info.ValidFields = (pSendContext->audio_repack_pts_valid) ? TIME_STAMP_INFO : 0;
	Info.TimeStamp = pSendContext->audio_repack_pts;

	while (RUASendData(pSendContext->pRUA, decoder, pSendContext->pDMA, send_buffer, send_length, (void*)&Info, sizeof(Info)) != RM_OK) {
		struct RUAEvent e;
		
		PROCESS_KEY_INSIDE_FUNCTION();

		e.ModuleID = decoder;
		e.Mask = RUAEVENT_XFER_FIFO_READY;
		RUAWaitForMultipleEvents(pSendContext->pRUA, &e, 1, SENDDATA_TIMEOUT_US, NULL);
	}

	RUAReleaseBuffer(pSendContext->pDMA, send_buffer);

	pSendContext->audio_repack_buf = NULL;
	
 flush_spu:
	/* flush spu data */
	if ( ! play_opt->send_spu)
		return;

#ifdef	ENABLE_SPU_OP
	if (! pSendContext->enable_spu) {
		return;
	}
#else
	return;
#endif

	if (pSendContext->spu_repack_buf == NULL)
		return;

	decoder = pSendContext->dcc_info->spu_decoder;
	send_buffer = pSendContext->spu_repack_buf + pSendContext->spu_repack_offset;
	send_length = pSendContext->spu_repack_size;
	Info.ValidFields = (pSendContext->spu_repack_pts_valid) ? TIME_STAMP_INFO : 0;
	Info.TimeStamp = pSendContext->spu_repack_pts;

	while (RUASendData(pSendContext->pRUA, decoder, pSendContext->pDMA, send_buffer, send_length, (void*)&Info, sizeof(Info)) != RM_OK) {
		struct RUAEvent e;

		PROCESS_KEY_INSIDE_FUNCTION();

		e.ModuleID = decoder;
		e.Mask = RUAEVENT_XFER_FIFO_READY;
		RUAWaitForMultipleEvents(pSendContext->pRUA, &e, 1, SENDDATA_TIMEOUT_US, NULL);
	}

	RUAReleaseBuffer(pSendContext->pDMA, send_buffer);

	pSendContext->spu_repack_buf = NULL;

 return_from_callback:
	return;

}

static void PESCallback(RMuint8 *buffer, RMuint32 length, RMuint64 PTS, RMbool isPtsValid,
			RMvdemuxDataType dataType, RMuint64 PESOffset, void *context)
{
	static RMascii *decoder_name[] = {"video", "audio", "spu"};
	RMascii *string;
	struct demux_context *pSendContext = (struct demux_context *) context;
	RMuint32 decoder;
	struct emhwlib_info Info;
	RMbool send_data = FALSE;
	RMuint8 *send_buffer = (RMuint8 *) NULL;
	RMuint32 send_length = 0;
	RMuint8 *repack_buffer;
	RMuint64 repack_pts;
	RMuint32 repack_offset, repack_size;
	RMbool repack_pts_valid;
	RMuint32 send_pts;
	RMstatus err;
	RMuint32 *pbyte_counter = 0;
	RMuint32 first_access_unit_pointer = 0;
	RMbool isFirstAccessUnitValid = FALSE;

	enum RM_PSM_State PlaybackStatus = RM_PSM_GetState(pSendContext->PSMcontext, &(pSendContext->dcc_info));


#ifdef PTS_DISCONTINUITY_DETECTION
	static RMuint64 prevVpts = 0xffffffffffffffffll;
	static RMuint64 prevApts = 0xffffffffffffffffll;
#endif

	if (pSendContext->ignoreCallback) {

		if ((actions.cmd == RM_QUIT) && (!actions.cmdProcessed)) {
			RMDBGLOG((ENABLE, "callback called when 'quit' command was issued\n"));
			goto return_from_callback;
		}
		if ((PlaybackStatus == RM_PSM_Stopped) && (actions.cmdProcessed)) {
			RMDBGLOG((ENABLE, "callback called when 'stop' command was issued\n"));
			goto return_from_callback;
		}
		if ((actions.cmd == RM_STOP_SEEK_ZERO)  && (!actions.cmdProcessed)) {
			RMDBGLOG((ENABLE, "callback called when 'seekzero' command was issued\n"));
			goto return_from_callback;
		}
		if ((actions.cmd == RM_SEEK) && (!actions.cmdProcessed)) {	
			RMDBGLOG((ENABLE, "callback called when 'seek' command was issued\n"));
			goto return_from_callback;
		}
		if (((actions.cmd == RM_IFWD) || (actions.cmd == RM_IRWD)) && (actions.cmdProcessed)) {	
			RMDBGLOG((ENABLE, "callback called when 'iframe' command was issued\n"));
			goto return_from_callback;
		}

		RMDBGLOG((ENABLE, "********** ignoring Callback!! *********, cmd %lu, processed %lu\n", actions.cmd, actions.cmdProcessed));
		goto return_from_callback;
	}

	switch (dataType) {
	case RMVDEMUX_AUDIO:
		if (pSendContext->audio_first_access_unit_pointer_valid) {
			isFirstAccessUnitValid = TRUE;
			first_access_unit_pointer = pSendContext->audio_first_access_unit_pointer;
			pSendContext->audio_first_access_unit_pointer_valid = FALSE;
		}
		break;
	default:
		isFirstAccessUnitValid = FALSE;
		first_access_unit_pointer = 0;
		break;
	}

	/* uncomment to save only when in iframe mode (debug purposes)
	   if (pSendContext->dcc_info->trickmode_id == RM_TRICKMODE_RWD_IFRAME) { */
		err = dump_data_into_file(play_opt, dataType, buffer, length, PTS, isPtsValid, first_access_unit_pointer);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot dump data %d\n", err));
			return;
		}
		/* } */
	
	switch (dataType) {
	case RMVDEMUX_VIDEO:
		if ( ! play_opt->send_video)
			return ;

		decoder = pSendContext->dcc_info->video_decoder;
		string = decoder_name[0];
		send_pts = play_opt->send_video_pts;
		repack_buffer = pSendContext->video_repack_buf;
		repack_offset = pSendContext->video_repack_offset;
		repack_size = pSendContext->video_repack_size;
		repack_pts = pSendContext->video_repack_pts;
		repack_pts_valid = pSendContext->video_repack_pts_valid;
		pbyte_counter = &pSendContext->video_byte_counter;
//		printf("Sending %lu bytes of video data\n", length);
		break;
	case RMVDEMUX_AUDIO:
		if ( ! play_opt->send_audio)
			return ;

		if ((PlaybackStatus != RM_PSM_Playing) && (PlaybackStatus != RM_PSM_Paused) && (PlaybackStatus != RM_PSM_Prebuffering))
			return;
	       
		decoder = pSendContext->dcc_info->audio_decoder;
		string = decoder_name[1];
		send_pts = play_opt->send_audio_pts;
		repack_buffer = pSendContext->audio_repack_buf;
		repack_offset = pSendContext->audio_repack_offset;
		repack_size = pSendContext->audio_repack_size;
		repack_pts = pSendContext->audio_repack_pts;
		repack_pts_valid = pSendContext->audio_repack_pts_valid;
		pbyte_counter = &pSendContext->audio_byte_counter;
//		printf("Sending Audio data\n");
		break;
	case RMVDEMUX_SUBPICTURE:
		if ( ! play_opt->send_spu)
			return ;

#ifdef	ENABLE_SPU_OP
		if (! pSendContext->enable_spu) {
			RMDBGPRINT((ENABLE, "disabled spu\n"));
			return;
		}
#else
		return;
#endif
		decoder = pSendContext->dcc_info->spu_decoder;
		string = decoder_name[2];
		send_pts = play_opt->send_spu_pts;
		repack_buffer = pSendContext->spu_repack_buf;
		repack_offset = pSendContext->spu_repack_offset;
		repack_size = pSendContext->spu_repack_size;
		repack_pts = pSendContext->spu_repack_pts;
		repack_pts_valid = pSendContext->spu_repack_pts_valid;
		break;
	case RMVDEMUX_NAVIGATION:
		RMDBGPRINT((ENABLE, "navigation\n"));
		return;
	default:
		RMDBGPRINT((ENABLE, "Unknown data type %d\n", dataType));
		return;
	}

	if ((pSendContext->repack_sample) && (repack_size>0) && 
	    ((isPtsValid) || (repack_offset + length > (RMuint32) (1<<play_opt->dmapool_log2size)) || (repack_size + length > REPACK_SIZE))) {
	    send_buffer = repack_buffer + repack_offset;
		send_length = repack_size;
		Info.ValidFields = (repack_pts_valid && send_pts) ? TIME_STAMP_INFO : 0;
		Info.TimeStamp = repack_pts;
		send_data = TRUE;
		
		repack_offset += repack_size;
		repack_size = 0;
		repack_pts = 0;
		repack_pts_valid = FALSE;
	}
	else if (!pSendContext->repack_sample) {
		send_buffer = buffer;
		send_length = length;
		Info.ValidFields = ((isPtsValid && send_pts) ? TIME_STAMP_INFO : 0) | (isFirstAccessUnitValid ? FIRST_ACCESS_UNIT_POINTER_INFO : 0);
		Info.TimeStamp = PTS;
		Info.FirstAccessUnitPointer = first_access_unit_pointer;
		send_data = TRUE;
	}

	if (send_data) {
		if (1/*(PlaybackStatus == RM_PSM_Playing) || (PlaybackStatus == RM_PSM_Paused) || (PlaybackStatus == RM_PSM_NextPic)*/) {
			if (pSendContext->FirstSystemTimeStamp) {
				if (Info.ValidFields & TIME_STAMP_INFO) {
					RMDBGLOG((ENABLE, "FirstSystemTimeStamp from %s = %llu = 0x%llx (0x%llx)\n", string, Info.TimeStamp, Info.TimeStamp, Info.TimeStamp/2));

					pSendContext->realFirstPTS = (RMint64) (Info.TimeStamp + pSendContext->start_90khz);

					// set the STC to 1sec before the real value, so that we dont the first frame when prebuffering
					DCCSTCSetTime(pSendContext->dcc_info->pStcSource, (RMuint64)(pSendContext->realFirstPTS - 90000), 90000);

					pSendContext->FirstSystemTimeStamp = FALSE;
#ifdef PTS_DISCONTINUITY_DETECTION
					if (dataType == RMVDEMUX_VIDEO)
						prevVpts = Info.TimeStamp;
				
					if (dataType == RMVDEMUX_AUDIO)
						prevApts = Info.TimeStamp;
#endif
				}
				else if (!(play_opt->send_audio_pts || play_opt->send_audio_pts)) {
					Info.TimeStamp = 0;
					RMDBGLOG((ENABLE, "No PTS -> Init FirstSystemTimeStamp = %llu\n", Info.TimeStamp));


					pSendContext->realFirstPTS = (RMint64) (Info.TimeStamp + pSendContext->start_90khz);

					// set the STC to 1sec before the real value, so that we dont the first frame when prebuffering
					DCCSTCSetTime(pSendContext->dcc_info->pStcSource, (RMuint64)(pSendContext->realFirstPTS - 90000), 90000);

					pSendContext->FirstSystemTimeStamp = FALSE;
#ifdef PTS_DISCONTINUITY_DETECTION
					prevVpts = Info.TimeStamp;
					prevApts = Info.TimeStamp;
#endif
				}
				else
					RMDBGLOG((ENABLE, "waiting for valid PTS\n"));
			}
		}

		if ((pSendContext->waitForValidAudioPTS) && (dataType == RMVDEMUX_AUDIO) && (send_pts)) {
			if (Info.ValidFields & TIME_STAMP_INFO) {
				RMDBGLOG((ENABLE, "first valid audio PTS %llu(0x%09llx), start sending audio\n",Info.TimeStamp,Info.TimeStamp));
				pSendContext->waitForValidAudioPTS = FALSE;
#ifdef PTS_DISCONTINUITY_DETECTION
				prevApts = Info.TimeStamp;
#endif
			}
			else {
				// dont send audio with invalid pts
				RMDBGLOG((ENABLE, "audio pts not valid\n"));
				if (isPtsValid) {
					repack_pts_valid = TRUE;
					repack_pts = PTS;
				}
				goto end_data_callback;
			}
		}


		if ((pSendContext->waitForValidVideoPTS) && (dataType == RMVDEMUX_VIDEO) && (send_pts)) {
			if (Info.ValidFields & TIME_STAMP_INFO) {
				RMDBGLOG((ENABLE, "first valid video PTS %llu(0x%09llx), start sending video\n",Info.TimeStamp,Info.TimeStamp));
				pSendContext->waitForValidVideoPTS = FALSE;
#ifdef PTS_DISCONTINUITY_DETECTION
				prevVpts = Info.TimeStamp;
#endif
			}
			else {
				// dont send video with invalid pts
				RMDBGLOG((ENABLE, "video pts not valid\n"));
				if (isPtsValid) {
					repack_pts_valid = TRUE;
					repack_pts = PTS;
				}
				goto end_data_callback;
			}
		}

#ifdef PTS_DISCONTINUITY_DETECTION

		if (Info.ValidFields & TIME_STAMP_INFO) {
			RMint64 diff = 0;

			if ((pSendContext->fakePrevPts) && (dataType == RMVDEMUX_AUDIO)) {
				RMDBGPRINT((ENABLE, "Set prevAPTS to 0x%09llx\n", Info.TimeStamp));
				prevApts = Info.TimeStamp;
				pSendContext->fakePrevPts = FALSE;
			}

			if ((dataType == RMVDEMUX_VIDEO) && (prevVpts != 0xffffffffffffffffll)) {
				diff = Info.TimeStamp - prevVpts;
				prevVpts = Info.TimeStamp;
				RMDBGPRINT((DISABLE, "Vpts = %9llx %8lx (%lx)\n", Info.TimeStamp, pSendContext->video_byte_counter, file_offset));
			} else if ((dataType == RMVDEMUX_AUDIO) && (prevApts != 0xffffffffffffffffll)) {
				diff = Info.TimeStamp - prevApts;
				prevApts = Info.TimeStamp;
				RMDBGPRINT((DISABLE, "Apts = %9llx %8lx (%lx)\n", Info.TimeStamp, pSendContext->audio_byte_counter, file_offset));
			}
			if ((diff < -PTS_DISCONTINUITY_RANGE) || (diff > PTS_DISCONTINUITY_RANGE)) {
				struct InbandCommand_type InbandCmd;

				RMDBGPRINT((ENABLE, "%spts discontinuity = %9llx -> %9llx\n", (dataType == RMVDEMUX_VIDEO)?"V":"A", Info.TimeStamp-diff, Info.TimeStamp));
				DCCSTCSetDiscontinuity(pSendContext->dcc_info->pStcSource, Info.TimeStamp-2*90000, 90000);
				
				InbandCmd.Tag = INBAND_COMMAND_TAG_DISCONTINUITY | INBAND_COMMAND_ACTION_STOP;
				InbandCmd.Coordinate = 0;
//				if (dataType == RMVDEMUX_VIDEO)
					RUASetProperty(pSendContext->pRUA, pSendContext->dcc_info->video_decoder, RMGenericPropertyID_InbandCommand, &InbandCmd, sizeof(InbandCmd), 0);
//				if (dataType == RMVDEMUX_AUDIO)
					RUASetProperty(pSendContext->pRUA, pSendContext->dcc_info->audio_decoder, RMGenericPropertyID_InbandCommand, &InbandCmd, sizeof(InbandCmd), 0);
			}
		}
#endif	// PTS_DISCONTINUITY_DETECTION

		if (PlaybackStatus == RM_PSM_Prebuffering)
			RMDBGPRINT((ENABLE, "%s", dataType == RMVDEMUX_AUDIO ? "a":"v"));

		{
			RMuint64 stc;
			DCCSTCGetTime(pSendContext->dcc_info->pStcSource, &stc, 90000);
			RMDBGLOG((SENDDBG, "sending %s, %lu, pts %llu(0x%09llx) %s stc %llu(0x%09llx)\n", 
				  dataType == RMVDEMUX_AUDIO ? "audio":"video",
				  send_length,
				  Info.TimeStamp,
				  Info.TimeStamp,
				  Info.ValidFields & TIME_STAMP_INFO ? "valid":"",
				  stc,
				  stc));
		}

		if (Info.ValidFields & TIME_STAMP_INFO) {
			static RMint64 max_diff = 0, min_diff = 0;
			RMint64 diff;
			if ( (prevVpts != 0xffffffffffffffffll) && (prevApts != 0xffffffffffffffffll) ) {
				diff = (RMint64)(prevVpts - prevApts) / (RMint64)90; /* diff in miliseconds */
				RMDBGLOG((DISABLE, "diff %lld %llx %llx\n", diff, prevVpts, prevApts));
				if ( (diff < -100) || (diff > 100)) {
					if ( (diff > 0) && (diff > max_diff+100) ) {
						max_diff = diff;
						RMDBGLOG((ENABLE, " %lld\n", diff));
					}
					if ( (diff < 0) && (diff < min_diff-100) ) {
						min_diff = diff;
						RMDBGLOG((ENABLE, " %lld\n", diff));
					}
				}
			}
		}
		
		while (RUASendData(pSendContext->pRUA, decoder, pSendContext->pDMA, send_buffer, send_length, (void*)&Info, sizeof(Info)) != RM_OK) {
			struct RUAEvent e;

			check_prebuf_state(pSendContext, 0);

			PROCESS_KEY_INSIDE_FUNCTION();

			PlaybackStatus = RM_PSM_GetState(pSendContext->PSMcontext, &(pSendContext->dcc_info));

			/* skip audio in trickmode */
			if ((dataType == RMVDEMUX_AUDIO) && 
			    ((PlaybackStatus == RM_PSM_Slow) || (PlaybackStatus == RM_PSM_Fast) || (PlaybackStatus == RM_PSM_NextPic)))
				goto end_data_callback;


			e.ModuleID = decoder;
			e.Mask = RUAEVENT_XFER_FIFO_READY;
			RUAWaitForMultipleEvents(pSendContext->pRUA, &e, 1, SENDDATA_TIMEOUT_US, NULL);
		}
		if ( pbyte_counter )
			*pbyte_counter = *pbyte_counter + send_length;
			
		if ( 0 && (Info.ValidFields & TIME_STAMP_INFO) ) {
			RMuint32 pts;
			err = RUAGetProperty(pSendContext->pRUA, decoder, RMGenericPropertyID_LastTransferredHwPts,
				&pts, sizeof(pts));
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "RMGenericPropertyID_LastTransferredHwPts Error %d on decoder 0x%lx\n", err, decoder));
			}
			else {
				RMDBGLOG((ENABLE, " %s in queue =  %ld ms\n",
					string, (((RMuint32)Info.TimeStamp/2) - pts)/45));
			}
		}
		
		/* sendind data may fill-up the xfer fifo, so we reset the event */
		{
			struct RUAEvent e;
			
			e.ModuleID = decoder;
			e.Mask = RUAEVENT_XFER_FIFO_READY;
			RUAResetEvent(pSendContext->pRUA, &e);
		}
	}
	
	if (pSendContext->repack_sample) {
		RMuint32 val;

		val = RMmax(length, REPACK_SIZE);
		if ((repack_offset + val) > (RMuint32) (1<<play_opt->dmapool_log2size)) {
			RUAReleaseBuffer(pSendContext->pDMA, repack_buffer);
			repack_buffer = (RMuint8 *) NULL;
			repack_offset = 0;
		}

		if (repack_buffer == NULL) {
			while (RUAGetBuffer(pSendContext->pDMA, &repack_buffer,  GETBUFFER_TIMEOUT_US) != RM_OK) {

				PROCESS_KEY_INSIDE_FUNCTION();

				RMDBGLOG((DISABLE, "Wait for a buffer\n"));
			}
		}

		memcpy(repack_buffer + repack_offset + repack_size, buffer, length);
		repack_size += length;
		if (isPtsValid) {
			repack_pts_valid = TRUE;
			repack_pts = PTS;
		}
	}		

 end_data_callback:
	switch (dataType) {
	case RMVDEMUX_VIDEO:
		pSendContext->video_repack_buf = repack_buffer;
		pSendContext->video_repack_offset = repack_offset;
		pSendContext->video_repack_size = repack_size;
		pSendContext->video_repack_pts = repack_pts;
		pSendContext->video_repack_pts_valid = repack_pts_valid;
		break;
	case RMVDEMUX_AUDIO:
		pSendContext->audio_repack_buf = repack_buffer;
		pSendContext->audio_repack_offset = repack_offset;
		pSendContext->audio_repack_size = repack_size;
		pSendContext->audio_repack_pts = repack_pts;
		pSendContext->audio_repack_pts_valid = repack_pts_valid;
		break;
	case RMVDEMUX_SUBPICTURE:
		pSendContext->spu_repack_buf = repack_buffer;
		pSendContext->spu_repack_offset = repack_offset;
		pSendContext->spu_repack_size = repack_size;
		pSendContext->spu_repack_pts = repack_pts;
		pSendContext->spu_repack_pts_valid = repack_pts_valid;
		break;
	default:
		RMDBGLOG((ENABLE, "Invalid data type %d\n", dataType));
		return;
	}

 return_from_callback:	
	return;
}

static void AC3DTSCallback(RMuint8 numberOfFrameHeaders, RMuint16 firstAccessUnitPointer, void *context)
{
	struct demux_context *pSendContext = (struct demux_context *) context;
	//RMDBGPRINT((ENABLE, "AC3DTSCallback: firstAccessUnitPointer= %x\n", firstAccessUnitPointer));
	pSendContext->audio_first_access_unit_pointer_valid = TRUE;
	pSendContext->audio_first_access_unit_pointer = firstAccessUnitPointer;
	return;
}

static void LPCMCallback(RMuint8 numberOfFrameHeaders, RMuint16 firstAccessUnitPointer, RMuint32 frequency,
			 RMuint8 numberOfChannels, RMvdemuxQuantization quantizationWordLength, void *context)
{
	struct demux_context *pSendContext = (struct demux_context *) context;
	//RMDBGPRINT((ENABLE, "LPCMCallback: firstAccessUnitPointer= %x\n", firstAccessUnitPointer));
	pSendContext->audio_first_access_unit_pointer_valid = TRUE;
	pSendContext->audio_first_access_unit_pointer = firstAccessUnitPointer;
	return;
}

static void aobPcm_callback (RMuint16 firstAccessUnitPointer, 
			     RMvdemuxQuantization quantizationGr1,
			     RMvdemuxQuantization quantizationGr2,
			     RMuint32 samplingFreqGr1,
			     RMuint32 samplingFreqGr2,
			     RMuint8 bitShift,
			     RMuint8 channelAssign,
			     void * context)
{
}
	
static void mlp_callback (RMuint16 firstAccessUnitPointer, 
			  RMuint8 forwardAUSearchPointer,
			  RMuint8 backwardAUSearchPointer,
			  void *context)
{
}

static RMstatus WaitForEOS(struct demux_context *context, struct RM_PSM_Actions *pActions)
{
	RMuint32 eos_bit_field = 0;
	enum RM_PSM_State PlaybackStatus = RM_PSM_GetState(context->PSMcontext, &(context->dcc_info));

	NTimes++;
	if (verbose_stderr != 0)
		fprintf(stderr, "File ready %ld times, waiting for EOS\n", NTimes);

	if (context->video_byte_counter > 0) {
		eos_bit_field |= EOS_BIT_FIELD_VIDEO;
	}

	if ((context->audio_byte_counter > 0) && 
	    ((PlaybackStatus == RM_PSM_Playing) ||
	     (PlaybackStatus == RM_PSM_Prebuffering))) {
		eos_bit_field |= EOS_BIT_FIELD_AUDIO;
	}
	
	return WaitForEOSWithCommand(context->PSMcontext, &(context->dcc_info), pActions, eos_bit_field);

}

static RMstatus InitUserDataProcessing(struct demux_context *pcontext)
{
	RMstatus err;
	
	switch(user_data_app_mode) {
	case user_data_dma_full_buffer:
	case user_data_dma_no_delay:
	case user_data_dma_minimum_size:
	case user_data_dma_exact_size:
	    {
		struct Receive_type Receive;
		Receive.pRUA = pcontext->pRUA;
		Receive.targetModule = EMHWLIB_TARGET_MODULE(VideoDecoder, EMHWLIB_MODULE_INDEX(pcontext->dcc_info->video_decoder), 1);
		Receive.buffer_count = 4;
		Receive.buffer_size_log2 = 12;	// 4k per buffer -> 16M
		err = DCCOpenReceive(&Receive, &pcontext->pReceive, &pcontext->pDmaUserData);

		if (user_data_app_mode == user_data_dma_no_delay) {
			struct EMhwlibReadBufferCompletion bc;
			bc.mode = EMhwlibReadBufferCompletionMode_NoDelay; /* complete the buffer as soon as the microcode sent data */
			bc.threshold = 0; /* ignored */
			err = RUASetProperty(pcontext->pRUA, Receive.targetModule, RMGenericPropertyID_ReadBufferCompletion, &bc, sizeof(bc), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "RMGenericPropertyID_ReadBufferCompletion Error %d\n", err));
				return err;
			}
		}
		else if (user_data_app_mode == user_data_dma_minimum_size) {
			struct EMhwlibReadBufferCompletion bc;
			bc.mode = EMhwlibReadBufferCompletionMode_MinimumSize; /* complete the buffer when the buffer has more than the threshold value */
			bc.threshold = 256;
			err = RUASetProperty(pcontext->pRUA, Receive.targetModule, RMGenericPropertyID_ReadBufferCompletion, &bc, sizeof(bc), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "RMGenericPropertyID_ReadBufferCompletion Error %d\n", err));
				return err;
			}
		}
		else if (user_data_app_mode == user_data_dma_exact_size) {
			struct EMhwlibReadBufferCompletion bc;
			bc.mode = EMhwlibReadBufferCompletionMode_ExactSize; /* complete the buffer when the buffer has exactly the threshold value */
			bc.threshold = 256;
			err = RUASetProperty(pcontext->pRUA, Receive.targetModule, RMGenericPropertyID_ReadBufferCompletion, &bc, sizeof(bc), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "RMGenericPropertyID_ReadBufferCompletion Error %d\n", err));
				return err;
			}
		}
		break;
	    }
	case user_data_get_chunk256_without_dma:
		break;
	case user_data_rua_mapping_without_dma:
	    {
		struct gbus_fifo *fifo;
		struct UserDataFIFOInfo udfi;
		if (pllad == NULL) {
			pllad = llad_open("0");
			pgbus = gbus_open(pllad);
		}

		err = RUAGetProperty(pcontext->pRUA, VideoDecoder, RMVideoDecoderPropertyID_UserDataFIFOInfo,
			&udfi, sizeof(udfi));
		fifo = (struct gbus_fifo *)udfi.ContainerAddress;
		pcontext->user_data_fifo_base = gbus_read_uint32(pgbus, (RMuint32) &(fifo->base));
		pcontext->user_data_fifo_size = gbus_read_uint32(pgbus, (RMuint32) &(fifo->size));
		if ( (pcontext->user_data_fifo_base == 0) || (pcontext->user_data_fifo_size == 0) ) {
			fprintf(stderr, "USER_DATA ERROR: user_data_fifo_base or user_data_fifo_size is NULL\n");
			return RM_ERROR;
		}

		pcontext->user_data_fifo_container = udfi.ContainerAddress;
		RMDBGLOG((DISABLE, "user_data_fifo_container=%lx base=%lx size=%lx\n",
			pcontext->user_data_fifo_container, pcontext->user_data_fifo_base, pcontext->user_data_fifo_size));
		err = RUALock(pcontext->pRUA, pcontext->user_data_fifo_base, pcontext->user_data_fifo_size);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "USER_DATA ERROR: Unable to lock output!\n"));
		}
		pcontext->pmapped_user_data_fifo_base = RUAMap(pcontext->pRUA, pcontext->user_data_fifo_base, pcontext->user_data_fifo_size);
		break;
	    }
	case no_user_data:
	default:
		return RM_OK;
	}
	
	pcontext->f_record = fopen("userdata.bin", "wb");
	if (pcontext->f_record == NULL)
		RMDBGLOG((ENABLE, "Error opening userdata.bin"));
	pcontext->f_record_size = 0;

	return RM_OK;
}

static void SaveUserData(struct demux_context *pcontext)
{
	RMstatus err;
	RMuint32 targetModule = EMHWLIB_TARGET_MODULE(VideoDecoder, EMHWLIB_MODULE_INDEX(pcontext->dcc_info->video_decoder), 1);
	struct RUAEvent e;
	e.ModuleID = pcontext->dcc_info->video_decoder;
	
	switch(user_data_app_mode) {
	case user_data_dma_full_buffer:
	case user_data_dma_no_delay:
	case user_data_dma_minimum_size:
	case user_data_dma_exact_size:
	    {
		RMuint8 *pBuf = NULL;
		RMuint32 size = 0;
		
		e.Mask = SOFT_IRQ_EVENT_XFER_RECEIVE_READY;
		if (RUAWaitForMultipleEvents(pcontext->pRUA, &e, 1, 0, NULL) == RM_OK ) {
			while(1) {
				err = RUAReceiveData(pcontext->pRUA, targetModule, pcontext->pDmaUserData, &pBuf, &size, NULL, NULL);
				if ( (err == RM_OK) && pBuf ) {
					if ( pcontext->f_record && (size > 0) ) {
						fwrite(pBuf, 1, size, pcontext->f_record);
						pcontext->f_record_size += size;
					}
					RMDBGLOG((DISABLE, "user_data receive size=0x%lx\n", size));
					RUAReleaseBuffer(pcontext->pDmaUserData, pBuf);
				}
				else
					break;
			}
		}
		break;
	    }
	case user_data_get_chunk256_without_dma:
	    {
		RMuint32 left_size;
		struct DataFIFOInfo user_fifo_info;

		e.Mask = SOFT_IRQ_EVENT_USER_DATA;
		if (RUAWaitForMultipleEvents(pcontext->pRUA, &e, 1, 0, NULL) == RM_OK ) {
			err = RUAGetProperty(pcontext->pRUA, targetModule, RMGenericPropertyID_DataFIFOInfo,
				&user_fifo_info, sizeof(user_fifo_info));
			left_size = user_fifo_info.Readable;
			if(left_size) {
				RMuint32 in;
				struct EMhwlibChunk256 out;
				in = RMmin(left_size, 256);

				err = RUAExchangeProperty(pcontext->pRUA, targetModule, RMGenericPropertyID_ReadChunk256,
					&in, sizeof(in), &out, sizeof(out));
				if(err == RM_OK) {
					left_size -= out.size;
					if ( pcontext->f_record && (out.size > 0) ) {
						fwrite(out.data, 1, out.size, pcontext->f_record);
						pcontext->f_record_size += out.size;
					}
					RMDBGLOG((DISABLE, "user_data get chunk size= 0x%03lx / 0x%03lx total= 0x%lx \n",
						out.size, user_fifo_info.Readable, pcontext->f_record_size));
				}
				else {
					RMDBGLOG((ENABLE, "user_data RMGenericPropertyID_ReadChunk256 ERROR\n"));
				}
			}
		}
		break;
	    }
	case user_data_rua_mapping_without_dma:
	    {
		struct gbus_fifo *fifo;
		RMuint32 rd, wr;

		fifo = (struct gbus_fifo *)pcontext->user_data_fifo_container;
		rd = gbus_read_uint32(pgbus, (RMuint32) &(fifo->rd));
		wr = gbus_read_uint32(pgbus, (RMuint32) &(fifo->wr));

		if ( wr > rd ) {
			/* data is contiguos in one chunck */
			if (pcontext->f_record) {
				fwrite(pcontext->pmapped_user_data_fifo_base + rd, 1, wr-rd, pcontext->f_record);
				pcontext->f_record_size += (wr-rd);
			}
		}
		else if (wr != rd) {
			/* data is separated in two chuncks because of circular fifo. */
			if (pcontext->f_record) {
				fwrite(pcontext->pmapped_user_data_fifo_base + rd, 1,
					pcontext->user_data_fifo_size-rd, pcontext->f_record);
				fwrite(pcontext->pmapped_user_data_fifo_base, 1, wr, pcontext->f_record);
				pcontext->f_record_size += (pcontext->user_data_fifo_size+wr-rd);
			}
		}

		gbus_write_uint32(pgbus, (RMuint32) &(fifo->rd), wr);

		break;
	    }
	case no_user_data:
	default:
		break;
	}
}


#ifdef WITH_MONO
int main_demux(struct mono_info *mono)
{
#else
int main(int argc, char *argv[])
{
	/*for MONO compatibility, always access these variables through the global pointers*/
	struct playback_cmdline playback_options; /*access through play_opt*/
	struct display_cmdline  display_options;/*access through disp_opt*/
	struct video_cmdline video_options; /*access through video_opt*/
	struct audio_cmdline audio_options; /*access through audio_opt*/
	struct demux_cmdline demux_options; /*access through demuxopt*/
	struct display_context disp_info;
	struct dh_context dh_info = {0,};

#endif
	struct DCCVideoSource *pVideoSource = NULL;
	struct DCCAudioSource *pAudioSource = NULL;
	struct DCCAudioProfile audio_profile;
	struct RUABufferPool *pDMA = NULL;
	ExternalRMvdemux demux;
	struct demux_context context;
	RMstatus err;
	RMfile file = NULL;
	RMuint32 videoscaler_id = 0;
	RMuint8 *repack_buf = (RMuint8 *) NULL;
	
	static struct dcc_context dcc_info = {0,};

	void **dmabuffer_array = (void **) NULL;
	RMuint32 dmabuffer_index = 0;

	RMuint32 error = 0;
	struct RM_PSM_Context PSMContext;

	RMMemset(&context, 0, sizeof(struct demux_context));

#ifdef WITH_MONO
	/*make the mono arguments global*/
	play_opt = mono->play_opt;
	video_opt = mono->video_opt;
	disp_opt = mono->disp_opt;
	audio_opt = mono->audio_opt;
	demux_opt = mono->demux_opt;
	dcc_info.pRUA = mono->pRUA;
	dcc_info.pDCC = mono->pDCC;
	dcc_info.disp_info = NULL;
	videoscaler_id = mono->video_scaler;
	dcc_info.route = DCCRoute_Main;

#else
	play_opt = &playback_options;
	disp_opt = &display_options;
	video_opt = &video_options;
	audio_opt = &audio_options;
	demux_opt = &demux_options;
	dcc_info.disp_info = &disp_info;
	dcc_info.dh_info = &dh_info;

	init_display_options(disp_opt);
	init_audio_options(audio_opt);
	init_playback_options(play_opt);
	init_video_options(video_opt);
	disp_opt->dh_info = &dh_info;
	audio_opt->dh_info = &dh_info;

	parse_cmdline(argc, argv);
	videoscaler_id = disp_opt->video_scaler;
	dcc_info.route = disp_opt->route;


	err = RUACreateInstance(&dcc_info.pRUA, play_opt->chip_num);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error creating RUA instance! %d\n", err));
		goto exit_with_error;
	}

	err = DCCOpen(dcc_info.pRUA, &dcc_info.pDCC);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error Opening DCC! %d\n", err));
		goto exit_with_error;
	}

	if (!play_opt->noucode) {
		err = DCCInitMicroCodeEx(dcc_info.pDCC, disp_opt->init_mode);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot initialize microcode %d\n", err));
			goto exit_with_error;
		}
	}
	else
		RMDBGLOG((ENABLE, "microcode not loaded\n"));

#endif


	err = open_save_files(play_opt);

	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "cannot open files to save data %d\n", err));
		goto exit_with_error;
	}

	if (demux_opt->system_type != RM_SYSTEM_UNKNOWN) {
		err = RMCreateVdemux(&demux);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot create demux %d\n", err));
			goto exit_with_error;
		}
		RMvdemuxSetType(demux, demux_opt->system_type);
		RMvdemuxSetCallbackData(demux, PESCallback, &context);
		RMvdemuxSetAudioCallbacks(demux, AC3DTSCallback, LPCMCallback, aobPcm_callback, mlp_callback);
	}
	else {
		demux = (ExternalRMvdemux) NULL;
#if 0
		RMDBGLOG((ENABLE, "system unknown, exiting\n"));
		err = RM_ERROR;
		goto exit_with_error;
#endif
	}

	dcc_info.chip_num = play_opt->chip_num;


	/* if HD control is enabled and mode is auto, setup parameters */
	if ((play_opt->disk_ctrl_low_level) &&
	    (play_opt->disk_ctrl_log2_block_size) &&
	    (play_opt->disk_ctrl_max_mem)) {
		RMuint32 bufferSize = 0;
		RMuint32 bufferCount = 0;
		RMuint32 log2BlockSize = play_opt->disk_ctrl_log2_block_size;
		RMuint32 maxBufferingMem = play_opt->disk_ctrl_max_mem;

		bufferSize = (1 << log2BlockSize);
		bufferCount = maxBufferingMem >> log2BlockSize;
	
		play_opt->dmapool_count = bufferCount;
		play_opt->dmapool_log2size = log2BlockSize;
	
		/* from #4005
		   
		videoOpt.fifo_size = 4*1024*1024; 
		videoOpt.xfer_count = (1<<playOpt.dmapool_log2size)/1024*playOpt.dmapool_count;
		audioOpt.fifo_size = 1*1024*1024; 
		audioOpt.xfer_count = (1<<playOpt.dmapool_log2size)/512*playOpt.dmapool_count;
		
		*/

		if (play_opt->disk_ctrl_low_level >= bufferCount)
			play_opt->disk_ctrl_low_level = bufferCount >> 1;
	
		video_opt->fifo_size = 4 * (1024 * 1024);
		audio_opt->fifo_size = 2 * (1024 * 1024);

		fprintf(stderr, ">> low level %lu => %lu bytes bufferized (+ bitstreamFIFO)\n", 
			play_opt->disk_ctrl_low_level,
			play_opt->disk_ctrl_low_level * bufferSize);

	
		video_opt->xfer_count = (bufferSize / 512) * bufferCount;
		audio_opt->xfer_count = (bufferSize / 512) * bufferCount;

		err = setup_disk_control_parameters(&dcc_info, play_opt, audio_opt, video_opt, NULL);
		if (err != RM_OK) {
			fprintf(stderr, "Error %d trying to setup HD control params\n", err);
			goto exit_with_error;
		}

	}

	/* update fifo and xfer size */
	if (video_opt->fifo_size == 0) 
		video_opt->fifo_size = VIDEO_FIFO_SIZE;

	if (video_opt->xfer_count == 0)
		video_opt->xfer_count = XFER_FIFO_COUNT;

	if (audio_opt->fifo_size == 0) 
		audio_opt->fifo_size = AUDIO_FIFO_SIZE;

	if (audio_opt->xfer_count == 0)
		audio_opt->xfer_count = XFER_FIFO_COUNT;

	/* update dmapool size and count */
	if (play_opt->dmapool_count == 0)
		play_opt->dmapool_count = DMA_BUFFER_COUNT;

	if (play_opt->dmapool_log2size == 0)
		play_opt->dmapool_log2size = DMA_BUFFER_SIZE_LOG2;

	switch (play_opt->disk_ctrl_state) {
	case DISK_CONTROL_STATE_DISABLE:
		break;
	case DISK_CONTROL_STATE_SLEEPING:
	case DISK_CONTROL_STATE_RUNNING:
		dmabuffer_array = (void **) RMMalloc(sizeof(void*) * play_opt->dmapool_count);
		dmabuffer_index = 0;
		if (dmabuffer_array == NULL) {
			RMDBGLOG((ENABLE, "Cannot allocate dmapool array! Disable disk control\n"));
			play_opt->disk_ctrl_state = DISK_CONTROL_STATE_DISABLE;
		}
		break;
	}


	err = apply_playback_options(&dcc_info, play_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set playback options %d\n", err));
		goto exit_with_error;
	}

	{
		// open first stc module
		struct DCCStcProfile stc_profile;

		RMDBGLOG((ENABLE, "using STC ID %lu\n", play_opt->STCid));
		stc_profile.STCID = play_opt->STCid;
		stc_profile.master = Master_STC;
		
		stc_profile.stc_timer_id = 3*stc_profile.STCID+0;
		stc_profile.stc_time_resolution = 90000;
		
		stc_profile.video_timer_id = 3*stc_profile.STCID+1;
		stc_profile.video_time_resolution = 90000;
		stc_profile.video_offset = -(play_opt->video_delay_ms * (RMint32)stc_profile.video_time_resolution / 1000);
		
		stc_profile.audio_timer_id = 3*stc_profile.STCID+2;
		stc_profile.audio_time_resolution = 90000;
		stc_profile.audio_offset = -(play_opt->audio_delay_ms * (RMint32)stc_profile.audio_time_resolution / 1000);
		
		err = DCCSTCOpen(dcc_info.pDCC, &stc_profile, &dcc_info.pStcSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot open stc module %d\n", err));
			goto exit_with_error;
		}
	}

#if 1
	{
		struct DCCXVideoProfile video_profile;
		enum EMhwlibVideoCodec vcodec;

		video_profile.ProtectedFlags = 0;
		video_profile.BitstreamFIFOSize = video_opt->fifo_size;
		video_profile.XferFIFOCount = video_opt->xfer_count;
		video_profile.PtsFIFOCount = VIDEO_PTS_FIFO_COUNT;
		video_profile.InbandFIFOCount = VIDEO_INBAND_FIFO_COUNT;
		video_profile.XtaskInbandFIFOCount = 0;
		video_profile.MpegEngineID = video_opt->MpegEngineID;
		video_profile.VideoDecoderID = video_opt->VideoDecoderID;
		
		video_profile.SPUProtectedFlags = 0;
		video_profile.SPUBitstreamFIFOSize = (enable_spu) ? SPU_FIFO_SIZE : 0;
		video_profile.SPUXferFIFOCount = (enable_spu) ? XFER_FIFO_COUNT : 0;
		video_profile.SPUPtsFIFOCount = (enable_spu) ? VIDEO_PTS_FIFO_COUNT : 0;
		video_profile.SPUInbandFIFOCount = (enable_spu) ? VIDEO_INBAND_FIFO_COUNT : 0;
		video_profile.SPUCodec = EMhwlibDVDSpuCodec;
		video_profile.SPUProfile = 0;
		video_profile.SPULevel = 0;
		video_profile.SPUExtraPictureBufferCount = 0;
		video_profile.SPUMaxWidth = 720;
		video_profile.SPUMaxHeight = 576;
	
		video_profile.STCID = play_opt->STCid;
	
		/* set codec based on command line options either "-pv" or "-vcodec" */
		if (video_opt->vcodec_max_width) {
			video_profile.Codec = video_opt->vcodec;
			video_profile.Profile = video_opt->vcodec_profile;
			video_profile.Level = video_opt->vcodec_level;
			video_profile.MaxWidth = video_opt->vcodec_max_width;
			video_profile.MaxHeight = video_opt->vcodec_max_height;
		}
		else {
			err = video_profile_to_codec(video_opt->Codec, &video_profile.Codec,
				&video_profile.Profile, &video_profile.Level, &video_profile.ExtraPictureBufferCount,
				&video_profile.MaxWidth, &video_profile.MaxHeight);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Unknown video decoder codec \n"));
				goto exit_with_error;
			}
		}

		/* set the extra pictures after the profile to codec conversion */
		video_profile.ExtraPictureBufferCount = video_opt->vcodec_extra_pictures;

		err = DCCXOpenVideoDecoderSource(dcc_info.pDCC, &video_profile, &pVideoSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot open video decoder %d\n", err));
			goto exit_with_error;
		}
		
		vcodec = video_profile.Codec;
		err = DCCXSetVideoDecoderSourceCodec(pVideoSource, vcodec);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set video decoder codec %d\n", err));
			goto exit_with_error;
		}
	}
#else
	{
		struct DCCVideoProfile video_profile;
		video_profile.MPEGProfile = video_opt->MPEGProfile;
		video_profile.BitstreamFIFOSize = video_opt->fifo_size;
		video_profile.XferFIFOCount = video_opt->xfer_count;
		video_profile.DemuxProgramID = 0;
		video_profile.MpegEngineID = video_opt->MpegEngineID;
		video_profile.VideoDecoderID = video_opt->VideoDecoderID;
		video_profile.SPUBitstreamFIFOSize = (enable_spu) ? SPU_FIFO_SIZE : 0;
		video_profile.SPUXferFIFOCount = (enable_spu) ? XFER_FIFO_COUNT : 0;

		video_profile.STCID = play_opt->STCid;

		err = DCCOpenVideoDecoderSource(dcc_info.pDCC, &video_profile, &pVideoSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot open video decoder %d\n", err));
			goto exit_with_error;
		}

		err = DCCSetVideoDecoderSourceCodec(pVideoSource, video_opt->Codec);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set video decoder codec %d\n", err));
			goto exit_with_error;
		}
	}
#endif

	err = DCCGetScalerModuleID(dcc_info.pDCC, dcc_info.route, DCCSurface_Video, videoscaler_id, &(dcc_info.SurfaceID));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get surface to display video source %d\n", err));
		goto exit_with_error;
	}

	err = DCCSetSurfaceSource(dcc_info.pDCC, dcc_info.SurfaceID, pVideoSource);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set the surface source %d\n", err));
		goto exit_with_error;
	}

	audio_profile.BitstreamFIFOSize = audio_opt->fifo_size;
	audio_profile.XferFIFOCount = audio_opt->xfer_count;
	audio_profile.DemuxProgramID = audio_opt->AudioEngineID * 2;
	audio_profile.AudioEngineID = audio_opt->AudioEngineID;
	audio_profile.AudioDecoderID = audio_opt->AudioDecoderID;
	audio_profile.STCID = play_opt->STCid;

	err = DCCOpenAudioDecoderSource(dcc_info.pDCC, &audio_profile, &pAudioSource);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot open audio decoder %d\n", err));
		goto exit_with_error;
	}

	/* dmapool must be created after the module open in case we do no copy transfers */
	err = RUAOpenPool(dcc_info.pRUA, 0, play_opt->dmapool_count, play_opt->dmapool_log2size, RUA_POOL_DIRECTION_SEND, &pDMA);
	if (RMFAILED(err)) {
		RMuint32 poolSize = play_opt->dmapool_count << play_opt->dmapool_log2size;

		fprintf(stderr, "Error cannot open dmapool %d\n\n"
			"requested %lu bytes of dmapool (%lu buffers of %lu bytes), make sure you\n"
			"loaded llad with the right parameters. For example:\n"
			"max_dmapool_memory_size >= %lu max_dmabuffer_log2_size >= %lu\n\n",
			err,
			poolSize,
			play_opt->dmapool_count,
			(RMuint32)(1<<play_opt->dmapool_log2size),
			poolSize,
			play_opt->dmapool_log2size);

		goto exit_with_error;
	}

	dcc_info.pVideoSource = pVideoSource;
	dcc_info.pAudioSource = pAudioSource;
	dcc_info.trickmode_id = RM_NO_TRICKMODE;

	dcc_info.seek_supported = FALSE;

	err = DCCGetVideoDecoderSourceInfo(pVideoSource, &(dcc_info.video_decoder), &(dcc_info.spu_decoder), &(dcc_info.video_timer));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting video decoder source information %d\n", err));
		goto exit_with_error;
	}

#if 0	// test for "mpeg4 720p profile". Profile has to be 816P and codec MPEG4_SD
	{
		enum VideoDecoder_Codec_type codec = VideoDecoder_Codec_MPEG4_SD;
		RUASetProperty(dcc_info.pRUA, dcc_info.video_decoder, RMVideoDecoderPropertyID_Codec, &codec, sizeof(codec), 0);
	}
#endif
	err = DCCGetAudioDecoderSourceInfo(pAudioSource, &(dcc_info.audio_decoder), &(dcc_info.audio_engine), &(dcc_info.audio_timer));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting audio decoder source information %d\n", err));
		goto exit_with_error;
	}

	// apply the fixed vop rate if required
	err = apply_video_decoder_options(&dcc_info, video_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error applying video_decoder_options %d\n", err));
		goto exit_with_error;
	}
	
	if (video_opt->VopInfo.FixedVopRate) {
		RMDBGLOG((ENABLE, "fixed vop rate from command line: %ld / %ld frames per second\n",
			video_opt->VopInfo.VopTimeIncrementResolution, video_opt->VopInfo.FixedVopTimeIncrement));
	}
	else if (video_opt->vtimescale.enable) {
		RMDBGLOG((ENABLE, "video time scale from command line: %ld ticks per second\n",
			video_opt->vtimescale.time_resolution));
	}
	else {
		/* time stamps are in 45k, ask the decoder to interpolate the time info from stream.
		For m4v the property will succeed. */
		video_opt->vtimescale.enable = TRUE;
		video_opt->vtimescale.time_resolution = 90000;
		err = RUASetProperty(dcc_info.pRUA, dcc_info.video_decoder, RMVideoDecoderPropertyID_VideoTimeScale,
			&video_opt->vtimescale, sizeof(video_opt->vtimescale), 0 );
		if (RMSUCCEEDED(err)) {
			RMDBGLOG((ENABLE, "set video time scale: %ld ticks per second\n",
				video_opt->vtimescale.time_resolution));
		}
		else if (0) {
			/* time scaling is not supported - it happens for NO M4V decoders.
			We have to use fixed vop rate. */
			video_opt->VopInfo.FixedVopRate = TRUE;
			video_opt->VopInfo.VopTimeIncrementResolution = 90000;
			video_opt->VopInfo.FixedVopTimeIncrement = 3000;
		
			err = RUASetProperty(dcc_info.pRUA, dcc_info.video_decoder, RMVideoDecoderPropertyID_VopInfo,
				&video_opt->VopInfo, sizeof(video_opt->VopInfo), 0 );
			if (RMSUCCEEDED(err)) {
				RMDBGLOG((ENABLE, "video time scale not supported. Set fixed vop rate: %ld / %ld frames per second\n",
					video_opt->VopInfo.VopTimeIncrementResolution, video_opt->VopInfo.FixedVopTimeIncrement));
			}
			else {
				RMDBGLOG((ENABLE,"video time scale not supported. Error setting fixed VOP rate : %d !\n", err));
			}
		}
	}

	// apply the sample rate, serial out status
	err = apply_audio_engine_options(&dcc_info, audio_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error applying audio engine options %d\n", err));
		goto exit_with_error;
	}
	// apply the audio format - uninit, set codec, set specific parameters, init
	err = apply_audio_decoder_options(&dcc_info, audio_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error applying audio_decoder_options %d\n", err));
		goto exit_with_error;
	}

#ifndef WITH_MONO
	set_default_out_window(&(dcc_info.disp_info->out_window));
	set_default_out_window(&(dcc_info.disp_info->osd_window[0]));
	set_default_out_window(&(dcc_info.disp_info->osd_window[1]));
	dcc_info.disp_info->active_window = &(dcc_info.disp_info->out_window);
	dcc_info.disp_info->video_enable = TRUE;

	err = apply_display_options(&dcc_info, disp_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set display options %d\n", err));
		goto exit_with_error;
	}

	if (manutest == TRUE) {
		if (demux_opt->data_type == RMVDEMUX_VIDEO)
			fprintf(stdout, "\nIs the Video output correctly? <Y/Q> ");
		else if (demux_opt->data_type == RMVDEMUX_AUDIO)
			fprintf(stdout, "\nIs the Audio output correctly? <Y/Q> ");
	}

	display_key_usage(KEYFLAGS);
#endif /*WITH_MONO*/
	
	apply_dvi_hdmi_audio_options(&dcc_info, audio_opt, 0, FALSE, FALSE, FALSE);
#ifndef WITH_MONO
	if (! disp_opt->configure_outports) apply_hdcp(&dcc_info, disp_opt);
#endif

#ifdef ENABLE_SPU_OP
	if(enable_spu){
		RMuint32 spu_decoder = dcc_info.spu_decoder;
		enum SpuDecoder_StreamType_type spu_st = SpuDecoder_StreamType_4by3;  // type according to selected stream from PGC_SPST_CTL
		RMbool spu_disp = TRUE;  // shall sub picture be displayed? may be overridden by forced display from stream. use GetProp_Display to check actual state.
		struct SpuDecoder_Palette_type spu_lut = {{  // DVD format: Y,Cr,Cb
			0x00, 0x28, 0x6d, 0xf0,
			0x00, 0x51, 0xf0, 0x5a,
			0x00, 0x10, 0x80, 0x80,
			0x00, 0xea, 0x80, 0x80,
			
			0x00, 0x66, 0xdb, 0x4e,
			0x00, 0x6a, 0xdd, 0xca,
			0x00, 0xd2, 0x92, 0x10,
			0x00, 0x5b, 0x49, 0x92,
			
			0x00, 0x7b, 0x80, 0x80,
			0x00, 0xc9, 0x98, 0x77,
			0x00, 0x30, 0xb6, 0x6d,
			0x00, 0x4f, 0x51, 0x5b,
			
			0x00, 0x1c, 0x77, 0xb6,
			0x00, 0x61, 0xcf, 0xcf,
			0x00, 0x10, 0x80, 0x80,
			0x00, 0xbf, 0x80, 0x80,
		}};  // dummy ScalerModuleID
		err = RUASetProperty(dcc_info.pRUA, spu_decoder, RMSpuDecoderPropertyID_Palette, &spu_lut, sizeof(spu_lut), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set spu palette\n"));
			goto exit_with_error;
		}

		err = RUASetProperty(dcc_info.pRUA, spu_decoder, RMSpuDecoderPropertyID_StreamType,&spu_st, sizeof(spu_st), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set spu type\n"));
			goto exit_with_error;
		}
			
		err = RUASetProperty(dcc_info.pRUA, spu_decoder, RMSpuDecoderPropertyID_SubpictureOn, &spu_disp, sizeof(spu_disp), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set spu ON\n"));
			goto exit_with_error;
		}
	}
#endif	// ENABLE_SPU_OP

	context.pRUA = dcc_info.pRUA;
	context.pDMA = pDMA;
	context.repack_sample = demux_opt->repack_sample;
	context.enable_spu = enable_spu;
	context.cmd = 0;
	context.start_90khz = play_opt->start_ms * 90;

	context.dcc_info = &dcc_info;

	context.PSMcontext = &PSMContext;
	PSMContext.validPSMContexts = 1;
	PSMContext.currentActivePSMContext = 1;
	PSMContext.keyflags = KEYFLAGS;


	file = open_stream(play_opt->filename, RM_FILE_OPEN_READ, 0);
	if (file == NULL) {
		fprintf(stderr, "Cannot open file %s\n", play_opt->filename);
		goto exit_with_error;
	}

	err = RMSizeOfOpenFile(file, &(context.file_size));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot find file size\n"));
		context.file_size = (RMint64) -1;
	}

	RMDBGLOG((ENABLE, "file: %s, size %llu, duration %llu\n", play_opt->filename, context.file_size, play_opt->duration / 1000));

	if (play_opt->duration)
		fprintf(stderr, "duration %llu secs\n", play_opt->duration / 1000);

	dcc_info.RM_PSM_commands = RM_PSM_ENABLE_PLAY;
	dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_STOP;
	dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_PAUSE;

	dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_SPEED;
	dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_FASTER;
	dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_SLOWER;
	dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_NEXTPIC;

	if ((play_opt->duration > 1000) && (context.file_size > 0)) {
		RMDBGLOG((ENABLE, "seek and iframe mode enabled\n"));

		dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_SEEK;
		
		dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_IFWD;
		dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_IRWD;

		context.dcc_info->seek_supported = TRUE;
		context.dcc_info->iframe_supported = TRUE;
	}


	if (RMFAILED (InitUserDataProcessing(&context))) {
		goto exit_with_error;
	}

	/* correct pids according to audio codec and system type */
	if ((demux_opt->system_type == RM_SYSTEM_MPEG2_DVD) || (demux_opt->system_type == RM_SYSTEM_MPEG2_PROGRAM)) {
		if (demux_opt->audio_pid == 0) {/* If audio PID==PES ID is not provided by user use audio codec option to detect */
			demux_opt->audio_pid = (audio_opt->Codec == AudioDecoder_Codec_MPEG1) ? 0xC0:0xBD;
		}
		if (audio_opt->Codec == AudioDecoder_Codec_MPEG1) {
			if ( demux_opt->audio_pid != (0xC0 + demux_opt->audio_subid)) {
				RMDBGPRINT((ENABLE, "\n***************** audio_pid audio_subid conflict *****************\n"));
				RMDBGPRINT((ENABLE, "*** for mpeg audio select either audio_pid, either audio_subid ***\n"));
				RMDBGPRINT((ENABLE, "******************************************************************\n\n"));
			}
			demux_opt->audio_pid = 0xC0 + demux_opt->audio_subid;
		}
	}
#ifndef WITH_MONO	
	RMTermInit(TRUE);    // don't allow ctrl-C and the like ...
	RMSignalInit(NULL, NULL);  // ... but catch other termination signals to call RMTermExit()
#endif


	repack_buf = (RMuint8 *) RMMalloc(1<<DMA_BUFFER_SIZE_LOG2);
	if (repack_buf == NULL)
		goto cleanup;


	do {
		RMuint8 *buf = NULL;
		enum RM_PSM_State PlaybackStatus;

		RMDBGLOG((ENABLE, "do-while\n"));
		if (play_opt->start_pause) {
			RMDBGLOG((ENABLE, "start in pause mode!\n"));
			/* required, because if we do 'next' the decoder *must* be running */
			err = Play(&context, RM_DEVICES_VIDEO, /*DCCVideoPlayIFrame*/DCCVideoPlayFwd);
			if (RMFAILED(err)) {
				fprintf(stderr, "Cannot start decoders %d\n", err);
				goto cleanup;
			}
			
			err = Pause(&context, RM_DEVICES_VIDEO);
			if (RMFAILED(err)) {
				fprintf(stderr, "Cannot pause decoders %d\n", err);
				goto cleanup;
			}
			RM_PSM_SetState(context.PSMcontext, &(context.dcc_info), RM_PSM_Paused);
		}
		else 
			RM_PSM_SetState(context.PSMcontext, &(context.dcc_info), RM_PSM_Playing);
		play_opt->start_pause = FALSE;

	mainloop:
		

		RMDBGLOG((ENABLE, "mainloop\n"));
		file_offset = 0;
		err = RMSeekFile(file, 0, RM_FILE_SEEK_START);
		if (err != RM_OK) {
			RMDBGLOG((ENABLE, "Error seeking file to beginning %d\n", err));
			goto cleanup;
		}


	mainloop_no_seek:
		RMDBGLOG((ENABLE, "mainloop_noseek\n"));

		if (actions.cmd == RM_SEEK) {
			RMint64 seek_pos;

			seek_pos = (dcc_info.seek_time * context.file_size * 1000) / (play_opt->duration);
			RMDBGLOG((ENABLE, "seeking to %lu s, pos %llu\n", dcc_info.seek_time, seek_pos)); 

			if (RMSeekFile(file, seek_pos, RM_FILE_SEEK_START) != RM_OK) {
				RMDBGLOG((ENABLE, "Error: seeking file to position %lu s, %lld kB\n", dcc_info.seek_time, seek_pos/1024));
				goto cleanup;
			}

		}

		context.FirstSystemTimeStamp = TRUE;
		context.ResumeFromTrickMode = FALSE;
		context.audio_byte_counter = 0;
		context.video_byte_counter = 0;
		context.audio_repack_buf = (RMuint8 *) NULL;
		context.video_repack_buf = (RMuint8 *) NULL;
		context.spu_repack_buf = (RMuint8 *) NULL;
		context.audio_repack_offset = 0;
		context.video_repack_offset = 0;
		context.spu_repack_offset = 0;
		context.audio_repack_size = 0;
		context.video_repack_size = 0;
		context.spu_repack_size = 0;
		context.audio_repack_pts = 0;
		context.video_repack_pts = 0;
		context.spu_repack_pts = 0;
		context.audio_repack_pts_valid = FALSE;
		context.video_repack_pts_valid = FALSE;
		context.spu_repack_pts_valid = FALSE;
		context.audio_first_access_unit_pointer_valid = FALSE;
		context.audio_first_access_unit_pointer = 0;

		context.waitForValidAudioPTS = TRUE;
		context.waitForValidVideoPTS = TRUE;
		context.ignoreCallback = FALSE;

		if (demux) {
			RMvdemuxReset(demux);
			RMvdemuxSetVideoStream(demux, demux_opt->video_pid, 0);
			RMvdemuxSetSubpictureStream(demux, demux_opt->spu_subid);
			RMvdemuxSetAudioStream(demux, demux_opt->audio_pid, demux_opt->audio_subid);
		}

		DCCSTCSetSpeed(dcc_info.pStcSource, play_opt->speed_N, play_opt->speed_M);


		PlaybackStatus = RM_PSM_GetState(context.PSMcontext, &(context.dcc_info));
		if ((PlaybackStatus != RM_PSM_Paused) && (PlaybackStatus != RM_PSM_Stopped)) {
			RMDBGLOG((ENABLE, "setting play state\n"));
			RM_PSM_SetState(context.PSMcontext, &(context.dcc_info), RM_PSM_Playing);	
		}
		else 
			PROCESS_KEY(FALSE, TRUE);

		
		switch(user_data_app_mode) {
		case user_data_dma_full_buffer: /* ReceivePool for used data should be cleared every time when Video is stopped */
		case user_data_dma_no_delay:
		case user_data_dma_minimum_size:
		case user_data_dma_exact_size:
			RUAPreparePoolForReceiveData(context.pDmaUserData);
			break;
		default:
			break;
		}

		// the following call will configure the decoders, after that we can 'pause' them
		err = Play(&context, RM_DEVICES_AUDIO | RM_DEVICES_VIDEO, DCCVideoPlayFwd);
		if (err != RM_OK)
			goto exit_with_error;

		/* do prebufferization only when in playing state */
		if (RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Playing) {

			Pause(&context, RM_DEVICES_STC | RM_DEVICES_VIDEO | RM_DEVICES_AUDIO);
		
			RM_PSM_SetState(context.PSMcontext, &(context.dcc_info), RM_PSM_Prebuffering);
			if (manutest != TRUE)
				fprintf(stderr, "prebuffering\n");
		}



#ifdef WITH_MONO
		RMDCCInfo(&dcc_info); // pass DCC context to application
#endif

		/* wake up disks if necessary */
		switch (play_opt->disk_ctrl_state) {
		case DISK_CONTROL_STATE_DISABLE:
		case DISK_CONTROL_STATE_RUNNING:
			break;
		case DISK_CONTROL_STATE_SLEEPING:
			if(play_opt->disk_ctrl_callback && play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_RUN) == RM_OK)
				play_opt->disk_ctrl_state = DISK_CONTROL_STATE_RUNNING;
			break;
		}

		while (1) { // additionnal while to handle commands issued during EOSWait
			RMuint32 total = 0;
			while (1) {
				
				RMuint32 count;
				RMstatus status;
				
				PROCESS_KEY(FALSE, TRUE);
				

							
				if (demux_opt->repack_sample) {
					buf = repack_buf;
				}
				else {
					if (buf) {
						RMDBGLOG((ENABLE, "******************** unreleased buffer found!\n"));
						RUAReleaseBuffer(pDMA, buf);
						buf = NULL;
					}

				get_buffer:
					switch (play_opt->disk_ctrl_state) {
					case DISK_CONTROL_STATE_DISABLE:
					case DISK_CONTROL_STATE_SLEEPING:
						break;
					case DISK_CONTROL_STATE_RUNNING:
						if (dmabuffer_index > 0) {
							dmabuffer_index--;
							buf = dmabuffer_array[dmabuffer_index];
							goto fill_buffer;
						}
						break;
					}
					
					while (RUAGetBuffer(pDMA, &buf,  GETBUFFER_TIMEOUT_US) != RM_OK) {

						RMDBGLOG((ENABLE, "\t\t****************get buffer failed!\n"));

						check_prebuf_state(&context, 0);

						switch (play_opt->disk_ctrl_state) {
						case DISK_CONTROL_STATE_DISABLE:
						case DISK_CONTROL_STATE_SLEEPING:
							break;
						case DISK_CONTROL_STATE_RUNNING:
							if(play_opt->disk_ctrl_callback && play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_SLEEP) == RM_OK)
								play_opt->disk_ctrl_state = DISK_CONTROL_STATE_SLEEPING;
							break;
						}

						
						PROCESS_KEY(FALSE, TRUE);
					}
				}
				
				check_prebuf_state(&context, (RMuint32) (1<<(play_opt->dmapool_log2size)));

				switch (play_opt->disk_ctrl_state) {
				case DISK_CONTROL_STATE_DISABLE:
				case DISK_CONTROL_STATE_RUNNING:
					break;
				case DISK_CONTROL_STATE_SLEEPING:
					dmabuffer_array[dmabuffer_index] = buf;
					dmabuffer_index ++;
					if (dmabuffer_index + play_opt->disk_ctrl_low_level >= play_opt->dmapool_count) {
						if(play_opt->disk_ctrl_callback && play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_RUN) == RM_OK)
							play_opt->disk_ctrl_state = DISK_CONTROL_STATE_RUNNING;
					}
					goto get_buffer;
				}
				
			fill_buffer:



			update_hdmi(&dcc_info, disp_opt, audio_opt);
				
				if (RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_IRewind) {
					RMint64 position;
					RMuint64 seekto;
					
					
					if (!trickSizeToSend) {
						trickSizeToSend = (RMuint32) (context.file_size / (play_opt->duration / 500)); //there are roughly 2 iframes per second
						trickBuffersToSend = trickSizeToSend >> play_opt->dmapool_log2size;
						RMDBGLOG((ENABLE, "size %llu, duration %lu s, iframeSize %lu, buffers %lu (of %lu bytes)\n", 
							  context.file_size, 
							  (RMuint32)(play_opt->duration / 1000), 
							  trickSizeToSend,
							  trickBuffersToSend,
							  (1<<play_opt->dmapool_log2size)));
						
					}
					if (trickBuffersSent >= trickBuffersToSend)
						trickBuffersSent = 0;
					
					if (trickBuffersSent == 0) {
						RMGetCurrentPositionOfFile(file, &position);
						seekto = position - (RMuint64) 2 * trickBuffersToSend * (1<<(play_opt->dmapool_log2size));
						RMDBGLOG((ENABLE, "pos %llu, seekto %llu\n", position, seekto));
						status = RMSeekFile(file, seekto, RM_FILE_SEEK_START);
						if (status != RM_OK) {
							perror("error seeking in rwd trickmode, assume EOS\n");
							break;
						}
					}
					
					status = RMReadFile(file, buf, (1<<play_opt->dmapool_log2size), &count);
					trickBuffersSent++;
					RMDBGLOG((ENABLE, "sent buffer %lu\n", trickBuffersSent));
				}
				else {
					status = RMReadFile(file, buf, (1<<play_opt->dmapool_log2size), &count);
					trickBuffersSent = 0;
				}
					
				total += count;
				RMDBGLOG((DISABLE, "bytes read %lu, total %lu\n", count, total));
				
				if (status == RM_ERRORREADFILE) {
					RMDBGLOG((ENABLE, "Error reading file %d\n", status));
					goto cleanup;
				}
				
				if (status == RM_ERRORENDOFFILE) {
					RMDBGLOG((ENABLE, "end of file\n"));
					if (demux_opt->repack_sample) 
						flush_repacked_sample(&context);
					else {
						RMDBGLOG((ENABLE, "release a buffer\n"));
						RUAReleaseBuffer(pDMA, buf);
						buf = NULL;
					}
					break;
				}
				
				file_offset += count;
				
				if (demux) {
					RMvdemuxDemux(demux, buf, count);
					/* check if the user pressed a key when we were processing a callback */
					RMDBGLOG((KEYDBG, "after callback\n"));
					PROCESS_KEY(FALSE, FALSE);
				}
				else {
					
					// this part of the code should be removed cause it's deprecated
					
					RMbool pts_valid = FALSE;
					RMuint64 stc;
					
					/* send only ONCE the PTS, do not use FistSystemTimeStamp which is set on TRICKMODE */
					if ((demux_opt->data_type == RMVDEMUX_AUDIO) && (context.audio_byte_counter == 0))
						pts_valid = TRUE;
					
					/* send only ONCE the PTS, do not use FistSystemTimeStamp which is set on TRICKMODE */
					if ((demux_opt->data_type == RMVDEMUX_VIDEO) && (context.video_byte_counter == 0))
						pts_valid = TRUE;
					
					/* fast forward may have been too fast for the decoder. Must set the STC
					   to the current picture in display to avoid skipping frames to catch STC 
					*/
					if (dcc_info.state != RM_PLAYING_TRICKMODE) {
						RMbool stc_valid = FALSE;
						
						if (context.FirstSystemTimeStamp) {
							stc = 0;
							stc_valid = TRUE;
							context.FirstSystemTimeStamp = FALSE;
						}
						else if (context.ResumeFromTrickMode) {
							err = RUAGetProperty(dcc_info.pRUA, dcc_info.SurfaceID, RMGenericPropertyID_CurrentDisplayPTS, &stc, sizeof(stc));
							if (RMFAILED(err)) {
								RMDBGLOG((ENABLE, "Cannot get video PTS\n"));
							}
							else {
								stc_valid = TRUE;
								RMDBGPRINT((ENABLE, "Set STC afer trickmode %llu\n", stc));
							}
							context.ResumeFromTrickMode = FALSE;
						}
						if ((stc_valid) && (dcc_info.SurfaceID != 0)) {
							
							DCCSTCSetTime(dcc_info.pStcSource, stc, 45000);
							DCCSTCPlay(dcc_info.pStcSource);
							
						}
					}
					
					PESCallback(buf, count, 0, pts_valid, demux_opt->data_type, 0, &context);
				}
				
				SaveUserData(&context);

#if 0
				// to trace the pts and stc info in audio decoder
				{
					RMuint32 LogMode;
					err = RUAGetProperty(dcc_info.pRUA, dcc_info.audio_decoder, RMGenericPropertyID_AudioDecoderLog, &LogMode, sizeof(RMuint32));
					if(err != RM_OK)
					{
						fprintf(stderr, "Cannot get RMGenericPropertyID_AudioDecoderLog\n");
					}
				}
#endif
				
				if (video_opt->UseAFD || video_opt->ForceAFD) {
					// TODO instead of blind polling, wait for signal from VideoDecoder that AFD has changed
					struct EMhwlibActiveFormatDescription afd;
					err = RUAGetProperty(dcc_info.pRUA, dcc_info.video_decoder, 
						RMVideoDecoderPropertyID_ActiveFormat, 
						&afd, sizeof(afd));
					if (video_opt->ForceAFD) {
						afd.ActiveFormatValid = video_opt->afd.ActiveFormatValid;
						afd.ActiveFormat = video_opt->afd.ActiveFormat;
					}
					if (RMSUCCEEDED(err) && (
						(afd.FrameAspectRatio.X && (afd.FrameAspectRatio.X != video_opt->afd.FrameAspectRatio.X)) || 
						(afd.FrameAspectRatio.Y && (afd.FrameAspectRatio.Y != video_opt->afd.FrameAspectRatio.Y)) || 
						(afd.ActiveFormatValid && (afd.ActiveFormat != video_opt->afd.ActiveFormat)) || 
						(afd.ActiveFormatValid != video_opt->afd.ActiveFormatValid)
					)) {
						fprintf(stderr, "\n\nReceived new content Active Format Descriptor: %salid Active Format \"%s\" (%u), Frame Aspect Ratio %lu:%lu\n", 
							afd.ActiveFormatValid ? "V" : "Inv", 
							get_afd_name(afd.ActiveFormat), 
							afd.ActiveFormat, 
							afd.FrameAspectRatio.X, 
							afd.FrameAspectRatio.Y);
						video_opt->afd = afd;
						{
							RMbool output_variable_ar;
							struct EMhwlibActiveFormatDescription output_afd;
							
							// get current output AFD and capabilities
							output_afd.FrameAspectRatio.X = disp_opt->ar_x;
							output_afd.FrameAspectRatio.Y = disp_opt->ar_y;
							output_afd.ActiveFormat = disp_opt->active_format;
							output_afd.ActiveFormatValid = disp_opt->active_format_valid;
							get_output_variable_aspect_ratio(disp_opt->standard, &output_variable_ar);
							
							// Apply content AFD to the scaler input window (zoom)
							apply_active_format_input(dcc_info.pRUA, 
								dcc_info.SurfaceID, 
								(dcc_info.route == DCCRoute_Secondary) ? DispVCRMixer : DispMainMixer, 
								afd, 
								FALSE, NULL, NULL, NULL, NULL, 
								output_variable_ar, &output_afd);
							
							// Modify output AFD, as needed
							if (
								(output_afd.FrameAspectRatio.X && (output_afd.FrameAspectRatio.X != disp_opt->ar_x)) || 
								(output_afd.FrameAspectRatio.Y && (output_afd.FrameAspectRatio.Y != disp_opt->ar_y)) || 
								(output_afd.ActiveFormatValid && (output_afd.ActiveFormat != disp_opt->active_format)) || 
								(output_afd.ActiveFormatValid != disp_opt->active_format_valid)
							) {
								apply_active_format_output(dcc_info.pRUA, 
									(dcc_info.route == DCCRoute_Secondary) ? DispVCRMixer : DispMainMixer, 
									disp_opt->dh_info->pDH, 
									output_afd);
								disp_opt->ar_x = output_afd.FrameAspectRatio.X;
								disp_opt->ar_y = output_afd.FrameAspectRatio.Y;
								disp_opt->active_format_valid = output_afd.ActiveFormatValid;
								disp_opt->active_format = output_afd.ActiveFormat;
							}
						}
					}
				}
				
				PROCESS_KEY(TRUE, TRUE);
				
				if (!demux_opt->repack_sample) {
					RUAReleaseBuffer(pDMA, buf);
					buf = NULL;
				}
			}
			
			check_prebuf_state(&context, 0);

			switch (play_opt->disk_ctrl_state) {
			case DISK_CONTROL_STATE_DISABLE:
			case DISK_CONTROL_STATE_SLEEPING:
				break;
			case DISK_CONTROL_STATE_RUNNING:
				if(play_opt->disk_ctrl_callback && play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_SLEEP) == RM_OK)
					play_opt->disk_ctrl_state = DISK_CONTROL_STATE_SLEEPING;
				break;
			}

			
			// in case we're still in pause state, wait for a key
			PROCESS_KEY(FALSE, TRUE);
			

			err = WaitForEOS(&context, &actions);
			{
				RMuint64 stc;
				DCCSTCGetTime(dcc_info.pStcSource, &stc, 90000);
			
				RMDBGLOG((ENABLE, "Timer duration %llu s\n", stc/90000));
			}
			if (err == RM_KEY_WHILE_WAITING_EOS) {
				err = RM_OK;
				PROCESS_KEY(FALSE, FALSE);
				if ((manutest == TRUE) && (actions.cmd == RM_MANU_QUIT_OK)) {
					goto cleanup;
				}
			}
			else {
				break; //EOS
			}
		}

		if (play_opt->loop_count > 0)
			play_opt->loop_count --;

		/* if there is another loop, stop devices */
		if ((play_opt->loop_count > 0) || (play_opt->waitexit != TRUE) || (play_opt->infinite_loop))
			Stop(&context, RM_DEVICES_AUDIO | RM_DEVICES_VIDEO | RM_DEVICES_STC, DCCStopMode_BlackFrame);

	} while ((play_opt->infinite_loop) || (play_opt->loop_count > 0));

 cleanup:
	error = 0;

 exit_with_error:
	if( play_opt->waitexit ) {
		RMascii key;
		fprintf(stderr, "press q key again if you really want to stop & quit\n");
		while ( !(RMGetKeyNoWait(&key) && ((key == 'q') || (key =='Q'))) );
	}
	
#ifndef WITH_MONO	
	RMTermExit();
#endif

	if (err != RM_OK) {
		fprintf(stderr, "quitting due to error %s (%d)...\n", RMstatusToString(err), err);
		error = err; //exit with error
	}

	RMDBGLOG((ENABLE, "closing...\n"));

	if (demux) {
		RMDBGLOG((ENABLE, "close demux\n"));
		RMDeleteVdemux(demux);
	}

	if (repack_buf != NULL)
		RMFree(repack_buf);

	if (dmabuffer_index) {
		RMuint32 i;
		for (i = 0; i < dmabuffer_index; i++) {
			RUAReleaseBuffer(pDMA, dmabuffer_array[i]);
			RMDBGLOG((ENABLE, "released buffer[%lu] @ 0x%08lx\n", i, dmabuffer_array[i]));
		}
		RMFree(dmabuffer_array);
	}


	if (manutest == TRUE) {
		if (manutest_res == RM_MANU_QUIT_OK)
			fprintf(stdout, "Succeed.\n");
		else 
			fprintf(stdout, "Failed.\n");
	}

	if (file) {
		RMDBGLOG((ENABLE, "closing bitstream %s\n", play_opt->filename));
		RMCloseFile(file);
	}

	err = close_save_files(play_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot close files used to save data %d\n", err));
		error = -1;
	}

	if (pVideoSource) {
		RMDBGLOG((ENABLE, "stop video source\n"));
		err = DCCStopVideoSource(pVideoSource, DCCStopMode_LastFrame);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot stop video decoder %d\n", err));
			error = -1;
		}
		if (context.pmapped_user_data_fifo_base) {
			RUAUnMap(context.pRUA, context.pmapped_user_data_fifo_base, context.user_data_fifo_size);
		}
		if (context.user_data_fifo_base) {
			RUAUnLock(context.pRUA, context.user_data_fifo_base, context.user_data_fifo_size);
		}
		if (pgbus)
			gbus_close(pgbus);
		if (pllad)
			llad_close(pllad);

		RMDBGLOG((ENABLE, "close video source\n"));
		err = DCCCloseVideoSource(pVideoSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error cannot close video decoder %d\n", err));
		}
	}
	
	if (pAudioSource) {
		RMDBGLOG((ENABLE, "stop audio source\n"));
		err = DCCStopAudioSource(pAudioSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot stop audio decoder %d\n", err));
			error = -1;
		}
		RMDBGLOG((ENABLE, "close audio source\n"));
		err = DCCCloseAudioSource(pAudioSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error cannot close video decoder %d\n", err));
			error = -1;
		}
	}

	if (dcc_info.pStcSource) {
		RMDBGLOG((ENABLE, "stop STC\n"));
		DCCSTCStop(dcc_info.pStcSource);

		RMDBGLOG((ENABLE, "close STC\n"));
		DCCSTCClose(dcc_info.pStcSource);
	}

	if (pDMA) {
		RMDBGLOG((ENABLE, "close DMA pool\n"));
		err = RUAClosePool(pDMA);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error cannot close dmapool %d\n", err));
			error = -1;
		}
	}


	if (context.f_record) {
		fclose(context.f_record);
		context.f_record = NULL;
	}
	if (context.pReceive)
		DCCCloseReceive (context.pReceive);


	clear_video_options(&dcc_info, video_opt);
#ifndef WITH_MONO	
	clear_display_options(&dcc_info, disp_opt);

	if (dcc_info.pDCC) {
		RMDBGLOG((ENABLE, "close DCC\n"));
		err = DCCClose(dcc_info.pDCC);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot close DCC %d\n", err));
			error = -1;
		}
	}

	if (dcc_info.pRUA) {
		RMDBGLOG((ENABLE, "close RUA\n"));
		err = RUADestroyInstance(dcc_info.pRUA);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot destroy RUA instance %d\n", err));
			error = -1;
		}
	}
#endif /*WITH_MONO*/

	if (manutest == TRUE)
		return ((manutest_res == RM_MANU_QUIT_OK) ? 0 : 1);

	return error;
}
