/*****************************************
 Copyright � 2005
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   play_asf_streaming.c

  based on code from Laurent Crinon and Glen Adams

  @author Sebastian Frias Feltrer
  @date   2005-09-10
*/


#define ALLOW_OS_CODE 1

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <assert.h>
#include <errno.h>


#include "get_key.h"
#include "../rmasfdemux/include/rmasfdemuxapi.h"
#include "../rmlibcw/include/rmlibcw.h"
#include "../rmstreamingprotocols/include/rmrtspapi.h"
#include "../rmcore/include/rmcore.h"
#include "../dcc/include/dcc.h"

#include "common.h"


#include "../rmasfdemux/include/wmdrm.h"
#include "../rmasfdemux/include/wmdrmopl.h"
#include "../rmwmaprodecoder/include/rmwmaprodefine.h"
#include "../rmwmaprodecoder/include/rmwmaprodecoderapi.h"


#define DEFAULT_BUFFERIZATION_DURATION 3


#define GETBUFFER_TIMEOUT_US    (TIMEOUT_10MS * 10)	  // 100 ms
#define SENDDATA_TIMEOUT_US	(TIMEOUT_10MS * 10)	  // 100 ms

#define ASF_DMA_BUFFER_SIZE_LOG2	15		// 32kB
#define ASF_DMA_BUFFER_COUNT		16		// 16*32kB ~= 512KB

#ifdef WMAPRO_V1
#define AUDIO_DMA_BUFFER_SIZE_LOG2	16		// 64kB
#define AUDIO_DMA_BUFFER_COUNT	        2		// 2*64kB ~= 128KB
#else
#define AUDIO_DMA_BUFFER_SIZE_LOG2	17		// 128kB
#define AUDIO_DMA_BUFFER_COUNT		16		// 16*128kB ~= 2048KB
#endif

#define VIDEO_XFER_FIFO_COUNT	(ASF_DMA_BUFFER_COUNT * (1<<ASF_DMA_BUFFER_SIZE_LOG2) / 2048)		// average video packet size = 2k
#define AUDIO_XFER_FIFO_COUNT	(AUDIO_DMA_BUFFER_COUNT * (1<<AUDIO_DMA_BUFFER_SIZE_LOG2) / 2048)	// average audio packet size = 2k

#define VIDEO_FIFO_SIZE		(5*1024*1024)	// ~= 10sec at 1MB/sec.
#define AUDIO_FIFO_SIZE		(1*1024*1024)	// ~= 10sec at 512kB/sec.

#define ADDITIONAL_WMAPRO_FIFO_SIZE	1024*1024 
#define TMP_WMAPRO_BUFFER_SIZE		32*1024

#define KEYFLAGS (SET_KEY_DISPLAY | SET_KEY_PLAYBACK | SET_KEY_AUDIO | SET_KEY_DEBUG | SET_KEY_SPI)

#define RM_STREAM_VIDEO 0x1
#define RM_STREAM_AUDIO 0x2

#define MAX_NUMBER_OF_AUDIO_STREAMS 16

#define RM_SKIP_TO_RESYNC 0x1

#define MAX_NUMBER_OF_AUDIO_STREAMS 16

#define RM_DEVICES_STC 0x1
#define RM_DEVICES_VIDEO 0x2
#define RM_DEVICES_AUDIO 0x4


#if 0
#define PAYLOADDBG ENABLE
#else
#define PAYLOADDBG DISABLE
#endif

#if 0
#define IFRAMEDBG ENABLE
#else
#define IFRAMEDBG DISABLE
#endif


#if 0
#define TRICKDBG ENABLE
#else
#define TRICKDBG DISABLE
#endif

#if 0
#define SENDDBG ENABLE
#else
#define SENDDBG DISABLE
#endif

#if 0
#define WMAPRODBG	ENABLE
#else
#define WMAPRODBG	DISABLE
#endif

#if 0
#define VC1_STARTCODE_DBG ENABLE
#else
#define VC1_STARTCODE_DBG DISABLE
#endif



#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

#define INFINITE_LOOP 0


#define MAXRESPONSESIZE    16384
#define HEARTBEATINTERVAL     60
#define NETWORK_TIMEOUT      200
#define VECTOR_LENGTH 32
#define MAX_SPEED 8
#define DEFAULT_SPEED 2


struct ASF_Streaming_Context {
	RMRTSPHandle rtspHandle;
	RMuint32 lastHeartBeat;
	ExternalRMASFDemux vASFDemux;
	RMbool eos;
	void *sendContext;
	RMbool enableCallbacks;
};


/* prototypes */

RMuint32 ASFGetContextSize(void);
RMstatus ASFOpen(void *context, RMascii *url, RMuint8 *buf, RMuint32 size, RMuint32 *rcvd);
RMstatus ASFPlay(void *context, RMint32 position, RMint32 speed);
RMstatus ASFPause(void *context);
RMstatus ASFResume(void *context);
RMstatus ASFFlush(void *context);

RMstatus uuDecodeBase64(RMascii *codedString,
			 RMuint32 sizeCodedString,
			 RMuint8 *decodedBuffer,
			 RMuint32 sizeDecodedBuffer,
			 RMuint32 *sizeRes);
RMstatus uuGetDecodedValue(RMascii c, RMint8 *value);



void show_keys(void);
RMuint32 getSecond(void);


/* callbacks */
// EOS signalling from RTSP
RMstatus eos(void *callbackContext); 

// callback to treat the payload of a RTSP packet (in this case, ASF payload)
RMstatus rtsppayload(void *callbackContext, RMuint8 *buf, RMuint32 size);

RMstatus seqLost(void *callbackContext);


/* proxy */

#include "../rmdef/rmdef.h"


typedef enum
{
	ASF_STREAMING_PLAYING = 15,
	ASF_STREAMING_PLAYING_TRICKMODE,
	ASF_STREAMING_PAUSE,
	ASF_STREAMING_STOP,
}ASF_streaming_state;

ASF_streaming_state proxy_get_state(void *context);

void proxy_set_demux(void *context, void *demux);
void proxy_print_Stream_Bitrate_Properties(void *context,
					   unsigned char Stream_Number, 
					   unsigned long Average_Bitrate);
void proxy_print_Bitrate_Mutual_Exclusion(void *context,
					   unsigned long mutex_index, 
					   unsigned short Stream_Numbers_Count,
					   unsigned char bitrate_exclusion,
					   unsigned char Stream_Number);

void proxy_set_payload_extension (void *context,
				  unsigned short Stream_Number,
				  unsigned long Media_Object_Number,
				  unsigned char Media_Object_Number_valid,
				  unsigned short Payload_Extension_System_ID,
				  unsigned char *Payload_Extension_System_Data,
				  unsigned short Partial_Payload_Extension_System_Data_Size,
				  unsigned short Payload_Extension_System_Data_Size,
				  unsigned short bytes_left);

void proxy_set_languagelistcb(void *context,
			      RMuint16 Language_ID_Records_Count,
			      RMuint16 Language_ID_Records_Index,
			      RMuint8 *Language_ID,
			      RMuint8 Partial_Language_ID_Length,
			      RMuint8 Language_ID_Length);

void proxy_set_inband_AspectRatio(void *context,
				  RMuint16 Stream_Num,
				  RMuint32 aspectRatioX,
				  RMuint32 aspectRatioY);

RMstatus proxy_init(int argc, char *argv[], void **context);
RMstatus proxy_terminate(void *context);
void proxy_set_file_properties( void *context,
				unsigned long long File_Size,
				unsigned long long Creation_Date,
				unsigned long long Data_Packets_Count,
				unsigned long long Play_Duration,
				unsigned long long Send_Duration,
				unsigned long long Preroll,
				unsigned long Minimum_Data_Packet_Size,
				unsigned long Maximum_Data_Packet_Size,
				unsigned long Maximum_Bitrate,
				unsigned char Broadcast,
				unsigned char Seekable);

void proxy_set_video_stream_properties(void *context,
				       unsigned char Stream_Number, unsigned long Compression_ID, 
				       unsigned long Image_Width, unsigned long Image_Height,
				       unsigned char *Codec_Specific_Data, 
				       unsigned long Partial_Codec_Specific_Data_Size, 
				       unsigned long Codec_Specific_Data_Size);

void proxy_set_audio_stream_properties(void *context,
				       unsigned char Stream_Number, 
				       unsigned short Codec_ID,
				       unsigned short Number_of_Channels, 
				       unsigned long Samples_Per_Second,
				       unsigned long Average_Number_of_Bytes_Per_Second,
				       unsigned short Block_Alignment, 
				       unsigned short Bits_Per_Sample,
				       unsigned char *Codec_Specific_Data, 
				       unsigned long Partial_Codec_Specific_Data_Size, 
				       unsigned long Codec_Specific_Data_Size);

void proxy_dummy_drm_init(void *context,
			  RMuint8 *Data,
			  RMuint32 Partial_Data_Size,
			  RMuint32 Data_Size);

RMstatus proxy_start_decoders(void *context);
RMstatus proxy_stop_decoders(void *context);
RMstatus proxy_flush(void *context);
RMstatus proxy_flush_video(void *context);
RMstatus proxy_set_speed(void *context, RMint32 speed);
RMstatus proxy_enter_trickmode(void *context);
RMstatus proxy_exit_trickmode(void *context);
RMstatus proxy_WaitForEOS(void *context, RMuint32 *pcmd);
RMuint32 proxy_get_duration(void *context);
RMuint32 proxy_get_position(void *context);
RMstatus proxy_get_status(void *context);
RMstatus proxy_pause(void *context);
RMstatus proxy_resume(void *context);

void proxy_payload(void *context,
		   unsigned char Stream_Number,  
		   unsigned char *buf, unsigned long size,
		   unsigned long bytes_left,
		   unsigned char Is_Key_Frame,
		   unsigned long Media_Object_Number, unsigned char Media_Object_Number_valid,
		   unsigned long Presentation_Time, unsigned char Presentation_Time_valid,
		   unsigned long Offset_Into_Media_Object);

RMstatus proxy_get_buffer(void *context,
		      RMuint8 **buffer,
		      RMuint32 *buffer_size);

void proxy_release_buffer(void *context,
			  RMuint8 *buffer);

void proxy_monitor(void *context);

void proxy_set_bufferization_time(void *context, RMuint32 t);



#define GET_XFER_FIFO_INFO(pRUA, ModuleId, string)			\
	{								\
	struct XferFIFOInfo_type XferFIFOInfo;				\
	RMreal fullness;						\
	RUAGetProperty(pRUA, ModuleId, RMGenericPropertyID_XferFIFOInfo, &XferFIFOInfo, sizeof(XferFIFOInfo)); \
	fullness = (RMreal)((100./XferFIFOInfo.Size)*XferFIFOInfo.Readable); \
	fprintf(stderr, string "( %lx: 0x%08lx %ld W=%ld R=%ld E=%ld ) --> f : %.02f\n", ModuleId, XferFIFOInfo.StartAddress, \
		XferFIFOInfo.Size, XferFIFOInfo.Writable,  XferFIFOInfo.Readable, XferFIFOInfo.Erasable, fullness);	\
}						

#define GET_DATA_FIFO_INFO(pRUA, ModuleId, string)			\
	{								\
	struct DataFIFOInfo DataFIFO;					\
	RMreal fullness;						\
	RUAGetProperty(pRUA, ModuleId, RMGenericPropertyID_DataFIFOInfo, &DataFIFO, sizeof(DataFIFO)); \
	fullness = (RMreal)((100./DataFIFO.Size)*DataFIFO.Readable);	\
	fprintf(stderr, string "( %lx: 0x%08lx %ld W=%ld R=%ld ) --> f : %.02f\n", ModuleId, DataFIFO.StartAddress, \
		DataFIFO.Size, DataFIFO.Writable,  DataFIFO.Readable, fullness); \
}

typedef enum {
	RMasfIFrameFSM_Disabled = 0,
	RMasfIFrameFSM_Init,
	RMasfIFrameFSM_WaitIFrameMONChange,
	RMasfIFrameFSM_SkipNext
}RMasfIFrameFSMstates;

typedef struct {
	RMuint16 languageIDCount;
	RMuint16 languageIDIndex;
	RMnonAscii * languageID;
	RMuint8 languageIDLength;
} RMasfdemuxLanguageID;

struct priv_cmdline {
	RMuint32 dummy;
};

struct asf_context {
	struct RUA *pRUA;
	struct RUABufferPool *pDMA;
	struct RUABufferPool *pDMAuncompressed;
	unsigned char *UncompressedBuffer;
	unsigned char *SequenceHeaderBuffer;
	RMbool FirstSystemTimeStamp;
	struct dcc_context *dcc_info;
	RMuint32 video_stream_index;
	RMuint32 audio_stream_index;
	RMuint32 cmd;
	RMbool SendVideoData;
	RMuint32 prev_video_media_object_number;
	RMuint32 video_frame_counter;
	RMuint32 VideoByteCounter;
	RMbool SendVideoPts;
	RMuint32 video_last_pts;	// used for video hack
	RMuint32 video_vop_tir;
	RMuint32 videoscaler_id;

	RMbool SendAudioData;
	RMuint32 prev_audio_media_object_number;
	RMuint32 audio_frame_counter;
	RMuint32 AudioByteCounter;
	RMbool SendAudioPts;
 	RMuint32 audio_vop_tir;
	RMuint32 start_ms; 	

	ExternWMAProVdecoder vDecoder;

	ExternalRMASFDemux vASFDemux;

	RMbool isIFrameMode;
	RMbool isTrickMode;
	RMint32 IFrameSize;
	RMbool SeekAudio;
	RMbool SeekVideo;
	RMuint32 PrevAudioMON;
	RMuint32 PrevVideoMON;


	struct AudioDecoder_WMAParameters_type wma_params;	// David: I want it to pass information to payload decoder
	RMuint32 WMAPROBitsPacketLength;

	RMfile f_bitstream;

	RMbool video_decoder_initialized;
	RMbool audio_decoder_initialized;
	RMbool audioFirstInit;

	RMuint32 Compression_ID;
	struct VideoDecoder_WMV9VSProp_type wmv9_prop;
	struct VideoDecoder_DIVX3VSProp_type divx3_prop;

	RMuint32 asf_packetSize;
	RMuint64 asf_Header_Object_Size;

	RMuint32 asf_followingIFramePacket;
	RMuint32 asf_followingIFramePacketSize; // not used
	RMuint64 asf_IFramePos;
	RMstatus asf_GetNextIFrameStatus;
	RMasfIFrameFSMstates IFrameFSMState;
	RMuint32 inband_aspect_ratio_x;
	RMuint32 inband_aspect_ratio_y;
	RMuint32 save_inband_aspect_ratio_y;
	
	RMint32 drmError;
	RMbool isContentEncrypted;
	RMbool unsupported_video;

	struct SurfaceAspectRatio_type InBandAspectRatioParams;
	RMbool setAspectRatio;
	RMuint64 Preroll;
	RMbool PrerollSET;
	RMuint64 Duration;
	RMbool ignoreCallback; /* when we catch a key during a callback, we must ignore all subsequent calls to the payload
				  callback  until 'PROCESS_KEY' process it. 
				  Required for 'stop', 'quit', 'seek[zero]' and 'iframe' */
	RMuint64 CurrentDisplayPTS;
	RMint32 IFrameDirection;
	RMbool VideoStreamFound;
	RMbool AudioStreamFound;
	RMbool isAudioOnlyFile;
	RMuint64 lastSTC;
	RMuint64 accurateAudioSeekTo;
	RMbool IgnoreAudio;

	RMuint32 Video_Codec_Specific_Data_Received;
	RMuint32 Audio_Codec_Specific_Data_Received;

	RMuint32 ContiguousVideoLength;
	RMuint32 ContiguousAudioLength;
	RMuint64 video_time_start;
	RMuint64 video_time_end;
	RMuint64 audio_time_start;
	RMuint64 audio_time_end;
	RMuint64 video_time_stamp;
	RMuint64 audio_time_stamp;
	RMint32 min_diff;
	RMint32 max_diff;
	RMuint32 packet_counter;

	RMbool firstIFrame;
	RMbool filePropSET;
	RMbool langPropSET;
	RMasfdemuxLanguageID lang[MAX_NUMBER_OF_AUDIO_STREAMS];
	RMstatus status;
	RMuint32 Presentation_Time;

	RMuint32 bufferization_duration;

	RMbool fDecodingWMAPROPacket;
	struct RMfifo *wmapro_fifo;
	struct wmapro_info *pwrite_wmapro_info;
	struct wmapro_info *pread_wmapro_info;
	RMuint8 *tmp_wmapro_buf;

	struct wmapro_info *pwrite_wmapro_info_original;
	struct wmapro_info *pread_wmapro_info_original;
	RMuint8 *tmp_wmapro_buf_original;

	// for VC1
	RMuint8 *seqHeader;
	RMuint32 seqHeaderSize;
	RMbool addSeqHeader;
	RMbool addEntryHeader;
	RMbool addFrameHeader;
	RMuint8 *entryHeader;
	RMuint32 entryHeaderSize;
	RMbool isVC1;
	RMbool getStartCodeBuffer;
	RMuint8 *startCodeBuffer;
	RMuint32 startCodeBufferSize;
	RMuint32 startCodeBufferLeft;


};

static RMbool fDecodeWMAPRO;

static struct playback_cmdline playback_options; 
static struct display_cmdline  display_options;
static struct video_cmdline video_options;
static struct audio_cmdline audio_options; 
static struct display_context disp_info;
static struct dh_context dh_info = {0,};

static struct RMfifo wmapro_fifo;
static RMuint8  *wmapro_fifo_buffer=NULL;
static RMuint8  *wmapro_fifo_buffer_original=NULL;

static struct priv_cmdline priv_opt;

static RMbool compressed_audio;
static RMuint32 audioStreams;
static RMuint32 audioStreamTable[10];

#define MAX_WMAPRO_INFO 128

struct wmapro_info {
	RMbool new_buffer;
	RMuint8 *ptr;
	RMuint32 size;
	struct emhwlib_info Info;
	RMuint32 Stream_Number;
	RMuint32 Media_Object_Number;
	RMuint32 fSendPTS;
	void *pBuffer;
};




/* implementation */

RMstatus eos(void *callbackContext)
{
	struct ASF_Streaming_Context *ctx = (struct ASF_Streaming_Context *)callbackContext;
	if (ctx->enableCallbacks) {
		RMDBGLOG((ENABLE, "\n\n\n\n\n\n****************** EOS, lastheartbeat %lu\n\n\n\n", ctx->lastHeartBeat));
		ctx->eos = TRUE;
	}
	return RM_OK;
}


RMstatus rtsppayload(void *callbackContext, RMuint8 *buf, RMuint32 size)
{
	struct ASF_Streaming_Context *ctx = (struct ASF_Streaming_Context *)callbackContext;
	struct asf_context *pSendContext = (struct asf_context *)ctx->sendContext;

	if (proxy_get_state(pSendContext) == ASF_STREAMING_PAUSE)
		RMDBGLOG((ENABLE, "callback called when in pause\n"));

	if (ctx->enableCallbacks) {
		RMDBGLOG((LOCALDBG, "payloadCallback(0x%08lx, %lu)\n", (RMuint32)buf, size));
		RMASFVDemuxDEMUX(ctx->vASFDemux, buf, size);
	}
	return RM_OK;
}


RMstatus seqLost(void *callbackContext)
{
	struct ASF_Streaming_Context *ctx = (struct ASF_Streaming_Context *)callbackContext;
	struct asf_context *pSendContext = (struct asf_context *)ctx->sendContext;

	if (ctx->enableCallbacks) {
		RMDBGLOG((ENABLE, "\n\n\n\n\n\n****************** SEQ_LOST, lastheartbeat %lu\n\n\n\n", ctx->lastHeartBeat));
		RMASFVDemuxResetState(ctx->vASFDemux);
		pSendContext->firstIFrame = FALSE;
		pSendContext->FirstSystemTimeStamp = FALSE;
		proxy_flush(pSendContext);
	}
	return RM_OK;
}


static RMbool parseVC1SeqHeader(struct asf_context *pSendContext, RMuint8 *buffer, RMuint32 size)
{
	RMuint32 i;
	RMuint32 entryHeaderFound = 0;
	RMuint32 entryHeaderSize = 0;

	if (size < 3)
		return FALSE;

	for (i = 3; i < size; i++) {

		if ((entryHeaderFound) && (buffer[i-2] != 0) && (buffer[i-1] != 0) && (buffer[i] != 1))
			entryHeaderSize++;
		
		if ((buffer[i-3] == 0) && (buffer[i-2] == 0) && (buffer[i-1] == 1) && (buffer[i] == 0xe)) {
			pSendContext->entryHeader = (buffer + i - 3);
			entryHeaderFound = i;
		}
	}

	pSendContext->entryHeaderSize = entryHeaderSize + 4;

	if (entryHeaderFound) {
		RMDBGLOG((ENABLE, "entryHeader found at i=%lu, size %lu\n", entryHeaderFound - 3, pSendContext->entryHeaderSize));

#if 0
		RMDBGLOG((ENABLE, "hacking it by clearing Broken_link and setting Closed_entry\n"));

		*(pSendContext->entryHeader + 4) = *(pSendContext->entryHeader + 4) | 0xC;
#endif

		for (i = 0; i < pSendContext->entryHeaderSize; i++)
			fprintf(stderr, "0x%02X ", *(pSendContext->entryHeader + i));

		fprintf(stderr, "\n");

		return TRUE;
	}

	return FALSE;

}



void show_keys()
{
	printf("\n***********  Key usage  : ***********\n"
	       "'space'    : pause\n"
	       "'p'        : resume\n"
	       "'f'        : seek (experimental)\n"
	       "'q'        : quit \n"
	       "*************************************\n\n");
}



RMuint32 ASFGetContextSize()
{
	return sizeof(struct ASF_Streaming_Context);
}

RMstatus ASFOpen(void *context, RMascii *url, RMuint8 *buf, RMuint32 size, RMuint32 *receivedASFHeaderSize)
{
	struct ASF_Streaming_Context *ctx = (struct ASF_Streaming_Context *)context;
	RMascii *describeResponse;
	RMstatus status;

	*receivedASFHeaderSize = 0;

	if (!context) {
		printf("ASFOpen: context is NULL\n");
		return RM_ERROR;
	}

	ctx->lastHeartBeat = getSecond() & 0x0fffffff;
	
	ctx->rtspHandle = RMRTSPOpen(url, HEARTBEATINTERVAL);
	if (!ctx->rtspHandle) {
		RMDBGLOG((ENABLE, "cant open rtsp\n"));
		return RM_ERROR;
	}

	RMRTSPRegisterCallbacks(ctx->rtspHandle, 
				ctx,         // callbacks' context
				rtsppayload, // payload callback
				eos,         // eos callback
				seqLost);       // seqlost callback (unused)

	describeResponse = malloc(sizeof *describeResponse * MAXRESPONSESIZE);
	if (!describeResponse) {
		RMDBGLOG((ENABLE, "not enough memory for describe response\n"));
	}


	// Send the DESCRIBE request to get a description of the movie, including its ASF header
	if (RMRTSPSendDescribeRequest(ctx->rtspHandle, (RMuint8*)describeResponse) != RM_OK) {
		printf("sendDescribeRequest failed\n");
		return RM_ERROR;
	}


	// uuDecodeBase64 the ASF header
	{
		RMascii *start;
		RMascii *end;
		
		if (RMFindAsciiString(describeResponse, "a=pgmpu:data:application/vnd.ms.wms-hdr.asfv1;base64,", &start) > 0) {
			start += RMasciiLength("a=pgmpu:data:application/vnd.ms.wms-hdr.asfv1;base64,");
			if (RMFindAsciiCharacter(start, '\r', &end) > 0) {
				status = uuDecodeBase64(start,
							(RMuint32)(end - start),
							buf,
							size,
							receivedASFHeaderSize);
			}
		}
	}

	free(describeResponse);

	// Send the video SETUP request to setup the streaming session of this movie with the server
	if (RMRTSPSendSetupRequest(ctx->rtspHandle, "video") != RM_OK) {
		printf("sendSetupRequest failed\n");
		return RM_ERROR;
	}

	// Send the audio SETUP request to setup the streaming session of this movie with the server
	if (RMRTSPSendSetupRequest(ctx->rtspHandle, "audio") != RM_OK) {
		printf("sendSetupRequest failed\n");
		return RM_ERROR;
	}

	return RM_OK;
}


RMstatus ASFPlay(void *context, RMint32 position, RMint32 speed)
{
	struct ASF_Streaming_Context *ctx = (struct ASF_Streaming_Context *)context;

	RMDBGLOG((ENABLE, "play from %lu at %ld\n", position, speed));

	// Make sure the context has been allocated
	if (context == NULL) {
		printf("ASFPlay: context is NULL\n");
		return RM_ERROR;
	}

	// RMRTSPSend the PLAY request to begin the data streaming
	if (RMRTSPSendPlayRequest(ctx->rtspHandle, position, speed) != RM_OK) {
		printf("RMRTSPSendPlayRequest failed\n");
		return RM_ERROR;
	}

	return RM_OK;
}

RMstatus ASFPause(void *context)
{
	struct ASF_Streaming_Context *ctx = (struct ASF_Streaming_Context *)context;

	// Make sure the context has been allocated
	if (context == NULL) {
		printf("ASFPause: context is NULL\n");
		return RM_ERROR;
	}

	// RMRTSPSend the PAUSE request to pause the stream
	if (RMRTSPSendPauseRequest(ctx->rtspHandle) != RM_OK) {
		printf("RMRTSPSendPauseRequest failed\n");
		return RM_ERROR;
	}

	return RM_OK;
}

RMstatus ASFResume(void *context)
{
	struct ASF_Streaming_Context *ctx = (struct ASF_Streaming_Context *)context;

	// Make sure the context has been allocated
	if (context == NULL) {
		printf("ASFResume: context is NULL\n");
		return RM_ERROR;
	}

	// RMRTSPSend the RESUME request to resume the stream from previously paused position
	if (RMRTSPSendResumeRequest(ctx->rtspHandle) != RM_OK) {
		printf("RMRTSPSendResumeRequest failed\n");
		return RM_ERROR;
	}

	return RM_OK;
}

#define FLUSH_BUFFER_SIZE 4096

RMstatus ASFFlush(void *context)
{
	struct ASF_Streaming_Context *ctx = (struct ASF_Streaming_Context *)context;
	RMstatus status = RM_OK;
	RMuint8 buffer[FLUSH_BUFFER_SIZE];
	RMuint32 readBytes;

	ctx->enableCallbacks = FALSE;

	while (1) {
		
		status = RMRTSPReadSockets(ctx->rtspHandle, buffer, FLUSH_BUFFER_SIZE, NETWORK_TIMEOUT, &readBytes);

		RMDBGLOG((ENABLE, "flush %lu bytes\n", readBytes));

		if (status == RM_TIMEOUT)
			break;
	}

	ctx->enableCallbacks = TRUE;

	return RM_OK;
}



RMuint32 getSecond(void)
{
	struct timeval current_time;

	gettimeofday(&current_time, 0);
	return(current_time.tv_sec);
}


RMstatus uuDecodeBase64(RMascii *codedString,
			 RMuint32 sizeCodedString,
			 RMuint8 *decodedBuffer,
			 RMuint32 sizeDecodedBuffer,
			 RMuint32 *sizeRes)
{
	RMuint32 indexCodedString = 0;
	RMuint32 indexDecodedBuffer = 0;
	RMuint8	tabCodedChar[4];
	RMuint8	tabDecodedChar[3];
	RMuint32 nbCharInCodedTab = 0;
	RMstatus useChar;
	RMint8 value;
	RMuint32 nbCharDecoded = 0;
	RMuint32 i = 0;
	RMbool needToBreak;

	if (codedString == NULL)
		return RM_ERROR;

	*sizeRes = 0;
	while(1){
		if(indexCodedString >= sizeCodedString)
			break;

		useChar = uuGetDecodedValue(codedString[indexCodedString], &value);
		indexCodedString++;

		if (useChar == RM_OK){
			nbCharDecoded = 3;
			needToBreak = FALSE;
			if(value == -1){
				if (nbCharInCodedTab == 0)
					break;
			
				if ((nbCharInCodedTab == 1) || (nbCharInCodedTab == 2))
					nbCharDecoded = 1;
				else
					nbCharDecoded = 2;
	
				nbCharInCodedTab = 3;
				needToBreak = TRUE;
			}
			
			tabCodedChar[nbCharInCodedTab] = value & 0xFF;
			nbCharInCodedTab ++;

			if(nbCharInCodedTab == 4){
				nbCharInCodedTab = 0;
				
				tabDecodedChar[0] = (tabCodedChar[0] << 2) | ((tabCodedChar[1] & 0x30) >> 4);
				tabDecodedChar[1] = ((tabCodedChar[1] & 0x0F) << 4) | ((tabCodedChar[2] & 0x3C) >> 2);
				tabDecodedChar[2] = ((tabCodedChar[2] & 0x03) << 6) | (tabCodedChar[3] & 0x3F);				

				for (i =0; i< nbCharDecoded; i++)
					decodedBuffer[indexDecodedBuffer+i] = tabDecodedChar[i];

				indexDecodedBuffer+=nbCharDecoded;

				if(indexDecodedBuffer > sizeDecodedBuffer)
					goto error;
			}

			if(needToBreak)
				break;
		}

	}	

	*sizeRes = indexDecodedBuffer;
	return RM_OK;
 error:
	return RM_ERROR;
}

RMstatus uuGetDecodedValue(RMascii c, RMint8 *value)
{
	if ((c >= 'A') && (c <= 'Z'))
		*value = (char) (c - 'A');
	else if ((c >= 'a') && (c <= 'z'))
		*value = (char) (c - 'a' + 26);
	else if ((c >= '0') && (c <= '9'))
		*value = (char) (c - '0' + 52);
	else if (c == '+')
		*value = 62;
	else if (c == '=') /*no op -- can't ignore this one*/
		*value = -1;
	else if (c == '/')
		*value = 63;
	else
		return RM_ERROR;

	return RM_OK;
}


static void print_GUID(void *context,
		       unsigned char GUID[16], 
		       unsigned char *Name, 
		       unsigned char *Data, 
		       unsigned long long Partial_Size, 
		       unsigned long long Size) 
{
	RMascii s[256];
	sprintf(s, "%02x%02x%02x%02x-%02x%02x-%02x%02x-%02x%02x-%02x%02x%02x%02x%02x%02x",
		GUID[3], GUID[2], GUID[1], GUID[0],
		  GUID[5], GUID[4],
		  GUID[7], GUID[6],
		  GUID[8], GUID[9],
		  GUID[10], GUID[11], GUID[12], GUID[13], GUID[14], GUID[15]);
	
	RMDBGLOG((ENABLE, "Skipping %llu bytes (%s) (%s)\n", Size, s, Name));
}

static int wm9stream_test(int argc, char *argv[])
{
	void *asf_stream_context = NULL;
	RMbool proxy_initialized = FALSE;
	RMbool proxy_started = FALSE;
	RMbool streaming_initialized = FALSE;
	RMstatus status = RM_OK;
	RMstatus proxy_status;
	RMuint8 *buffer = NULL;
	RMuint32 received[VECTOR_LENGTH];
	RMascii  ch = 0;
	void *SendContext = NULL;
	RMuint32 buffer_size;
	RMint32 drmError;
	RMbool isContentEncrypted;
	RMuint32 cmd;
	struct ASF_Streaming_Context *ctx = NULL;
	RMbool proxy_trickmode = FALSE;
	RMint32 speed = 1;

	// Initialize the RUA proxy
	if ((proxy_status = proxy_init(argc, argv, &SendContext)) != RM_OK) {
		printf("proxy_init failed\n");
		goto finish;
	}

	// The proxy has been initialized
	proxy_initialized = TRUE;

	// Allocate memory for the ASF stream library's context
	if ((asf_stream_context = malloc(ASFGetContextSize())) == NULL) {
		printf("malloc failed\n");
		goto finish;
	}

	memset(asf_stream_context, 0, sizeof(struct ASF_Streaming_Context));

	ctx = (struct ASF_Streaming_Context *)asf_stream_context;
	ctx->sendContext = SendContext;
	ctx->enableCallbacks = TRUE;

	RMDBGLOG((ENABLE, "create demux\n"));

	RMCreateASFVDemux(&(ctx->vASFDemux));

	proxy_set_demux(SendContext, ctx->vASFDemux);

	RMASFVDemuxInit(ctx->vASFDemux, SendContext);
	RMASFVDemuxSetStreamingBehavior(ctx->vASFDemux);

	RMASFVDemuxSetCallbacks(ctx->vASFDemux,
				print_GUID,
				proxy_set_file_properties,
				proxy_print_Stream_Bitrate_Properties,
				proxy_set_video_stream_properties,
				proxy_set_audio_stream_properties,
				proxy_print_Bitrate_Mutual_Exclusion,
				NULL,
				NULL,
				proxy_set_payload_extension,
				NULL,
				proxy_set_languagelistcb,
				NULL,
				proxy_payload,
				NULL,
				NULL,
				proxy_set_inband_AspectRatio);

	drmError = RMASFVDemuxIsContentEncrypted(ctx->vASFDemux, &isContentEncrypted);
	if (drmError != 0) {
		RMDBGLOG((ENABLE, "there was a error during DRM init\n"));
//		bypass_drm = TRUE;
		isContentEncrypted = FALSE;
	}

	if (isContentEncrypted)
		RMDBGLOG((ENABLE, "Encrypted Content!\n"));



	if(proxy_get_buffer(SendContext,
			    &buffer,				      
			    &buffer_size) != RM_OK){
		printf("ERROR getting a buffer\n");
		goto finish;
	}
		
	// Open an ASF streaming session with the video server
	if (ASFOpen(asf_stream_context,
		    argv[1],
		    buffer,
		    buffer_size,
		    &received[0]) != RM_OK) {
		printf("ASFOpen failed\n");
		goto finish;
	}

	// The streaming session has been initialized
	streaming_initialized = TRUE;

	// Demux the ASF header returned by the video server
	RMASFVDemuxDEMUX(ctx->vASFDemux,buffer, received[0]);

	proxy_release_buffer(SendContext,
			     buffer);
	
	// Check proxy to make sure callback initializations were successful
	if ((proxy_status = proxy_get_status(SendContext)) != RM_OK) {
		printf("proxy_get_status failed\n");
		goto finish;
	}

	// Start the RUA decoders
	if ((proxy_status = proxy_start_decoders(SendContext)) != RM_OK) {
		printf("proxy_start_decoders failed\n");
		goto finish;
	}

	// The decoders have started
	proxy_started = TRUE;

	// Instruct the video server to begin streaming
	if (ASFPlay(asf_stream_context, 0, 1) != RM_OK) {
		printf("ASFPlay failed\n");
		goto finish;
	}

	show_keys();

	do {
		RMuint32 readBytes;
		RMuint32 totalBytesRead;

		//proxy_monitor(SendContext);

		if(proxy_get_buffer(SendContext, &buffer, &buffer_size) != RM_OK) {
			printf("ERROR getting a buffer\n");
			goto finish;
		}
		
		cmd = 0;

		RMDBGLOG((LOCALDBG, "dmaBufferSize %lu\n", buffer_size));
		totalBytesRead = 0;
		while (buffer_size > totalBytesRead) {
			RMuint8 *buf = buffer + totalBytesRead;
			RMuint32 size = buffer_size - totalBytesRead;
			readBytes = 0;

			status = RMRTSPReadSockets(ctx->rtspHandle, buf, size, NETWORK_TIMEOUT, &readBytes);

			totalBytesRead += readBytes;

			if (status == RM_TIMEOUT)
				RMDBGLOG((LOCALDBG, "network timeout\n"));
			RMDBGLOG((LOCALDBG, "readBytes %lu, total %lu\n", readBytes, totalBytesRead));

			if((proxy_get_state(SendContext) == ASF_STREAMING_PAUSE) ||
			   (proxy_get_state(SendContext) == ASF_STREAMING_STOP)) {
				if (RMKeyAvailable() > 0) {				
					break;
				}

			}

			if (ctx->eos) {
				RMDBGLOG((ENABLE, "EOS!\n"));
				break;
			}
#define ASF_PACKET_SIZE 1500
			if (buffer_size - totalBytesRead < ASF_PACKET_SIZE)
				break;
		}

		proxy_release_buffer(SendContext, buffer);

		// Process keystroke, if present
		if (RMGetKeyNoWait(&ch)){
			switch (ch) {
			case ' ':
				if (proxy_get_state(SendContext) == ASF_STREAMING_PAUSE)
					break;
				
				printf("pause\n");
				proxy_pause(SendContext);

				// Instruct the video server to pause the stream
				if (ASFPause(asf_stream_context) != RM_OK) {
					printf("ASFPause failed\n");
					goto finish;
				}
				break;
			case 'f':{
				RMuint32 position;
				// Seek code is EXPERIMENTAL!!!

				fprintf(stderr, "Seeking ...\n");
				fprintf(stderr, "Seek time (s) : ");

				RMTermGetUint32(&position);



				// Instruct the video server to pause the stream
				if (ASFPause(asf_stream_context) != RM_OK) {
					printf("ASFPause failed\n");
					goto finish;
				}

				// Flush and reset RUA
				if ((proxy_status = proxy_flush(SendContext)) != RM_OK) {
					printf("proxy_flush failed\n");
					goto finish;
				}

				// Reset the ASF demux because of the
				RMASFVDemuxResetState(ctx->vASFDemux);

				// Instruct the video server to stream from the new position
				if (ASFPlay(asf_stream_context, position*1000, 1) != RM_OK) {
					printf("ASFPlay failed\n");
					goto finish;
				}

				break;
			}
			case 'p':
				if (proxy_get_state(SendContext) == ASF_STREAMING_PLAYING)
						break;
				
				printf("resume\n");
				
				if (proxy_trickmode == TRUE) {

					// Trickmode code is EXPERIMENTAL!!!
					printf("playing 1X\n");
					
					// Instruct the video server to pause the stream
					if (ASFPause(asf_stream_context) != RM_OK) {
						printf("ASFPause failed\n");
						goto finish;
					}
					

					// flush only the video, the audio has nothing in it because we're in trickmodes
					if ((proxy_status = proxy_flush(SendContext)) != RM_OK) {
						printf("proxy_flush failed\n");
						goto finish;
					}
					
					// flush incoming datas
					//RMRTSPFlushSockets(ctx->rtspHandle);
					ASFFlush(asf_stream_context);
					
					proxy_exit_trickmode(SendContext);
					
					// Reset the ASF demux because of
					// trickmode
					RMASFVDemuxResetState(ctx->vASFDemux);
					
					// Instruct the video server to play 1X from the current position
					if (ASFPlay(asf_stream_context, proxy_get_position(SendContext), 1) != RM_OK) {
						printf("ASFPlay failed\n");
						goto finish;
					}

					// RUA is no longer in trickmode
					proxy_trickmode = FALSE;

					// Consume the keystroke
					ch = 0;
				}
				else {
					proxy_resume(SendContext);
					
					// Instruct the video server to resume from paused position
					if (ASFResume(asf_stream_context) != RM_OK) {
						printf("ASFResume failed\n");
						goto finish;
					}
				}

				break;
			case ']':
				if(!proxy_trickmode){
					speed = DEFAULT_SPEED;
				}
				else {
					speed += 1;
					if(speed > MAX_SPEED)
						speed = DEFAULT_SPEED;
				}	
					
				// Trickmode code is EXPERIMENTAL!!!
				printf("fast-forward %ldX\n", speed);

				// Instruct the video server to pause the stream
				if (ASFPause(asf_stream_context) != RM_OK) {
					printf("ASFPause failed\n");
					goto finish;
				}

				// flush incoming datas
				ASFFlush(asf_stream_context);
				
				if (!proxy_trickmode) {
					if ((proxy_status = proxy_flush(SendContext)) != RM_OK) {
						printf("proxy_flush failed\n");
						goto finish;
					}

					proxy_enter_trickmode(SendContext);
				}
				else
					proxy_flush_video(SendContext);


				proxy_set_speed(SendContext, speed);

				// Reset the ASF demux because of trickmode
				RMASFVDemuxResetState(ctx->vASFDemux);

				// Instruct the video server to fast-forward from the current position
				if (ASFPlay(asf_stream_context, proxy_get_position(SendContext), 4) != RM_OK) {
					printf("ASFPlay failed\n");
					goto finish;
				}

				if(!proxy_trickmode)
					// RUA is now in trickmode
					proxy_trickmode = TRUE;

				break;
			case 'q':
				printf("quit!\n");
				goto finish;
			default:
				printf("unknown key '%c'\n", ch);
				break;
			}
		}

	} while ((ch != 'q') &&
		 ((proxy_status = proxy_get_status(SendContext)) == RM_OK) &&
		 ((status == RM_OK) || (status == RM_TIMEOUT)) &&
		 (!ctx->eos));

	// If end of data stream from network, let the proxy finish up before wrapping up
	if (ctx->eos) {
		RMDBGLOG((ENABLE, "wait for EOS\n"));
		if ((proxy_status = proxy_WaitForEOS(SendContext, &cmd)) != RM_OK) {
			printf("proxy_eos failed\n");
		}
	}


finish:
	fflush(stdout);
	fflush(stderr);
	printf("FINISH !!\n");

	// Close the streaming session with the video server
	if (ctx->rtspHandle)
		RMRTSPClose(ctx->rtspHandle);

	// Stop the RUA decoders
	if (proxy_started == TRUE)
		proxy_stop_decoders(SendContext);

	// Terminate the RUA proxy
	if (proxy_initialized == TRUE)
		proxy_terminate(SendContext);


	// Free the ASF stream library's context
	if (asf_stream_context) {
		RMDBGLOG((ENABLE, "free context\n"));
		free(asf_stream_context);
	}


	// If the RUA proxy had a failure, ...
	if (proxy_status != RM_OK) {
		printf("proxy error\n");
		return -3;
	}

	// If ASF streaming had a failure, ...
	if (status == RM_ERROR) {
		printf("streaming error\n");
		return -2;
	}

	// If user wants to quit, ...
	if (ch == 'q') {
		printf("quit\n");
		return -1;
	}

	// If end of stream was reached, ...
	if (status == RM_EOS) {
		printf("end of stream\n");
		return 0;
	}

	return 0;
}

#include <time.h>
#include <sys/time.h>

int main(int argc, char *argv[])
{

/*	char *argv_dolphins_tcp[] = {"wm9stream_test", "rtsp://172.30.1.18/Dolphins.wmv#tcp", "-9", "-c", "wma", "-data", "av", "-afreq", "48000"};
	char *argv_magic_tcp[] = {"wm9stream_test", "rtsp://172.30.1.18/Magic_of_Flight.wmv#tcp", "-9", "-c", "wma", "-data", "av", "-afreq", "48000"};
	char *argv_step_tcp[] = {"wm9stream_test", "rtsp://172.30.1.18/Step_Into_Liquid_Trailer.wmv#tcp", "-9", "-c", "wma", "-data", "av", "-afreq", "48000"};
	char *argv_stormchasers_tcp[] = {"wm9stream_test", "rtsp://172.30.1.18/Stormchasers.wmv#tcp", "-9", "-c", "wma", "-data", "av", "-afreq", "48000"};
	char *argv_limit_tcp[] = {"wm9stream_test", "rtsp://172.30.1.18/To_the_Limit.wmv#tcp", "-9", "-c", "wma", "-data", "av", "-afreq", "48000"};

	if (argc > 1)
*/		


#if INFINITE_LOOP

	RMuint32 i = 0;



	while(1) {
		RMDBGLOG((ENABLE, "\n\n\n\n\n*********************** iteration %lu\n\n\n\n\n\n", i++));
		if (wm9stream_test(argc, argv) == -1)
			break;
	};

#else

	return wm9stream_test(argc, argv);

#endif

/*	else {
		while (1) {
			struct timeval current_time;

			gettimeofday(&current_time, 0);
			printf("%s", ctime(&current_time.tv_sec));

			printf("Dolphins\n");
			if (wm9stream_test(9, argv_dolphins_tcp) == -1)
				return 0;

			printf("Magic_of_Flight\n");
			if (wm9stream_test(9, argv_magic_tcp) == -1)
				return 0;

			printf("Step_Into_Liquid_Trailer\n");
			if (wm9stream_test(9, argv_step_tcp) == -1)
				return 0;

			printf("Stormchasers\n");
			if (wm9stream_test(9, argv_stormchasers_tcp) == -1)
				return 0;

			printf("To_the_Limit\n");
			if (wm9stream_test(9, argv_limit_tcp) == -1)
				return 0;
		}
	}
*/
	return 0;
}







RMstatus start_decoders(void *context, RMuint32 devices, enum DCCVideoPlayCommand mode);
RMstatus stop_decoders(void *context, RMuint32 devices);

#define PROCESS_KEY(getkey);						\
	{								\
		if ((getkey)) {						\
			err = process_key(pSendContext->dcc_info, &(pSendContext->cmd), KEYFLAGS); \
			if (RMFAILED(err)) {				\
				RMDBGLOG((ENABLE, "Error while processing key %d\n", err)); \
				goto exit;				\
			}						\
		}							\
		if (pSendContext->cmd == RM_QUIT) {			\
			RMDBGLOG((ENABLE, "quit\n"));			\
			err = RM_ERROR;					\
			goto exit;					\
		}							\
		if (pSendContext->cmd == RM_STOP) {			\
			RMDBGLOG((ENABLE, "stop\n"));			\
			err = RM_ERROR;					\
			goto exit;					\
		}							\
	}

#define PROCESS_KEY_INCALLBACK();					\
	{								\
	RMstatus err;							\
									\
	err = process_key(pSendContext->dcc_info, &(pSendContext->cmd), KEYFLAGS); \
	if (RMFAILED(err)) {						\
		RMDBGLOG((ENABLE, "Error while processing key %d\n", err)); \
		pSendContext->status = RM_ERROR;			\
		goto return_from_callback;				\
	}								\
	if (pSendContext->cmd == RM_QUIT) {				\
		RMDBGLOG((ENABLE, "quit during callback\n"));		\
		pSendContext->ignoreCallback = TRUE;			\
		pSendContext->status = RM_ERROR;			\
		goto return_from_callback;							\
	} 								\
	if (pSendContext->cmd == RM_STOP) {				\
		RMDBGLOG((ENABLE, "stop during callback\n"));		\
		pSendContext->ignoreCallback = TRUE;			\
		pSendContext->status = RM_ERROR;			\
		goto return_from_callback;							\
	}								\
}

static RMstatus init_private_options(struct priv_cmdline *options)
{
	return RM_OK;
}


static void init_globals(void)
{
	fDecodeWMAPRO = FALSE;
	compressed_audio = FALSE;
	audioStreams = 0;
}

static void show_usage(char *progname)
{
	show_playback_options();
	show_display_options();
	show_video_options();
	show_audio_options();
	
	fprintf(stderr, 
		"\t-bypassDecryption: bypass payload decryption\n"
		"--------------------------------\n"
		"Minimum cmd line: %s rtsp://ip/path_to_file[#udp] (default is TCP)\n"
		"--------------------------------\n", progname);

	exit(1);
}

static void parse_cmdline(int argc, char *argv[])
{
	int i;
	RMstatus err;

	if (argc < 2) 
		show_usage(argv[0]);
	
	i = 1;
	while ((argc > i)) {
		if (argv[i][0] != '-') {
			if (playback_options.filename == NULL) {
				playback_options.filename = argv[i];
				i++;
			}
			else
				show_usage(argv[0]);
		}
		else {
			RMDBGLOG((ENABLE,"command = %s\n", argv[i]));

			if (! strcmp(argv[i], "-bypassDecryption")) {
				i++;
				continue;
			}

			err = parse_playback_cmdline(argc, argv, &i, &playback_options);
			if (err == RM_ERROR)
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_display_cmdline(argc, argv, &i, &display_options);
			if (err == RM_ERROR)
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_video_cmdline(argc, argv, &i, &video_options);
			if (err == RM_ERROR)
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_audio_cmdline(argc, argv, &i, &audio_options);
			if (RMFAILED(err))
				show_usage(argv[0]);
		}
	}

	if (playback_options.filename == NULL)
		show_usage(argv[0]);
}

static RMstatus initVideoDecoder(struct asf_context * context)
{
	if(context->video_decoder_initialized == FALSE) {
		RMstatus err = RM_ERROR;

		RMDBGLOG((ENABLE, "initVideoDecoder\n"));

		switch(context->Compression_ID) {
		case 0x3334504D: // MP43
			err = RUASetProperty(context->pRUA, 
					     context->dcc_info->video_decoder, 
					     RMVideoDecoderPropertyID_DIVX3VSProp, 
					     &(context->divx3_prop), sizeof(context->divx3_prop), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE,"Error setting DIVX3 video info : %d !\n", err));
				return RM_ERROR;
			}
			break;
		case 0x33564D57: //WMV3

			RMDBGLOG((ENABLE, "video prop : seq 0x%08lx, %ld x %ld\n", 
				  context->wmv9_prop.Sequence, 
				  context->wmv9_prop.Image_Width,
			          context->wmv9_prop.Image_Height));
			
			err = RUASetProperty(context->pRUA, 
					     context->dcc_info->video_decoder,
					     RMVideoDecoderPropertyID_WMV9VSProp, 
					     &(context->wmv9_prop), sizeof(context->wmv9_prop), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE,"Error setting WMV9 video info : %d !\n", err));
				return RM_ERROR;
			}
			break;
		case 0x41564D57: //WMVA - Windows Media Video 9 Advanced Profile
		case 0x31435657: //WVC1
			RMDBGLOG((ENABLE, "VC1 Advanced Profile\n"));
			//context->addSeqHeader = TRUE;
			break;
		default:
			fprintf(stderr,"FourCC: 0x%lx not supported !!!\n",context->Compression_ID);
			return RM_ERROR;
		}
		context->video_decoder_initialized = TRUE;
	}
	return RM_OK;
}

static void flush_wmaproFIFO(struct asf_context *pSendContext)
{
	RMDBGLOG((ENABLE, "flushWMAProFIFO\n"));
	RMfifo_flush(pSendContext->wmapro_fifo);
	pSendContext->fDecodingWMAPROPacket = FALSE;

}

static RMstatus initAudioDecoder(struct asf_context * context)
{
	if(context->audio_decoder_initialized == FALSE) {
		RMstatus status = RM_ERROR;
		struct AudioDecoder_WMAParameters_type *wma_params = &(context->wma_params);
		RMuint32 codec;

		RMDBGLOG((ENABLE, "initAudioDecoder\n"));

		codec = (RMuint32)wma_params->VersionNumber;
		switch (codec) {
		case 0x161:
		case 0x7A21:
		case 0x7A22:
			// WMA
			if (fDecodeWMAPRO) {
				fprintf(stderr, ">>> Error: audio specified is WMAPro while detected is WMA\n");
				fDecodeWMAPRO = FALSE;
				return RM_ERROR;
			}
			break;
		case 0x162:
			// WMAPro
			if (!fDecodeWMAPRO) {
				if(audio_options.Spdif != OutputSpdif_NoDecodeCompressed && audio_options.Spdif != OutputSpdif_Compressed)					
				{
				    fprintf(stderr, ">>> Error: audio specified is WMA while detected is WMAPro\n");
					fDecodeWMAPRO = TRUE;				
				}
			}
			break;
		default:
			// wrong codec
			fprintf(stderr, "error wrong codec %lx, disabling audio\n", codec);
			fDecodeWMAPRO = FALSE;
			context->SendAudioData = FALSE;
			return RM_ERROR;
			break;
			
		}

		if (fDecodeWMAPRO) {
			RMstatus err;
			RMMetaWMAParameters temp_wmaparams;
			temp_wmaparams.VersionNumber = wma_params->VersionNumber;
			temp_wmaparams.SamplingFrequency = wma_params->SamplingFrequency;
			temp_wmaparams.NumberOfChannels = wma_params->NumberOfChannels;
			temp_wmaparams.Bitrate = wma_params->Bitrate;
			temp_wmaparams.PacketSize = wma_params->PacketSize;
			temp_wmaparams.EncoderOptions = wma_params->EncoderOptions;
			temp_wmaparams.BitsPerSample = wma_params->BitsPerSample;
			temp_wmaparams.WMAProValidBitsPerSample = wma_params->WMAProValidBitsPerSample;
			temp_wmaparams.WMAProChannelMask = wma_params->WMAProChannelMask;
			temp_wmaparams.WMAProVersionNumber = wma_params->WMAProVersionNumber;
			temp_wmaparams.OutputChannels = wma_params->OutputChannels;
			
			if(context->vDecoder == (void *)NULL) {
				RMDBGLOG((ENABLE,"******** using RMF's WMAPRO decoder ********\n"));
				err = RMCreateWMAProVDecoder(&(context->vDecoder));
				if (err != RM_OK) {
					RMDBGLOG((ENABLE,"error: cant create wmaproVdecoder!\n"));
					return RM_ERROR;
				}
				
				err = RMWMAProVDecoderOpen(context->vDecoder);
				if (err != RM_OK) {
					RMDBGLOG((ENABLE,"error: cant open wmaproVdecoder!\n"));
					return RM_ERROR;
				}
			}

			if (context->vDecoder != (void *)NULL) {
				err = RMWMAProVDecoderInit(context->vDecoder, 
							   wma_params->EncoderOptions,
							   wma_params->PacketSize,
							   &temp_wmaparams);
				if (err != RM_OK)
					RMDBGLOG((ENABLE, "wmaprodecoder init error\n"));
			} else {
				RMDBGLOG((ENABLE, "calling wmaprodecoder init before open!\n"));
			}
			
		}
		
		if(codec != 0x163) {
			status = DCCSetAudioWMAFormat(context->dcc_info->pAudioSource, wma_params); 
			if(status == RM_OK){			
				// wma_params->SamplingFrequency
				RMDBGLOG((ENABLE, " set audio_freq = %ldHz (ignore any audio_freq in cmdline)\n", wma_params->SamplingFrequency));
				status = RUASetProperty(context->dcc_info->pRUA, context->dcc_info->audio_engine, RMAudioEnginePropertyID_SampleFrequency,
							&wma_params->SamplingFrequency, sizeof(wma_params->SamplingFrequency), 0);
				audio_options.SampleRate = wma_params->SamplingFrequency;
				apply_dvi_hdmi_audio_options(context->dcc_info, &audio_options, wma_params->NumberOfChannels, TRUE, TRUE, FALSE);
#ifndef WITH_MONO
				if (! display_options.configure_outports) apply_hdcp(context->dcc_info, &display_options);
#endif
			}
		}

		if(status != RM_OK){			
			RMDBGLOG((ENABLE, "Cannot set audio codec ... disabling audio, error = %d\n", status));
			context->SendAudioData = FALSE;
		}
		
		context->audio_decoder_initialized = TRUE;
		context->audioFirstInit = TRUE;
	}
	return RM_OK;
}


/**
 * Setup the video decoder, according to the given context
 *
 * @param pSendContext - context to use for the setup
 * @return RM_OK on sucess
 */
static RMstatus setup_audio_decoder(struct asf_context *pSendContext)
{
	struct DCCAudioProfile audio_profile;
	struct DCCAudioSource *pAudioSource = NULL;
	struct RUABufferPool *pDMAuncompressed;
	RMstatus err;

	if (pSendContext == NULL)
		return RM_ERROR;

	audio_profile.BitstreamFIFOSize = AUDIO_FIFO_SIZE;
 	audio_profile.XferFIFOCount = AUDIO_XFER_FIFO_COUNT;
	audio_profile.STCID = 0;
	audio_profile.DemuxProgramID = audio_options.AudioEngineID * 2;
	audio_profile.AudioEngineID = audio_options.AudioEngineID;
	audio_profile.AudioDecoderID = audio_options.AudioDecoderID;

	RMDBGLOG((ENABLE, "opening audio source, audioEngineID %lu\n", audio_profile.AudioEngineID));
	err = DCCOpenAudioDecoderSource(pSendContext->dcc_info->pDCC, &audio_profile, &pAudioSource);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot open audio decoder %d\n", err));
		return RM_ERROR;
	}
	pSendContext->dcc_info->pAudioSource = pAudioSource;

	if (fDecodeWMAPRO) {
		RMDBGLOG((ENABLE, "opening WMAPro DMApool\n"));
		err = RUAOpenPool(pSendContext->dcc_info->pRUA, 0, 
				AUDIO_DMA_BUFFER_COUNT, AUDIO_DMA_BUFFER_SIZE_LOG2, 
				RUA_POOL_DIRECTION_SEND, &pDMAuncompressed);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error: cannot open dmapool for compressed audio - %d\n", err));
			return RM_ERROR;
		}
		pSendContext->pDMAuncompressed = pDMAuncompressed;
	}
	
	RMDBGLOG((ENABLE, "get audio decoder info\n"));
	err = DCCGetAudioDecoderSourceInfo(pAudioSource, 
			&(pSendContext->dcc_info->audio_decoder), 
			&(pSendContext->dcc_info->audio_engine), 
			&(pSendContext->dcc_info->audio_timer));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting audio decoder source information %d\n", err));
		return RM_ERROR;
	}

	if (fDecodeWMAPRO) {
		if(pSendContext->vDecoder == (void *)NULL) {
			RMDBGLOG((ENABLE,"******** using RMF's WMAPRO decoder ********\n"));
			err = RMCreateWMAProVDecoder(&(pSendContext->vDecoder));
			if (err != RM_OK) {
				RMDBGLOG((ENABLE,"error: cant create wmaproVdecoder!\n"));
				return RM_ERROR;
			}
			
			err = RMWMAProVDecoderOpen(pSendContext->vDecoder);
			if (err != RM_OK) {
				RMDBGLOG((ENABLE,"error: cant open wmaproVdecoder!\n"));
				return RM_ERROR;
			}
		}
	}

	return RM_OK;
}

/**
 * Setup the video decoder, according to the given context
 *
 * @param pSendContext - context to use for the setup
 * @return RM_OK on sucess
 */
static RMstatus setup_video_decoder(struct asf_context *pSendContext)
{
	
	struct DCCVideoSource *pVideoSource = NULL;
	RMuint32 surfaceID;
	RMstatus err;
	
	if (pSendContext == NULL)
		return RM_ERROR;

#if 1
	{
		struct DCCXVideoProfile video_profile;
		enum EMhwlibVideoCodec vcodec;

		RMDBGLOG((ENABLE, "*** setup_video_decoder ***\n"));
		video_profile.ProtectedFlags = 0;
		video_profile.BitstreamFIFOSize = VIDEO_FIFO_SIZE;
		video_profile.XferFIFOCount = VIDEO_XFER_FIFO_COUNT;
		RMDBGLOG((ENABLE, "bitstream fifo %ld, count %ld\n", video_profile.BitstreamFIFOSize, video_profile.XferFIFOCount));
		video_profile.MpegEngineID = video_options.MpegEngineID;
		video_profile.VideoDecoderID = video_options.VideoDecoderID;
		video_profile.PtsFIFOCount = 180;
		video_profile.InbandFIFOCount = 16;
		video_profile.XtaskInbandFIFOCount = 0;
		video_profile.SPUBitstreamFIFOSize = 0;
		video_profile.SPUXferFIFOCount = 0;
		video_profile.STCID = 0;
	
		/* set codec based on command line options either "-pv" or "-vcodec" */
		if (video_options.vcodec_max_width) {
			video_profile.Codec = video_options.vcodec;
			video_profile.Profile = video_options.vcodec_profile;
			video_profile.Level = video_options.vcodec_level;
			video_profile.MaxWidth = video_options.vcodec_max_width;
			video_profile.MaxHeight = video_options.vcodec_max_height;
		}
		else {
			err = video_profile_to_codec(video_options.Codec, &video_profile.Codec,
						     &video_profile.Profile, &video_profile.Level, &video_profile.ExtraPictureBufferCount,
						     &video_profile.MaxWidth, &video_profile.MaxHeight);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Unknown video decoder codec \n"));
				return RM_ERROR;
			}
		}
		/* set the extra pictures after the profile to codec conversion */
		video_profile.ExtraPictureBufferCount = video_options.vcodec_extra_pictures;

		err = DCCXOpenVideoDecoderSource(pSendContext->dcc_info->pDCC, &video_profile, &pVideoSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot open video decoder %d\n", err));
			return RM_ERROR;
		}
		
		vcodec = video_profile.Codec;
		err = DCCXSetVideoDecoderSourceCodec(pVideoSource, vcodec);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set video decoder codec %d\n", err));
			return RM_ERROR;
		}
	}

#else
	{
		struct DCCVideoProfile video_profile;

		video_profile.MPEGProfile = video_options.MPEGProfile;
		printf("video profile = %d\n", video_profile.MPEGProfile);
		video_profile.BitstreamFIFOSize = VIDEO_FIFO_SIZE;
		video_profile.XferFIFOCount = VIDEO_XFER_FIFO_COUNT;
		video_profile.DemuxProgramID = 0;
		video_profile.SPUBitstreamFIFOSize = 0;
		video_profile.SPUXferFIFOCount = 0;
		
		video_profile.MpegEngineID = video_options.MpegEngineID;
		video_profile.VideoDecoderID = video_options.VideoDecoderID;
		
		video_profile.STCID = 0;
		
		RMDBGLOG((ENABLE, "opening video source\n"));
		err = DCCOpenVideoDecoderSource(pSendContext->dcc_info->pDCC, &video_profile, &pVideoSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot open video decoder %d\n", err));
			return RM_ERROR;
		}
		
		RMDBGLOG((ENABLE, "set video codec\n"));
		err = DCCSetVideoDecoderSourceCodec(pVideoSource, video_options.Codec);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set video decoder codec %d\n", err));
			return RM_ERROR;
		}
	}
	

#endif

	pSendContext->dcc_info->pVideoSource = pVideoSource;

	RMDBGLOG((ENABLE, "get scaler module\n"));
	err = DCCGetScalerModuleID(pSendContext->dcc_info->pDCC, DCCRoute_Main, DCCSurface_Video, pSendContext->videoscaler_id, &surfaceID);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get surface to display video source %d\n", err));
		return RM_ERROR;
	}
	pSendContext->dcc_info->SurfaceID = surfaceID;

	RMDBGLOG((ENABLE, "set surface\n"));
	err = DCCSetSurfaceSource(pSendContext->dcc_info->pDCC, surfaceID, pVideoSource);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set the surface source %d\n", err));
		return RM_ERROR;
	}

	RMDBGLOG((ENABLE, "get video decoder info\n"));
	err = DCCGetVideoDecoderSourceInfo(pVideoSource, 
			&(pSendContext->dcc_info->video_decoder), 
			&(pSendContext->dcc_info->spu_decoder), 
			&(pSendContext->dcc_info->video_timer));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting video decoder source information %d\n", err));
		return RM_ERROR;
	}

	set_default_out_window(&(pSendContext->dcc_info->disp_info->out_window));
	set_default_out_window(&(pSendContext->dcc_info->disp_info->osd_window[0]));
	set_default_out_window(&(pSendContext->dcc_info->disp_info->osd_window[1]));
	pSendContext->dcc_info->disp_info->active_window = &(pSendContext->dcc_info->disp_info->out_window);
	pSendContext->dcc_info->disp_info->video_enable = TRUE;

	display_options.dh_info = &dh_info;
	RMDBGLOG((ENABLE, "apply display options\n"));
	err = apply_display_options(pSendContext->dcc_info, &display_options);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set display opions %d\n", err));
		return RM_ERROR;
	}

	// apply the fixed vop rate if required
	RMDBGLOG((ENABLE, "apply video decoder options\n"));
	err = apply_video_decoder_options(pSendContext->dcc_info, &video_options);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error applying video_decoder_options %d\n", err));
		return RM_ERROR;
	}

	/* check for a scheduled aspect ratio change */
	if (pSendContext->setAspectRatio) {
		err = RUASetProperty(pSendContext->pRUA, pSendContext->dcc_info->video_decoder, 
				RMVideoDecoderPropertyID_InbandSurfaceAspectRatio, 
				&(pSendContext->InBandAspectRatioParams), 
				sizeof(struct SurfaceAspectRatio_type), 0);
		if (err != RM_OK) {
			RMDBGLOG((ENABLE, "error setting scheduled aspect ratio\n"));
			return RM_ERROR;
		}
		RMDBGLOG((ENABLE, ">>> scheduled aspect ratio set, ratio %lu:%lu\n", 
			  pSendContext->InBandAspectRatioParams.ar.X,
			  pSendContext->InBandAspectRatioParams.ar.Y));
	}


	return RM_OK;
}

static RMuint32 ResyncAudio(struct asf_context *pSendContext, struct emhwlib_info *pInfo)
{
	RMuint64 CurrentSTC;
	RMuint32 CutSTC;	
	RMuint32 Presentation_Time;


	if (pInfo->ValidFields & TIME_STAMP_INFO)
		Presentation_Time = pInfo->TimeStamp;
	else
		return 0;

	if (!pSendContext->FirstSystemTimeStamp) {
		//get the time in 1000th units because presentation time from ASF is always in 1/1000
		DCCSTCGetTime(pSendContext->dcc_info->pStcSource, &CurrentSTC, 1000);
		CutSTC = CurrentSTC & 0xffffffff;
		if( (RMint32)((Presentation_Time - CutSTC) + (pSendContext->audio_vop_tir*pSendContext->bufferization_duration)) <= 0) {

			RMDBGLOG((ENABLE, "Current STC = %lld PTS=%lu skipping to resync, offset : %lu\n", CurrentSTC, Presentation_Time, pSendContext->audio_vop_tir*pSendContext->bufferization_duration));
			if (fDecodeWMAPRO) {
				RMWMAProVDecoderFlushParser(pSendContext->vDecoder);
				return RM_SKIP_TO_RESYNC;
			}                         
		}
	}
	return 0;
}

/*static RMbool SwitchAudio(struct asf_context *pSendContext, RMuint32 Media_Object_Number)
{
	
		
	RMDBGLOG((ENABLE, "got audio stream change command\n"));

	if ((pSendContext->dcc_info->selectAudioStream > (RMint32)audioStreams) || 
	    (pSendContext->dcc_info->selectAudioStream == 0) ||
	    (audioStreams <= 1) || 
	    (pSendContext->dcc_info->selectAudioStream == (RMint32)pSendContext->audio_stream_index)) {
		RMDBGLOG((ENABLE, "audio stream change ignored (total audioStreams %lu, selected %ld, current %lu)\n", 
			  audioStreams, 
			  pSendContext->dcc_info->selectAudioStream,
			  pSendContext->audio_stream_index));
		return FALSE;
	}

	stop_decoders(pSendContext, RM_DEVICES_AUDIO);
	
	if (fDecodeWMAPRO) {
		if (pSendContext->vDecoder != NULL) {
			RMDBGLOG((ENABLE, "close wmapro decoder\n"));
			RMWMAProVDecoderClose(pSendContext->vDecoder);
			
			RMDBGLOG((ENABLE, "open wmapro decoder\n"));
			RMWMAProVDecoderOpen(pSendContext->vDecoder);
		}
		else
			RMDBGLOG((ENABLE, "no wmapro decoder created!\n"));
	}
	
	pSendContext->audio_decoder_initialized = FALSE;
	pSendContext->prev_audio_media_object_number = Media_Object_Number;
	
	RMDBGLOG((ENABLE, "total audio streams %lu\n", audioStreams));
	if (pSendContext->dcc_info->selectAudioStream == -1) {
		RMuint32 i;		

		
		for (i = 0; i < audioStreams ; i++) {
			if (audioStreamTable[i] != pSendContext->audio_stream_index)
				break;
		}
		RMDBGLOG((ENABLE, "current stream %lu, switch to %lu\n", pSendContext->audio_stream_index, audioStreamTable[i]));
		pSendContext->audio_stream_index = audioStreamTable[i];
	}
	else {
		RMDBGLOG((ENABLE, "current stream %lu, switch to %lu\n", pSendContext->audio_stream_index, pSendContext->dcc_info->selectAudioStream));
		pSendContext->audio_stream_index = pSendContext->dcc_info->selectAudioStream;
	}
	
	if (pSendContext->dcc_info->state != RM_PLAYING)
		start_decoders(pSendContext, RM_DEVICES_AUDIO, 0);

	return TRUE;
}
*/

void proxy_print_Bitrate_Mutual_Exclusion(void *context,
					  unsigned long mutex_index, 
					  unsigned short Stream_Numbers_Count,
					  unsigned char bitrate_exclusion,
					  unsigned char Stream_Number) 
{
	// one thread only here
}

static void try_decode_wmapro(struct asf_context *pSendContext, RMbool EOS)
{
	/* wmapro decoding and senddata */	
	if (((pSendContext->dcc_info->state != RM_PLAYING) &&
	     (pSendContext->dcc_info->state != RM_PAUSE)) ||
	    (!fDecodeWMAPRO)) {		
		return;
	}

	/* when no video is present we need to block here to avoid filling the wmapro bufer info fifo */
	if (pSendContext->VideoByteCounter == 0)
			EOS = TRUE;

	do 
	{
		RMuint32 rd1, rd2;
		RMuint32 size1, size2;
		RMstatus status;

		if(pSendContext->fDecodingWMAPROPacket == FALSE)
		{					  
		  if(RMfifo_get_readable_size(pSendContext->wmapro_fifo, &rd1, &size1, &rd2) >= sizeof(struct wmapro_info))
		  {		  	  
			RMuint8 *pr1, *pr2;			  
			  
			RMDBGLOG((WMAPRODBG, "To get wmapro_info\n"));
			RMFifoRead((RMuint8 *)pSendContext->pread_wmapro_info, sizeof(struct wmapro_info), &pr1, &size1, &pr2, &size2, (RMuint32)pSendContext->wmapro_fifo);		
			RMDBGLOG((WMAPRODBG, "reading wmapro audio from fifo %d, MON %d, %ld bytes, pts %llu\n",
					  (int)pSendContext->pread_wmapro_info->Stream_Number,
					  (int)pSendContext->pread_wmapro_info->Media_Object_Number,
					  pSendContext->pread_wmapro_info->size,
					  pSendContext->pread_wmapro_info->Info.TimeStamp));


			RMDBGLOG((WMAPRODBG, "To get wmapro_data\n"));			
			if(RMfifo_get_readable_size(pSendContext->wmapro_fifo, &rd1, &size1, &rd2) < pSendContext->pread_wmapro_info->size
			 ||pSendContext->pread_wmapro_info->size > TMP_WMAPRO_BUFFER_SIZE)
			   goto wmapro_fifo_error;
			
			RMFifoRead(pSendContext->tmp_wmapro_buf, pSendContext->pread_wmapro_info->size, &pr1, &size1, &pr2, &size2, (RMuint32)pSendContext->wmapro_fifo);			
			RMDBGLOG((WMAPRODBG, "Reset WMAPRO decoder with buffer(%p) size(%lu)\n", pSendContext->tmp_wmapro_buf, pSendContext->pread_wmapro_info->size));
			
			RMDBGLOG((WMAPRODBG, "To ResyncAudio wmapro\n"));			
#if 1
			if (ResyncAudio(pSendContext, &(pSendContext->pread_wmapro_info->Info)) == RM_SKIP_TO_RESYNC) {
				pSendContext->fDecodingWMAPROPacket = FALSE;
				continue;
			}
#endif

			RMDBGLOG((WMAPRODBG, "To reset wmapro parser\n"));			

			status = RMWMAProVDecoderResetParser(pSendContext->vDecoder, pSendContext->tmp_wmapro_buf, pSendContext->pread_wmapro_info->size);
			if (status != RM_OK) {
				RMDBGLOG((WMAPRODBG, "Cannot reset wmapro parser\n"));
				continue;
			}
			
			pSendContext->packet_counter ++;
			pSendContext->fDecodingWMAPROPacket = TRUE;

			RMDBGLOG((WMAPRODBG, ">>>>>>>>>fSameWMAPROPacket == FALSE, Packet No.#%d\n", pSendContext->packet_counter));			  
		  }
		  else
		  {
			RMDBGLOG((WMAPRODBG, "Insufficient data in wmapro FIFO\n"));			  
			return;
		  }
		}

		while (pSendContext->fDecodingWMAPROPacket) {

				RMstatus status;
				RMuint32 size_audio, size_info;	
				RMuint8 *pFrameBuffer;
				RMuint8 *buf_audio;
				struct emhwlib_info *pInfo;

 			    if (pSendContext->UncompressedBuffer != NULL) {
					RUAReleaseBuffer(pSendContext->pDMAuncompressed, pSendContext->UncompressedBuffer);
					pSendContext->UncompressedBuffer = NULL;
				}

				if (EOS) {
					while (1) {
						if (RUAGetBuffer(pSendContext->pDMAuncompressed, &pSendContext->UncompressedBuffer, GETBUFFER_TIMEOUT_US) == RM_OK)
							break;
					}
				}
				else {
					if (RUAGetBuffer(pSendContext->pDMAuncompressed, &pSendContext->UncompressedBuffer, 0) != RM_OK) {
						RMDBGLOG((WMAPRODBG, "Cannot get buffer\n"));
						return;
					}
				}

				
				status = RMWMAProVDecoderGetFrame(pSendContext->vDecoder, (void **)&pFrameBuffer);
					
				if (status == RM_WMAPRO_SKIPFRAME) {						
					RMDBGLOG((WMAPRODBG, "SKIP FRAME\n"));
					continue;
				}
				else if (status != RM_OK) {
					RMDBGLOG((WMAPRODBG, "Error get frame\n"));
					break;
				}
							
				buf_audio = pSendContext->UncompressedBuffer;

				status = RMWMAProVDecoderDecode(pSendContext->vDecoder, pFrameBuffer, buf_audio, &size_audio);				
				RMDBGLOG((WMAPRODBG, "size_audio = %d on buffer %p\n", size_audio, buf_audio));
			
				if (size_audio > (1<<AUDIO_DMA_BUFFER_SIZE_LOG2)) {
					RMDBGLOG((ENABLE, "size_audio (%ld) > dmabuffersize (%ld), disabling audio\n", size_audio, (1<<AUDIO_DMA_BUFFER_SIZE_LOG2)));
					pSendContext->SendAudioData = FALSE;
					break;
				}
			
				if(size_audio > 0) {
				
			  		RMbool broken_frame;

					pInfo = NULL;
					size_info = 0;
				
#ifdef _DUMP_INT_FILE_								
					fwrite(buf_audio, 1, size_audio, pSendContext->intfile);
#endif				

					/* need to be the first test to do it every time */
					broken_frame = RMWMAProVDecodeGetFlag(pSendContext->vDecoder, INQUIRE_BROKEN_FRAME_FLAG);
					RMDBGLOG((WMAPRODBG, "broken %lu, sendpts %lu, audiopts %lu\n", broken_frame, pSendContext->pread_wmapro_info->fSendPTS, pSendContext->SendAudioPts));
					if (pSendContext->pread_wmapro_info->fSendPTS && pSendContext->SendAudioPts && !broken_frame) {
						pInfo = &(pSendContext->pread_wmapro_info->Info);
				
						size_info = sizeof(struct emhwlib_info);
						pSendContext->pread_wmapro_info->fSendPTS = 0;
					}
			
				if ((pInfo != NULL) && (pInfo->ValidFields != 0))
					RMDBGLOG((WMAPRODBG, "sending wmapro audio %d, MON %d, %ld bytes, pts %llu = 0x%09lx\n",
						  (int)pSendContext->pread_wmapro_info->Stream_Number,
						  (int)pSendContext->pread_wmapro_info->Media_Object_Number,
						  size_audio,
						  pInfo == NULL ? 0:pInfo->TimeStamp,
						  pInfo == NULL ? 0:pInfo->TimeStamp));
				
				if (RUASendData(pSendContext->pRUA, pSendContext->dcc_info->audio_decoder, pSendContext->pDMAuncompressed, buf_audio, size_audio, pInfo, size_info) != RM_OK) {
					RMDBGLOG((ENABLE, "WmaPro Xfer task too small\n"));
					break;
				}

				pSendContext->AudioByteCounter += size_audio;
			}
			else
			{
				RMDBGLOG((ENABLE, "Flush WmaPro decoder due to error\n"));
				RMWMAProVDecoderFlushParser(pSendContext->vDecoder);
				pSendContext->fDecodingWMAPROPacket = FALSE;
				break;
			}
			
			if (status != RM_OK)
				break;
		}
		
	
		pSendContext->fDecodingWMAPROPacket = FALSE;
	}while(1);
	
	// This is a normal return
	return;

	// handle the fifo error (haven't been seen yet)
wmapro_fifo_error:
	RMDBGLOG((ENABLE, "Flush WmaPro FIFO due to error in fifo, !!!urgent!!!\n"));
	flush_wmaproFIFO(pSendContext);
}

void proxy_set_bufferization_time(void *context, RMuint32 t)
{
	struct asf_context *pSendContext = (struct asf_context *) context;

	pSendContext->bufferization_duration = t;

	DCCSTCSetVideoOffset(pSendContext->dcc_info->pStcSource, -(pSendContext->video_vop_tir*pSendContext->bufferization_duration), pSendContext->video_vop_tir);
	DCCSTCSetAudioOffset(pSendContext->dcc_info->pStcSource, -(pSendContext->audio_vop_tir*pSendContext->bufferization_duration), pSendContext->audio_vop_tir);

	RMDBGLOG((ENABLE, "Setting bufferization time to : %lu secs\n", pSendContext->bufferization_duration));
}

void proxy_monitor(void *context)
{
	struct asf_context *pSendContext = (struct asf_context *) context;
	static struct timeval lasttime;
	static int firstTime = TRUE;
	struct timeval now;
	if(firstTime){
		gettimeofday(&lasttime, NULL);
		firstTime = FALSE;
	}
 	
	gettimeofday(&now,NULL);
	if(now.tv_sec > lasttime.tv_sec){
		RMuint64 ptime;
		GET_XFER_FIFO_INFO(pSendContext->dcc_info->pRUA, pSendContext->dcc_info->audio_decoder, "Audio XFER fifo");
		GET_DATA_FIFO_INFO(pSendContext->dcc_info->pRUA, pSendContext->dcc_info->audio_decoder, "Audio Bitstream fifo");
		GET_XFER_FIFO_INFO(pSendContext->dcc_info->pRUA, pSendContext->dcc_info->video_decoder, "Video XFER fifo");
		GET_DATA_FIFO_INFO(pSendContext->dcc_info->pRUA, pSendContext->dcc_info->video_decoder, "Video Bitstream fifo");
		lasttime = now;
		DCCSTCGetTime(pSendContext->dcc_info->pStcSource, &ptime, 90000);
		printf("ptime = %d sec (bufferization time = %lu)\n", (int) ptime / 90000, pSendContext->bufferization_duration);
	}        
}

RMstatus proxy_get_buffer(void *context,
			  RMuint8 **buffer,
			  RMuint32 *buffer_size)
{
	struct asf_context *pSendContext = (struct asf_context *) context;
	RMstatus err;

	while((err = RUAGetBuffer(pSendContext->pDMA, buffer, GETBUFFER_TIMEOUT_US)) != RM_OK) {
		PROCESS_KEY(TRUE);
		update_hdmi(pSendContext->dcc_info, &display_options, &audio_options);
		try_decode_wmapro(pSendContext, FALSE);
		printf("Waiting for a buffer ::::::::::::::::::::::::::\n");
	}
	*buffer_size =  (1 << ASF_DMA_BUFFER_SIZE_LOG2);
 exit:
	pSendContext->status = err;
	return err;
}

void proxy_release_buffer(void *context,
			  RMuint8 *buffer)
{
	struct asf_context *pSendContext = (struct asf_context *) context;
	if (buffer!=NULL) 
		RUAReleaseBuffer(pSendContext->pDMA, buffer);

	try_decode_wmapro(pSendContext, FALSE);
	pSendContext->status = RM_OK;
}

void proxy_set_languagelistcb(void *context,
			      RMuint16 Language_ID_Records_Count,
			      RMuint16 Language_ID_Records_Index,
			      RMuint8 *Language_ID,
			      RMuint8 Partial_Language_ID_Length,
			      RMuint8 Language_ID_Length) 
{	
	struct asf_context *pSendContext = (struct asf_context *) context;

	RMDBGLOG((ENABLE, "languagelist called\n"));

	if( (Language_ID_Length != 0) && (Partial_Language_ID_Length == Language_ID_Length) ) {
#ifdef _DEBUG
		RMuint32 i;
#endif
		pSendContext->lang[Language_ID_Records_Index].languageIDCount = Language_ID_Records_Count;
		pSendContext->lang[Language_ID_Records_Index].languageIDIndex = Language_ID_Records_Index;

		if (pSendContext->lang[Language_ID_Records_Index].languageID)
			RMFree(pSendContext->lang[Language_ID_Records_Index].languageID);

		pSendContext->lang[Language_ID_Records_Index].languageID = (RMnonAscii *) RMMalloc(Language_ID_Length*sizeof(RMuint8));

		RMMemcpy(pSendContext->lang[Language_ID_Records_Index].languageID, Language_ID, Language_ID_Length);

		pSendContext->lang[Language_ID_Records_Index].languageIDLength = Language_ID_Length;

		RMDBGLOG((ENABLE,"Language %hu/%hu ->",  Language_ID_Records_Index, pSendContext->lang[Language_ID_Records_Index].languageIDCount));
#ifdef _DEBUG
		for(i=0;i<Language_ID_Length;i++)
			fprintf(stderr, "%c", (RMuint8)pSendContext->lang[Language_ID_Records_Index].languageID[i]);
		fprintf(stderr, "\n");
#endif
		pSendContext->langPropSET = TRUE;
	}
}

void proxy_set_inband_AspectRatio(void *context,
				  RMuint16 Stream_Num,
				  RMuint32 aspectRatioX,
				  RMuint32 aspectRatioY)
{
	struct asf_context *pSendContext = (struct asf_context *) context;
       	struct SurfaceAspectRatio_type param;
	RMstatus err;

	if (Stream_Num != pSendContext->video_stream_index)
		return;

	if ((aspectRatioX == pSendContext->inband_aspect_ratio_x) && (aspectRatioY == pSendContext->inband_aspect_ratio_y))
		return;

	RMDBGLOG((ENABLE,"Set inband aspect ratio to %lu:%lu\n", aspectRatioX, aspectRatioY));

	param.type = EMhwlibAspectRatio_Pixel;
	param.ar.X = aspectRatioX;
	param.ar.Y = aspectRatioY;
	
	if (pSendContext->pRUA) {
		err = RUASetProperty(pSendContext->pRUA, pSendContext->dcc_info->video_decoder, RMVideoDecoderPropertyID_InbandSurfaceAspectRatio, &param, sizeof(param), 0);
		if (err != RM_OK) {
			RMDBGLOG((ENABLE, "Cannot set video inband aspect ratio\n"));
		}
		else {
			pSendContext->setAspectRatio = FALSE;
		}
	}
	else {
		/* if RUA hasnt been yet open, we've to schedule the command for later */
		pSendContext->setAspectRatio = TRUE;
		pSendContext->InBandAspectRatioParams = param;
		RMDBGLOG((ENABLE, "rua not open yet, scheduling aspect ratio change for later\n"));
	}
	pSendContext->inband_aspect_ratio_x = aspectRatioX;
	pSendContext->inband_aspect_ratio_y = aspectRatioY;
}

void proxy_set_payload_extension (void *context,
				  unsigned short Stream_Number,
				  unsigned long Media_Object_Number,
				  unsigned char Media_Object_Number_valid,
				  unsigned short Payload_Extension_System_ID,
				  unsigned char *Payload_Extension_System_Data,
				  unsigned short Partial_Payload_Extension_System_Data_Size,
				  unsigned short Payload_Extension_System_Data_Size,
				  unsigned short bytes_left) 
{
	struct asf_context *pSendContext = (struct asf_context *) context;

	if(pSendContext->video_stream_index == Stream_Number) {
		if(
		   (Payload_Extension_System_ID & RMASFPayloadExtensionSystemPixelAspectRatio)
		   &&
		   (Payload_Extension_System_Data_Size == 2)
		   ) {
			/* data might be fragmented (split on 2 buffers) */
			if(Partial_Payload_Extension_System_Data_Size == 1) {
				if(bytes_left == 1) 
					pSendContext->save_inband_aspect_ratio_y = Payload_Extension_System_Data[0];
				else 
					proxy_set_inband_AspectRatio(context, 
							   Stream_Number,
							   Payload_Extension_System_Data[0],
							   pSendContext->save_inband_aspect_ratio_y);
			} else { /* Partial_Payload_Extension_System_Data_Size will never be 0 */
				proxy_set_inband_AspectRatio(context, 
						   Stream_Number,
						   Payload_Extension_System_Data[1],
						   Payload_Extension_System_Data[0]);
			}
		}
	}
}

void proxy_print_Stream_Bitrate_Properties(void *context,
					   unsigned char Stream_Number, 
					   unsigned long Average_Bitrate) 
{
	//audioStreamTable[audioStreams++] = Stream_Number;
	RMDBGLOG((ENABLE, "    Stream #%hu: %lu bits/second\n", Stream_Number, Average_Bitrate));
}

void proxy_set_file_properties( void *context,
				unsigned long long File_Size,
				unsigned long long Creation_Date,
				unsigned long long Data_Packets_Count,
				unsigned long long Play_Duration,
				unsigned long long Send_Duration,
				unsigned long long Preroll,
				unsigned long Minimum_Data_Packet_Size,
				unsigned long Maximum_Data_Packet_Size,
				unsigned long Maximum_Bitrate,
				unsigned char Broadcast,
				unsigned char Seekable) 
{	

	struct asf_context *pSendContext = (struct asf_context *) context;

	RMDBGLOG((ENABLE, "    Send Duration = %llu ms\n", Send_Duration / 10000));
	RMDBGLOG((ENABLE, "    Preroll = %llu ms\n", Preroll));

	RMDBGLOG((ENABLE, "    Play Duration = %llu ms\n", (Play_Duration - Preroll) / 10000));

	RMDBGLOG((ENABLE, "    Maximum_Bitrate = %lu bits/s\n", Maximum_Bitrate));
	RMDBGLOG((ENABLE, "    Minimum_Data_Packet_Size = %lu, Maximum_Data_Packet_Size = %lu\n",
		  Minimum_Data_Packet_Size, Maximum_Data_Packet_Size));

	pSendContext->Preroll = Preroll;
	pSendContext->PrerollSET = FALSE;
	pSendContext->Duration = (Play_Duration - Preroll) / 10000;

	pSendContext->filePropSET = TRUE;
	
}

void proxy_set_video_stream_properties(void *context,
				       unsigned char Stream_Number, unsigned long Compression_ID, 
				       unsigned long Image_Width, unsigned long Image_Height,
				       unsigned char *Codec_Specific_Data, 
				       unsigned long Partial_Codec_Specific_Data_Size, 
				       unsigned long Codec_Specific_Data_Size) 
{
	struct asf_context *pSendContext = (struct asf_context *) context;
#ifdef _DEBUG
	int i, j;
#endif
	RMstatus status;

	RMDBGLOG((ENABLE, "Stream #%hu - Video\n", Stream_Number));

	if (Partial_Codec_Specific_Data_Size) {

		if(pSendContext->Video_Codec_Specific_Data_Received == 0)
			RMDBGLOG((ENABLE, "    Video Codec Specific Data: (%lu bytes, partial size %lu)\n",
				  Codec_Specific_Data_Size,
				  Partial_Codec_Specific_Data_Size));

#ifdef _DEBUG
		for(i = 0; i < (int)Partial_Codec_Specific_Data_Size; i++) {
			for(j = 7; j >= 0; j--)
				fprintf(stderr, "%c", (((*(Codec_Specific_Data + i)) >> j) & 1) + 48);

		}

		fprintf(stderr, "\n");

		for(i = 0; i < (int)Partial_Codec_Specific_Data_Size; i++) {
			fprintf(stderr, "0x%02X ", *(Codec_Specific_Data + i));

		}

#endif

		pSendContext->Video_Codec_Specific_Data_Received += Partial_Codec_Specific_Data_Size;
#ifdef _DEBUG
		if (pSendContext->Video_Codec_Specific_Data_Received == Codec_Specific_Data_Size)
			fprintf(stderr, "\n");
#endif
	}

	if (pSendContext->Video_Codec_Specific_Data_Received == Codec_Specific_Data_Size) {

		pSendContext->video_stream_index = Stream_Number;
		pSendContext->Compression_ID = Compression_ID;
		
		RMDBGLOG((ENABLE, "    Image Width = %lu, Image Height = %lu, Codec = ", Image_Width, Image_Height));
#ifdef _DEBUG
		for(i = 0; i < 4; i++)
			fprintf(stderr, "%c", (char)(Compression_ID >> (i * 8)) & 255);

		fprintf(stderr, " (0x");

		for(i = 0; i < 4; i++)
			fprintf(stderr, "%02x", (char)(Compression_ID >> (i * 8)) & 255);


		fprintf(stderr, ")\n");
#endif

		if(Compression_ID == 0x33564D57) { // WMV3
			int bit_select;

			/* when used in mono, use codec auto detection */
			bit_select = (Codec_Specific_Data[0] >> 6) & 3;
			switch (bit_select) {
			case 0: RMDBGLOG((ENABLE, "    Simple Profile\n")); break; // Supported
			case 1: RMDBGLOG((ENABLE, "    Main Profile\n")); break; // Supported
			case 2: { // Not supported
				RMDBGLOG((ENABLE, "    Complex Profile\n")); 
				fprintf(stderr, " Complex Profile is not supported by this hardware! \n"); 
				pSendContext->unsupported_video = TRUE;
				return;
			}
			case 3: RMDBGLOG((ENABLE, "    Error in PROFILE\n")); break;
			}
			
			bit_select = (Codec_Specific_Data[0] >> 5) & 1;      
			if(bit_select) // All supported
				RMDBGLOG((ENABLE, "    Interlaced mode\n"));
			else
				RMDBGLOG((ENABLE, "    Progressive mode\n"));
			
			bit_select = (Codec_Specific_Data[0] >> 4) & 1;      
			if(bit_select) {
				RMDBGLOG((ENABLE, "    Sprite mode on\n")); // Not supported
				fprintf(stderr, " Sprite mode is not supported by this hardware! \n"); 
				pSendContext->unsupported_video = TRUE;
				return;
			}
			else
				RMDBGLOG((ENABLE, "    Sprite mode off\n"));
			
			bit_select = (Codec_Specific_Data[0] >> 1) & 7;            
			RMDBGLOG((ENABLE, "    Framerate is %0d fps\n", bit_select * 4 + 2));
			
			bit_select = (((Codec_Specific_Data[0] >> 0) & 1) << 4) + ((Codec_Specific_Data[1] >> 4) & 15); 
			if(bit_select == 31) // All supported
				RMDBGLOG((ENABLE, "    Bitrate is > 4064 kbps\n"));
			else
				RMDBGLOG((ENABLE, "    Bitrate is %0d kbps\n", bit_select * 64 + 32));
			
			
			bit_select = (Codec_Specific_Data[1] >> 3) & 1;            
			if(bit_select) {// All supported
					RMDBGLOG((ENABLE, "    Loop filter on\n")); // Supported
					bit_select = (Codec_Specific_Data[0] >> 6) & 3;
					if(bit_select == 0)
						RMDBGLOG((ENABLE, "Loop filter incompatible with simple profile\n"));
			} else
				RMDBGLOG((ENABLE, "    Loop filter off\n"));
			
			bit_select = (Codec_Specific_Data[1] >> 2) & 1;            
			if(bit_select) { // Simple and main, should be 0
				RMDBGLOG((ENABLE, "    XINTRA8 on\n"));  // Not supported
				fprintf(stderr, " XINTRA8 ON is only valid with complex profile and is not supported by this hardware! \n"); 
				pSendContext->unsupported_video = TRUE;
				return;
				bit_select = (Codec_Specific_Data[0] >> 6) & 3;
				if(bit_select != 2)
					RMDBGLOG((ENABLE, "XINTRA8 only present in complex profile\n"));
			} else
				RMDBGLOG((ENABLE, "    XINTRA8 off\n"));
			
			bit_select = (Codec_Specific_Data[1] >> 1) & 1;            
			if(bit_select) { // All supported
				RMDBGLOG((ENABLE, "    Multiresolution on\n"));
				bit_select = (Codec_Specific_Data[0] >> 6) & 3;
				if(bit_select == 0)
					RMDBGLOG((ENABLE, "Multiresolution incompatible with simple profile\n"));
			}
			else
				RMDBGLOG((ENABLE, "    Multiresolution off\n"));
			
			bit_select = (Codec_Specific_Data[1] >> 0) & 1;            
			if(bit_select) // Simple and main should be 1
				RMDBGLOG((ENABLE, "    Fast Transform on\n"));  
			else {
				RMDBGLOG((ENABLE, "    Fast Transform off\n")); // Not supported
				fprintf(stderr, " Fast transform OFF is only valid with complex profile and is not supported by this hardware! \n");
				pSendContext->unsupported_video = TRUE;
				return;
				if(bit_select != 2)
					RMDBGLOG((ENABLE, " IDCT is present\n"));
			}
			
			bit_select = (Codec_Specific_Data[2] >> 7) & 1;            
			if(bit_select)  // All supported
				RMDBGLOG((ENABLE, "    Fast UVMC on\n"));
			else
				RMDBGLOG((ENABLE, "    Fast UVMC off\n"));
			
			bit_select = (Codec_Specific_Data[2] >> 6) & 1;            
			if(bit_select) {
				RMDBGLOG((ENABLE, " Broadcast ON\n")); 
			}
			else
				RMDBGLOG((ENABLE, "    Broadcast off\n"));
			
			bit_select = (Codec_Specific_Data[2] >> 4) & 3;        
			switch(bit_select) { // All supported
			case 0: RMDBGLOG((ENABLE, "    Frame quantization step size\n")); break;
			case 1: 
				{
					RMDBGLOG((ENABLE, "    Macroblock quantization step size\n"));
					bit_select = (Codec_Specific_Data[0] >> 6) & 3;
					if(bit_select == 0)
						RMDBGLOG((ENABLE, "DQUANT incompatible with simple profile\n"));
					break;
				}
			case 2:
				{
					RMDBGLOG((ENABLE, "    Boundary alternate quantization\n"));
					bit_select = (Codec_Specific_Data[0] >> 6) & 3;
					if(bit_select == 0)
						RMDBGLOG((ENABLE, "DQUANT incompatible with simple profile\n"));
					break;
				}
			case 3: RMDBGLOG((ENABLE, "Error in DQUANT\n")); break;
			}
			
			bit_select = (Codec_Specific_Data[2] >> 3) & 1;        
			if(bit_select)
				RMDBGLOG((ENABLE, "    Variable size transform on\n")); // Supported
			else
				RMDBGLOG((ENABLE, "    Variable size transform off\n"));
			
			bit_select = (Codec_Specific_Data[2] >> 2) & 1;        
			if(bit_select)
				RMDBGLOG((ENABLE, "    Transform table switching on\n"));  // Supported
			else
				RMDBGLOG((ENABLE, "    Transform table switching off\n"));
			
			bit_select = (Codec_Specific_Data[2] >> 1) & 1;        
			if(bit_select)
				RMDBGLOG((ENABLE, "    Overlap filter on\n"));  // Supported
			else
				RMDBGLOG((ENABLE, "    Overlap filter off\n"));
			
			bit_select = (Codec_Specific_Data[2] >> 0) & 1;        
			if(bit_select) {
				RMDBGLOG((ENABLE, "    Startcodes present\n")); // Not supported by microcode if 1 - Could be written
				RMDBGLOG((ENABLE, " ***************** WARNING ************************\n"));
				RMDBGLOG((ENABLE, " ***************** WARNING ************************\n"));
				RMDBGLOG((ENABLE, " Start code present not be supported yet! \n")); 
				RMDBGLOG((ENABLE, " ***************** WARNING ************************\n"));
				RMDBGLOG((ENABLE, " ***************** WARNING ************************\n"));
			}
			else
				RMDBGLOG((ENABLE, "    No startcodes\n"));
			
			bit_select = (Codec_Specific_Data[3] >> 7) & 1;        
			if(bit_select)
				RMDBGLOG((ENABLE, "    Preprocessing on\n")); // Supported
			else
				RMDBGLOG((ENABLE, "    Preprocessing off\n"));
			
			bit_select = (Codec_Specific_Data[3] >> 4) & 7; // Supported
			if(bit_select)
				RMDBGLOG((ENABLE, "    %d consecutive B-frames\n", bit_select));
			else
				RMDBGLOG((ENABLE, "    No B-frames\n"));
			
			bit_select = (Codec_Specific_Data[3] >> 2) & 3;
			switch(bit_select) { // All supported
			case 0: RMDBGLOG((ENABLE, "    Quantizer implicitly specified at frame level\n")); break;
			case 1: RMDBGLOG((ENABLE, "    Quantizer explicitly specified at frame level\n")); break;
			case 2: RMDBGLOG((ENABLE, "    5QP deadzone quantizer user for all frames\n")); break;
			case 3: RMDBGLOG((ENABLE, "    3QP deadzone quantizer user for all frames\n")); break;
			}
			
			bit_select = (Codec_Specific_Data[3] >> 1) & 1;        
			if(bit_select) { // Not in spec... Usefull? (Frederic)
				RMDBGLOG((ENABLE, "    Frame interpolation on\n"));
				RMDBGLOG((ENABLE, " ***************** WARNING ************************\n"));
				RMDBGLOG((ENABLE, " ***************** WARNING ************************\n"));
				RMDBGLOG((ENABLE, " Frame interpolation may not be supported! \n")); 
				RMDBGLOG((ENABLE, " ***************** WARNING ************************\n"));
				RMDBGLOG((ENABLE, " ***************** WARNING ************************\n"));
			}
			else
				RMDBGLOG((ENABLE, "    Frame interpolation off\n"));
			
			bit_select = (Codec_Specific_Data[3] >> 0) & 1;        
			if(bit_select)
				RMDBGLOG((ENABLE, "    Release encoder used\n"));
			else {
				RMDBGLOG((ENABLE, "    Beta encoder used\n")); // Not supported
				fprintf(stderr, " This file has been created by a WMV9 BETA encoder! \n"); 
				fprintf(stderr, " This file is not supported due to changes that\n"); 
				fprintf(stderr, " may have occured between this BETA version and the\n"); 
				fprintf(stderr, " final version off Microsoft WMV9 encoder.\n"); 
				pSendContext->unsupported_video = TRUE;
				return;
			}
		} 
		else if(Compression_ID == 0x3334504D) { // MP43
			pSendContext->video_stream_index = Stream_Number;

			pSendContext->divx3_prop.Image_Width = (RMuint16) Image_Width;
			pSendContext->divx3_prop.Image_Height = (RMuint16) Image_Height;

			RMDBGLOG((ENABLE, "    Found old WMV format (DivX3.11): %d x %d\n", 
				  (int) pSendContext->divx3_prop.Image_Width, (int) pSendContext->divx3_prop.Image_Height));
		}
		else if ((Compression_ID == 0x41564D57) || //WMVA - Windows Media Video 9 Advanced Profile
			 (Compression_ID == 0x31435657) ) { // WVC1 

			RMuint8 *pByte;
			int index;

			RMDBGLOG((ENABLE, ">> VC1 Advanced Profile\n"));

			if (Codec_Specific_Data[0] & (1<<5))
				RMDBGLOG((ENABLE, ">> progressive sequence\n"));
			
			if (Codec_Specific_Data[0] & (1<<4))
				RMDBGLOG((ENABLE, ">> single sequence header\n"));
			
			if (Codec_Specific_Data[0] & (1<<3))
				RMDBGLOG((ENABLE, ">> single entry point header\n"));
			
			if (Codec_Specific_Data[0] & (1<<2))
				RMDBGLOG((ENABLE, ">> single slice pictures\n"));
			
			if (Codec_Specific_Data[0] & (1<<1))
				RMDBGLOG((ENABLE, ">> no B frames\n"));


			pSendContext->seqHeader = (RMuint8 *)RMMalloc((Partial_Codec_Specific_Data_Size - 1) * sizeof(RMuint8));
			pSendContext->seqHeaderSize = (Partial_Codec_Specific_Data_Size - 1);
#ifdef _DEBUG
			fprintf(stderr, "VC1 seqHeader size %lu, seqHeader:\n", pSendContext->seqHeaderSize);
#endif
			for(index = 1; index < (int)Partial_Codec_Specific_Data_Size; index++) {
				pByte = (Codec_Specific_Data + index);

#ifdef _DEBUG
				fprintf(stderr, "0x%02X ", *pByte);
#endif
				*(pSendContext->seqHeader + index - 1) = *pByte;

			}
#ifdef _DEBUG
			fprintf(stderr, "\n");
#endif
			parseVC1SeqHeader(pSendContext, pSendContext->seqHeader, pSendContext->seqHeaderSize);

			pSendContext->video_vop_tir = 90000;
			DCCSTCSetTimeResolution(pSendContext->dcc_info->pStcSource, DCC_Video, pSendContext->video_vop_tir);

			pSendContext->isVC1 = TRUE;
			pSendContext->getStartCodeBuffer = TRUE;
			pSendContext->addSeqHeader = TRUE;
			pSendContext->addEntryHeader = TRUE;
			pSendContext->addFrameHeader = TRUE;



		}
		else 
			pSendContext->unsupported_video = TRUE;
		
		if (pSendContext->unsupported_video) {
			pSendContext->SendVideoData = FALSE;
			RMDBGLOG((ENABLE, ">> unsupported video codec, disabling video\n"));
			return;
		}

		if (!pSendContext->SendVideoData) {
			RMDBGLOG((ENABLE, ">>> video stream found, enabling video playback\n"));
			//pSendContext->SendVideoData = TRUE;

			pSendContext->SendVideoData = playback_options.send_video;

		}
	}


	if ((Codec_Specific_Data_Size >= sizeof(RMuint32)) && 
	    (Compression_ID != 0x41564D57) && 
	    (Compression_ID != 0x31435657)) { // only for non VC1 codec
		// hack! communicate this properly... (inband?)
		RMDBGLOG((ENABLE, "    Sequence header 0x%lx\n", RMbeBufToUint32(Codec_Specific_Data)));
		
		pSendContext->wmv9_prop.Sequence = RMbeBufToUint32(Codec_Specific_Data);
		pSendContext->wmv9_prop.Image_Width = Image_Width;
		pSendContext->wmv9_prop.Image_Height = Image_Height;
		pSendContext->wmv9_prop.MB_Width = (Image_Width + 15) / 16;
		pSendContext->wmv9_prop.MB_Height = (Image_Height + 15) / 16;
	}

	pSendContext->VideoStreamFound = TRUE;

	status = setup_video_decoder(pSendContext);
	if (RMFAILED(status)){
		RMDBGLOG((ENABLE,"Error initializing video\n"));
		pSendContext->SendVideoData = FALSE;
	} else {
		pSendContext->SendVideoData = playback_options.send_video;
		if (!(pSendContext->dcc_info->seek_supported))
			/* Seek is not supported, do play now */
			start_decoders(pSendContext, RM_DEVICES_VIDEO, DCCVideoPlayFwd);
	}
}

void proxy_set_audio_stream_properties(void *context,
				       unsigned char Stream_Number, 
				       unsigned short Codec_ID,
				       unsigned short Number_of_Channels, 
				       unsigned long Samples_Per_Second,
				       unsigned long Average_Number_of_Bytes_Per_Second,
				       unsigned short Block_Alignment, 
				       unsigned short Bits_Per_Sample,
				       unsigned char *Codec_Specific_Data, 
				       unsigned long Partial_Codec_Specific_Data_Size, 
				       unsigned long Codec_Specific_Data_Size) 
{
	struct asf_context *pSendContext = (struct asf_context *) context;
	struct AudioDecoder_WMAParameters_type *wma_params = &(pSendContext->wma_params);
	RMstatus status;

	pSendContext->WMAPROBitsPacketLength = 0;
	pSendContext->Audio_Codec_Specific_Data_Received += Partial_Codec_Specific_Data_Size;

	RMDBGLOG((ENABLE,"print_Audio_Stream_Properties %lu, %lu, %lu\n", 
				pSendContext->Audio_Codec_Specific_Data_Received, 
				Partial_Codec_Specific_Data_Size, 
				Codec_Specific_Data_Size));

	if(Partial_Codec_Specific_Data_Size == Codec_Specific_Data_Size)
		pSendContext->Audio_Codec_Specific_Data_Received = Codec_Specific_Data_Size;
	
	if(pSendContext->Audio_Codec_Specific_Data_Received == Codec_Specific_Data_Size) {

		audioStreamTable[audioStreams++] = Stream_Number;

		RMDBGLOG((ENABLE, "Stream #%hu - Audio - \n", Stream_Number));
		RMDBGLOG((ENABLE, "%hu channel(s), %lu samples/second, %hu bits/sample\n",
			  Number_of_Channels, Samples_Per_Second, Bits_Per_Sample));
		RMDBGLOG((ENABLE, "    Bitrate: %lu bit/s, Block size is 0x%04x bytes [0x%05x bits]\n", 
			  Average_Number_of_Bytes_Per_Second * 8, Block_Alignment, Block_Alignment * 8));

		wma_params->VersionNumber = Codec_ID;
		wma_params->SamplingFrequency = Samples_Per_Second;
		wma_params->NumberOfChannels = Number_of_Channels;
		wma_params->Bitrate = Average_Number_of_Bytes_Per_Second * 8;
		wma_params->PacketSize = Block_Alignment * 8;
		wma_params->EncoderOptions = 0;
		wma_params->BitsPerSample = Bits_Per_Sample;
		wma_params->WMAProValidBitsPerSample = Bits_Per_Sample;
		wma_params->WMAProChannelMask = 0;
		wma_params->WMAProVersionNumber = 0;
		

		if (Codec_ID == 0x160) { // WMA Audio Version 1
			RMDBGLOG((ENABLE, "error, codec WMA Audio Version 1 not supported, disable audio\n"));
			pSendContext->SendAudioData = FALSE;
			return;
		}
			

		// Audio Codec Type Specific data in ASF
		if ( (Codec_ID == 0x161) || // WMA Audio Version 2
		     (Codec_ID == 0x7A21) ||
		     (Codec_ID == 0x7A22) ) {
			if (10 == Codec_Specific_Data_Size) { // 4 + 2 + 4
				RMuint32      dwSamplesPerBlock;
				RMuint16      wEncodeOptions;
				RMuint32      dwSuperBlockAlign;
				
				// struct {
				//	RMuint32      dwSamplesPerBlock;
				//	RMuint16      wEncodeOptions;
				//	RMuint32      dwSuperBlockAlign;
				// }

				dwSamplesPerBlock = 
					  (((RMuint32) Codec_Specific_Data[3]) << 24)
					+ (((RMuint32) Codec_Specific_Data[2]) << 16)
					+ (((RMuint32) Codec_Specific_Data[1]) << 8)
					+  ((RMuint32) Codec_Specific_Data[0]);
				wEncodeOptions = 
					+ (((RMuint16) Codec_Specific_Data[5]) << 8)
					+  ((RMuint16) Codec_Specific_Data[4]);
				dwSuperBlockAlign = 
					  (((RMuint32) Codec_Specific_Data[9]) << 24)
					+ (((RMuint32) Codec_Specific_Data[8]) << 16)
					+ (((RMuint32) Codec_Specific_Data[7]) << 8)
					+  ((RMuint32) Codec_Specific_Data[6]);

				RMDBGLOG((ENABLE, 
					"    Audio codec ID: %04x,\n"
					"    Bits per block: 0x%04x\n"
                                        "    Encode option: 0x%04x \n",
					  (int) Codec_ID, (int) dwSamplesPerBlock, (int) wEncodeOptions));

				wma_params->EncoderOptions = wEncodeOptions;

				// channel assign
				wma_params->OutputChannels = audio_options.OutputChannels;
			}
			else {
				RMDBGLOG((ENABLE, "Error: audio specific data has invalid size (%d)\n",
					  (int) Codec_Specific_Data_Size));
			}
		}

		// WMA pro type specific data (untested yet..)
		if (Codec_ID == 0x162 || Codec_ID == 0x163) { // WMA Audio Pro or WMALSL
			RMuint16      wValidBitsPerSample;
			RMuint32      dwChannelMask;
			RMuint16      wEncodeOptions;
			
			// struct {
			//	RMuint16      wValidBitsPerSample;
			//	RMuint32      dwChannelMask;
			//      RMuint32      dwReserved1;
			//      RMuint32      dwReserved2;
			//	RMuint16      wEncodeOptions;
			// }
			
			wValidBitsPerSample = 
				+ (((RMuint16) Codec_Specific_Data[1]) << 8)
				+  ((RMuint16) Codec_Specific_Data[0]);
			dwChannelMask = 
				  (((RMuint32) Codec_Specific_Data[5]) << 24)
				+ (((RMuint32) Codec_Specific_Data[4]) << 16)
				+ (((RMuint32) Codec_Specific_Data[3]) << 8)
				+  ((RMuint32) Codec_Specific_Data[2]);
			wEncodeOptions = 
				+ (((RMuint16) Codec_Specific_Data[15]) << 8)
				+  ((RMuint16) Codec_Specific_Data[14]);
			
			RMDBGLOG((ENABLE, 
				"    Audio codec ID: %04x,\n"
				"    %u valid bits/sample, %08X channel mask\n"
				"    0x%04x encode options\n",
				(int) Codec_ID,
				  (int) wValidBitsPerSample, (int) dwChannelMask, (int) wEncodeOptions));
			
			wma_params->EncoderOptions = wEncodeOptions;
			wma_params->WMAProValidBitsPerSample = wValidBitsPerSample;
			wma_params->WMAProChannelMask = dwChannelMask;

			// channel assign
			wma_params->OutputChannels = audio_options.WmaParams.OutputChannels;
		}
		wma_params->OutputDualMode = audio_options.OutputDualMode;
		wma_params->OutputSpdif = audio_options.Spdif;
	
		pSendContext->audio_stream_index = Stream_Number;
		
		RMDBGLOG((ENABLE, "audioStreamTable[%ld]=%ld\n", audioStreams-1, Stream_Number));		

		if (!pSendContext->SendAudioData) {
			RMDBGLOG((ENABLE, ">>> audio stream found, enabling audio playback\n"));
			pSendContext->AudioStreamFound = TRUE;

			status = setup_audio_decoder(pSendContext);
			if (RMFAILED(status)){
				RMDBGLOG((ENABLE,"Error initializing audio\n"));
				 pSendContext->SendAudioData = FALSE;
			} else {
				pSendContext->SendAudioData = playback_options.send_audio;
				if (!(pSendContext->dcc_info->seek_supported))
					/* Seek is not supported, do play now */
					start_decoders(pSendContext, RM_DEVICES_AUDIO, DCCVideoPlayFwd);
			}
		}
	}
}

void proxy_dummy_drm_init(void *context,
			  RMuint8 *Data,
			  RMuint32 Partial_Data_Size,
			  RMuint32 Data_Size)
{
	return;
}

RMstatus proxy_WaitForEOS(void *context, RMuint32 *pcmd)
{
	RMuint32 eos_bit_field = 0;
	struct asf_context *pSendContext = (struct asf_context *) context;
	
	if(!RMfifo_is_empty(pSendContext->wmapro_fifo)){
		try_decode_wmapro(pSendContext, TRUE);
		RMDBGLOG((ENABLE, "WMAPRO FIFO is not empry before EOS\n"));
	}

	if (pSendContext->VideoByteCounter > 0) {
		// Hack: send last PTS again so that video ucode can get the EOS. The problem is that
		// there is still data in the FIFO and the next inband command is not read by the video microcode.
		struct emhwlib_info Info;
		RMuint8 *buffer;

		while(RUAGetBuffer(pSendContext->pDMA, &buffer, GETBUFFER_TIMEOUT_US) != RM_OK) {
			/* should never happen since we released an empty buffer before getting here */
			RMDBGLOG((ENABLE,"Cannot get buffer for EOS\n"));
		}

		buffer[0] = 0;
		
		Info.ValidFields = TIME_STAMP_INFO;
		Info.TimeStamp = pSendContext->video_last_pts;
		while (RUASendData(pSendContext->pRUA, pSendContext->dcc_info->video_decoder, pSendContext->pDMA, buffer, 1, &Info, sizeof(Info)) != RM_OK) {
			usleep(SENDDATA_TIMEOUT_US); // Should rarelly happen...
		}

		RUAReleaseBuffer(pSendContext->pDMA, buffer);

		eos_bit_field |= EOS_BIT_FIELD_VIDEO;
		RMDBGLOG((ENABLE, "TotalVideoSent %lu bytes, wait for video EOS\n", pSendContext->VideoByteCounter));
	}

	if (pSendContext->AudioByteCounter > 0) {
		eos_bit_field |= EOS_BIT_FIELD_AUDIO;
		RMDBGLOG((ENABLE, "TotalAudioSent %lu bytes, wait for audio EOS\n", pSendContext->AudioByteCounter));
	}
	
	return CommonWaitForEOS(pSendContext->dcc_info, pcmd, eos_bit_field, KEYFLAGS);
}

RMstatus proxy_stop_decoders(void *context)
{
	return stop_decoders(context, RM_DEVICES_AUDIO | RM_DEVICES_VIDEO);
}


RMstatus stop_decoders(void *context, RMuint32 devices)
{
	struct asf_context *pSendContext = (struct asf_context *) context;
	
	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "STOP: stc\n"));
		DCCSTCStop(pSendContext->dcc_info->pStcSource);
	}

	if (devices & RM_DEVICES_VIDEO) {
		if (pSendContext->SendVideoData) {
			RMDBGLOG((ENABLE, "STOP: video decoder\n"));
			pSendContext->status = DCCStopVideoSource(pSendContext->dcc_info->pVideoSource, DCCStopMode_LastFrame);
			if (RMFAILED(pSendContext->status)){
				RMDBGLOG((ENABLE, "Error stopping video source %d\n", pSendContext->status));
				return pSendContext->status;
			}
			pSendContext->video_decoder_initialized = FALSE;
			if (pSendContext->isVC1) {
				RMDBGLOG((ENABLE, "codec: VC1 Advanced Profile, will add seqHeader to bitstream\n"));
				pSendContext->addSeqHeader = TRUE;
			}

		}
	}

	if (devices & RM_DEVICES_AUDIO) {
		if (pSendContext->SendAudioData) {
			RMDBGLOG((ENABLE, "STOP: audio decoder\n"));
			pSendContext->status = DCCStopAudioSource(pSendContext->dcc_info->pAudioSource);
			if (RMFAILED(pSendContext->status)){
				RMDBGLOG((ENABLE,"Error stopping audio source %d\n", pSendContext->status));
				return pSendContext->status;
			}
			if (fDecodeWMAPRO) {
				flush_wmaproFIFO(pSendContext);
			}
			pSendContext->audio_decoder_initialized = FALSE;
		}
	}

	if ((devices & RM_DEVICES_AUDIO) && (devices & RM_DEVICES_VIDEO)) {
		pSendContext->FirstSystemTimeStamp = TRUE;
	}
	pSendContext->dcc_info->state = RM_STOP;
	return pSendContext->status;
}

RMstatus proxy_start_decoders(void *context)
{
	return start_decoders(context, RM_DEVICES_AUDIO | RM_DEVICES_VIDEO, DCCVideoPlayFwd);
}

RMstatus start_decoders(void *context, RMuint32 devices, enum DCCVideoPlayCommand mode)
{
	struct asf_context *pSendContext = (struct asf_context *) context;
	
	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "PLAY: stc\n"));
		DCCSTCPlay(pSendContext->dcc_info->pStcSource);
	}

	if (devices & RM_DEVICES_VIDEO) {
		if (pSendContext->SendVideoData) {
			pSendContext->status = initVideoDecoder(pSendContext);
			if (pSendContext->status != RM_OK) {
				RMDBGLOG((ENABLE, "error during video init\n"));
				return pSendContext->status;
			}

			RMDBGLOG((ENABLE, "PLAY: video decoder %s\n", (mode == DCCVideoPlayIFrame ? "(iframe)":"")));
			pSendContext->status = DCCPlayVideoSource(pSendContext->dcc_info->pVideoSource, mode);
			if (RMFAILED(pSendContext->status)) {
				RMDBGLOG((ENABLE, "Cannot play video decoder %d\n", pSendContext->status));
				return pSendContext->status;
			}
		}
	}

	if (devices & RM_DEVICES_AUDIO) {
		if (pSendContext->SendAudioData) {
			pSendContext->status = initAudioDecoder(pSendContext);
			if (pSendContext->status != RM_OK) {
				RMDBGLOG((ENABLE, "error during audio init\n"));
				return pSendContext->status;
			}

			RMDBGLOG((ENABLE, "PLAY: audio decoder\n"));
			pSendContext->status = DCCPlayAudioSource(pSendContext->dcc_info->pAudioSource);
			if (RMFAILED(pSendContext->status)) {
				RMDBGLOG((ENABLE, "Cannot play video decoder %d\n", pSendContext->status));
				return pSendContext->status;
			}
		}
	}


	pSendContext->dcc_info->state = RM_PLAYING;
	return pSendContext->status;

}

void proxy_set_demux(void *context, void *demux)
{
	struct asf_context *pSendContext = (struct asf_context *) context;
	pSendContext->vASFDemux = (ExternalRMASFDemux)demux;
	pSendContext->status = RM_OK;
}

RMstatus proxy_init(int argc, char *argv[], void **context)
{
	struct RUABufferPool *pDMA = NULL;
	struct asf_context *pSendContext;
	RMstatus err = RM_OK;
	struct stream_options_s stream_options;

	init_globals();

	pSendContext = (struct asf_context*)RMCalloc(1, sizeof(struct asf_context));
	*context = (void*)pSendContext;
	pSendContext->dcc_info = (struct dcc_context *) RMCalloc(1, sizeof(struct dcc_context));

	init_video_options(&video_options);
	init_audio_options(&audio_options);
	init_display_options(&display_options);
	init_playback_options(&playback_options);
	pSendContext->dcc_info->disp_info = &disp_info;
	pSendContext->dcc_info->dh_info = &dh_info;

	parse_cmdline(argc, argv);
	pSendContext->videoscaler_id = display_options.video_scaler;

	if (audio_options.Codec == AudioDecoder_Codec_WMAPRO) {
		RMDBGLOG((ENABLE, "cmdline options, codec = WMAPro, outputchannels %s (0x%lx)\n", 
			  audio_options.WmaParams.OutputChannels == Wmapro_6 ? "6":"2 (downmix if necessary)",
			  audio_options.WmaParams.OutputChannels));
	}
	else {
		RMDBGLOG((ENABLE, "cmdline options, codec = WMA, outputchannels %lu\n", audio_options.OutputChannels));
	}

	//audio_options.WmaParams.OutputChannels = 2;

	// To identify WMAPRO stream
	if(audio_options.Codec == AudioDecoder_Codec_WMAPRO)
	{
		if(audio_options.Spdif != OutputSpdif_NoDecodeCompressed && audio_options.Spdif != OutputSpdif_Compressed)
			fDecodeWMAPRO = TRUE;
	}

	RMDBGLOG((ENABLE, "opening RUA\n"));
	err = RUACreateInstance(&(pSendContext->dcc_info->pRUA), playback_options.chip_num);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error creating RUA instance! %d\n", err));
		goto exit_with_error;
	}

	RMDBGLOG((ENABLE, "opening DCC\n"));
	err = DCCOpen(pSendContext->dcc_info->pRUA, &(pSendContext->dcc_info->pDCC));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error Opening DCC! %d\n", err));
		goto exit_with_error;
	}
	RMDBGLOG((ENABLE, "init microcode\n"));
	err = DCCInitMicroCodeEx(pSendContext->dcc_info->pDCC, display_options.init_mode);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot initialize microcode %d\n", err));
		goto exit_with_error;
	}

//	display_key_usage(KEYFLAGS);

	init_private_options(&priv_opt);
	init_stream_options(&stream_options);

	pSendContext->vDecoder = (ExternWMAProVdecoder)NULL;
	pSendContext->vASFDemux = (ExternalRMASFDemux)NULL;

	pSendContext->video_stream_index = 0;
	//pSendContext->SendVideoData = playback_options.send_video;
	pSendContext->SendVideoPts = playback_options.send_video_pts;

	pSendContext->audio_stream_index = 0;
	//pSendContext->SendAudioData = playback_options.send_audio;
	pSendContext->SendAudioPts = playback_options.send_audio_pts;

	pSendContext->fDecodingWMAPROPacket = FALSE;



	pSendContext->tmp_wmapro_buf_original = (RMuint8 *)RMMalloc(TMP_WMAPRO_BUFFER_SIZE*sizeof(RMuint8));
	if(pSendContext->tmp_wmapro_buf_original == NULL)
	{
		RMDBGLOG((ENABLE,"Can't allocate %ld bytes for pSendContext->tmp_wmapro_buf\n",  TMP_WMAPRO_BUFFER_SIZE));
		goto exit_with_error;
	}	

	wmapro_fifo_buffer_original = (RMuint8 *)RMMalloc(ADDITIONAL_WMAPRO_FIFO_SIZE*sizeof(RMuint8));
	if(wmapro_fifo_buffer_original == NULL)
	{
		RMDBGLOG((ENABLE,"Can't allocate %ld bytes for wmapro_buffer\n",  ADDITIONAL_WMAPRO_FIFO_SIZE));
		goto exit_with_error;
	}	

	pSendContext->pread_wmapro_info_original = (struct wmapro_info *)RMMalloc(sizeof(struct wmapro_info));
	if(pSendContext->pread_wmapro_info_original == NULL)
	{
		RMDBGLOG((ENABLE,"Can't allocate %ld bytes for pread_wmapro_info\n",  sizeof(struct wmapro_info)));
		goto exit_with_error;
	}

	pSendContext->pwrite_wmapro_info_original = (struct wmapro_info *)RMMalloc(sizeof(struct wmapro_info));
	if(pSendContext->pwrite_wmapro_info_original == NULL)
	{
		RMDBGLOG((ENABLE,"Can't allocate %ld bytes for pwrite_wmapro_info\n",  sizeof(struct wmapro_info)));
		goto exit_with_error;
	}	

	RMDBGLOG((ENABLE, "original, 1 @ %p, 2 @ %p, 3 @ %p, 4 @ %p\n",
		  wmapro_fifo_buffer_original,
		  pSendContext->pread_wmapro_info_original,
		  pSendContext->pwrite_wmapro_info_original,
		  pSendContext->tmp_wmapro_buf_original));

#if (EM86XX_MODE == EM86XX_MODEID_STANDALONE)
	pSendContext->tmp_wmapro_buf = (RMuint8 *)((RMuint32)pSendContext->tmp_wmapro_buf_original | 0x80000000);
	wmapro_fifo_buffer = (RMuint8 *)((RMuint32)wmapro_fifo_buffer_original | 0x80000000);
	pSendContext->pread_wmapro_info = (struct wmapro_info *)((RMuint32)pSendContext->pread_wmapro_info_original | 0x80000000);
	pSendContext->pwrite_wmapro_info = (struct wmapro_info *)((RMuint32)pSendContext->pwrite_wmapro_info_original | 0x80000000);
#else
	pSendContext->tmp_wmapro_buf = (RMuint8 *)pSendContext->tmp_wmapro_buf_original;
	wmapro_fifo_buffer = (RMuint8 *)wmapro_fifo_buffer_original;
	pSendContext->pread_wmapro_info = (struct wmapro_info *)pSendContext->pread_wmapro_info_original;
	pSendContext->pwrite_wmapro_info = (struct wmapro_info *)pSendContext->pwrite_wmapro_info_original;
#endif

	pSendContext->wmapro_fifo = RMfifo_open ((RMuint32) wmapro_fifo_buffer, ADDITIONAL_WMAPRO_FIFO_SIZE*sizeof(RMuint8), (RMuint32) &wmapro_fifo);

	RMDBGLOG((ENABLE, "cached, 1 @ %p, 2 @ %p, 3 @ %p, 4 @ %p\n",
		  wmapro_fifo_buffer,
		  pSendContext->pread_wmapro_info,
		  pSendContext->pwrite_wmapro_info,
		  pSendContext->tmp_wmapro_buf));


	


	RMDBGLOG((ENABLE, "apply playback options\n"));
	err = apply_playback_options(pSendContext->dcc_info, &playback_options);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set playback options %d\n", err));
		goto exit_with_error;
	}

	pSendContext->video_vop_tir = 1000;
	pSendContext->audio_vop_tir = 1000;
	pSendContext->unsupported_video = FALSE;
	pSendContext->bufferization_duration = DEFAULT_BUFFERIZATION_DURATION;

	{
		// open first stc module
		struct DCCStcProfile stc_profile;
		stc_profile.STCID = 0;
		stc_profile.master = Master_STC;

		stc_profile.stc_timer_id = 0;
		stc_profile.stc_time_resolution = pSendContext->video_vop_tir;
	
		stc_profile.video_timer_id = 1;
		stc_profile.video_time_resolution = pSendContext->video_vop_tir;
		stc_profile.video_offset = -(pSendContext->video_vop_tir*pSendContext->bufferization_duration);
	
		stc_profile.audio_timer_id = 2;
		stc_profile.audio_time_resolution = pSendContext->audio_vop_tir;
		stc_profile.audio_offset = -(pSendContext->audio_vop_tir*pSendContext->bufferization_duration);
	
		err = DCCSTCOpen(pSendContext->dcc_info->pDCC, &stc_profile, &(pSendContext->dcc_info->pStcSource));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot open stc module %d\n", err));
			goto exit_with_error;
		}
	}
	
	pSendContext->dcc_info->trick_supported = FALSE;
	pSendContext->dcc_info->seek_supported = FALSE;
	pSendContext->dcc_info->iframe_supported = FALSE;
		
	RMDBGLOG((ENABLE, "opening DMApool\n"));
 	err = RUAOpenPool(pSendContext->dcc_info->pRUA, 0, ASF_DMA_BUFFER_COUNT, ASF_DMA_BUFFER_SIZE_LOG2, RUA_POOL_DIRECTION_SEND, &pDMA);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error cannot open dmapool %d\n", err));
		goto exit_with_error;
	}

	pSendContext->dcc_info->chip_num = playback_options.chip_num;
	//pSendContext->dcc_info->pDH = NULL;
	pSendContext->dcc_info->route = DCCRoute_Main;
	pSendContext->dcc_info->state = RM_PLAYING;
	pSendContext->dcc_info->trickmode_id = RM_NO_TRICKMODE;

	pSendContext->pRUA = pSendContext->dcc_info->pRUA;
	pSendContext->pDMA = pDMA;
 	pSendContext->UncompressedBuffer = NULL;

	pSendContext->Presentation_Time = 0;

	RMTermInit(FALSE);    // don't allow ctrl-C and the like ...

	pSendContext->IFrameFSMState = RMasfIFrameFSM_Disabled;

	pSendContext->video_decoder_initialized = FALSE;
	pSendContext->audio_decoder_initialized = FALSE;
	pSendContext->FirstSystemTimeStamp = TRUE;

	pSendContext->cmd = RM_PLAY;
	
	pSendContext->prev_video_media_object_number = 0;
	pSendContext->video_frame_counter = 0;
	pSendContext->VideoByteCounter = 0;
	pSendContext->video_last_pts = 0;
	
	pSendContext->prev_audio_media_object_number = 0;
	pSendContext->audio_frame_counter = 0;
	pSendContext->AudioByteCounter = 0;
	
	pSendContext->start_ms = playback_options.start_ms;
	
	if (pSendContext->dcc_info->state == RM_PLAYING_TRICKMODE) {
		pSendContext->dcc_info->state = RM_PLAYING;
		pSendContext->dcc_info->trickmode_id = RM_NO_TRICKMODE;
	}
	pSendContext->isTrickMode = FALSE;
	pSendContext->isIFrameMode = FALSE;
	pSendContext->firstIFrame = FALSE;

	if (pSendContext->isVC1) {
		RMDBGLOG((ENABLE, "\n\n\n\n\n************* VC1 **************\n\n\n\n\n"));
		pSendContext->getStartCodeBuffer = TRUE;
		pSendContext->addSeqHeader = TRUE;
		pSendContext->addEntryHeader = TRUE;
		pSendContext->addFrameHeader = TRUE;
	}
	
	RMDBGLOG((ENABLE, "Bufferization time = %lu secs\n", pSendContext->bufferization_duration));

	DCCSTCSetTime(pSendContext->dcc_info->pStcSource, 0, pSendContext->video_vop_tir);
	DCCSTCSetSpeed(pSendContext->dcc_info->pStcSource, playback_options.speed_N, playback_options.speed_M);
	
	pSendContext->status = RM_OK;
	return RM_OK;
 exit_with_error:
	proxy_terminate(context);
	pSendContext->status = RM_ERROR;
	return RM_ERROR;
}

RMstatus proxy_terminate(void *context)
{
	struct asf_context *pSendContext = (struct asf_context *) context;
	RMstatus err;

	RMTermExit();

	RMDBGLOG((ENABLE, "closing...\n"));

	{
		RMuint32 i;
		
		for(i=0;i<MAX_NUMBER_OF_AUDIO_STREAMS;i++) {
			if(pSendContext->lang[i].languageID) {
				RMFree(pSendContext->lang[i].languageID);
				pSendContext->lang[i].languageID = (RMnonAscii *) 0;
			}
		}
	}

	if (pSendContext->vDecoder != (void *)NULL) {

		RMDBGLOG((ENABLE, "closing WMAPRO decoder\n"));
		RMWMAProVDecoderClose(pSendContext->vDecoder);
		RMDeleteWMAProVDecoder(pSendContext->vDecoder);
		pSendContext->vDecoder = (void *)NULL;
	}

	if( playback_options.waitexit ) {
		RMascii key;
		RMDBGLOG((ENABLE, "press q key again if you really want to stop & quit\n"));
		while ( !(RMGetKeyNoWait(&key) && ((key == 'q') || (key =='Q'))) );
	}
	
/* 	if (pSendContext->dcc_info->pDH != NULL) { */
/* 		DHDone(pSendContext->dcc_info->pDH); */
/* 		pSendContext->dcc_info->pDH = NULL; */
/* 	} */

	if (pSendContext->dcc_info->pStcSource) {
		RMDBGLOG((ENABLE, "stopping STC\n"));
		DCCSTCStop(pSendContext->dcc_info->pStcSource);
	}

	if (pSendContext->dcc_info->pVideoSource) {
		RMDBGLOG((ENABLE, "stopping video source\n"));
		err = DCCStopVideoSource(pSendContext->dcc_info->pVideoSource, DCCStopMode_LastFrame);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot stop video decoder %d\n", err));
		}
	}
	
	if (pSendContext->dcc_info->pAudioSource) {
		RMDBGLOG((ENABLE, "stopping audio source\n"));
		err = DCCStopAudioSource(pSendContext->dcc_info->pAudioSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot stop audio decoder %d\n", err));
		}
	}
	
	if (pSendContext->pDMA) {
		RMDBGLOG((ENABLE, "closing DMApool\n"));
		err = RUAClosePool(pSendContext->pDMA);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error cannot close dmapool %d\n", err));
		}
	}

	if (pSendContext->pDMAuncompressed) {
		RMDBGLOG((ENABLE, "closing WMAPRO DMA pool\n"));
		err = RUAClosePool(pSendContext->pDMAuncompressed);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error cannot close compressed dmapool %d\n", err));
		}
	}

	if (pSendContext->dcc_info->pVideoSource) {
		RMDBGLOG((ENABLE, "closing video source\n"));
		err = DCCCloseVideoSource(pSendContext->dcc_info->pVideoSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error cannot close video decoder %d\n", err));
		}
	}

	if (pSendContext->dcc_info->pAudioSource) {
		RMDBGLOG((ENABLE, "closing audio source\n"));
		err = DCCCloseAudioSource(pSendContext->dcc_info->pAudioSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error cannot close video decoder %d\n", err));
		}
	}

	if (pSendContext->dcc_info->pStcSource) {
		RMDBGLOG((ENABLE, "closing STC\n"));
		err = DCCSTCClose(pSendContext->dcc_info->pStcSource);
		if (RMFAILED(err)){
			fprintf(stderr, "Error cannot close STC %d\n", err);
		}
	}
	
	if (pSendContext->dcc_info->pDCC) {
		RMDBGLOG((ENABLE, "closing DCC\n"));
		err = DCCClose(pSendContext->dcc_info->pDCC);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot close DCC %d\n", err));
		}
	}

	if (pSendContext->dcc_info->pRUA) {
		RMDBGLOG((ENABLE, "closing RUA\n"));
		err = RUADestroyInstance(pSendContext->dcc_info->pRUA);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot destroy RUA instance %d\n", err));
		}
	}


	RMDBGLOG((ENABLE, "cached, 1 @ %p, 2 @ %p, 3 @ %p, 4 @ %p\n",
		  wmapro_fifo_buffer,
		  pSendContext->pread_wmapro_info,
		  pSendContext->pwrite_wmapro_info,
		  pSendContext->tmp_wmapro_buf));

	RMDBGLOG((ENABLE, "original, 1 @ %p, 2 @ %p, 3 @ %p, 4 @ %p\n",
		  wmapro_fifo_buffer_original,
		  pSendContext->pread_wmapro_info_original,
		  pSendContext->pwrite_wmapro_info_original,
		  pSendContext->tmp_wmapro_buf_original));


	RMfifo_close(pSendContext->wmapro_fifo);

	if (wmapro_fifo_buffer_original != NULL) {
		RMDBGLOG((ENABLE, "free 1\n"));
		RMFree(wmapro_fifo_buffer_original);
	}

	if(pSendContext->pread_wmapro_info_original != NULL) {
		RMDBGLOG((ENABLE, "free 2\n"));
		RMFree(pSendContext->pread_wmapro_info_original);
	}

	if(pSendContext->pwrite_wmapro_info_original != NULL) {
		RMDBGLOG((ENABLE, "free 3\n"));
		RMFree(pSendContext->pwrite_wmapro_info_original);
	}

	if(pSendContext->tmp_wmapro_buf_original != NULL) {
		RMDBGLOG((ENABLE, "free 4\n"));
		RMFree(pSendContext->tmp_wmapro_buf_original);
	}


	if(pSendContext != NULL){
		if(pSendContext->dcc_info != NULL){
			RMFree(pSendContext->dcc_info);
			pSendContext->dcc_info= NULL;
		}
		RMFree(pSendContext);
		pSendContext = NULL;
	}

	RMDBGLOG((ENABLE, "end proxy close\n"));

	return RM_OK;
}

RMstatus proxy_pause(void *context)
{
	struct asf_context *pSendContext = (struct asf_context *) context;

	if (pSendContext->dcc_info->pVideoSource) {
		pSendContext->status = DCCPauseVideoSource(pSendContext->dcc_info->pVideoSource);
		if (RMFAILED(pSendContext->status)) {
			RMDBGLOG((ENABLE, "Error pausing video source %d\n", pSendContext->status));
			return pSendContext->status;
		}
	}
	
	if (pSendContext->dcc_info->pAudioSource) {
		pSendContext->status = DCCPauseAudioSource(pSendContext->dcc_info->pAudioSource);
		if (RMFAILED(pSendContext->status)) {
			RMDBGLOG((ENABLE, "Error pausing audio source %d\n", pSendContext->status));
			return pSendContext->status;
		}
	}
	
	if (pSendContext->dcc_info->pStcSource) {
		DCCSTCStop(pSendContext->dcc_info->pStcSource);
	}

	pSendContext->dcc_info->state = RM_PAUSE;

	return pSendContext->status;
}

RMstatus proxy_resume(void *context)
{
	struct asf_context *pSendContext = (struct asf_context *) context;

	if (pSendContext->dcc_info->pVideoSource) {
		pSendContext->status = DCCPlayVideoSource(pSendContext->dcc_info->pVideoSource, DCCVideoPlayFwd);
		if (RMFAILED(pSendContext->status)) {
			RMDBGLOG((ENABLE, "Error playing video source %d\n", pSendContext->status));
			return pSendContext->status;
		}
	}

	DCCSTCSetSpeed(pSendContext->dcc_info->pStcSource, 1, 1);
	
	if (pSendContext->dcc_info->pAudioSource) {
		pSendContext->status = DCCPlayAudioSource(pSendContext->dcc_info->pAudioSource);
		if (RMFAILED(pSendContext->status)) {
			RMDBGLOG((ENABLE, "Error playing audio source %d\n", pSendContext->status));
			return pSendContext->status;
		}
	}

	if (pSendContext->dcc_info->pStcSource) {
		DCCSTCPlay(pSendContext->dcc_info->pStcSource);
	}

	pSendContext->dcc_info->state = RM_PLAYING;

	return pSendContext->status;
}

RMstatus proxy_flush(void *context)
{
	struct asf_context *pSendContext = (struct asf_context *) context;

	RMDBGLOG((ENABLE, "flushing fifos\n"));
	
	proxy_stop_decoders(context);

	if (fDecodeWMAPRO) {
		RMDBGLOG((ENABLE, "close wmapro decoder\n"));
		RMWMAProVDecoderClose(pSendContext->vDecoder);
		
		RMDBGLOG((ENABLE, "open wmapro decoder\n"));
		RMWMAProVDecoderOpen(pSendContext->vDecoder);
	}

	if(pSendContext->status == RM_OK)
		proxy_start_decoders(context);

	DCCSTCSetVideoOffset(pSendContext->dcc_info->pStcSource, -(pSendContext->video_vop_tir*pSendContext->bufferization_duration), pSendContext->video_vop_tir);
	DCCSTCSetAudioOffset(pSendContext->dcc_info->pStcSource, -(pSendContext->audio_vop_tir*pSendContext->bufferization_duration), pSendContext->audio_vop_tir);

	RMDBGLOG((ENABLE, "Setting bufferization time to : %lu secs\n", pSendContext->bufferization_duration));


	return pSendContext->status;
}

RMstatus proxy_flush_video(void *context)
{
	struct asf_context *pSendContext = (struct asf_context *) context;
	RMstatus err = RM_OK;
	RMuint64 time;

	err = RUAGetProperty(pSendContext->pRUA, pSendContext->dcc_info->SurfaceID, RMGenericPropertyID_CurrentDisplayPTS, &time, sizeof(time));

	RMDBGLOG((ENABLE, "flush video fifo at %llu in %ld units\n", time, pSendContext->video_vop_tir));
	pSendContext->CurrentDisplayPTS = time;

	stop_decoders(pSendContext, RM_DEVICES_VIDEO);

	start_decoders(pSendContext, RM_DEVICES_VIDEO, DCCVideoPlayFwd);

	DCCSTCSetVideoOffset(pSendContext->dcc_info->pStcSource, -(pSendContext->video_vop_tir*pSendContext->bufferization_duration), pSendContext->video_vop_tir);
	DCCSTCSetAudioOffset(pSendContext->dcc_info->pStcSource, -(pSendContext->audio_vop_tir*pSendContext->bufferization_duration), pSendContext->audio_vop_tir);

	RMDBGLOG((ENABLE, "Setting bufferization time to : %lu secs\n", pSendContext->bufferization_duration));


	return pSendContext->status;
}


RMstatus proxy_set_speed(void *context, RMint32 speed)
{
	struct asf_context *pSendContext = (struct asf_context *) context;

	pSendContext->status = DCCSTCSetSpeed(pSendContext->dcc_info->pStcSource, speed, 1);	

	return pSendContext->status;
}


RMstatus proxy_enter_trickmode(void *context)
{
	struct asf_context *pSendContext = (struct asf_context *) context;
	RMstatus err = RM_OK;
	RMuint64 time;

	err = RUAGetProperty(pSendContext->pRUA, pSendContext->dcc_info->SurfaceID, RMGenericPropertyID_CurrentDisplayPTS, &time, sizeof(time));

	RMDBGLOG((ENABLE, "enter trickmode at %llu in %ld units\n", time, pSendContext->video_vop_tir));

	pSendContext->CurrentDisplayPTS = time;

	if (pSendContext->video_vop_tir == 90000)
		pSendContext->CurrentDisplayPTS *= 2;


	return err;
}

RMstatus proxy_exit_trickmode(void *context)
{
	struct asf_context *pSendContext = (struct asf_context *) context;
	RMstatus err = RM_OK;
	RMuint64 time;

	err = RUAGetProperty(pSendContext->pRUA, pSendContext->dcc_info->SurfaceID, RMGenericPropertyID_CurrentDisplayPTS, &time, sizeof(time));

	if (pSendContext->video_vop_tir == 90000)
		time *= 2;

	RMDBGLOG((ENABLE, "resume from trickmode at %llu in %ld units\n", time, pSendContext->video_vop_tir));
	pSendContext->CurrentDisplayPTS = (time * 1000) / pSendContext->video_vop_tir;


	stop_decoders(pSendContext, RM_DEVICES_STC | RM_DEVICES_AUDIO | RM_DEVICES_VIDEO);

	pSendContext->status = DCCSTCSetSpeed(pSendContext->dcc_info->pStcSource, 1, 1);

	if (fDecodeWMAPRO) {
		RMDBGLOG((ENABLE, "close wmapro decoder\n"));
		RMWMAProVDecoderClose(pSendContext->vDecoder);
		
		RMDBGLOG((ENABLE, "open wmapro decoder\n"));
		RMWMAProVDecoderOpen(pSendContext->vDecoder);
	}

	pSendContext->FirstSystemTimeStamp = TRUE;

	pSendContext->IFrameFSMState = RMasfIFrameFSM_Disabled;
	pSendContext->SeekAudio = TRUE;
	pSendContext->SeekVideo = TRUE;

	/* the stc will be put into "play" mode with the first pts */
	start_decoders(pSendContext, RM_DEVICES_AUDIO | RM_DEVICES_VIDEO, DCCVideoPlayFwd);

	return pSendContext->status;
}

RMuint32 proxy_get_duration(void *context)
{
	struct asf_context *pSendContext = (struct asf_context *) context;

	return pSendContext->Duration/1000;
}

RMuint32 proxy_get_position(void *context)
{
	struct asf_context *pSendContext = (struct asf_context *) context;

	RMuint64 currentPTS;

	RUAGetProperty(pSendContext->pRUA, pSendContext->dcc_info->SurfaceID, RMGenericPropertyID_CurrentDisplayPTS, &(currentPTS), sizeof(RMuint64));
	RMDBGLOG((ENABLE, ">>current PTS %llu\n", currentPTS));

	return currentPTS;
}

RMstatus proxy_get_status(void *context)
{
	struct asf_context *pSendContext = (struct asf_context *) context;

	return pSendContext->status;
}

ASF_streaming_state proxy_get_state(void *context)
{
	struct asf_context *pSendContext = (struct asf_context *) context;

	switch (pSendContext->dcc_info->state){
	case RM_PLAYING:
		return ASF_STREAMING_PLAYING;
	case RM_PLAYING_TRICKMODE:
		return ASF_STREAMING_PLAYING_TRICKMODE;
	case RM_PAUSE:
		return ASF_STREAMING_PAUSE;
	default:
		return ASF_STREAMING_STOP;
	};
}

void proxy_payload(void *context,
		   unsigned char Stream_Number,  
		   unsigned char *buf, unsigned long size,
		   unsigned long bytes_left,
		   unsigned char Is_Key_Frame,
		   unsigned long Media_Object_Number, unsigned char Media_Object_Number_valid,
		   unsigned long Presentation_Time, unsigned char Presentation_Time_valid,
		   unsigned long Offset_Into_Media_Object)
{
	struct asf_context *pSendContext = (struct asf_context *) context;
	struct emhwlib_info Info = {0,};
	struct emhwlib_info *pInfo = NULL;
	RMuint32 size_info = 0;

	//struct RUABufferPool *pDMA_audio;
	RMint32 diff;
	#define DELTA_PTS 100			// 1 sec
	#define CONTIGUOUS_LENGHT 0x100000	// 1 MB

	RMuint32 dataType = 0;
	RMbool SetPTS = FALSE;
	RMbool SendPTS = FALSE;
	RMbool SendData = FALSE;
	RMuint32 PrevMON = 0;
	RMuint32 decoder = 0;

	//RMbool ptsAlreadyScaled = FALSE;

	// dummy init
	RMbool *seeking = &(pSendContext->SeekVideo);
	RMuint32 *previousMON = &(pSendContext->PrevVideoMON);

	if (pSendContext->ignoreCallback) {
		if (pSendContext->cmd == RM_QUIT) {
			RMDBGLOG((ENABLE, "callback called when 'quit' command was issued\n"));
			goto return_from_callback;
		}
		if (pSendContext->cmd == RM_STOP) {
			RMDBGLOG((ENABLE, "callback called when 'stop' command was issued\n"));
			goto return_from_callback;
		}
		if (pSendContext->cmd == RM_STOP_SEEK_ZERO) {
			RMDBGLOG((ENABLE, "callback called when 'seekzero' command was issued\n"));
			goto return_from_callback;
		}
		if ((pSendContext->dcc_info->state == RM_PLAYING_TRICKMODE) && 
		    ((pSendContext->dcc_info->trickmode_id == RM_TRICKMODE_FWD_IFRAME) ||	
		     (pSendContext->dcc_info->trickmode_id == RM_TRICKMODE_RWD_IFRAME)) ) {
			RMDBGLOG((ENABLE, "callback called when 'iframe' command was issued\n"));
			goto return_from_callback;
		}
	}

	
	if (pSendContext->drmError != 0) {
		RMDBGLOG((ENABLE, "there was a decryption error, callback ignored\n"));
		goto return_from_callback;
	}

	if ((pSendContext->isContentEncrypted) && (bytes_left != 0))
		RMDBGLOG((ENABLE, "non aligned read, offset %ld!\n", bytes_left));


	RMDBGLOG((PAYLOADDBG,"ST:%02d,MON:%04d, (valid %ld), Key:%01d,time:%05d.%03d,(valid %ld), size:%05d, left:%05d, offset:%05d \n",
		  (int)Stream_Number,
		  (int)Media_Object_Number,
		  (int)Media_Object_Number_valid,
		  (int)Is_Key_Frame,
		  (int)(Presentation_Time/1000),
		  (int)(Presentation_Time%1000),
		  (int)Presentation_Time_valid,
		  (int)size,
		  (int)bytes_left,
		  (int)Offset_Into_Media_Object));

	
	if (Stream_Number == pSendContext->video_stream_index)
		dataType = RM_STREAM_VIDEO;
	else if (Stream_Number == pSendContext->audio_stream_index)
		dataType = RM_STREAM_AUDIO;
	else
		goto return_from_callback;



	// Decrypt packet, if necessary
	if (pSendContext->isContentEncrypted) {
		if ((pSendContext->drmError = WMDRM_decrypt_packet(buf, size)) != 0) {
			RMASFVDemuxSetDRMError(pSendContext->vASFDemux, pSendContext->drmError);
			RMDBGLOG((ENABLE, "DECRYPTION FAILED\n"));
			goto return_from_callback;
		}
	}

	/* adjust PTS if necessary */
	if ((pSendContext->PrerollSET) && (pSendContext->Preroll)) {
		RMDBGLOG((DISABLE, "pts %llu, adjusted pts %llu\n", (RMuint64)Presentation_Time, (RMuint64)Presentation_Time - pSendContext->Preroll));
		
		if ((RMuint32) pSendContext->Preroll > Presentation_Time) {
			RMDBGLOG((ENABLE, "Skipping packets with negative PTS\n"));
			goto return_from_callback;
		}
		else
			Presentation_Time -= (RMuint32)pSendContext->Preroll;
	}

	/* wait for first IFrame, some streams dont start with a IFrame!! */
	if ((!pSendContext->firstIFrame) && (dataType == RM_STREAM_VIDEO)) {
		if ((Is_Key_Frame) && (Offset_Into_Media_Object == 0)) {
			fprintf(stderr, ">> first IFrame found, start sending video. MON(%lu), Stream(%lu)\n", (RMuint32)Media_Object_Number, (RMuint32)Stream_Number);
			pSendContext->firstIFrame = TRUE;
		}
		else {
			fprintf(stderr, "waiting for first IFrame, skipping MON(%lu) Stream(%lu) \n", (RMuint32)Media_Object_Number, (RMuint32)Stream_Number);
			goto return_from_callback;
		}
	}


	/* accurate audio seek, required for WMA FFWD trickmode */
	if (dataType == RM_STREAM_AUDIO) {
		if (pSendContext->accurateAudioSeekTo > (RMuint64)Presentation_Time) {
			RMDBGLOG((ENABLE, "skipping audio %lu < %llu\n", Presentation_Time, pSendContext->accurateAudioSeekTo));
			goto return_from_callback;
		}
		else if (pSendContext->accurateAudioSeekTo != 0) {
			RMDBGLOG((ENABLE, "start sending audio %lu\n", Presentation_Time));
			pSendContext->accurateAudioSeekTo = 0;
		}
	}



	switch (dataType) {
	case RM_STREAM_VIDEO: 
		if (!pSendContext->SendVideoData)
			goto return_from_callback;
		SendPTS = pSendContext->SendVideoPts;
		PrevMON = pSendContext->prev_video_media_object_number;
		pSendContext->VideoByteCounter += size;
		pSendContext->prev_video_media_object_number = Media_Object_Number;
		decoder = pSendContext->dcc_info->video_decoder;
		SendData = TRUE;
		seeking = &(pSendContext->SeekVideo);
		previousMON = &(pSendContext->PrevVideoMON);

		break;
	case RM_STREAM_AUDIO: 
		if (!pSendContext->SendAudioData)
			goto return_from_callback;
		SendPTS = pSendContext->SendAudioPts;
		PrevMON = pSendContext->prev_audio_media_object_number;
		decoder = pSendContext->dcc_info->audio_decoder;
		if (!fDecodeWMAPRO)
			pSendContext->AudioByteCounter += size;

		pSendContext->prev_audio_media_object_number = Media_Object_Number;
		
		Is_Key_Frame = 1; /* audio payload doesnt set the keyframe flag, so we must 
				     force it to one, see "if (*seeking)" below */
				     
		seeking = &(pSendContext->SeekAudio);
		previousMON = &(pSendContext->PrevAudioMON);

		SendData = ((fDecodeWMAPRO) || ((pSendContext->dcc_info->state != RM_PLAYING) && (pSendContext->dcc_info->state != RM_PAUSE))) ? FALSE : TRUE;
		
		if (pSendContext->dcc_info->state == RM_PLAYING) {
			struct emhwlib_info PTSInfo;
			PTSInfo.ValidFields = TIME_STAMP_INFO;
			PTSInfo.TimeStamp = Presentation_Time;
			
			if ((!fDecodeWMAPRO) && (ResyncAudio(pSendContext, &PTSInfo) == RM_SKIP_TO_RESYNC))
				goto return_from_callback;
			
		}

		
	}


	
	if (*seeking) {
		if ((Is_Key_Frame) && (Offset_Into_Media_Object == 0)) {
			RMDBGLOG((ENABLE, ">>first %s payload after a seek, MON %lu, size %ld, pts %lu\n", (dataType == RM_STREAM_VIDEO) ? "video":"audio", Media_Object_Number, size, Presentation_Time));
			*previousMON = Media_Object_Number;
			SetPTS = TRUE;
		}
		else
			goto return_from_callback;
		
		*seeking = FALSE;
	}

	if ((pSendContext->isIFrameMode) && (dataType == RM_STREAM_VIDEO)) {
		switch (pSendContext->IFrameFSMState) {
		case RMasfIFrameFSM_Disabled: 
			break;
		case RMasfIFrameFSM_Init: 
			if ((Is_Key_Frame) && (Offset_Into_Media_Object == 0)) {
				RMDBGLOG((TRICKDBG, ">>this payload will be sent, MON %lu, size %ld, pts %lu\n", Media_Object_Number, size, Presentation_Time));
				pSendContext->PrevVideoMON = Media_Object_Number;
				pSendContext->IFrameFSMState = RMasfIFrameFSM_WaitIFrameMONChange;
				SetPTS = TRUE;
			}
			else {
			        RMDBGLOG((TRICKDBG, "++skip payload MON %lu, size %ld until KEY & OFF=0, pts %lu\n", Media_Object_Number, size, Presentation_Time));
				goto return_from_callback;
			}
			break;
		case RMasfIFrameFSM_WaitIFrameMONChange: 
			if (pSendContext->PrevVideoMON != Media_Object_Number) {
				RMDBGLOG((TRICKDBG,"++skipping video because IFrame MON(%lu) changed to %lu, size %lu\n", pSendContext->PrevVideoMON, Media_Object_Number, size));
				pSendContext->IFrameFSMState = RMasfIFrameFSM_SkipNext;
				goto return_from_callback;
			}

			break;
		case RMasfIFrameFSM_SkipNext: 
			RMDBGLOG((TRICKDBG, "++skippingNEXT video because IFrame MON(%lu) changed to %lu, size %lu\n", pSendContext->PrevVideoMON, Media_Object_Number, size));
			goto return_from_callback;
			break;
		default: 
			goto return_from_callback;
		}
		
	} else if (pSendContext->isIFrameMode) {
		// skip all other streams
		goto return_from_callback;
	}
	

	RMDBGLOG((DISABLE, "prevMON %s is %lu pts %lu\n", (dataType == RM_STREAM_VIDEO) ? "video":"audio", PrevMON, Presentation_Time));

	//  do not resend pts at each subpacket
	if ((Media_Object_Number_valid && (Media_Object_Number != PrevMON)) || SetPTS) {
		Info.ValidFields = TIME_STAMP_INFO;
		Info.TimeStamp = (RMuint64)Presentation_Time;

		pInfo = &Info;
		size_info = sizeof(Info);

		if (dataType == RM_STREAM_VIDEO) {
			pSendContext->video_last_pts = Presentation_Time;
			pSendContext->video_time_stamp = Presentation_Time;
		} 
		else if (dataType == RM_STREAM_AUDIO)
			pSendContext->audio_time_stamp = Presentation_Time;
			
		if ( pSendContext->FirstSystemTimeStamp ) {
			pSendContext->min_diff = 0;
			pSendContext->max_diff = 0;
			if (dataType == RM_STREAM_VIDEO)
				pSendContext->audio_time_stamp = pSendContext->video_time_stamp;
			else
				pSendContext->video_time_stamp = pSendContext->audio_time_stamp;
		}

		if (pSendContext->VideoStreamFound) {
			diff = pSendContext->video_time_stamp - pSendContext->audio_time_stamp;
			RMDBGLOG((DISABLE, "diff %lu\n", diff));
			if ( (diff < -DELTA_PTS) || (diff > DELTA_PTS)) {
				if ( (diff > 0) && (diff > pSendContext->max_diff+100) ) {
					pSendContext->max_diff = diff;
					if(pSendContext->dcc_info->trickmode_id == RM_NO_TRICKMODE)
						RMDBGLOG((ENABLE, " %ld\n", diff));
				}
				if ( (diff < 0) && (diff < pSendContext->min_diff-100) ) {
					pSendContext->min_diff = diff;
					if(pSendContext->dcc_info->trickmode_id == RM_NO_TRICKMODE)
						RMDBGLOG((ENABLE, " %ld\n", diff));
				}
			}
		}

		


	} 
	
	if (!SendPTS) {
		pInfo = NULL;
		size_info = 0;
	}


	
	if ((pSendContext->CurrentDisplayPTS) && (dataType == RM_STREAM_VIDEO))  {
		if ((Presentation_Time >= pSendContext->CurrentDisplayPTS) && (Is_Key_Frame) && (Offset_Into_Media_Object == 0)) {
			pSendContext->CurrentDisplayPTS = 0;
			pSendContext->SeekAudio = TRUE;
			pSendContext->IgnoreAudio = FALSE;
			RMDBGLOG((ENABLE, "will send video MON=%lu, size=%lu, pts=%lu %s, %lu\n",
				  Media_Object_Number, 
				  size, 
				  Presentation_Time,
				  Is_Key_Frame == 1 ? "key":"", 
				  Offset_Into_Media_Object));
		}
		else {
			RMDBGLOG((ENABLE, "dropping video frame MON=%lu, size=%lu, pts=%lu < DisplayPTS(%llu), %s, %lu\n", 
				  Media_Object_Number,
				  size, 
				  Presentation_Time, 
				  pSendContext->CurrentDisplayPTS,
				  Is_Key_Frame == 1 ? "key":"", 
				  Offset_Into_Media_Object));
			pSendContext->IgnoreAudio = TRUE;
			goto return_from_callback;
		}
	}
	if ((pSendContext->CurrentDisplayPTS) && (dataType == RM_STREAM_AUDIO)) {
		if ((Presentation_Time >= pSendContext->CurrentDisplayPTS) && 
		    (Is_Key_Frame) && (Offset_Into_Media_Object == 0) &&
		    (pSendContext->IgnoreAudio == FALSE)) {
			pSendContext->CurrentDisplayPTS = 0;
			RMDBGLOG((ENABLE, "will send audio MON=%lu, size=%lu, pts=%lu %s, %lu\n",
				  Media_Object_Number, 
				  size, 
				  Presentation_Time, 
				  Is_Key_Frame == 1 ? "key":"", 
				  Offset_Into_Media_Object));
		}
		else {
			RMDBGLOG((ENABLE, "dropping audio frame MON=%lu, size=%lu, pts=%lu < DisplayPTS(%llu)\n", 
				  Media_Object_Number, 
				  size,
				  Presentation_Time, 
				  pSendContext->CurrentDisplayPTS));
			goto return_from_callback;
		}
	}


	if ( pSendContext->FirstSystemTimeStamp && pInfo && (pInfo->ValidFields & TIME_STAMP_INFO)) {
		if ( (!pSendContext->PrerollSET) && pSendContext->Preroll ) {
			if (pInfo->TimeStamp < pSendContext->Preroll) {
				RMDBGLOG((ENABLE, "First PTS (%llu) < Preroll (%llu), adjusting Preroll to %llu so first PTS=0\n",
					  pInfo->TimeStamp, pSendContext->Preroll,
					  pInfo->TimeStamp));
				pSendContext->Preroll = pInfo->TimeStamp;
				pInfo->TimeStamp = 0;
			}
			else {
				RMDBGLOG((ENABLE, "Preroll is %llu: first PTS %llu needs to be adjusted to %llu\n", 
					  pSendContext->Preroll, pInfo->TimeStamp,
					  pInfo->TimeStamp - pSendContext->Preroll));
				pInfo->TimeStamp -= pSendContext->Preroll;
			}
			pSendContext->PrerollSET = TRUE;
		}

	}

	if ((pSendContext->audio_vop_tir != 1000) && (dataType == RM_STREAM_AUDIO)) {
		RMuint64 pts = (pInfo == NULL) ? 0 : pInfo->TimeStamp;
		RMuint64 scaledPTS;
		
		scaledPTS = (pts * pSendContext->audio_vop_tir) / 1000;
		RMDBGLOG((SENDDBG, "scaling audio pts %llu thru a factor %lu/1000 -> %llu\n", pts, pSendContext->audio_vop_tir, scaledPTS));
		if (pInfo)
			pInfo->TimeStamp = scaledPTS;
	}

	if ((pSendContext->video_vop_tir != 1000) && (dataType == RM_STREAM_VIDEO)) {
		RMuint64 pts = (pInfo == NULL) ? 0 : pInfo->TimeStamp;
		RMuint64 scaledPTS;
		
		scaledPTS = (pts * pSendContext->video_vop_tir) / 1000;
		RMDBGLOG((SENDDBG, "scaling video pts %llu thru a factor %lu/1000 -> %llu\n", pts, pSendContext->video_vop_tir, scaledPTS));
		if (pInfo)
			pInfo->TimeStamp = scaledPTS;
	}


	if ( pSendContext->FirstSystemTimeStamp && pInfo && (pInfo->ValidFields & TIME_STAMP_INFO)) {
		RMuint32 timeScale = (dataType == RM_STREAM_VIDEO) ? pSendContext->video_vop_tir : pSendContext->audio_vop_tir;
			
		RMDBGLOG((ENABLE, "FirstSystemTimeStamp for %s = %llu(0x%llx) at %ld/sec = %lu s\n",
			  dataType == RM_STREAM_VIDEO ? "video":"audio",
			  pInfo->TimeStamp, 
			  pInfo->TimeStamp, 
			  timeScale,
			  (RMuint32)pInfo->TimeStamp / timeScale)); 
		

		if(fDecodeWMAPRO) {
			//this is correct because wmapro has timescale = 1000

			RMint64 firstPTS = (RMint64)pInfo->TimeStamp + (RMint64)pSendContext->start_ms - (RMint64)(pSendContext->audio_vop_tir>>1);
			RMDBGLOG((ENABLE, "Set STC at least %ld clicks before PTS for WMAPRO decoding \n", pSendContext->audio_vop_tir>>1));
			RMDBGLOG((ENABLE, "firstPTS %lld %s\n", firstPTS, (firstPTS < 0) ? ">>> timer is negative!":""));
			DCCSTCSetTime(pSendContext->dcc_info->pStcSource, RMmax(0, (RMuint64)firstPTS), timeScale);
		}
		else {
			RMuint32 startms = (pSendContext->start_ms * timeScale) / 1000;
			RMuint32 offset = (300 * timeScale) / 1000;

			RMint64 firstPTS = (RMint64)pInfo->TimeStamp + (RMint64)startms - (RMint64)offset;

			RMDBGLOG((ENABLE, "timer will be set to %lld %s\n", firstPTS, (firstPTS < 0) ? ">>> timer is negative!":""));

			DCCSTCSetTime(pSendContext->dcc_info->pStcSource, RMmax(0, (RMuint64)firstPTS), timeScale);
		}
		
		DCCSTCPlay(pSendContext->dcc_info->pStcSource);

		pSendContext->FirstSystemTimeStamp = FALSE;
		RMDBGLOG((ENABLE, "vpts-apts[ms]= 0\n"));
	}

	/* senddata for video and wma audio */
	if (SendData) {


		// send VC1 start codes
		if ((dataType == RM_STREAM_VIDEO) && (pSendContext->isVC1)) {

			if (pSendContext->getStartCodeBuffer) {
				if (pSendContext->startCodeBuffer) {
					RMDBGLOG((VC1_STARTCODE_DBG, "releasing startCodeBuffer @0x%08lx, bytes left %lu\n", (RMuint32)pSendContext->startCodeBuffer, pSendContext->startCodeBufferLeft));
					RUAReleaseBuffer(pSendContext->pDMA, pSendContext->startCodeBuffer);
				}
				while(RUAGetBuffer(pSendContext->pDMA, &(pSendContext->startCodeBuffer), GETBUFFER_TIMEOUT_US) != RM_OK) {
					RMDBGLOG((ENABLE, "cant get buffer for VC1 startcode\n"));
					PROCESS_KEY_INCALLBACK();
				}
				pSendContext->startCodeBufferSize = (1 << ASF_DMA_BUFFER_SIZE_LOG2);
				pSendContext->startCodeBufferLeft = (1 << ASF_DMA_BUFFER_SIZE_LOG2);
				RMDBGLOG((VC1_STARTCODE_DBG, "got a new startCodeBuffer @0x%08lx, size %lu\n", (RMuint32)pSendContext->startCodeBuffer, pSendContext->startCodeBufferSize));
				pSendContext->getStartCodeBuffer = FALSE;
			}

			// check for start code presence in bitstream from ASF


			if ((buf[0] == 0) && (buf[1] == 0) && (buf[2] == 1)) {
				if (buf[3] == 0x0F) {
					// all start codes are already present in the bitstream
					// dont add any
					pSendContext->addSeqHeader = FALSE;
					pSendContext->addEntryHeader = FALSE;
					pSendContext->addFrameHeader = FALSE;
				}
				else if (buf[3] == 0x0E) {
					// dont add entryHeader nor frameHeader
					pSendContext->addEntryHeader = FALSE;
					pSendContext->addFrameHeader = FALSE;
				}
				else if (buf[3] == 0x0D) {
					// dont add frameHeader
					pSendContext->addFrameHeader = FALSE;
				}
				// no start code present, add them (default)
			}


			// sequence header
			if (pSendContext->addSeqHeader) {
				RMuint32 i;

				// copy the seqHeader
				RMDBGLOG((ENABLE, "adding seqHeader, size %lu, startCodeBufferLeft %lu\n", pSendContext->seqHeaderSize, pSendContext->startCodeBufferLeft));
				for (i = 0; i < pSendContext->seqHeaderSize; i++)
					*(pSendContext->startCodeBuffer + i) = *(pSendContext->seqHeader + i);
				
				// send the seqHeader
				while (RUASendData(pSendContext->pRUA, decoder, pSendContext->pDMA, pSendContext->startCodeBuffer, pSendContext->seqHeaderSize, pInfo, size_info) != RM_OK) {
					RMDBGLOG((ENABLE, "waiting for sendSeqHeader to complete\n"));
				}
				

				pSendContext->startCodeBuffer += pSendContext->seqHeaderSize;
				pSendContext->startCodeBufferLeft -= pSendContext->seqHeaderSize;
				pSendContext->addSeqHeader = FALSE;

			}

			// entry header (for iframes)
			if ((pSendContext->addEntryHeader) && Media_Object_Number_valid && (Media_Object_Number != PrevMON) && Is_Key_Frame && (Offset_Into_Media_Object == 0))  {
				RMuint32 i;

				// copy the entryHeader
				RMDBGLOG((VC1_STARTCODE_DBG, "adding entryHeader (size %lu) to iframe MON %lu, startCodeBufferLeft %lu\n", pSendContext->entryHeaderSize, (RMuint32) Media_Object_Number, pSendContext->startCodeBufferLeft ));

				for (i = 0; i < pSendContext->entryHeaderSize; i++)
					*(pSendContext->startCodeBuffer + i) = *(pSendContext->entryHeader + i);
				
				// send the entryHeader
				while (RUASendData(pSendContext->pRUA, decoder, pSendContext->pDMA, pSendContext->startCodeBuffer, pSendContext->entryHeaderSize, pInfo, size_info) != RM_OK) {
					RMDBGLOG((ENABLE, "waiting for sendEntryHeader to complete\n"));
				}
				

				pSendContext->startCodeBuffer += pSendContext->entryHeaderSize;
				pSendContext->startCodeBufferLeft -= pSendContext->entryHeaderSize;

			}

			// picture header (for all frames)
			if ((pSendContext->addFrameHeader) && Media_Object_Number_valid && (Media_Object_Number != PrevMON)) {
				// new picture, add picture header startcode "00 00 01 0D"
				RMDBGLOG((VC1_STARTCODE_DBG, "add newPic startcode to MON %lu, startCodeBufferLeft %lu\n", (RMuint32) Media_Object_Number, pSendContext->startCodeBufferLeft ));
				*(pSendContext->startCodeBuffer) = 0x00;
				*(pSendContext->startCodeBuffer + 1) = 0x00;
				*(pSendContext->startCodeBuffer + 2) = 0x01;
				*(pSendContext->startCodeBuffer + 3) = 0x0D;

				// send the startcode
				while (RUASendData(pSendContext->pRUA, decoder, pSendContext->pDMA, pSendContext->startCodeBuffer, 4, pInfo, size_info) != RM_OK) {
					RMDBGLOG((ENABLE, "waiting for sendNewPicSC to complete\n"));
				}
				

				pSendContext->startCodeBuffer += 4;
				pSendContext->startCodeBufferLeft -= 4;
			}

			if (pSendContext->startCodeBufferLeft < (pSendContext->seqHeaderSize + pSendContext->entryHeaderSize + 4))
				pSendContext->getStartCodeBuffer = TRUE;
			
		}



		RMDBGLOG((SENDDBG, "sending MON(%lu) %s, size %lu, pts %llu = 0x%llx (%s), %s, %lu\n",
			  Media_Object_Number, 
			  dataType == RM_STREAM_VIDEO ? "video":"audio",
			  size, 
			  pInfo == NULL ? 0:pInfo->TimeStamp, 
			  pInfo == NULL ? 0:pInfo->TimeStamp,
			  pInfo == NULL ? "no pts":(pInfo->ValidFields & TIME_STAMP_INFO ? "valid":""),
			  Is_Key_Frame == 1 ? "key":"", 
			  Offset_Into_Media_Object));
		
		if ((Is_Key_Frame) && (!Offset_Into_Media_Object) && (dataType == RM_STREAM_VIDEO))
			RMDBGLOG((IFRAMEDBG, "sending video keyframe MON(%lu) size %lu, pts %llu = 0x%llx (%s), %lu\n", 
				  Media_Object_Number, 
				  size,
				  pInfo == NULL ? 0:pInfo->TimeStamp,
				  pInfo == NULL ? 0:pInfo->TimeStamp,
				  pInfo == NULL ? "no pts" : (pInfo->ValidFields & TIME_STAMP_INFO ? "valid":""), 
				  Offset_Into_Media_Object));


		while (RUASendData(pSendContext->pRUA, decoder, pSendContext->pDMA, buf, size, pInfo, size_info) != RM_OK) {
			struct RUAEvent e;

			RMDBGLOG((ENABLE, "waiting for senddata %s\n", dataType == RM_STREAM_VIDEO ? "video":"audio"));

			PROCESS_KEY_INCALLBACK();
			update_hdmi(pSendContext->dcc_info, &display_options, &audio_options);
			
			e.ModuleID = decoder;
			e.Mask = RUAEVENT_XFER_FIFO_READY;
			RUAWaitForMultipleEvents(pSendContext->pRUA, &e, 1, SENDDATA_TIMEOUT_US, NULL);
		}
		
		/* sendind data may fill-up the xfer fifo, so we reset the event */
		{
			struct RUAEvent e;
			
			e.ModuleID = decoder;
			e.Mask = RUAEVENT_XFER_FIFO_READY;
			RUAResetEvent(pSendContext->pRUA, &e);
		}
		goto callback_end; //callback end
			
	}



	/* wmapro decoding and senddata */	
	if ((dataType == RM_STREAM_AUDIO) && 
	    (pSendContext->dcc_info->state != RM_PLAYING_TRICKMODE) &&
	    (fDecodeWMAPRO)) {
		RMuint8 *pw1, *pw2;	
		RMuint32 wr1, wr2;
 		RMuint32 size1, size2;
                 
 		while (RMfifo_get_writable_size(pSendContext->wmapro_fifo, &wr1, &size1, &wr2) < sizeof(struct wmapro_info) + size) {
			RMDBGLOG((WMAPRODBG, "WMAPRO fifo too small\n")); 			
			try_decode_wmapro(pSendContext, FALSE); 			
			PROCESS_KEY_INCALLBACK();
			update_hdmi(pSendContext->dcc_info, &display_options, &audio_options);
  		} 

 		pSendContext->pwrite_wmapro_info->size = size;
 		pSendContext->pwrite_wmapro_info->Info = Info;
 		pSendContext->pwrite_wmapro_info->Stream_Number = Stream_Number;
 		pSendContext->pwrite_wmapro_info->Media_Object_Number = Media_Object_Number;
 		pSendContext->pwrite_wmapro_info->fSendPTS = 1;

		RMFifoWrite((RMuint8 *)pSendContext->pwrite_wmapro_info, 
			    sizeof(struct wmapro_info), &pw1, &size1, &pw2, &size2, (RMuint32)pSendContext->wmapro_fifo);

 		RMFifoWrite((RMuint8 *)buf, size, &pw1, &size1, &pw2, &size2, (RMuint32)pSendContext->wmapro_fifo);
		// copy audio data in compressed form		
		RMDBGLOG((WMAPRODBG, "saving wmapro audio into fifo %d, MON %d, %ld bytes, pts %llu\n",
		          (int)pSendContext->pwrite_wmapro_info->Stream_Number,
			  (int)pSendContext->pwrite_wmapro_info->Media_Object_Number,
			  pSendContext->pwrite_wmapro_info->size,
			  pSendContext->pwrite_wmapro_info->Info.TimeStamp));

  	        RMDBGLOG((WMAPRODBG, "buf 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x\n", 
		  *(RMuint8*)buf, 
		  *(RMuint8*)(buf+1), 
		  *(RMuint8*)(buf+2), 
		  *(RMuint8*)(buf+3), 
		  *(RMuint8*)(buf+4), 
		  *(RMuint8*)(buf+5)));

 		try_decode_wmapro(pSendContext, FALSE);
	}

 callback_end:

	if (Presentation_Time_valid)
		pSendContext->Presentation_Time = Presentation_Time;

	/*************************************************************************************/
	/* video debug stuff */
	/*************************************************************************************/

	if (dataType == RM_STREAM_VIDEO) {
		if (Media_Object_Number_valid && (Media_Object_Number != PrevMON)) {			
			pSendContext->video_frame_counter++;

#ifdef DISPLAY_VIDEO_STREAM_PAYLOAD_INFO
			//			RMDBGLOG((ENABLE, "Stream #%d: ", Stream_Number))
			RMDBGLOG((ENABLE, "VideoFrameCnt=%ld VideoByteCounter=0x%lx (size=0x%lx)",
				  pSendContext->video_frame_counter, pSendContext->VideoByteCounter, size))
#if 0
			if (Presentation_Time_valid)
				RMDBGLOG((ENABLE, " - PTS = 0x%lx", Presentation_Time))
			if (Media_Object_Number_valid)
				RMDBGLOG((ENABLE, " - Media_Object_Number = %lx", Media_Object_Number))
			if (Is_Key_Frame)
				RMDBGLOG((ENABLE, " (key frame)"));
#endif
			RMDBGLOG((ENABLE,"\n"));
			RMDBGLOG((ENABLE,"%02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x...\n",
				  (int)(buf[0]), (int)(buf[1]), (int)(buf[2]), (int)(buf[3]), (int)(buf[4]), (int)(buf[5]), 
				  (int)(buf[6]), (int)(buf[7]), (int)(buf[8]), (int)(buf[9]), (int)(buf[10])))
//			if(pSendContext->video_frame_counter > 0x124)
//				scanf ("%ld", &size_info);
#endif
		}

		if(pSendContext->ContiguousVideoLength == 0)
			pSendContext->video_time_start = get_ustime();
		pSendContext->ContiguousVideoLength +=size;
		if(pSendContext->ContiguousVideoLength > CONTIGUOUS_LENGHT) {
			pSendContext->video_time_end = get_ustime();
			//RMDBGLOG((ENABLE, "pSendContext->ContiguousVideoLength 0x%08lx = %8lldus\n", pSendContext->ContiguousVideoLength, pSendContext->video_time_end - pSendContext->video_time_start));
		}
		pSendContext->ContiguousAudioLength = 0;

#ifdef DISPLAY_BITRATE
	
 		if (pSendContext->prev_time == 0) {
			pSendContext->prev_time = Presentation_Time;
		}
		else if (Presentation_Time - pSendContext->prev_time > 1000) {
			RMDBGLOG((ENABLE,"bitrate = %d.%dMBit/s\n", 
				  (int) ((pSendContext->nb_bytes_since_prev_time * 8) / 1000000),
				  (int) (((pSendContext->nb_bytes_since_prev_time * 8) % 1000000) / 1000)));
			pSendContext->prev_time = Presentation_Time;
			pSendContext->nb_bytes_since_prev_time = 0;
		
			pSendContext->nb_bytes_since_prev_time += size;
		}
	
#endif
	}

	/* audio debug stuff */

	if (dataType == RM_STREAM_AUDIO) {
		if (Media_Object_Number_valid && (Media_Object_Number != PrevMON)) {

			//RMDBGLOG((ENABLE, "\nFrame counter = %d, size = %d\n",(int)pSendContext->audio_frame_counter, (int)size));
			//fflush(stdout);
			pSendContext->audio_frame_counter++;

#ifdef DISPLAY_AUDIO_STREAM_PAYLOAD_INFO
			if (size == 0) 
				RMDBGLOG((ENABLE, "Audio frame #%ld, audio byte count = %ld : empty size\n", 
					  pSendContext->audio_frame_counter, pSendContext->AudioByteCounter));
			else
				RMDBGLOG((ENABLE, "Audio frame #%ld, audio byte count = %ld\n", 
					  pSendContext->audio_frame_counter, pSendContext->AudioByteCounter));

			if (Media_Object_Number_valid && (Media_Object_Number != pSendContext->prev_audio_media_object_number)) {
				RMDBGLOG((ENABLE, "Stream #%d, writing %lu bytes (total = %ld)", Stream_Number, size, pSendContext->AudioByteCounter));
				if (Presentation_Time_valid)
					RMDBGLOG((ENABLE, " - PTS = %lu", Presentation_Time));
				if (Media_Object_Number_valid)
					RMDBGLOG((ENABLE, " - Media_Object_Number = %lu", Media_Object_Number));
				if (Is_Key_Frame)
					RMDBGLOG((ENABLE, " (key frame)"));
				RMDBGLOG((ENABLE,"\n"));
			}
#endif
		}

		//RMDBGLOG((ENABLE, "audio = %ld\n", size)); 
		if(pSendContext->ContiguousVideoLength == 0)
			pSendContext->audio_time_start = get_ustime();
		pSendContext->ContiguousAudioLength = 0;
		pSendContext->ContiguousAudioLength +=size;
		if(pSendContext->ContiguousAudioLength > CONTIGUOUS_LENGHT) {
			pSendContext->audio_time_end = get_ustime();
			//RMDBGLOG((ENABLE, "pSendContext->ContiguousAudioLength 0x%08lx = %8lldus\n", pSendContext->ContiguousAudioLength, pSendContext->audio_time_end - pSendContext->audio_time_start));
		}
		pSendContext->ContiguousVideoLength = 0;

	}

	return;

 return_from_callback:

	RMDBGLOG((PAYLOADDBG,"dropped ST:%02d,MON:%04d,Key:%01d,time:%05d.%03d,size:%05d,left:%05d\n",
		  (int)Stream_Number,
		  (int)Media_Object_Number,
		  (int)Is_Key_Frame,
		  (int)(Presentation_Time/1000),
		  (int)(Presentation_Time%1000),
		  (int)size,
		  (int)bytes_left));
	if ((Is_Key_Frame) && (dataType == RM_STREAM_VIDEO)) {
		RMDBGLOG((SENDDBG, "dropped a keyframe! ST:%02d,MON:%04d,Key:%01d,time:%05d.%03d,size:%05d,left:%05d\n",
		  (int)Stream_Number,
		  (int)Media_Object_Number,
		  (int)Is_Key_Frame,
		  (int)(Presentation_Time/1000),
		  (int)(Presentation_Time%1000),
		  (int)size,
		  (int)bytes_left));
	}

	return;	
}



