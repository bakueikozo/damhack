/*
 *
 * Copyright (c) Sigma Designs, Inc. 2002. All rights reserved.
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>


#define ALLOW_OS_CODE 1
#include "common.h"
#include "bitmaps.h"
#include "gfx_demo.h"

#define KEYFLAGS (SET_KEY_DISPLAY | SET_KEY_PLAYBACK)
#define TIMEOUT_US 10000
#define MAX_SCALERS 5

static RMuint32 bitmap_addr = 0, circle_addr = 0, logo_addr = 0, gfx = 0, buf_addr = 0;
static struct DCCOSDProfile bitmap_profile;
static RMuint32 scalers[MAX_SCALERS] = {DispOSDScaler,};
static RMuint32 scaler_count = 0;
static struct RUA *pRUA = NULL;
static RMbool end = FALSE;
char *filename = (char *) NULL;
struct playback_cmdline play_opt;
struct display_cmdline disp_opt;
struct video_cmdline video_opt;
static struct dcc_context dcc_info = {0,};
RMuint32 inv_speed = 1;

													
#define SEND_GFX_COMMAND(propertyID, pValue, ValueSize)				                \
{												\
	RMstatus err;										\
	do{											\
		err = RUASetProperty(pRUA, gfx, propertyID, pValue, ValueSize, 0);		\
		if ((err == RM_PENDING)) {							\
 			struct RUAEvent evt;							\
			evt.ModuleID = gfx;				         		\
			evt.Mask = RUAEVENT_COMMANDCOMPLETION;					\
			RUAWaitForMultipleEvents(pRUA, &evt, 1, TIMEOUT_US, NULL);		\
		}										\
		if(!user_command())								\
			end = TRUE;								\
	}while((err == RM_PENDING) && (end == FALSE));								\
	if (err != RM_OK) {									\
		RMDBGLOG((ENABLE, "Can't send command to command fifo\n" ));			\
		end = TRUE;									\
	}											\
											   	\
}





static RMuint32 multiple_readers = FALSE;


static void show_usage(char *progname)
{
	show_display_options();
	show_video_options();
	
	fprintf(stderr, "------------------------------------------------------------\n");
	fprintf(stderr, "Minimum cmd line: %s <filename.jpg/filename.bmp>\n", progname);
	fprintf(stderr, "Image should be 256x256 or bigger and true color\n");
	fprintf(stderr, "------------------------------------------------------------\n");

	exit(1);
}


static RMuint32 user_command(){
	RMascii key;

	if (RMKeyAvailable()) {
		key = RMGetKey();
		switch(key){
		case 'q':
		case 'Q':
			return 0;
		case ' ':
			DCCSTCStop(dcc_info.pStcSource);
			break;
		case 'P':
		case 'p':
			DCCSTCPlay(dcc_info.pStcSource);
			break;
		case '+':
			inv_speed = RMmax(1, inv_speed-1);
			DCCSTCSetSpeed(dcc_info.pStcSource, 1, inv_speed);
			break;
		case '-':
			inv_speed = RMmin(8, inv_speed+1);
			DCCSTCSetSpeed(dcc_info.pStcSource, 1, inv_speed);
			break;
		}
		return 1;
	}
	return 2;

}
static void parse_cmdline(int argc, char *argv[])
{
	int i;
	RMstatus err;
	
	
	if (argc < 2) 
		show_usage(argv[0]);
	
	i = 1;
	while ((argc > i)) {
		if (argv[i][0] != '-') {
			if (filename == NULL) {
				filename = argv[i];
				i++;
				continue;
			}
			else
				show_usage(argv[0]);
		}

		if (! strcmp(argv[i], "-oscaler")) {
			if (argc > i+1) {
				if (! strcmp(argv[i+1], "osd")) {
					scalers[scaler_count] = EMHWLIB_MODULE(DispOSDScaler,0);
					scaler_count++;
				}
				else if (! strcmp(argv[i+1], "vp")) {
					scalers[scaler_count] =  EMHWLIB_MODULE(DispVideoPlane,0);
					scaler_count++;
				}
				else if (! strcmp(argv[i+1], "vcr")) {
					scalers[scaler_count] = EMHWLIB_MODULE(DispVCRMultiScaler,0);
					scaler_count++;
				}
				else if (! strcmp(argv[i+1], "crt")) {
					scalers[scaler_count] = EMHWLIB_MODULE(DispCRTMultiScaler,0);
					scaler_count++;
				}
				else if (! strcmp(argv[i+1], "main")) {
					scalers[scaler_count] = EMHWLIB_MODULE(DispMainVideoScaler,0);
					scaler_count++;
				}
				else
					show_usage(argv[0]);
				i+=2;
				continue;
			}
			else
				show_usage(argv[0]);
		}

		if (! strcmp(argv[i], "-multiple_readers")) {
			multiple_readers = TRUE;
			i++;
			continue;
		}

		err = parse_playback_cmdline(argc, argv, &i, &play_opt);
		if (err == RM_ERROR) 
			show_usage(argv[0]);
		if (err != RM_PENDING)
			continue;
		err = parse_display_cmdline(argc, argv, &i, &disp_opt);
		if (err == RM_ERROR) 
			show_usage(argv[0]);
		if (err != RM_PENDING)
			continue;
		err = parse_video_cmdline(argc, argv, &i, &video_opt);
		if (RMFAILED(err))
			show_usage(argv[0]);
	}
	

	if (filename == NULL)
		show_usage(argv[0]);
}

static RMstatus init_scaler(struct DCC *pDCC, struct RUA *pRUA, struct DCCVideoSource *pVideoSource, RMuint32 osd_scaler)
{
	RMbool enable = TRUE;
	struct EMhwlibDisplayWindow window;
	enum EMhwlibMixerSourceState state;
	RMuint32 mixer, src_index = 0, canvas_alpha = 0x80;
	struct RUAEvent e;
	RMuint32 index;
	static RMuint32 window_counter = 0;
	RMstatus err;
	
	mixer = DispMainMixer;
	
	window.X = 2048;
	window.Y = 2048;
	window.Width = (4-window_counter) * 1024;
	window.Height = (4-window_counter) * 1024;

	window_counter = (window_counter + 1) % 4;
	
	window.XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToCenter;
	window.YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToCenter;
	window.XMode = EMhwlibDisplayWindowValueMode_Relative;
	window.YMode = EMhwlibDisplayWindowValueMode_Relative;
	window.WidthMode = EMhwlibDisplayWindowValueMode_Relative;
	window.HeightMode = EMhwlibDisplayWindowValueMode_Relative;
	
	err = RUAExchangeProperty(dcc_info.pRUA, mixer, RMGenericPropertyID_MixerSourceIndex, &osd_scaler, sizeof(osd_scaler), &src_index, sizeof(src_index));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get scaler index\n"));
		return err;
	}
	mixer = EMHWLIB_TARGET_MODULE(mixer, 0, src_index);
	
	
	while ((err = RUASetProperty(dcc_info.pRUA, mixer, RMGenericPropertyID_MixerSourceWindow, &(window), sizeof(window), 0)) == RM_PENDING);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set scaler output window %d\n", err));
		return err;
	}

	state = EMhwlibMixerSourceState_Master;
	while((err =  RUASetProperty(dcc_info.pRUA, mixer, RMGenericPropertyID_MixerSourceState, &state, sizeof(state), 0))==RM_PENDING);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set scaler's state on mixer\n"));
		return err;
	}
	
	while ((err = RUASetProperty(dcc_info.pRUA, mixer, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot Validate mixer\n"));
		return err;
	}
	
	while( (err = RUASetProperty(dcc_info.pRUA, osd_scaler, RMGenericPropertyID_Alpha0, &(canvas_alpha), sizeof(canvas_alpha), 0)) == RM_PENDING);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set the alpha value on the scaler\n"));
	}
	
	while ((err = RUASetProperty(dcc_info.pRUA, osd_scaler, RMGenericPropertyID_Enable, &enable, sizeof(enable), 0)) == RM_PENDING);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot validate scaler input window %d\n", err);
		return err;
	}

	if (osd_scaler != DispVideoPlane) {
		window.X = 0;
		window.Y = 0;
		window.Width = 4096;
		window.Height = 4096;
		window.XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
		window.YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
		window.XMode = EMhwlibDisplayWindowValueMode_Relative;
		window.YMode = EMhwlibDisplayWindowValueMode_Relative;
		window.WidthMode = EMhwlibDisplayWindowValueMode_Relative;
		window.HeightMode = EMhwlibDisplayWindowValueMode_Relative;
		while ((err = RUASetProperty(dcc_info.pRUA, osd_scaler, RMGenericPropertyID_ScalerInputWindow, &window, sizeof(window), 0)) == RM_PENDING);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot validate scaler input window %d\n", err);
			return err;
		}
	}
	
	err = DCCSetSurfaceSource(dcc_info.pDCC, osd_scaler, pVideoSource);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot set the surface source %d\n", err);
		return RM_ERROR;
	}
	
	err = DCCEnableVideoSource(pVideoSource, TRUE);
	if (RMFAILED(err)){
		fprintf(stderr,"Error enabling OSD buffer : %d\n",err);
		return err;
	}

	while ((err = RUASetProperty(dcc_info.pRUA, osd_scaler, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot validate scaler input window %d\n", err);
		return err;
	}
	
	e.ModuleID = EMHWLIB_MODULE(DisplayBlock, 0);
	e.Mask = EMHWLIB_DISPLAY_EVENT_ID(osd_scaler);
	err = RUAWaitForMultipleEvents(pRUA, &e, 1, 1000000, &index);
	if (err == RM_ERROR) {
		fprintf(stderr, "cannot wait for the scaler to refresh\n");
		return err;
	}
	
	return RM_OK;
}


/* load the bitmap specfied on the commandline, and all that's on gfx_demo.h */
static RMstatus load_bitmaps()
{
	struct RMBitmapFileInfo bfi;
	struct RMBitmapFileOptions opts;
	RMuint8 *buf_map;
	RMuint32 buf_size, bitmap_size;
	RMstatus err;
		
	opts.alpha = 0x80;
	opts.force_rgb = TRUE;
		
	err = RMOpenBitmapFile(filename, &bfi, &opts, &bitmap_profile);
	if(RMFAILED(err)){
		RMDBGLOG((ENABLE, "Error opening file %s\n", filename));
			return err;
	}
	
	if (bitmap_profile.ColorMode != EMhwlibColorMode_TrueColor){
		fprintf(stderr, "Image should be true color\n");
		return -1;
	}

	bitmap_size = 4*bitmap_profile.Width*bitmap_profile.Height;
	buf_size = bitmap_size + sizeof(circle_pix) + sizeof(logo_pix) + sizeof(glyph_points);
	buf_addr = RUAMalloc(pRUA, 0, RUA_DRAM_UNCACHED, buf_size);
	
	bitmap_addr = buf_addr;
	logo_addr   = buf_addr + bitmap_size;
	circle_addr = buf_addr + bitmap_size + sizeof(logo_pix);
	elephant_glyph.GlyphAddr = buf_addr + bitmap_size + sizeof(logo_pix) + sizeof(circle_pix);
		
	elephant_glyph.OutAddr = RUAMalloc(pRUA, 0, RUA_DRAM_UNCACHED, 192*192/8); /*128x128@1bpp*/
		
	err = RUALock(pRUA, buf_addr, buf_size);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error locking OSD buffer at 0x%08lX (0x%08lX bytes)\n", buf_addr, buf_size));
		return err;
	}
	buf_map = RUAMap(pRUA, buf_addr, buf_size);
	if (buf_map == NULL) {
		RMDBGLOG((ENABLE, "Error mapping OSD buffer at 0x%08lX (0x%08lX bytes)\n", buf_addr, buf_size));
		return RM_ERROR;
	}
		
	RMBitmapToRaw(buf_map, NULL, &bfi);
	RMMemcpy(buf_map + bitmap_size, logo_pix, sizeof(logo_pix));
	RMMemcpy(buf_map + bitmap_size + sizeof(logo_pix), circle_pix, sizeof(circle_pix));
	RMMemcpy(buf_map + bitmap_size + sizeof(logo_pix) + sizeof(circle_pix), glyph_points,  sizeof(glyph_points));
	
	RUAUnMap(pRUA, buf_map, buf_size);
	err = RUAUnLock(pRUA, buf_addr, buf_size);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error unlocking OSD buffer at 0x%08lX (0x%08lX bytes)\n", buf_addr, buf_size));
		return err;
	}
	
	RMCloseBitmapFile(&bfi);
	return RM_OK;
}

/* 
   disclaimer: when this function was frist written, readaility was not the 
   main goal, and unfortunately hasn't been rewritten since. work is in progress.
*/
static void gfx_demo_draw_picture(RMuint32 pic_luma, RMuint32 pic_index)
{
	static struct GFXEngine_Surface_type YZ_surface;
	static struct GFXEngine_Surface_type X_surface;
	static struct GFXEngine_ColorFormat_type format;
	static struct GFXEngine_AlphaFormat_type alpha_format;
	static struct GFXEngine_AlphaPalette_type alpha_palette;
	static struct GFXEngine_Palette_2BPP_type color_palette;
	static struct GFXEngine_Palette_1BPP_type color_palette_1bpp;
	static struct GFXEngine_MoveReplaceScaleRectangle_type circle_move;
	static struct GFXEngine_BlendRectangles_type blend;
	static struct GFXEngine_MoveReplaceRectangle_type move;
	static struct GFXEngine_SingleColorBlendRectangles_type sc_blend;
	static RMuint32 last_x[2];
	static RMuint32 last_y[2];
	static RMuint32 x,  y , i;
	static RMint32 x_inc, y_inc, size_inc, alpha_inc;
	static RMuint32 size;
	static RMuint32 state;
	static RMuint8 alpha; 
	static RMuint32 color;
	static RMbool done;

	
	switch(state){
				       
	case 0:/*copy the bitmap on both pictures */

		x = 3, y = 5, i;
		x_inc = 2; 
		y_inc = 1; 
		size_inc  = 3; 
		alpha_inc = 2;
		size = 0;
		state = 0;
		alpha= 0xff; 
		color = 0x0000ff;
		done = FALSE;

		X_surface.SurfaceID = GFX_SURFACE_ID_X;
		X_surface.Tiled = FALSE;


		YZ_surface.StartAddress = bitmap_addr;
		YZ_surface.TotalWidth = bitmap_profile.Width;
		YZ_surface.Tiled = FALSE;


		format.MainMode = bitmap_profile.ColorMode; 
		format.SubMode = bitmap_profile.ColorFormat;
		format.SamplingMode = bitmap_profile.SamplingMode;
		format.ColorSpace = bitmap_profile.ColorSpace;

		format.SurfaceID = GFX_SURFACE_ID_NX;
		SEND_GFX_COMMAND(RMGFXEnginePropertyID_ColorFormat, &format, sizeof(format));

		format.SurfaceID = GFX_SURFACE_ID_Z;
		YZ_surface.SurfaceID = GFX_SURFACE_ID_Z;
		SEND_GFX_COMMAND(RMGFXEnginePropertyID_ColorFormat, &format, sizeof(format));
		SEND_GFX_COMMAND(RMGFXEnginePropertyID_Surface, &YZ_surface, sizeof(YZ_surface));

		format.SurfaceID = GFX_SURFACE_ID_Y;
		YZ_surface.SurfaceID = GFX_SURFACE_ID_Y;
		SEND_GFX_COMMAND(RMGFXEnginePropertyID_ColorFormat, &format, sizeof(format));
		SEND_GFX_COMMAND(RMGFXEnginePropertyID_Surface, &YZ_surface, sizeof(YZ_surface));
			
		circle_move.AlphaX = 0;
		circle_move.AlphaY = 0;
		circle_move.SrcWidth = 32;			
		circle_move.SrcHeight = 32;
		circle_move.DstWidth = 64;
		circle_move.DstHeight = 64;
		circle_move.Merge = TRUE;

		move.AlphaX = 0;
		move.AlphaY = 0;
		move.Merge = FALSE;
				
		sc_blend.SaturateAlpha = 0;
		last_x[0] = last_x[1] = 0;
		last_y[0] = last_y[1] = 0;

	case 1:
		move.Width = bitmap_profile.Width;
		move.Height = bitmap_profile.Height;
		move.SrcX = move.DstX = move.SrcY = move.DstY = 0;
		SEND_GFX_COMMAND( RMGFXEnginePropertyID_MoveRectangle, &move, sizeof(move));
		state++;
		break;
	case 2: /*setup X */
		format.MainMode = bitmap_profile.ColorMode;
		format.SubMode = bitmap_profile.ColorFormat;
		format.SamplingMode = bitmap_profile.SamplingMode;
		format.ColorSpace = bitmap_profile.ColorSpace;


		format.SurfaceID = GFX_SURFACE_ID_X;
		SEND_GFX_COMMAND( RMGFXEnginePropertyID_ColorFormat, &format, sizeof(format));
		X_surface.TotalWidth = bitmap_profile.Width;
		alpha = 0x04;
		state++;

	case 3: /*the sc_blend fade out*/
		X_surface.StartAddress = pic_luma;
		SEND_GFX_COMMAND( RMGFXEnginePropertyID_Surface, &X_surface, sizeof(X_surface));
		size += size_inc; 
		sc_blend.Width =  RMmin(size, bitmap_profile.Width);
		sc_blend.SrcY = sc_blend.DstY =  0;
		sc_blend.Height = bitmap_profile.Height/4;

		for (i = 0; i < 4; i++){
			if(i & 0x1){
				sc_blend.SrcX = RMmax(0,(RMint32)(bitmap_profile.Width-size));
				sc_blend.DstX = RMmax(0,(RMint32)(bitmap_profile.Width-size));
				sc_blend.Color = (alpha<<24)|0x1010ff;
			} else {
				sc_blend.SrcX = 0;
				sc_blend.DstX = 0;
				sc_blend.Color = (alpha<<24)|0xffeeee;
			}
						
			SEND_GFX_COMMAND( RMGFXEnginePropertyID_SingleColorBlendRectangles, &sc_blend, sizeof(sc_blend));
			sc_blend.SrcY += bitmap_profile.Height/4;
			sc_blend.DstY += bitmap_profile.Height/4;
		}

		if (size > bitmap_profile.Width){
			alpha ++;
		}
					
		if (alpha == 0x40){
			size_inc = 8;
			alpha = 0xff;
			size = 0;
			state++;
		}

						
		break;
	case 4:
		YZ_surface.StartAddress = elephant_glyph.OutAddr;
		YZ_surface.TotalWidth = 64;
		YZ_surface.SurfaceID = GFX_SURFACE_ID_Y;
		SEND_GFX_COMMAND( RMGFXEnginePropertyID_Surface, &YZ_surface, sizeof(YZ_surface));

		format.MainMode = EMhwlibColorMode_LUT_1BPP;
		format.SubMode = EMhwlibColorFormat_32BPP;
		format.SamplingMode = EMhwlibSamplingMode_444;
		format.ColorSpace = EMhwlibColorSpace_RGB_0_255;

		format.SurfaceID = GFX_SURFACE_ID_Y;
		SEND_GFX_COMMAND( RMGFXEnginePropertyID_ColorFormat, &format, sizeof(format));
		color_palette_1bpp.SurfaceID = GFX_SURFACE_ID_Y;
		size = 512;
		state++;
	case 5:
		if(size + 100 >= 4096){
			if(done){
				size = 0;
				state++;
				break;
			}
			else
				done = TRUE;
		}
		else
			size += 50;
					
		elephant_glyph.ScaleFactor =  (size * 0x100)/4096;
		move.Width = (size*128)/4096;
		move.Height = (size*128)/4096;
		if(move.Width > YZ_surface.TotalWidth){
			YZ_surface.TotalWidth += 64;
			SEND_GFX_COMMAND( RMGFXEnginePropertyID_Surface, &YZ_surface, sizeof(YZ_surface));
		}
		SEND_GFX_COMMAND( RMGFXEnginePropertyID_GlyphMask, &elephant_glyph, sizeof(elephant_glyph));
		i = 0;
		for (y = 0; y <= bitmap_profile.Height - 128; y += 128){
			if((i++) & 0x1){
				color_palette_1bpp.Palette[0]= 0xff1010ff;
				color_palette_1bpp.Palette[1]= 0xffff8010;
			}
			else {
				color_palette_1bpp.Palette[0]= 0xffffeeee;
				color_palette_1bpp.Palette[1]= 0xff3080ff;
			}
			SEND_GFX_COMMAND( RMGFXEnginePropertyID_Palette_1BPP, &color_palette_1bpp, sizeof(color_palette_1bpp));
						
			for (x = 0; x <= bitmap_profile.Width - 128; x += 128){
				move.DstX = x + (128 - move.Width)/2 ;
				move.DstY = y + (128 - move.Height)/2;
				SEND_GFX_COMMAND( RMGFXEnginePropertyID_ReplaceRectangle, &move, sizeof(move));
			}
		}
		break;

	case 6: 	
		format.MainMode = bitmap_profile.ColorMode;
		format.SubMode = bitmap_profile.ColorFormat;
		format.SamplingMode = bitmap_profile.SamplingMode;
		format.ColorSpace = bitmap_profile.ColorSpace;

		format.SurfaceID = GFX_SURFACE_ID_Y;
		SEND_GFX_COMMAND( RMGFXEnginePropertyID_ColorFormat, &format, sizeof(format));
					
		YZ_surface.TotalWidth = bitmap_profile.Width;
		YZ_surface.StartAddress = bitmap_addr;
		YZ_surface.SurfaceID = GFX_SURFACE_ID_Y;
		SEND_GFX_COMMAND( RMGFXEnginePropertyID_Surface, &YZ_surface, sizeof(YZ_surface));
		state++;

	case 7:
		/*bring the bitmap back vertically*/
		size += size_inc;

		move.Width = bitmap_profile.Width/8;
		move.Height = size;
		move.DstX = 0;
		move.SrcX = 0;
		for ( i=0; i< 8; i++){
			if((i & 0x1)){
				move.DstY = bitmap_profile.Height - size;
				move.SrcY = 0;
			}
			else{
				move.DstY = 0;
				move.SrcY = bitmap_profile.Height - size;
			}
			SEND_GFX_COMMAND( RMGFXEnginePropertyID_MoveRectangle, &move, sizeof(move));
			move.DstX += bitmap_profile.Width/8;
			move.SrcX += bitmap_profile.Width/8;
		}
		if (size + size_inc > bitmap_profile.Height){
			state++;
		}

		break;

	case 8:
	case 9:
		move.Width = bitmap_profile.Width;
		move.Height = bitmap_profile.Height;
		move.SrcX = move.DstX = move.SrcY = move.DstY = 0;
		SEND_GFX_COMMAND( RMGFXEnginePropertyID_MoveRectangle, &move, sizeof(move));
		state++;
		break;
					
	case 10:
		move.Width = move.Height = 64;

		blend.DstX = blend.Src2X = bitmap_profile.Width - logo_profile.Width - 30;
		blend.DstY =  blend.Src2Y = 30;

		blend.Src1X = 0;
		blend.Src1Y = 0;
		blend.SaturateAlpha = FALSE;
		blend.Width = logo_profile.Width;
		blend.Height = logo_profile.Height;
		alpha_inc = 2;
		x = 5;
		y = 12;
		YZ_surface.StartAddress = bitmap_addr;
		YZ_surface.TotalWidth = bitmap_profile.Width;
		YZ_surface.SurfaceID = GFX_SURFACE_ID_Z;
		SEND_GFX_COMMAND( RMGFXEnginePropertyID_Surface, &YZ_surface, sizeof(YZ_surface));

		format.MainMode = bitmap_profile.ColorMode;
		format.SubMode = bitmap_profile.ColorFormat;
		format.SamplingMode = bitmap_profile.SamplingMode;
		format.ColorSpace = bitmap_profile.ColorSpace;

		format.SurfaceID = GFX_SURFACE_ID_Z;
		SEND_GFX_COMMAND( RMGFXEnginePropertyID_ColorFormat, &format, sizeof(format));

		state++;
	case 11: 
		YZ_surface.StartAddress = bitmap_addr;
		YZ_surface.TotalWidth = bitmap_profile.Width;
		YZ_surface.SurfaceID = GFX_SURFACE_ID_Y;
		SEND_GFX_COMMAND( RMGFXEnginePropertyID_Surface, &YZ_surface, sizeof(YZ_surface));

		format.MainMode = bitmap_profile.ColorMode;
		format.SubMode = bitmap_profile.ColorFormat;
		format.SamplingMode = bitmap_profile.SamplingMode;
		format.ColorSpace = bitmap_profile.ColorSpace;

		format.SurfaceID = GFX_SURFACE_ID_Y;
		SEND_GFX_COMMAND( RMGFXEnginePropertyID_ColorFormat, &format, sizeof(format));

		move.SrcX = move.DstX = last_x[pic_index];
		move.SrcY = move.DstY = last_y[pic_index];
		SEND_GFX_COMMAND( RMGFXEnginePropertyID_MoveRectangle, &move, sizeof(move));

		format.MainMode = bitmap_profile.ColorMode;
		format.SubMode = bitmap_profile.ColorFormat;
		format.SamplingMode = bitmap_profile.SamplingMode;
		format.ColorSpace = bitmap_profile.ColorSpace;

		format.SurfaceID = GFX_SURFACE_ID_X;
		SEND_GFX_COMMAND( RMGFXEnginePropertyID_ColorFormat, &format, sizeof(format));

		X_surface.StartAddress = bitmap_addr;
		X_surface.TotalWidth = bitmap_profile.Width;
		SEND_GFX_COMMAND( RMGFXEnginePropertyID_Surface, &X_surface, sizeof(X_surface));

		YZ_surface.StartAddress = logo_addr;
		YZ_surface.TotalWidth = logo_profile.Width;
		YZ_surface.SurfaceID = GFX_SURFACE_ID_Y;
		SEND_GFX_COMMAND( RMGFXEnginePropertyID_Surface, &YZ_surface, sizeof(YZ_surface));

		format.MainMode = logo_profile.ColorMode;
		format.SubMode = logo_profile.ColorFormat;
		format.SamplingMode = logo_profile.SamplingMode;
		format.ColorSpace = logo_profile.ColorSpace;

		format.SurfaceID = GFX_SURFACE_ID_Y;
		SEND_GFX_COMMAND( RMGFXEnginePropertyID_ColorFormat, &format, sizeof(format));
		color_palette.SurfaceID = GFX_SURFACE_ID_Y;
		color_palette.Palette[2]= (0xff<<24) | (alpha<<16)|(alpha<<8)|alpha/4;
		color_palette.Palette[1]= 0x0;
		color_palette.Palette[0]= (alpha<<24) | color;
		alpha -= ( alpha > alpha_inc) ? alpha_inc:0;

		SEND_GFX_COMMAND( RMGFXEnginePropertyID_Palette_2BPP, &color_palette, sizeof(color_palette));

		SEND_GFX_COMMAND( RMGFXEnginePropertyID_BlendRectangles, &blend, sizeof(blend));

		YZ_surface.StartAddress = bitmap_addr;
		YZ_surface.TotalWidth = bitmap_profile.Width;
		YZ_surface.SurfaceID = GFX_SURFACE_ID_Z;
		SEND_GFX_COMMAND( RMGFXEnginePropertyID_Surface, &YZ_surface, sizeof(YZ_surface));

		format.MainMode = bitmap_profile.ColorMode;
		format.SubMode = bitmap_profile.ColorFormat;
		format.SamplingMode = bitmap_profile.SamplingMode;
		format.ColorSpace = bitmap_profile.ColorSpace;

		format.SurfaceID = GFX_SURFACE_ID_Z;
		SEND_GFX_COMMAND( RMGFXEnginePropertyID_ColorFormat, &format, sizeof(format));
					
		X_surface.StartAddress = circle_addr;
		X_surface.TotalWidth = circle_profile.Width;

		SEND_GFX_COMMAND( RMGFXEnginePropertyID_Surface, &X_surface, sizeof(X_surface));

		alpha_format.AlphaFormat = GFX_ALPHA_FORMAT_LUT_1BPA;
		SEND_GFX_COMMAND( RMGFXEnginePropertyID_AlphaFormat, &alpha_format, sizeof(alpha_format ));
					
		alpha_palette.Alpha0 = 0x00;
		alpha_palette.Alpha1 = 0xff;
		alpha_palette.SurfaceID = GFX_SURFACE_ID_X;
		SEND_GFX_COMMAND( RMGFXEnginePropertyID_AlphaPalette, &alpha_palette, sizeof(alpha_palette));
						
		x += x_inc;
		y += y_inc;
		if ((x >= (bitmap_profile.Width - circle_move.DstWidth - x_inc)) || (x <=1)){
			color += 0x886010;
			color &= 0xffffff;
			alpha = 0xff;
			x_inc *= -1;
		}
		if ((y >= (bitmap_profile.Height - circle_move.DstHeight - y_inc)) || (y <=1)){
			color += 0x102066;
			color &= 0xffffff;
			alpha = 0xff;
			y_inc *= -1;
		}
		circle_move.DstX = last_x[pic_index] = (x % (bitmap_profile.Width-64));
		circle_move.DstY = last_y[pic_index] = (y % (bitmap_profile.Height-64));
		circle_move.SrcX = circle_move.DstX + 16;
		circle_move.SrcY = circle_move.DstY + 16;
		SEND_GFX_COMMAND( RMGFXEnginePropertyID_ReplaceAndScaleRectangle, &circle_move, sizeof(circle_move));
		break;
					
					
	}
}

int main(int argc, char *argv[])
{
	struct DCC *pDCC = NULL;
	struct DCCVideoSource *pVideoSource;
	struct dh_context dh_info = {0,};
	struct GFXEngine_Open_type gfx_profile;
	RMuint32 close_profile;

	RMuint32 pic_luma_addr[2], pic_addr[2], pic_index = 0, surface_addr;
	
	

	RMstatus err;
	init_display_options(&disp_opt);
	init_video_options(&video_opt);
	init_playback_options(&play_opt);
	disp_opt.dh_info = &dh_info;
	parse_cmdline(argc, argv);

	err = RUACreateInstance(&pRUA, play_opt.chip_num);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error creating RUA instance! %d\n", err);
		return err;
	}
	
	err = DCCOpen(pRUA, &pDCC);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error Opening DCC! %d\n", err);
		return err;
	}

	err = DCCInitMicroCodeEx(pDCC, disp_opt.init_mode);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot initialize microcode %d\n", err);
		return err;
	}
	
	dcc_info.pRUA = pRUA;
 	dcc_info.pDCC = pDCC;
	dcc_info.route = DCCRoute_Main;

	
	err = apply_display_options(&dcc_info, &disp_opt);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot set display options %d\n", err);
		return err;
	}


	/* the mixer should not modify the GFX scaler's config */
	{
		enum EMhwlibMixerSourceState state;
		RMuint32 mixer, scaler, src_index, mixer_src;

		mixer = EMHWLIB_MODULE(DispMainMixer, 0);
		scaler= EMHWLIB_MODULE(DispOSDScaler,0);
		/* set a NULL surface, this will force a full register update when next surface is set */
		err = DCCSetSurfaceSource(dcc_info.pDCC, scaler, NULL);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot unset gfx scaler's surface\n");
			goto cleanup;
		}

		err = RUAExchangeProperty(dcc_info.pRUA, mixer, RMGenericPropertyID_MixerSourceIndex, &scaler, sizeof(scaler), &src_index, sizeof(src_index));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot get scaler index\n"));
			goto cleanup;
		}

		mixer_src = EMHWLIB_TARGET_MODULE(mixer, 0 , src_index );
		state = EMhwlibMixerSourceState_Slave;

		while((err =  RUASetProperty(dcc_info.pRUA, mixer_src, RMGenericPropertyID_MixerSourceState, &state, sizeof(state), 0))==RM_PENDING);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set scaler's state on mixer\n"));
			goto cleanup;
		}

		while ((err = RUASetProperty(dcc_info.pRUA, mixer, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot validate mixer\n");
			goto cleanup;
		}

		do{
			err = RUAGetProperty(dcc_info.pRUA, mixer_src, RMGenericPropertyID_MixerSourceState, &state, sizeof(state));
			if(RMFAILED(err)){
				RMDBGLOG((ENABLE, "error getting source state %s\n", RMstatusToString(err)));
			}
			/* this is just to avoid busy loops, can be substituted by a sleep function or removed */
			if(state != EMhwlibMixerSourceState_Slave){
				struct RUAEvent evt;

				evt.ModuleID = EMHWLIB_MODULE(DisplayBlock, 0);
				evt.Mask = EMHWLIB_DISPLAY_EVENT_ID(mixer);

				err = RUAWaitForMultipleEvents(dcc_info.pRUA, &evt, 1, TIMEOUT_US, NULL);
				if(RMFAILED(err)){
					RMDBGLOG((ENABLE, "wait for display update event completion failed, %s\n", RMstatusToString(err)));
				}
			}
		}while(state != EMhwlibMixerSourceState_Slave);

	}
	{

		// open first stc module
		struct DCCStcProfile stc_profile;
		
		stc_profile.STCID = 0;
		stc_profile.master = Master_STC;
	
		stc_profile.stc_timer_id = 0;
		stc_profile.stc_time_resolution = 90000;
		
		stc_profile.video_timer_id = 1;
		stc_profile.video_time_resolution = 90000;
		stc_profile.video_offset = 0;
		
		stc_profile.audio_timer_id = NO_TIMER;
		stc_profile.audio_time_resolution = 0;
		stc_profile.audio_offset = 0;
		

		err = DCCSTCOpen(dcc_info.pDCC, &stc_profile, &dcc_info.pStcSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot open stc module %d\n", err));
			goto cleanup;
		}

		err = DCCSTCSetTime(dcc_info.pStcSource,  0, 90000);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot insert picture inside surface %d\n", err);
			goto cleanup;
		}
		err = DCCSTCSetSpeed(dcc_info.pStcSource, 1, inv_speed);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot insert picture inside surface %d\n", err);
			goto cleanup;
		}
	
	}
	
	err = load_bitmaps();
	if (RMFAILED(err)) {
		fprintf(stderr, "Error loading bitmaps %d\n", err);
		goto cleanup;
	}
	
/* 	if(EMHWLIB_MODULE_CATEGORY(scalers[0]) == DispVideoPlane){ */
/* 		struct EMhwlibTVFormatAnalog tv_format; */
/* 		err = RUAExchangeProperty(pRUA, DisplayBlock, RMDisplayBlockPropertyID_TVFormatAnalog, &(disp_opt->standard), sizeof(disp_opt->standard), &tv_format, sizeof(tv_format)); */
/* 		if (RMFAILED(err)) { */
/* 			fprintf(stderr, "Cannot get TV format %d\n", err); */
/* 			goto cleanup; */
/* 		} */
/* 		mosaic_width = tv_format.ActiveWidth; */
/* 		mosaic_height = tv_format.ActiveHeight; */
/* 		fprintf(stderr, "active width %ld, active height %ld\n", tv_format.ActiveWidth, tv_format.ActiveHeight); */

/* 	} */

	
	
	/* open a video source with two pictures */
		
	
	err = DCCOpenMultiplePictureOSDVideoSource(dcc_info.pDCC, &bitmap_profile, 2, &(pVideoSource), dcc_info.pStcSource );
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot open OSD decoder %d\n", err);
		goto cleanup;
	}

	err = DCCGetOSDSurfaceInfo(dcc_info.pDCC, pVideoSource, NULL, &surface_addr, NULL);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot get surface address %d\n", err);
		goto cleanup;
	}

	err = DCCGetOSDPictureInfo(pVideoSource, 0, &(pic_addr[0]),  &(pic_luma_addr[0]), NULL, NULL, NULL);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot get osd buffer info %d\n", err);
		goto cleanup;
	}

	err = DCCGetOSDPictureInfo(pVideoSource, 1, &(pic_addr[1]), &(pic_luma_addr[1]), NULL, NULL, NULL);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot get osd buffer info %d\n", err);
		goto cleanup;
	}
	
	/* works only for tango2 */
	if (multiple_readers) {
#ifdef RMFEATURE_HAS_VIDEOPLANE
		err = init_scaler(pDCC, pRUA, pVideoSource, EMHWLIB_MODULE(DispVideoPlane,0));
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot set VideoPlane %d\n", err);
			goto cleanup;
		}
#endif
			
#ifdef RMFEATURE_HAS_VCR_SCALER
		err = init_scaler(pDCC, pRUA, pVideoSource, EMHWLIB_MODULE(DispVCRMultiScaler,0));
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot set vcr scaler %d\n", err);
			goto cleanup;
		}
#endif
	}
		
	/* set OSD last. so it it cleared when DCCCloseVideoSource */
	err = init_scaler(pDCC, pRUA, pVideoSource, scalers[0]);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot set osd scaler %d\n", err);
		goto cleanup;
	}

	err = DCCClearOSDPicture(pVideoSource, 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot clear OSD\n");
		goto cleanup;
	}

	err = DCCInsertPictureInMultiplePictureOSDVideoSource(pVideoSource, 0, 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot insert picture inside surface %d\n", err);
		goto cleanup;
	}





	/* init the gfx_engine */
	{
		RMuint32 chip_num;
		RMuint32 gfx_count; 
		
		struct GFXEngine_DRAMSize_in_type  dramSizeIn;
		struct GFXEngine_DRAMSize_out_type dramSizeOut;
		RMint32 i;
		
		chip_num = 0;
		
		dramSizeIn.CommandFIFOCount = 10;
		err = RUAExchangeProperty(pRUA, EMHWLIB_MODULE(GFXEngine,0), RMGFXEnginePropertyID_DRAMSize,
					  &dramSizeIn, sizeof(dramSizeIn), &dramSizeOut, sizeof(dramSizeOut));
		if (RMFAILED(err)) {
			fprintf(stderr, "Error getting dram size for gfx engine\n");
			goto cleanup;
		}
		
		gfx_profile.CommandFIFOCount = dramSizeIn.CommandFIFOCount;
		gfx_profile.Priority = 1;
		gfx_profile.CachedSize = dramSizeOut.CachedSize;
		gfx_profile.UncachedSize = dramSizeOut.UncachedSize;
	
		if (gfx_profile.CachedSize > 0) {
			gfx_profile.CachedAddress = RUAMalloc(pRUA, 0, RUA_DRAM_CACHED, gfx_profile.CachedSize);
		} else {
			gfx_profile.CachedAddress = 0;
		}
		
		gfx_profile.UncachedSize = dramSizeOut.UncachedSize;
		if (gfx_profile.UncachedSize > 0) {
			gfx_profile.UncachedAddress = RUAMalloc(pRUA, 0, RUA_DRAM_UNCACHED, gfx_profile.UncachedSize);
		} else {
			gfx_profile.UncachedAddress = 0;
		}
		gfx = GFXEngine;
		
		err = RUAExchangeProperty(pRUA, EMHWLIB_MODULE(Enumerator,0),  RMEnumeratorPropertyID_CategoryIDToNumberOfInstances, 
					  &gfx, sizeof(gfx), &gfx_count, sizeof(gfx_count));
		if (RMFAILED(err)) {
			fprintf(stderr, "Error getting gfx engine count\n");
			goto cleanup;
		}
			
		for (i=0 ; i<(RMint32) gfx_count ; i++) {
			gfx = EMHWLIB_MODULE(GFXEngine, i);
			err = RUASetProperty(pRUA, gfx, RMGFXEnginePropertyID_Open, &gfx_profile, sizeof(gfx_profile), 0);
			if (err == RM_OK) 
				break;
		}
		if (i==(RMint32)gfx_count) {
			fprintf(stderr, "Cannot open a gfx engine [0..%lu[\n", gfx_count);
			goto cleanup;
		}
	}//*/


	err = DCCSTCPlay(dcc_info.pStcSource);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot insert picture inside surface %d\n", err);
		goto cleanup;
	}
		

	{
		struct GFXEngine_Surface_type NX_surface;
		struct GFXEngine_DisplayPicture_type display_pic;

		NX_surface.SurfaceID = GFX_SURFACE_ID_NX;
		NX_surface.TotalWidth = bitmap_profile.Width;
		NX_surface.Tiled = FALSE;

		
		RMTermInit(TRUE);
		RMSignalInit(NULL, NULL);

		/* wait for the picture to be on display. This is the correct way to make the 
		   next double buffering implementation work 100%
		*/
		{
			struct RUAEvent e;
			RMuint32 index;
				
			e.ModuleID = EMHWLIB_MODULE(DisplayBlock, 0);
			e.Mask = EMHWLIB_DISPLAY_NEW_PICTURE_EVENT_ID(DispOSDScaler);
			err = RUAWaitForMultipleEvents(pRUA, &e, 1, 1000000, &index);
			if (err == RM_ERROR) {
				fprintf(stderr, "cannot wait for the picture to be on display\n");
				goto cleanup;
			}
		}
		pic_index = 0;
		display_pic.Pts = 0;

		while(!end){
			pic_index++;
			pic_index &= 0x1;
			/*block until the picture we're editing it's released*/
			SEND_GFX_COMMAND( RMGFXEnginePropertyID_WaitForPicture, &(pic_addr[pic_index]), sizeof(pic_addr[pic_index]));

			/* setup NX to point to the picture we're editing */
			NX_surface.StartAddress = pic_luma_addr[pic_index];
			SEND_GFX_COMMAND( RMGFXEnginePropertyID_Surface, &NX_surface, sizeof(NX_surface));

			/* edit the picture */
			gfx_demo_draw_picture(pic_luma_addr[pic_index], pic_index);

			/* display the picture */
			display_pic.Surface = surface_addr;
			display_pic.Picture = pic_addr[pic_index];
			display_pic.Pts += 1800;
			SEND_GFX_COMMAND( RMGFXEnginePropertyID_DisplayPicture, &display_pic, sizeof(display_pic));

			update_hdmi(&dcc_info, &disp_opt, NULL);
		}
	}
	

 cleanup:
	RMTermExit();
	if(buf_addr)
		RUAFree(pRUA, buf_addr);
	if(elephant_glyph.OutAddr)
		RUAFree(pRUA, elephant_glyph.OutAddr);
	
	err = RUASetProperty(pRUA, gfx, RMGFXEnginePropertyID_Close, &close_profile, sizeof(close_profile), 0);
	if (RMFAILED(err)) fprintf(stderr, "Cannot close the gfx accelerator\n");
		
	if(gfx_profile.CachedAddress)		
		RUAFree(pRUA, gfx_profile.CachedAddress);
		
	if(gfx_profile.UncachedAddress)		
		RUAFree(pRUA, gfx_profile.UncachedAddress);

	clear_display_options(&dcc_info, &disp_opt);

	err = DCCCloseVideoSource(pVideoSource);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot close osd source %s\n", RMstatusToString(err)));
		goto cleanup;
	}

	if (multiple_readers) {
		RMuint32 surface = 0;
#ifdef RMFEATURE_HAS_VIDEOPLANE
		RUASetProperty(pRUA, DispVideoPlane, RMGenericPropertyID_Surface, &surface, sizeof(surface), 0);
#endif
#ifdef RMFEATURE_HAS_VCR_SCALER
		RUASetProperty(pRUA, DispVCRMultiScaler, RMGenericPropertyID_Surface, &surface, sizeof(surface), 0);
#endif
		/* to avoid compilation warning */
		surface ++;
	}

	err = DCCClose(pDCC);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot close DCC %d\n", err);
		goto cleanup;
	}

	err = RUADestroyInstance(pRUA);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot destroy RUA instance %d\n", err);
		goto cleanup;
	}

	return 0;

}

 
