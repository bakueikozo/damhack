/*****************************************
 Copyright � 2006
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   play_psfdemux_helper.h
  @brief  
  
  Helper function for play_psfdemux

  @author Julien Lerouge
  @date   2006-02-14
*/
#ifndef __PSFDEMUX_DCC_X__
#define __PSFDEMUX_DCC_X__

#include "rmdef/rmdef.h"
#include "dcc/include/dcc.h"

struct PSFDemuxTaskProfile {
	RMuint32 ProtectedFlags;
	RMuint32 BitstreamFIFOSize;
 	RMuint32 XferFIFOCount;
 	RMuint32 InbandFIFOCount;
	
 	RMuint32 InputPort;
 	RMuint32 PrimaryMPM;
 	RMuint32 SecondaryMPM;

	RMuint32 DemuxTaskID;

	RMuint32 XTaskModuleId;
	RMuint32 XTaskContext;
	RMuint32 XTaskInbandFIFOCount;
};

RMstatus PSFOpenDemuxTask(struct DCC *pDCC, 
			  struct PSFDemuxTaskProfile *dcc_profile,
			  struct DCCDemuxTask **ppDemuxTask);

#endif /* __PSFDEMUX_DCC_X__ */
