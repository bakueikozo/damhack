/*****************************************
 Copyright © 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   cmdline_options.h
  @brief  

  Structs, init and parse functions for the options given
  to the sample apps.
  
  @author Oriol Prieto
  @date   2005-03-16
*/

#ifndef __CMDLINE_OPTIONS_H__
#define __CMDLINE_OPTIONS_H__

#ifndef ALLOW_OS_CODE
#define ALLOW_OS_CODE
#endif 
#include "rmdef/rmdef.h"

RM_EXTERN_C_BLOCKSTART


enum disk_control_state {
	DISK_CONTROL_STATE_DISABLE,
	DISK_CONTROL_STATE_SLEEPING,
	DISK_CONTROL_STATE_RUNNING
};

enum disk_control_action {
	DISK_CONTROL_ACTION_SLEEP,
	DISK_CONTROL_ACTION_RUN,
	DISK_CONTROL_ACTION_RUN_NOWAIT
};

typedef RMstatus (*RMDiskControl)(const enum disk_control_action action);

struct osd_picture_info{
	RMbool enable;
	RMbool alpha_merge;
	RMascii *filename;
	RMascii *alpha_filename;
	RMuint32 dramblock;
	RMuint32 alpha;
	RMbool zoom;
	enum EMhwlibColorSpace color_space;
	RMuint32 scaler;
	enum DCCRoute route;
	struct EMhwlibDisplayWindow source_window;
	struct EMhwlibDisplayWindow output_window;
	enum PictureOrientation orientation;
	struct EMhwlibNonLinearScalingMode nonlinearmode;
	struct EMhwlibBlackStripMode blackstrip;
	struct EMhwlibCutStripMode cutstrip;
	RMuint32 lock_scaler;
};

// For ActiveFormat calculations:
struct active_format_context {
	RMuint32 MixerModuleID;  // module ID of the route's mixer
	struct EMhwlibActiveFormatDescription MixerAFD;  // active format description of the outputs connected to MixerModuleID
	RMbool MixerVariableAR; 
	RMuint32 HDSDModuleID;  // module ID of the HD->SD downconverter, if active, otherwise 0
	struct EMhwlibActiveFormatDescription HDSDAFD;  // active format description of the outputs connected to HDSDModuleID
	RMbool HDSDVariableAR;
};

struct display_cmdline {
	RMbool configure_outports;
	RMuint32 video_scaler;
	RMuint32 video_alpha;
	enum EMhwlibTVStandard standard;
	enum EMhwlibTVStandard sd_standard;
	enum EMhwlibTVStandard sd_standard_50Hz;
	enum EMhwlibTVStandard sd_standard_60Hz;
	RMbool use_hdsd_conversion;
	RMbool allow_otf;
	RMbool allow_buf;
	RMbool sd_component;
	RMbool sd_autodetect;
	RMbool sd_cav_1080p;  // allow 1080p on component out

	RMascii vidmode_filename[2048];
	enum EMhwlibTVStandard vga_standard;
	enum DCCVideoConnector connector;
	enum EMhwlibComponentMode component;
	enum EMhwlibColorSpace color_space;  // output color space
	enum EMhwlibColorSpace mixer_color_space;
	RMuint32 bus_size;
	RMuint32 ar_x;
	RMuint32 ar_y;
	RMbool active_format_valid;
	enum EMhwlibActiveFormat active_format;
	RMuint32 sd_ar_x;
	RMuint32 sd_ar_y;
	RMbool sd_active_format_valid;
	enum EMhwlibActiveFormat sd_active_format;
	RMuint32 target_ar_x;
	RMuint32 target_ar_y;
	struct active_format_context afd_info;
	struct EMhwlibDisplayWindow source_window;
	struct EMhwlibDisplayWindow output_window;
	struct osd_picture_info osd_pictures[2];
	RMuint32 agc_level;          /* macrovision pulses 0, 1, 2, 3. Usually is same value as aps. */
	RMuint32 agc_version;        /* one of AGC_VERSION_0_CONSTANT_BPP or AGC_VERSION_1_ALTERNATE_BPP  */
	RMuint32 aps_level;          /* analog protection system */
	RMuint32 cgmsa;              /* copy generation management system 0, 1, 2, 3 */
	RMuint32 rcd;                /* redistribution control descriptor */
	RMuint32 asb;                /* analog source bit */
	RMascii *dump_osd_dir;

	enum EMhwlibComponentOrder component_order;
	enum EMhwlibScalerFieldSelection field_selection;
	enum DH_device_state dvi_hdmi_state;
	enum DH_vendor_parts dvi_hdmi_part;
	RMbool dvi_hdmi_hdcp;
	RMbool dvi_hdmi_display_edid;
	RMuint32 dvi_hdmi_edid_vfreq;  // preferred vsync frequency (50, 59, 60 etc.)
	RMuint32 dvi_hdmi_edid_hsize;  // preferred horizontal active size
	RMuint32 dvi_hdmi_edid_vsize;  // preferred vertical active size
	RMbool dvi_hdmi_edid_intl;     // preferred interlaced (TRUE) / progressive (FALSE) mode
	RMuint64 edid_exclude_mask;    // which VICs to exclude
	RMuint64 edid_exclude_mask_vfreq;
	RMuint64 edid_exclude_mask_asp;
	RMuint64 edid_force_mask;      // which VICs to prefer
	RMuint64 edid_force_mask_vfreq;
	RMuint64 edid_force_mask_asp;
	RMuint32 edid_max_pixclk;      // minimal pixel clock of the source, 0 = disable limit
	RMuint32 edid_min_pixclk;      // maximum pixel clock of the source, 0 = disable limit
	RMuint32 edid_max_hfreq;       // minimal horizontal frequency of the source, 0 = disable limit
	RMuint32 edid_min_hfreq;       // maximum horizontal frequency of the source, 0 = disable limit
	RMuint32 edid_max_vfreq;       // minimal vertical frequency of the source, 0 = disable limit
	RMuint32 edid_min_vfreq;       // maximum vertical frequency of the source, 0 = disable limit
	RMbool hdmi_monitor;  // TRUE: HDMI monitor/TV, FALSE: DVI monitor (no AVI frames, no audio)
	RMbool hdmi_force;  // TRUE: force hdmi_monitor state, FALSE: determine hdmi_monitor state from monitor EDID
	enum DH_EDID_select edid_sel;
	enum DH_EDID_select vga_edid_sel;
	RMuint32 dvi_hdmi_edid_descriptor; // 0: use default descr., 1 or higher: use specific short descriptor from EDID
	RMbool dvi_hdmi_edid_write;     // program content of a file into display's EDID EEPROM
	RMbool dvi_hdmi_edid_read;      // read display's EDID into a file
	RMbool dvi_hdmi_edid_override;  // use content of a file instead of display's EDID
	RMascii *dvi_hdmi_edid_file;    // file name for previous three settings
	struct EMhwlibNonLinearScalingMode nonlinearmode;
	struct EMhwlibBlackStripMode blackstrip;
	struct EMhwlibCutStripMode cutstrip;
	enum EMhwlibScalingMode scalingmode;
	enum EMhwlibDeinterlacingMode deinterlacingmode;
	struct DispMainVideoScaler_DeinterlacingMotionConfig_type deinterlacing_motion_config;
	struct DispMainVideoScaler_DeinterlacingProportion_type deinterlacing_proportion;
	struct EMhwlibLumaKeying luma_key;
	RMuint32 lock_scaler;
	RMbool do_pulldown;
	RMuint32 color_degradation_boundary;
	RMbool show_hwc;
	enum DCCInitMode init_mode;
	enum EMhwlibDigitalTimingSignal dig_protocol;
	RMbool dig_force_doublerate;
	RMbool dig_doublerate;
	RMbool dig_clk_normal;
	RMbool dig_ddr;
	RMbool dig_inv_cap_clk;
	RMuint32 dig_delay;
	RMbool dig_force_delay;
	RMbool dig_vsync_delay;
	RMbool dig_trailing_edge;
	RMbool chroma_sync;
	RMbool scart_enable;
	RMuint32 scart_en_pio;
	RMbool scart_widescreen;
	RMuint32 scart_ws_pio;
	struct dh_context *dh_info;
	RMbool dh_first_run;
	RMuint32 i2c_module;
	RMuint32 i2c_speed;
	RMbool i2c_ddc_on_tx;
	RMuint32 dvi_reset_gpio;
	RMbool hdmi_de;
	RMbool hdmi_active_format_valid;
	enum DH_active_format_aspect_ratio hdmi_active_format;
	RMuint32 hdmi_bar_top;
	RMuint32 hdmi_bar_bottom;
	RMuint32 hdmi_bar_left;
	RMuint32 hdmi_bar_right;
	enum EMhwlibScanInfo hdmi_scan;
	RMascii *hdmi_spd_vendor;
	RMascii *hdmi_spd_product;
	enum DH_source_dev_info hdmi_spd_class;
	RMuint32 tmds_threshold;
	enum GPIOId_type tmds_gpio;
	enum GPIOId_type filter_gpio_start;
	RMuint32 filter_gpio_num;
	RMuint32 filter_gpio_val;
	RMbool force_route;
	enum DCCRoute route;
	RMuint32 genlock_input;  // Input ModuleID of sync source
	RMuint8 genlock_min;  // min phase
	RMuint8 genlock_max;  // max phase
	RMuint32 input;
	struct DCCVideoSource *input_videosource;
	enum EMhwlibTVStandard input_mode;
	enum EMhwlibDigitalTimingSignal input_timingsignal;
	RMbool input_vvld;
	RMuint32 input_bussize;
	RMbool input_invv;
	RMbool input_invh;
	RMbool input_usev2;
	RMbool input_interlaced;
	struct EMhwlibDisplayTimeInterval time_interval;
	RMbool force_DACCompDisable;
	RMbool DACCompDisable;
	RMbool force_DACDisable;
	struct EMhwlibDACDisable DACDisable;
	RMbool force_LumaChromaDelay;
	enum EMhwlibLumaChromaDelay LumaChromaDelay;
	RMbool force_TripleCVBS;
	RMbool TripleCVBS;
	RMbool force_LineCrop;
	struct EMhwlibLineCrop LineCrop;
	RMuint32 gamma_table;
	RMbool disable_pixel_timer;
	RMbool hdmi_convert;
	enum EMhwlibColorSpace hdmi_color_space;
	enum EMhwlibSamplingMode hdmi_sampling_mode;
	RMuint32 hdmi_component_depth;
	struct EMhwlibDownScalingMode downscalingmode;
	struct DispMainVideoScaler_FilterSelection_type filtermode;
};

struct capture_cmdline {
	enum EMhwlibTVStandard TVStandard;
	RMbool guess;  // guess the TV standard
	RMuint32 dram;  // number of the DRAM bank to use
	enum EMhwlibColorSpace InputColorSpace;
	enum EMhwlibColorSpace SurfaceColorSpace;
	enum EMhwlibSamplingMode SamplingMode;
	enum EMhwlibColorMode ColorMode;
	enum EMhwlibInputColorFormat InputColorFormat;
	RMuint32 InputModuleID;
	enum EMhwlibDigitalTimingSignal DigitalTimingSignal;
	RMbool UseVideoValid;
	RMuint32 bussize;
	RMbool DualEdge;
	RMbool DualEdgeWidth;
	RMbool DualEdgeInvert;
	RMbool InvertVSync;
	RMbool InvertHSync;
	RMint32 over_pos_x;  // shifting of the capture frame on the input field
	RMint32 over_pos_y;
	RMuint32 over_width;  // how much to add for overscan capture
	RMuint32 over_height;
	// intermediate params to calc over_xxx
	RMint32 shift_x;  // shifting of the capture frame on the input field
	RMint32 shift_y;
	RMuint32 ov_top;  // how much to add for overscan capture
	RMuint32 ov_bot;
	RMuint32 ov_lft;
	RMuint32 ov_rgt;
	struct EMhwlibAspectRatio PictureAspectRatio; 
	struct EMhwlibAspectRatio PixelAspectRatio; 
	RMbool DeInt;
	RMuint32 vbi_x;
	RMuint32 vbi_y;
	RMuint32 vbi_w;
	RMuint32 vbi_h;
	RMuint32 vbiraw_topstart;
	RMuint32 vbiraw_topmask;
	RMuint32 vbiraw_botstart;
	RMuint32 vbiraw_botmask;
	RMbool vbianc_enable;
	RMuint32 vbianc_w;
	RMuint32 vbianc_h;
	RMuint32 vbianc_ytop;
	RMuint32 vbianc_ybot;
	RMuint32 vbi_buf;
	RMuint32 vbi_size;
	RMbool vbi_dma;
	RMbool UseV2Pads;
	RMbool disablescaler;
	struct EMhwlibPictureOverride override;
	RMbool audio_free_run;
	RMuint64 AudioGuardTime;
};

struct video_cmdline {
	RMuint32 MpegEngineID;
	RMuint32 VideoDecoderID;
	enum MPEG_Profile MPEGProfile;
	enum VideoDecoder_Codec_type Codec;
	struct VideoDecoder_VopInfo_type VopInfo;
	struct VideoDecoder_VideoTimeScale_type vtimescale;
	RMuint8 dram;
	enum EMhwlibColorSpace input_color_space;
	RMbool force_input_color_space;
	enum EMhwlibScanMode input_scan_mode;
	RMbool display_ttx;
	RMbool display_cc;
	RMuint32 use_soft_cc_decoder;
	enum EMhwlibCCSelect cc_select;
	RMuint32 fifo_size;
	RMuint32 xfer_count;

	enum EMhwlibVideoCodec vcodec;
	RMuint32 vcodec_profile;
	RMuint32 vcodec_level;
	RMuint32 vcodec_max_width;
	RMuint32 vcodec_max_height;
	RMint32 vcodec_extra_pictures;
	RMuint32 vcodec_orientation;

	RMuint32 wmv9_seq;
	RMbool MSflag;
	RMbool auto_detect_codec;
	RMuint32 display_error_threshold;
	struct VideoDecoder_AnchorErrPropagation_type anchor_error_parms;
	RMuint32 interlaced_progressive_algorithm;

	RMbool lowdelay;
	RMbool UseAFD;
	RMbool ForceAFD;
	RMuint32 AFDTransition;
	struct EMhwlibActiveFormatDescription afd;

	RMint64 first_pts_in_stream;
	RMbool skipNCP;
};

struct audio_cmdline {
	RMuint32 AudioEngineID;
	RMuint32 AudioDecoderID;
	enum AudioDecoder_Codec_type Codec;
	RMuint32 SubCodec;
	RMuint32 SampleRate;
	RMuint32 SamplingFrequency;	/* input frequency of the audio stream. Used only for pcm files */
	RMbool ForceSampleRate;
	RMuint32 CaptureSource;
	RMuint32 CaptureBitstream;
	RMuint32 CaptureType;
	RMuint32 CaptureDelay;
	RMbool SerialOut;
	RMbool ExternalClk;
	RMuint32 ExternalClkFreq;
 	RMbool AudioIn;
 	RMbool AudioInTandem;
 	RMuint32 AudioInAlign;
 	RMbool AudioInLSBfirst;
 	RMuint32 I2SAlign;
 	RMbool I2SSClkNormal;
 	RMbool I2SFrameNormal;
 	RMbool I2SLSBFirst;
 	RMbool I2S16Bit;
	RMbool OutputChannelsExplicitAssign; // for -chan option
 	enum AudioOutputChannels_type OutputChannels;
	enum OutputSpdif_type Spdif;	// it should go in every specific Params structure
	enum OutputDualMode_type OutputDualMode;
	RMbool OutputLfe;
	RMbool SignedPCM;
	RMuint32 BassMode;
	RMbool DownSample;
	struct AudioEngine_Delay_type ChannelDelay;
	struct AudioEngine_PL2x_type PL2xParams;
	struct AudioDecoder_AACParameters_type AACParams;
	struct AudioDecoder_DVDAParameters_type DVDAParams;
	struct AudioDecoder_BSACParameters_type BSACParams;
	struct AudioDecoder_Ac3Parameters_type Ac3Params;
	struct AudioDecoder_DtsParameters_type DtsParams;
	struct AudioDecoder_MpegParameters_type MpegParams;
	struct AudioDecoder_LpcmVobParameters_type LpcmVobParams;
	struct AudioDecoder_LpcmAobParameters_type LpcmAobParams;
	struct AudioDecoder_LpcmBDParameters_type LpcmBDParams;
	struct AudioDecoder_PcmCdaParameters_type PcmCdaParams;
	struct AudioDecoder_PCMXParameters_type PCMXParams;
	struct AudioDecoder_WMAParameters_type	WmaParams;
	struct AudioDecoder_TToneParameters_type TToneParams; 
   	struct AudioDecoder_AudioPlayTime_type audio_play_time;  // audio in and out control.
	struct dh_context *dh_info;
	RMbool dh_check;  // TRUE: call DHCheckHDMI() in audio's HDMI update code
	RMuint32 fifo_size;
	RMuint32 xfer_count;
	RMuint32 skip_first_n_bytes;
	RMuint32 send_n_bytes;
	enum ClockSignal mclk_on_rclk;
	RMbool transcode_ec3_to_ac3;
	RMint32 AudioFreqFromStream;
	RMbool auto_detect_codec;
	RMbool AudioCP;  // status of the audio copy protection bit in the SPDIF IEC 60958-3 header (bit 2)

	struct AudioEngine_ChannelStatus_type spdifChannelStatus; // full spdif channel status, apply AudioCP only if not set here (check mask) 
	
	enum MClkFactor mclk;

	RMuint32 thisAudioInstance;
	RMuint32 audioInstances;
	RMuint32 chconfig;
	RMuint32 drcenable;
	RMuint32 drcboost;
	RMuint32 drccut;
	RMint32 drcdialref;
	RMbool lossless;  
	
	RMbool ppdmx;			   // Force PP to do downmixing
	RMbool centerup;		   // Center up 6dB
	RMuint32 OutputSurround20;       //LtRt or LoRo
	RMuint32 i2s_spdif;  // select I2S data copy to SPDIF.
	RMbool mute_enable;
	enum GPIOId_type mute_gpio;
	RMbool mute_polarity;
	RMbool cdmx_enable;			// Customized downmixing
	RMbool sync_stc;
	
	RMbool HDMIPassThrough;
	RMuint32 HDMIPassThroughI2SLines;
	RMbool HBR_Enable;  // TRUE if HighBitRate audio is used (for Dolby TrueHD, e.g.)
	RMbool HBR_Compressed;  // TRUE if HBR audio from I2S is compressed, FALSE for PCM
	RMuint32 HBR_HeaderID;  // 4 bit HBR packet header ID
};

struct playback_cmdline {
	RMascii *filename;
	RMuint32 chip_num;
	RMuint32 STCid;
	RMint32 STC_initial_value;
	RMbool   noucode;
	RMuint32 loop_count;
	RMuint64 duration; /*in ms*/
	RMbool infinite_loop;
	RMbool waitexit;
	RMbool manutest;
	RMbool send_video;
	RMbool send_audio;
	RMbool send_spu;
	RMbool send_video_pts;
	RMbool send_audio_pts;
	RMbool send_spu_pts;
	RMbool save_video;
	int f_video_data;
	int f_video_pts;
	RMuint32 video_byte_count;
	RMbool save_audio;
	int f_audio_data;
	int f_audio_pts;
	RMuint32 audio_byte_count;
	RMbool save_spu;
	int f_spu_data;
	int f_spu_pts;
	RMuint32 spu_byte_count;
	RMint32 speed_N;
	RMuint32 speed_M;
	RMuint8 dram;
	RMuint32 start_ms;
	RMbool start_pause;
	RMascii *bcc_filename;
	RMbool stc_compensation;
	RMuint32 stc_comp_debug;
	RMbool spi;
	RMbool serial_spi;
	RMbool require_video_audio;
	RMint32 audio_delay_ms;
	RMint32 video_delay_ms;
	RMuint32 dmapool_count;
	RMuint32 dmapool_log2size;
	enum disk_control_state disk_ctrl_state;
	RMuint32 disk_ctrl_low_level;
	RMDiskControl disk_ctrl_callback;
	RMuint32 disk_ctrl_max_mem;
	RMuint32 disk_ctrl_log2_block_size;
	RMuint32 max_usable_RUA_mem;
	RMuint32 prebuf_max;
	RMbool send_audio_trickmode;
	RMbool savems;
	RMbool dontSendMPEG4pts;
	RMbool fast_audio_recovery;
};

struct demux_cmdline {
	RMsystemType system_type;
	RMsystemType data_type;
	RMbool repack_sample;
	RMuint32 video_pid;
	RMuint32 audio_pid;
	RMuint32 audio_subid;
	RMuint32 spu_subid;
	RMuint32 fifo_size;
	RMuint32 xfer_count;
	RMbool send_scrambled_packets_for_invalid_key; /* FALSE by default */
	RMuint32 wait_for_pcr_time_ms; /* 0 by default */
	RMuint32 pts_taken_as_pcr_offset_ms; /* 0 by default */

};

RMstatus init_playback_options(struct playback_cmdline *options);
RMstatus init_display_options(struct display_cmdline *options);
RMstatus init_video_options(struct video_cmdline *options);

RMstatus init_audio_options(struct audio_cmdline *options);
RMstatus init_audio_options2(struct audio_cmdline options[], RMuint32 entries);
RMstatus print_parsed_audio_options(struct audio_cmdline options[]);

RMstatus init_capture_options(struct capture_cmdline *options);

RMstatus parse_playback_cmdline(int argc, char **argv, int *index, struct playback_cmdline *options);
RMstatus parse_display_cmdline (int argc, char **argv, int *index, struct display_cmdline *options);
RMstatus parse_video_cmdline   (int argc, char **argv, int *index, struct video_cmdline *options);

RMstatus parse_audio_cmdline(int argc, char **argv, int *index, struct audio_cmdline *options);
RMstatus parse_audio_cmdline2(int argc, char **argv, int *index, struct audio_cmdline options[], RMuint32 optionsCount, RMuint32 *currentInstance);

RMstatus parse_capture_cmdline (int argc, char **argv, int *index, struct capture_cmdline *options);
RMstatus parse_wmapro_intermediate(RMfile file, struct AudioDecoder_WMAParameters_type *options);
enum AudioOutputChannels_type get_channel_mask(const RMascii* szValue);

RM_EXTERN_C_BLOCKEND

#endif // __CMDLINE_OPTIONS_H__
