#include "ad9380.h"
#include "ad9380yuvdata.h"
#include "ad9380vgadata.h"
#include "ad9380hdmidata.h"
#include "ad9380cscdata.h"
#include "i2c.h"

static RMuint8 isUpdateCSC=0;
static RMuint8 isUpdateCSCTable=0;


static void printBinary(RMuint32 val,RMuint8 bits)
{
	RMuint8 i=0;
	RMuint32 tmp=0;
	for(i=1;i<=bits;i++)
	{
		tmp=val >> (bits-i);
		tmp=tmp & 0x01;
		printf("%ld",tmp);
	}

}

RMstatus ad9380_checkRegisterSet(struct RUA *pInstance,
										   RMuint32 dev ,
										   RMuint8 delay)

{
	RMstatus err=RM_OK;
	RMuint32 addr;
	//		RMuint32 *data;
	RMuint32 reg;
/*
	
	for(addr=0x00;addr<=0xed;addr++)
	{
		err = read_i2c(pInstance, delay, dev, addr, &reg);
		if (RMFAILED(err))
		{
			printf("Can't Read I2C \n");
			return err;
		}
		printf(" reg %lx = %lx \n",addr,reg);			
	}*/

	printf("\n---------------------------\n");
	printf("RMuint8 i2c_data[][2] = { \n");
	printf("<devicevalues name=\"AD9880 Family\">\n");
	//for(addr=0x00;addr<=0x95;addr++)
	for(addr=0x00;addr<=0xee;addr++)
	{
		err = read_i2c(pInstance, delay, dev, addr, &reg);
		if (RMFAILED(err))
		{
			printf("Can't Read I2C \n");
			//return err;
		}
		//printf(" { 0x%lx , 0x%lx },\n",addr,reg);	
		//printf("0x%2lx,",reg);	
		//printf("	<registerval addr=\"%lX\" value=\"%lX\"/>\n",addr,reg);
		printf("	<registerval addr=\"%2lX\" value=\"%2lX\" ( dec = %3ld , bin = ",addr,reg,reg);
		printBinary(reg,8);
		printf(")\\>\n");
	}
	printf("};\n");
	printf("\n---------------------------\n");


if(0){
		RMuint8 hex_val[]={
0x13,0x00,0x40,0x54,0x80,0x80,0x80,0x80,0x00,0x80,0x00,0x80,0x00,0x80,0x20,0x40,0x40,0x02,0xa9,0x00,0x00,0x00,0xdb,0x02,0xee,0x08,0x14,0x06,0x4e,0xff,0x20,0x32,0x14,0xec,0x08,0x14,0x20,0x52,0x08,0x80,0x82,0x00,0x05,0x00,0x02,0xd0,0x18,0x6f,0xf0,0x96,0x0d,0x95,0x82,0x2c,0x52,0x08,0x00,0x00,0x00,0x19,0xd7,0x1c,0x54,0x08,0x00,0x1e,0x89,0x02,0x92,0x00,0x00,0x08,0x00,0x0e,0x87,0x18,0xbd,0x3b,0x6d,0x54,0x90,0x40,0x01,0x3f,0x00,0x00,0x0f,0x00,0x91,0x20,0x03,0x0b,0x54,0x81,0x00,0x99,0x00,0x02,0x0b,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x22,0x55,0x10,0x2d,0x80,0x02,0x11,0x28,0x00,0x04,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x01,0x05,0x00,0x00,0x0b,0x00,
		};
		for(addr=0x00;addr<=0x95;addr++)
		{
			reg=hex_val[addr];
			switch(addr) {
			case 0x00:
			case 0x15:
			case 0x16:
			case 0x17:
			case 0x18:
			case 0x2f:
			case 0x30:		
				break;
			default:
				if (addr<0x5a) {
					printf(" { 0x%lx , 0x%lx },\n",addr,reg);	
				}

			}
			
			//printf("0x%2lx,",reg);	
			//printf("	<registerval addr=\"%lX\" value=\"%ld\"/>\n",addr,reg);
		}
	}

	return err;
}


//Use H
#if 0
static float H(float curVal,float matchVal,float maxPoint)
{
	float result=0;
	float minus=0;	
	//minus = abs(Curval-matchVal);
	if ((curVal==0) || (matchVal==0)) {
		result = 0; 
	}else
		if (curVal >= matchVal) {
			minus=curVal-matchVal;
			result=maxPoint-(minus/curVal)*maxPoint;
			if (result<maxPoint/2) {
				result=0;
			}
		}else{
			minus=matchVal-curVal;		
			result=maxPoint-(minus/matchVal)*maxPoint;
			if (result<maxPoint/2) {
				result=0;
			}
		}
		return result;
		
}
#else
static float H(float curVal,float matchVal,float maxPoint)
{
	float result=0;
	float minus=0;	
	//minus = abs(Curval-matchVal);
	if ((curVal==0) || (matchVal==0)) {
		result = 0; 
	}else
		if (curVal >= matchVal) {
			minus=curVal-matchVal;
			result=maxPoint-minus;
			if (result<maxPoint/2) {
				result=0;
			}
		}else{
			minus=matchVal-curVal;		
			result=maxPoint-minus;
			if (result<maxPoint/2) {
				result=0;
			}
		}
		return result;		
}
#endif

RMstatus ad9380_getCaptureStandard(	struct RUA *pInstance,
								   RMuint32 numHsyncPerVsync,
								   enum EMhwlibTVStandard tvStandartSupportedList[],
								   RMuint8 sizeOftvStandartSupportedList,
								   enum EMhwlibTVStandard *newTVStandard)
{
	RMstatus err=RM_OK;
	struct EMhwlibTVFormatDigital formatDigital;
	RMuint32 curLinesPerField;
	float maxH=0;
	float curH=0;	
	RMuint8 i=0;
	enum EMhwlibTVStandard oldTVStandard;
	oldTVStandard=*newTVStandard;
	
	*newTVStandard=EMhwlibTVStandard_Custom;
	
	
	for(i=0;i<sizeOftvStandartSupportedList;i++)
	{		
		curH=0; 
		err = RUAExchangeProperty(pInstance, DisplayBlock, 
			RMDisplayBlockPropertyID_TVFormatDigital, 
			&tvStandartSupportedList[i], sizeof(tvStandartSupportedList[i]), 
			&formatDigital, sizeof(formatDigital));
		if RMFAILED(err) {
			fprintf(stderr, "Can not get format!\n");
			return err;
		}
		curLinesPerField = formatDigital.VTotalSize;
		if (formatDigital.TopFieldHeight) curLinesPerField /= 2;
		
		//printf("%d > compare %ld with %ld\n",i,numHsyncPerVsync,curLinesPerField);
		curH += H((float)numHsyncPerVsync,(float)curLinesPerField,100);
		if (maxH<curH) {
			*newTVStandard=tvStandartSupportedList[i];
			maxH=curH;			
		}
	}
	
	//printf("H = %f\n",maxH);	
	if (maxH<80) {
		*newTVStandard=EMhwlibTVStandard_Custom;
	}else
		if (maxH<97) {
			*newTVStandard=oldTVStandard;
		}
	return err;
}

RMstatus ad9380_getCaptureStandardYUV_ByNumHsyncPerVsync(
									  struct RUA *pInstance, 
									  RMuint8 dev, 
									  RMuint8 delay,
									  RMuint32 numHsyncPerVsync,
									  enum EMhwlibTVStandard *yuvId)
{
	RMstatus err=RM_OK;	
	enum EMhwlibTVStandard yuvTVStandartSupportedList[]= {
		ad9380_yuv_ntsc,//ad9380_yuv_480i,
			ad9380_yuv_pal, //ad9380_yuv_576i,			
			ad9380_yuv_480p,
			ad9380_yuv_1080i30,
			ad9380_yuv_576p,
			ad9380_yuv_720p60,
			//		ad9380_yuv_1080i25,		
			ad9380_yuv_1080p60
			//EMhwlibTVStandard_480p59,
			//		EMhwlibTVStandard_720p60,
			//		EMhwlibTVStandard_1080i60,
			//		EMhwlibTVStandard_ITU_Bt656_525,
			//		EMhwlibTVStandard_ITU_Bt656_625,		
			
	};
	err=ad9380_getCaptureStandard(pInstance,numHsyncPerVsync,yuvTVStandartSupportedList,(sizeof(yuvTVStandartSupportedList) / sizeof(enum EMhwlibTVStandard)),yuvId);
	if (err!=RM_OK) {
		printf("Can not get TV standard YUV!\n");
	}
	
	return err;
}

#if AUTODETECT_BY_EM

RMstatus ad9380_getCaptureStandardYUV(
									  struct RUA *pInstance, 
									  RMuint8 dev, 
									  RMuint8 delay,
									  RMuint32 numHsyncPerVsync,
									  enum EMhwlibTVStandard *yuvId)
{
	RMstatus err=RM_OK;
	enum EMhwlibTVStandard oldTVStandard;
	enum EMhwlibTVStandard yuvTVStandartSupportedList[]= {
		ad9380_yuv_ntsc,//ad9380_yuv_480i,
		ad9380_yuv_pal, //ad9380_yuv_576i,			
		ad9380_yuv_480p,
		ad9380_yuv_1080i30,
		ad9380_yuv_576p,
		ad9380_yuv_720p60,
//		ad9380_yuv_1080i25,		
		ad9380_yuv_1080p60
		//EMhwlibTVStandard_480p59,
		//		EMhwlibTVStandard_720p60,
		//		EMhwlibTVStandard_1080i60,
		//		EMhwlibTVStandard_ITU_Bt656_525,
		//		EMhwlibTVStandard_ITU_Bt656_625,		
		
	};
	RMuint32 regValue=0x0;	
	RMuint32 regAdd=0x0;
	oldTVStandard=*yuvId;
	
	err=ad9380_getCaptureStandard(pInstance,numHsyncPerVsync,yuvTVStandartSupportedList,(sizeof(yuvTVStandartSupportedList) / sizeof(enum EMhwlibTVStandard)),yuvId);
	if (err!=RM_OK) {
		printf("Can not get TV standard YUV!\n");
	}else
	{
		if (*yuvId!=oldTVStandard) {
			printf("Using I2C bus to detect YUV Mode\n");
			numHsyncPerVsync=0;
			
			regAdd=0x17;
			err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
				return err;
			}		
			numHsyncPerVsync |= regValue << 8;
			usleep(100);
			regAdd=0x18;
			err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
				return err;
			}
			numHsyncPerVsync |= regValue;
			
			err=ad9380_getCaptureStandard(pInstance,numHsyncPerVsync,yuvTVStandartSupportedList,(sizeof(yuvTVStandartSupportedList) / sizeof(enum EMhwlibTVStandard)),yuvId);
			if (err!=RM_OK) {
				printf("Can not get TV standard YUV!\n");
			}
		}else
		{
			//printf("Not read I2C AD . NumHS = 0x%lx\n",numHsyncPerVsync);
		}
	}

	return err;
}
#else
RMstatus ad9380_getCaptureStandardYUV(
									  struct RUA *pInstance, 
									  RMuint8 dev, 
									  RMuint8 delay,
									  enum EMhwlibTVStandard *yuvId)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x0;
	RMuint32 regAdd=0x0;




	if (1) {
		enum EMhwlibTVStandard yuvIdNew=*yuvId;
		enum EMhwlibTVStandard yuvIdOld=*yuvId;
		
		RMuint32 numHsyncPerVsync=0;
		RMuint8 samples=10;
		RMuint8 i;
		RMuint8 changeCount=0;
		for(i=0;i<samples;i++)
		{
			regAdd=0x17;
			err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
				return err;
			}		
			regValue &= 0x0f;//Only use 4 low bits
			numHsyncPerVsync |= regValue << 8;
			usleep(100);
			regAdd=0x18;
			err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
				return err;
			}
			numHsyncPerVsync |= regValue;
			if (ad9380_getCaptureStandardYUV_ByNumHsyncPerVsync(pInstance,dev,delay,numHsyncPerVsync,&yuvIdNew)!=RM_OK) {
				printf("Error ad9380_getCaptureStandardVGA_ByNumHsyncPerVsync!\n");
			}
			if (yuvIdNew != yuvIdOld) {
				yuvIdOld=yuvIdNew;
				changeCount =0;
			}else{				
				changeCount ++;
			}
			
			usleep(100);
		}
		
		if (changeCount >= 9  ) { //IF SIGNAL DETECT OK.
			*yuvId = yuvIdNew;
			//printf("\n****Count Change = %d \n",changeCount);
		}
		
		
	}else{
		
	regAdd=0x15;
	usleep(100);
	err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}	
	usleep(100);
	switch(regValue) {
	case 0x04:
	case 0xac://YUV+VGA
		regAdd=0x17;
		err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
			return err;
		}		
		usleep(100);
		switch(regValue) {
		case 0x01:
			regAdd=0x18;
			err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
				return err;
			}
			switch(regValue) {
			case 0x06:
			case 0x07:
				*yuvId=ad9380_yuv_ntsc;
				break;
			case 0x39:
			case 0x38:
				*yuvId=ad9380_yuv_pal;
				break;
			default:
				*yuvId=ad9380_invalid_standard;
//				fprintf(stderr, "0x04 - 0x01 - 0x%lx\n",regValue);
				//err=RM_ERROR;
			}
			break;
		case 0x02:
			regAdd=0x18;			
			err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
				return err;
			}
			switch(regValue) {
			case 0x0d:
			case 0x41:
				*yuvId=ad9380_yuv_480p;
				break;
			case 0x32: //1080i30
			case 0x33:
				*yuvId=ad9380_yuv_1080i30;
				break;
			case 0xee:
			case 0x18:
			case 0x15:
				*yuvId=ad9380_yuv_720p60;
				break;
			case 0x71:
				*yuvId=ad9380_yuv_576p;
				break;
			default:
				*yuvId=ad9380_invalid_standard;
//				fprintf(stderr, "0x04 - 0x02 - 0x%lx\n",regValue);
				//err=RM_ERROR;
			}
			break;		
		case 0x04:
			regAdd=0x18;
			err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
				return err;
			}
			switch(regValue) {
			case 0x6d:
				*yuvId=ad9380_yuv_480p;
				break;
			case 0x8a:
				*yuvId=ad9380_yuv_1080i30;
				break;
			case 0x65:
				*yuvId=ad9380_yuv_1080p60;
				break;
				
			default:
				*yuvId=ad9380_invalid_standard;
//				fprintf(stderr, "0x04 - 0x04 - 0x%lx\n",regValue);
				//err=RM_ERROR;
			}
			break;
		default:
			*yuvId=ad9380_invalid_standard;
//			fprintf(stderr, "0x04 - 0x%lx\n",regValue);
			//err=RM_ERROR;
		}
		break;
	case 0x08:	
		regAdd=0x17;
		err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
			return err;
		}
		usleep(100);
		switch(regValue) {
		case 0x01:
			regAdd=0x18;
			err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
				return err;
			}
			switch(regValue) {
			case 0x07:
				regAdd=0x5e;
				err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
				if (RMFAILED(err)) {
					fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
					return err;
				}	
				switch(regValue) {
				case 0:
					*yuvId=ad9380_yuv_480i;
					break;
				case 0xd4:
					*yuvId=ad9380_yuv_576i;
					break;
				default:
					*yuvId=ad9380_invalid_standard;
					fprintf(stderr, "0x08 -0x01- 0x07 - 0x%lx\n",regValue);
					//err=RM_ERROR;
				}
				break;
			default:
				*yuvId=ad9380_invalid_standard;
//				fprintf(stderr, "0x08 - 0x01 - 0x%lx\n",regValue);
				//err=RM_ERROR;
			}
			break;
		case 0x02:
			regAdd=0x18;
			err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
				return err;
			}
			switch(regValue) {
			case 0x0d:
				*yuvId=ad9380_yuv_576p;
				break;
			case 0x32:
				*yuvId=ad9380_yuv_1080i25;
				break;
			default:
				*yuvId=ad9380_invalid_standard;
//				fprintf(stderr, "0x08 - 0x02 - 0x%lx\n",regValue);
				//err=RM_ERROR;
			}
			break;
		case 0x04:
			*yuvId=ad9380_yuv_1080p60;
			break;
		default:
			fprintf(stderr, "0x08 - 0x%lx\n",regValue);
		}
		break;
	default:
		*yuvId=ad9380_invalid_standard;
//		fprintf(stderr, "0x15=0x%lx\n",regValue);
		//err=RM_ERROR;
		break;
	}
	}
	return err;
}
#endif

static RMstatus ad9380_setCaptureStandard(
	struct RUA *pInstance, 
	RMuint8 dev, 
	RMuint8 delay,
	enum EMhwlibTVStandard TVStandard)
{
	RMstatus err;
	RMuint8 range, current;
	struct EMhwlibTVFormatDigital fmt;
	RMuint32 vcogain, postdiv, plldiv, bp;
	RMreal c;
	
	// Analog Devices 9883 setup
	RMuint8 i2c_data[][2] = {
		{0x01, 0x69},  // PLL Div MSB //1 - 1
		{0x02, 0xD0},  // PLL Div LSB //2 - 2
		{0x03, 0x48},  // VCO		  //3 - 3
		{0x04, 0x80},  // Phase adj.  //4 - 4
	};
	
	err = RUAExchangeProperty(pInstance, DisplayBlock, 
		RMDisplayBlockPropertyID_TVFormatDigital, 
		&(TVStandard), sizeof(TVStandard), 
		&fmt, sizeof(fmt));
	if (RMFAILED(err)) fprintf(stderr, "Failed to get TV format, %s\n", RMstatusToString(err));
	
	vcogain = 150;
	postdiv = 1;
	if (fmt.PixelClock < 32000000) {
		range = 0;
		postdiv = 4;
	} else if (fmt.PixelClock < 64000000) {
		range = 1;
		postdiv = 2;
	} else if (fmt.PixelClock < 125000000) {
		range = 2;
	} else {
		range = 3;
		vcogain = 180;
	}
	plldiv = fmt.HTotalSize;
	
	// Formula from AD's Excel sheet 249461068RevAD9883_PLL.xls:
	// c=((HFreq*6.28/((PixClk<32000000)?12.5:15))^2*((0.082*0.000001*plldiv*postdiv)/(vcogain*1000000))*1000000
	c = fmt.PixelClock;
	c *= 6.28 / fmt.HTotalSize;
	c /= ((fmt.PixelClock < 32000000) ? 12.5 : 15.0);
	c *= c;
	c *= (0.082 * plldiv * postdiv) / (vcogain * 1000000.0);
	current = 
		(c <   75.0) ? 0 : 
		(c <  125.0) ? 1 : 
		(c <  200.0) ? 2 : 
		(c <  300.0) ? 3 : 
		(c <  425.0) ? 4 : 
		(c <  625.0) ? 5 : 
		(c < 1125.0) ? 6 : 
		               7;
	fprintf(stderr, "AD9883 calc - PixClk=%lu range=%u c=%f current=%u\n", fmt.PixelClock, range, c, current);
	
	bp = fmt.XOffset - fmt.HSyncWidth;  // BackPorch
	i2c_data[0x01 - 1][1] = (plldiv >> 4) & 0xFF;
	i2c_data[0x02 - 1][1] = (plldiv << 4) & 0xF0;
	i2c_data[0x03 - 1][1] = (range << 6) | (current << 3);

	printf("i2c_data[0x01]= 0x%x\n",i2c_data[0x01-1][1]);
	printf("i2c_data[0x02]= 0x%x\n",i2c_data[0x02-1][1]);
	printf("i2c_data[0x03]= 0x%x\n",i2c_data[0x03-1][1]);
	err = init_i2c(pInstance, delay, dev, i2c_data, sizeof(i2c_data) / sizeof (RMuint8) / 2);
	
	return err;
}

RMstatus ad9380_setCaptureStandardYUV(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,enum EMhwlibTVStandard yuvId)
{
	RMstatus err=RM_OK;

	if (0) {
		ad9380_setCaptureStandard(pInstance,dev,delay,yuvId);
	}
	
	switch(yuvId) {
	
	case ad9380_yuv_ntsc:
		err=init_i2c(pInstance,delay,dev,AD9380_NTSC_I2CDATA,sizeof(AD9380_NTSC_I2CDATA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 480i\n");
			return err;
		}
		break;
	case ad9380_yuv_pal:
		err=init_i2c(pInstance,delay,dev,AD9380_PAL_I2CDATA,sizeof(AD9380_PAL_I2CDATA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 480i\n");
			return err;
		}
		break;
	case ad9380_yuv_480i:
		err=init_i2c(pInstance,delay,dev,AD9380_480i60_I2CDATA,sizeof(AD9380_480i60_I2CDATA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 480i\n");
			return err;
		}
		break;
	
	case ad9380_yuv_480p:
		err=init_i2c(pInstance,delay,dev,AD9380_480p59_I2CDATA,sizeof(AD9380_480p59_I2CDATA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 480p\n");
			return err;
		}
		break;
	
	case ad9380_yuv_576i:
		err=init_i2c(pInstance,delay,dev,AD9380_576i50_I2CDATA,sizeof(AD9380_576i50_I2CDATA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 576i\n");
			return err;
		}
		break;	
	case ad9380_yuv_576p:	
		/*
		err=init_i2c(pInstance,delay,dev,AD9380_576p50_I2CDATA,sizeof(AD9380_576p50_I2CDATA)/2/sizeof(RMuint8));
				if (RMFAILED(err)) {
					fprintf(stderr, "Failed to set capture standard yuv 576p\n");
					return err;
				}*/
		
		err=init_i2c(pInstance,delay,dev,AD9380_480p59_I2CDATA,sizeof(AD9380_480p59_I2CDATA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 480p\n");
			return err;
		}
		
		break;
	case ad9380_yuv_720p60:
		err=init_i2c(pInstance,delay,dev,AD9380_720p60_I2CDATA,sizeof(AD9380_720p60_I2CDATA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 720p60\n");
			return err;
		}
		break;
	case ad9380_yuv_1080i25:
		err=init_i2c(pInstance,delay,dev,AD9380_1080i50_I2CDATA,sizeof(AD9380_1080i50_I2CDATA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 1080i25\n");
			return err;
		}
		break;
	case ad9380_yuv_1080i30:
		err=init_i2c(pInstance,delay,dev,AD9380_1080i60_I2CDATA,sizeof(AD9380_1080i60_I2CDATA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 1080i30\n");
			return err;
		}
		break;
	case ad9380_yuv_1080p60:
		err=init_i2c(pInstance,delay,dev,AD9380_1080p60_I2CDATA,sizeof(AD9380_1080p60_I2CDATA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 1080p60\n");
			return err;
		}
		break;
	default:		
		fprintf(stderr, "No support current capture standard yuv !\n");		
		//ad9380_checkRegisterSet(pInstance,dev,delay);
		break;
	}

	return err;
}

RMstatus ad9380_setColorSpaceConverter(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,RMuint8 cscId)
{
	RMstatus err=RM_OK;
	printf("*******ad9380_setColorSpaceConverter Call*****\n");
	switch(cscId) {
	case ad9380_yuv_480i:
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_480i60,sizeof(AD9380_CSC_480i60)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 480i\n");
			return err;
		}
		break;
	case ad9380_yuv_480p:
	/*
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_480p59,sizeof(AD9380_CSC_480p59)/2/sizeof(RMuint8));
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to set capture standard yuv 480p\n");
				return err;
			}*/
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_TABLE46,sizeof(AD9380_CSC_TABLE46)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 480p\n");
			return err;
		}
		break;
	case ad9380_yuv_576i:
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_576i50,sizeof(AD9380_CSC_576i50)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 576i\n");
			return err;
		}
		break;
	case ad9380_yuv_576p:	
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_576p50,sizeof(AD9380_CSC_576p50)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 576p\n");
			return err;
		}
		break;
	case ad9380_yuv_720p60:
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_720p60,sizeof(AD9380_CSC_720p60)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 720p60\n");
			return err;
		}
		break;
	case ad9380_yuv_1080i25:
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_1080i50,sizeof(AD9380_CSC_1080i50)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 1080i25\n");
			return err;
		}
		break;
	case ad9380_yuv_1080i30:
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_1080i60,sizeof(AD9380_CSC_1080i60)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 1080i30\n");
			return err;
		}
		break;
	case ad9380_yuv_1080p60:
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_1080p60,sizeof(AD9380_CSC_1080p60)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 1080p60\n");
			return err;
		}
		break;
//VGA////////////////////////////////////////////////////////////////////////
	case ad9380_vga_25mhz_60hz: //640x480x60
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_25MHz_60Hz_VGA,sizeof(AD9380_CSC_25MHz_60Hz_VGA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 1080p60\n");
			return err;
		}
		break;		
	case ad9380_vga_40mhz_60hz: //800x600x60
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_40MHz_60Hz_VGA,sizeof(AD9380_CSC_40MHz_60Hz_VGA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 1080p60\n");
			return err;
		}
		break;	
	case ad9380_vga_65mhz_60hz: //1024x768x60
		//err=init_i2c(pInstance,delay,dev,AD9380_40MHz_60Hz_VGA_I2CDATA,sizeof(AD9380_40MHz_60Hz_VGA_I2CDATA)/2/sizeof(RMuint8));
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_65MHz_60Hz_VGA,sizeof(AD9380_CSC_65MHz_60Hz_VGA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 1080p60\n");
			return err;
		}
		break;	
	case ad9380_vga_78mhz_75hz: //1024x768x75
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_78MHz_75Hz_VGA,sizeof(AD9380_CSC_78MHz_75Hz_VGA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 1080p60\n");
			return err;
		}
		break;	
	case ad9380_vga_94mhz_85hz: //1024x768x85
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_94MHz_85Hz_VGA,sizeof(AD9380_CSC_94MHz_85Hz_VGA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 1080p60\n");
			return err;
		}
		break;	
	case ad9380_vga_108mhz_60hz://1280x1024x60
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_108MHz_60Hz_VGA,sizeof(AD9380_CSC_108MHz_60Hz_VGA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 1080p60\n");
			return err;
		}
		break;	
	case ad9380_vga_135mhz_75hz://1280x1024x75
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_135MHz_75Hz_VGA,sizeof(AD9380_CSC_135MHz_75Hz_VGA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 1080p60\n");
			return err;
		}
		break;	
	case ad9380_vga_157mhz_85hz://1280x1024x85
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_157MHz_85Hz_VGA,sizeof(AD9380_CSC_157MHz_85Hz_VGA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 1080p60\n");
			return err;
		}
		break;	
	
//HDMI////////////////////////////////////////////////////////////////////////
	case ad9380_hdmi_480i:
	case ad9380_hdmi_480p:
	case ad9380_hdmi_720p59:
	case ad9380_hdmi_720p60:
	case ad9380_hdmi_1080i59:
	case ad9380_hdmi_1080i60:
	case ad9380_hdmi_1080p59:
	case ad9380_hdmi_1080p60:
		if (0) {
			err=init_i2c(pInstance,delay,dev,AD9380_CSC_HDMI,sizeof(AD9380_CSC_HDMI)/2/sizeof(RMuint8));
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to set capture standard HDMI !\n");
				return err;
			}
		}else {
			err=init_i2c(pInstance,delay,dev,AD9380_CSC_TABLE46,sizeof(AD9380_CSC_TABLE46)/2/sizeof(RMuint8));
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to set capture standard HDMI !\n");
				return err;
			}
		}
		
		break;	
		
	default:
		err=RM_ERROR;
		if (RMFAILED(err)) {
			fprintf(stderr, "No support current capture standard yuv !\n");
		}
		break;
	}
	
	return err;
}

RMstatus ad9380_setColorSpaceConverterStatus(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,RMuint8 isEnable)
{
	RMstatus err=RM_OK;
	RMuint32 regAdd=0;
	RMuint32 regValue=0;
	regAdd=0x34;
	err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}

	if (isEnable) {
		regValue |= 0x02;
		err = write_i2c(pInstance, delay, dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Can't enable CSC . \nFailed to write reg 0x%lx\n",regAdd);
			return err;
		}
	}else {
		regValue &= (~0x02);
		err = write_i2c(pInstance, delay, dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Can't disable CSC . \nFailed to write reg 0x%lx\n",regAdd);
			return err;
		}
	}


	return err;
}


RMstatus ad9380_setAutoOffset(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,RMuint8 isHold)
{
	RMstatus err=RM_OK;
	RMuint32 regAdd=0;
	RMuint32 regValue=0;
	regAdd=0x1b;
	err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	
	if (isHold) {
		regValue |= 0x01;
		err = write_i2c(pInstance, delay, dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Can't Hold Auto offset . \nFailed to write reg 0x%lx\n",regAdd);
			return err;
		}
	}else {
		regValue &= (~0x01);
		err = write_i2c(pInstance, delay, dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Can't use Auto offset . \nFailed to write reg 0x%lx\n",regAdd);
			return err;
		}
	}
	
	
	return err;
}

///HDMI CAPTURE//////////////////////////////////////////////////////////////////////////
RMstatus ad9380_isHdmiMode(struct RUA *pInstance,
						   RMuint8 dev, 
						   RMuint8 delay,
						   RMuint8 *isHDMIMode)
{
	RMstatus err=RM_OK;
	RMuint32 regAdd=0;
	RMuint32 regVal=0;
	regAdd=0x5b;
	err=read_i2c(pInstance,delay,dev,regAdd,&regVal);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	if (regVal & 0x08) {
		*isHDMIMode=1;
	}else
		*isHDMIMode=0; //DVI
	return err;
}

RMstatus ad9380_isHdmiRGBAviInput(struct RUA *pInstance,
						   RMuint8 dev, 
						   RMuint8 delay,
						   RMuint8 *isRGB)
{
	RMstatus err=RM_OK;
	RMuint32 regAdd=0;
	RMuint32 regVal=0;
	regAdd=0x81;
	err=read_i2c(pInstance,delay,dev,regAdd,&regVal);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	if (regVal & 0x60) {
		*isRGB=0;
	}else
		*isRGB=1; //Y[1:0] = 00
	return err;
}

RMstatus ad9380_getHdmiCSCInput(struct RUA *pInstance,
								  RMuint8 dev, 
								  RMuint8 delay,
								  RMuint8 *idCSC)
{
	RMstatus err=RM_OK;
	RMuint32 regAdd=0;
	RMuint32 regVal=0;
	regAdd=0x81;
	err=read_i2c(pInstance,delay,dev,regAdd,&regVal);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	/*
	printf("reg 0x81 = 0x%lx\n -> (regVal&0x60)>>5 = ",regVal);
		printBinary((regVal&0x60)>>5,8);
		printf("\n");*/
	
	switch((regVal&0x60)>>5) {
	case 0: //RGB
		*idCSC=0;
		break;
	case 1: //YCbCr 4:2:2
		*idCSC=1;
		break;
	case 2: //YCbCr 4:4:4
		*idCSC=2;
		break;
	default:
		printf("Unknown CSC input format \n");
		break;
	}
	
	return err;
}

RMstatus ad9380_setHdmiCSCOutput(struct RUA *pInstance,
								RMuint8 dev, 
								RMuint8 delay,
								RMuint8 idCSCInput)
{
	RMstatus err=RM_OK;
	switch(idCSCInput) {
	case 0: //RGB
		//printf("CSC RGB Input detected \n");
		err=ad9380_setColorSpaceConverterStatus(pInstance,dev,delay,0);
		break;
	case 1: //YCbCr 4:2:2		
		printf("CSC YCbCr 4:2:2 Input detected \n");
		err=ad9380_setColorSpaceConverterStatus(pInstance,dev,delay,1);
		break;
	case 2: //YCbCr 4:4:4
		printf("CSC YCbCr 4:4:4 Input detected \n");
		err=ad9380_setColorSpaceConverterStatus(pInstance,dev,delay,1);			
		//err=ad9380_setColorSpaceConverter_test(pInstance,dev,delay,45);
		break;
	default:
		printf("Invalid CSC detected !");
		err=RM_ERROR;
	}

	return err;
}

RMstatus ad9380_setMacrovisionOverSampleStatus(struct RUA *pInstance,
						   RMuint8 dev, 
						   RMuint8 delay,
						   RMuint8 isEnable)
{
	RMstatus err=RM_OK;
	RMuint32 regAdd=0;
	RMuint32 regValue=0;
	regAdd=0x32;
	err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	
	if (isEnable) {
		regValue |= 0x80;
		err = write_i2c(pInstance, delay, dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Can't enable Macrovision over sample . \nFailed to write reg 0x%lx\n",regAdd);
			return err;
		}
	}else {
		regValue &= (~0x80);
		err = write_i2c(pInstance, delay, dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Can't disavle Macrovision over sample . \nFailed to write reg 0x%lx\n",regAdd);
			return err;
		}
	}
	return err;
}
#if AUTODETECT_BY_EM
RMstatus ad9380_getCaptureStandardHDMI(
									  struct RUA *pInstance, 
									  RMuint8 dev, 
									  RMuint8 delay,
									  RMuint32 numHsyncPerVsync,
									  enum EMhwlibTVStandard *hdmiId)
{
	RMstatus err=RM_OK;
	enum EMhwlibTVStandard oldTVStandard;
	enum EMhwlibTVStandard hdmiTVStandartSupportedList[]= 
	{
		ad9380_hdmi_480i,
		ad9380_hdmi_480p, 
		ad9380_hdmi_576p, 
		ad9380_hdmi_720p60,
		ad9380_hdmi_1080i59,
		ad9380_hdmi_1080i60,
		ad9380_hdmi_1080p60,							
	};
	RMuint32 regValue=0x0;	
	RMuint32 regAdd=0x0;
	oldTVStandard=*hdmiId;
	
	err=ad9380_getCaptureStandard(pInstance,numHsyncPerVsync,hdmiTVStandartSupportedList,(sizeof(hdmiTVStandartSupportedList) / sizeof(enum EMhwlibTVStandard)),hdmiId);
	if (err!=RM_OK) {
		printf("Can not get TV standard YUV!\n");
	}else
	{
		if (*hdmiId!=oldTVStandard) {
			printf("Read I2C to make sure that capture standard change\n");
			numHsyncPerVsync=0;
			
			regAdd=0x17;
			err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
				return err;
			}		
			regValue &= 0x0f;//Only use 4 low bits
			numHsyncPerVsync |= regValue << 8;
			usleep(100);
			regAdd=0x18;
			err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
				return err;
			}
			numHsyncPerVsync |= regValue;
			
			err=ad9380_getCaptureStandard(pInstance,numHsyncPerVsync,hdmiTVStandartSupportedList,(sizeof(hdmiTVStandartSupportedList) / sizeof(enum EMhwlibTVStandard)),hdmiId);
			if (err!=RM_OK) {
				printf("Can not get TV standard HDMI!\n");
			}
		}else
		{
			//printf("Not read I2C AD . NumHS = 0x%lx\n",numHsyncPerVsync);
		}
	}
	return err;
}
#else

RMstatus ad9380_getCaptureStandardHDMI_ByNumHsyncPerVsync(
									   struct RUA *pInstance, 
									   RMuint8 dev, 
									   RMuint8 delay,
									   RMuint32 numHsyncPerVsync,
									   enum EMhwlibTVStandard *hdmiId)
{
	RMstatus err=RM_OK;
	enum EMhwlibTVStandard hdmiTVStandartSupportedList[]= 
	{
		ad9380_hdmi_480i,
			ad9380_hdmi_480p,
			ad9380_hdmi_480p59,
			ad9380_hdmi_576p, 
			ad9380_hdmi_720p60,
			ad9380_hdmi_1080i59,
			ad9380_hdmi_1080i60,
			ad9380_hdmi_1080p60,							
	};
	
	err=ad9380_getCaptureStandard(pInstance,numHsyncPerVsync,hdmiTVStandartSupportedList,(sizeof(hdmiTVStandartSupportedList) / sizeof(enum EMhwlibTVStandard)),hdmiId);
	if (err!=RM_OK) {
		printf("Can not get TV standard YUV!\n");
	}
	return err;
}
RMstatus ad9380_getCaptureStandardHDMI(
									  struct RUA *pInstance, 
									  RMuint8 dev, 
									  RMuint8 delay,
									  enum EMhwlibTVStandard *hdmiId)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x0;
	RMuint32 regAdd=0x0;	

	if (1) {
		enum EMhwlibTVStandard hdmiIdNew=*hdmiId;
		enum EMhwlibTVStandard hdmiIdOld=*hdmiId;
		
		RMuint32 numHsyncPerVsync=0;
		RMuint8 samples=10;
		RMuint8 i;
		RMuint8 changeCount=0;
		for(i=0;i<samples;i++)
		{
			regAdd=0x17;
			err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
				return err;
			}		
			regValue &= 0x0f;//Only use 4 low bits
			numHsyncPerVsync |= regValue << 8;
			usleep(100);
			regAdd=0x18;
			err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
				return err;
			}
			numHsyncPerVsync |= regValue;
			if (ad9380_getCaptureStandardHDMI_ByNumHsyncPerVsync(pInstance,dev,delay,numHsyncPerVsync,&hdmiIdNew)!=RM_OK) {
				printf("Error ad9380_getCaptureStandardVGA_ByNumHsyncPerVsync!\n");
			}
			if (hdmiIdNew != hdmiIdOld) {
				hdmiIdOld=hdmiIdNew;
				changeCount =0;
			}else{				
				changeCount ++;
			}
			
			usleep(100);
		}
		
		if (changeCount >= 9  ) { //IF SIGNAL DETECT OK.
			*hdmiId = hdmiIdNew;
			//printf("\n****Count Change = %d \n",changeCount);
		}
		
		
	}else{

			regAdd=0x18;
		usleep(300);
		err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
			return err;
		}
		switch(regValue) {
			
	/*
		case 0x06: //480i60
		case 0x07: //480i59
		case 0x38:
		case 0x39:
		case 0x40:
			*hdmiId=ad9380_hdmi_480i;
			break;		*/


		case 0x0c:
		case 0x0d: //480p
		case 0x0e:
	//	case 0x77:
			*hdmiId=ad9380_hdmi_480p;
			break;
		case 0x70:
		case 0x71://576p (PAL)
		case 0x72:
			*hdmiId=ad9380_hdmi_576p;
			break;
		case 0xed:
		case 0xee://720p	
		case 0xef:
			*hdmiId=ad9380_hdmi_720p60;
			break;
		case 0x32:
		case 0x33://1080i
		case 0x34:
			*hdmiId=ad9380_hdmi_1080i59;
			//*hdmiId=ad9380_hdmi_1080i60;
			break;
		case 0x65:
			//*hdmiId=ad9380_hdmi_1080p59;
		//	break;
		case 0x64:
			//*hdmiId=ad9380_hdmi_480i;
			//*hdmiId=ad9380_hdmi_480p;
			//*hdmiId=ad9380_hdmi_1080i59;		
			//*hdmiId=ad9380_hdmi_720p60;
			//*hdmiId=ad9380_hdmi_1080p60;
			*hdmiId=ad9380_hdmi_1080p59;
			break;		
			
		case 0:
	//		printf("NO SYGNAL DETECTED !\n 0x18=0");
		default:
		
			*hdmiId=ad9380_invalid_standard;
			fprintf(stderr, "Invalid standard regVal=  0x%lx\n",regValue);
			//err=RM_ERROR;
		}

	}
	return err;
}
#endif

RMstatus ad9380_setCaptureStandardHDMI(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,enum EMhwlibTVStandard hdmiId)
{
	RMstatus err=RM_OK;
		if (0) {
				ad9380_setCaptureStandard(pInstance,dev,delay,hdmiId);
			}
				
	switch(hdmiId) {		
	case ad9380_hdmi_720p59:
	case ad9380_hdmi_720p60:
		err=init_i2c(pInstance,delay,dev,AD9380_HDMI_720p_I2CDATA,sizeof(AD9380_HDMI_720p_I2CDATA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard HDMI \n");
			return err;
		}
		break;	
	
		
	case ad9380_hdmi_480i:
	case ad9380_hdmi_480p:
	case ad9380_hdmi_576p:
	case ad9380_hdmi_480p59:
		if (0) {
			err=init_i2c(pInstance,delay,dev,AD9380_HDMI_TESTING_I2CDATA,sizeof(AD9380_HDMI_TESTING_I2CDATA)/2/sizeof(RMuint8));
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to set capture standard HDMI \n");
				return err;
			}
		}else{
			err=init_i2c(pInstance,delay,dev,AD9380_HDMI_480_I2CDATA,sizeof(AD9380_HDMI_480_I2CDATA)/2/sizeof(RMuint8));
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to set capture standard HDMI \n");
				return err;
			}
		}
		
		break;	
	case ad9380_hdmi_1080i60:
	case ad9380_hdmi_1080i59:
		err=init_i2c(pInstance,delay,dev,AD9380_HDMI_1080i_I2CDATA,sizeof(AD9380_HDMI_1080i_I2CDATA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard HDMI \n");
			return err;
		}
		break;	
	case ad9380_hdmi_1080p59:
	case ad9380_hdmi_1080p60:
		if (1) {
			err=init_i2c(pInstance,delay,dev,AD9380_HDMI_TESTING_I2CDATA,sizeof(AD9380_HDMI_TESTING_I2CDATA)/2/sizeof(RMuint8));
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to set capture standard HDMI \n");
				return err;
			}
			
		}else {
			err=init_i2c(pInstance,delay,dev,AD9380_HDMI_1080p_I2CDATA,sizeof(AD9380_HDMI_1080p_I2CDATA)/2/sizeof(RMuint8));
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to set capture standard HDMI \n");
				return err;
			}
		}
		
		break;	
	default:
		err=RM_ERROR;
		if (RMFAILED(err)) {
			fprintf(stderr, "No support current capture standard HDMI !\n");
		}
		break;
	}
	
	return err;
}
#if	AUTODETECT_BY_EM
RMstatus ad9380_autoUpdateCaptureStandardHDMI(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,RMuint32 numHsyncPerVsync,enum EMhwlibTVStandard *cur_std)
{
	RMstatus err=RM_OK;
	RMuint8 idCSC=0;
	enum EMhwlibTVStandard old_std;
	
	old_std=*cur_std;
				
	if (isUpdateCSC) {
		err	= ad9380_getHdmiCSCInput(pInstance,dev,delay,&idCSC);
		
		
		if (err==RM_OK) {
			//err=ad9380_setHdmiCSCOutput(pInstance,dev,delay,idCSC);
			
			if (idCSC && (*cur_std)) {
				if (isUpdateCSCTable) {

					ad9380_setColorSpaceConverter(pInstance,dev,delay,*cur_std);
					isUpdateCSCTable=0;
				}				
			}
		}		
		isUpdateCSC=0;
	}

	if (ad9380_getCaptureStandardHDMI(pInstance,dev,delay,numHsyncPerVsync,cur_std)!=RM_OK) {
		//printf("No Standard detected \n");
		return RM_ERROR;
	}
	

	if((*cur_std != old_std) && (*cur_std!=EMhwlibTVStandard_Custom)) {	
		
		
		
		printf("Detected change capture HDMI standard %d, old = %d\n",*cur_std,old_std);
		ad9380_setCaptureStandardHDMI(pInstance,dev,delay,*cur_std);
		
		//ad9380_setColorSpaceConverterStatus(pInstance,dev,delay,0);
		ad9380_setMacrovisionOverSampleStatus(pInstance,dev,delay,1);
		
		//ad9380_setColorSpaceConverter(pInstance,dev,delay,*cur_std);
		err	= ad9380_getHdmiCSCInput(pInstance,dev,delay,&idCSC);
		if(0){//Test
			
			int i=0;
			//while(0){		
			while(i<20) {
				RMuint32 regAdd=0;
				RMuint32 regVal;
				regAdd=0x84;
				if (read_i2c(pInstance,10,0x98>>1,regAdd,&regVal)==RM_OK) {
					printf("read 0x%lx :  0x%lx\n",regAdd,regVal);
				}
				regVal=0;
				if (regVal) {
					printf("Signal OK !\n");
					break;
				}
				sleep(1);
				i++;
			}
		}//test
		if (err==RM_OK) {
			err=ad9380_setHdmiCSCOutput(pInstance,dev,delay,idCSC);
		}
		isUpdateCSC=1; //Re update CSC
		}
	
				
	

	return err;
}
#else
RMstatus ad9380_autoUpdateCaptureStandardHDMI(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,enum EMhwlibTVStandard *cur_std)
{
	RMstatus err=RM_OK;
	RMuint8 idCSC=0;
	RMuint8 old_std;
	old_std=*cur_std;
	
	if (isUpdateCSC) {
		err	= ad9380_getHdmiCSCInput(pInstance,dev,delay,&idCSC);
		if (err==RM_OK) {
			err=ad9380_setHdmiCSCOutput(pInstance,dev,delay,idCSC);
			if (idCSC && (*cur_std)) {
				if (isUpdateCSCTable) {
					ad9380_setColorSpaceConverter(pInstance,dev,delay,*cur_std);
					isUpdateCSCTable=0;
				}				
			}
		}		
		isUpdateCSC=0;
	}
	
	
	
	if (ad9380_getCaptureStandardHDMI(pInstance,dev,delay,cur_std)!=RM_OK) {
		//printf("No Standard detected \n");
		return RM_ERROR;
	}
	
	if (*cur_std != old_std) {		
		//printf("Detected change capture HDMI standard %d, old = %d\n",*cur_std,old_std);
		ad9380_setCaptureStandardHDMI(pInstance,dev,delay,*cur_std);
		//ad9380_setColorSpaceConverterStatus(pInstance,dev,delay,0);
		ad9380_setMacrovisionOverSampleStatus(pInstance,dev,delay,1);
		//ad9380_setColorSpaceConverter(pInstance,dev,delay,*cur_std);
		err	= ad9380_getHdmiCSCInput(pInstance,dev,delay,&idCSC);
		if(0){//Test
			
			int i=0;
			//while(0){		
			while(i<20) {
				RMuint32 regAdd=0;
				RMuint32 regVal;
				regAdd=0x84;
				if (read_i2c(pInstance,10,0x98>>1,regAdd,&regVal)==RM_OK) {
					printf("read 0x%lx :  0x%lx\n",regAdd,regVal);
				}
				regVal=0;
				if (regVal) {
					printf("Signal OK !\n");
					break;
				}
				sleep(1);
				i++;
			}
		}//test

		if (err==RM_OK) {
			err=ad9380_setHdmiCSCOutput(pInstance,dev,delay,idCSC);
		}
		isUpdateCSC=1; //Re update CSC
		
	}				
				
	return err;
}
#endif
#if AUTODETECT_BY_EM
RMstatus ad9380_autoUpdateCaptureStandardYUV(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,RMuint32 numHsyncPerVsync,enum EMhwlibTVStandard *cur_std)
{
	RMstatus err=RM_OK;	
	enum EMhwlibTVStandard old_std;
	old_std=*cur_std;
	
	if (ad9380_getCaptureStandardYUV(pInstance,dev,delay,numHsyncPerVsync,cur_std)!=RM_OK) {
		
		//printf("No Standard detected \n");
		return RM_ERROR;
	}
	
	if (*cur_std != old_std) {		
		printf("Detected change capture YUV standard %d\n",*cur_std);
		ad9380_setCaptureStandardYUV(pInstance,dev,delay,*cur_std);		
		ad9380_setColorSpaceConverterStatus(pInstance,dev,delay,0);	
		ad9380_setAudioClockYUV(pInstance,dev,delay,1);
	}				
				
	return err;
}
#else
RMstatus ad9380_autoUpdateCaptureStandardYUV(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,enum EMhwlibTVStandard *cur_std)
{
	RMstatus err=RM_OK;	
	enum EMhwlibTVStandard old_std;
	old_std=*cur_std;	
	if (ad9380_getCaptureStandardYUV(pInstance,dev,delay,cur_std)!=RM_OK) {
		
		//printf("No Standard detected \n");
		return RM_ERROR;
	}
	
	if (*cur_std != old_std) {		
		printf("Detected change capture YUV standard %d\n",*cur_std);
		ad9380_setCaptureStandardYUV(pInstance,dev,delay,*cur_std);		
		ad9380_setColorSpaceConverterStatus(pInstance,dev,delay,0);	
		ad9380_setAudioClockYUV(pInstance,dev,delay,1);
		ad9380_setAutoOffset(pInstance,dev,delay,1);
	}				
				
	return err;
}

#endif
#if	AUTODETECT_BY_EM
RMstatus ad9380_autoUpdateCaptureStandardVGA(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,RMuint32 numHsyncPerVsync,enum EMhwlibTVStandard *cur_std)
{
	RMstatus err=RM_OK;
	RMuint8 old_std;
	old_std=*cur_std;
	
	
	if (ad9380_getCaptureStandardVGA(pInstance,dev,delay,numHsyncPerVsync,cur_std)!=RM_OK) {
		//printf("No Standard detected \n");
		//return RM_ERROR;
	}
	
	if (*cur_std != old_std) {		
		printf("Detected change capture VGA standard %d\n",*cur_std);
		ad9380_setCaptureStandardVGA(pInstance,dev,delay,*cur_std);		
		ad9380_setColorSpaceConverterStatus(pInstance,dev,delay,0);	
		//		ad9380_setAudioClockYUV(pInstance,dev,delay);
	}				
				
	return err;
}
#else
RMstatus ad9380_autoUpdateCaptureStandardVGA(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,enum EMhwlibTVStandard *cur_std)
{
	RMstatus err=RM_OK;
	enum EMhwlibTVStandard old_std;
	old_std=*cur_std;
	
	
	if (ad9380_getCaptureStandardVGA(pInstance,dev,delay,cur_std)!=RM_OK) {
		//printf("No Standard detected \n");
		//return RM_ERROR;
	}
	
	if (*cur_std != old_std) {		
		printf("Detected change capture VGA standard %d\n",*cur_std);
		ad9380_setCaptureStandardVGA(pInstance,dev,delay,*cur_std);		
		ad9380_setColorSpaceConverterStatus(pInstance,dev,delay,1);	
		//ad9380_setColorSpaceConverter(pInstance,dev,delay,*cur_std);
		ad9380_setColorSpaceConverter_test(pInstance,dev,delay,48);
//		ad9380_setAudioClockYUV(pInstance,dev,delay);
	}				
				
	return err;
}
#endif

RMstatus ad9380_getAudioFrequency(struct RUA *pInstance, 								  
							RMuint8 dev, 
							RMuint8 delay,
							RMuint32 *pclk)
{
	RMstatus err=RM_OK;
	// if contrastValue = 0x80 or 0x90 -> No effect on the video data
	RMuint32 regValue=0;
	RMuint32 regAdd=0x5f;	
	RMuint32 Channelstatus=0;
	err=read_i2c(pInstance,delay,dev,regAdd,&regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
//	printf("0x%lx = 0x%lx\n",regAdd,regValue);
	Channelstatus = regValue;
	regValue=0;
	regAdd=0x60;	
	err=read_i2c(pInstance,delay,dev,regAdd,&regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}	
//	printf("0x%lx = 0x%lx\n",regAdd,regValue);
	Channelstatus += regValue;
	if (!Channelstatus) {
		return RM_ERROR;
	}
	regValue=0;
	regAdd=0x61;	
	
	err=read_i2c(pInstance,delay,dev,regAdd,&regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	*pclk=regValue & 0x0f;
	
	return err;
}


RMstatus ad9380_getPacketDetect(struct RUA *pInstance,
								  RMuint8 dev, 
								  RMuint8 delay,
								  RMuint32 *packetID)
{
	RMstatus err=RM_OK;
	// if contrastValue = 0x80 or 0x90 -> No effect on the video data
	RMuint32 regValue=0;
	RMuint32 regAdd=0x5a;	
	err=read_i2c(pInstance,delay,dev,regAdd,&regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	*packetID=regValue;
	return err;
}

RMstatus ad9380_getAudioSampleRateHDMI(
									struct RUA *pInstance, 
									RMuint8 dev, 
									RMuint8 delay,
									RMuint32 *sampleRate)
{
	RMstatus err;
	RMuint32 pclk;
	
	err = ad9380_getAudioFrequency(pInstance,dev,delay,&pclk);
	if (err !=RM_OK) {
		//printf("can't get Audio Frequency \n");
		*sampleRate=0;
		return err;
	}
	
	pclk &= 0x0F;
/*
	fprintf(stderr, "\n\n\tAudio fs: %s\n\n\n", 
		(pclk == 0) ? "44.1 kHz" : 
	(pclk == 1) ? "<unknown>" : 
	(pclk == 2) ? "48 kHz" : 
	(pclk == 3) ? "32 kHz" : 
	(pclk == 4) ? "22.05 kHz <invalid>" : 
	(pclk == 5) ? "11.025 kHz <invalid>" : 
	(pclk == 6) ? "24 kHz <invalid>" : 
	(pclk == 7) ? "16 kHz <invalid>" : 
	(pclk == 8) ? "88.2 kHz" : 
	(pclk == 9) ? "8 kHz <invalid>" : 
	(pclk == 10) ? "96 kHz" : 
	(pclk == 11) ? "<reserved>" : 
	(pclk == 12) ? "176.4 kHz" : 
	(pclk == 13) ? "12 kHz <invalid>" : 
	(pclk == 14) ? "192 kHz" : 
	(pclk == 15) ? "<not indicated>" : "-");*/




	if (0) {
		switch (pclk) {
		case  0: *sampleRate =  44100; break;
		case  1: 
			*sampleRate =      0; 
			//*sampleRate =  44100;
			break;  // no audio
		case  2: *sampleRate =  48000; break;
		case  3: *sampleRate =  32000; break;
			//case  4: *sampleRate =  22050; break;
			//case  5: *sampleRate =  11025; break;
			//case  6: *sampleRate =  24000; break;
			//case  7: *sampleRate =  16000; break;
		case  8: *sampleRate =  88200; break;
			//case  9: *sampleRate =   8000; break;
		case 10: *sampleRate =  96000; break;
		case 12: *sampleRate = 176400; break;
			//case 13: *sampleRate =  12000; break;
		case 14: *sampleRate = 192000; break;
		default: 
			//*sampleRate =  44100;
			*sampleRate =  0;
			//return RM_ERROR;
			return RM_OK;
		}
	}else{
		switch (pclk) {//Only support 44 Khz and 48 Khz.
		case  0x00: *sampleRate =  44100; break;
//		case  1: *sampleRate =      0; 	break;  // no audio
		case  0x02: *sampleRate =  48000; break;
//		case  3: *sampleRate =  32000; break;
			//case  4: *sampleRate =  22050; break;
			//case  5: *sampleRate =  11025; break;
			//case  6: *sampleRate =  24000; break;
			//case  7: *sampleRate =  16000; break;
//		case  8: *sampleRate =  88200; break;
			//case  9: *sampleRate =   8000; break;
		case 0x0a: *sampleRate =  96000; break;
//		case 12: *sampleRate = 176400; break;
			//case 13: *sampleRate =  12000; break;
		case 0x0d: *sampleRate = 192000; break;
		default: 
			//*sampleRate =  44100;
			*sampleRate =  0;
			//return RM_ERROR;
			return RM_OK;
		}
	}
	
	return err;
}

//VGA CAPTURE////////////////////////////////////////////////////////////////////////

RMstatus ad9380_getCaptureStandardVGA_ByNumHsyncPerVsync(
									  struct RUA *pInstance, 
									  RMuint8 dev, 
									  RMuint8 delay,
									  RMuint32 numHsyncPerVsync,
									  enum EMhwlibTVStandard *vgaId)
{
	RMstatus err=RM_OK;
	enum EMhwlibTVStandard vgaTVStandartSupportedList[]= 
	{
		ad9380_vga_25mhz_60hz,
			ad9380_vga_25mhz_75hz, 
			ad9380_vga_25mhz_85hz, 
			ad9380_vga_40mhz_60hz,
			//		ad9380_vga_40mhz_75hz,
			//		ad9380_vga_40mhz_85hz,
			ad9380_vga_65mhz_60hz,
			//		ad9380_vga_78mhz_75hz,
			//		ad9380_vga_94mhz_85hz,
			ad9380_vga_1280_768,
			ad9380_vga_108mhz_60hz,
			ad9380_vga_157mhz_85hz,					
	};
	err=ad9380_getCaptureStandard(pInstance,numHsyncPerVsync,vgaTVStandartSupportedList,(sizeof(vgaTVStandartSupportedList) / sizeof(enum EMhwlibTVStandard)),vgaId);
	if (err!=RM_OK) {
		printf("Can not get TV standard YUV!\n");
	}
	return err;
}

RMstatus ad9380_getCaptureStandardVGA(
									  struct RUA *pInstance, 
									  RMuint8 dev, 
									  RMuint8 delay,
									  enum EMhwlibTVStandard *vgaId)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x0;
	RMuint32 regAdd=0x0;
	
	if (1) {
		enum EMhwlibTVStandard vgaIdNew=*vgaId;
		enum EMhwlibTVStandard vgaIdOld=*vgaId;

		RMuint32 numHsyncPerVsync=0;
		RMuint8 samples=10;
		RMuint8 i;
		RMuint8 changeCount=0;
		for(i=0;i<samples;i++)
		{
			regAdd=0x17;
			err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
				return err;
			}		
			regValue &= 0x0f;//Only use 4 low bits
			numHsyncPerVsync |= regValue << 8;
			usleep(100);
			regAdd=0x18;
			err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
				return err;
			}
			numHsyncPerVsync |= regValue;
			if (ad9380_getCaptureStandardVGA_ByNumHsyncPerVsync(pInstance,dev,delay,numHsyncPerVsync,&vgaIdNew)!=RM_OK) {
				printf("Error ad9380_getCaptureStandardVGA_ByNumHsyncPerVsync!\n");
			}
			if (vgaIdNew != vgaIdOld) {
				vgaIdOld=vgaIdNew;
				changeCount =0;
			}else{				
				changeCount ++;
			}

			usleep(100);
		}

		if (changeCount >= 9  ) { //IF SIGNAL DETECT OK.
			*vgaId = vgaIdNew;
			//printf("\n****Count Change = %d \n",changeCount);
		}
		
		
	}else{



	regAdd=0x15;
	err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	switch(regValue) {	
	case 0xa0:
	case 0xa8:
	case 0xac: //VGA+YUV
		regAdd=0x17;
		err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
			return err;
		}
		switch(regValue) {
		case 0x02:
			regAdd=0x18;
			err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
				return err;
			}
			switch(regValue) {
			case 0x0d:
				*vgaId=ad9380_vga_25mhz_60hz;
				break;
			case 0x74: //60 hz
				*vgaId=ad9380_vga_40mhz_60hz;
			case 0x71: //75 hz				
				*vgaId=ad9380_vga_40mhz_75hz;
			case 0x77: //85 hz
				*vgaId=ad9380_vga_40mhz_85hz;
				break;			
			default:
				*vgaId=ad9380_invalid_standard;				
			}
			break;
		case 0x03:
				regAdd=0x18;
				err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
				if (RMFAILED(err)) {
					fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
					return err;
				}
				switch(regValue) {
				case 0x1e:
				case 0x1b: //1280x768x60
					*vgaId=ad9380_vga_1280_768;
					break;
				case 0x26:
					*vgaId=ad9380_vga_65mhz_60hz;
					break;			
				case 0x20:
					*vgaId=ad9380_vga_78mhz_75hz;
					break;			
				case 0x28:
					*vgaId=ad9380_vga_94mhz_85hz;
					break;	
					
				default:
					*vgaId=ad9380_invalid_standard;
				}
				break;
		case 0x04:
			regAdd=0x18;
			err = read_i2c(pInstance, delay, dev, regAdd, &regValue);
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
				return err;
			}
			switch(regValue) {
			case 0x2a: //1280x1024x60
				*vgaId=ad9380_vga_108mhz_60hz;
				//*vgaId=ad9380_vga_135mhz_75hz; //Same
				break;			
			
			case 0x30:
				*vgaId=ad9380_vga_157mhz_85hz;
				break;			
				
			default:
				*vgaId=ad9380_invalid_standard;
			}
			break;
		default:
			*vgaId=ad9380_invalid_standard;
		}
		break;
	default:
		*vgaId=ad9380_invalid_standard;
		break;
	}
	}
	
	return err;
}


RMstatus ad9380_setCaptureStandardVGA(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,enum EMhwlibTVStandard vgaId)
{
	RMstatus err=RM_OK;
	if (0) {
		ad9380_setCaptureStandard(pInstance,dev,delay,vgaId);
	}
	
	switch(vgaId) {		
	//VGA STANDARD :
	case ad9380_vga_25mhz_60hz: //640x480x60
	case ad9380_vga_25mhz_75hz:
	case ad9380_vga_25mhz_85hz:
			
		
		if (1) {
			err=init_i2c(pInstance,delay,dev,AD9380_25MHz_60Hz_VGA_I2CDATA,sizeof(AD9380_25MHz_60Hz_VGA_I2CDATA)/2/sizeof(RMuint8));
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to set capture standard yuv 1080p60\n");
				return err;			
			}
		}else {
			err=init_i2c(pInstance,delay,dev,AD9380_TEST_VGA_I2CDATA,sizeof(AD9380_TEST_VGA_I2CDATA)/2/sizeof(RMuint8));
			if (RMFAILED(err)) {
				fprintf(stderr, "Failed to set capture standard yuv 1080p60\n");
				return err;
			}
		}
		

		break;		
	case ad9380_vga_40mhz_60hz: //800x600x60
	case ad9380_vga_40mhz_75hz: //800x600x75
	case ad9380_vga_40mhz_85hz: //800x600x85
		err=init_i2c(pInstance,delay,dev,AD9380_40MHz_60Hz_VGA_I2CDATA,sizeof(AD9380_40MHz_60Hz_VGA_I2CDATA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 1080p60\n");
			return err;
		}
		break;		
	case ad9380_vga_65mhz_60hz: //1024x768x60
		//err=init_i2c(pInstance,delay,dev,AD9380_40MHz_60Hz_VGA_I2CDATA,sizeof(AD9380_40MHz_60Hz_VGA_I2CDATA)/2/sizeof(RMuint8));
		err=init_i2c(pInstance,delay,dev,AD9380_65MHz_60Hz_VGA_I2CDATA,sizeof(AD9380_65MHz_60Hz_VGA_I2CDATA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 1080p60\n");
			return err;
		}
		break;	
	case ad9380_vga_78mhz_75hz: //1024x768x75
		err=init_i2c(pInstance,delay,dev,AD9380_78MHz_75Hz_VGA_I2CDATA,sizeof(AD9380_78MHz_75Hz_VGA_I2CDATA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 1080p60\n");
			return err;
		}
		break;	
	
	case ad9380_vga_94mhz_85hz: //1024x768x85
		err=init_i2c(pInstance,delay,dev,AD9380_94MHz_85Hz_VGA_I2CDATA,sizeof(AD9380_94MHz_85Hz_VGA_I2CDATA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 1080p60\n");
			return err;
		}
		break;	
	case ad9380_vga_1280_768:
		err=init_i2c(pInstance,delay,dev,AD9380_1280_768_VGA_I2CDATA,sizeof(AD9380_1280_768_VGA_I2CDATA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 1080p60\n");
			return err;
		}

		break;	
	case ad9380_vga_108mhz_60hz://1280x1024x60
		err=init_i2c(pInstance,delay,dev,AD9380_108MHz_60Hz_VGA_I2CDATA,sizeof(AD9380_108MHz_60Hz_VGA_I2CDATA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 1080p60\n");
			return err;
		}
		break;	
	case ad9380_vga_135mhz_75hz://1280x1024x75
		err=init_i2c(pInstance,delay,dev,AD9380_135MHz_75Hz_VGA_I2CDATA,sizeof(AD9380_135MHz_75Hz_VGA_I2CDATA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 1080p60\n");
			return err;
		}
		break;	
	case ad9380_vga_157mhz_85hz://1280x1024x85
		err=init_i2c(pInstance,delay,dev,AD9380_157MHz_85Hz_VGA_I2CDATA,sizeof(AD9380_157MHz_85Hz_VGA_I2CDATA)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 1080p60\n");
			return err;
		}
		break;	
		
	default:
		err=RM_ERROR;
		if (RMFAILED(err)) {
			fprintf(stderr, "No support current capture standard vga !\n");
		}
		break;
	}
	
	return err;
}

//////////////////////////////////////////////////////////////////////////


RMstatus ad9380_setCapturePort(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,RMuint8 port)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0;
	RMuint32 regAdd=0x11;
	switch (port) {
				case 1:     //YUV
					regValue=0xfd;				
					err = write_i2c(pInstance, delay, dev,regAdd,regValue);
					if (RMFAILED(err)) {
						fprintf(stderr, "Failed to write register 0x%lx\n",regAdd);
						return err;
					}
					err=init_i2c(pInstance,delay,dev,AD9380_RGB_I2CDATA,sizeof(AD9380_RGB_I2CDATA)/2/sizeof(RMuint8));
					if (RMFAILED(err)) {
						fprintf(stderr, "Failed to set capture standard yuv 480i\n");
						return err;
					}

					break;
				case 2:    //VGA
					regValue=0x55;
					err = write_i2c(pInstance, delay, dev,regAdd,regValue);
					if (RMFAILED(err)) {
						fprintf(stderr, "Failed to write register 0x%lx\n",regAdd);
						return err;
					}
					//Default RGB Data.
					err=init_i2c(pInstance,delay,dev,AD9380_RGB_I2CDATA,sizeof(AD9380_RGB_I2CDATA)/2/sizeof(RMuint8));
					if (RMFAILED(err)) {
						fprintf(stderr, "Failed to set capture standard yuv 480i\n");
						return err;
					}
					break;
				case 3:    //HDMI
					regValue=0x02;
					//regValue=0xff;

					err = write_i2c(pInstance, delay, dev,regAdd,regValue);
					if (RMFAILED(err)) {
						fprintf(stderr, "Failed to write register 0x%lx\n",regAdd);
						return err;
					}
					//isUpdateCSC=1; //Enable Update Color Converter Space					
					isUpdateCSCTable=1;
					err=init_i2c(pInstance,delay,dev,AD9380_CSC_TABLE46,sizeof(AD9380_CSC_TABLE46)/2/sizeof(RMuint8));
					if (RMFAILED(err)) {
						fprintf(stderr, "Failed to set capture standard yuv 480p\n");
						return err;
					}
//					err=ad9380_setHdmiCSCOutput(pInstance,dev,delay,1);
					break;
				default: 
					printf("Only support YUV,VGA and HDMI Capture Port ! YUV By default !\n");
					regValue=0xfd;
					err = write_i2c(pInstance, delay, dev,regAdd,regValue);
					break;
				}
//	usleep(50);	
	return err;
}

//GAIN
RMstatus ad9380_setContrast(struct RUA *pInstance, 								  
							   RMuint8 dev, 
							   RMuint8 delay,
							   RMuint32 contrastValue)
{
	RMstatus err=RM_OK;
	// if contrastValue = 0x80 or 0x90 -> No effect on the video data
	if ((contrastValue>=0)&&(contrastValue<=255)) {
		RMuint32 regValue=0;
		RMuint32 regAdd=0x00;
		regAdd=0x05; //Red gain
		regValue=contrastValue & 0xff;
		err=write_i2c(pInstance,delay,dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
			return err;
		}		
		regAdd=0x06; //Green gain
		regValue=contrastValue & 0xff;
		err=write_i2c(pInstance,delay,dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
			return err;
		}
		regAdd=0x07; //Blue gain
		regValue=contrastValue & 0xff;
		err=write_i2c(pInstance,delay,dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
			return err;
		}

	}
	return err;
}

RMstatus ad9380_getContrast(struct RUA *pInstance, 								  
							   RMuint8 dev, 
							   RMuint8 delay,
							   RMuint32 *contrastValue)
{
	RMstatus err=RM_OK;
	// if contrastValue = 0x80 or 0x90 -> No effect on the video data
	
	RMuint32 regValue=0;
	RMuint32 regAdd=0x05;	
	err=read_i2c(pInstance,delay,dev,regAdd,&regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	
	*contrastValue=regValue & 0xff;
	
	return err;
}

RMstatus ad9380_isContrastValid(struct RUA *pInstance, 								  
								RMuint8 dev, 
								RMuint8 delay,
								RMuint32 contrastValue)
{
	RMstatus err=RM_OK;
	// if contrastValue = 0x80 or 0x90 -> No effect on the video data
	if ((contrastValue<0)||(contrastValue>255)) {
		err=RM_ERROR;
	}
	return err;
}


RMstatus ad9380_setBrightness(struct RUA *pInstance, 								  
								 RMuint8 dev, 
								 RMuint8 delay,
								 RMint32 brightnessValue)
{
	RMstatus err=RM_OK;
	// if contrastValue = 0x80 or 0x90 -> No effect on the video data
	if ((brightnessValue>=-128)&&(brightnessValue<=127)) {
		RMuint32 regValue=0;
		RMuint32 regAdd=0x00;
		regAdd=0x09;//Red offset
		regValue=brightnessValue & 0xff;
		err=write_i2c(pInstance,delay,dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
			return err;
		}		
		regAdd=0x0b;//Green offset
		regValue=brightnessValue & 0xff;
		err=write_i2c(pInstance,delay,dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
			return err;
		}		
		regAdd=0x0d;//blue offset
		regValue=brightnessValue & 0xff;
		err=write_i2c(pInstance,delay,dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
			return err;
		}		
	}
	return err;
}

RMstatus ad9380_getBrightness(struct RUA *pInstance, 								  
							RMuint8 dev, 
							RMuint8 delay,
							RMint32 *brightnessValue)
{
	RMstatus err=RM_OK;
	// if contrastValue = 0x80 or 0x90 -> No effect on the video data
	
	RMuint32 regValue=0;
	RMuint32 regAdd=0x09;	
	err=read_i2c(pInstance,delay,dev,regAdd,&regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	
	//*brightnessValue=regValue & 0xff;
	
	return err;
}

RMstatus ad9380_isBrightnessValid(struct RUA *pInstance, 								  
								RMuint8 dev, 
								RMuint8 delay,
								RMint32 brightnessValue)
{
	RMstatus err=RM_OK;
	// if brightnessValue = 0x80 or 0x90 -> No effect on the video data
	if ((brightnessValue<-128)||(brightnessValue>127)) {
		err=RM_ERROR;
	}
	return err;
}


RMstatus ad9380_setBrightnessAdjust(struct RUA *pInstance, 								  
								 RMuint8 dev, 
								 RMuint8 delay,
								 RMint32 brightnessValue)
{
	RMstatus err=RM_OK;
	// if contrastValue = 0x80 or 0x90 -> No effect on the video data
	if ((brightnessValue>=-128)&&(brightnessValue<=127)) {
		RMuint32 regValue=0;
		RMuint32 regAdd=0x00;
		regAdd=0x08;//Red offset
		regValue=brightnessValue & 0xff;
		err=write_i2c(pInstance,delay,dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
			return err;
		}		
		regAdd=0x0a;//Green offset
		regValue=brightnessValue & 0xff;
		err=write_i2c(pInstance,delay,dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
			return err;
		}		
		regAdd=0x0c;//blue offset
		regValue=brightnessValue & 0xff;
		err=write_i2c(pInstance,delay,dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
			return err;
		}		
	}
	return err;
}

RMstatus ad9380_getBrightnessAdjust(struct RUA *pInstance, 								  
							RMuint8 dev, 
							RMuint8 delay,
							RMint32 *brightnessValue)
{
	RMstatus err=RM_OK;
	// if contrastValue = 0x80 or 0x90 -> No effect on the video data
	
	RMuint32 regValue=0;
	RMuint32 regAdd=0x08;	
	err=read_i2c(pInstance,delay,dev,regAdd,&regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	
	//*brightnessValue=regValue & 0xff;
	
	return err;
}

RMstatus ad9380_isBrightnessAdjustValid(struct RUA *pInstance, 								  
								RMuint8 dev, 
								RMuint8 delay,
								RMint32 brightnessValue)
{
	RMstatus err=RM_OK;
	// if brightnessValue = 0x80 or 0x90 -> No effect on the video data
	if ((brightnessValue<-128)||(brightnessValue>127)) {
		err=RM_ERROR;
	}
	return err;
}


static RMstatus ad9380_TestRegister(struct RUA *pInstance, 								  
									   RMuint8 dev, 
									   RMuint8 delay,
									   RMuint32 regAdd,
									   RMuint32 isAsc)
{
	
	RMstatus err=RM_OK;
	RMuint32 regValue=0;
	RMuint32 i=0;
	
	for(i=0;i<=255;i++)
	{
		if (!isAsc) 
			regValue=255-i;
		else
			regValue=i;
		err=write_i2c(pInstance,delay,dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
			return err;
		}
		usleep(50000);
		printf("0x%lx = 0x%lx\n",regAdd,regValue);
		
	}
	return err;
}


RMstatus ad9380_setColorSpaceConverter_test(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,RMuint8 tableId)
{
	RMstatus err=RM_OK;
	
	switch(tableId) {
	case 1://ad9380_yuv_480i:
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_480i60,sizeof(AD9380_CSC_480i60)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 480i\n");
			return err;
		}
		break;
	case 2://ad9380_yuv_480p:
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_480p59,sizeof(AD9380_CSC_480p59)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 480p\n");
			return err;
		}
		break;
	case 3://ad9380_yuv_576i:
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_576i50,sizeof(AD9380_CSC_576i50)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 576i\n");
			return err;
		}
		break;
	case 4://ad9380_yuv_576p:	
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_576p50,sizeof(AD9380_CSC_576p50)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 576p\n");
			return err;
		}
		break;
	case 5://ad9380_yuv_720p60:
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_720p60,sizeof(AD9380_CSC_720p60)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 720p60\n");
			return err;
		}
		break;
	case 6://ad9380_yuv_1080i25:
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_1080i50,sizeof(AD9380_CSC_1080i50)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 1080i25\n");
			return err;
		}
		break;
	case 7://ad9380_yuv_1080i30:
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_1080i60,sizeof(AD9380_CSC_1080i60)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 1080i30\n");
			return err;
		}
		break;
	case 8://ad9380_yuv_1080p60:
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_1080p60,sizeof(AD9380_CSC_1080p60)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 1080p60\n");
			return err;
		}
		break;
		
	case 44:
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_TABLE44,sizeof(AD9380_CSC_TABLE44)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 44\n");
			return err;
		}
		break;
	case 45:
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_TABLE45,sizeof(AD9380_CSC_TABLE45)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 45\n");
			return err;
		}
		break;
	case 46:
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_TABLE46,sizeof(AD9380_CSC_TABLE46)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 46\n");
			return err;
		}
		break;
	case 47:	
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_TABLE47,sizeof(AD9380_CSC_TABLE47)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 47\n");
			return err;
		}
		break;
	case 48:
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_TABLE48,sizeof(AD9380_CSC_TABLE48)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 48\n");
			return err;
		}
		break;
	case 49:
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_TABLE49,sizeof(AD9380_CSC_TABLE49)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 49\n");
			return err;
		}
		break;
	case 50:
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_TABLE50,sizeof(AD9380_CSC_TABLE50)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 50\n");
			return err;
		}
		break;
	case 51:
		err=init_i2c(pInstance,delay,dev,AD9380_CSC_TABLE51,sizeof(AD9380_CSC_TABLE51)/2/sizeof(RMuint8));
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to set capture standard yuv 51\n");
			return err;
		}
		break;
	default:
		err=RM_ERROR;
		if (RMFAILED(err)) {
			fprintf(stderr, "No support current capture standard yuv !\n");
		}
		break;
	}
	
	return err;
}


RMstatus ad9380_ResetClockTermination(struct RUA *pInstance, 								  
						  RMuint8 dev, 
						  RMuint8 delay)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x59;
	
	regAdd=0x59;
	regValue = 0x36;		
	err=write_i2c(pInstance,delay,dev,regAdd,regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
		return err;
	}
	regValue = 0x16;
	err=write_i2c(pInstance,delay,dev,regAdd,regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
		return err;
	}
	return err;
}


RMstatus ad9380_ResetOutput(struct RUA *pInstance, 								  
									  RMuint8 dev, 
									  RMuint8 delay)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x26;
	
	regAdd=0x26;
	regValue = 0x88;		
	err=write_i2c(pInstance,delay,dev,regAdd,regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
		return err;
	}
	regValue = 0x08;
	err=write_i2c(pInstance,delay,dev,regAdd,regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
		return err;
	}
	return err;
}

RMstatus ad9380_threeStateOutput(struct RUA *pInstance, 								  
							RMuint8 dev, 
							RMuint8 delay,RMbool isThreeState)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x26;
	
	regAdd=0x26;
	err=read_i2c(pInstance,delay,dev,regAdd,&regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	if (isThreeState) {
		regValue |= 0x70;		
	}else{
		regValue &= 0x8f;		
	}

	
	err=write_i2c(pInstance,delay,dev,regAdd,regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
		return err;
	}
	
	return err;
}

RMstatus ad9380_PowerDown(struct RUA *pInstance, 								  
							 RMuint8 dev, 
							 RMuint8 delay)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;
		
	regAdd=0x26;
	err=read_i2c(pInstance,delay,dev,regAdd,&regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	regValue |= 0x01;		
	err=write_i2c(pInstance,delay,dev,regAdd,regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
		return err;
	}
	return err;
}

RMstatus ad9380_PowerUp(struct RUA *pInstance, 								  
						   RMuint8 dev, 
						   RMuint8 delay)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;
	
	regAdd=0x26;
	err=read_i2c(pInstance,delay,dev,regAdd,&regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	regValue &= 0xfe;
	
	err=write_i2c(pInstance,delay,dev,regAdd,regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
		return err;
	}
	return err;
}
void ad9380_Debug(struct RUA *pInstance, 								  
					 RMuint8 dev, 
					 RMuint8 delay,
					 RMuint8 key)
{
	switch(key) {
	case 'w':
		{
			
			RMuint32 regAdd;
			RMuint32 regValue;
			printf("Write regAdd = ");scanf("%lx",&regAdd);
			printf("regValue = ");scanf("%lx",&regValue);
			write_i2c(pInstance,delay,dev,regAdd,regValue);
			printf("Write to 0x%lx value 0x%lx\n",regAdd,regValue);
			break;
		}
	case 'r':
		{
			
			RMuint32 regAdd;
			RMuint32 regValue;
			printf("Read regAdd = ");scanf("%lx",&regAdd);							
			read_i2c(pInstance,delay,dev,regAdd,&regValue);
			printf("Read to 0x%lx value 0x%lx , = ",regAdd,regValue);
			printBinary(regValue,8);
			printf("\n");
			break;
		}
	case 'a':
		{
			
			ad9380_checkRegisterSet(pInstance,dev,delay);
			//ad9380_checkRegisterSet(pInstance);
			break;
		}	
	case '0':
		{
			
			RMuint32 regAdd;
			printf("Write regAdd = ");scanf("%lx",&regAdd);			
			ad9380_TestRegister(pInstance,dev,delay,regAdd,1);
			break;
		}
	case '1':
		{
			
			RMuint32 regAdd;
			printf("Write regAdd = ");scanf("%lx",&regAdd);			
			ad9380_TestRegister(pInstance,dev,delay,regAdd,0);
			break;
		}
	case '2':
		{
			
			RMuint32 tableId;
			printf("Write tableId = ");scanf("%ld",&tableId);			
			ad9380_setColorSpaceConverter_test(pInstance,dev,delay,tableId);
			break;
		}

	case '3':
		{
			
			RMuint32 cscStatus;
			printf("Write cscStatus = ");scanf("%lx",&cscStatus);
			ad9380_setColorSpaceConverterStatus(pInstance,dev,delay,cscStatus);
			break;
		}
	case 'd':
		{
			printf("Power Down AD :\n");
			ad9380_PowerDown(pInstance,dev,delay);
			break;
		}
	case 'u':
		{
			printf("Power Up AD :\n");
			ad9380_PowerUp(pInstance,dev,delay);
			break;
		}
	case 'p':
		{
			printf("Reset AD :\n");
			ad9380_PowerDown(pInstance,dev,delay);
			ad9380_PowerUp(pInstance,dev,delay);
			break;
		}
		
	default:
		break;
	}
}


void ad9380_showMenu()
{
	
	printf(" \n ******************** MENU ************************\n");
	printf("  c: decrease contrast   - C: increase contrast\n");
//	printf("  b: decrease brightness - B: increase brightness\n");
//	printf("  t: decrease saturation - T: increase saturation\n");
//	printf("  h: decrease hue		 - H: increase hue\n");
//	printf("  s: decrease sharpness	 - S: increase sharpness\n");
#ifndef NO_AUDIO
	printf("  v: decrease Volume	 - V: increase Volume\n");
#endif
//	printf("  z: Switch CVBS -> SVIDEO -> TUNER.\n");
#ifndef NO_AUDIO
	printf("  x: Switch Audio Output HeadPhone <--> LoudSpeaker.\n");
	printf("  y: Switch Audio Input Scart1 <--> Audio Input Scart4.\n");
#endif	
	printf("  q: Exit .\n");
	printf(" \n **************************************************\n");
	
	
}



RMstatus ad9380_setAudioClockYUV(struct RUA *pInstance, RMuint8 dev, RMuint8 delay, RMuint8 isUseMCLKExternal)
{
	RMstatus err=RM_OK;
	RMuint32 regAdd=0;
	RMuint32 regVal=0;
	regAdd=0x27;
	err=read_i2c(pInstance,delay,dev,regAdd,&regVal);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	
	switch(isUseMCLKExternal) {
	case 0:
		regVal = regVal & 0xdf;
		break;
	case 1:
		regVal = regVal | 0x20;

		break;
	default:
		break;
	}

	err=write_i2c(pInstance,delay,dev,regAdd,regVal);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
		return err;
	}
	/*
	err=init_i2c(pInstance,delay,dev,AD9380_YUV_AUDIO_I2CDATA,sizeof(AD9380_YUV_AUDIO_I2CDATA)/2/sizeof(RMuint8));
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to set AUDIO CLOCK yuv !\n");
		return err;
	}	*/

	return err;
}




















