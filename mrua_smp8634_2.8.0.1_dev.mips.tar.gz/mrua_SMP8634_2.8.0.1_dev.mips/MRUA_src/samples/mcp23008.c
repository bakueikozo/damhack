#include "mcp23008.h"
#include "i2c.h"
#define MCP_I2C_ADDR_WRITE_OUT 0x40>>1

static RMuint32 dev=MCP_I2C_ADDR_WRITE_OUT;
static RMuint32 delay= 10;
//static RMuint32 MCP_I2C_ADDR_WRITE_IN 0x21;

RMstatus mcp23008_setI2CConfig(struct RUA *pInstance,RMuint32 i2c_dev,RMuint8 i2c_delay)
{
	RMstatus err=RM_OK;
	dev=i2c_dev;
	delay=i2c_delay;
	return err;
}
RMstatus mcp23008_openHDMIPort(
							   struct RUA *pInstance,
							   RMuint8 hdmiPort) 
{
	RMstatus err=RM_OK;
	RMuint32 regAdd=0x00;
	RMuint32 regValue=0x00;	
	regAdd=0;
	regValue=0;
	err=write_i2c(pInstance,delay,dev,regAdd,regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
		return err;
	}
	regAdd=0x09;
	err = read_i2c(pInstance, delay, dev, regAdd, &regValue); 
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	
	switch(hdmiPort) {
	case 1:
		regValue = regValue & 0xEF ;
		regValue = regValue | 0x88 ;
		
		printf("select HDMI1\n");
		break;
	case 2:
		regValue = regValue & 0x6F;
//		regValue = regValue | 0x68 ;
		regValue = regValue | 0x48 ; 
		printf("select HDMI2\n");
		break;
	case 3:
		regValue = regValue & 0x2F ;
		regValue = regValue | 0x28 ;
		printf("select HDMI3\n");
		break;

	default:
		printf("Invalid HDMI port ( only 1 -> 3 )\n");
		err=RM_ERROR;
		return err;
		break;
	}		

	err=write_i2c(pInstance,delay,dev,regAdd,regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
		return err;
	}		

	return err;
}

RMstatus mcp23008_selectAnalogAudio(struct RUA *pInstance) 
{
	RMstatus err=RM_OK;
	RMuint32 regAdd=0x00;
	RMuint32 regValue=0x00;	
	
	//select audio analog : reg 0x09 = xxxxx1xx
	regAdd=0x09;
	err = read_i2c(pInstance, delay, dev, regAdd, &regValue); 
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	//regValue = regValue & 0xFD;
	//regValue = regValue & 0xFB;
	regValue = regValue | 0x04;
	err=write_i2c(pInstance,delay,dev,regAdd,regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
		return err;
	}
	return err;
}
RMstatus mcp23008_selectHDMIAudio(struct RUA *pInstance)
{
	RMstatus err=RM_OK;
	RMuint32 regAdd=0x00;
	RMuint32 regValue=0x00;	
	
	//select audio HDMI : reg 0x09 = xxxxx0xx
	regAdd=0x09;
	err = read_i2c(pInstance, delay, dev, regAdd, &regValue); 
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	regValue = regValue & 0xfb ;
	err=write_i2c(pInstance,delay,dev,regAdd,regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
		return err;
	}
	return err;
}
RMstatus mcp23008_setEQForHDMI(
							   struct RUA *pInstance,
							   RMuint8 eqValue) 
{
	RMstatus err=RM_OK;
	RMuint32 regAdd=0x00;
	RMuint32 regValue=0x00;	
	regAdd=0x09;
	err = read_i2c(pInstance, delay, dev, regAdd, &regValue); 
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	
	switch(eqValue) {
	case 1:
		regValue = regValue & 0xE7 ;
		break;
	case 2:
		regValue = regValue & 0xEF;
		regValue = regValue | 0x08;
		break;
	case 3:
		regValue = regValue & 0xF7 ;
		regValue = regValue | 0x10;
		break;
	case 4:
		regValue = regValue & 0xFF ;
		regValue = regValue | 0x18;
		break;
	default:
		break;
	}
	err=write_i2c(pInstance,delay,dev,regAdd,regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
		return err;
	}		
	return err;
}
