/*
 *
 * Copyright (c) Sigma Designs, Inc. 2002. All rights reserved.
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <sys/time.h>



#define ALLOW_OS_CODE 1
#include "common.h"

#include "../rmrtk/include/rmrtk.h"


#define KEYFLAGS (SET_KEY_DISPLAY | SET_KEY_PLAYBACK)
#define TIMEOUT_US 1000000

#define FONT_FILE "Vera.ttf"
RMuint32 gfx_dram_controller = 0;

/* 
 *  use the SEND_GFX_COMMAND if you don't want a continuos polling
 *  otherwise you can just write
 *  while( RUASetProperty(pRUA, moduleID, propertyID, pValue, ValueSize, 0) == RM_PENDING);
 *
 *  uncomment the following line if you want the application to wait for the completion of commands
 *  before going on (otherwise the command is queued, and the application only waits if the command
 *  queue is full)
 * 
 */


/* #define WAIT_FOR_COMMANDS */


#define SEND_GFX_COMMAND(pRUA, moduleID, propertyID, pValue, ValueSize)					\
{													\
	RMstatus err;											\
	RMuint32 n;											\
	n = 1005;											\
	do{												\
		err = RUASetProperty(pRUA, moduleID, propertyID, pValue, ValueSize, 0);			\
		if ((err == RM_PENDING)) {								\
 			struct RUAEvent evt;								\
			evt.ModuleID = moduleID;							\
			evt.Mask = RUAEVENT_COMMANDCOMPLETION;						\
			while (RUAWaitForMultipleEvents(pRUA, &evt, 1, TIMEOUT_US, NULL) != RM_OK)	\
				RMDBGLOG((ENABLE, "Waiting for a command to finish\n"));		\
                }											\
                        n--;										\
													\
	}while((n>0) && (err == RM_PENDING));								\
													\
	if (err != RM_OK) {										\
		RMDBGLOG((ENABLE, "Can't send command to command fifo\n" ));				\
		return err;										\
	}												\
													\
}







char *filename = (char *) NULL;


struct playback_cmdline play_opt;
struct display_cmdline disp_opt;
struct video_cmdline video_opt;

static struct dcc_context dcc_info = {0,};


static void show_usage(char *progname)
{
	show_display_options();
	show_video_options();
	
	fprintf(stderr, "------------------------------------------------------------\n");
	fprintf(stderr, "Minimum cmd line: %s <filename.jpg/filename.bmp>\n", progname);
	fprintf(stderr, "Image should be 256x256 or bigger and true color\n");
	fprintf(stderr, "------------------------------------------------------------\n");

	exit(1);
}

static void parse_cmdline(int argc, char *argv[])
{
	int i;

	i = 1;
	while ((argc > i)) {
		if ( ! strcmp(argv[i], "-gfxdram")) {
			if (argc > i+1) {
				gfx_dram_controller = strtol(argv[i+1], NULL, 10);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
	}

}



static RMstatus gfx_test( struct RUA *pRUA, RMuint32 osd_addr, struct DCCOSDProfile *osd_profile)
{
	RMstatus err;
	RMuint32 gfx;
	RMuint32 dram_buf = 0;
	struct GFXEngine_Open_type gfx_profile;
	struct timeval init, final;
	RMuint32 elapsed;
		RMuint32 total_bytes;
		RMuint32 transfer_count = 0;


	fprintf(stderr, "osd allocated at 0x%08lx\n", osd_addr); 

	
	/* init the gfx_engine */
	{
		RMuint32 chip_num;
		RMuint32 gfx_count; 
		
		struct GFXEngine_DRAMSize_in_type  dramSizeIn;
		struct GFXEngine_DRAMSize_out_type dramSizeOut;
		
		RMint32 i;
		
		chip_num = 0;
		
		dramSizeIn.CommandFIFOCount = 10;
		err = RUAExchangeProperty(pRUA, EMHWLIB_MODULE(GFXEngine,0), RMGFXEnginePropertyID_DRAMSize,
					  &dramSizeIn, sizeof(dramSizeIn), &dramSizeOut, sizeof(dramSizeOut));
		if (RMFAILED(err)) {
			fprintf(stderr, "Error getting dram size for gfx engine\n");
			return -1;
		}
		
		gfx_profile.CommandFIFOCount = dramSizeIn.CommandFIFOCount;
		gfx_profile.Priority = 1;
		gfx_profile.CachedSize = dramSizeOut.CachedSize;
		gfx_profile.UncachedSize = dramSizeOut.UncachedSize;
	
		if (gfx_profile.CachedSize > 0) {
			fprintf(stderr, "about to malloc cached, size %ld\n", gfx_profile.CachedSize);
			gfx_profile.CachedAddress = RUAMalloc(pRUA, gfx_dram_controller, RUA_DRAM_CACHED, gfx_profile.CachedSize);
		} else {
			gfx_profile.CachedAddress = 0;
		}
		
		gfx_profile.UncachedSize = dramSizeOut.UncachedSize;
		if (gfx_profile.UncachedSize > 0) {
			gfx_profile.UncachedAddress = RUAMalloc(pRUA, gfx_dram_controller, RUA_DRAM_UNCACHED, gfx_profile.UncachedSize);
		} else {
			gfx_profile.UncachedAddress = 0;
		}
		fprintf(stderr, "gfx engine task structure allocated at 0x%08lx\n", gfx_profile.UncachedAddress); 

		gfx = GFXEngine;
		
		err = RUAExchangeProperty(pRUA, EMHWLIB_MODULE(Enumerator,0),  RMEnumeratorPropertyID_CategoryIDToNumberOfInstances, 
					  &gfx, sizeof(gfx), &gfx_count, sizeof(gfx_count));
		if (RMFAILED(err)) {
			fprintf(stderr, "Error getting gfx engine count\n");
			return -1;
		}
			
		for (i=0 ; i<(RMint32) gfx_count ; i++) {
			gfx = EMHWLIB_MODULE(GFXEngine, i);
			err = RUASetProperty(pRUA, gfx, RMGFXEnginePropertyID_Open, &gfx_profile, sizeof(gfx_profile), 0);
			if (err == RM_OK) 
				break;
		}
		
		if (i==(RMint32)gfx_count) {
			fprintf(stderr, "Cannot open a gfx engine [0..%lu[\n", gfx_count);
			return -1;
		}
	}//*/
	

	
	/* setup NX  */
	{
		struct GFXEngine_Surface_type surface_param;
		struct GFXEngine_ColorFormat_type format_param;

		format_param.SurfaceID = GFX_SURFACE_ID_NX;
		format_param.MainMode = osd_profile->ColorMode; //wont care!
		format_param.SubMode = osd_profile->ColorFormat;
		format_param.SamplingMode = osd_profile->SamplingMode;
		format_param.ColorSpace = osd_profile->ColorSpace;
		SEND_GFX_COMMAND(pRUA, gfx, RMGFXEnginePropertyID_ColorFormat, &format_param, sizeof(format_param));
		
		surface_param.SurfaceID = GFX_SURFACE_ID_NX;
		surface_param.StartAddress = osd_addr;
		surface_param.TotalWidth = osd_profile->Width;
		surface_param.Tiled = FALSE;
		SEND_GFX_COMMAND(pRUA, gfx, RMGFXEnginePropertyID_Surface, &surface_param, sizeof(surface_param));


	}//*/
	
	/* just move (Y)  */
	{
		struct GFXEngine_Surface_type surface_param;
		struct GFXEngine_ColorFormat_type format_param;
		struct GFXEngine_MoveReplaceRectangle_type move_param;
		RMuint32 test_id = 0;
		RMuint32 test_transfer_count;
		
		format_param.SurfaceID = GFX_SURFACE_ID_Y;
		surface_param.SurfaceID = GFX_SURFACE_ID_Y;
		
		format_param.MainMode = osd_profile->ColorMode;
		format_param.SubMode = osd_profile->ColorFormat;
		format_param.SamplingMode = osd_profile->SamplingMode;
		format_param.ColorSpace = osd_profile->ColorSpace;

		
		surface_param.StartAddress = osd_addr;
		surface_param.TotalWidth = osd_profile->Width;
		surface_param.Tiled = FALSE;

		SEND_GFX_COMMAND(pRUA, gfx, RMGFXEnginePropertyID_ColorFormat, &format_param, sizeof(format_param));
		SEND_GFX_COMMAND(pRUA, gfx, RMGFXEnginePropertyID_Surface, &surface_param, sizeof(surface_param));

		move_param.SrcX = 0;
		move_param.SrcY = 0;
		move_param.Width = osd_profile->Width;//osd_profile->Width/2;
		move_param.Height = osd_profile->Height;//osd_profile->Height/2;
		move_param.DstX = 0;
		move_param.DstY = 0;//osd_profile->Height/2;
		move_param.AlphaX = 0;
		move_param.AlphaY = 0;
		move_param.Merge = FALSE;

		total_bytes = move_param.Width * move_param.Height;  /* read */
		total_bytes *= 2;  /* write */
		total_bytes *= 4; /* 32bpp */

		test_transfer_count = (512*1024*1024)/total_bytes;

		gettimeofday(&init, NULL);
		while(TRUE){
			if(transfer_count == test_transfer_count){
				gettimeofday(&final, NULL);
				elapsed = final.tv_sec - init.tv_sec;
				elapsed *= 1000000;
				elapsed += (RMint32)final.tv_usec - init.tv_usec;
				fprintf(stderr, "%ldkB/s (%ld ops per second) chunks are (%ld x %ld)\n", 
					(RMuint32) (((((RMuint64)transfer_count*total_bytes)/elapsed)*1000000)>>10), 
					(transfer_count*1000)/(elapsed/1000),
					move_param.Width,
					move_param.Height
					);
				move_param.Width -= (move_param.Width + 7)/8;
				move_param.Height -= (move_param.Height + 7)/8;
				if((!move_param.Width) ||
				   (!move_param.Height)){
					move_param.Width = osd_profile->Width;
					move_param.Height = osd_profile->Height;
				}

				total_bytes = move_param.Width * move_param.Height;  /* read */
				total_bytes *= 2;  /* write */
				total_bytes *= 4; /* 32bpp */
				/* calculate this here so that we don't need to make an extra multiplication on every command*/
				test_transfer_count = (512*1024*1024)/total_bytes;
				transfer_count=0;
				test_id++;
				gettimeofday(&init, NULL);
			}

			SEND_GFX_COMMAND(pRUA, gfx, RMGFXEnginePropertyID_MoveRectangle, &move_param, sizeof(move_param));
			transfer_count++;
		}

	}//*/
	/* just move (Y)  */
	{
		struct GFXEngine_Surface_type surface_param;
		struct GFXEngine_ColorFormat_type format_param;
		struct GFXEngine_MoveReplaceRectangle_type move_param;
		
		format_param.SurfaceID = GFX_SURFACE_ID_Y;
		surface_param.SurfaceID = GFX_SURFACE_ID_Y;
		
		format_param.MainMode = osd_profile->ColorMode;
		format_param.SubMode = osd_profile->ColorFormat;
		format_param.SamplingMode = osd_profile->SamplingMode;
		format_param.ColorSpace = osd_profile->ColorSpace;

		
		surface_param.StartAddress = osd_addr;
		surface_param.TotalWidth = osd_profile->Width;
		surface_param.Tiled = FALSE;

		SEND_GFX_COMMAND(pRUA, gfx, RMGFXEnginePropertyID_ColorFormat, &format_param, sizeof(format_param));
		SEND_GFX_COMMAND(pRUA, gfx, RMGFXEnginePropertyID_Surface, &surface_param, sizeof(surface_param));

		move_param.SrcX = 0;
		move_param.SrcY = 0;
		move_param.Width = osd_profile->Width;//osd_profile->Width/2;
		move_param.Height = osd_profile->Height;//osd_profile->Height/2;
		move_param.DstX = 0;
		move_param.DstY = 0;//osd_profile->Height/2;
		move_param.AlphaX = 0;
		move_param.AlphaY = 0;
		move_param.Merge = FALSE;

		total_bytes = move_param.Width * move_param.Height;  /* read */
		total_bytes *= 2;  /* write */
		total_bytes *= 4; /* 32bpp */

		
		while(TRUE){
			if(transfer_count ==500)/* move_param.SrcX >  (osd_profile->Width - move_param.Width)) */{
				gettimeofday(&final, NULL);
				elapsed = final.tv_sec - init.tv_sec;
				elapsed *= 1000000;
				elapsed += (RMint32)final.tv_usec - init.tv_usec;
				gettimeofday(&init, NULL);
				fprintf(stderr, "elapsed usecs %ld : %ldkB/s (transfer count %ld)\n", 
					elapsed,
					(RMuint32) (((((RMuint64)transfer_count*total_bytes)/elapsed)*1000000)>>10), transfer_count);
				transfer_count=0;
				move_param.SrcX  = 0;
			}

			SEND_GFX_COMMAND(pRUA, gfx, RMGFXEnginePropertyID_MoveRectangle, &move_param, sizeof(move_param));
/* 			move_param.SrcX++; */
			transfer_count++;
		}

	}//*/

	
	/* wait for all commands to be finished */
	{
		struct RUAEvent evt;
		RMbool empty_queue = FALSE;
		evt.ModuleID = gfx;
		evt.Mask = RUAEVENT_COMMANDCOMPLETION;
		while(!empty_queue){
			RUAGetProperty(pRUA, gfx, RMGFXEnginePropertyID_CommandQueueEmpty, &empty_queue, sizeof(empty_queue));
			/* the following lines could be removed if you don't care about a continuous polling */
			if(!empty_queue) {
				while( RUAWaitForMultipleEvents(pRUA, &evt, 1, TIMEOUT_US, NULL)!=RM_OK){
					RMDBGLOG((ENABLE, "Waiting for a command to finish\n"));
				}
			}
		}
	}
	
	
	/* close the gfx accelerator */
 	{
 		RMuint32 close_profile = 0;

		
 		err = RUASetProperty(pRUA, gfx, RMGFXEnginePropertyID_Close, &close_profile, sizeof(close_profile), 0);
 		if (RMFAILED(err)) fprintf(stderr, "Cannot close de gfx accelerator\n");

		if(dram_buf != 0)
				RUAFree(pRUA, dram_buf);
		if(gfx_profile.CachedAddress)		
			RUAFree(pRUA, gfx_profile.CachedAddress);

		if(gfx_profile.UncachedAddress)		
			RUAFree(pRUA, gfx_profile.UncachedAddress);
 	}//*/



	dram_buf = 0;
	return 0;
}




int main(int argc, char *argv[])
{
	struct DCC *pDCC = NULL;
	struct RUA *pRUA = NULL;
	RMuint32 osd_addr;
	RMstatus err;
	struct DCCOSDProfile  osd_profile;
/* 	RMuint32 mixer = 0, scaler, src_index, mixer_src; */
	struct display_context disp_info;
	struct dh_context dh_info = {0,};



	

	init_display_options(&disp_opt);
	init_video_options(&video_opt);
	init_playback_options(&play_opt);
	disp_opt.dh_info = &dh_info;

	parse_cmdline(argc, argv);

	err = RUACreateInstance(&pRUA, play_opt.chip_num);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error creating RUA instance! %d\n", err);
		return -1;
	}
	
	err = DCCOpen(pRUA, &pDCC);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error Opening DCC! %d\n", err);
		return err;
	}

	dcc_info.pRUA = pRUA;
 	dcc_info.pDCC = pDCC;
	dcc_info.route = DCCRoute_Main;
	dcc_info.disp_info = &disp_info;


/* 	fprintf( stdout, "press any key\n\n\n"); */
	osd_profile.ColorSpace = EMhwlibColorSpace_RGB_0_255;
	osd_profile.ColorFormat = EMhwlibColorFormat_32BPP;
	osd_profile.ColorMode = EMhwlibColorMode_TrueColor;
	osd_profile.SamplingMode = EMhwlibSamplingMode_444;
	osd_profile.Width = 1024;
	osd_profile.Height = 1024;
	osd_profile.PixelAspectRatio.X = 1;
	osd_profile.PixelAspectRatio.Y = 1;


	osd_addr = RUAMalloc(pRUA, gfx_dram_controller, RUA_DRAM_UNCACHED, osd_profile.Width*osd_profile.Height*4);

	gfx_test(dcc_info.pRUA, osd_addr, &osd_profile);
	fprintf( stdout, "gfx test done, press any key to quit\n");
	RMGetKey();

	err = RUADestroyInstance(pRUA);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot destroy RUA instance %d\n", err);
		return -1;
	}

	



	return 0;
	

}

