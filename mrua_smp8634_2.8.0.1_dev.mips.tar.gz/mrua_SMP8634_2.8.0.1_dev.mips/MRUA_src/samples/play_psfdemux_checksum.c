/*
 *
 * Copyright (c) Sigma Designs, Inc. 2002. All rights reserved.
 *
 */

/**
   @file play_psfdemux_checksum.c
   @brief sample application for hardware demux of EM86xx
	
   @author Aurelia Popa-Radu, Michael Uman
   @ingroup dccsamplecode
*/

#include "../samples/sample_os.h"

#define ALLOW_OS_CODE 1
#include <libgen.h>
#include "../dcc/include/dcc.h"
#include "../samples/common.h"
#include "command_ids.h"

#include "play_psfdemux_helper.h"

#include "psfdemux_common.h"
#include "../gbuslib/include/gbus_fifo.h" /* needed for receiving data from DemuxOutput direct from DRAM fifo */

#include "../samples/rmttx.h"
#include "checksum.h"

/* ################## Begin DTCP code ################### */
#if (EM86XX_CHIP == EM86XX_CHIPID_TANGO15)
#include "../rmdtcp/include/dtcp_session.h"
#else
#include "../rmdtcpapi/include/dtcp_session.h"
#endif
/* ############### End DTCP code ####################### */

/* to enable or disable the debug messages of this source file, put 1 or 0 below */
#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

#if 0
#define SENDDBG ENABLE
#define CRCDBG	ENABLE
#else
#define SENDDBG DISABLE
#define CRCDBG 	DISABLE
#endif

#define	DO_SAVE			1
#define DO_CRC32		1
//#define DO_DUMP		1
#define WAIT_FOR_KEY		1
#define DO_LINEAR_BUFFER	1
#define USE_WAITEOS			1
#define DO_CAPTURE			1
//#define INIT_DISPLAY_CONSUMER	1
#define SAVEPATH			"SAVEYUV"
#define HANDLE_DISPLAY_STATUS	1

#if 0
#define CALLDBG ENABLE
#else
#define CALLDBG DISABLE
#endif

#define FORCE_MONITOR		0
#define	FORCE_DECRYPTION	1

#define NO_FAST_AUDIO_RECOVERY_AFTER_TRICKMODE 0 // only to disable it (enabled by default), otherwise use -far cmdline option

#define RM_DEVICES_STC      0x1
#define RM_DEVICES_VIDEO    0x2
#define RM_DEVICES_AUDIO    0x4
#define RM_DEVICES_PSFDEMUX 0x8

#define RM_DEVICES_ALL (RM_DEVICES_STC | RM_DEVICES_VIDEO | RM_DEVICES_AUDIO | RM_DEVICES_PSFDEMUX)

#define KEYFLAGS (SET_KEY_DISPLAY | SET_KEY_PLAYBACK | SET_KEY_AUDIO | SET_KEY_DEBUG | SET_KEY_SPI)


#define DMA_BUFFER_SIZE_LOG2	15	// 32k buffer
#define DMA_BUFFER_COUNT	16	// 16*32k = 0x80000 = 0.5M 
#define DEMUX_FIFO_SIZE		(1<<DMA_BUFFER_SIZE_LOG2) * DMA_BUFFER_COUNT	// match the dma pool for standalone
#define DEMUX_XFER_FIFO_COUNT	DMA_BUFFER_COUNT	// same as dma pool buffers - this application sends complete buffer every time. 

#define VIDEO_FIFO_SIZE		( 1792*1024) /* "-vfifo 1792", default same value as in play_demux and play_hwdemux */
#define AUDIO_FIFO_SIZE		(  128*1024)
#define SPU_FIFO_SIZE		(  104*1024)
#define VIDEO_PTS_FIFO_COUNT    (512) /* ~8 sec fifo for 60 frames/sec */
#define VIDEO_INBAND_FIFO_COUNT (128)


#ifdef WITH_MONO
#define MAX_TASK_COUNT		1
#else
#define MAX_TASK_COUNT		3
#endif

#define FILE_PLAYBACK_START_POSITION		0 // byte position in file from where the playback starts - used for debug

/************************************************************************************************
Description of the events - masks correspondence:
  event, module - one event for all tasks         mask                       bit position
    SOFT_IRQ_EVENT_ERROR, CPUBlock                CPU_ERROR_EVENT_MASK       bit0
  
  event, module per task                          mask
    SOFT_IRQ_EVENT_XFER_RECEIVE_READY, DemuxTask  DEMUX_RECEIVE_EVENT_MASK   bit1 
    SOFT_IRQ_XFER_FIFO_READY, DemuxTask           DEMUX_SEND_EVENT_MASK      bit2, used only in file playback 
    SOFT_IRQ_INBAND_COMMAND, DemuxTask            DEMUX_EOS_EVENT_MASK       bit2, same mask as send event
    SOFT_IRQ_INBAND_COMMAND, VideoDecoder         VIDEO_EOS_EVENT_MASK       bit3, used only in file playback
    SOFT_IRQ_INBAND_COMMAND, DisplayBlock         DISPLAY_EOS_EVENT_MASK     bit4, used only in file playback
    SOFT_IRQ_INBAND_COMMAND, AudioDecoder         AUDIO_EOS_EVENT_MASK       bit5, used only in file playback
    SOFT_IRQ_EVENT_DEMUX_SECTION_END, DemuxTask   DEMUX_SECTION_EVENT_MASK   bit6
    SOFT_IRQ_EVENT_FILLING, DemuxTask             DEMUX_THRESHOLD_EVENT_MASK bit7

*************************************************************************************************/
/* 7 events = 1demux + 1video + 1display + 1audio for file playback + 1 xfer receive event + 1 section_end event/threshold when we don't use DMA */
#define MAX_EVENT_COUNT_PER_TASK      7

#define CPU_ERROR_EVENT_MASK          (1<<0)
#define DEMUX_RECEIVE_EVENT_MASK(i)   (1<<(1+0+i*MAX_EVENT_COUNT_PER_TASK))
#define DEMUX_SEND_EVENT_MASK(i)      (1<<(1+1+i*MAX_EVENT_COUNT_PER_TASK))
#define DEMUX_EOS_EVENT_MASK(i)       (1<<(1+1+i*MAX_EVENT_COUNT_PER_TASK))
#define VIDEO_EOS_EVENT_MASK(i)       (1<<(1+2+i*MAX_EVENT_COUNT_PER_TASK))
#define DISPLAY_EOS_EVENT_MASK(i)     (1<<(1+3+i*MAX_EVENT_COUNT_PER_TASK))
#define AUDIO_EOS_EVENT_MASK(i)       (1<<(1+4+i*MAX_EVENT_COUNT_PER_TASK))
#define DEMUX_SECTION_EVENT_MASK(i)   (1<<(1+5+i*MAX_EVENT_COUNT_PER_TASK))
#define DEMUX_THRESHOLD_EVENT_MASK(i) (1<<(1+6+i*MAX_EVENT_COUNT_PER_TASK))

// av_flags
#define VIDEO_PID_FROM_CMDLINE		(1 << 0)
#define PCR_PID_FROM_CMDLINE		(1 << 1)
#define AUDIO_PID_FROM_CMDLINE		(1 << 2)
#define AV_PIDS_ENABLE_FIRST_TIME	(1 << 3)
#define	ECM0_PID_FROM_CMDLINE		(1 << 4)
#define	ECM1_PID_FROM_CMDLINE		(1 << 5)
#define	TTX_PID_FROM_CMDLINE		(1 << 6)

static RMascii		crcLogFilename[1024];

#ifdef	DO_SAVE
void save_frame(int count,
				RMuint8* pLuma, RMuint32 luma_w, RMuint32 luma_h, RMuint32 luma_width,
				RMuint8* pChroma, RMuint32  chroma_w, RMuint32 chroma_h, RMuint32 chroma_width);
#endif

void compute_crclog_filename(RMascii* bsFilename, RMascii* logFilename);
RMstatus WaitForFrames(struct dcc_context *pSendContext);

#ifdef	DO_CAPTURE
int get_picture(struct dcc_context *dccContext);
#endif

struct dvb_csa_key arte_dvb_key_table[] = {
#ifdef ARTE_DVB_KEY_TABLE
#include "keys/arte_dvb_key_table.h"
#endif
};

/* STREAM-4.ts */
struct dvb_csa_key stream_dvb_key_table[] = {
#ifdef STREAM_DVB_KEY_TABLE
#include "keys/stream_dvb_key_table.h"
#endif
};

struct dvb_csa_key cweven_dvb_key_table[] = {
#ifdef CWEVEN_DVB_KEY_TABLE
#include "keys/cweven_dvb_key_table.h"
#endif
};

struct dvb_csa_key cwodd_dvb_key_table[] = {
#ifdef CWODD_DVB_KEY_TABLE
#include "keys/cwodd_dvb_key_table.h"
#endif
};
	
struct dvb_csa_key ecm1_dvb_key_table[] = {
#ifdef ECM1_DVB_KEY_TABLE
#include "keys/ecm1_dvb_key_table.h"
#endif
};
	
struct dvb_csa_key ecm4_dvb_key_table[] = {
	/* to prove that ECM parsing is Ok invalidate key_byte_counter and scrambling settings */
#ifdef ECM4_DVB_KEY_TABLE
#include "keys/ecm4_dvb_key_table.h"
#endif
};

struct dvb_csa_key cwtest_dvb_key_table[] = {
#ifdef CWTEST_DVB_KEY_TABLE
#define ORIGINAL_CWTEST  // for file CWtest.trp
//#define DVBCSA_ODD_TAR // for file phat_odd.mpg
#include "keys/cwtest_dvb_key_table.h"
#endif
};

/* vgs3.mpg */
struct dvb_csa_key vgs3_dvb_key_table[] = {
	/* to prove that ECM parsing is Ok invalidate key_byte_counter and scrambling settings */
#ifdef VGS3_DVB_KEY_TABLE
#include "keys/vgs3_dvb_key_table.h"
#endif
};

/* suitei05_KDDI_DRM.m2t */
struct aes_key skf_aes_key_table[] = {
#ifdef SKF_AES_KEY_TABLE
#include "keys/skf_aes_key_table.h"
#endif
};

/* dsodd.ts */
struct aes_key dsodd_aes_key_table[] = {
#ifdef DSODD_AES_KEY_TABLE
#include "keys/dsodd_aes_key_table.h"
#endif
};

/* scrambled.ts */
struct aes_key scrambled_aes_key_table[] = {
#ifdef SCRAMBLED_AES_KEY_TABLE
#define AES_SCRAMBLED_ORIGINAL
#include "keys/scrambled_aes_key_table.h"
#endif
};

/* dscps.ts */
struct aes_key dscps_aes_key_table[] = {
#ifdef DSCPS_AES_KEY_TABLE
#include "keys/dscps_aes_key_table.h"
#endif
};

/* aes cbc+ofb keys for transport/mpeg2/Confidential/AES/11-7 */
struct aes_key aes_cbc_ofb_key_table[] = {
#ifdef AES_CBC_OFB_KEY_TABLE
//#define AES_KEY_1107
//#define AES_KEY_SCR1111
//#define AES_KEY_SCR1112
#include "keys/aes_cbc_ofb_key_table.h"
#endif
};

/* aes ecb keys (clear partial block) for transport/mpeg2/HD_underwater_encrypted.ts */
struct aes_key aes_ecb_key_table[] = {
#ifdef AES_ECB_KEY_TABLE
#define AES_KEY_ICE_UNDER_CEMA
//#define AES_KEY_TSDAT
#include "keys/aes_ecb_key_table.h"
#endif
};

/* ############## AES_CBC_PRECIPHER TEST CODE BEGIN ############## */
/* hardcoded keys for pre-encrypted test files (ex: mummy.2keys.800000.aes.m2t) */
struct aes_2keys_test precipher_aes_key_table[] = {
#ifdef PRECIPHER_AES_KEY_TABLE
#include "keys/precipher_aes_key_table.h"
#endif
};
/* ############## AES_CBC_PRECIPHER TEST CODE END ############### */

struct dvb_arib_key arib_key_table[] = {
#ifdef MULTI2_EIGHT_KEYS
#define ARIB_KEY_TABLE
#define MULTI2_STREAM_8_ECM
#endif
#ifdef ARIB_KEY_TABLE
//#define MULTI2_U17_TVSIZUOKA
//#define MULTI2_TR27_ECM
//#define MULTI2_TR26_ECM_X2
//#define MULTI2_ARIB_STREAM_1_TO_7
//#define ARIB_orig
#include "keys/arib_key_table.h"
#endif
};

static RMstatus HwPlay(struct context_per_task *context);
static RMstatus HwStop(struct context_per_task *context);
static RMstatus OpenVideoDecoder(struct context_per_task *context);
static RMstatus Play(struct context_per_task *pContext, RMuint32 devices, enum DCCVideoPlayCommand mode);
static RMstatus Stop(struct context_per_task *pContext, RMuint32 devices);
static RMstatus Pause(struct context_per_task *pContext, RMuint32 devices);
static RMstatus ProcessKey(void);


static void printTimeOfDay(struct timeval now)
{
	RMuint64 secondsPerMinute = 60;
	RMuint64 secondsPerHour = 60 * secondsPerMinute;
	RMuint64 secondsPerDay = 24 * secondsPerHour;
	RMuint64 today, h, m;

	today = (now.tv_sec - ((now.tv_sec / secondsPerDay) * secondsPerDay));

	h = today / secondsPerHour;
	today -= h * secondsPerHour;
	m = today / secondsPerMinute;
	today -= m * secondsPerMinute;
	
	fprintf(stderr, "time is %02llu:%02llu:%02llu.%llu\n", h, m, today, (RMuint64)now.tv_usec);

}


#define GET_DATA_FIFO_INFO(pRUA, ModuleId, checkStarvation)		\
	{								\
		struct DataFIFOInfo DataFIFOInfo;			\
		RMreal fullness;					\
		RUAGetProperty(pRUA, ModuleId, RMGenericPropertyID_DataFIFOInfo, &DataFIFOInfo, sizeof(DataFIFOInfo)); \
		fullness = (RMreal)((100./DataFIFOInfo.Size)*DataFIFOInfo.Readable); \
		fprintf(stderr, "Data %lx: st=%08lx sz=%ld wr=%ld rd=%ld --> f : %.02f\n", ModuleId, DataFIFOInfo.StartAddress,	\
			DataFIFOInfo.Size, DataFIFOInfo.Writable,  DataFIFOInfo.Readable, fullness); \
		if ((fullness < 2) && checkStarvation) {		\
			struct timeval now;				\
									\
			gettimeofday(&now, NULL);			\
			RMDBGLOG((ENABLE, "close to starvation at\n")); \
			printTimeOfDay(now);				\
		}							\
	}								\


#define GET_XFER_FIFO_INFO(pRUA, ModuleId, checkStarvation)		\
	{								\
		struct XferFIFOInfo_type XferFIFOInfo;			\
		RMreal fullness;					\
		RMstatus err;						\
		err = RUAGetProperty(pRUA, ModuleId, RMGenericPropertyID_XferFIFOInfo, &XferFIFOInfo, sizeof(XferFIFOInfo)); \
		if ( RMFAILED(err) ) {					\
			fprintf(stderr, "XFER %lx: ERROR\n", ModuleId);	\
		}							\
		else {							\
			fullness = (RMreal)((100./XferFIFOInfo.Size)*XferFIFOInfo.Readable); \
			fprintf(stderr, "XFER %lx: st=%08lx sz=%ld wr=%ld rd=%ld er=%lx --> f : %.02f	\n", ModuleId, XferFIFOInfo.StartAddress, \
				XferFIFOInfo.Size, XferFIFOInfo.Writable,  XferFIFOInfo.Readable, XferFIFOInfo.Erasable, fullness); \
			if ((fullness < 2) && checkStarvation) {	\
				struct timeval now;			\
									\
				gettimeofday(&now, NULL);		\
				RMDBGLOG((ENABLE, "close to starvation at\n")); \
				printTimeOfDay(now);			\
			}						\
		}							\
	}								\


#define MONITOR_INTERVAL_US 250000

static void monitor(struct context_per_task *context, RMbool alwaysShow)
{	
	/* the bitrate reading of this probe is accurate only if the blocking call is RUASendData */

	struct timeval now;	
	RMuint64 elapsed; 	
	RMuint64 ptime; 	
	struct dcc_context *dcc_info = context->dcc_info;

	gettimeofday(&now, NULL);
	elapsed = (now.tv_sec - context->last.tv_sec) * 1000000;		
	elapsed += (now.tv_usec - context->last.tv_usec);
	if (elapsed > MONITOR_INTERVAL_US || alwaysShow){
		RMuint64 bitrate = (RMuint64)context->bitrate * 1000000;
		bitrate /= elapsed;

		context->meanBitrate += bitrate;
		context->meanCount++;

		DCCSTCGetTime(dcc_info->pStcSource, &ptime, 90000);			
		fprintf(stderr, "\n*****************************\n");
		fprintf(stderr, "timeofday %llu.%llu secs since epoch\n", (RMuint64)now.tv_sec, (RMuint64)now.tv_usec);
		printTimeOfDay(now);

		fprintf(stderr, "STC = %llu (%llu secs) bytes sent %lu\n", ptime, (ptime/90000), context->file_byte_counter);
		/* sample code to get fifo info */
		fprintf(stderr, "Demux :\n"); 
		GET_DATA_FIFO_INFO(dcc_info->pRUA, context->demux_task, FALSE);
		if (!context->play_opt->spi) {
			GET_XFER_FIFO_INFO(dcc_info->pRUA, context->demux_task, FALSE);
		}

		fprintf(stderr, "bitrate: mean %llu bit/sec, pseudo-instantaneus %llu bit/sec (%lu bytes/%llu us)\n", 
			context->meanBitrate / context->meanCount,
			bitrate, 
			context->bitrate >> 3, 
			elapsed);

		fprintf(stderr, "Video :\n"); 			
		GET_DATA_FIFO_INFO(dcc_info->pRUA, dcc_info->video_decoder, TRUE);

		if (dcc_info->pMultipleAudioSource) {
			struct DCCAudioSourceHandle audioHandle;
			RMuint32 i;

			for (i = 0; i < context->audioInstances; i++) {
				fprintf(stderr, "Audio[%lu] :\n", i);
				
				DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(dcc_info->pMultipleAudioSource, i, &audioHandle);
						
				GET_DATA_FIFO_INFO(dcc_info->pRUA, audioHandle.moduleID, TRUE);
			}
		}
			
		fprintf(stderr, "*****************************\n");			
		gettimeofday(&context->last, NULL);
		context->bitrate = 0;
		fflush(stderr);
		
	}					        

	return;
}





/****************************** static variables ******************************/

static RMuint32				task_count = 0;
static struct dcc_context       	*pdcc_info[MAX_TASK_COUNT];
static struct context_per_task		Tasks[MAX_TASK_COUNT] = {{0,},}; 
static struct RM_PSM_Context    	PSMcontext;
static RMuint32				output_count_per_task;
static RMuint32				idle_port = 0xff;

static RMbool				timedbg = FALSE;
static enum AudioDecoder_Codec_type	stream_type_6 = AudioDecoder_Codec_DTS;
static struct llad			*pllad = NULL;
static struct gbus			*pgbus = NULL;

/* ############## AES_CBC_PRECIPHER CODE BEGIN ############## */
static RMuint32 aes_state = 0;
/* ############## AES_CBC_PRECIPHER CODE END ################ */

#ifndef WITH_MONO
/* these can stay global as they are only used by the standalone play_psfdemux app */
static struct playback_cmdline  playback_options[MAX_TASK_COUNT]; 
static struct display_cmdline   display_options[MAX_TASK_COUNT]; 
static struct video_cmdline     video_options[MAX_TASK_COUNT]; 
static struct audio_cmdline     audio_options[MAX_TASK_COUNT*MAX_AUDIO_DECODER_INSTANCES]; 
static struct demux_cmdline     demux_options[MAX_TASK_COUNT]; 
static struct display_context   disp_info[MAX_TASK_COUNT]; 
static struct dh_context        dh_info[MAX_TASK_COUNT] = {{0,},}; 
#endif

static RMstatus InitPidTablePerTask(struct context_per_task *context)
{
	RMstatus err;
	RMuint32 i;

	RMDBGLOG((CALLDBG, "initPIDTablePerTask (context @0x%08lx)\n", (RMuint32)context));

#ifdef USE_HW_FIXED_PID_ENTRY
	/* set the fixed Pid entries available only for EM8634 */
	struct EMhwlibFixedPidEntry_type fixed_entry;
	struct EMhwlibOutputMask_type out;
	RMuint32 dummy;
	
	RMDBGLOG((CALLDBG, "initPIDTablePerTask - useHWFixedPIDEntry\n"));

	/* PAT */
	fixed_entry.input_type = EMhwlibPid_Ts;
	fixed_entry.flags = TS_FLAGS;
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PATPidEntry, &fixed_entry, sizeof(fixed_entry), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_PATPidEntry"));
		return err;
	}
	out.output_mask[0] = PAT_OUTPUT_MASK;
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PATPidEntryAddOutputs, &out, sizeof(out), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_PATPidEntryAddOutputs"));
		return err;
	}
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PATPidEntryEnable, &dummy, sizeof(dummy), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_PATPidEntryEnable"));
		return err;
	}
	/* CAT */
	fixed_entry.input_type = EMhwlibPid_Ts;
	fixed_entry.flags = TS_FLAGS;
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_CATPidEntry, &fixed_entry, sizeof(fixed_entry), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_CATPidEntry"));
		return err;
	}
	out.output_mask[0] = CAT_OUTPUT_MASK;
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_CATPidEntryAddOutputs, &out, sizeof(out), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_CATPidEntryAddOutputs"));
		return err;
	}
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_CATPidEntryEnable, &dummy, sizeof(dummy), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_CATPidEntryEnable"));
		return err;
	}
#endif
	
	/* set the initial Pid entries */
	for (i = 0; i < context->pid_table_count; i++) {
	
		struct DemuxTask_PidEntry_type entry;
		struct EMhwlibEntryOutputMask_type out;
		struct PidEntry_type *p = context->pid_table;
		struct DemuxTask_PidEntryRecipher_type recipher_entry;

		err = RUAGetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_AllocatePidEntry, &p[i].index, sizeof(p[i].index));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_AllocatePidEntry"));
			return err;
		}
		RMDBGLOG((ENABLE, "InitPidTablePerTask RMDemuxTaskPropertyID_AllocatePidEntry %ld\n", p[i].index));
		
		entry.index = p[i].index;
		entry.PidEntry.pid = p[i].pid;
		entry.PidEntry.input_type = p[i].input_type;
		entry.PidEntry.flags = p[i].flags;

		RMDBGLOG((ENABLE, "setPIDEntry[%lu]: index %lu pid 0x%lx type 0x%lx flags 0x%lx\n",
			  i,
			  (RMuint32)entry.index,
			  (RMuint32)entry.PidEntry.pid,
			  (RMuint32)entry.PidEntry.input_type,
			  (RMuint32)entry.PidEntry.flags));

		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntry, &entry, sizeof(entry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_PidEntry"));
			return err;
		}

		recipher_entry.index = p[i].index;
		recipher_entry.enable = FALSE;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryRecipher, &recipher_entry, sizeof(recipher_entry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_InitPidTablePerTask Error RMDemuxTaskPropertyID_PidEntryReciphe", context->id));
			return err;
		}
		
		out.entry_index = entry.index;
		out.output_mask[0] = p[i].output_mask[0];

		RMDBGLOG((ENABLE, "addOutputs2PIDEntry: mask 0x%lx\n", (RMuint32)out.output_mask[0]));

		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryAddOutputs, &out, sizeof(out), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_PidEntryAddOutputs"));
			return err;
		}
		
		if (p[i].enable) {
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryEnable, &entry.index, sizeof(entry.index), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_PidEntryEnable"));
				return err;
			}
		}
		
		/* initialize the variable used for playback */
		switch (p[i].type) {
#ifndef USE_HW_FIXED_PID_ENTRY
		case PAT_PID_ENTRY:
			context->pat_pidentry = p[i].index;
			break;
		case CAT_PID_ENTRY:
			context->cat_pidentry = p[i].index;
			break;
#endif
		case PMT_PID_ENTRY:
			context->pmt_pidentry = p[i].index;
			break;
		case VIDEO_PID_ENTRY:
			context->video_pidentry = p[i].index;
			break;
		case AUDIO_PID_ENTRY:
			context->audio_pidentry = p[i].index;
			break;
		case PCR_PID_ENTRY:
			context->pcr_pidentry = p[i].index;
			break;
		case ECM0_PID_ENTRY:
			context->ecm_pidentry[0] = p[i].index;
			break;
		case ECM1_PID_ENTRY:
			context->ecm_pidentry[1] = p[i].index;
			break;
		case TTX_PID_ENTRY:
			context->teletext_pidentry = p[i].index;
			break;
		}
	}
	
	return RM_OK;
}

static RMstatus DisablePidTablePerTask(struct RUA *pRUA, RMuint32 demux_task, struct PidEntry_type *p, RMuint32 pid_table_count)
{
	RMstatus err;
	RMuint32 i;

	RMDBGLOG((ENABLE, "disablePIDTablePerTask\n"));

#ifdef USE_HW_FIXED_PID_ENTRY
	{
		RMuint32 dummy;
		err = RUASetProperty(pRUA, demux_task, RMDemuxTaskPropertyID_PATPidEntryDisable, &dummy, sizeof(dummy), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "DisablePidTablePerTask Error RMDemuxTaskPropertyID_PATPidEntryDisable"));
			return err;
		}
		err = RUASetProperty(pRUA, demux_task, RMDemuxTaskPropertyID_CATPidEntryDisable, &dummy, sizeof(dummy), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "DisablePidTablePerTask Error RMDemuxTaskPropertyID_CATPidEntryDisable"));
			return err;
		}
	}
#endif
	for (i=0; i<pid_table_count; i++) {
		RMDBGLOG((ENABLE, "disabling PID_entry[%lu/%lu] index %lu\n", i, pid_table_count, p[i].index));
		err = RUASetProperty(pRUA, demux_task, RMDemuxTaskPropertyID_PidEntryDisable, &p[i].index, sizeof(p[i].index), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "DisablePidTablePerTask Error RMDemuxTaskPropertyID_PidEntryDisable"));
			return err;
		}
	}
	return RM_OK;
}

static RMstatus FreePidTablePerTask(struct RUA *pRUA, RMuint32 demux_task, struct PidEntry_type *p, RMuint32 pid_table_count)
{
	RMstatus err;
	RMuint32 i;

	RMDBGLOG((CALLDBG, "freePIDTablePerTask\n"));

	for (i=0; i<pid_table_count; i++) {
		err = RUASetProperty(pRUA, demux_task, RMDemuxTaskPropertyID_FreePidEntry, &p[i].index, sizeof(p[i].index), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "FreePidTablePerTask Error RMDemuxTaskPropertyID_FreePidEntry"));
			return err;
		}
		RMDBGLOG((ENABLE, "FreePidTablePerTask RMDemuxTaskPropertyID_FreePidEntry %ld\n", p[i].index));
	}
	return RM_OK;
}

static RMstatus InitPesTablePerTask(struct context_per_task *context)
{
	RMstatus err;
	RMuint32 i;
	struct PesEntry_type *p = context->pes_table;
	RMuint32 pes_table_count = context->pes_table_count;
 
	RMDBGLOG((CALLDBG, "initPESTablePerTask\n"));

	/* set the initial Pes entries */
	for (i=0; i<pes_table_count; i++) {
		struct DemuxTask_PesEntry_type entry;
		entry.index = i;
		entry.PesEntry.stream_id = p[i].stream_id;
		entry.PesEntry.substream_id = p[i].substream_id;
		entry.PesEntry.enable = p[i].enable;
		entry.PesEntry.output_mask[0] = p[i].output_mask[0];
		entry.PesEntry.cipher_mask = p[i].cipher_mask;
		entry.PesEntry.cipher_index[0] = p[i].cipher_index[0];
		if(context->demux_opt->send_scrambled_packets_for_invalid_key)
			entry.PesEntry.input_type = EMhwlibPes_packet1;
		else
			entry.PesEntry.input_type = EMhwlibPes_packet;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PesEntry, &entry, sizeof(entry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "InitPesTablePerTask Error RMDemuxTaskPropertyID_PesEntry"));
			return err;
		}
	}
	return RM_OK;
}

static RMstatus DisablePesTablePerTask(struct RUA *pRUA, RMuint32 demux_task, struct PesEntry_type *p, RMuint32 pes_table_count)
{
	RMstatus err;
	RMuint32 i;

	RMDBGLOG((CALLDBG, "disablePESTablePerTask\n"));

	for (i=0; i<pes_table_count; i++) {
		struct DemuxTask_PesEntry_type entry;
		entry.index = i;
		entry.PesEntry.stream_id = p[i].stream_id;
		entry.PesEntry.substream_id = p[i].substream_id;
		entry.PesEntry.enable = FALSE;
		entry.PesEntry.output_mask[0] = p[i].output_mask[0];
		entry.PesEntry.cipher_mask = p[i].cipher_mask;
		entry.PesEntry.cipher_index[0] = p[i].cipher_index[0];
		entry.PesEntry.input_type = p[i].input_type;
		err = RUASetProperty(pRUA, demux_task, RMDemuxTaskPropertyID_PesEntry, &entry, sizeof(entry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "DisablePesTable Error RMDemuxTaskPropertyID_PesEntry"));
			return err;
		}
	}
	return RM_OK;
}

static RMstatus InitSectionTable(struct context_per_task *context)
{
	RMstatus err;
	RMuint32 i;
	
	RMDBGLOG((CALLDBG, "initSectionTable (context @0x%08lx)\n", (RMuint32)context));

	for (i=0; i<context->match_section_table_count;i++) {
		struct DemuxTask_MatchSectionEntry_type section_entry;
		
		err = RUAGetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_AllocateMatchSectionEntry,
				     &context->match_section_table[i].index, sizeof(context->match_section_table[i].index));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "InitSectionTable Error RMDemuxTaskPropertyID_AllocateMatchSectionEntry"));
			return err;
		}
		RMDBGLOG((ENABLE, "InitSectionTable RMDemuxTaskPropertyID_AllocateMatchSectionEntry %ld\n",
			  context->match_section_table[i].index));
		
		section_entry.Index = context->match_section_table[i].index;
		section_entry.SectionEntry = context->match_section_table[i].section_entry;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_MatchSectionEntry,
				     &section_entry, sizeof(section_entry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error RMDemuxTaskPropertyID_MatchSectionEntry"));
			return err;
		}
	}
	return RM_OK;
}
	
static RMstatus FreeSectionTable(struct context_per_task *context)
{
	RMstatus err;
	RMuint32 i;
	
	RMDBGLOG((CALLDBG, "freeSectionTable (context @0x%08lx)\n", (RMuint32)context));

	for (i=0; i<context->match_section_table_count;i++) {
		
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_FreeMatchSectionEntry,
				     &context->match_section_table[i].index, sizeof(context->match_section_table[i].index), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "FreeSectionTable Error RMDemuxTaskPropertyID_FreeMatchSectionEntry"));
			return err;
		}
		RMDBGLOG((ENABLE, "FreeSectionTable RMDemuxTaskPropertyID_FreeMatchSectionEntry %ld\n",
			  context->match_section_table[i].index));
	}
	return RM_OK;
}

static void ClearInfoTable(struct context_per_task *context)
{

	RMuint32 i;

	RMMemset(&(context->pat_info), 0, sizeof(struct PATInfo_type));
	RMMemset(&(context->cat_info), 0, sizeof(struct CATInfo_type));
	RMMemset(&(context->VideoPidList), 0, sizeof(struct ESPidList_type));
	RMMemset(&(context->AudioPidList), 0, sizeof(struct ESPidList_type));

	for (i = 0; i < MAX_PROGRAM_NUMBER; i++) {
		RMMemset(&(context->pmt_info[i]), 0, sizeof(struct PMTInfo_type));
	}
 
}

static RMstatus ResetDemuxTask(struct context_per_task *context)
{
	RMstatus err;
	struct DemuxTask_MatchSectionEntry_type section_entry;

	DisablePidTablePerTask(context->pRUA, context->demux_task, context->pid_table, context->pid_table_count);

	ClearInfoTable(context);
	context->pat = FALSE;
	context->pmt = FALSE;
	context->cat = FALSE;
	context->av_flags = AV_PIDS_ENABLE_FIRST_TIME;
	context->video_pid = 0x1FFF;
	context->audio_pid = 0x1FFF;
	context->pcr_pid = 0x1FFF;
	context->ecm_pid[0] = 0x1FFF;
	context->ecm_pid[1] = 0x1FFF;

	/* reset PAT version_number in hardware section filter */
	context->match_section_table[0].section_entry.mask[5] = 0x00; 
	context->match_section_table[0].section_entry.mode[5] = 0x00;
	context->match_section_table[0].section_entry.comp[5] = 0x00;

	section_entry.Index = context->match_section_table[0].index;
	section_entry.SectionEntry = context->match_section_table[0].section_entry;
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_MatchSectionEntry,
		&section_entry, sizeof(section_entry), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error RMDemuxTaskPropertyID_MatchSectionEntry"));
	}

	/* reset PMT version_number in hardware section filter */
	context->match_section_table[1].section_entry.mask[5] = 0x00; 
	context->match_section_table[1].section_entry.mode[5] = 0x00;
	context->match_section_table[1].section_entry.comp[5] = 0x00;

	section_entry.Index = context->match_section_table[1].index;
	section_entry.SectionEntry = context->match_section_table[1].section_entry;
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_MatchSectionEntry,
		&section_entry, sizeof(section_entry), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error RMDemuxTaskPropertyID_MatchSectionEntry"));
	}

	/* reset CAT version_number in hardware section filter */
	context->match_section_table[3].section_entry.mask[5] = 0x00; 
	context->match_section_table[3].section_entry.mode[5] = 0x00;
	context->match_section_table[3].section_entry.comp[5] = 0x00;

	section_entry.Index = context->match_section_table[3].index;
	section_entry.SectionEntry = context->match_section_table[3].section_entry;
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_MatchSectionEntry,
		&section_entry, sizeof(section_entry), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error RMDemuxTaskPropertyID_MatchSectionEntry"));
	}

	/* reset ECM for next parity */
	context->match_section_table[4].section_entry.mask[0] = 0xFC;
	context->match_section_table[4].section_entry.comp[0] = 0x80;
	
	section_entry.Index = context->match_section_table[4].index;
	section_entry.SectionEntry = context->match_section_table[4].section_entry;
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_MatchSectionEntry,
		&section_entry, sizeof(section_entry), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "decoder: Error RMDemuxTaskPropertyID_MatchSectionEntry");
		return RM_ERROR;
	}
	context->match_section_table[5].section_entry.mask[0] = 0xFC;
	context->match_section_table[5].section_entry.comp[0] = 0x80;
	
	section_entry.Index = context->match_section_table[5].index;
	section_entry.SectionEntry = context->match_section_table[5].section_entry;
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_MatchSectionEntry,
		&section_entry, sizeof(section_entry), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "decoder: Error RMDemuxTaskPropertyID_MatchSectionEntry");
		return RM_ERROR;
	}

	// enable pat pid
#ifdef USE_HW_FIXED_PID_ENTRY
	{
		RMuint32 dummy;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PATPidEntryEnable, &dummy, sizeof(dummy), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "ResetDemuxTask Error RMDemuxTaskPropertyID_PATPidEntryEnable"));
			return err;
		}
	}
#else
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryEnable,
	&context->pat_pidentry, sizeof(context->pat_pidentry), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "ResetDemuxTask Error RMDemuxTaskPropertyID_PidEntryEnable"));
		return err;
	}
#endif

	return RM_OK;
}

#ifdef MULTI2_EIGHT_KEYS
static void HardcodeAVPids(struct context_per_task *context)
{	   
	context->VideoPidList.index = 0;
	context->VideoPidList.count = 1;
	context->VideoPidList.pcr_pid = 0x1ff;
	context->VideoPidList.stream_type[0] = 2; 
	context->VideoPidList.elementary_pid[0] = 0x100;
	context->VideoPidList.es_ecm_pid[0] = 0x1f1;
	RMDBGLOG((ENABLE, "==============%ld_HardcodeAVPids vid pid=0x%x ecmpid=0x%x\n", 
				context->id, context->VideoPidList.elementary_pid[0],  context->VideoPidList.es_ecm_pid[0] ));
	
	context->AudioPidList.index = 0;
	context->AudioPidList.count = 1;
	context->AudioPidList.pcr_pid = 0x1ff;
	context->AudioPidList.stream_type[0] = 6;
	context->AudioPidList.elementary_pid[0] = 0x110;
	context->AudioPidList.es_ecm_pid[0] = 0x1f2;
	RMDBGLOG((ENABLE, "==============%ld_HardcodeAVPids aud pid=0x%x ecmpid=0x%x\n", 
				context->id, context->AudioPidList.elementary_pid[0],  context->AudioPidList.es_ecm_pid[0] ));
	return;
}

// hardcoding data pids works together with hardcoding the tables in psfdemux_parsing and 
// ecm association in psfdemux_drm ecmcallback
static void HardcodeDataPids(struct context_per_task *context) 
{
	RMuint32 index = 0;
	context->DataPidList.index = 0;
	context->DataPidList.count = 6;
	context->DataPidList.share_ecm = FALSE;
	for( index = 0; index<context->DataPidList.count; index++ ){
		context->DataPidList.data_pid_entries[index] = DATA_ENTRY+index;
		context->DataPidList.ecm_pid_entries[index] = DATA_ENTRY+6+index;
		context->DataPidList.cipher_indices[index] = 2 + index;
	}
	index = 0;
	context->DataPidList.elementary_pids[index] = 0x111;
	context->DataPidList.ecm_pids[index] = 0x1f3;
	index = 1;
	context->DataPidList.elementary_pids[index] = 0x140;
	context->DataPidList.ecm_pids[index] = 0x1f4;
	index = 2;
	context->DataPidList.elementary_pids[index] = 0x150;
	context->DataPidList.ecm_pids[index] = 0x1f5;
	index = 3;
	context->DataPidList.elementary_pids[index] = 0x155;
	context->DataPidList.ecm_pids[index] = 0x1f6;
	index = 4;
	context->DataPidList.elementary_pids[index] = 0x156;
	context->DataPidList.ecm_pids[index] = 0x1f7;
	index = 5;
	context->DataPidList.elementary_pids[index] = 0x157;
	context->DataPidList.ecm_pids[index] = 0x1f8;
	for( index = 0; index<context->DataPidList.count; index++ ){
		RMDBGLOG((ENABLE, "==============%ld_HardcodeDataPids data %d pid=0x%x (entry %d) ecmpid=0x%x (entry %d), use cipher %d\n", 
					context->id, index, context->DataPidList.elementary_pids[index], context->DataPidList.data_pid_entries[index],
					context->DataPidList.ecm_pids[index], context->DataPidList.ecm_pid_entries[index], context->cipher_index[context->DataPidList.cipher_indices[index]] ));
	}
	return;
}

static RMstatus SetHwDataPlayback(struct context_per_task *context)
{
	RMstatus err;
	RMuint32 i;
	RMbool one_data_entry_enabled = FALSE;
	struct DemuxTask_PidEntry_type entry;
	struct DemuxTask_PidEntryAddCipher_type cipher;
	RMDBGLOG((ENABLE, "============== %ld_SetHwDataPlayback data pid count=%d \n", context->id, context->DataPidList.count ));
	for( i=0; i<context->DataPidList.count; i++ ) {
		if( context->DataPidList.elementary_pids[i] != 0x1fff ) {
			// enable data pid
			entry.index = context->DataPidList.data_pid_entries[i];
			entry.PidEntry.pid = context->DataPidList.elementary_pids[i];
			entry.PidEntry.input_type = EMhwlibPid_Ts;
			entry.PidEntry.flags = TS_FLAGS;
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntry, &entry, sizeof(entry), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "%SetHwDataPlayback Error data RMDemuxTaskPropertyID_PidEntry", context->id));
				return err;
			}
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryEnable, &entry.index, sizeof(entry.index), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "%SetHwDataPlayback Error data RMDemuxTaskPropertyID_PidEntryEnable", context->id));
				return err;
			}
			RMDBGLOG((ENABLE, "============== set data pid %d 0x%x \n", entry.index, entry.PidEntry.pid ));
			one_data_entry_enabled = TRUE;
			if( context->DataPidList.share_ecm == 0 && context->DataPidList.ecm_pids[i] != 0x1fff ) {
				// associate the ecm pid to the data pid
				cipher.index = context->DataPidList.data_pid_entries[i]; // pid index 
				cipher.pid_cipher_index = 0;
				cipher.cipher_index = context->cipher_index[ context->DataPidList.cipher_indices[i] ];
				err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryAddCipher, &cipher, sizeof(cipher), 0);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "SetHwDataPlayback Error RMDemuxTaskPropertyID_PidEntryAddCipher"));
					return err;
				}
				RMDBGLOG((ENABLE, "==============          add cipher %d %d  \n", cipher.index, cipher.cipher_index));
				// and the corresponding ecm pid
				entry.index = context->DataPidList.ecm_pid_entries[i];
				entry.PidEntry.pid = context->DataPidList.ecm_pids[i];
				entry.PidEntry.input_type = EMhwlibPid_Ts;
				entry.PidEntry.flags = TS_FLAGS;
				err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntry, &entry, sizeof(entry), 0);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "%SetHwDataPlayback Error data RMDemuxTaskPropertyID_PidEntry", context->id));
					return err;
				}
				err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryEnable, &entry.index, sizeof(entry.index), 0);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "%SetHwDataPlayback Error data RMDemuxTaskPropertyID_PidEntryEnable", context->id));
					return err;
				}
				RMDBGLOG((ENABLE, "==============                  with ecm pid %d 0x%x \n", entry.index, entry.PidEntry.pid ));
			}
		}
		else { // disable the  pid and ecm pid
			entry.index = context->DataPidList.data_pid_entries[i];
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryDisable, &entry.index, sizeof(entry.index), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "%SetHwDataPlayback Error data RMDemuxTaskPropertyID_PidEntryDisable", context->id));
				return err;
			}
			RMDBGLOG((ENABLE, "============== disabled data pid %d 0x%x\n", entry.index, context->DataPidList.elementary_pids[i] ));
			entry.index = context->DataPidList.ecm_pid_entries[i];
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryDisable, &entry.index, sizeof(entry.index), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "%SetHwDataPlayback Error data RMDemuxTaskPropertyID_PidEntryDisable", context->id));
				return err;
			}
			RMDBGLOG((ENABLE, "============== disabled ecm pid %d 0x%x\n", entry.index, context->DataPidList.ecm_pids[i] ));
		}
	}	

	if( context->DataPidList.share_ecm && one_data_entry_enabled ) {
		if( context->DataPidList.ecm_pids[0] != 0x1fff ) {
			// associate this ecm pid to all data pids
			for( i=0; i<context->DataPidList.count; i++ ) {
				cipher.index = context->DataPidList.data_pid_entries[i];
				cipher.pid_cipher_index = 0;
				cipher.cipher_index = context->cipher_index[ context->DataPidList.cipher_indices[0] ];
				err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryAddCipher, &cipher, sizeof(cipher), 0);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "SetHwDataPlayback Error RMDemuxTaskPropertyID_PidEntryAddCipher"));
					return err;
				}
			}
			// enable the ecm pid entry
			entry.index = context->DataPidList.ecm_pid_entries[0];
			entry.PidEntry.pid = context->DataPidList.ecm_pids[0];
			entry.PidEntry.input_type = EMhwlibPid_Ts;
			entry.PidEntry.flags = TS_FLAGS;
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntry, &entry, sizeof(entry), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "%SetHwDataPlayback Error data RMDemuxTaskPropertyID_PidEntry", context->id));
				return err;
			}
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryEnable, &entry.index, sizeof(entry.index), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "%SetHwDataPlayback Error data RMDemuxTaskPropertyID_PidEntryEnable", context->id));
				return err;
			}
		}
	}
	
	return RM_OK;
}
#endif //#ifdef MULTI2_EIGHT_KEYS

	
static RMstatus SetHwAVPlayback(struct context_per_task *context)
{
	RMstatus err;
	struct DemuxTask_PidEntry_type entry;
	struct DemuxTask_PidEntryAddCipher_type cipher;

	RMDBGLOG((ENABLE, "============== %ld_SetHwAVPlayback vpid=%x apid=%x pcrpid=%x\n",
		  context->id, context->video_pid, context->audio_pid, context->pcr_pid));
	
	if (context->video_pid != 0x1fff) {
		/* set the video pid */
		entry.index = context->video_pidentry;
		entry.PidEntry.pid = context->video_pid;
		if(context->demux_opt->send_scrambled_packets_for_invalid_key)
			entry.PidEntry.input_type = EMhwlibPid_Ts1;
		else
			entry.PidEntry.input_type = EMhwlibPid_Ts;

		entry.PidEntry.flags = TS_FLAGS;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntry, &entry, sizeof(entry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error video RMDemuxTaskPropertyID_PidEntry", context->id));
			return err;
		}
	
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryEnable, &entry.index, sizeof(entry.index), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error video RMDemuxTaskPropertyID_PidEntryEnable", context->id));
			return err;
		}
	}
	else {
		/* disable the video pid */
		entry.index = context->video_pidentry;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryDisable, &entry.index, sizeof(entry.index), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error video RMDemuxTaskPropertyID_PidEntryDisable", context->id));
			return err;
		}
	}
	
	if (context->audio_pid != 0x1fff) {
		/* set the audio pid */
		entry.index = context->audio_pidentry;
		entry.PidEntry.pid = context->audio_pid;
		if(context->demux_opt->send_scrambled_packets_for_invalid_key)
			entry.PidEntry.input_type = EMhwlibPid_Ts1;
		else
			entry.PidEntry.input_type = EMhwlibPid_Ts;
		entry.PidEntry.flags = TS_FLAGS;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntry, &entry, sizeof(entry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error audio RMDemuxTaskPropertyID_PidEntry", context->id));
			return err;
		}
	
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryEnable, &entry.index, sizeof(entry.index), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error audio RMDemuxTaskPropertyID_PidEntryEnable", context->id));
			return err;
		}
	}
	else {
		/* disable the audio pid */
		entry.index = context->audio_pidentry;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryDisable, &entry.index, sizeof(entry.index), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error audio RMDemuxTaskPropertyID_PidEntryDisable", context->id));
			return err;
		}
	}
	
	if (context->teletext_pid != 0x1fff  && context->video_opt->display_ttx) {
		/* set the audio pid */
		entry.index = context->teletext_pidentry;
		entry.PidEntry.pid = context->teletext_pid;
		entry.PidEntry.input_type = EMhwlibPid_Ts;
		entry.PidEntry.flags = TS_FLAGS;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntry, &entry, sizeof(entry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error teletext RMDemuxTaskPropertyID_PidEntry", context->id));
			return err;
		}
	
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryEnable, &entry.index, sizeof(entry.index), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error teletext RMDemuxTaskPropertyID_PidEntryEnable", context->id));
			return err;
		}
	}
	else {
		/* disable the teletext pid */
		entry.index = context->teletext_pidentry;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryDisable, &entry.index, sizeof(entry.index), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error teletext RMDemuxTaskPropertyID_PidEntryDisable", context->id));
			return err;
		}
	}
	
	/* set the pcr pid */
#ifdef USE_HW_PCR_PID_ENTRY
	/* EM8634 has three hardware PCR filters but only two clock recovery blocks,
	 limiting us to only two hardware PCR filters. For the third task we have to use PCR extraction from PidBank.
	 For task 0 and 1 I will use the hardware PCR pids and for task 2 the PidBank pcr pid. */
	if(context->id < 2) {
		/* Set and enable the pcr extraction from special hardware pcr pid. We don't need any output connected. */
		if ( context->pcr_pid != 0x1fff ) {
			RMuint32 dummy;
			struct EMhwlibPCRPidEntry_type hwpcr;

			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback USE_HW_PCR_PID_ENTRY\n", context->id));
			hwpcr.pid = context->pcr_pid;
			hwpcr.clock_recovery_id = context->id; /* 0 or 1 for EM8634. Next chips will have a clock recovery for every PCR: 0, 1, 2. */
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PCRPidEntry, &hwpcr, sizeof(hwpcr), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error pcr RMDemuxTaskPropertyID_PCRPidEntry", context->id));
				return err;
			}
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PCRPidEntryEnable, &dummy, sizeof(dummy), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error pcr RMDemuxTaskPropertyID_PCRPidEntryEnable", context->id));
				return err;
			}
		}
		else {
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PCRPidEntryDisable, &dummy, sizeof(dummy), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error pcr RMDemuxTaskPropertyID_PCRPidEntryDisable", context->id));
				return err;
			}
		}
	}
	else /* third task will use PCR extraction from PidBank. */
#endif
	{
		/* select the pcr extraction from pid bank. we need to have an output associated and enabled. */
		if ( (context->pcr_pid != context->video_pid) && (context->pcr_pid != context->audio_pid) && (context->pcr_pid != 0x1fff) ) {
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidBankPCRPid, &context->pcr_pid, sizeof(context->pcr_pid), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error pcr RMDemuxTaskPropertyID_PidBankPCRPid", context->id));
				return err;
			}

			/* set and enable the pcr in pid bank */
			entry.index = context->pcr_pidentry;
			entry.PidEntry.pid = context->pcr_pid;
			entry.PidEntry.input_type = EMhwlibPid_Ts;
			entry.PidEntry.flags = TS_FLAGS;
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntry, &entry, sizeof(entry), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error pcr RMDemuxTaskPropertyID_PidEntry", context->id));
				return err;
			}
	
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryEnable, &entry.index, sizeof(entry.index), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error pcr RMDemuxTaskPropertyID_PidEntryEnable", context->id));
				return err;
			}
		}
		else if  ((context->pcr_pid  == context->video_pid) || (context->pcr_pid == context->audio_pid)) {
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidBankPCRPid, &context->pcr_pid, sizeof(context->pcr_pid), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error pcr RMDemuxTaskPropertyID_PidBankPCRPid", context->id));
				return err;
			}

		}
		else {
			/* disable the pcr pid */
			entry.index = context->pcr_pidentry;
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryDisable, &entry.index, sizeof(entry.index), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error pcr RMDemuxTaskPropertyID_PidEntryDisable", context->id));
				return err;
			}
		}
	}

	/* Set the ECM pid */
	if (context->ecm_pid[0] != 0x1FFF) {
		// Apply cipher to pid of video
		cipher.index = context->video_pidentry;		/* pid index */
		cipher.pid_cipher_index = 0;			/* first and only cipher per pid in current implementation */
		cipher.cipher_index = context->cipher_index[0];	/* 1st cipher index of this task */
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryAddCipher, &cipher, sizeof(cipher), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_PidEntryAddCipher"));
			return err;
		}
		// Apply cipher to pid of audio
		if (context->ecm_pid[0] == context->ecm_pid[1]) {
			cipher.index = context->audio_pidentry;		/* pid index */
			cipher.pid_cipher_index = 0;			/* first and only cipher per pid in current implementation */
			cipher.cipher_index = context->cipher_index[0];	/* 1st cipher index of this task */
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryAddCipher, &cipher, sizeof(cipher), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_PidEntryAddCipher"));
				return err;
			}
		}

		fprintf(stderr, "   m>   ecm_pid[0]=0x%04X pidentry[0]=0x%02x\n", (RMuint16)(context->ecm_pid[0]), (RMuint16)(context->ecm_pidentry[0]));
		entry.index = context->ecm_pidentry[0];
		entry.PidEntry.pid = context->ecm_pid[0];
		entry.PidEntry.input_type = EMhwlibPid_Ts;
		entry.PidEntry.flags = TS_FLAGS;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntry, &entry, sizeof(entry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error ECM RMDemuxTaskPropertyID_PidEntry", context->id));
			return err;
		}

		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryEnable, &entry.index, sizeof(entry.index), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error ECM RMDemuxTaskPropertyID_PidEntryEnable", context->id));
			return err;
		}
	}
	else {
		/* disable the ecm video pid */
		entry.index = context->ecm_pidentry[0];
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryDisable, &entry.index, sizeof(entry.index), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error ECM0 RMDemuxTaskPropertyID_PidEntryDisable", context->id));
			return err;
		}
	}

	if ((context->ecm_pid[1] != 0x1FFF) && (context->ecm_pid[1] != context->ecm_pid[0])) {
		// Apply cipher to pid of audio
		cipher.index = context->audio_pidentry;		/* pid index */
		cipher.pid_cipher_index = 0;			/* first and only cipher per pid in current implementation */
#if defined(MULTI2_ARIB_STREAM_1_TO_7) || defined(MULTI2_TR26_ECM_X2)
		cipher.cipher_index = context->cipher_index[0];	/* Quick test: force video and audio share the same cipher index */
#else
		cipher.cipher_index = context->cipher_index[1];	/* 2nd cipher index of this task */
#endif
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryAddCipher, &cipher, sizeof(cipher), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_PidEntryAddCipher"));
			return err;
		}

		fprintf(stderr, "   m>   ecm_pid[1]=0x%04X pidentry[1]=0x%02x\n", (RMuint16)(context->ecm_pid[1]), (RMuint16)(context->ecm_pidentry[1]));
		entry.index = context->ecm_pidentry[1];
		entry.PidEntry.pid = context->ecm_pid[1];
		entry.PidEntry.input_type = EMhwlibPid_Ts;
		entry.PidEntry.flags = TS_FLAGS;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntry, &entry, sizeof(entry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error ECM RMDemuxTaskPropertyID_PidEntry", context->id));
			return err;
		}

		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryEnable, &entry.index, sizeof(entry.index), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error ECM RMDemuxTaskPropertyID_PidEntryEnable", context->id));
			return err;
		}
	}
	else {
		/* disable the ecm audio pid */
		entry.index = context->ecm_pidentry[1];
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryDisable, &entry.index, sizeof(entry.index), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error ECM1 RMDemuxTaskPropertyID_PidEntryDisable", context->id));
			return err;
		}
	}

#if (FORCE_DECRYPTION)
	if ( (  (context->app_type == aes_cbc_decryption) 
		|| (context->app_type == aes_ecb_decryption)
		|| (context->app_type == aes_ofb_decryption)
		|| (context->app_type == multi2_decryption)
		|| (context->app_type == dvbcsa_decryption) ) && 
	    ((context->ecm_pid[0] == 0x1FFF) && (context->ecm_pid[1] = 0x1FFF))) {
		// Apply cipher to pid of video
		cipher.index = context->video_pidentry;		/* pid index */
		cipher.pid_cipher_index = 0;			/* first and only cipher per pid in current implementation */
		cipher.cipher_index = context->cipher_index[0];	/* 1st cipher index of this task */
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryAddCipher, &cipher, sizeof(cipher), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_PidEntryAddCipher"));
			return err;
		}

		// Apply cipher to pid of audio
		cipher.index = context->audio_pidentry;		/* pid index */
		cipher.pid_cipher_index = 0;			/* first and only cipher per pid in current implementation */
		cipher.cipher_index = context->cipher_index[0];	/* 1st cipher index of this task */
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryAddCipher, &cipher, sizeof(cipher), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_PidEntryAddCipher"));
			return err;
		}
	}
#endif

	return RM_OK;
}

static RMstatus SwitchAudioDecoder(struct context_per_task *context, enum AudioDecoder_Codec_type ACodec)
{

	RMstatus err = RM_OK;

	if (context->audio_opt->Codec == ACodec) return err;

	RMDBGLOG((ENABLE, "%lx_SwitchAudioDecoder: from %u to %u SPDIF[%u]\n",
		context->id, context->audio_opt->Codec, ACodec, context->audio_opt->Spdif));
	context->audio_opt->Codec = ACodec;
	if (ACodec == AudioDecoder_Codec_AC3) {
		context->audio_opt->Ac3Params.OutputChannels = Ac3_LR;
			
		if (!context->audio_opt->OutputChannelsExplicitAssign)
			context->audio_opt->OutputChannels = Audio_Out_Ch_LR;
	}

	/* apply the audio format - uninit, set codec, set specific parameters, init */
	err = apply_audio_decoder_options(context->dcc_info, context->audio_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%lx_Error applying audio_decoder_options err=%d\n", context->id, err));
		return RM_ERROR;
	}

	apply_dvi_hdmi_audio_options(context->dcc_info, context->audio_opt, 0, FALSE, FALSE, FALSE);

	err = Play(context, RM_DEVICES_AUDIO, VideoDecoder_Command_PlayFwd);
	return err;
}

static RMstatus SwitchVideoDecoder(struct context_per_task *context, enum VideoDecoder_Codec_type VCodec, enum MPEG_Profile MPEGProfile)
{
	RMstatus err = RM_OK;
	RMuint32 dummy;
	struct ReceiveThreshold_type rec_thr;
	struct DemuxOutput_Connect_type	connect;
	RMuint32 demux_output;

	if ((context->video_opt->MPEGProfile == MPEGProfile) && (context->video_opt->Codec == VCodec))
		return err;

	fprintf(stderr, "\nSwitch Video Codec from %u to %u Profile from %u to %u\n", context->video_opt->Codec, VCodec, context->video_opt->MPEGProfile, MPEGProfile);

	demux_output = EMHWLIB_MODULE(DemuxOutput, context->videoDemuxOutputIndex + output_count_per_task * context->id); 

	err = RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_Close, &dummy, sizeof(dummy), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "SwitchVideoDecoder cannot close DemuxOutput %lu err=%d\n", demux_output, err));
		return err;
	}

	RMDBGLOG((LOCALDBG, "SwitchVideoDecoder: CloseVideoSource %p\n", context->dcc_info->pVideoSource));
	err = DCCCloseVideoSource(context->dcc_info->pVideoSource);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%lx_Error cannot close video decoder err=%d\n", context->id, err));
		return err;
	}
	clear_video_options(context->dcc_info, context->video_opt);
#ifndef WITH_MONO
	clear_display_options(context->dcc_info, context->disp_opt);
#endif
	
	context->video_opt->Codec = VCodec;
	context->video_opt->MPEGProfile = MPEGProfile;

	err = OpenVideoDecoder(context); /* spu_hack: this will open the SpuDecoder too */
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "SwitchVideoDecoder: can NOT open video decoder\n"));
		return err;
	}

	/* the decoder will provide the bitstream, pts and inband fifo - no need to open a DemuxOutput, just connect */
	context->output_table[context->videoDemuxOutputIndex].consumer_module_id = context->dcc_info->video_decoder;
	connect.demux_task_module_id = context->demux_task;
	connect.consumer_module_id = context->output_table[context->videoDemuxOutputIndex].consumer_module_id;
	err = RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_Connect, &connect, sizeof(connect), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "SwitchVideoDecoder: DemuxOutput %ld failed to connect consumer=0x%lx\n",
			demux_output, connect.consumer_module_id));
		return err;
	}

	err = DCCXSetVideoDecoderSourceCodec(context->dcc_info->pVideoSource, context->vcodec);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set video decoder codec %d\n", err));
		return err;
	}

	/* apply the fixed vop rate if required */
	err = apply_video_decoder_options(context->dcc_info, context->video_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%lx_Error applying video_decoder_options err=%d\n", context->id, err));
		return RM_ERROR;
	}

	if ((! context->video_opt->VopInfo.FixedVopRate) && (! context->video_opt->vtimescale.enable)) { 
		/* time stamps are in 45k, ask the decoder to interpolate the time info from stream.
		   For m4v the property will succeed. */
		context->video_opt->vtimescale.enable = TRUE;
		context->video_opt->vtimescale.time_resolution = 90000;
		err = RUASetProperty(context->dcc_info->pRUA, context->dcc_info->video_decoder, RMVideoDecoderPropertyID_VideoTimeScale,
		     &context->video_opt->vtimescale, sizeof(context->video_opt->vtimescale), 0 );
		if (RMSUCCEEDED(err)) {
			RMDBGLOG((ENABLE, "set video time scale: %ld ticks per second\n", context->video_opt->vtimescale.time_resolution));
		}
		else if (0) {
			/* time scaling is not supported - it happens for NO M4V decoders.
			   We have to use fixed vop rate. */
			context->video_opt->VopInfo.FixedVopRate = TRUE;
			context->video_opt->VopInfo.VopTimeIncrementResolution = 90000;
			context->video_opt->VopInfo.FixedVopTimeIncrement = 3000;

			err = RUASetProperty(context->dcc_info->pRUA, context->dcc_info->video_decoder, RMVideoDecoderPropertyID_VopInfo,
					     &context->video_opt->VopInfo, sizeof(context->video_opt->VopInfo), 0 );
			if (RMSUCCEEDED(err)) {
				RMDBGLOG((ENABLE, "video time scale not supported. Set fixed vop rate: %ld / %ld frames per second\n",
					context->video_opt->VopInfo.VopTimeIncrementResolution,
					context->video_opt->VopInfo.FixedVopTimeIncrement));
			}
			else {
				RMDBGLOG((ENABLE,"video time scale not supported. Error setting fixed VOP rate : %d !\n", err));
			}
		}
	}

	RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_Enable, &dummy, sizeof(dummy), 0);
	RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_DataType,
		&context->output_table[context->videoDemuxOutputIndex].type, sizeof(context->output_table[context->videoDemuxOutputIndex].type), 0);

	/* set to 0 the threshold because in case of playback I don't need the interrupts for receive */
	rec_thr.partial_read = FALSE;
	rec_thr.size = 0;
	RUASetProperty(context->pRUA, demux_output, RMGenericPropertyID_Threshold, &rec_thr, sizeof(rec_thr), 0);

	/* by default the output has the pts enabled */
	if (!context->play_opt->send_video_pts) {
		err = RUASetProperty(context->dcc_info->pRUA, demux_output, RMDemuxOutputPropertyID_EnablePts,
			&context->play_opt->send_video_pts, sizeof(context->play_opt->send_video_pts), 0 );
	}
	err = Play(context, RM_DEVICES_VIDEO, VideoDecoder_Command_PlayFwd);
 	return err;
}

static RMstatus SwitchCodec(struct context_per_task *context)
{

	enum AudioDecoder_Codec_type ACodec;
	enum VideoDecoder_Codec_type VCodec;
	enum MPEG_Profile MPEGProfile;
	RMuint32 index;
	RMstatus err;

	if (! context->video_opt->auto_detect_codec)
		goto audio_codec;

	for (index = 0; index < context->VideoPidList.count; index++) {
		if (context->VideoPidList.elementary_pid[index] == context->video_pid)
			break;
	}

	if (index >= context->VideoPidList.count)
		goto audio_codec;

	switch (context->VideoPidList.stream_type[index]) {
		case 1:		// mpeg 1 video
			RMDBGLOG((ENABLE, "mpeg1 video detected, error\n"));
			return RM_ERROR;
			break;
		case 2:		// mpeg 2 video
			RMDBGLOG((LOCALDBG, "mpeg2 video detected\n"));
			MPEGProfile = Profile_MPEG2_HD;
			VCodec = VideoDecoder_Codec_MPEG2_HD;
			break;
		case 0x10:	// mpeg 4 video
			RMDBGLOG((LOCALDBG, "mpeg4 video detected\n"));
			MPEGProfile = Profile_MPEG4_HD;
			VCodec = VideoDecoder_Codec_MPEG4_HD;
			break;
		case 0x1b:	// H264 video
			RMDBGLOG((LOCALDBG, "h264 video detected\n"));
			MPEGProfile = Profile_H264_HD;
			VCodec = VideoDecoder_Codec_H264_HD;
			break;
		case 0xea:      // VC-1 video
			RMDBGLOG((LOCALDBG, "VC-1 video detected\n"));
			MPEGProfile = Profile_VC1_HD;
			VCodec = VideoDecoder_Codec_VC1_HD;
		default:
			RMDBGLOG((ENABLE, "%lx_SwitchCodec: video codec unknown, don't SwitchVideoDecoder !\n", context->id));
			goto audio_codec;
	}

	err = SwitchVideoDecoder(context, VCodec, MPEGProfile);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%lx_Error Switch video decoder err=%d\n", context->id, err));
		return RM_ERROR;
	}

	audio_codec:

	if (! context->audio_opt->auto_detect_codec)
		return RM_OK;

	for (index = 0; index < context->AudioPidList.count; index++) {
		if (context->AudioPidList.elementary_pid[index] == context->audio_pid)
			break;
	}

	if (index >= context->AudioPidList.count)
		return RM_OK;

	switch (context->AudioPidList.stream_type[index]) {
		case 3:		// mpeg 1 audio
		case 4:		// mpeg 2 audio
			RMDBGLOG((ENABLE, "%lx_SwitchCodec: mpeg audio detected\n", context->id));
			ACodec = AudioDecoder_Codec_MPEG1;
			break;
		case 6:		// private, can be DTS audio
			RMDBGLOG((ENABLE, "%lx_SwitchCodec: private stream_type = 6, by default DTS\n", context->id));
			ACodec = stream_type_6;
			break;
		case 0x0f:	// ISO/IEC 13818-7 Audio with ADTS transport syntax
			RMDBGLOG((ENABLE, "%lx_SwitchCodec: ADTS audio detected\n", context->id));
			ACodec = AudioDecoder_Codec_AAC;
			context->audio_opt->AACParams.InputFormat = 1;	// adif, no sync word
			context->audio_opt->AACParams.OutputChannels = Aac_LR;
			break;
		case 0x80:	// 0x80 = bdlpcm
			RMDBGLOG((ENABLE, "%lx_SwitchCodec: bdlpcm audio detected\n", context->id));
			ACodec = AudioDecoder_Codec_PCM;
			context->audio_opt->SubCodec = 3;
			context->audio_opt->PcmCdaParams.ChannelAssign = PcmCda2_LR;
			context->audio_opt->PcmCdaParams.BitsPerSample = 16;

			if (!context->audio_opt->OutputChannelsExplicitAssign)
				context->audio_opt->OutputChannels = Audio_Out_Ch_LR;
			break;
		case 0x81:	// 0x81 = ac3
		case 0x83:	// 0x83 = dolby lossless - to check
		case 0x84:	// 0x84 = dolby digital plus - to check
			RMDBGLOG((ENABLE, "%lx_SwitchCodec: ac3 audio detected\n", context->id));
			ACodec = AudioDecoder_Codec_AC3;
			break;
		case 0x82:	// 0x82 = dts
		case 0x85:	// 0x85 = dts hd - to check
			RMDBGLOG((ENABLE, "%lx_SwitchCodec: dts audio detected\n", context->id));
			ACodec = AudioDecoder_Codec_DTS;
			break;
		case 0xe6:	// 0xe6 = wmaTS - Vincent
		case 0x11:	// 0x11, audio with LATM transport syntax as defined in ISO/IEC 14496-3 / AMD 1
		default:
			RMDBGLOG((ENABLE, "%lx_SwitchCodec: audio codec unknown, don't SwitchAudioDecoder !\n", context->id));
			return RM_OK;
	}

	err = SwitchAudioDecoder(context, ACodec);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%lx_SwitchCodec: SwitchAudioDecoder Error=%d\n", context->id, err));
		return RM_ERROR;
	}

	return RM_OK;
}

static RMstatus send_disable_output_demux_command(struct RUA *pRUA, RMuint32 demux, struct EMhwlibOutputMask_type *discmd) 
{
	struct RUAEvent evt;
	RMuint32 index;
	RMstatus err;

	evt.ModuleID = demux;
	evt.Mask = RUAEVENT_COMMANDCOMPLETION;
	
	err = RUAResetEvent(pRUA, &evt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot reset demux OutputDisableCommand completion event, %s\n", RMstatusToString(err)));
		return err;
	}
	
	err = RUASetProperty(pRUA, demux, RMDemuxTaskPropertyID_OutputDisableCommand, discmd, sizeof(struct EMhwlibOutputMask_type), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot send demux OutputDisableCommand, %s\n", RMstatusToString(err)));
		return err;
	}
		
	evt.ModuleID = demux;
	evt.Mask = RUAEVENT_COMMANDCOMPLETION;
	err = RUAWaitForMultipleEvents(pRUA, &evt, 1, TIMEOUT_100MS, &index);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "wait for demux OutputDisableCommand completion %d failed, %s\n", RMstatusToString(err)));
		return err;
	}
	
	return RM_OK;
}

static void GetPidsFromAVListOrCmdLine(struct context_per_task *context)
{
	if (!(context->av_flags & VIDEO_PID_FROM_CMDLINE)) {
		if (context->VideoPidList.count) {
			fprintf(stderr, "vpid[%lu]= 0x%04x(0x%02x) ", 
				context->VideoPidList.index,
				context->VideoPidList.elementary_pid[context->VideoPidList.index], 
				context->VideoPidList.stream_type[context->VideoPidList.index]);
			context->video_pid = context->VideoPidList.elementary_pid[context->VideoPidList.index];
		}
		else {
			context->video_pid = 0x1fff;
			fprintf(stderr, "   vpid= NO pid in the list ");
		}
	}

	if (!(context->av_flags & ECM0_PID_FROM_CMDLINE)) {
		if (context->VideoPidList.count) {
			context->ecm_pid[0] = context->VideoPidList.es_ecm_pid[context->VideoPidList.index];
		}
	}

	if (!(context->av_flags & AUDIO_PID_FROM_CMDLINE)) {
		if (context->AudioPidList.count) {
			fprintf(stderr, "apid[%lu]= 0x%04x(0x%02x) ", 
				context->AudioPidList.index,
				context->AudioPidList.elementary_pid[context->AudioPidList.index], 
				context->AudioPidList.stream_type[context->AudioPidList.index]);
			context->audio_pid = context->AudioPidList.elementary_pid[context->AudioPidList.index];
		}
		else {
			context->audio_pid = 0x1fff;
			fprintf(stderr, "   apid= NO pid in the list ");
		}
	}

	if (!(context->av_flags & ECM1_PID_FROM_CMDLINE)) {
		if (context->AudioPidList.count) {
			context->ecm_pid[1] = context->AudioPidList.es_ecm_pid[context->AudioPidList.index];
		}
	}
	
	if (!(context->av_flags & PCR_PID_FROM_CMDLINE)) {
		context->pcr_pid = context->VideoPidList.pcr_pid;
		fprintf(stderr, "pcrpid= 0x%04x", context->VideoPidList.pcr_pid);
	}
	
	if (!(context->av_flags & TTX_PID_FROM_CMDLINE)  && context->video_opt->display_ttx ) {
		if (context->TeletextPidList.count) {
			fprintf(stderr, "tpid[%lu]= 0x%04x(0x%02x) ", 
				context->TeletextPidList.index,
				context->TeletextPidList.elementary_pid[context->TeletextPidList.index], 
				context->TeletextPidList.stream_type[context->TeletextPidList.index]);
			context->teletext_pid = context->TeletextPidList.elementary_pid[context->TeletextPidList.index];
		}
	}
	
	fprintf(stderr, "\n");

	context->av_flags &= ~VIDEO_PID_FROM_CMDLINE;
	context->av_flags &= ~AUDIO_PID_FROM_CMDLINE;
	context->av_flags &= ~PCR_PID_FROM_CMDLINE;
	context->av_flags &= ~ECM0_PID_FROM_CMDLINE;
	context->av_flags &= ~ECM1_PID_FROM_CMDLINE;
	context->av_flags &= ~TTX_PID_FROM_CMDLINE;
}
	
static RMstatus SetPidFilterForAVPlayback(struct context_per_task *context)
{
	RMstatus err;

	fprintf(stderr, "   m>   %ld_SetPidFilterForAVPlayback ", context->id);

	/* get the new pids from the list or from the command line */
	GetPidsFromAVListOrCmdLine(context);
	
	if ((context->change_program_method == change_program_with_stop_all)
	 || (context->av_flags & AV_PIDS_ENABLE_FIRST_TIME)) {
		/* This method works always but data is lost at stop time.
		It is not good for PVR applications. */
		RMDBGLOG((ENABLE, "%ld_SetPidFilterForAVPlayback change program with stop all\n", context->id));
		err = HwStop(context);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetPidFilterForAVPlayback HwStop Error\n", context->id));
			return err;
		}
	}
	else if(context->change_program_method == change_program_without_stop) {
		/* This method works in case the video and/or audio change codec.
		The method is good for PVR applications - no data lost.
		In order to not have freezing or skipping the programs
		should have either contiguos PCR values or we need
		to to detect the pcr discontinuity.*/	
		RMDBGLOG((ENABLE, "%ld_SetPidFilterForAVPlayback change program without stop\n", context->id));
	}
	else if(context->change_program_method == change_program_with_av_stop) {
		/* This method works OK if the video and audio don't change codec.
		The method is good for PVR applications - no data lost.
		In order to not have freezing or skipping the programs
		should have either contiguos PCR values or we need
		to to detect the pcr discontinuity.*/	

		struct EMhwlibOutputMask_type discmd;

		RMDBGLOG((ENABLE, "%ld_SetPidFilterForAVPlayback change program with AV stop\n", context->id));

		/* disable the current audio, video and pcr pids */
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryDisable, &context->audio_pidentry, sizeof(context->audio_pidentry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetPidFilterForAVPlayback Error audio RMDemuxTaskPropertyID_PidEntryEnable", context->id));
			return err;
		}
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryDisable, &context->video_pidentry, sizeof(context->video_pidentry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetPidFilterForAVPlayback Error audio RMDemuxTaskPropertyID_PidEntryEnable", context->id));
			return err;
		}
#ifdef USE_HW_PCR_PID_ENTRY
		{
			RMuint32 dummy;
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PCRPidEntryDisable, &dummy, sizeof(dummy), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error pcr RMDemuxTaskPropertyID_PCRPidEntryDisable", context->id));
				return err;
			}
		}
#else
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryDisable, &context->pcr_pidentry, sizeof(context->pcr_pidentry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetPidFilterForAVPlayback Error pcr RMDemuxTaskPropertyID_PidEntryEnable", context->id));
			return err;
		}
#endif

		/* disable and flush the audio and video output context, then stop decoders */
		discmd.output_mask[0] = (1<<context->audioDemuxOutputIndex[0]) | (1<<context->videoDemuxOutputIndex);
		err = send_disable_output_demux_command (context->pRUA, context->demux_task, &discmd);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetPidFilterForAVPlayback send_disable_output_demux_command Error\n", context->id));
		}
	
		err = Stop(context, RM_DEVICES_AUDIO | RM_DEVICES_VIDEO );
		
		{
			/* reprogram the demux to send the new pcr - needed in case that
			the PCR discontinuity is not detected or the next program doesn't have PCR */
			enum EMhwlibTimerSync timer_sync;
			timer_sync = EMhwlibTimerSync_FirstPcrSetPlayStc;
			RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_TimerSync, &timer_sync, sizeof(timer_sync), 0);
		}
	}
	else {
		RMDBGLOG((ENABLE, "%ld_SetPidFilterForAVPlayback change program ??????\n", context->id));
	}
	
	/* switch the video or audio codec if needed */
	err = SwitchCodec(context);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_SetPidFilterForAVPlayback SwitchCodec Error\n", context->id));
		return err;
	}

	/* set and enable the new pids in the hardware pid filter */
	err = SetHwAVPlayback(context);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_SetPidFilterForAVPlayback SetHwAVPlayback Error\n", context->id));
		//return err;
	}

#ifdef MULTI2_EIGHT_KEYS
	err = SetHwDataPlayback(context);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_SetPidFilterForAVPlayback SetHwDataPlayback Error\n", context->id));
	}
#endif //#ifdef MULTI2_EIGHT_KEYS
	
	if ((context->change_program_method == change_program_with_stop_all)
	 || (context->av_flags & AV_PIDS_ENABLE_FIRST_TIME)) {
		err = HwPlay(context);
		if (RMFAILED(err)) {
			fprintf(stderr, "%ld_SetPidFilterForAVPlayback HwPlay err=%d\n", context->id, err);
			return err;
		}
	}
	else if(context->change_program_method == change_program_without_stop) {
		/* nothing to do */
	}
	else if(context->change_program_method == change_program_with_av_stop) {
		RMuint32 demux_output = EMHWLIB_MODULE(DemuxOutput, context->audioDemuxOutputIndex[0] + output_count_per_task * context->id);
		RMuint32 dummy;

		/* enable the audio and video outputs and set decoders in Play state */
		err = RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_Enable, &dummy, sizeof(dummy), 0);
		if( RMFAILED(err) ) {
			fprintf(stderr, "couldnt enable audio output");
		}

		demux_output = EMHWLIB_MODULE(DemuxOutput, context->videoDemuxOutputIndex + output_count_per_task * context->id);
		err = RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_Enable, &dummy, sizeof(dummy), 0);
		if( RMFAILED(err) ) {
			fprintf(stderr, "couldnt enable audio output");
		}
		
		err = Play(context, RM_DEVICES_AUDIO | RM_DEVICES_VIDEO, VideoDecoder_Command_PlayFwd);
	}
	else {
		RMDBGLOG((ENABLE, "%ld_SetPidFilterForAVPlayback change program ??????\n", context->id));
	}
	
	context->av_flags &= ~AV_PIDS_ENABLE_FIRST_TIME;
	
	return RM_OK;
}

static RMstatus SetNextPMT(struct context_per_task *context)
{
	RMstatus err;
	struct DemuxTask_PidEntry_type entry;
	struct PMTInfo_type *pmt_info;

	RMDBGLOG((CALLDBG, "setNextPMT (context @0x%08lx)\n", (RMuint32)context));

	if (context->pat_info.count == 0) {
		fprintf(stderr, "   m> %ld_NextPMT error: pat_info.count=0\n", context->id);
		return RM_ERROR;
	}
	
	/* next pmt in list */
	context->pmt_index = (context->pmt_index + 1) % context->pat_info.count;
	
	if (context->pat_info.program_number[context->pmt_index] == 0) {
		/* skip network PID*/
		context->pmt_index = (context->pmt_index+1)%context->pat_info.count;
	}
	pmt_info = &context->pmt_info[context->pmt_index];
	if (pmt_info->count) {
		context->pmt = TRUE;
	}
	/* for time being use same Pid entry */
	RMDBGLOG((ENABLE, "   %ld_SetNextPMT sets pmt_pidentry_%lx pid=%lx\n", context->id,
		  context->pmt_pidentry, context->pat_info.program_map_pid[context->pmt_index]));

	entry.index = context->pmt_pidentry;
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryDisable, &entry.index, sizeof(entry.index), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_PMT Error RMDemuxTaskPropertyID_PidEntryDisable", context->id));
		return err;
	}
	entry.PidEntry.pid = context->pat_info.program_map_pid[context->pmt_index];
	entry.PidEntry.input_type = EMhwlibPid_Ts;
	entry.PidEntry.flags = TS_FLAGS;
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntry, &entry, sizeof(entry), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_PMT Error RMDemuxTaskPropertyID_PidEntry", context->id));
		return err;
	}

	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryEnable, &entry.index, sizeof(entry.index), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_PMT Error RMDemuxTaskPropertyID_PidEntryEnable", context->id));
		return err;
	}

	{
		struct DemuxTask_MatchSectionEntry_type section_entry;

		/* filter any version of pmt section in hardware section filter */
		context->match_section_table[1].section_entry.mask[5] = 0; 
		context->match_section_table[1].section_entry.mode[5] = 0;
		context->match_section_table[1].section_entry.comp[5] = 0;
		
		section_entry.Index = context->match_section_table[1].index;
		section_entry.SectionEntry = context->match_section_table[1].section_entry;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_MatchSectionEntry,
				&section_entry, sizeof(section_entry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error RMDemuxTaskPropertyID_MatchSectionEntry"));
		}

		/* reset ECM for next parity */
		context->match_section_table[4].section_entry.mask[0] = 0xFC;
		context->match_section_table[4].section_entry.comp[0] = 0x80;
			
		section_entry.Index = context->match_section_table[4].index;
		section_entry.SectionEntry = context->match_section_table[4].section_entry;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_MatchSectionEntry,
			&section_entry, sizeof(section_entry), 0);
		if (RMFAILED(err)) {
			fprintf(stderr, "decoder: Error RMDemuxTaskPropertyID_MatchSectionEntry");
		}
		context->match_section_table[5].section_entry.mask[0] = 0xFC;
		context->match_section_table[5].section_entry.comp[0] = 0x80;
			
		section_entry.Index = context->match_section_table[5].index;
		section_entry.SectionEntry = context->match_section_table[5].section_entry;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_MatchSectionEntry,
			&section_entry, sizeof(section_entry), 0);
		if (RMFAILED(err)) {
			fprintf(stderr, "decoder: Error RMDemuxTaskPropertyID_MatchSectionEntry");
		}
	}
	return RM_OK;
}

static RMstatus CheckAVPlaybackAgainstAVList(struct context_per_task *context)
{
	RMDBGLOG((CALLDBG, "checkAVPlaybackAgainstAVList (context @0x%08lx)\n", (RMuint32)context));

	if ( (context->video_pid == context->VideoPidList.elementary_pid[context->VideoPidList.index]) &&
	     (context->pcr_pid == context->VideoPidList.pcr_pid) &&
	     (context->audio_pid == context->AudioPidList.elementary_pid[context->AudioPidList.index]) )
		return RM_OK;
		
	return RM_ERROR;
}

static RMstatus PmtSetAVList(struct context_per_task *context)
{
	RMuint32 i, ai=0, vi=0, ti=0;
	struct PMTInfo_type *pmt_info;

	RMDBGLOG((CALLDBG, "pmtSetAVList (context @0x%08lx)\n", (RMuint32)context));

	if ( context->pat_info.count == 0 ) {
		fprintf(stderr, "   m> %ld_PmtSetAVList error: empty PmtPidList\n", context->id);
		return RM_ERROR;
	}
	
	if (context->pat_info.program_number[context->pmt_index] == 0) {
		/* skip network PID*/
		context->pmt_index = (context->pmt_index+1)%context->pat_info.count;
	}
	pmt_info = &context->pmt_info[context->pmt_index];
	if (pmt_info->count == 0) {
		/* prepare for next pmt in list */
		context->pmt_index = (context->pmt_index+1)%context->pat_info.count;
		fprintf(stderr, "   m> %ld_PmtSetAVList index=%lx has no streams => increment pmt index and return!\n", context->id, context->pmt_index);
		return RM_ERROR;
	}
	pmt_info->update = FALSE; /* handshake with ParsePMT */

	fprintf(stderr, "   m> %ld_PmtSetAVList index=%lx prog=0x%03x pid=0x%03x\n", context->id,
		context->pmt_index, context->pat_info.program_number[context->pmt_index],
		context->pat_info.program_map_pid[context->pmt_index]);
	fprintf(stderr, "   m> %lu PES streams:\n", pmt_info->count);
	
	context->VideoPidList.pcr_pid = pmt_info->pcr_pid;

	for(i=0;i<pmt_info->count;i++) {
		// see page 45, 13818-1 (MPEG-2 Systems spec)
		switch (pmt_info->stream_type[i]) {
		case 1:		// mpeg 1 video
		case 2:		// mpeg 2 video
		case 0x10:	// mpeg 4 video
		case 0x1b:	// H264 video
		case 0xea:      // VC-1 video
		//case 0x80:	// video, it is used by wsnet to indicate a video stream
			context->VideoPidList.stream_type[vi] = pmt_info->stream_type[i];
			context->VideoPidList.elementary_pid[vi] = pmt_info->elementary_pid[i];

			if (pmt_info->es_ecm_count == 0) { // ECM for entire program
				if (pmt_info->ecm_count == 0) 	// No ECM
					context->VideoPidList.es_ecm_pid[vi] = 0x1FFF;
				else if (pmt_info->ecm_count == 1) 	// Standard
					context->VideoPidList.es_ecm_pid[vi] = pmt_info->ecm_pid[0];
				else {	// Wired TS
					if ((vi + ai + ti) < pmt_info->ecm_count)
						context->VideoPidList.es_ecm_pid[vi] = pmt_info->ecm_pid[vi + ai + ti];
					else
						context->VideoPidList.es_ecm_pid[vi] = 0x1FFF;
				}
			}
			else {	// ECM for elementary
				context->VideoPidList.es_ecm_pid[vi] = pmt_info->es_ecm_pid[i];
			}
			fprintf(stderr, "   m>   vpid[%lu]= 0x%04x(0x%02x)= %s\n",
				vi,
				pmt_info->elementary_pid[i],
				pmt_info->stream_type[i],
				VideoTypeToString(pmt_info->stream_type[i]));
			fprintf(stderr, "   m>   ecm_pid=0x%04X\n", context->VideoPidList.es_ecm_pid[vi]);
			vi++;
			break;
		case 6:		// private, can be DTS audio also can be teletext
			if( context->video_opt->display_ttx )  { // break if teletext is enabled
								// otherwise fall through, let audio get it
				// Teletext stream
				context->TeletextPidList.stream_type[ti] = pmt_info->stream_type[i];
				context->TeletextPidList.elementary_pid[ti] = pmt_info->elementary_pid[i];

				if (pmt_info->es_ecm_count == 0) { // ECM for entire program
					if (pmt_info->ecm_count == 0) 	// No ECM
						context->TeletextPidList.es_ecm_pid[ti] = 0x1FFF;
					else if (pmt_info->ecm_count == 1) 	// Standard
						context->TeletextPidList.es_ecm_pid[ti] = pmt_info->ecm_pid[0];
					else {	// Wired TS
						if ((ai + vi + ti) < pmt_info->ecm_count)
							context->AudioPidList.es_ecm_pid[ai] = pmt_info->ecm_pid[ai + vi + ti];
						else
							context->AudioPidList.es_ecm_pid[ai] = 0x1FFF;
					}
				}
				else {	// ECM for elementary
					context->TeletextPidList.es_ecm_pid[ti] = pmt_info->es_ecm_pid[i];
				}
				fprintf(stderr, "   m>   tpid[%lu]= 0x%04x(0x%02x)= %s\n",
					ai,
					pmt_info->elementary_pid[i],
					pmt_info->stream_type[i],
					"teletext" );
				fprintf(stderr, "   m>   ecm_pid=0x%04X\n", context->TeletextPidList.es_ecm_pid[ti]);
				ti++;
				break;
			}
		
		case 3:		// mpeg 1 audio
		case 4:		// mpeg 2 audio
		case 0x0f:	// ISO/IEC 13818-7 Audio with ADTS transport syntax
		case 0x80:	// audio for BR disc !!
		case 0x81:	// 0x81 = ac3
		case 0x82:	// 0x82 = dts
		case 0x83:	// 0x83 = dolby lossless
		case 0x84:	// 0x84 = dolby digital plus
		case 0x85:	// 0x85 = dts hd
		case 0xe6:	// 0xe6 = wmaTS - Vincent
		case 0x11:	// 0x11, audio with LATM transport syntax as defined in ISO/IEC 14496-3 / AMD 1
			context->AudioPidList.stream_type[ai] = pmt_info->stream_type[i];
			context->AudioPidList.elementary_pid[ai] = pmt_info->elementary_pid[i];

			if (pmt_info->es_ecm_count == 0) { // ECM for entire program
				if (pmt_info->ecm_count == 0) 	// No ECM
					context->AudioPidList.es_ecm_pid[ai] = 0x1FFF;
				else if (pmt_info->ecm_count == 1) 	// Standard
					context->AudioPidList.es_ecm_pid[ai] = pmt_info->ecm_pid[0];
				else {	// Wired TS
					if ((ai + vi + ti) < pmt_info->ecm_count)
						context->AudioPidList.es_ecm_pid[ai] = pmt_info->ecm_pid[ai + vi + ti];
					else
						context->AudioPidList.es_ecm_pid[ai] = 0x1FFF;
				}
			}
			else {	// ECM for elementary
				context->AudioPidList.es_ecm_pid[ai] = pmt_info->es_ecm_pid[i];
			}
			fprintf(stderr, "   m>   apid[%lu]= 0x%04x(0x%02x)= %s\n",
				ai,
				pmt_info->elementary_pid[i],
				pmt_info->stream_type[i],
				AudioTypeToString(pmt_info->stream_type[i]));
			fprintf(stderr, "   m>   ecm_pid=0x%04X\n", context->AudioPidList.es_ecm_pid[ai]);
			ai++;
			break;
		default:
			fprintf(stderr, "   m>    pid= 0x%04x(0x%02x)= unknown pes\n", pmt_info->elementary_pid[i], pmt_info->stream_type[i]);
			break;
		}
	}
	context->VideoPidList.count = vi;
	context->VideoPidList.index = 0;
	context->AudioPidList.count = ai;
	context->AudioPidList.index = 0;
	context->TeletextPidList.count = ti;
	context->TeletextPidList.index = 0;

	if ((!vi) && (!ai) && (!ti)) {
		fprintf(stderr, "   m>    %ld_PmtSetAVList No valid video and audio streams -> try next pmt from pat list index=%lx!\n", context->id, context->pmt_index);
		return RM_ERROR;
	}

#ifdef MULTI2_EIGHT_KEYS
	// hardcode pids for all video, audio and data, provious contents will be overwritten
	HardcodeAVPids(context);
	HardcodeDataPids(context);
#endif  //#ifdef MULTI2_EIGHT_KEYS

	return RM_OK;
}

static RMstatus OpenVideoDecoder(struct context_per_task *context)
{
	RMstatus err;
	/* open video decoder using DCCX functions */
	struct DCCXVideoProfile video_profile;

	RMDBGLOG((ENABLE, "openVideoDecoder\n"));

	video_profile.ProtectedFlags = 0;
	video_profile.BitstreamFIFOSize = context->video_opt->fifo_size;
	video_profile.XferFIFOCount = 0;
	video_profile.PtsFIFOCount = VIDEO_PTS_FIFO_COUNT;
	video_profile.InbandFIFOCount = VIDEO_INBAND_FIFO_COUNT;
	video_profile.XtaskInbandFIFOCount = 0;
	video_profile.MpegEngineID = context->video_opt->MpegEngineID;
	video_profile.VideoDecoderID = context->video_opt->VideoDecoderID;
	
	/* DCC spu_hack */
	video_profile.SPUProtectedFlags = 0;
	video_profile.SPUBitstreamFIFOSize = (context->enable_spu) ? SPU_FIFO_SIZE : 0;
	video_profile.SPUXferFIFOCount = 0;
	video_profile.SPUPtsFIFOCount = (context->enable_spu) ? VIDEO_PTS_FIFO_COUNT : 0;
	video_profile.SPUInbandFIFOCount = (context->enable_spu) ? VIDEO_INBAND_FIFO_COUNT : 0;
	video_profile.SPUCodec = EMhwlibDVDSpuCodec;
	video_profile.SPUProfile = 0;
	video_profile.SPULevel = 0;
	video_profile.SPUExtraPictureBufferCount = 0;
	video_profile.SPUMaxWidth = 720;
	video_profile.SPUMaxHeight = 576;
	
	video_profile.STCID = context->id;

	/* set codec based on command line options either "-pv" or "-vcodec" */
	if (context->video_opt->vcodec_max_width) {
		video_profile.Codec = context->video_opt->vcodec;
		video_profile.Profile = context->video_opt->vcodec_profile;
		video_profile.Level = context->video_opt->vcodec_level;
		video_profile.MaxWidth = context->video_opt->vcodec_max_width;
		video_profile.MaxHeight = context->video_opt->vcodec_max_height;
	}
	else {
		err = video_profile_to_codec(context->video_opt->MPEGProfile, &video_profile.Codec,
					     &video_profile.Profile, &video_profile.Level, &video_profile.ExtraPictureBufferCount,
					     &video_profile.MaxWidth, &video_profile.MaxHeight);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Unknown video decoder codec \n"));
			return RM_ERROR;
		}
	}

	/* set the extra pictures after the profile to codec conversion */
	video_profile.ExtraPictureBufferCount = context->video_opt->vcodec_extra_pictures;

	err = DCCXOpenVideoDecoderSource(context->dcc_info->pDCC, &video_profile, &context->dcc_info->pVideoSource);
	if (RMFAILED(err)) {
		fprintf(stderr, "%lx_Cannot open video decoder err=%d\n", context->id, err);
		return RM_ERROR;
	}
	
	/* save the video codec to set it after demux output connection */
	context->vcodec = video_profile.Codec;

#ifdef WITH_MONO
	err = DCCGetScalerModuleID(context->dcc_info->pDCC, context->dcc_info->route, DCCSurface_Video, context->id, &context->dcc_info->SurfaceID);
#else
	err = DCCGetScalerModuleID(context->dcc_info->pDCC, context->dcc_info->route, DCCSurface_Video, context->disp_opt->video_scaler, &context->dcc_info->SurfaceID);
#endif
	if (RMFAILED(err)) {
		fprintf(stderr, "%lx_Cannot get surface to display video source %d\n", context->id, err);
		return RM_ERROR;
	}

#ifdef	INIT_DISPLAY_CONSUMER
	err = DCCSetSurfaceSource(context->dcc_info->pDCC, context->dcc_info->SurfaceID, context->dcc_info->pVideoSource);
	if (RMFAILED(err)) {
		fprintf(stderr, "%lx_Cannot set the surface source err=%d\n", context->id, err);
		return RM_ERROR;
	}
#endif

	err = DCCGetVideoDecoderSourceInfo(context->dcc_info->pVideoSource, &(context->dcc_info->video_decoder),
					   &(context->dcc_info->spu_decoder), &(context->dcc_info->video_timer));
	if (RMFAILED(err)) {
		fprintf(stderr, "%lx_Error getting video decoder source information err=%d\n", context->id, err);
		return RM_ERROR;
	}

#ifndef WITH_MONO
	context->dcc_info->disp_info->video_enable = TRUE;
	set_default_out_window(&(context->dcc_info->disp_info->out_window));
	set_default_out_window(&(context->dcc_info->disp_info->osd_window[0]));
	set_default_out_window(&(context->dcc_info->disp_info->osd_window[1]));

	context->dcc_info->disp_info->active_window = &(context->dcc_info->disp_info->out_window);

	err = apply_display_options(context->dcc_info, context->disp_opt);
	if (RMFAILED(err)) {
		fprintf(stderr, "%lx_Cannot set display options %d\n", context->id, err);
		return RM_ERROR;
	}

	/* set first decoder in top left quarter, second in right top quarter, third in center bottom quarter */
	if (task_count == 2) {
		context->dcc_info->disp_info->active_window->X = (context->id ? 3072:1024);
		context->dcc_info->disp_info->active_window->Y = (context->id ? 3072:1024);
		context->dcc_info->disp_info->active_window->Width  = 2048;
		context->dcc_info->disp_info->active_window->Height = 2048;
	}
	else if (task_count == 3) {
		context->dcc_info->disp_info->active_window->X = (context->id == 2) ? 2048:(context->id ? 3072:1024);
		context->dcc_info->disp_info->active_window->Y = (context->id == 2) ? 3072:1024;
		context->dcc_info->disp_info->active_window->Width  = 2048;
		context->dcc_info->disp_info->active_window->Height = 2048;
	}
	set_display_out_window(context->dcc_info);

#endif
	if(context->enable_spu){
		RMuint32 spu_decoder = context->dcc_info->spu_decoder;
		enum SpuDecoder_StreamType_type spu_st = SpuDecoder_StreamType_4by3;  // type according to selected stream from PGC_SPST_CTL
		RMbool spu_disp = TRUE;  // shall sub picture be displayed? may be overridden by forced display from stream. use GetProp_Display to check actual state.
		struct SpuDecoder_Palette_type spu_lut = {{  // DVD format: Y,Cr,Cb
			0x00, 0x28, 0x6d, 0xf0,
			0x00, 0x51, 0xf0, 0x5a,
			0x00, 0x10, 0x80, 0x80,
			0x00, 0xea, 0x80, 0x80,
			
			0x00, 0x66, 0xdb, 0x4e,
			0x00, 0x6a, 0xdd, 0xca,
			0x00, 0xd2, 0x92, 0x10,
			0x00, 0x5b, 0x49, 0x92,
			
			0x00, 0x7b, 0x80, 0x80,
			0x00, 0xc9, 0x98, 0x77,
			0x00, 0x30, 0xb6, 0x6d,
			0x00, 0x4f, 0x51, 0x5b,
			
			0x00, 0x1c, 0x77, 0xb6,
			0x00, 0x61, 0xcf, 0xcf,
			0x00, 0x10, 0x80, 0x80,
			0x00, 0xbf, 0x80, 0x80,
		}};  // dummy ScalerModuleID
		err = RUASetProperty(context->pRUA, spu_decoder, RMSpuDecoderPropertyID_Palette, &spu_lut, sizeof(spu_lut), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set spu palette\n"));
			return RM_ERROR;
		}

		err = RUASetProperty(context->pRUA, spu_decoder, RMSpuDecoderPropertyID_StreamType,&spu_st, sizeof(spu_st), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set spu type\n"));
			return RM_ERROR;
		}
			
		err = RUASetProperty(context->pRUA, spu_decoder, RMSpuDecoderPropertyID_SubpictureOn, &spu_disp, sizeof(spu_disp), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set spu ON\n"));
			return RM_ERROR;
		}
	}

	return RM_OK;
}

static RMstatus OpenAudioDecoder(struct context_per_task *pSendContext)
{
	RMstatus err;
	struct dcc_context *dcc_info = pSendContext->dcc_info;
	struct DCCAudioProfile audio_profiles[MAX_AUDIO_DECODER_INSTANCES];
	RMuint32 i;

	for (i = 0; i < pSendContext->audioInstances; i++) {
		RMDBGLOG((ENABLE, "******** %ld_OpenAudioDecoder %ld/%ld: ae=%ld ad=%ld\n",
			pSendContext->id, i, pSendContext->audioInstances,
			pSendContext->audio_opt_table[i].AudioEngineID,
			pSendContext->audio_opt_table[i].AudioDecoderID));
		audio_profiles[i].BitstreamFIFOSize = pSendContext->audio_opt_table[i].fifo_size;
		audio_profiles[i].XferFIFOCount = 0;
		audio_profiles[i].DemuxProgramID = pSendContext->audio_opt_table[i].AudioEngineID * 2;
		audio_profiles[i].AudioEngineID = pSendContext->audio_opt_table[i].AudioEngineID;
		audio_profiles[i].AudioDecoderID = pSendContext->audio_opt_table[i].AudioDecoderID;
		audio_profiles[i].STCID = pSendContext->id;
	}
	
	err = DCCOpenMultipleAudioDecoderSource(dcc_info->pDCC, audio_profiles, pSendContext->audioInstances, &(dcc_info->pMultipleAudioSource));
	
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot open multiple audio decoder %d\n", err);
		return err;
	}
	
	for (i = 0; i < pSendContext->audioInstances; i++) {

		// apply the sample rate, serial out status
	
		RMDBGLOG((ENABLE, "**** apply audio engine options for instance %lu\n", i));
		err = apply_audio_engine_options(dcc_info, &(pSendContext->audio_opt_table[i]));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error applying audio engine options %d\n", err));
			return err;
		}
	
		// apply the audio format - uninit, set codec, set specific parameters, init
		RMDBGLOG((ENABLE, "**** apply audio decoder options for instance %lu\n", i));
		err = apply_audio_decoder_options(dcc_info, &(pSendContext->audio_opt_table[i]));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error applying audio_decoder_options %d\n", err));
			return err;
		}
	}	

	RMDBGLOG((ENABLE, "apply dvi/hdmi audio options\n"));
	// TODO determine NumChannel from options->Codec and options->SubCodec
	// This will open the pDH handle, when -no_disp is specified
	apply_dvi_hdmi_audio_options(dcc_info, pSendContext->audio_opt, 0, FALSE, FALSE, FALSE);
#ifndef WITH_MONO
	if (! pSendContext->disp_opt->configure_outports) apply_hdcp(dcc_info, pSendContext->disp_opt);
#endif

	RMDBGLOG((ENABLE, "**** END OPEN AUDIO DECODER\n"));


	return RM_OK;
}



static RMstatus OpenDemuxOutputModule(struct context_per_task *context, RMuint32 i)
{
	RMstatus err;
	struct DemuxOutput_DRAMSize_in_type dram_in;
	struct DemuxOutput_DRAMSize_out_type dram_out;
	struct DemuxOutput_Open_type profile;
	RMuint32 demux_task = context->demux_task;
	RMuint32 demux_output = EMHWLIB_MODULE(DemuxOutput, i + output_count_per_task*context->id); 

	RMDBGLOG((CALLDBG, "openDemuxOutputModule (context @0x%08lx)\n", (RMuint32)context));

	dram_in.BitstreamFIFOSize = context->output_table[i].buffer_count * (1<<context->output_table[i].buffer_size_log2);
	dram_in.XferFIFOCount = context->output_table[i].buffer_count;
	dram_in.PtsFIFOCount = context->output_table[i].pts_count;
	dram_in.InbandFIFOCount = context->output_table[i].inband_count;

	err = RUAExchangeProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_DRAMSize,
				  &dram_in, sizeof(dram_in), &dram_out, sizeof(dram_out));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting property RMDemuxOutputPropertyID_DRAMSize! %s\n", RMstatusToString(err)));
		return err;
	}

	profile.BitstreamFIFOSize = dram_in.BitstreamFIFOSize;
	profile.XferFIFOCount = dram_in.XferFIFOCount;
	profile.PtsFIFOCount = dram_in.PtsFIFOCount;
	profile.InbandFIFOCount = dram_in.InbandFIFOCount;
	profile.demux_task_module_id = demux_task;
	profile.stc_module_id = EMHWLIB_MODULE(STC, context->id);

	profile.BitstreamProtectedAddress = 0;
	profile.BitstreamProtectedSize = dram_out.BitstreamProtectedSize;
	if (profile.BitstreamProtectedSize > 0) {
		profile.BitstreamProtectedAddress = DCCMalloc(context->dcc_info->pDCC, 0, RUA_DRAM_CACHED, profile.BitstreamProtectedSize);
		if (!profile.BitstreamProtectedAddress) {
			RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in cached DRAM %lu!\n",
				  profile.BitstreamProtectedSize, 0L));
			return RM_FATALOUTOFMEMORY;
		}
		RMDBGLOG((DISABLE, "video cached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
			  profile.BitstreamProtectedAddress, profile.BitstreamProtectedSize, profile.BitstreamProtectedAddress + profile.BitstreamProtectedSize));
	} 	
	context->output_table[i].BitstreamProtectedAddr = profile.BitstreamProtectedAddress;

	profile.UnprotectedAddress = 0;
	profile.UnprotectedSize = dram_out.UnprotectedSize;
	if (profile.UnprotectedSize > 0) {
		profile.UnprotectedAddress = DCCMalloc(context->dcc_info->pDCC, 0, RUA_DRAM_UNCACHED, profile.UnprotectedSize);
		if (!profile.UnprotectedAddress) {
			RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in uncached DRAM %lu!\n",
				  profile.UnprotectedSize, 0L));
			return RM_FATALOUTOFMEMORY;
		}
		RMDBGLOG((DISABLE, "video uncached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
			  profile.UnprotectedAddress, profile.UnprotectedSize, profile.UnprotectedAddress + profile.UnprotectedSize));
	} 	
	context->output_table[i].UnprotectedAddr = profile.UnprotectedAddress;

	err = RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_Open, &profile, sizeof(profile), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "OpenDemuxOutput Error\n"));
		return err;
	}
	return RM_OK;
}

static RMstatus OpenOutputTableForRecord(struct context_per_task *context)
{
	RMstatus err = RM_OK;
	RMuint32 i, dummy;

	RMDBGLOG((CALLDBG, "openOutputTableForRecord (context @0x%08lx)\n", (RMuint32)context));
	
	/* sanity check - if the output is for playback with an invalid decoder, mark it for recording */
	/* if an output for decoders has to be saved mark it for recording */
	for (i=0; i<context->output_table_count;i++) {
		if (EMHWLIB_MODULE_CATEGORY(context->output_table[i].consumer_module_id) == VideoDecoder) {
			if ( context->play_opt->save_video ) {
				context->output_table[i].consumer_module_id = 0;
				context->output_table[i].pts_count = 128;
				context->output_table[i].inband_count = 0;
				strcat(context->output_table[i].filename, ".video");
				RMDBGLOG((ENABLE, "VideoDecoder not enabled. Data is recorded in file %s.\n",
					context->output_table[i].filename));
			}
		}
		if (EMHWLIB_MODULE_CATEGORY(context->output_table[i].consumer_module_id) == AudioDecoder) {
			if ( (context->audio_opt->AudioDecoderID >= 2) || context->play_opt->save_audio ) {
				context->output_table[i].consumer_module_id = 0;
				context->output_table[i].pts_count = 128;
				context->output_table[i].inband_count = 0;
				strcat(context->output_table[i].filename, ".audio");
				RMDBGLOG((ENABLE, "AudioDecoder not enabled. Data is recorded in file %s.\n",
					context->output_table[i].filename));
			}
		}
		else if (EMHWLIB_MODULE_CATEGORY(context->output_table[i].consumer_module_id) == SpuDecoder) {
			if ( !context->enable_spu || context->play_opt->save_audio ) {
				context->output_table[i].consumer_module_id = 0;
				context->output_table[i].pts_count = 128;
				context->output_table[i].inband_count = 0;
				strcat(context->output_table[i].filename, ".spu");
				RMDBGLOG((ENABLE, "SpuDecoder not enabled. Data is recorded in file %s.\n",
					context->output_table[i].filename));
			}
		}
	}

	/* allocate output buffers for recording */
	for (i=0; i<context->output_table_count;i++) {
		RMuint32 demux_output = EMHWLIB_MODULE(DemuxOutput, i + output_count_per_task*context->id); 
		struct ReceiveThreshold_type rec_thr;
		RMuint32 section_mask;

		context->output_table[i].BitstreamProtectedAddr = 0;
		context->output_table[i].UnprotectedAddr = 0;
		context->output_table[i].pDma = 0;
		context->output_table[i].pmapped_bts_fifo_base = 0;
		context->output_table[i].fifo_container = 0;
		context->output_table[i].bts_fifo_base = 0;
		context->output_table[i].bts_fifo_size = 0;
		
		if(context->output_table[i].consumer_module_id) {
			continue;
		}

		/* open file to record data */
		if (context->output_table[i].filename[0]) {
			RMascii pts_filename[20];
			sprintf(context->output_table[i].filename, "%s%lx",
				context->output_table[i].filename, EMHWLIB_MODULE_INDEX(context->demux_task));
			context->output_table[i].f_out = fopen(context->output_table[i].filename, "wb");
			if (context->output_table[i].f_out == NULL) {
				fprintf(stderr, "OpenOutputTableForRecord: File %s cannot open\n", context->output_table[i].filename);
			}
			context->output_table[i].f_out_size = 0;

			if ( (context->output_table[i].type == EMhwlibData_Vpayload_pts)
			  || (context->output_table[i].type == EMhwlibData_ASpayload_pts) ) {
				sprintf(pts_filename, "%s%s", context->output_table[i].filename, ".pts");
				context->output_table[i].f_pts_out = fopen(pts_filename, "wb");
				if (context->output_table[i].f_pts_out == NULL) {
					fprintf(stderr, "OpenOutputTableForRecord: File %s cannot open\n", pts_filename);
				}
			}
		}

		/* Open DemuxOutput module */
		if (RMFAILED(err = OpenDemuxOutputModule(context, i)))
			return err;
		context->output_table[i].demux_output_module_id = demux_output;

		switch(context->output_table[i].receive_mode) {
		case receive_data_dma_backward_compatible:
		case receive_data_dma_full_buffer:
		case receive_data_dma_no_delay:
		case receive_data_dma_minimum_size:
		case receive_data_dma_exact_size:
			/* Allocate DMA pool for DemuxOutput */
			if (context->output_table[i].buffer_count) {
				err = RUAOpenPool(context->pRUA, 
						  context->output_table[i].partial_read ? (RUA_POOL_FORCE_DRAM_COPY | demux_output) : demux_output,
						  context->output_table[i].buffer_count, 
						  context->output_table[i].buffer_size_log2, 
						  RUA_POOL_DIRECTION_RECEIVE, 
						  &context->output_table[i].pDma);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "OpenOutputTableForRecord: RUAOpenPool Error\n"));
					return err;
				}
				if (context->output_table[i].receive_mode == receive_data_dma_full_buffer) {
					struct EMhwlibReadBufferCompletion bc;
					bc.mode = EMhwlibReadBufferCompletionMode_Full; /* complete the buffer when full */
					bc.threshold = 0; /* ignored */
					err = RUASetProperty(context->pRUA, demux_output, RMGenericPropertyID_ReadBufferCompletion, &bc, sizeof(bc), 0);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "RMGenericPropertyID_ReadBufferCompletion Error %d\n", err));
						return err;
					}
				}
				else if (context->output_table[i].receive_mode == receive_data_dma_no_delay) {
					struct EMhwlibReadBufferCompletion bc;
					bc.mode = EMhwlibReadBufferCompletionMode_NoDelay; /* complete the buffer as soon as the microcode sent data */
					bc.threshold = 0; /* ignored */
					err = RUASetProperty(context->pRUA, demux_output, RMGenericPropertyID_ReadBufferCompletion, &bc, sizeof(bc), 0);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "RMGenericPropertyID_ReadBufferCompletion Error %d\n", err));
						return err;
					}
				}
				else if (context->output_table[i].receive_mode == receive_data_dma_minimum_size) {
					struct EMhwlibReadBufferCompletion bc;
					bc.mode = EMhwlibReadBufferCompletionMode_MinimumSize; /* complete the buffer when the buffer has more than the threshold value */
					bc.threshold = 256;
					err = RUASetProperty(context->pRUA, demux_output, RMGenericPropertyID_ReadBufferCompletion, &bc, sizeof(bc), 0);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "RMGenericPropertyID_ReadBufferCompletion Error %d\n", err));
						return err;
					}
				}
				else if (context->output_table[i].receive_mode == receive_data_dma_exact_size) {
					struct EMhwlibReadBufferCompletion bc;
					bc.mode = EMhwlibReadBufferCompletionMode_ExactSize; /* complete the buffer when the buffer has exactly the threshold value */
					bc.threshold = 256;
					err = RUASetProperty(context->pRUA, demux_output, RMGenericPropertyID_ReadBufferCompletion, &bc, sizeof(bc), 0);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "RMGenericPropertyID_ReadBufferCompletion Error %d\n", err));
						return err;
					}
				}
			}
			break;
		case receive_data_nodma_rua_map:
			/* no dma - map bitstream DemuxOutput fifo in user space for direct access */
			if (context->output_table[i].buffer_count) {
				struct gbus_fifo *fifo;

				if (pllad == NULL) {
					pllad = llad_open("0");
					pgbus = gbus_open(pllad);
				}
				err = RUAGetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_BtsFIFO,
					&context->output_table[i].fifo_container, sizeof(context->output_table[i].fifo_container));
				if ( RMFAILED(err) || (context->output_table[i].fifo_container == 0) ) {
					RMDBGLOG((ENABLE, "%ld_OpenOutputTableForRecord: RMDemuxOutputPropertyID_BtsFIFO Error for 0x%lx\n", context->id, i));
					return err;
				}
				fifo = (struct gbus_fifo *)context->output_table[i].fifo_container;

				context->output_table[i].bts_fifo_base = gbus_read_uint32(pgbus, (RMuint32) &(fifo->base));
				context->output_table[i].bts_fifo_size = gbus_read_uint32(pgbus, (RMuint32) &(fifo->size));
				RMDBGLOG((DISABLE, "i=%lx: irq_output_source=%lx fifo_container=%lx base=%lx size=%lx\n",
					i, context->output_table[i].fifo_container, context->output_table[i].bts_fifo_base, context->output_table[i].bts_fifo_size));
				if ( (context->output_table[i].bts_fifo_base == 0) || (context->output_table[i].bts_fifo_size == 0) ) {
					fprintf(stderr, "%ld_OpenOutputTableForRecord ERROR output=0x%lx base or size 0\n", context->id, i);
					return RM_ERROR;
				}

				err = RUALock(context->pRUA, context->output_table[i].bts_fifo_base, context->output_table[i].bts_fifo_size);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "%ld_OpenOutputTableForRecord ERROR: Unable to lock output 0x%lx!\n", context->id, i));
				}
				context->output_table[i].pmapped_bts_fifo_base = RUAMap(context->pRUA, context->output_table[i].bts_fifo_base,
					context->output_table[i].bts_fifo_size);
			}
			break;
		case receive_data_nodma_get_chunk256:
			if (pllad == NULL) {
				pllad = llad_open("0");
				pgbus = gbus_open(pllad);
			}
			break;
		default:
			return RM_ERROR;
		}
		RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_Enable, &dummy, sizeof(dummy), 0);
			
		if (context->match_section_table) {
			/* hack for 8622 that has only 32 section entries shared by all tasks */
			section_mask = context->output_table[i].section_mask << context->match_section_table[0].index;
			RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_SectionMask, &section_mask, sizeof(section_mask), 0);
		}
		
		RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_DataType, &context->output_table[i].type, sizeof(context->output_table[i].type), 0);

		rec_thr.partial_read = context->output_table[i].partial_read;
		rec_thr.size = context->output_table[i].threshold;
		RUASetProperty(context->pRUA, demux_output, RMGenericPropertyID_Threshold, &rec_thr, sizeof(rec_thr), 0);
	}
	return err;
}

static RMstatus OpenOutputTableForPlayback(struct context_per_task *context)
{
	RMstatus err = RM_OK;
	RMuint32 i, dummy;

	RMuint32 openAudioDecoders = 0;

	RMDBGLOG((CALLDBG, "openOutputTableForPlayback (context @0x%08lx)\n", (RMuint32)context));

	RMDBGLOG((ENABLE, "audioInstances %lu\n", context->audioInstances));
	
	/* connect the outputs to preallocated buffers from decoders */
	for (i=0; i<context->output_table_count;i++) {
		struct DemuxOutput_Connect_type	connect;
		RMuint32 demux_output = EMHWLIB_MODULE(DemuxOutput, i + output_count_per_task*context->id); 

		if(context->output_table[i].consumer_module_id == 0) {
			continue;
		}

		context->output_table[i].BitstreamProtectedAddr = 0;
		context->output_table[i].UnprotectedAddr = 0;
		context->output_table[i].pDma = 0;
	
		if (EMHWLIB_MODULE_CATEGORY(context->output_table[i].consumer_module_id) == VideoDecoder) {
			err = OpenVideoDecoder(context); /* spu_hack: this will open the SpuDecoder too */
			context->output_table[i].consumer_module_id = context->dcc_info->video_decoder;
			if (RMFAILED(err))
				return err;
			context->videoDemuxOutputIndex = i;
			RMDBGLOG((ENABLE, "video demux output index %lu\n", context->videoDemuxOutputIndex));
		}
		else if ((EMHWLIB_MODULE_CATEGORY(context->output_table[i].consumer_module_id) == AudioDecoder) && (!openAudioDecoders)) {
			struct DCCAudioSourceHandle audioHandle;

			err = OpenAudioDecoder(context);
			if (RMFAILED(err))
				return err;

			// this is the first instance
			DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(context->dcc_info->pMultipleAudioSource, 0, &audioHandle);
			context->output_table[i].consumer_module_id = audioHandle.moduleID;
			
			context->audioDemuxOutputIndex[0] = i;

			RMDBGLOG((ENABLE, "audio demux output index %lu, module 0x%lx\n", context->audioDemuxOutputIndex[0], context->output_table[i].consumer_module_id));
			openAudioDecoders++;
		}
		else if ((EMHWLIB_MODULE_CATEGORY(context->output_table[i].consumer_module_id) == AudioDecoder) && (openAudioDecoders)) {
			struct DCCAudioSourceHandle audioHandle;

			context->output_table[i].consumer_module_id = 0;

			if (context->audioInstances >= openAudioDecoders + 1) {

				err = DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(context->dcc_info->pMultipleAudioSource, openAudioDecoders, &audioHandle);
				if (err != RM_OK)
					return err;
				context->output_table[i].consumer_module_id = audioHandle.moduleID;
				
				context->audioDemuxOutputIndex[openAudioDecoders] = i;
				
				RMDBGLOG((ENABLE, "audio[%lu] demux output index %lu, module 0x%lx\n",
					openAudioDecoders, context->audioDemuxOutputIndex[openAudioDecoders], context->output_table[i].consumer_module_id));
				openAudioDecoders++;
			}
			else
				continue; //keep processing the rest of the outputs

		}
		else if (EMHWLIB_MODULE_CATEGORY(context->output_table[i].consumer_module_id) == SpuDecoder) {
			/* spu_hack: SpuDecoder is already open by OpenVideoDecoder */
		}
		else {
			RMDBGLOG((ENABLE, "OpenOutputTableForPlayback: unsupported consumer_module_id=0x%lx\n", context->output_table[i].consumer_module_id));
			return err;
		}

		/* the decoder will provide the bitstream, pts and inband fifo - no need to open a DemuxOutput, just connect */
		connect.demux_task_module_id = context->demux_task;
		connect.consumer_module_id = context->output_table[i].consumer_module_id;
		err = RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_Connect, &connect, sizeof(connect), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "OpenOutputTableForPlayback: DemuxOutput %ld failed to connect consumer=0x%lx\n", connect.consumer_module_id));
			return err;
		}
		else
			RMDBGLOG((ENABLE, "module 0x%lx connected to output 0x%lx (index %lu)\n", 
				  connect.consumer_module_id,
				  demux_output,
				  i));
		
		/* Video, Audio need uninit/init sequence */
		if (EMHWLIB_MODULE_CATEGORY(context->output_table[i].consumer_module_id) == VideoDecoder) {
			enum DemuxOutputTrigger_type trigger = DemuxOutputTrigger_Pts;
			err = RUASetProperty(context->dcc_info->pRUA, demux_output, RMDemuxOutputPropertyID_Trigger,
				     &trigger, sizeof(trigger), 0 );
			err = DCCXSetVideoDecoderSourceCodec(context->dcc_info->pVideoSource, context->vcodec);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot set video decoder codec %d\n", err));
				return err;
			}
			/* apply the fixed vop rate if required */
			err = apply_video_decoder_options(context->dcc_info, context->video_opt);
			if (RMFAILED(err)) {
				fprintf(stderr, "%lx_Error applying video_decoder_options err=%d\n", context->id, err);
				return RM_ERROR;
			}

			if (context->video_opt->VopInfo.FixedVopRate) {
				RMDBGLOG((ENABLE, "fixed vop rate from command line: %ld / %ld frames per second\n",
					  context->video_opt->VopInfo.VopTimeIncrementResolution, context->video_opt->VopInfo.FixedVopTimeIncrement));
			}
			else if (context->video_opt->vtimescale.enable) {
				RMDBGLOG((ENABLE, "video time scale from command line: %ld ticks per second\n",
					  context->video_opt->vtimescale.time_resolution));
			}
			else {
				/* time stamps are in 45k, ask the decoder to interpolate the time info from stream.
				   For m4v the property will succeed. */
				context->video_opt->vtimescale.enable = TRUE;
				context->video_opt->vtimescale.time_resolution = 90000;
				err = RUASetProperty(context->dcc_info->pRUA, context->dcc_info->video_decoder, RMVideoDecoderPropertyID_VideoTimeScale,
						     &context->video_opt->vtimescale, sizeof(context->video_opt->vtimescale), 0 );
				if (RMSUCCEEDED(err)) {
					RMDBGLOG((ENABLE, "set video time scale: %ld ticks per second\n",
						  context->video_opt->vtimescale.time_resolution));
				}
				err = RM_OK; /* OK for Mpeg2 */
			}
			/* by default the output has the pts enabled */
			if (!context->play_opt->send_video_pts) {
				err = RUASetProperty(context->dcc_info->pRUA, demux_output, RMDemuxOutputPropertyID_EnablePts, &context->play_opt->send_video_pts, sizeof(context->play_opt->send_video_pts), 0 );
				trigger = DemuxOutputTrigger_None;
				err = RUASetProperty(context->dcc_info->pRUA, demux_output, RMDemuxOutputPropertyID_Trigger, &trigger, sizeof(trigger), 0 );
			}
		}
		else if (EMHWLIB_MODULE_CATEGORY(context->output_table[i].consumer_module_id) == AudioDecoder) {
			enum DemuxOutputTrigger_type trigger = DemuxOutputTrigger_Pts;

			RMDBGLOG((ENABLE, "set triggers for audio output %lu\n", i));

			err = RUASetProperty(context->dcc_info->pRUA, demux_output, RMDemuxOutputPropertyID_Trigger, &trigger, sizeof(trigger), 0 );
			err = RUASetProperty(context->dcc_info->pRUA, demux_output, RMDemuxOutputPropertyID_TransportPriority, &context->audio_ts_priority, sizeof(context->audio_ts_priority), 0 );
#if 1
			/* apply the audio format - uninit, set codec, set specific parameters, init */
			err = apply_audio_decoder_options(context->dcc_info, &(context->audio_opt_table[openAudioDecoders-1]));
			if (RMFAILED(err)) {
				fprintf(stderr, "%lx_Error applying audio_decoder_options err=%d\n", context->id, err);
				return RM_ERROR;
			}

#endif

			/* by default the output has the pts enabled */
			if (!context->play_opt->send_audio_pts) {
				err = RUASetProperty(context->dcc_info->pRUA, demux_output, RMDemuxOutputPropertyID_EnablePts, &context->play_opt->send_audio_pts, sizeof(context->play_opt->send_audio_pts), 0 );
				trigger = DemuxOutputTrigger_None;
				err = RUASetProperty(context->dcc_info->pRUA, demux_output, RMDemuxOutputPropertyID_Trigger, &trigger, sizeof(trigger), 0 );
			}

		}
		else if (EMHWLIB_MODULE_CATEGORY(context->output_table[i].consumer_module_id) == SpuDecoder) {
			enum DemuxOutputTrigger_type trigger = DemuxOutputTrigger_Pts;
			err = RUASetProperty(context->dcc_info->pRUA, demux_output, RMDemuxOutputPropertyID_Trigger,
				     &trigger, sizeof(trigger), 0 );
			/* spu_hack - need to uninit init the spu after connection to DemuxOutput */
			err = DCCXSetVideoDecoderSourceCodec(context->dcc_info->pVideoSource, context->vcodec);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot set spu decoder codec %d\n", err));
				return err;
			}
			/* by default the output has the pts enabled */
			if (!context->play_opt->send_spu_pts) {
				err = RUASetProperty(context->dcc_info->pRUA, demux_output, RMDemuxOutputPropertyID_EnablePts,
					&context->play_opt->send_spu_pts, sizeof(context->play_opt->send_spu_pts), 0 );
				trigger = DemuxOutputTrigger_None;
				err = RUASetProperty(context->dcc_info->pRUA, demux_output, RMDemuxOutputPropertyID_Trigger,
					&trigger, sizeof(trigger), 0 );
			}
		}

		RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_Enable,
			&dummy, sizeof(dummy), 0);
		RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_DataType,
			&context->output_table[i].type, sizeof(context->output_table[i].type), 0);
		{
			struct ReceiveThreshold_type rec_thr;
			/* set to 0 the threshold because in case of playback I don't need the interrupts for receive */
			rec_thr.partial_read = FALSE;
			rec_thr.size = 0;
			RUASetProperty(context->pRUA, demux_output, RMGenericPropertyID_Threshold, &rec_thr, sizeof(rec_thr), 0);
		}
	}
	return err;
}

static RMstatus OpenOutputTableForInputRecord(struct context_per_task *context)
{
	/* open one single output that will be saved in file */
	RMDBGLOG((CALLDBG, "OpenOutputTableForInputRecord (context @0x%08lx)\n", (RMuint32)context));
	
	RMMemset(context->output_table, 0, sizeof(struct Output_type));
	context->output_table[0].type = EMhwlibData_TS;
	context->output_table[0].buffer_count = 32; /* 1 MByte fifo */
	context->output_table[0].buffer_size_log2 = LOG2_32k;
	context->output_table[0].partial_read = FALSE;
	context->output_table[0].threshold = (1<<LOG2_32k);
	sprintf(context->output_table[0].filename, "input_record.out");
	context->output_table[0].receive_mode = receive_data_dma_full_buffer;

	return OpenOutputTableForRecord(context);
}

static RMstatus CloseOutputTablePerTask(struct context_per_task *context)
{
	RMuint32 i;
	RMstatus err = RM_OK;

	RMDBGLOG((CALLDBG, "closeOutputTablePerTask (context @0x%08lx)\n", (RMuint32)context));

	for (i=0; i<context->output_table_count;i++) {
		if (context->output_table[i].demux_output_module_id) {
			RMuint32 dummy;
			err = RUASetProperty(context->pRUA, context->output_table[i].demux_output_module_id,
				RMDemuxOutputPropertyID_Close, &dummy, sizeof(dummy), 0);
			if( RMFAILED(err) ) {
				fprintf(stderr,"OutputEntry_Close %lx: RMDemuxOutputPropertyID_Close failed %d", i, err);
			}
		}
		/* release output buffers */
		if (context->output_table[i].pDma) {
			RUAClosePool(context->output_table[i].pDma);
			context->output_table[i].pDma = NULL;
		}
		
		if (context->output_table[i].pmapped_bts_fifo_base) {
			RUAUnMap(context->pRUA, context->output_table[i].pmapped_bts_fifo_base, context->output_table[i].bts_fifo_size);
		}
		if (context->output_table[i].bts_fifo_base) {
			RUAUnLock(context->pRUA, context->output_table[i].bts_fifo_base, context->output_table[i].bts_fifo_size);
		}

		if (context->output_table[i].UnprotectedAddr) {
			DCCFree(context->dcc_info->pDCC, context->output_table[i].UnprotectedAddr);
			context->output_table[i].UnprotectedAddr = 0;
		}
		if (context->output_table[i].BitstreamProtectedAddr) {
			DCCFree(context->dcc_info->pDCC, context->output_table[i].BitstreamProtectedAddr);
			context->output_table[i].BitstreamProtectedAddr = 0;
		}
		if (context->output_table[i].f_out) {
			fclose(context->output_table[i].f_out);
			context->output_table[i].f_out = NULL;
		}
		if (context->output_table[i].f_pts_out) {
			fclose(context->output_table[i].f_pts_out);
			context->output_table[i].f_pts_out = NULL;
		}
	}
	RMFree(context->output_table);
	
	return err;
}

static RMstatus ResetOutputTablePerTask(struct context_per_task *context)
{
	RMuint32 i;

	RMDBGLOG((ENABLE, "resetOutputTablePerTask (context @0x%08lx)\n", (RMuint32)context));

	for (i=0; i<context->output_table_count;i++) {
		if (context->output_table[i].demux_output_module_id) {
			RMuint32 dummy;
			RMstatus err;
			err = RUASetProperty(context->pRUA, context->output_table[i].demux_output_module_id,
				RMDemuxOutputPropertyID_Flush, &dummy, sizeof(dummy), 0);
			if( RMFAILED(err) ) {
				fprintf(stderr,"OutputEntry_Close %lx: RMDemuxOutputPropertyID_Flush failed %d", i, err);
			}
			if (context->output_table[i].pDma)
				err = RUAPreparePoolForReceiveData(context->output_table[i].pDma);
		}
		if (context->output_table[i].f_out) {
			/*fprintf(stderr, "********** %ld_Received output=%lx total_size=%lx\n",
				context->id, i, context->output_table[i].f_out_size);*/
			fseek(context->output_table[i].f_out, 0, SEEK_SET);
			context->output_table[i].f_out_size = 0;
		}
		if (context->output_table[i].f_pts_out) {
			fseek(context->output_table[i].f_pts_out, 0, SEEK_SET);
		}
	}
	return RM_OK;
}
			
static void SavePtsInfile(struct context_per_task *context, RMuint32 i)
{
	RMstatus err;
	
	if (context->output_table[i].pts_count) {
		while (1) {
			struct DemuxOutput_Pts45kFifoEntry_type pts_entry;

			err = RUAGetProperty(context->pRUA, EMHWLIB_MODULE(DemuxOutput, i + output_count_per_task*context->id),
				RMDemuxOutputPropertyID_Pts45kFifoEntry, &pts_entry, sizeof(pts_entry));
			if (err == RM_OK) {
				RMDBGLOG((ENABLE, "get pts=0x%lx bc=0x%lx\n", pts_entry.pts, pts_entry.byte_counter));
				if (context->output_table[i].f_pts_out) {
					RMuint8 temp[4];
					temp[0] = (RMuint8)(pts_entry.byte_counter>>24);
					temp[1] = (RMuint8)(pts_entry.byte_counter>>16);
					temp[2] = (RMuint8)(pts_entry.byte_counter>>8);
					temp[3] = (RMuint8)(pts_entry.byte_counter>>0);
					fwrite(temp, 1, 4, context->output_table[i].f_pts_out);

					temp[0] = (RMuint8)(pts_entry.pts>>24);
					temp[1] = (RMuint8)(pts_entry.pts>>16);
					temp[2] = (RMuint8)(pts_entry.pts>>8);
					temp[3] = (RMuint8)(pts_entry.pts>>0);
					fwrite(temp, 1, 4, context->output_table[i].f_pts_out);
				}
			}
			else
				break;
		}
	}
}

static RMstatus SaveDemuxOutputPerTaskWithoutDMA(struct context_per_task *context, RMuint32 irq_output_source)
{
	RMuint32 i;
	RMstatus err = RM_ERROR;
		
	//fprintf(stderr, "%lx_SaveDemuxOutputPerTaskWithoutDMA irq_output_source=0x%lx\n", context->id, irq_output_source);

	for (i=0; i<context->output_table_count;i++) {
		if(irq_output_source & (1 << i)) {
			if (context->output_table[i].receive_mode == receive_data_nodma_get_chunk256) {
				RMuint32 left_size;
				struct DataFIFOInfo fifo_info;
				RMuint32 demux_output = EMHWLIB_MODULE(DemuxOutput, i + output_count_per_task*context->id);

				err = RUAGetProperty(context->pRUA, demux_output, RMGenericPropertyID_DataFIFOInfo,
					&fifo_info, sizeof(fifo_info));
				left_size = fifo_info.Readable;
				while(left_size) {
					struct EMhwlibChunk256 out;
					RMuint32 in;
					in = RMmin(left_size, 256);

					err = RUAExchangeProperty(context->pRUA, demux_output, RMGenericPropertyID_ReadChunk256,
						&in, sizeof(in), &out, sizeof(out));
					if(err == RM_OK) {
						left_size -= out.size;
						if (context->output_table[i].callback) {
							(context->output_table[i].callback)(out.data, out.size, NULL, 0, RM_OK, context->output_table[i].section_mask, context);
						}
						if (context->output_table[i].f_out && (out.size > 0)) {
							if (context->output_table[i].f_out_size < MAX_RECORD_FILE_SIZE) { /* save only MAX_RECORD_FILE_SIZE bytes */
								fwrite(out.data, 1, out.size, context->output_table[i].f_out);
							}
							context->output_table[i].f_out_size += out.size;
						}
			
						SavePtsInfile(context, i);
						RMDBGLOG((DISABLE, "get chunk size= 0x%03lx / 0x%03lx f_out_size= 0x%lx \n",
							out.size, fifo_info.Readable, context->output_table[i].f_out_size));
					}
					else {
						RMDBGLOG((ENABLE, "RMGenericPropertyID_ReadChunk256 ERROR\n"));
						break;
					}
				}
			}
			else if (context->output_table[i].receive_mode == receive_data_nodma_rua_map) {
				struct gbus_fifo *fifo;
				RMuint32 rd, wr;
			
				RMDBGLOG((DISABLE, "%ld_SaveDemuxOutputPerTaskWithoutDMA output=0x%lx check\n", context->id, i));
				fifo = (struct gbus_fifo *)context->output_table[i].fifo_container;

				rd = gbus_read_uint32(pgbus, (RMuint32) &(fifo->rd));
				wr = gbus_read_uint32(pgbus, (RMuint32) &(fifo->wr));
				RMDBGLOG((DISABLE, "i=%lx: irq_output_source=%lx fifo_container=%lx base=%lx size=%lx rd=%lx wr=%lx\n",
					i, irq_output_source, context->output_table[i].fifo_container,
					context->output_table[i].bts_fifo_base, context->output_table[i].bts_fifo_size, rd, wr));

				if ( wr > rd ) {
					/* data is contiguos in one chunck */
					if (context->output_table[i].callback) {
						(context->output_table[i].callback)(context->output_table[i].pmapped_bts_fifo_base + rd,
							wr-rd, NULL, 0, RM_OK, context->output_table[i].section_mask, context);
					}
					if (context->output_table[i].f_out) {
						if (context->output_table[i].f_out_size < MAX_RECORD_FILE_SIZE) { // save only MAX_RECORD_FILE_SIZE bytes
							fwrite(context->output_table[i].pmapped_bts_fifo_base + rd, 1, wr-rd, context->output_table[i].f_out);
						}
						context->output_table[i].f_out_size += (wr-rd);
					}
				}
				else if (wr != rd) {
					/* data is separated in two chuncks because of circular fifo. We assume for now that
					the callbacks support not contiguos data and in this case we don't need to RMMemcpy the two chuncks in only one. */
					if (context->output_table[i].callback) {
						(context->output_table[i].callback)(context->output_table[i].pmapped_bts_fifo_base + rd,
							context->output_table[i].bts_fifo_size-rd, NULL, 0, RM_OK, context->output_table[i].section_mask, context);
						(context->output_table[i].callback)(context->output_table[i].pmapped_bts_fifo_base,
							wr, NULL, 0, RM_OK, context->output_table[i].section_mask, context);
					}
					if (context->output_table[i].f_out) {
						if (context->output_table[i].f_out_size < MAX_RECORD_FILE_SIZE) { // save only MAX_RECORD_FILE_SIZE bytes
							fwrite(context->output_table[i].pmapped_bts_fifo_base + rd, 1,
								context->output_table[i].bts_fifo_size-rd, context->output_table[i].f_out);
							fwrite(context->output_table[i].pmapped_bts_fifo_base, 1, wr, context->output_table[i].f_out);
						}
						context->output_table[i].f_out_size += (context->output_table[i].bts_fifo_size+wr-rd);
					}
				}

				gbus_write_uint32(pgbus, (RMuint32) &(fifo->rd), wr);
			
				SavePtsInfile(context, i);
			
			}
		}
	}

	return err;
}

static RMstatus ReceiveDataAndSaveInFilePerTask(struct context_per_task *context)
{
	RMuint32 i;
	RMstatus err = RM_OK;
	RMuint8 *pBuf = NULL;
	RMuint32 size = 0;
	RMint32 irq_output_source;
		
	RMDBGLOG((CALLDBG, "receiveDataAndSaveInFilePerTask (context @0x%08lx)\n", (RMuint32)context));


	/* read irq_output_source - TODO check problem at the end when interrupt does not come and I miss some packets */
	RUAGetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_IrqOutputSource, &irq_output_source, sizeof(irq_output_source));
	//fprintf(stderr, "%ld_ReceiveDataAndSaveInFilePerTask irq_output_source=0x%lx\n", context->id, irq_output_source);

	for (i=0; i<context->output_table_count;i++) {
		RMuint32 received_buffer_count = 0;
		while(context->output_table[i].pDma && (irq_output_source & (1 << i))) {
			//fprintf(stderr, "%ld_ReceiveDataAndSaveInFilePerTask output=0x%lx check\n", context->id, i);
			err = RUAReceiveData(context->pRUA, EMHWLIB_MODULE(DemuxOutput, i + output_count_per_task*context->id),
				context->output_table[i].pDma, &pBuf, &size, NULL, NULL);
			if ( RMFAILED(err) || (pBuf == NULL) ) {
				//fprintf(stderr, "%ld_ReceiveDataAndSaveInFilePerTask output=0x%lx RM_ERROR or buf=0x%lx\n", context->id, i, (RMuint32)pBuf);
				err = RM_OK;
				break;
			}
			if ( size == 0 ) {
				//fprintf(stderr, "%ld_ReceiveDataAndSaveInFilePerTask output=0x%lx size=0x%lx\n", context->id, i, size);
				RUAReleaseBuffer(context->output_table[i].pDma, pBuf);
				break;
			}

			//fprintf(stderr, "%ld_ReceiveDataAndSaveInFilePerTask output=0x%lx size= 0x%lx\n", context->id, i, size);
			if (context->output_table[i].callback) {
				(context->output_table[i].callback)(pBuf, size, NULL, 0, RM_OK, context->output_table[i].section_mask, context);
			}
			if (context->output_table[i].f_out) {
				if (context->output_table[i].f_out_size < MAX_RECORD_FILE_SIZE) { /* save only MAX_RECORD_FILE_SIZE bytes */
					fwrite(pBuf, 1, size, context->output_table[i].f_out);
				}
				context->output_table[i].f_out_size += size;
			}
			
			SavePtsInfile(context, i);
			
			while (0) {
				struct InbandCommandX_type ibc_entry;

				err = RUAGetProperty(context->pRUA, EMHWLIB_MODULE(DemuxOutput, i + output_count_per_task*context->id),
					RMGenericPropertyID_InbandCommandX, &ibc_entry, sizeof(ibc_entry));
				if (err == RM_OK) {
					RMDBGLOG((LOCALDBG, "get ibc tag=0x%lx bc=0x%lx\n", ibc_entry.flags_tag, ibc_entry.offset_value));
				}
				else
					break;
			}
			
			RUAReleaseBuffer(context->output_table[i].pDma, pBuf);

			received_buffer_count++;
			if (received_buffer_count == context->output_table[i].buffer_count) {
				/* if one output is high bit rate we could stay in this while loop forever.
				   Let's try to go in main loop from time to time. */
				break;
			}
		}
	}
	return err;
}

#ifndef WITH_MONO
			
static void show_usage(char *progname)
{
	fprintf(stderr, "DEMUX OPTIONS (default values inside brackets)\n"
		"\t-task index, where index=[0],1,2\n"
		"\t-app [psf], pes, input_record\n"
		"\t      dvb_arte,dvb_cwe,dvb_cwo,arib,dvb_1ecm,dvb_4ecm,dvb_stream,dvb_cwtest,dvb_vgs3,\n"
		"\t      arib,\n"
		"\t      aes_skf,aes_dsodd,aes_dscps,aes_scra,aes_precipher\n"
		"\t-y [m2t],dvd,m1s\n"
	        "\t-tsskip: Number of padding bytes to discard between every 188 TS packets [0]. Use 4 for blue-ray streams\n"
		"\t-vpid video_pid: [0]\n"
		"\t-apid audio_pid: [0]\n"
		"\t-rpid pcr_pid: [video_pid]\n"
		"\t-ssubid spu substream id: [0]\n"
		"\t-asubid audio substream id: [0]\n"
		"\t-ecm0pid ecm_pid[0]: [ecm_pid for video]\n"
		"\t-ecm1pid ecm_pid[1]: [ecm_pid for audio]\n"
		"\t-spi index: select paralel SPI and index=[0],1\n"
		"\t-ssi index: select serial SPI and index=[0],1,2\n"
		"\t-idleport index: select not used input port, needed for file playback, index=0,1,2,[3]\n"
		"\t-pmt index: select the program for playback using PMT index=[0]. If the index points to a network PID, next index will be used.\n"
		"\t-synclock count: select sync lock count for transport streams [0],1,..,7. Use not zero values for corrupted media. \n"
		"\t-pcrdisc threshold: threshold in ms [5000] \n"
		"\t-audiotspriority priority: [0],2,3\n"
		"\t-streamtype6 acodec: [dts],ac3\n"
		"\t-allpat: all pat sections will be received by application, no matter the version\n"
		"\t-allpmt: all pmt sections will be received by application, no matter the version\n"
		"\t-chpr change_program_mode: [stopall] nostop avstop \n"
		"\t-send_scrambled \n"
		);
#ifdef WITH_AACS
	fprintf(stderr,
		"\t-aacs <xtask pid> <xtask context>\n");
	fprintf(stderr,
		"\t-mt <spn0> ... <spn5>\n"
		"\t-sk <playlist id> < playitem id>\n");
#endif /* WITH_AACS */
	show_playback_options();
	show_display_options();
	show_video_options();
	show_audio_options();

	fprintf(stderr, "--------------------------------\n");
	fprintf(stderr, "Minimum cmd line: %s <file name>\n", progname);
	fprintf(stderr, "--------------------------------\n");

	exit(1);
}

#if defined(AES_KEY_SCR1111) || defined(AES_KEY_SCR1112)
static void reverse_byte_order_in_array( RMuint8 * array, RMuint32 size )
{
	RMuint32 i;
	for( i=0; i<(size/2); i++ ) {
		RMuint8 temp = array[i];
		array[i] = array[size-1-i];
		array[size-1-i] = temp;
	}
}

static void reverse_key_iv_byte_order( struct aes_key * ptable, RMuint32 size )
{
	RMuint32 i;
	for( i=0; i<size; i++ ) {
		reverse_byte_order_in_array( ptable[i].key, 16 );
		reverse_byte_order_in_array( ptable[i].iv, 16 );
	}
}
#endif 

static void parse_cmdline(int argc, char *argv[])
{
	int i;
	RMstatus err;
	RMuint32 task_index = 0;
	RMuint32 current_audio_instance = 0;
	struct playback_cmdline  *play_opt;
	struct display_cmdline   *disp_opt;
	struct video_cmdline     *video_opt;
	struct audio_cmdline     *audio_opt;
	struct demux_cmdline     *demux_opt;

	/* init first task in case "-task" option is not called */
	play_opt = &playback_options[0];
	disp_opt = &display_options[0];
	video_opt = &video_options[0];
	audio_opt = &audio_options[0];
	demux_opt = &demux_options[0];
	Tasks[0].id = 0;
	task_count = 0;

	if (argc < 2) 
		show_usage(argv[0]);
	
	i = 1;
	while ((argc > i)) {
		if (argv[i][0] != '-') {
			if (play_opt->filename == NULL) {
				play_opt->spi = FALSE;
				play_opt->filename = argv[i];
				i++;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-task")) {
			if (argc > i+1) {
				RMuint32 j = 0, task_id;
				task_id = strtol(argv[i+1], NULL, 10);
				if (task_id > MAX_TASK_COUNT)
					show_usage(argv[0]);
				i+=2;

				/* search for same task id */
				for (j=0; j < task_count; j++) {
					if( task_id == Tasks[j].id)
						break;
				}
				task_index = j;
				if ( task_index == task_count ) {
					/* new task id appeared */
					Tasks[task_index].id = task_id;
					task_count++;
					if (task_count > MAX_TASK_COUNT)
						show_usage(argv[0]);
					/* by default initialize the video, audio decoders as task id */
					video_options[task_index].VideoDecoderID = Tasks[task_index].id;
					audio_options[task_index*MAX_AUDIO_DECODER_INSTANCES].AudioDecoderID = Tasks[task_index].id;
					display_options[task_index].video_scaler = Tasks[task_index].id;
					if (Tasks[task_index].id ==2) {
						audio_options[task_index*MAX_AUDIO_DECODER_INSTANCES].AudioEngineID = 1;
						audio_options[task_index*MAX_AUDIO_DECODER_INSTANCES].AudioDecoderID = 0;
					}
				}
				play_opt = &playback_options[task_index];
				disp_opt = &display_options[task_index];
				video_opt = &video_options[task_index];
				audio_opt = &audio_options[task_index*MAX_AUDIO_DECODER_INSTANCES];
				demux_opt = &demux_options[task_index];
				current_audio_instance = 0;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-app")) {
			if (argc > i+1) {
				if ( ! strcmp(argv[i+1], "psf")) {
					Tasks[task_index].app_type = pid_filter_section;
					Tasks[task_index].SourceType = SourceType_m2t;
				}
				else if ( ! strcmp(argv[i+1], "dvb_arte")) {
					Tasks[task_index].app_type = dvbcsa_decryption;
					Tasks[task_index].SourceType = SourceType_m2t;
					Tasks[task_index].pkey_table = (void *)arte_dvb_key_table;
					Tasks[task_index].key_table_size = sizeof(arte_dvb_key_table)/sizeof(struct dvb_csa_key);
				}
				else if ( ! strcmp(argv[i+1], "dvb_cwe")) {
					Tasks[task_index].app_type = dvbcsa_decryption;
					Tasks[task_index].SourceType = SourceType_m2t;
					Tasks[task_index].pkey_table = (void *)cweven_dvb_key_table;
					Tasks[task_index].key_table_size = sizeof(cweven_dvb_key_table)/sizeof(struct dvb_csa_key);
				}
				else if ( ! strcmp(argv[i+1], "dvb_cwo")) {
					Tasks[task_index].app_type = dvbcsa_decryption;
					Tasks[task_index].SourceType = SourceType_m2t;
					Tasks[task_index].pkey_table = (void *)cwodd_dvb_key_table;
					Tasks[task_index].key_table_size = sizeof(cwodd_dvb_key_table)/sizeof(struct dvb_csa_key);
				}
				else if ( ! strcmp(argv[i+1], "arib")) {
					Tasks[task_index].app_type = multi2_decryption;
					Tasks[task_index].SourceType = SourceType_m2t;
					Tasks[task_index].pkey_table = (void *)arib_key_table;
					Tasks[task_index].key_table_size = sizeof(arib_key_table)/sizeof(struct dvb_arib_key);
				}
				else if ( ! strcmp(argv[i+1], "dvb_1ecm")) {
					Tasks[task_index].app_type = dvbcsa_decryption;
					Tasks[task_index].SourceType = SourceType_m2t;
					Tasks[task_index].pkey_table = (void *)ecm1_dvb_key_table;
					Tasks[task_index].key_table_size = sizeof(ecm1_dvb_key_table)/sizeof(struct dvb_csa_key);
				}
				else if ( ! strcmp(argv[i+1], "dvb_4ecm")) {
					Tasks[task_index].app_type = dvbcsa_decryption;
					Tasks[task_index].SourceType = SourceType_m2t;
					Tasks[task_index].pkey_table = (void *)ecm4_dvb_key_table;
					Tasks[task_index].key_table_size = sizeof(ecm4_dvb_key_table)/sizeof(struct dvb_csa_key);
				}
				else if ( ! strcmp(argv[i+1], "dvb_cwtest")) {
					Tasks[task_index].app_type = dvbcsa_decryption;
					Tasks[task_index].SourceType = SourceType_m2t;
					Tasks[task_index].pkey_table = (void *)cwtest_dvb_key_table;
					Tasks[task_index].key_table_size = sizeof(cwtest_dvb_key_table)/sizeof(struct dvb_csa_key);
				}
				else if ( ! strcmp(argv[i+1], "dvb_vgs3")) {
					Tasks[task_index].app_type = dvbcsa_decryption;
					Tasks[task_index].SourceType = SourceType_m2t;
					Tasks[task_index].pkey_table = (void *)vgs3_dvb_key_table;
					Tasks[task_index].key_table_size = sizeof(vgs3_dvb_key_table)/sizeof(struct dvb_csa_key);
				}
				else if ( ! strcmp(argv[i+1], "aes_skf")) {
					Tasks[task_index].app_type = aes_cbc_decryption;
					Tasks[task_index].SourceType = SourceType_m2t;
					Tasks[task_index].pkey_table = (void *)skf_aes_key_table;
					Tasks[task_index].key_table_size = sizeof(skf_aes_key_table)/sizeof(struct aes_key);
				}
				else if ( ! strcmp(argv[i+1], "aes_scra")) {
					Tasks[task_index].app_type = aes_ecb_decryption;
					Tasks[task_index].SourceType = SourceType_m2t;
					Tasks[task_index].pkey_table = (void *)scrambled_aes_key_table;
					Tasks[task_index].key_table_size = sizeof(scrambled_aes_key_table)/sizeof(struct aes_key);
				}
				else if ( ! strcmp(argv[i+1], "aes_ecb")) {
					Tasks[task_index].app_type = aes_ecb_decryption;
					Tasks[task_index].SourceType = SourceType_m2t;
					Tasks[task_index].pkey_table = (void *)aes_ecb_key_table;
					Tasks[task_index].key_table_size = sizeof(aes_ecb_key_table)/sizeof(struct aes_key);
				}
				else if ( ! strcmp(argv[i+1], "aes_dsodd")) {
					Tasks[task_index].app_type = aes_ecb_decryption;
					Tasks[task_index].SourceType = SourceType_m2t;
					Tasks[task_index].pkey_table = (void *)dsodd_aes_key_table;
					Tasks[task_index].key_table_size = sizeof(dsodd_aes_key_table)/sizeof(struct aes_key);
				}
				else if ( ! strcmp(argv[i+1], "aes_dscps")) {
					Tasks[task_index].app_type = aes_ecb_decryption;
					Tasks[task_index].SourceType = SourceType_m2t;
					Tasks[task_index].pkey_table = (void *)dscps_aes_key_table;
					Tasks[task_index].key_table_size = sizeof(dscps_aes_key_table)/sizeof(struct aes_key);
				}
				else if ( ! strcmp(argv[i+1], "aes_ofb")) {
					Tasks[task_index].app_type = aes_ofb_decryption;
					Tasks[task_index].SourceType = SourceType_m2t;
					Tasks[task_index].pkey_table = (void *)aes_cbc_ofb_key_table;
					Tasks[task_index].key_table_size = sizeof(aes_cbc_ofb_key_table)/sizeof(struct aes_key);
#if defined(AES_KEY_SCR1111) || defined(AES_KEY_SCR1112)
					reverse_key_iv_byte_order(Tasks[task_index].pkey_table, Tasks[task_index].key_table_size);
#endif 
				}
				/* ####### AES_CBC_PRECIPHER TEST CODE BEGIN ####### */
				else if ( ! strcmp(argv[i+1], "aes_precipher")) {
					Tasks[task_index].test_aes_precipher = TRUE;
					Tasks[task_index].pkey_table = (void *)precipher_aes_key_table;
					Tasks[task_index].key_table_size = sizeof(precipher_aes_key_table)/sizeof(struct aes_2keys_test);
				}
				/* ###### AES_CBC_PRECIPHER TEST CODE END ########## */				
				else if ( ! strcmp(argv[i+1], "dvb_stream")) {
					Tasks[task_index].app_type = dvbcsa_decryption;
					Tasks[task_index].SourceType = SourceType_m2t;
					Tasks[task_index].pkey_table = (void *)stream_dvb_key_table;
					Tasks[task_index].key_table_size = sizeof(stream_dvb_key_table)/sizeof(struct dvb_csa_key);
				}
				else if ( ! strcmp(argv[i+1], "pes")) {
					Tasks[task_index].app_type = program_stream_parsing;
				}
				else if ( ! strcmp(argv[i+1], "input_record")) {
					Tasks[task_index].SourceType = SourceType_payload;
					Tasks[task_index].app_type = input_record;
				}
				else
					show_usage(argv[0]);
				i += 2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-y")) {
			if (argc > i+1) {
				if ( ! strcmp(argv[i+1], "m2t")) {
					Tasks[task_index].SourceType = SourceType_m2t;
				}
				else if ( ! strcmp(argv[i+1], "dvd")) {
					Tasks[task_index].SourceType = SourceType_dvd;
					Tasks[task_index].app_type = program_stream_parsing;
				}
				else if ( ! strcmp(argv[i+1], "m1s")) {
					Tasks[task_index].SourceType = SourceType_m1s;
					Tasks[task_index].app_type = program_stream_parsing;
				}
				else
					show_usage(argv[0]);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-tsskip")) {
			if (argc > i+1) {
				Tasks[task_index].ts_skip = strtol(argv[i+1], NULL, 10);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-vscaler")) {
			if (argc > i+1) {
				RMasciiToUInt32(argv[i+1], &(disp_opt->video_scaler));
				i += 2;
				if (disp_opt->video_scaler > 2) 
					show_usage(argv[0]);
			}
			else
				show_usage(argv[0]);
		
		}
#ifdef WITH_AACS
		else if ( ! strcmp(argv[i], "-aacs")) {
			if (argc > i + 2) {
				Tasks[task_index].aacs_xtask_pid = strtol(argv[i + 1], NULL, 0);
				Tasks[task_index].aacs_context = strtol(argv[i + 2], NULL, 0);
				i += 3;
			} else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-mt")) {
			if (argc > i + 6) {
			    RMuint32 j;
			    for (j = 1; j <= MAX_SP; j++)
				    Tasks[task_index].mt_spn[j - 1] = strtol(argv[i + j], NULL, 0);
			    Tasks[task_index].mt_index = 0;
			    i += 7;
			    Tasks[task_index].mt_enabled = 1;
			} else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-sk")) {
			if (argc > i + 2) {
				Tasks[task_index].sk_plid = strtol(argv[i + 1], NULL, 0);
				Tasks[task_index].sk_item = strtol(argv[i + 2], NULL, 0);
				Tasks[task_index].sk_enabled = 1;
				i += 3;
			} else
				show_usage(argv[0]);
		}
#endif /* WITH_AACS */
		else if ( ! strcmp(argv[i], "-spu")) {
			Tasks[task_index].enable_spu = TRUE;
			i++;
		}
		else if ( ! strcmp(argv[i], "-vpid")) {
			if (argc > i+1) {
				Tasks[task_index].video_pid = strtol(argv[i+1], NULL, 0);
				Tasks[task_index].av_flags |= VIDEO_PID_FROM_CMDLINE;
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-apid")) {
			if (argc > i+1) {
				Tasks[task_index].audio_pid = strtol(argv[i+1], NULL, 0);
				Tasks[task_index].av_flags |= AUDIO_PID_FROM_CMDLINE;
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-rpid")) {
			if (argc > i+1) {
				Tasks[task_index].pcr_pid = strtol(argv[i+1], NULL, 0);
				Tasks[task_index].av_flags |= PCR_PID_FROM_CMDLINE;
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-asubid")) {
			if (argc > i+1) {
				Tasks[task_index].audio_subid = strtol(argv[i+1], NULL, 0);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-ssubid")) {
			if (argc > i+1) {
				Tasks[task_index].spu_subid = strtol(argv[i+1], NULL, 0);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-ecm0pid")) {
			if (argc > i+1) {
				Tasks[task_index].ecm_pid[0] = strtol(argv[i+1], NULL, 0);
				Tasks[task_index].av_flags |= ECM0_PID_FROM_CMDLINE;
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-ecm1pid")) {
			if (argc > i+1) {
				Tasks[task_index].ecm_pid[1] = strtol(argv[i+1], NULL, 0);
				Tasks[task_index].av_flags |= ECM1_PID_FROM_CMDLINE;
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-ttxpid")) {
			if (argc > i+1) {
				Tasks[task_index].teletext_pid = strtol(argv[i+1], NULL, 0);
				Tasks[task_index].av_flags |= TTX_PID_FROM_CMDLINE;
				Tasks[task_index].video_opt->display_ttx = TRUE;
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-pmt")) {
			if (argc > i+1) {
				Tasks[task_index].pmt_index = strtol(argv[i+1], NULL, 0);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-spi")) {
			play_opt->spi = TRUE;
			play_opt->serial_spi = FALSE;
			if (argc > i+1) {
				if ( (argv[i+1][0] == '0') || (argv[i+1][0] == '1') ) {
					Tasks[task_index].input_port = argv[i+1][0] - '0';
					/* for SPI the hardware input port are 0 and 2 */
					Tasks[task_index].input_port = 2* Tasks[task_index].input_port;
					i+=2;
				}
				else {
					fprintf(stderr, "Please specify -spi 0 or 1\n"); 
					show_usage(argv[0]);
				}
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-ssi")) {
			play_opt->spi = TRUE;
			play_opt->serial_spi = TRUE;
			if (argc > i+1) {
				if ( (argv[i+1][0] >= '0') && (argv[i+1][0] <= '2') ) {
					Tasks[task_index].input_port = argv[i+1][0] - '0';
					/* for SSI the hardware input port are 0, 1 and 2 */
					i+=2;
				}
				else {
					fprintf(stderr, "Please specify -ssi 0, 1 or 2 \n"); 
					show_usage(argv[0]);
				}
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-idleport")) {
			if (argc > i+1) {
				idle_port = strtol(argv[i+1], NULL, 10);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-synclock")) {
			if (argc > i+1) {
				Tasks[task_index].sync_lock = strtol(argv[i+1], NULL, 10);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-pcrdisc")) {
			if (argc > i+1) {
				Tasks[task_index].pcr_disc = strtol(argv[i+1], NULL, 10);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-audiotspriority")) {
			if (argc > i+1) {
				Tasks[task_index].audio_ts_priority = (enum EMhwlibTransportPriority_type)strtol(argv[i+1], NULL, 10);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-allpat")) {
			Tasks[task_index].section_filter_based_on_new_version &= ~1;
			i++;
		}
		else if ( ! strcmp(argv[i], "-allpmt")) {
			Tasks[task_index].section_filter_based_on_new_version &= ~2;
			i++;
		}
		else if ( ! strcmp(argv[i], "-monitor")) {
			Tasks[task_index].monitor = TRUE;
			i++;
		}
		else if ( ! strcmp(argv[i], "-timedbg")) {
			timedbg = TRUE;
			i++;
		}
		else if (RMCompareAscii(argv[i], "-dfifo")) {
			if (argc > i+1) {
				RMasciiToUInt32(argv[i+1], &(demux_opt->fifo_size));
				demux_opt->fifo_size *= 1024;
				i += 2;
				err = RM_OK;
			}
			else
				err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-dxfer")) {
			if (argc > i+1) {
				RMasciiToUInt32(argv[i+1], &(demux_opt->xfer_count));
				i += 2;
				err = RM_OK;
			}
			else
				err = RM_ERROR;
		}
		else if (! strcmp(argv[i], "-streamtype6")) {
			if (argc > i+1) {
				err = RM_OK;
				if ( !(strcmp(argv[i+1], "ac3"))) {
					stream_type_6 = AudioDecoder_Codec_AC3;
				}
				else if ( ! (strcmp(argv[i+1], "dts"))) {
					stream_type_6 = AudioDecoder_Codec_DTS;
				} 
				else {
					err = RM_ERROR;
				}
			}
			else
				err = RM_ERROR;
			i+=2;
		}
		else if (! strcmp(argv[i], "-chpr")) {
			if (argc > i+1) {
				err = RM_OK;
				if ( !(strcmp(argv[i+1], "stopall"))) {
					Tasks[task_index].change_program_method = change_program_with_stop_all;
				}
				else if ( ! (strcmp(argv[i+1], "nostop"))) {
					Tasks[task_index].change_program_method = change_program_without_stop;
				} 
				else if ( ! (strcmp(argv[i+1], "avstop"))) {
					Tasks[task_index].change_program_method = change_program_with_av_stop;
				} 
				else {
					err = RM_ERROR;
				}
			}
			else
				err = RM_ERROR;
			i+=2;
		}
		else if ( ! strcmp(argv[i], "-send_scrambled")) {
			demux_opt->send_scrambled_packets_for_invalid_key = TRUE;
			i++;
		}
		else {
			err = parse_playback_cmdline(argc, argv, &i, play_opt);
			if (err == RM_ERROR) 
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_display_cmdline(argc, argv, &i, disp_opt);
			if (err == RM_ERROR) 
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_video_cmdline(argc, argv, &i, video_opt);
			if (err == RM_ERROR)
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;

			err = parse_audio_cmdline2(argc, argv, &i, Tasks[task_index].audio_opt_table, MAX_AUDIO_DECODER_INSTANCES, &current_audio_instance);
			if (RMFAILED(err))
				show_usage(argv[0]);
		}
	}

	/* in case "-task" option was not called assume only one task */
	if(task_count == 0) {
		task_count = 1;
	}
	if ( (play_opt->spi == FALSE) && (play_opt->filename == NULL) )
		show_usage(argv[0]);
}
#endif /* ! WITH_MONO */

#ifndef	DO_CAPTURE

static RMbool CheckAllTaskReady (struct context_per_task *context)
{
	RMuint32 j;
	
	if (context->file_status == RM_ERRORENDOFFILE) {
		context->nTimes++;
		if (context->wait_eos_state)
			fprintf(stderr, "%lx_Stop received in CheckAllTaskReady wait_eos_state=%lx, %ld times\n",
				context->id, context->wait_eos_state, context->nTimes);
		context->file_status = RM_OK; /* remove EOS status RM_ERRORENDOFFILE */
		if (context->play_opt->loop_count > 0)
			context->play_opt->loop_count --;

		if ((context->play_opt->loop_count > 0) || (context->play_opt->infinite_loop)) {
			RMDBGLOG((ENABLE, "seek to zero\n"));
			if (RMSeekFile(context->file, 0, RM_FILE_SEEK_START) == RM_ERRORSEEKFILE) {
				fprintf(stderr, "%lx_Error seeking file to beginning\n", context->id);
				return TRUE;
			}
		}
		else if (context->play_opt->loop_count == 0) {
			/* check if all tasks are finished */
			RMuint32 done_tasks = 0;
			for (j=0; j< task_count; j++) {
				if ((Tasks[j].play_opt->loop_count > 0) || (Tasks[j].play_opt->infinite_loop))
					done_tasks++;
			}
			if(done_tasks == 0)
				return TRUE;
		}
	}

	return FALSE;
}
#endif

static RMstatus StopCleanup (struct context_per_task *context)
{
	RMuint32 j;
	RMstatus err;
	
	if(context->pDma) {
		if(context->buf)
			RUAReleaseBuffer(context->pDma, context->buf);
		err = RUAResetPool(context->pDma);	/* needed for no dram copy version on standalone */
		if (RMFAILED(err)) {
			fprintf(stderr, "%lx_Error cannot reset dmapool\n", context->id);
			return err;
		}
	}
		
	context->buf = NULL;
	context->buffer_used = FALSE;
	context->send_inband = FALSE;
	context->file_byte_counter = 0;
#if defined(WITH_AACS)
	context->mt_index = 0;
#endif /* WITH_AACS */

	if (context->file_status == RM_ERRORENDOFFILE) {
		context->nTimes++;
		if (context->wait_eos_state)
			fprintf(stderr, "%lx_Stop received in StopCleanup wait_eos_state=%lx, %ld times\n",
				context->id, context->wait_eos_state, context->nTimes);
		context->file_status = RM_OK; /* remove EOS status RM_ERRORENDOFFILE */
		if (context->play_opt->loop_count > 0)
			context->play_opt->loop_count --;

		if ((context->play_opt->loop_count > 0) || (context->play_opt->infinite_loop)) {
			RMDBGLOG((ENABLE, "seek to zero\n"));
			if (RMSeekFile(context->file, 0, RM_FILE_SEEK_START) == RM_ERRORSEEKFILE) {
				fprintf(stderr, "%lx_Error seeking file to beginning\n", context->id);
				return RM_ERROR;
			}
		}
		else if (context->play_opt->loop_count == 0) {
			/* check if all tasks are finished */
			RMuint32 done_tasks = 0;
			for (j=0; j< task_count; j++) {
				if ((Tasks[j].play_opt->loop_count > 0) || (Tasks[j].play_opt->infinite_loop))
					done_tasks++;
			}
			if(done_tasks)
				return RM_ERROR;
		}
	}
	context->wait_eos_state = MAX_EVENT_COUNT_PER_TASK; /* invalid state */
	err = ResetOutputTablePerTask(context);

	return RM_OK;
}

static RMstatus HwStop(struct context_per_task *context)
{
	RMstatus err;

	RMDBGLOG((ENABLE, "hwstop\n"));

	/* stop STC, decoders, demux */
	err = DCCStopDemuxTask(context->dcc_info->pDemuxTask);
	if (RMFAILED(err)) {
		fprintf(stderr, "%lx_Cannot stop demux %d\n", context->id, err);
		return err;
	}
	if (context->dcc_info->pVideoSource) {
		err = DCCStopVideoSource(context->dcc_info->pVideoSource, DCCStopMode_LastFrame);
		if (RMFAILED(err)) {
			fprintf(stderr, "%lx_Cannot stop video decoder err=%d\n", context->id, err);
			return err;
		}
	}

	if (context->dcc_info->pMultipleAudioSource) {
		RMDBGLOG((ENABLE, "stop multiple audio source\n"));
		err = DCCStopMultipleAudioSource(context->dcc_info->pMultipleAudioSource);
		if (RMFAILED(err)) {
			fprintf(stderr, "%lx_Cannot stop multiple audio decoder err=%d\n", context->id, err);
			return err;
		}
	}


	DCCSTCStop(context->dcc_info->pStcSource); // hack - stop STC after audio is stopped

	err = StopCleanup(context);
	
	if ((context->monitor) || FORCE_MONITOR) {
		RMDBGLOG((ENABLE, "FIFO STATUS after stop\n"));
		monitor(context, TRUE); 
		RMDBGLOG((ENABLE, "***********************\n"));
	}


	return err;
}

static RMstatus HwPlay(struct context_per_task *context)
{
	RMstatus err;

	RMDBGLOG((ENABLE, "hwplay\n"));

	if ((context->monitor) || FORCE_MONITOR) {
		RMDBGLOG((ENABLE, "FIFO STATUS before play\n"));
		monitor(context, TRUE); 
		RMDBGLOG((ENABLE, "***********************\n"));
	}
	
	if (((context->isTrickMode) || (context->isIFrameMode)) && (context->play_opt->send_audio)) {
		RMuint32 demux_output;
		RMuint32 dummy;
		RMuint32 i;
		
		RMDBGLOG((ENABLE, ">> reenable audio output\n"));
		for (i = 0; i < context->audioInstances; i++) {
			demux_output = EMHWLIB_MODULE(DemuxOutput, context->audioDemuxOutputIndex[i] + output_count_per_task * context->id);
			
			err = RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_Enable, &dummy, sizeof(dummy), 0);
			if( RMFAILED(err) ) {
				fprintf(stderr, "couldnt enable audio output");
			}
		}
		context->isTrickMode = FALSE;
		context->isIFrameMode = FALSE;
	}
	if (context->isRewinding)
		context->isRewinding = FALSE;

	/* play STC, decoders, demux - no need for STC play if EMhwlibTimerSync_FirstPcrSetPlayStc is used for RMDemuxTaskPropertyID_TimerSync */
	if (!context->play_opt->send_video_pts && !context->play_opt->send_audio_pts && !context->play_opt->send_spu_pts) {
		fprintf(stderr, "%lx_DCCSTCSetTime 0\n", context->id);
		DCCSTCSetTime(context->dcc_info->pStcSource, 0, 45000);
		DCCSTCPlay(context->dcc_info->pStcSource);
	}
	DCCSTCSetSpeed(context->dcc_info->pStcSource, context->play_opt->speed_N, context->play_opt->speed_M);
	if (context->dcc_info->pVideoSource) {
		err = DCCPlayVideoSource(context->dcc_info->pVideoSource, DCCVideoPlayFwd);
//		err = DCCPlayVideoSource(context->dcc_info->pVideoSource, DCCVideoPlayIFrame);
		if (RMFAILED(err)) {
			fprintf(stderr, "%lx_Cannot play video decoder %d\n", context->id, err);
			return err;
		}
	}

	if (context->dcc_info->pMultipleAudioSource) {
		RMDBGLOG((ENABLE, "play multiple audio source\n"));
		err = DCCPlayMultipleAudioSource(context->dcc_info->pMultipleAudioSource);
		if (RMFAILED(err)) {
			fprintf(stderr, "%lx_Cannot play multiple audio decoder err=%d\n", context->id, err);
			return err;
		}
	}



	err = DCCPlayDemuxTask(context->dcc_info->pDemuxTask);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot play demux %d\n", err);
	}
	return err;
}



static RMstatus Stop(struct context_per_task *pContext, RMuint32 devices)
{
	RMstatus err = RM_OK;
	
	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "STOP: stc\n"));
		DCCSTCStop(pContext->dcc_info->pStcSource);
	}

	if (devices & RM_DEVICES_PSFDEMUX) {
		RMDBGLOG((ENABLE, "STOP: psfdemux\n"));
		
		err = DCCStopDemuxTask(pContext->dcc_info->pDemuxTask);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot stop demux %lx, err=%d\n", pContext->id, err);
			return err;
		}

		err = StopCleanup(pContext);

	}

	if (err != RM_OK)
		return err;


	if (devices & RM_DEVICES_VIDEO) {
		if ((pContext->sendVideoData) && (pContext->dcc_info->pVideoSource)) {
			RMDBGLOG((ENABLE, "STOP: video decoder\n"));
			err = DCCStopVideoSource(pContext->dcc_info->pVideoSource, DCCStopMode_LastFrame);
//			err = DCCStopVideoSource(pContext->dcc_info->pVideoSource, DCCStopMode_BlackFrame);
			if (RMFAILED(err)) {
				fprintf(stderr, "Cannot stop video decoder %lx, err=%d\n", pContext->id, err);
				return err;
			}
			{       // in case of h264, some streams only send sps and pps informations at the beginning of the stream
				// stopping in the middle of the stream causes loss of these information 
				// so to make the video decoder to explicitly save the information after stopping
				RMbool keep_sequence = TRUE;
				RMDBGLOG((LOCALDBG, "STOP: save video header \n"));
				err = RUASetProperty(pContext->dcc_info->pRUA, pContext->dcc_info->video_decoder, RMVideoDecoderPropertyID_StorePreviousVideoHeader,
					&keep_sequence, sizeof(keep_sequence), 0);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Error setting video decoder to keep sequence header on Stop %d\n", err));
					return err;
				}
			}
		}
	}

	if (devices & RM_DEVICES_AUDIO) {
		if (pContext->sendAudioData) { 
			if (pContext->dcc_info->pMultipleAudioSource) {
				RMDBGLOG((ENABLE, "STOP: multiple audio decoder\n"));
				
				err = DCCStopMultipleAudioSource(pContext->dcc_info->pMultipleAudioSource);
				if (RMFAILED(err)){
					fprintf(stderr, "Cannot stop multiple audio decoder %lx, err=%d\n", pContext->id, err);
					return err;
				}
			}
		}
	}

	if ((pContext->monitor) || FORCE_MONITOR) {
		RMDBGLOG((ENABLE, "FIFO STATUS after stop\n"));
		monitor(pContext, TRUE); 
		RMDBGLOG((ENABLE, "***********************\n"));
	}


	return err;

}

static RMstatus Play(struct context_per_task *pContext, RMuint32 devices, enum DCCVideoPlayCommand mode)
{
	RMstatus err = RM_OK;

	if ((pContext->monitor) || FORCE_MONITOR) {
		RMDBGLOG((ENABLE, "FIFO STATUS before play\n"));
		monitor(pContext, TRUE); 
		RMDBGLOG((ENABLE, "***********************\n"));
	}


	if (devices & RM_DEVICES_PSFDEMUX) {
		RMDBGLOG((ENABLE, "PLAY: psfdemux\n"));
		
		err = DCCPlayDemuxTask(pContext->dcc_info->pDemuxTask);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot play demux %lx, err=%d\n", pContext->id, err);
			return err;
		}
	}

	if (devices & RM_DEVICES_VIDEO) {
		if ((pContext->sendVideoData) && (pContext->dcc_info->pVideoSource)) {
			RMDBGLOG((ENABLE, "PLAY: video decoder\n"));
			
			err = DCCPlayVideoSource(pContext->dcc_info->pVideoSource, mode);
			if (RMFAILED(err)) {
				fprintf(stderr, "Cannot play video decoder %lx, err=%d\n", pContext->id, err);
				return err;
			}
		}
	}

	if (devices & RM_DEVICES_AUDIO) {
		if (pContext->sendAudioData) {
			if (pContext->dcc_info->pMultipleAudioSource) {
				RMDBGLOG((ENABLE, "PLAY: multiple audio decoder\n"));
				
				err = DCCPlayMultipleAudioSource(pContext->dcc_info->pMultipleAudioSource);
				if (RMFAILED(err)){
					fprintf(stderr, "Cannot play multiple audio decoder %lx, err=%d\n", pContext->id, err);
					return err;
				}
			}
		}
	}

	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "PLAY: stc\n"));
		DCCSTCPlay(pContext->dcc_info->pStcSource);
	}


	return err;

}


static RMstatus Pause(struct context_per_task *pContext, RMuint32 devices)
{

	RMstatus err = RM_OK;
	
	if (devices & RM_DEVICES_PSFDEMUX) {
		RMDBGLOG((ENABLE, "PAUSE: psfdemux\n"));
		
		err = DCCPauseDemuxTask(pContext->dcc_info->pDemuxTask);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot pause demux %lx, err=%d\n", pContext->id, err);
			return err;
		}
	}

	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "PAUSE: stc\n"));
		DCCSTCStop(pContext->dcc_info->pStcSource);
	}



	if (devices & RM_DEVICES_VIDEO) {
		if ((pContext->sendVideoData) && (pContext->dcc_info->pVideoSource)) {
			RMDBGLOG((ENABLE, "PAUSE: video decoder\n"));

			err = DCCPauseVideoSource(pContext->dcc_info->pVideoSource);
			if (RMFAILED(err)) {
				fprintf(stderr, "Cannot pause video decoder %lx, err=%d\n", pContext->id, err);
				return err;
			}
		}
	}

	if (devices & RM_DEVICES_AUDIO) {
		if (pContext->sendAudioData) {
			if (pContext->dcc_info->pMultipleAudioSource) {
				RMDBGLOG((ENABLE, "PAUSE: multiple audio decoder\n"));
				
				err = DCCPauseMultipleAudioSource(pContext->dcc_info->pMultipleAudioSource);
				if (RMFAILED(err)) {
					fprintf(stderr, "Cannot pause multiple audio decoder %lx, err=%d\n", pContext->id, err);
					return err;
				}
			}
		}
	}


	return err;

}

static RMstatus SendInbandCommands(struct context_per_task *context)
{
	RMstatus err = RM_OK;
	
	/* ############## AES_CBC_PRECIPHER TEST CODE BEGIN ############## */
	if(context->test_aes_precipher == TRUE)
	{
		struct aes_2keys_test *key_table;

		key_table  = ((struct aes_2keys_test *)context->pkey_table);
	        if(context->file_byte_counter == (aes_state*key_table->key_byte_counter))
		{
			err = AESKeyPrecipherInband(context->pRUA,context->demux_task,
						    key_table->scrambling,
						    (aes_state&1)?key_table->key1:key_table->key0, (aes_state&1)?key_table->iv1: key_table->iv0, context->key_size,aes_state);
			if (RMFAILED(err)) 
			{
				fprintf (stderr, "aes precipher key inband failure\n");
				return RM_ERROR; 
			}
			aes_state++;
		}
		return err;
	} 
	/* ############## AES_CBC_PRECIPHER TEST CODE END ############### */

	switch (context->app_type) {
		case  dvbcsa_decryption: {
			RMuint32 index;
			struct dvb_csa_key *key_table;

			for (index = 0; index < context->key_table_size; index++) {
				key_table = ((struct dvb_csa_key *)context->pkey_table) + index;
				if ((key_table->renew) && (context->file_byte_counter >= key_table->key_byte_counter)) {
					fprintf (stderr, "dvb key inband at file_byte_counter=%lx position=%lu entry=%u\n",
						context->file_byte_counter, index, key_table->ecm_entry);
					if (1) {
						err = DvbKeyInband(context, key_table->ecm_entry, key_table->scrambling, key_table->key, context->key_size);
					}
					else if (0) {
						err = DvbKeyOutband(context, key_table->ecm_entry, key_table->scrambling, key_table->key, context->key_size);
					}
					else if (0) {
						err = DvbKeyXtask(context, key_table->ecm_entry, key_table->scrambling, key_table->key);
					}
#if 0
					else {
						err = DvbKeyXtaskEncrypted(context, key_table->scrambling, key_table->key);
					}
#endif

					if (RMFAILED(err)) {
						fprintf (stderr, "dvb key inband failure\n");
						return RM_ERROR;
						}
		 			key_table->renew = FALSE; 
				}
			}
		}
		break;

		case multi2_decryption: 
		{
			RMuint32 i;
			for(i=0; i<context->cipher_count; i++) {
				if (context->arib_key_table[i*2].new_key) {
					Multi2KeySetup(context, XTASK_CIPHER, i*2, EVEN_KEY);
					context->arib_key_table[i*2].new_key = FALSE;
				}
				if (context->arib_key_table[i*2+1].new_key) {
					Multi2KeySetup(context, XTASK_CIPHER, i*2+1, ODD_KEY);
					context->arib_key_table[i*2+1].new_key = FALSE;
				}
			}
		}
		break;

		case aes_cbc_decryption:
		case aes_ecb_decryption:
		{
			RMuint32 index;
			struct aes_key *key_table;

			for (index = 0; index < context->key_table_size; index++) {
				key_table = ((struct aes_key *)context->pkey_table) + index;

				if ((key_table->renew) && (context->file_byte_counter >= key_table->key_byte_counter)) {
					fprintf (stderr, "AES key setup at file_byte_counter=%lx position=%lu entry=%u\n",
						context->file_byte_counter, index, key_table->ecm_entry);
					if (1) {
						//fprintf(stderr, "AES Inband key setup at bc=%lx position=%lu entry=%u\n",context->file_byte_counter, index, key_table->ecm_entry);
						err = AESKeyInband(context, key_table->ecm_entry, key_table->scrambling, key_table->key, key_table->iv, context->key_size);
					}
					else if (0) {
						err = AESKeyOutband(context, key_table->ecm_entry, key_table->scrambling, key_table->key, key_table->iv, context->key_size);
					}
					if (RMFAILED(err)) {
						fprintf (stderr, "aes key inband failure\n");
						return RM_ERROR;
					}
				 key_table->renew = FALSE; 
				}
			}
		}
		break;

		case  aes_ofb_decryption:  // test case just get the next key from the key table
		{
			RMuint32 index;
			for (index = 0; index < context->key_table_size; index++) {
				struct aes_key *key_table = ((struct aes_key *)context->pkey_table) + index;
				RMint32 file_byte_counter_offset = 0;
#ifdef AES_KEY_1017
				file_byte_counter_offset = 6249121 + 249121;
#endif
#if defined(AES_KEY_SCR1111) || defined (AES_KEY_SCR1112)
				file_byte_counter_offset = -6249121;
#endif
				if(RMFAILED(err)) {
					fprintf(stderr, "update time failed \n");
					return RM_ERROR;
				}
				//fprintf(stderr, "update time to load key %llu\n", time );
				if( key_table->renew && (key_table->key_byte_counter ==0 || context->file_byte_counter >= key_table->key_byte_counter + file_byte_counter_offset )) {
					if(1) {
						fprintf(stderr, "AES Inband key setup at bc=%lx position=%lu entry=%u\n",context->file_byte_counter, index, key_table->ecm_entry);
						err = AESKeyInband(context, key_table->ecm_entry, key_table->scrambling, key_table->key, key_table->iv, context->key_size);
					}
					else {
						//fprintf(stderr, "AES Outband key setup at bc=%lx time=%llu position=%lu entry=%u\n",context->file_byte_counter, time/1000, index, key_table->ecm_entry);
						err = AESKeyOutband(context, key_table->ecm_entry, key_table->scrambling, key_table->key, key_table->iv, context->key_size);
					}
					if(RMFAILED(err)) {
						fprintf(stderr, "aes key failure\n");
						return RM_ERROR;
					}
					key_table->renew = FALSE; 
					break;
				}
			}
		}
		break;

		default: {
#ifdef TEST_CUSTOM_INBAND
			/* table of demux byte counters corresponding to start of video frames (0x000001b3) */
			RMuint32 byte_cnt_nav1slds_dvd[] = {0, 0x64021-0x121, 0xca021-0x121, 0x134021-0x121, 0x19b021-0x121}; /* nav1slds.vob = 5 slides */
			RMuint32 byte_cnt_01301_m2t[] = {0x310-0x110, 0x31d50-0x150, 0x65710-0x110, 0x98e90-0x190}; /* 01301.m2ts = 4 slides */
			RMuint32 byte_cnt_nav1slds_twice[] = {0x1fc800-0x400}; /* 1 pts offset for nav1slds_twice.vob */
			RMuint32 byte_cnt_01301_twice[] = {0xc6000-0}; /* 1 pts offset for 01301_twice.m2ts */

			static RMuint32 state = 0; /* state machine to be used for special inband commands */
			RMuint32 test_id = 1; /* 0= user inbands, 1= pts offset, 2= aspect ratio + scaling */
		
			RMuint32 *byte_cnt; /* pointer to the list of byte_counters used for inband commands */
			RMuint32 ibc_cnt; /* number of inaband commands to send */
			struct InbandCommandX_type ibcx;
		
			if (context->app_type == program_stream_parsing) {
				byte_cnt = byte_cnt_nav1slds_dvd;
				ibc_cnt = sizeof(byte_cnt_nav1slds_dvd)/sizeof(RMuint32);
			}
			else {
				byte_cnt = byte_cnt_01301_m2t;
				ibc_cnt = sizeof(byte_cnt_01301_m2t)/sizeof(RMuint32);
			}
		
			if (test_id == 1) {
				if (context->app_type == program_stream_parsing) {
					/* test for pts_offset for nav1slds_twice.vob */
					byte_cnt = byte_cnt_nav1slds_twice;
					ibc_cnt = sizeof(byte_cnt_nav1slds_twice)/sizeof(RMuint32);
				}
				else {
					/* test for pts_offset for 01301_twice.m2ts */
					byte_cnt = byte_cnt_01301_twice;
					ibc_cnt = sizeof(byte_cnt_01301_twice)/sizeof(RMuint32);
				}
			}

			/* send the inband command 1 buffer before the required bytecounter, For fine tuning
			   make sure you use EMhwlibInbandOffset_Absolute */
			if (  byte_cnt[state] && ((context->file_byte_counter + (1<<context->play_opt->dmapool_log2size)) < byte_cnt[state]) )
				return RM_OK;

			if ( state >= ibc_cnt )
				return RM_OK;
		
			if (test_id == 0) {
				/* test user inbands - note that I use EMhwlibInbandOffset_Ignore and the inband will be posted
				   at the offset of the buffer containing the byte_counter from the table !*/
				ibcx.flags_tag = INBAND_COMMAND_TAG_USER0 | INBAND_COMMAND_CONSUMED_BY_USER;
				ibcx.offset_value = 0; /* ignored */
				if (context->app_type == program_stream_parsing)
					ibcx.output_mask = 3; /* video is demux output 0, audio is demux output 1 */
				else
					ibcx.output_mask = 0xc; /* video is demux output 2, audio is demux output 3 */
				ibcx.offset_control = EMhwlibInbandOffset_Ignore;
				err = RUASetProperty(context->pRUA, context->demux_task, RMGenericPropertyID_InbandCommandX,	&ibcx, sizeof(ibcx), 0);
				if ( RMSUCCEEDED(err) ) {
					fprintf (stderr, "\n ---- CustomInband at file_byte_counter=0x%lx ---- \n",
						context->file_byte_counter);
					state++;
				}
				return err;
			}
			else if (test_id == 1) {
				/* test pts offset */
				ibcx.flags_tag = INBAND_COMMAND_TAG_PTS_OFFSET;
				ibcx.offset_value = byte_cnt[state]; /* ignored */
				ibcx.output_mask = 0; /* no need to propagate it to the outputs */
				ibcx.offset_control = EMhwlibInbandOffset_Absolute;
				
				/* increase offset for every inband */
				ibcx.params.pts_offset_params.pts_offset = 5*state*90000;
				ibcx.params.pts_offset_params.time_resolution = 90000;

				if (context->app_type == program_stream_parsing) {
					/* constant offset for nav1slds_twice.vob */
					ibcx.params.pts_offset_params.pts_offset = 0x112eed*2;
				}
				else {
					/* constant offset for 01301_twice.m2ts */
					ibcx.params.pts_offset_params.pts_offset = 0xdbf24*2;
				}
				
				err = RUASetProperty(context->pRUA, context->demux_task, RMGenericPropertyID_InbandCommandX, &ibcx, sizeof(ibcx), 0);
				if ( RMSUCCEEDED(err) ) {
					fprintf (stderr, "\n ---- PtsOffset=0x%llx at absolute byte_counter=0x%lx file_byte_counter=0x%lx ---- \n",
						ibcx.params.pts_offset_params.pts_offset, byte_cnt[state], context->file_byte_counter);
					state++;
				}
				return err;
			}
			else if (test_id == 2) {
				/* test aspect ratio and scaling */
				struct TestAspectRatio {
					RMuint32 X;
					RMuint32 Y;
					RMuint32 ScalingMode;
					RMascii msg[30];
				};
				struct TestAspectRatio TAR[10] = {
					{ 16, 9, EMhwlibScalingMode_LetterBox, "16_9 -> 4_3 letterbox"},
					{ 16, 9, EMhwlibScalingMode_PanScan,   "16_9 -> 4_3 panscan"},
					{  4, 3, EMhwlibScalingMode_LetterBox, "4_3 -> 4_3"},
					{ 16, 9, EMhwlibScalingMode_LetterBox, "16_9 -> 4_3 letterbox"},
					{ 16, 9, EMhwlibScalingMode_PanScan,   "16_9 -> 4_3 panscan"},
					{  4, 3, EMhwlibScalingMode_LetterBox, "4_3 -> 4_3"},
				};

				ibcx.flags_tag = INBAND_COMMAND_TAG_ASPECT_RATIO;
				ibcx.offset_value = byte_cnt[state];
				if (context->app_type == program_stream_parsing)
					ibcx.output_mask = 1<<0; /* video is on demux output 0 */
				else
					ibcx.output_mask = 1<<2; /* video is on demux output 2 */
				ibcx.offset_control = EMhwlibInbandOffset_Absolute;
				
				ibcx.params.aspect_ratio_params.type = EMhwlibAspectRatio_Display;
				ibcx.params.aspect_ratio_params.ar.X = TAR[state].X;
				ibcx.params.aspect_ratio_params.ar.Y = TAR[state].Y;
				err = RUASetProperty(context->pRUA, context->demux_task, RMGenericPropertyID_InbandCommandX,
					&ibcx, sizeof(ibcx), 0);
				
				if ( RMSUCCEEDED(err) ) {
					ibcx.flags_tag = INBAND_COMMAND_TAG_SCALING_MODE;
					ibcx.params.scaling_params = TAR[state].ScalingMode;
					err = RUASetProperty(context->pRUA, context->demux_task, RMGenericPropertyID_InbandCommandX,
						&ibcx, sizeof(ibcx), 0);
					if ( RMSUCCEEDED(err) ) {
						fprintf (stderr, " ---- %s at absolute byte_counter=0x%lx file_byte_counter=0x%lx ----\n",
							TAR[state].msg, byte_cnt[state], context->file_byte_counter);
						state++;
					}
				}
				return err;
			}
			else if (test_id == 3) {
				/* test for BluRay AACS files */
				ibcx.flags_tag = INBAND_COMMAND_TAG_DUMMY | INBAND_COMMAND_ACTION_OUTPUT_STOP;
				ibcx.offset_value = 0;
				ibcx.output_mask = 0; /* no need to propagate it to the outputs */
				ibcx.offset_control = EMhwlibInbandOffset_Absolute;
				err = RUASetProperty(context->pRUA, context->demux_task, RMGenericPropertyID_InbandCommandX, &ibcx, sizeof(ibcx), 0);

				ibcx.flags_tag = INBAND_COMMAND_TAG_DUMMY;
				ibcx.offset_value = 0x12c0;
				ibcx.output_mask = 0; /* no need to propagate it to the outputs */
				ibcx.offset_control = EMhwlibInbandOffset_Absolute;
				err = RUASetProperty(context->pRUA, context->demux_task, RMGenericPropertyID_InbandCommandX, &ibcx, sizeof(ibcx), 0);

				state++;

				return err;
			}
#endif // TEST_CUSTOM_INBAND
		}
		break;
	}
	return err;
}

static RMstatus ProcessKey(void)
{
	RMstatus err = RM_OK;
	RMuint32 current_task, i, j;
	static struct RM_PSM_Actions actions;
	enum RM_PSM_State PlaybackState;

	current_task = PSMcontext.currentActivePSMContext;
	
	err = process_command(&PSMcontext, pdcc_info, &actions);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error while processing key %d\n", err);
		return err;
	}


	PlaybackState = RM_PSM_GetState(&PSMcontext, pdcc_info);

	// check ToDoActions
	if (actions.toDoActions & RM_PSM_FLUSH_VIDEO) {
		RMDBGLOG((ENABLE, "flushVIDEO\n"));

		Pause(&Tasks[current_task], RM_DEVICES_PSFDEMUX);
		Stop(&Tasks[current_task], RM_DEVICES_VIDEO);
		Play(&Tasks[current_task], RM_DEVICES_PSFDEMUX, 0);

		actions.toDoActions &= ~RM_PSM_FLUSH_VIDEO;
	}
	if (actions.toDoActions & RM_PSM_FIRST_PTS) {
		RMDBGLOG((ENABLE, "firstPTS\n"));
		if (!Tasks[current_task].play_opt->send_video_pts && !Tasks[current_task].play_opt->send_audio_pts && !Tasks[current_task].play_opt->send_spu_pts) {
			fprintf(stderr, "%lx_DCCSTCSetTime 0\n", current_task);
			DCCSTCSetTime(Tasks[current_task].dcc_info->pStcSource, 0, 45000);
		}
	}
	if (actions.toDoActions & RM_PSM_DEMUX_IFRAME) {
		RMDBGLOG((ENABLE, "demuxIFrame\n"));
		RMDBGLOG((ENABLE, "trick mode iframe\n"));

		for (i = 0; i < Tasks[current_task].audioInstances; i++) {
			struct EMhwlibOutputMask_type discmd;

			/* announce demux to disable and flush the context audio output */
			discmd.output_mask[0] = (1<<Tasks[current_task].audioDemuxOutputIndex[i]);
			err = send_disable_output_demux_command (Tasks[current_task].pRUA, Tasks[current_task].demux_task, &discmd);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "%ld_trick mode iframe send_disable_output_demux_command Error\n", Tasks[current_task].id));
			}
		}

		/* audio decoder stop flushes the demux output - no need to call RMDemuxOutputPropertyID_Flush */
		err = Stop(&Tasks[current_task], RM_DEVICES_AUDIO);

		err = Play(&Tasks[current_task], RM_DEVICES_VIDEO, DCCVideoPlayIFrame);

		Tasks[current_task].isIFrameMode = TRUE;
		actions.toDoActions &= ~RM_PSM_DEMUX_IFRAME;
	}
	if (actions.toDoActions & RM_PSM_RESYNC_TIMER) {
		RMDBGLOG((ENABLE, "resyncTimer\n"));
		
		if (Tasks[current_task].dcc_info->SurfaceID != 0) {
			RMuint64 stc;
			
			err = RUAGetProperty(Tasks[current_task].pRUA, Tasks[current_task].dcc_info->SurfaceID, RMGenericPropertyID_CurrentDisplayPTS, &stc, sizeof(stc));
			if (err == RM_OK) {
				RMDBGLOG((ENABLE, "set timer to %llu (0x09%llx) = %llu sec\n",
					  stc,
					  stc,
					  stc / 45000));
				DCCSTCSetTime(Tasks[current_task].dcc_info->pStcSource, stc, 45000);
			}
		}

		actions.toDoActions &= ~RM_PSM_RESYNC_TIMER;
	}
	if (actions.toDoActions & RM_PSM_DEMUX_NORMAL) {
		RMuint32 demux_output;
		RMuint32 dummy;

		RMDBGLOG((ENABLE, "demuxNormal\n"));
		RMDBGLOG((ENABLE, ">> resume from iframe\n"));


		if (Tasks[current_task].play_opt->send_audio) {
			RMDBGLOG((ENABLE, "reenable audio\n"));
			for (i = 0; i < Tasks[current_task].audioInstances; i++) {
				demux_output = EMHWLIB_MODULE(DemuxOutput, Tasks[current_task].audioDemuxOutputIndex[i] + output_count_per_task * Tasks[current_task].id);
				
				err = RUASetProperty(Tasks[current_task].pRUA, demux_output, RMDemuxOutputPropertyID_Enable, &dummy, sizeof(dummy), 0);
				if( RMFAILED(err) ) {
					fprintf(stderr, "couldnt enable audio output");
				}
			}
		}


		if ((Tasks[current_task].play_opt->fast_audio_recovery) && (Tasks[current_task].play_opt->duration)) {
			// seek to restore audio faster
			if (Tasks[current_task].dcc_info->SurfaceID != 0) {
				RMuint64 stc;
				
				err = RUAGetProperty(Tasks[current_task].pRUA, Tasks[current_task].dcc_info->SurfaceID, RMGenericPropertyID_CurrentDisplayPTS, &stc, sizeof(stc));
				if (err == RM_OK) {
					RMint64 seek_pos;
					
					stc /= 45000;

					if (Tasks[current_task].video_opt) {
						RMDBGLOG((ENABLE, "adjust seek time (%llu) to", stc));
						stc -= Tasks[current_task].video_opt->first_pts_in_stream / 1000;
						RMDBGPRINT((ENABLE, " %llu because first_pts_in_stream=%llu\n", stc, Tasks[current_task].video_opt->first_pts_in_stream));
					}

					RMDBGLOG((ENABLE, "seeking to %lu to restore audio faster\n", stc));
					seek_pos = (stc * Tasks[current_task].fileSize * 1000) / (Tasks[current_task].play_opt->duration); 
					if (seek_pos > (RMint64)Tasks[current_task].fileSize) {
						RMDBGLOG((ENABLE, "seekpos(%lld) > fileSize(%llu), seek to 0\n", seek_pos, Tasks[current_task].fileSize));
						if (RMSeekFile(Tasks[current_task].file, 0, RM_FILE_SEEK_START) != RM_OK) { 
							RMDBGLOG((ENABLE, "Error: seeking file to zero\n")); 
						}
					}
					else {
						RMDBGLOG((ENABLE, "seeking to %lu s, pos %llu\n", stc, seek_pos)); 
						
						if (RMSeekFile(Tasks[current_task].file, seek_pos, RM_FILE_SEEK_START) != RM_OK) { 
							RMDBGLOG((ENABLE, "Error: seeking file to position %lu s, %lld kB\n",
								  Tasks[current_task].dcc_info->seek_time, seek_pos/1024)); 
							err = RM_ERROR;
						}
					}
					
					err = Stop(&Tasks[current_task], RM_DEVICES_ALL);
					err = Play(&Tasks[current_task], RM_DEVICES_ALL, DCCVideoPlayFwd);
				}
			}
		}
		else {
			err = Stop(&Tasks[current_task], RM_DEVICES_ALL);
			
			err = Play(&Tasks[current_task], RM_DEVICES_ALL, DCCVideoPlayFwd);
		}


		actions.toDoActions &= ~RM_PSM_DEMUX_NORMAL;
		Tasks[current_task].isIFrameMode = FALSE;
	}

	
	// check PerformedActions
	if (actions.performedActions & RM_PSM_VIDEO_STOPPED) {
		RMDBGLOG((ENABLE, "video stopped\n"));
		actions.performedActions &= ~RM_PSM_VIDEO_STOPPED;
	}
	if (actions.performedActions & RM_PSM_AUDIO_STOPPED) {
		RMDBGLOG((ENABLE, "audio stopped\n"));
		actions.performedActions &= ~RM_PSM_AUDIO_STOPPED;
	}

	// check PlaybackState
	if (((PlaybackState == RM_PSM_Slow) || (PlaybackState == RM_PSM_Fast) || (PlaybackState == RM_PSM_NextPic)) &&
	    (actions.cmdProcessed) && 
	    (!Tasks[current_task].isTrickMode)) {
		RMDBGLOG((ENABLE, ">> trick mode all frames (task %lu)\n", current_task));

		for (i = 0; i < Tasks[current_task].audioInstances; i++) {
			struct EMhwlibOutputMask_type discmd;

			/* announce demux to disable and flush the context audio output */
			discmd.output_mask[0] = (1<<Tasks[current_task].audioDemuxOutputIndex[i]);
			err = send_disable_output_demux_command (Tasks[current_task].pRUA, Tasks[current_task].demux_task, &discmd);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "%ld_trick mode all frames send_disable_output_demux_command Error\n", Tasks[current_task].id));
			}
		}


		/* audio decoder stop flushes the demux output - no need to call RMDemuxOutputPropertyID_Flush */
		err = Stop(&Tasks[current_task], RM_DEVICES_AUDIO);

		Tasks[current_task].isTrickMode = TRUE;

	}

	if ((PlaybackState == RM_PSM_Rewind) && (!Tasks[current_task].isRewinding)) {
		RMDBGLOG((ENABLE, ">> blind rewind\n"));

		for(i = 0; i < task_count; i++){
			if ( (current_task == i+1) || (current_task == 0) ) {
				Stop(&Tasks[i], RM_DEVICES_ALL);
			}
		}

		err = Play(&Tasks[current_task], RM_DEVICES_STC, 0);
		Tasks[current_task].isRewinding = TRUE;
		Tasks[current_task].FirstSystemTime = TRUE;
		Tasks[current_task].isIFrameMode = FALSE;
		Tasks[current_task].isTrickMode = FALSE;

	}

	if ((PlaybackState == RM_PSM_Playing) &&
	    (Tasks[current_task].isTrickMode) &&
	    (actions.cmdProcessed)) {
		RMuint32 demux_output;
		RMuint32 dummy;

		RMDBGLOG((ENABLE, ">> resume from trickmode\n"));

		if (Tasks[current_task].play_opt->send_audio) {
			RMDBGLOG((ENABLE, "reenable audio\n"));

			for (i = 0; i < Tasks[current_task].audioInstances; i++) {
				demux_output = EMHWLIB_MODULE(DemuxOutput, Tasks[current_task].audioDemuxOutputIndex[i] + output_count_per_task * Tasks[current_task].id);
				
				err = RUASetProperty(Tasks[current_task].pRUA, demux_output, RMDemuxOutputPropertyID_Enable, &dummy, sizeof(dummy), 0);
				if( RMFAILED(err) ) {
					fprintf(stderr, "couldnt enable audio output");
				}
			}
		}

		if (Tasks[current_task].play_opt->fast_audio_recovery && Tasks[current_task].play_opt->duration) {
			// seek to restore audio faster
			if (Tasks[current_task].dcc_info->SurfaceID != 0) {
				RMuint64 stc;
				
				err = RUAGetProperty(Tasks[current_task].pRUA, Tasks[current_task].dcc_info->SurfaceID, RMGenericPropertyID_CurrentDisplayPTS, &stc, sizeof(stc));
				if (err == RM_OK) {
					RMint64 seek_pos;
					
					stc /= 45000;

					if (Tasks[current_task].video_opt) {
						RMDBGLOG((ENABLE, "adjust seek time (%llu) to", stc));
						stc -= (Tasks[current_task].video_opt->first_pts_in_stream / 1000);
						RMDBGPRINT((ENABLE, " %llu because first_pts_in_stream=%llu\n", stc, Tasks[current_task].video_opt->first_pts_in_stream));
					}

					RMDBGLOG((ENABLE, "seeking to %lu to restore audio faster\n", stc));
					seek_pos = (stc * Tasks[current_task].fileSize * 1000) / (Tasks[current_task].play_opt->duration); 
					if (seek_pos > (RMint64)Tasks[current_task].fileSize) {
						RMDBGLOG((ENABLE, "seekpos(%lld) > fileSize(%llu), seek to 0\n", seek_pos, Tasks[current_task].fileSize));
						if (RMSeekFile(Tasks[current_task].file, 0, RM_FILE_SEEK_START) != RM_OK) { 
							RMDBGLOG((ENABLE, "Error: seeking file to zero\n")); 
						}
					}
					else {
						RMDBGLOG((ENABLE, "seeking to %lu s, pos %lld\n", stc, seek_pos)); 
						
						if (RMSeekFile(Tasks[current_task].file, seek_pos, RM_FILE_SEEK_START) != RM_OK) { 
							RMDBGLOG((ENABLE, "Error: seeking file to position %lu s, %lld kB\n",
								  Tasks[current_task].dcc_info->seek_time, seek_pos/1024)); 
							err = RM_ERROR;
						}
					}
					
					err = Stop(&Tasks[current_task], RM_DEVICES_ALL);
					err = Play(&Tasks[current_task], RM_DEVICES_ALL, DCCVideoPlayFwd);
				}
			}
		}

		
		err = Play(&Tasks[current_task], RM_DEVICES_AUDIO, 0);

		Tasks[current_task].isTrickMode = FALSE;
	}


	if ((PlaybackState == RM_PSM_Playing) &&
	    (Tasks[current_task].isRewinding) &&
	    (actions.cmdProcessed) &&
	    (Tasks[current_task].play_opt->duration)) {
		RMint64 currentTime;
		RMuint64 stc;
		RMint64 seek_pos;

			
		DCCSTCGetTime(Tasks[current_task].dcc_info->pStcSource, &stc, 1000);
		
		currentTime = (RMuint64)stc - Tasks[current_task].video_opt->first_pts_in_stream;

		RMDBGLOG((ENABLE, "stc %llu first_pts %llu, diff %llu\n", stc, Tasks[current_task].video_opt->first_pts_in_stream, currentTime));

		RMDBGLOG((ENABLE, ">> resume from rewind at %llu\n", currentTime));
		
		
		currentTime /= 1000;
		RMDBGLOG((ENABLE, "seeking to %lu to resume from rewind\n", currentTime));
		seek_pos = (currentTime * Tasks[current_task].fileSize * 1000) / (Tasks[current_task].play_opt->duration); 
		if (seek_pos > (RMint64)Tasks[current_task].fileSize) {
			RMDBGLOG((ENABLE, "seekpos(%lld) > fileSize(%llu), seek to 0\n", seek_pos, Tasks[current_task].fileSize));
			if (RMSeekFile(Tasks[current_task].file, 0, RM_FILE_SEEK_START) != RM_OK) { 
				RMDBGLOG((ENABLE, "Error: seeking file to zero\n")); 
			}
		}
		else {
			RMDBGLOG((ENABLE, "seeking to %lu s, pos %llu\n", currentTime, seek_pos)); 
			
			if (RMSeekFile(Tasks[current_task].file, seek_pos, RM_FILE_SEEK_START) != RM_OK) { 
				RMDBGLOG((ENABLE, "Error: seeking file to position %lu s, %lld kB\n",
					  Tasks[current_task].dcc_info->seek_time, seek_pos/1024)); 
				err = RM_ERROR;
			}
		}
		
		err = Stop(&Tasks[current_task], RM_DEVICES_ALL);
		err = Play(&Tasks[current_task], RM_DEVICES_ALL, DCCVideoPlayFwd);
		
		Tasks[current_task].isRewinding = FALSE;
	}


	// check Command

	if ((actions.cmd == RM_QUIT) && (!actions.cmdProcessed)) {
		RMDBGLOG((ENABLE, "quit\n"));
		actions.cmdProcessed = TRUE;

		for(i = 0; i < task_count; i++){
			if(current_task == i+1 || current_task == 0){
				if(Tasks[i].buf){
					RUAReleaseBuffer(Tasks[i].pDma, Tasks[i].buf);
					Tasks[i].buf = NULL;
				}
			}
		}
		return RM_ERROR;

	}

	if ((actions.cmd == RM_STOP) && (actions.cmdProcessed)) {
		RMuint32 demux_output;
		RMuint32 dummy;

		RMDBGLOG((ENABLE, "Got stop command\n"));
		Tasks[current_task].FirstSystemTime = TRUE;

		for(i = 0; i < task_count; i++){
			if ( (current_task == i+1) || (current_task == 0) ) {
				Stop(&Tasks[i], RM_DEVICES_ALL);
			}
		}

		if (((Tasks[current_task].isIFrameMode) || (Tasks[current_task].isTrickMode)) && (Tasks[current_task].play_opt->send_audio))  {
			RMDBGLOG((ENABLE, ">> reenable audio output\n"));
			
			for (i = 0; i < Tasks[current_task].audioInstances; i++) {
				demux_output = EMHWLIB_MODULE(DemuxOutput, Tasks[current_task].audioDemuxOutputIndex[i] + output_count_per_task * Tasks[current_task].id);
				
				err = RUASetProperty(Tasks[current_task].pRUA, demux_output, RMDemuxOutputPropertyID_Enable, &dummy, sizeof(dummy), 0);
				if( RMFAILED(err) ) {
					fprintf(stderr, "couldnt enable audio output");
				}
			}
		}

		Tasks[current_task].isIFrameMode = FALSE;
		Tasks[current_task].isTrickMode = FALSE;
	}
	if ((actions.cmd == RM_STOP_SEEK_ZERO) && (!actions.cmdProcessed)) {
		RMDBGLOG((ENABLE, "Got stop seek zero command\n"));
		RM_PSM_SetState(&PSMcontext, pdcc_info, RM_PSM_Stopped);
		Tasks[current_task].FirstSystemTime = TRUE;
		actions.cmdProcessed = TRUE;

		for(i = 0; i < task_count; i++){
			if ( (current_task == i+1) || (current_task == 0) ) {
				Stop(&Tasks[i], RM_DEVICES_ALL);
				RMDBGLOG((ENABLE, "seek to zero\n"));
				if (RMSeekFile(Tasks[i].file, 0, RM_FILE_SEEK_START) != RM_OK) { 
					RMDBGLOG((ENABLE, "Error: seeking file to zero\n")); 
				}
			}
		}

		if (((Tasks[current_task].isTrickMode) || (Tasks[current_task].isIFrameMode)) && (Tasks[current_task].play_opt->send_audio)) {
			RMuint32 demux_output;
			RMuint32 dummy;

			RMDBGLOG((ENABLE, ">> reenable audio output\n"));
			for (i = 0; i < Tasks[current_task].audioInstances; i++) {
				demux_output = EMHWLIB_MODULE(DemuxOutput, Tasks[current_task].audioDemuxOutputIndex[i] + output_count_per_task * Tasks[current_task].id);
				
				err = RUASetProperty(Tasks[current_task].pRUA, demux_output, RMDemuxOutputPropertyID_Enable, &dummy, sizeof(dummy), 0);
				if( RMFAILED(err) ) {
					fprintf(stderr, "couldnt enable audio output");
				}
			}
		}

		Tasks[current_task].isTrickMode = FALSE;
		Tasks[current_task].isIFrameMode = FALSE;

	}
	if ((actions.cmd == RM_SEEK) && (!actions.cmdProcessed) && (Tasks[current_task].play_opt->duration)) {
		RMint64 seek_pos;

		RMDBGLOG((ENABLE, "got seek command\n"));

		if (((Tasks[current_task].isTrickMode) || (Tasks[current_task].isIFrameMode)) && (Tasks[current_task].play_opt->send_audio)) {
			RMuint32 demux_output;
			RMuint32 dummy;

			RMDBGLOG((ENABLE, ">> reenable audio output\n"));
			for (i = 0; i < Tasks[current_task].audioInstances; i++) {
				demux_output = EMHWLIB_MODULE(DemuxOutput, Tasks[current_task].audioDemuxOutputIndex[i] + output_count_per_task * Tasks[current_task].id);
				
				err = RUASetProperty(Tasks[current_task].pRUA, demux_output, RMDemuxOutputPropertyID_Enable, &dummy, sizeof(dummy), 0);
				if( RMFAILED(err) ) {
					fprintf(stderr, "couldnt enable audio output");
				}
			}
		}

		Tasks[current_task].isTrickMode = FALSE;
		Tasks[current_task].isIFrameMode = FALSE;
		RM_PSM_SetState(&PSMcontext, pdcc_info, RM_PSM_Playing);

		
		seek_pos = (Tasks[current_task].dcc_info->seek_time * Tasks[current_task].fileSize * 1000) / (Tasks[current_task].play_opt->duration); 
		if (seek_pos > (RMint64)Tasks[current_task].fileSize) {
			RMDBGLOG((ENABLE, "seekpos(%lld) > fileSize(%llu), seek to 0\n", seek_pos, Tasks[current_task].fileSize));
			if (RMSeekFile(Tasks[current_task].file, 0, RM_FILE_SEEK_START) != RM_OK) { 
				RMDBGLOG((ENABLE, "Error: seeking file to zero\n")); 
			}
		}
		else {
			RMDBGLOG((ENABLE, "seeking to %lu s, pos %llu\n", Tasks[current_task].dcc_info->seek_time, seek_pos)); 
			
			if (RMSeekFile(Tasks[current_task].file, seek_pos, RM_FILE_SEEK_START) != RM_OK) { 
				RMDBGLOG((ENABLE, "Error: seeking file to position %lu s, %lld kB\n", Tasks[current_task].dcc_info->seek_time, seek_pos/1024)); 
				err = RM_ERROR;
			}
		}
		
		err = Stop(&Tasks[current_task], RM_DEVICES_ALL);

		DCCSTCSetSpeed(Tasks[current_task].dcc_info->pStcSource, Tasks[current_task].play_opt->speed_N, Tasks[current_task].play_opt->speed_M);

		err = Play(&Tasks[current_task], RM_DEVICES_ALL, DCCVideoPlayFwd);


	}
	if ((!actions.cmdProcessed) &&
	    ((actions.cmd == KEY_CMD_PAT_INFO) ||
	     (actions.cmd == KEY_CMD_SWITCH_SPI_FILE) ||
	     (actions.cmd == KEY_CMD_CHANGE_PMT) ||
	     (actions.cmd == KEY_CMD_CHANGE_VIDEO) ||
	     (actions.cmd == RM_AUDIO_STREAM_CHANGE))) {
		// check PSFDEMUX commands

		switch(actions.cmd){
		case KEY_CMD_PAT_INFO: /* i */
			for(i = 0; i < task_count; i++) {
				if ( (current_task == i+1) || (current_task == 0) ) {
					RMDBGLOG((ENABLE, "pat info\n"));
					fprintf(stderr, "   %ld_PAT: ", Tasks[i].id);
					for (j=0; j<Tasks[i].pat_info.count; j++) {
						fprintf(stderr, "[%4x %3x] ", Tasks[i].pat_info.program_number[j],
							Tasks[i].pat_info.program_map_pid[j]);
					}
					fprintf(stderr, "\n");
				}
			}
			break;
		case KEY_CMD_SWITCH_SPI_FILE: /* K */
			for(i = 0; i < task_count; i++) {
				if ( (current_task == i+1) || (current_task == 0) ) {
					struct DemuxTask_InputParameters_type InParam;
					RMDBGLOG((ENABLE, "file-spi change\n"));
					Tasks[i].video_opt->auto_detect_codec = TRUE;
					Tasks[i].audio_opt->auto_detect_codec = TRUE;
					
					err = HwStop(&Tasks[i]);
					if (RMFAILED(err)) {
						fprintf(stderr, "%ld_SwitchSpiFile HwStop Error", Tasks[i].id);
						return err;
					}

					/* flip the spi mode */
					if (Tasks[i].play_opt->spi == FALSE) {
						Tasks[i].play_opt->spi = TRUE;
					}
					else {
						Tasks[i].play_opt->spi = FALSE;
					}	
					InParam.Spi = Tasks[i].play_opt->spi ? (Tasks[i].play_opt->serial_spi ? Serial_Spi : Paralel_Spi) : No_Spi;
					InParam.SourceType = Tasks[i].SourceType;
					err = RUASetProperty(Tasks[i].pRUA, Tasks[i].demux_task,
						RMDemuxTaskPropertyID_InputParameters, &InParam, sizeof(InParam), 0);
					
					/* reset pids, outputs and sections and prepare them for a new stream */
					ResetDemuxTask(&Tasks[i]);
					
					err = HwPlay(&Tasks[i]);
					if (RMFAILED(err)) {
						fprintf(stderr, "%ld_SwitchSpiFile HwPlay Error", Tasks[i].id);
						return err;
					}
		  
				}
			}
			break;
		case KEY_CMD_CHANGE_PMT: /* m */
			for(i = 0; i < task_count; i++) {
				if ( (current_task == i+1) || (current_task == 0) ) {
					/*if (program_count <= 1) {
					  RMDBGLOG((ENABLE, "only one program\n"));
					  break;
					  }*/
					RMDBGLOG((ENABLE, "pmt change\n"));
					Tasks[i].video_opt->auto_detect_codec = TRUE;
					Tasks[i].audio_opt->auto_detect_codec = TRUE;
					SetNextPMT(&Tasks[i]);
				}
			}
			break;
		case KEY_CMD_CHANGE_VIDEO: /* X */
			for(i = 0; i < task_count; i++) {
				if ( (current_task == i+1) || (current_task == 0) ) {
					if ( Tasks[i].VideoPidList.count > 1 ) {
						RMDBGLOG((ENABLE, "video stream change\n"));
						Tasks[i].video_opt->auto_detect_codec = TRUE;
						Tasks[i].VideoPidList.index = (Tasks[i].VideoPidList.index + 1) % Tasks[i].VideoPidList.count;
						err = SetPidFilterForAVPlayback(&Tasks[i]);
					}
				}
			}
			break;
		case RM_AUDIO_STREAM_CHANGE: /* A */
			for(i = 0; i < task_count; i++) {
				if ( (current_task == i+1) || (current_task == 0) ) {
					if ( Tasks[i].AudioPidList.count > 1 ) {
						Tasks[i].audio_opt->auto_detect_codec = TRUE;
						Tasks[i].AudioPidList.index = (Tasks[i].AudioPidList.index + 1) % Tasks[i].AudioPidList.count;
						RMDBGLOG((ENABLE, "audio stream change to index=%ld\n", Tasks[i].AudioPidList.index));
						err = SetPidFilterForAVPlayback(&Tasks[i]);
					}
				}
			}
			break;
		}

	}

	if ((actions.cmd == RM_DUALMODE_CHANGE) && (!actions.cmdProcessed)) { 
		fprintf(stderr, "Changing DualMode to :");	
		switch(Tasks[current_task].audio_opt->OutputDualMode) {		
		case DualMode_LeftMono:				
			fprintf(stderr, " RightMono\n");	
			Tasks[current_task].audio_opt->OutputDualMode = DualMode_RightMono;	
			break;					
		case DualMode_RightMono:			
			fprintf(stderr, " MixMono\n");		
			Tasks[current_task].audio_opt->OutputDualMode = DualMode_MixMono; 
			break;					
		case DualMode_MixMono:				
			fprintf(stderr, " Stereo\n");		
			Tasks[current_task].audio_opt->OutputDualMode = DualMode_Stereo; 
			break;					
		case DualMode_Stereo:				
			fprintf(stderr, " LeftMono\n");		
			Tasks[current_task].audio_opt->OutputDualMode = DualMode_LeftMono; 
			break;					
		default:					
			fprintf(stderr, " Unknown dual mode\n");
			break;					
		}

		for (i = 0; i < Tasks[current_task].audioInstances; i++) {
			Tasks[current_task].audio_opt_table[i].OutputDualMode = Tasks[current_task].audio_opt_table[0].OutputDualMode;

			err = apply_audio_decoder_options_onthefly(Tasks[current_task].dcc_info, &(Tasks[current_task].audio_opt_table[i]));
			if (RMFAILED(err)) {
				fprintf(stderr, "Error applying audio decoder options on the fly %d\n", err);
			}
		}				
		actions.cmdProcessed = TRUE;				
	}								

	if((!actions.cmdProcessed) &&
	   (actions.cmd == KEY_CMD_GET_DEBUG_INFO)){
		if(!FORCE_MONITOR){
			for(i = 0; i < task_count; i++) {
				Tasks[i].monitor = !Tasks[i].monitor;
				if(Tasks[i].monitor){
					RMDBGLOG((ENABLE, "Task %lu : enable monitoring ...\n", i));
				}
				else
					RMDBGLOG((ENABLE, "Task %lu : disable monitoring ...\n", i));

			}
		}
		else
			RMDBGLOG((ENABLE, "Monitor forced, cannot enable/disable\n"));
	}
	
	return err;
}

/* sample code to compensate STC drift */
static RMstatus StcCompensation(struct context_per_task *context)
{
#define STCC_INTV    10      /* averaging of PCR-STC difference over STC_INTV seconds */
#define STCC_CORR    60      /* correction attempts every STC_CORR seconds */
#define STCC_MAX     50      /* limit ppm value to -STCC_MAX .. STCC_MAX */
#define STCC_DISCONT 90000   /* discontinuity threshold (1 Sec.) */
			
/* rounding division, returns (RMint)a / (RMuint)b */
#define RNDDIV(a, b) (((a) < 0) ? -((-(a) + (b) / 2) / (b)) : (((a) + (b) / 2) / (b)))
			
	RMstatus err;
	RMuint32 stc_dbg = context->play_opt->stc_comp_debug;  // Debug message level: 0=silent, 1=corrective actions 2=actions 3=all
	struct DemuxTask_CurrentPcrInfo_in_type pcr_in;
	struct DemuxTask_CurrentPcrInfo_out_type pcr_out;
	struct RUAEvent e;
	RMuint64 stc32, pcr32, ustime;
	RMint64 delta;
	static RMuint32 avrg_n = 0; /* number of samples in averaging sccumulator */
	static RMint64 avrg_delta = 0; /* accumulated delta values */
	static RMint64 last_delta = 0; /* previous delta value */
	static RMuint64 ustime0 = 0, ustime1 = 0, ustime2 = 0, last_ustime = 0;
	static RMint64 dist_last = 0;
	static RMint64 STC_ppb = 0;
	
	pcr_in.time_resolution = 90000; // native
	e.ModuleID = context->demux_task;
	e.Mask = SOFT_IRQ_EVENT_DEMUX_PCR_UPDATE;
	
	if ((err = RUAWaitForMultipleEvents(context->pRUA, &e, 1, 0, NULL)) == RM_OK) {
		ustime = get_ustime();
		err = RUAExchangeProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_CurrentPcrInfo,
			&pcr_in, sizeof(pcr_in), &pcr_out, sizeof(pcr_out));
		if (RMFAILED(err))
			return err;
		
		/* Truncate to 32 bit */
		stc32 = pcr_out.stc & 0xFFFFFFFF;
		pcr32 = pcr_out.pcr & 0xFFFFFFFF;
		//fprintf(stderr, "\nPCR:%llx STC=%llx %llx", pcr_out.pcr, pcr_out.stc, pcr_out.pcr-pcr_out.stc);
		
		/* Handle wraparound case */
		if ((stc32 > 0xC0000000) && (pcr32 < 0x40000000)) pcr32 += 0x100000000LL;
		if ((stc32 < 0x40000000) && (pcr32 > 0xC0000000)) stc32 += 0x100000000LL;
		
		/* Current delta */
		delta = (RMint64)(stc32 - pcr32);
		if (stc_dbg >= 3) fprintf(stderr, "\rSTC-PCR:%6lld ", delta);
		if (RMabs(delta) > STCC_DISCONT) { /* discontinuity, reset offset */
			if (stc_dbg >= 2) fprintf(stderr, "\nReset drift averages @ PCR=0x%llX STC=0x%llX delta=%lld\n", 
				pcr32, stc32, delta);
			delta = 0;
		}
		
		/* Every STCC_CORR seconds, average delta over the last STCC_INTV sec. */
		if ((! ustime0) || ((RMuint32)(ustime - ustime0) >= (RMuint32)(STCC_CORR * 1000000))) {
			if (! ustime1) ustime1 = ustime;
			if (! ustime2) {
				if ((RMuint32)(ustime - ustime1) >= (RMuint32)(STCC_INTV * 1000000)) {
					ustime2 = ustime;
				}
				avrg_delta += delta;
				avrg_n++;
//				fprintf(stderr, "| avrg/%03lu: %6lld ", avrg_n, RNDDIV(avrg_delta, avrg_n));
			} else {
				RMuint64 curr_ustime, t;
				RMint64 curr_delta, dist, ppb;
				
				/* Determine center time of average */
				curr_ustime = ustime1 + (ustime2 - ustime1) / 2;
				
				/* Normalize delta average to picoSec */
				curr_delta = RNDDIV(avrg_delta * 100000, avrg_n * 9);
				
				if (last_ustime) {
					/* Determine time "t" since last update */
					t = curr_ustime - last_ustime; 
					
					/* Drift in ppb is delta difference (in picoSec.) over t (in Sec.) */
					ppb = RNDDIV((curr_delta - last_delta) * 1000000LL, t);
				} else {
					/* No comparison on first average */
					t = STCC_INTV * 1000000LL;
					ppb = 0;
				}
				
				/* Spread out current delta over next 10 cycle to create distance correction value */
				dist = RNDDIV(curr_delta, STCC_CORR * 10);
				
				if (stc_dbg >= 3) fprintf(stderr, "| delta/%03lu: %6lld | drift: %4lld ppb ", 
					avrg_n, curr_delta, ppb);
				
				if (stc_dbg >= 1) {
					fprintf(stderr, "\n*** Elapsed time: %llu:%02llu \n", t / (60 * 1000000LL), (t / 1000000LL) % 60);
					fprintf(stderr, "    STC to PCR drift: %lld ppb, net. drift: %lld ppb\n", ppb, ppb + dist_last);
					fprintf(stderr, "    PCR to STC distance: %lld pSec\n", curr_delta);
					fprintf(stderr, "    distance compensation: %lld ppb\n", -dist);
					fprintf(stderr, "    Last net. drift correction: %lld ppb\n", STC_ppb + dist_last);
					fprintf(stderr, "    Next net. drift correction: %lld ppb\n", STC_ppb - ppb);
				}
				
				/* Compensate for drift */
				STC_ppb -= ppb;
				
				/* Overcompensate to target correct value after next cycle */
				STC_ppb -= dist;
				
				/* Make sure STC_ppm stays inbetween -STCC_MAX .. STCC_MAX */
				if (STC_ppb > (STCC_MAX * 1000LL)) STC_ppb = STCC_MAX * 1000LL;
				else if (STC_ppb < (STCC_MAX * -1000LL)) STC_ppb = STCC_MAX * -1000LL;
				
				/* Write significant values into logfile */
				if (context->stcd) fprintf(context->stcd, "%lld\t%lld\t%lld\t%lld\n", curr_delta, ppb, -dist_last, STC_ppb);
				
				if (stc_dbg >= 1) fprintf(stderr, "    STC correction: %lld ppb, includes %lld ppb distance compensation\n", 
					STC_ppb, -dist);
				
				/* Adjust speed */
				err = DCCVCXOSetSpeedAVCorrect(context->dcc_info->pStcSource, 1000000000 + STC_ppb, 1000000000);
				//err = DCCSTCSetSpeedCleanDiv(context->dcc_info->pStcSource, 1000000000 + STC_ppb, 1000000000);
				//err = DCCSTCSetSpeedVCXO(context->dcc_info->pStcSource, 1000000000 + STC_ppb, 1000000000);
				
				/* Store and reset values */
				dist_last = dist;
				last_ustime = curr_ustime;
				last_delta = curr_delta;
				ustime0 = ustime1;
				ustime1 = 0;
				ustime2 = 0;
				avrg_delta = 0;
				avrg_n = 0;
			}
		}
	}

	return err;
}

#ifdef DO_CAPTURE

int get_picture(struct dcc_context *dccContext) {
#if 0
	struct VideoDecoder_NextPicture_type new_pic;
	RMstatus err;
	struct RUA*	pRUA = dccContext->pRUA;
	static RMuint32 framecount = 0;

	err = RUAGetProperty(dccContext->pRUA,
			 dccContext->video_decoder, 
			 RMVideoDecoderPropertyID_NextPicture, 
			 &new_pic, sizeof(new_pic));
	
	if(err == RM_OK) { 
		RMDBGLOG((CRCDBG, "FRAME %ld AVAILABLE @ 0x%08lx!\n", ++framecount, new_pic.PictureAddress));
			/* release the frame... */
		err = RUASetProperty(pRUA,
				 dccContext->video_decoder,
				 RMVideoDecoderPropertyID_ReleasePicture,
				 &new_pic.PictureAddress,
				 sizeof(new_pic.PictureAddress),
				 0);
	}
	
	return 0;
#else
	int result = 0;
	struct VideoDecoder_NextPicture_type new_pic;
	RMstatus err;
	struct RUA*	pRUA = dccContext->pRUA;
	static RMuint32 framecount = 0;
//	RMDBGLOG((ENABLE, "get_picture()\n"));

	err = RUAGetProperty(dccContext->pRUA,
						 dccContext->video_decoder, 
						 RMVideoDecoderPropertyID_NextPicture, 
						 &new_pic, sizeof(new_pic));

	if(err == RM_OK) { 
		RMuint32	luma_x, luma_y;
		RMuint32	luma_w, luma_h;
		RMuint32	chroma_x, chroma_y;
		RMuint32	chroma_w, chroma_h;
		RMuint32	luma_address, chroma_address;
		RMuint32	luma_width, chroma_width;
		RMuint32	luma_size_linear, chroma_size_linear;
		RMuint32	luma_size_tile, chroma_size_tile;
		RMuint32	buf_width, buf_height;
		RMuint8*	pLuma;
		RMuint8*	pChroma;

#ifdef	DO_CRC32
		RMuint32	luma_crc, chroma_crc;
		FILE*		ofp;
#endif

#ifdef	HANDLE_DISPLAY_STATUS
		if (new_pic.Picture.picture_display_status) {
#endif

#ifdef	DO_CRC32
			ofp = fopen(crcLogFilename, "a");
			RMDBGLOG((ENABLE, "ofp = %08lx\n", ofp));
#endif

			RMDBGLOG((CRCDBG, "FRAME %ld AVAILABLE @ 0x%08lx!\n", framecount, new_pic.PictureAddress));

			luma_x = new_pic.Picture.luma_position_in_buffer.x;
			luma_y = new_pic.Picture.luma_position_in_buffer.y;
			luma_w = new_pic.Picture.luma_position_in_buffer.width;
			luma_h = new_pic.Picture.luma_position_in_buffer.height;

			RMDBGLOG((ENABLE, "FRAME DIMENSIONS : %ld X %ld\n", luma_w, luma_h));

	//		RMDBGLOG((ENABLE, "LUMA: X=%d Y=%d W=%d H=%d\n", luma_x, luma_y, luma_w, luma_h));

			chroma_x = new_pic.Picture.chroma_position_in_buffer.x;
			chroma_y = new_pic.Picture.chroma_position_in_buffer.y;
			chroma_w = new_pic.Picture.chroma_position_in_buffer.width;
			chroma_h = new_pic.Picture.chroma_position_in_buffer.height;

	//		RMDBGLOG((ENABLE, "CHROMA: X=%d Y=%d W=%d H=%d\n", chroma_x, chroma_y, chroma_w, chroma_h));

			/* Get Luma & Chroma addresses */
			luma_address   = new_pic.Picture.luma_address;
			chroma_address = new_pic.Picture.chroma_address;

			RMDBGLOG((CRCDBG, "LUMA @ 0x%08lx CHROMA @ 0x%08lx\n", luma_address, chroma_address));

			luma_width   = new_pic.Picture.luma_total_width ; //& 0x3f;
			chroma_width = new_pic.Picture.chroma_total_width ; // & 0x3f;

			RMDBGLOG((CRCDBG, "LUMA WIDTH = %ld CHROMA WIDTH = %ld\n", luma_width, chroma_width));

			/* luma */
			buf_width 			= ((luma_w + 127)/128)*128;
			buf_height 			= ((luma_h + 31)/32)*32;
			luma_size_tile		= (buf_width * buf_height);

			RMDBGLOG((CRCDBG, "LUMA TILE BUFFER %ld x %ld size = %ld\n", buf_width, buf_height, luma_size_tile));

			/* chroma */
			buf_width 			= ((chroma_w + 127)/128)*128;
			buf_height 			= ((chroma_h + 31)/32)*32;
			chroma_size_tile	= (buf_width * buf_height) * 2;

			RMDBGLOG((CRCDBG, "CHROMA TILE BUFFER %ld x %ld size = %ld\n", buf_width, buf_height, chroma_size_tile));

			luma_size_linear   	= luma_w  * luma_h;
			chroma_size_linear 	= chroma_w * chroma_h * 2;


#if 0
			if (new_pic.Picture.picture_display_status == 0) {
				RMDBGLOG((ENABLE, "picture_decode_status = %ld picture_display_status = %ld\n", new_pic.Picture.picture_decode_status, new_pic.Picture.picture_display_status));
				RMDBGLOG((ENABLE, "LUMA BUFFER @ 0x%08lx CHROMA BUFFER @ 0x%08lx\n", luma_address, chroma_address));

				RMDBGLOG((ENABLE, "___WAITING____\n"));

				while (1) {
					sleep(1);
				}
			}
#endif

#ifdef WAIT_FOR_KEY
			
			/* if environment WAITKEY is defined, wait for user to hit a key. */
			if (getenv("WAITKEY") != 0L) {
				printf("HIT A KEY!\n");
				while (!RMKeyAvailable()) {
				}
				RMGetKey();
			}

#endif

			/* lock memory regions */
			err = RUALock(pRUA, luma_address, luma_size_tile);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "ERROR: Unable to lock luma buffer!\n"));
			}
			err = RUALock(pRUA, chroma_address, chroma_size_tile);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "ERROR: Unable to lock chroma buffer!\n"));
			}

			/* map memory regions */
			pLuma 	= RUAMap(pRUA, luma_address, luma_size_tile);
			pChroma = RUAMap(pRUA, chroma_address, chroma_size_tile);

			RMDBGLOG((CRCDBG, "Mapped Luma @ 0x%08lx and Chroma @ 0x%08lx\n", (RMuint32)pLuma, (RMuint32)pChroma));

#ifdef	DO_CRC32

#ifdef	DO_SOFT_CRC
			luma_crc   = _crc32(pLuma, luma_width, luma_x, luma_w, luma_y, luma_h, 0, 0);
			chroma_crc = _crc32(pChroma, chroma_width, chroma_x, chroma_w*2, chroma_y, chroma_h, 0, 0);

			RMDBGLOG((CRCDBG, "FRAME # %ld : LUMA CRC = 0x%08lx CHROMA CRC = 0x%08lx\n",
						framecount, luma_crc, chroma_crc));

#else	// DO_SOFT_CRC

			luma_crc 	= crc32_be_h(pRUA, luma_address, luma_width, luma_x, luma_w, luma_y, luma_h);
			chroma_crc 	= crc32_be_h(pRUA, chroma_address, chroma_width, chroma_x, chroma_w * 2, chroma_y, chroma_h);

#endif	// DO_SOFT_CRC

			fprintf(stderr, "#%10lu luma %10lx chroma %10lx\n", framecount, luma_crc, chroma_crc);	// to standard error stream
			fprintf(ofp, 	"#%10lu luma %10lx chroma %10lx\n", framecount, luma_crc, chroma_crc);	// to file

#endif	// DO_CRC32

#ifdef	DO_SAVE
			
			/* if environment SAVEPATH is defined, save the Y, U, & V components to specified path. */
			if (getenv(SAVEPATH) != NULL)
				save_frame(	framecount, 
						pLuma, luma_w, luma_h, luma_width, 
						pChroma, chroma_w, chroma_h, chroma_width);

#endif


			/* unmap memory areas */
			RUAUnMap(pRUA, pLuma, luma_size_tile);
			RUAUnMap(pRUA, pChroma, chroma_size_tile);

			/* Unlock memory regions */
			RUAUnLock(pRUA, luma_address, luma_size_tile);
			RUAUnLock(pRUA, chroma_address, chroma_size_tile);

			/* release the frame... */
			err = RUASetProperty(pRUA,
								 dccContext->video_decoder,
								 RMVideoDecoderPropertyID_ReleasePicture,
								 &new_pic.PictureAddress,
								 sizeof(new_pic.PictureAddress),
								 0);
			if (RMFAILED(err)) {
				printf("ERROR: Unable to release picture buffer!\n");
			}

			framecount++;

#ifdef	DO_CRC32
			if (ofp)
				fclose(ofp);
#endif

	//		usleep(100);

			result = 1;
#ifdef	HANDLE_DISPLAY_STATUS
		} else {
	
			RMDBGLOG((ENABLE, "DROP FRAME\n"));

			/* release the frame... */
			err = RUASetProperty(pRUA,
								 dccContext->video_decoder,
								 RMVideoDecoderPropertyID_ReleasePicture,
								 &new_pic.PictureAddress,
								 sizeof(new_pic.PictureAddress),
								 0);
			if (RMFAILED(err)) {
				printf("ERROR: Unable to release picture buffer!\n");
			}

		}
#endif

	}

	return result;

#endif
}

#endif	// DO_CAPTURE

static void get_filename(char* szFilename, size_t len, int framenum, int component) 
{
	char*		outputDir = getenv(SAVEPATH);
	char		compChar = 'X';

	if (component < 3) {
		switch (component) {
			case 0:
				compChar = 'Y';
				break;
			case 1:
				compChar = 'U';
				break;
			case 2:
				compChar = 'V';
				break;
		}
		
		if (outputDir) {
			snprintf(szFilename, len, "%s/out_%d.%c", outputDir, framenum, compChar);
		} else {
			snprintf(szFilename, len, "out_%d.%c", framenum, compChar);
		}
	} else {
		snprintf(szFilename, len, "%s/size.txt", outputDir);
	}

	return;
}


#ifdef	DO_SAVE

void save_frame(int count,
				RMuint8* pLuma, RMuint32 luma_w, RMuint32 luma_h, RMuint32 luma_width,
				RMuint8* pChroma, RMuint32  chroma_w, RMuint32 chroma_h, RMuint32 chroma_width)
{
	char		szFilename[256];
	FILE		*fpY, *fpU, *fpV;
	FILE		*fSize;
	RMuint32	luma_tile_size, chroma_tile_size;
#ifdef	DO_LINEAR_BUFFER
	RMuint32	x,y;
#endif
	RMuint32	chromasize;
	RMuint8		*data;
	RMuint8		*ptr;

	RMDBGLOG((ENABLE, "Saving frame %ld...\n", count));

	get_filename(szFilename, 256, count, 3);
	fSize = fopen(szFilename, "a");	// open for append
	fprintf(fSize, "%ldx%ld\n", luma_w, luma_h);
	fclose(fSize);

	luma_tile_size = ((((luma_w + 127)/128)*128) * ((((luma_h + 31)/32)*32)));
	chroma_tile_size = ((((chroma_w + 127)/128)*128) * ((((chroma_h + 31)/32)*32)));

	RMDBGLOG((CRCDBG, "Luma size = %ld Chroma size = %ld\n", luma_tile_size, chroma_tile_size));

//	RMuint32	chroma_size = chroma_w * chroma_h;
//	RMuint32	luma_size = luma_w * luma_h;

	/* open the Y, U, & V files */
	get_filename(szFilename, 256, count, 0);
	fpY = fopen(szFilename, "wb");
	get_filename(szFilename, 256, count, 1);
	fpU = fopen(szFilename, "wb");
	get_filename(szFilename, 256, count, 2);
	fpV = fopen(szFilename, "wb");

#ifdef	DO_LINEAR_BUFFER
	/* save the luma buffer */
	for (y = 0 ; y < luma_h ; y++)
		for (x = 0 ; x < luma_w ; x++) {
			RMuint8* pixel = (pLuma +\
					(x/128) * 4096 + (y/32) * luma_width * 32 +
					(x % 128) + (y % 32)*128);

			RMuint8 c = *pixel;
			fwrite(&c, 1, 1, fpY);
		}

	chromasize = chroma_w * chroma_h * 2;
	data = malloc(chromasize);
	ptr = data;

	/* break chroma buffer into U & V components */
	for (y = 0 ; y < chroma_h ; y++)
		for (x = 0 ; x < chroma_w*2 ; x++) {
			RMuint8* pixel = (pChroma +\
					(x/128) * 4096 + (y/32) * chroma_width * 32 +
					(x % 128) + (y % 32)*128);

			*ptr++ = *pixel;
		}

	for (x = 0 ; x < chromasize/2 ; x++) {
		fwrite(&data[2*x],   1, 1, fpU);
		fwrite(&data[2*x+1], 1, 1, fpV);
	}

	free(data);

#else	// DO_LINEAR_BUFFER
	
	fwrite(pLuma, luma_tile_size , 1, fpY);
	
#endif

	/* close all the files */
	fclose(fpY);
	fclose(fpU);
	fclose(fpV);

	return;
}
#endif	// DO_SAVE



#ifdef WITH_MONO
int main_psfdemux(struct mono_info *mono)
#else
int main(int argc, char *argv[])
#endif
{
	struct dcc_context dcc_info[MAX_TASK_COUNT] = { {0, } };
	struct DCC *pDCC = NULL;
	struct RUA *pRUA = NULL;
	struct RUAEvent event_list[1 + MAX_EVENT_COUNT_PER_TASK * MAX_TASK_COUNT];
	
	RMuint32 i = 0;
	RMstatus err;
	RMuint32 event_index = 0;
	RMuint32 WaitEventsMask = 0, BlockingWaitEventsMask = 0;
	RMbool wait_on_receive_event;

	struct DemuxTask_InputParameters_type InParam;
	struct stream_options_s stream_options;
	RMuint64 startTime = 0;
	
	/* #### Begin DTCP code #### */
	struct dtcp_cookie *dtcpCookieHandle = NULL;
         /* #### End DTCP code #### */

	/* init variables that do not depend on parse_cmdline */
	for (i=0; i< MAX_TASK_COUNT; i++) {
		/* is this really needed? */
		RMMemset(&Tasks[i], 0, sizeof(struct context_per_task));
		RMMemset(&dcc_info[i], 0, sizeof(struct dcc_context));
		Tasks[i].change_program_method = change_program_with_stop_all;
		Tasks[i].section_filter_based_on_new_version = 3; /* by default filter PAT and PMT based on version */
#ifdef WITH_MONO

		Tasks[i].play_opt = mono->play_opt;
		Tasks[i].video_opt = mono->video_opt;
		Tasks[i].disp_opt = mono->disp_opt;


#if NO_FAST_AUDIO_RECOVERY_AFTER_TRICKMODE
		Tasks[i].play_opt->fast_audio_recovery = FALSE;
#endif

		Tasks[i].audio_opt = mono->audio_opt;
		Tasks[i].audio_opt_table = mono->audio_opt;

		Tasks[i].demux_opt = mono->demux_opt;
		dcc_info[i].disp_info = NULL;

		Tasks[i].audioInstances = Tasks[i].audio_opt->audioInstances;
		
		RMDBGLOG((ENABLE, "task %lu, audio instances %lu, %lu\n", i, Tasks[i].audioInstances, Tasks[i].audio_opt->audioInstances));
		
		print_parsed_audio_options(Tasks[i].audio_opt_table);



  		/* TODO 
		 * 1)use the videoscaler set by mono
		 * 2)do something about audio_pid and video_pid
		 */
		switch (mono->demux_opt->system_type) {
		case RM_SYSTEM_MPEG2_TRANSPORT:
			RMDBGLOG((ENABLE, "----> M2T\n"));
			Tasks[i].SourceType = SourceType_m2t;
			Tasks[i].app_type = pid_filter_section;
			break;
		case RM_SYSTEM_MPEG2_TRANSPORT_192:
			RMDBGLOG((ENABLE, "----> M2T with ts_skip = 4\n"));
			Tasks[i].SourceType = SourceType_m2t;
			Tasks[i].app_type = pid_filter_section;
			Tasks[i].ts_skip = 4;
			break;
		case RM_SYSTEM_MPEG1:
			RMDBGLOG((ENABLE, "----> M1S\n"));
			Tasks[i].SourceType = SourceType_m1s;
			Tasks[i].app_type = program_stream_parsing;
			break;
		case RM_SYSTEM_MPEG2_DVD:
			RMDBGLOG((ENABLE, "----> DVD\n"));
			Tasks[i].SourceType = SourceType_dvd;
			Tasks[i].app_type = program_stream_parsing;
			break;
		case RM_SYSTEM_MPEG2_PROGRAM:
			RMDBGLOG((ENABLE, "----> M2P\n"));
			Tasks[i].SourceType = SourceType_m1s;
			Tasks[i].app_type = program_stream_parsing;
			break;
		default:
			RMDBGLOG((ENABLE, "unsupported type %ld\n", mono->demux_opt->system_type));
			return -1;
			break;
		}
#else // no WITH_MONO
		RMMemset(&demux_options[i], 0, sizeof(struct demux_cmdline));
		Tasks[i].play_opt = &playback_options[i];
		Tasks[i].disp_opt = &display_options[i];
		Tasks[i].video_opt = &video_options[i];
		Tasks[i].demux_opt = &demux_options[i];

		Tasks[i].audio_opt = &audio_options[i*MAX_AUDIO_DECODER_INSTANCES];
		Tasks[i].audio_opt_table = &audio_options[i*MAX_AUDIO_DECODER_INSTANCES];

		dcc_info[i].disp_info = &disp_info[i];

		init_display_options(Tasks[i].disp_opt);
		init_video_options(Tasks[i].video_opt);
		init_playback_options(Tasks[i].play_opt);
		Tasks[i].disp_opt->dh_info = &dh_info[i];
		Tasks[i].SourceType = SourceType_m2t;
		Tasks[i].app_type = pid_filter_section;

		init_audio_options2(Tasks[i].audio_opt_table, MAX_AUDIO_DECODER_INSTANCES);
		Tasks[i].audioInstances = Tasks[i].audio_opt->audioInstances;
		
		Tasks[i].audio_opt->dh_info = &dh_info[i];
		dcc_info[i].dh_info = &dh_info[i];


#endif // WITH_MONO
 
		/*common*/
		pdcc_info[i] = &dcc_info[i];

		dcc_info[i].RM_PSM_commands = RM_PSM_ENABLE_PLAY;
		dcc_info[i].RM_PSM_commands |= RM_PSM_ENABLE_STOP;
		dcc_info[i].RM_PSM_commands |= RM_PSM_ENABLE_PAUSE;
		dcc_info[i].RM_PSM_commands |= RM_PSM_ENABLE_SWITCHAUDIO;
		dcc_info[i].RM_PSM_commands |= RM_PSM_ENABLE_SWITCHVIDEO;

		dcc_info[i].RM_PSM_commands |= RM_PSM_ENABLE_NEXTPIC;
		
		dcc_info[i].RM_PSM_commands |= RM_PSM_ENABLE_SPEED;
		dcc_info[i].RM_PSM_commands |= RM_PSM_ENABLE_FASTER;
		dcc_info[i].RM_PSM_commands |= RM_PSM_ENABLE_SLOWER;


#if 0 // force trickmodes
		//dcc_info[i].RM_PSM_commands |= RM_PSM_ENABLE_SEEK;
		dcc_info[i].RM_PSM_commands |= RM_PSM_ENABLE_IFWD;
		//dcc_info[i].RM_PSM_commands |= RM_PSM_ENABLE_IRWD;
#endif


		dcc_info[i].route = DCCRoute_Main;
		
		Tasks[i].input_port = Tasks[i].id;
		Tasks[i].wait_eos_state = MAX_EVENT_COUNT_PER_TASK; /* invalid state */
		Tasks[i].av_flags = AV_PIDS_ENABLE_FIRST_TIME;
		Tasks[i].video_pid = 0x1FFF;
		Tasks[i].audio_pid = 0x1FFF;
		Tasks[i].pcr_pid = 0x1FFF;
		Tasks[i].ecm_pid[0] = 0x1FFF;
		Tasks[i].ecm_pid[1] = 0x1FFF;
		Tasks[i].teletext_pid = 0x1FFF;

		Tasks[i].sendVideoData = TRUE;
		Tasks[i].sendAudioData = TRUE;

		Tasks[i].isTrickMode = FALSE;
		Tasks[i].isIFrameMode = FALSE;
		Tasks[i].isRewinding = FALSE;
		Tasks[i].pcr_disc = 10000; /* 10sec */

		/* ## AES_CBC_PRECIPHER TEST CODE BEGIN ## */
		Tasks[i].test_aes_precipher = FALSE;
		Tasks[i].dtcpip_streaming = FALSE;
		/* ## AES_CBC_PRECIPHER TEST CODE END ## */
	}


#ifdef WITH_MONO
	pRUA = mono->pRUA;
	pDCC = mono->pDCC;
	task_count = 1;

#else

	parse_cmdline(argc, argv);

	compute_crclog_filename(Tasks[0].play_opt->filename, crcLogFilename);
	RMDBGLOG((ENABLE, "Writing log file %s\n", crcLogFilename));

	/* init crc table and delete any existing log file. */
	crc32_init();
	unlink(crcLogFilename);


	display_key_usage(KEYFLAGS);

	RMDBGLOG((ENABLE, "creating RUA instance\n"));
	err = RUACreateInstance(&pRUA, Tasks[0].play_opt->chip_num);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error creating RUA instance! %d\n", err);
		return -1;
	}

	RMDBGLOG((ENABLE, "opening DCC\n"));
	err = DCCOpen(pRUA, &pDCC);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error Opening DCC! %d\n", err);
		return -1;
	}

	if (!Tasks[0].play_opt->noucode) {
		RMDBGLOG((ENABLE, "init microcode\n"));
		err = DCCInitMicroCodeEx(pDCC, Tasks[0].disp_opt->init_mode);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot initialize microcode %d\n", err);
			return -1;
		}
	}
	else
		RMDBGLOG((ENABLE, "microcode not loaded\n"));

	RMTermInit(TRUE);    // don't allow ctrl-C and the like ...
	RMSignalInit(NULL, NULL);  // ... but catch other termination signals to call RMTermExit()
#endif

	

	for (i=0; i< task_count; i++) {

		dcc_info[i].pRUA = pRUA;
		dcc_info[i].pDCC = pDCC;
		Tasks[i].pRUA = pRUA;
		Tasks[i].dcc_info = &dcc_info[i];
	}



	{
		RMuint32 nb_demux_tasks;
		RMuint32 module_id = EMHWLIB_MODULE(DemuxTask,0);
		err = RUAExchangeProperty(pRUA, EMHWLIB_MODULE(Enumerator,0),  RMEnumeratorPropertyID_CategoryIDToNumberOfInstances, 
					  &(module_id), sizeof(module_id), &nb_demux_tasks, sizeof(nb_demux_tasks));
		
		module_id = EMHWLIB_MODULE(DemuxOutput,0);
		err = RUAExchangeProperty(pRUA, EMHWLIB_MODULE(Enumerator,0),  RMEnumeratorPropertyID_CategoryIDToNumberOfInstances, 
					  &(module_id), sizeof(module_id), &output_count_per_task, sizeof(output_count_per_task));
		output_count_per_task = output_count_per_task / nb_demux_tasks;
	}


	/* initialize variables depending on parse_cmdline and open the emhwlib modules */
	{
		/* enable closed caption only for one task - the one selected by user or by default first one */
		RMbool cc_enabled = FALSE;
		for (i=0; i< task_count; i++) {
			if (cc_enabled) {
				/* disable cc for all the other tasks */
				Tasks[i].video_opt->display_cc = FALSE;
			}
			if (Tasks[i].video_opt->display_cc) {
				/* first task with cc enabled will display closed caption */
				cc_enabled = TRUE;
			}
		}
		if (!cc_enabled) {
			/* enable by default only first task */
			//Tasks[0].video_opt->display_cc = TRUE; //it does not work for multiple processes
		}
	}
	/* to do default detection ... */
	if (idle_port > 3)
		idle_port = 4 - task_count;

	/* if all tasks are spi we can afford to wait with timeout on receive events */
	wait_on_receive_event = TRUE;
	for (i=0; i< task_count; i++) {
		if (!Tasks[i].play_opt->spi) {
			wait_on_receive_event = FALSE;
			break;
		}
	}
	
	for (i=0; i< task_count; i++) {

		struct PSFDemuxTaskProfile demux_profile;
		struct DCCStcProfile stc_profile;
		enum EMhwlibTimerSync timer_sync;

		fprintf(stderr, "\n****************** open %lx/%lx: task = %lx ******************\n", i+1, task_count, Tasks[i].id);
	
		RMMemset(&demux_profile, 0, sizeof(demux_profile));

		
		if (Tasks[i].video_opt->fifo_size == 0) 
			Tasks[i].video_opt->fifo_size = VIDEO_FIFO_SIZE;
		if (Tasks[i].audio_opt->fifo_size == 0) 
			Tasks[i].audio_opt->fifo_size = AUDIO_FIFO_SIZE;

		Tasks[i].audioInstances = Tasks[i].audio_opt->audioInstances;
		{
			RMuint32 j;
			for (j = 0; j < Tasks[i].audioInstances; j++) {
				if (Tasks[i].audio_opt_table[j].fifo_size == 0) 
					Tasks[i].audio_opt_table[j].fifo_size = AUDIO_FIFO_SIZE;	
			}
		}

		if (Tasks[i].demux_opt->fifo_size == 0) 
			Tasks[i].demux_opt->fifo_size = DEMUX_FIFO_SIZE;
		if (Tasks[i].demux_opt->xfer_count == 0)
			Tasks[i].demux_opt->xfer_count = DEMUX_XFER_FIFO_COUNT;
		if (Tasks[i].play_opt->dmapool_count == 0)
			Tasks[i].play_opt->dmapool_count = DMA_BUFFER_COUNT;
		if (Tasks[i].play_opt->dmapool_log2size == 0)
			Tasks[i].play_opt->dmapool_log2size = DMA_BUFFER_SIZE_LOG2;

		if (Tasks[i].play_opt->stc_compensation && (Tasks[i].play_opt->stc_comp_debug >= 4)) {
			Tasks[i].stcd = fopen("STC_Debug.txt", "w");
			if (Tasks[i].stcd)
				fprintf(Tasks[i].stcd, "STC-PCR pSec.\tDrift ppb\tDist. corr. ppb\tSTC corr. ppb\n");
		}
		err = InitTableVariables(&Tasks[i]);
		if (RMFAILED(err))
			goto cleanup;

		print_parsed_audio_options(Tasks[i].audio_opt_table);
		err = apply_playback_options(&dcc_info[i], Tasks[i].play_opt);
		if (RMFAILED(err)) {
			fprintf(stderr, "%ld_Cannot set playback options err=%d\n", Tasks[i].id, err);
			goto cleanup;
		}

		/* open DemuxTask module */
#ifdef WITH_AACS
		demux_profile.ProtectedFlags = Tasks[i].aacs_xtask_pid ? 
			EMHWLIB_USE_ERASER_FIFO : 0;
#else
		demux_profile.ProtectedFlags = 0;
#endif
		demux_profile.BitstreamFIFOSize = Tasks[i].play_opt->spi ? 0 : Tasks[i].demux_opt->fifo_size;
		demux_profile.XferFIFOCount = Tasks[i].play_opt->spi ? 0:Tasks[i].demux_opt->xfer_count;
		demux_profile.InbandFIFOCount = Tasks[i].play_opt->spi ? 0:128;
		demux_profile.DemuxTaskID = Tasks[i].id;
		demux_profile.InputPort = Tasks[i].input_port;
		demux_profile.PrimaryMPM = Tasks[i].id;	/* parsing mpm */
		demux_profile.SecondaryMPM = Tasks[i].play_opt->spi ? Tasks[i].id : 3; /* input mpm */
#ifdef WITH_AACS
		demux_profile.XTaskModuleId = Tasks[i].aacs_xtask_pid ? EMHWLIB_MODULE(XTask, Tasks[i].aacs_xtask_pid) : 0;
		demux_profile.XTaskContext = Tasks[i].aacs_context;
		demux_profile.XTaskInbandFIFOCount = 128;
#endif /* WITH_AACS */
		err = PSFOpenDemuxTask(pDCC, &demux_profile, &(dcc_info[i].pDemuxTask));
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot open demux %d\n", err);
			goto cleanup;
		}
		
		err = DCCGetDemuxTaskInfo(dcc_info[i].pDemuxTask, &(dcc_info[i].demux_task));
		if (RMFAILED(err)) {
			fprintf(stderr, "Error getting demux_task source information %d\n", err);
			goto cleanup;
		}
		fprintf(stderr, "dcc_info[%ld].demux_task =  %ld\n", i, dcc_info[i].demux_task);

		Tasks[i].demux_task = dcc_info[i].demux_task;

		/* open stc module */
		stc_profile.STCID = Tasks[i].id;
		stc_profile.master = Master_STC;

		stc_profile.stc_timer_id = 3*Tasks[i].id;
		stc_profile.stc_time_resolution = 90000;

		stc_profile.video_timer_id = 3*Tasks[i].id+1;
		stc_profile.video_time_resolution = 90000;
		stc_profile.video_offset = -(Tasks[i].play_opt->video_delay_ms * (RMint32)stc_profile.video_time_resolution / 1000);

		stc_profile.audio_timer_id = 3*Tasks[i].id+2;
		stc_profile.audio_time_resolution = 90000;
		stc_profile.audio_offset = -(Tasks[i].play_opt->audio_delay_ms * (RMint32)stc_profile.audio_time_resolution / 1000);

		err = DCCSTCOpen(pDCC, &stc_profile, &dcc_info[i].pStcSource);
		if (RMFAILED(err)) {
			fprintf(stderr, "%lx_Cannot open stc module err=%d\n", Tasks[i].id, err);
			goto cleanup;
		}
		
		if ( Tasks[i].play_opt->spi == FALSE ) {
			/* local file - dmapool must be created after the module open in case we do no copy transfers */
			err = RUAOpenPool(pRUA, Tasks[i].demux_task, Tasks[i].play_opt->dmapool_count, Tasks[i].play_opt->dmapool_log2size,
					  RUA_POOL_DIRECTION_SEND, &Tasks[i].pDma);
			if (RMFAILED(err)) {
				fprintf(stderr, "%ld_Error cannot open dmapool err=%d\n", Tasks[i].id, err);
				goto cleanup;
			}

			/* Initialize the HTTP stream options data structure */
			init_stream_options(&stream_options);

			/* ################## Begin DTCP code ######################## */
#ifdef WITH_MONO	
			if (mono->dtcpCookieHandle) {
				// If MONO is present, simply use MONO's DTCP cookie handle
				dtcpCookieHandle = mono->dtcpCookieHandle;
				stream_options = mono->stream_opts;
			}
#else
			// Parse the URL searching for DTCP parameters.
			// If found, initialize the DTCP subsystem.
			err = init_DTCP_session (&dtcpCookieHandle,
						 &stream_options,
						 pRUA,
						 Tasks[i].play_opt->filename,
					         TRUE);
			if (RMFAILED(err)) {
				fprintf(stderr, "Cannot initialize or check for DTCP-IP session correctly !!!\n");
				goto cleanup;
			}
#endif // WITH_MONO
			if (dtcpCookieHandle) {
			// Use inband commands to decrypt the data
				dtcpCookieHandle->dtcp_inband_flag = 1;
				dtcpCookieHandle->dtcp_inband_context = Tasks[i].dcc_info;
				Tasks[i].dtcpip_streaming = TRUE;
			}
			/* #################### End DTCP code ####################### */

			Tasks[i].file = open_stream(Tasks[i].play_opt->filename, RM_FILE_OPEN_READ, &stream_options);
			if (Tasks[i].file == NULL) {
				fprintf(stderr, "%lx_Cannot open file %s\n", Tasks[i].id, Tasks[i].play_opt->filename);
				goto cleanup;
			}
			RMSizeOfOpenFile(Tasks[i].file, &Tasks[i].fileSize);
			RMDBGLOG((ENABLE, "file: %s, size %llu, duration %llu\n", Tasks[i].play_opt->filename, Tasks[i].fileSize, Tasks[i].play_opt->duration / 1000));

			if (Tasks[i].play_opt->duration)
				fprintf(stderr, "duration %llu secs\n", Tasks[i].play_opt->duration / 1000);

			if ((Tasks[i].play_opt->duration > 1000) && (Tasks[i].fileSize > 0)) {
				RMDBGLOG((ENABLE, "seek and iframe modes enabled\n"));
				
				Tasks[i].dcc_info->RM_PSM_commands |= RM_PSM_ENABLE_SEEK;
				Tasks[i].dcc_info->RM_PSM_commands |= RM_PSM_ENABLE_IFWD;
				//Tasks[i].dcc_info->RM_PSM_commands |= RM_PSM_ENABLE_IRWD;

				/* activate rewind mode */
				Tasks[i].dcc_info->RM_PSM_commands |= RM_PSM_ENABLE_REWIND;

			}


		}
		
		/* set input parameters */
		InParam.Spi = Tasks[i].play_opt->spi ? (Tasks[i].play_opt->serial_spi ? Serial_Spi : Paralel_Spi) : No_Spi;
		InParam.SourceType = Tasks[i].SourceType;
		err = RUASetProperty(pRUA, Tasks[i].demux_task, RMDemuxTaskPropertyID_InputParameters, &InParam, sizeof(InParam), 0);
		err = RUASetProperty(pRUA, Tasks[i].demux_task, RMDemuxTaskPropertyID_IdleInputPort, &idle_port, sizeof(idle_port), 0);
		err = RUASetProperty(pRUA, Tasks[i].demux_task, RMDemuxTaskPropertyID_TSSyncLockCount,
			&Tasks[i].sync_lock, sizeof(Tasks[i].sync_lock), 0);

		RUASetProperty(pRUA, Tasks[i].demux_task, RMDemuxTaskPropertyID_TsSkipBytes, &Tasks[i].ts_skip, sizeof(RMuint32), 0);
		{
			struct DemuxTask_PcrDiscontinuity_type discont;
			discont.threshold = Tasks[i].pcr_disc * 90;	/* default 10 sec */
			discont.time_resolution = 90000;
			err = RUASetProperty(pRUA, Tasks[i].demux_task, RMDemuxTaskPropertyID_PcrDiscontinuity, &discont, sizeof(discont), 0);
		}
		if (!Tasks[i].play_opt->send_video_pts && !Tasks[i].play_opt->send_audio_pts && !Tasks[i].play_opt->send_spu_pts)
			timer_sync = EMhwlibTimerSync_None;
		else
			timer_sync = EMhwlibTimerSync_FirstPcrSetPlayStc;
		RUASetProperty(pRUA, Tasks[i].demux_task, RMDemuxTaskPropertyID_TimerSync, &timer_sync, sizeof(timer_sync), 0);
		/* init cipher tables according to application type */
		err = InitKeyAndCipherTable(&Tasks[i]);
		if (RMFAILED(err))
			goto cleanup;

		/* init pid,section, output tables according to application type */
		if (Tasks[i].app_type == program_stream_parsing) {
			Tasks[i].av_flags &= ~AV_PIDS_ENABLE_FIRST_TIME;
			err = InitPesTablePerTask(&Tasks[i]);
			if (RMFAILED(err))
				goto cleanup;
			err = OpenOutputTableForRecord(&Tasks[i]);
			if (RMFAILED(err)) {
				fprintf(stderr, "OpenOutputTableForRecord failed %d\n", err);
				goto cleanup;
			}
			err = OpenOutputTableForPlayback(&Tasks[i]);
			if (RMFAILED(err)) {
				fprintf(stderr, "OpenOutputTableForPlayback failed %d\n", err);
				goto cleanup;
			}
		}
		else if (Tasks[i].app_type == input_record) {
			err = OpenOutputTableForInputRecord(&Tasks[i]);
			if (RMFAILED(err)) {
				fprintf(stderr, "OpenOutputTableForInputRecord failed %d\n", err);
				goto cleanup;
			}
		}
		else {
			err = InitSectionTable(&Tasks[i]);
			if (RMFAILED(err))
				goto cleanup;
			err = InitPidTablePerTask(&Tasks[i]);
			if (RMFAILED(err))
				goto cleanup;
			err = OpenOutputTableForRecord(&Tasks[i]);
			if (RMFAILED(err)) {
				fprintf(stderr, "OpenOutputTableForRecord failed %d\n", err);
				goto cleanup;
			}
			err = OpenOutputTableForPlayback(&Tasks[i]);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "OpenOutputTableForPlayback failed %d\n", err));
				goto cleanup;
			}
		}
		
		if (Tasks[i].av_flags &
			(VIDEO_PID_FROM_CMDLINE | PCR_PID_FROM_CMDLINE | AUDIO_PID_FROM_CMDLINE | ECM0_PID_FROM_CMDLINE | ECM1_PID_FROM_CMDLINE | TTX_PID_FROM_CMDLINE )) {
			fprintf(stderr, "Video and audio pids set by command line options \n");
			SetHwAVPlayback(&Tasks[i]);
		}
	}
	
	PSMcontext.validPSMContexts = task_count;
	PSMcontext.currentActivePSMContext = 0;
	PSMcontext.keyflags = KEYFLAGS;

	RM_PSM_SetState(&(PSMcontext), pdcc_info, RM_PSM_Playing);

	for (i=0; i< task_count; i++) {
		if ( Tasks[i].file ) {
			RMDBGLOG((ENABLE, "seek to zero\n"));
			if (RMSeekFile(Tasks[i].file, 0, RM_FILE_SEEK_START) != RM_OK) {
				perror("seeking file to beginning\n");
				goto cleanup;
			}
		}

		err = HwPlay(&Tasks[i]);
		if (RMFAILED(err)) {
			fprintf(stderr, "%lx_HwPlay err=%d\n", Tasks[i].id, err);
			goto cleanup;
		}
		if ( Tasks[i].play_opt->spi == FALSE ) {
			RMDBGLOG((ENABLE, "available buffer count: %lu\n", RUAGetAvailableBufferCount(Tasks[i].pDma)));
		}
	}

	startTime = get_ustime();
	
#ifdef WITH_MONO
	RMDCCInfo(&dcc_info[0]); // pass DCC context to application
#endif


	for (i = 0; i < task_count; i++) {
		RMuint32 j;
		if (!Tasks[i].play_opt->send_audio) {
			RMDBGLOG((ENABLE, "disable audio for task %lu\n", i));
			for (j = 0; j < Tasks[i].audioInstances; j++) {
				struct EMhwlibOutputMask_type discmd;
				
				/* announce demux to disable and flush the context audio output */
				discmd.output_mask[0] = (1<<Tasks[i].audioDemuxOutputIndex[j]);
				err = send_disable_output_demux_command (Tasks[i].pRUA, Tasks[i].demux_task, &discmd);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "%ld_trick mode iframe send_disable_output_demux_command Error\n", Tasks[i].id));
				}
			}
			
			/* audio decoder stop flushes the demux output - no need to call RMDemuxOutputPropertyID_Flush */
			err = Stop(&Tasks[i], RM_DEVICES_AUDIO);
			
		}
	}
	

	while (1) {
		RMuint32 count;
		struct InbandCommandX_type ibcx;
		RMuint32 nEvents;
		RMuint64 t_start = 0;
		RMuint32 timeout;

		if (timedbg)
			t_start = get_ustime();

	process_key:
		err = ProcessKey();
		if (RMFAILED(err))
			goto cleanup;
		
		for (i=0; i< task_count; i++) {
			if ((Tasks[i].monitor) || FORCE_MONITOR)
				monitor(&Tasks[i], FALSE); 
		}

		WaitEventsMask = 0;
		BlockingWaitEventsMask = 0;
		nEvents = 0;

		event_list[nEvents].ModuleID = EMHWLIB_MODULE(CPUBlock, 0);
		event_list[nEvents].Mask = SOFT_IRQ_EVENT_ERROR;
		WaitEventsMask |= CPU_ERROR_EVENT_MASK;
		nEvents++;
		
		for (i=0; i< task_count; i++) {
			/* multi task file playback or spi have 1 receive event per task */
			event_list[nEvents].ModuleID = Tasks[i].demux_task;
			event_list[nEvents].Mask = SOFT_IRQ_EVENT_XFER_RECEIVE_READY;
			WaitEventsMask |= DEMUX_RECEIVE_EVENT_MASK(i);
			nEvents++;
			
			/* if all tasks are spi we can afford to block on receive events
			 else we have to keep only the send events as blocking */
			if (wait_on_receive_event)
				BlockingWaitEventsMask |= DEMUX_RECEIVE_EVENT_MASK(i);
				
			if (pllad) {
				/* if we use direct reading for sections we need to process the event */
				event_list[nEvents].ModuleID = Tasks[i].demux_task;
				event_list[nEvents].Mask = SOFT_IRQ_EVENT_DEMUX_SECTION_END;
				WaitEventsMask |= DEMUX_SECTION_EVENT_MASK(i);
				nEvents++;
				if (wait_on_receive_event)
					BlockingWaitEventsMask |= DEMUX_SECTION_EVENT_MASK(i);

				/* if we use direct reading for outputs we need to process the event */
				event_list[nEvents].ModuleID = Tasks[i].demux_task;
				event_list[nEvents].Mask = SOFT_IRQ_EVENT_FILLING;
				WaitEventsMask |= DEMUX_THRESHOLD_EVENT_MASK(i);
				nEvents++;
				if (wait_on_receive_event)
					BlockingWaitEventsMask |= DEMUX_THRESHOLD_EVENT_MASK(i);
			}
		}

		/* try to send data for all tasks */
		for (i=0; i< task_count; i++) {
			enum RM_PSM_State PlaybackStatus;


			PlaybackStatus = RM_PSM_GetState(&PSMcontext, &(Tasks[i].dcc_info));

			if (PlaybackStatus == RM_PSM_Rewind) {
				RMint64 currentTime;
				RMuint64 stc;

				DCCSTCGetTime(Tasks[i].dcc_info->pStcSource, &stc, 1000);
				
				currentTime = (RMuint64)stc - Tasks[i].video_opt->first_pts_in_stream;

				if ((currentTime > (RMint64)Tasks[i].lastSTC + 1000) ||
				    (currentTime < (RMint64)Tasks[i].lastSTC - 1000)) {
					Tasks[i].lastSTC = currentTime;
					RMDBGLOG((ENABLE, "time = %llu/%llu (%ld/100)\n", currentTime, Tasks[i].play_opt->duration, (currentTime * 100) / Tasks[i].play_opt->duration));
				}
				
				if (currentTime > (RMint64)Tasks[i].play_opt->duration) {
					RMDBGLOG((ENABLE, "currentTime > duration!\n"));
					goto cleanup;
					break;
				}
				else if (currentTime <= 0) {
					RMDBGLOG((ENABLE, "currentTime <= 0\n"));
					Tasks[i].file_status = RM_ERRORENDOFFILE;
					goto signal_eos;
					break;
				}

				continue; // dont send data

			}
			
			update_hdmi(&dcc_info[i], Tasks[i].disp_opt, Tasks[i].audio_opt);
			
			if ( Tasks[i].play_opt->spi ) {
				if ( Tasks[i].play_opt->stc_compensation ) {
					/* sample code to compensate STC drift */
					StcCompensation(&Tasks[i]);
				}
				continue;
			}
			
			if ((Tasks[i].video_opt->display_cc && Tasks[i].video_opt->UseAFD) || Tasks[i].video_opt->ForceAFD) {
				// TODO instead of blind polling, wait for signal from VideoDecoder that AFD has changed
				struct EMhwlibActiveFormatDescription afd;
				err = RUAGetProperty(Tasks[i].dcc_info->pRUA, Tasks[i].dcc_info->video_decoder, 
					RMVideoDecoderPropertyID_ActiveFormat, 
					&afd, sizeof(afd));
				if (Tasks[i].video_opt->ForceAFD) {
					afd.ActiveFormatValid = Tasks[i].video_opt->afd.ActiveFormatValid;
					afd.ActiveFormat = Tasks[i].video_opt->afd.ActiveFormat;
				}
				if (RMSUCCEEDED(err) && (
					(afd.FrameAspectRatio.X && (afd.FrameAspectRatio.X != Tasks[i].video_opt->afd.FrameAspectRatio.X)) || 
					(afd.FrameAspectRatio.Y && (afd.FrameAspectRatio.Y != Tasks[i].video_opt->afd.FrameAspectRatio.Y)) || 
					(afd.ActiveFormatValid && (afd.ActiveFormat != Tasks[i].video_opt->afd.ActiveFormat)) || 
					(afd.ActiveFormatValid != Tasks[i].video_opt->afd.ActiveFormatValid)
				)) {
					fprintf(stderr, "\nReceived new content Active Format Descriptor: %salid Active Format \"%s\" (%u), Frame Aspect Ratio %lu:%lu\n", 
						afd.ActiveFormatValid ? "V" : "Inv", 
						get_afd_name(afd.ActiveFormat), 
						afd.ActiveFormat, 
						afd.FrameAspectRatio.X, 
						afd.FrameAspectRatio.Y);
					Tasks[i].video_opt->afd = afd;
					apply_active_format(Tasks[i].dcc_info->pRUA, Tasks[i].disp_opt, afd, Tasks[i].dcc_info->SurfaceID);
				}
			}
			
			/* check if the task is finished */
			if ((Tasks[i].play_opt->loop_count == 0) && (Tasks[i].play_opt->infinite_loop == FALSE))
				continue;
				
			/* any send task should be marked as blocking */
			BlockingWaitEventsMask |= DEMUX_SEND_EVENT_MASK(i);
			/* try to get new buffer if we don't have one */
			if ((Tasks[i].buf == NULL) && (Tasks[i].buffer_used == FALSE)) {
				err = RUAGetBuffer(Tasks[i].pDma, &Tasks[i].buf,  0);
				if(err != RM_OK) {
					/* no free buffer -> add an event and prepare to wait */
					event_list[nEvents].ModuleID = Tasks[i].demux_task;
					event_list[nEvents].Mask = RUAEVENT_XFER_FIFO_READY;
					WaitEventsMask |= DEMUX_SEND_EVENT_MASK(i);
					nEvents++;
				}
				else {
					/*fprintf(stderr, "%lx_GetBuffer OK\n", Tasks[i].id);*/
				}
			}

			
			if (Tasks[i].buf) {
				if (Tasks[i].buffer_used == FALSE) {
					Tasks[i].file_status = RMReadFile(Tasks[i].file, Tasks[i].buf, (1<<Tasks[i].play_opt->dmapool_log2size), &count);
					Tasks[i].buffer_used = TRUE;

					if ( !(Tasks[i].av_flags & AV_PIDS_ENABLE_FIRST_TIME) ) /* don't send inbands if PMT is not known yet */
						Tasks[i].send_inband = TRUE;

					if (Tasks[i].file_status == RM_ERRORREADFILE) {
						fprintf(stderr, "%lx_Error reading file\n", Tasks[i].id);
						goto cleanup;
					}
		
					if (Tasks[i].file_status == RM_ERRORENDOFFILE) {
						RMuint32 j;

						fprintf(stderr, "%lx_EndOfFile\n", Tasks[i].id);
					
						RUAReleaseBuffer(Tasks[i].pDma, Tasks[i].buf);
						Tasks[i].buf = NULL;
						
						ibcx.flags_tag = INBAND_COMMAND_TAG_END_SEQUENCE | INBAND_COMMAND_CONSUMED_BY_USER;
						ibcx.offset_value = 0; /* ignored */
						ibcx.output_mask = (1<<Tasks[i].videoDemuxOutputIndex);
						ibcx.offset_control = EMhwlibInbandOffset_Ignore;
						RUASetProperty(pRUA, Tasks[i].demux_task, RMGenericPropertyID_InbandCommandX, &ibcx, sizeof(ibcx), 0);
						fprintf (stderr, " ---- INBAND_COMMAND_TAG_END_SEQUENCE at file_byte_counter=0x%lx ----\n", Tasks[i].file_byte_counter);

						ibcx.flags_tag = INBAND_COMMAND_TAG_EOS | INBAND_COMMAND_CONSUMED_BY_USER;
						ibcx.offset_value = 0; /* ignored */
						ibcx.output_mask = (1<<Tasks[i].videoDemuxOutputIndex);
						
						for (j = 0; j < Tasks[i].audioInstances; j++)
							ibcx.output_mask |= ( 1 << Tasks[i].audioDemuxOutputIndex[j] );

						ibcx.offset_control = EMhwlibInbandOffset_Ignore;
						RUASetProperty(pRUA, Tasks[i].demux_task, RMGenericPropertyID_InbandCommandX, &ibcx, sizeof(ibcx), 0);
						fprintf (stderr, " ---- EOS inband at file_byte_counter=0x%lx ---- \n", Tasks[i].file_byte_counter);
						Tasks[i].wait_eos_state = 1; /* demux, video, audio, display */
						if (Tasks[i].dcc_info->pVideoSource)
							Tasks[i].wait_eos_state += 1; /* video, display */
//							Tasks[i].wait_eos_state += 2; /* video, display */
						if (!(Tasks[i].isTrickMode || Tasks[i].isIFrameMode)  &&( Tasks[i].play_opt->send_audio ==TRUE)) {  /* wait for audio if it isn't stopped as in trick mode, iframe mode or -data v mode  */
							if (Tasks[i].dcc_info->pMultipleAudioSource) {
								Tasks[i].wait_eos_state += 1; /* audio */
								DCCSetMultipleAudioBtsThreshold(Tasks[i].dcc_info->pMultipleAudioSource, 0);
							}
						}
							
						continue;
					}
				}
								
				/* ##### AES_CBC_PRECIPHER CODE BEGIN ####### */
				if (Tasks[i].test_aes_precipher)
					Tasks[i].send_inband = TRUE;
				/* ###### AES_CBC_PRECIPHER CODE END ####### */
				
				/* #### Begin DTCP code #### */
				if (Tasks[i].dtcpip_streaming)
					Tasks[i].send_inband = FALSE;
				/* #### End DTCP code #### */

				if( Tasks[i].send_inband ) {
					err = SendInbandCommands(&Tasks[i]);
					if (RMFAILED(err))
						continue; /* loop back through and try again */
					Tasks[i].send_inband = FALSE;
				}

#if defined(WITH_AACS)
				if (Tasks[i].mt_enabled &&
				    Tasks[i].mt_index < MAX_SP &&
				    Tasks[i].file_byte_counter + count > Tasks[i].mt_spn[Tasks[i].mt_index] * PACKET_SIZE) {
					/* Send MT IbC to signal beginning of new SP */
					struct InbandCommandX_type ibc;
					RMstatus err;

					ibc.flags_tag = INBAND_COMMAND_TAG_AACS;
					ibc.offset_value = Tasks[i].mt_spn[Tasks[i].mt_index] * PACKET_SIZE;
					ibc.offset_control = EMhwlibInbandOffset_Absolute;
					ibc.params.aacs.cmd = AACS_IBC_CMD_MT;
					ibc.params.aacs.spn = Tasks[i].mt_spn[Tasks[i].mt_index];
					ibc.params.aacs.slot = Tasks[i].mt_index;

					fprintf(stderr, "Send MT IbC for SPN %lu.\n", ibc.params.aacs.spn);
					err = RUASetProperty(pRUA, Tasks[i].demux_task, RMGenericPropertyID_InbandCommandX, &ibc, sizeof(ibc), 0);
					if (RMFAILED(err)) {
						fprintf(stderr, "Error sending MT IbC : %s\n", RMstatusToString(err));
						goto cleanup;
					}

					Tasks[i].mt_index++;
					while (Tasks[i].mt_index < MAX_SP && Tasks[i].mt_spn[Tasks[i].mt_index] == (unsigned) -1)
						Tasks[i].mt_index++;
				}

				if (Tasks[i].sk_enabled && Tasks[i].file_byte_counter == 0) {
					/* Send SK IbC to signal beginning of new PlayItem */
					struct InbandCommandX_type ibc;
					RMstatus err;

					ibc.flags_tag = INBAND_COMMAND_TAG_AACS;
					ibc.offset_value = 0;
					ibc.offset_control = EMhwlibInbandOffset_Absolute;
					ibc.params.aacs.cmd = AACS_IBC_CMD_PLAY_ITEM;
					ibc.params.aacs.pl = Tasks[i].sk_plid;
					ibc.params.aacs.item = Tasks[i].sk_item;

					fprintf(stderr, "Send SK IbC for %lu/%lu.\n", ibc.params.aacs.pl, ibc.params.aacs.item);
					err = RUASetProperty(pRUA, Tasks[i].demux_task, RMGenericPropertyID_InbandCommandX, &ibc, sizeof(ibc), 0);
					if (RMFAILED(err)) {
						fprintf(stderr, "Error sending SK IbC : %s\n", RMstatusToString(err));
						goto cleanup;
					}
				}
#endif /* WITH_AACS */

#if 1
				/* This code is used to display DSP usage and dump log file of audio decoding processing.
				   Get info about first audio instance. */
				if (Tasks[i].dcc_info->pMultipleAudioSource) {
					struct DCCAudioSourceHandle audioHandle;
					DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(Tasks[i].dcc_info->pMultipleAudioSource, 0, &audioHandle);
					/*{
						RMuint32 profile;					
						err = RUAGetProperty(dcc_info[i].pRUA, audioHandle.moduleID, RMGenericPropertyID_Profile,
							&profile, sizeof(profile));
						if (err == RM_OK) {
							RMDBGLOG((ENABLE, "DSP Usage task [%lu]= %lu%%\n", i, profile));
						}
					}*/

					/*{
						RMuint32 LogMode;
						RUAGetProperty(dcc_info[i].pRUA, audioHandle.moduleID, RMGenericPropertyID_AudioDecoderLog,
							&LogMode, sizeof(RMuint32));
					}*/
					{
						struct AudioDecoderInfo Ainfo;
						struct RUAEvent e;
						e.ModuleID = audioHandle.moduleID;
						e.Mask = SOFT_IRQ_EVENT_AU_DECODED;
						
						if ((err = RUAWaitForMultipleEvents(pRUA, &e, 1, 0, NULL)) == RM_OK) {
							RUAGetProperty(dcc_info[i].pRUA, e.ModuleID,
								RMGenericPropertyID_AudioDecoderStatus, &Ainfo, sizeof(struct AudioDecoderInfo));

							RMDBGLOG((ENABLE, "\n&&&&&&& Channel Assignment = %lu, channel # = %lu, lfe = %lu, sample_rate=%lu\n&&&&&&& speakerCFG=0x%lx, BassMode=%lu, Spdif=%lu, samples=%lu, errorcnt=%lu, bytecnt=0x%lx\n",
							Ainfo.ChannelAssignment, Ainfo.ChannelNumber, Ainfo.lfe, Ainfo.SampleRate,
							Ainfo.SpeakerConfig, Ainfo.BassMode, Ainfo.SpdifMode, Ainfo.SampleCount, Ainfo.ErrorCount, Ainfo.ByteCount));

						}
					}
				}
#endif
				err = RUASendData(pRUA, Tasks[i].demux_task, Tasks[i].pDma, Tasks[i].buf, count, NULL, 0);
				if (err == RM_OK) {
					Tasks[i].bitrate += count * 8;
					Tasks[i].file_byte_counter += count;
					RUAReleaseBuffer(Tasks[i].pDma, Tasks[i].buf);
					Tasks[i].buf = 0;
					Tasks[i].buffer_used = FALSE;
#if (EM86XX_MODE == EM86XX_MODEID_WITHHOST)
					if( Tasks[i].av_flags & AV_PIDS_ENABLE_FIRST_TIME ) {
						usleep(10); /* give some time for receive PCI transfer */
					}
#endif

				}
				else {
					/* no place to send buffer -> add an event and prepare to wait */
					event_list[nEvents].ModuleID = Tasks[i].demux_task;
					event_list[nEvents].Mask = RUAEVENT_XFER_FIFO_READY;
					WaitEventsMask |= DEMUX_SEND_EVENT_MASK(i);
					nEvents++;
				}
				
#ifdef	DO_CAPTURE
//				get_picture(&dcc_info[0]);
#endif

				if (0)
					{
						struct DataFIFOInfo DataFIFOInfo;
						struct XferFIFOInfo_type XferFIFOInfo;
						RMuint32 available_count = RUAGetAvailableBufferCount(Tasks[i].pDma);
						if ( available_count > 20 ) {
							RUAGetProperty(pRUA, Tasks[i].demux_task, RMGenericPropertyID_DataFIFOInfo,
								&DataFIFOInfo, sizeof(DataFIFOInfo));
							RUAGetProperty(pRUA, Tasks[i].demux_task, RMGenericPropertyID_XferFIFOInfo,
								&XferFIFOInfo, sizeof(XferFIFOInfo));
							fprintf(stderr, "%lx_RUASendData %s bc=%lx time=%lld nbuf=%ld bts: wr=%lx rd=%lx xfer: wr=%lx rd=%lx er=%lx\n",
								Tasks[i].id, (err==RM_OK)?"OK":"ERROR",
								Tasks[i].file_byte_counter,
								get_ustime() - t_start,
								available_count,
								DataFIFOInfo.Writable,  DataFIFOInfo.Readable,
								XferFIFOInfo.Writable,  XferFIFOInfo.Readable, XferFIFOInfo.Erasable);
							}
						t_start = get_ustime();
					}


			}
		} /* end "for" loop to send data */

#ifdef	DO_CAPTURE
		get_picture(&dcc_info[0]);
#endif

		for (i=0; i< task_count; i++) {
			if (Tasks[i].file_status == RM_ERRORENDOFFILE) {
				fprintf(stderr, "--- END OF FILE! ---\n");

				/* add demux eos event in list */
				event_list[nEvents].ModuleID = Tasks[i].demux_task;
				event_list[nEvents].Mask = RUAEVENT_INBAND_COMMAND;
				WaitEventsMask |= DEMUX_EOS_EVENT_MASK(i);
				if (task_count == 1)
					BlockingWaitEventsMask |= DEMUX_EOS_EVENT_MASK(i);
				else
					BlockingWaitEventsMask &= ~DEMUX_EOS_EVENT_MASK(i);
					
				nEvents++;

				/* add video eos event in list */
				event_list[nEvents].ModuleID = Tasks[i].dcc_info->video_decoder;
				event_list[nEvents].Mask = RUAEVENT_INBAND_COMMAND;
				WaitEventsMask |= VIDEO_EOS_EVENT_MASK(i);
				if (task_count == 1)
					BlockingWaitEventsMask |= VIDEO_EOS_EVENT_MASK(i);
				nEvents++;
				
#ifndef DO_CAPTURE
				/* display EOS events */
				event_list[nEvents].ModuleID = EMHWLIB_MODULE(DisplayBlock, 0);
				event_list[nEvents].Mask = EMHWLIB_DISPLAY_INBAND_COMMAND_EVENT_ID(Tasks[i].dcc_info->SurfaceID);
				WaitEventsMask |= DISPLAY_EOS_EVENT_MASK(i);
				if (task_count == 1)
					BlockingWaitEventsMask |= DISPLAY_EOS_EVENT_MASK(i);
				nEvents++;
#endif

				/* audio EOS event */
				if (Tasks[i].play_opt->send_audio==TRUE) { /* dont add  audio EOS event if audio is disabled ( '-data v') */ 
					if (Tasks[i].dcc_info->pMultipleAudioSource) {
						struct DCCAudioSourceHandle audioHandle;
						RMuint32 j;
						
						for (j = 0; j < Tasks[i].audioInstances; j++) {
							DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(Tasks[i].dcc_info->pMultipleAudioSource, j, &audioHandle);
							event_list[nEvents].ModuleID = audioHandle.moduleID;
						}
					}
					event_list[nEvents].Mask = RUAEVENT_INBAND_COMMAND;
					WaitEventsMask |= AUDIO_EOS_EVENT_MASK(i);
					if (task_count == 1)
						BlockingWaitEventsMask |= AUDIO_EOS_EVENT_MASK(i);
					nEvents++;
				}
			}
		}

	check_other_events:

		/*each task can add as much as one MAX_EVENT_COUNT_PER_TASK events - xfer_ready or eos events */
		event_index = 1 + MAX_EVENT_COUNT_PER_TASK * MAX_TASK_COUNT;
		if(nEvents == 0)
			goto process_key;
#if 1
		if (BlockingWaitEventsMask == 0)
			timeout = 0;
		else if ((WaitEventsMask & BlockingWaitEventsMask) != BlockingWaitEventsMask) {
			/*as long as one task can go on, don't wait too much for the other events */
			timeout = 0;
		}
		else { // ((WaitEventsMask & BlockingWaitEventsMask) == BlockingWaitEventsMask) {
			/*all tasks are blocked: we can afford to spend some time waiting */
			timeout = TIMEOUT_100MS;
		}
#else
		timeout = 0;
#endif

#ifdef	DUMP_EVENT_MASKS

		fprintf(stderr, "WaitEventsMask=%lx BlockingWaitEventsMask=%lx\n", WaitEventsMask, BlockingWaitEventsMask);
		if (timeout)
			fprintf(stderr, "\nT");
		else
			fprintf(stderr, ".");
			
		fprintf(stderr, "(%lx 0:%lx_%lx 1:%lx_%lx 2:%lx_%lx 3:%lx_%lx 4:%lx_%lx 5:%lx_%lx )\n",
			nEvents,
			event_list[0].ModuleID, event_list[0].Mask,
			event_list[1].ModuleID, event_list[1].Mask,
			event_list[2].ModuleID, event_list[2].Mask,
			event_list[3].ModuleID, event_list[3].Mask,
			event_list[4].ModuleID, event_list[4].Mask,
			event_list[5].ModuleID, event_list[5].Mask
			);
		
#endif	// DUMP_EVENT_MASKS

#if 1 
		if ( RUAWaitForMultipleEvents(pRUA, event_list, nEvents, timeout, &event_index) != RM_OK) {
			/* no events to process yet */
#ifdef	DO_CAPTURE
//			get_picture(&dcc_info[0]);
#endif
			goto process_key;
		}
#else

		if (WaitForFrames(&dcc_info[0])) {
		}

#endif


//	process_events:

		if (event_list[event_index].ModuleID == EMHWLIB_MODULE(CPUBlock, 0)) {
			struct CPUBlock_Error_type Error;
			while (1) { /* get all the errors */
				err = RUAGetProperty(pRUA, CPUBlock, RMCPUBlockPropertyID_Error, &Error, sizeof(Error));
				if ( err != RM_OK) {
					RMDBGLOG((DISABLE,"RMGenericPropertyID_Error failed err=%d\n", err));
					break;
				}
				else {
					RMDBGLOG((ENABLE,"SOFT_IRQ_EVENT_ERROR: module_id=0x%lx error=%d time=%ld\n",
						Error.module_id, Error.error, Error.time));
					if ( (Error.error == RM_UNHANDLED_VIDEO_PCR_DISCONTINUITY) ||
					     (Error.error == RM_UNHANDLED_AUDIO_PCR_DISCONTINUITY) ) {
						RMDBGLOG((ENABLE,"UNHANDLED_PCR_DISCONTINUITY - restart by Stop/Play\n"));
						/* identify what instance */
						for (i=0; i< task_count; i++) {
							if (Tasks[i].id == EMHWLIB_MODULE_INDEX(Error.module_id))
								break;
						}
						if(i >= task_count) {
							fprintf(stderr, "Unidentified UNHANDLED_PCR_DISCONTINUITY i=%ld ??? \n", i);
							continue;
						}
						err = HwStop(&Tasks[i]);
						if (RMFAILED(err)) {
							fprintf(stderr, "%lx_HwStop after UNHANDLED_PCR_DISCONTINUITY err=%d\n", Tasks[i].id, err);
							goto cleanup;
						}
						err = HwPlay(&Tasks[i]);
						if (RMFAILED(err)) {
							fprintf(stderr, "%lx_HwPlay after UNHANDLED_PCR_DISCONTINUITY err=%d\n", Tasks[i].id, err);
							goto cleanup;
						}
					}
				}
			}
		}
		else if (event_list[event_index].Mask == RUAEVENT_INBAND_COMMAND) {
			/* inband events - EOS */
			if (EMHWLIB_MODULE_CATEGORY(event_list[event_index].ModuleID) == DemuxTask) {
				/* one demux EOS came, identify what instance */
				struct InbandCommandX_type ibcx;
				for (i=0; i< task_count; i++) {
					if (Tasks[i].id == EMHWLIB_MODULE_INDEX(event_list[event_index].ModuleID))
						break;
				}
				if(i >= task_count) {
					fprintf(stderr, "Unidentified Demux inband event ??? \n");
					goto cleanup;
				}
				while (1) { /* the EOS inband was set with INBAND_COMMAND_CONSUMED_BY_USER */
					err = RUAGetProperty(pRUA, event_list[event_index].ModuleID, RMGenericPropertyID_InbandCommandX, &ibcx, sizeof(ibcx));
					if ( err != RM_OK) {
						//fprintf(stderr, "%lx_demux_inband_event without tag - hwlib already process it\n", Tasks[i].id);
						break;
					}
					else if ((ibcx.flags_tag & 0xff) == INBAND_COMMAND_TAG_EOS) {
						Tasks[i].wait_eos_state--;
						fprintf(stderr, "---%lx_WaitForEOS demux OK %ld times event_index=%lx\n", Tasks[i].id, Tasks[i].nTimes, event_index);
						WaitEventsMask &= ~DEMUX_EOS_EVENT_MASK(i);
						BlockingWaitEventsMask &= ~DEMUX_EOS_EVENT_MASK(i);
					}
					else {
						fprintf(stderr, "%lx_demux_inband_event with tag=%lx\n", Tasks[i].id, ibcx.flags_tag);
					}
				}
			}
			else if (EMHWLIB_MODULE_CATEGORY(event_list[event_index].ModuleID) == VideoDecoder) {
				/* one video EOS came, identify what instance */
				for (i=0; i< task_count; i++) {
					if (Tasks[i].dcc_info->video_decoder == event_list[event_index].ModuleID)
						break;
				}
				if(i >= task_count) {
					fprintf(stderr, "Unidentified Video inband event ??? \n");
					goto cleanup;
				}
				while (1) { /* the EOS inband was set with INBAND_COMMAND_CONSUMED_BY_USER */
					err = RUAGetProperty(pRUA, event_list[event_index].ModuleID, RMGenericPropertyID_InbandCommandX, &ibcx, sizeof(ibcx));
					if ( err != RM_OK) {
						//fprintf(stderr, "%lx_video_inband_event without tag - hwlib already process it\n", Tasks[i].id);
						break;
					}
					else if ((ibcx.flags_tag & 0xff) == INBAND_COMMAND_TAG_EOS) {
						Tasks[i].wait_eos_state--;
						fprintf(stderr, "---%lx_WaitForEOS video OK %ld times event_index=%lx\n", Tasks[i].id, Tasks[i].nTimes, event_index);
						WaitEventsMask &= ~VIDEO_EOS_EVENT_MASK(i);
						BlockingWaitEventsMask &= ~VIDEO_EOS_EVENT_MASK(i);
					}
					else {
						fprintf(stderr, "%lx_video_inband_event with tag=%lx\n", Tasks[i].id, ibcx.flags_tag);
					}
				}
			}
			else if (EMHWLIB_MODULE_CATEGORY(event_list[event_index].ModuleID) == AudioDecoder) {
				/* one audio EOS came, identify what instance */
				for (i=0; i< task_count; i++) {
					if (dcc_info->pMultipleAudioSource) {
						struct DCCAudioSourceHandle audioHandle;
						RMuint32 j;

						for (j = 0; j < Tasks[i].audioInstances; j++) {
							DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(Tasks[i].dcc_info->pMultipleAudioSource, j, &audioHandle);
							if (audioHandle.moduleID == event_list[event_index].ModuleID)
								break;
						}
						if (audioHandle.moduleID == event_list[event_index].ModuleID)
							break;
					}
				}
				if(i >= task_count) {
					fprintf(stderr, "Unidentified Audio inband event ??? \n");
					goto cleanup;
				}
				while (1) { /* the EOS inband was set with INBAND_COMMAND_CONSUMED_BY_USER */
					err = RUAGetProperty(pRUA, event_list[event_index].ModuleID, RMGenericPropertyID_InbandCommandX, &ibcx, sizeof(ibcx));
					if ( err != RM_OK) {
						//fprintf(stderr, "%lx_audio_inband_event without tag - hwlib already process it\n", Tasks[i].id);
						break;
					}
					else if ((ibcx.flags_tag & 0xff) == INBAND_COMMAND_TAG_EOS) {
						Tasks[i].wait_eos_state--;
						fprintf(stderr, "---%lx_WaitForEOS audio OK %ld times event_index=%lx\n", Tasks[i].id, Tasks[i].nTimes, event_index);
						WaitEventsMask &= ~AUDIO_EOS_EVENT_MASK(i);
						BlockingWaitEventsMask &= ~AUDIO_EOS_EVENT_MASK(i);
					}
					else {
						fprintf(stderr, "%lx_audio_inband_event with tag=%lx\n", Tasks[i].id, ibcx.flags_tag);
					}
				}
			}
		}
		else if (event_list[event_index].ModuleID == EMHWLIB_MODULE(DisplayBlock, 0)) {
			/* one display EOS came, identify what instance */
			for (i=0; i< task_count; i++) {
				if (EMHWLIB_DISPLAY_INBAND_COMMAND_EVENT_ID(Tasks[i].dcc_info->SurfaceID) == event_list[event_index].Mask)
					break;
			}
			if(i >= task_count) {
				fprintf(stderr, "Unidentified display EOS ??? \n");
				goto cleanup;
			}
			while (1) { /* the EOS inband was set with INBAND_COMMAND_CONSUMED_BY_USER */
				err = RUAGetProperty(pRUA, Tasks[i].dcc_info->video_decoder, RMVideoDecoderPropertyID_DisplayInbandCommandX, &ibcx, sizeof(ibcx));
				if ( err != RM_OK) {
					//fprintf(stderr, "%lx_display_inband_event without tag - hwlib already process it\n", Tasks[i].id);
					break;
				}
				else if ((ibcx.flags_tag & 0xff) == INBAND_COMMAND_TAG_EOS) {
					Tasks[i].wait_eos_state--;
					fprintf(stderr, "---%lx_WaitForEOS display OK %ld times event_index=%lx\n", Tasks[i].id, Tasks[i].nTimes, event_index);
					WaitEventsMask &= ~DISPLAY_EOS_EVENT_MASK(i);
					BlockingWaitEventsMask &= ~DISPLAY_EOS_EVENT_MASK(i);
				}
				else {
					fprintf(stderr, "%lx_display_inband_event with tag=%lx\n", Tasks[i].id, ibcx.flags_tag);
				}
			}
		}
		else if ( (event_list[event_index].Mask == SOFT_IRQ_EVENT_XFER_RECEIVE_READY)
		       || (event_list[event_index].Mask == SOFT_IRQ_EVENT_DEMUX_SECTION_END)
		       || (event_list[event_index].Mask == SOFT_IRQ_EVENT_FILLING) ) {
			/* one receive event came, identify what instance */
			for (i=0; i< task_count; i++) {
				if (Tasks[i].id == EMHWLIB_MODULE_INDEX(event_list[event_index].ModuleID))
					break;
			}
			if(i >= task_count) {
				fprintf(stderr, "Unidentified SOFT_IRQ_EVENT_XFER_RECEIVE_READY ??? \n");
				goto cleanup;
			}
			if (event_list[event_index].Mask == SOFT_IRQ_EVENT_XFER_RECEIVE_READY) {
				/*fprintf(stderr, "%ld_SOFT_IRQ_EVENT_XFER_RECEIVE_READY\n", Tasks[i].id);*/
				WaitEventsMask &= ~DEMUX_RECEIVE_EVENT_MASK(i);
				err = ReceiveDataAndSaveInFilePerTask(&Tasks[i]);
				if (RMFAILED(err)) {
					fprintf(stderr, "ReceiveDataAndSaveInFilePerTask ProcessKey quit or error\n");
					goto cleanup;
				}
			}
			else if (event_list[event_index].Mask == SOFT_IRQ_EVENT_FILLING) {
				RMuint32 irq_output_source;
				//fprintf(stderr, "%ld_SOFT_IRQ_EVENT_FILLING\n", Tasks[i].id);
				WaitEventsMask &= ~DEMUX_THRESHOLD_EVENT_MASK(i);
				RUAGetProperty(pRUA, Tasks[i].demux_task, RMDemuxTaskPropertyID_IrqThresholdOutputSource,
					&irq_output_source, sizeof(irq_output_source));
				SaveDemuxOutputPerTaskWithoutDMA(&Tasks[i], irq_output_source);
			}
			else { // SOFT_IRQ_EVENT_DEMUX_SECTION_END
				RMuint32 irq_output_source;
				//fprintf(stderr, "%ld_SOFT_IRQ_EVENT_DEMUX_SECTION_END\n", Tasks[i].id);
				WaitEventsMask &= ~DEMUX_SECTION_EVENT_MASK(i);
				RUAGetProperty(pRUA, Tasks[i].demux_task, RMDemuxTaskPropertyID_IrqSectionOutputSource,
					&irq_output_source, sizeof(irq_output_source));
				SaveDemuxOutputPerTaskWithoutDMA(&Tasks[i], irq_output_source);
			}

			if( Tasks[i].pat ) {
				Tasks[i].pat = FALSE;
				if (Tasks[i].file && (Tasks[i].av_flags & AV_PIDS_ENABLE_FIRST_TIME) ) {
					/* add this code to handle files that have only one PMT packet at the very beggining of the file */
					err = HwStop(&Tasks[i]);
					if (RMSeekFile(Tasks[i].file, 0, RM_FILE_SEEK_START) != RM_OK) {
						fprintf(stderr, " error seeking file to beginning after PAT detection\n");
						goto cleanup;
					}
					
				/* # AES_CBC_PRECIPHER TEST CODE BEGIN # */
				if (Tasks[i].test_aes_precipher)
					aes_state = 0;
				/* # AES_CBC_PRECIPHER TEST CODE END # */	
					
				/* #### Begin DTCP code #### */
				if (dtcpCookieHandle)
					dtcpCookieHandle->dtcp_inband_state = 0;
				 /* #### End DTCP code #### */
					
					Tasks[i].file_status = RM_OK;
					err = HwPlay(&Tasks[i]);
				}
				/* TODO - add code to handle PAT change */
			}
			if( Tasks[i].pmt) {
				Tasks[i].pmt = FALSE;
				PmtSetAVList(&Tasks[i]);
				if ( RMFAILED(CheckAVPlaybackAgainstAVList(&Tasks[i])) ) {
					if ( Tasks[i].av_flags & AV_PIDS_ENABLE_FIRST_TIME) {
						/* first time playback seek file to start and open the decoders */
						if (Tasks[i].file) {
							RMDBGLOG((ENABLE, "seek to 0x%lx\n", FILE_PLAYBACK_START_POSITION));
							if (RMSeekFile(Tasks[i].file, FILE_PLAYBACK_START_POSITION, RM_FILE_SEEK_START) != RM_OK) {
								fprintf(stderr, "   m>   error seeking file to beginning\n");
								goto cleanup;
							}
							
							/* ### AES_CBC_PRECIPHER CODE BEGIN ###*/
							if (Tasks[i].test_aes_precipher)
								aes_state = 0;
							/* ### AES_CBC_PRECIPHER CODE END ### */
					
							/* #### Begin DTCP code #### */
							if (dtcpCookieHandle)
								dtcpCookieHandle->dtcp_inband_state = 0;
							 /* #### End DTCP code #### */

							Tasks[i].file_status = RM_OK;
							fprintf(stderr, "   m>   seek file to beginning\n");
						}
					}
					SetPidFilterForAVPlayback(&Tasks[i]); /* HwStop, change Pids, HwPlay */
					goto process_key;
				}
			}

			if ( Tasks[i].play_opt->spi ) {
				if (Tasks[i].app_type == multi2_decryption) {
					if ( Tasks[i].ecm ) {
						RMuint32 i=0;
						Tasks[i].ecm = FALSE;
						/* TODO - add code to handle ECM change */
						for( i=0; i<Tasks[i].cipher_count; i++ ) {
							if (Tasks[i].arib_key_table[i*2].new_key) {
								Multi2KeySetup( &(Tasks[i]), OUTBAND_COMMAND, i*2, EVEN_KEY);
								Tasks[i].arib_key_table[i*2].new_key = FALSE;
							}
							if (Tasks[i].arib_key_table[i*2+1].new_key) {
								Multi2KeySetup( &(Tasks[i]), OUTBAND_COMMAND, i*2+1, ODD_KEY);
								Tasks[i].arib_key_table[i*2+1].new_key = FALSE;
							}
						}
					}
				}
				if (Tasks[i].app_type == dvbcsa_decryption) {
					RMuint32 index;
					struct dvb_csa_key *key_table;
					struct context_per_task *context = &Tasks[i];

					for (index = 0; index < context->key_table_size; index++) {
						key_table = ((struct dvb_csa_key *)context->pkey_table) + index;
						if ((key_table->renew) && (context->file_byte_counter >= key_table->key_byte_counter)) {
							err = DvbKeyOutband(context, key_table->ecm_entry, key_table->scrambling, key_table->key, context->key_size);
							if (RMFAILED(err)) {
								fprintf (stderr, "dvb key inband failure\n");
								return RM_ERROR;
							}
		 					key_table->renew = FALSE; 
						}
					}
				}
			}
		}
		else if (event_list[event_index].Mask == SOFT_IRQ_EVENT_XFER_FIFO_READY ) {
			/* one send event came, identify what instance */
			for (i=0; i< task_count; i++) {
				if (Tasks[i].id == EMHWLIB_MODULE_INDEX(event_list[event_index].ModuleID))
					break;
			}

			if(i >= task_count) {
				fprintf(stderr, "Unidentified SOFT_IRQ_EVENT_XFER_FIFO_READY ??? \n");
				goto cleanup;
			}
			WaitEventsMask &= ~DEMUX_SEND_EVENT_MASK(i);
			BlockingWaitEventsMask &= ~DEMUX_SEND_EVENT_MASK(i);
			goto process_key;
		}
		else {
			fprintf(stderr, "\n\nUnhandled event ModuleID=0x%lx Event=0x%lx\n", event_list[event_index].ModuleID, event_list[event_index].Mask);
		}

		if ((i < task_count) && (Tasks[i].wait_eos_state == 0)) {
		signal_eos:
#ifdef	DO_CAPTURE
			goto cleanup;
#else
			/* check if all tasks are finished in order to exit before sending HwStop/HwPlay */
			if ( CheckAllTaskReady(&Tasks[i]) )
				goto cleanup;
			
//			Tasks[i].nTimes++;
			fprintf(stderr, "%lx_WaitForEOS OK %ld times event_index=%lx\n", Tasks[i].id, Tasks[i].nTimes, event_index);

			RMDBGLOG((ENABLE, "EOS -> STOP\n"));

			err = HwStop(&Tasks[i]);
			if (RMFAILED(err)) {
				fprintf(stderr, "%lx_HwStop after EOS err=%d\n", Tasks[i].id, err);
				goto cleanup;
			}
			RMDBGLOG((ENABLE, "EOS -> PLAY\n"));
			err = HwPlay(&Tasks[i]);
			if (RMFAILED(err)) {
				fprintf(stderr, "%lx_HwPlay after EOS err=%d\n", Tasks[i].id, err);
				goto cleanup;
			}
			RMDBGLOG((ENABLE, "set playback state to playing\n"));
			RM_PSM_SetState(&(PSMcontext), pdcc_info, RM_PSM_Playing);
#endif
		}
		if (WaitEventsMask && ((WaitEventsMask & BlockingWaitEventsMask) == BlockingWaitEventsMask))
			goto check_other_events;

		if ( timedbg ) {
			RMuint64 t_end = get_ustime();
			fprintf(stderr, "total= %lld\n", t_end - t_start);
		}	
	} /* end "while" to send/receive data for all tasks */


 cleanup:

#ifdef	DO_CAPTURE
	WaitForFrames(&dcc_info[0]);
#endif

	printf("Elapsed time = %lld\n",get_ustime() - startTime );
	if( Tasks[0].play_opt->waitexit ) {
		RMascii key;
		fprintf(stderr, "press q key again if you really want to stop & quit\n");

		while ( !(RMGetKeyNoWait(&key) && ((key == 'q') || (key =='Q'))) ) {
			for (i=0; i< task_count; i++) {
				ReceiveDataAndSaveInFilePerTask(&Tasks[i]);
			}
		}
	}


	RMDBGLOG((ENABLE, "closing...\n"));

#ifdef WITH_MONO
	RMDCCInfo(NULL); // invalidate DCC context
#endif

	
#ifndef WITH_MONO
	/* #### Begin DTCP code #### */
	if (dtcpCookieHandle) {
		err = term_DTCP_session(dtcpCookieHandle, pRUA);
		if (RMFAILED(err)) 
			fprintf(stderr, "Cannot terminate DTCP-IP session !!!\n");
	}
	/* #### End DTCP code #### */
#endif // WITH_MONO	
	
	for (i=0; i< task_count; i++) {
		if (Tasks[i].file) {
			RMCloseFile(Tasks[i].file);
			Tasks[i].file = NULL;
		}

		if (dcc_info[i].pDemuxTask) {
			err = DCCStopDemuxTask(dcc_info[i].pDemuxTask);
			if (RMFAILED(err)) {
				fprintf(stderr, "Cannot stop demux %d\n", err);
			}
		}
		
		if (dcc_info[i].pVideoSource) {
			err = DCCStopVideoSource(dcc_info[i].pVideoSource, DCCStopMode_LastFrame);
			if (RMFAILED(err)) {
				fprintf(stderr, "%lx_Cannot stop video decoder err=%d\n", Tasks[i].id, err);
			}
	
			err = DCCCloseVideoSource(dcc_info[i].pVideoSource);
			if (RMFAILED(err)) {
				fprintf(stderr, "%lx_Error cannot close video decoder err=%d\n", Tasks[i].id, err);
			}
			clear_video_options(&dcc_info[i], Tasks[i].video_opt);
#ifndef WITH_MONO
			clear_display_options(&dcc_info[i], Tasks[i].disp_opt);
#endif
		}

		if (dcc_info[i].pMultipleAudioSource) {
			err = DCCStopMultipleAudioSource(dcc_info[i].pMultipleAudioSource);
			if (RMFAILED(err)) {
				fprintf(stderr, "%lx_Cannot stop multiple audio decoder err=%d\n", Tasks[i].id, err);
			}
			RMDBGLOG((ENABLE, "***************** CLOSE multiple audio source\n"));
			err = DCCCloseMultipleAudioSource(dcc_info[i].pMultipleAudioSource);
			if (RMFAILED(err)) {
				fprintf(stderr, "%lx_Error cannot close multiple audio decoder err=%d\n", Tasks[i].id, err);
			}
		}

		if (dcc_info[i].pStcSource) {
			DCCSTCStop(dcc_info[i].pStcSource); // hack - stop STC after audio is stopped
			err = DCCSTCClose(dcc_info[i].pStcSource);
			if (RMFAILED(err)) {
				fprintf(stderr, "Error cannot close STC %d\n", err);
			}
		}

		err = ResetOutputTablePerTask(&Tasks[i]);

		if (Tasks[i].app_type == program_stream_parsing) {
			DisablePesTablePerTask(pRUA, Tasks[i].demux_task, Tasks[i].pes_table, Tasks[i].pes_table_count);
			if (Tasks[i].pes_table)
				RMFree(Tasks[i].pes_table);
		}
		else {
			DisablePidTablePerTask(pRUA, Tasks[i].demux_task, Tasks[i].pid_table, Tasks[i].pid_table_count);
			FreePidTablePerTask(pRUA, Tasks[i].demux_task, Tasks[i].pid_table, Tasks[i].pid_table_count);
			FreeSectionTable(&Tasks[i]);
			RMFree(Tasks[i].pid_table);
			RMFree(Tasks[i].match_section_table);
		}
	
		FreeKeyAndCipherTable(&Tasks[i]);
		
		if (Tasks[i].pDma) {
			err = RUAClosePool(Tasks[i].pDma);
			Tasks[i].pDma = NULL;
			if (RMFAILED(err))
				fprintf(stderr, "%lx_Error cannot close dmapool err=%d\n", Tasks[i].id, err);
		}
		CloseOutputTablePerTask(&Tasks[i]);
		err = DCCCloseDemuxTask(Tasks[i].dcc_info->pDemuxTask);
		if (RMFAILED(err)) {
			fprintf(stderr, "Error cannot close demux %d\n", err);
		}

		if (Tasks[i].stcd) 
			fclose(Tasks[i].stcd);
		
		if (Tasks[i].dcc_info->ttx_sw_decoder)
			RMTTXClose(Tasks[i].dcc_info->ttx_sw_decoder);
	}

#ifndef WITH_MONO
	RMTermExit();

	if (pgbus)
		gbus_close(pgbus);
	if (pllad)
		llad_close(pllad);
	err = DCCClose(pDCC);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot close DCC %d\n", err);
	}
	err = RUADestroyInstance(pRUA);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot destroy RUA instance %d\n", err);
		return -1;
	}
#endif

	return 0;
}

/* Take basename and add .log to it... */
void compute_crclog_filename(RMascii* bsFilename, RMascii* logFilename) {
	RMascii*	pName = basename(bsFilename);
	RMascii*	p;
	RMascii*	pHomeEnv;

	RMDBGLOG((SENDDBG, "filename = %s basename = %s\n", bsFilename, pName));

	*logFilename = '\0';

	p = strrchr(pName, (int)'.');

	if (p) {
		if ((pHomeEnv = getenv("HOME"))) {
			strcpy(logFilename, pHomeEnv);
			strcat(logFilename, "/");
		}
		strncat(logFilename, pName, p - pName);
		strcat(logFilename, ".log");
		RMDBGLOG((SENDDBG, "Logfilename = %s\n", logFilename));
				
	} else {
		strcpy(logFilename, pName);
	}
	
	return;
}

#ifdef	DO_CAPTURE
RMstatus WaitForFrames(struct dcc_context *pSendContext) {
	RMbool		bDone = FALSE;
	RMstatus	result = RM_OK;
	RMuint32	to_cnt = 0;

	RMDBGLOG((SENDDBG, "WaitForFrames()\n"));

	while (!bDone) {
		if (get_picture(pSendContext) == 1) {
			to_cnt = 0;
		} else {
			to_cnt++;
			usleep(100);
		}

		if (to_cnt > 100) {
			bDone = TRUE;
		}
	}

	return result;
}
#endif

