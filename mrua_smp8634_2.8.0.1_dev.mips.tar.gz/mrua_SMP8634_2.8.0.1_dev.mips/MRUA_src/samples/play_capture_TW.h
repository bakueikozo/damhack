#ifndef _PLAY_CAPTURE_TW_H
#define _PLAY_CAPTURE_TW_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define ALLOW_OS_CODE 1
//#include "../dcc/include/dcc.h"
#include "../rua/include/rua.h"
#include "../rua/include/rua_property.h"
#include "../rmcore/include/rmstatustostring.h"
#include "../emhwlib_hal/pll/include/pll_hal.h"
#include "command_ids.h"
#include "get_key.h"
#include "common.h"
// to enable or disable the debug messages of this source file, put 1 or 0 below
#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

// zoom helper defines and functions
#undef ZOOM_0
#undef ZOOM_1
#define ZOOM_0 4096  // 0% zoom position
#define ZOOM_1 8192  // 100% zoom position

#define AUDIO_FIFO_SIZE (2048*1024)
#define XFER_FIFO_COUNT (32)


#if 1
// Perform Hamming 8/4 check and return data in low 4 bits, or 0xFF on error
RMuint8 unham[256] = {
	0x01,0xff,0x01,0x01,0xff,0x00,0x01,0xff, 0xff,0x02,0x01,0xff,0x0a,0xff,0xff,0x07,
		0xff,0x00,0x01,0xff,0x00,0x00,0xff,0x00, 0x06,0xff,0xff,0x0b,0xff,0x00,0x03,0xff,
		0xff,0x0c,0x01,0xff,0x04,0xff,0xff,0x07, 0x06,0xff,0xff,0x07,0xff,0x07,0x07,0x07,
		0x06,0xff,0xff,0x05,0xff,0x00,0x0d,0xff, 0x06,0x06,0x06,0xff,0x06,0xff,0xff,0x07,
		0xff,0x02,0x01,0xff,0x04,0xff,0xff,0x09, 0x02,0x02,0xff,0x02,0xff,0x02,0x03,0xff,
		0x08,0xff,0xff,0x05,0xff,0x00,0x03,0xff, 0xff,0x02,0x03,0xff,0x03,0xff,0x03,0x03,
		0x04,0xff,0xff,0x05,0x04,0x04,0x04,0xff, 0xff,0x02,0x0f,0xff,0x04,0xff,0xff,0x07,
		0xff,0x05,0x05,0x05,0x04,0xff,0xff,0x05, 0x06,0xff,0xff,0x05,0xff,0x0e,0x03,0xff,
		0xff,0x0c,0x01,0xff,0x0a,0xff,0xff,0x09, 0x0a,0xff,0xff,0x0b,0x0a,0x0a,0x0a,0xff,
		0x08,0xff,0xff,0x0b,0xff,0x00,0x0d,0xff, 0xff,0x0b,0x0b,0x0b,0x0a,0xff,0xff,0x0b,
		0x0c,0x0c,0xff,0x0c,0xff,0x0c,0x0d,0xff, 0xff,0x0c,0x0f,0xff,0x0a,0xff,0xff,0x07,
		0xff,0x0c,0x0d,0xff,0x0d,0xff,0x0d,0x0d, 0x06,0xff,0xff,0x0b,0xff,0x0e,0x0d,0xff,
		0x08,0xff,0xff,0x09,0xff,0x09,0x09,0x09, 0xff,0x02,0x0f,0xff,0x0a,0xff,0xff,0x09,
		0x08,0x08,0x08,0xff,0x08,0xff,0xff,0x09, 0x08,0xff,0xff,0x0b,0xff,0x0e,0x03,0xff,
		0xff,0x0c,0x0f,0xff,0x04,0xff,0xff,0x09, 0x0f,0xff,0x0f,0x0f,0xff,0x0e,0x0f,0xff,
		0x08,0xff,0xff,0x05,0xff,0x0e,0x0d,0xff, 0xff,0x0e,0x0f,0xff,0x0e,0x0e,0xff,0x0e,
};

RMascii LatinG0[128] = {
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', // 0
		' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', // 1
		' ', '!', '"', '#', '$', '%', '&', '`', '(', ')', '*', '+', ',', '-', '.', '/', // 2
		'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?', // 3
		'@', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', // 4
		'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\', ']', '^', '_', // 5
		'e', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', // 6
		'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~', '#', // 7
};

#endif

enum capture_chip {
		cap_NoChip, 
		cap_ADV7402, 
		cap_SAA7119,
		cap_WM8775, 
		cap_MSP34x5,
		cap_TW9919,
		cap_AD9380,
};

enum capture_port {
		cap_CVBS1=0, 
		cap_Direct, 
		cap_SVideo1, 
		cap_Tuner1, 
		cap_Component1, 
		cap_VGA, 
		cap_HDMI0, 
		cap_CVBS2, 
		cap_SVideo2, 
		cap_Tuner2, 		
		cap_ScartCVBS1, 
		cap_ScartCVBS2, 
		cap_ScartRGB1, 
		cap_ScartRGB2, 
		cap_Component2, 
		cap_HDMI1, 
		
};

enum capture_board {
		cap_kissjamoplasma, 
		cap_sigma775avinput, 
		cap_sigma760e1hdref, 
		cap_sigma760e2hdlcd, 
		cap_sigma844e1dtv, 
		cap_pioneer809e1video, 
		cap_sigma895e1,
};


struct avi_info {
	RMbool valid;
	RMuint32 color_format;
	RMuint32 active_format;
	RMbool h_bar;
	RMbool v_bar;
	RMuint32 scan_info;
	RMuint32 color_space;
	RMuint32 aspect_ratio;
	RMuint32 scaling;
	RMuint32 vic;
	RMuint32 ext_col;       // EC
	RMbool it_content;      // ITC
	
	RMuint32 pixel_rep;
	RMuint32 top;
	RMuint32 quantisation;  // Q
	RMuint32 bottom;
	RMuint32 left;
	RMuint32 right;
};

enum hdmi_mode {
	mode_unknown, 
		mode_HDMI, 
		mode_DVI
};

struct local_cmdline {
	RMbool zoom_force;
	RMuint32 zoom_x;
	RMuint32 zoom_y;
	RMuint32 zoom_w;
	RMuint32 zoom_h;
	RMuint32 zoomstep;
	struct EMhwlibDisplayWindow *output_window;
	RMuint32 arg_vbi;
	RMbool parse_anc;
	RMbool print_anc;
	RMbool dump_vbi;
	RMbool i2c_init;
	RMuint32 i2c_module;
	enum capture_board i2c_board;
	enum capture_port i2c_port;
	enum capture_chip i2c_video_chip;
	RMuint8 i2c_video_dev;
	RMuint32 i2c_video_delay;
	enum capture_chip i2c_audio1_chip;
	RMuint8 i2c_audio1_dev;
	RMuint32 i2c_audio1_delay;
	enum capture_chip i2c_audio2_chip;
	RMuint8 i2c_audio2_dev;
	RMuint32 i2c_audio2_delay;
	RMbool enable_i2c_cc;
	RMbool enable_i2c_wss;
	RMbool ccfifo_print;
	RMuint32 use_soft_cc_decoder;
	RMuint32 ccfifo_id_in;
	RMuint32 ccfifo_id_send;
	RMuint32 ccfifo_id_out;
	RMuint32 ccfifo_addr_in;
	RMuint32 ccfifo_addr_out;
	RMuint32 VBIFlags;
	RMuint32 VBIPTS;
	RMuint32 VBISequence;
	RMuint32 VBISize;
	RMuint32 VBIOffs;
	RMuint16 *pVBIChunk;
	RMuint16 *pVBIData;
	FILE *vbidump;
	RMbool update;
	RMbool use_gpio_fid;
	RMbool invert_fid;	
	RMbool last_hotplug;
	struct ReceiveObject_type *pR;
	struct RUABufferPool *pDmaReceive;
	RMbool force_active_format;
//	enum DH_active_format_aspect_ratio active_format;
	enum EMhwlibActiveFormat active_format;
	
	RMbool force_wide_screen;
	RMbool wide_screen;
	RMuint32 wss_odd;
	RMuint32 wss_even;
	
	RMbool last_hdcp_ok;
	RMbool last_power;
	RMbool last_sync;
	RMbool last_clock;
	RMbool last_auth;
	RMbool last_crypt;
	RMuint32 cable_eq;
	struct avi_info last_avi;
	
	RMuint32 CurrChStat;
	RMuint16 CurrPc;
	RMuint32 overscan_crop_amount;
	RMbool last_isrc2;
	RMuint8 last_isrc[32];
	RMuint32 overscan_crop;  // percentage of frame size to crop around edge for overscanned pictures
	RMuint8 last_isrc_header;
	RMbool force_overscan_crop;
	RMbool new_avi;
	RMbool intr_debug;
	RMbool update_videomode;
	RMbool follow_vfreq;
	RMbool verbouse;
	RMbool green_bg;
	RMuint8 intr_mask[6];
	enum hdmi_mode hdmi_mode;  // TRUE: HDMI with info frames, audio etc. FALSE: DVI mode
	RMbool upsample_from_422;
	
} local_opt[2];


//void Write_Gpio(enum GPIOId_type pin,RMbool val);								   
//void Write_Gpio(struct RUA *pInstance, enum GPIOId_type pin,RMbool val);
#endif
