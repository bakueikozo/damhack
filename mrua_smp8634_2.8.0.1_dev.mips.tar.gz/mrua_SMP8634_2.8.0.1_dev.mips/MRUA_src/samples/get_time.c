/*
 *
 * Copyright (c) Sigma Designs, Inc. 2002. All rights reserved.
 *
 */

/**
	@file get_time.c
	@brief common code for play_video, play_demux, play_hwdemux applications
	
	@author Christian Wolff, Aurelia Popa-Radu
   	@ingroup mruasamplecode
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>

#define ALLOW_OS_CODE 1
#include "../rua/include/rua.h"
#include "../rua/include/rua_property.h"

#include "common.h"

RMuint64 get_ustime(void)
{
	static RMbool firsttimehere=TRUE;
	static struct timeval timeorigin;

	struct timeval now;

	// the first time, set the origin.
	if (firsttimehere) {
		gettimeofday(&timeorigin,NULL);
		firsttimehere=FALSE;
	}

	gettimeofday(&now,NULL);

	return 
		(RMuint64)(
		 (
		  (RMint64)now.tv_sec
		  -(RMint64)timeorigin.tv_sec
		  )*1000000LL
		 +
		 ( 
		  (RMint64)now.tv_usec
		  -(RMint64)timeorigin.tv_usec
		  )
		 );
}

