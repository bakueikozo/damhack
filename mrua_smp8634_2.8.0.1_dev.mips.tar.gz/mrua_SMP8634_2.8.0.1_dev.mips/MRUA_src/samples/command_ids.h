/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   command_ids.h
  @brief  list of commands handled by play_xxx

  @author Julien Soulier
  @date   2005-03-24
*/

#ifndef __COMMAND_IDS_H__
#define __COMMAND_IDS_H__

/* no key */
#define KEY_CMD_NONE1 '\n'
#define KEY_CMD_NONE2 '\0'

/* playback commands */
#define KEY_CMD_PLAY         'p'
#define KEY_CMD_PAUSE        ' '
#define KEY_CMD_STOP         's'
#define KEY_CMD_STOP_ZERO    'z'
#define KEY_CMD_FAST_FWD     '+'
#define KEY_CMD_SLOW_FWD     '-'
#define KEY_CMD_REWIND       'R'
#define KEY_CMD_IFRAME_FWD   ']'
#define KEY_CMD_IFRAME_BWD   '['	
#define KEY_CMD_SEEK         'f'
#define KEY_CMD_SPEED_FACTOR '='
#define KEY_CMD_NEXT_PICTURE 'n'
#define KEY_CMD_QUIT         'q'
#define KEY_CMD_MANU_YES     'y'
#define KEY_CMD_NEXT_TRACK   'N'
#define KEY_CMD_PREV_TRACK   'P'
#define KEY_CMD_TIME_SHIFT   'j'
#define KEY_CMD_DISABLE_STC  'O'


/* audio commands */
#define KEY_CMD_DUALMODE_AUDIO 'E'
#define KEY_CMD_VOLUME_PLUS    'V'
#define KEY_CMD_VOLUME_MINUS   'v'
#define KEY_CMD_VOLUME_MUTE    '_'
#define KEY_CMD_SPEED_UP       '>'
#define KEY_CMD_SPEED_DOWN     '<'

/* display commands */
#define KEY_CMD_CONTRAST_PLUS     'C'
#define KEY_CMD_CONTRAST_MINUS    'c'
#define KEY_CMD_SATURATION_PLUS   'T'
#define KEY_CMD_SATURATION_MINUS  't'
#define KEY_CMD_BRIGHTNESS_PLUS   'B'
#define KEY_CMD_BRIGHTNESS_MINUS  'b'
#define KEY_CMD_HUE_PLUS          'H'
#define KEY_CMD_HUE_MINUS         'h'
#define KEY_CMD_DEFAULT_OUTPUT    '7'
#define KEY_CMD_HALF_OUTPUT       '1'
#define KEY_CMD_PLUS_OUTPUT_SIZE  '9'
#define KEY_CMD_MINUS_OUTPUT_SIZE '3'
#define KEY_CMD_LEFT_OUTPUT       '4'
#define KEY_CMD_RIGHT_OUTPUT      '6'
#define KEY_CMD_BOTTOM_OUTPUT     '2'
#define KEY_CMD_TOP_OUTPUT        '8'
#define KEY_CMD_SWITCH_OUTPUT     '5'
#define KEY_CMD_ENABLE_OUTPUT     '0'
#define KEY_CMD_DUMP_OSD_INFO     'd'
#define KEY_CMD_NONLINEAR_PLUS    'W'
#define KEY_CMD_NONLINEAR_MINUS   'w'
#define KEY_CMD_ROTATE_PICTURE    'r'
#define KEY_CMD_DAC_ON_OFF        'x'


/* demux commands */
#define KEY_CMD_SWITCH_SPI_FILE   'K'
#define KEY_CMD_CHANGE_CHANNEL    'k'
#define KEY_CMD_PAT_INFO          'i'
#define KEY_CMD_CHANGE_PMT        'm'
#define KEY_CMD_CYCLE_AUDIO       'a' // it'll cycle thru audio streams (WMA)
#define KEY_CMD_CHANGE_AUDIO      'l' // it'll let you choose the stream
#define KEY_CMD_CHANGE_VIDEO      'X'
#define KEY_CMD_CHANGE_AUDIO_PID  'A'

/* debug commands */
#define KEY_CMD_I2C 'I'
#define KEY_CMD_GBUS 'g'
#define KEY_CMD_VIDEOMODE 'M'
#define KEY_CMD_HIGHLIGHT 'L'
#define KEY_CMD_STCDRIFT '|'
#define KEY_CMD_DISPLAY_INFO 'Y'
#define KEY_CMD_VSYNCTIMES 'Z'
#define KEY_CMD_FILTER_SELECT '*'
#define KEY_CMD_HDCP_TOGGLE '#'

/* multiple streams commands */
#define KEY_CMD_SELECT_DECODER  '?' /* subsequent commands will go to the selected decoder (for
				       play_multiple_audio, play_multiple_video, play_mosaic) */

/* NeroDigital specific navigation */
#define KEY_CMD_NERO_NEXT_CHAPTER 'S'               /* will seek to next chapter */
#define KEY_CMD_NERO_PREV_CHAPTER 'D'               /* will seek to prev chapter */
#define KEY_CMD_NERO_CYCLE_SUBTITLE 'G'             /* will cycle subtitles, off,1,2..off */

#define KEY_CMD_GET_DEBUG_INFO '!'             /* 
						  will show debugging
						  info such as picture
						  rate*/


/* debug keys */

/* 
 * keys specific to applications (don't use them as generic commands)
 */

/* play_mosaic*/
/* 'F' --> toggle fullscreen mode */

#endif // __COMMAND_IDS_H__
