#ifndef _I2C_H
#define _I2C_H

#include "../rmdef/rmdef.h"
#include "../rua/include/rua.h"
#include "../rua/include/rua_property.h"
#include "common.h"

//RMuint32 I2C_ModuleID = I2C;

RMstatus init_i2c(
				  struct RUA *pInstance, 
				  RMuint8 delay, 
				  RMuint8 dev, 
				  RMuint8 i2c_data[][2], 
				  RMuint32 data_size);

RMstatus read_i2c(
				  struct RUA *pInstance, 
				  RMuint8 delay, 
				  RMuint32 dev, 
				  RMuint32 addr, 
				  RMuint32 *data);
RMstatus write_i2c(
				   struct RUA *pInstance, 
				   RMuint8 delay, 
				   RMuint32 dev, 
				   RMuint32 addr, 
				   RMuint32 data);

RMstatus read_i2c_data(
					   struct RUA *pInstance, 
					   RMuint8 delay, 
					   RMuint32 dev, 
					   RMuint32 addr, 
					   RMuint8 *data, 
					   RMuint32 data_size);

RMstatus read_i2c_dsp_msp4450g(
							   struct RUA *pInstance, 
							   RMuint8 delay, 
							   RMuint32 dev, 
							   RMuint32 sub,
							   RMuint32 addr, 
							   RMuint32 *data);
RMstatus write_i2c_dsp_msp4450g(
								struct RUA *pInstance, 
								RMuint8 delay, 
								RMuint32 dev, 
								RMuint32 sub,
								RMuint32 addr, 
								RMuint32 data);

RMstatus read_i2c_control_msp4450g(
								   struct RUA *pInstance, 
								   RMuint8 delay, 
								   RMuint32 dev, 
								   RMuint32 sub,
								   RMuint32 *data);
RMstatus write_i2c_control_msp4450g(
									struct RUA *pInstance, 
									RMuint8 delay, 
									RMuint32 dev, 
									RMuint32 sub,
									RMuint32 data);


RMstatus init_i2c_WM(
					 struct RUA *pInstance, 
					 RMuint8 delay, 
					 RMuint8 dev, 
					 RMuint16 i2c_data[][2], 
					 RMuint32 data_size);

#endif

