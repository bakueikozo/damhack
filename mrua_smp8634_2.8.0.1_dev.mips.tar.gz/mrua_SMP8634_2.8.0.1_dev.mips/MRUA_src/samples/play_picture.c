/*
 *
 * Copyright (c) Sigma Designs, Inc. 2002. All rights reserved.
 *
 */

/**
	@file play_picture.c
	@brief sample application to access the Mambo chip and display a BMP/JPEG picture on the graphic plane
	
	@author Pascal Cannenterre
   	@ingroup dccsamplecode
*/

/*#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
*/
#include "sample_os.h"

#define ALLOW_OS_CODE 1
#include "common.h"

#if ((EM86XX_CHIP==EM86XX_CHIPID_TANGO15)&&(EM86XX_MODE==EM86XX_MODEID_STANDALONE))
#include "rua_memory.h"
#endif 

#define KEYFLAGS (SET_KEY_DISPLAY | SET_KEY_DEBUG)

static struct playback_cmdline  *play_opt;
static struct display_cmdline *disp_opt;
#ifndef WITH_MONO

static void show_usage(char *progname)
{
	show_playback_options();
	show_display_options();
	
	fprintf(stderr, "------------------------------------------------------------\n");
	fprintf(stderr, "Minimum cmd line: %s <filename.jpg/filename.bmp>\n", progname);
	fprintf(stderr, "------------------------------------------------------------\n");

	exit(1);
}

static void parse_cmdline(int argc, char *argv[])
{
	int i;
	RMstatus err;

	if (argc < 2) 
		show_usage(argv[0]);
	
	i = 1;
	while ((argc > i)) {
		if (argv[i][0] != '-') {
			if (play_opt->filename == NULL) {
				play_opt->filename = argv[i];
				i++;
			}
			else
				show_usage(argv[0]);
		}
		else {
			err = parse_playback_cmdline(argc, argv, &i, play_opt);
			if (err == RM_ERROR) 
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_display_cmdline(argc, argv, &i, disp_opt);
			if (RMFAILED(err))
				show_usage(argv[0]);
		}
	}

	if (play_opt->filename == NULL)
		show_usage(argv[0]);
}
#endif /*WITH_MONO*/


#ifdef WITH_MONO
int main_picture(struct mono_info *mono)
{
#else
int main(int argc, char *argv[])
{
	/*for MONO compatibility, always access these variables through the global pointers*/
	struct playback_cmdline playback_options; /* access through play_opt */
	struct display_cmdline  display_options;  /* access through disp_opt */
	struct display_context disp_info;
	struct dh_context dh_info = {0,};

#endif

	RMstatus err;
	static struct dcc_context dcc_info = {0,};
	struct osd_picture_info osd_picture = {0};
	struct DCCOSDProfile osd_profile;


#ifdef WITH_MONO
	/*make the mono arguments global*/
	play_opt = mono->play_opt;
	disp_opt = mono->disp_opt;
	dcc_info.pRUA = mono->pRUA;
	dcc_info.pDCC = mono->pDCC;
	osd_picture.scaler = mono->osd_scaler;
	set_default_out_window(&(osd_picture.source_window));
	set_default_out_window(&(osd_picture.output_window));
	dcc_info.disp_info = NULL;
	dcc_info.route = DCCRoute_Main;
#else
	play_opt = &playback_options;
	disp_opt = &display_options;
	dcc_info.disp_info = &disp_info;
	dcc_info.dh_info = &dh_info;

	init_playback_options(play_opt);
	init_display_options(disp_opt);
	disp_opt->dh_info = &dh_info;
	parse_cmdline(argc, argv);
	dcc_info.route = disp_opt->route;

	err = RUACreateInstance(&dcc_info.pRUA, play_opt->chip_num);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error creating RUA instance! %d\n", err);
		return -1;
	}

 	if (disp_opt->dump_osd_dir != NULL) {
		RMbool dirty_bits = FALSE;
		while ((err = RUASetProperty(dcc_info.pRUA, DisplayBlock, RMDisplayBlockPropertyID_EnableDirtyBits, &dirty_bits, sizeof(dirty_bits), 0)) == RM_PENDING);
		if (RMFAILED(err)) {
			fprintf(stderr, "Error setting disable_dirty flag %d\n", err);
			return err;
		}
	}
	
	err = DCCOpen(dcc_info.pRUA, &dcc_info.pDCC);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error Opening DCC! %d\n", err);
		return -1;
	}

	err = DCCInitChainEx(dcc_info.pDCC, disp_opt->init_mode);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot initialize microcode %d\n", err);
		return -1;
	}

	display_key_usage(KEYFLAGS);
#endif

#if ((EM86XX_CHIP==EM86XX_CHIPID_TANGO15)&&(EM86XX_MODE==EM86XX_MODEID_STANDALONE))
	c_malloc_init( (void *)dcc_info.pRUA );
#endif

	dcc_info.chip_num = play_opt->chip_num;

	err = apply_playback_options(&dcc_info, play_opt);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot set playback options %d\n", err);
		goto cleanup2;
	}

	osd_picture.route = dcc_info.route;
	osd_picture.enable = TRUE;
	osd_picture.filename = play_opt->filename;
	osd_picture.dramblock = 0;
	osd_picture.alpha = 128;
	osd_picture.alpha_merge = FALSE;
	osd_picture.zoom = FALSE;
	osd_picture.color_space = EMhwlibColorSpace_None;
	osd_picture.orientation = FRTop_FCLeft;
	osd_picture.nonlinearmode.Width = 0;
	osd_picture.nonlinearmode.Level = 0;
	osd_picture.blackstrip.Horizontal = 4096;
	osd_picture.blackstrip.Vertical = 4096;
	osd_picture.cutstrip.Horizontal = 4096;
	osd_picture.cutstrip.Vertical = 4096;

#ifndef WITH_MONO
	
	/* this fields are filled by parse_display_options */
	osd_picture.scaler = disp_opt->osd_pictures[0].scaler;
	osd_picture.source_window = disp_opt->osd_pictures[0].source_window;
	osd_picture.output_window = disp_opt->osd_pictures[0].output_window;
	osd_picture.zoom = disp_opt->osd_pictures[0].zoom;
	osd_picture.color_space = disp_opt->osd_pictures[0].color_space;

	osd_picture.alpha_filename = disp_opt->osd_pictures[0].alpha_filename;
	osd_picture.alpha_merge = disp_opt->osd_pictures[0].alpha_merge;
	osd_picture.alpha = disp_opt->osd_pictures[0].alpha;

	osd_picture.blackstrip = disp_opt->blackstrip;
	osd_picture.cutstrip = disp_opt->cutstrip;

	osd_picture.lock_scaler = disp_opt->lock_scaler;
	
	err = apply_display_options(&dcc_info, disp_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set display options %d\n", err));
		return -1;
	}
	
	dcc_info.disp_info->osd_enable[0] = TRUE;
	dcc_info.disp_info->osd_window[0] = osd_picture.output_window;
	dcc_info.disp_info->active_window = &(dcc_info.disp_info->osd_window[0]);
	err = DCCGetScalerModuleID(dcc_info.pDCC, osd_picture.route, DCCSurface_OSD, osd_picture.scaler, &(dcc_info.disp_info->osd_scaler[0]));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get surface to display OSD source %d\n", err));
		return err;
	}
	
	err = apply_osd_pictureX(&dcc_info, &osd_picture, &osd_profile, &(dcc_info.pOSDSource[0]), disp_opt);
#else
	err = apply_osd_picture(&dcc_info, &osd_picture, &osd_profile, &(dcc_info.pOSDSource[0]));
#endif
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot open osd source %s\n", RMstatusToString(err)));
		return err;
	}

#ifndef WITH_MONO
	if (disp_opt->dump_osd_dir != NULL) {
		RMuint32 lutAddr = 0;

		err = RUAGetProperty(dcc_info.pRUA, dcc_info.disp_info->osd_scaler[0], RMGenericPropertyID_LUTAddress, &lutAddr, sizeof(lutAddr));
		dumpBitmapInfo(&dcc_info, dcc_info.pOSDSource[0], &osd_profile, lutAddr, disp_opt->dump_osd_dir);
		dump_dvi_init(&dcc_info, disp_opt);
		
	}
	
	RMTermInit(TRUE);    // don't allow ctrl-C and the like ...
	RMSignalInit(NULL, NULL);  // ... but catch other termination signals to call RMTermExit()
#endif

#ifdef WITH_MONO
	RMDCCInfo(&dcc_info); // pass DCC context to application
#endif

	do {
		RMuint32 cmd;
		err = process_key(&dcc_info, &cmd, KEYFLAGS);
		if (RMFAILED(err)) {
			fprintf(stderr, "Error while processing key %d\n", err);
			break;
		}
		switch(cmd) {
		case RM_QUIT:
		case RM_STOP:
			goto cleanup;
			break;
		case RM_ROTATE_PICTURE:
			err = DCCCloseVideoSource(dcc_info.pOSDSource[0]);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot close osd source %s\n", RMstatusToString(err)));
				return err;
			}
			dcc_info.pOSDSource[0] = NULL;
			/* there are 8 possible orientations */
			osd_picture.orientation &= 0x7;
			osd_picture.orientation++;

			err = apply_osd_picture(&dcc_info, &osd_picture, NULL, &(dcc_info.pOSDSource[0]));
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot open osd source %s\n", RMstatusToString(err)));
				return err;
			}
			
		default:
			usleep(50*1000);
			break;
		}
		update_hdmi(&dcc_info, disp_opt, NULL);
	} while(1);

cleanup:
#ifndef WITH_MONO
	RMTermExit();
#endif
cleanup2:
	err = DCCCloseVideoSource(dcc_info.pOSDSource[0]);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot close osd source %s\n", RMstatusToString(err)));
		return err;
	}
	dcc_info.pOSDSource[0] = NULL;

	/* jpeg decoding may force a different source window */
	{
		RMuint32 scaler;

		err = DCCGetScalerModuleID(dcc_info.pDCC, osd_picture.route, DCCSurface_OSD, osd_picture.scaler, &scaler);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot get surface to display OSD source %d\n", err));
			return RM_ERROR;
		}
		
		set_default_out_window(&(osd_picture.source_window));
		while ((err = RUASetProperty(dcc_info.pRUA, scaler, RMGenericPropertyID_ScalerInputWindow, &(osd_picture.source_window), sizeof(osd_picture.source_window), 0)) == RM_PENDING);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set scaler input window on OSD surface %d\n", err));
			return err;
		}
		
		while ((err = RUASetProperty(dcc_info.pRUA, scaler, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot validate scaler input window %d\n", err));
			return err;
		}
	}

#ifndef WITH_MONO
	clear_display_options(&dcc_info, disp_opt);

	if (disp_opt->dump_osd_dir != NULL) {
		RMbool dirty_bits = TRUE;
		while ((err = RUASetProperty(dcc_info.pRUA, DisplayBlock , RMDisplayBlockPropertyID_EnableDirtyBits, &dirty_bits, sizeof(dirty_bits), 0)) == RM_PENDING);
		if (RMFAILED(err)) {
			fprintf(stderr, "Error setting disable_dirty flag %d\n", err);
			return err;
		}
	}

	err = DCCClose(dcc_info.pDCC);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot close DCC %d\n", err);
		return -1;
	}
#endif //#ifndef WITH_MONO

#if ((EM86XX_CHIP==EM86XX_CHIPID_TANGO15)&&(EM86XX_MODE==EM86XX_MODEID_STANDALONE))
	c_malloc_uninit( (void *)dcc_info.pRUA );
#endif

#ifndef WITH_MONO
	err = RUADestroyInstance(dcc_info.pRUA);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot destroy RUA instance %d\n", err);
		return -1;
	}
#endif /*WITH_MONO*/
	return 0;
}

