/*
 *
 * Copyright (c) Sigma Designs, Inc. 2002. All rights reserved.
 *
 */

/**
   @file play_psfdemux.c
   @brief sample application for hardware demux of EM86xx
	
   @author Aurelia Popa-Radu
   @ingroup dccsamplecode
*/

#include "../samples/sample_os.h"

#define ALLOW_OS_CODE 1
#include "../dcc/include/dcc.h"
#include "../samples/common.h"
#include "command_ids.h"

#include "play_psfdemux_helper.h"

#include "../rmlibcw/include/rmsocket.h"

// this will add a field to the context, see psfdemux_common.h
#define MULTICAST 1 
#define MAX_MULTICAST_STREAMS 10

#include "psfdemux_common.h"


/**************************** macros ******************************/

#define KEYFLAGS (SET_KEY_DISPLAY | SET_KEY_PLAYBACK | SET_KEY_AUDIO | SET_KEY_DEBUG | SET_KEY_SPI)


#define DMA_BUFFER_SIZE_LOG2	15	// 32k buffer
#define DMA_BUFFER_COUNT	32	// 32 * 32k = 0x200000 = 1M 
#define DEMUX_FIFO_SIZE		(1 << DMA_BUFFER_SIZE_LOG2) * DMA_BUFFER_COUNT	// match the dma pool for standalone
#define DEMUX_XFER_FIFO_COUNT	DMA_BUFFER_COUNT	// same as dma pool buffers - this application sends complete buffer every time. 

#define VIDEO_FIFO_SIZE		( 1792*1024) /* "-vfifo 1792", default same value as in play_demux and play_hwdemux */
#define AUDIO_FIFO_SIZE		(  128*1024)
#define SPU_FIFO_SIZE		(  104*1024)


#define DUMP_SOCKET_DATA	0
#define	FORCE_DECRYPTION	1

#define SOCKET_BLOCKING_READ_SLEEP 3000

//#define AUTO_CHANGE_CHANNEL

#ifdef WITH_MONO
#define MAX_TASK_COUNT		1
#else
#define MAX_TASK_COUNT		3
#endif

#define MAX_EVENT_COUNT_PER_TASK     5 /* 4 events (demux, video, display, audio) for file playback and 1 receive event per task */
#define CPU_ERROR_EVENT_MASK        (1<<0)
#define DEMUX_RECEIVE_EVENT_MASK(i) (1<<(1+0+i*MAX_EVENT_COUNT_PER_TASK))
#define DEMUX_SEND_EVENT_MASK(i)    (1<<(1+1+i*MAX_EVENT_COUNT_PER_TASK))
#define DEMUX_EOS_EVENT_MASK(i)     (1<<(1+1+i*MAX_EVENT_COUNT_PER_TASK))
#define VIDEO_EOS_EVENT_MASK(i)     (1<<(1+2+i*MAX_EVENT_COUNT_PER_TASK))
#define DISPLAY_EOS_EVENT_MASK(i)   (1<<(1+3+i*MAX_EVENT_COUNT_PER_TASK))
#define AUDIO_EOS_EVENT_MASK(i)     (1<<(1+4+i*MAX_EVENT_COUNT_PER_TASK))

#define VIDEO_PID_FROM_CMDLINE    1
#define PCR_PID_FROM_CMDLINE      2
#define AUDIO_PID_FROM_CMDLINE    4
#define AV_PIDS_ENABLE_FIRST_TIME 8

#define LOOP_KEY_TABLE /* Allow the Key table to loop when it reaches the end */

#if defined(WITH_AACS)
#define MAX_SP			6
#define PACKET_SIZE		192
#define AACS_IBC_CMD_MT		2
#define AACS_IBC_CMD_PLAY_ITEM  4
#endif

/* to enable or disable the debug messages of this source file, put 1 or 0 below */
#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

#if 0
#define CALLDBG ENABLE
#else
#define CALLDBG DISABLE
#endif


struct dvb_csa_key arte_dvb_key_table[] = {
	{ TRUE, 0, EMhwlibScramblingBits_10, { 0xfc, 0x32, 0x54, 0x76, 0x94, 0xba, 0xdc, 0xfe },
	 { 0x0F, 0x0E, 0x0D, 0x0C, 0x0B, 0x0A, 0x09, 0x08, 0x07, 0x06, 0x05, 0x04, 0x03, 0x02, 0x01, 0x00},
	  ECM0_SECTION_ENTRY }, /* arte key starts from LSB (byte 0) */
};

struct dvb_csa_key cweven_dvb_key_table[] = {
	{ FALSE, 0xffffffff, EMhwlibScramblingBits_None, { 0x34, 0x18, 0x3c, 0xe0, 0x41, 0xc2, 0x03, 0x7c },
	 { 0x00, 0x00, 0x00, 0x00, 0x91, 0x01, 0x02, 0x05, 0xFF, 0x02, 0x00, 0x17, 0x14, 0x00, 0x6E, 0x26}, },
};

struct dvb_csa_key cwodd_dvb_key_table[] = {
	{ FALSE, 0xffffffff, EMhwlibScramblingBits_None, { 0x7e, 0x7e, 0x00, 0x00, 0xc8, 0x03, 0xc6, 0xff },
	 { 0x00, 0x00, 0x00, 0x00, 0x91, 0x01, 0x02, 0x05, 0xFF, 0x02, 0x00, 0x17, 0x15, 0x00, 0x8F, 0x26}, },
};
	
struct dvb_csa_key ecm1_dvb_key_table[] = {
	{ TRUE, 0, EMhwlibScramblingBits_11, { 0x8b, 0xbe, 0xba, 0x13, 0x69, 0xb2, 0xfb, 0xbc },
	 { 0x0F, 0x0E, 0x0D, 0x0C, 0x0B, 0x0A, 0x09, 0x08, 0x07, 0x06, 0x05, 0x04, 0x03, 0x02, 0x01, 0x00},
	  ECM0_SECTION_ENTRY }, /* 1ECM key starts from LSB (byte 0) */
};

struct dvb_csa_key ecm4_dvb_key_table[] = {
	/* to prove that ECM parsing is Ok invalidate key_byte_counter and scrambling settings */
	{  FALSE, 0xffffffff, EMhwlibScramblingBits_None, /*0x00000000, EMhwlibScramblingBits_10,*/ { 0x5e, 0x2d, 0x29, 0x08, 0xbd, 0x2d, 0x61, 0x2f },
	 { 0x00, 0x02, 0x2D, 0x5E, 0xE4, 0x00, 0x49, 0x15, 0x09, 0x04, 0x00, 0x00, 0x01, 0x4D, 0x04, 0x4E}, }, /* 4ECM key starts from LSB (byte 0) */
	{  FALSE, 0xffffffff, EMhwlibScramblingBits_None, /*0x00E3F3F0, EMhwlibScramblingBits_11,*/ { 0x5c, 0x2c, 0x28, 0x08, 0xba, 0x2c, 0x60, 0x2e },
	 { 0x00, 0x02, 0x2C, 0x5C, 0xE4, 0x00, 0x45, 0x15, 0x09, 0x04, 0x00, 0x00, 0x01, 0x4D, 0x04, 0x4E}, },
	{  FALSE, 0xffffffff, EMhwlibScramblingBits_None, /*0x01E61c00, EMhwlibScramblingBits_10,*/ { 0x62, 0x2f, 0x2b, 0x08, 0xbf, 0x2f, 0x63, 0x2d },
	 { 0x00, 0x02, 0x2F, 0x62, 0xE4, 0x00, 0x51, 0x15, 0x09, 0x04, 0x00, 0x00, 0x01, 0x4D, 0x04, 0x4E}, },
	{  FALSE, 0xffffffff, EMhwlibScramblingBits_None, /*0x02e56880, EMhwlibScramblingBits_11,*/ { 0x60, 0x2e, 0x2a, 0x08, 0xbc, 0x2e, 0x62, 0x2c },
	 { 0x00, 0x02, 0x2E, 0x60, 0xE4, 0x00, 0x4D, 0x15, 0x09, 0x04, 0x00, 0x00, 0x01, 0x4D, 0x04, 0x4E}, },
};

struct dvb_csa_key vgs3_key_table[] = {
	/* to prove that ECM parsing is Ok invalidate key_byte_counter and scrambling settings */
	{  FALSE, 0xffffffff, EMhwlibScramblingBits_None, { 0x7A, 0x03, 0xFF, 0x78, 0x74, 0x80, 0x01, 0xF3},
	 { 0x00, 0x00, 0x00, 0x00, 0x91, 0x01, 0x02, 0x05, 0xFF, 0x02, 0x00, 0x17, 0x64, 0x00, 0xBA, 0x26}, }, /* vgs3 key starts from LSB (byte 0) */
	{  FALSE, 0xffffffff, EMhwlibScramblingBits_None, { 0x8B, 0x3F, 0x0E, 0x3E, 0x7E, 0x00, 0x78, 0x06},
	 { 0x00, 0x00, 0x00, 0x00, 0x91, 0x01, 0x02, 0x05, 0xFF, 0x02, 0x00, 0x17, 0x65, 0x00, 0xC0, 0x26}, },
	{  FALSE, 0xffffffff, EMhwlibScramblingBits_None, { 0x20, 0x60, 0x00, 0xC0, 0x00, 0x00, 0x00, 0x00},
	 { 0x00, 0x00, 0x00, 0x00, 0x91, 0x01, 0x02, 0x05, 0xFF, 0x02, 0x00, 0x17, 0x66, 0x00, 0xC6, 0x26}, },
	{  FALSE, 0xffffffff, EMhwlibScramblingBits_None, { 0xAF, 0x00, 0xE0, 0xCF, 0xF8, 0x00, 0x00, 0xF8},
	 { 0x00, 0x00, 0x00, 0x00, 0x91, 0x01, 0x02, 0x05, 0xFF, 0x02, 0x00, 0x17, 0x67, 0x00, 0xCC, 0x26}, },
};



static RMstatus HwPlay(struct context_per_task *context);
static RMstatus HwStop(struct context_per_task *context);

	

static void printTimeOfDay(struct timeval now)
{
	RMuint64 secondsPerMinute = 60;
	RMuint64 secondsPerHour = 60 * secondsPerMinute;
	RMuint64 secondsPerDay = 24 * secondsPerHour;
	RMuint64 today, h, m;

	today = (now.tv_sec - ((now.tv_sec / secondsPerDay) * secondsPerDay));

	h = today / secondsPerHour;
	today -= h * secondsPerHour;
	m = today / secondsPerMinute;
	today -= m * secondsPerMinute;
	
	fprintf(stderr, "time is %02llu:%02llu:%02llu.%llu\n", h, m, today, (RMuint64)now.tv_usec);

}


#define GET_DATA_FIFO_INFO(pRUA, ModuleId, checkStarvation)		\
	{								\
		struct DataFIFOInfo DataFIFOInfo;			\
		RMreal fullness;					\
		RUAGetProperty(pRUA, ModuleId, RMGenericPropertyID_DataFIFOInfo, &DataFIFOInfo, sizeof(DataFIFOInfo)); \
		fullness = (RMreal)((100./DataFIFOInfo.Size)*DataFIFOInfo.Readable); \
		fprintf(stderr, "Data %lx: st=%08lx sz=%ld wr=%ld rd=%ld --> f : %.02f\n", ModuleId, DataFIFOInfo.StartAddress,	\
			DataFIFOInfo.Size, DataFIFOInfo.Writable,  DataFIFOInfo.Readable, fullness); \
		if ((fullness < 2) && checkStarvation) {		\
			struct timeval now;				\
									\
			gettimeofday(&now, NULL);			\
			RMDBGLOG((ENABLE, "close to starvation at\n")); \
			printTimeOfDay(now);				\
		}							\
	}								\


#define GET_XFER_FIFO_INFO(pRUA, ModuleId, checkStarvation)		\
	{								\
		struct XferFIFOInfo_type XferFIFOInfo;			\
		RMreal fullness;					\
		RUAGetProperty(pRUA, ModuleId, RMGenericPropertyID_XferFIFOInfo, &XferFIFOInfo, sizeof(XferFIFOInfo)); \
		fullness = (RMreal)((100./XferFIFOInfo.Size)*XferFIFOInfo.Readable); \
		fprintf(stderr, "XFER %lx: st=%08lx sz=%ld wr=%ld rd=%ld er=%lx --> f : %.02f	\n", ModuleId, XferFIFOInfo.StartAddress, \
			XferFIFOInfo.Size, XferFIFOInfo.Writable,  XferFIFOInfo.Readable, XferFIFOInfo.Erasable, fullness); \
		if ((fullness < 2) && checkStarvation) {		\
			struct timeval now;				\
									\
			gettimeofday(&now, NULL);			\
			RMDBGLOG((ENABLE, "close to starvation at\n")); \
			printTimeOfDay(now);				\
		}							\
	}								\


#define MONITOR_INTERVAL_US 250000

static void monitor(struct context_per_task *context, RMbool alwaysShow)
{	
	/* the bitrate reading of this probe is accurate only if the blocking call is RUASendData */

	struct timeval now;	
	static struct timeval last;	
	static int first = 1;
	RMuint64 elapsed; 	
	RMuint64 ptime; 	
	struct dcc_context *dcc_info = context->dcc_info;

	gettimeofday(&now, NULL);
	elapsed = (now.tv_sec - last.tv_sec) * 1000000;		
	elapsed += (now.tv_usec - last.tv_usec);
	if (elapsed > MONITOR_INTERVAL_US || first || alwaysShow){
		RMuint64 bitrate = (RMuint64)context->bitrate * 1000000;
		bitrate /= elapsed;

		context->meanBitrate += bitrate;
		context->meanCount++;

		DCCSTCGetTime(dcc_info->pStcSource, &ptime, 90000);			
		fprintf(stderr, "\n*****************************\n");
		fprintf(stderr, "timeofday %llu.%llu secs since epoch\n", (RMuint64)now.tv_sec, (RMuint64)now.tv_usec);
		printTimeOfDay(now);

		fprintf(stderr, "STC = %llu (%llu secs)\n", ptime, (ptime/90000));
		
		fprintf(stderr, "socket read speed %llu bytes/sec (%llu bits/sec), readTime %llu tries %lu\n", 
			context->readSpeed, 
			context->readSpeed * 8,
			context->readTime, 
			context->tries);
		context->readSpeed = 0;
		context->readTime = 0;
		context->tries = 0;

		fprintf(stderr, "Demux :\n"); 
		GET_DATA_FIFO_INFO(dcc_info->pRUA, context->demux_task, FALSE);
		GET_XFER_FIFO_INFO(dcc_info->pRUA, context->demux_task, FALSE);

		fprintf(stderr, "bitrate: mean %llu bit/sec, pseudo-instantaneus %llu bit/sec (%lu bytes/%llu us)\n", 
			context->meanBitrate / context->meanCount,
			bitrate, 
			context->bitrate >> 3, 
			elapsed);

		fprintf(stderr, "Video :\n"); 			
		GET_DATA_FIFO_INFO(dcc_info->pRUA, dcc_info->video_decoder, TRUE);
		GET_XFER_FIFO_INFO(dcc_info->pRUA, dcc_info->video_decoder, TRUE);
			
		fprintf(stderr, "Audio :\n"); 			
		GET_DATA_FIFO_INFO(dcc_info->pRUA, dcc_info->audio_decoder, TRUE);
		GET_XFER_FIFO_INFO(dcc_info->pRUA, dcc_info->audio_decoder, TRUE);
		fprintf(stderr, "*****************************\n");			
		gettimeofday(&last, NULL);
		first = 0;
		context->bitrate = 0;
		fflush(stderr);
		
	}					        

	return;
}





/****************************** global variables ******************************/

/* these should be made local */
static RMuint32			task_count = 0;
static struct dcc_context       *pdcc_info[MAX_TASK_COUNT];
static struct context_per_task	Tasks[MAX_TASK_COUNT] = {{0,},}; 
static struct RM_PSM_Context    PSMcontext;
static RMuint32			output_count_per_task;
static RMuint32			idle_port = 0xff;
static RMbool			timedbg = FALSE;
enum AudioDecoder_Codec_type    stream_type_6 = AudioDecoder_Codec_DTS;


#ifndef WITH_MONO
/* these can stay global as they are only used by the standalone play_psfdemux app */
static RMbool			load_ucode = TRUE;
static struct playback_cmdline  playback_options[MAX_TASK_COUNT]; 
static struct display_cmdline   display_options[MAX_TASK_COUNT]; 
static struct video_cmdline     video_options[MAX_TASK_COUNT]; 
static struct audio_cmdline     audio_options[MAX_TASK_COUNT]; 
static struct demux_cmdline     demux_options[MAX_TASK_COUNT]; 
static struct display_context   disp_info[MAX_TASK_COUNT]; 
static struct dh_context        dh_info[MAX_TASK_COUNT] = {{0,},}; 
#endif

static RMbool global_dump_socket_data = FALSE;

#if DUMP_SOCKET_DATA
static FILE *global_saveFile[MAX_TASK_COUNT];
#endif

static RMstatus InitPidTablePerTask(struct context_per_task *context)
{
	RMstatus err;
	RMuint32 i;

	RMDBGLOG((CALLDBG, "initPIDTablePerTask (context @0x%08lx)\n", (RMuint32)context));

#ifdef USE_HW_FIXED_PID_ENTRY
	/* set the fixed Pid entries available only for EM8634 */
	struct EMhwlibFixedPidEntry_type fixed_entry;
	struct EMhwlibOutputMask_type out;
	RMuint32 dummy;
	
	RMDBGLOG((CALLDBG, "initPIDTablePerTask - useHWFixedPIDEntry\n"));

	/* PAT */
	fixed_entry.input_type = EMhwlibPid_Ts;
	fixed_entry.flags = TS_FLAGS;
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PATPidEntry, &fixed_entry, sizeof(fixed_entry), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_PATPidEntry"));
		return err;
	}
	out.output_mask[0] = PAT_OUTPUT_MASK;
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PATPidEntryAddOutputs, &out, sizeof(out), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_PATPidEntryAddOutputs"));
		return err;
	}
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PATPidEntryEnable, &dummy, sizeof(dummy), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_PATPidEntryEnable"));
		return err;
	}
	/* CAT */
	fixed_entry.input_type = EMhwlibPid_Ts;
	fixed_entry.flags = TS_FLAGS;
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_CATPidEntry, &fixed_entry, sizeof(fixed_entry), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_CATPidEntry"));
		return err;
	}
	out.output_mask[0] = CAT_OUTPUT_MASK;
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_CATPidEntryAddOutputs, &out, sizeof(out), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_CATPidEntryAddOutputs"));
		return err;
	}
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_CATPidEntryEnable, &dummy, sizeof(dummy), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_CATPidEntryEnable"));
		return err;
	}
#endif
	
	/* set the initial Pid entries */
	for (i = 0; i < context->pid_table_count; i++) {
	
		struct DemuxTask_PidEntry_type entry;
		struct EMhwlibEntryOutputMask_type out;
		struct PidEntry_type *p = context->pid_table;
		struct DemuxTask_PidEntryRecipher_type recipher_entry;
		
		err = RUAGetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_AllocatePidEntry, &p[i].index, sizeof(p[i].index));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_AllocatePidEntry"));
			return err;
		}
		RMDBGLOG((ENABLE, "InitPidTablePerTask RMDemuxTaskPropertyID_AllocatePidEntry %ld\n", p[i].index));
		
		entry.index = p[i].index;
		entry.PidEntry.pid = p[i].pid;
		entry.PidEntry.input_type = p[i].input_type;
		entry.PidEntry.flags = p[i].flags;

		RMDBGLOG((ENABLE, "setPIDEntry[%lu]: index %lu pid 0x%lx type 0x%lx flags 0x%lx\n",
			  i,
			  (RMuint32)entry.index,
			  (RMuint32)entry.PidEntry.pid,
			  (RMuint32)entry.PidEntry.input_type,
			  (RMuint32)entry.PidEntry.flags));

		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntry, &entry, sizeof(entry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_PidEntry"));
			return err;
		}

		recipher_entry.index = p[i].index;
		recipher_entry.enable = FALSE;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryRecipher, &recipher_entry, sizeof(recipher_entry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_InitPidTablePerTask Error RMDemuxTaskPropertyID_PidEntryReciphe", context->id));
			return err;
		}
		
		out.entry_index = entry.index;
		out.output_mask[0] = p[i].output_mask[0];

		RMDBGLOG((ENABLE, "addOutputs2PIDEntry: mask 0x%lx\n", (RMuint32)out.output_mask[0]));

		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryAddOutputs, &out, sizeof(out), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_PidEntryAddOutputs"));
			return err;
		}
		
		if (p[i].enable) {
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryEnable, &entry.index, sizeof(entry.index), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_PidEntryEnable"));
				return err;
			}
		}
		
		/* initialize the variable used for playback */
		switch (p[i].type) {
#ifndef USE_HW_FIXED_PID_ENTRY
		case PAT_PID_ENTRY:
			context->pat_pidentry = p[i].index;
			break;
		case CAT_PID_ENTRY:
			context->cat_pidentry = p[i].index;
			break;
#endif
		case PMT_PID_ENTRY:
			context->pmt_pidentry = p[i].index;
			break;
		case VIDEO_PID_ENTRY:
			context->video_pidentry = p[i].index;
			break;
		case AUDIO_PID_ENTRY:
			context->audio_pidentry = p[i].index;
			break;
		case PCR_PID_ENTRY:
			context->pcr_pidentry = p[i].index;
			break;
		case ECM0_PID_ENTRY:
			context->ecm_pidentry[0] = p[i].index;
			break;
		case ECM1_PID_ENTRY:
			context->ecm_pidentry[1] = p[i].index;
			break;
		case TTX_PID_ENTRY:
			context->teletext_pidentry = p[i].index;
			break;
		}
	}
	
	return RM_OK;
}

static RMstatus DisablePidTablePerTask(struct RUA *pRUA, RMuint32 demux_task, struct PidEntry_type *p, RMuint32 pid_table_count)
{
	RMstatus err;
	RMuint32 i;

	RMDBGLOG((ENABLE, "disablePIDTablePerTask\n"));

#ifdef USE_HW_FIXED_PID_ENTRY
	{
		RMuint32 dummy;
		err = RUASetProperty(pRUA, demux_task, RMDemuxTaskPropertyID_PATPidEntryDisable, &dummy, sizeof(dummy), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "DisablePidTablePerTask Error RMDemuxTaskPropertyID_PATPidEntryDisable"));
			return err;
		}
		err = RUASetProperty(pRUA, demux_task, RMDemuxTaskPropertyID_CATPidEntryDisable, &dummy, sizeof(dummy), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "DisablePidTablePerTask Error RMDemuxTaskPropertyID_CATPidEntryDisable"));
			return err;
		}
	}
#endif
	for (i=0; i<pid_table_count; i++) {
		RMDBGLOG((ENABLE, "disabling PID_entry[%lu/%lu] index %lu\n", i, pid_table_count, p[i].index));
		err = RUASetProperty(pRUA, demux_task, RMDemuxTaskPropertyID_PidEntryDisable, &p[i].index, sizeof(p[i].index), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "DisablePidTablePerTask Error RMDemuxTaskPropertyID_PidEntryDisable"));
			return err;
		}
	}
	return RM_OK;
}

static RMstatus FreePidTablePerTask(struct RUA *pRUA, RMuint32 demux_task, struct PidEntry_type *p, RMuint32 pid_table_count)
{
	RMstatus err;
	RMuint32 i;

	RMDBGLOG((CALLDBG, "freePIDTablePerTask\n"));

	for (i=0; i<pid_table_count; i++) {
		err = RUASetProperty(pRUA, demux_task, RMDemuxTaskPropertyID_FreePidEntry, &p[i].index, sizeof(p[i].index), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "FreePidTablePerTask Error RMDemuxTaskPropertyID_FreePidEntry"));
			return err;
		}
		RMDBGLOG((ENABLE, "FreePidTablePerTask RMDemuxTaskPropertyID_FreePidEntry %ld\n", p[i].index));
	}
	return RM_OK;
}

static RMstatus InitPesTablePerTask(struct context_per_task *context)
{
	RMstatus err;
	RMuint32 i;
	struct PesEntry_type *p = context->pes_table;
	RMuint32 pes_table_count = context->pes_table_count;
 
	RMDBGLOG((CALLDBG, "initPESTablePerTask\n"));

	/* set the initial Pes entries */
	for (i=0; i<pes_table_count; i++) {
		struct DemuxTask_PesEntry_type entry;
		entry.index = i;
		entry.PesEntry.stream_id = p[i].stream_id;
		entry.PesEntry.substream_id = p[i].substream_id;
		entry.PesEntry.enable = p[i].enable;
		entry.PesEntry.output_mask[0] = p[i].output_mask[0];
		entry.PesEntry.cipher_mask = p[i].cipher_mask;
		entry.PesEntry.cipher_index[0] = p[i].cipher_index[0];
		if(context->demux_opt->send_scrambled_packets_for_invalid_key)
			entry.PesEntry.input_type = EMhwlibPes_packet1;
		else
			entry.PesEntry.input_type = EMhwlibPes_packet;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PesEntry, &entry, sizeof(entry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "InitPesTablePerTask Error RMDemuxTaskPropertyID_PesEntry"));
			return err;
		}
	}
	return RM_OK;
}

static RMstatus DisablePesTablePerTask(struct RUA *pRUA, RMuint32 demux_task, struct PesEntry_type *p, RMuint32 pes_table_count)
{
	RMstatus err;
	RMuint32 i;

	RMDBGLOG((CALLDBG, "disablePESTablePerTask\n"));

	for (i=0; i<pes_table_count; i++) {
		struct DemuxTask_PesEntry_type entry;
		entry.index = i;
		entry.PesEntry.stream_id = p[i].stream_id;
		entry.PesEntry.substream_id = p[i].substream_id;
		entry.PesEntry.enable = FALSE;
		entry.PesEntry.output_mask[0] = p[i].output_mask[0];
		entry.PesEntry.cipher_mask = p[i].cipher_mask;
		entry.PesEntry.cipher_index[0] = p[i].cipher_index[0];
		entry.PesEntry.input_type = p[i].input_type;
		err = RUASetProperty(pRUA, demux_task, RMDemuxTaskPropertyID_PesEntry, &entry, sizeof(entry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "DisablePesTable Error RMDemuxTaskPropertyID_PesEntry"));
			return err;
		}
	}
	return RM_OK;
}

static RMstatus InitSectionTable(struct context_per_task *context)
{
	RMstatus err;
	RMuint32 i;
	
	RMDBGLOG((CALLDBG, "initSectionTable (context @0x%08lx)\n", (RMuint32)context));

	for (i=0; i<context->match_section_table_count;i++) {
		struct DemuxTask_MatchSectionEntry_type section_entry;
		
		err = RUAGetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_AllocateMatchSectionEntry,
				     &context->match_section_table[i].index, sizeof(context->match_section_table[i].index));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "InitSectionTable Error RMDemuxTaskPropertyID_AllocateMatchSectionEntry"));
			return err;
		}
		RMDBGLOG((ENABLE, "InitSectionTable RMDemuxTaskPropertyID_AllocateMatchSectionEntry %ld\n",
			  context->match_section_table[i].index));
		
		section_entry.Index = context->match_section_table[i].index;
		section_entry.SectionEntry = context->match_section_table[i].section_entry;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_MatchSectionEntry,
				     &section_entry, sizeof(section_entry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error RMDemuxTaskPropertyID_MatchSectionEntry"));
			return err;
		}
	}
	return RM_OK;
}
	
static RMstatus FreeSectionTable(struct context_per_task *context)
{
	RMstatus err;
	RMuint32 i;
	
	RMDBGLOG((CALLDBG, "freeSectionTable (context @0x%08lx)\n", (RMuint32)context));

	for (i=0; i<context->match_section_table_count;i++) {
		
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_FreeMatchSectionEntry,
				     &context->match_section_table[i].index, sizeof(context->match_section_table[i].index), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "FreeSectionTable Error RMDemuxTaskPropertyID_FreeMatchSectionEntry"));
			return err;
		}
		RMDBGLOG((ENABLE, "FreeSectionTable RMDemuxTaskPropertyID_FreeMatchSectionEntry %ld\n",
			  context->match_section_table[i].index));
	}
	return RM_OK;
}

static void ClearInfoTable(struct context_per_task *context)
{

	RMuint32 i;

	RMMemset(&(context->pat_info), 0, sizeof(struct PATInfo_type));
	RMMemset(&(context->cat_info), 0, sizeof(struct CATInfo_type));
	RMMemset(&(context->VideoPidList), 0, sizeof(struct ESPidList_type));
	RMMemset(&(context->AudioPidList), 0, sizeof(struct ESPidList_type));

	for (i = 0; i < MAX_PROGRAM_NUMBER; i++) {
		RMMemset(&(context->pmt_info[i]), 0, sizeof(struct PMTInfo_type));
	}
 
}

static RMstatus ResetDemuxTask(struct context_per_task *context)
{
	RMstatus err;
	struct DemuxTask_MatchSectionEntry_type section_entry;

	DisablePidTablePerTask(context->pRUA, context->demux_task, context->pid_table, context->pid_table_count);

	ClearInfoTable(context);
	context->pat = FALSE;
	context->pmt = FALSE;
	context->cat = FALSE;
	context->av_flags = AV_PIDS_ENABLE_FIRST_TIME;
	context->video_pid = 0x1FFF;
	context->audio_pid = 0x1FFF;
	context->pcr_pid = 0x1FFF;
	context->ecm_pid[0] = 0x1FFF;
	context->ecm_pid[1] = 0x1FFF;

	/* reset PAT version_number in hardware section filter */
	context->match_section_table[0].section_entry.mask[5] = 0x00; 
	context->match_section_table[0].section_entry.mode[5] = 0x00;
	context->match_section_table[0].section_entry.comp[5] = 0x00;

	section_entry.Index = context->match_section_table[0].index;
	section_entry.SectionEntry = context->match_section_table[0].section_entry;
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_MatchSectionEntry,
		&section_entry, sizeof(section_entry), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error RMDemuxTaskPropertyID_MatchSectionEntry"));
	}

	/* reset PMT version_number in hardware section filter */
	context->match_section_table[1].section_entry.mask[5] = 0x00; 
	context->match_section_table[1].section_entry.mode[5] = 0x00;
	context->match_section_table[1].section_entry.comp[5] = 0x00;

	section_entry.Index = context->match_section_table[1].index;
	section_entry.SectionEntry = context->match_section_table[1].section_entry;
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_MatchSectionEntry,
		&section_entry, sizeof(section_entry), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error RMDemuxTaskPropertyID_MatchSectionEntry"));
	}

	/* reset CAT version_number in hardware section filter */
	context->match_section_table[3].section_entry.mask[5] = 0x00; 
	context->match_section_table[3].section_entry.mode[5] = 0x00;
	context->match_section_table[3].section_entry.comp[5] = 0x00;

	section_entry.Index = context->match_section_table[3].index;
	section_entry.SectionEntry = context->match_section_table[3].section_entry;
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_MatchSectionEntry,
		&section_entry, sizeof(section_entry), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error RMDemuxTaskPropertyID_MatchSectionEntry"));
	}

	/* reset ECM for next parity */
	context->match_section_table[4].section_entry.mask[0] = 0xFC;
	context->match_section_table[4].section_entry.comp[0] = 0x80;
	
	section_entry.Index = context->match_section_table[4].index;
	section_entry.SectionEntry = context->match_section_table[4].section_entry;
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_MatchSectionEntry,
		&section_entry, sizeof(section_entry), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "decoder: Error RMDemuxTaskPropertyID_MatchSectionEntry");
		return RM_ERROR;
	}
	context->match_section_table[5].section_entry.mask[0] = 0xFC;
	context->match_section_table[5].section_entry.comp[0] = 0x80;
	
	section_entry.Index = context->match_section_table[5].index;
	section_entry.SectionEntry = context->match_section_table[5].section_entry;
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_MatchSectionEntry,
		&section_entry, sizeof(section_entry), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "decoder: Error RMDemuxTaskPropertyID_MatchSectionEntry");
		return RM_ERROR;
	}

	// enable pat pid
#ifdef USE_HW_FIXED_PID_ENTRY
	{
		RMuint32 dummy;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PATPidEntryEnable, &dummy, sizeof(dummy), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "ResetDemuxTask Error RMDemuxTaskPropertyID_PATPidEntryEnable"));
			return err;
		}
	}
#else
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryEnable,
	&context->pat_pidentry, sizeof(context->pat_pidentry), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "ResetDemuxTask Error RMDemuxTaskPropertyID_PidEntryEnable"));
		return err;
	}
#endif

	return RM_OK;
}

static RMstatus SetHwAVPlayback(struct context_per_task *context)
{
	RMstatus err;
	struct DemuxTask_PidEntry_type entry;
	struct DemuxTask_PidEntryAddCipher_type cipher;

	RMDBGLOG((ENABLE, "============== %ld_SetHwAVPlayback vpid=%x apid=%x pcrpid=%x\n",
		  context->id, context->video_pid, context->audio_pid, context->pcr_pid));
	
	if (context->video_pid != 0x1fff) {
		/* set the video pid */
		entry.index = context->video_pidentry;
		entry.PidEntry.pid = context->video_pid;
		entry.PidEntry.input_type = EMhwlibPid_Ts;
		entry.PidEntry.flags = TS_FLAGS;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntry, &entry, sizeof(entry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error video RMDemuxTaskPropertyID_PidEntry", context->id));
			return err;
		}
	
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryEnable, &entry.index, sizeof(entry.index), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error video RMDemuxTaskPropertyID_PidEntryEnable", context->id));
			return err;
		}
	}
	else {
		/* disable the video pid */
		entry.index = context->video_pidentry;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryDisable, &entry.index, sizeof(entry.index), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error video RMDemuxTaskPropertyID_PidEntryDisable", context->id));
			return err;
		}
	}
	
	if (context->audio_pid != 0x1fff) {
		/* set the audio pid */
		entry.index = context->audio_pidentry;
		entry.PidEntry.pid = context->audio_pid;
		/* same PidEntry.input_type as video */
		entry.PidEntry.flags = TS_FLAGS;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntry, &entry, sizeof(entry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error audio RMDemuxTaskPropertyID_PidEntry", context->id));
			return err;
		}
	
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryEnable, &entry.index, sizeof(entry.index), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error audio RMDemuxTaskPropertyID_PidEntryEnable", context->id));
			return err;
		}
	}
	else {
		/* disable the audio pid */
		entry.index = context->audio_pidentry;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryDisable, &entry.index, sizeof(entry.index), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error audio RMDemuxTaskPropertyID_PidEntryDisable", context->id));
			return err;
		}
	}
	
	/* set the pcr pid */
#ifdef USE_HW_PCR_PID_ENTRY
	/* EM8634 has three hardware PCR filters but only two clock recovery blocks,
	 limiting us to only two hardware PCR filters. For the third task we have to use PCR extraction from PidBank.
	 For task 0 and 1 I will use the hardware PCR pids and for task 2 the PidBank pcr pid. */
	if(context->id < 2) {
		/* Set and enable the pcr extraction from special hardware pcr pid. We don't need any output connected. */
		if ( context->pcr_pid != 0x1fff ) {
			RMuint32 dummy;
			struct EMhwlibPCRPidEntry_type hwpcr;

			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback USE_HW_PCR_PID_ENTRY\n", context->id));
			hwpcr.pid = context->pcr_pid;
			hwpcr.clock_recovery_id = context->id; /* 0 or 1 for EM8634. Next chips will have a clock recovery for every PCR: 0, 1, 2. */
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PCRPidEntry, &hwpcr, sizeof(hwpcr), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error pcr RMDemuxTaskPropertyID_PCRPidEntry", context->id));
				return err;
			}
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PCRPidEntryEnable, &dummy, sizeof(dummy), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error pcr RMDemuxTaskPropertyID_PCRPidEntryEnable", context->id));
				return err;
			}
		}
	}
	else /* third task will use PCR extraction from PidBank. */
#endif
	{
		/* select the pcr extraction from pid bank. we need to have an output associated and enabled. */
		if ( (context->pcr_pid != context->video_pid) && (context->pcr_pid != context->audio_pid) && (context->pcr_pid != 0x1fff) ) {
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidBankPCRPid, &context->pcr_pid, sizeof(context->pcr_pid), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error pcr RMDemuxTaskPropertyID_PidBankPCRPid", context->id));
				return err;
			}

			/* set and enable the pcr in pid bank */
			entry.index = context->pcr_pidentry;
			entry.PidEntry.pid = context->pcr_pid;
			entry.PidEntry.input_type = EMhwlibPid_Ts;
			entry.PidEntry.flags = TS_FLAGS;
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntry, &entry, sizeof(entry), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error pcr RMDemuxTaskPropertyID_PidEntry", context->id));
				return err;
			}
	
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryEnable, &entry.index, sizeof(entry.index), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error pcr RMDemuxTaskPropertyID_PidEntryEnable", context->id));
				return err;
			}
		}
		else if  ((context->pcr_pid  == context->video_pid) || (context->pcr_pid == context->audio_pid)) {
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidBankPCRPid, &context->pcr_pid, sizeof(context->pcr_pid), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error pcr RMDemuxTaskPropertyID_PidBankPCRPid", context->id));
				return err;
			}

		}
		else {
			/* disable the pcr pid */
			entry.index = context->pcr_pidentry;
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryDisable, &entry.index, sizeof(entry.index), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error pcr RMDemuxTaskPropertyID_PidEntryDisable", context->id));
				return err;
			}
		}
	}

	/* Set the ECM pid */
	if (context->ecm_pid[0] != 0x1FFF) {
		// Apply cipher to pid of video
		cipher.index = context->video_pidentry;		/* pid index */
		cipher.pid_cipher_index = 0;			/* first and only cipher per pid in current implementation */
		cipher.cipher_index = context->cipher_index[0];	/* 1st cipher index of this task */
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryAddCipher, &cipher, sizeof(cipher), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_PidEntryAddCipher"));
			return err;
		}

		// Apply cipher to pid of audio
		if (context->ecm_pid[0] == context->ecm_pid[1]) {
			cipher.index = context->audio_pidentry;		/* pid index */
			cipher.pid_cipher_index = 0;			/* first and only cipher per pid in current implementation */
			cipher.cipher_index = context->cipher_index[0];	/* 1st cipher index of this task */
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryAddCipher, &cipher, sizeof(cipher), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_PidEntryAddCipher"));
				return err;
			}
		}

		fprintf(stderr, "   m>   ecm_pid[0]=0x%04X pidentry[0]=0x%02x\n", (RMuint16)(context->ecm_pid[0]), (RMuint16)(context->ecm_pidentry[0]));
		entry.index = context->ecm_pidentry[0];
		entry.PidEntry.pid = context->ecm_pid[0];
		entry.PidEntry.input_type = EMhwlibPid_Ts;
		entry.PidEntry.flags = TS_FLAGS;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntry, &entry, sizeof(entry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error ECM RMDemuxTaskPropertyID_PidEntry", context->id));
			return err;
		}

		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryEnable, &entry.index, sizeof(entry.index), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error ECM RMDemuxTaskPropertyID_PidEntryEnable", context->id));
			return err;
		}
	}
	else {
		/* disable the ecm video pid */
		entry.index = context->ecm_pidentry[0];
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryDisable, &entry.index, sizeof(entry.index), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error ECM0 RMDemuxTaskPropertyID_PidEntryDisable", context->id));
			return err;
		}
	}

	if ((context->ecm_pid[1] != 0x1FFF) && (context->ecm_pid[1] != context->ecm_pid[0])) {
		// Apply cipher to pid of audio
		cipher.index = context->audio_pidentry;		/* pid index */
		cipher.pid_cipher_index = 0;			/* first and only cipher per pid in current implementation */
		cipher.cipher_index = context->cipher_index[1];	/* 2nd cipher index of this task */
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryAddCipher, &cipher, sizeof(cipher), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_PidEntryAddCipher"));
			return err;
		}

		fprintf(stderr, "   m>   ecm_pid[1]=0x%04X pidentry[1]=0x%02x\n", (RMuint16)(context->ecm_pid[1]), (RMuint16)(context->ecm_pidentry[1]));
		entry.index = context->ecm_pidentry[1];
		entry.PidEntry.pid = context->ecm_pid[1];
		entry.PidEntry.input_type = EMhwlibPid_Ts;
		entry.PidEntry.flags = TS_FLAGS;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntry, &entry, sizeof(entry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error ECM RMDemuxTaskPropertyID_PidEntry", context->id));
			return err;
		}

		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryEnable, &entry.index, sizeof(entry.index), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error ECM RMDemuxTaskPropertyID_PidEntryEnable", context->id));
			return err;
		}
	}
	else {
		/* disable the ecm audio pid */
		entry.index = context->ecm_pidentry[1];
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryDisable, &entry.index, sizeof(entry.index), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_SetHwAVPlayback Error ECM1 RMDemuxTaskPropertyID_PidEntryDisable", context->id));
			return err;
		}
	}

#if (FORCE_DECRYPTION)
	if (((context->app_type == aes_cbc_decryption) || (context->app_type == aes_ecb_decryption) ||
		(context->app_type == multi2_decryption) || (context->app_type == dvbcsa_decryption)) &&
	    ((context->ecm_pid[0] == 0x1FFF) && (context->ecm_pid[1] = 0x1FFF))) {
		// Apply cipher to pid of video
		cipher.index = context->video_pidentry;		/* pid index */
		cipher.pid_cipher_index = 0;			/* first and only cipher per pid in current implementation */
		cipher.cipher_index = context->cipher_index[0];	/* 1st cipher index of this task */
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryAddCipher, &cipher, sizeof(cipher), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_PidEntryAddCipher"));
			return err;
		}

		// Apply cipher to pid of audio
		cipher.index = context->audio_pidentry;		/* pid index */
		cipher.pid_cipher_index = 0;			/* first and only cipher per pid in current implementation */
		cipher.cipher_index = context->cipher_index[0];	/* 1st cipher index of this task */
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryAddCipher, &cipher, sizeof(cipher), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "InitPidTablePerTask Error RMDemuxTaskPropertyID_PidEntryAddCipher"));
			return err;
		}
	}
#endif

	return RM_OK;
}

static RMstatus OpenVideoDecoder(struct context_per_task *context)
{
	RMstatus err;

	/* open video decoder using DCCX functions */
	struct DCCXVideoProfile video_profile;

	RMDBGLOG((ENABLE, "openVideoDecoder\n"));

	video_profile.ProtectedFlags = 0;
	video_profile.BitstreamFIFOSize = context->video_opt->fifo_size;
	video_profile.XferFIFOCount = 0;
	video_profile.PtsFIFOCount = 180;
	video_profile.InbandFIFOCount = 16;
	video_profile.XtaskInbandFIFOCount = 0;
	video_profile.MpegEngineID = context->video_opt->MpegEngineID;
	video_profile.VideoDecoderID = context->video_opt->VideoDecoderID;
	
	/* DCC spu_hack */
	video_profile.SPUProtectedFlags = 0;
	video_profile.SPUBitstreamFIFOSize = (context->enable_spu) ? SPU_FIFO_SIZE : 0;
	video_profile.SPUXferFIFOCount = 0;
	video_profile.SPUPtsFIFOCount = (context->enable_spu) ? 180 : 0;
	video_profile.SPUInbandFIFOCount = (context->enable_spu) ? 16 : 0;
	video_profile.SPUCodec = EMhwlibDVDSpuCodec;
	video_profile.SPUProfile = 0;
	video_profile.SPULevel = 0;
	video_profile.SPUExtraPictureBufferCount = 0;
	video_profile.SPUMaxWidth = 720;
	video_profile.SPUMaxHeight = 576;
	
	video_profile.STCID = context->id;

	/* set codec based on command line options either "-pv" or "-vcodec" */
	if (context->video_opt->vcodec_max_width) {
		video_profile.Codec = context->video_opt->vcodec;
		video_profile.Profile = context->video_opt->vcodec_profile;
		video_profile.Level = context->video_opt->vcodec_level;
		video_profile.MaxWidth = context->video_opt->vcodec_max_width;
		video_profile.MaxHeight = context->video_opt->vcodec_max_height;
	}
	else {
		err = video_profile_to_codec(context->video_opt->MPEGProfile, &video_profile.Codec,
					     &video_profile.Profile, &video_profile.Level, &video_profile.ExtraPictureBufferCount,
					     &video_profile.MaxWidth, &video_profile.MaxHeight);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Unknown video decoder codec \n"));
			return RM_ERROR;
		}
	}

	/* set the extra pictures after the profile to codec conversion */
	video_profile.ExtraPictureBufferCount = context->video_opt->vcodec_extra_pictures;

	err = DCCXOpenVideoDecoderSource(context->dcc_info->pDCC, &video_profile, &context->dcc_info->pVideoSource);
	if (RMFAILED(err)) {
		fprintf(stderr, "%lx_Cannot open video decoder err=%d\n", context->id, err);
		return RM_ERROR;
	}
	
	/* save the video codec to set it after demux output connection */
	context->vcodec = video_profile.Codec;

	err = DCCGetScalerModuleID(context->dcc_info->pDCC, context->dcc_info->route, DCCSurface_Video, context->disp_opt->video_scaler, &context->dcc_info->SurfaceID);
	if (RMFAILED(err)) {
		fprintf(stderr, "%lx_Cannot get surface to display video source %d\n", context->id, err);
		return RM_ERROR;
	}
	err = DCCSetSurfaceSource(context->dcc_info->pDCC, context->dcc_info->SurfaceID, context->dcc_info->pVideoSource);
	if (RMFAILED(err)) {
		fprintf(stderr, "%lx_Cannot set the surface source err=%d\n", context->id, err);
		return RM_ERROR;
	}

	err = DCCGetVideoDecoderSourceInfo(context->dcc_info->pVideoSource, &(context->dcc_info->video_decoder),
					   &(context->dcc_info->spu_decoder), &(context->dcc_info->video_timer));
	if (RMFAILED(err)) {
		fprintf(stderr, "%lx_Error getting video decoder source information err=%d\n", context->id, err);
		return RM_ERROR;
	}

#ifndef WITH_MONO
	context->dcc_info->disp_info->video_enable = TRUE;
	set_default_out_window(&(context->dcc_info->disp_info->out_window));
	set_default_out_window(&(context->dcc_info->disp_info->osd_window[0]));
	set_default_out_window(&(context->dcc_info->disp_info->osd_window[1]));

	context->dcc_info->disp_info->active_window = &(context->dcc_info->disp_info->out_window);

	err = apply_display_options(context->dcc_info, context->disp_opt);
	if (RMFAILED(err)) {
		fprintf(stderr, "%lx_Cannot set display options %d\n", context->id, err);
		return RM_ERROR;
	}

	/* set first decoder in top left quarter, second in right top quarter, third in center bottom quarter */
	if (task_count == 2) {
		context->dcc_info->disp_info->active_window->X = (context->id ? 3072:1024);
		context->dcc_info->disp_info->active_window->Y = (context->id ? 3072:1024);
		context->dcc_info->disp_info->active_window->Width  = 2048;
		context->dcc_info->disp_info->active_window->Height = 2048;
	}
	else if (task_count == 3) {
		context->dcc_info->disp_info->active_window->X = (context->id == 2) ? 2048:(context->id ? 3072:1024);
		context->dcc_info->disp_info->active_window->Y = (context->id == 2) ? 3072:1024;
		context->dcc_info->disp_info->active_window->Width  = 2048;
		context->dcc_info->disp_info->active_window->Height = 2048;
	}
	set_display_out_window(context->dcc_info);

#endif
	if (context->enable_spu) {
		RMuint32 spu_decoder = context->dcc_info->spu_decoder;
		enum SpuDecoder_StreamType_type spu_st = SpuDecoder_StreamType_4by3;  // type according to selected stream from PGC_SPST_CTL
		RMbool spu_disp = TRUE;  // shall sub picture be displayed? may be overridden by forced display from stream. use GetProp_Display to check actual state.
		struct SpuDecoder_Palette_type spu_lut = {{  // DVD format: Y,Cr,Cb
			0x00, 0x28, 0x6d, 0xf0,
			0x00, 0x51, 0xf0, 0x5a,
			0x00, 0x10, 0x80, 0x80,
			0x00, 0xea, 0x80, 0x80,
			
			0x00, 0x66, 0xdb, 0x4e,
			0x00, 0x6a, 0xdd, 0xca,
			0x00, 0xd2, 0x92, 0x10,
			0x00, 0x5b, 0x49, 0x92,
			
			0x00, 0x7b, 0x80, 0x80,
			0x00, 0xc9, 0x98, 0x77,
			0x00, 0x30, 0xb6, 0x6d,
			0x00, 0x4f, 0x51, 0x5b,
			
			0x00, 0x1c, 0x77, 0xb6,
			0x00, 0x61, 0xcf, 0xcf,
			0x00, 0x10, 0x80, 0x80,
			0x00, 0xbf, 0x80, 0x80,
		}};  // dummy ScalerModuleID
		err = RUASetProperty(context->pRUA, spu_decoder, RMSpuDecoderPropertyID_Palette, &spu_lut, sizeof(spu_lut), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set spu palette\n"));
			return RM_ERROR;
		}

		err = RUASetProperty(context->pRUA, spu_decoder, RMSpuDecoderPropertyID_StreamType,&spu_st, sizeof(spu_st), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set spu type\n"));
			return RM_ERROR;
		}
			
		err = RUASetProperty(context->pRUA, spu_decoder, RMSpuDecoderPropertyID_SubpictureOn, &spu_disp, sizeof(spu_disp), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set spu ON\n"));
			return RM_ERROR;
		}
	}

	return RM_OK;
}

static RMstatus SwitchVideoDecoder(struct context_per_task *context, enum VideoDecoder_Codec_type VCodec, enum MPEG_Profile MPEGProfile)
{
	RMstatus err = RM_OK;
	RMuint32 dummy;
	struct ReceiveThreshold_type rec_thr;
	struct DemuxOutput_Connect_type	connect;
	RMuint32 demux_output;

	if ((context->video_opt->MPEGProfile == MPEGProfile) && (context->video_opt->Codec == VCodec))
		return err;

	fprintf(stderr, "\nSwitch Video Codec from %u to %u Profile from %u to %u\n", context->video_opt->Codec, VCodec, context->video_opt->MPEGProfile, MPEGProfile);

	demux_output = EMHWLIB_MODULE(DemuxOutput, context->videoDemuxOutputIndex + output_count_per_task * context->id); 

	err = RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_Close, &dummy, sizeof(dummy), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "SwitchVideoDecoder cannot close DemuxOutput %lu err=%d\n", demux_output, err));
		return err;
	}

	RMDBGLOG((LOCALDBG, "SwitchVideoDecoder: CloseVideoSource %p\n", context->dcc_info->pVideoSource));
	err = DCCCloseVideoSource(context->dcc_info->pVideoSource);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%lx_Error cannot close video decoder err=%d\n", context->id, err));
		return err;
	}
	clear_video_options(context->dcc_info, context->video_opt);
#ifndef WITH_MONO
	clear_display_options(context->dcc_info, context->disp_opt);
#endif
	
	context->video_opt->Codec = VCodec;
	context->video_opt->MPEGProfile = MPEGProfile;

	err = OpenVideoDecoder(context); /* spu_hack: this will open the SpuDecoder too */
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "SwitchVideoDecoder: can NOT open video decoder\n"));
		return err;
	}

	/* the decoder will provide the bitstream, pts and inband fifo - no need to open a DemuxOutput, just connect */
	context->output_table[context->videoDemuxOutputIndex].consumer_module_id = context->dcc_info->video_decoder;
	connect.demux_task_module_id = context->demux_task;
	connect.consumer_module_id = context->output_table[context->videoDemuxOutputIndex].consumer_module_id;
	err = RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_Connect, &connect, sizeof(connect), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "SwitchVideoDecoder: DemuxOutput %ld failed to connect consumer=0x%lx\n",
			demux_output, connect.consumer_module_id));
		return err;
	}

	err = DCCXSetVideoDecoderSourceCodec(context->dcc_info->pVideoSource, context->vcodec);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set video decoder codec %d\n", err));
		return err;
	}
fprintf( stderr, "\n\n\n\n *****************************video codec %d ************************************\n", context->vcodec );

	/* apply the fixed vop rate if required */
	err = apply_video_decoder_options(context->dcc_info, context->video_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%lx_Error applying video_decoder_options err=%d\n", context->id, err));
		return RM_ERROR;
	}

	if ((! context->video_opt->VopInfo.FixedVopRate) && (! context->video_opt->vtimescale.enable)) { 
		/* time stamps are in 45k, ask the decoder to interpolate the time info from stream.
		   For m4v the property will succeed else returns error and we have to ignore the error */
		context->video_opt->vtimescale.enable = TRUE;
		context->video_opt->vtimescale.time_resolution = 90000;
		err = RUASetProperty(context->dcc_info->pRUA, context->dcc_info->video_decoder, RMVideoDecoderPropertyID_VideoTimeScale,
		     &context->video_opt->vtimescale, sizeof(context->video_opt->vtimescale), 0 );
		if (RMSUCCEEDED(err)) {
			RMDBGLOG((ENABLE, "set video time scale: %ld ticks per second\n", context->video_opt->vtimescale.time_resolution));
		}
		else
			err = RM_OK; /* ignore the error */
	}

	RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_Enable, &dummy, sizeof(dummy), 0);
	RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_DataType,
		&context->output_table[context->videoDemuxOutputIndex].type, sizeof(context->output_table[context->videoDemuxOutputIndex].type), 0);

	/* set to 0 the threshold because in case of playback I don't need the interrupts for receive */
	rec_thr.partial_read = FALSE;
	rec_thr.size = 0;
	RUASetProperty(context->pRUA, demux_output, RMGenericPropertyID_Threshold, &rec_thr, sizeof(rec_thr), 0);

	/* by default the output has the pts enabled */
	if (!context->play_opt->send_video_pts) {
		err = RUASetProperty(context->dcc_info->pRUA, demux_output, RMDemuxOutputPropertyID_EnablePts,
			&context->play_opt->send_video_pts, sizeof(context->play_opt->send_video_pts), 0 );
	}
 	return err;
}

static RMstatus SwitchAudioDecoder(struct context_per_task *context, enum AudioDecoder_Codec_type ACodec)
{

	RMstatus err = RM_OK;

	if (context->audio_opt->Codec == ACodec) return err;

	RMDBGLOG((ENABLE, "%lx_SwitchAudioDecoder: from %u to %u SPDIF[%u]\n",
		context->id, context->audio_opt->Codec, ACodec, context->audio_opt->Spdif));
	context->audio_opt->Codec = ACodec;
	if (ACodec == AudioDecoder_Codec_AC3) {
		context->audio_opt->Ac3Params.OutputChannels = Ac3_LR;
			
		if (!context->audio_opt->OutputChannelsExplicitAssign)
			context->audio_opt->OutputChannels = Audio_Out_Ch_LR;
	}

	/* apply the audio format - uninit, set codec, set specific parameters, init */
	err = apply_audio_decoder_options(context->dcc_info, context->audio_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%lx_Error applying audio_decoder_options err=%d\n", context->id, err));
		return RM_ERROR;
	}

	apply_dvi_hdmi_audio_options(context->dcc_info, context->audio_opt, 0, FALSE, FALSE, FALSE);

	return err;
}

static RMstatus SwitchCodec(struct context_per_task *context)
{

	enum AudioDecoder_Codec_type ACodec;
	enum VideoDecoder_Codec_type VCodec;
	enum MPEG_Profile MPEGProfile;
	RMuint32 index;
	RMstatus err;

	if (! context->video_opt->auto_detect_codec) {
		MPEGProfile = context->MulticastMPEGProfile[context->MulticastCurrent];
		VCodec = context->MulticastVCodec[context->MulticastCurrent];
		goto video_codec;
	}

	for (index = 0; index < context->VideoPidList.count; index++) {
		if (context->VideoPidList.elementary_pid[index] == context->video_pid)
			break;
	}

	if (index >= context->VideoPidList.count)
		goto switch_audio;

	switch (context->VideoPidList.stream_type[index]) {
		case 1:		// mpeg 1 video
			RMDBGLOG((ENABLE, "mpeg1 video detected, error\n"));
			return RM_ERROR;
			break;
		case 2:		// mpeg 2 video
			RMDBGLOG((LOCALDBG, "mpeg2 video detected\n"));
			MPEGProfile = Profile_MPEG2_HD;
			VCodec = VideoDecoder_Codec_MPEG2_HD;
			break;
		case 0x10:	// mpeg 4 video
			RMDBGLOG((LOCALDBG, "mpeg4 video detected\n"));
			MPEGProfile = Profile_MPEG4_HD;
			VCodec = VideoDecoder_Codec_MPEG4_HD;
			break;
		case 0x1b:	// H264 video
			RMDBGLOG((LOCALDBG, "h264 video detected\n"));
			MPEGProfile = Profile_H264_HD;
			VCodec = VideoDecoder_Codec_H264_HD;
			break;
		case 0xea:      // VC-1 video
			RMDBGLOG((LOCALDBG, "VC-1 video detected\n"));
			MPEGProfile = Profile_VC1_HD;
			VCodec = VideoDecoder_Codec_VC1_HD;
		default:
			RMDBGLOG((ENABLE, "%lx_SwitchCodec: video codec unknown, don't SwitchVideoDecoder !\n", context->id));
			goto switch_audio;
	}

	video_codec:
	err = SwitchVideoDecoder(context, VCodec, MPEGProfile);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%lx_Error Switch video decoder err=%d\n", context->id, err));
		return RM_ERROR;
	}

	switch_audio:

	if (! context->audio_opt->auto_detect_codec) {
		ACodec = context->MulticastACodec[context->MulticastCurrent];
		goto audio_codec;
	}

	for (index = 0; index < context->AudioPidList.count; index++) {
		if (context->AudioPidList.elementary_pid[index] == context->audio_pid)
			break;
	}

	if (index >= context->AudioPidList.count)
		return RM_OK;

	switch (context->AudioPidList.stream_type[index]) {
		case 3:		// mpeg 1 audio
		case 4:		// mpeg 2 audio
			RMDBGLOG((ENABLE, "%lx_SwitchCodec: mpeg audio detected\n", context->id));
			ACodec = AudioDecoder_Codec_MPEG1;
			break;
		case 6:		// private, can be DTS audio
			RMDBGLOG((ENABLE, "%lx_SwitchCodec: unknown codec id = 6, by default DTS\n", context->id));
			ACodec = stream_type_6;
			break;
		case 0x0f:	// ISO/IEC 13818-7 Audio with ADTS transport syntax
			RMDBGLOG((ENABLE, "%lx_SwitchCodec: ADTS audio detected\n", context->id));
			ACodec = AudioDecoder_Codec_AAC;
			context->audio_opt->AACParams.InputFormat = 1;	// adif, no sync word
			context->audio_opt->AACParams.OutputChannels = Aac_LR;
			break;
		case 0x80:	// 0x80 = bdlpcm
			RMDBGLOG((ENABLE, "%lx_SwitchCodec: bdlpcm audio detected\n", context->id));
			ACodec = AudioDecoder_Codec_PCM;
			context->audio_opt->SubCodec = 3;
			context->audio_opt->PcmCdaParams.ChannelAssign = PcmCda2_LR;
			context->audio_opt->PcmCdaParams.BitsPerSample = 16;

			if (!context->audio_opt->OutputChannelsExplicitAssign)
				context->audio_opt->OutputChannels = Audio_Out_Ch_LR;
			break;
		case 0x81:	// 0x81 = ac3
		case 0x83:	// 0x83 = dolby lossless - to check
		case 0x84:	// 0x84 = dolby digital plus - to check
			RMDBGLOG((ENABLE, "%lx_SwitchCodec: ac3 audio detected\n", context->id));
			ACodec = AudioDecoder_Codec_AC3;
			break;
		case 0x82:	// 0x82 = dts
		case 0x85:	// 0x85 = dts hd - to check
			RMDBGLOG((ENABLE, "%lx_SwitchCodec: dts audio detected\n", context->id));
			ACodec = AudioDecoder_Codec_DTS;
			break;
		case 0xe6:	// 0xe6 = wmaTS - Vincent
		case 0x11:	// 0x11, audio with LATM transport syntax as defined in ISO/IEC 14496-3 / AMD 1
		default:
			RMDBGLOG((ENABLE, "%lx_SwitchCodec: audio codec unknown, don't SwitchAudioDecoder !\n", context->id));
			return RM_OK;
	}

	audio_codec:
	err = SwitchAudioDecoder(context, ACodec);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%lx_SwitchCodec: SwitchAudioDecoder Error=%d\n", context->id, err));
		return RM_ERROR;
	}

	return RM_OK;
}

static RMstatus SetPidFilterForAVPlayback(struct context_per_task *context)
{
	RMstatus err;

	fprintf(stderr, "   m>   %ld_SetPidFilterForAVPlayback ", context->id);

	if (!(context->av_flags & VIDEO_PID_FROM_CMDLINE)) {
		if(context->VideoPidList.count) {
			fprintf(stderr, "vpid[%lu]= 0x%04x(0x%02x) ", context->VideoPidList.index,
				context->VideoPidList.elementary_pid[context->VideoPidList.index], context->VideoPidList.stream_type[context->VideoPidList.index]);
			context->video_pid = context->VideoPidList.elementary_pid[context->VideoPidList.index];
			context->ecm_pid[0] = context->VideoPidList.es_ecm_pid[context->VideoPidList.index];
		}
		else
			fprintf(stderr, "   vpid= NO pid in the list ");
	}

	if (!(context->av_flags & AUDIO_PID_FROM_CMDLINE)) {
		if(context->AudioPidList.count) {
			fprintf(stderr, "apid[%lu]= 0x%04x(0x%02x) ", context->AudioPidList.index,
				context->AudioPidList.elementary_pid[context->AudioPidList.index], context->AudioPidList.stream_type[context->AudioPidList.index]);
			context->audio_pid = context->AudioPidList.elementary_pid[context->AudioPidList.index];
			context->ecm_pid[1] = context->AudioPidList.es_ecm_pid[context->AudioPidList.index];
		}
		else
			fprintf(stderr, "   apid= NO pid in the list ");
	}
	
	if (!(context->av_flags & PCR_PID_FROM_CMDLINE)) {
		context->pcr_pid = context->VideoPidList.pcr_pid;
		fprintf(stderr, "pcrpid= 0x%04x", context->VideoPidList.pcr_pid);
	}
	fprintf(stderr, "\n");

	context->av_flags &= ~VIDEO_PID_FROM_CMDLINE;
	context->av_flags &= ~AUDIO_PID_FROM_CMDLINE;
	context->av_flags &= ~PCR_PID_FROM_CMDLINE;
	
	err = HwStop(context); //TODO play with disable
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_SetPidFilterForAVPlayback HwStop Error\n", context->id));
		return err;
	}

	err = SwitchCodec(context);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_SetPidFilterForAVPlayback SwitchCodec Error\n", context->id));
		return err;
	}
	
	/* set the new pids in the hardware pid filter */
	err = SetHwAVPlayback(context);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_SetPidFilterForAVPlayback SetHwAVPlayback Error\n", context->id));
		//return err;
	}
	
	err = HwPlay(context); //TODO with enable
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_SetPidFilterForAVPlayback HwPlay Error", context->id));
		return err;
	}
	
	context->av_flags &= ~AV_PIDS_ENABLE_FIRST_TIME;
	
	return RM_OK;
}

static RMstatus SetNextPMT(struct context_per_task *context)
{
	RMstatus err;
	struct DemuxTask_PidEntry_type entry;
	struct PMTInfo_type *pmt_info;

	RMDBGLOG((CALLDBG, "setNextPMT (context @0x%08lx)\n", (RMuint32)context));

	if ( context->pat_info.count == 0 ) {
		fprintf(stderr, "   m> %ld_NextPMT error: pat_info.count=0\n", context->id);
		return RM_ERROR;
	}
	
	/* next pmt in list */
	context->pmt_index = (context->pmt_index+1)%context->pat_info.count;
	
	if (context->pat_info.program_number[context->pmt_index] == 0) {
		/* skip network PID*/
		context->pmt_index = (context->pmt_index+1)%context->pat_info.count;
	}
	pmt_info = &context->pmt_info[context->pmt_index];
	if (pmt_info->count) {
		context->pmt = TRUE;
	}
	/* for time being use same Pid entry */
	RMDBGLOG((ENABLE, "   %ld_SetNextPMT sets pmt_pidentry_%lx pid=%lx\n", context->id,
		  context->pmt_pidentry, context->pat_info.program_map_pid[context->pmt_index]));

	entry.index = context->pmt_pidentry;
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryDisable, &entry.index, sizeof(entry.index), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_PMT Error RMDemuxTaskPropertyID_PidEntryEnable", context->id));
		return err;
	}
	entry.PidEntry.pid = context->pat_info.program_map_pid[context->pmt_index];
	entry.PidEntry.input_type = EMhwlibPid_Ts;
	entry.PidEntry.flags = TS_FLAGS;
	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntry, &entry, sizeof(entry), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_PMT Error RMDemuxTaskPropertyID_PidEntry", context->id));
		return err;
	}

	err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryEnable, &entry.index, sizeof(entry.index), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_PMT Error RMDemuxTaskPropertyID_PidEntryEnable", context->id));
		return err;
	}

	{
		struct DemuxTask_MatchSectionEntry_type section_entry;

		/*
		 * reset pmt version in hardware section filter
		 */
		context->match_section_table[1].section_entry.mask[5] = 0x00; 
		context->match_section_table[1].section_entry.mode[5] = 0x00;
		context->match_section_table[1].section_entry.comp[5] = 0x00;
		
		section_entry.Index = context->match_section_table[1].index;
		section_entry.SectionEntry = context->match_section_table[1].section_entry;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_MatchSectionEntry,
			&section_entry, sizeof(section_entry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error RMDemuxTaskPropertyID_MatchSectionEntry"));
		}

		/*
		 * reset ECM for next parity
		 */
		context->match_section_table[4].section_entry.mask[0] = 0xFC;
		context->match_section_table[4].section_entry.comp[0] = 0x80;
			
		section_entry.Index = context->match_section_table[4].index;
		section_entry.SectionEntry = context->match_section_table[4].section_entry;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_MatchSectionEntry,
			&section_entry, sizeof(section_entry), 0);
		if (RMFAILED(err)) {
			fprintf(stderr, "decoder: Error RMDemuxTaskPropertyID_MatchSectionEntry");
		}
		context->match_section_table[5].section_entry.mask[0] = 0xFC;
		context->match_section_table[5].section_entry.comp[0] = 0x80;
			
		section_entry.Index = context->match_section_table[5].index;
		section_entry.SectionEntry = context->match_section_table[5].section_entry;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_MatchSectionEntry,
			&section_entry, sizeof(section_entry), 0);
		if (RMFAILED(err)) {
			fprintf(stderr, "decoder: Error RMDemuxTaskPropertyID_MatchSectionEntry");
		}
	}

	return RM_OK;
}

static RMstatus CheckAVPlaybackAgainstAVList(struct context_per_task *context)
{
	RMDBGLOG((CALLDBG, "checkAVPlaybackAgainstAVList (context @0x%08lx)\n", (RMuint32)context));

	if ( (context->video_pid == context->VideoPidList.elementary_pid[context->VideoPidList.index]) &&
	     (context->pcr_pid == context->VideoPidList.pcr_pid) &&
	     (context->audio_pid == context->AudioPidList.elementary_pid[context->AudioPidList.index]) )
		return RM_OK;
		
	return RM_ERROR;
}

static RMstatus PmtSetAVList(struct context_per_task *context)
{
	RMuint32 i, ai=0, vi=0;
	struct PMTInfo_type *pmt_info;

	RMDBGLOG((CALLDBG, "pmtSetAVList (context @0x%08lx)\n", (RMuint32)context));

	if ( context->pat_info.count == 0 ) {
		fprintf(stderr, "   m> %ld_PmtSetAVList error: empty PmtPidList\n", context->id);
		return RM_ERROR;
	}
	
	if (context->pat_info.program_number[context->pmt_index] == 0) {
		/* skip network PID*/
		context->pmt_index = (context->pmt_index+1)%context->pat_info.count;
	}
	pmt_info = &context->pmt_info[context->pmt_index];
	if (pmt_info->count == 0) {
		/* prepare for next pmt in list */
		context->pmt_index = (context->pmt_index+1)%context->pat_info.count;
		fprintf(stderr, "   m> %ld_PmtSetAVList index=%lx not found => try next pmt from pat list!\n", context->id, context->pmt_index);
		return RM_ERROR;
	}
	pmt_info->update = FALSE; /* handshake with ParsePMT */

	fprintf(stderr, "   m> %ld_PmtSetAVList index=%lx prog=0x%03x pid=0x%03x\n", context->id,
		context->pmt_index, context->pat_info.program_number[context->pmt_index],
		context->pat_info.program_map_pid[context->pmt_index]);
	fprintf(stderr, "   m> %lu PES streams:\n", pmt_info->count);

	context->VideoPidList.pcr_pid = pmt_info->pcr_pid;
	
	for(i=0;i<pmt_info->count;i++) {
		// see page 45, 13818-1 (MPEG-2 Systems spec)
		switch (pmt_info->stream_type[i]) {
		case 1:		// mpeg 1 video
		case 2:		// mpeg 2 video
		case 0x10:	// mpeg 4 video
		case 0x1b:	// H264 video
		case 0xea:      // VC-1 video
		//case 0x80:	// video, it is used by wsnet to indicate a video stream
			context->VideoPidList.stream_type[vi] = pmt_info->stream_type[i];
			context->VideoPidList.elementary_pid[vi] = pmt_info->elementary_pid[i];

			if (pmt_info->es_ecm_count == 0) { // ECM for entire program
				if (pmt_info->ecm_count == 0) 	// No ECM
					context->VideoPidList.es_ecm_pid[vi] = 0x1FFF;
				else if (pmt_info->ecm_count == 1) 	// Standard
					context->VideoPidList.es_ecm_pid[vi] = pmt_info->ecm_pid[0];
				else {	// Wired TS
					if ((vi + ai) < pmt_info->ecm_count)
						context->VideoPidList.es_ecm_pid[vi] = pmt_info->ecm_pid[vi + ai];
					else
						context->VideoPidList.es_ecm_pid[vi] = 0x1FFF;
				}
			}
			else {	// ECM for elementary
				context->VideoPidList.es_ecm_pid[vi] = pmt_info->es_ecm_pid[i];
			}
			fprintf(stderr, "   m>   vpid[%lu]= 0x%04x(0x%02x)= %s\n",
				vi,
				pmt_info->elementary_pid[i],
				pmt_info->stream_type[i],
				VideoTypeToString(pmt_info->stream_type[i]));
			fprintf(stderr, "   m>   ecm_pid=0x%04X\n", context->VideoPidList.es_ecm_pid[vi]);
			vi++;
			break;
		case 3:		// mpeg 1 audio
		case 4:		// mpeg 2 audio
		case 6:		// private, can be DTS audio
		case 0x0f:	// ISO/IEC 13818-7 Audio with ADTS transport syntax
		case 0x80:	// audio for BR disc !!
		case 0x81:	// 0x81 = ac3
		case 0x82:	// 0x82 = dts
		case 0x83:	// 0x83 = dolby lossless
		case 0x84:	// 0x84 = dolby digital plus
		case 0x85:	// 0x85 = dts hd
		case 0xe6:	// 0xe6 = wmaTS - Vincent
		case 0x11:	// 0x11, audio with LATM transport syntax as defined in ISO/IEC 14496-3 / AMD 1
			context->AudioPidList.stream_type[ai] = pmt_info->stream_type[i];
			context->AudioPidList.elementary_pid[ai] = pmt_info->elementary_pid[i];

			if (pmt_info->es_ecm_count == 0) { // ECM for entire program
				if (pmt_info->ecm_count == 0) 	// No ECM
					context->AudioPidList.es_ecm_pid[ai] = 0x1FFF;
				else if (pmt_info->ecm_count == 1) 	// Standard
					context->AudioPidList.es_ecm_pid[ai] = pmt_info->ecm_pid[0];
				else {	// Wired TS
					if ((ai + vi) < pmt_info->ecm_count)
						context->AudioPidList.es_ecm_pid[ai] = pmt_info->ecm_pid[ai + vi];
					else
						context->AudioPidList.es_ecm_pid[ai] = 0x1FFF;
				}
			}
			else {	// ECM for elementary
				context->AudioPidList.es_ecm_pid[ai] = pmt_info->es_ecm_pid[i];
			}
			fprintf(stderr, "   m>   apid[%lu]= 0x%04x(0x%02x)= %s\n",
				ai,
				pmt_info->elementary_pid[i],
				pmt_info->stream_type[i],
				AudioTypeToString(pmt_info->stream_type[i]));
			fprintf(stderr, "   m>   ecm_pid=0x%04X\n", context->AudioPidList.es_ecm_pid[ai]);
			ai++;
			break;
		default:
			fprintf(stderr, "   m>    pid= 0x%04x(0x%02x)= unknown pes\n", pmt_info->elementary_pid[i], pmt_info->stream_type[i]);
			break;
		}
	}
	context->VideoPidList.count = vi;
	context->VideoPidList.index = 0;
	context->AudioPidList.count = ai;
	context->AudioPidList.index = 0;

	if ((!vi) && (!ai)) {
		fprintf(stderr, "   m>    %ld_PmtSetAVList No valid video and audio streams -> try next pmt from pat list index=%lx!\n", context->id, context->pmt_index);
		return RM_ERROR;
	}

	return RM_OK;
}

static RMstatus OpenAudioDecoder(struct context_per_task *context)
{
	RMstatus err;
	struct DCCAudioProfile audio_profile;

	RMDBGLOG((ENABLE, "openAudioDecoder\n"));

	audio_profile.BitstreamFIFOSize = context->audio_opt->fifo_size;
	audio_profile.XferFIFOCount = 0;// No audio xfer_fifo
	audio_profile.DemuxProgramID = context->audio_opt->AudioEngineID * 2 + context->audio_opt->AudioDecoderID;
	audio_profile.AudioEngineID = context->audio_opt->AudioEngineID;
	audio_profile.AudioDecoderID = context->audio_opt->AudioDecoderID;
	audio_profile.STCID = context->id;

	err = DCCOpenAudioDecoderSource(context->dcc_info->pDCC, &audio_profile, &context->dcc_info->pAudioSource);
	if (RMFAILED(err)) {
		fprintf(stderr, "%lx_Cannot open audio decoder err=%d\n", context->id, err);
		return RM_ERROR;
	}

	err = DCCGetAudioDecoderSourceInfo(context->dcc_info->pAudioSource, &(context->dcc_info->audio_decoder),
					   &(context->dcc_info->audio_engine), &(context->dcc_info->audio_timer));
	if (RMFAILED(err)) {
		fprintf(stderr, "Error getting audio decoder source information %d\n", err);
		return RM_ERROR;
	}

	/* apply the sample rate, serial out status */
	err = apply_audio_engine_options(context->dcc_info, context->audio_opt);
	if (RMFAILED(err)) {
		fprintf(stderr, "%lx_Error applying audio engine options err=%d\n", context->id, err);
		return RM_ERROR;
	}
	/* apply the audio format - uninit, set codec, set specific parameters, init */
	err = apply_audio_decoder_options(context->dcc_info, context->audio_opt);
	if (RMFAILED(err)) {
		fprintf(stderr, "%lx_Error applying audio_decoder_options err=%d\n", context->id, err);
		return RM_ERROR;
	}
	apply_dvi_hdmi_audio_options(context->dcc_info, context->audio_opt, 0, FALSE, FALSE, FALSE);
#ifndef WITH_MONO
	if (! context->disp_opt->configure_outports) apply_hdcp(context->dcc_info, context->disp_opt);
#endif
	
	return RM_OK;
}

static RMstatus OpenDemuxOutputModule(struct context_per_task *context, RMuint32 i)
{
	RMstatus err;
	struct DemuxOutput_DRAMSize_in_type dram_in;
	struct DemuxOutput_DRAMSize_out_type dram_out;
	struct DemuxOutput_Open_type profile;
	RMuint32 demux_task = context->demux_task;
	RMuint32 demux_output = EMHWLIB_MODULE(DemuxOutput, i + output_count_per_task*context->id); 

	RMDBGLOG((CALLDBG, "openDemuxOutputModule (context @0x%08lx)\n", (RMuint32)context));

	dram_in.BitstreamFIFOSize = context->output_table[i].buffer_count * (1<<context->output_table[i].buffer_size_log2);
	dram_in.XferFIFOCount = context->output_table[i].buffer_count;
	dram_in.PtsFIFOCount = context->output_table[i].pts_count;
	dram_in.InbandFIFOCount = context->output_table[i].inband_count;

	err = RUAExchangeProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_DRAMSize,
				  &dram_in, sizeof(dram_in), &dram_out, sizeof(dram_out));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting property RMDemuxOutputPropertyID_DRAMSize! %s\n", RMstatusToString(err)));
		return err;
	}

	profile.BitstreamFIFOSize = dram_in.BitstreamFIFOSize;
	profile.XferFIFOCount = dram_in.XferFIFOCount;
	profile.PtsFIFOCount = dram_in.PtsFIFOCount;
	profile.InbandFIFOCount = dram_in.InbandFIFOCount;
	profile.demux_task_module_id = demux_task;
	profile.stc_module_id = EMHWLIB_MODULE(STC, context->id);

	profile.BitstreamProtectedAddress = 0;
	profile.BitstreamProtectedSize = dram_out.BitstreamProtectedSize;
	if (profile.BitstreamProtectedSize > 0) {
		profile.BitstreamProtectedAddress = DCCMalloc(context->dcc_info->pDCC, 0, RUA_DRAM_CACHED, profile.BitstreamProtectedSize);
		if (!profile.BitstreamProtectedAddress) {
			RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in cached DRAM %lu!\n",
				  profile.BitstreamProtectedSize, 0L));
			return RM_FATALOUTOFMEMORY;
		}
		RMDBGLOG((DISABLE, "video cached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
			  profile.BitstreamProtectedAddress, profile.BitstreamProtectedSize, profile.BitstreamProtectedAddress + profile.BitstreamProtectedSize));
	} 	
	context->output_table[i].BitstreamProtectedAddr = profile.BitstreamProtectedAddress;

	profile.UnprotectedAddress = 0;
	profile.UnprotectedSize = dram_out.UnprotectedSize;
	if (profile.UnprotectedSize > 0) {
		profile.UnprotectedAddress = DCCMalloc(context->dcc_info->pDCC, 0, RUA_DRAM_UNCACHED, profile.UnprotectedSize);
		if (!profile.UnprotectedAddress) {
			RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in uncached DRAM %lu!\n",
				  profile.UnprotectedSize, 0L));
			return RM_FATALOUTOFMEMORY;
		}
		RMDBGLOG((DISABLE, "video uncached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
			  profile.UnprotectedAddress, profile.UnprotectedSize, profile.UnprotectedAddress + profile.UnprotectedSize));
	} 	
	context->output_table[i].UnprotectedAddr = profile.UnprotectedAddress;

	err = RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_Open, &profile, sizeof(profile), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "OpenDemuxOutput Error\n"));
		return err;
	}
	return RM_OK;
}

static RMstatus OpenOutputTableForRecord(struct context_per_task *context)
{
	RMstatus err = RM_OK;
	RMuint32 i, dummy;

	RMDBGLOG((CALLDBG, "openOutputTableForRecord (context @0x%08lx)\n", (RMuint32)context));
	
	/* sanity check - if the output is for playback with an invalid decoder just mark it for recording */
	for (i=0; i<context->output_table_count;i++) {
		if (EMHWLIB_MODULE_CATEGORY(context->output_table[i].consumer_module_id) == AudioDecoder) {
			if(context->audio_opt->AudioDecoderID >= 2) {
				RMDBGLOG((ENABLE, "\nAudioDecoder %ld not supported for playback. Data is recorded in file.\n",
					context->audio_opt->AudioDecoderID));
				context->output_table[i].consumer_module_id = 0;
			}
		}
		else if (EMHWLIB_MODULE_CATEGORY(context->output_table[i].consumer_module_id) == SpuDecoder) {
			if(!context->enable_spu) {
				RMDBGLOG((ENABLE, "\nSpuDecoder not enabled. Data is recorded in file.\n"));
				context->output_table[i].consumer_module_id = 0;
			}
		}
	}

	/* allocate output buffers for recording */
	for (i=0; i<context->output_table_count;i++) {
		RMuint32 demux_output = EMHWLIB_MODULE(DemuxOutput, i + output_count_per_task*context->id); 

		context->output_table[i].BitstreamProtectedAddr = 0;
		context->output_table[i].UnprotectedAddr = 0;
		context->output_table[i].pDma = 0;
		
		if(context->output_table[i].consumer_module_id) {
			continue;
		}

		/* open file to record data */
		if (context->output_table[i].filename[0]) {
			sprintf(context->output_table[i].filename, "%s%lx",
				context->output_table[i].filename, EMHWLIB_MODULE_INDEX(context->demux_task) );
			context->output_table[i].f_out = fopen(context->output_table[i].filename, "wb");
			if (context->output_table[i].f_out == NULL) {
				fprintf(stderr, "OpenOutputTableForRecord: File %s cannot open\n", context->output_table[i].filename);
			}
			context->output_table[i].f_out_size = 0;
		}

		/* Open DemuxOutput module */
		if (RMFAILED(err = OpenDemuxOutputModule(context, i)))
			return err;
		context->output_table[i].demux_output_module_id = demux_output;

		/* Allocate DMA pool for DemuxOutput */
		if (context->output_table[i].buffer_count) {
			struct ReceiveThreshold_type rec_thr;
			RMuint32 section_mask;

			err = RUAOpenPool(context->pRUA, context->output_table[i].partial_read ? (RUA_POOL_FORCE_DRAM_COPY | demux_output): demux_output,
					  context->output_table[i].buffer_count, context->output_table[i].buffer_size_log2, RUA_POOL_DIRECTION_RECEIVE, &context->output_table[i].pDma);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "OpenOutputTableForRecord: RUAOpenPool Error\n"));
				return err;
			}
		
			RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_Enable,
				&dummy, sizeof(dummy), 0);
				
			if (context->app_type == program_stream_parsing)
				section_mask = context->output_table[i].section_mask;
			else {
				/* hack for 8622 that has only 32 section entries shared by all tasks */
				section_mask = context->output_table[i].section_mask << context->match_section_table[0].index;
			}

			RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_SectionMask,
					&section_mask, sizeof(section_mask), 0);

			RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_DataType,
				&context->output_table[i].type, sizeof(context->output_table[i].type), 0);

			rec_thr.partial_read = context->output_table[i].partial_read;
			rec_thr.size = context->output_table[i].threshold;
			RUASetProperty(context->pRUA, demux_output, RMGenericPropertyID_Threshold, &rec_thr, sizeof(rec_thr), 0);
		}
		else if (context->output_table[i].type == EMhwlibData_PCR) {
			/* in order to extract PCR we have to enable the output even if output fifo is null */
			RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_DataType,
				&context->output_table[i].type, sizeof(context->output_table[i].type), 0);
			RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_Enable,
				&dummy, sizeof(dummy), 0);
		}
	}
	return err;
}

static RMstatus OpenOutputTableForPlayback(struct context_per_task *context)
{
	RMstatus err = RM_OK;
	RMuint32 i, dummy;

	RMDBGLOG((CALLDBG, "openOutputTableForPlayback (context @0x%08lx)\n", (RMuint32)context));
	
	/* connect the outputs to preallocated buffers from decoders */
	for (i=0; i<context->output_table_count;i++) {
		struct DemuxOutput_Connect_type	connect;
		RMuint32 demux_output = EMHWLIB_MODULE(DemuxOutput, i + output_count_per_task*context->id); 

		if(context->output_table[i].consumer_module_id == 0) {
			continue;
		}

		context->output_table[i].BitstreamProtectedAddr = 0;
		context->output_table[i].UnprotectedAddr = 0;
		context->output_table[i].pDma = 0;
	
		if (EMHWLIB_MODULE_CATEGORY(context->output_table[i].consumer_module_id) == VideoDecoder) {
			err = OpenVideoDecoder(context); /* spu_hack: this will open the SpuDecoder too */
			context->output_table[i].consumer_module_id = context->dcc_info->video_decoder;
			if (RMFAILED(err))
				return err;
			context->videoDemuxOutputIndex = i;
			RMDBGLOG((ENABLE, "video demux output index %lu\n", context->videoDemuxOutputIndex));
		}
		else if (EMHWLIB_MODULE_CATEGORY(context->output_table[i].consumer_module_id) == AudioDecoder) {
			if (context->audioInstances > 1) {
				/* TODO - port DCCMultipleAudioInstance as in play_psfdemux.
				for time being one audio instance - don't open the second audio output */
				context->output_table[i].consumer_module_id = 0;
				continue;
			}

			context->audioInstances++;
			err = OpenAudioDecoder(context);
			context->output_table[i].consumer_module_id = context->dcc_info->audio_decoder;
			if (RMFAILED(err))
				return err;
		}
		else if (EMHWLIB_MODULE_CATEGORY(context->output_table[i].consumer_module_id) == SpuDecoder) {
			/* spu_hack: SpuDecoder is already open by OpenVideoDecoder */
		}
		else {
			RMDBGLOG((ENABLE, "OpenOutputTableForPlayback: unsupported consumer_module_id=0x%lx\n", context->output_table[i].consumer_module_id));
			return err;
		}

		/* the decoder will provide the bitstream, pts and inband fifo - no need to open a DemuxOutput, just connect */
		connect.demux_task_module_id = context->demux_task;
		connect.consumer_module_id = context->output_table[i].consumer_module_id;
		err = RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_Connect,
				     &connect, sizeof(connect), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "OpenOutputTableForPlayback: DemuxOutput %ld failed to connect consumer=0x%lx\n", connect.consumer_module_id));
			return err;
		}
		
		/* Video, Audio need uninit/init sequence */
		if (EMHWLIB_MODULE_CATEGORY(context->output_table[i].consumer_module_id) == VideoDecoder) {
			enum DemuxOutputTrigger_type trigger = DemuxOutputTrigger_Pts;
			err = RUASetProperty(context->dcc_info->pRUA, demux_output, RMDemuxOutputPropertyID_Trigger,
				     &trigger, sizeof(trigger), 0 );
			err = DCCXSetVideoDecoderSourceCodec(context->dcc_info->pVideoSource, context->vcodec);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot set video decoder codec %d\n", err));
				return err;
			}
fprintf( stderr, "\n\n\n\n ***********************222 ******video codec %d ************************************\n", context->vcodec );
			/* apply the fixed vop rate if required */
			err = apply_video_decoder_options(context->dcc_info, context->video_opt);
			if (RMFAILED(err)) {
				fprintf(stderr, "%lx_Error applying video_decoder_options err=%d\n", context->id, err);
				return RM_ERROR;
			}

			if (context->video_opt->VopInfo.FixedVopRate) {
				RMDBGLOG((ENABLE, "fixed vop rate from command line: %ld / %ld frames per second\n",
					  context->video_opt->VopInfo.VopTimeIncrementResolution, context->video_opt->VopInfo.FixedVopTimeIncrement));
			}
			else if (context->video_opt->vtimescale.enable) {
				RMDBGLOG((ENABLE, "video time scale from command line: %ld ticks per second\n",
					  context->video_opt->vtimescale.time_resolution));
			}
			else {
				/* time stamps are in 45k, ask the decoder to interpolate the time info from stream.
				   For m4v the property will succeed else returns error and we have to ignore the error */
				context->video_opt->vtimescale.enable = TRUE;
				context->video_opt->vtimescale.time_resolution = 90000;
				err = RUASetProperty(context->dcc_info->pRUA, context->dcc_info->video_decoder, RMVideoDecoderPropertyID_VideoTimeScale,
						     &context->video_opt->vtimescale, sizeof(context->video_opt->vtimescale), 0 );
				if (RMSUCCEEDED(err)) {
					RMDBGLOG((ENABLE, "set video time scale: %ld ticks per second\n",
						  context->video_opt->vtimescale.time_resolution));
				}
				else
					err = RM_OK; /* ignore the error */
			}
			/* by default the output has the pts enabled */
			if (!context->play_opt->send_video_pts) {
				err = RUASetProperty(context->dcc_info->pRUA, demux_output, RMDemuxOutputPropertyID_EnablePts,
					&context->play_opt->send_video_pts, sizeof(context->play_opt->send_video_pts), 0 );
				trigger = DemuxOutputTrigger_None;
				err = RUASetProperty(context->dcc_info->pRUA, demux_output, RMDemuxOutputPropertyID_Trigger,
					&trigger, sizeof(trigger), 0 );
			}
		}
		else if (EMHWLIB_MODULE_CATEGORY(context->output_table[i].consumer_module_id) == AudioDecoder) {
			enum DemuxOutputTrigger_type trigger = DemuxOutputTrigger_Pts;
			err = RUASetProperty(context->dcc_info->pRUA, demux_output, RMDemuxOutputPropertyID_Trigger,
				     &trigger, sizeof(trigger), 0 );
			err = RUASetProperty(context->dcc_info->pRUA, demux_output, RMDemuxOutputPropertyID_TransportPriority,
				     &context->audio_ts_priority, sizeof(context->audio_ts_priority), 0 );
			
			/* apply the audio format - uninit, set codec, set specific parameters, init */
			err = apply_audio_decoder_options(context->dcc_info, context->audio_opt);
			if (RMFAILED(err)) {
				fprintf(stderr, "%lx_Error applying audio_decoder_options err=%d\n", context->id, err);
				return RM_ERROR;
			}
			/* by default the output has the pts enabled */
			if (!context->play_opt->send_audio_pts) {
				err = RUASetProperty(context->dcc_info->pRUA, demux_output, RMDemuxOutputPropertyID_EnablePts,
					&context->play_opt->send_audio_pts, sizeof(context->play_opt->send_audio_pts), 0 );
				trigger = DemuxOutputTrigger_None;
				err = RUASetProperty(context->dcc_info->pRUA, demux_output, RMDemuxOutputPropertyID_Trigger,
					&trigger, sizeof(trigger), 0 );
			}
		}
		else if (EMHWLIB_MODULE_CATEGORY(context->output_table[i].consumer_module_id) == SpuDecoder) {
			enum DemuxOutputTrigger_type trigger = DemuxOutputTrigger_Pts;
			err = RUASetProperty(context->dcc_info->pRUA, demux_output, RMDemuxOutputPropertyID_Trigger,
				     &trigger, sizeof(trigger), 0 );
			/* spu_hack - need to uninit init the spu after connection to DemuxOutput */
			err = DCCXSetVideoDecoderSourceCodec(context->dcc_info->pVideoSource, context->vcodec);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot set spu decoder codec %d\n", err));
				return err;
			}
			/* by default the output has the pts enabled */
			if (!context->play_opt->send_spu_pts) {
				err = RUASetProperty(context->dcc_info->pRUA, demux_output, RMDemuxOutputPropertyID_EnablePts,
					&context->play_opt->send_spu_pts, sizeof(context->play_opt->send_spu_pts), 0 );
				trigger = DemuxOutputTrigger_None;
				err = RUASetProperty(context->dcc_info->pRUA, demux_output, RMDemuxOutputPropertyID_Trigger,
					&trigger, sizeof(trigger), 0 );
			}
		}

		RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_Enable,
			&dummy, sizeof(dummy), 0);
		RUASetProperty(context->pRUA, demux_output, RMDemuxOutputPropertyID_DataType,
			&context->output_table[i].type, sizeof(context->output_table[i].type), 0);
		{
			struct ReceiveThreshold_type rec_thr;
			/* set to 0 the threshold because in case of playback I don't need the interrupts for receive */
			rec_thr.partial_read = FALSE;
			rec_thr.size = 0;
			RUASetProperty(context->pRUA, demux_output, RMGenericPropertyID_Threshold, &rec_thr, sizeof(rec_thr), 0);
		}
	}
	return err;
}

static RMstatus CloseOutputTablePerTask(struct context_per_task *context)
{
	RMuint32 i;
	RMstatus err = RM_OK;

	RMDBGLOG((CALLDBG, "closeOutputTablePerTask (context @0x%08lx)\n", (RMuint32)context));

	for (i=0; i<context->output_table_count;i++) {
		if (context->output_table[i].demux_output_module_id) {
			RMuint32 dummy;
			err = RUASetProperty(context->pRUA, context->output_table[i].demux_output_module_id,
				RMDemuxOutputPropertyID_Close, &dummy, sizeof(dummy), 0);
			if( RMFAILED(err) ) {
				fprintf(stderr,"OutputEntry_Close %lx: RMDemuxOutputPropertyID_Close failed %d", i, err);
			}
		}
		/* release output buffers */
		if (context->output_table[i].pDma) {
			RUAClosePool(context->output_table[i].pDma);
			context->output_table[i].pDma = NULL;
		}
		if (context->output_table[i].UnprotectedAddr) {
			DCCFree(context->dcc_info->pDCC, context->output_table[i].UnprotectedAddr);
			context->output_table[i].UnprotectedAddr = 0;
		}
		if (context->output_table[i].BitstreamProtectedAddr) {
			DCCFree(context->dcc_info->pDCC, context->output_table[i].BitstreamProtectedAddr);
			context->output_table[i].BitstreamProtectedAddr = 0;
		}
		if (context->output_table[i].f_out) {
			fclose(context->output_table[i].f_out);
			context->output_table[i].f_out = NULL;
		}
	}
	RMFree(context->output_table);
	
	return err;
}

static RMstatus ResetOutputTablePerTask(struct context_per_task *context)
{
	RMuint32 i;

	RMDBGLOG((CALLDBG, "resetOutputTablePerTask (context @0x%08lx)\n", (RMuint32)context));

	for (i=0; i<context->output_table_count;i++) {
		if (context->output_table[i].demux_output_module_id) {
			RMuint32 dummy;
			RMstatus err;
			err = RUASetProperty(context->pRUA, context->output_table[i].demux_output_module_id,
				RMDemuxOutputPropertyID_Flush, &dummy, sizeof(dummy), 0);
			if( RMFAILED(err) ) {
				fprintf(stderr,"OutputEntry_Close %lx: RMDemuxOutputPropertyID_Flush failed %d", i, err);
			}

      if (context->output_table[i].pDma)
				err = RUAPreparePoolForReceiveData(context->output_table[i].pDma);

		}
		if (context->output_table[i].f_out) {
			fprintf(stderr, "********** %ld_Received output=%lx total_size=%lx\n",
				context->id, i, context->output_table[i].f_out_size);
			fseek(context->output_table[i].f_out, 0, SEEK_SET);
			context->output_table[i].f_out_size = 0;
		}
	}
	return RM_OK;
}
			
static RMstatus ReceiveDataAndSaveInFilePerTask(struct context_per_task *context)
{
	RMuint32 i;
	RMstatus err = RM_OK;
	RMuint8 *pBuf = NULL;
	RMuint32 size = 0;
	RMint32 irq_output_source;
		
	RMDBGLOG((CALLDBG, "receiveDataAndSaveInFilePerTask (context @0x%08lx)\n", (RMuint32)context));


	/* read irq_output_source - TODO check problem at the end when interrupt does not come and I miss some packets */
	RUAGetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_IrqOutputSource, &irq_output_source, sizeof(irq_output_source));
	//fprintf(stderr, "%ld_ReceiveDataAndSaveInFilePerTask irq_output_source=0x%lx\n", context->id, irq_output_source);

	for (i=0; i<context->output_table_count;i++) {
		RMuint32 received_buffer_count = 0;
		while(context->output_table[i].pDma && (irq_output_source & (1 << i))) {
			//fprintf(stderr, "%ld_ReceiveDataAndSaveInFilePerTask output=0x%lx check\n", context->id, i);
			err = RUAReceiveData(context->pRUA, EMHWLIB_MODULE(DemuxOutput, i + output_count_per_task*context->id),
				context->output_table[i].pDma, &pBuf, &size, NULL, NULL);
			if ( RMFAILED(err) || (pBuf == NULL) ) {
				//fprintf(stderr, "%ld_ReceiveDataAndSaveInFilePerTask output=0x%lx RM_ERROR or buf=0x%lx\n", context->id, i, (RMuint32)pBuf);
				err = RM_OK;
				break;
			}
			if ( size == 0 ) {
				//fprintf(stderr, "%ld_ReceiveDataAndSaveInFilePerTask output=0x%lx size=0x%lx\n", context->id, i, size);
				RUAReleaseBuffer(context->output_table[i].pDma, pBuf);
				break;
			}

			//fprintf(stderr, "%ld_ReceiveDataAndSaveInFilePerTask output=0x%lx size= 0x%lx\n", context->id, i, size);
			if (context->output_table[i].callback) {
				(context->output_table[i].callback)(pBuf, size, NULL, 0, RM_OK, context->output_table[i].section_mask, context);
			}
			if (context->output_table[i].f_out) {
				if (context->output_table[i].f_out_size < MAX_RECORD_FILE_SIZE) { /* save only MAX_RECORD_FILE_SIZE bytes */
					fwrite(pBuf, 1, size, context->output_table[i].f_out);
				}
				context->output_table[i].f_out_size += size;
			}
			
			while (0) {
				struct DemuxOutput_Pts45kFifoEntry_type pts_entry;

				err = RUAGetProperty(context->pRUA, EMHWLIB_MODULE(DemuxOutput, i + output_count_per_task*context->id),
					RMDemuxOutputPropertyID_Pts45kFifoEntry, &pts_entry, sizeof(pts_entry));
				if (err == RM_OK) {
					RMDBGLOG((LOCALDBG, "get pts=0x%lx bc=0x%lx\n", pts_entry.pts, pts_entry.byte_counter));
				}
				else
					break;
			}
			
			while (0) {
				struct InbandCommandX_type ibc_entry;

				err = RUAGetProperty(context->pRUA, EMHWLIB_MODULE(DemuxOutput, i + output_count_per_task*context->id),
					RMGenericPropertyID_InbandCommandX, &ibc_entry, sizeof(ibc_entry));
				if (err == RM_OK) {
					RMDBGLOG((LOCALDBG, "get ibc tag=0x%lx bc=0x%lx\n", ibc_entry.flags_tag, ibc_entry.offset_value));
				}
				else
					break;
			}
			
			RUAReleaseBuffer(context->output_table[i].pDma, pBuf);

			received_buffer_count++;
			if (received_buffer_count == context->output_table[i].buffer_count) {
				/* if one output is high bit rate we could stay in this while loop forever.
				   Let's try to go in main loop from time to time. */
				break;
			}
		}
	}
	return err;
}

#ifndef WITH_MONO
			
static void show_usage(char *progname)
{
	fprintf(stderr, "DEMUX OPTIONS (default values inside brackets)\n"
		"\t-task index, where index=[0],1,2\n"
		"\t-app [psf],dvb_arte,dvb_cwe,dvb_cwo,dvb_1ecm,dvb_4ecm,pes,vgs3\n"
		"\t-y [m2t],dvd,m1s\n"
	        "\t-tsskip: Number of padding bytes to discard between every 188 TS packets [0]. Use 4 for blue-ray streams\n"
		"\t-noucode: demux microcode is not loaded\n"
		"\t-vpid video_pid: [0]\n"
		"\t-apid audio_pid: [0]\n"
		"\t-rpid pcr_pid: [video_pid]\n"
		"\t-spi index: select paralel SPI and index=[0],1\n"
		"\t-ssi index: select serial SPI and index=[0],1,2\n"
		"\t-idleport index: select not used input port, needed for file playback, index=0,1,2,[3]\n"
		"\t-synclock count: select sync lock count for transport streams [0],1,..,7. Use not zero values for corrupted media. \n"
		"\t-pcrdisc threshold: threshold in ms [5000] \n"
		"\t-audiotspriority priority: [0],2,3\n"
		"\t-streamtype6 acodec: [dts],ac3\n"
		);
#ifdef WITH_AACS
	fprintf(stderr,
		"\t-aacs <xtask pid> <xtask context>\n");
	fprintf(stderr,
		"\t-mt <spn0> ... <spn5>\n"
		"\t-sk <playlist id> < playitem id>\n");
#endif /* WITH_AACS */
	show_playback_options();
	show_display_options();
	show_video_options();
	show_audio_options();

	fprintf(stderr, "--------------------------------\n");
	fprintf(stderr, "Minimum cmd line: %s <file name>\n", progname);
	fprintf(stderr, "--------------------------------\n");

	exit(1);
}

//extern RMstatus get_profile_profile(const char* prof, enum MPEG_Profile* profile);
//extern RMstatus get_profile_codec(const char* prof, enum VideoDecoder_Codec_type* type);

static void parse_cmdline(int argc, char *argv[])
{
	int i;
	RMstatus err = RM_OK;
	RMuint32 task_index = 0;
	struct playback_cmdline  *play_opt;
	struct display_cmdline   *disp_opt;
	struct video_cmdline     *video_opt;
	struct audio_cmdline     *audio_opt;
	struct demux_cmdline     *demux_opt;

	/* init first task in case "-task" option is not called */
	play_opt = &playback_options[0];
	disp_opt = &display_options[0];
	video_opt = &video_options[0];
	audio_opt = &audio_options[0];
	demux_opt = &demux_options[0];
	Tasks[0].id = 0;
	task_count = 0;

	if (argc < 2) 
		show_usage(argv[0]);
	
	i = 1;
	while ((argc > i)) {
		if ( ! strcmp(argv[i], "-multicast")) {				
			i++;			
			if (argc > i) {
				// strip port number
				char *port = strchr(argv[i], ':');
				printf("arg = '%s'\n", argv[i]);
				if (port != NULL) {
					play_opt->spi = FALSE;
					*port = '\0';
					port++;
					Tasks[task_index].MulticastAddress[Tasks[task_index].nMulticastStreams] = argv[i];
					Tasks[task_index].MulticastPort[Tasks[task_index].nMulticastStreams] = atoi(port);

					// set default audio/video codec
					Tasks[task_index].MulticastACodec[Tasks[task_index].nMulticastStreams] = AudioDecoder_Codec_MPEG1;
					Tasks[task_index].MulticastVCodec[Tasks[task_index].nMulticastStreams] = VideoDecoder_Codec_MPEG2_HD;
					Tasks[task_index].MulticastMPEGProfile[Tasks[task_index].nMulticastStreams] = Profile_MPEG2_HD;

					// enable auto codec detection
					video_options[task_index].auto_detect_codec = TRUE;
					audio_options[task_index].auto_detect_codec = TRUE;
						
					fprintf(stderr, "%ld_Stream %s:%lu\n", task_index,
						       Tasks[task_index].MulticastAddress[Tasks[task_index].nMulticastStreams],
						       Tasks[task_index].MulticastPort[Tasks[task_index].nMulticastStreams]);
					i++;
					Tasks[task_index].nMulticastStreams++;
				}
				else					
					break;		
			}
		}
		else if ((! strcmp(argv[i], "-c")) && (Tasks[task_index].nMulticastStreams > 0)) {
			/* the -c following -multicast */
			i++;
			if (argc > i) {
				audio_options[task_index].auto_detect_codec = FALSE;  /* use specified coded instead of auto detection */
				if ( ! (strcmp(argv[i], "ac3")) || ! (strcmp(argv[i], "ac3_20"))) {
					Tasks[task_index].MulticastACodec[Tasks[task_index].nMulticastStreams - 1] = AudioDecoder_Codec_AC3;
				} 
				else if ( ! (strcmp(argv[i], "mpeg"))) {
					Tasks[task_index].MulticastACodec[Tasks[task_index].nMulticastStreams - 1] = AudioDecoder_Codec_MPEG1;
				}
				else if ( ! (strcmp(argv[i], "aac1"))) {
					Tasks[task_index].MulticastACodec[Tasks[task_index].nMulticastStreams - 1] = AudioDecoder_Codec_AAC;
				}
				else {
					fprintf( stderr, "fixed audio codec %s is not supported, try auto detect\n", argv[i] );
					audio_options[task_index].auto_detect_codec = TRUE;
					break; // codec not supported
				}
			}
			else 
				break; // no codec found, cmdline is incorrect, the stream will be ignored
			i++;
		}
		else if ((! strcmp(argv[i], "-pv")) && (Tasks[task_index].nMulticastStreams > 0)) {

	                if (argc > i+1) {
        	                if (RMCompareAscii(argv[i+1], "auto")) {
					video_options[task_index].auto_detect_codec = FALSE;
	                        }
        	                else {
                	                err = get_profile_profile(argv[i+1], &(Tasks[task_index].MulticastMPEGProfile[Tasks[task_index].nMulticastStreams -1]) );
                        	        err = get_profile_codec(argv[i+1], &(Tasks[task_index].MulticastVCodec[Tasks[task_index].nMulticastStreams - 1]) );
	                        }
        	        }
                	else
                        	err = RM_ERROR;

	                if (err != RM_ERROR)
        	                err = RM_OK;
	                i+=2;
		}
		else if ( ! strcmp(argv[i], "-task")) {
			if (argc > i+1) {
				RMuint32 j = 0, task_id;
				task_id = strtol(argv[i+1], NULL, 10);
				if (task_id > MAX_TASK_COUNT)
					show_usage(argv[0]);
				i+=2;

				/* search for same task id */
				for (j=0; j < task_count; j++) {
					if( task_id == Tasks[j].id)
						break;
				}
				task_index = j;
				if ( task_index == task_count ) {
					/* new task id appeared */
					Tasks[task_index].id = task_id;
					task_count++;
					if (task_count > MAX_TASK_COUNT)
						show_usage(argv[0]);
					/* by default initialize the video, audio decoders as task id */
					video_options[task_index].VideoDecoderID = Tasks[task_index].id;
					audio_options[task_index].AudioDecoderID = Tasks[task_index].id;
					display_options[task_index].video_scaler = Tasks[task_index].id;
					if (Tasks[task_index].id ==2) {
						audio_options[task_index].AudioEngineID = 1;
						audio_options[task_index].AudioDecoderID = 0;
					}
				}
				play_opt = &playback_options[task_index];
				disp_opt = &display_options[task_index];
				video_opt = &video_options[task_index];
				audio_opt = &audio_options[task_index];
				demux_opt = &demux_options[task_index];
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-app")) {
			if (argc > i+1) {
				if ( ! strcmp(argv[i+1], "psf")) {
					Tasks[task_index].app_type = pid_filter_section;
					Tasks[task_index].SourceType = SourceType_m2t;
				}
				else if ( ! strcmp(argv[i+1], "dvb_arte")) {
					Tasks[task_index].app_type = dvbcsa_decryption;
					Tasks[task_index].SourceType = SourceType_m2t;
					Tasks[task_index].pkey_table = (void *)arte_dvb_key_table;
					Tasks[task_index].key_table_size = sizeof(arte_dvb_key_table)/sizeof(struct dvb_csa_key);
				}
				else if ( ! strcmp(argv[i+1], "dvb_cwe")) {
					Tasks[task_index].app_type = dvbcsa_decryption;
					Tasks[task_index].SourceType = SourceType_m2t;
					Tasks[task_index].pkey_table = (void *)cweven_dvb_key_table;
					Tasks[task_index].key_table_size = sizeof(cweven_dvb_key_table)/sizeof(struct dvb_csa_key);
				}
				else if ( ! strcmp(argv[i+1], "dvb_cwo")) {
					Tasks[task_index].app_type = dvbcsa_decryption;
					Tasks[task_index].SourceType = SourceType_m2t;
					Tasks[task_index].pkey_table = (void *)cwodd_dvb_key_table;
					Tasks[task_index].key_table_size = sizeof(cwodd_dvb_key_table)/sizeof(struct dvb_csa_key);
				}
				else if ( ! strcmp(argv[i+1], "dvb_1ecm")) {
					Tasks[task_index].app_type = dvbcsa_decryption;
					Tasks[task_index].SourceType = SourceType_m2t;
					Tasks[task_index].pkey_table = (void *)ecm1_dvb_key_table;
					Tasks[task_index].key_table_size = sizeof(ecm1_dvb_key_table)/sizeof(struct dvb_csa_key);
				}
				else if ( ! strcmp(argv[i+1], "dvb_4ecm")) {
					Tasks[task_index].app_type = dvbcsa_decryption;
					Tasks[task_index].SourceType = SourceType_m2t;
					Tasks[task_index].pkey_table = (void *)ecm4_dvb_key_table;
					Tasks[task_index].key_table_size = sizeof(ecm4_dvb_key_table)/sizeof(struct dvb_csa_key);
				}
				else if ( ! strcmp(argv[i+1], "vgs3")) {
					Tasks[task_index].app_type = dvbcsa_decryption;
					Tasks[task_index].SourceType = SourceType_m2t;
					Tasks[task_index].pkey_table = (void *)vgs3_key_table;
					Tasks[task_index].key_table_size = sizeof(vgs3_key_table)/sizeof(struct dvb_csa_key);
				}
				else if ( ! strcmp(argv[i+1], "pes")) {
					Tasks[task_index].app_type = program_stream_parsing;
				}
				else
					show_usage(argv[0]);
				i += 2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-y")) {
			if (argc > i+1) {
				if ( ! strcmp(argv[i+1], "m2t")) {
					Tasks[task_index].SourceType = SourceType_m2t;
				}
				else if ( ! strcmp(argv[i+1], "dvd")) {
					Tasks[task_index].SourceType = SourceType_dvd;
					Tasks[task_index].app_type = program_stream_parsing;
				}
				else if ( ! strcmp(argv[i+1], "m1s")) {
					Tasks[task_index].SourceType = SourceType_m1s;
				}
				else
					show_usage(argv[0]);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-tsskip")) {
			if (argc > i+1) {
				Tasks[task_index].ts_skip = strtol(argv[i+1], NULL, 10);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-vscaler")) {
			if (argc > i+1) {
				RMasciiToUInt32(argv[i+1], &(disp_opt->video_scaler));
				i += 2;
				if (disp_opt->video_scaler > 2) 
					show_usage(argv[0]);
			}
			else
				show_usage(argv[0]);
		
		}
#ifdef WITH_AACS
		else if ( ! strcmp(argv[i], "-aacs")) {
			if (argc > i + 2) {
				Tasks[task_index].aacs_xtask_pid = strtol(argv[i + 1], NULL, 0);
				Tasks[task_index].aacs_context = strtol(argv[i + 2], NULL, 0);
				i += 3;
			} else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-mt")) {
			if (argc > i + 6) {
			    RMuint32 j;
			    for (j = 1; j <= MAX_SP; j++)
				    Tasks[task_index].mt_spn[j - 1] = strtol(argv[i + j], NULL, 0);
			    Tasks[task_index].mt_index = 0;
			    i += 7;
			    Tasks[task_index].mt_enabled = 1;
			} else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-sk")) {
			if (argc > i + 2) {
				Tasks[task_index].sk_plid = strtol(argv[i + 1], NULL, 0);
				Tasks[task_index].sk_item = strtol(argv[i + 2], NULL, 0);
				Tasks[task_index].sk_enabled = 1;
				i += 3;
			} else
				show_usage(argv[0]);
		}
#endif /* WITH_AACS */
		else if ( ! strcmp(argv[i], "-spu")) {
			Tasks[task_index].enable_spu = TRUE;
			i++;
		}
		else if ( ! strcmp(argv[i], "-vpid")) {
			if (argc > i+1) {
				Tasks[task_index].video_pid = strtol(argv[i+1], NULL, 0);
				Tasks[task_index].av_flags |= VIDEO_PID_FROM_CMDLINE;
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-apid")) {
			if (argc > i+1) {
				Tasks[task_index].audio_pid = strtol(argv[i+1], NULL, 0);
				Tasks[task_index].av_flags |= AUDIO_PID_FROM_CMDLINE;
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-rpid")) {
			if (argc > i+1) {
				Tasks[task_index].pcr_pid = strtol(argv[i+1], NULL, 0);
				Tasks[task_index].av_flags |= PCR_PID_FROM_CMDLINE;
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-spi")) {
			play_opt->spi = TRUE;
			play_opt->serial_spi = FALSE;
			if (argc > i+1) {
				if ( (argv[i+1][0] == '0') || (argv[i+1][0] == '1') ) {
					Tasks[task_index].input_port = argv[i+1][0] - '0';
					/* for SPI the hardware input port are 0 and 2 */
					Tasks[task_index].input_port = 2* Tasks[task_index].input_port;
					i+=2;
				}
				else {
					fprintf(stderr, "Please specify -spi 0 or 1\n"); 
					show_usage(argv[0]);
				}
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-ssi")) {
			play_opt->spi = TRUE;
			play_opt->serial_spi = TRUE;
			if (argc > i+1) {
				if ( (argv[i+1][0] >= '0') && (argv[i+1][0] <= '2') ) {
					Tasks[task_index].input_port = argv[i+1][0] - '0';
					/* for SSI the hardware input port are 0, 1 and 2 */
					i+=2;
				}
				else {
					fprintf(stderr, "Please specify -ssi 0, 1 or 2 \n"); 
					show_usage(argv[0]);
				}
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-idleport")) {
			if (argc > i+1) {
				idle_port = strtol(argv[i+1], NULL, 10);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-synclock")) {
			if (argc > i+1) {
				Tasks[task_index].sync_lock = strtol(argv[i+1], NULL, 10);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-pcrdisc")) {
			if (argc > i+1) {
				Tasks[task_index].pcr_disc = strtol(argv[i+1], NULL, 10);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-audiotspriority")) {
			if (argc > i+1) {
				Tasks[task_index].audio_ts_priority = (enum EMhwlibTransportPriority_type)strtol(argv[i+1], NULL, 10);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-noucode")) {
			load_ucode = FALSE;
			i++;
		}
		else if ( ! strcmp(argv[i], "-monitor")) {
			Tasks[task_index].monitor = TRUE;
			i++;
		}
		else if ( ! strcmp(argv[i], "-timedbg")) {
			timedbg = TRUE;
			i++;
		}
		else if (RMCompareAscii(argv[i], "-dfifo")) {
			if (argc > i+1) {
				RMasciiToUInt32(argv[i+1], &(demux_opt->fifo_size));
				demux_opt->fifo_size *= 1024;
				i += 2;
				err = RM_OK;
			}
			else
				err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-dxfer")) {
			if (argc > i+1) {
				RMasciiToUInt32(argv[i+1], &(demux_opt->xfer_count));
				i += 2;
				err = RM_OK;
			}
			else
				err = RM_ERROR;
		}
		else if ( ! strcmp(argv[i], "-dump_socket_data")) {
			global_dump_socket_data = TRUE;
			i++;
		}
		else if (! strcmp(argv[i], "-streamtype6")) {
			if (argc > i+1) {
				err = RM_OK;
				if ( !(strcmp(argv[i+1], "ac3"))) {
					stream_type_6 = AudioDecoder_Codec_AC3;
				}
				else if ( ! (strcmp(argv[i+1], "dts"))) {
					stream_type_6 = AudioDecoder_Codec_DTS;
				} 
				else {
					err = RM_ERROR;
				}
			}
			else
				err = RM_ERROR;
			i+=2;
		}
		else {
			err = parse_playback_cmdline(argc, argv, &i, play_opt);
			if (err == RM_ERROR) 
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_display_cmdline(argc, argv, &i, disp_opt);
			if (err == RM_ERROR) 
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_video_cmdline(argc, argv, &i, video_opt);
			if (err == RM_ERROR)
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_audio_cmdline(argc, argv, &i, audio_opt);
			if (RMFAILED(err))
				show_usage(argv[0]);
		}
	}

	/* in case "-task" option was not called assume only one task */
	if (task_count == 0) {
		task_count = 1;
	}

	if (play_opt->spi == FALSE) {
		for (task_index = 0; task_index < task_count; task_index++) {
			if (Tasks[task_index].nMulticastStreams == 0)
				show_usage(argv[0]);
		}
	}
}
#endif /* ! WITH_MONO */


static RMbool CheckAllTaskReady (struct context_per_task *context)
{
	RMuint32 j;
	
	if (context->file_status == RM_ERRORENDOFFILE) {
		context->nTimes++;
		if (context->wait_eos_state)
			fprintf(stderr, "%lx_Stop received in WaitForEOS, %ld times\n", context->id, context->nTimes);
		context->file_status = RM_OK; /* remove EOS status RM_ERRORENDOFFILE */
		if (context->play_opt->loop_count > 0)
			context->play_opt->loop_count --;

		if ((context->play_opt->loop_count > 0) || (context->play_opt->infinite_loop)) {
#if 0
			if (RMSeekFile(context->file, 0, RM_FILE_SEEK_START) == RM_ERRORSEEKFILE) {
				fprintf(stderr, "%lx_Error seeking file to beginning\n", context->id);
				return TRUE;
			}
#endif
		}
		else if (context->play_opt->loop_count == 0) {
			/* check if all tasks are finished */
			RMuint32 done_tasks = 0;
			for (j=0; j< task_count; j++) {
				if ((Tasks[j].play_opt->loop_count > 0) || (Tasks[j].play_opt->infinite_loop))
					done_tasks++;
			}
			if(done_tasks == 0)
				return TRUE;
		}
	}

	return FALSE;
}

static RMstatus StopCleanup (struct context_per_task *context)
{
	RMuint32 j, index;
	RMstatus err;
	
	if(context->pDma) {
		if(context->buf)
			RUAReleaseBuffer(context->pDma, context->buf);
		err = RUAResetPool(context->pDma);	/* needed for no dram copy version on standalone */
		if (RMFAILED(err)) {
			fprintf(stderr, "%lx_Error cannot reset dmapool\n", context->id);
			return err;
		}
	}
		
	context->buf = NULL;
	context->buffer_used = FALSE;
	context->send_inband = FALSE;
	context->file_byte_counter = 0;
#if (EM86XX_CHIP != EM86XX_CHIPID_TANGO2)
	context->current_ecm_key = 0;
#endif
	for (index = 0; index < context->key_table_size; index++) {
		((struct dvb_csa_key *)context->pkey_table)[index].renew = FALSE;
		((struct dvb_csa_key *)context->pkey_table)[index].key_byte_counter = 0xffffffff;
	}
#if defined(WITH_AACS)
	context->mt_index = 0;
#endif /* WITH_AACS */
	if (context->file_status == RM_ERRORENDOFFILE) {
		context->nTimes++;
		if (context->wait_eos_state)
			fprintf(stderr, "%lx_Stop received in WaitForEOS, %ld times\n", context->id, context->nTimes);
		context->file_status = RM_OK; /* remove EOS status RM_ERRORENDOFFILE */
		if (context->play_opt->loop_count > 0)
			context->play_opt->loop_count --;

		if ((context->play_opt->loop_count > 0) || (context->play_opt->infinite_loop)) {
#if 0
			if (RMSeekFile(context->file, 0, RM_FILE_SEEK_START) == RM_ERRORSEEKFILE) {
				fprintf(stderr, "%lx_Error seeking file to beginning\n", context->id);
				return RM_ERROR;
			}
#endif
		}
		else if (context->play_opt->loop_count == 0) {
			/* check if all tasks are finished */
			RMuint32 done_tasks = 0;
			for (j=0; j< task_count; j++) {
				if ((Tasks[j].play_opt->loop_count > 0) || (Tasks[j].play_opt->infinite_loop))
					done_tasks++;
			}
			if(done_tasks == 0)
				return RM_ERROR;
		}
	}
	context->wait_eos_state = MAX_EVENT_COUNT_PER_TASK; /* invalid state */
	err = ResetOutputTablePerTask(context);

	return RM_OK;
}

static RMstatus HwStop(struct context_per_task *context)
{
	RMstatus err;

	RMDBGLOG((ENABLE, "stop\n"));

	/* stop STC, decoders, demux */
	err = DCCStopDemuxTask(context->dcc_info->pDemuxTask);
	if (RMFAILED(err)) {
		fprintf(stderr, "%lx_Cannot stop demux %d\n", context->id, err);
		return err;
	}
	if (context->dcc_info->pVideoSource) {
		err = DCCStopVideoSource(context->dcc_info->pVideoSource, DCCStopMode_LastFrame);
		if (RMFAILED(err)) {
			fprintf(stderr, "%lx_Cannot stop video decoder err=%d\n", context->id, err);
			return err;
		}
	}
	if (context->dcc_info->pAudioSource) {
		err = DCCStopAudioSource(context->dcc_info->pAudioSource);
		if (RMFAILED(err)) {
			fprintf(stderr, "%lx_Cannot stop audio decoder err=%d\n", context->id, err);
			return err;
		}
	}
	DCCSTCStop(context->dcc_info->pStcSource); // hack - stop STC after audio is stopped

	err = StopCleanup(context);
	
	return err;
}

static RMstatus HwPlay(struct context_per_task *context)
{
	RMstatus err;

	RMDBGLOG((ENABLE, "hwplay\n"));

	/* play STC, decoders, demux - no need for STC play if EMhwlibTimerSync_FirstPcrSetPlayStc is used for RMDemuxTaskPropertyID_TimerSync */
	if (!context->play_opt->send_video_pts && !context->play_opt->send_audio_pts && !context->play_opt->send_spu_pts) {
		fprintf(stderr, "%lx_DCCSTCSetTime 0\n", context->id);
		DCCSTCSetTime(context->dcc_info->pStcSource, 0, 45000);
		DCCSTCPlay(context->dcc_info->pStcSource);
	}
	DCCSTCSetSpeed(context->dcc_info->pStcSource, context->play_opt->speed_N, context->play_opt->speed_M);
	if (context->dcc_info->pVideoSource) {
		err = DCCPlayVideoSource(context->dcc_info->pVideoSource, DCCVideoPlayFwd);
		if (RMFAILED(err)) {
			fprintf(stderr, "%lx_Cannot play video decoder %d\n", context->id, err);
			return err;
		}
	}
	if (context->dcc_info->pAudioSource) {
		err = DCCPlayAudioSource(context->dcc_info->pAudioSource);
		if (RMFAILED(err)) {
			fprintf(stderr, "%lx_Cannot play audio decoder err=%d\n", context->id, err);
			return err;
		}
	}
	err = DCCPlayDemuxTask(context->dcc_info->pDemuxTask);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot play demux %d\n", err);
	}
	return err;
}

static RMstatus SendInbandCommands(struct context_per_task *context)
{
	RMstatus err = RM_OK;

	if (context->app_type == dvbcsa_decryption) {
		struct dvb_csa_key *key_table;
		RMuint32 index;

		for (index = 0; index < context->key_table_size; index++) {
			key_table = ((struct dvb_csa_key *)context->pkey_table) + index;
			if ((key_table->renew) && (context->file_byte_counter >= key_table->key_byte_counter)) {
				fprintf (stderr, "dvb key inband at file_byte_counter = %lx position=%lu\n", context->file_byte_counter, index);
				if (1) {
					err = DvbKeyInband(context, key_table->ecm_entry, key_table->scrambling, key_table->key, context->key_size);
				}
				else if (0) {
					err = DvbKeyOutband(context, key_table->ecm_entry, key_table->scrambling, key_table->key, context->key_size);
				}
				else if (0) {
					err = DvbKeyXtask(context, key_table->ecm_entry, key_table->scrambling, key_table->key);
				}
#if 0
				else {
					err = DvbKeyXtaskEncrypted(context, key_table->scrambling, key_table->key);
				}
#endif

				if (RMFAILED(err)) {
					fprintf (stderr, "dvb key inband failure\n");
					return RM_ERROR;
				}
		 		key_table->renew = FALSE; 
			}
		}
	}
#ifdef TEST_CUSTOM_INBAND
	else {
		/* table of demux byte counters corresponding to start of video frames (0x000001b3) */
		RMuint32 byte_cnt_nav1slds_dvd[] = {0, 0x64021-0x121, 0xca021-0x121, 0x134021-0x121, 0x19b021-0x121}; /* nav1slds.vob = 5 slides */
		RMuint32 byte_cnt_01301_m2t[] = {0x310-0x110, 0x31d50-0x150, 0x65710-0x110, 0x98e90-0x190}; /* 01301.m2ts = 4 slides */
		RMuint32 byte_cnt_nav1slds_twice[] = {0x1fc800-0x400}; /* 1 pts offset for nav1slds_twice.vob */
		RMuint32 byte_cnt_01301_twice[] = {0xc6000-0}; /* 1 pts offset for 01301_twice.m2ts */

		static RMuint32 state = 0; /* state machine to be used for special inband commands */
		RMuint32 test_id = 1; /* 0= user inbands, 1= pts offset, 2= aspect ratio + scaling */
		
		RMuint32 *byte_cnt; /* pointer to the list of byte_counters used for inband commands */
		RMuint32 ibc_cnt; /* number of inaband commands to send */
		struct InbandCommandX_type ibcx;
		
		if (context->app_type == program_stream_parsing) {
			byte_cnt = byte_cnt_nav1slds_dvd;
			ibc_cnt = sizeof(byte_cnt_nav1slds_dvd)/sizeof(RMuint32);
		}
		else {
			byte_cnt = byte_cnt_01301_m2t;
			ibc_cnt = sizeof(byte_cnt_01301_m2t)/sizeof(RMuint32);
		}
		
		if (test_id == 1) {
			if (context->app_type == program_stream_parsing) {
				/* test for pts_offset for nav1slds_twice.vob */
				byte_cnt = byte_cnt_nav1slds_twice;
				ibc_cnt = sizeof(byte_cnt_nav1slds_twice)/sizeof(RMuint32);
			}
			else {
				/* test for pts_offset for 01301_twice.m2ts */
				byte_cnt = byte_cnt_01301_twice;
				ibc_cnt = sizeof(byte_cnt_01301_twice)/sizeof(RMuint32);
			}
		}

		/* send the inband command 1 buffer before the required bytecounter, For fine tuning
		   make sure you use EMhwlibInbandOffset_Absolute */
		if (  byte_cnt[state] && ((context->file_byte_counter + (1<<context->play_opt->dmapool_log2size)) < byte_cnt[state]) )
			return RM_OK;

		if ( state >= ibc_cnt )
			return RM_OK;
		
		if (test_id == 0) {
			/* test user inbands - note that I use EMhwlibInbandOffset_Ignore and the inband will be posted
			   at the offset of the buffer containing the byte_counter from the table !*/
			ibcx.flags_tag = INBAND_COMMAND_TAG_USER0 | INBAND_COMMAND_CONSUMED_BY_USER;
			ibcx.offset_value = 0; /* ignored */
			if (context->app_type == program_stream_parsing)
				ibcx.output_mask = 3; /* video is demux output 0, audio is demux output 1 */
			else
				ibcx.output_mask = 0xc; /* video is demux output 2, audio is demux output 3 */
			ibcx.offset_control = EMhwlibInbandOffset_Ignore;
			err = RUASetProperty(context->pRUA, context->demux_task, RMGenericPropertyID_InbandCommandX,	&ibcx, sizeof(ibcx), 0);
			if ( RMSUCCEEDED(err) ) {
				fprintf (stderr, "\n ---- CustomInband at file_byte_counter=0x%lx ---- \n",
					context->file_byte_counter);
				state++;
			}
			return err;
		}
		else if (test_id == 1) {
			/* test pts offset */
			ibcx.flags_tag = INBAND_COMMAND_TAG_PTS_OFFSET;
			ibcx.offset_value = byte_cnt[state]; /* ignored */
			ibcx.output_mask = 0; /* no need to propagate it to the outputs */
			ibcx.offset_control = EMhwlibInbandOffset_Absolute;
			
			/* increase offset for every inband */
			ibcx.params.pts_offset_params.pts_offset = 5*state*90000;
			ibcx.params.pts_offset_params.time_resolution = 90000;

			if (context->app_type == program_stream_parsing) {
				/* constant offset for nav1slds_twice.vob */
				ibcx.params.pts_offset_params.pts_offset = 0x112eed*2;
			}
			else {
				/* constant offset for 01301_twice.m2ts */
				ibcx.params.pts_offset_params.pts_offset = 0xdbf24*2;
			}
			
			err = RUASetProperty(context->pRUA, context->demux_task, RMGenericPropertyID_InbandCommandX, &ibcx, sizeof(ibcx), 0);
			if ( RMSUCCEEDED(err) ) {
				fprintf (stderr, "\n ---- PtsOffset=0x%llx at absolute byte_counter=0x%lx file_byte_counter=0x%lx ---- \n",
					ibcx.params.pts_offset_params.pts_offset, byte_cnt[state], context->file_byte_counter);
				state++;
			}
			return err;
		}
		else if (test_id == 2) {
			/* test aspect ratio and scaling */
			struct TestAspectRatio {
				RMuint32 X;
				RMuint32 Y;
				RMuint32 ScalingMode;
				RMascii msg[30];
			};
			struct TestAspectRatio TAR[10] = {
				{ 16, 9, EMhwlibScalingMode_LetterBox, "16_9 -> 4_3 letterbox"},
				{ 16, 9, EMhwlibScalingMode_PanScan,   "16_9 -> 4_3 panscan"},
				{  4, 3, EMhwlibScalingMode_LetterBox, "4_3 -> 4_3"},
				{ 16, 9, EMhwlibScalingMode_LetterBox, "16_9 -> 4_3 letterbox"},
				{ 16, 9, EMhwlibScalingMode_PanScan,   "16_9 -> 4_3 panscan"},
				{  4, 3, EMhwlibScalingMode_LetterBox, "4_3 -> 4_3"},
			};

			ibcx.flags_tag = INBAND_COMMAND_TAG_ASPECT_RATIO;
			ibcx.offset_value = byte_cnt[state];
			if (context->app_type == program_stream_parsing)
				ibcx.output_mask = 1<<0; /* video is on demux output 0 */
			else
				ibcx.output_mask = 1<<2; /* video is on demux output 2 */
			ibcx.offset_control = EMhwlibInbandOffset_Absolute;
			
			ibcx.params.aspect_ratio_params.type = EMhwlibAspectRatio_Display;
			ibcx.params.aspect_ratio_params.ar.X = TAR[state].X;
			ibcx.params.aspect_ratio_params.ar.Y = TAR[state].Y;
			err = RUASetProperty(context->pRUA, context->demux_task, RMGenericPropertyID_InbandCommandX,
				&ibcx, sizeof(ibcx), 0);
			
			if ( RMSUCCEEDED(err) ) {
				ibcx.flags_tag = INBAND_COMMAND_TAG_SCALING_MODE;
				ibcx.params.scaling_params = TAR[state].ScalingMode;
				err = RUASetProperty(context->pRUA, context->demux_task, RMGenericPropertyID_InbandCommandX,
					&ibcx, sizeof(ibcx), 0);
				if ( RMSUCCEEDED(err) ) {
					fprintf (stderr, " ---- %s at absolute byte_counter=0x%lx file_byte_counter=0x%lx ----\n",
						TAR[state].msg, byte_cnt[state], context->file_byte_counter);
					state++;
				}
			}
			return err;
		}
	}
#endif // TEST_CUSTOM_INBAND
	return err;
}

static RMsocket OpenMulticast(RMascii *address, RMuint16 port)
{

	RMsocket socket; 
	RMstatus status;
fprintf( stderr, "***********************************open multicast ******************************\n" );
	socket = RMSocketOpenDgram((RMascii *)NULL, port);
	status = RMSocketJoinMulticastSession(socket, address, 0);
	if (status != RM_OK) return 0;

	return socket;
}


static void CloseMulticast(RMsocket socket)
{
	if (socket) RMSocketClose(socket);
}

static RMstatus SwitchMulticast(struct context_per_task *context)
{
	RMstatus err;

	if (context->nMulticastStreams <= 1) {
		fprintf(stderr, "%ld_nMulticastStreams(%ld) <= 1\n", context->id, context->nMulticastStreams);
		return RM_ERROR;
	}

	err = HwStop(context);
	if (RMFAILED(err)) {
		fprintf(stderr, "%ld_SwitchMulticast HwStop Error", context->id);
		return err;
	}

	CloseMulticast(context->multicastSocket);

	ResetDemuxTask(context);

	/* Open new multicast socket */
	context->MulticastCurrent = (context->MulticastCurrent + 1) % context->nMulticastStreams;
	context->multicastSocket = OpenMulticast((RMascii *)context->MulticastAddress[context->MulticastCurrent],
		(RMuint16)context->MulticastPort[context->MulticastCurrent]);
	if (context->multicastSocket == 0) {				
		fprintf(stderr, "%ld_SwitchMulticast: Failed to open multicast %s:%d\n", context->id,
			context->MulticastAddress[context->MulticastCurrent], (int) context->MulticastPort[context->MulticastCurrent]);
		return RM_ERROR;		
	}

	fprintf(stderr, "%ld_SwitchMulticast to %s:%lu\n", context->id,
		context->MulticastAddress[context->MulticastCurrent], context->MulticastPort[context->MulticastCurrent]);
    
	err = HwPlay(context);
	if (RMFAILED(err)) {
		fprintf(stderr, "%ld_SwitchMulticast HwPlay Error", context->id);
		return err;
	}
		  
	return RM_OK;
}

static RMstatus ProcessKey(void)
{
	RMstatus err;
	RMuint32 current_task, i, j;
	static struct RM_PSM_Actions actions;
	
	current_task = PSMcontext.currentActivePSMContext;
	if(current_task > task_count) {
		fprintf(stderr, "ERROR: currentActivePSMContext(%ld) >= task_count(%ld)\n", current_task, task_count);
		return RM_ERROR;
	}
	
	err = process_command(&PSMcontext, pdcc_info, &actions);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error while processing key %d\n", err);
		return RM_ERROR;
	}
	switch(actions.cmd){
		/* current_task value is 0 when all decoders are selected and 1,..task_count when aspecific decoder is selected */
	case RM_DECODER_CHANGE:
		current_task = PSMcontext.currentActivePSMContext;
		if(current_task > task_count) {
			fprintf(stderr, "ERROR: currentActivePSMContext(%ld) >= task_count(%ld)\n", current_task, task_count);
			return RM_ERROR;
		}
		break;
	case RM_STOP_SEEK_ZERO:
	case RM_STOP:
		for(i = 0; i < task_count; i++){
			if ( (current_task == i+1) || (current_task == 0) ) {
				StopCleanup(&Tasks[i]);
			}
		}
		break;
	case KEY_CMD_PAT_INFO: /* i */
		for(i = 0; i < task_count; i++) {
			if ( (current_task == i+1) || (current_task == 0) ) {
				RMDBGLOG((ENABLE, "pat info\n"));
				fprintf(stderr, "   %ld_PAT: ", Tasks[i].id);
				for (j=0; j<Tasks[i].pat_info.count; j++) {
					fprintf(stderr, "[%4x %3x] ", Tasks[i].pat_info.program_number[j],
						Tasks[i].pat_info.program_map_pid[j]);
				}
				fprintf(stderr, "\n");

				/* Add next code just for debug - randomly SwitchMulticast does not work and no data is received.
				   Calling RMSocketJoinMulticastSession seems to fix the problem! */
				err = RMSocketJoinMulticastSession(Tasks[i].multicastSocket, Tasks[i].MulticastAddress[Tasks[i].MulticastCurrent], 0);
				if (err != RM_OK) {
					fprintf(stderr, "RMSocketJoinMulticastSession %s:%d FAILED\n",
						Tasks[i].MulticastAddress[Tasks[i].MulticastCurrent], (int) Tasks[i].MulticastPort[Tasks[i].MulticastCurrent]);
					return RM_ERROR;
				}
				fprintf(stderr, "RMSocketJoinMulticastSession to %s:%lu\n",
					Tasks[i].MulticastAddress[Tasks[i].MulticastCurrent], Tasks[i].MulticastPort[Tasks[i].MulticastCurrent]);
			}
		}
		break;
	case KEY_CMD_CHANGE_CHANNEL: /* k */
		for (i = 0; i < task_count; i++) {
			if ( (current_task == i+1) || (current_task == 0) ) {
				fprintf(stderr, "change multicast\n");
				err = SwitchMulticast(&Tasks[i]);

			}
		}
		break;
	case KEY_CMD_CHANGE_PMT: /* m */
		for(i = 0; i < task_count; i++) {
			if ( (current_task == i+1) || (current_task == 0) ) {
				/*if (program_count <= 1) {
				  RMDBGLOG((ENABLE, "only one program\n"));
				  break;
				  }*/
				RMDBGLOG((ENABLE, "pmt change\n"));
				SetNextPMT(&Tasks[i]);
			}
		}
		break;
	case KEY_CMD_CHANGE_VIDEO: /* X */
		for(i = 0; i < task_count; i++) {
			if ( (current_task == i+1) || (current_task == 0) ) {
				RMDBGLOG((ENABLE, "video stream change\n"));
				if ( Tasks[i].VideoPidList.count > 1 ) {
					Tasks[i].VideoPidList.index = (Tasks[i].VideoPidList.index + 1)%Tasks[i].VideoPidList.count;
					err = SetPidFilterForAVPlayback(&Tasks[i]);
				}
			}
		}
		break;
	case RM_AUDIO_STREAM_CHANGE: /* A */
		for(i = 0; i < task_count; i++) {
			if ( (current_task == i+1) || (current_task == 0) ) {
				RMDBGLOG((ENABLE, "audio stream change\n"));
				if ( Tasks[i].AudioPidList.count > 1 ) {
					Tasks[i].AudioPidList.index = (Tasks[i].AudioPidList.index + 1)%Tasks[i].AudioPidList.count;
					err = SetPidFilterForAVPlayback(&Tasks[i]);
				}
			}
		}
		break;
	case RM_QUIT:
		for(i = 0; i < task_count; i++){
			if(current_task == i+1 || current_task == 0){
				if(Tasks[i].buf){
					RUAReleaseBuffer(Tasks[i].pDma, Tasks[i].buf);
					Tasks[i].buf = NULL;
				}
			}
		}
		return RM_ERROR;
	}
	return RM_OK;
}

/* sample code to compensate STC drift */
static RMstatus StcCompensation(struct context_per_task *context)
{
#define STCC_INTV    10      /* averaging of PCR-STC difference over STC_INTV seconds */
#define STCC_CORR    60      /* correction attempts every STC_CORR seconds */
#define STCC_MAX     50      /* limit ppm value to -STCC_MAX .. STCC_MAX */
#define STCC_DISCONT 90000   /* discontinuity threshold (1 Sec.) */
			
/* rounding division, returns (RMint)a / (RMuint)b */
#define RNDDIV(a, b) (((a) < 0) ? -((-(a) + (b) / 2) / (b)) : (((a) + (b) / 2) / (b)))
			
	RMstatus err;
	RMuint32 stc_dbg = context->play_opt->stc_comp_debug;  // Debug message level: 0=silent, 1=corrective actions 2=actions 3=all
	struct DemuxTask_CurrentPcrInfo_in_type pcr_in;
	struct DemuxTask_CurrentPcrInfo_out_type pcr_out;
	struct RUAEvent e;
	RMuint64 stc32, pcr32, ustime;
	RMint64 delta;
	static RMuint32 avrg_n = 0; /* number of samples in averaging sccumulator */
	static RMint64 avrg_delta = 0; /* accumulated delta values */
	static RMint64 last_delta = 0; /* previous delta value */
	static RMuint64 ustime0 = 0, ustime1 = 0, ustime2 = 0, last_ustime = 0;
	static RMint64 dist_last = 0;
	static RMint64 STC_ppb = 0;
	
	pcr_in.time_resolution = 90000; // native
	e.ModuleID = context->demux_task;
	e.Mask = SOFT_IRQ_EVENT_DEMUX_PCR_UPDATE;
	
	if ((err = RUAWaitForMultipleEvents(context->pRUA, &e, 1, 0, NULL)) == RM_OK) {
		ustime = get_ustime();
		err = RUAExchangeProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_CurrentPcrInfo,
			&pcr_in, sizeof(pcr_in), &pcr_out, sizeof(pcr_out));
		if (RMFAILED(err))
			return err;
		
		/* Truncate to 32 bit */
		stc32 = pcr_out.stc & 0xFFFFFFFF;
		pcr32 = pcr_out.pcr & 0xFFFFFFFF;
		
		/* Handle wraparound case */
		if ((stc32 > 0xC0000000) && (pcr32 < 0x40000000)) pcr32 += 0x100000000LL;
		if ((stc32 < 0x40000000) && (pcr32 > 0xC0000000)) stc32 += 0x100000000LL;
		
		/* Current delta */
		delta = (RMint64)(stc32 - pcr32);
		if (stc_dbg >= 3) fprintf(stderr, "\rSTC-PCR:%6lld ", delta);
		if (RMabs(delta) > STCC_DISCONT) { /* discontinuity, reset offset */
			if (stc_dbg >= 2) fprintf(stderr, "\nReset drift averages @ PCR=0x%llX STC=0x%llX delta=%lld\n", 
				pcr32, stc32, delta);
			delta = 0;
		}
		
		/* Every STCC_CORR seconds, average delta over the last STCC_INTV sec. */
		if ((! ustime0) || ((RMuint32)(ustime - ustime0) >= (RMuint32)(STCC_CORR * 1000000))) {
			if (! ustime1) ustime1 = ustime;
			if (! ustime2) {
				if ((RMuint32)(ustime - ustime1) >= (RMuint32)(STCC_INTV * 1000000)) {
					ustime2 = ustime;
				}
				avrg_delta += delta;
				avrg_n++;
				fprintf(stderr, "| avrg/%03lu: %6lld ", avrg_n, RNDDIV(avrg_delta, avrg_n));
			} else {
				RMuint64 curr_ustime, t;
				RMint64 curr_delta, dist, ppb;
				
				/* Determine center time of average */
				curr_ustime = ustime1 + (ustime2 - ustime1) / 2;
				
				/* Normalize delta average to picoSec */
				curr_delta = RNDDIV(avrg_delta * 100000, avrg_n * 9);
				
				if (last_ustime) {
					/* Determine time "t" since last update */
					t = curr_ustime - last_ustime; 
					
					/* Drift in ppb is delta difference (in picoSec.) over t (in Sec.) */
					ppb = RNDDIV((curr_delta - last_delta) * 1000000LL, t);
				} else {
					/* No comparison on first average */
					t = STCC_INTV * 1000000LL;
					ppb = 0;
				}
				
				/* Spread out current delta over next 10 cycle to create distance correction value */
				dist = RNDDIV(curr_delta, STCC_CORR * 10);
				
				if (stc_dbg >= 3) fprintf(stderr, "| delta/%03lu: %6lld | drift: %4lld ppb ", 
					avrg_n, curr_delta, ppb);
				
				if (stc_dbg >= 1) {
					fprintf(stderr, "\n*** Elapsed time: %llu:%02llu \n", t / (60 * 1000000LL), (t / 1000000LL) % 60);
					fprintf(stderr, "    STC to PCR drift: %lld ppb, net. drift: %lld ppb\n", ppb, ppb + dist_last);
					fprintf(stderr, "    PCR to STC distance: %lld pSec\n", curr_delta);
					fprintf(stderr, "    distance compensation: %lld ppb\n", -dist);
					fprintf(stderr, "    Last net. drift correction: %lld ppb\n", STC_ppb + dist_last);
					fprintf(stderr, "    Next net. drift correction: %lld ppb\n", STC_ppb - ppb);
				}
				
				/* Compensate for drift */
				STC_ppb -= ppb;
				
				/* Overcompensate to target correct value after next cycle */
				STC_ppb -= dist;
				
				/* Make sure STC_ppm stays inbetween -STCC_MAX .. STCC_MAX */
				if (STC_ppb > (STCC_MAX * 1000LL)) STC_ppb = STCC_MAX * 1000LL;
				else if (STC_ppb < (STCC_MAX * -1000LL)) STC_ppb = STCC_MAX * -1000LL;
				
				/* Write significant values into logfile */
				if (context->stcd) fprintf(context->stcd, "%lld\t%lld\t%lld\t%lld\n", curr_delta, ppb, -dist_last, STC_ppb);
				
				if (stc_dbg >= 1) fprintf(stderr, "    STC correction: %lld ppb, includes %lld ppb distance compensation\n", 
					STC_ppb, -dist);
				
				/* Adjust speed */
				err = DCCVCXOSetSpeedAVCorrect(context->dcc_info->pStcSource, 1000000000 + STC_ppb, 1000000000);
//				err = DCCSTCSetSpeedCleanDiv(context->dcc_info->pStcSource, 1000000000 + STC_ppb, 1000000000);
//				err = DCCSTCSetSpeedVCXO(context->dcc_info->pStcSource, 1000000000 + STC_ppb, 1000000000);
				
				/* Store and reset values */
				dist_last = dist;
				last_ustime = curr_ustime;
				last_delta = curr_delta;
				ustime0 = ustime1;
				ustime1 = 0;
				ustime2 = 0;
				avrg_delta = 0;
				avrg_n = 0;
			}
		}
	}

	return err;
}

#ifdef WITH_MONO
int main_psfdemux(struct mono_info *mono)
#else
int main(int argc, char *argv[])
#endif
{
	struct dcc_context dcc_info[MAX_TASK_COUNT] = { {0, } };
	struct DCC *pDCC = NULL;
	struct RUA *pRUA = NULL;
	struct RUAEvent event_list[1 + MAX_EVENT_COUNT_PER_TASK * MAX_TASK_COUNT];
	
	RMuint32 i = 0;
	RMstatus err;
	RMuint32 event_index;
	RMuint32 WaitEventsMask = 0, BlockingWaitEventsMask = 0;

	struct DemuxTask_InputParameters_type InParam;
	//struct stream_options_s stream_options;
	RMuint64 startTime = 0;
#ifdef AUTO_CHANGE_CHANNEL
	RMuint64 periodTime = 0;
#endif
	
	/* init variables that do not depend on parse_cmdline */
	for (i = 0; i < MAX_TASK_COUNT; i++) {
		/* is this really needed? */
		RMMemset(&Tasks[i], 0, sizeof(struct context_per_task));
		RMMemset(&dcc_info[i], 0, sizeof(struct dcc_context));
#ifdef WITH_MONO

		Tasks[i].play_opt = mono->play_opt;
		Tasks[i].video_opt = mono->video_opt;
		Tasks[i].disp_opt = mono->disp_opt;
		Tasks[i].audio_opt = mono->audio_opt;
		Tasks[i].demux_opt = mono->demux_opt;
		dcc_info[i].disp_info = NULL;
  		/* TODO 
		 * 1)use the videoscaler set by mono
		 * 2)do something about audio_pid and video_pid
		 */
		switch (mono->demux_opt->system_type) {
		case RM_SYSTEM_MPEG2_TRANSPORT:
			RMDBGLOG((ENABLE, "----> M2T\n"));
			Tasks[i].SourceType = SourceType_m2t;
			break;
		case RM_SYSTEM_MPEG2_TRANSPORT_192:
			RMDBGLOG((ENABLE, "----> M2T with ts_skip = 4\n"));
			Tasks[i].SourceType = SourceType_m2t;
			Tasks[i].ts_skip = 4;
			break;
		case RM_SYSTEM_MPEG1:
			RMDBGLOG((ENABLE, "----> M1S\n"));
			Tasks[i].SourceType = SourceType_m1s;
			break;
		case RM_SYSTEM_MPEG2_DVD:
			RMDBGLOG((ENABLE, "----> DVD\n"));
			Tasks[i].SourceType = SourceType_dvd;
			break;
		case RM_SYSTEM_MPEG2_PROGRAM:
			RMDBGLOG((ENABLE, "----> M2P\n"));
			Tasks[i].SourceType = SourceType_m1s;
			break;
		default:
			RMDBGLOG((ENABLE, "unsupported type %ld\n", mono->demux_opt->system_type));
			return -1;
			break;
		}
#else
		Tasks[i].play_opt = &playback_options[i];
		Tasks[i].disp_opt = &display_options[i];
		Tasks[i].video_opt = &video_options[i];
		Tasks[i].audio_opt = &audio_options[i];
		Tasks[i].demux_opt = &demux_options[i];
		dcc_info[i].disp_info = &disp_info[i];
		dcc_info[i].dh_info = &dh_info[i];

		init_display_options(Tasks[i].disp_opt);
		init_video_options(Tasks[i].video_opt);
		init_audio_options(Tasks[i].audio_opt);
		init_playback_options(Tasks[i].play_opt);
		Tasks[i].audio_opt->dh_info = &dh_info[i];
		Tasks[i].disp_opt->dh_info = &dh_info[i];
		Tasks[i].SourceType = SourceType_m2t;

#endif
		/*common*/
		Tasks[i].video_opt->display_cc = FALSE;
		pdcc_info[i] = &dcc_info[i];
		dcc_info[i].RM_PSM_commands = RM_PSM_ENABLE_PLAY;
		dcc_info[i].RM_PSM_commands |= RM_PSM_ENABLE_STOP;
		dcc_info[i].RM_PSM_commands |= RM_PSM_ENABLE_PAUSE;
		dcc_info[i].RM_PSM_commands |= RM_PSM_ENABLE_SWITCHAUDIO;
		dcc_info[i].RM_PSM_commands |= RM_PSM_ENABLE_SWITCHVIDEO;

		dcc_info[i].route = DCCRoute_Main;
		dcc_info[i].trickmode_id = RM_NO_TRICKMODE;
		dcc_info[i].state = RM_PLAYING;
		
		Tasks[i].app_type = pid_filter_section;
		Tasks[i].input_port = Tasks[i].id;
		Tasks[i].wait_eos_state = MAX_EVENT_COUNT_PER_TASK; /* invalid state */
		Tasks[i].av_flags = AV_PIDS_ENABLE_FIRST_TIME;
		Tasks[i].video_pid = 0x1FFF;
		Tasks[i].audio_pid = 0x1FFF;
		Tasks[i].pcr_pid = 0x1FFF;
		Tasks[i].ecm_pid[0] = 0x1FFF;
		Tasks[i].ecm_pid[1] = 0x1FFF;

		Tasks[i].pcr_disc = 10000; /* 10sec */
		/* TODO - port DCCMultipleAudioInstance - for time being initialize to the default one instance */
		Tasks[i].audioInstances = 1;
	}

#ifdef WITH_MONO
	pRUA = mono->pRUA;
	pDCC = mono->pDCC;
	task_count = 1;
#else
	parse_cmdline(argc, argv);
	
	RMDBGLOG((ENABLE, "creating RUA instance\n"));
	err = RUACreateInstance(&pRUA, Tasks[0].play_opt->chip_num);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error creating RUA instance! %d\n", err);
		return -1;
	}

	RMDBGLOG((ENABLE, "opening DCC\n"));
	err = DCCOpen(pRUA, &pDCC);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error Opening DCC! %d\n", err);
		return -1;
	}

	if (load_ucode) {
		RMDBGLOG((ENABLE, "init microcode\n"));
		err = DCCInitMicroCodeEx(pDCC, Tasks[0].disp_opt->init_mode);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot initialize microcode %d\n", err);
			return -1;
		}
	}
	RMTermInit(TRUE);    // don't allow ctrl-C and the like ...
	RMSignalInit(NULL, NULL);  // ... but catch other termination signals to call RMTermExit()
#endif

	{
		RMuint32 nb_demux_tasks;
		RMuint32 module_id = EMHWLIB_MODULE(DemuxTask,0);
		err = RUAExchangeProperty(pRUA, EMHWLIB_MODULE(Enumerator,0),  RMEnumeratorPropertyID_CategoryIDToNumberOfInstances, 
					  &(module_id), sizeof(module_id), &nb_demux_tasks, sizeof(nb_demux_tasks));
		
		module_id = EMHWLIB_MODULE(DemuxOutput,0);
		err = RUAExchangeProperty(pRUA, EMHWLIB_MODULE(Enumerator,0),  RMEnumeratorPropertyID_CategoryIDToNumberOfInstances, 
					  &(module_id), sizeof(module_id), &output_count_per_task, sizeof(output_count_per_task));
		output_count_per_task = output_count_per_task / nb_demux_tasks;
	}

	/* initialize variables depending on parse_cmdline and open the emhwlib modules */
	{
		/* enable closed caption only for one task - the one selected by user or by default first one */
		RMbool cc_enabled = FALSE;
		for (i=0; i< task_count; i++) {
			if (cc_enabled) {
				/* disable cc for all the other tasks */
				Tasks[i].video_opt->display_cc = FALSE;
			}
			if (Tasks[i].video_opt->display_cc) {
				/* first task with cc enabled will display closed caption */
				cc_enabled = TRUE;
			}
		}
		if (!cc_enabled) {
			/* enable by default only first task */
			//Tasks[0].video_opt->display_cc = TRUE; //it does not work for multiple processes
		}
	}

	/* to do default detection ... */
	if (idle_port > 3)
		idle_port = 4 - task_count;

	/* initialize variables depending on parse_cmdline and open the emhwlib modules */
	for (i = 0; i < task_count; i++) {

		struct PSFDemuxTaskProfile demux_profile;
		struct DCCStcProfile stc_profile;
		enum EMhwlibTimerSync timer_sync;
		RMuint32 index = Tasks[i].MulticastCurrent;

		fprintf(stderr, "\n****************** open %lx/%lx: task = %lx ******************\n", i+1, task_count, Tasks[i].id);
	
		RMMemset(&demux_profile, 0, sizeof(demux_profile));

		dcc_info[i].pRUA = pRUA;
		dcc_info[i].pDCC = pDCC;
		Tasks[i].pRUA = pRUA;
		Tasks[i].dcc_info = &dcc_info[i];
		if (Tasks[i].video_opt->fifo_size == 0) 
			Tasks[i].video_opt->fifo_size = VIDEO_FIFO_SIZE;
		if (Tasks[i].audio_opt->fifo_size == 0) 
			Tasks[i].audio_opt->fifo_size = AUDIO_FIFO_SIZE;
		if (Tasks[i].demux_opt->fifo_size == 0) 
			Tasks[i].demux_opt->fifo_size = DEMUX_FIFO_SIZE;
		if (Tasks[i].demux_opt->xfer_count == 0)
			Tasks[i].demux_opt->xfer_count = DEMUX_XFER_FIFO_COUNT;
		if (Tasks[i].play_opt->dmapool_count == 0)
			Tasks[i].play_opt->dmapool_count = DMA_BUFFER_COUNT;
		if (Tasks[i].play_opt->dmapool_log2size == 0)
			Tasks[i].play_opt->dmapool_log2size = DMA_BUFFER_SIZE_LOG2;

		if (Tasks[i].play_opt->stc_compensation && (Tasks[i].play_opt->stc_comp_debug >= 4)) {
			Tasks[i].stcd = fopen("STC_Debug.txt", "w");
			if (Tasks[i].stcd)
				fprintf(Tasks[i].stcd, "STC-PCR pSec.\tDrift ppb\tDist. corr. ppb\tSTC corr. ppb\n");
		}
		err = InitTableVariables(&Tasks[i]);
		if (RMFAILED(err))
			goto cleanup;

		err = apply_playback_options(&dcc_info[i], Tasks[i].play_opt);
		if (RMFAILED(err)) {
			fprintf(stderr, "%ld_Cannot set playback options err=%d\n", Tasks[i].id, err);
			goto cleanup;
		}

		/* open DemuxTask module */
#ifdef WITH_AACS
		demux_profile.ProtectedFlags = Tasks[i].aacs_xtask_pid ? 
			EMHWLIB_USE_ERASER_FIFO : 0;
#else
		demux_profile.ProtectedFlags = 0;
#endif
		demux_profile.BitstreamFIFOSize = Tasks[i].play_opt->spi ? 0 : Tasks[i].demux_opt->fifo_size;
		demux_profile.XferFIFOCount = Tasks[i].play_opt->spi ? 0:Tasks[i].demux_opt->xfer_count;
		demux_profile.InbandFIFOCount = Tasks[i].play_opt->spi ? 0:128;
		demux_profile.DemuxTaskID = Tasks[i].id;
		demux_profile.InputPort = Tasks[i].input_port;
		demux_profile.PrimaryMPM = Tasks[i].id;	/* parsing mpm */
		demux_profile.SecondaryMPM = Tasks[i].play_opt->spi ? Tasks[i].id : 3; /* input mpm */
#ifdef WITH_AACS
		demux_profile.XTaskModuleId = Tasks[i].aacs_xtask_pid ? EMHWLIB_MODULE(XTask, Tasks[i].aacs_xtask_pid) : 0;
		demux_profile.XTaskContext = Tasks[i].aacs_context;
		demux_profile.XTaskInbandFIFOCount = 128;
#endif /* WITH_AACS */
		err = PSFOpenDemuxTask(pDCC, &demux_profile, &(dcc_info[i].pDemuxTask));
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot open demux %d\n", err);
			goto cleanup;
		}
		
		err = DCCGetDemuxTaskInfo(dcc_info[i].pDemuxTask, &(dcc_info[i].demux_task));
		if (RMFAILED(err)) {
			fprintf(stderr, "Error getting demux_task source information %d\n", err);
			goto cleanup;
		}
		fprintf(stderr, "dcc_info[%ld].demux_task =  %ld\n", i, dcc_info[i].demux_task);

		Tasks[i].demux_task = dcc_info[i].demux_task;

		/* open stc module */
		stc_profile.STCID = Tasks[i].id;
		stc_profile.master = Master_STC;

		stc_profile.stc_timer_id = 3*Tasks[i].id;
		stc_profile.stc_time_resolution = 90000;

		stc_profile.video_timer_id = 3*Tasks[i].id+1;
		stc_profile.video_time_resolution = 90000;

		if (!Tasks[i].play_opt->video_delay_ms) {
			RMDBGLOG((ENABLE, "use default video STC offset of 2 seconds\n"));
			Tasks[i].play_opt->video_delay_ms = 2000;
		}
		else
			RMDBGLOG((ENABLE, ">> video STC offset %lu\n", Tasks[i].play_opt->video_delay_ms));
		
		stc_profile.video_offset = -(Tasks[i].play_opt->video_delay_ms * (RMint32)stc_profile.video_time_resolution / 1000);

		stc_profile.audio_timer_id = 3*Tasks[i].id+2;
		stc_profile.audio_time_resolution = 90000;

		if (!Tasks[i].play_opt->audio_delay_ms) {
			RMDBGLOG((ENABLE, "use default audio STC offset of 2 seconds\n"));
			Tasks[i].play_opt->audio_delay_ms = 2000;
		}
		else
			RMDBGLOG((ENABLE, ">> audio STC offset %lu\n", Tasks[i].play_opt->audio_delay_ms));

		stc_profile.audio_offset = -(Tasks[i].play_opt->audio_delay_ms * (RMint32)stc_profile.audio_time_resolution / 1000);
			
		err = DCCSTCOpen(pDCC, &stc_profile, &dcc_info[i].pStcSource);
		if (RMFAILED(err)) {
			fprintf(stderr, "%lx_Cannot open stc module err=%d\n", Tasks[i].id, err);
			goto cleanup;
		}
		
		if (Tasks[i].play_opt->spi == FALSE) {
			/* local file - dmapool must be created after the module open in case we do no copy transfers */
			err = RUAOpenPool(pRUA, Tasks[i].demux_task, Tasks[i].play_opt->dmapool_count, Tasks[i].play_opt->dmapool_log2size,
					  RUA_POOL_DIRECTION_SEND, &Tasks[i].pDma);
			if (RMFAILED(err)) {
				fprintf(stderr, "%ld_Error cannot open dmapool err=%d\n", Tasks[i].id, err);
				goto cleanup;
			}

			RMDBGLOG((ENABLE, "total multicast streams %lu, selecting %lu\n", Tasks[i].nMulticastStreams, index));
			RMDBGLOG((ENABLE, ">> open multicast address %s, port %u\n", Tasks[i].MulticastAddress[index], Tasks[i].MulticastPort[index]));
				

			Tasks[i].multicastSocket = OpenMulticast((RMascii *)Tasks[i].MulticastAddress[index], (RMuint16)Tasks[i].MulticastPort[index]);
			if (Tasks[i].multicastSocket == 0) {				
				fprintf(stderr, "Failed to open multicast %s:%d	\n", Tasks[i].MulticastAddress[index], (int) Tasks[i].MulticastPort[index]);
				goto cleanup;		
			}
		}
		Tasks[i].audio_opt->Codec = Tasks[i].MulticastACodec[index];
		Tasks[i].video_opt->Codec = Tasks[i].MulticastVCodec[index];
		Tasks[i].video_opt->MPEGProfile = Tasks[i].MulticastMPEGProfile[index];
		
		/* set input parameters */
		InParam.Spi = Tasks[i].play_opt->spi ? (Tasks[i].play_opt->serial_spi ? Serial_Spi : Paralel_Spi) : No_Spi;
		InParam.SourceType = Tasks[i].SourceType;
		err = RUASetProperty(pRUA, Tasks[i].demux_task, RMDemuxTaskPropertyID_InputParameters, &InParam, sizeof(InParam), 0);
		err = RUASetProperty(pRUA, Tasks[i].demux_task, RMDemuxTaskPropertyID_IdleInputPort, &idle_port, sizeof(idle_port), 0);
		err = RUASetProperty(pRUA, Tasks[i].demux_task, RMDemuxTaskPropertyID_TSSyncLockCount, &Tasks[i].sync_lock, sizeof(Tasks[i].sync_lock), 0);

		RUASetProperty(pRUA, Tasks[i].demux_task, RMDemuxTaskPropertyID_TsSkipBytes, &Tasks[i].ts_skip, sizeof(RMuint32), 0);
		{
			struct DemuxTask_PcrDiscontinuity_type discont;
			discont.threshold = Tasks[i].pcr_disc * 90;	/* default 10 sec */
			discont.time_resolution = 90000;
			err = RUASetProperty(pRUA, Tasks[i].demux_task, RMDemuxTaskPropertyID_PcrDiscontinuity, &discont, sizeof(discont), 0);
		}
		if (!Tasks[i].play_opt->send_video_pts && !Tasks[i].play_opt->send_audio_pts && !Tasks[i].play_opt->send_spu_pts)
			timer_sync = EMhwlibTimerSync_None;
		else
			timer_sync = EMhwlibTimerSync_FirstPcrSetPlayStc;
		RUASetProperty(pRUA, Tasks[i].demux_task, RMDemuxTaskPropertyID_TimerSync, &timer_sync, sizeof(timer_sync), 0);
		/* init cipher tables according to application type */
		err = InitKeyAndCipherTable(&Tasks[i]);
		if (RMFAILED(err))
			goto cleanup;

		/* init pid,section, output tables according to application type */
		if (Tasks[i].app_type == program_stream_parsing) {
			Tasks[i].av_flags &= ~AV_PIDS_ENABLE_FIRST_TIME;
			err = InitPesTablePerTask(&Tasks[i]);
			if (RMFAILED(err))
				goto cleanup;
			err = OpenOutputTableForRecord(&Tasks[i]);
			if (RMFAILED(err)) {
				fprintf(stderr, "OpenOutputTableForRecord failed %d\n", err);
				goto cleanup;
			}
			err = OpenOutputTableForPlayback(&Tasks[i]);
			if (RMFAILED(err)) {
				fprintf(stderr, "OpenOutputTableForPlayback failed %d\n", err);
				goto cleanup;
			}
		}
		else {
			err = InitSectionTable(&Tasks[i]);
			if (RMFAILED(err))
				goto cleanup;
			err = InitPidTablePerTask(&Tasks[i]);
			if (RMFAILED(err))
				goto cleanup;
			err = OpenOutputTableForRecord(&Tasks[i]);
			if (RMFAILED(err)) {
				fprintf(stderr, "OpenOutputTableForRecord failed %d\n", err);
				goto cleanup;
			}
			err = OpenOutputTableForPlayback(&Tasks[i]);
			if (RMFAILED(err)) {
				fprintf(stderr, "OpenOutputTableForPlayback failed %d\n", err);
				goto cleanup;
			}
		}
		
		if (Tasks[i].av_flags & (VIDEO_PID_FROM_CMDLINE | PCR_PID_FROM_CMDLINE | AUDIO_PID_FROM_CMDLINE)) {
			fprintf(stderr, "Video and audio pids set by command line options \n");
			SetHwAVPlayback(&Tasks[i]);
		}
	}
	
	PSMcontext.validPSMContexts = task_count;
	PSMcontext.currentActivePSMContext = 0;
	PSMcontext.keyflags = KEYFLAGS;

	RM_PSM_SetState(&(PSMcontext), pdcc_info, RM_PSM_Playing);

#if DUMP_SOCKET_DATA
	for (i = 0; i < task_count; i++) {
		if (global_dump_socket_data) {
			RMascii tempstr[1024];
			sprintf( tempstr, "psfdemux_multicast_socketData.dump%ld", Tasks[i].id );
			RMDBGLOG((ENABLE, "\t\t\t***** OPEN SAVE DATA FILE ****\n"));
			global_saveFile[i] = fopen(tempstr, "wb");
		}
	}
#endif

	for (i = 0; i < task_count; i++) {

		err = HwPlay(&Tasks[i]);
		if (RMFAILED(err)) {
			fprintf(stderr, "%lx_HwPlay err=%d\n", Tasks[i].id, err);
			goto cleanup;
		}
	}

	startTime = get_ustime();

#ifdef AUTO_CHANGE_CHANNEL
	periodTime = startTime;
#endif
	

#ifdef WITH_MONO
	RMDCCInfo(&dcc_info[0]); // pass DCC context to application
#endif


	RMDBGLOG((ENABLE, "\t****** WHILE(1) ******, task count %lu\n", task_count));

#if 0
{
//	static RMuint64 FirstLogTime;
//	static RMuint64 SecondLogTime = 0;
	static RMuint8 buff[(1 << DMA_BUFFER_SIZE_LOG2)];
	RMuint32 bufSize = (1 << DMA_BUFFER_SIZE_LOG2);
	
	while (1) {
		err = ProcessKey();
		if (RMFAILED(err))
			goto cleanup;
		
		for (i = 0; i < task_count; i++) {
			RMuint32 count = 0;
			RMuint64 readCount = 0;
			RMuint32 bytesLeft = bufSize;

//FirstLogTime = get_ustime();
//fprintf( stderr, " %lld  first %lld,  \t", FirstLogTime-SecondLogTime, FirstLogTime );
			while (readCount < (RMuint64)bufSize) {  // read one dma buffer of data
						RMsocket dummy;
						RMint16 dataReadyOnUDP;
						dataReadyOnUDP = RMSocketSelect(&Tasks[i].multicastSocket, 1, 3000, &dummy);
						if (dataReadyOnUDP<0) { // fail 
							RMDBGLOG((ENABLE, "socket failed %ld bytes=%ld\n", Tasks[i].id, readCount));
							goto cleanup;
						}
						else if (dataReadyOnUDP==0) { // timeout 
							RMDBGLOG((LOCALDBG, "socket yield %ld bytes=%ld\n", Tasks[i].id, readCount));
							break;
						}
						count = RMSocketRecv(Tasks[i].multicastSocket, buff + readCount, bytesLeft);
						readCount += count;
						bytesLeft -= count;
						if (count > bytesLeft) { // the space left is not enough for another read
							RMDBGLOG((LOCALDBG, "buff full %ld bytes=%ld\n", Tasks[i].id, readCount));
							break;
						}
			}
			
//SecondLogTime = get_ustime();
//fprintf( stderr, "second %lld,  diff %lld  read %lld\n",  SecondLogTime, SecondLogTime-FirstLogTime, readCount );

			if (global_dump_socket_data) {
//						RMDBGLOG((ENABLE, "dumping %lu bytes for task %ld (i=%ld)\n", count, Tasks[i].id, i ));
						fwrite(buff, readCount, 1, global_saveFile[i]);
			}

//			usleep( 10000 );
		}
	}
	goto cleanup;
}
#endif

	while (1) {
		struct InbandCommandX_type ibcx;
		RMuint32 nEvents;
		RMuint64 t_start = 0;
		RMuint32 timeout;
		RMuint32 count = 0;

		if (timedbg)
			t_start = get_ustime();

	process_key:
		err = ProcessKey();
		if (RMFAILED(err))
			goto cleanup;
		
		for (i = 0; i < task_count; i++) {
			if (Tasks[i].monitor)
				monitor(&Tasks[i], FALSE); 
		}

		WaitEventsMask = 0;
		BlockingWaitEventsMask = 0;
		nEvents = 0;

		event_list[nEvents].ModuleID = EMHWLIB_MODULE(CPUBlock, 0);
		event_list[nEvents].Mask = SOFT_IRQ_EVENT_ERROR;
		WaitEventsMask |= CPU_ERROR_EVENT_MASK;
		nEvents++;

		for (i = 0; i < task_count; i++) {

#ifdef AUTO_CHANGE_CHANNEL
			if ((Tasks[i].nMulticastStreams > 1) && (get_ustime() > periodTime + TIMEOUT_1SEC * 22)) {
				if (SwitchMulticast(&Tasks[i]) == RM_OK) {
					periodTime = get_ustime();
				}
			}
#endif
			/* multi task file playback or spi have 1 receive event per task */
			event_list[nEvents].ModuleID = Tasks[i].demux_task;
			event_list[nEvents].Mask = SOFT_IRQ_EVENT_XFER_RECEIVE_READY;
			WaitEventsMask |= DEMUX_RECEIVE_EVENT_MASK(i);
			/* if all tasks are spi we can afford to block on receive events
			 else we have to keep only the send events as blocking */
			if ((task_count == 1) && Tasks[i].play_opt->spi)
				BlockingWaitEventsMask |= DEMUX_RECEIVE_EVENT_MASK(i);
			nEvents++;

		}

		/* try to send data for all tasks */
		for (i = 0; i < task_count; i++) {
		
			update_hdmi(&dcc_info[i], Tasks[i].disp_opt, Tasks[i].audio_opt);
			if (Tasks[i].play_opt->spi)
				continue;

			if ((Tasks[i].video_opt->display_cc && Tasks[i].video_opt->UseAFD) || Tasks[i].video_opt->ForceAFD) {
				// TODO instead of blind polling, wait for signal from VideoDecoder that AFD has changed
				struct EMhwlibActiveFormatDescription afd;
				err = RUAGetProperty(Tasks[i].dcc_info->pRUA, Tasks[i].dcc_info->video_decoder, 
					RMVideoDecoderPropertyID_ActiveFormat, 
					&afd, sizeof(afd));
				if (Tasks[i].video_opt->ForceAFD) {
					afd.ActiveFormatValid = Tasks[i].video_opt->afd.ActiveFormatValid;
					afd.ActiveFormat = Tasks[i].video_opt->afd.ActiveFormat;
				}
				if (RMSUCCEEDED(err) && (
					(afd.FrameAspectRatio.X && (afd.FrameAspectRatio.X != Tasks[i].video_opt->afd.FrameAspectRatio.X)) || 
					(afd.FrameAspectRatio.Y && (afd.FrameAspectRatio.Y != Tasks[i].video_opt->afd.FrameAspectRatio.Y)) || 
					(afd.ActiveFormatValid && (afd.ActiveFormat != Tasks[i].video_opt->afd.ActiveFormat)) || 
					(afd.ActiveFormatValid != Tasks[i].video_opt->afd.ActiveFormatValid)
				)) {
					fprintf(stderr, "\nReceived new content Active Format Descriptor: %salid Active Format \"%s\" (%u), Frame Aspect Ratio %lu:%lu\n", 
						afd.ActiveFormatValid ? "V" : "Inv", 
						get_afd_name(afd.ActiveFormat), 
						afd.ActiveFormat, 
						afd.FrameAspectRatio.X, 
						afd.FrameAspectRatio.Y);
					Tasks[i].video_opt->afd = afd;
					apply_active_format(Tasks[i].dcc_info->pRUA, Tasks[i].disp_opt, afd, Tasks[i].dcc_info->SurfaceID);
				}
			}

			/* check if the task is finished */
			if ((Tasks[i].play_opt->loop_count == 0) && (Tasks[i].play_opt->infinite_loop == FALSE))
				continue;
				
			/* any send task should be marked as blocking */
			BlockingWaitEventsMask |= DEMUX_SEND_EVENT_MASK(i);
			/* try to get new buffer if we don't have one */
			if ((Tasks[i].buf == NULL) && (Tasks[i].buffer_used == FALSE)) {
				err = RUAGetBuffer(Tasks[i].pDma, &Tasks[i].buf,  0);
				if (err != RM_OK) {
					/* no free buffer -> add an event and prepare to wait */
					event_list[nEvents].ModuleID = Tasks[i].demux_task;
					event_list[nEvents].Mask = RUAEVENT_XFER_FIFO_READY;
					WaitEventsMask |= DEMUX_SEND_EVENT_MASK(i);
					nEvents++;
				}
				else {
					/*fprintf(stderr, "%lx_GetBuffer OK\n", Tasks[i].id);*/
				}
			}

			if (Tasks[i].buf) {
				if (Tasks[i].buffer_used == FALSE) {
					RMuint32 bufSize = (1 << DMA_BUFFER_SIZE_LOG2);
					RMuint64 readCount = 0;
					RMuint32 bytesLeft = bufSize;
					
					while (readCount < (RMuint64)bufSize) {  // read one dma buffer of data
						RMsocket dummy;
						RMint16 dataReadyOnUDP;
						dataReadyOnUDP = RMSocketSelect(&Tasks[i].multicastSocket, 1, 2000, &dummy);
						if (!dataReadyOnUDP) {
							RMDBGLOG((LOCALDBG, "socket yield %ld bytes=%ld\n", Tasks[i].id, readCount));
							break;
						}

						count = RMSocketRecv(Tasks[i].multicastSocket, Tasks[i].buf + readCount, bytesLeft);
						//fprintf(stderr, "task %d, read %lu bytes, bytesLeft = %ld \n", i, count, bytesLeft);
						if (count > bytesLeft) { // something wrong
							RMDBGLOG((ENABLE, "Errno = %d reading from multicast\n", errno));
							goto cleanup;
						}
						readCount += count;
						bytesLeft -= count;
						if (count > bytesLeft) { // the space left is not enough for another read
							//RMDBGLOG((ENABLE, "task %d got %d bytes\n", Tasks[i].id, readCount ));
							break;
						}
					}

					count = (RMuint32)readCount;
					//diffT = readTime - startT;
					//Tasks[i].readSpeed = (readCount * 1000000) / diffT;
					//Tasks[i].readTime += diffT;
					//Tasks[i].tries ++;
					
					if (!readCount) // this buffer is not occupied
						continue;
					
#if DUMP_SOCKET_DATA
					if (global_dump_socket_data) {
						RMDBGLOG((ENABLE, "dumping %lu bytes\n", count));
						fwrite(Tasks[i].buf, count, 1, global_saveFile[i]);
					}
#endif
					Tasks[i].buffer_used = TRUE;
					if (!(Tasks[i].av_flags & AV_PIDS_ENABLE_FIRST_TIME)) /* don't send inbands if PMT is not known yet */
						Tasks[i].send_inband = TRUE;
				}
		 
				if (Tasks[i].send_inband) {
					err = SendInbandCommands(&Tasks[i]);
					if (RMFAILED(err))
						continue; /* loop back through and try again */
					Tasks[i].send_inband = FALSE;
				}

#if defined(WITH_AACS)
				if (Tasks[i].mt_enabled &&
				    Tasks[i].file_byte_counter + count > Tasks[i].mt_spn[Tasks[i].mt_index] * PACKET_SIZE) {
					/* Send MT IbC to signal beginning of new SP */
					struct InbandCommandX_type ibc;
					RMstatus err;

					ibc.flags_tag = INBAND_COMMAND_TAG_AACS;
					ibc.offset_value = Tasks[i].mt_spn[Tasks[i].mt_index] * PACKET_SIZE;
					ibc.offset_control = EMhwlibInbandOffset_Absolute;
					ibc.params.aacs.cmd = AACS_IBC_CMD_MT;
					ibc.params.aacs.spn = Tasks[i].mt_spn[Tasks[i].mt_index];
					ibc.params.aacs.slot = Tasks[i].mt_index;

					fprintf(stderr, "Send MT IbC for SPN %lu.\n", ibc.params.aacs.spn);
					err = RUASetProperty(pRUA, Tasks[i].demux_task, RMGenericPropertyID_InbandCommandX, &ibc, sizeof(ibc), 0);
					if (RMFAILED(err)) {
						fprintf(stderr, "Error sending MT IbC : %s\n", RMstatusToString(err));
						goto cleanup;
					}

					Tasks[i].mt_index++;
				}

				if (Tasks[i].sk_enabled && Tasks[i].file_byte_counter == 0) {
					/* Send SK IbC to signal beginning of new PlayItem */
					struct InbandCommandX_type ibc;
					RMstatus err;

					ibc.flags_tag = INBAND_COMMAND_TAG_AACS;
					ibc.offset_value = 0;
					ibc.offset_control = EMhwlibInbandOffset_Absolute;
					ibc.params.aacs.cmd = AACS_IBC_CMD_PLAY_ITEM;
					ibc.params.aacs.pl = Tasks[i].sk_plid;
					ibc.params.aacs.item = Tasks[i].sk_item;

					fprintf(stderr, "Send SK IbC for %lu/%lu.\n", ibc.params.aacs.pl, ibc.params.aacs.item);
					err = RUASetProperty(pRUA, Tasks[i].demux_task, RMGenericPropertyID_InbandCommandX, &ibc, sizeof(ibc), 0);
					if (RMFAILED(err)) {
						fprintf(stderr, "Error sending SK IbC : %s\n", RMstatusToString(err));
						goto cleanup;
					}
				}
#endif /* WITH_AACS */

				err = RUASendData(pRUA, Tasks[i].demux_task, Tasks[i].pDma, Tasks[i].buf, count, NULL, 0);
				if (err == RM_OK) {
					Tasks[i].bitrate += count * 8;
					Tasks[i].file_byte_counter += count;
					RUAReleaseBuffer(Tasks[i].pDma, Tasks[i].buf);
					Tasks[i].buf = 0;
					Tasks[i].buffer_used = FALSE;
#if (EM86XX_MODE == EM86XX_MODEID_WITHHOST)
					if (Tasks[i].av_flags & AV_PIDS_ENABLE_FIRST_TIME) {
						usleep(10); /* give some time for receive PCI transfer */
					}
#endif
				}
				else {
					RMDBGLOG((ENABLE, "couldnt send data!!!\n"));
					/* no place to send buffer -> add an event and prepare to wait */
					event_list[nEvents].ModuleID = Tasks[i].demux_task;
					event_list[nEvents].Mask = RUAEVENT_XFER_FIFO_READY;
					WaitEventsMask |= DEMUX_SEND_EVENT_MASK(i);
					nEvents++;
				}
				if (0) {
						struct DataFIFOInfo DataFIFOInfo;
						struct XferFIFOInfo_type XferFIFOInfo;
						RMuint32 available_count = RUAGetAvailableBufferCount(Tasks[i].pDma);
						if ( available_count > 1 ) {
							RUAGetProperty(pRUA, Tasks[i].demux_task, RMGenericPropertyID_DataFIFOInfo,
								&DataFIFOInfo, sizeof(DataFIFOInfo));
							RUAGetProperty(pRUA, Tasks[i].demux_task, RMGenericPropertyID_XferFIFOInfo,
								&XferFIFOInfo, sizeof(XferFIFOInfo));
							fprintf(stderr, "%lx_RUASendData %s bc=%lx time=%lld nbuf=%ld bts: wr=%lx rd=%lx xfer: wr=%lx rd=%lx er=%lx\n",
								Tasks[i].id, (err==RM_OK)?"OK":"ERROR",
								Tasks[i].file_byte_counter,
								get_ustime() - t_start,
								available_count,
								DataFIFOInfo.Writable,  DataFIFOInfo.Readable,
								XferFIFOInfo.Writable,  XferFIFOInfo.Readable, XferFIFOInfo.Erasable);
						}
						t_start = get_ustime();
				}
			}
		} /* end "for" loop to send data */

		for (i = 0; i < task_count; i++) {
			if (Tasks[i].file_status == RM_ERRORENDOFFILE) {
				/* add demux eos event in list */
				event_list[nEvents].ModuleID = Tasks[i].demux_task;
				event_list[nEvents].Mask = RUAEVENT_INBAND_COMMAND;
				WaitEventsMask |= DEMUX_EOS_EVENT_MASK(i);
				if (task_count == 1)
					BlockingWaitEventsMask |= DEMUX_EOS_EVENT_MASK(i);
				else
					BlockingWaitEventsMask &= ~DEMUX_EOS_EVENT_MASK(i);
					
				nEvents++;

				/* add video eos event in list */
				event_list[nEvents].ModuleID = Tasks[i].dcc_info->video_decoder;
				event_list[nEvents].Mask = RUAEVENT_INBAND_COMMAND;
				WaitEventsMask |= VIDEO_EOS_EVENT_MASK(i);
				if (task_count == 1)
					BlockingWaitEventsMask |= VIDEO_EOS_EVENT_MASK(i);
				nEvents++;
				
				/* display EOS events */
				event_list[nEvents].ModuleID = EMHWLIB_MODULE(DisplayBlock, 0);
				event_list[nEvents].Mask = EMHWLIB_DISPLAY_INBAND_COMMAND_EVENT_ID(Tasks[i].dcc_info->SurfaceID);
				WaitEventsMask |= DISPLAY_EOS_EVENT_MASK(i);
				if (task_count == 1)
					BlockingWaitEventsMask |= DISPLAY_EOS_EVENT_MASK(i);
				nEvents++;
				

				/* audio EOS event */
				event_list[nEvents].ModuleID = Tasks[i].dcc_info->audio_decoder;
				event_list[nEvents].Mask = RUAEVENT_INBAND_COMMAND;
				WaitEventsMask |= AUDIO_EOS_EVENT_MASK(i);
				if (task_count == 1)
					BlockingWaitEventsMask |= AUDIO_EOS_EVENT_MASK(i);
				nEvents++;
			}
		}

	check_other_events:

		/*each task can add as much as one 3 events - xfer_ready or eos events */
		event_index = 1 + MAX_EVENT_COUNT_PER_TASK * MAX_TASK_COUNT;
		if (nEvents == 0)
			goto process_key;

		if (BlockingWaitEventsMask == 0)
			timeout = 0;
		else if ((WaitEventsMask & BlockingWaitEventsMask) != BlockingWaitEventsMask) {
			/*as long as one task can go on, don't wait too much for the other events */
			timeout = 0;
		}
		else { // ((WaitEventsMask & BlockingWaitEventsMask) == BlockingWaitEventsMask) 
			/*all tasks are blocked: we can afford to spend some time waiting */
			timeout = TIMEOUT_100MS;
		}

#if 0
		fprintf(stderr, "WaitEventsMask=%lx BlockingWaitEventsMask=%lx\n", WaitEventsMask, BlockingWaitEventsMask);
		if (timeout)
			fprintf(stderr, "\nT");
		else
			fprintf(stderr, ".");
			
		fprintf(stderr, "(%lx 0:%lx_%lx 1:%lx_%lx 2:%lx_%lx 3:%lx_%lx 4:%lx_%lx 5:%lx_%lx )\n",
			nEvents,
			event_list[0].ModuleID, event_list[0].Mask,
			event_list[1].ModuleID, event_list[1].Mask,
			event_list[2].ModuleID, event_list[2].Mask,
			event_list[3].ModuleID, event_list[3].Mask,
			event_list[4].ModuleID, event_list[4].Mask,
			event_list[5].ModuleID, event_list[5].Mask
			);
#endif 

		if (RUAWaitForMultipleEvents(pRUA, event_list, nEvents, timeout, &event_index) != RM_OK) {
			goto process_key;
		}
		
		if (event_list[event_index].ModuleID == EMHWLIB_MODULE(CPUBlock, 0)) {
			struct CPUBlock_Error_type Error;
			while (1) { /* get all the errors */
				err = RUAGetProperty(pRUA, CPUBlock, RMCPUBlockPropertyID_Error, &Error, sizeof(Error));
				if ( err != RM_OK) {
					RMDBGLOG((DISABLE,"RMGenericPropertyID_Error failed err=%d\n", err));
					break;
				}
				else {
					RMDBGLOG((ENABLE,"SOFT_IRQ_EVENT_ERROR: module_id=0x%lx error=%d time=%ld\n",
						Error.module_id, Error.error, Error.time));
					if ( (Error.error == RM_UNHANDLED_VIDEO_PCR_DISCONTINUITY) ||
					     (Error.error == RM_UNHANDLED_AUDIO_PCR_DISCONTINUITY) ) {
						RMDBGLOG((ENABLE,"UNHANDLED_PCR_DISCONTINUITY - restart by Stop/Play\n"));
						/* identify what instance */
						for (i=0; i< task_count; i++) {
							if (Tasks[i].id == EMHWLIB_MODULE_INDEX(Error.module_id))
								break;
						}
						if(i >= task_count) {
							fprintf(stderr, "Unidentified UNHANDLED_PCR_DISCONTINUITY i=%ld ??? \n", i);
							continue;
						}
						err = HwStop(&Tasks[i]);
						if (RMFAILED(err)) {
							fprintf(stderr, "%lx_HwStop after UNHANDLED_PCR_DISCONTINUITY err=%d\n", Tasks[i].id, err);
							goto cleanup;
						}
						err = HwPlay(&Tasks[i]);
						if (RMFAILED(err)) {
							fprintf(stderr, "%lx_HwPlay after UNHANDLED_PCR_DISCONTINUITY err=%d\n", Tasks[i].id, err);
							goto cleanup;
						}
					}
				}
			}
		}
		else if (event_list[event_index].Mask == RUAEVENT_INBAND_COMMAND) {
			/* inband events - EOS */
			if (EMHWLIB_MODULE_CATEGORY(event_list[event_index].ModuleID) == DemuxTask) {
				/* one demux EOS came, identify what instance */
				struct InbandCommandX_type ibcx;

				for (i = 0; i < task_count; i++) {
					if (Tasks[i].id == EMHWLIB_MODULE_INDEX(event_list[event_index].ModuleID))
						break;
				}
				if (i >= task_count) {
					fprintf(stderr, "Unidentified Demux inband event ??? \n");
					goto cleanup;
				}
				while (1) { /* the EOS inband was set with INBAND_COMMAND_CONSUMED_BY_USER */
					err = RUAGetProperty(pRUA, event_list[event_index].ModuleID, RMGenericPropertyID_InbandCommandX, &ibcx, sizeof(ibcx));
					if ( err != RM_OK) {
						//fprintf(stderr, "%lx_demux_inband_event without tag - hwlib already process it\n", Tasks[i].id);
						break;
					}
					else if ((ibcx.flags_tag & 0xff) == INBAND_COMMAND_TAG_EOS) {
						Tasks[i].wait_eos_state--;
						fprintf(stderr, "---%lx_WaitForEOS demux OK %ld times event_index=%lx\n", Tasks[i].id, Tasks[i].nTimes, event_index);
						WaitEventsMask &= ~DEMUX_EOS_EVENT_MASK(i);
						BlockingWaitEventsMask &= ~DEMUX_EOS_EVENT_MASK(i);
					}
					else {
						fprintf(stderr, "%lx_demux_inband_event with tag=%lx\n", Tasks[i].id, ibcx.flags_tag);
					}
				}
			}
			else if (EMHWLIB_MODULE_CATEGORY(event_list[event_index].ModuleID) == VideoDecoder) {
				/* one video EOS came, identify what instance */
				for (i = 0; i < task_count; i++) {
					if (Tasks[i].dcc_info->video_decoder == event_list[event_index].ModuleID)
						break;
				}
				if (i >= task_count) {
					fprintf(stderr, "Unidentified Video inband event ??? \n");
					goto cleanup;
				}
				while (1) { /* the EOS inband was set with INBAND_COMMAND_CONSUMED_BY_USER */
					err = RUAGetProperty(pRUA, event_list[event_index].ModuleID, RMGenericPropertyID_InbandCommandX, &ibcx, sizeof(ibcx));
					if ( err != RM_OK) {
						//fprintf(stderr, "%lx_video_inband_event without tag - hwlib already process it\n", Tasks[i].id);
						break;
					}
					else if ((ibcx.flags_tag & 0xff) == INBAND_COMMAND_TAG_EOS) {
						Tasks[i].wait_eos_state--;
						fprintf(stderr, "---%lx_WaitForEOS video OK %ld times event_index=%lx\n", Tasks[i].id, Tasks[i].nTimes, event_index);
						WaitEventsMask &= ~VIDEO_EOS_EVENT_MASK(i);
						BlockingWaitEventsMask &= ~VIDEO_EOS_EVENT_MASK(i);
					}
					else {
						fprintf(stderr, "%lx_video_inband_event with tag=%lx\n", Tasks[i].id, ibcx.flags_tag);
					}
				}
			}
			else if (EMHWLIB_MODULE_CATEGORY(event_list[event_index].ModuleID) == AudioDecoder) {
				/* one audio EOS came, identify what instance */
				for (i = 0; i < task_count; i++) {
					if (Tasks[i].dcc_info->audio_decoder == event_list[event_index].ModuleID)
						break;
				}
				if(i >= task_count) {
					fprintf(stderr, "Unidentified Audio inband event ??? \n");
					goto cleanup;
				}
				while (1) { /* the EOS inband was set with INBAND_COMMAND_CONSUMED_BY_USER */
					err = RUAGetProperty(pRUA, event_list[event_index].ModuleID, RMGenericPropertyID_InbandCommandX, &ibcx, sizeof(ibcx));
					if ( err != RM_OK) {
						//fprintf(stderr, "%lx_audio_inband_event without tag - hwlib already process it\n", Tasks[i].id);
						break;
					}
					else if ((ibcx.flags_tag & 0xff) == INBAND_COMMAND_TAG_EOS) {
						Tasks[i].wait_eos_state--;
						fprintf(stderr, "---%lx_WaitForEOS audio OK %ld times event_index=%lx\n", Tasks[i].id, Tasks[i].nTimes, event_index);
						WaitEventsMask &= ~AUDIO_EOS_EVENT_MASK(i);
						BlockingWaitEventsMask &= ~AUDIO_EOS_EVENT_MASK(i);
					}
					else {
						fprintf(stderr, "%lx_audio_inband_event with tag=%lx\n", Tasks[i].id, ibcx.flags_tag);
					}
				}
			}
		}
		else if (event_list[event_index].ModuleID == EMHWLIB_MODULE(DisplayBlock, 0)) {

			/* one display EOS came, identify what instance */
			for (i = 0; i < task_count; i++) {
				if (EMHWLIB_DISPLAY_INBAND_COMMAND_EVENT_ID(Tasks[i].dcc_info->SurfaceID) == event_list[event_index].Mask)
					break;
			}
			if (i >= task_count) {
				fprintf(stderr, "Unidentified display EOS ??? \n");
				goto cleanup;
			}
			while (1) { /* the EOS inband was set with INBAND_COMMAND_CONSUMED_BY_USER */
				err = RUAGetProperty(pRUA, Tasks[i].dcc_info->video_decoder, RMVideoDecoderPropertyID_DisplayInbandCommandX, &ibcx, sizeof(ibcx));
				if ( err != RM_OK) {
					//fprintf(stderr, "%lx_display_inband_event without tag - hwlib already process it\n", Tasks[i].id);
					break;
				}
				else if ((ibcx.flags_tag & 0xff) == INBAND_COMMAND_TAG_EOS) {
					Tasks[i].wait_eos_state--;
					fprintf(stderr, "---%lx_WaitForEOS display OK %ld times event_index=%lx\n", Tasks[i].id, Tasks[i].nTimes, event_index);
					WaitEventsMask &= ~DISPLAY_EOS_EVENT_MASK(i);
					BlockingWaitEventsMask &= ~DISPLAY_EOS_EVENT_MASK(i);
				}
				else {
					fprintf(stderr, "%lx_display_inband_event with tag=%lx\n", Tasks[i].id, ibcx.flags_tag);
				}
			}
		}
		else if (event_list[event_index].Mask == SOFT_IRQ_EVENT_XFER_RECEIVE_READY) {

			/* one receive event came, identify what instance */
			for (i = 0; i < task_count; i++) {
				if (Tasks[i].id == EMHWLIB_MODULE_INDEX(event_list[event_index].ModuleID))
					break;
			}
			if (i >= task_count) {
				fprintf(stderr, "Unidentified SOFT_IRQ_EVENT_XFER_RECEIVE_READY ??? \n");
				goto cleanup;
			}
			/*fprintf(stderr, "%ld_SOFT_IRQ_EVENT_XFER_RECEIVE_READY\n", Tasks[i].id);*/
			WaitEventsMask &= ~DEMUX_RECEIVE_EVENT_MASK(i);
			ReceiveDataAndSaveInFilePerTask(&Tasks[i]);

			if (Tasks[i].pat) {
				Tasks[i].pat = FALSE;
				/* TODO - add code to handle PAT change */
			}
			if (Tasks[i].pmt) {
				Tasks[i].pmt = FALSE;
				PmtSetAVList(&Tasks[i]);
				if ( RMFAILED(CheckAVPlaybackAgainstAVList(&Tasks[i])) ) {
					SetPidFilterForAVPlayback(&Tasks[i]); /* HwStop, change Pids, HwPlay */
					goto process_key;
				}
			}
		}
		else if (event_list[event_index].Mask == SOFT_IRQ_EVENT_XFER_FIFO_READY) {
			/* one send event came, identify what instance */
			for (i = 0; i < task_count; i++) {
				if (Tasks[i].id == EMHWLIB_MODULE_INDEX(event_list[event_index].ModuleID))
					break;
			}

			if (i >= task_count) {
				fprintf(stderr, "Unidentified SOFT_IRQ_EVENT_XFER_FIFO_READY ??? \n");
				goto cleanup;
			}
			WaitEventsMask &= ~DEMUX_SEND_EVENT_MASK(i);
			BlockingWaitEventsMask &= ~DEMUX_SEND_EVENT_MASK(i);
			goto process_key;
		}

		if (Tasks[i].wait_eos_state == 0) {
			/* check if all tasks are finished in order to exit before sending HwStop/HwPlay */
			if ( CheckAllTaskReady(&Tasks[i]) )
				goto cleanup;
			
			Tasks[i].nTimes++;
			fprintf(stderr, "%lx_WaitForEOS OK %ld times event_index=%lx\n", Tasks[i].id, Tasks[i].nTimes, event_index);

			err = HwStop(&Tasks[i]);
			if (RMFAILED(err)) {
				fprintf(stderr, "%lx_HwStop after EOS err=%d\n", Tasks[i].id, err);
				goto cleanup;
			}
			err = HwPlay(&Tasks[i]);
			if (RMFAILED(err)) {
				fprintf(stderr, "%lx_HwPlay after EOS err=%d\n", Tasks[i].id, err);
				goto cleanup;
			}
		}
		if (WaitEventsMask && ((WaitEventsMask & BlockingWaitEventsMask) == BlockingWaitEventsMask))
			goto check_other_events;

		if (Tasks[i].play_opt->spi && Tasks[i].play_opt->stc_compensation) {
			/* sample code to compensate STC drift */
			StcCompensation(&Tasks[i]);
		}
		if (timedbg) {
			RMuint64 t_end = get_ustime();
			fprintf(stderr, "total= %lld\n", t_end - t_start);
		}
	} /* end "while" to send/receive data for all tasks */
	
 cleanup:

#if DUMP_SOCKET_DATA
	for (i = 0; i < task_count; i++) {
		if (global_dump_socket_data && global_saveFile[i]) {
			RMDBGLOG((ENABLE, "\t\t\t***** CLOSE SAVE DATA FILE **** %ld\n", i));
			fclose(global_saveFile[i]);
		}
	}
#endif

	printf("Elapsed time = %lld\n",get_ustime() - startTime );
	if( Tasks[0].play_opt->waitexit ) {
		RMascii key;
		fprintf(stderr, "press q key again if you really want to stop & quit\n");

		while (!(RMGetKeyNoWait(&key) && ((key == 'q') || (key =='Q')))) {
			for (i = 0; i < task_count; i++) {
				ReceiveDataAndSaveInFilePerTask(&Tasks[i]);
			}
		}
	}
#ifndef WITH_MONO
	RMTermExit();
#endif
	
	for (i = 0; i < task_count; i++) {
		if (Tasks[i].file) {
			RMCloseFile(Tasks[i].file);
			Tasks[i].file = NULL;
		}

		CloseMulticast(Tasks[i].multicastSocket);

		if (dcc_info[i].pDemuxTask) {
			err = DCCStopDemuxTask(dcc_info[i].pDemuxTask);
			if (RMFAILED(err)) {
				fprintf(stderr, "Cannot stop demux %d\n", err);
			}
		}
		if (dcc_info[i].pVideoSource) {
			err = DCCStopVideoSource(dcc_info[i].pVideoSource, DCCStopMode_LastFrame);
			if (RMFAILED(err)) {
				fprintf(stderr, "%lx_Cannot stop video decoder err=%d\n", Tasks[i].id, err);
			}
	
			err = DCCCloseVideoSource(dcc_info[i].pVideoSource);
			if (RMFAILED(err)) {
				fprintf(stderr, "%lx_Error cannot close video decoder err=%d\n", Tasks[i].id, err);
			}
			clear_video_options(&dcc_info[i], Tasks[i].video_opt);
#ifndef WITH_MONO
			clear_display_options(&dcc_info[i], Tasks[i].disp_opt);
#endif
		}

		if (dcc_info[i].pAudioSource) {
			err = DCCCloseAudioSource(dcc_info[i].pAudioSource);
			if (RMFAILED(err)) {
				fprintf(stderr, "%lx_Error cannot close audio decoder err=%d\n", Tasks[i].id, err);
			}
		}

		if (dcc_info[i].pStcSource) {
			DCCSTCStop(dcc_info[i].pStcSource); // hack - stop STC after audio is stopped
			err = DCCSTCClose(dcc_info[i].pStcSource);
			if (RMFAILED(err)) {
				fprintf(stderr, "Error cannot close STC %d\n", err);
			}
		}

		err = ResetOutputTablePerTask(&Tasks[i]);
		
		if (Tasks[i].app_type == program_stream_parsing)
			DisablePesTablePerTask(pRUA, Tasks[i].demux_task, Tasks[i].pes_table, Tasks[i].pes_table_count);
		else {
			DisablePidTablePerTask(pRUA, Tasks[i].demux_task, Tasks[i].pid_table, Tasks[i].pid_table_count);
			FreePidTablePerTask(pRUA, Tasks[i].demux_task, Tasks[i].pid_table, Tasks[i].pid_table_count);
			FreeSectionTable(&Tasks[i]);
			RMFree(Tasks[i].pid_table);
			RMFree(Tasks[i].match_section_table);
		}
	
		FreeKeyAndCipherTable(&Tasks[i]);
		
		if (Tasks[i].pDma) {
			err = RUAClosePool(Tasks[i].pDma);
			Tasks[i].pDma = NULL;
			if (RMFAILED(err))
				fprintf(stderr, "%lx_Error cannot close dmapool err=%d\n", Tasks[i].id, err);
		}
		CloseOutputTablePerTask(&Tasks[i]);
		err = DCCCloseDemuxTask(Tasks[i].dcc_info->pDemuxTask);
		if (RMFAILED(err)) {
			fprintf(stderr, "Error cannot close demux %d\n", err);
		}

		if (Tasks[i].stcd) 
			fclose(Tasks[i].stcd);
	}
	
#ifndef WITH_MONO
	if (load_ucode) {
		err = DCCClose(pDCC);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot close DCC %d\n", err);
		}
	}	
	err = RUADestroyInstance(pRUA);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot destroy RUA instance %d\n", err);
		return -1;
	}
#endif

	return 0;
}

