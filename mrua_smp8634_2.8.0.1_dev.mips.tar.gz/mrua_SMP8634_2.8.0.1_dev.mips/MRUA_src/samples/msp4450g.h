#ifndef _MSP4450G_H
#define _MSP4450G_H
#include <stdio.h>
#include "../rua/include/rua.h"
#include "../rua/include/rua_property.h"
#include "common.h"

//Input: Demodulator Block
//Output: I2S
//-------------------------------------------------------------------------------
#define MSP4450G_I2SOUT_PIN_ACTIVE		0x0000
// Active also changes AUD_CL_OUT to output, vice versa for tristate
#define MSP4450G_I2SOUT_PIN_TRISTATE		0x0090  // basically i2s OFF
#define MSP4450G_I2SOUT_MODE_MASTER		0x0000
#define MSP4450G_I2SOUT_MODE_SLAVE		0x0020
#define MSP4450G_I2SOUT_STROBEWS_BOUND		0x0000
#define MSP4450G_I2SOUT_STROBEWS_1CLK		0x0040
#define MSP4450G_I2SOUT_BIT_16			0x0000
#define MSP4450G_I2SOUT_BIT_32			0x0001

#define MSPSCARTDSP_PRESCALE_OFF	0x00 //off
#define MSPSCARTDSP_PRESCALE_0DB	0x19 //0 db gain (2 V rms Input leads to digital full scale)
#define MSPSCARTDSP_PRESCALE_14DB	0x7f //+14 db gain (400 m V rms input leads to digital full scale)

#define MSPVOL_MAX	0x7F	//+12db
#define MSPVOL_0DB	0x73	// 0db
#define MSPVOL_MID	0x4F
#define MSPVOL_MIN	0x01	// -114db
#define MSPVOL_MUTE	0x00	// mute


typedef enum {	
	msp_standard_autodetect=	0x0001, 
		msp_standard_btscstereo=	0x0020, 
		msp_standard_btscmonosap=	0x0021, 
		msp_standard_dk1stereo=		0x0004, 
		msp_standard_dk2stereo=		0x0005, 
		msp_standard_dk3stereo=		0x0007, 
		msp_standard_dknicam=		0x000b,
		msp_standard_dkmono_hdev3=	0x0006, 
		msp_standard_dknicam_hdev2=	0x000c, 
		msp_standard_dknicam_hdev3=	0x000d,
		
		//<YVo>
		msp_standard_mstereo=		0x0002,
		msp_standard_mEIAstereo=	0x0030,
		msp_standard_bgstereo=		0x0003,
		msp_standard_bgsc_stereo=	0x0008,
		msp_standard_inicam_fm=		0x000a,
		//</YVo>
		
} MSP4450G_STANDARD;

typedef enum { 	
	
	msp_fm28khz=0, 
		msp_fm50khz, 
		msp_fm75khz, 
		msp_fm100khz, 
		msp_fm150khz, 
		msp_fm180khz,
		msp_fm_hdev2_150khz, 
		msp_fm_hdev2_360khz, 
		msp_fm_hdev3_450khz, 
		msp_fm_hdev3_540khz,
		msp_fm_satellite, 
		msp_am 
		
} MSP4450G_FMamPRESCALE;

typedef enum {
	
	msp_digio_tristate=0x01, 
		msp_digio_outputenable, 
		msp_digio_out_and_interrupt
		
} MSP4450G_DIGIO_MODE;

// btsc, Prescale set to 100 khZ FM deviation
typedef enum { 
	
	msp_45mhz_MKorea=0, 
		msp_45mhz_MBtsc, msp_45mhz_MJapan, 
		msp_45mhz_ChromaCarrier 
		
} MSP4450G_DETECT_45MHZ;

typedef enum { 
	
	msp_65mhz_LSecam=0, 
		msp_65mhz_DK123Nicam
		
} MSP4450G_DETECT_65MHZ;

//Input: SCART1 DSP
//-------------------------------------------------------------------------------
typedef enum{
		sc_dsp_src_sc1in=0x00,  //SCART1 to DSP input (RESET position)
		sc_dsp_src_monoin=0x08, //MONO to DSP input (set Sound A Mono in the channel matrix mode for the corresponding output channels)
		sc_dsp_src_sc2in=0x10,  //SCART2 to DSP input
		sc_dsp_src_sc3in=0x18, //SCART3 to DSP input
		sc_dsp_src_sc4in=0x01, //SCART4 to DSP input
		sc_dsp_mute=0x19  //mute DSP input
}MSP4450G_SC_DSP_SRC;

//MATRIX Operations
//-------------------------------------------------------------------------------
typedef enum{
	matrix_main=0x0008, 
		//khuong add
		matrix_headphone=0x0009, 
		//khuong end
		matrix_sc1DA=0x000a, 
		matrix_i2s=0x000b, 
		matrix_qpeak=0x000c
		
}MSP4450G_MATRIX;
typedef enum {
	matrix_mode_soundAMono=0x00, 
		matrix_mode_soundBMono=0x10, 
		matrix_mode_stereo=0x20, 
		matrix_mode_mono=0x30, 
		
		matrix_mode_sumDiff=0x40,
		matrix_mode_abXchange=0x50, 
		matrix_mode_phaseChangeB=0x60, 
		matrix_mode_phaseChangeA=0x70, 
		matrix_mode_onlyA=0x80, 
		matrix_mode_onlyB=0x90
} MSP4450G_MATRIX_MODE;

typedef enum{	
	matrix_src_demodFMAM=0x00, 
		matrix_src_stereoAB=0x01, 
		matrix_src_stereoA=0x03, 
		matrix_src_stereoB=0x04,
		matrix_src_SCARTin=0x02, 
		matrix_src_I2S1=0x05, 
		matrix_src_I2S2=0x06,
		//khuong add
		matrix_src_I2S3_c12=0x07,
		matrix_src_I2S3_c34=0x08
		//khuong end
		
}MSP4450G_MATRIX_SRC;

typedef struct {
	RMuint8 isLowD_CTR_I_O_1;
	RMuint8 isLowD_CTR_I_O_0;
	RMuint8 scartDspInputSelect; //0 -> 5 == SCART1  -> mute
	RMuint8 scart1OutputSelect; // 0 -> 7
	RMuint8 scart2OutputSelect; // 0 -> 7
}ScartSignalPath;

typedef struct {
	RMuint8 isAutomaticSoundSelect;
	RMuint8 isANA_IN1Plus;
	RMuint8 isActiveAUD_CL_OUT;
	RMuint8 isWSChangesAtDataWordBoundary;
	RMuint8 isMasterModeI2SInterface;
	RMuint8 isActiveStateI2SOutputPins;
	RMuint8 isActiveDigitalOutputPinD_CTR_I_O;
}Demodulator;

typedef struct {
	RMuint8 prescaleType;//	
	RMuint32 prescaleValue; //Can get by some function
	RMuint8 matrixModeFM; // 0 -> 4
}ScartAndI2SInputs;

typedef struct {
	RMuint8 outputType; //0 -> 5 Loudspeaker -> Quasi-Peak Detector
	RMuint8 source; // 0 -> 13
	RMuint8 matrixMode; // 0-> 3
}OutputChannels;

RMstatus msp4450g_detect(struct RUA *pInstance);
RMstatus msp4450g_reset(struct RUA *pInstance);
RMstatus msp4450g_applyStandardDetected(struct RUA *pInstance,RMuint32 modus);
RMstatus msp4450g_demod_selectStandard(struct RUA *pInstance, MSP4450G_STANDARD s);
RMstatus msp4450g_demod_InputFMamPrescale(struct RUA *pInstance,MSP4450G_FMamPRESCALE p);
RMstatus msp4450g_demod_getDetectedStandard(struct RUA *pInstance, RMuint32 *regValue);
RMstatus msp4450g_demod_init(struct RUA *pInstance,  MSP4450G_DETECT_45MHZ nD45mhz, MSP4450G_DETECT_65MHZ nD65mhz, MSP4450G_DIGIO_MODE digIOMode, RMuint32 i2sMode);
RMstatus msp4450g_scartdsp_SelectSource(struct RUA *pInstance, MSP4450G_SC_DSP_SRC src);
RMstatus msp4450g_scartdsp_InputPrescale(struct RUA *pInstance,RMuint32 db);
RMstatus msp4450g_matrix_SelectMode(struct RUA *pInstance, MSP4450G_MATRIX m, MSP4450G_MATRIX_MODE md);
RMstatus msp4450g_matrix_SelectSource(struct RUA *pInstance, MSP4450G_MATRIX m, MSP4450G_MATRIX_SRC src);
RMstatus msp4450g_headphone_SetVolume(struct RUA *pInstance, RMuint8 db);
RMstatus msp4450g_headphone_IncreaseVolume(struct RUA *pInstance);
RMstatus msp4450g_headphone_DecreaseVolume(struct RUA *pInstance);
RMstatus msp4450g_loudspeaker_SetVolume(struct RUA *pInstance, RMuint8 db);
RMstatus msp4450g_loudspeaker_IncreaseVolume(struct RUA *pInstance);
RMstatus msp4450g_loudspeaker_DecreaseVolume(struct RUA *pInstance);

RMstatus msp4450g_InitScart1InHeadPhoneOut(struct RUA *pInstance);
RMstatus msp4450g_InitScart3InHeadPhoneOut(struct RUA *pInstance);
RMstatus msp4450g_InitScart1InLoudSpeakerOut(struct RUA *pInstance);
RMstatus msp4450g_InitScart3InLoudSpeakerOut(struct RUA *pInstance);
RMstatus msp4450g_InitScart4InHeadPhoneOut(struct RUA *pInstance);
RMstatus msp4450g_InitScart4InLoudSpeakerOut(struct RUA *pInstance);

RMstatus msp4450g_InitMonoInHeadPhoneOut(struct RUA *pInstance);
RMstatus msp4450g_InitMonoInLoudSpeakerOut(struct RUA *pInstance);
RMstatus msp4450g_InitScart1InI2sAndLoudSpeakerOut(struct RUA *pInstance);
RMstatus msp4450g_InitScart1InI2sAndHeadPhoneOut(struct RUA *pInstance);

RMstatus msp4450g_InitScart1InI2sAndHeadPhoneOutSlaver(struct RUA *pInstance);
RMstatus msp4450g_InitScart1InI2sAndLoudSpeakerOutSlaver(struct RUA *pInstance);
RMstatus msp4450g_InitScart3InI2sAndHeadPhoneOutSlaver(struct RUA *pInstance);
RMstatus msp4450g_InitScart3InI2sAndLoudSpeakerOut(struct RUA *pInstance);


RMstatus msp4450g_InitI2s3InAndHeadPhoneOut(struct RUA *pInstance);
RMstatus msp4450g_InitI2s3InAndLoudSpeakerOut(struct RUA *pInstance);
RMstatus msp4450g_initScartInputThoughtI2s(struct RUA *pInstance, 
										   RMuint8 isMaster,  
										   RMuint8 scartInput ,
										   RMuint8 isMultiSampleInput,
										   RMuint8 howManyBit,
										   RMuint8 isLoudSpeakerOutput,
										   RMuint8 is32BitsOutput,
										   RMuint8 is8ChannelOutput
										   );
void msp4450g_Debug(struct RUA *pInstance, RMuint8 key);
#endif
