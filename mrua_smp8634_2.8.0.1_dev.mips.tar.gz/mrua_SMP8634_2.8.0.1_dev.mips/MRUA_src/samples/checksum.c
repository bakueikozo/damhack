#include <stdio.h>
#include <stdlib.h>
#define ALLOW_OS_CODE 1
#include "emhwlib/include/emhwlib.h"
#include "../emhwlib_hal/include/emhwlib_registers.h"
#include "rmdef/rmdef.h"
#include "checksum.h"
#include "llad/include/gbus.h"
#include "mbus/include/mbus.h"
#include "rua/include/rua.h"

static void crc32_be_init(void);
//static void crc32_le_init(void);

static RMuint32 crc_table[256];
//#define DEBUG_CHECKSUM		1

#define MAX_WAITERS  32 

struct __RUA {
	struct EMhwlib *pEMhwlib;
	struct llad *pLLAD;
	struct gbus *pGBus;
	pthread_mutex_t mutex;

	/* count is a growing only value since there is no way to
	   remove an event from the array.
	*/
	RMuint32 event_count;
	struct RUAEvent event_array[MAX_WAITERS];
};

void crc32_be_init(void)
{
    RMuint32 crc, poly;
    RMuint32 i, j;

    RMDBGLOG((ENABLE, "crc32_be_init()\n"));

    poly = CRCPOLY_BE;
    for (i = 0; i < 256; i++) {
        crc = (i << 24);
        for (j = 8; j > 0; j--)
            crc = (crc & 0x80000000) ? (crc << 1) ^ poly : crc << 1;
        crc_table[i] = crc;
    }

}

#if 0
void crc32_le_init(void)
{
    RMuint32 crc, poly;
    RMuint32 i, j;

    poly = CRCPOLY_LE;
    for (i = 0; i < 256; i++) {
        crc = (i << 24);
        for (j = 8; j > 0; j--)
            crc = (crc & 1) ? (crc >> 1) ^ poly : crc >> 1;
        crc_table[i] = crc;
    }

}
#endif

void crc32_init(void) {
    crc32_be_init();

    return;
}

static RMuint32 crc32_be(RMuint8* buffer_start, RMuint32 buffer_width,
                         RMuint32 xmin, RMuint32 xmax,
                         RMuint32 ymin, RMuint32 ymax,
                         RMuint8 hard_checksum, RMuint8 T)
{
    RMuint32 x, y;
    RMuint8  c;
    RMuint32 crc;
    register RMuint8* pixel;
    //	RMuint8* offset;
    //	RMuint32 bufwidth = 128;
	RMuint8	 i;

    RMDBGLOG((DISABLE, "crc32_be(0x%08lx, %ld, %ld, %ld, %ld, %ld, %d, %d)\n",
              buffer_start, buffer_width, xmin, xmax, ymin, ymax, hard_checksum, T));

#ifdef	DEBUG_CHECKSUM
    FILE*	fp = fopen("/tmp/checksum_log.txt", "a");

    fprintf(fp, "crc32_be(0x%08lx, %ld, %ld, %ld, %ld, %ld)\n", (RMuint32)buffer_start, buffer_width, xmin, xmax, ymin, ymax);

#endif

    crc = 0xFFFFFFFF;
    //	pixel = buffer_start;
    //	offset = buffer_start;

    for (y = ymin ; y < ymax ; y++)
        //		for (x = xmin ; x < xmax ; x++) {
        for (x = xmin ; x < xmax ; ) {
            pixel = (buffer_start +\
                     (x/128) * 4096 + (y/32) * buffer_width * 32 +
                     (x % 128) + (y % 32)*128);


#if 0
            c = *pixel;
            crc = (crc << 8) ^ crc_table[((crc >> 24) ^ c) & 0xFF];
#ifdef	DEBUG_CHECKSUM
            fprintf(fp, "0x%08lx - %ld %ld 0x%02x 0x%08lx\n", (RMuint32)pixel, x, y, c, crc);
#endif

#else
            i = 0;

            while ((x < xmax) && (i < 128)) {
                c = *pixel;
                crc = (crc << 8) ^ crc_table[((crc >> 24) ^ c) & 0xFF];

#ifdef	DEBUG_CHECKSUM
                fprintf(fp, "0x%08lx - %ld %ld 0x%02x 0x%08lx\n", (RMuint32)pixel, x, y, c, crc);
#endif

                x++;
                pixel++;
                i++;
            }
#endif

        }

#ifdef	DEBUG_CHECKSUM
    fclose(fp);
#endif

    return crc;
}

RMuint32 _crc32(RMuint8* buffer_start, RMuint32 buffer_width,
                RMuint32 xmin, RMuint32 xmax,
                RMuint32 ymin, RMuint32 ymax,
                RMuint8 hard_checksum, RMuint8 T)
{
    return crc32_be(buffer_start, buffer_width,
                    xmin, xmax, ymin, ymax, hard_checksum, T);
}

#if 1

RMuint32 crc32_be_h(void  *r, 
                  RMuint32 buffer_start, RMuint32 buffer_width,
                  RMuint32 xmin, RMuint32 xmax,
                  RMuint32 ymin, RMuint32 ymax)
{
    RMuint32 x, y;
    RMuint32 address;
  //  RMuint8  c;
	struct gbus* h = ((struct __RUA*)r)->pGBus;
    RMuint32 size, switchbox, skip;

    RMuint32 crc;

    crc = 0xFFFFFFFF;

    if (xmin > 0x10000 || xmax > 0x10000 || ymin > 0x10000 || ymax > 0x10000 ||
            buffer_start > 0x40000000 || buffer_width > 0x10000000 ||
            xmin == xmax || ymin == ymax || buffer_start == 0 || buffer_width == 0)
        return crc;

    // tiled buffer - crc done in host interface

    x = xmax-xmin;
    y = ymax-ymin;
    size = x*y;
    address = buffer_start
              + (xmin/128)*4096 + (ymin/32)*buffer_width*32
              + (xmin%128) + (ymin%32)*128;
    skip = (buffer_width/128 - 1) | 0x10000;
    // configure the switchbox
    // tango rev C only
    switchbox = gbus_read_uint32(h, REG_BASE_host_interface + SBOX_ROUTE);
    gbus_write_uint32(h, REG_BASE_host_interface + SBOX_ROUTE, 0xfffffff1);

    // init checksum

//    if (save->playvideo_chip_no_rev_id < CHIP_TANGO3) {
        gbus_write_uint32(h, REG_BASE_host_interface + 0x9804, crc);
        gbus_write_uint32(h, REG_BASE_host_interface + 0x9800, size);
//    } else {
//        gbus_write_uint32(h, REG_BASE_host_interface + 0x9800, crc);
//        gbus_write_uint32(h, REG_BASE_host_interface + 0x9804, 0);
//       gbus_write_uint32(h, REG_BASE_host_interface + 0x9808, 3);
//    }
    // MBUS interface r0
    gbus_write_uint32(h, REG_BASE_host_interface + MIF_R0_ADD, address);
    gbus_write_uint32(h, REG_BASE_host_interface + MIF_R0_CNT, (y << 16) + x);
    gbus_write_uint32(h, REG_BASE_host_interface + MIF_R0_SKIP, skip);
    gbus_write_uint32(h, REG_BASE_host_interface + MIF_R0_CMD, MBUS_RECTANGLE_VOID | MBUS_TILED);
    // MBUS interface w0
    gbus_write_uint32(h, REG_BASE_host_interface + MIF_W0_ADD, address);
    gbus_write_uint32(h, REG_BASE_host_interface + MIF_W0_CNT, (y << 16) + x);
    gbus_write_uint32(h, REG_BASE_host_interface + MIF_W0_SKIP, skip);
    gbus_write_uint32(h, REG_BASE_host_interface + MIF_W0_CMD, MBUS_RECTANGLE_VOID | MBUS_TILED);

//    if (save->playvideo_chip_no_rev_id < CHIP_TANGO3) {
        size = gbus_read_uint32(h, REG_BASE_host_interface + 0x9800);
        while (size != 0)
            size = gbus_read_uint32(h, REG_BASE_host_interface + 0x9800);
        crc = gbus_read_uint32(h, REG_BASE_host_interface + 0x9804);
//    } else {
//        RMuint32 count = gbus_read_uint32(h, REG_BASE_host_interface + 0x9804);
//        while (count < size)
//            count = gbus_read_uint32(h, REG_BASE_host_interface + 0x9804);
//        crc = gbus_read_uint32(h, REG_BASE_host_interface + 0x9800);
//    }

    // configure the switchbox
    // tango rev C only
    gbus_write_uint32(h, REG_BASE_host_interface + SBOX_ROUTE, switchbox);

    return crc;
}

#endif

