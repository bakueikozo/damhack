
#include "i2c.h"
//#include "play_capture_TW.h"
RMuint32 I2C_ModuleID_NEW = I2C;

//to enable or disable the debug messages of this source file, put 1 or 0 below
#if 1
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

#if 1
RMstatus init_i2c( struct RUA *pInstance, 
				  RMuint8 delay, 
				  RMuint8 dev, 
				  RMuint8 i2c_data[][2], 
				  RMuint32 data_size)
{
	RMstatus err=RM_OK;
	RMuint32 i;
	
	struct I2C_DeviceParams_type i2c;
	struct I2C_WriteRMuint8_type i2c_write;
	
	i2c.PioClock = 0;
	i2c.PioData = 1;
	i2c.WrAddr = dev << 1;
	i2c.RdAddr = i2c.WrAddr | 0x01;
	i2c.DelayUs = delay;
	
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_DeviceParams, &i2c, sizeof(i2c), 0);
	for (i = 0; i < data_size; i++) {
		i2c_write.SubAddr = i2c_data[i][0];
		i2c_write.Data = i2c_data[i][1];
		//		err=write_i2c(pInstance,delay,dev,(RMuint32)i2c_data[i][0],(RMuint32)i2c_data[i][1]);
		err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_WriteRMuint8, &i2c_write, sizeof(i2c_write), 0);
		
		if (RMFAILED(err)) RMDBGPRINT((ENABLE, "Failed to write 0x%02X to i2c 0x%02X:0x%02X\n", i2c_data[i][1], i2c.WrAddr, i2c_data[i][0]));
	}
	return err;
//	return RM_OK ;
}

#else

RMstatus init_i2c(
				  struct RUA *pInstance, 
				  RMuint8 delay, 
				  RMuint8 dev, 
				  RMuint8 i2c_data[][2], 
				  RMuint32 data_size)
{
	RMstatus err=RM_OK;
	RMuint32 i;
	RMuint32 regAdd;
	RMuint32 regVal;
	
	for (i = 0; i < data_size; i++) {
		regAdd= 0xff & i2c_data[i][0] ;
		regVal = 0xff & i2c_data[i][1];
		err=write_i2c(pInstance,delay,dev,regAdd,regVal);
		
		if (err!=RM_OK) {
			printf("can write i2c \n");
			return err;
		}
		usleep(50);
	}
	return err;
}

#endif

RMstatus write_i2c(
						  struct RUA *pInstance, 
						  RMuint8 delay, 
						  RMuint32 dev, 
						  RMuint32 addr, 
						  RMuint32 data)
{
	RMstatus err;
	struct I2C_DeviceParams_type i2c;
	struct I2C_WriteRMuint8_type i2c_write;
	
	i2c.PioClock = 0;
	i2c.PioData = 1;
	i2c.WrAddr = dev << 1;
	i2c.RdAddr = i2c.WrAddr | 0x01;
	i2c.DelayUs = delay;
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_DeviceParams, &i2c, sizeof(i2c), 0);
	i2c_write.SubAddr = addr;
	i2c_write.Data = data;
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_WriteRMuint8, &i2c_write, sizeof(i2c_write), 0);
	//	if (RMSUCCEEDED(err)) RMDBGPRINT((ENABLE, "Wrote 0x%02X to i2c 0x%02X:0x%02X\n", data, i2c.WrAddr, addr));
	//	else RMDBGPRINT((ENABLE, "Failed to write 0x%02X to i2c 0x%02X:0x%02X\n", data, i2c.WrAddr, addr));
	return err;
//	return RM_OK ;
	
}


RMstatus read_i2c(
						 struct RUA *pInstance, 
						 RMuint8 delay, 
						 RMuint32 dev, 
						 RMuint32 addr, 
						 RMuint32 *data)

{
	RMstatus err;
	struct I2C_DeviceParams_type i2c;
	struct I2C_QueryRMuint8_in_type i2c_param;
	struct I2C_QueryRMuint8_out_type i2c_res;
	
	i2c.PioClock = 0;
	i2c.PioData = 1;
	i2c.WrAddr = dev << 1;
	i2c.RdAddr = i2c.WrAddr | 0x01;
	i2c.DelayUs = delay;
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_DeviceParams, &i2c, sizeof(i2c), 0);
	i2c_param.SubAddr = addr;
	err = RUAExchangeProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_QueryRMuint8, 
		&i2c_param, sizeof(i2c_param), 
		&i2c_res, sizeof(i2c_res));
	//	if (RMSUCCEEDED(err)) RMDBGPRINT((ENABLE, "Reading 0x%02X from i2c 0x%02X:0x%02X\n", i2c_res.Data, i2c.RdAddr, addr));
	//	else RMDBGPRINT((ENABLE, "Failed to read from i2c 0x%02X:0x%02X\n", i2c.RdAddr, addr));
	*data = i2c_res.Data;
	return err;
//	return RM_OK ;
	
}
RMstatus read_i2c_data(
					   struct RUA *pInstance, 
					   RMuint8 delay, 
					   RMuint32 dev, 
					   RMuint32 addr, 
					   RMuint8 *data, 
					   RMuint32 data_size)
{
	RMstatus err;
	struct I2C_DeviceParams_type i2c;
	struct I2C_QueryData_in_type i2c_param; 
	struct I2C_QueryData_out_type i2c_res;
	
	i2c.PioClock = 0;
	i2c.PioData = 1;
	i2c.WrAddr = dev << 1;
	i2c.RdAddr = i2c.WrAddr | 0x01;
	i2c.DelayUs = delay;
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_DeviceParams, &i2c, sizeof(i2c), 0);
	i2c_param.UseSubAddr = TRUE;
	i2c_param.SubAddr = addr;
	i2c_param.DataSize = data_size;
	err = RUAExchangeProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_QueryData, 
		&i2c_param, sizeof(i2c_param), 
		&i2c_res, sizeof(i2c_res));
	if (RMFAILED(err)) {
		RMDBGLOG((LOCALDBG, "Error setting RMI2CPropertyID_QueryData(0x%02X:0x%02X, 0x%02X) on I2C 0x%08lX GPIO %lu/%lu! %s\n", 
			i2c.WrAddr, i2c_param.SubAddr, i2c_param.DataSize, 
			I2C_ModuleID_NEW, i2c.PioClock, i2c.PioData, 
			RMstatusToString(err)));
	}
	RMMemcpy(data, i2c_res.Data, data_size);
	return err;
//	return RM_OK ;
}


RMstatus read_i2c_control_msp4450g(
										  struct RUA *pInstance, 
										  RMuint8 delay, 
										  RMuint32 dev, 
										  RMuint32 sub,
										  RMuint32 *data)
{
	RMstatus err;
	
	struct I2C_DeviceParams_type i2c;
	struct I2C_WriteData_type i2c_write;	
	
	struct I2C_QueryData_in_type i2c_param; 
	struct I2C_QueryData_out_type i2c_res;
	
	i2c.PioClock = 0;
	i2c.PioData = 1;
	i2c.WrAddr = dev << 1;
	i2c.RdAddr = i2c.WrAddr | 0x01;
	i2c.DelayUs = delay;
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_DeviceParams, &i2c, sizeof(i2c), 0);
	
	i2c_write.UseSubAddr = FALSE;
	i2c_write.SubAddr = sub;
	i2c_write.DataSize = 1;
	i2c_write.Data[0] = sub;
	
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_WriteData, &i2c_write, sizeof(i2c_write), 0);
	if (RMFAILED(err)) RMDBGPRINT((ENABLE, "Failed to write 0x%02X%02X to i2c 0x%02X\n", i2c_write.Data[0], i2c_write.Data[1], i2c.WrAddr));
	
	i2c_param.UseSubAddr = TRUE;
	i2c_param.SubAddr = sub;
	i2c_param.DataSize = 2;
	
	err = RUAExchangeProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_QueryData, 
		&i2c_param, sizeof(i2c_param), 
		&i2c_res, sizeof(i2c_res));
	
	if (RMFAILED(err)) {
		RMDBGLOG((LOCALDBG, "Error setting RMI2CPropertyID_QueryData(0x%02X:0x%02X, 0x%02X) on I2C 0x%08lX GPIO %lu/%lu! %s\n", 
			i2c.WrAddr, i2c_param.SubAddr, i2c_param.DataSize, 
			I2C_ModuleID_NEW, i2c.PioClock, i2c.PioData, 
			RMstatusToString(err)));
	}
	
	*data=(i2c_res.Data[0] & 0xff) ;
	*data = *data << 8;
	*data=*data | (i2c_res.Data[1] & 0xff);
	
	return err;
//	return RM_OK ;
	
}
RMstatus write_i2c_control_msp4450g(
										   struct RUA *pInstance, 
										   RMuint8 delay, 
										   RMuint32 dev, 
										   RMuint32 sub,
										   RMuint32 data)
{
	RMstatus err;
	
	struct I2C_DeviceParams_type i2c;
	struct I2C_WriteData_type i2c_write;	
	
	i2c.PioClock = 0;
	i2c.PioData = 1;
	i2c.WrAddr = dev << 1;
	i2c.RdAddr = i2c.WrAddr | 0x01;
	i2c.DelayUs = delay;
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_DeviceParams, &i2c, sizeof(i2c), 0);
	
	i2c_write.UseSubAddr = TRUE;
	i2c_write.SubAddr = sub;
	i2c_write.DataSize = 2;
	i2c_write.Data[0] = (data & 0xff00) >> 8;
	i2c_write.Data[1] = (data & 0xff);	
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_WriteData, &i2c_write, sizeof(i2c_write), 0);
	if (RMFAILED(err)) RMDBGPRINT((ENABLE, "Failed to write 0x%02X%02X to i2c 0x%02X\n", i2c_write.Data[0], i2c_write.Data[1], i2c.WrAddr));
	
	return err;
//	return RM_OK ;
	
}

// Demod or DSP
RMstatus read_i2c_dsp_msp4450g(
									  struct RUA *pInstance, 
									  RMuint8 delay, 
									  RMuint32 dev, 
									  RMuint32 sub,
									  RMuint32 addr, 
									  RMuint32 *data)
{
	RMstatus err;
	
	struct I2C_DeviceParams_type i2c;
	struct I2C_WriteData_type i2c_write;	
	
	struct I2C_QueryData_in_type i2c_param; 
	struct I2C_QueryData_out_type i2c_res;
	
	i2c.PioClock = 0;
	i2c.PioData = 1;
	i2c.WrAddr = dev << 1;
	i2c.RdAddr = i2c.WrAddr | 0x01;
	i2c.DelayUs = delay;
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_DeviceParams, &i2c, sizeof(i2c), 0);
	
	i2c_write.UseSubAddr = TRUE;
	i2c_write.SubAddr = sub;
	i2c_write.DataSize = 2;
	i2c_write.Data[0] = (addr & 0xff00) >> 8;
	i2c_write.Data[1] = addr & 0x00FF;
	
	
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_WriteData, &i2c_write, sizeof(i2c_write), 0);
	if (RMFAILED(err)) RMDBGPRINT((ENABLE, "Failed to write 0x%02X%02X to i2c 0x%02X\n", i2c_write.Data[0], i2c_write.Data[1], i2c.WrAddr));
	
	i2c_param.UseSubAddr = TRUE;
	i2c_param.SubAddr = sub;
	i2c_param.DataSize = 2;
	
	err = RUAExchangeProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_QueryData, 
		&i2c_param, sizeof(i2c_param), 
		&i2c_res, sizeof(i2c_res));
	
	if (RMFAILED(err)) {
		RMDBGLOG((LOCALDBG, "Error setting RMI2CPropertyID_QueryData(0x%02X:0x%02X, 0x%02X) on I2C 0x%08lX GPIO %lu/%lu! %s\n", 
			i2c.WrAddr, i2c_param.SubAddr, i2c_param.DataSize, 
			I2C_ModuleID_NEW, i2c.PioClock, i2c.PioData, 
			RMstatusToString(err)));
	}
	
	*data=(i2c_res.Data[0] & 0xff) ;
	*data = *data << 8;
	*data=*data | (i2c_res.Data[1] & 0xff);
	
	return err;
//	return RM_OK ;
	
}


RMstatus write_i2c_dsp_msp4450g(
									   struct RUA *pInstance, 
									   RMuint8 delay, 
									   RMuint32 dev, 
									   RMuint32 sub,
									   RMuint32 addr, 
									   RMuint32 data)
{
	RMstatus err;
	
	struct I2C_DeviceParams_type i2c;
	struct I2C_WriteData_type i2c_write;	
	
	i2c.PioClock = 0;
	i2c.PioData = 1;
	i2c.WrAddr = dev << 1;
	i2c.RdAddr = i2c.WrAddr | 0x01;
	i2c.DelayUs = delay;
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_DeviceParams, &i2c, sizeof(i2c), 0);
	
	i2c_write.UseSubAddr = TRUE;
	i2c_write.SubAddr = sub;
	i2c_write.DataSize = 4;
	i2c_write.Data[0] = (addr & 0xff00) >> 8;
	i2c_write.Data[1] = addr & 0x00FF;
	i2c_write.Data[2] = (data & 0xff00) >> 8;
	i2c_write.Data[3] = data & 0x00FF;
	
	
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_WriteData, &i2c_write, sizeof(i2c_write), 0);
	if (RMFAILED(err)) RMDBGPRINT((ENABLE, "Failed to write 0x%02X%02X to i2c 0x%02X\n", i2c_write.Data[0], i2c_write.Data[1], i2c.WrAddr));
	
	
	return err;
	//return RM_OK ;
	
}



/**
  @param pInstance
  @param delay - uSec delay between bits in i2c
  @param dev - raw i2c slave address, 0x00..0x7f
  @param i2c_data
  @param data_size
*/
RMstatus init_i2c_WM(
							struct RUA *pInstance, 
							RMuint8 delay, 
							RMuint8 dev, 
							RMuint16 i2c_data[][2], 
							RMuint32 data_size)
{
	RMstatus err;
	RMuint32 i;
	struct I2C_DeviceParams_type i2c;
	struct I2C_WriteData_type i2c_write;
	
	i2c.PioClock = 0;
	i2c.PioData = 1;
	i2c.WrAddr = dev << 1;
	i2c.RdAddr = i2c.WrAddr | 0x01;
	i2c.DelayUs = delay;
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_DeviceParams, &i2c, sizeof(i2c), 0);
	for (i = 0; i < data_size; i++) {
		i2c_write.UseSubAddr = FALSE;
		i2c_write.SubAddr = i2c_data[i][0];
		i2c_write.DataSize = 2;
		i2c_write.Data[0] = ((i2c_data[i][0] & 0x1F) << 1) | ((i2c_data[i][1] & 0x0100) ? 1 : 0);
		i2c_write.Data[1] = i2c_data[i][1] & 0xFF;
		err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_WriteData, &i2c_write, sizeof(i2c_write), 0);
		if (RMFAILED(err)) RMDBGPRINT((ENABLE, "Failed to write 0x%02X%02X to i2c 0x%02X\n", i2c_write.Data[0], i2c_write.Data[1], i2c.WrAddr));
	}
	return RM_OK;
}



/*
RMstatus read_i2c(
	struct RUA *pInstance, 
	RMuint8 delay, 
	RMuint32 dev, 
	RMuint32 addr, 
	RMuint32 *data)
{
	RMstatus err;
	struct EMhwlibI2CDeviceParameter i2c;
	struct I2C_QueryRMuint8_in_type i2c_param;
	struct I2C_QueryRMuint8_out_type i2c_res;
	
	i2c.APIVersion = 1;
	i2c.Clock = GPIOId_Sys_0;
	i2c.Data = GPIOId_Sys_1;
	i2c.Delay = delay;
	i2c.Speed = 100;
	i2c.DevAddr = dev << 1;
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_DeviceParameter, &i2c, sizeof(i2c), 0);
	i2c_param.SubAddr = addr;
	err = RUAExchangeProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_QueryRMuint8, 
		&i2c_param, sizeof(i2c_param), 
		&i2c_res, sizeof(i2c_res));
//	if (RMSUCCEEDED(err)) RMDBGPRINT((ENABLE, "Reading 0x%02X from i2c 0x%02X:0x%02X\n", i2c_res.Data, i2c.DevAddr | 0x01, addr));
//	else RMDBGPRINT((ENABLE, "Failed to read from i2c 0x%02X:0x%02X\n", i2c.DevAddr | 0x01, addr));
	*data = i2c_res.Data;
	return err;
}

RMstatus write_i2c(
	struct RUA *pInstance, 
	RMuint8 delay, 
	RMuint32 dev, 
	RMuint32 addr, 
	RMuint32 data)
{
	RMstatus err;
	struct EMhwlibI2CDeviceParameter i2c;
	struct I2C_WriteRMuint8_type i2c_write;
	
	i2c.APIVersion = 1;
	i2c.Clock = GPIOId_Sys_0;
	i2c.Data = GPIOId_Sys_1;
	i2c.Delay = delay;
	i2c.Speed = 100;
	i2c.DevAddr = dev << 1;
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_DeviceParameter, &i2c, sizeof(i2c), 0);
	i2c_write.SubAddr = addr;
	i2c_write.Data = data;
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_WriteRMuint8, &i2c_write, sizeof(i2c_write), 0);
//	if (RMSUCCEEDED(err)) RMDBGPRINT((ENABLE, "Wrote 0x%02X to i2c 0x%02X:0x%02X\n", data, i2c.DevAddr, addr));
//	else RMDBGPRINT((ENABLE, "Failed to write 0x%02X to i2c 0x%02X:0x%02X\n", data, i2c.DevAddr, addr));
	return err;
}


RMstatus read_i2c_dsp_msp4450g(
							   struct RUA *pInstance, 
							   RMuint8 delay, 
							   RMuint32 dev, 
							   RMuint32 sub,
							   RMuint32 addr, 
							   RMuint32 *data)
{
	RMstatus err;
	
	struct I2C_DeviceParams_type i2c;
	struct I2C_WriteData_type i2c_write;	
	
	struct I2C_QueryData_in_type i2c_param; 
	struct I2C_QueryData_out_type i2c_res;
	
	i2c.PioClock = 0;
	i2c.PioData = 1;
	i2c.WrAddr = dev << 1;
	i2c.RdAddr = i2c.WrAddr | 0x01;
	i2c.DelayUs = delay;
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_DeviceParams, &i2c, sizeof(i2c), 0);
	
	i2c_write.UseSubAddr = TRUE;
	i2c_write.SubAddr = sub;
	i2c_write.DataSize = 2;
	i2c_write.Data[0] = (addr & 0xff00) >> 8;
	i2c_write.Data[1] = addr & 0x00FF;
	
	
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_WriteData, &i2c_write, sizeof(i2c_write), 0);
	if (RMFAILED(err)) RMDBGPRINT((ENABLE, "Failed to write 0x%02X%02X to i2c 0x%02X\n", i2c_write.Data[0], i2c_write.Data[1], i2c.WrAddr));
	
	i2c_param.UseSubAddr = TRUE;
	i2c_param.SubAddr = sub;
	i2c_param.DataSize = 2;
	
	err = RUAExchangeProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_QueryData, 
		&i2c_param, sizeof(i2c_param), 
		&i2c_res, sizeof(i2c_res));
	
	if (RMFAILED(err)) {
		RMDBGLOG((LOCALDBG, "Error setting RMI2CPropertyID_QueryData(0x%02X:0x%02X, 0x%02X) on I2C 0x%08lX GPIO %lu/%lu! %s\n", 
			i2c.WrAddr, i2c_param.SubAddr, i2c_param.DataSize, 
			I2C_ModuleID_NEW, i2c.PioClock, i2c.PioData, 
			RMstatusToString(err)));
	}
	
	*data=(i2c_res.Data[0] & 0xff) ;
	*data = *data << 8;
	*data=*data | (i2c_res.Data[1] & 0xff);
	
	return err;
}

RMstatus write_i2c_dsp_msp4450g(
								struct RUA *pInstance, 
								RMuint8 delay, 
								RMuint32 dev, 
								RMuint32 sub,
								RMuint32 addr, 
								RMuint32 data)
{
	RMstatus err;
	
	struct I2C_DeviceParams_type i2c;
	struct I2C_WriteData_type i2c_write;	
	
	i2c.PioClock = 0;
	i2c.PioData = 1;
	i2c.WrAddr = dev << 1;
	i2c.RdAddr = i2c.WrAddr | 0x01;
	i2c.DelayUs = delay;
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_DeviceParams, &i2c, sizeof(i2c), 0);
	
	i2c_write.UseSubAddr = TRUE;
	i2c_write.SubAddr = sub;
	i2c_write.DataSize = 4;
	i2c_write.Data[0] = (addr & 0xff00) >> 8;
	i2c_write.Data[1] = addr & 0x00FF;
	i2c_write.Data[2] = (data & 0xff00) >> 8;
	i2c_write.Data[3] = data & 0x00FF;
	
	
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_WriteData, &i2c_write, sizeof(i2c_write), 0);
	if (RMFAILED(err)) RMDBGPRINT((ENABLE, "Failed to write 0x%02X%02X to i2c 0x%02X\n", i2c_write.Data[0], i2c_write.Data[1], i2c.WrAddr));
	
	
	return err;
}

RMstatus read_i2c_control_msp4450g(
								   struct RUA *pInstance, 
								   RMuint8 delay, 
								   RMuint32 dev, 
								   RMuint32 sub,
								   RMuint32 *data)
{
	RMstatus err;
	
	struct I2C_DeviceParams_type i2c;
	struct I2C_WriteData_type i2c_write;	
	
	struct I2C_QueryData_in_type i2c_param; 
	struct I2C_QueryData_out_type i2c_res;
	
	i2c.PioClock = 0;
	i2c.PioData = 1;
	i2c.WrAddr = dev << 1;
	i2c.RdAddr = i2c.WrAddr | 0x01;
	i2c.DelayUs = delay;
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_DeviceParams, &i2c, sizeof(i2c), 0);
	
	i2c_write.UseSubAddr = FALSE;
	i2c_write.SubAddr = sub;
	i2c_write.DataSize = 1;
	i2c_write.Data[0] = sub;
	
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_WriteData, &i2c_write, sizeof(i2c_write), 0);
	if (RMFAILED(err)) RMDBGPRINT((ENABLE, "Failed to write 0x%02X%02X to i2c 0x%02X\n", i2c_write.Data[0], i2c_write.Data[1], i2c.WrAddr));
	
	i2c_param.UseSubAddr = TRUE;
	i2c_param.SubAddr = sub;
	i2c_param.DataSize = 2;
	
	err = RUAExchangeProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_QueryData, 
		&i2c_param, sizeof(i2c_param), 
		&i2c_res, sizeof(i2c_res));
	
	if (RMFAILED(err)) {
		RMDBGLOG((LOCALDBG, "Error setting RMI2CPropertyID_QueryData(0x%02X:0x%02X, 0x%02X) on I2C 0x%08lX GPIO %lu/%lu! %s\n", 
			i2c.WrAddr, i2c_param.SubAddr, i2c_param.DataSize, 
			I2C_ModuleID_NEW, i2c.PioClock, i2c.PioData, 
			RMstatusToString(err)));
	}
	
	*data=(i2c_res.Data[0] & 0xff) ;
	*data = *data << 8;
	*data=*data | (i2c_res.Data[1] & 0xff);
	
	return err;
}

RMstatus write_i2c_control_msp4450g(
									struct RUA *pInstance, 
									RMuint8 delay, 
									RMuint32 dev, 
									RMuint32 sub,
									RMuint32 data)
{
	RMstatus err;
	
	struct I2C_DeviceParams_type i2c;
	struct I2C_WriteData_type i2c_write;	
	
	i2c.PioClock = 0;
	i2c.PioData = 1;
	i2c.WrAddr = dev << 1;
	i2c.RdAddr = i2c.WrAddr | 0x01;
	i2c.DelayUs = delay;
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_DeviceParams, &i2c, sizeof(i2c), 0);
	
	i2c_write.UseSubAddr = TRUE;
	i2c_write.SubAddr = sub;
	i2c_write.DataSize = 2;
	i2c_write.Data[0] = (data & 0xff00) >> 8;
	i2c_write.Data[1] = (data & 0xff);	
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_WriteData, &i2c_write, sizeof(i2c_write), 0);
	if (RMFAILED(err)) RMDBGPRINT((ENABLE, "Failed to write 0x%02X%02X to i2c 0x%02X\n", i2c_write.Data[0], i2c_write.Data[1], i2c.WrAddr));
	
	return err;
}
*/
/**
  @delay: uSec delay between bits in i2c
  @dev: raw i2c slave address, 0x00..0x7f
*/
/*
RMstatus init_i2c(
	struct RUA *pInstance, 
	RMuint8 delay, 
	RMuint8 dev, 
	RMuint8 i2c_data[][2], 
	RMuint32 data_size)
{
	RMstatus err;
	RMuint32 i;
	struct EMhwlibI2CDeviceParameter i2c;
	struct I2C_WriteRMuint8_type i2c_write;
	
	i2c.APIVersion = 1;
	i2c.Clock = GPIOId_Sys_0;
	i2c.Data = GPIOId_Sys_1;
	i2c.Delay = delay;
	i2c.Speed = 100;
	i2c.DevAddr = dev << 1;
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_DeviceParameter, &i2c, sizeof(i2c), 0);
	for (i = 0; i < data_size; i++) {
		i2c_write.SubAddr = i2c_data[i][0];
		i2c_write.Data = i2c_data[i][1];
		err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_WriteRMuint8, &i2c_write, sizeof(i2c_write), 0);
		if (RMFAILED(err)) RMDBGPRINT((ENABLE, "Failed to write 0x%02X to i2c 0x%02X:0x%02X\n", i2c_data[i][1], i2c.DevAddr, i2c_data[i][0]));
	}
	return RM_OK;
}*/

/*
RMstatus read_i2c_data(
					   struct RUA *pInstance, 
					   RMuint8 delay, 
					   RMuint32 dev, 
					   RMuint32 addr, 
					   RMuint8 *data, 
					   RMuint32 data_size)
{
	RMstatus err;
	struct EMhwlibI2CDeviceParameter i2c;
	struct I2C_QueryData_in_type i2c_param; 
	struct I2C_QueryData_out_type i2c_res;
	
	i2c.APIVersion = 1;
	i2c.Clock = GPIOId_Sys_0;
	i2c.Data = GPIOId_Sys_1;
	i2c.Delay = delay;
	i2c.Speed = 100;
	i2c.DevAddr = dev << 1;
	err = RUASetProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_DeviceParameter, &i2c, sizeof(i2c), 0);
	i2c_param.UseSubAddr = TRUE;
	i2c_param.SubAddr = addr;
	i2c_param.DataSize = data_size;
	err = RUAExchangeProperty(pInstance, I2C_ModuleID_NEW, RMI2CPropertyID_QueryData, 
		&i2c_param, sizeof(i2c_param), 
		&i2c_res, sizeof(i2c_res));
	if (RMFAILED(err)) {
		RMDBGLOG((LOCALDBG, "Error setting RMI2CPropertyID_QueryData(0x%02X:0x%02X, 0x%02X) on I2C 0x%08lX GPIO %lu/%lu! %s\n", 
			i2c.DevAddr, i2c_param.SubAddr, i2c_param.DataSize, 
			I2C_ModuleID_NEW, i2c.Clock, i2c.Data, 
			RMstatusToString(err)));
	}
	RMMemcpy(data, i2c_res.Data, data_size);
	return err;
}
*/
