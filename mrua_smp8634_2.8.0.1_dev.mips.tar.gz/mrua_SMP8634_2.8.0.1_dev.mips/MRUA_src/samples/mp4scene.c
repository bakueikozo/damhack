/*
 *
 * Copyright (c) Sigma Designs, Inc. 2006. All rights reserved.
 *
 */


/**
   @file mp4scene.c
   @brief limited BIFS parsing for MP4 streams
	
   @author Yifan Liu
   @ingroup dccsamplecode
*/


#include "../samples/sample_os.h"

#define ALLOW_OS_CODE 1
#include "../dcc/include/dcc.h"
#include "../samples/common.h"

#include "psfdemux_common.h"
#include "mp4scene.h"


#if 1
#define CALLDBG ENABLE
#else
#define CALLDBG DISABLE
#endif


enum SFNodeType_type {
	UnknownSFNodeType = 0,
	SF2DNode,
	SF3DNode,
	SFAppearanceNode,
	SFAudioNode,
	SFBackground2DNode,
	SFBackground3DNode,
	SFColorNode,
	SFCoordinate2DNode,
	SFCoordinateNode,
	SFExpressionNode,
	SFFAPNode,
	SFFDPNode,
	SFFITNode,
	SFFaceDefMeshNode,
	SFFaceDefTablesNode,
	SFFaceDefTransformNode,
	SFFogNode,
	SFFontStyleNode,
	SFGeometryNode,
	SFLinePropertiesNode,
	SFMaterialNode,
	SFNavigationInfoNode,
	SFNormalNode,
	SFStreamingNode,
	SFTextureCoordinateNode,
	SFTextureNode,
	SFTextureTransformNode,
	SFTopNode,
	SFViewpointNode,
	SFVisemeNode,
	SFWorldNode
};

RMuint8 NodeTypeBitNumber_table[] =
{
	0, /*UnknownNodeType*/
	5, /*SF2DNode*/
	6, /*SF3DNode*/
	1, /*SFAppearanceNode*/
	3, /*SFAudioNode*/

	1, /*SFBackground2DNode*/
	1, /*SFBackground3DNode*/
	1, /*SFColorNode*/
	1, /*SFCoordinate2DNode*/
	1, /*SFCoordinateNode*/

	1, /*SFExpressionNode*/
	1, /*SFFAPNode*/
	1, /*SFFDPNode*/
	1, /*SFFITNode*/
	1, /*SFFaceDefMeshNode*/

	1, /*SFFaceDefTablesNode*/
	1, /*SFFaceDefTransformNode*/
	1, /*SFFogNode*/
	1, /*SFFontStyleNode*/
	5, /*SFGeometryNode*/

	1, /*SFLinePropertiesNode*/
	2, /*SFMaterialNode*/
	1, /*SFNavigationInfoNode*/
	1, /*SFNormalNode*/
	3, /*SFStreamingNode*/

	1, /*SFTextureCoordinateNode*/
	3, /*SFTextureNode*/
	1, /*SFTextureTransformNode*/
	3, /*SFTopNode*/
	1, /*SFViewpointNode*/

	1, /*SFVisemeNode*/
	7, /*SFWorldNode*/
};


enum SFWorldNode_type {
	Reserved_Type = 0,
	Anchor,
	AnimationStream,
	Appearance,
	AudioBuffer,
	AudioClip,
	AudioDelay,
	AudioFX,
	AudioMix,
	AudioSource,
	AudioSwitch,
	Background,
	Background2D,
	Billboard,
	Bitmap,
	Box,
	Circle,
	Collision,
	Color,
	ColorInterpolator,
	CompositeTexture2D,
	CompositeTexture3D,
	Conditional,
	Cone,
	Coordinate,
	Coordinate2D,
	CoordinateInterpolator,
	CoordinateInterpolator2D,
	Curve2D,
	Cylinder,
	CylinderSensor,
	DirectionalLight,
	DiscSensor,
	ElevationGrid,
	Expression,
	Extrusion,
	Face,
	FaceDefMesh,
	FaceDefTables,
	FaceDefTransform,
	FAP,
	FDP,
	FIT,
	Fog,
	FontStyle,
	Form,
	Group,
	ImageTexture,
	IndexedFaceSet,
	IndexedFaceSet2D,
	IndexedLineSet,
	IndexedLineSet2D,
	Inline,
	LOD,
	Layer2D,
	Layer3D,
	Layout,
	LineProperties,
	ListeningPoint,
	Material,
	Material2D,
	MovieTexture,
	NavigationInfo,
	Normal,
	NormalInterpolator,
	OrderedGroup,
	OrientationInterpolator,
	PixelTexture,
	PlaneSensor,
	PlaneSensor2D,
	PointLight,
	PointSet,
	PointSet2D,
	PositionInterpolator,
	PositionInterpolator2D,
	ProximitySensor2D,
	ProximitySensor,
	QuantizationParameter,
	Rectangle,
	ScalarInterpolator,
	Script,
	Shape,
	Sound,
	Sound2D,
	Sphere,
	SphereSensor,
	SpotLight,
	Switch,
	TermCap,
	Text,
	TextureCoordinate,
	TextureTransform,
	TimeSensor,
	TouchSensor,
	Transform,
	Transform2D,
	Valuator,
	Viewpoint,
	VisibilitySensor,
	Viseme,
	WorldInfo,
};



char SFWorldNode_name[][64] = {
	"Reserved_Type = 0",
	"Anchor",
	"AnimationStream",
	"Appearance",
	"AudioBuffer",
	"AudioClip",
	"AudioDelay",
	"AudioFX",
	"AudioMix",
	"AudioSource",
	"AudioSwitch",
	"Background",
	"Background2D",
	"Billboard",
	"Bitmap",
	"Box",
	"Circle",
	"Collision",
	"Color",
	"ColorInterpolator",
	"CompositeTexture2D",
	"CompositeTexture3D",
	"Conditional",
	"Cone",
	"Coordinate",
	"Coordinate2D",
	"CoordinateInterpolator",
	"CoordinateInterpolator2D",
	"Curve2D",
	"Cylinder",
	"CylinderSensor",
	"DirectionalLight",
	"DiscSensor",
	"ElevationGrid",
	"Expression",
	"Extrusion",
	"Face",
	"FaceDefMesh",
	"FaceDefTables",
	"FaceDefTransform",
	"FAP",
	"FDP",
	"FIT",
	"Fog",
	"FontStyle",
	"Form",
	"Group",
	"ImageTexture",
	"IndexedFaceSet",
	"IndexedFaceSet2D",
	"IndexedLineSet",
	"IndexedLineSet2D",
	"Inline",
	"LOD",
	"Layer2D",
	"Layer3D",
	"Layout",
	"LineProperties",
	"ListeningPoint",
	"Material",
	"Material2D",
	"MovieTexture",
	"NavigationInfo",
	"Normal",
	"NormalInterpolator",
	"OrderedGroup",
	"OrientationInterpolator",
	"PixelTexture",
	"PlaneSensor",
	"PlaneSensor2D",
	"PointLight",
	"PointSet",
	"PointSet2D",
	"PositionInterpolator",
	"PositionInterpolator2D",
	"ProximitySensor2D",
	"ProximitySensor",
	"QuantizationParameter",
	"Rectangle",
	"ScalarInterpolator",
	"Script",
	"Shape",
	"Sound",
	"Sound2D",
	"Sphere",
	"SphereSensor",
	"SpotLight",
	"Switch",
	"TermCap",
	"Text",
	"TextureCoordinate",
	"TextureTransform",
	"TimeSensor",
	"TouchSensor",
	"Transform",
	"Transform2D",
	"Valuator",
	"Viewpoint",
	"VisibilitySensor",
	"Viseme",
	"WorldInfo"
};


enum FieldType_type {
	UnknownNodeType = 0,
	SF2DNodeType = SF2DNode,
	SF3DNodeType = SF3DNode,
	SFBoolType = SFWorldNode+1,
	SFColorType,

	SFFloatType,
	SFInt32Type,
	SFRotationType,
	SFStringType,
	SFTimeType,

	SFUrlType,
	SFVec2fType,
	SFVec3fType,
	SFImageType,
	SFCommandBufferType,

	SFScriptType,
	MF2DNodeType,
	MF3DNodeType,
	MFFloatType,
	MFBoolType,

	MFColorType,
	MFInt32Type,
	MFRotationType,
	MFStringType,
	MFTimeType,

	MFUrlType,
	MFVec2fType,
	MFVec3fType,
	MFImageType,
	MFCommandBufferType,

	MFScriptType,
};




struct BitStream_type {
	RMuint8 * stream;
	RMuint32 size;
	RMuint32 cur_byte;
	RMuint32 cur_bit;
};




struct FieldData {
	int fieldType; /* The type of the field (e.g., SFInt32Type). This is given by */
			/* the .Field Type. column of the node coding table for the */
			/* node to which it belongs. */
	int quantType; /* The type of quantization used for the field. This is given by */
			/* the .Q. column of the node coding table of the node to */
			/* which it belongs. Types refer to Table 19 in 9.3.3.1.1. */
	int animType; /* The animation method for the field. This is given by the .A. */
			/* column of the node coding table. Types refer to animation */
			/* type in Table 25 in 9.3.3.2.1. */
	boolean useEfficientCoding; /* Set to true if the efficient coding is to be used. This value is */
			/* FALSE by default. If there is a local */
			/* QuantizationParameter node this value is the same */
			/* as its useEfficientCoding field. */
	/* The following data structures are used in the quantization */
	/* process: */
	//FieldCodingTable fct; /* This field is determined from the node coding table as */
				/* described in 9.3.2.9. */
	//AnimFieldQP aqp; /* This field is only used in BIFS-Anim. It references an */
			/* AnimFieldQP stucture described in 9.3.2.10. */
	//QuantizationParameter lqp; /* This field points to the local QuantizationParameter */


	//boolean isQuantized; /* Set to true if the corresponding field is quantized, false */
				/* otherwise. */
	//int nbBits; /* The number of bits used for the quantization of the field. */
	//float floatMin[]; /* The minimum bounds for the quantization of vector fields. */
			/* These values are obtained from the FieldCodingTable */
			/* (described in 9.3.2.9) and the current */
			/* QuantizationParameter node (for BIFS-Scene) or the */
			/* animField (for BIFS-Anim). */
	//float floatMax[]; /* The maximum bounds for the quantization of vector fields. */
				/* These values are obtained from the FieldCodingTable */
				/* (described in 9.3.2.9) and the current */
				/* QuantizationParameter node (for BIFS-Scene) or the */
				/* animField (for BIFS-Anim). */
	//int intMin[]; /* The minimum bounds for integers (SFInt32 and MFInt32). */
				/* These values are obtained from the FieldCodingTable */
				/* (described in 9.3.2.9) and the current */
				/* QuantizationParameter node (for BIFS-Scene) or the  */
				/* animField (for BIFS-Anim). */
};



#define NODE_DATA_FIELD_NUMBER 16

struct NodeData {
	int nodeType; /* The nodeType of the node. */

	struct FieldData field[NODE_DATA_FIELD_NUMBER];
			/* The fields of this node whose construction is described below. This array is indexed in all mode. */
	boolean isAnimField[NODE_DATA_FIELD_NUMBER];
				/* The mask of animated fields for the entire BIFS-Anim session, */
				/* indexed in .dyn. mode. This array is only used in BIFS-Anim. */
				/* The following data describes the indexing of the fields in .in., .out., */
				/* .def., .dyn. and .all. modes */
	int nDEFbits; /* The number of bits used for .def. field codes (the width of the codewords in the 2nd column of the node coding tables). */
	int nINbits; /* The number of bits used for .in. field codes (the width of the codewords in the 3rd column of the node coding tables). */
	int nOUTbits; /* The number of bits used for .out. field codes (the width of the codewords in the 4th column of the node coding tables). */
	int numDEFfields; /* The number of .def. fields available for this node */
	int numDYNfields; /* The number of .dyn. fields available for this node. */
	int in2all[NODE_DATA_FIELD_NUMBER]; /* The ids of eventIns and exposedFields in .all. mode, indexed with the ids in .in. mode. */
	int def2all[NODE_DATA_FIELD_NUMBER]; /* The ids of fields and exposedFields in .all. mode, indexed with the ids in .def. mode. */
	int dyn2all[NODE_DATA_FIELD_NUMBER]; /* The ids of dynamic fields in .all. mode, indexed with the ids in .dyn. mode. */
	boolean useQuant;
				/* When the NodeData is used for storing a prototype, the useQuant states whether the quantization is applied on the PROTO or not. */
				/* boolean useAnim; When the NodeData is used for storing a prototype, the useQuant */
				/* states whether the BIFS-Anim is applied on the PROTO or not. */
	struct NodeData * protoData;
				/* In case that a node is contained in a PROTO, its NodeData structure points to the PROTO NodeData structure in the proto field.*/
};






#define ParseBIFS_GET_BITS( s, n, b )   \
	do {                            \
		RMstatus err;           \
		err = bitstream_get_bits( (s), (n), (RMuint32*)(b) ); \
		if( err ) {                       \
			bitstream_destory( (s) ); \
			return RM_ERROR;          \
		}                                 \
	} while(0)
//printf( "get %d bits from 0x%02x bit %d\n", (n), (s)->stream[(s)->cur_byte], (s)->cur_bit );
//printf( "got 0x%02x \n", *(b)&0xff );

/*
RMuint8 buf[] =
{
 0x47 ,0x40 ,0x20 ,0x12 ,0x00 ,0x04 ,0xb0 ,0x1a ,0x00 ,0x00 ,0xc1 ,0x00 ,0x00 ,0xd0 ,0xc0 ,0x10,
 0x12 ,0x81 ,0x30 ,0x2a ,0x05 ,0x72 ,0x61 ,0x04 ,0x88 ,0x50 ,0x45 ,0x05 ,0x3f ,0x00 ,0x70 ,0xa1,
 0xd4 ,0xbe ,0xff ,0xff ,0xff ,0xff ,0xff ,0xff ,0xff ,0xff ,0xff ,0xff ,0xff ,0xff ,0xff ,0xff,
 0xff ,0xff ,0xff ,0xff ,0xff ,0xff ,0xff ,0xff ,0xff ,0xff ,0xff ,0xff ,0xff ,0xff ,0xff ,0xff
};
*/

RMuint8 USENAMES = 0;



static RMstatus SFNode( enum SFNodeType_type nodeDataType, struct BitStream_type * bs, struct BIFSInfo_type * out );




static struct BitStream_type * bitstream_create( RMuint8 *src, RMuint32 size )
{
	struct BitStream_type * bs = (struct BitStream_type *)malloc( sizeof(struct BitStream_type) );
	bs->stream = src;
	bs->size = size;
	bs->cur_byte = 0;
	bs->cur_bit = 7;  /* assuming big endian, bit counter start from MSB */
	return bs;
}
static void bitstream_destory( struct BitStream_type * bs )
{
	if( bs != NULL ){
		free( bs );
		bs = NULL;
	}
	return;
}

static RMstatus bitstream_get_one_byte( struct BitStream_type * bs, RMuint8 * byte )
{
	RMuint8 curbyte = bs->stream[bs->cur_byte];
	RMuint8 curbit = bs->cur_bit;

	*byte = 0;   /* init the output */
	if( bs->cur_byte >= bs->size )
		return RM_ERROR;

	*byte = curbyte << (7-curbit);
	bs->cur_byte ++;
	curbyte = bs->stream[bs->cur_byte];
	*byte |= curbyte >> (curbit+1);

	return RM_OK;
}

static RMstatus bitstream_get_less_one_byte( struct BitStream_type * bs, RMuint32 num, RMuint8 * byte )
{
	RMuint8 curbyte = bs->stream[bs->cur_byte];
	RMuint8 curbit = bs->cur_bit;
	*byte = 0;   /* init the output */
	if( num >= 8 ) /* get 0 - 7 bits only */
		return RM_ERROR;
	if( bs->cur_byte >= bs->size )
		return RM_ERROR;

	*byte = curbyte << (7-curbit);

	if( curbit >= num) {  /* enough bits in curbyte */
		*byte >>= (8-num);
		bs->cur_bit -= num;
	}
	else if( curbit + 1 == (RMuint8)num ){  /* curbyte is just used up */
		*byte >>= (8-num);
		bs->cur_bit = 7;
		bs->cur_byte ++;
	}
	else {  /* curbyte is not enough */
		RMuint32 more = num - (curbit+1);
		RMuint32 next;
		bs->cur_byte++;
		if( bs->cur_byte >= bs->size ) {
			*byte = 0;
			return RM_ERROR;      /* end of stream no next byte */
		}
		next = bs->stream[bs->cur_byte];
		next >>= curbit+1;
		*byte |= next;
		*byte >>= 8-num;
		bs->cur_bit = 7-more;
	}
	return RM_OK;
}

static RMstatus bitstream_get_bits( struct BitStream_type * bs, RMuint32 num, RMuint32 *bits )
{
	RMstatus err;
	*bits = 0;
	if( num >= 8 ) {
		RMuint32 bytes = num/8;
		RMuint32 shift = 8-(num%8);
		RMuint8 bottom = 0;
		RMuint32 i;
		for( i=0; i<bytes; i++ ) {
			RMuint8 b;
			err = bitstream_get_one_byte( bs, &b );
			if( RMFAILED(err) )
				return err;
			*bits |= ((RMuint32)b & 0x000000ff) << (8*bytes - i*8);
		}
		*bits >>= shift;

		err = bitstream_get_less_one_byte( bs, num%8, &bottom );
		if( RMFAILED(err) )
			return err;

		*bits |= (RMuint32)bottom & (0x000000ff>>shift) ;
		return RM_OK;
	}
	else {
		return bitstream_get_less_one_byte( bs, num, (RMuint8*)bits );
	}
}


static RMstatus PROTOlist( struct BitStream_type * bs, struct BIFSInfo_type * out )
{
	RMuint8 bits;
	RMDBGLOG((CALLDBG, "PROTOlist\n" ));
	ParseBIFS_GET_BITS( bs, 1, &bits );
	while( bits ){
		// PROTOdeclaration();
		fprintf( stderr, "PROTOdeclaration is not implemented,  return now\n" );
		return RM_ERROR;  /* protodeclaration isnot implemneted */
		ParseBIFS_GET_BITS( bs, 1, &bits );
	}
	return RM_OK;
}

static RMuint32 GetNDTnbBits( enum SFNodeType_type node )
{
	RMDBGLOG((CALLDBG, "GetNDTnbBits %d\n", (RMuint32)node ));

	return NodeTypeBitNumber_table[ (RMuint32)node ];
}

static RMuint32 GetNodeType( enum SFNodeType_type nodetype, RMuint32 localnodetype )
{
	RMDBGLOG((CALLDBG, "GetNodeType nodetype 0x%x, localnodetype 0x%x\n", nodetype, localnodetype  ));
	switch( nodetype ) {
		case SFTopNode:
			if( localnodetype == 0x4 )
				return OrderedGroup;
			return 0;
		case SF3DNode:
			if( localnodetype == 0x28 )
				return Sound2D;
			else if( localnodetype == 0x26 )
				return Shape;
			return 0;
		case SFAudioNode:
			if( localnodetype == 0x6 )
				return AudioSource;
			return 0;
		case SFGeometryNode:
			if( localnodetype == 0x1 )
				return Bitmap;
			return 0;
		case SFAppearanceNode:
			if( localnodetype == 0x1 )
				return Appearance;
			return 0;
		case SFTextureNode:
			if( localnodetype == 0x4 )
				return MovieTexture;
			return 0;
		default:
			return 0;
	}
}

static struct NodeData * CreateNode( RMuint32 nodetype )
{
	struct NodeData * nd = NULL;

	RMDBGLOG((CALLDBG, "CreateNode %s\n", SFWorldNode_name[nodetype] ));
	nd = (struct NodeData*)malloc(sizeof(struct NodeData));
	if( ! nd )
		return NULL;
	switch( nodetype ) {
		case Appearance:
			nd->nodeType = Appearance;
			nd->field[0].fieldType = SFMaterialNode;
			nd->field[1].fieldType = SFTextureNode;
			nd->field[2].fieldType = SFTextureTransformNode;
			nd->def2all[0] = 0;
			nd->def2all[1] = 1;
			nd->def2all[2] = 2;
			nd->nDEFbits = 2;
			nd->nINbits = 2;
			nd->nOUTbits = 2;
			nd->protoData = NULL;
			return nd;
		case AudioSource:
			nd->nodeType = AudioSource;
			nd->field[0].fieldType = 0;
			nd->field[1].fieldType = MFUrlType;
			nd->field[2].fieldType = 0;
			nd->field[3].fieldType = 0;
			nd->field[4].fieldType = 0;
			nd->field[5].fieldType = 0;
			nd->field[6].fieldType = 0;
			nd->field[7].fieldType = 0;
			nd->def2all[0] = 0;
			nd->def2all[1] = 1;
			nd->def2all[2] = 2;
			nd->def2all[3] = 3;
			nd->def2all[4] = 4;
			nd->def2all[5] = 5;
			nd->def2all[6] = 6;
			nd->def2all[7] = 7;
			nd->nDEFbits = 3;
			nd->nINbits = 3;
			nd->nOUTbits = 3;
			nd->protoData = NULL;
			return nd;
		case Bitmap:
			nd->nodeType = Bitmap;
			nd->field[0].fieldType = SFVec2fType;
			nd->def2all[0] = 0;
			nd->nDEFbits = 0;
			nd->nINbits = 0;
			nd->nOUTbits = 0;
			nd->protoData = NULL;
			return nd;
		case MovieTexture:
			nd->nodeType = MovieTexture;
			nd->field[0].fieldType = 0;
			nd->field[1].fieldType = 0;
			nd->field[2].fieldType = 0;
			nd->field[3].fieldType = 0;
			nd->field[4].fieldType = MFUrlType;
			nd->field[5].fieldType = 0;
			nd->field[6].fieldType = 0;
			nd->def2all[0] = 0;
			nd->def2all[1] = 1;
			nd->def2all[2] = 2;
			nd->def2all[3] = 3;
			nd->def2all[4] = 4;
			nd->def2all[5] = 5;
			nd->def2all[6] = 6;
			nd->nDEFbits = 3;
			nd->nINbits = 3;
			nd->nOUTbits = 3;
			nd->protoData = NULL;
			return nd;
		case OrderedGroup:
			nd->nodeType = OrderedGroup;
			nd->field[0].fieldType = MF3DNodeType;
			nd->field[1].fieldType = MFFloatType;
			nd->def2all[0] = 0;
			nd->def2all[1] = 1;
			nd->nDEFbits = 1;
			nd->nINbits = 2;
			nd->nOUTbits = 1;
			nd->protoData = NULL;
			return nd;
		case Shape:
			nd->nodeType = Shape;
			nd->field[0].fieldType = SFAppearanceNode;
			nd->field[1].fieldType = SFGeometryNode;
			nd->def2all[0] = 0;
			nd->def2all[1] = 1;
			nd->nDEFbits = 1;
			nd->nINbits = 1;
			nd->nOUTbits = 1;
			nd->protoData = NULL;
			return nd;
		case Sound2D:
			nd->nodeType = Sound2D;
			nd->field[0].fieldType = SFFloatType;
			nd->field[1].fieldType = SFVec2fType;
			nd->field[2].fieldType = SFAudioNode;
			nd->field[3].fieldType = SFBoolType;
			nd->def2all[0] = 0;
			nd->def2all[1] = 1;
			nd->def2all[2] = 2;
			nd->def2all[3] = 3;
			nd->nDEFbits = 2;
			nd->nINbits = 2;
			nd->nOUTbits = 2;
			nd->protoData = NULL;
			return nd;
		default:
			free(nd);
			return NULL;
	}
}


static void DestroyNode( struct NodeData * node )
{
	RMDBGLOG((CALLDBG, "DestroyNode\n" ));
	if( node != NULL )
		free( node );
	return;
}

static RMuint8 isSF( struct FieldData * field )
{
	RMDBGLOG((CALLDBG, "isSF %d\n", field->fieldType ));
	if( (RMuint32)field->fieldType > (RMuint32)SFScriptType ) {
		return 0;
	}
	else {
		return 1;
	}
}

static enum FieldType_type MultipleFieldTypeToSingleFieldType( enum FieldType_type type)
{
	switch( type ) {
		case MF2DNodeType:
		case SF2DNodeType:
			return SF2DNodeType;
		case MF3DNodeType:
		case SF3DNodeType:
			return SF3DNodeType;
		case MFBoolType:
		case SFBoolType:
			return SFBoolType;
		case MFColorType:
		case SFColorType:
			return SFColorType;
		case MFFloatType:
		case SFFloatType:
			return SFFloatType;
		case MFInt32Type:
		case SFInt32Type:
			return SFInt32Type;
		case MFRotationType:
		case SFRotationType:
			return SFRotationType;
		case MFStringType:
		case SFStringType:
			return SFStringType;
		case MFTimeType:
		case SFTimeType:
			return SFTimeType;
		case MFUrlType:
		case SFUrlType:
			return SFUrlType;
		case MFVec2fType:
		case SFVec2fType:
			return SFVec2fType;
		case MFVec3fType:
		case SFVec3fType:
			return SFVec3fType;
		case MFImageType:
		case SFImageType:
			return SFImageType;
		case MFCommandBufferType:
		case SFCommandBufferType:
			return SFCommandBufferType;
		case MFScriptType:
		case SFScriptType:
			return SFScriptType;
		case UnknownNodeType:
		default:
			return UnknownNodeType;
	}
}



static RMstatus SFUrl( enum SFNodeType_type nodeDataType, enum SFNodeType_type parentNodeDataType, struct BitStream_type * bs, struct BIFSInfo_type * out )
{
	RMuint8 isOD = 0;
	RMDBGLOG((CALLDBG, "SFUrl\n" ));
	ParseBIFS_GET_BITS( bs, 1, &isOD ); /* is OD */
	if( isOD ) {
		RMuint32 ODID;
		ParseBIFS_GET_BITS( bs, 10, &ODID ); /* get OD id*/
		if( parentNodeDataType == AudioSource ) {
			RMDBGLOG((CALLDBG, "audio OD ID 0x%x\n", ODID ));
			out->audOD = ODID;
		}
		else if( parentNodeDataType == MovieTexture ){
			RMDBGLOG((CALLDBG, "video OD ID 0x%x\n", ODID ));
			out->vidOD = ODID;
		}
		else {
			RMDBGLOG((CALLDBG, "unknown OD ID 0x%x\n", ODID ));
		}
		return RM_OK;
	}
	else {
		RMDBGLOG((CALLDBG, "SFUrl : SFString not implemented\n" ));
		return RM_ERROR;
	}
}


static RMstatus SFField( struct NodeData * node, struct FieldData * field,  struct BitStream_type * bs, struct BIFSInfo_type * out )
{
	RMDBGLOG((CALLDBG, "SFField\n" ));
	switch( field->fieldType ) {
		case SF2DNodeType:
		case SF3DNodeType:
		case SFAudioNode:
		case SFGeometryNode:
		case SFAppearanceNode:
		case SFTextureNode:
			return SFNode( field->fieldType, bs, out );
		case SFBoolType:
			RMDBGLOG((CALLDBG, "SFBool not implemented\n" ));
			//SFBool bValue;
			return RM_ERROR;
		case SFColorType:
			RMDBGLOG((CALLDBG, "SFColorType not implemented\n" ));
			//SFColor cValue(field);
			return RM_ERROR;
		case SFFloatType:
			RMDBGLOG((CALLDBG, "SFFloat not implemented\n" ));
			//SFFloat fValue(field);
			return RM_ERROR;
		case SFInt32Type:
			RMDBGLOG((CALLDBG, "SFInt32 not implemented\n" ));
			//SFInt32 iValue(field);
			return RM_ERROR;
		case SFRotationType:
			RMDBGLOG((CALLDBG, "SFRotation not implemented\n" ));
			//SFRotation rValue(field);
			return RM_ERROR;
		case SFStringType:
			RMDBGLOG((CALLDBG, "SFString not implemented\n" ));
			//SFString sValue;
			return RM_ERROR;
		case SFTimeType:
			RMDBGLOG((CALLDBG, "SFTime not implemented\n" ));
			//SFTime tValue;
			return RM_ERROR;
		case SFUrlType:
			return SFUrl( field->fieldType, node->nodeType, bs, out );
		case SFVec2fType:
			RMDBGLOG((CALLDBG, "SFVec2f not implemented\n" ));
			//SFVec2f v2Value(field);
			return RM_ERROR;
		case SFVec3fType:
			RMDBGLOG((CALLDBG, "SFVec3f not implemented\n" ));
			//SFVec3f v3Value(field);
			return RM_ERROR;
		case SFImageType:
			RMDBGLOG((CALLDBG, "SFImage not implemented\n" ));
			//SFImage imageValue(field);
			return RM_ERROR;
		case SFCommandBufferType:
			RMDBGLOG((CALLDBG, "SFCommandBuffer not implemented\n" ));
			//SFCommandBuffer commandValue(field);
			return RM_ERROR;
		case SFScriptType:
			RMDBGLOG((CALLDBG, "SFScript not implemented\n" ));
			//SFScript scriptValue();
			return RM_ERROR;
		default:
			RMDBGLOG((CALLDBG, "%d not implemented\n", field->fieldType ));
			return RM_ERROR;
	}
}


static RMstatus MFListDescription( struct NodeData * node, struct FieldData * field, struct BitStream_type * bs, struct BIFSInfo_type * out )
{
	RMuint8 endFlag;
	RMstatus err;

	RMDBGLOG((CALLDBG, "MFListDescription\n" ));
	ParseBIFS_GET_BITS( bs, 1, &endFlag ); /* bit(1) endFlag; */
	while( !endFlag ) {
		field->fieldType = MultipleFieldTypeToSingleFieldType( field->fieldType );
		err = SFField( node,field, bs, out );
		if( RMFAILED(err) ) {
			return RM_ERROR;
		}
		ParseBIFS_GET_BITS( bs, 1, &endFlag ); /* bit(1) endFlag; */
	}
	return RM_OK;
}


static RMstatus MFVectorDescription( struct NodeData * node, struct FieldData * field, struct BitStream_type * bs, struct BIFSInfo_type * out )
{
	RMstatus err;
	RMuint8 bits;
	RMuint32 numberOfFields;
	RMuint32 i;

	RMDBGLOG((CALLDBG, "MFVectorDescription\n" ));
	ParseBIFS_GET_BITS( bs, 5, &bits ); /* int(5) NbBits; */
	ParseBIFS_GET_BITS( bs, bits, &numberOfFields ); /* int(NbBits) numberOfFields; */

	for( i=0; i < numberOfFields; i++ ) {
		err = SFField( node, (field+i), bs, out );
		if( RMFAILED(err) ) {
			return err;
		}
	}
	return RM_OK;
}


static RMstatus MFField( struct NodeData * node, struct FieldData * field,  struct BitStream_type * bs, struct BIFSInfo_type * out )
{
	RMuint8 bits;
	RMDBGLOG((CALLDBG, "MFField\n" ));
	ParseBIFS_GET_BITS( bs, 1, &bits ); /* bit(1) reserved; */
	if( ! bits ) {
		RMuint8 isListDescription;
		ParseBIFS_GET_BITS( bs, 1, &isListDescription ); /* bit(1) */
		if( isListDescription) {
			return MFListDescription( node, field, bs, out );
		}
		else {
			return MFVectorDescription( node, field, bs, out );
		}
	}
	else {
		return RM_OK;
	}
}

static RMstatus Field( struct NodeData * node, struct FieldData * field,  struct BitStream_type * bs, struct BIFSInfo_type * out )
{
	RMDBGLOG((CALLDBG, "Field\n" ));
	if( isSF(field) )
		return SFField(node, field, bs, out);
	else
		return MFField(node, field, bs, out);
}

static RMstatus ListNodeDescription( struct NodeData * node,  struct BitStream_type * bs, struct BIFSInfo_type * out )
{
	RMuint8 bits;
	RMstatus err;
	RMDBGLOG((CALLDBG, "ListNodeDescription\n" ));
	ParseBIFS_GET_BITS( bs, 1, &bits ); /* bit(1) endFlag; */
	while( ! bits ){
		if( node->protoData != NULL ) {
			/*
			bit(1) isedField;
			if( isedField){
				bit(node.nALLbits) fieldRef;
				bit(node.proto.nALLbits) protoField;
			} else {
				bit(node.nDEFbits) fieldRef;
				Field value(node.field[node.def2all[fieldRef]]);
			}
			*/
			fprintf( stderr, "protoData not NULL  not implemented\n" );
			return RM_ERROR;
		}
		else {
			ParseBIFS_GET_BITS( bs, node->nDEFbits, &bits ); /* bit(node.nDEFbits) fieldRef; */
			RMDBGLOG((CALLDBG, "field %d\n", bits ));
			err = Field( node, &(node->field[node->def2all[bits]]), bs, out );
			if( RMFAILED(err) ) {
				RMDBGLOG((CALLDBG, "Field failed, type %d\n", (node->field[node->def2all[bits]]).fieldType ));
				return RM_ERROR;
			}
		}
		ParseBIFS_GET_BITS( bs, 1, &bits ); /* bit(1) endFlag; */
	}
	return RM_OK;
}


static RMstatus SFNode( enum SFNodeType_type nodeDataType, struct BitStream_type * bs, struct BIFSInfo_type * out )
{
	RMuint8 bits;
	RMDBGLOG((CALLDBG, "SFnode\n" ));
	ParseBIFS_GET_BITS( bs, 1, &bits );
	if( bits ) { /* is Reused */
		//GetNodeID
		fprintf( stderr, "Reused node id not implemented\n" );
		return RM_ERROR;
	}
	else {
		RMuint32 localNodeType, nodetype;
		RMuint32 nbBits = GetNDTnbBits( nodeDataType );
		ParseBIFS_GET_BITS( bs, nbBits, &bits );  /* get localnoeetype */
		localNodeType = (RMuint32)bits & 0x000000ff;
		nodetype = GetNodeType( nodeDataType, localNodeType );
		if( 0){ /* nodetype == IndexedFaceSetType .. */
		}
		else {
			if( localNodeType == 0 ) {
				/*
				bit(GetNDTnbBitsExt(nodeDataType) extLocalNodeType;
				if (extLocalNodeType == 1) {
					bit(BIFSConfiguration.PROTOIDbits) PROTOnodeType;
					nodeType = GetPROTONodeType(PROTODataType,PROTOnodeType)
				}
				if (extLocalNodeType > 1) {
					nodeType = GetExtNodeType(NodeDataType,extLocalNodeType)
				}
				*/
				RMDBGLOG((ENABLE, "localNodeType type not implemented\n" ));
				return RM_ERROR;
			}
			ParseBIFS_GET_BITS( bs, 1, &bits ); /* bit(1) isUpdateable; */
			if( bits ) {
				/*
				bit(BIFSConfiguration.nodeIDbits) nodeID;
				if( USENAMES ) {
					String name;
				}
				*/
				RMDBGLOG((ENABLE,"updateable not implemented\n" ));
				return RM_ERROR;
			}
			ParseBIFS_GET_BITS( bs, 1, &bits ); /* bit(1) MaskAccess; */
			if( bits) {
				/*
				MaskNodeDescription mnode(MakeNode(nodeDataType, nodeType));
				*/
				RMDBGLOG((ENABLE, "MaskAccess not implemented\n" ));
				return RM_ERROR;
			}
			else {
				RMstatus err;
				struct NodeData * nd = CreateNode( nodetype );
				if( nd == NULL ) {
					RMDBGLOG((ENABLE, "node creation failed nodeType %d, %s \n", nodetype, SFWorldNode_name[nodetype] ));
					return RM_ERROR;
				}

				err = ListNodeDescription( nd, bs, out );
				if( RMFAILED(err) ) {
					RMDBGLOG((ENABLE, "failed ListNodeDescription nodeType %d, %s \n", nodetype, SFWorldNode_name[nodetype] ));
				}
				DestroyNode( nd );
				return err;
			}
		}
	}

	return RM_OK;
}


static RMstatus ROUTEs( struct BitStream_type * bs, struct BIFSInfo_type * out )
{
	RMDBGLOG((CALLDBG, "ROUTEs\n" ));
	return RM_OK;
}


static RMstatus BIFSscene(struct BitStream_type * bs, struct BIFSInfo_type *out)
{
	RMuint8 bits;
	RMstatus err;
	RMDBGLOG((CALLDBG, "BIFSscene\n" ));
	ParseBIFS_GET_BITS( bs, 6, &bits );  /* reserved */
	ParseBIFS_GET_BITS( bs, 1, &bits );  /* USENAMES */
	USENAMES = bits;
	err = PROTOlist(bs, out);
	if( err )
		return RM_ERROR;
	err = SFNode(SFTopNode, bs, out);
	if( err )
		return RM_ERROR;

	ParseBIFS_GET_BITS( bs, 1, &bits );
	if( bits & 0x1 )
		err = ROUTEs(bs, out);
		if( err )
			return RM_ERROR;
	return RM_OK;
}

static RMstatus BIFSsceneReplace(struct BitStream_type * bs, struct BIFSInfo_type *out)
{
	RMDBGLOG((CALLDBG, "BIFSsceneReplace\n" ));
	return BIFSscene( bs, out );
}


RMstatus ParseBIFS(RMuint8 *pBuffer1, RMuint32 size1, RMuint8 *pBuffer2, RMuint32 size2, struct BIFSInfo_type *out)
{
	struct BitStream_type * bs = NULL;
	RMuint32 bits = 0;

	RMDBGLOG((CALLDBG, "Parse BIFS\n" ));
	if (out == 0)
		return RM_ERROR;

	/* parse ts package for now */
	pBuffer1 += 14;
	size1 -= 14;
	fprintf( stderr, "%02x %02x %02x %02x\n", (int)*pBuffer1, (int)*(pBuffer1+1), (int)*(pBuffer1+2), (int)*(pBuffer1+3) );
	bs = bitstream_create( pBuffer1, size1 );
	if( bs == NULL )
		return RM_ERROR;

	/* trying to extract only video and audio od, through away the rest information */
	/* assuming only command syntax, no animation */
	ParseBIFS_GET_BITS( bs, 2, &bits );
	switch( bits ) {
		case 0:
		case 1:
		case 2:
			fprintf( stderr, "cmd not supported %d\n", (int)bits );
			break;
		case 3:
		{
			RMstatus err;
			err = BIFSsceneReplace( bs, out );
			if( err ) {
				bitstream_destory( bs );
				return RM_ERROR;
			}
		}
	}

	bitstream_destory( bs );
	return RM_OK;
}

/*
int test_main()
{
	struct BIFSInfo_type out;
	out.vidOD = 0;
	out.audOD = 0;

	if( ParseBIFS(buf, 64, NULL, 0, &out))
		printf( "Parse returned error \n" );

	printf( "vid od %d  aud od %d \n", out.vidOD, out.audOD );
	return 0;
}
*/
