
/*
 *
 * Copyright (c) Sigma Designs, Inc. 2002. All rights reserved.
 *
 */

/**
	@file play_vdemux.h
	@brief sample application, thread file for software demux based decoding
	
	@author Yifan Liu
	@ingroup dccsamplecode
*/



#ifndef __PLAY_V_DEMUX_H__
#define __PLAY_V_DEMUX_H__

// play_psfswpvr is a two threaded application.  
// the play_psfswpvr.c contains the main thread, which utilizes the hardware demux.
// play_vdemux.c contains a thread that utilize a software demux
// the hardware thread starts a playback from (for all demux tasks) first
// Upon swiching command, all hardware demux tasks' output shall be suspended 
// while the demux module is still alive.  The main thread is suspended.
// The software demux is created on main_vdemux thread. the output of the software
// demux is then connected to the video and audio decoders and start playback from
// software demux's source (assume only one for now).
// 


#define MAX_TASK_COUNT		3

#define RM_DEVICES_STC      0x1
#define RM_DEVICES_VIDEO    0x2
#define RM_DEVICES_AUDIO    0x4
#define RM_DEVICES_PSFDEMUX 0x8

struct context_per_task;




//extern struct playback_cmdline  playback_options[MAX_TASK_COUNT]; 
//extern struct video_cmdline     video_options[MAX_TASK_COUNT]; 
//extern struct audio_cmdline     audio_options[MAX_TASK_COUNT*MAX_AUDIO_DECODER_INSTANCES]; 
//extern struct demux_cmdline     demux_options[MAX_TASK_COUNT]; 
//extern struct display_cmdline   display_options[MAX_TASK_COUNT]; 
//extern struct display_context   disp_info[MAX_TASK_COUNT]; 
//extern struct dh_context        dh_info[MAX_TASK_COUNT] = {{0,},}; 

//extern struct context_per_task  Tasks[MAX_TASK_COUNT];
//extern RMuint32 task_count;

//extern RMuint32	output_count_per_task;


extern RMstatus send_disable_output_demux_command(struct RUA *pRUA, RMuint32 demux, struct EMhwlibOutputMask_type *discmd);
extern RMstatus DecoderStop(struct context_per_task *pContext, RMuint32 devices);
extern RMstatus DecoderPlay(struct context_per_task *pContext, RMuint32 devices, enum DCCVideoPlayCommand mode);
extern RMstatus DecoderPause(struct context_per_task *pContext, RMuint32 devices);


//extern int main_vdemux(void);
extern void * main_vdemux( void * dcc_context_data );

extern RMstatus SwtichToSoftwareDemux(void);
extern RMstatus ReconnectHardwareDemux(void);

extern RMstatus RunSoftwareDemux( struct context_per_task * hwdemux_task );

extern void SetupSoftwareDemuxGlobal( struct context_per_task  *tasks, RMuint32 taskcount, RMuint32 outputcountpertask );

extern RMascii alt_filename[2048];

extern pthread_t software_demux_tid;
extern RMbool software_demux_in_action;
extern RMuint64 start_time_stamp;
extern RMuint64 start_file_position;

#endif // __PLAY_V_DEMUX_H__

