#include "cpu_uart_gpio.h"
/*
 *	RX  0
 *	CTS 1
 *	DSR 2
 *	DCD 3
 *	TXD 4
 *	RTS 5
 *	DTR 6

 */
void Write_Gpio_Uart1(enum UART_type pin, RMuint8 ishigh)
{
	
	struct llad *pLLAD;
	struct gbus *pGBus;
	RMuint32 chip_num = 0;
	RMascii device[40];
	sprintf(device, "%lu", chip_num);
	
	pLLAD = llad_open(device);
	pGBus = gbus_open(pLLAD);
	//Set CPU_UART_GPIO_MODE . Value : 0x7f7f : All pin are in the GPIO mode.
	gbus_write_uint32(pGBus, REG_BASE_cpu_block + CPU_UART1_base + CPU_UART_GPIOMODE,0x7F7F);
	//Set CPU_UART_GPIO_DIR : direction of pin : 0 : input , 1 : output
	gbus_write_uint32(pGBus, REG_BASE_cpu_block + CPU_UART1_base + CPU_UART_GPIODIR, ( 0x0100 | 1) << pin);
	if(ishigh)
		gbus_write_uint32(pGBus, REG_BASE_cpu_block + CPU_UART1_base + CPU_UART_GPIODATA, (0x0100 |1) << pin);
	else
		gbus_write_uint32(pGBus, REG_BASE_cpu_block + CPU_UART1_base + CPU_UART_GPIODATA, 0x0100 << pin);
		
	gbus_close(pGBus);
	llad_close(pLLAD);
	
	
}

void Write_Gpio_Uart0(enum UART_type pin, RMuint8 ishigh)
{
	
	struct llad *pLLAD;
	struct gbus *pGBus;
	RMuint32 chip_num = 0;
	RMascii device[40];
	sprintf(device, "%lu", chip_num);
	
	pLLAD = llad_open(device);
	pGBus = gbus_open(pLLAD);
	//Set CPU_UART_GPIO_MODE . Value : 0x7f7f : All pin are in the GPIO mode.
	//gbus_write_uint32(pGBus, REG_BASE_cpu_block + CPU_UART0_base + CPU_UART_GPIOMODE,0x7F7F);
	//gbus_write_uint32(pGBus, REG_BASE_cpu_block + CPU_UART0_base + CPU_UART_GPIOMODE,0x7F11);
	//Set CPU_UART_GPIO_DIR : direction of pin : 0 : input , 1 : output
	gbus_write_uint32(pGBus, REG_BASE_cpu_block + CPU_UART0_base + CPU_UART_GPIODIR, ( 0x0100 | 1) << pin);
	if(ishigh)
		gbus_write_uint32(pGBus, REG_BASE_cpu_block + CPU_UART0_base + CPU_UART_GPIODATA, (0x0100 |1) << pin);
	else
		gbus_write_uint32(pGBus, REG_BASE_cpu_block + CPU_UART0_base + CPU_UART_GPIODATA, 0x0100 << pin);
	
	gbus_close(pGBus);
	llad_close(pLLAD);
	
	
}
