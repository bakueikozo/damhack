/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   outports_options.h
  @brief  

  outports_options.h

  @author Oriol Prieto Gasco
  @date   2006-04-15
*/

#ifndef __OUTPORTS_OPTIONS_H__
#define __OUTPORTS_OPTIONS_H__


struct outport_config{
	/* action */
	enum DCCOutportState action;
	/* format */
	RMascii vidmode_filename[2048];  /* maybe translate to format struct on parse_outports_options */
	enum EMhwlibTVStandard standard; /* maybe translate to format struct on parse_outports_options */
	RMuint32 flags; /* as in DCCOutportConfig */
	/* route */
	enum DCCRoute route;
	/* video */
/* 	RMint8 brightness;  */
/* 	RMuint8 hue; */
/* 	RMuint8 contrast; */
/* 	RMuint8 saturation; */
	/* aspect */
	RMuint8 ar_x;
	RMuint8 ar_y;
	RMbool afd_used;
	RMbool active_format_valid;
	enum EMhwlibActiveFormat active_format;
	RMbool wss_used;  // WSS settings for backward compatibility, to be removed
	struct EMhwlibCGMSWSS_625 wss_625;
	struct EMhwlibCGMSWSS_525 wss_525;
	/* copy */
	RMuint32 agc_level;          /* macrovision pulses 0, 1, 2, 3. Usually is same value as aps. */
	RMuint32 agc_version;        /* one of AGC_VERSION_0_CONSTANT_BPP or AGC_VERSION_1_ALTERNATE_BPP  */
	RMuint32 aps_level;          /* analog protection system */
	RMuint32 cgmsa;              /* copy generation management system 0, 1, 2, 3 */
	RMuint32 rcd;                /* redistribution control descriptor */
	RMuint32 asb;                /* analog source bit */

	/* signal */
	enum EMhwlibColorSpace color_space;
	RMuint32 bus_size;
	enum EMhwlibComponentOrder component_order;

	/* EMhwlib pre-encodes the component/composite mode on 
	   struct RMGenericPropertyID_AnalogTVFormat so we need to do some 
	   ugly workarounds to mix that information with the user's preferences...
	   The policy is:
	   If component_mode is set by the caller (-cav_mode option) it is used.
	   If component mode is not set by the caller, the component mode defined by the TVFormat
	   structure is used.
	   If composite_mode is set by the caller it is used.
	   If composite_mode is not set by the caller, the composite mode defined by the TVFormat
	   structure is used.

	*/
	RMbool valid_component_mode;   /* if FALSE, the component_mode in the TVFormat structure is used */
	enum EMhwlibComponentMode component_mode;
	RMbool valid_composite_mode;   /* if FALSE, the component_mode in the TVFormat structure is used */
	enum EMhwlibCompositeMode composite_mode;
	enum EMhwlibColorOrder color_order;
 	enum EMhwlibDigitalTimingSignal digital_protocol;
	/* hdmi / dvi / edid / hdcp */
	enum DH_device_state dvi_hdmi_state;
	enum DH_vendor_parts dvi_hdmi_part;
	RMbool dvi_hdmi_hdcp;
	RMbool dvi_hdmi_display_edid;
	RMbool hdmi_monitor;  // TRUE: HDMI monitor/TV, FALSE: DVI monitor (no AVI frames, no audio)
	RMbool hdmi_force;  // TRUE: force hdmi_monitor state, FALSE: determine hdmi_monitor state from monitor EDID
	RMascii *dvi_hdmi_edid_file;
	RMuint32 i2c_module;
	RMuint32 i2c_speed;
	RMbool i2c_ddc_on_tx;
	RMuint32 dvi_reset_gpio;
	RMbool hdmi_de;
	enum DH_active_format_aspect_ratio hdmi_active_format;
	RMuint32 hdmi_bar_top;
	RMuint32 hdmi_bar_bottom;
	RMuint32 hdmi_bar_left;
	RMuint32 hdmi_bar_right;
	enum EMhwlibScanInfo hdmi_scan;
	RMbool use_active_format;
	RMascii *hdmi_spd_vendor;
	RMascii *hdmi_spd_product;
	enum DH_source_dev_info hdmi_spd_class;
	RMuint32 tmds_threshold;
	enum GPIOId_type tmds_gpio;
	enum GPIOId_type filter_gpio_start;
	RMuint32 filter_gpio_num;
	RMuint32 filter_gpio_val;

	/**/
	RMbool dig_force_doublerate;
	RMbool dig_doublerate;
	RMbool dig_clk_normal;
	RMbool dig_ddr;
	RMbool dig_inv_cap_clk;
	RMuint32 dig_delay;
	RMbool dig_force_delay;
	RMbool dig_vsync_delay;
	RMbool dig_trailing_edge;
	RMbool chroma_sync;
	/***/
	RMbool scart_enable;
	RMuint32 scart_en_pio;
	RMbool scart_widescreen;
	RMuint32 scart_ws_pio;
	struct dh_context *dh_info;
	struct dh_context dh_info_local;

	RMbool use_digital_timing; /* this is needed for vga */

	RMbool force_DACCompDisable;
	RMbool DACCompDisable;
	RMbool force_DACDisable;
	struct EMhwlibDACDisable DACDisable;
	RMbool force_LumaChromaDelay;
	enum EMhwlibLumaChromaDelay LumaChromaDelay;
	RMbool force_TripleCVBS;
	RMbool TripleCVBS;
	RMbool force_LineCrop;
	struct EMhwlibLineCrop LineCrop;
	RMbool disable_pixel_timer;
};

struct global_config{
	RMbool allow_buf;
	RMbool allow_otf;
 	RMbool do_cs;
	RMbool do_cp;

	RMuint32 chip;
};

struct outports_options{
	struct outport_config digital;
	struct outport_config analog;
	struct outport_config component;
	struct outport_config composite;
	struct global_config global;
};

RMstatus parse_outports_options(RMuint32 argc, RMascii *argv[], RMuint32 *index, struct outports_options *options);

RMstatus init_outports_options(struct outports_options *options);

RMstatus apply_outports_options(struct DCC *pDCC, struct outports_options *options);


#endif // __OUTPORTS_OPTIONS_H__
