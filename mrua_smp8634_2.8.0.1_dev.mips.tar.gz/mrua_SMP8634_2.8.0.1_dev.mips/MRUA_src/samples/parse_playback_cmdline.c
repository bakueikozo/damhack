#define _LARGEFILE64_SOURCE 1 // Required for large files (> 4GB)
#include "sample_os.h"

#define ALLOW_OS_CODE 1
#include "../rua/include/rua.h"
#include "../dcc/include/dcc.h"
#include "common.h"

extern int verbose_stdout;
extern int verbose_stderr;
RMbool manutest = FALSE;

void show_playback_options(void)
{
	fprintf(stderr, "PLAYBACK OPTIONS (default values inside brackets)\n"
		"\t-m chip: Selects the board number [0]\n"
		"\t-L count: Loops the file count times [1]\n"
		"\t-l: Loops the file infinitely [FALSE]\n"
		"\t-waitexit: application doesn't stop and exit until q key is pressed\n"
		"\t-data mode: selects which streams to send to decode: n,a,v,s (n=none) [avs]\n"
		"\t-ts mode: selects which streams to send PTS to decode: n,a,v,s (n=none) [avs]\n"
		"\t-save mode: selects which streams to save into file: n,a,v,s (n=none) [n]\n"
		"\t            mode: avs, av, a, vs, v, n\n"
		"\t-savems mode: same as -save but outputs elementary file with embedded pts and frame_size data\n"
		"\t-speed N M: set the speed factor to N/M [1 1]\n"
		"\t-dram controller: sets the dram controller to use [0]\n"
 		"\t-manutest: maunufacture testing mode\n"
		"\t-pause: starts playback in pause state\n"
		"\t-bcc filename: use the BCC file filename [NULL]\n"
		"\t-stcdrift: enable correction of STC-to-PCR drift (SPI only)\n"
		"\t-stcdbg n: level of debug print [0]..3\n"
		"\t-delay time: set delay in ms for audio, video timers relative to stc timer [0]\n"
		"\t-dmapool count log2_size: sets the count and the log2 size of the dma pool.\n"
		"\t                          Default is application dependent.\n"
		"\t-disk_ctrl level: minimum number of buffer when reactivation of disk must be done.\n"
		"\t-prebuf size: maximum size in kB read from media for prebuffering.\n"
		"\t-sat: send audio while in trickmodes [false]\n"
		"\t-past: play any supported track [disabled]; otherwise video track must have a known codec\n"
		"\t-noucode: do not load microcode [FALSE]\n"
		"\t-STCid value: selects the STC ID to use [0]\n"
		"\t-STC_initial_value value: sets STC initial value before reading stream (allows black frame in prebuffering mode)]\n"
		"\t-far <value>: fast audio recovery after trickmodes (performs a seek when resuming from trickmodes) [0] 1\n"
		"\t-dontSendMPEG4pts: dont send video pts for mpeg4/h264 encoded AVI files\n"
		);
}

static RMuint64 g_t = 0;
static RMuint64 HDsleepTime = 0;
static RMuint64 HDrunTime = 0;

static RMstatus default_disk_ctrl_callback(const enum disk_control_action action)
{
	RMuint64 t;
	RMuint64 diff;

	t = RMGetTimeInMicroSeconds();
	if(!g_t)
		g_t = t;
	diff = t - g_t;
	fprintf(stderr, "---------------------------------------\n");
	if(action == DISK_CONTROL_ACTION_SLEEP) {
		HDrunTime += diff;
		fprintf(stderr, "SLEEP!! SLEEP!! SLEEP!! SLEEP!! SLEEP!!\n");
		fprintf(stderr, " wakeup time       %10llu us\n\n", diff);
	}
	else {
		HDsleepTime += diff;
		fprintf(stderr, "WAKE UP!! WAKE UP!! WAKE UP!! WAKE UP!!\n");
		fprintf(stderr, " sleep time        %10llu us\n\n", diff);
	}
	
	fprintf(stderr, " total wakeup time %10llu us\n", HDrunTime);
	fprintf(stderr, " total sleep time  %10llu us\n", HDsleepTime);
	if(HDrunTime)
		fprintf(stderr, " sleep/run ratio   %10llu\n", HDsleepTime/HDrunTime);
	fprintf(stderr, "---------------------------------------\n");

	fflush(stderr);
	g_t = t;
	return RM_OK;
}

RMstatus init_playback_options(struct playback_cmdline *options)
{
	options->filename = NULL;
	options->duration = 0;
	options->chip_num = 0;
	options->noucode = FALSE;
	options->STCid = 0;
	options->STC_initial_value=0;
	options->loop_count = 1;
	options->infinite_loop = FALSE;
	options->waitexit = FALSE;
	options->send_audio = TRUE;
	options->send_video = TRUE;
	options->send_spu = TRUE;
	options->send_audio_pts = TRUE;
	options->send_video_pts = TRUE;
	options->send_spu_pts = TRUE;
	options->save_audio = FALSE;
	options->save_video = FALSE;
	options->save_spu = FALSE;
	options->savems = FALSE;

	options->speed_N = 1;
	options->speed_M = 1;

	options->f_video_data = -1;
	options->f_video_pts = -1;
	options->f_audio_data = -1;
	options->f_audio_pts = -1;
	options->f_spu_data = -1;
	options->f_spu_pts = -1;

	options->dram = 0;
	options->start_ms = 0;
	options->start_pause = FALSE;
	options->bcc_filename = NULL;
	
	options->video_byte_count = 0;
	options->audio_byte_count = 0;
	options->spu_byte_count = 0;
	
	options->stc_compensation = FALSE;
	options->stc_comp_debug = 0;
	options->require_video_audio = TRUE;
	options->audio_delay_ms = 0;
	options->video_delay_ms = 0;
	
	options->spi = FALSE;
	options->serial_spi = FALSE;

	options->dmapool_count = 0;
	options->dmapool_log2size = 0;
	
	options->prebuf_max = 0;

	options->disk_ctrl_state = DISK_CONTROL_STATE_DISABLE;
	options->disk_ctrl_low_level = 0;
	options->disk_ctrl_callback = default_disk_ctrl_callback;

	options->disk_ctrl_max_mem = 0;
	options->disk_ctrl_log2_block_size = 0;
	options->max_usable_RUA_mem = 0;

	options->send_audio_trickmode = FALSE;
	options->dontSendMPEG4pts = FALSE;
	options->fast_audio_recovery = TRUE;

	return RM_OK;
}

RMstatus parse_playback_cmdline(int argc, char **argv, int *index, struct playback_cmdline *options)
{
	RMstatus err = RM_PENDING;
	int i = *index;
	
	RMDBGLOG((ENABLE, "parsing option[%lu]='%s'\n", i, argv[i]));

	if (! strcmp(argv[i], "-m")) {
		if (argc > i+1) {
			options->chip_num = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (! strcmp(argv[i], "-L")) {
		if (argc > i+1) {
			options->loop_count = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (! strcmp(argv[i], "-l")) {
		options->infinite_loop = TRUE;
		i++;
		err = RM_OK;
	}
	else if (! strcmp(argv[i], "-waitexit")) {
		options->waitexit = TRUE;
		i++;
		err = RM_OK;
	}
	else if (! strcmp(argv[i], "-noucode")) {
		options->noucode = TRUE;
		i++;
		err = RM_OK;
	}
	else if (! strcmp(argv[i], "-STCid")) {
		if (argc > i+1) {
			options->STCid = strtol(argv[i+1], NULL, 10);
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (! strcmp(argv[i], "-STC_initial_value")) {
		if (argc > i+1) {
			options->STC_initial_value = strtol(argv[i+1], NULL, 10);
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}

 	else if (! strcmp(argv[i], "-manutest")) {
 		manutest = options->manutest = TRUE;
 		verbose_stdout = verbose_stderr = 0;
		i++;
		err = RM_OK;
	}
	else if (! strcmp(argv[i], "-data")) {
		if (argc > i+1) {
			RMuint32 n = 0;
			
			options->send_audio = FALSE;
			options->send_video = FALSE;
			options->send_spu = FALSE;
			err = RM_OK;
			for (n=0 ; n<strlen(argv[i+1]) ; n++) {
				switch (argv[i+1][n]) {
				case 'a':
					options->send_audio = TRUE;
					break;
				case 'v':
					options->send_video = TRUE;
					break;
				case 's':
					options->send_spu = TRUE;
					break;
				case 'n':
					break;
				default:
					err = RM_ERROR;
				}
			}
			i += 2;
		}
		else
			err = RM_ERROR;
	}
	else if (! strcmp(argv[i], "-ts")) {
		if (argc > i+1) {
			RMuint32 n = 0;
			
			options->send_audio_pts = FALSE;
			options->send_video_pts = FALSE;
			options->send_spu_pts = FALSE;
			err = RM_OK;
			for (n=0 ; n<strlen(argv[i+1]) ; n++) {
				switch (argv[i+1][n]) {
				case 'a':
					options->send_audio_pts = TRUE;
					break;
				case 'v':
					options->send_video_pts = TRUE;
					break;
				case 's':
					options->send_spu_pts = TRUE;
					break;
				case 'n':
					break;
				default:
					err = RM_ERROR;
				}
			}
			i += 2;
		}
		else
			err = RM_ERROR;
	}
	else if (! strcmp(argv[i], "-save")) {
		if (argc > i+1) {
			RMuint32 n = 0;

			options->savems = FALSE;			
			options->save_audio = FALSE;
			options->save_video = FALSE;
			options->save_spu = FALSE;
			err = RM_OK;
			for (n=0 ; n<strlen(argv[i+1]) ; n++) {
				switch (argv[i+1][n]) {
				case 'a':
					options->save_audio = TRUE;
					break;
				case 'v':
					options->save_video = TRUE;
					break;
				case 's':
					options->save_spu = TRUE;
					break;
				case 'n':
					break;
				default:
					err = RM_ERROR;
				}
			}
			i += 2;
		}
		else
			err = RM_ERROR;
	}
	else if (! strcmp(argv[i], "-savems")) {
		if (argc > i+1) {
			RMuint32 n = 0;
			
			options->savems = FALSE;
			options->save_audio = FALSE;
			options->save_video = FALSE;
			options->save_spu = FALSE;
			err = RM_OK;
			for (n=0 ; n<strlen(argv[i+1]) ; n++) {
				switch (argv[i+1][n]) {
				case 'a':
					options->save_audio = TRUE;
					options->savems = TRUE;
					break;
				case 'v':
					options->save_video = TRUE;
					options->savems = TRUE;
					break;
				case 's':
					options->save_spu = TRUE;
					options->savems = TRUE;
					break;
				case 'n':
					break;
				default:
					err = RM_ERROR;
				}
			}
			i += 2;
		}
		else
			err = RM_ERROR;
	}
	else if (! strcmp(argv[i], "-speed")) {
		if (argc > i+2) {
			options->speed_N = strtol(argv[i+1], NULL, 10);
			options->speed_M = strtol(argv[i+2], NULL, 10);
			i += 3;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (! strcmp(argv[i], "-dram")) {
		if (argc > i+1) {
			options->dram = strtol(argv[i+1], NULL, 10);
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (! strcmp(argv[i], "-pause")) {
		options->start_pause = TRUE;
		i ++;
		err = RM_OK;
	}
	else if (! strcmp(argv[i], "-dontSendMPEG4pts")) {
		options->dontSendMPEG4pts = TRUE;
		i ++;
		err = RM_OK;
	}
	else if (! strcmp(argv[i], "-far")) {
		RMuint32 dummy;
		
		if (argc > i+1) {
			dummy = strtol(argv[i+1], NULL, 10);
			i += 2;
			
			if (!dummy)
				options->fast_audio_recovery = FALSE;

			err = RM_OK;
		}
		else
			err = RM_ERROR;


	}
	else if (! strcmp(argv[i], "-bcc")) {
		if (argc > i+1) {
			options->bcc_filename = argv[i+1];
			i += 2;
			err = RM_OK;
		}
		else {
			err = RM_ERROR;
		}
	}
	else if (! strcmp(argv[i], "-stcdrift")) {
		options->stc_compensation = TRUE;
		i ++;
		err = RM_OK;
	}
	else if (! strcmp(argv[i], "-stcdbg")) {
		if (argc > i+1) {
			options->stc_comp_debug = strtol(argv[i+1], NULL, 10);
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (! strcmp(argv[i], "-delay")) {
		if (argc > i+1) {
			options->video_delay_ms = strtol(argv[i+1], NULL, 10);
			options->audio_delay_ms = options->video_delay_ms;
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (! strcmp(argv[i], "-dmapool")) {
		if (argc > i+2) {
			options->dmapool_count = strtol(argv[i+1], NULL, 10);
			options->dmapool_log2size = strtol(argv[i+2], NULL, 10);
			i += 3;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (! strcmp(argv[i], "-disk_ctrl")) {
		if (argc > i+1) {
			options->disk_ctrl_state = DISK_CONTROL_STATE_SLEEPING;
			options->disk_ctrl_low_level = strtol(argv[i+1], NULL, 10);
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (! strcmp(argv[i], "-prebuf")) {
		if (argc > i+1) {
			options->prebuf_max = strtol(argv[i+1], NULL, 10);
			options->prebuf_max *= 1024;
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (! strcmp(argv[i], "-sat")) {
		options->send_audio_trickmode = TRUE;
		i ++;
		err = RM_OK;
	}
	else if (! strcmp(argv[i], "-past")) {
		options->require_video_audio = FALSE;
		i ++;
		err = RM_OK;
	}

	*index = i;

	return err;
}

RMstatus open_save_files(struct playback_cmdline *options)
{
	if (options->save_video) {
		options->f_video_data = open("video.out", O_CREAT | O_TRUNC | O_WRONLY | O_LARGEFILE, 
				S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
		if (options->f_video_data == -1) {
			fprintf(stderr, "Cannot open file %s\n", "video.out");
			return RM_ERROR;
		}
		options->f_video_pts = open("videopts.out", O_CREAT | O_TRUNC | O_WRONLY | O_LARGEFILE, 
				S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
		if (options->f_video_pts == -1) {
			fprintf(stderr, "Cannot open file %s\n", "videopts.out");
			return RM_ERROR;
		}
	}
	if (options->save_audio) {
		options->f_audio_data = open("audio.out", O_CREAT | O_TRUNC | O_WRONLY | O_LARGEFILE, 
				S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
		if (options->f_audio_data == -1) {
			fprintf(stderr, "Cannot open file %s\n", "audio.out");
			return RM_ERROR;
		}
		options->f_audio_pts = open("audiopts.out", O_CREAT | O_TRUNC | O_WRONLY | O_LARGEFILE, 
				S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
		if (options->f_audio_pts == -1) {
			fprintf(stderr, "Cannot open file %s\n", "audiopts.out");
			return RM_ERROR;
		}
	}
	if (options->save_spu) {
		options->f_spu_data = open("spu.out", O_CREAT | O_TRUNC | O_WRONLY | O_LARGEFILE, 
				S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
		if (options->f_spu_data == -1) {
			fprintf(stderr, "Cannot open file %s\n", "spu.out");
			return RM_ERROR;
		}
		options->f_spu_pts = open("spupts.out", O_CREAT | O_TRUNC | O_WRONLY | O_LARGEFILE, 
				S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
		if (options->f_spu_pts == -1) {
			fprintf(stderr, "Cannot open file %s\n", "spupts.out");
			return RM_ERROR;
		}
	}

	return RM_OK;
}			

RMstatus close_save_files(struct playback_cmdline *options)
{
	if (options->f_video_data != -1) {
		close(options->f_video_data);
		options->f_video_data = -1;
	}
	if (options->f_video_pts != -1) {
		close(options->f_video_pts);
		options->f_video_pts = -1;
	}
	if (options->f_audio_data != -1) {
		close(options->f_audio_data);
		options->f_audio_data = -1;
	}
	if (options->f_audio_pts != -1) {
		close(options->f_audio_pts);
		options->f_audio_pts = -1;
	}
	if (options->f_spu_data != -1) {
		close(options->f_spu_data);
		options->f_spu_data = -1;
	}
	if (options->f_spu_pts != -1) {
		close(options->f_spu_pts);
		options->f_spu_pts = -1;
	}

	return RM_OK;
}

RMstatus dump_data_into_file(struct playback_cmdline *options, RMvdemuxDataType dataType, RMuint8 *buf, RMuint32 size, RMuint64 PTS, RMbool PTSValid, RMuint32 first_access_unit_pointer)
{
	int fd_data, fd_pts;
	RMuint32 *byte_count;
	
	switch (dataType) {
	case RMVDEMUX_VIDEO:
		if (! options->save_video) 
			return RM_OK;
		
		fd_data = options->f_video_data;
		fd_pts = options->f_video_pts;
		byte_count = &(options->video_byte_count);
		break;
	case RMVDEMUX_AUDIO:
		if (! options->save_audio) 
			return RM_OK;
		
		fd_data = options->f_audio_data;
		fd_pts = options->f_audio_pts;
		byte_count = &(options->audio_byte_count);
		break;
	case RMVDEMUX_SUBPICTURE:
		if (! options->save_spu) 
			return RM_OK;
		
		fd_data = options->f_spu_data;
		fd_pts = options->f_spu_pts;
		byte_count = &(options->spu_byte_count);
		break;
	default:
		return RM_ERROR;
	}

	RMDBGLOG((DISABLE, "dumping %lu bytes of %s\n", size, (dataType == RMVDEMUX_VIDEO) ? "video":((dataType == RMVDEMUX_AUDIO) ? "audio":"spu")));

	if (write(fd_data, buf, size) == -1)
		return RM_ERROR;
	
	fsync(fd_data);

	if (PTSValid) {
		RMuint8 temp[4];
		RMuint32 ByteCount = *byte_count;
		if ( first_access_unit_pointer )
			ByteCount += (first_access_unit_pointer - 1);
		
		temp[0] = (RMuint8)(ByteCount>>24);
		temp[1] = (RMuint8)(ByteCount>>16);
		temp[2] = (RMuint8)(ByteCount>>8);
		temp[3] = (RMuint8)(ByteCount>>0);
		if (write(fd_pts, temp, 4) == -1)
			return RM_ERROR;
		
		temp[0] = (RMuint8)(PTS>>25);
		temp[1] = (RMuint8)(PTS>>17);
		temp[2] = (RMuint8)(PTS>>9);
		temp[3] = (RMuint8)(PTS>>1);
		if (write(fd_pts, temp, 4) == -1)
			return RM_ERROR;
	}
	
	fsync(fd_pts);
	
	*byte_count += size;

	return RM_OK;
	
}

RMstatus apply_playback_options(struct dcc_context *dcc_info, struct playback_cmdline *options)
{
	RMstatus err;

	err = DCCSetMemoryManager(dcc_info->pDCC, options->dram);
	if (RMFAILED(err)){
		RMDBGLOG((ENABLE, "Error setting Dram controller : %d !\n", err));	
		return RM_ERROR;
	}

	return RM_OK;
}


RMstatus setup_disk_control_parameters(struct dcc_context *dcc_info, 
				       struct playback_cmdline *play_opt, 
				       struct audio_cmdline *audio_opt, 
				       struct video_cmdline *video_opt, 
				       struct demux_cmdline *demux_opt)
{
	RMuint32 maxRUAMem = 0;
	RMuint32 maxBufferingMem = 0;
	RMuint32 log2BlockSize = 0;

	RMuint32 videoRequiredMem = 0;
	RMuint32 videoMinXFERSize = 0;
	RMuint32 videoDecoderMem = 0;

	RMuint32 audioRequiredMem = 0;
	RMuint32 audioMinXFERSize = 0;
	RMuint32 audioDecoderMem = 0;

	RMuint32 demuxRequiredMem = 0;
	RMuint32 demuxMinXFERSize = 0;
	RMuint32 demuxMem = 0;

	RMuint32 xferFIFOPerEntrySize = 0;
	RMuint32 requiredMem = 0;

	RMstatus status;


	RMASSERT(dcc_info);
	RMASSERT(play_opt);
	
	maxRUAMem = play_opt->max_usable_RUA_mem;
	maxBufferingMem = play_opt->disk_ctrl_max_mem;
	log2BlockSize = play_opt->disk_ctrl_log2_block_size;

	RMDBGLOG((ENABLE, "setup_disk_control_parameters(maxRUAMem %lu, maxBuffering %lu, log2BlockSize %lu)\n",
		  maxRUAMem,
		  maxBufferingMem,
		  log2BlockSize));

	if (video_opt) {
		struct VideoDecoder_DRAMSize_in_type dram_in;
		struct VideoDecoder_DRAMSize_out_type dram_out;

		// compute video memory requirements

		dram_in.MPEGProfile = video_opt->MPEGProfile;
		dram_in.BitstreamFIFOSize = 0;
		dram_in.XferFIFOCount = 0;
		
		status = RUAExchangeProperty(dcc_info->pRUA, VideoDecoder, RMVideoDecoderPropertyID_DRAMSize, &dram_in, sizeof(dram_in), &dram_out, sizeof(dram_out));
		if (RMFAILED(status)) {
			RMDBGLOG((ENABLE, "Error getting property RMVideoDecoderPropertyID_DRAMSize! %s\n", RMstatusToString(status)));
			return status;
		}
		
		// cachedSize = fifo + decoder
		// uncachedSize = xfer task + xfer task queue
		
		videoDecoderMem = dram_out.CachedSize;     // fifo = 0
		
		videoMinXFERSize = dram_out.UncachedSize;
		
		dram_in.XferFIFOCount = 1;
		
		status = RUAExchangeProperty(dcc_info->pRUA, VideoDecoder, RMVideoDecoderPropertyID_DRAMSize, &dram_in, sizeof(dram_in), &dram_out, sizeof(dram_out));
		if (RMFAILED(status)) {
			RMDBGLOG((ENABLE, "Error getting property RMVideoDecoderPropertyID_DRAMSize! %s\n", RMstatusToString(status)));
			return status;
		}
		
		xferFIFOPerEntrySize = dram_out.UncachedSize - videoMinXFERSize;
		
		if (video_opt->xfer_count)
			videoRequiredMem = videoDecoderMem + video_opt->fifo_size + videoMinXFERSize + (xferFIFOPerEntrySize * video_opt->xfer_count);
		else
			videoRequiredMem = videoDecoderMem + video_opt->fifo_size;

		RMDBGLOG((ENABLE, "video requires %lu bytes (decoder %lu fifo %lu xfer %lu xferCount %lu)\n", 
			  videoRequiredMem,
			  videoDecoderMem,
			  video_opt->fifo_size,
			  videoMinXFERSize + (xferFIFOPerEntrySize * video_opt->xfer_count),
			  video_opt->xfer_count));

	}

	if (audio_opt) {
		struct AudioDecoder_DRAMSize_in_type dram_in;
		struct AudioDecoder_DRAMSize_out_type dram_out;

		// compute audio memory requirements

		/* we need 8 x 0x300(0x180) for Ac3, 8 x 0xF00 for WMA, 8 x 0x400 for WMAPRO => allocate maximum=8 x 0xF00 */
		dram_in.MaxChannelOutCount = 8;
		dram_in.PCMLineCount = 0xf00;
		dram_in.BitstreamFIFOSize = 0;
		dram_in.XferFIFOCount = 0;

		status = RUAExchangeProperty(dcc_info->pRUA, AudioDecoder, RMAudioDecoderPropertyID_DRAMSize, &dram_in, sizeof(dram_in), &dram_out, sizeof(dram_out));
		if (RMFAILED(status)) {
			RMDBGLOG((ENABLE, "Error getting property RMAudioDecoderPropertyID_DRAMSize! %s\n", RMstatusToString(status)));
			return status;
		}
		
		// cachedSize = fifo + decoder
		// uncachedSize = xfer task + xfer task queue
		
		audioDecoderMem = dram_out.CachedSize;     // fifo = 0
		
		audioMinXFERSize = dram_out.UncachedSize;
		
		dram_in.XferFIFOCount = 1;
		
		status = RUAExchangeProperty(dcc_info->pRUA, AudioDecoder, RMAudioDecoderPropertyID_DRAMSize, &dram_in, sizeof(dram_in), &dram_out, sizeof(dram_out));
		if (RMFAILED(status)) {
			RMDBGLOG((ENABLE, "Error getting property RMAudioDecoderPropertyID_DRAMSize! %s\n", RMstatusToString(status)));
			return status;
		}
		
		xferFIFOPerEntrySize = dram_out.UncachedSize - audioMinXFERSize;
		
		if (audio_opt->xfer_count)
			audioRequiredMem = audioDecoderMem + audio_opt->fifo_size + audioMinXFERSize + (xferFIFOPerEntrySize * audio_opt->xfer_count);
		else
			audioRequiredMem = audioDecoderMem + audio_opt->fifo_size;

		RMDBGLOG((ENABLE, "audio requires %lu bytes (decoder %lu fifo %lu xfer %lu xferCount %lu)\n", 
			  audioRequiredMem,
			  audioDecoderMem,
			  audio_opt->fifo_size,
			  audioMinXFERSize + (xferFIFOPerEntrySize * audio_opt->xfer_count),
			  audio_opt->xfer_count));


	}

	if (demux_opt) {
		struct DemuxTask_DRAMSizeX_in_type dram_in;
		struct DemuxTask_DRAMSizeX_out_type dram_out;

		// compute hwdemux memory requirements

		dram_in.ProtectedFlags = 0;
		dram_in.BitstreamFIFOSize = 0;
		dram_in.XferFIFOCount = 0;
		dram_in.InbandFIFOCount = 0;
		dram_in.XTaskModuleId = 0;
		dram_in.XTaskInbandFIFOCount = 0;

		status = RUAExchangeProperty(dcc_info->pRUA, DemuxTask, RMDemuxTaskPropertyID_DRAMSizeX, &dram_in, sizeof(dram_in), &dram_out, sizeof(dram_out));
		if (RMFAILED(status)) {
			RMDBGLOG((ENABLE, "Error getting property RMDemuxTaskPropertyID_DRAMSize! %s\n", RMstatusToString(status)));
			return status;
		}

		// cachedSize = fifo
		// uncachedSize = xfer task + xfer task queue
		
		demuxMem = dram_out.BitstreamProtectedSize;     // fifo = 0
		demuxMinXFERSize = dram_out.UnprotectedSize;
		
		dram_in.XferFIFOCount = 1;
		
		status = RUAExchangeProperty(dcc_info->pRUA, DemuxTask, RMDemuxTaskPropertyID_DRAMSizeX, &dram_in, sizeof(dram_in), &dram_out, sizeof(dram_out));
		if (RMFAILED(status)) {
			RMDBGLOG((ENABLE, "Error getting property RMDemuxTaskPropertyID_DRAMSize! %s\n", RMstatusToString(status)));
			return status;
		}
		
		xferFIFOPerEntrySize = dram_out.UnprotectedSize - demuxMinXFERSize;

		if (demux_opt->xfer_count)
			demuxRequiredMem = demuxMem + demux_opt->fifo_size + demuxMinXFERSize + (xferFIFOPerEntrySize * demux_opt->xfer_count);
		else
			demuxRequiredMem = demuxMem + demux_opt->fifo_size;

		RMDBGLOG((ENABLE, "demux requires %lu bytes (demux %lu fifo %lu xfer %lu xferCount %lu)\n", 
			  demuxRequiredMem,
			  demuxMem,
			  demux_opt->fifo_size,
			  demuxMinXFERSize + (xferFIFOPerEntrySize * demux_opt->xfer_count),
			  demux_opt->xfer_count));


	}



	requiredMem = videoRequiredMem + audioRequiredMem + demuxRequiredMem;

	RMDBGLOG((ENABLE, ">> required RUA mem %lu\n", requiredMem));


	if (requiredMem > maxRUAMem) {
		RMint32 sizeLeft = (RMint32)maxRUAMem;
		RMuint32 adjBufferCount = 0;
		RMuint32 adjXFERCount = 0;

		// we can only adjust the number of xfer transfers and the number of dmaBuffers
		// we cannot adjust fifo sizes because they are already minimal for all situations.

		RMDBGLOG((ENABLE, ">> not enough memory, adjust params\n"));

		if (video_opt)
			sizeLeft -= videoDecoderMem + video_opt->fifo_size + videoMinXFERSize;
		if (audio_opt)
			sizeLeft -= audioDecoderMem + audio_opt->fifo_size + audioMinXFERSize;

		if (demux_opt) {
			sizeLeft -= demuxMem + demux_opt->fifo_size + demuxMinXFERSize;

			if (sizeLeft <= 0) {
				fprintf(stderr, "not enough RUA memory for playback, available %lu, required %lu\n", maxRUAMem, requiredMem);
				return RM_ERROR;
			}

			// there's no A/V xfer fifos
			sizeLeft += videoMinXFERSize + audioMinXFERSize;

			adjXFERCount = sizeLeft / xferFIFOPerEntrySize;

			if (log2BlockSize > 15) {
				RMuint32 fragments = (1 << (log2BlockSize - 15));
				adjBufferCount = adjXFERCount / (fragments * 2);
			}
			else 
				adjBufferCount = adjXFERCount / 2;
		      
		}
		else {

			if (sizeLeft <= 0) {
				fprintf(stderr, "not enough RUA memory for playback, available %lu, required %lu\n", maxRUAMem, requiredMem);
				return RM_ERROR;
			}

			sizeLeft /= 2;

			adjXFERCount = sizeLeft / xferFIFOPerEntrySize;

			adjBufferCount = (adjXFERCount * 512) >> log2BlockSize;

		}

		fprintf(stderr, "\nprevious params:\nbufferCount %lu log2bufferSize %lu bufferingMemory %lu\n",
			play_opt->dmapool_count,
			play_opt->dmapool_log2size,
			(RMuint32)play_opt->dmapool_count << play_opt->dmapool_log2size);

		if (video_opt)
			fprintf(stderr, "video: fifoSize %lu xferCount %lu\n", video_opt->fifo_size, video_opt->xfer_count);
		if (audio_opt)
			fprintf(stderr, "audio: fifoSize %lu xferCount %lu\n", audio_opt->fifo_size, audio_opt->xfer_count);
		if (demux_opt)
			fprintf(stderr, "demux: fifoSize %lu xferCount %lu\n", demux_opt->fifo_size, demux_opt->xfer_count);

		fprintf(stderr, "\n\n");

		play_opt->dmapool_count = adjBufferCount;

		if (video_opt)
			video_opt->xfer_count = adjXFERCount;
		if (audio_opt)
			audio_opt->xfer_count = adjXFERCount;
		if (demux_opt)
			demux_opt->xfer_count = adjXFERCount;
		

		fprintf(stderr, "\nnew params:\nbufferCount %lu log2bufferSize %lu bufferingMemory %lu\n",
			play_opt->dmapool_count,
			play_opt->dmapool_log2size,
			(RMuint32)play_opt->dmapool_count << play_opt->dmapool_log2size);

		if (video_opt)
			fprintf(stderr, "video: fifoSize %lu xferCount %lu\n", video_opt->fifo_size, video_opt->xfer_count);
		if (audio_opt)
			fprintf(stderr, "audio: fifoSize %lu xferCount %lu\n", audio_opt->fifo_size, audio_opt->xfer_count);
		if (demux_opt)
			fprintf(stderr, "demux: fifoSize %lu xferCount %lu\n", demux_opt->fifo_size, demux_opt->xfer_count);

		fprintf(stderr, "\n\n");

	}

		


	return RM_OK;

}
