/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   common.h
  @brief  

  @author Julien Soulier
  @date   2004-04-24
*/

#ifndef __COMMON_H__
#define __COMMON_H__

#define RM_UNKNOWN 0

#define RM_PLAYING 1
#define RM_PAUSED  2
#define RM_STOPPED 3

#define RM_PLAY  4
#define RM_PAUSE 5
#define RM_STOP  6
#define RM_STOP_SEEK_ZERO  7

#define RM_QUIT  8

#define RM_PLAYING_TRICKMODE 9   // no audio

#define RM_CHANNEL_CHANGE	10
#define RM_PAT_INFO		11
#define RM_PMT_CHANGE		12
#define RM_AUDIO_STREAM_CHANGE	13
#define RM_VIDEO_STREAM_CHANGE	14

#define RM_SEEK                 15
#define RM_DUALMODE_CHANGE      16

#define RM_ROTATE_PICTURE       17

#define RM_MANU_QUIT_OK		18

#define RM_NONE                 19
#define RM_SPEED                20
#define RM_SLOW_FWD             21
#define RM_FAST_FWD             22
#define RM_IFWD                 23
#define RM_IRWD                 24
#define RM_NEXTPIC              25

#define RM_DECODER_CHANGE       26

#define RM_NERO_NEXT_CHAPTER 27
#define RM_NERO_PREV_CHAPTER 28
#define RM_NERO_SWITCH_SUBTITLE 29

#define RM_REWIND 30

#define RM_NO_TRICKMODE		0
#define RM_TRICKMODE_FAST_FWD	1
#define RM_TRICKMODE_FAST_RWD	2
#define RM_TRICKMODE_SLOW_FWD	3
#define RM_TRICKMODE_SLOW_RWD	4
#define RM_TRICKMODE_NEXT_PIC	5
#define RM_TRICKMODE_FWD_IFRAME	6
#define RM_TRICKMODE_RWD_IFRAME	7

#define SET_KEY_PLAYBACK (1<<0)
#define SET_KEY_DISPLAY  (1<<1)
#define SET_KEY_AUDIO    (1<<2)
#define SET_KEY_SPI      (1<<3)
#define SET_KEY_DEBUG    (1<<4)

#define TIMEOUT_1MIN  60000000
#define TIMEOUT_1SEC   1000000
#define TIMEOUT_100MS   100000
#define TIMEOUT_10MS     10000
#define TIMEOUT_1MS       1000
#define NO_TIMEOUT           0

#define DISK_CONTROL_MAX_WAKEUP_COUNT 50   // in polling iterations of TIMEOUT_100MS

#define EOS_BIT_FIELD_VIDEO (1<<0)
#define EOS_BIT_FIELD_AUDIO (1<<1)
#define EOS_BIT_FIELD_DEMUX (1<<2)

#include "../dcc/include/dcc.h"
#include "../rmscc/include/rmscc.h"
#include "../rmrtk/include/rmrtk.h"

#include "dvi_hdmi_update.h"
#include "get_key.h"
#include "rminputstream.h"
#include "cmdline_options.h"
#include "bitmaps.h"

#include "rmpfs.h"


/* 
 * display_context is used by the sample apps when not used through mono 
 * otherwise libsamples is not allowed to modify the display
 */
struct display_context{
	RMuint8 contrast; 
	RMuint8 saturation;
	RMint8  brightness;
	RMint8  hue;
	RMuint32 osd_scaler[2];
	RMbool osd_enable[2];
	RMbool video_enable;
	struct EMhwlibDisplayWindow out_window;
	struct EMhwlibDisplayWindow osd_window[2];
	struct EMhwlibDisplayWindow *active_window;
	struct EMhwlibNonLinearScalingMode nonlinearmode;
	struct EMhwlibBlackStripMode blackstrip;
	struct EMhwlibCutStripMode cutstrip;
};

struct dh_context{
	struct DH_control *pDH;
	struct DH_HDMI_state HDMIState;
	enum DH_device_state dvi_hdmi_state;  // obsolete
	enum DH_connection dvi_hdmi_cable;  // obsolete
	enum DH_vendor_parts dvi_hdmi_part;
	RMuint8 *pSRM;
	struct CEA861BDataBlockCollection *pDBC;
	RMuint32 nDBC;
	RMuint32 nDH;
	RMuint32 DH_sel;
	struct DH_control *pDH_array[5];
};

#define RM_PSM_ENABLE_PLAY 1
#define RM_PSM_ENABLE_STOP (1<<1)
#define RM_PSM_ENABLE_PAUSE (1<<2)
#define RM_PSM_ENABLE_NEXTPIC (1<<3)
#define RM_PSM_ENABLE_SPEED (1<<4)
#define RM_PSM_ENABLE_FASTER (1<<5)
#define RM_PSM_ENABLE_SLOWER (1<<6)
#define RM_PSM_ENABLE_IFWD (1<<7)
#define RM_PSM_ENABLE_IRWD (1<<8)

#define RM_PSM_ENABLE_SEEK (1<<9)
#define RM_PSM_ENABLE_SWITCHAUDIO (1<<10)
#define RM_PSM_ENABLE_SWITCHVIDEO (1<<11)
#define RM_PSM_ENABLE_SWITCHSUBTITLE (1<<12)
#define RM_PSM_ENABLE_SWITCHSUBPICTURE (1<<13)
#define RM_PSM_ENABLE_CHAPTERS (1<<14)

#define RM_PSM_USE_MUTE_DURING_TRICKMODES (1<<15)

#define RM_PSM_ENABLE_REWIND (1<<16)

#define RM_PSM_STC_STOPPED 1
#define RM_PSM_AUDIO_STOPPED (1<<1)
#define RM_PSM_VIDEO_STOPPED (1<<2)
#define RM_PSM_DEMUX_STOPPED (1<<3)

#define RM_PSM_FIRST_PTS 1
#define RM_PSM_RESYNC_TIMER (1<<1)
#define RM_PSM_DEMUX_NORMAL (1<<2) // resume from iframe trickmode
#define RM_PSM_DEMUX_IFRAME (1<<3) // init iframe trickmode
#define RM_PSM_FLUSH_VIDEO (1<<4) 
#define RM_PSM_NORMAL_PLAY (1<<5) // resume from trickmode



enum RM_PSM_State {
	RM_PSM_Playing = 0,
	RM_PSM_Stopped,
	RM_PSM_Paused,
	RM_PSM_NextPic,
	RM_PSM_Slow,
	RM_PSM_Fast,
	RM_PSM_IForward,
	RM_PSM_IRewind,
	RM_PSM_Prebuffering,
	RM_PSM_IPaused,
	RM_PSM_INextPic,
	RM_PSM_Rewind
};

struct RM_PSM_Actions {
	RMuint32 performedActions;
	RMuint32 toDoActions;
	RMuint32 cmd;
	RMbool cmdProcessed;
	RMbool appSpecific;
	RMuint32 asyncCmd;
	RMbool asyncCmdPending;
};

struct RM_PSM_Context {
	RMint32 validPSMContexts;
	RMint32 currentActivePSMContext;
	RMuint32 selectedPSMContextMask;
	RMuint32 keyflags;
};

struct dcc_context {
	RMuint32 chip_num;
	struct DCC *pDCC;
	struct RUA *pRUA;
	struct DCCVideoSource *pVideoSource;
	struct DCCAudioSource *pAudioSource;

	struct DCCMultipleAudioSource *pMultipleAudioSource;

	struct DCCVideoSource *pOSDSource[2];
	struct DCCSTCSource *pStcSource;
	enum DCCRoute route;
	RMuint32 SurfaceID;
	RMuint32 video_timer;
	RMuint32 audio_timer;
	RMuint32 video_decoder;
	RMuint32 audio_decoder;
	RMuint32 audio_engine;
	RMuint32 spu_decoder;
	RMuint32 state;
	RMuint32 trickmode_id;

	/* next member is used for DemuxTask module */
	struct DCCDemuxTask *pDemuxTask;
	RMuint32 demux_task;

	/* next four members are used for backward compatibility for Demux and DemuxProgram modules */
	struct DCCDemuxSource *pDemuxSource;
	RMuint32 demux;
	RMuint32 demuxProgram0;
	RMuint32 demuxProgram1;

	RMint32 volume_index;
	RMbool mute;
	RMbool seek_supported;
	RMbool iframe_supported;
	RMbool trick_supported;
	RMuint32 seek_time;
	RMint32 selectAudioStream;

	enum EMhwlibScalerFieldSelection field_selection;
	
	struct display_context *disp_info;
	
	/* commands that should be treated by the playback FSM */
	RMuint32 RM_PSM_commands;
	/* current playback state */
	enum RM_PSM_State FSMstate;
	/* previous FSM state */
	enum RM_PSM_State previousFSMState;

	RMuint32 ccfifo_in_id;
	RMuint32 ccfifo_in_addr;
	RMuint32 ccfifo_out_id;
	RMuint32 ccfifo_out_addr;
	struct DCCVideoSource *pCCOSDSource;
	RMscc scc;
	RMTrtk rtk;
	
	/* Check for HDCP unplugged devices */
	struct dh_context *dh_info;
	RMuint64 hdcp_last_check;
	
	RMuint32 ttx_fifo_id;  // ttx fifo's module id
	struct RMttx * ttx_sw_decoder; // a pointer

	RMbool disable_stc;
};


#define NERO_MAX_CHAPTERS 32

enum RMStreamInfoType {
	RMStreamInfoIsType_Unknown = 0,
	RMStreamInfoIsType_MPEG4,
	RMStreamInfoIsType_AVI
};


typedef struct RMNeroChapterEntry {
	RMascii *name;
	RMuint64 time_ms;
} RMNeroChapterEntry;

typedef struct RMMP4StreamInfo {
	RMuint32 videoStreams;
	RMuint32 audioStreams;
	RMuint32 spuStreams;
	RMuint32 chapters;
	RMbool isPlayable;
	RMbool isNero;
	struct RMNeroChapterEntry chapterList[NERO_MAX_CHAPTERS];
	RMuint32 duration; // in seconds
} RMMP4StreamInfo;

typedef struct RMAVIStreamInfo {
	RMuint32 videoStreams;

	RMuint32 audioStreams;

	RMbool trickModesAllowed;
	RMuint32 duration; // in seconds
} RMAVIStreamInfo;

typedef struct RMFileStreamInfo {
        enum RMStreamInfoType streamType;
	union {
		struct RMMP4StreamInfo mp4Info;
		struct RMAVIStreamInfo aviInfo;
	} data;
} RMFileStreamInfo;



#ifdef WITH_MONO
#include "main_apps.h"
#endif


RM_EXTERN_C_BLOCKSTART

RMuint64 get_ustime(void);
RMstatus process_key(struct dcc_context *dcc_info, RMuint32 *cmd, RMuint32 keyflags);
RMstatus handle_key(struct dcc_context *dcc_info, RMuint32 *cmd, RMuint32 keyflags, RMascii key);

// ----
void muteAudio(struct dcc_context *dcc_info);
void unMuteAudio(struct dcc_context *dcc_info);
void routeAudioTimerToDisplayPTS(struct dcc_context *dcc_info, RMbool enable);

enum RM_PSM_State RM_PSM_GetState(struct RM_PSM_Context *PSMcontext, struct dcc_context *dcc_info_array[]);
void RM_PSM_SetState(struct RM_PSM_Context *PSMcontext, struct dcc_context *dcc_info_array[], enum RM_PSM_State newstate);
RMstatus process_command(struct RM_PSM_Context *PSMcontext, struct dcc_context *dcc_info_array[], struct RM_PSM_Actions *actions);
RMstatus WaitForEOSWithCommand(struct RM_PSM_Context *PSMcontext, struct dcc_context *dcc_info_array[], struct RM_PSM_Actions *pActions, RMuint32 eos_bit_field);
// ----

void display_key_usage(RMuint32 keyflags);

void set_default_out_window(struct EMhwlibDisplayWindow *window);
void show_display_options(void);
RMstatus GetTVStandard(RMascii *StandardName, enum EMhwlibTVStandard *Standard);
RMstatus GetTVStandardName(enum EMhwlibTVStandard Standard, RMascii **StandardName);
RMstatus PrintTVStandardNames(void);
RMstatus apply_hdcp(struct dcc_context *dcc_info, struct display_cmdline *options);
RMstatus update_hdmi(struct dcc_context *dcc_info, struct display_cmdline *disp_opt, struct audio_cmdline *audio_opt);
RMstatus set_component_videomode_from_edmode(struct dcc_context *dcc_info, struct display_cmdline *options);
RMstatus set_videomode_from_EDID(struct dcc_context *dcc_info, struct display_cmdline *options);
RMstatus load_edid_block_from_file(RMfile fd, RMuint32 *mode, RMuint8 *data);
RMstatus upload_edid_file(struct display_cmdline *options);
RMstatus download_edid_file(struct display_cmdline *options);
RMstatus force_edid_file(struct display_cmdline *options);
RMstatus parse_video_mode_file(RMascii *filename, struct EMhwlibTVFormatDigital *pDig, struct EMhwlibTVFormatAnalog *pAna);
RMstatus apply_videomode_from_vmf_file(struct dcc_context *dcc_info, RMascii *vidmode_filename);
RMstatus display_edid(struct display_cmdline *options);
RMstatus apply_display_options(struct dcc_context *dcc_info, struct display_cmdline *options);
RMstatus clear_display_options(struct dcc_context *dcc_info, struct display_cmdline *options);
RMstatus clear_video_options(struct dcc_context *dcc_info, struct video_cmdline *options);

RMstatus set_display_out_window(struct dcc_context *dcc_info);

RMstatus apply_osd_picture(struct dcc_context *dcc_info, struct osd_picture_info *osd, 
			   struct DCCOSDProfile *profile, struct DCCVideoSource **osd_source);

RMstatus apply_osd_pictureX(struct dcc_context *dcc_info, 
			    struct osd_picture_info *osd, 	
			    struct DCCOSDProfile *osd_profile, 
			    struct DCCVideoSource **osd_source,
			    struct display_cmdline *options);

RMstatus apply_genlock(struct RUA *pRUA, struct display_cmdline *disp_opt);
RMstatus setup_dummy_capture(struct RUA *pRUA, struct DCC *pDCC, struct display_cmdline *disp_opt, RMuint32 TimerNumber);
RMstatus close_dummy_capture(struct display_cmdline *disp_opt);

RMstatus set_scaler_source_zoom(
	struct RUA *pRUA, 
	RMuint32 ScalerModuleID, 
	RMuint32 x, RMuint32 y, RMuint32 w, RMuint32 h);
RMascii *get_afd_name(enum EMhwlibActiveFormat ActiveFormat);
RMstatus apply_active_format_abs(
	struct EMhwlibActiveFormatDescription content_afd, 
	struct EMhwlibAspectRatio output_ar, 
	RMbool output_variable_ar, // TRUE: output can be both, 16:9 and 4:3
	struct EMhwlibActiveFormatDescription *output_afd, 
	RMuint32 *x, RMuint32 *y, RMuint32 *w, RMuint32 *h, 
	RMbool *update_zoom);
RMstatus apply_active_format_rel(
	struct EMhwlibActiveFormatDescription content_afd, 
	struct EMhwlibAspectRatio output_ar, 
	RMbool output_variable_ar, // TRUE: output can be both, 16:9 and 4:3
	struct EMhwlibActiveFormatDescription *output_afd, 
	RMuint32 *x, RMuint32 *y, RMuint32 *w, RMuint32 *h, 
	RMbool *update_zoom);
RMstatus get_scaler_output_aspect_ratio(struct RUA *pRUA, 
	RMuint32 ScalerModuleID,  // scaler module ID
	RMuint32 MixerModuleID,  // module ID of the scaler's mixer
	struct EMhwlibAspectRatio *scaler_ar, 
	RMbool *variable_output);

/** Apply active format and frame aspect ratio to a scaler */
/* If output_afd is used, and different from previuous one, apply to output with apply_active_format_output() */
RMstatus apply_active_format_input(struct RUA *pRUA, 
	RMuint32 ScalerModuleID,  // scaler module ID of the content surface
	RMuint32 MixerModuleID,  // module ID of the scaler's mixer
	struct EMhwlibActiveFormatDescription content_afd,  // active format description of the content and picture aspect ratio of the input frame
	RMbool zoom_abs,  // TRUE: sets scaler input window with absolute pixel values, current input window needs to be set to full frame and absolute; FALSE: sets scaler input window with relative values, uses complete input frame
	RMuint32 *x_abs,  // for zoom_abs=TRUE, these full frame window values will be used, unless they are NULL.
	RMuint32 *y_abs,  // if not NULL, these values will be filled with the new zoom window for set_scaler_source_zoom()
	RMuint32 *w_abs, 
	RMuint32 *h_abs, 
	RMbool output_variable_ar,  // TRUE: output is capable of both, 4:3 and 16:9 (e.g. 480i, 480p); FALSE: output only supports current aspect ratio
	struct EMhwlibActiveFormatDescription *output_afd);  // new active format and frame aspect ratio for the output (needs to be applied to output by caller)

/** Apply active format and frame aspect ratio to output (as returned by apply_active_format_input()) */
RMstatus apply_active_format_output_module(struct RUA *pRUA, 
	RMuint32 OutputModuleID, 
	struct DH_control *pDH, 
	struct EMhwlibActiveFormatDescription output_afd);

/** Apply active format and frame aspect ratio to all outputs of a mixer (as returned by apply_active_format_input()) */
RMstatus apply_active_format_output(struct RUA *pRUA, 
	RMuint32 MixerModuleID,  // module ID of the output's mixer
	struct DH_control *pDH,  // current HDMI output handle, or NULL
	struct EMhwlibActiveFormatDescription output_afd);  // active format and frame aspect ratio for the output

RMstatus get_output_variable_aspect_ratio(
	enum EMhwlibTVStandard TVStandard, 
	RMbool *output_variable_ar);

RMstatus update_output_afd_settings(
	struct dcc_context *dcc_info, 
	struct display_cmdline *disp_opt, 
	RMbool *pUpdate);

RMstatus apply_active_format(
	struct RUA *pRUA, 
	struct display_cmdline *disp_opt, 
	struct EMhwlibActiveFormatDescription ContentAFD,  // active format description of the content and picture aspect ratio of the input frame
	RMuint32 ScalerModuleID);  // scaler module ID of the content surface


RMstatus dump_dvi_init(struct dcc_context *dcc_info, struct display_cmdline *options);


//RMstatus parse_wmapro_intermediate(int fd, struct audio_cmdline *options);

void show_capture_options(void);
void reduce_aspect_ratio(RMuint32 *X, RMuint32 *Y, RMuint32 boundary);
void get_aspect_ratio_from_video_mode(
	enum EMhwlibTVStandard TVStandard,  
	struct EMhwlibTVFormatDigital *pTVFormat,  // optional, can be NULL
	RMbool wide,  // ambiguous modes (SDTV,EDTV): FALSE=4:3, TRUE=16:9 anamorphic
	RMuint32 *asp_x, 
	RMuint32 *asp_y);
RMstatus setup_capture(
	struct dcc_context *dcc_info, 
	struct DCCVideoSource **ppVideoSource, 
	struct capture_cmdline *options, 
	RMuint16 **ppVBIData, 
	struct ReceiveObject_type **ppR, 
	struct RUABufferPool **ppDmaReceive, 
	RMuint32 TimerNumber, 
	RMbool use_gpio, 
	RMbool inv_fid);
RMstatus apply_capture_options(
	struct dcc_context *dcc_info, 
	struct DCCVideoSource **ppVideoSource, 
	struct capture_cmdline *options, 
	RMuint16 **ppVBIData, 
	struct ReceiveObject_type **ppR, 
	struct RUABufferPool **ppDmaReceive, 
	RMuint32 TimerNumber, 
	RMbool use_gpio, 
	RMbool inv_fid);
RMstatus guess_capture_format(
	struct dcc_context *dcc_info, 
	struct capture_cmdline *options);
RMstatus close_capture(
	struct dcc_context *dcc_info, 
	struct DCCVideoSource **ppVideoSource, 
	struct capture_cmdline *capture_opt, 
	RMuint16 **ppVBIData, 
	struct ReceiveObject_type **ppR, 
	struct RUABufferPool **ppDmaReceive);

void show_video_options(void);
RMstatus apply_video_decoder_options(struct dcc_context *dcc_info, struct video_cmdline *options);

void show_audio_options(void);

RMstatus apply_audio_engine_options_with_handle(struct dcc_context *dcc_info, struct audio_cmdline *options, struct DCCAudioSourceHandle *pSingleAudioSourceHandle);
RMstatus apply_audio_engine_options(struct dcc_context *dcc_info, struct audio_cmdline *options);

RMstatus apply_audio_decoder_options_with_handle(struct dcc_context *dcc_info, struct audio_cmdline *options, struct DCCAudioSourceHandle *pSingleAudioSourceHandle);
RMstatus apply_audio_decoder_options(struct dcc_context *dcc_info, struct audio_cmdline *options);

RMstatus apply_audio_decoder_options_onthefly_with_handle(struct dcc_context *dcc_info, struct audio_cmdline *options, struct DCCAudioSourceHandle *pSingleAudioSourceHandle);
RMstatus apply_audio_decoder_options_onthefly(struct dcc_context *dcc_info, struct audio_cmdline *options);
/** 
	@param dcc_info
	@param options      The audio options
	@param AudioCP      TRUE: set copy protection bit in SPDIF and HDMI IEC 60958-3 header (Bit 2, 'C')
*/
RMstatus set_audio_cp_bit(struct dcc_context *dcc_info, struct audio_cmdline *options, RMbool AudioCP, RMuint32 engine);


RMstatus set_audio_channel_status(struct dcc_context *dcc_info, struct AudioEngine_ChannelStatus_type cs, RMuint32 engine);

/** 
	@param dcc_info
	@param options      The audio options
	@param NumChannel   Number of audio channels (2..8: force channel number, 0: detect from options->OutputChannels)
	@param LowFreqChannel_3  TRUE if low frequency audio is on channel 3
	@param FrontCenterChannel_4  TRUE if Front Center audio is on channel 4
	@param FrontLeftRightCenterChannels_7_8  If LeftCenter/RightCenter channels exist, are they in the Front(TRUE) or Rear(FALSE)?
	See EIA/CEA-861-B Table 22 for possible channel assignments
*/
RMstatus apply_dvi_hdmi_audio_options(
	struct dcc_context *dcc_info, 
	struct audio_cmdline *options, 
	RMuint32 NumChannel, 
	RMbool LowFreqChannel_3, 
	RMbool FrontCenterChannel_4, 
	RMbool FrontLeftRightCenterChannels_7_8);

RMstatus update_hdmi_audio(struct dcc_context *dcc_info, struct audio_cmdline *audio_opt);

void show_playback_options(void);


RMstatus setup_disk_control_parameters(struct dcc_context *dcc_info, 
				       struct playback_cmdline *play_opt, 
				       struct audio_cmdline *audio_opt, 
				       struct video_cmdline *video_opt, 
				       struct demux_cmdline *demux_opt);

RMstatus refresh_soft_cc(struct dcc_context *dcc_info);
RMstatus video_profile_to_codec(enum MPEG_Profile profile, enum EMhwlibVideoCodec *pvcodec, RMuint32 *pprofile, RMuint32 *plevel,
	RMuint32 *pextra_buffers, RMuint32 *pwidth, RMuint32 *pheight);
RMstatus open_save_files(struct playback_cmdline *options);
RMstatus close_save_files(struct playback_cmdline *options);
RMstatus dump_data_into_file(struct playback_cmdline *options, RMvdemuxDataType dataType, RMuint8 *buf, RMuint32 size, RMuint64 PTS, RMbool PTSValid, RMuint32 first_access_unit_pointer);
RMstatus apply_playback_options(struct dcc_context *dcc_info, struct playback_cmdline *options);
RMstatus WaitForRuaEvents(struct dcc_context *dcc_info, struct RUAEvent** ppEventsIn, RMuint32* pnEvents, RMuint32 timeout);
RMstatus CommonWaitForEOS(struct dcc_context *dcc_info, RMuint32 *pcmd, RMuint32 eos_bit_field, RMuint32 key_flags);

/* RMstatus load_osd_file(RMascii *filename, struct dcc_context *dcc_info, struct DCCOSDProfile *osd_profile, RMuint32 *ppLut, struct RMBitmapFileOptions *opts, struct EMhwlibDisplayWindow *window); */

RMstatus dumpBitmapInfo(struct dcc_context *dcc_info, struct DCCVideoSource *pOSDSource, struct DCCOSDProfile *osd_profile, RMuint32 lutAddr, RMascii *dir_name);

extern RMstatus get_profile_profile(const char* prof, enum MPEG_Profile* profile);
extern RMstatus get_profile_codec(const char* prof, enum VideoDecoder_Codec_type* type);




#define	SEQUENCE_START_CODE		0x01000163
#define	FRAME_START_CODE		0xB800ABCD
#define TILE_START_CODE			0xAA009AA9

typedef struct _tagSeqHeader {
	RMuint32	nChannels;
	RMuint32	nSamplesPerSec;
	RMuint32	nSampleFrame;
	RMuint32	nValidBitsPerSample;
	RMuint32	nChannelMask;
	RMuint32	encoder_options;
} SEQUENCE_HEADER;

/*----------------------------------------------------------------------------*/

#ifndef	LITTLE_ENDIAN
#define	SWAP_DWORD(x)			((((x) & 0xff000000) >> 24) | \
								 (((x) & 0x00ff0000) >> 8)	| \
								 (((x) & 0x0000ff00) << 8)  | \
								 (((x) & 0x000000ff) << 24))
#else
#define SWAP_DWORD(x)			((x))
#endif

/*----------------------------------------------------------------------------*/

RM_EXTERN_C_BLOCKEND

#endif // __COMMON_H__
