
/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   set_outports.c
  @brief  

  Sample application to configure the display outports.

  @author Oriol Prieto Gasco
  @date   2006-04-15
*/


#include "sample_os.h"

#define ALLOW_OS_CODE 1
#include "common.h"
#include "outports_options.h"

#include "../dcc/include/dcc.h"
int main(int argc, char *argv[])
{
	RMstatus err;
	struct DCC *pDCC;
	struct RUA *pRUA;
	struct outports_options options;
	RMuint32 i = 1;

	err = init_outports_options(&options);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error at init_outports_options %d\n", err);
		return -1;
	}
	err = parse_outports_options((RMuint32)argc, (RMascii **)argv, &i, &options);
	if (RMFAILED(err)) {
		fprintf(stderr, 
			"\nERROR %s did not configure the display: invalid options\n"
			"Offending option: %s\n"
			"Try %s -help for a description of valid options\n"
			, argv[0], argv[i], argv[0]);
		return -1;
	}

	err = RUACreateInstance(&pRUA, options.global.chip);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error creating RUA instance! %d\n", err);
		return -1;
	}

	err = DCCOpen(pRUA, &pDCC);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error Opening DCC! %d\n", err);
		RUADestroyInstance(pRUA);
		return -1;
	}

	err = apply_outports_options(pDCC, &options);
	if (RMFAILED(err)) {
		fprintf(stderr, 
			"\nERROR %s did not configure the display: unsupported configuration\n", argv[0]);
		DCCClose(pDCC);
		RUADestroyInstance(pRUA);
		return -1;
	}

	err = DCCClose(pDCC);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot close DCC %d\n", err);
		RUADestroyInstance(pRUA);
		return -1;
	}
	err = RUADestroyInstance(pRUA);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot destroy RUA instance %d\n", err);
		return -1;
	}

	return 0;
}
