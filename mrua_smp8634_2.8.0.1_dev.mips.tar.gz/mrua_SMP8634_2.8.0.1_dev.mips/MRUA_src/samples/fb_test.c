/*****************************************
 Copyright © 2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define ALLOW_OS_CODE 1
#include "../rua/include/rua.h"

#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <linux/fb.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <stdlib.h>
#include <string.h>

#if 0
#define DEB(f) (f)
#else
#define DEB(f)
#endif

struct fb_var_screeninfo fb_var;
struct fb_fix_screeninfo fb_fix;
char * fb_base_addr = NULL;

/* Set a pixel color
 * @param p_osd osd descriptor
 * @param x
 * @param y
 * @color 0xAARRGGBB (AA = alpha : 0 transparent)
 */
static void set_pixel(RMuint32 x, RMuint32 y, RMuint32 color)
{
	//static RMuint32 i=0;
	/* TODO We assume for now we have contigus regions */
	switch (fb_var.bits_per_pixel){
		case 32:
			{
				RMuint32 *addr= (RMuint32 *)fb_base_addr+(y*fb_var.xres+x);
                                RMuint32ToLeBuf(color, (RMuint8 *) addr);
			}
			break;
		case 24:
			{
				RMuint32 *addr= (RMuint32 *)fb_base_addr+(y*fb_var.xres+x);
                                RMuint32ToLeBuf((0x00FFFFFF) & color, (RMuint8 *) addr);
				/*RMuint8 *addr = (RMuint8 *)fb_base_addr+(y*fb_var.xres+x)*3;
				*addr = (RMuint8) (color & 0xFF);
				*(addr+1) = (RMuint8) (color >> 8 & 0xFF);
				*(addr+2) = (RMuint8) (color >> 16 & 0xFF);*/
			}
			break;
		case 16:
			{
				RMuint16 *addr = (RMuint16 *) fb_base_addr+(y*fb_var.xres+x);
                                RMuint16ToLeBuf((RMuint16) color, (RMuint8 *) addr);
			}
			break;
		case 8:
			{
				RMuint8 *addr = (RMuint8 *)fb_base_addr+(y*fb_var.xres+x);
				*addr = (RMuint8) color;
			}
			break;
		case 4:
			{
				RMuint8 *addr = (RMuint8 *)fb_base_addr+(y*fb_var.xres+x) / 2;
				RMuint32 bit = (RMuint32) ((RMuint8 *)fb_base_addr+(y*fb_var.xres+x) % 2);
				RMuint8 pixel = *addr;
				pixel = pixel & ( 0x0F << bit * 4 );
				color = ( color & 0x0000000F ) << 4;
				*addr = pixel | ( (RMuint8) color >> bit * 4 );
			}
			break;
		case 2:
			{
				RMuint8 *addr = (RMuint8 *)fb_base_addr+(y*fb_var.xres+x) / 4;
				RMuint32 bit = (RMuint32) ((RMuint8 *)fb_base_addr+(y*fb_var.xres+x) % 4);
				RMuint8 pixel = *addr;
				pixel = pixel & ( 0xFF ^ ( 0x3 << bit * 2));
				color = color & 0x00000003;
				*addr = pixel | ( (RMuint8) color << bit * 2 );
			}
			break;
		case 1:
			{
				/*RMuint8 *addr = (RMuint8 *)fb_base_addr+(y*fb_var.xres+x);
				*addr = (RMuint8) color;*/
				RMuint8 *addr = (RMuint8 *)fb_base_addr+(y*fb_var.xres+x) / 8;
				RMuint32 bit = (RMuint32) ((RMuint8 *)fb_base_addr+(y*fb_var.xres+x) % 8);
				RMuint8 pixel = *addr;
				pixel = pixel & ( 0xFF ^ ( 0x1 << bit ));
				color = color & 0x00000001;
				*addr = pixel | ( (RMuint8) color << bit );
			}
			break;
		default:
			fprintf(stderr,"Unknown bpp : %d\n",fb_var.bits_per_pixel);
			break;
	}
	/*if (i<10){
		DEB(fprintf(stderr,"(%ld,%ld) [%p] <- %lX\n",x,y,addr,*addr));
		i++;
	}*/
}

static void mire()
{
	RMuint32 x,y;
	RMuint32 color;
	RMuint8 red,green,blue,alpha;

	DEB(fprintf(stderr,"begin mire\n"));
	for (y=0;y<fb_var.yres;y++)
		for (x=0;x<fb_var.xres;x++){
			color = ((x-fb_var.xres/2)*(x-fb_var.xres/2) + (y-fb_var.yres/2)*(y-fb_var.yres/2))/64;
			red   = (color/8) % 256;
			green = (color/4) % 256;
			blue  = (color/2) % 256;
			alpha = (color*2) % 256;
			//alpha = 0xFF;

			color |= ((RMuint32)alpha << 24);
			color |= ((RMuint32)red   << 16);
			color |= ((RMuint32)green << 8 );
			color |= ((RMuint32)blue       );

			set_pixel(x,y,color);
		}

	DEB(fprintf(stderr,"end mire\n"));
}

int main(int argc, char** argv)
{
	int fd = 0;
	long int screensize = 0;
	
	if (argc<2) {
		fprintf(stderr,"Usage (example): %s /dev/fb/1\n",argv[0]);
		return -1;
	}
 
	fd=open(argv[1],O_RDWR);
	if (fd <0){
		printf("error opening %s\n",argv[1]);
		exit(1);
	}

	// Get fixed screen information
	if (ioctl(fd, FBIOGET_FSCREENINFO, &fb_fix)) {
		printf("Error reading fb fixed information.\n");
		exit(1);
	}

	// Get variable screen information
	if (ioctl(fd, FBIOGET_VSCREENINFO, &fb_var)) {
		printf("Error reading fb variable information.\n");
		exit(1);
	}

	printf("%dx%d, %dbpp\n", fb_var.xres, fb_var.yres, fb_var.bits_per_pixel );

	screensize = fb_var.xres * fb_var.yres * fb_var.bits_per_pixel / 8;
	
#if (EM86XX_MODE == EM86XX_MODEID_WITHHOST) || (EM86XX_CHIP == EM86XX_CHIPID_TANGO2)
	/* fix #6351 comment26 e.m. 2006oct20 */
#define PAGE_SIZE       (4096)
	fb_base_addr = (char *)mmap(NULL , screensize+PAGE_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
#else
	//uclinux doesn't support MAP_SHARED or MAP_PRIVATE with PROT_WRITE, so no mmap at all is simpler
	fb_base_addr = (char *)fb_fix.smem_start;
#endif
	if ((int)fb_base_addr == -1) {
		printf("error mapping fb\n");
		exit(1);
	}

#if (EM86XX_CHIP == EM86XX_CHIPID_TANGO2) && (EM86XX_MODE == EM86XX_MODEID_STANDALONE)
	/* temporary fix for 5159, mapping is paged aligned */
	if (fb_fix.smem_start & (PAGE_SIZE-1)) {
		fb_base_addr += (fb_fix.smem_start & (PAGE_SIZE-1));
		fprintf(stderr, "Fix alignment 0x%08lx -> %p.\n",
			fb_fix.smem_start, fb_base_addr);
	}
#endif /* EM86XX_CHIPID_TANGO2 && EM86XX_MODEID_STANDALONE */

	//blank	
	memset(fb_base_addr,0x00,screensize);

	usleep(50000);
	mire();
#if (EM86XX_MODE == EM86XX_MODEID_WITHHOST) || (EM86XX_CHIP == EM86XX_CHIPID_TANGO2)
	munmap(fb_base_addr, screensize);
#endif
	close(fd);
	return 0;
}

