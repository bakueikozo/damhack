#define ALLOW_OS_CODE 1
#include "../rua/include/rua.h"
#include "../dcc/include/dcc.h"
#include "common.h"
#include "sample_os.h"
#include "../samples/rmttx.h"

#undef DEBUG
#define DEBUG	DISABLE

extern RMbool manutest;

struct profile_record {
	char*							profile_id;
	enum MPEG_Profile				profile_profile;
	enum VideoDecoder_Codec_type	profile_codec;
};

#define	PROFILE_ENTRY(name, value)	{ name, Profile_##value , VideoDecoder_Codec_##value, },
#define	PROFILE_END()				{ 0, 0, 0, },

/* lookup table for video profiles */
struct profile_record	profile_table[] = {
	PROFILE_ENTRY("2sd", 	MPEG2_SD)
	PROFILE_ENTRY("3sd",	DIVX3_SD)	
	PROFILE_ENTRY("4sd", 	MPEG4_SD)
	PROFILE_ENTRY("4sdr",	MPEG4_SD_Padding)
	PROFILE_ENTRY("2dvd", 	MPEG2_DVD)
	PROFILE_ENTRY("2hd",	MPEG2_HD)
	PROFILE_ENTRY("3hd",	DIVX3_HD)
	PROFILE_ENTRY("4hd",	MPEG4_HD)
	PROFILE_ENTRY("4hdr",	MPEG4_HD_Padding)
	PROFILE_ENTRY("2sddi", 	MPEG2_SD_DeInt)
	PROFILE_ENTRY("4sddi",	MPEG4_SD_DeInt)
	PROFILE_ENTRY("4sddir",	MPEG4_SD_DeInt_Padding)
	PROFILE_ENTRY("2dvddi",	MPEG2_DVD_DeInt)
	PROFILE_ENTRY("2hddi",	MPEG2_HD_DeInt)
	PROFILE_ENTRY("4hddi",	MPEG4_HD_DeInt)
	PROFILE_ENTRY("4hddir",	MPEG4_HD_DeInt_Padding)
	PROFILE_ENTRY("9sd",	WMV_SD)
	PROFILE_ENTRY("9816p",	WMV_816P)
	PROFILE_ENTRY("9hd",	WMV_HD)
	PROFILE_ENTRY("5sd",	H264_SD)
	PROFILE_ENTRY("5hd",	H264_HD)
	PROFILE_ENTRY("5sddi",	H264_SD_DeInt)
	PROFILE_ENTRY("5hddi",	H264_HD_DeInt)
	PROFILE_ENTRY("10sd",	VC1_SD)
	PROFILE_ENTRY("10hd",	VC1_HD)
	
	PROFILE_END()
};

/* look up profile name, store profile identifier */
RMstatus get_profile_profile(const char* prof, enum MPEG_Profile* profile) {
	int i;
	
	for (i = 0 ; profile_table[i].profile_id != 0L ; i++) {
		if (strcmp(profile_table[i].profile_id, prof) == 0) {
			*profile = profile_table[i].profile_profile;
			return RM_OK;
		}
	}
	
	return RM_ERROR;
}

/* look up profile name, store video decoder identifier */
RMstatus get_profile_codec(const char* prof, enum VideoDecoder_Codec_type* type) {
	int i;
	
	for (i = 0 ; profile_table[i].profile_id != 0L ; i++) {
		if (strcmp(profile_table[i].profile_id, prof) == 0) {
			*type = profile_table[i].profile_codec;
			return RM_OK;
		}
	}
	
	return RM_ERROR;
}

static 	RMuint8 ccbuf[256], dtvbuf[128];
static RMuint32 ccsize = 0, dtvsize = 0;

void show_video_options(void)
{
	fprintf(stderr, "VIDEO OPTIONS (default values inside brackets)\n"
		"\t-2: Selects MPEG2-HD [default]\n"
		"\t-3: Selects DivX3.11-SD\n"
		"\t-4: Selects MPEG4-SD\n"
		"\t-5: Selects H264-SD\n"
		"\t-9: Selects WMV_816P\n"
		"\t-10: Selects VC-1 AP HD\n"
		"\t-p profile: 2=MPEG-1/2, 3=DivX3.11, 4=MPEG-4, 5=H.264, 9=WMV or \n"
		"\t            VC-1 MP, 10=VC-1 AP"
		"\t-v codec:\n"
		"\t-pv codec: 2sd 4sd 4sdr 2dvd [2hd] 4hd 4hdr 2sddi 4sddi 4sddir \n"
		"\t           2dvddi 2hddi 4hddi 4hddir 9sd 9816p 9hd 3sd 3hd 5sd \n"
		"\t           5hd 10sd 10hd auto\n"
		"\t-ve video engine: selects the video engine (DSP) to be used, 0 or 1 [0]\n"
		"\t-vd video decoder: selects the video decoder on the DSP to use. [0]\n"
		"\t-fixvop <resolution per second> <increment per frame>: \n"
		"\t-vtimescale <pts time resolution>: \n"
		"\t          play m4v with pts expressed in vtimescale units. For mpeg4 over m2t use 45000.\n"
		"\t-ics colorspace: Forces the input colorspace. [yuv_601] yuv_709 \n"
		"\t                 rgb_0_255 rgb_16_235\n"
		"\t-cc closed_caption_mode: Selects the closed caption display mode.\n"
		"\t                         [tv] soft (608soft cc1) cc2 cc3 cc4 708soft off\n"
		"\t-vcodec codec width height: Selects the video codec.\n"
		"\t          codec: mpeg2, mpeg4, divx3, vc1, wmv, h264, jpeg.\n"
		"\t-extrapict: number of extra picture buffers for display[0]\n"
		"\t-vprofile: baseline h264 0, main is 1.[0]\n"
		"\t-vlevel:   level: 0..14 is L1..L5.1 for h264.[0]\n"
		"\t                         [tv] 608soft 708soft off\n"
		"\t-vfifo size: select the video bitstream fifo size in KB. Default is application dependent\n"
		"\t-vxfer count: select the video xfer fifo count. Default is application dependent\n"
		"\t-ms : enable playback of MS elemtary with PTS files\n"
		"\t-seq : WMV9 sequence parameter (Decimal or 0xXXXXXXXX Hexadecimal)\n"
		"\t-scan <mode>: sets video scan mode: [source] frame top bot\n"
		"\t-displayerror <threshold>: sets display error threshold [0]\n"
		"\t-err_prop_threshold <threshold> : sets anchor error propagation threshold\n"
		"\t-err_prop_length <length> : sets anchor error propagation length\n"
		"\t-lowdelay: used to set lowdelay mode and display pictures as soon as their are decoded [FALSE]\n"
		"\t-intprog algorithm: Selects the interlaced_progressive algorithm: [std], mpeg2_prog_seq, mpeg2_menu_prog\n"
		"\t-use_afd: parse Active Format information from MPEG2 or H.264 streams and adjust the display accordingly\n"
		"\t-act <active format>: force active format for the content\n"
		"\t\t[none], full, 16x9top, 14x9top, 64x27, 4x3, 16x9, 14x9, 4x3_14x9, 16x9_14x9, 16x9_4x3\n"
		"\t-skipNCP <value>: skip (1) or not to skip (0) NotCoded P-frames: [0] 1\n"
		);
}

RMstatus init_video_options(struct video_cmdline *options)
{
	RMDBGLOG((ENABLE, "\n*********************init_video_options\n\n"));

	options->MpegEngineID = 0;
	options->VideoDecoderID = 0;
 	options->MPEGProfile = Profile_MPEG2_HD;
	options->Codec = VideoDecoder_Codec_MPEG2_HD;
	options->VopInfo.FixedVopRate = FALSE;			// by default don't use fixed rate
	options->VopInfo.VopTimeIncrementResolution = 30000;	// ticks per second
	options->VopInfo.FixedVopTimeIncrement = 1000;		// ticks per frame
	options->vtimescale.enable = FALSE;
	options->vtimescale.time_resolution = 45000;
	options->input_color_space = EMhwlibColorSpace_YUV_601;
	options->force_input_color_space = FALSE;
	options->display_ttx = FALSE;
	
	/* default CC is TV */
	options->display_cc = TRUE;
	options->cc_select = EMhwlibCCSelect_CC1;
	options->use_soft_cc_decoder = 0;

	options->fifo_size = 0;
	options->xfer_count = 0;
	
	options->vcodec = EMhwlibVideoCodec_MPEG2;
	options->vcodec_profile = 0;
	options->vcodec_level = 0;
	options->vcodec_max_width = 0;
	options->vcodec_max_height = 0;
	options->vcodec_extra_pictures = 0;
	options->MSflag = FALSE;
	options->wmv9_seq = 0x4d491a01;
	options->auto_detect_codec = FALSE;
	
	options->input_scan_mode = EMhwlibScanMode_Source;
	options->display_error_threshold = 0;
	options->anchor_error_parms.AnchorErrPropagationThreshold = 500;
	options->anchor_error_parms.AnchorErrPropagationLength = 13;
	options->lowdelay = FALSE; /* used only for play_video */
	options->interlaced_progressive_algorithm = INTERLACED_PROGRESSIVE_ALGORITHM_USING_DECODER_SPECIFICATION;
	options->UseAFD = FALSE;  // parse and use Active Format Descriptor from stream
	options->ForceAFD = FALSE;  // force Active Format Descriptor for content
	options->AFDTransition = 0;  // Future extension: adjust display of several frames to new format
	options->afd.ActiveFormatValid = FALSE;
	options->afd.ActiveFormat = EMhwlibAF_same_as_picture;
	options->afd.FrameAspectRatio.X = 0;
	options->afd.FrameAspectRatio.Y = 0;
	
	options->first_pts_in_stream = 0;
	options->skipNCP = FALSE;

	return RM_OK;
}

RMstatus parse_video_cmdline(int argc, char **argv, int *index, struct video_cmdline *options)
{
	RMstatus err = RM_PENDING;
	int i = *index;

	if (RMCompareAscii(argv[i], "-seq")) {
		if (argc > i+1) {
			if (RMNCompareAscii(argv[i+1], "0x", 2) == TRUE) {
            	sscanf(argv[i+1], "0x%lx", &options->wmv9_seq);
			} else {
				options->wmv9_seq = strtol(argv[i+1], NULL, 10);
			}
			i+=2;
			err = RM_OK;
		}
		else {
			err = RM_ERROR;
		}
	}
	else if (RMCompareAscii(argv[i], "-ve")) {
		if (argc > i+1) {
			options->MpegEngineID = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else {
			err = RM_ERROR;
		}
	} 
	else if ( ! strcmp(argv[i], "-vd")) {
		if (argc > i+1) {
			options->VideoDecoderID = strtol(argv[i+1], NULL, 10);
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-2")) {
		options->MPEGProfile = Profile_MPEG2_HD;
		options->Codec = VideoDecoder_Codec_MPEG2_HD;
		i++;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-3")) {
		options->MPEGProfile = Profile_DIVX3_SD;
		options->Codec = VideoDecoder_Codec_DIVX3_SD;
		i++;

		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-4")) {
		options->MPEGProfile = Profile_MPEG4_SD;
		options->Codec = VideoDecoder_Codec_MPEG4_SD;
		i++;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-5")) {
		options->MPEGProfile = Profile_H264_SD;
		options->Codec = VideoDecoder_Codec_H264_SD;
		i++;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-9")) {
		options->MPEGProfile = Profile_WMV_816P;
		options->Codec = VideoDecoder_Codec_WMV_816P;
		i++;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-10")) {
		options->MPEGProfile = Profile_VC1_HD;
		options->Codec = VideoDecoder_Codec_VC1_HD;
		i++;
		err = RM_OK;
	}
	else if ((RMCompareAscii(argv[i], "-p")) || (RMCompareAscii(argv[i], "-v"))) {
		if (argc > i+1) {
			if (RMCompareAscii(argv[i], "-p")) {
				err = get_profile_profile(argv[i+1], &options->MPEGProfile);			
			}
			if (RMCompareAscii(argv[i], "-v")) {
				err = get_profile_codec(argv[i+1], &options->Codec);
			}
		}
		else
			err = RM_ERROR;
		
		if (err != RM_ERROR)
			err = RM_OK;
		i+=2;
	}
	else if (RMCompareAscii(argv[i], "-pv")) {
		if (argc > i+1) {
			if (RMCompareAscii(argv[i+1], "auto")) {
				options->auto_detect_codec = TRUE;
				RMDBGLOG((ENABLE, "\n\n\n\n\n********************** VIDEO CODEC: AUTO ***************\n\n\n\n"));
			}
			else {
				err = get_profile_profile(argv[i+1], &options->MPEGProfile);			
				
				err = get_profile_codec(argv[i+1], &options->Codec);
			}
		}
		else
			err = RM_ERROR;

		if (err != RM_ERROR)
			err = RM_OK;
		i+=2;
	}
	else if (RMCompareAscii(argv[i], "-fixvop")) {
		if (argc > i+2) {
			options->VopInfo.FixedVopRate = TRUE;
			RMasciiToUInt32(argv[i+1], &(options->VopInfo.VopTimeIncrementResolution));
			RMasciiToUInt32(argv[i+2], &(options->VopInfo.FixedVopTimeIncrement));
			i += 3;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-vtimescale")) {
		if (argc > i+1) {
			options->vtimescale.enable = TRUE;
			RMasciiToUInt32(argv[i+1], &(options->vtimescale.time_resolution));
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-skipNCP")) {
		if (argc > i+1) {
			RMuint32 dummy;
			RMasciiToUInt32(argv[i+1], &dummy);

			if (dummy)
				options->skipNCP = TRUE;
			else
				options->skipNCP = FALSE;

			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-ics")) {
		if (argc > i+1) {
			if (RMCompareAsciiCaseInsensitively(argv[i+1], "none")) {
				options->input_color_space = EMhwlibColorSpace_None;
			// backwards compatibility
			} else if (RMCompareAscii(argv[i+1], "yuv_601")) {
				options->input_color_space = EMhwlibColorSpace_YUV_601;
			} else if (RMCompareAscii(argv[i+1], "yuv_709")) {
				options->input_color_space = EMhwlibColorSpace_YUV_709;
			} else if (RMCompareAscii(argv[i+1], "xv_601")) {
				options->input_color_space = EMhwlibColorSpace_xvYCC_601;
			} else if (RMCompareAscii(argv[i+1], "xv_709")) {
				options->input_color_space = EMhwlibColorSpace_xvYCC_709;
			} else if (RMCompareAscii(argv[i+1], "rgb_0_255")) {
				options->input_color_space = EMhwlibColorSpace_RGB_0_255;
			} else if (RMCompareAscii(argv[i+1], "rgb_16_235")) {
				options->input_color_space = EMhwlibColorSpace_RGB_16_235;
			// new notation
			} else if (RMCompareAsciiCaseInsensitively(argv[i+1], "YCC601")) {
				options->input_color_space = EMhwlibColorSpace_YUV_601;
			} else if (RMCompareAsciiCaseInsensitively(argv[i+1], "YCC601f")) {
				options->input_color_space = EMhwlibColorSpace_YUV_601_0_255;
			} else if (RMCompareAsciiCaseInsensitively(argv[i+1], "YCC709")) {
				options->input_color_space = EMhwlibColorSpace_YUV_709;
			} else if (RMCompareAsciiCaseInsensitively(argv[i+1], "YCC709f")) {
				options->input_color_space = EMhwlibColorSpace_YUV_709_0_255;
			} else if (RMCompareAsciiCaseInsensitively(argv[i+1], "xvYCC601")) {
				options->input_color_space = EMhwlibColorSpace_xvYCC_601;
			} else if (RMCompareAsciiCaseInsensitively(argv[i+1], "xvYCC601f")) {
				options->input_color_space = EMhwlibColorSpace_xvYCC_601_0_255;
			} else if (RMCompareAsciiCaseInsensitively(argv[i+1], "xvYCC709")) {
				options->input_color_space = EMhwlibColorSpace_xvYCC_709;
			} else if (RMCompareAsciiCaseInsensitively(argv[i+1], "xvYCC709f")) {
				options->input_color_space = EMhwlibColorSpace_xvYCC_709_0_255;
			} else if (RMCompareAsciiCaseInsensitively(argv[i+1], "RGB")) {
				options->input_color_space = EMhwlibColorSpace_RGB_0_255;
			} else if (RMCompareAsciiCaseInsensitively(argv[i+1], "RGBl")) {
				options->input_color_space = EMhwlibColorSpace_RGB_16_235;
			}
			else
				err = RM_ERROR;
			if (err != RM_ERROR) {
				err = RM_OK;
				options->force_input_color_space = TRUE;
			}
			i += 2;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-ttx")) {
		options->display_ttx = TRUE; // ttx should be a playback option instead of video
		err = RM_OK;		     // put it here to be handled together with cc
		i++;
	}
	else if (RMCompareAscii(argv[i], "-cc")) {
		if (argc > i+1) {
			err = RM_OK;
			if(RMCompareAscii(argv[i+1], "tv")) {
				options->display_cc = TRUE;
				options->use_soft_cc_decoder = 0;
			}
			else if(RMCompareAscii(argv[i+1], "soft") || 
				RMCompareAscii(argv[i+1], "608soft") ||
				RMCompareAscii(argv[i+1], "cc1")) {
				options->display_cc = TRUE;
				options->use_soft_cc_decoder = 1;
				options->cc_select = EMhwlibCCSelect_CC1;
			}
			else if(RMCompareAscii(argv[i+1], "cc2") ){
				options->display_cc = TRUE;
				options->use_soft_cc_decoder = 1;
				options->cc_select = EMhwlibCCSelect_CC2;
			}
			else if(RMCompareAscii(argv[i+1], "cc3") ){
				options->display_cc = TRUE;
				options->use_soft_cc_decoder = 1;
				options->cc_select = EMhwlibCCSelect_CC3;
			}
			else if(RMCompareAscii(argv[i+1], "cc4") ){
				options->display_cc = TRUE;
				options->use_soft_cc_decoder = 1;
				options->cc_select = EMhwlibCCSelect_CC4;
			}
			else if(RMCompareAscii(argv[i+1], "708soft")) {
				options->display_cc = TRUE;
				options->use_soft_cc_decoder = 2;
			}
			else if(RMCompareAscii(argv[i+1], "off")) {
				options->display_cc = FALSE;
			}
			else
				err = RM_ERROR;

			i += 2;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-vcodec")) {
		if (argc > i+3) {
			err = RM_OK;
			if(RMCompareAscii(argv[i+1], "mpeg2")) {
				options->vcodec = EMhwlibVideoCodec_MPEG2;
			}
			else if(RMCompareAscii(argv[i+1], "mpeg4")) {
				options->vcodec = EMhwlibVideoCodec_MPEG4;
			}
			else if(RMCompareAscii(argv[i+1], "divx3")) {
				options->vcodec = EMhwlibVideoCodec_DIVX3;
			}
			else if(RMCompareAscii(argv[i+1], "vc1")) {
				options->vcodec = EMhwlibVideoCodec_VC1;
			}
			else if(RMCompareAscii(argv[i+1], "wmv")) {
				options->vcodec = EMhwlibVideoCodec_WMV;
			}
			else if(RMCompareAscii(argv[i+1], "h264")) {
				options->vcodec = EMhwlibVideoCodec_H264;
			}
			else if(RMCompareAscii(argv[i+1], "jpeg")) {
				options->vcodec = EMhwlibJPEGCodec;
				if (options->vcodec_profile == 0)
					options->vcodec_profile = EMhwlib_JPEG_422_Profile;
			}
			else
				err = RM_ERROR;
			if (err != RM_ERROR) {
				RMasciiToUInt32(argv[i+2], &(options->vcodec_max_width));
				RMasciiToUInt32(argv[i+3], &(options->vcodec_max_height));
					
/*
				if ((options->vcodec_max_width > 1920) || (options->vcodec_max_height > 1088)){
					RMDBGLOG((ENABLE,"ERROR - too much memory required for %ld x %ld\n",
						options->vcodec_max_width, options->vcodec_max_height));
					err = RM_ERROR;
				}
*/
			}

			i += 4;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-vprofile")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options->vcodec_profile));
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-vlevel")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options->vcodec_level));
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}

	else if (RMCompareAscii(argv[i], "-extrapict")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], (RMuint32*)&(options->vcodec_extra_pictures));
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-vfifo")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options->fifo_size));
			options->fifo_size *= 1024;
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-vxfer")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options->xfer_count));
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-ms")) {
		options->MSflag = TRUE;
		err = RM_OK;
		i++;
	}
	else if (RMCompareAscii(argv[i], "-lowdelay")) {
		options->lowdelay = TRUE;
		err = RM_OK;
		i++;
	}
	else if (RMCompareAscii(argv[i], "-scan")) {
		if (argc > i+1) {
			err = RM_OK;
			if(RMCompareAscii(argv[i+1], "frame")) {
				options->input_scan_mode = EMhwlibScanMode_Progressive;
			}
			else if(RMCompareAscii(argv[i+1], "top")) {
				options->input_scan_mode = EMhwlibScanMode_Interlaced_TopFieldFirst;
			}
			else if(RMCompareAscii(argv[i+1], "bot")) {
				options->input_scan_mode = EMhwlibScanMode_Interlaced_BotFieldFirst;
			}
			else
				err = RM_ERROR;
			i += 2;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-displayerror")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options->display_error_threshold));
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-err_prop_threshold")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options->anchor_error_parms.AnchorErrPropagationThreshold));
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-err_prop_length")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options->anchor_error_parms.AnchorErrPropagationLength));
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-intprog")) {
		if (argc > i+1) {
			err = RM_OK;
			if(RMCompareAscii(argv[i+1], "std")) {
				options->interlaced_progressive_algorithm = INTERLACED_PROGRESSIVE_ALGORITHM_USING_DECODER_SPECIFICATION;
			}
			else if(RMCompareAscii(argv[i+1], "mpeg2_prog_seq")) {
				options->interlaced_progressive_algorithm = INTERLACED_PROGRESSIVE_ALGORITHM_USING_MPEG2_PROGRESSIVE_SEQ;
			}
			else if(RMCompareAscii(argv[i+1], "mpeg2_menu_prog")) {
				options->interlaced_progressive_algorithm = INTERLACED_PROGRESSIVE_ALGORITHM_USING_MPEG2_MENU_PROGRESSIVE;
			}
			else
				err = RM_ERROR;
			i += 2;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-use_afd")) {
		options->UseAFD = TRUE;
		err = RM_OK;
		i++;
	}
	else if (RMCompareAscii(argv[i], "-act")) {
		if (argc > i+1) {
			options->ForceAFD = TRUE;
			options->afd.ActiveFormatValid = TRUE;
			if (RMCompareAscii(argv[i+1], "none")) {
				options->afd.ActiveFormatValid = FALSE;
			} else if (RMCompareAscii(argv[i+1], "full")) {
				options->afd.ActiveFormat = EMhwlibAF_same_as_picture;
			} else if (RMCompareAscii(argv[i+1], "16x9top")) {
				options->afd.ActiveFormat = EMhwlibAF_16x9_top;
			} else if (RMCompareAscii(argv[i+1], "14x9top")) {
				options->afd.ActiveFormat = EMhwlibAF_14x9_top;
			} else if (RMCompareAscii(argv[i+1], "64x27")) {
				options->afd.ActiveFormat = EMhwlibAF_64x27_centered;
			} else if (RMCompareAscii(argv[i+1], "4x3")) {
				options->afd.ActiveFormat = EMhwlibAF_4x3_centered;
			} else if (RMCompareAscii(argv[i+1], "16x9")) {
				options->afd.ActiveFormat = EMhwlibAF_16x9_centered;
			} else if (RMCompareAscii(argv[i+1], "14x9")) {
				options->afd.ActiveFormat = EMhwlibAF_14x9_centered;
			} else if (RMCompareAscii(argv[i+1], "4x3_14x9")) {
				options->afd.ActiveFormat = EMhwlibAF_4x3_centered_prot_14x9;
			} else if (RMCompareAscii(argv[i+1], "16x9_14x9")) {
				options->afd.ActiveFormat = EMhwlibAF_16x9_centered_prot_14x9;
			} else if (RMCompareAscii(argv[i+1], "16x9_4x3")) {
				options->afd.ActiveFormat = EMhwlibAF_16x9_centered_prot_4x3;
			} else {
				err = RM_ERROR;
			}
			if (err != RM_ERROR)
				err = RM_OK;
			i += 2;
		}
		else 
			err = RM_ERROR;
	}

	*index = i;
	
	return err;
}

RMstatus apply_video_decoder_options(struct dcc_context *dcc_info, struct video_cmdline *options)
{
	RMstatus err;

	if (options->VopInfo.FixedVopRate) {
		RMDBGLOG((ENABLE,"Fixed VOP Rate = %ld / %ld \n", options->VopInfo.VopTimeIncrementResolution, options->VopInfo.FixedVopTimeIncrement));
		err = RUASetProperty(dcc_info->pRUA, dcc_info->video_decoder, RMVideoDecoderPropertyID_VopInfo,
			&options->VopInfo, sizeof(options->VopInfo), 0 );
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE,"************** Error setting fixed VOP rate : %d !\n", err));
			options->VopInfo.FixedVopRate = FALSE;
		}
	} else if (options->vtimescale.enable) {
		RMDBGLOG((ENABLE,"VideoTimeScale = %ld \n", options->vtimescale.time_resolution));
		err = RUASetProperty(dcc_info->pRUA, dcc_info->video_decoder, RMVideoDecoderPropertyID_VideoTimeScale,
			&options->vtimescale, sizeof(options->vtimescale), 0 );
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE,"************** Error setting VideoTimeScale : %d !\n", err));
			options->vtimescale.enable = FALSE;
		}
	}

	if (options->skipNCP) {
		RMbool dummy = TRUE;

		RMDBGLOG((ENABLE, "SkipNotCodedPFrames\n"));

		err = RUASetProperty(dcc_info->pRUA, dcc_info->video_decoder, RMVideoDecoderPropertyID_SkipNotCodedPFrames, &dummy, sizeof(dummy), 0);

		if (err != RM_OK)
			fprintf(stderr, "error setting skip not coded p frames property: %s\n", RMstatusToString(err));
	}

	err = RUASetProperty(dcc_info->pRUA, dcc_info->video_decoder, RMVideoDecoderPropertyID_DisplayErrorThreshold,
		&options->display_error_threshold, sizeof(options->display_error_threshold), 0 );
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE,"************** Error setting DisplayErrorThreshold : %d !\n", err));
	}
	err = RUASetProperty(dcc_info->pRUA, dcc_info->video_decoder, RMVideoDecoderPropertyID_AnchorErrPropagation,
		&options->anchor_error_parms, sizeof(options->anchor_error_parms), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE,"************** Error setting AnchorErrPropagation: %d !\n", err));
	}
	
	err = RUASetProperty(dcc_info->pRUA, dcc_info->video_decoder, RMVideoDecoderPropertyID_InterlacedProgressiveAlgorithm,
		&options->interlaced_progressive_algorithm, sizeof(options->interlaced_progressive_algorithm), 0 );
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE,"************** Error setting InterlacedProgressiveAlgorithm : %d !\n", err));
	}

	if (options->force_input_color_space) {
		struct VideoDecoder_ForceColorSpace_type prop;
		
		prop.Enable = TRUE;
		prop.ColorSpace = options->input_color_space;
		err = RUASetProperty(dcc_info->pRUA, dcc_info->video_decoder, RMVideoDecoderPropertyID_ForceColorSpace, &prop, sizeof(prop), 0);
		if (RMFAILED(err))
			RMDBGLOG((ENABLE,"Error setting input color space: %d !\n", err));
	}

	err = RUASetProperty(dcc_info->pRUA, dcc_info->video_decoder, RMVideoDecoderPropertyID_ScanMode, 
			     &(options->input_scan_mode), sizeof(options->input_scan_mode), 0);
	if (RMFAILED(err))
		RMDBGLOG((ENABLE,"Error setting video scan mode: %d !\n", err));

	if (options->display_cc) {
		RMuint32 entry_count, fifo_size,  mixer, stc_id = 0;
		struct CCFifo_Open_type cc_open;
		entry_count = 256;
#if 0
		switch (dcc_info->route) {
		case DCCRoute_Main:
			mixer = EMHWLIB_MODULE(DispMainMixer, 0);
			break;
		case DCCRoute_Secondary:
			return RM_NOTIMPLEMENTED;
		default:
			return RM_ERROR;
		}
#else
		/* FIXME: Closed caption won't work if route != DCCRoute_Main */
		mixer = EMHWLIB_MODULE(DispMainMixer, 0);
#endif

		dcc_info->ccfifo_in_id = EMHWLIB_MODULE(CCFifo, 0);

		err = RUAExchangeProperty(dcc_info->pRUA, dcc_info->ccfifo_in_id, RMCCFifoPropertyID_DRAMSize, &entry_count, sizeof(entry_count), &fifo_size, sizeof(fifo_size));
		if (RMFAILED(err)) {
			fprintf(stderr, "CCfifo error %s\n", RMstatusToString(err));
			return err;
		}
		if(dcc_info->pStcSource)
			DCCSTCGetModuleId(dcc_info->pStcSource, &stc_id);
		cc_open.UncachedAddress = DCCMalloc(dcc_info->pDCC, 0, RUA_DRAM_UNCACHED, fifo_size);

		cc_open.EntryCount = entry_count;
		cc_open.UncachedSize = fifo_size;
		cc_open.STCModuleId = stc_id;

		dcc_info->ccfifo_in_addr =  cc_open.UncachedAddress;
		
		err = RUASetProperty(dcc_info->pRUA, dcc_info->ccfifo_in_id, RMCCFifoPropertyID_Open, &cc_open, sizeof(cc_open), 0);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot open ccfifo %s\n", RMstatusToString(err));
			return err;
		}
		
		/* open second CC fifo for pass-through */
		if (options->use_soft_cc_decoder) {
			dcc_info->ccfifo_out_id = EMHWLIB_MODULE(CCFifo, 1);
			
			err = RUAExchangeProperty(dcc_info->pRUA, dcc_info->ccfifo_out_id, RMCCFifoPropertyID_DRAMSize, &entry_count, sizeof(entry_count), &fifo_size, sizeof(fifo_size));
			if (RMFAILED(err)) {
				fprintf(stderr, "CCfifo error %s\n", RMstatusToString(err));
				return err;
			}
			if(dcc_info->pStcSource)
				DCCSTCGetModuleId(dcc_info->pStcSource, &stc_id);
			cc_open.UncachedAddress = DCCMalloc(dcc_info->pDCC, 0, RUA_DRAM_UNCACHED, fifo_size);
			
			cc_open.EntryCount = entry_count;
			cc_open.UncachedSize = fifo_size;
			cc_open.STCModuleId = stc_id;
			
			dcc_info->ccfifo_out_addr = cc_open.UncachedAddress;
			
			err = RUASetProperty(dcc_info->pRUA, dcc_info->ccfifo_out_id, RMCCFifoPropertyID_Open, &cc_open, sizeof(cc_open), 0);
			if (RMFAILED(err)) {
				fprintf(stderr, "Cannot open ccfifo %s\n", RMstatusToString(err));
				return err;
			}
		} 
		else {
			dcc_info->ccfifo_out_id = dcc_info->ccfifo_in_id;
			dcc_info->ccfifo_out_addr = 0;
		}
		


		if (options->use_soft_cc_decoder){
			RMbool enable;
			struct DCCOSDProfile osd_profile;
			
			Rtk86Handle rtk_handle;
			struct EMhwlibDisplayWindow window;
			struct rmscc_init scc_init;
			RMuint32 scaler, src_index, used_colors;
			RMpalette_8BPP cc_palette;
			
			scaler = DispOSDScaler;
				
			/* create a buffer to draw the closed caption on */
			osd_profile.ColorSpace = EMhwlibColorSpace_RGB_0_255;
			osd_profile.SamplingMode = EMhwlibSamplingMode_444;
			osd_profile.ColorFormat = EMhwlibColorFormat_32BPP;
			/* eia708 does not support indexed mode yet */
			if(options->use_soft_cc_decoder == 1)
				osd_profile.ColorMode = EMhwlibColorMode_LUT_8BPP;
			else if(options->use_soft_cc_decoder == 2)
				osd_profile.ColorMode = EMhwlibColorMode_TrueColor;
			osd_profile.PixelAspectRatio.X = 1;
			osd_profile.PixelAspectRatio.Y = 1;
			osd_profile.Width = 640;
			osd_profile.Height = 480;
				
			window.X = 2048;
			window.Y = 2048;
			window.Width = 4096;
			window.Height = 4096;
				
			window.XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToCenter;
			window.YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToCenter;
			window.XMode = EMhwlibDisplayWindowValueMode_Relative;
			window.YMode = EMhwlibDisplayWindowValueMode_Relative;
			window.WidthMode = EMhwlibDisplayWindowValueMode_Relative;
			window.HeightMode = EMhwlibDisplayWindowValueMode_Relative;

			
			/* Disable the scaler while we program it */
			enable = FALSE;
			err =  RUASetProperty(dcc_info->pRUA, scaler, RMGenericPropertyID_Enable, &enable, sizeof(enable), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot enable scaler\n"));
				return err;
			}
	
			err = DCCOpenOSDVideoSource(dcc_info->pDCC, &osd_profile, &(dcc_info->pCCOSDSource));
			if (RMFAILED(err)) {
				fprintf(stderr, "Cannot open OSD decoder %d\n", err);
				return err;
			}
				
			while ((err = RUASetProperty(dcc_info->pRUA, scaler, RMGenericPropertyID_ScalerInputWindow, &(window), sizeof(window), 0)) == RM_PENDING);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot set scaler input window on OSD surface %d\n", err));
				return err;
			}
				
				
			err = DCCSetSurfaceSource(dcc_info->pDCC, scaler, dcc_info->pCCOSDSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot set the surface source %d\n", err));
				return err;
			}

			err = DCCEnableVideoSource(dcc_info->pCCOSDSource, TRUE);
			if (RMFAILED(err)){
				RMDBGLOG((ENABLE, "Error enabling OSD buffer : %d\n",err));
				return err;
			}
			
			err = RUAExchangeProperty(dcc_info->pRUA, mixer, RMGenericPropertyID_MixerSourceIndex, &scaler, sizeof(scaler), &src_index, sizeof(src_index));
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot get scaler index\n"));
				return err;
			}
			
			/* display the osd only on the active region of the screen (80% width, 80% height) */
				
			mixer = EMHWLIB_TARGET_MODULE(mixer, 0, src_index);

			window.Width = 8*4096/10;
			window.Height = 8*4096/10;
			while ((err = RUASetProperty(dcc_info->pRUA, mixer, RMGenericPropertyID_MixerSourceWindow, &(window), sizeof(window), 0)) == RM_PENDING);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot set scaler output window %d\n", err));
				return err;
			}

			if(options->use_soft_cc_decoder == 2){
 
				/* this asks the video decoder to put only the eia708 closed caption
				 * data into the fifo. The default is to put only eia608 so we don't need
				 * to handle this when use_soft_cc_decoder == 1
				 */
				struct CCFifo_AllowedTypes_type allowed_types;
				allowed_types.Allow608 = FALSE;
				allowed_types.Allow708 = TRUE;
				err = RUASetProperty(dcc_info->pRUA, dcc_info->ccfifo_in_id, RMCCFifoPropertyID_AllowedTypes, &(allowed_types), sizeof(allowed_types), 0);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Cannot set scaler input window on OSD surface %d\n", err));
					return err;
				}
				/* make this instance of rmscc a eia708 decoder */
				scc_init.format = rmscc_eia_708;
			}
			else if (options->use_soft_cc_decoder == 1){
				/* make this instance of rmscc a eia608 decoder */
				scc_init.format = rmscc_eia_608;
			}
			else{
				RMDBGLOG((ENABLE, "Wrong value for use_soft_decoder\n"));
				return RM_ERROR;
			}
			rtk_handle.pOSDSource = dcc_info->pCCOSDSource;
			rtk_handle.pRUA = dcc_info->pRUA;
		
			scc_init.rtk = RMFRTKOpen(&rtk_handle);
			if(scc_init.rtk == NULL){
				RMDBGLOG((ENABLE, "Error opening rtk: %d\n",err));
				return RM_ERROR;
			}
				
			scc_init.resize_callback = NULL;
			scc_init.cc_select = (enum rmscc_ccselect)((RMuint32)options->cc_select - 1);
			dcc_info->scc = RMSCCOpen(&scc_init);
			if(dcc_info->scc == NULL){
				RMDBGLOG((ENABLE, "Error opening scc: %d\n",err));
				return RM_ERROR;
			}
			
			dcc_info->rtk= scc_init.rtk;

			/* ask rmscc which palette needs to be set... */
			err = RMSCCGetPalette(dcc_info->scc, &cc_palette, &used_colors);
			if (RMFAILED(err)){
				RMDBGLOG((ENABLE, "Error enabling OSD buffer : %d\n",err));
				return err;
			}

			/* and set it */
			while ((err = RUASetProperty(dcc_info->pRUA, scaler, RMGenericPropertyID_8BPP_LUT, &cc_palette, sizeof(cc_palette), 0)) == RM_PENDING);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot set LUT for OSD scaler: %s\n", RMstatusToString(err)));
				return err;
			}

			while ((err = RUASetProperty(dcc_info->pRUA, scaler, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot validate scaler input window: %s\n", RMstatusToString(err)));
				return err;
			}

			
			/* rmscc has cleared the osd so now we can displayed it */
			enable = TRUE;
			err =  RUASetProperty(dcc_info->pRUA, scaler, RMGenericPropertyID_Enable, &enable, sizeof(enable), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot enable scaler\n"));
				return err;
			}
				
		}
		else{
			while ((err = RUASetProperty(dcc_info->pRUA, mixer, RMGenericPropertyID_CCFifo, &dcc_info->ccfifo_out_id, sizeof(dcc_info->ccfifo_out_id), 0)) == RM_PENDING);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot set CC_fifo\n"));
				return err;
			}
		}
		
		while ((err = RUASetProperty(dcc_info->pRUA, mixer, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot validate mixer settings\n"));
			return err;
		}
		
		err = RUASetProperty(dcc_info->pRUA, dcc_info->video_decoder, RMGenericPropertyID_CCFifo, &dcc_info->ccfifo_in_id, sizeof(dcc_info->ccfifo_in_id), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set CC_fifo on video decoder\n"));
			return err;
		}
	}
	else {
		dcc_info->ccfifo_in_id = 0;
		dcc_info->ccfifo_out_id = 0;
	}
	if (options->display_ttx) {
		RMuint32 mixer;
		mixer = EMHWLIB_MODULE(DispMainMixer, 0);
		dcc_info->ttx_fifo_id = EMHWLIB_MODULE(TTXFifo, 0); // use one ttx fifo for now
		if( dcc_info->ttx_sw_decoder == 0 )  // make sure the TTXfifo is opened
			dcc_info->ttx_sw_decoder = RMTTXOpen( dcc_info->pRUA, dcc_info->ttx_fifo_id, TTX_FIFO_SIZE );

		while ((err = RUASetProperty(dcc_info->pRUA, mixer, RMGenericPropertyID_TTXFifo, &(dcc_info->ttx_fifo_id), sizeof(RMuint32), 0)) == RM_PENDING);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set TTX_fifo\n"));
			return err;
		}
	}
	return RM_OK;
}

RMstatus clear_video_options(struct dcc_context *dcc_info, struct video_cmdline *options)
{
	RMstatus err;
	struct RUAEvent evt;
	RMuint32 wait_count;
	RMbool cc_done = FALSE;
	RMbool mute = TRUE;



	err = RM_OK;
	evt.ModuleID = DisplayBlock;
	evt.Mask = EMHWLIB_DISPLAY_EVENT_ID(DispMainMixer);

	if (dcc_info->ccfifo_in_id) {
		if (options->use_soft_cc_decoder) {
			RMDBGLOG((DEBUG, "Closing soft CC decoder...\n"));
			RMFRTKClose(dcc_info->rtk);
			
			err = DCCCloseVideoSource(dcc_info->pCCOSDSource);
			if (RMFAILED(err)) 
			{
				RMDBGLOG((ENABLE, "Cannot close cc-osd source %s\n", RMstatusToString(err)));
				return err;
			}
			dcc_info->pCCOSDSource = NULL;
			RMDBGLOG((DEBUG, "Done closing soft CC decoder.\n"));
			RMSCCClose(dcc_info->scc);
		}
		else{
			wait_count = 0;
			while((err = RUASetProperty(dcc_info->pRUA, dcc_info->ccfifo_in_id, RMCCFifoPropertyID_Mute, &mute, sizeof(mute), 0) == RM_PENDING) && (wait_count <4)){
				RUAWaitForMultipleEvents(dcc_info->pRUA, &evt, 1, 500000, NULL);
				wait_count++;
			}

			wait_count = 0;
			while((err = RUASetProperty(dcc_info->pRUA, dcc_info->ccfifo_in_id, RMCCFifoPropertyID_Flush, NULL, 0, 0) == RM_PENDING) && (wait_count <4)){
				RUAWaitForMultipleEvents(dcc_info->pRUA, &evt, 1, 500000, NULL);
				wait_count++;
			}

			wait_count = 0;
			while((err = RUASetProperty(dcc_info->pRUA, dcc_info->ccfifo_in_id, RMCCFifoPropertyID_Clear, NULL, 0, 0) == RM_PENDING) && (wait_count <4)){
				RUAWaitForMultipleEvents(dcc_info->pRUA, &evt, 1, 500000, NULL);
				wait_count++;
			}
		}

		/* the clear and flush commands can take some vsyncs to execute (flush(1), clear(4)) 
		   here we wait until they are finished before closing the CCFifo
		*/
		wait_count = 0;
		do{
			err = RUAGetProperty(dcc_info->pRUA, dcc_info->ccfifo_in_id, RMCCFifoPropertyID_FifoEmpty, &cc_done, sizeof(cc_done));
			if(!cc_done){
				RUAWaitForMultipleEvents(dcc_info->pRUA, &evt, 1, 500000, NULL);
				wait_count++;
			}
		}while((!cc_done) && wait_count<16);
		if(!cc_done)
			RMDBGLOG((ENABLE, "ERROR CLEARING CCFIFO!\n"));

		while( (err = RUASetProperty(dcc_info->pRUA, dcc_info->ccfifo_in_id, RMCCFifoPropertyID_Close, NULL, 0, 0)) == RM_PENDING);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot close ccfifo %s\n", RMstatusToString(err));
		}
	}

	if ((dcc_info->ccfifo_out_id) && (dcc_info->ccfifo_out_id != dcc_info->ccfifo_in_id)) {
		RMDBGLOG((DEBUG, "Clearing CC fifo #%lu...\n", EMHWLIB_MODULE_INDEX(dcc_info->ccfifo_out_id)));
		err = RUASetProperty(dcc_info->pRUA, dcc_info->ccfifo_out_id,
				     RMCCFifoPropertyID_Clear, NULL, 0, 0);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot clear passthrough CCfifo %s\n", RMstatusToString(err));
		}
		RMDBGLOG((DEBUG, "Done clearing CC fifo.\n"));

		RMDBGLOG((DEBUG, "Closing CC passthrough fifo #%lu...\n", EMHWLIB_MODULE_INDEX(dcc_info->ccfifo_out_id)));
		while( (err = RUASetProperty(dcc_info->pRUA, dcc_info->ccfifo_out_id, 
					     RMCCFifoPropertyID_Close, NULL, 0, 0)) == RM_PENDING);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot close passthrough ccfifo %s\n", RMstatusToString(err));
		}
		RMDBGLOG((DEBUG, "Done closing CC passthrough fifo.\n"));
	}
	
	if (dcc_info->ccfifo_in_addr) {
		DCCFree(dcc_info->pDCC, dcc_info->ccfifo_in_addr);
		RMDBGLOG((DEBUG, "Done freeing CC fifo memory.\n"));
	}
	
	if (dcc_info->ccfifo_out_addr) {
		DCCFree(dcc_info->pDCC, dcc_info->ccfifo_out_addr);
		RMDBGLOG((DEBUG, "Done freeing CC passthrough fifo memory.\n"));
	}
	
	if (options->display_ttx) {  // close ttx in case of program change 
		if( dcc_info->ttx_sw_decoder != 0 ) { 
			RMTTXClose( dcc_info->ttx_sw_decoder );
			dcc_info->ttx_sw_decoder = 0;
		}
	}
	return RM_OK;
}


RMstatus refresh_soft_cc(struct dcc_context *dcc_info)
{    
	RMstatus err;
	struct CCFifo_CCEntry_type cc_entry;
	enum rmscc_ccselect ccselect = RMSCCGetDisplayCCType(dcc_info->scc);
	
	while (RMSUCCEEDED(RUAGetProperty(dcc_info->pRUA, dcc_info->ccfifo_in_id, RMCCFifoPropertyID_CCEntry, &cc_entry, sizeof(cc_entry)))) {
		if (RMFAILED(err = RUASetProperty(dcc_info->pRUA, dcc_info->ccfifo_out_id, RMCCFifoPropertyID_CCEntry, &cc_entry, sizeof(cc_entry), 0))) {
			RMDBGLOG((DEBUG, "Failed to pass through CC entry! %s\n", RMstatusToString(err)));
			if (err == RM_PENDING) { // probably a STC discontinuity, flush old CC data
				RMuint64 usec;
				RMDBGLOG((DEBUG, "Flushing and clearing CC fifo #%lu...\n", 
					EMHWLIB_MODULE_INDEX(dcc_info->ccfifo_out_id)));
				usec = get_ustime();
				while (RMFAILED(err = RUASetProperty(dcc_info->pRUA, dcc_info->ccfifo_out_id, 
					RMCCFifoPropertyID_Flush, NULL, 0, 0)) && (get_ustime() - usec < 20000));
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Cannot flush CCfifo %s\n", RMstatusToString(err)));
				}
				usec = get_ustime();
				while (RMFAILED(err = RUASetProperty(dcc_info->pRUA, dcc_info->ccfifo_out_id, 
					RMCCFifoPropertyID_Clear, NULL, 0, 0)) && (get_ustime() - usec < 20000));
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Cannot clear CCfifo %s\n", RMstatusToString(err)));
				}
				RMDBGLOG((DEBUG, "Done flushing and clearing CC fifo.\n"));
			}
		}
		if (cc_entry.Enable){
			switch(cc_entry.Type){
			case EMhwlibCCType_TopField:
			case EMhwlibCCType_BottomField:
				if( (ccselect != rmscc_not_available) && (((RMuint32)ccselect & 0x2)>>1 == cc_entry.Type) ) {
					if(ccsize >= 128 - 2){
						RMSCCDecode(dcc_info->scc, ccbuf, ccsize, get_ustime() );
						ccsize = 0;
					}
					ccbuf[ccsize++] = cc_entry.CC1;
					ccbuf[ccsize++] = cc_entry.CC2;
				}
				break;
			case EMhwlibCCType_DTVCCHeader:
				if(dtvsize){
					RMSCCDecode(dcc_info->scc, dtvbuf, dtvsize, get_ustime() );
					dtvsize = 0;
				}
			case EMhwlibCCType_DTVCCData:
				if (dtvsize < 128 - 1) {
					dtvbuf[dtvsize++] = cc_entry.CC1;
					dtvbuf[dtvsize++] = cc_entry.CC2;
				}
				break;
			default:
				break;
			}
		}
	}
	if(ccsize){
		RMSCCDecode(dcc_info->scc, ccbuf, ccsize, get_ustime() );
		ccsize = 0;
	}
	if(dtvsize >= 128){
		fprintf(stderr, "More than 127 dtv bytes without a header?\n");
		return RM_ERROR;
	}
     
	return RM_OK;
}

RMstatus video_profile_to_codec(enum MPEG_Profile profile, enum EMhwlibVideoCodec *pvcodec,
	RMuint32 *pprofile, RMuint32 *plevel, RMuint32 *pextra_buffers,
	RMuint32 *pwidth, RMuint32 *pheight)
{
	/* set codec based on command line option */
	*pextra_buffers = 0;
	*pprofile = 0;
	*plevel = 0;
	
	switch(profile) {
	case Profile_MPEG2_SD:
	case Profile_MPEG2_DVD:
	case Profile_MPEG2_SD_DeInt:
	case Profile_MPEG2_DVD_DeInt:
		*pvcodec = EMhwlibVideoCodec_MPEG2;
		*pwidth = 720;
		*pheight = 576;
		break;
	case Profile_MPEG2_HD:
	case Profile_MPEG2_HD_DeInt:
		*pvcodec = EMhwlibVideoCodec_MPEG2;
		*pwidth = 1920;
		*pheight = 1080;
		break;
	case Profile_MPEG4_SD:
	case Profile_MPEG4_SD_DeInt:
		*pvcodec = EMhwlibVideoCodec_MPEG4;
		*pwidth = 720;
		*pheight = 576;
		break;
	case Profile_MPEG4_SD_Padding:
	case Profile_MPEG4_SD_DeInt_Padding:
		*pvcodec = EMhwlibVideoCodec_MPEG4_Padding;
		*pwidth = 720;
		*pheight = 576;
		break;
	case Profile_MPEG4_HD:
	case Profile_MPEG4_HD_DeInt:
		*pvcodec = EMhwlibVideoCodec_MPEG4;
		*pwidth = 1920;
		*pheight = 1080;
		break;
	case Profile_MPEG4_HD_Padding:
	case Profile_MPEG4_HD_DeInt_Padding:
		*pvcodec = EMhwlibVideoCodec_MPEG4_Padding;
		*pwidth = 1920;
		*pheight = 1080;
		break;
	case Profile_DIVX3_SD:
		*pvcodec = EMhwlibVideoCodec_DIVX3;
		*pwidth = 720;
		*pheight = 576;
		break;
	case Profile_DIVX3_HD:
		*pvcodec = EMhwlibVideoCodec_DIVX3;
		*pwidth = 1920;
		*pheight = 1080;
		break;
	case Profile_VC1_SD:
		*pvcodec = EMhwlibVideoCodec_VC1;
		*pwidth = 720;
		*pheight = 576;
		break;
	case Profile_VC1_HD:
		*pvcodec = EMhwlibVideoCodec_VC1;
		*pwidth = 1920;
		*pheight = 1080;
		break;
	case Profile_WMV_SD:
		*pvcodec = EMhwlibVideoCodec_WMV;
		*pwidth = 720;
		*pheight = 576;
		break;
	case Profile_WMV_816P:
		*pvcodec = EMhwlibVideoCodec_WMV;
		*pwidth = 1440;
		*pheight = 816;
		break;
	case Profile_WMV_HD:
		*pvcodec = EMhwlibVideoCodec_WMV;
		*pwidth = 1920;
		*pheight = 1080;
		break;
	case Profile_H264_SD:
	case Profile_H264_SD_DeInt:
		*pvcodec = EMhwlibVideoCodec_H264;
		*pprofile = EMhwlib_H264_BaselineProfile;
		*plevel = EMhwlib_H264_Level_4;
		*pwidth = 720;
		*pheight = 576;
		break;
	case Profile_H264_HD:
	case Profile_H264_HD_DeInt:
		*pvcodec = EMhwlibVideoCodec_H264;
		*pprofile = EMhwlib_H264_BaselineProfile;
		*plevel = EMhwlib_H264_Level_4;
		*pwidth = 1920;
		*pheight = 1080;
		break;
	default:
		RMDBGLOG((ENABLE, "Unknown video decoder codec \n"));
		return RM_ERROR;
	}
	return RM_OK;
}

