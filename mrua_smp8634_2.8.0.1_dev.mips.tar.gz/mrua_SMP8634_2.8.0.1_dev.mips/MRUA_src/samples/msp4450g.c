#include "msp4450g.h"
#include "i2c.h"
#define DMSG 1
#define MPRINT(x) { DMSG ?printf x:0; }

#define MSP4450G_I2C_ADDR			0x80 >> 1
#define MSP4450G_SADDR_CONTROL		0x00
#define MSP4450G_SADDR_WRDEMOD		0x10
#define	MSP4450G_SADDR_RDDEMOD		0x11
#define MSP4450G_SADDR_WRDSP		0x12
#define	MSP4450G_SADDR_RDDSP		0x13
#define MSP4450G_DELAY				10

#define I2S_srcIN_PRESCALE	0x11
#define MSPSI2S_PRESCALE_OFF	0x00
#define MSPSI2S_PRESCALE_0DB	0x10
#define MSPSI2S_PRESCALE_14DB	0x7f

typedef enum { 
	msp_dmreg_standardselect=0x0020, 
		msp_dmreg_modus=0x0030, 
		msp_dmreg_i2sconfig=0x0040,
		msp_dmreg_standardresult=0x007E, 
		msp_dmreg_status = 0x0200 
} MSP4450G_DEMOD_REGISTER;

static RMstatus msp4450g_readDsp(struct RUA *pInstance,
						  RMuint32 regAddr,
						  RMuint32 *regValue)
{
	RMstatus err=RM_OK;
	err=read_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_RDDSP,regAddr,regValue);
	return err;
}

RMstatus msp4450g_detect(struct RUA *pInstance)
{
	RMstatus s=RM_OK;
	RMuint32 regValue=0;
	
	if( msp4450g_readDsp(pInstance,0x001E, &regValue) != RM_OK )
	{
		printf("msp4450g_detect() error <1> \n ") ;
		return RM_NOT_FOUND;
	}
	
	if( regValue != 0x0317 )
	{
		printf("msp4450g_detect() error <2> reg 0x1e = 0x%lx \n",regValue) ;
		return RM_NOT_FOUND;
	}
	
	s = msp4450g_readDsp(pInstance, 0x001F, &regValue);
	return s;
}



static RMstatus msp4450g_writeControl(struct RUA *pInstance,RMuint16 data)
{
	RMstatus err=RM_OK;
	err=write_i2c_control_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_CONTROL, data);	
	return err;
}

RMstatus msp4450g_reset(struct RUA *pInstance)
{
	RMstatus err=RM_OK;
	if( msp4450g_writeControl(pInstance, 0x8000) != RM_OK )
	{
		printf("msp4450g_reset() error <1>\n");
		return RM_ERROR;
	}	
	 err=msp4450g_writeControl(pInstance,0x0000);
	 return err;
}

static RMstatus msp4450g_writeDemod(struct RUA *pInstance, RMuint32 regAddr, RMuint32 data)
{
	return write_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR, MSP4450G_SADDR_WRDEMOD, regAddr, data);
}


RMstatus msp4450g_demod_selectStandard(struct RUA *pInstance, MSP4450G_STANDARD s)
{
	
	if( msp4450g_writeDemod(pInstance, 0x0020, s) != RM_OK )
		return RM_ERROR;
	
	return RM_OK;
}


RMstatus msp4450g_demod_InputFMamPrescale(struct RUA *pInstance,MSP4450G_FMamPRESCALE p)
{
	RMuint32 uCfg=0x00;
	RMuint32 regValue=0x00;
	RMstatus s;
	
//	assert( pC != NULL);
	
	switch( p )
	{
	case msp_fm28khz:
		uCfg = 0x7F00;
		break;
	case msp_fm50khz:
		uCfg = 0x4800;
		break;
	case msp_fm75khz:
		uCfg = 0x3000;
		break;
	case msp_fm100khz:
		uCfg = 0x2400;
		break;
	case msp_fm150khz:
		uCfg = 0x1800;
		break;
	case msp_fm180khz:
		uCfg = 0x1300;
		break;
		
	case msp_fm_hdev2_150khz:
		uCfg = 0x3000;
		break;
	case msp_fm_hdev2_360khz:
		uCfg = 0x1400;
		break;
		
	case msp_fm_hdev3_450khz:
		uCfg = 0x2000;
		break;
	case msp_fm_hdev3_540khz:
		uCfg = 0x1A00;
		break;
		
	case msp_fm_satellite:
		uCfg = 0x1000;
		break;
		
	case msp_am:
		uCfg = 0x7C00;
		break;
		
	default:
		return RM_INVALID_PARAMETER;
		break;
	}
	
	if( (s = read_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_RDDSP,0x000e, &regValue)) != RM_OK )
	{
		printf("msp4450g_demod_InputFMamPrescale, msp4450g_readDsp() failed %d\n", s);
		return RM_ERROR;
	}
	
	// cfg is bit 15:8
	regValue = (regValue & 0xFF) | uCfg; //
	
/*
	data16 = 0x0002;
	data16 = (data16 & 0xFF) | uCfg; // YVo add
*/
	
	if( (s = write_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_WRDSP, 0x0e, regValue)) != RM_OK )
	{
		printf("msp4450g_demod_InputFMamPrescale, msp4450g_writeDsp(data=0x%lx) failed %d\n", regValue, s);
		return RM_ERROR;
	}
	
	return RM_OK;
}

RMstatus msp4450g_demod_getDetectedStandard(struct RUA *pInstance, RMuint32 *regValue)
{

	if( read_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_RDDEMOD,0x007e, regValue) != RM_OK )
		return RM_ERROR;
	
	return RM_OK;
}


RMstatus msp4450g_demod_init(struct RUA *pInstance,  MSP4450G_DETECT_45MHZ nD45mhz, MSP4450G_DETECT_65MHZ nD65mhz, 
							 MSP4450G_DIGIO_MODE digIOMode, RMuint32 i2sMode)
{
	RMuint16 data16;

	// [0] = 1, automatic sound select ON
	data16 = 0x0001;
	
	// [15] = 0
	// [14:13] 4.5 mhz carrier
	switch( nD45mhz )
	{
	case msp_45mhz_MKorea:
		break;
	case msp_45mhz_MBtsc:
		
		data16 = data16 | (0x01 << 13);
		break;
	case msp_45mhz_MJapan:
		data16 = data16 | (0x02 << 13);
		break;
	case msp_45mhz_ChromaCarrier:
		data16 = data16 | (0x03 << 13);
		break;
	
	default:
		return RM_INVALID_PARAMETER;
		break;
	}
	
	// [12] 6.5Mhz carrier
	switch( nD65mhz )
	{
	case msp_65mhz_LSecam:
		break;
	case msp_65mhz_DK123Nicam:
		data16 = data16 | (0x01 << 12);
		break;
		
	default:
		return RM_INVALID_PARAMETER;
		break;
	}
	

	
	switch( digIOMode )
	{
	case msp_digio_outputenable:
		// [3] = 0;
		break;
	
	case msp_digio_tristate:
		data16 = data16 | 0x0008;
		break;
			
	case msp_digio_out_and_interrupt:
		// [3] = 0;
		// [1] = 1;
		data16 = data16 | 0x0002;
		break;
		
	default:
		printf("msp4450g_init() digIOMode %d invalid\n", digIOMode);
		return RM_INVALID_PARAMETER;
		break;
	}

	
	
	// no extra options...
	//assert( (i2sMode & ~(MSP4450G_I2SOUT_PIN_TRISTATE | MSP4450G_I2SOUT_MODE_SLAVE |MSP4450G_I2SOUT_STROBEWS_1CLK | MSP4450G_I2SOUT_BIT_32)) == 0 );
	// zero out lsb, it is taken care of in another register.
	data16 = data16 | (i2sMode & (~MSP4450G_I2SOUT_BIT_32));

	
	// <1> (typcal configuration, not below)
	// 0 01(4.5mhz=btsc) 0(6.5mhz=SECAM) 0000 0(AUD_CL_OUT=X) 0(I2S STRBalign) 0(I2S master) 0(I2S=X) 
	// 0(Dig IO=active for Test Point) 0 1(DigIO Status) 1(Automatic Sound Sel)
	// = 0x2003

	//data16 = data16 & 0xFFF7;
	//data16 = data16 & 0xFFFE;
	//data16 = data16 | 0x18;
	//data16 = data16 & 0xFFE7;//3,4 Audio_2
	
	
		
	if( write_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_WRDEMOD,0x30, data16) != RM_OK )
	{
		printf("msp4450g_init() writeDemod(modus) failed\n");
		return RM_ERROR;
	}
	
	//return RM_OK;
	
	if( i2sMode & MSP4450G_I2SOUT_BIT_32 )
	{
		data16 = 0x0001;
	}
	else
	{
		data16 = 0x0000;
	}
	
	if( write_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_WRDEMOD,0x30, data16) != RM_OK )
	{
		printf("msp4450g_i2sout_configure() writeDemod(i2sconfig, 0x%x) failed\n", data16);
		return RM_ERROR;
	}
	
	return RM_OK;
}

//
//Input: SCART1 DSP
//-------------------------------------------------------------------------------
RMstatus msp4450g_scartdsp_SelectSource(struct RUA *pInstance, MSP4450G_SC_DSP_SRC src)
{
	RMuint32 data16;
	RMstatus s;
	
	s = read_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_RDDSP,0x0013, &data16);

	if( s != RM_OK )
	{
		printf("msp4450g_scart1dsp_SelectSource, msp4450g_readDsp(msp_dsreg_acbreg) failed %d\n", s);
		return RM_ERROR;
	}
	
	//  bit    5432 1098 7854 3210
	//  mask = 1111 1100 1101 1111
	//           xx xx00 xx0      
	//  sc_dsp_src_monoin= 0000 1000
	//  shift 5 to match bits
	data16 = data16 & 0xFCDF;
	data16 = data16 | (src << 5);
	
	s = write_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_WRDSP,0x0013, data16);
	if( s != RM_OK )
	{
		printf("msp4450g_scart1dsp_SelectSource, msp4450g_writeDsp(msp_dsreg_acbreg, data=0x%lx) failed %d\n", data16, s);
		return RM_ERROR;
	}
	
	return RM_OK;

}

RMstatus msp4450g_scartdsp_InputPrescale(struct RUA *pInstance,RMuint32 db)
{
	RMuint32 data16;
	RMstatus s;
	
	if( db > 0x7f)
		return RM_INVALID_PARAMETER;
	
	
	data16 = db << 8;	
	
	if( (s = write_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_WRDSP,0x000d, data16)) != RM_OK )
	{
		printf("msp4450g_scart1dsp_InputPrescale, msp4450g_writeDsp(msp_dsreg_scartdsp_prescale, data=0x%lx) failed %d\n", data16, s);
		return RM_ERROR;
	}
	
	return RM_OK;
}


RMstatus msp4450g_matrix_SelectMode(struct RUA *pInstance, MSP4450G_MATRIX m, MSP4450G_MATRIX_MODE md)
{
	RMuint32 data16;
	RMstatus s;
	
//	assert( pC != NULL );
	
	switch( m )
	{
	case matrix_main:
		//khuong add
	case matrix_headphone:
		//khuong end
	case matrix_sc1DA:
	case matrix_i2s:
	case matrix_qpeak:
		
		break;
	default:
		return RM_INVALID_PARAMETER;
	}
	
	switch( md )
	{
	case matrix_mode_soundAMono:
	case matrix_mode_soundBMono:
	case matrix_mode_stereo:
	case matrix_mode_mono:
	case matrix_mode_sumDiff:
	case matrix_mode_abXchange:
	case matrix_mode_phaseChangeB:
	case matrix_mode_phaseChangeA:
	case matrix_mode_onlyA:
	case matrix_mode_onlyB:
		break;
	default:
		return RM_INVALID_PARAMETER;
	}
	
	if( (s = read_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_RDDSP,m, &data16)) != RM_OK )
	{
		printf("msp4450g_matrix_SelectSource, msp4450g_readDsp(0x%x) failed %d\n", m, s);
		return RM_ERROR;
	}
	
	// source is bit 15:8
	data16 = data16 & 0xFF00;
	data16 = data16 | md;
	if( (s = write_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_WRDSP,m, data16)) != RM_OK )
	{
		printf("msp4450g_matrix_SelectSource, msp4450g_writeDsp(0x%x, data=0x%lx) failed %d\n", m, data16, s);
		return RM_ERROR;
	}
	
	return RM_OK;	
	
}



//
// MATRIX Operations
//-------------------------------------------------------------------------------
RMstatus msp4450g_matrix_SelectSource(struct RUA *pInstance, MSP4450G_MATRIX m, MSP4450G_MATRIX_SRC src)
{
	RMuint32 data16;
	RMstatus s;
	
	switch( m )
	{
	case matrix_main:
		//khuong add
	case matrix_headphone:	
		//khuong end
	case matrix_sc1DA:
	case matrix_i2s:
	case matrix_qpeak:
		break;
	default:
		return RM_INVALID_PARAMETER;
	}
	
	switch( src )
	{
	case matrix_src_demodFMAM:
	case matrix_src_stereoAB:
	case matrix_src_stereoA:
	case matrix_src_stereoB:
	case matrix_src_SCARTin:
	case matrix_src_I2S1:
	case matrix_src_I2S2:
		
		//khuong add
	case matrix_src_I2S3_c12:
	case matrix_src_I2S3_c34:
		//khuong end
		break;
	default:
		return RM_INVALID_PARAMETER;
	}
	
	
	if( (s = read_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_RDDSP,m, &data16)) != RM_OK )
	{
		printf("msp4450g_matrix_SelectSource, msp4450g_readDsp(0x%x) failed %d\n", m, s);
		return RM_ERROR;
	}
	
	// source is bit 15:8
	data16 = data16 & 0xFF;
	data16 = data16 | (src << 8);
	
	if( (s = write_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_WRDSP,m, data16)) != RM_OK )
	{
		printf("msp4450g_matrix_SelectSource, msp4450g_writeDsp(0x%x, data=0x%lx) failed %d\n", m, data16, s);
		return RM_ERROR;
	}
	
	return RM_OK;
	
	
}


RMstatus msp4450g_headphone_SetVolume(struct RUA *pInstance, RMuint8 db)
{
	RMuint32 data16;
	RMuint32 data16_old;
	read_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_RDDSP,0x0006, &data16_old);

	data16_old = (data16_old & 0x00FF);
	
	data16 = db << 8;
	data16 = data16 | data16_old;
	printf("data is written: 0x%lx",data16);//tractran
	
	//msp4450g_writeDsp(pC, msp_dsreg_vol_headphone, data16);
	write_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_WRDSP,0x06, data16);
	return RM_OK;
}

RMstatus msp4450g_headphone_IncreaseVolume(struct RUA *pInstance)
{
	RMuint32 data16;
	RMuint32 data16_old;	
	RMuint32 db;
	read_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_RDDSP,0x0006, &data16_old);
	db=data16_old>>8;
	if (db<=125) {
		db+=2;
		printf("vol = %ld db\n",db -0x73);
	}
	data16_old = (data16_old & 0x00FF);	
	data16 = db << 8;
	data16 = data16 | data16_old;
	printf("data is written: 0x%lx",data16);
	
	//msp4450g_writeDsp(pC, msp_dsreg_vol_headphone, data16);
	write_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_WRDSP,0x06, data16);
	return RM_OK;
}

RMstatus msp4450g_headphone_DecreaseVolume(struct RUA *pInstance)
{
	RMuint32 data16;
	RMuint32 data16_old;	
	RMuint32 db;
	read_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_RDDSP,0x0006, &data16_old);
	db=data16_old>>8;
	if (db>=2) {
		db-=2;
		printf("vol = %ld db\n",db -0x73);
	}
	data16_old = (data16_old & 0x00FF);	
	data16 = db << 8;
	data16 = data16 | data16_old;
	printf("data is written: 0x%lx",data16);
	
	//msp4450g_writeDsp(pC, msp_dsreg_vol_headphone, data16);
	write_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_WRDSP,0x06, data16);
	return RM_OK;
}
RMstatus msp4450g_loudspeaker_SetVolume(struct RUA *pInstance, RMuint8 db)
{
	RMuint32 data16;
	RMuint32 data16_old;
	read_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_RDDSP,0x0000, &data16_old);
	
	data16_old = (data16_old & 0x00FF);
	
	data16 = db << 8;
	data16 = data16 | data16_old;
	//msp4450g_writeDsp(pC, msp_dsreg_vol_main, data16);
	write_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_WRDSP,0x00, data16);
	//msp4450g_readDsp(pC,msp_dsreg_vol_main, &data16);
	/*
	read_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_RDDSP,0x00, &data16);
		printf("data is : 0x%lx",data16);*/
	
	return RM_OK;
}

RMstatus msp4450g_loudspeaker_IncreaseVolume(struct RUA *pInstance)
{
	RMuint32 data16;
	RMuint32 data16_old;
	RMuint8 db;
	
	read_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_RDDSP,0x0000, &data16_old);

	db=data16_old>>8;
	if (db<=125) {
		db+=2;
		printf("vol = %d db\n",db -0x73);
	}
	
	data16_old = (data16_old & 0x00FF);
	
	data16 = db << 8;
	data16 = data16 | data16_old;
	//msp4450g_writeDsp(pC, msp_dsreg_vol_main, data16);
	write_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_WRDSP,0x00, data16);
	//msp4450g_readDsp(pC,msp_dsreg_vol_main, &data16);
	/*
	read_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_RDDSP,0x00, &data16);
		printf("data is : 0x%lx",data16);*/
	
	return RM_OK;
}

RMstatus msp4450g_loudspeaker_DecreaseVolume(struct RUA *pInstance)
{
	RMuint32 data16;
	RMuint32 data16_old;
	RMuint8 db;
	
	read_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_RDDSP,0x0000, &data16_old);

	db=data16_old>>8;
	if (db>=2) {
		db-=2;
		printf("vol = %d db\n",db -0x73);
	}
	
	data16_old = (data16_old & 0x00FF);
	
	data16 = db << 8;
	data16 = data16 | data16_old;
	//msp4450g_writeDsp(pC, msp_dsreg_vol_main, data16);
	write_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_WRDSP,0x00, data16);
	//msp4450g_readDsp(pC,msp_dsreg_vol_main, &data16);
	/*
	read_i2c_dsp_msp4450g(pInstance,MSP4450G_DELAY,MSP4450G_I2C_ADDR,MSP4450G_SADDR_RDDSP,0x00, &data16);
		printf("data is : 0x%lx",data16);*/
	
	return RM_OK;
}

RMstatus msp4450g_InitScart1InHeadPhoneOut(struct RUA *pInstance)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;
	//Scart1 input to Headphone
	printf("**Scart1 input to headphone** \n");
	msp4450g_detect(pInstance);
	msp4450g_reset(pInstance);
	//Source select
	regAdd=0x0013;
	err=read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue=regValue & (~(0x19<<5)); //Scart1 input
	err=write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);

	//SCART Input Prescale : 0db gain
	regAdd=0x000d;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue=regValue | 0x1900; //Prescale Scart
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);

	
	//Matrix Mode for Headphone output : (0x09)

	regAdd=0x09;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue =regValue & 0xff00;
	regValue =regValue | 0x0020; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);

	//Matrix Source for SCART input :

	regAdd=0x09;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x02ff; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	regAdd=0x06;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x7300; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//msp4450g_headphone_SetVolume(pInstance,volume);
	

	return err;

}

RMstatus msp4450g_InitScart3InHeadPhoneOut(struct RUA *pInstance)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;
	//Scart1 input to Headphone
	printf("**Scart3 input and Out direct to headphone ** \n");
	msp4450g_detect(pInstance);
	msp4450g_reset(pInstance);
	//Source select
	regAdd=0x0013;
	err=read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue=regValue & (~(0x19<<5)); //Scart1 input	
	regValue=regValue | (0x18<<5);
	err=write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//SCART Input Prescale : 0db gain
	regAdd=0x000d;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue=regValue | 0x1900; //Prescale Scart
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	
	//Matrix Mode for Headphone output : (0x09)
	
	regAdd=0x09;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue =regValue & 0xff00;
	regValue =regValue | 0x0020; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//Matrix Source for SCART input :
	
	regAdd=0x09;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x02ff; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	

	
	
	return err;
	
}

RMstatus msp4450g_InitScart1InLoudSpeakerOut(struct RUA *pInstance)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;
 //Scart1 input to LoudSpeaker 
	
	printf("**Scart1 input to LoudSpeaker** \n");
	msp4450g_detect(pInstance);
	msp4450g_reset(pInstance);
	//Source select
	regAdd=0x0013;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue=regValue & (~(0x19<<5)); //Scart1 input
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//SCART Input Prescale : 0db gain
	regAdd=0x000d;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue=regValue | 0x1900; //Prescale Scart
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);		
	//Matrix Mode for LoudSpeaker output : (0x08)
	//regAdd=0x09; //Headphone
	regAdd=0x08; //LoudSpeaker
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue =regValue & 0xff00;
	regValue =regValue | 0x0020; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	//Matrix Source for SCART input :
	
	//regAdd=0x09; //HeadPhone
	regAdd=0x08;  //Loudspeaker
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x02ff; //SCART input
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//Set Volume for loudSpeaker :
	//regAdd=0x06; // Headphone
	regAdd=0x00; //Loudspeaker
/*
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x4D00; 
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
*/
	
	return err;
}

RMstatus msp4450g_InitScart3InLoudSpeakerOut(struct RUA *pInstance)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;
 //Scart1 input to LoudSpeaker 
	
	printf("**Scart3 input to LoudSpeaker** \n");
	msp4450g_detect(pInstance);
	msp4450g_reset(pInstance);
	//Source select
	regAdd=0x0013;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue=regValue & (~(0x19<<5)); //Scart1 input
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//SCART Input Prescale : 0db gain
	regAdd=0x000d;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue=regValue | 0x1900; //Prescale Scart
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);		
	//Matrix Mode for LoudSpeaker output : (0x08)
	//regAdd=0x09; //Headphone
	regAdd=0x08; //LoudSpeaker
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue =regValue & 0xff00;
	regValue =regValue | 0x0020; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	//Matrix Source for SCART input :
	
	//regAdd=0x09; //HeadPhone
	regAdd=0x08;  //Loudspeaker
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x02ff; //SCART input
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//Set Volume for loudSpeaker :
	//regAdd=0x06; // Headphone
	regAdd=0x00; //Loudspeaker
/*
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x4D00; 
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
*/
	
	return err;
}

RMstatus msp4450g_InitScart4InHeadPhoneOut(struct RUA *pInstance)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;
	//Scart1 input to Headphone
	printf("**Scart4 input to headphone** \n");
	msp4450g_detect(pInstance);
	msp4450g_reset(pInstance);
	//Source select
	regAdd=0x0013;
	err=read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	//regValue=regValue & (~(0x19<<5)); //Scart1 input
	regValue=regValue & (~(0x18<<5)); //Scart4 input
	regValue=regValue | (0x01<<5);
	err=write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//SCART Input Prescale : 0db gain
	regAdd=0x000d;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue=regValue | 0x1900; //Prescale Scart
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	
	//Matrix Mode for Headphone output : (0x09)
	
	regAdd=0x09;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue =regValue & 0xff00;
	regValue =regValue | 0x0020; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//Matrix Source for SCART input :
	
	regAdd=0x09;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x02ff; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
/*
	regAdd=0x06;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x7300; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
*/
	
	//msp4450g_headphone_SetVolume(pInstance,volume);
	
	
	return err;
	
}

RMstatus msp4450g_InitScart4InLoudSpeakerOut(struct RUA *pInstance)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;
	//Scart1 input to LoudSpeaker 
	
	printf("**Scart4 input to LoudSpeaker** \n");
	msp4450g_detect(pInstance);
	msp4450g_reset(pInstance);
	//Source select
	regAdd=0x0013;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	//regValue=regValue & (~(0x19<<5)); //Scart1 input
	regValue=regValue & (~(0x18<<5)); //Scart4 to DSP input xxxx00xx1
	regValue=regValue | (0x01<<5);
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//SCART Input Prescale : 0db gain
	regAdd=0x000d;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue=regValue | 0x1900; //Prescale Scart
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);		
	//Matrix Mode for LoudSpeaker output : (0x08)
	//regAdd=0x09; //Headphone
	regAdd=0x08; //LoudSpeaker
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue =regValue & 0xff00;
	regValue =regValue | 0x0020; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	//Matrix Source for SCART input :
	
	//regAdd=0x09; //HeadPhone
	regAdd=0x08;  //Loudspeaker
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x02ff; //SCART input
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//Set Volume for loudSpeaker :
	//regAdd=0x06; // Headphone
	regAdd=0x00; //Loudspeaker
/*
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x7300; 
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
*/
	
	return err;
}

RMstatus msp4450g_InitMonoInHeadPhoneOut(struct RUA *pInstance)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;
	
	//MONO input to Headphone
	printf("**Mono input to headphone** \n");
	msp4450g_detect(pInstance);
	msp4450g_reset(pInstance);
	//Source select
	regAdd=0x0013;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue=regValue & (~(0x19<<5)); //Scart1 input
	regValue=regValue | (0x08 <<5 ); //MONO input to DSP
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	//FM/AM Input Prescale : 
	regAdd=0x000e;
//	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
//	regValue = regValue & 0x00ff;
//	regValue=regValue | 0x2400; //100 kHz FM deviation
	//FM Matrix mode:

	regValue = 0x2403;
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);


	//Matrix Mode for Headphone output : (0x09)

	regAdd=0x09;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue =regValue & 0xff00;
	regValue =regValue | 0x0020; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);


	//Matrix Source for FM/AM mono signal input :

	regAdd=0x09;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x00ff; 
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//Set Volume for headphone :
/*
	regAdd=0x06;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);	
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x7300; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
*/
	//msp4450g_headphone_SetVolume(pInstance,volume);
	return err;
}

RMstatus msp4450g_applyStandardDetected(struct RUA *pInstance,RMuint32 modus)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;

	regAdd=0x007e;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDEMOD,regAdd,&regValue);
	switch(regValue) {
	case 0x0000:
		printf("Could not find a sound standard !\n");
		break;
	case 0x0003:
		printf("B/G-FM sound standard detected !\n");
		break;
	case 0x0008:
		printf("B/G-NICAM sound standard detected !\n");
		break;
	case 0x000a:
		printf("I sound standard detected !\n");
		break;
	case 0x0040:
		printf("FM-radio sound standard detected !\n");
		break;
	case 0x0002:		
	case 0x0020:		
	case 0x0030:
		{
			//modus[14,13] detected 4.5 MHz carrier is interpreted
			switch(modus & 0x6000) {
			case 0x00:
				printf("M-Korea standard detected !\n");
				break;
			case 0x01:
				printf("M-BTSC standard detected !\n");
				break;
			case 0x10:
				printf("M-Japan standard detected !\n");
				break;
			default:
				printf("Chroma carrier  !\n");
				break;
			}			
			break;
		}
	case 0x0009:
	case 0x0004:
	case 0x000b:
		{
			//modus[12] detected 6.5 MHz carrier is interpreted 
			switch(modus & 0x1000) {
			case 0x0:
				printf("L-(SECAM) standard detected !\n");
				break;
			case 0x1:
				printf("D/K1, D/K2, D/K3, or D/K NICAM standard detected !\n");
				break;
			default:
				break;
			}
			
			break;
		}	

	default:
		break;
	}
/*
	regValue=regValue & (~(0x19<<5)); //Scart1 input
	regValue=regValue | (0x08 <<5 ); //MONO input to DSP
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
*/
	

	return err;
}

RMstatus msp4450g_InitMonoInLoudSpeakerOut(struct RUA *pInstance)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;
	RMuint8 detected=0;
	
	//MONO input to Headphone
	printf("**Mono input to LoudSpeaker** \n");
	msp4450g_detect(pInstance);
	msp4450g_reset(pInstance);
	
	msp4450g_demod_init(pInstance,msp_45mhz_MBtsc, msp_65mhz_DK123Nicam, msp_digio_tristate, MSP4450G_I2SOUT_PIN_TRISTATE);
	msp4450g_demod_selectStandard(pInstance, msp_standard_autodetect);
	msp4450g_demod_InputFMamPrescale(pInstance, msp_fm100khz);

	{
		RMint32 loop;
		RMuint32 standard;
		
		printf("detecting standard... 5 seconds....");
		for( loop = 0; loop < 20; loop++)
		{
			if( RMFAILED(msp4450g_demod_getDetectedStandard(pInstance, &standard)) )
				printf("msp4450g_demod_getDetectedStandard() failed\n");
			
			if( standard == 0 )
			{
				printf("no standard detected\n");
				//break;
			}
			else if( standard <= 0x7FF )
			{
				printf("0x%lx detected\n", standard);
				detected=1;
				/*
				regAdd=0x0000;
								regValue=0x7300; //Volume
								write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,0x12,regAdd,regValue);
								*/
				//read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,0x13,regAdd,&regValue);

				

				break;
				
			}
			usleep(500);
		}
		/*
		if( loop == 5 )
		MPRINT(("no standard detected\n"));*/
		
	}


	//Source select
	regAdd=0x0013;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue=regValue & (~(0x19<<5)); //Scart1 input
	regValue=regValue | (0x08 <<5 ); //MONO input to DSP 
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);

	//FM/AM Input Prescale and Matrix mode

	if (!detected) {
		regAdd=0x000e;
		regValue = 0x2403;
		write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
		
	}else{
		//Matrix mode is set automaticaly. We only set Prescale :
		regAdd=0x000e;
		read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
		regValue = regValue & 0x00ff;
		regValue=regValue | 0x2400; //100 kHz FM deviation
		write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);				
	}
	
	
	//Matrix Mode for LoudSpeaker output : (0x08) [7:0]
	if (!detected) {
		regAdd=0x08;
		read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
		regValue =regValue & 0xff00;
		regValue =regValue | 0x0030; //Mono
		write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);				
	}else { // page 34 ... should be set to Stereo (transparent).
		regAdd=0x08;
		read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
		regValue =regValue & 0xff00;
		regValue =regValue | 0x0020; //Stereo (transparent)
		write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);				
	}

	
	//Matrix Source for LoudSpeaker output (0x08) [15:8] :
	
	regAdd=0x08;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x00ff; //FM/AM demodulated
//	regValue =regValue | 0x04ff; //FM/AM demodulated
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//Set Volume for headphone :
/*
	regAdd=0x00;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);	
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x4d00; 
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
*/
	//msp4450g_headphone_SetVolume(pInstance,volume);
	return err;
}

RMstatus msp4450g_InitScart1InI2sAndHeadPhoneOut(struct RUA *pInstance)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;
	//Scart1 input to I2s and headphone output 
	printf("**Scart1 input to headphone** \n");
	msp4450g_detect(pInstance);
	msp4450g_reset(pInstance);

	//Source select (Scart signal path)
	regAdd=0x0013;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue=regValue & (~(0x19<<5)); //Scart1 input
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);

	//SCART Input Prescale : 0db gain
	regAdd=0x000d;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue=regValue | 0x1900; //Prescale Scart
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//I2S inputs prescale (set to 0 db after RESET) 
	//msp4450g_reset(pInstance); 
	regAdd=0x0011; //I2S 3 Prescale
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue=regValue | 0x1000; //0 db gain and mod synchronous input mode
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);	

	regAdd=0x30;
	//regValue=0x30a9;
	//regValue=0x0024;
	msp4450g_writeDemod(pInstance,regAdd,regValue);
	
	regAdd=0x40;
	regValue=0x04fd;
	regValue=0x04f9;
	//regValue=0x04f1;
	

	//regValue=0x05fe;
	regValue=0x00;
	msp4450g_writeDemod(pInstance,regAdd,regValue);


	//Output Channels : 2 output channel : I2S, Headphone
	//Matrix Source for SCART  Input and output I2S :
	
	regAdd=0x0b; // I2S Output
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x02ff; //SCART Input
	//	regValue =regValue | 0x03ff; //Stereo A
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//Matrix Mode for I2S output channel: (0x09)
	
	regAdd=0x0b;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue =regValue & 0xff00;
	regValue =regValue | 0x0020; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);


	//Matrix Source for I2S 3 input and Headphone output:

	regAdd=0x09; //HeadPhone Output
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x07ff; //I2S 3 input channels 1 and 2
	//regValue =regValue | 0x08ff; //I2S 3 input channels 3 and 4
	//regValue =regValue | 0x09ff; //I2S 3 input channels 5 and 6
	//regValue =regValue | 0x0aff; //I2S 3 input channels 7 and 8

	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//Matrix Mode for Headphone output : (0x09)
	
	regAdd=0x09;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue =regValue & 0xff00;
	regValue =regValue | 0x0020; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//Set Volume for headphone :
	regAdd=0x06;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x7300; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//msp4450g_headphone_SetVolume(pInstance,volume);
	return err;
	
}

RMstatus msp4450g_InitScart1InI2sAndHeadPhoneOutSlaver(struct RUA *pInstance)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;
	//Scart1 input to I2s and headphone output 
	printf("**Scart1 input to headphone** \n");
	msp4450g_detect(pInstance);
	msp4450g_reset(pInstance);
	
	//Source select (Scart signal path)
	regAdd=0x0013;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue=regValue & (~(0x19<<5)); //Scart1 input
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//SCART Input Prescale : 0db gain
	regAdd=0x000d;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue=regValue | 0x1900; //Prescale Scart
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//I2S inputs prescale (set to 0 db after RESET) 
	//msp4450g_reset(pInstance); 
	regAdd=0x0011; //I2S 3 Prescale
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue=regValue | 0x1000; //0 db gain and mod synchronous input mode
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);	
	
	regAdd=0x30;
	//regValue=0x30a9;
	regValue=0x0024; //bit [5] = 0 
	msp4450g_writeDemod(pInstance,regAdd,regValue);
	
	//Output Channels : 2 output channel : I2S, Headphone
	//Matrix Source for SCART  Input and output I2S :
	
	regAdd=0x0b; // I2S Output
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x02ff; //SCART Input
	//	regValue =regValue | 0x03ff; //Stereo A
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//Matrix Mode for I2S output channel: (0x09)
	
	regAdd=0x0b;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue =regValue & 0xff00;
	regValue =regValue | 0x0020; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	
	//Matrix Source for I2S 3 input and Headphone output:
	
	regAdd=0x09; //HeadPhone Output
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x07ff; //I2S 3 input channels 1 and 2
	//regValue =regValue | 0x08ff; //I2S 3 input channels 3 and 4
	//regValue =regValue | 0x09ff; //I2S 3 input channels 5 and 6
	//regValue =regValue | 0x0aff; //I2S 3 input channels 7 and 8
	
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//Matrix Mode for Headphone output : (0x09)
	
	regAdd=0x09;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue =regValue & 0xff00;
	regValue =regValue | 0x0020; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//Set Volume for headphone :
	regAdd=0x06;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x7300; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//msp4450g_headphone_SetVolume(pInstance,volume);
	return err;
	
}


RMstatus msp4450g_InitScart1InI2sAndLoudSpeakerOut(struct RUA *pInstance)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;
	//Scart1 input to I2s and headphone output 
	printf("**Scart1 input to LoudSpeaker** \n");
	msp4450g_detect(pInstance);
	msp4450g_reset(pInstance);
	
	//Source select (Scart signal path)
	regAdd=0x0013;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue=regValue & (~(0x19<<5)); //Scart1 input
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//SCART Input Prescale : 0db gain
	regAdd=0x000d;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue=regValue | 0x1900; //Prescale Scart
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//I2S inputs prescale (set to 0 db after RESET) 
	//msp4450g_reset(pInstance); 

	regAdd=0x0016; //I2S 1 Prescale
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue=regValue | 0x1000; //0 db gain and mod synchronous input mode
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);	

	
	regAdd=0x30;
	regValue=0x30a9;
	//regValue=0x0024; //bit [5] = 1 //Slaver
	//regValue=0x0006; //bit [5] = 0 
	msp4450g_writeDemod(pInstance,regAdd,regValue);
	
	//Output Channels : 2 output channel : I2S, Headphone
	//Matrix Source for SCART  Input and output I2S :
	
	regAdd=0x0b; // I2S Output
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x02ff; //SCART Input
	//	regValue =regValue | 0x03ff; //Stereo A
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//Matrix Mode for I2S output channel: (0x09)
	
	regAdd=0x0b;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue =regValue & 0xff00;
	regValue =regValue | 0x0020; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	
	//Matrix Source for I2S 3 input and Headphone output:
	
	regAdd=0x08; //LoudSpeaker Output
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x07ff; //I2S 3 input channels 1 and 2
	//regValue =regValue | 0x08ff; //I2S 3 input channels 3 and 4
	//regValue =regValue | 0x09ff; //I2S 3 input channels 5 and 6
	//regValue =regValue | 0x0aff; //I2S 3 input channels 7 and 8
	
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//Matrix Mode  : 
	
	regAdd=0x08;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue =regValue & 0xff00;
	regValue =regValue | 0x0020; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//Set Volume 
	regAdd=0x00;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x7300; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//msp4450g_headphone_SetVolume(pInstance,volume);
	return err;
	
}

static inline RMstatus msp4450g_readDemod(struct RUA *pInstance, RMuint32 regAdd, RMuint32 *pData)
{
	return read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDEMOD,regAdd,pData);	
}

static RMstatus msp4450g_i2s_InputPrescale(struct RUA *pC ,RMuint16 i2s_port,RMuint16 data)
{
	RMuint32 temp;
	
	msp4450g_readDsp(pC,i2s_port,&temp);
	
	temp = temp & 0xFF;
	
	data = data & 0xFF;
	
	data = (data<<8)|temp;
	
	//khuong add
	data = data | 0x01 ; //asynchonous input mode for I2S3
	//khuong end
	printf("\n\t==0x0012,0x0011,0x%X==\n",data);//tractran
	write_i2c_dsp_msp4450g(pC,10,0x80>>1,MSP4450G_SADDR_WRDSP,i2s_port,data);	
	
	return RM_OK;
}

static RMstatus msp4450g_i2s_Configure(struct RUA * pC,RMuint32 modus,RMuint32 config)
{
	RMuint32 data16;
	RMuint32 data16_temp;
	assert(pC != NULL);
	
	msp4450g_readDemod(pC, msp_dmreg_modus, &data16);
	
	
	msp4450g_readDemod(pC, msp_dmreg_i2sconfig, &data16_temp);
	printf("\n\t ===data16_temp = 0x%lX===\n",data16_temp);//tractran
	
	
	
	data16 = data16 & 0xF000;
	modus = modus & 0xFFF;
	data16 = data16 | modus;
	
	
	data16 = 0x30A9 ;//khuong add , good
	
	printf("\n\t==0x0010,0x0030,0x%lX\n",data16);//tractran
	printf("\n\t==0x0010,0x0040,0x%lX\n",config);//tractran
	
	msp4450g_writeDemod(pC,msp_dmreg_modus,data16);
	
	
	msp4450g_writeDemod(pC, msp_dmreg_i2sconfig,config);
	
	return RM_OK;
	
}

RMstatus msp4450g_InitScart3InI2sAndLoudSpeakerOut(struct RUA *pInstance)
{
	RMstatus err=RM_OK;
	RMstatus s=RM_OK;
	
	MPRINT(("----------------------------------------------------------------------\n"));
	
	
	if( RMFAILED(s = msp4450g_detect(pInstance)) )
	{
		MPRINT(("msp4450g_detect() RM_OK:%c, RM_NOT_FOUND:%c\n", (s == RM_OK)?'y':'n', (s == RM_NOT_FOUND)?'y':'n'));
	}
	else
		MPRINT(("msp4450g_detect() detected\n"));
	
	MPRINT(("reset\n"));
	if( RMFAILED(s = msp4450g_reset(pInstance)) )
		MPRINT(("msp4450g_reset() FAILED %d\n", s));
	
	MPRINT(("Demod = DK123 Nicam/autodetect, fmdeviation = 100kHz, digio TRistate, I2sOUT active-master-32bit\n"));
	

	MPRINT(("SCART DSP = SC3 IN, prescale = 0db\n"));
	if( RMFAILED(s = msp4450g_scartdsp_SelectSource(pInstance, sc_dsp_src_sc3in)) )
		MPRINT(("msp4450g_scartdsp_SelectSource(sc_dsp_src_sc3in) FAILED %d\n", s));

	
	MPRINT(("MSPSCARTDSP_PRESCALE_0DB \n"));
	if( RMFAILED(s = msp4450g_scartdsp_InputPrescale(pInstance, MSPSCARTDSP_PRESCALE_0DB)) )
		MPRINT(("msp44505g_scartdsp_InputPrescale(0dB) FAILED %d\n", s));
	
	//
	
	// i2s in
	MPRINT(("MSPI2SDSP_PRESCALE_0DB \n"));
	if( RMFAILED(s = msp4450g_i2s_InputPrescale(pInstance,I2S_srcIN_PRESCALE,MSPSI2S_PRESCALE_0DB)) )
		MPRINT(("msp4450g_i2s_InputPrescale_kh(0dB) FAILED %d\n", s));	
	
	
	
	MPRINT(("route SC1 in to i2s out \n"));
	if (1) {
		//msp4450g_i2s_Configure(pInstance, 0x00B,0);
		msp4450g_i2s_Configure(pInstance, 0x01,0);
	}
	
	if( RMFAILED(s = msp4450g_matrix_SelectMode(pInstance, matrix_i2s, matrix_mode_stereo)) )
		MPRINT(("msp4450g_matrix_SelectMode(matrix_sc1DA, matrix_mode_stereo) FAILED %d\n", s));
	
	
	if( RMFAILED(s = msp4450g_matrix_SelectSource(pInstance, matrix_i2s ,matrix_src_SCARTin)))
		MPRINT(("mspmsp4450g_matrix_SelectSource(matrix_i2s ,matrix_src_SCARTin) FAILED %d\n", s));
	
	
	
	// route i2s in to loundspeaker out
	// matrix_src_I2S3_c12 :0x07
	
	MPRINT(("route i2s3-12 in to lounfspeaker \n"));
	if( RMFAILED(s = msp4450g_matrix_SelectMode(pInstance, matrix_main, matrix_mode_stereo)) )
		MPRINT(("msp4450g_matrix_SelectMode(matrix_main, matrix_mode_stereo) FAILED %d\n", s));
	
	
	if( RMFAILED(s = msp4450g_matrix_SelectSource(pInstance, matrix_main , matrix_src_I2S3_c12))) 
		MPRINT(("mspmsp4450g_matrix_SelectSource(matrix_main , matrix_src_I2S3_c12) FAILED %d\n", s))
		
		
		//if( RMFAILED(s = msp4450g_loudspeaker_SetVolume(&mspConfig, MSPVOL_0DB)))
		if( RMFAILED(s = msp4450g_loudspeaker_SetVolume(pInstance, MSPVOL_MID)))
			MPRINT(("msp4450g_loundspeaker_SetVolume(MSPVOL_0DB) FAILED %d\n", s));
		
		MPRINT(("SUBWOOFER  \n"));

	return err;
	
}

RMstatus msp4450g_InitScart3InI2sAndHeadPhoneOutSlaver(struct RUA *pInstance)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;
	//Scart1 input to I2s and headphone output 
	printf("**Scart3 input to headphone** \n");
	msp4450g_detect(pInstance);
	msp4450g_reset(pInstance);
	
	//Source select (Scart signal path)
	regAdd=0x0013;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue=regValue & (~(0x19<<5)); //Scart1 input
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//SCART Input Prescale : 0db gain
	regAdd=0x000d;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue=regValue | 0x1900; //Prescale Scart
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//I2S inputs prescale (set to 0 db after RESET) 
	//msp4450g_reset(pInstance); 
	regAdd=0x0011; //I2S 3 Prescale
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue=regValue | 0x1000; //0 db gain and mod synchronous input mode
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);	
	
	regAdd=0x30;
	//regValue=0x30a9;
	regValue=0x0024; //bit [5] = 0 
	msp4450g_writeDemod(pInstance,regAdd,regValue);
	
	//Output Channels : 2 output channel : I2S, Headphone
	//Matrix Source for SCART  Input and output I2S :
	
	regAdd=0x0b; // I2S Output
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x02ff; //SCART Input
	//	regValue =regValue | 0x03ff; //Stereo A
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//Matrix Mode for I2S output channel: (0x09)
	
	regAdd=0x0b;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue =regValue & 0xff00;
	regValue =regValue | 0x0020; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	
	//Matrix Source for I2S 3 input and Headphone output:
	
	regAdd=0x09; //HeadPhone Output
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x07ff; //I2S 3 input channels 1 and 2
	//regValue =regValue | 0x08ff; //I2S 3 input channels 3 and 4
	//regValue =regValue | 0x09ff; //I2S 3 input channels 5 and 6
	//regValue =regValue | 0x0aff; //I2S 3 input channels 7 and 8
	
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//Matrix Mode for Headphone output : (0x09)
	
	regAdd=0x09;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue =regValue & 0xff00;
	regValue =regValue | 0x0020; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//Set Volume for headphone :
	regAdd=0x06;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x7300; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//msp4450g_headphone_SetVolume(pInstance,volume);
	return err;
	
}

RMstatus msp4450g_InitI2s3InAndHeadPhoneOut(struct RUA *pInstance)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;
	//Scart1 input to I2s and headphone output 
	printf("**I2S3 input to headphone** \n");
	msp4450g_detect(pInstance);
	msp4450g_reset(pInstance);

	//I2S inputs prescale (set to 0 db after RESET) 
	//msp4450g_reset(pInstance); 
	regAdd=0x0011; //I2S 3 Prescale
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue=regValue | 0x1000; //0 db gain and mod synchronous input mode
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);


	regAdd=0x30;
	//regValue=0x30a9;
	regValue=0x0024; //bit [5] = 0 
	msp4450g_writeDemod(pInstance,regAdd,regValue);

	//Matrix Source for I2S 3 input and Headphone output:
	regAdd=0x09; //HeadPhone Output
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x0700; //I2S 3 input channels 1 and 2
	//regValue =regValue | 0x08ff; //I2S 3 input channels 3 and 4
	//regValue =regValue | 0x09ff; //I2S 3 input channels 5 and 6
	//regValue =regValue | 0x0aff; //I2S 3 input channels 7 and 8

	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//Matrix Mode for Headphone output : (0x09)
	
	regAdd=0x09;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue =regValue & 0xff00;
	regValue =regValue | 0x0020; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//Set Volume for headphone :
	regAdd=0x06;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x7300; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//msp4450g_headphone_SetVolume(pInstance,volume);
	return err;
	
}

RMstatus msp4450g_InitI2s3InAndLoudSpeakerOut(struct RUA *pInstance)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;
	//Scart1 input to I2s and headphone output 
	printf("**I2s3 input to LoudSpeaker** \n");
	msp4450g_detect(pInstance);
	msp4450g_reset(pInstance);
	/*** SCART Signal Path ***/
	/* Step 1 : Select analog input for the SCART baseband processing
	(SCART DSP Input Select) by means of the
	ACB register.  0x13 Page 45 */
	regAdd=0x0013;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	// high of digital output pin D_CTR_I/O_0 : (Note MODUS[3]=0)
	regValue = regValue | 0x4000; //bit [14] = 1
	regValue=regValue & (~(0x19<<5)); //Scart 1 to Dsp input
	//regValue=regValue | (0x01<<5); // Scart4 to DSP input.

	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	/* Step 2 :	Select the source for each analog SCART output
	(SCART Output Select) by means of the ACB register. */
	
	/*** Demodulator ***/
	/* Step 1 : Set MODUS register to the preferred mode and
	Sound IF input. */

	/* Step 2 : Choose preferred prescale (FM and NICAM) values.*/
	/* Step 3 : Write STANDARD SELECT register. */
	/* Step 4 : If Automatic Sound Select is not active:
	Choose FM matrix repeatedly according to the
	sound mode indicated in the STATUS register. */

	/*** SCART and I2S Inputs ***/
	/* Step 1 : Select preferred prescale for SCART.*/
	/* Step 2 : Select preferred prescale for I2S inputs
	(set to 0 dB after RESET).*/

	/*** Output Channels ***/
	/* Step 1 : Select the source channel and matrix for each output
	channel.*/
	/* Step 2 : Set audio baseband processing. */
	/* Step 3 : Select volume for each output channel. */
	
	//I2S inputs prescale (set to 0 db after RESET) 
	//msp4450g_reset(pInstance); 
	regAdd=0x0011; //I2S 3 Prescale
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x0000;
	regValue=regValue | 0x1000; //0 db gain and mod synchronous input mode
if (1) {

	regValue=regValue | 0x1001; //asynchronous input mode .
}
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	regAdd=0x30;
	//regValue=0x30a9;
	regValue=0x0024; //bit [5] = 0 
	if (1) {//slave
	
	msp4450g_writeDemod(pInstance,regAdd,regValue);
	}
	//Matrix Source for I2S 3 input and Loudspeaker output:	
	regAdd=0x08; //LoudSpeaker Output
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = regValue & 0x00ff;
	regValue =regValue | 0x07ff; //I2S 3 input channels 1 and 2
	//regValue =regValue | 0x0800; //I2S 3 input channels 3 and 4
	//regValue =regValue | 0x09ff; //I2S 3 input channels 5 and 6
	//regValue =regValue | 0x0aff; //I2S 3 input channels 7 and 8
	
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//Matrix Mode for LoudSpeaker output : (0x08)
	
	regAdd=0x08;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue =regValue & 0xff00;
	regValue =regValue | 0x0020; //Stereo(transparent mode)
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//Set Volume for headphone :
	regAdd=0x00;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	
	regValue = regValue & 0x00ff;
	//regValue =regValue | 0x7300; //Stereo(transparent mode)
	regValue =regValue | 0x0100;
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//msp4450g_headphone_SetVolume(pInstance,volume);
	return err;
	
}

RMstatus msp4450g_initScartInputThoughtI2s(struct RUA *pInstance, 
								 RMuint8 isMaster,  
								 RMuint8 scartInput ,
								 RMuint8 isMultiSampleInput,
								 RMuint8 howManyBit,
								 RMuint8 isLoudSpeakerOutput,
								 RMuint8 is32BitsOutput,
								 RMuint8 is8ChannelOutput
								 )
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;
	//Scart1 input to I2s and headphone output 
	printf("Scart %d input throught i2s and output to ",scartInput);
	if (isLoudSpeakerOutput) {
		printf("LoudSpeaker. ");
	}else
		printf("HeadPhone. ");
	msp4450g_detect(pInstance);
	msp4450g_reset(pInstance);

	/*
	 *	Config Demod
	 */
	regAdd=0x30;
	//regValue=0x30a9;
	regValue=0x00;
	if (!isMaster) {//slave	
		regValue= regValue | 0x0020;		
		printf("MSP is Slaver \n");
	}else {
		regValue= regValue & 0xffdf;		
		printf("MSP is Master \n");
	}
	printf("Write Demod 0x%lx value 0x%lx \n",regAdd,regValue);
	msp4450g_writeDemod(pInstance,regAdd,regValue);
	
	regAdd=0x40;
	regValue=0x00;
	switch(is8ChannelOutput) {
	case 0:
		regValue = regValue & 0xfc;
		switch(is32BitsOutput) {
		case 0:
			break;
		case 1:
			regValue = regValue | 0x01;
			break;
		default:
			break;
		}
		break;
		case 1: //Alway 32 bit output.
			regValue = regValue & 0xfd;
			regValue = regValue | 0x02;
			break;
		default:
			break;
	}
	
	switch(isMultiSampleInput) {
	case 0: //Two Sample 24 bit Input Mode. May be not to need specify how many bit.
		regValue=0xb1; // Or can use 0x01.
		regValue = regValue | 0x01;
		break;
	case 1:
		regValue = regValue | 0x0100; //bit[8]=1
		switch(howManyBit) {
		case 16:
			regValue =regValue | 0x70;
			break;
		case 18:
			regValue =regValue | 0x80;
			break;
		case 20:
			regValue =regValue | 0x90;
			break;
		case 22:
			regValue =regValue | 0xa0;
			break;
		case 24:
			regValue =regValue | 0xb0;
			break;
		case 26:
			regValue =regValue | 0xc0;
			break;
		case 28:
			regValue =regValue | 0xd0;
			break;
		case 30:
			regValue =regValue | 0xe0;
			break;
		case 32:
			regValue =regValue | 0xf0;
			break;
		default:
			break;
		}
		break;
		default:
			break;
	}
	
	//Multi Sample 32 bit Input Mode. Required specify how many bit.
	//	regValue=0x1f2;
	printf("Write Demod 0x%lx value 0x%lx \n",regAdd,regValue);
	
	msp4450g_writeDemod(pInstance,regAdd,regValue);

	/*** SCART Signal Path ***/
	/* Step 1 : Select analog input for the SCART baseband processing
	(SCART DSP Input Select) by means of the
	ACB register.  0x13 Page 45 */
	regAdd=0x0013;
	//read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue=0x00;
	// high of digital output pin D_CTR_I/O_0 : (Note MODUS[3]=0)
	/*
	switch(digitalOutputPin) {
		case 1:
			regValue = regValue & 0xbfff; //bit [14] = 0
			regValue = regValue | 0x8000; //bit [15] = 1
			break;
		default:
		case 0:
			regValue = regValue & 0x7fff; //bit [15] = 0
			regValue = regValue | 0x4000; //bit [14] = 1
			break;
		}*/
	
	
	regValue=regValue & (~(0x19<<5)); 

	switch(scartInput) {
	case 0: //Mono Input, (apply with tuner)
		regValue=regValue | 0x08<<5; //Scart 1 to Dsp input
		break;
	case 1:		
		break;
	case 2:
		regValue=regValue | 0x10<<5; //Scart 1 to Dsp input
		break;
	case 3:
		regValue=regValue | 0x18<<5; //Scart 3 to Dsp input
		break;
	case 4:
		regValue=regValue | 0x01<<5; //Scart 1 to Dsp input
		break;
	default://Mute
		printf("Mute DSP Input\n");
		regValue=regValue & (~(0x00<<5));
		break;
	}

	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	/* Step 2 :	Select the source for each analog SCART output
	(SCART Output Select) by means of the ACB register. 0x13 Page 45 */
	
	/*** Demodulator ***/
	/* Step 1 : Set MODUS register to the preferred mode and
	Sound IF input. */

	/* Step 2 : Choose preferred prescale (FM and NICAM) values.*/
	/* Step 3 : Write STANDARD SELECT register. */
	/* Step 4 : If Automatic Sound Select is not active:
	Choose FM matrix repeatedly according to the
	sound mode indicated in the STATUS register. */

	/*** SCART and I2S Inputs ***/
	/* Step 1 : Select preferred prescale for SCART. 0x0D*/
	regAdd=0x000d;
	regValue = 0x1900;
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	

	/* Step 2 : Select preferred prescale for I2S inputs	
	(set to 0 dB after RESET).*/
	

	regAdd=0x11; //I2S 3
	//read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);	
	regValue=0x1000;
	//regValue=regValue | 0x1000; //0 db gain and mod synchronous input mode
	printf("Write DSP 0x%lx value 0x%lx \n",regAdd,regValue);
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);		
		
/*
	regAdd=0x16; //I2S 1
	//read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);	
	regValue=0x1000;
	//regValue=regValue | 0x1000; //0 db gain and mod synchronous input mode
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);		
	
	regAdd=0x12; //I2S 2
	//read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);	
	regValue=0x1000;
	//regValue=regValue | 0x1000; //0 db gain and mod synchronous input mode
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);		
*/

	
	/*** Output Channels ***/
	/* Step 1 : Select the source channel and matrix for each output
	channel.*/
	/* Step 2 : Set audio baseband processing. */
	/* Step 3 : Select volume for each output channel. */
		
	

	
	regAdd=0x0b;
	regValue=0x0200;//Scart Input;
	regValue = regValue | 0x0020; // Stereo
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	

	if (isLoudSpeakerOutput) {
		regAdd=0x08; //LoudSpeaker Output	
	}else
		regAdd=0x09; //LoudSpeaker Output
	
	//read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	regValue = 0x00;
	//regValue = regValue & 0x00ff;
	regValue =regValue | 0x0700; //I2S 3 input channels 1 and 2
	//regValue =regValue | 0x0800; //I2S 3 input channels 3 and 4
	//regValue =regValue | 0x0900; //I2S 3 input channels 5 and 6
	//regValue =regValue | 0x0a00; //I2S 3 input channels 7 and 8
	

	regValue =regValue | 0x0020; //Stereo(transparent mode)
	
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	
	//Matrix Mode for LoudSpeaker output : (0x08)
/*

	//Set Volume for headphone :
	regAdd=0x00;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	
	regValue = regValue & 0x00ff;
	//regValue =regValue | 0x7300; //Stereo(transparent mode)
	regValue =regValue | 0x0100;
	write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
*/
	
	//msp4450g_headphone_SetVolume(pInstance,volume);
	return err;
			
}

static void printBinary(RMuint32 val,RMuint8 bits)
{
	RMuint8 i=0;
	RMuint32 tmp=0;
	for(i=1;i<=bits;i++)
	{
		tmp=val >> (bits-i);
		tmp=tmp & 0x01;
		printf("%ld",tmp);
	}
	
}

static RMstatus msp4450g_checkRegisterSet(struct RUA *pInstance)

{
	RMstatus err=RM_OK;
	RMuint32 regAdd;
	RMuint32 regValue;
	printf("\n--Demod Registers-------------------------\n");

	regAdd=0x7e;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDEMOD,regAdd,&regValue);
	printf("<Demod addr=\"%4lX\" value=\"%4lX\" ( dec = %5ld , bin = ",regAdd,regValue,regValue);
	printBinary(regValue,16);
	printf(")\\>\n");

	regAdd=0x200;
	read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDEMOD,regAdd,&regValue);
	printf("<Demod addr=\"%4lX\" value=\"%4lX\" ( dec = %5ld , bin = ",regAdd,regValue,regValue);
	printBinary(regValue,16);
	printf(")\\>\n");
	

	printf("\n--DSP Registers-------------------------\n");

//	printf("RMuint8 i2c_data[][2] = { \n");
	printf("<devicevalues name=\"AD9880 Family\">\n");
	for(regAdd=0x00;regAdd<=0x6c;regAdd++)
	{
		read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
		if (RMFAILED(err))
		{
			printf("Can't Read I2C \n");
			//return err;
		}
		printf("<DSP addr=\"%4lX\" value=\"%4lX\" ( dec = %5ld , bin = ",regAdd,regValue,regValue);
		printBinary(regValue,16);
		printf(")\\>\n");
		
	}
//	printf("};\n");
	printf("\n---END------------------------\n");

	


	return err;
}

static RMstatus msp4450g_WriteDSPRegisterHighBit(struct RUA *pInstance,										 
										 RMuint32 regAdd,
										 RMuint32 highBitValue)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0;
	err=read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	if (RMFAILED(err))
	{
		printf("Can't Read DSP regAdd = 0x%lx \n",regAdd);
		return err;
	}
	regValue=regValue & 0x00ff;
	regValue=regValue | ((highBitValue << 8) & 0xff00);
	err=write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	if (RMFAILED(err))
	{
		printf("Can't Write DSP regAdd = 0x%lx \n",regAdd);
		return err;
	}
	return err;
}

static RMstatus msp4450g_WriteDSPRegisterLowBit(struct RUA *pInstance,												 
												 RMuint32 regAdd,
												 RMuint32 lowBitValue)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0;
	err=read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
	if (RMFAILED(err))
	{
		printf("Can't Read DSP regAdd = 0x%lx \n",regAdd);
		return err;
	}
	regValue=regValue & 0xff00;
	regValue=regValue | (lowBitValue & 0x00ff);
	err=write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);
	if (RMFAILED(err))
	{
		printf("Can't Write DSP regAdd = 0x%lx \n",regAdd);
		return err;
	}
	return err;
}

static RMstatus msp4450g_TestDSPRegister(struct RUA *pInstance,
									RMuint32 regAdd,
									RMint8 isHightBit)
{
	
	RMstatus err=RM_OK;
	RMuint32 i=0;
	
	if (isHightBit) { //HIGH PART
		switch(regAdd) {
		case 0x08:
		case 0x09:
		case 0x0a:
		case 0x41:
		case 0x0b:
		case 0x0c:
			{
				RMuint32 highBitValue[]={0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,0x0b,0x0c,0x0d};
				for(i=0;i< (sizeof(highBitValue)/sizeof(RMuint32));i++)
				{
					if (msp4450g_WriteDSPRegisterHighBit(pInstance,regAdd,highBitValue[i])==RM_OK) {
						printf("0x%lx = 0x%lx\n",regAdd,highBitValue[i]);	
					}else
						break;					
					usleep(100000);					
				}				
			}
			break;
		case 0x0e://FM/AM Prescale
			{
				RMuint32 highBitValue[]={0x00,0x7f,0x48,0x30,0x24,0x18,0x13,0x30,0x14,0x20,0x1a,0x10,0x7c};				
				for(i=0;i< (sizeof(highBitValue)/sizeof(RMuint32));i++)
				{
					if (msp4450g_WriteDSPRegisterHighBit(pInstance,regAdd,highBitValue[i])==RM_OK) {
						printf("0x%lx = 0x%lx\n",regAdd,highBitValue[i]);	
					}else
						break;					
					usleep(100000);					
				}				
			}
			break;
		case 0x0d: //SCART Input Prescale
			{
				RMuint32 highBitValue[]={0x00,0x19,0x7f};
				for(i=0;i< (sizeof(highBitValue)/sizeof(RMuint32));i++)
				{
					if (msp4450g_WriteDSPRegisterHighBit(pInstance,regAdd,highBitValue[i])==RM_OK) {
						printf("0x%lx = 0x%lx\n",regAdd,highBitValue[i]);	
					}else
						break;					
					usleep(100000);					
				}				
			}
			break;
		case 0x11: //I2S3 Input Prescale
		case 0x12: //I2S2 Prescale
		case 0x16: //I2S1 Prescale
			{
				RMuint32 highBitValue[]={0x00,0x10,0x7f};
				for(i=0;i< (sizeof(highBitValue)/sizeof(RMuint32));i++)
				{
					if (msp4450g_WriteDSPRegisterHighBit(pInstance,regAdd,highBitValue[i])==RM_OK) {
						printf("0x%lx = 0x%lx\n",regAdd,highBitValue[i]);	
					}else
						break;					
					usleep(100000);					
				}				
			}
			break;
		
		default:
			printf("No support browse this DSP register !\n");
		}
		
	}else {  // LOW PART
		switch(regAdd) {
		case 0x08:
		case 0x09:
		case 0x0a:
		case 0x41:
		case 0x0b:
		case 0x0c:
			{
				RMuint32 lowBitValue[]={0x00,0x10,0x20,0x30};
				
				for(i=0;i< (sizeof(lowBitValue)/sizeof(RMuint32));i++)
				{
					if (msp4450g_WriteDSPRegisterLowBit(pInstance,regAdd,lowBitValue[i])==RM_OK) {
						printf("0x%lx = 0x%lx\n",regAdd,lowBitValue[i]);	
					}else
						break;					
					usleep(100000);					
				}
			}
			break;
		case 0x0e://FM/AM Matrix Modes
			{
				RMuint32 lowBitValue[]={0x00,0x01,0x02,0x03,0x04};
				
				for(i=0;i< (sizeof(lowBitValue)/sizeof(RMuint32));i++)
				{
					if (msp4450g_WriteDSPRegisterLowBit(pInstance,regAdd,lowBitValue[i])==RM_OK) {
						printf("0x%lx = 0x%lx\n",regAdd,lowBitValue[i]);	
					}else
						break;					
					usleep(100000);					
				}				
			}
			break;
		case 0x11: //Input mode for i2s3
			{
				RMuint32 lowBitValue[]={0x00,0x01};
				
				for(i=0;i< (sizeof(lowBitValue)/sizeof(RMuint32));i++)
				{
					if (msp4450g_WriteDSPRegisterLowBit(pInstance,regAdd,lowBitValue[i])==RM_OK) {
						printf("0x%lx = 0x%lx\n",regAdd,lowBitValue[i]);	
					}else
						break;					
					usleep(100000);					
				}				
			}

			break;
		default:
			printf("No support browse this DSP register !\n");
		}
		
	}

	return err;
}

static RMstatus msp4450g_TestDemodRegister(struct RUA *pInstance,
										 RMuint32 regAdd,
										 RMint8 isHightBit)
{
	
	RMstatus err=RM_OK;	
	RMuint32 i=0;
	
	if (isHightBit) { //HIGH PART
		switch(regAdd) {
		
		case 0x40: //I2S Config
			{				
				RMuint32 regValue=0; //Reset value
				for(i=0;i<= 255;i++)
				{
					regValue=regValue & 0x00ff;
					regValue=regValue | ((i << 8) & 0xff00);

					err=write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDEMOD,regAdd,regValue);
					if (err==RM_OK) {
						printf("0x%lx = 0x%lx\n",regAdd,regValue);	
					}else
						break;					
					usleep(100000);					
				}				
			}
			break;
		
		default:
			printf("No support browse this Demod register !\n");
		}
		
	}else {  // LOW PART
		switch(regAdd) {
		
		case 0x40: //I2S Config
			{
				RMuint32 regValue=0; //Reset value
				for(i=0;i<= 255;i++)
				{
					regValue=regValue & 0xff00;
					regValue=regValue | (i & 0x00ff);
					
					err=write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDEMOD,regAdd,regValue);
					if (err==RM_OK) {
						printf("0x%lx = 0x%lx\n",regAdd,regValue);	
					}else
						break;					
					usleep(100000);					
				}				
			}

			break;
		default:
			printf("No support browse this Demod register !\n");
		}
		
	}

	return err;
}

void msp4450g_Debug(struct RUA *pInstance, RMuint8 key)
{
	switch(key) {
	case 'w': //Write DSP
		{
			
			RMuint32 regAdd;
			RMuint32 regValue;
			printf("Write DSP (0x12) regAdd = ");scanf("%lx",&regAdd);
			printf("regValue = ");scanf("%lx",&regValue);
			write_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_WRDSP,regAdd,regValue);			
			printf("Write DSP to 0x%lx value 0x%lx\n",regAdd,regValue);
			break;
		}
	case 'W': //Write Demod
		{
			
			RMuint32 regAdd;
			RMuint32 regValue;
			printf("Write demod (0x10) regAdd = ");scanf("%lx",&regAdd);
			printf("regValue = ");scanf("%lx",&regValue);
			msp4450g_writeDemod(pInstance,regAdd,regValue);			
			printf("Write Demod to 0x%lx value 0x%lx\n",regAdd,regValue);
			break;
		}
	case 'r': //Read DSP
		{
			
			RMuint32 regAdd;
			RMuint32 regValue;
			printf("Read DSP (0x13) regAdd = ");scanf("%lx",&regAdd);							
			read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDSP,regAdd,&regValue);
			printf("Read DSP regAdd 0x%lx value 0x%lx\n",regAdd,regValue);
			break;
		}
	case 'R': //Read Demod
		{
			
			RMuint32 regAdd;
			RMuint32 regValue;
			printf("Read Demod (0x11) regAdd = ");scanf("%lx",&regAdd);							
			read_i2c_dsp_msp4450g(pInstance,10,0x80>>1,MSP4450G_SADDR_RDDEMOD,regAdd,&regValue);
			printf("Read Demod regAdd 0x%lx value 0x%lx\n",regAdd,regValue);
			break;
		}
	case 'a'://Show All DSP reg can read
		{
			
			msp4450g_checkRegisterSet(pInstance);			
			break;
		}	

	case '0'://Browse DSP reg
		{			
			RMuint32 regAdd;
			int isHiBit;
			printf("Browse DSP regAdd = ");scanf("%lx",&regAdd);			
			printf("Write isHibit = ");
			scanf("%d", &isHiBit);
			msp4450g_TestDSPRegister(pInstance,regAdd,(RMint8)isHiBit);
			break;
		}

	case '1': //Browse Demod reg
		{
			RMuint32 regAdd;
			int isHiBit;
			printf("Browse Demod regAdd = ");
			scanf("%lx",&regAdd);			
			printf("Write isHibit = ");
			scanf("%d",&isHiBit);
			msp4450g_TestDemodRegister(pInstance,regAdd,(RMint8)isHiBit);
			break;
		}


		
	default:
		break;
	}
}

