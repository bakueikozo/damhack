/*
 *
 * Copyright (c) Sigma Designs, Inc. 2006. All rights reserved.
 *
 */


/**
   @file psfdemux_common.h
   @brief common part of play_psfdemux
	
   @author Aurelia Popa-Radu
   @ingroup dccsamplecode
*/

#ifndef __PSFDEMUX_COMMON_H__
#define __PSFDEMUX_COMMON_H__


#define USING_LIBRMARIB 0
#define	ALLOW_LIBRMARIB	((USING_LIBRMARIB) && (EM86XX_MODE==EM86XX_MODEID_STANDALONE) && (EM86XX_CHIP == EM86XX_CHIPID_TANGO2) )


//#define WITH_TIME_SHIFT /* pat, pmt and video, audio, pcr are saved as TS in output 8 */
//#define RECORD_AV_TS    /* video, audio, are saved as TS in output 8 */


/**************************** compiling options ******************************/
#if ((EM86XX_CHIP==EM86XX_CHIPID_TANGO2) && (EM86XX_REVISION > 3))
#define USE_HW_FIXED_PID_ENTRY /* enable the PAT, CAT hardware filters instead of pid entries in the Pid Bank.*/
//#define USE_HW_PCR_PID_ENTRY /* enable the PCR hardware filter instead of pcr pid entries in the Pid Bank.*/
#else
/* EM8622 doesn't have PAT, CAT, PCR hw filters. Use the pid entries in the Pid Bank.*/
#endif


// identifier for the type of pid entry; it could be used also to identify the output where the data will be dumped
#define PAT_PID_ENTRY                0
#define PMT_PID_ENTRY                1
#define VIDEO_PID_ENTRY              2
#define AUDIO_PID_ENTRY              3
#define PCR_PID_ENTRY                4
#define CAT_PID_ENTRY                5
#define ECM0_PID_ENTRY               6
#define ECM1_PID_ENTRY               7
#define BIFS_PID_ENTRY              10
#define OD_PID_ENTRY                11
#define TTX_PID_ENTRY               12
#define RECIPHER_PID_ENTRY          13

#ifdef MULTI2_EIGHT_KEYS
#define DATA_ENTRY 9
#define DATA_OUT 13
#define DATA_SEC 8
#endif 

// output masks for transport stream - where the pid data is saved to.
#define TIME_SHIFT_FILE_NAME        "8.out" /* generic name for the recorded file*/
#define RECORD_OUTPUT_MASK           (1 << 8)   // output  8
#define REPLICATED_AUDIO_OUTPUT_MASK (1 << 9)   // output  9

#define RECIPHER_FILE_NAME        "recipher.ts" /* generic name for the recorded file*/


#if defined (WITH_TIME_SHIFT) /*pat, pmt and video, audio, pcr are saved as TS in output 8 */

#define REC_CNT                     32
#define MAX_RECORD_FILE_SIZE        0x80000000 /* 2GB */

#define PAT_OUTPUT_MASK	            ((1 << PAT_PID_ENTRY) | RECORD_OUTPUT_MASK)   // output  0, 8
#define	PMT_OUTPUT_MASK             ((1 << PMT_PID_ENTRY) | RECORD_OUTPUT_MASK)   // output  1, 8
#define	VIDEO_OUTPUT_MASK           ((1 << VIDEO_PID_ENTRY) | RECORD_OUTPUT_MASK) // output  2, 8
#define	AUDIO_OUTPUT_MASK           ((1 << AUDIO_PID_ENTRY) | REPLICATED_AUDIO_OUTPUT_MASK | RECORD_OUTPUT_MASK) // output  3, 9, 8
#define	PCR_OUTPUT_MASK	            ((1 << PCR_PID_ENTRY) | RECORD_OUTPUT_MASK)   // output  4, 8

#elif defined (RECORD_AV_TS) /* video, audio are saved as TS in output 8 */

#define REC_CNT                     32
#define MAX_RECORD_FILE_SIZE        0x08000000 /* 128MB */

#define PAT_OUTPUT_MASK	            (1 << PAT_PID_ENTRY)   // output  0
#define	PMT_OUTPUT_MASK             (1 << PMT_PID_ENTRY)   // output  1
#define	VIDEO_OUTPUT_MASK           ((1 << VIDEO_PID_ENTRY) | RECORD_OUTPUT_MASK) // output  2, 8
#define	AUDIO_OUTPUT_MASK           ((1 << AUDIO_PID_ENTRY) | REPLICATED_AUDIO_OUTPUT_MASK | RECORD_OUTPUT_MASK) // output  3, 9, 8
#define	PCR_OUTPUT_MASK	            (1 << PCR_PID_ENTRY)   // output  4

#else /* no record in output 8 */

#define REC_CNT                     0
#define MAX_RECORD_FILE_SIZE        0x08000000 /* 128MB */

#define PAT_OUTPUT_MASK	            (1 << PAT_PID_ENTRY)   // output  0
#define	PMT_OUTPUT_MASK             (1 << PMT_PID_ENTRY)   // output  1
#define	VIDEO_OUTPUT_MASK           (1 << VIDEO_PID_ENTRY) // output  2
#define	AUDIO_OUTPUT_MASK           ((1 << AUDIO_PID_ENTRY) | REPLICATED_AUDIO_OUTPUT_MASK) // output  3, 9
#define	PCR_OUTPUT_MASK	            (1 << PCR_PID_ENTRY)   // output  4

#endif

#define CAT_OUTPUT_MASK             (1 << CAT_PID_ENTRY)   // output  5
#define ECM0_OUTPUT_MASK            (1 << ECM0_PID_ENTRY)  // output  6
#define ECM1_OUTPUT_MASK            (1 << ECM1_PID_ENTRY)  // output  7

#define BIFS_OUTPUT_MASK            (1 << BIFS_PID_ENTRY)  // output 10
#define OD_OUTPUT_MASK              (1 << OD_PID_ENTRY)    // output 11
#define TTX_OUTPUT_MASK             (1 << TTX_PID_ENTRY)   // output 12
#define RECIPHER_OUTPUT_MASK        (1 << RECIPHER_PID_ENTRY) // output 13

// identifier of the entry in match section table
#define PAT_SECTION_ENTRY	0
#define	PMT_SECTION_ENTRY	1
#define	DSM_CC_SECTION_ENTRY	2
#define	CAT_SECTION_ENTRY	3
#define	ECM0_SECTION_ENTRY	4
#define	ECM1_SECTION_ENTRY	5
#define BIFS_SECTION_ENTRY      6
#define OD_SECTION_ENTRY        7

#define PAT_SECTION_MASK	(1 << PAT_SECTION_ENTRY)
#define	PMT_SECTION_MASK	(1 << PMT_SECTION_ENTRY)
#define	DSM_CC_SECTION_MASK	(1 << DSM_CC_SECTION_ENTRY)
#define	CAT_SECTION_MASK	(1 << CAT_SECTION_ENTRY)
#define	ECM0_SECTION_MASK	(1 << ECM0_SECTION_ENTRY)
#define	ECM1_SECTION_MASK	(1 << ECM1_SECTION_ENTRY)
#define BIFS_SECTION_MASK       (1 << BIFS_SECTION_ENTRY)
#define OD_SECTION_MASK         (1 << OD_SECTION_ENTRY)


#define MAX_DESCRIPTOR_NUMBER  5
#define MAX_STREAM_NUMBER      100
#define MAX_PROGRAM_NUMBER	30

#define LOG2_4k                 12
#define LOG2_32k                15

#define TS_FLAGS ( EMHWLIB_IGNORE_CONTINUITY_COUNTER_ERROR | EMHWLIB_IGNORE_ERROR_INDICATOR )


#if defined(WITH_AACS)
#define MAX_SP			6
#define PACKET_SIZE		192
#define AACS_IBC_CMD_MT		2
#define AACS_IBC_CMD_PLAY_ITEM  4
#define AACS_IBC_CMD_CACHE_CLIP	8
#endif

struct PATInfo_type {
	RMuint32 count;	/* number of programs in this PAT */
	RMuint16 program_number[MAX_PROGRAM_NUMBER];
	RMuint16 program_map_pid[MAX_PROGRAM_NUMBER];
	RMuint8  version_number_current_next_indicator; /* version_number on bit 5..1, current_next_indicator on bit 0 */
};

struct PMTInfo_type {
	RMuint32 count;	/* number of streams in this program */
	RMuint16 stream_type[MAX_STREAM_NUMBER];
	RMuint16 elementary_pid[MAX_STREAM_NUMBER];
	RMuint16 stream_descriptor[MAX_STREAM_NUMBER][MAX_DESCRIPTOR_NUMBER];
	RMuint32 descriptor_count[MAX_STREAM_NUMBER];	
	
	RMuint32 es_ecm_count;				/* number of es ECMs in this program */
	RMuint16 es_ecm_pid[MAX_STREAM_NUMBER];		/* for an elementary */
	RMuint16 es_ca_system_id[MAX_STREAM_NUMBER];	/* for an elementary */

	RMuint32 ecm_count;				/* for whole program */
	RMuint16 ecm_pid[MAX_STREAM_NUMBER];		/* for whole program */
	RMuint16 ca_system_id[MAX_STREAM_NUMBER];	/* for whole program */

	RMuint16 pcr_pid;
	RMuint16 program_number;


	RMuint8  version_number_current_next_indicator; /* version_number on bit 5..1, current_next_indicator on bit 0 */
	RMbool   update;
	
	RMbool   mp4;   /* dmb mp4 related fields */
	RMuint16 bifsID;
	RMuint16 bifsPid;
	RMuint16 odID;
	RMuint16 odPid;
	RMuint16 mp4VideoID;
	RMuint16 mp4VideoPid;
	RMuint16 mp4AudioID;
	RMuint16 mp4AudioPid;
};

struct ESPidList_type {
	RMuint32 index;	/* current index in the stream list */
	RMuint16 pcr_pid;
	RMuint32 count;	/* number of streams in this program */
	RMuint16 stream_type[MAX_STREAM_NUMBER];
	RMuint16 elementary_pid[MAX_STREAM_NUMBER];

	RMuint16 es_ecm_pid[MAX_STREAM_NUMBER];		/* for an elementary		*/
};

struct DataPidList_type {
	RMuint32 index;	// current entry,
	RMuint32 count;	// number of data streams in the list
	RMuint32 share_ecm;	// if 1, all data pid share the same ecm pid ecm_pids[0]
	RMuint16 data_pid_entries[MAX_STREAM_NUMBER]; // pid table entry number
	RMuint16 elementary_pids[MAX_STREAM_NUMBER]; // pid number for data streams
	RMuint16 ecm_pid_entries[MAX_STREAM_NUMBER]; // pid table entry number for associated ecm
	RMuint16 ecm_pids[MAX_STREAM_NUMBER];       // pid number for ecm streams
	RMuint16 cipher_indices[MAX_STREAM_NUMBER];  // which index in context->cipher_index[] to use
};

struct section_context_type {
	RMuint32 state;
	RMuint16 length;
	RMuint32 crc;
	RMbool private_section_with_crc;
};

#define VideoTypeToString(x) \
	(x == 1)?"mpeg 1 video":\
	(x == 2)?"mpeg 2 video":\
	(x == 0x10)?"mpeg 4 video":\
	(x == 0x1b)?"h264 video":\
	(x == 0xea)?"vc1 video":"unknown"

/*	(x == 0x80)?"wsnet  video":"unknown" */
	
#define AudioTypeToString(x) \
	(x == 3)?"mpeg 1 audio":\
	(x == 4)?"mpeg 2 audio":\
	(x == 6)?"dts    audio":\
	(x == 0x0f)?"aac adts audio":\
	(x == 0x80)?"hdmv_lpcm audio":\
	(x == 0x81)?"ac3    audio":\
	(x == 0xe6)?"wmats  audio":\
	(x == 0x82)?"dts    audio":\
	(x == 0x83)?"dolby lossless audio":\
	(x == 0x84)?"dolby digital plus audio":\
	(x == 0x85)?"dts hd audio":\
	(x == 0x11)?"latm":"unknown"

#define WAIT_KEY() \
{ \
	RMascii key; \
	fprintf(stderr, "press key to continue\n"); \
	while ( !(RMGetKeyNoWait(&key)) ); \
} \

#define WAIT_KEY_CLEANUP() \
{ \
	RMascii key; \
	fprintf(stderr, "press key to continue or quit\n"); \
	while ( !(RMGetKeyNoWait(&key)) ); \
	if( key == 'q' || key == 'Q' ) \
		goto cleanup; \
} \
		
typedef	void (*psfCallback) (RMuint8 *pBuffer1, RMuint32 size1, RMuint8 *pBuffer2, RMuint32 size2, RMstatus err, RMuint32 mask, void *context);



/* We have different  types of applications, selectable in command line:
   -app psf    = pid_filter_section,
   -app dvb    = dvbcsa_decryption,
   -app arib   = multi2_decryption,
   -app aes0   = aes_cbc_decryption,  encryption starting from start of TS payload
   -app aes1   = aes_ecb_decryption,  encryption starting from end of TS payload
   -app pes    = program_stream_parsing
*/
enum application_type {
	pid_filter_section,
	dvbcsa_decryption,
	multi2_decryption,
	aes_cbc_decryption,
	aes_ecb_decryption,
	aes_ofb_decryption,
	aes_ctr_decryption,
	aes_cfb_decryption,
	aes_nsa_decryption,
	program_stream_parsing,
	input_record,
};

struct dvb_csa_key {
	RMbool renew; /* TRUE when a new key is detected */
	RMuint32 key_byte_counter;
	enum EMhwlibScramblingBits scrambling;
	RMuint8 key[8];
	RMuint8 ecm_data[16]; /* storage for encrypted key from ecm_pid, needed to identify the clear key provided in table */
	RMuint8 ecm_entry; /* for ECM0 or ECM1 */
};

struct aes_key {
	RMbool renew; /* TRUE when a new key is detected */
	RMuint32 key_byte_counter;
	enum EMhwlibScramblingBits scrambling;
	RMuint8 key[16];
	RMuint8 iv[16];
	RMuint8 ecm_data[16]; /* storage for encrypted key from ecm_pid, needed to identify the clear key provided in table */
	RMuint8 ecm_entry; /* for ECM0 or ECM1 */
};

/* ############## AES_CBC_PRECIPHER TEST CODE BEGIN ############### */
struct aes_2keys_test {
	RMuint32 key_byte_counter;
	enum EMhwlibScramblingBits scrambling;
	RMuint8 key0[16];
	RMuint8 iv0[16];
	RMuint8 key1[16];
	RMuint8 iv1[16];
};
/* ############## AES_CBC_PRECIPHER CODE TEST END ################# */

struct dvb_arib_key {
	RMuint8		pair_key[16];
	RMuint8		sys_key[32];
	RMuint8		cbc_iv[8];
	RMuint8		data[16];
	RMuint32	cipher[64];
};

struct	CATInfo_type	 {	/* CAT packet	*/
	RMuint32	count;			/* number of CA provider & EMMs	*/
	RMuint16	ca_system_id[MAX_STREAM_NUMBER];
	RMuint16	emm_pid[MAX_STREAM_NUMBER];
	RMuint8		version_number_current_next_indicator; /* version_number on bit 5..1, current_next_indicator on bit 0 */
};


struct MatchSectionEntry_type {
	struct PSFMatchSection_type section_entry;
	RMuint32 index;     /* index allocated in section filter */
};


/* application specific structure based on struct EMhwlibPidEntryInfo_type */
struct PidEntry_type {
	RMuint16                  pid;            /* 13 bit value */
	enum EMhwlibPidInput_type input_type;
	RMuint32                  flags;          /* reserved bit field for ignore_error_indicator, ignore_continuity_counter, splicing_enable */
	RMbool                    enable;         /* if FALSE the pid entry is ignored */
	RMuint32                  output_mask[1]; /* 32 bit mask indicating the output buffers for this pid.*/
	RMuint32                  cipher_mask;    /* indicates what cipher is enabled - bit mask. Only on cipher supported. */
	RMuint32                  cipher_index[1];/* indicates what cipher is used */

	RMuint32                  type;           /* application use it to identify the pat, pmt, video, audio, pcr*/
	RMuint32                  index;          /* pid entry index allocated in pid filter */
};

/* application specific structure based on struct EMhwlibPesEntry_type */
struct PesEntry_type {
	RMuint8                   stream_id;
	RMuint8                   substream_id;
	enum EMhwlibPesInput_type input_type;
	RMbool                    enable;         /* if FALSE the pes entry is ignored */
	RMuint32                  output_mask[1]; /* 32 bit mask indicating the output buffers for this pid.*/
	RMuint32                  cipher_mask;    /* indicates what cipher is enabled - bit mask. Only on cipher supported. */
	RMuint32                  cipher_index[1];/* indicates what cipher is used */

	RMuint32                  index;     /* index allocated in pes filter */
};

/* Different choices for application to receive data from one DemuxOutput.
See more comments at the end of this file. */
enum receive_data_mode {
	receive_data_dma_backward_compatible,/* backward compatibility - the new RMDemuxOutputPropertyId_ReadBufferCompletion is not called */
	receive_data_dma_full_buffer,        /* complete the dma buffer when it is full */
	receive_data_dma_no_delay,           /* complete the dma buffer as soon as the microcode sends data */
	receive_data_dma_minimum_size,       /* complete the dma buffer when the buffer has more than the threshold value */
	receive_data_dma_exact_size,         /* complete the dma buffer when the buffer has exact size of the threshold value */
	receive_data_nodma_get_chunk256,     /* get directly from demux output data fifo */
	receive_data_nodma_rua_map           /* get directly from demux output data fifo */
};

/* application specific structure based on DemuxOutput module properties */
struct Output_type {
	enum EMhwlibDataType_type type;
	RMuint32		section_mask;    /* the hardware section filter does and-logic for all sections marked with 1 in section mask */
	
	/* number of buffers and size to allocate for DMA pool. Also in this application the DemuxOutput has bts_fifo_size = buffer_count*(1<<buffer_size_log2) */
	RMuint32		buffer_count;
	RMuint32		buffer_size_log2;
	
	/* if partial_read is TRUE the microcode will signal event after one section/pes_packet is completed;
	   if FALSE the event is signaled according to threshold's value */
	RMbool			partial_read;
	RMuint32		threshold;

	/* number of pts and inband entries for the pts and inband fifos of the DemuxOutput */
	RMuint32		pts_count;
	RMuint32		inband_count;

	RMuint32                consumer_module_id; /* if 0 data will be saved in file; if not 0, the output will be consumed by specified video/audio/spu consumer */
	psfCallback		callback;
	
	/* variables needed for the file handle, name and maximum size of the data to be saved from this DemuxOutput */
	RMascii			filename[20];
	FILE			*f_out;
	RMuint32		f_out_size;

	/* the module id of this DemuxOutput */
	RMuint32		demux_output_module_id;

	enum receive_data_mode  receive_mode; /* default receive_data_dma_backward_compatible */

	/* variables needed at close to free the memory allocated for DemuxOutput */
	RMuint32		BitstreamProtectedAddr;
	RMuint32		UnprotectedAddr;

	/* variable needed for getting the data from DemuxOutput fifo with DMA transfers */
	struct RUABufferPool	*pDma;

	/* variables needed for getting the data directly from DemuxOutput fifo, without DMA transfers */
	RMuint8			*pmapped_bts_fifo_base;
	RMuint32		fifo_container;
	RMuint32		bts_fifo_base;
	RMuint32		bts_fifo_size;

	FILE			*f_pts_out;
	FILE			*f_ibc_out;
};


/*
 * TODO --
 * what is the best content and name of this struct
 */
struct arib_key_band {

	/*
	 * If this key is valid?
	 */
	RMbool		new_key;

	/*
	 * If the cipher table already setup?
	 */
	RMbool		ciphertable_done;

	/*
	 * Index of CipherTable
	 */
	RMuint32	index_cipher_table;

	/*
	 * struct	DemuxTask_Multi2Key_type
	 * {
	 *  RMuint32	key_index;	// entry of Multi2Table
	 *  RMuint8x32 system_key;	// customer provide
	 *  RMuint8x32 data_key;	// customer provide
	 *  RMuint8x8	iv;		// customer provide
	 * }
	 */
	struct		DemuxTask_Multi2Key_type multi2_key;

	/*
	 * Specifies the scrambling bits of the packets affected by the key
	 */
	enum		EMhwlibScramblingBits scrambling;

	/*
	 * Specifies if offset_value is used, is relative or absolute
	 */
	enum		EMhwlibInbandOffset offset_control;

	/*
	 * Offset in bytes
	 */
	RMuint32	offset_value;

	/*
	 * CipherText of the multi2 key
	 */
	RMuint32	cipher_text[32];	/* 128bytes, 1024bits RSA	*/
};

			

enum change_program_type {
	change_program_with_stop_all = 0, /* This method works always but data is lost at stop time.
                                            It is not good for PVR applications. */
	change_program_with_av_stop,      /* This method works in case the video and/or audio change codec.
                                            The method is good for PVR applications - no data lost.
                                            In order to not have freezing or skipping the programs
                                            should have either contiguos PCR values or we need
                                            to to detect the pcr discontinuity.*/	
	change_program_without_stop,      /* This method works OK if the video and audio don't change codec.
                                            The method is good for PVR applications - no data lost.
                                            In order to not have freezing or skipping the programs
                                            should have either contiguos PCR values or we need
					    to to detect the pcr discontinuity.*/	
};

struct context_per_task {
	RMuint32		id;
	RMuint32		input_port;
	RMuint32		sync_lock;
	enum DemuxSourceType	SourceType;
	struct RUABufferPool	*pDma;      /* input dma pool */

	struct RUA		*pRUA;
	struct dcc_context	*dcc_info;

#if (ALLOW_LIBRMARIB)
	void 			*drm_handle;	/* Dynamic library pointer */
#endif
	
	RMuint32		demux_task; /* demux_task_moduleID */

	enum application_type	app_type;

	struct PesEntry_type    *pes_table;
	RMuint32		pes_table_count; /* number of system strams entries used in current application */
	struct PidEntry_type	*pid_table;
	RMuint32		pid_table_count; /* number of pids used in current application */
	struct Output_type	*output_table;
	RMuint32		output_table_count;/* number of outputs used in current application */
	struct MatchSectionEntry_type	*match_section_table;
	RMuint32		match_section_table_count;/* number of sections used in current application */
	
	RMuint32		cipher_index[8];/* max 8 cipher entries used in current application */
	RMuint32		cipher_count;   /* number of cipher entries used in current application */
	RMuint32		key_index[16];  /* max 16 key entries used in current application */
	RMuint32		key_count;      /* number of key entries used in current application */

	void			*pkey_table;	/* key table defined by this application */
	RMuint32		key_table_size;	/* number of keys in the table defined by this application */
	RMuint32		key_size;	/* size of the key */

	enum EMhwlibVideoCodec  vcodec;         /* storage needed to uninit/init after demux connect */
	RMbool                  enable_spu;     /* spu_hack needed because DCC interface has no independent spu support */
	
	RMfile			file;
	RMint64			fileSize;
	RMstatus		file_status;
	RMuint32		file_byte_counter;
	RMuint8			*buf;
	RMbool			buffer_used;
	RMbool			send_inband;
	RMuint32		nTimes;
	
	struct playback_cmdline *play_opt;
	struct display_cmdline  *disp_opt;
	struct video_cmdline    *video_opt;
	struct audio_cmdline    *audio_opt;
	struct demux_cmdline    *demux_opt;

	struct audio_cmdline    *audio_opt_table;
	RMuint32                audioInstances;

	RMuint32                wait_eos_state; /* used as state machine to detect when all EOS events per task came */
	RMuint32                ts_skip;
	RMbool			pat;            /* TRUE when a new PAT is found */
	RMbool			cat;
	RMbool			ecm;
	RMbool			pmt;            /* TRUE when a new PMT is found */
	enum change_program_type change_program_method; /* */
	RMuint32		pmt_index;      /* index of the current PMT in the pat_info */
	RMuint32		av_flags;       /* value used to mark if the application program the video audio from commnad line */
	RMuint16		video_pid;
	RMuint16                od_pid;         /* od pid number for DMB playback, needed by demux video data */
	RMuint16		pcr_pid;
	RMuint16		audio_pid;
	RMuint16		audio_subid;    /* needed for PES */
	RMuint16		spu_subid;      /* needed for PES parsing */
 	RMuint32		emm_pid;
 	RMuint32		ecm_pid[MAX_STREAM_NUMBER];
	RMuint16		teletext_pid;
#ifndef USE_HW_FIXED_PID_ENTRY
 	RMuint32		pat_pidentry;   /* index of the PAT pid entry allocated in hw pid table */
	RMuint32		cat_pidentry;	/* index of the CAT pid entry allocated in hw pid table	*/
#endif
	RMuint32		pmt_pidentry;   /* index of the PMT pid entry allocated in hw pid table */
	RMuint32		video_pidentry; /* index of the video pid entry allocated in hw pid table */
	RMuint32		audio_pidentry; /* index of the audio pid entry allocated in hw pid table */
	RMuint32		pcr_pidentry;   /* index of the PCR pid entry allocated in hw pid table */
 	RMuint32		ecm_pidentry[MAX_STREAM_NUMBER];	/* index of the ecm video entry allocated in hw pid table	*/
	RMuint32		teletext_pidentry; /* index of the ttx pid entry allocated in hw pid table */

	struct PATInfo_type     pat_info;
 	struct CATInfo_type	cat_info;
	struct PMTInfo_type     pmt_info[MAX_PROGRAM_NUMBER];
	struct ESPidList_type   VideoPidList;
	struct ESPidList_type   AudioPidList;
	struct ESPidList_type   TeletextPidList;
	struct DataPidList_type DataPidList;
	struct arib_key_band    arib_key_table[16];	/* EVEN/ODD key	*/
	RMuint8			prev_encrypted_key[16];
	RMuint32		recipher_mode;          /* mode=0 no recipher; mode >=1 recipher */ 
	RMuint32		recipher_cipher_entry;  /* entry in cipher table used for encryption */
	RMuint32		recipher_even_key_index;
	RMuint32		recipher_odd_key_index;
	RMuint8			recipher_even_key[32];
	RMuint8			recipher_odd_key[32];
	RMuint8			recipher_iv[32];
	RMuint32		recipher_xpu_key;  /* commandline key index for key stored in xpu */


#if (EM86XX_CHIP != EM86XX_CHIPID_TANGO2)
	RMuint8			current_ecm_key;
#endif

	FILE                    *stcd;         /* file used for stc_compensation */
#ifdef WITH_AACS
	RMuint32 		aacs_xtask_pid; /* PID of AACS xtask */
	RMuint32 		aacs_context;	/* Context for AACS xtask */
	RMuint32		mt_spn[MAX_SP]; /* SPN for all SPs */
	RMuint32 		mt_index;	/* Current IbC */
	RMuint32		mt_enabled;	/* Mt enabled */
	RMuint32		sk_enabled;	/* Segment Key enabled */
	RMuint32		sk_plid;		/* PlayList ID */
	RMuint32		sk_item;		/* PLayItem ID */
	RMuint32		clip_id;			/*Clip_id*/
	RMuint32		dir;				/*Dir*/
	RMuint32		cahce_clip_enabled; /*cache clip enabled*/
#endif /* WITH_AACS */


#ifdef MULTICAST
	RMsocket multicastSocket; /* used by play_psfdemux_multicast */
	RMuint32 nMulticastStreams;
	RMuint32 MulticastCurrent;
	enum AudioDecoder_Codec_type MulticastACodec[MAX_MULTICAST_STREAMS];
	enum VideoDecoder_Codec_type MulticastVCodec[MAX_MULTICAST_STREAMS];
	enum MPEG_Profile MulticastMPEGProfile[MAX_MULTICAST_STREAMS];
	char *MulticastAddress[MAX_MULTICAST_STREAMS];
	unsigned long MulticastPort[MAX_MULTICAST_STREAMS];
#endif

/* ############## AES_CBC_PRECIPHER CODE BEGIN ############ */
	RMbool dtcpip_streaming;
	RMbool test_aes_precipher;
/* ############## AES_CBC_PRECIPHER CODE END  ############# */

	RMbool monitor;

	RMuint64 readSpeed;
	RMuint64 readTime;
	RMuint32 tries;
	RMuint32 bitrate;
	RMuint64 meanBitrate;
	RMuint32 meanCount;

	RMbool isTrickMode;
	RMbool isIFrameMode;
	RMbool isRewinding;
	RMbool FirstSystemTime;

	RMbool sendVideoData;
	RMbool sendAudioData;

	RMbool sendVideoPTS;
	RMbool sendAudioPTS;

	struct timeval last;

	RMuint64 lastSTC;

	RMuint32 audioDemuxOutputIndex[MAX_AUDIO_DECODER_INSTANCES];
	RMuint32 videoDemuxOutputIndex;
	RMuint32 pcr_disc; /* threshold in ms for PCR discontinuity */
	enum EMhwlibTransportPriority_type audio_ts_priority;

	RMuint32		section_filter_based_on_new_version;

	RMuint32 prebuf_level;
	void **dmabuffer_array;
	RMuint32 dmabuffer_index;

	RMuint32 VCXOModuleID;

};


enum key_type {
	WRONG_KEY,
	PAIR_KEY,
	EVEN_KEY,
	ODD_KEY
};

enum key_setup_ways {
	INBAND_COMMAND,
	OUTBAND_COMMAND,
	XTASK_CLEAR,
	XTASK_CIPHER,
};


/****************************** prototypes ******************************/

RMstatus ParsePAT(RMuint8 *pBuffer1, RMuint32 size1, RMuint8 *pBuffer2, RMuint32 size2, struct PATInfo_type *out);
RMstatus ParsePMT(RMuint8 *pBuffer1, RMuint32 size1, RMuint8 *pBuffer2, RMuint32 size2, struct PMTInfo_type *out);
RMstatus ParseCAT(RMuint8 *pBuffer1, RMuint32 size1, RMuint8 *pBuffer2, RMuint32 size2, struct CATInfo_type *out);

void ParseCADescriptor(RMuint8 *p, RMuint16 *ca_sys_id, RMuint16 *ecm_pid);
void PATCallback(RMuint8 *pBuffer1, RMuint32 size1, RMuint8 *pBuffer2, RMuint32 size2, RMstatus err, RMuint32 mask, void *context_in);
void PMTCallback(RMuint8 *pBuffer1, RMuint32 size1, RMuint8 *pBuffer2, RMuint32 size2, RMstatus err, RMuint32 mask, void *context_in);
void CATCallback(RMuint8 *pBuffer1, RMuint32 size1, RMuint8 *pBuffer2, RMuint32	size2, RMstatus	err, RMuint32 mask, void *context_in);
void ECMCallback(RMuint8 *pBuffer1, RMuint32 size1, RMuint8 *pBuffer2, RMuint32 size2, RMstatus err, RMuint32 mask, void *context_in);
void TTXCallback(RMuint8 *pBuffer1, RMuint32 size1, RMuint8 *pBuffer2, RMuint32 size2, RMstatus err, RMuint32 mask, void *context_in);
 
RMuint16 GetEMMPid(struct context_per_task *context, RMuint16 ca_id);
RMstatus InitTableVariables(struct context_per_task *context);

RMstatus DvbKeyInband(struct context_per_task *context, RMuint8 ecm_entry, enum EMhwlibScramblingBits scrambling, RMuint8 *pkey, RMuint32 key_size);
RMstatus DvbKeyOutband(struct context_per_task *context, RMuint8 ecm_entry, enum EMhwlibScramblingBits scrambling, RMuint8 *pkey, RMuint32 key_size);
RMstatus DvbKeyXtask(struct context_per_task *context, RMuint8 ecm_entry, enum EMhwlibScramblingBits scrambling, RMuint8 *pkey);

RMstatus AESKeyInband(struct context_per_task *context, RMuint8 ecm_entry, enum EMhwlibScramblingBits scrambling, RMuint8 *pkey, RMuint8 *piv, RMuint32 key_size);
RMstatus AESKeyOutband(struct context_per_task *context, RMuint8 ecm_entry, enum EMhwlibScramblingBits scrambling, RMuint8 *pkey, RMuint8 *piv, RMuint32 key_size);

RMstatus Multi2KeyInband(struct context_per_task *context, RMuint32 index, enum key_type key_type);
RMstatus Multi2KeyOutband(struct context_per_task *context, RMuint32 index, enum key_type key_type);

/* ############## AES_CBC_PRECIPHER CODE BEGIN ############ */
RMstatus AESKeyPrecipherInband(struct RUA *Context_RUA,RMuint32 Context_demux_task,enum EMhwlibScramblingBits scrambling, RMuint8 *pkey, RMuint8 *piv, RMuint32 key_size,RMuint32 inband_state);
/* ############## AES_CBC_PRECIPHER CODE END ############## */

RMstatus Multi2KeyXtask(struct context_per_task *context, RMuint32 index, enum key_type	key_type);
RMstatus Multi2KeyXtaskEncrypted(struct context_per_task *context, RMuint32 index, enum key_type key_type);
RMstatus Multi2KeySetup(struct context_per_task *context, enum key_setup_ways ways, RMuint32 index, enum key_type key_type);

RMstatus InitKeyAndCipherTable(struct context_per_task *context);
RMstatus FreeKeyAndCipherTable(struct context_per_task *context);
RMstatus InitKeyAndCipherTableForRecipher(struct context_per_task *context);
RMstatus FreeKeyAndCipherTableForRecipher(struct context_per_task *context);

#ifdef USE_XPU_WRITE_KEY
#include "../rmdemuxwritekey/rmdemuxwritekeyapi.h"
RMstatus SetAesCbcOfbKeyThroughXPU(struct context_per_task *context, RMuint32 key_index, RMuint32 key_size );
RMstatus SetRecipherKeyThroughXPU(struct context_per_task *context, union Demux_Cipher_Key *pKey, enum EMhwlibCipher cipher_type, RMuint32 key_index, RMuint32 key_sizex );
#endif

#if 0
void DumpMulti2Key(struct DemuxTask_Multi2Key_type *multi2_key, RMuint32 c_index);
void PrivateSectionCallback(RMuint8 *pBuffer1, RMuint32 size1, RMuint8 *pBuffer2, RMuint32 size2, RMstatus err, void *context);
RMstatus DvbKeyXtaskEncrypted(struct context_per_task *context, enum EMhwlibScramblingBits scrambling, RMuint8 *pkey);
#endif


/*
 The properties related to receiving data from DemuxOutput modules are:
 - RMDemuxOutputPropertyId_Threshold affecting the demux microcode
 - RMGenericPropertyId_ReadBufferCompletion affecting the DMA transfer from
 DRAM output data fifo to the DMA buffers.
 If the property RMGenericPropertyID_ReadBufferCompletion is not called the DMA
transfers for DemuxOutput are set by default for backward compability:
    - EMhwlibReadBufferCompletionMode_NoDelay, if data type is "access unit", as
      PSI, DSM_CC, VPES, APES, RDI
    - EMhwlibReadBufferCompletionMode_Full, for all the other data types.
 
<--------------demux microcode---------><-----------DMA transfers-------------->
+-----------------------+---------------+------------------------+-------------+
|RMDemuxOutputPropertyId|  DemuxTask    |  RMGenericPropertyId_  |  DemuxTask  |
|       _Threshold      |   events      | _ReadBufferCompletion  |  DMA event  |
+-------------+---------+SOFT_IRQ_EVENT +------------+-----------+SOFT_IRQ_XFER|
|partial_read |threshold|    _DEMUX_    |  mode      | threshold |RECEIVE_EVENT|
+-------------+---------+---------------+------------+-----------+-------------+ 
|   FALSE     |         |               |            |           | event when  |
| (threshold  |         | FILLING when  | No_Delay   | Ignored   | size >= thr1|
| is used to  | thr1!=0 |  data >=thr1  | Full       | Ignored   | buffer full |
|   trigger   |         |               | ExactSize  | thr2      | size == thr2|
|   events)   |         |               | MinSize    | thr2      | size >= thr2|
+-------------+---------+---------------+------------------------+-------------+ 
|   TRUE      |         |  SECTION_END  |            |           | event when  |
| (only for   |         |   PES_END     | No_Delay   | Ignored   | size > 0    |
| filter of   | Ignored | when complete | Full       | Ignored   | buffer full |
|sections and |         | section or PES| ExactSize  | thr2      | size == thr2|
|PES packets) |         |  is written   | MinSize    | thr2      | size >= thr2|
+-------------+---------+---------------+------------------------+-------------+

Note. From demux point of view the "partial_read" has same meaning as "disable
threshold and send data and associated interrupt only when the output has a
complete section or PES packet."

*/


#endif // __PLAY_PSFDEMUX_COMMON_H__
