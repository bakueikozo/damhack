#ifndef _AD9380_H
#define _AD9380_H
#include <stdio.h>
#include "../rua/include/rua.h"
#include "../rua/include/rua_property.h"
#include "common.h"
#include "../emhwlib/include/emhwlib_videoformats.h"

#ifndef AUTODETECT_BY_EM
#define AUTODETECT_BY_EM 0
#endif

#define ad9380_invalid_standard EMhwlibTVStandard_Custom 

enum ad9380_yuv_type{
		//ad9380_yuv_ntsc=EMhwlibTVStandard_NTSC_M,
		ad9380_yuv_ntsc=EMhwlibTVStandard_ITU_Bt656_525,
		//ad9380_yuv_pal=EMhwlibTVStandard_PAL_M,
		//ad9380_yuv_pal=EMhwlibTVStandard_PAL_BG,
		ad9380_yuv_pal=EMhwlibTVStandard_ITU_Bt656_625,
		
		ad9380_yuv_480i=EMhwlibTVStandard_HDMI_480i59,
		ad9380_yuv_480p=EMhwlibTVStandard_480p59,
		//ad9380_yuv_480p=EMhwlibTVStandard_480p59_714,
		ad9380_yuv_576i=EMhwlibTVStandard_HDMI_576i50,
		ad9380_yuv_576p=EMhwlibTVStandard_576p50,
		ad9380_yuv_720p60=EMhwlibTVStandard_720p60,
//cur		ad9380_yuv_720p60=EMhwlibTVStandard_720p59,
		//ad9380_yuv_720p60=EMhwlibTVStandard_720p60, 
		//ad9380_yuv_720p60=EMhwlibTVStandard_720p50, 
		//ad9380_yuv_720p60=EMhwlibTVStandard_720p30, 			
		//ad9380_yuv_720p60=EMhwlibTVStandard_720p29, 
		//ad9380_yuv_720p60=EMhwlibTVStandard_720p25, 
		//ad9380_yuv_720p60=EMhwlibTVStandard_720p24, 
		//ad9380_yuv_720p60=EMhwlibTVStandard_720p23, 
		
		ad9380_yuv_1080i25=EMhwlibTVStandard_1080i50,
		ad9380_yuv_1080i30=EMhwlibTVStandard_1080i60,
		ad9380_yuv_1080p60=EMhwlibTVStandard_1080p60,
		
};

enum ad9380_vga_type{	
		//VGA CAPTURE 

		ad9380_vga_25mhz_60hz=EMhwlibTVStandard_VESA_640x480x60,
		ad9380_vga_25mhz_75hz=EMhwlibTVStandard_VESA_640x480x75, 
		ad9380_vga_25mhz_85hz=EMhwlibTVStandard_VESA_640x480x85, 
			
		ad9380_vga_40mhz_60hz=EMhwlibTVStandard_VESA_800x600x60,
		ad9380_vga_40mhz_75hz=EMhwlibTVStandard_VESA_800x600x75,
		ad9380_vga_40mhz_85hz=EMhwlibTVStandard_VESA_800x600x85,
		ad9380_vga_65mhz_60hz=EMhwlibTVStandard_VESA_1024x768x60,
		ad9380_vga_78mhz_75hz=EMhwlibTVStandard_VESA_1024x768x75,
		ad9380_vga_94mhz_85hz=EMhwlibTVStandard_VESA_1024x768x85,
		ad9380_vga_108mhz_60hz=EMhwlibTVStandard_VESA_1280x1024x60,
		ad9380_vga_135mhz_75hz=EMhwlibTVStandard_VESA_1280x1024x75,
		ad9380_vga_157mhz_85hz=EMhwlibTVStandard_VESA_1280x1024x85,  
		
		//ad9380_vga_25mhz_60hz=EMhwlibTVStandard_CVT_640x480x60,		
		//		ad9380_vga_40mhz_60hz=EMhwlibTVStandard_CVT_800x600x60,		
		//		ad9380_vga_65mhz_60hz=EMhwlibTVStandard_CVT_1024x768x60,
		//		ad9380_vga_78mhz_75hz=EMhwlibTVStandard_CVT_1024x768x75,		
		//		ad9380_vga_94mhz_85hz=EMhwlibTVStandard_CVT_1024x768x85, 				
		//		ad9380_vga_108mhz_60hz=EMhwlibTVStandard_CVT_1280x1024x60,
		//		ad9380_vga_135mhz_75hz=EMhwlibTVStandard_CVT_1280x1024x75,		
		//		ad9380_vga_157mhz_85hz=EMhwlibTVStandard_CVT_1280x1024x85,
		
//Ext
		ad9380_vga_1280_768=EMhwlibTVStandard_VESA_1280x768x60,

};
enum ad9380_hdmi_type{	
	ad9380_hdmi_480i= EMhwlibTVStandard_HDMI_480i60,
	ad9380_hdmi_480p= EMhwlibTVStandard_HDMI_480p60,
	ad9380_hdmi_480p59=EMhwlibTVStandard_HDMI_480p59, 	
	ad9380_hdmi_576p= EMhwlibTVStandard_HDMI_576p50,
	ad9380_hdmi_720p59= EMhwlibTVStandard_HDMI_720p59,
	ad9380_hdmi_720p60= EMhwlibTVStandard_HDMI_720p60,
	ad9380_hdmi_1080i59= EMhwlibTVStandard_HDMI_1080i59, 
	ad9380_hdmi_1080i60= EMhwlibTVStandard_HDMI_1080i60, 
	ad9380_hdmi_1080p59= EMhwlibTVStandard_HDMI_1080p59, 
	ad9380_hdmi_1080p60= EMhwlibTVStandard_HDMI_1080p60, 	
};

RMstatus ad9380_checkRegisterSet(struct RUA *pInstance,
								 RMuint32 dev ,
									RMuint8 delay
									);
RMstatus ad9380_getCaptureStandard(struct RUA *pInstance, 
								   RMuint32 numHsyncPerVsync,
								   enum EMhwlibTVStandard tvStandartSupportedList[],
								   RMuint8 sizeOftvStandartSupportedList,
								   enum EMhwlibTVStandard *newTVStandard);
RMstatus ad9380_setCaptureStandardYUV(
									  struct RUA *pInstance, 
									  RMuint8 dev, 
									  RMuint8 delay, enum EMhwlibTVStandard yuvId);

#if AUTODETECT_BY_EM
RMstatus ad9380_getCaptureStandardYUV(
									  struct RUA *pInstance, 
									  RMuint8 dev, 
									  RMuint8 delay,
									  RMuint32 numHsyncPerVsync,
									  enum EMhwlibTVStandard *yuvId);			

#else
RMstatus ad9380_getCaptureStandardYUV(
									  struct RUA *pInstance, 
									  RMuint8 dev, 
									  RMuint8 delay,
									  enum EMhwlibTVStandard *yuvId);
#endif
RMstatus ad9380_setAudioClockYUV(struct RUA *pInstance, RMuint8 dev, RMuint8 delay, RMuint8 isUseMCLKExternal);
RMstatus ad9380_setColorSpaceConverter(
										  struct RUA *pInstance,
										  RMuint8 dev, 
										  RMuint8 delay,
										  RMuint8 yuvId);
RMstatus ad9380_setColorSpaceConverter_test(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,RMuint8 tableId);
RMstatus ad9380_setColorSpaceConverterStatus(
												struct RUA *pInstance,
												RMuint8 dev, 
												RMuint8 delay,
												RMuint8 isEnable);
RMstatus ad9380_setAutoOffset(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,RMuint8 isHold);

RMstatus ad9380_isHdmiMode(struct RUA *pInstance,
						   RMuint8 dev, 
						   RMuint8 delay,
						   RMuint8 *isHDMIMode);
RMstatus ad9380_setMacrovisionOverSampleStatus(struct RUA *pInstance,
											   RMuint8 dev, 
											   RMuint8 delay,
											   RMuint8 isEnable);
RMstatus ad9380_isHdmiRGBAviInput(struct RUA *pInstance,
								  RMuint8 dev, 
								  RMuint8 delay,
								  RMuint8 *isRGB);
RMstatus ad9380_getHdmiCSCInput(struct RUA *pInstance,
								RMuint8 dev, 
								RMuint8 delay,
								RMuint8 *idCSC);
RMstatus ad9380_setHdmiCSCOutput(struct RUA *pInstance,
								 RMuint8 dev, 
								 RMuint8 delay,
								 RMuint8 idCSCInput);
#if AUTODETECT_BY_EM
RMstatus ad9380_getCaptureStandardHDMI(
									   struct RUA *pInstance, 
									   RMuint8 dev, 
									   RMuint8 delay,
									   RMuint32 numHsyncPerVsync,
									   enum EMhwlibTVStandard *hdmiId);
#else
RMstatus ad9380_getCaptureStandardHDMI_ByNumHsyncPerVsync(
														  struct RUA *pInstance, 
														  RMuint8 dev, 
														  RMuint8 delay,
														  RMuint32 numHsyncPerVsync,
														  enum EMhwlibTVStandard *hdmiId);
RMstatus ad9380_getCaptureStandardHDMI(
									   struct RUA *pInstance, 
									   RMuint8 dev, 
									   RMuint8 delay,
									   enum EMhwlibTVStandard *hdmiId);
#endif
RMstatus ad9380_setCaptureStandardHDMI(struct RUA *pInstance,
									   RMuint8 dev, 
									   RMuint8 delay,
									   enum EMhwlibTVStandard hdmiId);

#if AUTODETECT_BY_EM
RMstatus ad9380_autoUpdateCaptureStandardYUV(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,RMuint32 numHsyncPerVsync,enum EMhwlibTVStandard *cur_std);
#else
RMstatus ad9380_autoUpdateCaptureStandardYUV(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,enum EMhwlibTVStandard *cur_std);
#endif
#if	AUTODETECT_BY_EM
RMstatus ad9380_autoUpdateCaptureStandardVGA(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,RMuint32 numHsyncPerVsync,enum EMhwlibTVStandard *cur_std);
#else
RMstatus ad9380_autoUpdateCaptureStandardVGA(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,enum EMhwlibTVStandard *cur_std);
#endif
#if	AUTODETECT_BY_EM
RMstatus ad9380_autoUpdateCaptureStandardHDMI(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,RMuint32 numHsyncPerVsync,enum EMhwlibTVStandard *cur_std);
#else
RMstatus ad9380_autoUpdateCaptureStandardHDMI(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,enum EMhwlibTVStandard *cur_std);
#endif
RMstatus ad9380_getAudioFrequency(struct RUA *pInstance, 								  
								  RMuint8 dev, 
								  RMuint8 delay,
								  RMuint32 *pclk);

RMstatus ad9380_getCaptureStandardYUV_ByNumHsyncPerVsync(
														 struct RUA *pInstance, 
														 RMuint8 dev, 
														 RMuint8 delay,
														 RMuint32 numHsyncPerVsync,
														 enum EMhwlibTVStandard *yuvId);
RMstatus ad9380_getCaptureStandardVGA_ByNumHsyncPerVsync(
														 struct RUA *pInstance, 
														 RMuint8 dev, 
														 RMuint8 delay,
														 RMuint32 numHsyncPerVsync,
														 enum EMhwlibTVStandard *vgaId);
#if AUTODETECT_BY_EM
RMstatus ad9380_getCaptureStandardVGA(
									  struct RUA *pInstance, 
									  RMuint8 dev, 
									  RMuint8 delay,
									  RMuint32 numHsyncPerVsync,
									  enum EMhwlibTVStandard *vgaId);
#else

RMstatus ad9380_getCaptureStandardVGA(
									  struct RUA *pInstance, 
									  RMuint8 dev, 
									  RMuint8 delay,
									  enum EMhwlibTVStandard *vgaId);
#endif
RMstatus ad9380_setCaptureStandardVGA(
									  struct RUA *pInstance, 
									  RMuint8 dev, 
									  RMuint8 delay,
									  enum EMhwlibTVStandard vgaId);

RMstatus ad9380_setBrightness(struct RUA *pInstance, 								  
							  RMuint8 dev, 
							  RMuint8 delay,
							  RMint32 brightnessValue);
							  
RMstatus ad9380_getBrightness(struct RUA *pInstance, 								  
							  RMuint8 dev, 
							  RMuint8 delay,
							  RMint32 *brightnessValue);
RMstatus ad9380_isBrightnessValid(struct RUA *pInstance, 								  
								  RMuint8 dev, 
								  RMuint8 delay,
								  RMint32 brightnessValue);
RMstatus ad9380_isBrightnessAdjustValid(struct RUA *pInstance, 								  
								  RMuint8 dev, 
								  RMuint8 delay,
								  RMint32 brightnessValue);
RMstatus ad9380_setBrightnessAdjust(struct RUA *pInstance, 								  
									RMuint8 dev, 
									RMuint8 delay,
									RMint32 brightnessValue);
RMstatus ad9380_getBrightnessAdjust(struct RUA *pInstance, 								  
									RMuint8 dev, 
									RMuint8 delay,
									RMint32 *brightnessValue);
RMstatus ad9380_setContrast(struct RUA *pInstance, 								  
							RMuint8 dev, 
							RMuint8 delay,
							RMuint32 contrastValue);
RMstatus ad9380_getContrast(struct RUA *pInstance, 								  
							RMuint8 dev, 
							RMuint8 delay,
							RMuint32 *contrastValue);
RMstatus ad9380_isContrastValid(struct RUA *pInstance, 								  
							RMuint8 dev, 
							RMuint8 delay,
							RMuint32 contrastValue);
RMstatus ad9380_setCapturePort(
							   struct RUA *pInstance, 
							   RMuint8 dev, 
							   RMuint8 delay,
							   RMuint8 port);
RMstatus ad9380_PowerUp(struct RUA *pInstance, 								  
						RMuint8 dev, 
						RMuint8 delay);
RMstatus ad9380_PowerDown(struct RUA *pInstance, 								  
						  RMuint8 dev, 
						  RMuint8 delay);
void ad9380_Debug(struct 
				  RUA *pInstance, 								  
				  RMuint8 dev, 
				  RMuint8 delay,
				  RMuint8 key);
void ad9380_showMenu(void);
RMstatus ad9380_getAudioSampleRateHDMI(
									   struct RUA *pInstance, 
									   RMuint8 dev, 
									   RMuint8 delay,
									   RMuint32 *sampleRate);
RMstatus ad9380_getPacketDetect(struct RUA *pInstance,
								RMuint8 dev, 
								RMuint8 delay,
								RMuint32 *packetID);
RMstatus ad9380_ResetClockTermination(struct RUA *pInstance, 								  
									  RMuint8 dev, 
									  RMuint8 delay);
RMstatus ad9380_ResetOutput(struct RUA *pInstance, 								  
							RMuint8 dev, 
							RMuint8 delay);
RMstatus ad9380_threeStateOutput(struct RUA *pInstance, 								  
								 RMuint8 dev, 
								 RMuint8 delay,RMbool isThreeState);
#endif
