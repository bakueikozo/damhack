/*
 *
 * Copyright (c) Sigma Designs, Inc. 2002. All rights reserved.
 * Cleanup version
 */

/**
	@file dcc_demo.c
	@brief sample application to access the Mambo chip and test DMA transfers
	
	@author Rex Ching
   	@ingroup dccsamplecode
*/
#include <ctype.h>
#include "../samples/sample_os.h"

#define TMP_FIX_MIX_WEIGHT_KEYS  //Temporary fix the key pressing features of Weight Mixing
#define ALLOW_OS_CODE 1
#include "../dcc/include/dcc.h"
#include "../samples/common.h"

//--------WMA
#include "../rmasfdemux/include/rmasfdemuxapi.h"
#include "../rmasfdemux/include/wmdrm.h"
#include "../rmasfdemux/include/wmdrmopl.h"
#include "../rmwmaprodecoder/include/rmwmaprodefine.h"
#include "../rmwmaprodecoder/include/rmwmaprodecoderapi.h"
//-------WMA
//#define DBX
#include "../dcc/src/dcc_common.h"

#define GETBUFFER_TIMEOUT_US 0 //1000000
#define WAIT_EOS_TIMEOUT_US   10000   //Reduce from 1 min to 10000us to avoid silence at waiting EOS, 
									  //application will keep waiting even its timeout till an EOS event occured	
//#define WAIT_COMMAND_TIMEOUT_US 100000
#define DMA_BUFFER_SIZE_LOG2 17 //16 //15
#define DMA_BUFFER_COUNT     8 //16 //32

#define DMA_PCMX_BUFFER_SIZE_LOG2 17 //16 //15
#define DMA_PCMX_BUFFER_COUNT 2 //4 //8  


#define SENDDATA_TIMEOUT_US 1000000
#define REPACK_SIZE (4096)

#define AUDIO_FIFO_SIZE (1024*1024)
#define XFER_FIFO_COUNT (32)

#define AUDIO_PCMX_FIFO_SIZE (512*1024)
#define XFER_PCMX_FIFO_COUNT (32)


#define KEYFLAGS (SET_KEY_PLAYBACK | SET_KEY_AUDIO)

#define RM_DEVICES_STC 0x1
#define RM_DEVICES_AUDIO 0x4
#define MAX_WMAPRO_INFO 128

//PLAY MUL AUDIO STATUS
#define PMA_GETBUFFER_ERROR		0x00
#define PMA_SENDBUFFER_ERROR	0x01
#define PMA_SENDDATA_ERROR		0xff
#define PMA_ERROR				0xfe
#define PMA_OK					0x02
#define PMA_DECODER_PENDING		0x03
#define PMA_READFILE_ERROR		0x04
#define PMA_READFILE_EOF		0x05
#define PMA_READFILE_EOF_LOOP	0x06
#define PMA_EOS_PENDING			0x07
#define PMA_REDO				0x08	
#define PMA_QUIT				0x09

#define MAX_TASK_COUNT			2
static RMbool rptpcmx=FALSE;
#ifdef TMP_FIX_MIX_WEIGHT_KEYS
//RMuint32 mixing_weights[]={10,20,30,40,50,60,70,80,90,100};
struct AudioDecoder_MixerWeight_type cmdblock;
RMuint32 weight[MAX_TASK_COUNT][8]=
{
  {100,100,100,100,100,100,100,100},
  {100,100,100,100,100,100,100,100}  
};
#endif 

static struct RUAEvent e[MAX_TASK_COUNT];
static RMuint32 nEvents=0;
static RMuint32 pcmx_rcnt=0;
static RMbool	nEOS[MAX_TASK_COUNT]={0,0};
static RMuint32 nStatus[MAX_TASK_COUNT]={0x02,0x02};
static RMbool gMixingMode =FALSE;

//----------PMA protoypes
static void PMAAddEvents(struct RUAEvent e[], RMuint32* nEvents, RMuint32 mask, RMuint32 decoder);

#define ASF_DMA_BUFFER_SIZE_LOG2	15	// 32kB
#define ASF_DMA_BUFFER_COUNT		16	// 16*32kB ~= 512KB
#ifdef WMAPRO_V1
#define AUDIO_DMA_BUFFER_SIZE_LOG2	16		// 64kB
#define AUDIO_DMA_BUFFER_COUNT		2		// 2*64kB ~= 128KB
#else
#define AUDIO_DMA_BUFFER_SIZE_LOG2	17		// 128kB
#define AUDIO_DMA_BUFFER_COUNT		2		// 2*128kB ~= 256KB
#endif

#define VIDEO_XFER_FIFO_COUNT	(ASF_DMA_BUFFER_COUNT * (1<<ASF_DMA_BUFFER_SIZE_LOG2) / 2048)		// average video packet size = 2k
#define AUDIO_XFER_FIFO_COUNT	(AUDIO_DMA_BUFFER_COUNT * (1<<AUDIO_DMA_BUFFER_SIZE_LOG2) / 2048)	// average audio packet size = 2k

/* do NOT increase these values unless you have a reason to, otherwise, curacao wont be able to run due to lack of memory */
#define ASF_VIDEO_FIFO_SIZE		(3*1024*1024)	// 3s @ 1MB/s
#define ASF_AUDIO_FIFO_SIZE		(5*1024*1024)	// 5s @ 1MB/s 
#define ASF_KEYFLAGS (SET_KEY_DISPLAY | SET_KEY_PLAYBACK | SET_KEY_AUDIO | SET_KEY_DEBUG | SET_KEY_SPI)

/*
 * Globals, should be explicitely initialized in init_globals
 */
static RMbool bypass_drm;

static RMuint32 audioStreams;
static RMuint32 audioStreamTable[10];


#define PAYLOADDBG DISABLE
#define TRICKDBG DISABLE
#define SENDDBG DISABLE
#define WMAPRODBG	DISABLE

#define MAX_INDEX_NUMBER 5
#define INDEX_BUFFER_SIZE (200 * 1024)

typedef enum 
{
	RMasfIFrameFSM_Disabled = 0,
	RMasfIFrameFSM_Init,
	RMasfIFrameFSM_WaitIFrameMONChange,
	RMasfIFrameFSM_SkipNext
}RMasfIFrameFSMstates;

#define RM_DEVICES_VIDEO 0x2
#define RM_STREAM_VIDEO 0x1
#define RM_STREAM_AUDIO 0x2
#define RM_SKIP_TO_RESYNC 0x1

#define MAX_NUMBER_OF_AUDIO_STREAMS 16

#define RMAUDIO_4_28_CONVERT (1<<28)
struct wmapro_buffer_info {
	RMbool new_buffer;
	RMuint8 *ptr;
	RMuint32 size;
	struct emhwlib_info Info;
	RMuint32 Stream_Number;
	RMuint32 Media_Object_Number;
	RMuint32 fSendPTS;
	void *pBuffer;
};

struct asf_context 
{
	struct RUA *pRUA;
	struct RUABufferPool *pDMA;
	struct RUABufferPool *pDMAuncompressed;
	unsigned char *UncompressedBuffer;
	unsigned char *SequenceHeaderBuffer;
	RMbool FirstSystemTimeStamp;
	struct dcc_context *dcc_info;
	RMuint32 video_stream_index;
	RMuint32 audio_stream_index;
	RMuint32 cmd;
	RMbool SendVideoData;
	RMuint32 prev_video_media_object_number;
	RMuint32 video_frame_counter;
	RMuint32 VideoByteCounter;
	RMbool SendVideoPts;
	RMuint32 video_last_pts;	// used for video hack
	RMuint32 video_vop_tir;

	RMbool SendAudioData;
	RMuint32 prev_audio_media_object_number;
	RMuint32 audio_frame_counter;
	RMuint32 AudioByteCounter;
	RMbool SendAudioPts;
 	RMuint32 audio_vop_tir;
	RMuint32 start_ms; 	

	ExternWMAProVdecoder vDecoder;

	ExternalRMASFDemux vASFDemux;

	RMbool isIFrameMode;
	RMbool isTrickMode;
	RMint32 IFrameSize;
	RMbool SeekAudio;
	RMbool SeekVideo;
	RMuint32 PrevAudioMON;
	RMuint32 PrevVideoMON;


	struct AudioDecoder_WMAParameters_type wma_params;	
	RMuint32 WMAPROBitsPacketLength;

	RMfile f_bitstream;
	RMbool video_decoder_initialized;
	RMbool audio_decoder_initialized;

	RMuint32 Compression_ID;
	struct VideoDecoder_WMV9VSProp_type wmv9_prop;
	struct VideoDecoder_DIVX3VSProp_type divx3_prop;

	RMuint32 asf_packetSize;
	RMuint64 asf_Header_Object_Size;

	RMasfIFrameFSMstates IFrameFSMState;
	RMuint32 inband_aspect_ratio_x;
	RMuint32 inband_aspect_ratio_y;
	RMuint32 save_inband_aspect_ratio_y;
	RMuint32 save_inband_aspect_ratio_x;	

	RMint32 drmError;
	RMbool isContentEncrypted;
	RMbool unsupported_video;

	struct SurfaceAspectRatio_type InBandAspectRatioParams;
	RMbool setAspectRatio;
	RMuint64 Preroll;
	RMbool PrerollSET;
	RMuint64 Duration;
	RMbool ignoreCallback; 
	RMuint64 CurrentDisplayPTS;
	RMint32 IFrameDirection;
	RMbool VideoStreamFound;
	RMbool AudioStreamFound;
	RMbool isAudioOnlyFile;
	RMuint64 lastSTC;
	RMuint64 accurateAudioSeekTo;
	RMbool IgnoreAudio;

	RMuint32 Video_Codec_Specific_Data_Received;
	RMuint32 Audio_Codec_Specific_Data_Received;

	RMuint32 ContiguousVideoLength;
	RMuint32 ContiguousAudioLength;
	RMuint64 video_time_start;
	RMuint64 video_time_end;
	RMuint64 audio_time_start;
	RMuint64 audio_time_end;
	RMuint64 video_time_stamp;
	RMuint64 audio_time_stamp;
	RMint32 min_diff;
	RMint32 max_diff;
	RMuint32 packet_counter;
	RMuint32 DemuxProgramID;
	RMuint32 STCID;
	struct RMfifo *wmapro_fifo;
	RMuint64 prev_Audio_Presentaion_time;
	RMbool compressed_audio;
};
/* prototypes */
static RMstatus asfStop(struct asf_context *pSendContext, RMuint32 devices);
static RMstatus asfPlay(struct asf_context * pSendContext, RMuint32 devices, enum DCCVideoPlayCommand mode);
static RMstatus setup_audio_decoder(struct asf_context *pSendContext);

struct priv_cmdline 
{
	RMuint32 dummy;
};

static struct audio_cmdline *asf_audio_opt;
static struct playback_cmdline  *asf_play_opt;
static struct priv_cmdline priv_opt;
	


static RMstatus init_private_options(struct priv_cmdline *options)
{
	return RM_OK;
}


static void print_Audio_Stream_Properties
(
 void *context,
 unsigned char Stream_Number, unsigned short Codec_ID,
 unsigned short Number_of_Channels, unsigned long Samples_Per_Second,
 unsigned long Average_Number_of_Bytes_Per_Second,
 unsigned short Block_Alignment, unsigned short Bits_Per_Sample,
 unsigned char *Codec_Specific_Data, unsigned long Partial_Codec_Specific_Data_Size, unsigned long Codec_Specific_Data_Size
 ) {
	struct asf_context *pSendContext = (struct asf_context *) context;
	struct AudioDecoder_WMAParameters_type *wma_params = &(pSendContext->wma_params);
	RMstatus status;

	pSendContext->WMAPROBitsPacketLength = 0;
	pSendContext->Audio_Codec_Specific_Data_Received += Partial_Codec_Specific_Data_Size;

	RMDBGLOG((ENABLE,"print_Audio_Stream_Properties %lu, %lu, %lu\n", 
				pSendContext->Audio_Codec_Specific_Data_Received, 
				Partial_Codec_Specific_Data_Size, 
				Codec_Specific_Data_Size));

	if(Partial_Codec_Specific_Data_Size == Codec_Specific_Data_Size)
		pSendContext->Audio_Codec_Specific_Data_Received = Codec_Specific_Data_Size;
	
	if(pSendContext->Audio_Codec_Specific_Data_Received == Codec_Specific_Data_Size) {

		audioStreamTable[audioStreams++] = Stream_Number;

		RMDBGLOG((ENABLE, "Stream #%hu - Audio - \n", Stream_Number));
		RMDBGLOG((ENABLE, "%hu channel(s), %lu samples/second, %hu bits/sample\n",
			  Number_of_Channels, Samples_Per_Second, Bits_Per_Sample));
		RMDBGLOG((ENABLE, "    Bitrate: %lu bit/s, Block size is 0x%04x bytes [0x%05x bits]\n", 
			  Average_Number_of_Bytes_Per_Second * 8, Block_Alignment, Block_Alignment * 8));

		wma_params->VersionNumber = Codec_ID;
		wma_params->SamplingFrequency = Samples_Per_Second;
		wma_params->NumberOfChannels = Number_of_Channels;
		wma_params->Bitrate = Average_Number_of_Bytes_Per_Second * 8;
		wma_params->PacketSize = Block_Alignment * 8;
		wma_params->EncoderOptions = 0;
		wma_params->BitsPerSample = Bits_Per_Sample;
		wma_params->WMAProValidBitsPerSample = Bits_Per_Sample;
		wma_params->WMAProChannelMask = 0;
		wma_params->WMAProVersionNumber = 0;
		wma_params->OutputChannels = asf_audio_opt->WmaParams.OutputChannels;

		if (Codec_ID == 0x160) { // WMA Audio Version 1
			RMDBGLOG((ENABLE, "error, codec WMA Audio Version 1 not supported, disable audio\n"));
			pSendContext->SendAudioData = FALSE;
			return;
		}
			

		// Audio Codec Type Specific data in ASF
		if ( (Codec_ID == 0x161) || // WMA Audio Version 2
		     (Codec_ID == 0x7A21) ||
		     (Codec_ID == 0x7A22) ) {
			if (10 == Codec_Specific_Data_Size) { // 4 + 2 + 4
				RMuint32      dwSamplesPerBlock;
				RMuint16      wEncodeOptions;
				RMuint32      dwSuperBlockAlign;
				
				dwSamplesPerBlock = 
					  (((RMuint32) Codec_Specific_Data[3]) << 24)
					+ (((RMuint32) Codec_Specific_Data[2]) << 16)
					+ (((RMuint32) Codec_Specific_Data[1]) << 8)
					+  ((RMuint32) Codec_Specific_Data[0]);
				wEncodeOptions = 
					+ (((RMuint16) Codec_Specific_Data[5]) << 8)
					+  ((RMuint16) Codec_Specific_Data[4]);
				dwSuperBlockAlign = 
					  (((RMuint32) Codec_Specific_Data[9]) << 24)
					+ (((RMuint32) Codec_Specific_Data[8]) << 16)
					+ (((RMuint32) Codec_Specific_Data[7]) << 8)
					+  ((RMuint32) Codec_Specific_Data[6]);

				RMDBGLOG((ENABLE, 
					"    Audio codec ID: %04x,\n"
					"    Bits per block: 0x%04x\n"
                                        "    Encode option: 0x%04x \n",
					  (int) Codec_ID, (int) dwSamplesPerBlock, (int) wEncodeOptions));

				wma_params->EncoderOptions = wEncodeOptions;
			}
			else {
				RMDBGLOG((ENABLE, "Error: audio specific data has invalid size (%d)\n",
					  (int) Codec_Specific_Data_Size));
			}
		}

		// WMA pro type specific data (untested yet..)
		if (Codec_ID == 0x162 || Codec_ID == 0x163) { // WMA Audio Pro or WMALSL
			RMuint16      wValidBitsPerSample;
			RMuint32      dwChannelMask;
			RMuint16      wEncodeOptions;
			
			
			wValidBitsPerSample = 
				+ (((RMuint16) Codec_Specific_Data[1]) << 8)
				+  ((RMuint16) Codec_Specific_Data[0]);
			dwChannelMask = 
				  (((RMuint32) Codec_Specific_Data[5]) << 24)
				+ (((RMuint32) Codec_Specific_Data[4]) << 16)
				+ (((RMuint32) Codec_Specific_Data[3]) << 8)
				+  ((RMuint32) Codec_Specific_Data[2]);
			wEncodeOptions = 
				+ (((RMuint16) Codec_Specific_Data[15]) << 8)
				+  ((RMuint16) Codec_Specific_Data[14]);
			
			RMDBGLOG((ENABLE, 
				"    Audio codec ID: %04x,\n"
				"    %u valid bits/sample, %08X channel mask\n"
				"    0x%04x encode options\n",
				(int) Codec_ID,
				  (int) wValidBitsPerSample, (int) dwChannelMask, (int) wEncodeOptions));
			
			wma_params->EncoderOptions = wEncodeOptions;
			wma_params->WMAProValidBitsPerSample = wValidBitsPerSample;
			wma_params->WMAProChannelMask = dwChannelMask;
			
		
		}
		wma_params->OutputDualMode = asf_audio_opt->OutputDualMode;
		wma_params->OutputSpdif = asf_audio_opt->Spdif;
	
		pSendContext->audio_stream_index = Stream_Number;
		
		RMDBGLOG((ENABLE, "audioStreamTable[%ld]=%ld\n", audioStreams-1, Stream_Number));		

		if (!pSendContext->SendAudioData) {
			RMDBGLOG((ENABLE, ">>> audio stream found, enabling audio playback\n"));
			pSendContext->AudioStreamFound = TRUE;

			status = setup_audio_decoder(pSendContext);
			if (RMFAILED(status)){
				RMDBGLOG((ENABLE,"Error initializing audio\n"));
				 pSendContext->SendAudioData = FALSE;
			} else {
				pSendContext->SendAudioData = asf_play_opt->send_audio;
				if (!(pSendContext->dcc_info->seek_supported))
					/* Seek is not supported, do play now */
					asfPlay(pSendContext, RM_DEVICES_AUDIO, DCCVideoPlayFwd);
			}
		}
	}
}

///////////////////YYYY
static RMuint32 ResyncAudio(struct asf_context *pSendContext, RMuint32 Presentation_Time)
{


	RMuint64 CurrentSTC;
	RMint32 CutSTC;
	struct AudioDecoder_WMAParameters_type *wma_params = &(pSendContext->wma_params);
	RMuint32 codec = (RMuint32)wma_params->VersionNumber;
	if (!pSendContext->FirstSystemTimeStamp) {
		DCCSTCGetTime(pSendContext->dcc_info->pStcSource, &CurrentSTC, pSendContext->video_vop_tir);
		CutSTC = CurrentSTC & 0xffffffff;
		if( (RMint32)(Presentation_Time - CutSTC) <= 0) {

			RMDBGLOG((ENABLE, "Current STC = %lld PTS=%lu skipping to resync\n", CurrentSTC, Presentation_Time));
			if (pSendContext->compressed_audio) {
				RMWMAProVDecoderFlushParser(pSendContext->vDecoder);
			}
			if (codec!=0x161)
				return RM_SKIP_TO_RESYNC;
                         
		}
	}
	return 0;
}


static RMstatus initAudioDecoder(struct asf_context * context)
{
	if(context->audio_decoder_initialized == FALSE) {
		RMstatus status = RM_ERROR;
		struct AudioDecoder_WMAParameters_type *wma_params = &(context->wma_params);
		RMuint32 codec;

		RMDBGLOG((ENABLE, "initAudioDecoder\n"));

		codec = (RMuint32)wma_params->VersionNumber;
		switch (codec) {
		case 0x161:
		case 0x7A21:
		case 0x7A22:
			// WMA
			if (context->compressed_audio) {
				fprintf(stderr, ">>> Error: audio specified is WMAPro while detected is WMA\n");
				context->compressed_audio = FALSE;
				return RM_ERROR;
			}
			break;
		case 0x162:
			// WMAPro
			if (!context->compressed_audio) {
				fprintf(stderr, ">>> Error: audio specified is WMA while detected is WMAPro\n");
				context->compressed_audio = TRUE;
				return RM_ERROR;
			}
			break;
		case 0x163:
			// WMALSL
			RMDBGLOG((ENABLE, "initAudioDecoder: WMALSL\n"));
			if (!context->compressed_audio) {
				fprintf(stderr, ">>> Error: audio specified is WMA while detected is WMALSL\n");
				context->compressed_audio = TRUE;
				return RM_ERROR;
			}
			break;
		default:
			// wrong codec
			fprintf(stderr, "error wrong codec %lx, disabling audio\n", codec);
			context->compressed_audio = FALSE;
			context->SendAudioData = FALSE;
			return RM_ERROR;
			break;
			
		}

		if (context->compressed_audio) {
			RMstatus err;
			RMMetaWMAParameters temp_wmaparams;
			temp_wmaparams.VersionNumber = wma_params->VersionNumber;
			temp_wmaparams.SamplingFrequency = wma_params->SamplingFrequency;
			temp_wmaparams.NumberOfChannels = wma_params->NumberOfChannels;
			temp_wmaparams.Bitrate = wma_params->Bitrate;
			temp_wmaparams.PacketSize = wma_params->PacketSize;
			temp_wmaparams.EncoderOptions = wma_params->EncoderOptions;
			temp_wmaparams.BitsPerSample = wma_params->BitsPerSample;
			temp_wmaparams.WMAProValidBitsPerSample = wma_params->WMAProValidBitsPerSample;
			temp_wmaparams.WMAProChannelMask = wma_params->WMAProChannelMask;
			temp_wmaparams.WMAProVersionNumber = wma_params->WMAProVersionNumber;
			temp_wmaparams.OutputChannels = wma_params->OutputChannels;
			
			if(context->vDecoder == (void *)NULL) {
				RMDBGLOG((ENABLE,"******** using RMF's WMAPRO decoder ********\n"));
				err = RMCreateWMAProVDecoder(&(context->vDecoder));
				if (err != RM_OK) {
					RMDBGLOG((ENABLE,"error: cant create wmaproVdecoder!\n"));
					return RM_ERROR;
				}
				
				err = RMWMAProVDecoderOpen(context->vDecoder);
				if (err != RM_OK) {
					RMDBGLOG((ENABLE,"error: cant open wmaproVdecoder!\n"));
					return RM_ERROR;
				}
			}

			if (context->vDecoder != (void *)NULL) {
				err = RMWMAProVDecoderInit(context->vDecoder, 
							   wma_params->EncoderOptions,
							   wma_params->PacketSize,
							   &temp_wmaparams);
				if (err != RM_OK)
					RMDBGLOG((ENABLE, "wmaprodecoder init error\n"));
			} else {
				RMDBGLOG((ENABLE, "calling wmaprodecoder init before open!\n"));
			}
			
		}
		
		if(codec != 0x163) {
			status = DCCSetAudioWMAFormat(context->dcc_info->pAudioSource, wma_params); 
			if(status == RM_OK){			
				// wma_params->SamplingFrequency
				RMDBGLOG((ENABLE, " set audio_freq = %ldHz (ignore any audio_freq in cmdline)\n", wma_params->SamplingFrequency));
				status = RUASetProperty(context->dcc_info->pRUA, context->dcc_info->audio_engine, RMAudioEnginePropertyID_SampleFrequency,
							&wma_params->SamplingFrequency, sizeof(wma_params->SamplingFrequency), 0);
				asf_audio_opt->SampleRate = wma_params->SamplingFrequency;
				apply_dvi_hdmi_audio_options(context->dcc_info, asf_audio_opt, wma_params->NumberOfChannels, TRUE, TRUE, FALSE);
			}
		}
		else {
			asf_audio_opt->Codec = AudioDecoder_Codec_PCM;
			asf_audio_opt->SubCodec = 0;
			asf_audio_opt->SampleRate = wma_params->SamplingFrequency;
			asf_audio_opt->PcmCdaParams.ChannelAssign = PcmCda2_LR;
			asf_audio_opt->PcmCdaParams.BitsPerSample = wma_params->BitsPerSample;
			asf_audio_opt->PcmCdaParams.MsbFirst = FALSE;
			
			// apply the sample rate, serial out status
			status = apply_audio_engine_options(context->dcc_info, asf_audio_opt);
			if(status != RM_OK){			
				RMDBGLOG((ENABLE, "Cannot apply audio engine options ... disabling audio, error = %d\n", status));
				context->SendAudioData = FALSE;
			}
			
			status = apply_audio_decoder_options(context->dcc_info, asf_audio_opt);
			RMDBGLOG((ENABLE, " set PCM codec for WMALSL, Sampling Freq=%lu\n", asf_audio_opt->SampleRate));
			DCCSTCSetTimeResolution(context->dcc_info->pStcSource, DCC_Audio, 90000);
		}
		
		if(status != RM_OK){			
			RMDBGLOG((ENABLE, "Cannot set audio codec ... disabling audio, error = %d\n", status));
			context->SendAudioData = FALSE;
		}
		
		context->audio_decoder_initialized = TRUE;
	}
	return RM_OK;
}

static RMbool SwitchAudio(struct asf_context *pSendContext, RMuint32 Media_Object_Number)
{
	
		
	RMDBGLOG((ENABLE, "got audio stream change command\n"));

	pSendContext->dcc_info->state = RM_PLAYING;

	if ((pSendContext->dcc_info->selectAudioStream > (RMint32)audioStreams) || 
	    (pSendContext->dcc_info->selectAudioStream == 0) ||
	    (audioStreams <= 1) || 
	    (pSendContext->dcc_info->selectAudioStream == (RMint32)pSendContext->audio_stream_index)) {
		RMDBGLOG((ENABLE, "audio stream change ignored (total audioStreams %lu, selected %ld, current %lu)\n", 
			  audioStreams, 
			  pSendContext->dcc_info->selectAudioStream,
			  pSendContext->audio_stream_index));
		return FALSE;
	}

	asfStop(pSendContext, RM_DEVICES_AUDIO);
	
	if (pSendContext->compressed_audio) {
		RMDBGLOG((ENABLE, "close wmapro decoder\n"));
		RMWMAProVDecoderClose(pSendContext->vDecoder);
		
		RMDBGLOG((ENABLE, "open wmapro decoder\n"));
		RMWMAProVDecoderOpen(pSendContext->vDecoder);
	}
	
	pSendContext->dcc_info->state = RM_PLAYING;
	pSendContext->audio_decoder_initialized = FALSE;
	pSendContext->prev_audio_media_object_number = Media_Object_Number;
	
	RMDBGLOG((ENABLE, "total audio streams %lu\n", audioStreams));
	if (pSendContext->dcc_info->selectAudioStream == -1) {
		RMuint32 i;		

		
		for (i = 0; i < audioStreams ; i++) {
			if (audioStreamTable[i] != pSendContext->audio_stream_index)
				break;
		}
		RMDBGLOG((ENABLE, "current stream %lu, switch to %lu\n", pSendContext->audio_stream_index, audioStreamTable[i]));
		pSendContext->audio_stream_index = audioStreamTable[i];
	}
	else {
		RMDBGLOG((ENABLE, "current stream %lu, switch to %lu\n", pSendContext->audio_stream_index, pSendContext->dcc_info->selectAudioStream));
		pSendContext->audio_stream_index = pSendContext->dcc_info->selectAudioStream;
	}
	

	asfPlay(pSendContext, RM_DEVICES_AUDIO, 0);

	return TRUE;
}

static void try_decode_wmapro(struct asf_context *pSendContext, RMbool EOS)
{
	/* wmapro decoding and senddata */	
	RMstatus status;
	RMuint32 rd1, size1, rd2;
	struct wmapro_buffer_info *buf_info;
	RMuint32 size_audio = 0, size_info;
	RMuint8 *buf_audio;
	struct emhwlib_info *pInfo;
	
	RMuint32 broken_frame;

	while (RMfifo_get_readable_size(pSendContext->wmapro_fifo, &rd1, &size1, &rd2) >= sizeof(struct wmapro_buffer_info)) {
		buf_info = (struct wmapro_buffer_info *) rd1;
		
		if (buf_info->new_buffer) {
			RMDBGLOG((WMAPRODBG, "Reset WMAPRO decoder with buffer(%p) size(%lu)\n", buf_info->ptr, buf_info->size));
			status = RMWMAProVDecoderResetParser(pSendContext->vDecoder, buf_info->ptr, buf_info->size);
			if (status != RM_OK) {
				RMDBGLOG((WMAPRODBG, "Cannot reset wmapro parser\n"));
				pSendContext->prev_Audio_Presentaion_time = buf_info->Info.TimeStamp;

				goto next_wmapro_packet;
			}
			
			if((RMuint32)buf_info->Info.TimeStamp > 0)
			{
			  if (ResyncAudio(pSendContext, buf_info->Info.TimeStamp) == RM_SKIP_TO_RESYNC)
			  {
				RMDBGLOG((ENABLE, "Skip to resync\n"));
				goto next_wmapro_packet;
			  }
			  pSendContext->prev_Audio_Presentaion_time = buf_info->Info.TimeStamp;
			}
			else
			{
				buf_info->Info.TimeStamp = pSendContext->prev_Audio_Presentaion_time;
			}

			pSendContext->packet_counter ++;
			buf_info->new_buffer = FALSE;
			buf_info->pBuffer = NULL;
		}
		
		while (1) {	
			RMbool fHaveNewBuffer = FALSE;
			
			if (buf_info->pBuffer == NULL) {
				status = RMWMAProVDecoderGetFrame(pSendContext->vDecoder, &(buf_info->pBuffer));
					
				if (status == RM_WMAPRO_SKIPFRAME) {
					buf_info->pBuffer = NULL;
					RMDBGLOG((WMAPRODBG, "SKIP FRAME\n"));
					continue;
				}
				else if (status != RM_OK) {
					RMDBGLOG((WMAPRODBG, "Error get frame\n"));
					break;
				}
			}
 			  if (pSendContext->UncompressedBuffer != NULL) {
				RUAReleaseBuffer(pSendContext->pDMAuncompressed, pSendContext->UncompressedBuffer);
				pSendContext->UncompressedBuffer = NULL;
			  }

			  if (EOS) {
				while (1) {
					if (RUAGetBuffer(pSendContext->pDMAuncompressed, &pSendContext->UncompressedBuffer, GETBUFFER_TIMEOUT_US) == RM_OK)
						break;
				}
			  }
			  else {
				if (RUAGetBuffer(pSendContext->pDMAuncompressed, &pSendContext->UncompressedBuffer, 0) != RM_OK) {
					RMDBGLOG((WMAPRODBG, "Cannot get buffer\n"));
					return;
			    }
		      }

		      fHaveNewBuffer = TRUE;
			
			buf_audio = pSendContext->UncompressedBuffer;

			status = RMWMAProVDecoderDecode(pSendContext->vDecoder, buf_info->pBuffer, buf_audio, &size_audio);
			buf_info->pBuffer = NULL;
			RMDBGLOG((WMAPRODBG, "size_audio = %d on buffer %p\n", size_audio, buf_audio));
			
			if (size_audio > (1<<AUDIO_DMA_BUFFER_SIZE_LOG2)) {
				RMDBGLOG((ENABLE, "size_audio (%ld) > dmabuffersize (%ld), disabling audio\n", size_audio, (1<<AUDIO_DMA_BUFFER_SIZE_LOG2)));
				pSendContext->SendAudioData = FALSE;
				break;
			}
			
			if(size_audio > 0) {
				
				pInfo = NULL;
				size_info = 0;
				
				/* need to be the first test to do it every time */
				broken_frame = RMWMAProVDecodeGetFlag(pSendContext->vDecoder, INQUIRE_BROKEN_FRAME_FLAG);
				RMDBGLOG((WMAPRODBG, "broken %lu, sendpts %lu, audiopts %lu\n", broken_frame, buf_info->fSendPTS, pSendContext->SendAudioPts));
				if (buf_info->fSendPTS && pSendContext->SendAudioPts && !broken_frame) {
					pInfo = &(buf_info->Info);
				
					size_info = sizeof(buf_info->Info);
					buf_info->fSendPTS = 0;					
				}
			
				if ((pInfo != NULL) && (pInfo->ValidFields != 0))
					RMDBGLOG((WMAPRODBG, "sending wmapro audio %d, MON %d, %ld bytes, pts %llu\n",
						  (int)buf_info->Stream_Number,
						  (int)buf_info->Media_Object_Number,
						  size_audio,
						  pInfo == NULL ? 0:pInfo->TimeStamp));
				
				if (RUASendData(pSendContext->pRUA, pSendContext->dcc_info->audio_decoder, pSendContext->pDMAuncompressed, buf_audio, size_audio, pInfo, size_info) != RM_OK) {
					RMDBGLOG((ENABLE, "WmaPro Xfer task too small\n"));
					break;
				}

				pSendContext->AudioByteCounter += size_audio;
			}
			else
			{
				printf("Flush WMAPRO decoder due to error\n");
				RMWMAProVDecoderFlushParser(pSendContext->vDecoder);
				break;
			}


			if (status != RM_OK)
				break;
	}
		
	next_wmapro_packet:
		RUAReleaseBuffer(pSendContext->pDMA, buf_info->ptr);
		RMfifo_incr_read_ptr(pSendContext->wmapro_fifo, sizeof(struct wmapro_buffer_info));
	}
}


static void play_Payload
(
 void *context,
 unsigned char Stream_Number,  
 unsigned char *buf, unsigned long size,
 unsigned long bytes_left,
 unsigned char Is_Key_Frame,
 unsigned long Media_Object_Number, unsigned char Media_Object_Number_valid,
 unsigned long Presentation_Time, unsigned char Presentation_Time_valid,
 unsigned long Offset_Into_Media_Object
 )
{
	struct asf_context *pSendContext = (struct asf_context *) context;
	struct emhwlib_info Info;
	struct emhwlib_info *pInfo;
	RMuint32 size_info;
	RMint32 diff;
	RMstatus err;
	#define DELTA_PTS 100			// 1 sec
	#define CONTIGUOUS_LENGHT 0x100000	// 1 MB

	RMuint32 dataType = 0;
	RMbool SetPTS = FALSE;
	RMbool SendPTS = FALSE;
	RMbool SendData = FALSE;
	RMuint32 PrevMON = 0;
	RMuint32 decoder = 0;
	// dummy init
	RMbool *seeking = &(pSendContext->SeekVideo);
	RMuint32 *previousMON = &(pSendContext->PrevVideoMON);


	if (pSendContext->ignoreCallback) {
		if (pSendContext->cmd == RM_QUIT) {
			RMDBGLOG((ENABLE, "callback called when 'quit' command was issued\n"));
			goto return_from_callback;
		}
		if (pSendContext->cmd == RM_STOP) {
			RMDBGLOG((ENABLE, "callback called when 'stop' command was issued\n"));
			goto return_from_callback;
		}
		if (pSendContext->cmd == RM_STOP_SEEK_ZERO) {
			RMDBGLOG((ENABLE, "callback called when 'seekzero' command was issued\n"));
			goto return_from_callback;
		}
		if ((pSendContext->dcc_info->state == RM_PLAYING_TRICKMODE) && 
		    ((pSendContext->dcc_info->trickmode_id == RM_TRICKMODE_FWD_IFRAME) ||	
		     (pSendContext->dcc_info->trickmode_id == RM_TRICKMODE_RWD_IFRAME)) ) {
			RMDBGLOG((ENABLE, "callback called when 'iframe' command was issued\n"));
			goto return_from_callback;
		}
		if ((pSendContext->cmd == RM_SEEK) && (pSendContext->dcc_info->seek_supported)) {
			RMDBGLOG((ENABLE, "callback called when 'seek' command was issued\n"));
			goto return_from_callback;
		}

		RMDBGLOG((ENABLE, "********** ignoring Callback!! *********\n"));
		goto return_from_callback;
	}
		

	if (pSendContext->drmError != 0) {
		RMDBGLOG((ENABLE, "there was a decryption error, callback ignored\n"));
		goto return_from_callback;
	}

	if ((pSendContext->isContentEncrypted) && (bytes_left != 0))
		RMDBGLOG((ENABLE, "non aligned read, offset %ld!\n", bytes_left));

	RMDBGLOG((PAYLOADDBG,"ST:%02d,MON:%04d,Key:%01d,time:%05d.%03d, size:%05d, left:%05d, offset:%05d \n",
		  (int)Stream_Number,
		  (int)Media_Object_Number,
		  (int)Is_Key_Frame,
		  (int)(Presentation_Time/1000),
		  (int)(Presentation_Time%1000),
		  (int)size,
		  (int)bytes_left,
		  (int)Offset_Into_Media_Object));
	
	if (Stream_Number == pSendContext->video_stream_index)
		dataType = RM_STREAM_VIDEO;
	else if (Stream_Number == pSendContext->audio_stream_index)
		dataType = RM_STREAM_AUDIO;
	else
		goto return_from_callback;


	// Decrypt packet, if necessary
	if (pSendContext->isContentEncrypted) {
		if ((pSendContext->drmError = WMDRM_decrypt_packet(buf, size)) != 0) {
			
			RMASFVDemuxSetDRMError(pSendContext->vASFDemux, pSendContext->drmError);
			RMDBGLOG((ENABLE, "DECRYPTION FAILED\n"));
			goto return_from_callback;
		}
	}

	/* adjust PTS if necessary */
	if ((pSendContext->PrerollSET) && (pSendContext->Preroll)) {
		RMDBGLOG((DISABLE, "pts %llu, adjusted pts %llu\n",
			  (RMuint64)Presentation_Time,
			  (RMuint64)Presentation_Time - pSendContext->Preroll));
		
		Presentation_Time = Presentation_Time - (RMuint32)pSendContext->Preroll;
	}

	/* accurate audio seek, required for WMA FFWD trickmode */
	if (dataType == RM_STREAM_AUDIO) {
		if (pSendContext->accurateAudioSeekTo > (RMuint64)Presentation_Time) {
			RMDBGLOG((ENABLE, "skipping audio %lu < %llu\n", Presentation_Time, pSendContext->accurateAudioSeekTo));
			goto return_from_callback;
		}
		else if (pSendContext->accurateAudioSeekTo != 0) {
			RMDBGLOG((ENABLE, "start sending audio %lu\n", Presentation_Time));
			pSendContext->accurateAudioSeekTo = 0;
		}
	}

	switch (dataType) 
	{
	case RM_STREAM_VIDEO: 
		{
			if (!pSendContext->SendVideoData)
				goto return_from_callback;
			SendPTS = pSendContext->SendVideoPts;
			PrevMON = pSendContext->prev_video_media_object_number;
			pSendContext->VideoByteCounter += size;
			pSendContext->prev_video_media_object_number = Media_Object_Number;
			decoder = pSendContext->dcc_info->video_decoder;
			SendData = TRUE;
			seeking = &(pSendContext->SeekVideo);
			previousMON = &(pSendContext->PrevVideoMON);
			
			break;
		}
	case RM_STREAM_AUDIO: 
		{
			if (!pSendContext->SendAudioData)
				goto return_from_callback;
			SendPTS = pSendContext->SendAudioPts;
			PrevMON = pSendContext->prev_audio_media_object_number;
			decoder = pSendContext->dcc_info->audio_decoder;
			if (!pSendContext->compressed_audio)
				pSendContext->AudioByteCounter += size;

			pSendContext->prev_audio_media_object_number = Media_Object_Number;
			
			Is_Key_Frame = 1; 
					     
			seeking = &(pSendContext->SeekAudio);
			previousMON = &(pSendContext->PrevAudioMON);

			SendData = ((pSendContext->compressed_audio) || (pSendContext->dcc_info->state == RM_PLAYING_TRICKMODE)) ? FALSE : TRUE;

			if (pSendContext->dcc_info->state != RM_PLAYING_TRICKMODE) {
				
				if (ResyncAudio(pSendContext, Presentation_Time) == RM_SKIP_TO_RESYNC)
					goto return_from_callback;
				
				if (pSendContext->dcc_info->state == RM_AUDIO_STREAM_CHANGE) {
					RMbool status;
					status = SwitchAudio(pSendContext, Media_Object_Number);
					if (status == TRUE)
						goto return_from_callback;
				}
			}

			break;
		}
	}

	
	
	if (*seeking) {
		if ((Is_Key_Frame) && (Offset_Into_Media_Object == 0)) {
			RMDBGLOG((ENABLE, ">>first %s payload after a seek, MON %lu, size %ld, pts %lu\n", 
				  (dataType == RM_STREAM_VIDEO) ? "video":"audio",
				  Media_Object_Number, 
				  size,
				  Presentation_Time));
			*previousMON = Media_Object_Number;
			SetPTS = TRUE;
		}
		else
			goto return_from_callback;
		
		*seeking = FALSE;
	}

	if ((pSendContext->isIFrameMode) && (dataType == RM_STREAM_VIDEO)) {
		switch (pSendContext->IFrameFSMState) {
			case RMasfIFrameFSM_Disabled: {
				break;
			}
			case RMasfIFrameFSM_Init: {
				if ((Is_Key_Frame) && (Offset_Into_Media_Object == 0)) {
					RMDBGLOG((TRICKDBG, ">>this payload will be sent, MON %lu, size %ld\n", Media_Object_Number, size));
					pSendContext->PrevVideoMON = Media_Object_Number;
					pSendContext->IFrameFSMState = RMasfIFrameFSM_WaitIFrameMONChange;
					SetPTS = TRUE;
				}
				else {
				        RMDBGLOG((TRICKDBG, "++skip payload MON %lu, size %ld until KEY & OFF=0\n", Media_Object_Number, size));
					goto return_from_callback;
				}
				break;
			}
			case RMasfIFrameFSM_WaitIFrameMONChange: {
				if (pSendContext->PrevVideoMON != Media_Object_Number) {
					RMDBGLOG((TRICKDBG,"++skipping video because IFrame MON(%lu) changed to %lu, size %lu\n", 
						  pSendContext->PrevVideoMON,
						  Media_Object_Number,
						  size));
					pSendContext->IFrameFSMState = RMasfIFrameFSM_SkipNext;
					goto return_from_callback;
				}

				break;
			}
			case RMasfIFrameFSM_SkipNext: {
				RMDBGLOG((TRICKDBG,"++skippingNEXT video because IFrame MON(%lu) changed to %lu, size %lu\n", 
					  pSendContext->PrevVideoMON,
					  Media_Object_Number,
					  size));
				goto return_from_callback;
				break;
			}
			default: {
				goto return_from_callback;
			}
			
		}
		
	} else if (pSendContext->isIFrameMode) {
		// skip all other streams
		goto return_from_callback;
	}
	

	RMDBGLOG((DISABLE, "prevMON %s is %lu pts %lu\n", (dataType == RM_STREAM_VIDEO) ? "video":"audio", PrevMON, Presentation_Time));
	//  do not resend pts at each subpacket
	if ( ((Media_Object_Number_valid && (Media_Object_Number != PrevMON)) || (SetPTS)) && (SendPTS) ) {
		Info.ValidFields = TIME_STAMP_INFO;
		Info.TimeStamp = Presentation_Time;
		pInfo = &Info;
		size_info = sizeof(Info);
		if (dataType == RM_STREAM_VIDEO) {
			pSendContext->video_last_pts = Presentation_Time;
			pSendContext->video_time_stamp = Presentation_Time;
		} else if (dataType == RM_STREAM_AUDIO)
			pSendContext->audio_time_stamp = Presentation_Time;
			
		if ( pSendContext->FirstSystemTimeStamp ) {
			pSendContext->min_diff = 0;
			pSendContext->max_diff = 0;
			if (dataType == RM_STREAM_VIDEO)
				pSendContext->audio_time_stamp = pSendContext->video_time_stamp;
			else
				pSendContext->video_time_stamp = pSendContext->audio_time_stamp;
		}

		if (!pSendContext->isAudioOnlyFile) {
			diff = pSendContext->video_time_stamp - pSendContext->audio_time_stamp;
			RMDBGLOG((DISABLE, "diff %lu\n", diff));
			if ( (diff < -DELTA_PTS) || (diff > DELTA_PTS)) {
				if ( (diff > 0) && (diff > pSendContext->max_diff+100) ) {
					pSendContext->max_diff = diff;
					if(pSendContext->dcc_info->trickmode_id == RM_NO_TRICKMODE)
						RMDBGLOG((ENABLE, " %ld\n", diff));
				}
				if ( (diff < 0) && (diff < pSendContext->min_diff-100) ) {
					pSendContext->min_diff = diff;
					if(pSendContext->dcc_info->trickmode_id == RM_NO_TRICKMODE)
						RMDBGLOG((ENABLE, " %ld\n", diff));
				}
			}
		}

		
		
	} else {
		pInfo = NULL;
		size_info = 0;
	}


	if ( pSendContext->FirstSystemTimeStamp && pInfo && (pInfo->ValidFields & TIME_STAMP_INFO) && (pSendContext->dcc_info->state != RM_PLAYING_TRICKMODE)) {
		if (!pSendContext->PrerollSET) {
			if (pSendContext->Preroll) {
				if (pInfo->TimeStamp < pSendContext->Preroll) {
					RMDBGLOG((ENABLE, "First PTS (%llu) < Preroll (%llu), adjusting Preroll to %llu so first PTS=0\n",
						  pInfo->TimeStamp,
						  pSendContext->Preroll,
						  pInfo->TimeStamp));
					pSendContext->Preroll = pInfo->TimeStamp;
					pInfo->TimeStamp = 0;
				}
				else {
					RMDBGLOG((ENABLE, "Preroll is %llu, First PTS %llu needs to be adjusted to %llu\n",
						  pSendContext->Preroll,
						  pInfo->TimeStamp,
						  pInfo->TimeStamp - pSendContext->Preroll));
					pInfo->TimeStamp -= pSendContext->Preroll;
				}
				pSendContext->PrerollSET = TRUE;
			}
		}
						  
			
			
		RMDBGLOG((ENABLE, "FirstSystemTimeStamp for %s = %llu(0x%llx) at %ld/sec\n",
			  dataType == RM_STREAM_VIDEO ? "video":"audio",
			  pInfo->TimeStamp, 
			  pInfo->TimeStamp, 
			  pSendContext->video_vop_tir)); 
		

		if(pSendContext->compressed_audio) {
			RMint64 firstPTS = (RMint64)pInfo->TimeStamp + (RMint64)pSendContext->start_ms - (RMint64)(pSendContext->video_vop_tir>>5);
			RMDBGLOG((ENABLE, "Set STC at least %ld clicks before PTS for WMAPRO decoding (video)\n", pSendContext->video_vop_tir>>5));
			RMDBGLOG((ENABLE, "firstPTS %lld %s\n", firstPTS, (firstPTS < 0) ? ">>> timer is negative!":""));

			DCCSTCSetTime(pSendContext->dcc_info->pStcSource, RMmax(0, (RMuint64)firstPTS), pSendContext->video_vop_tir);
		}
		else {
			RMint64 firstPTS = (RMint64)pInfo->TimeStamp + (RMint64)pSendContext->start_ms - (RMint64)300;
			RMDBGLOG((ENABLE, "timer will be set to %lld %s\n", firstPTS, (firstPTS < 0) ? ">>> timer is negative!":""));

			DCCSTCSetTime(pSendContext->dcc_info->pStcSource, RMmax(0, (RMuint64)firstPTS), pSendContext->video_vop_tir);
			//DCCSTCSetTime(pSendContext->dcc_info->pStcSource, pInfo->TimeStamp + pSendContext->start_ms, pSendContext->video_vop_tir);
		}

		DCCSTCPlay(pSendContext->dcc_info->pStcSource);

		pSendContext->FirstSystemTimeStamp = FALSE;
		RMDBGLOG((ENABLE, "vpts-apts[ms]= 0\n"));
	}
	

	if ((pSendContext->CurrentDisplayPTS) && (pSendContext->IFrameDirection > 0) && (dataType == RM_STREAM_VIDEO))  {
		if ((Presentation_Time >= pSendContext->CurrentDisplayPTS) && 
		    (Is_Key_Frame) && 
		    (Offset_Into_Media_Object == 0)) {
			pSendContext->CurrentDisplayPTS = 0;
			pSendContext->SeekAudio = TRUE;
			pSendContext->IgnoreAudio = FALSE;
			RMDBGLOG((PAYLOADDBG, "will send video MON=%lu, size=%lu, pts=%lu %s, %lu\n",
				  Media_Object_Number,
				  size,
				  Presentation_Time,
				  Is_Key_Frame == 1 ? "key":"",
				  Offset_Into_Media_Object));
		}
		else {
			RMDBGLOG((PAYLOADDBG, "dropping video frame MON=%lu, size=%lu, pts=%lu < DisplayPTS(%llu), %s, %lu\n",
				  Media_Object_Number,
				  size,
				  Presentation_Time,
				  pSendContext->CurrentDisplayPTS,
				  Is_Key_Frame == 1 ? "key":"",
				  Offset_Into_Media_Object));
			pSendContext->IgnoreAudio = TRUE;
			goto return_from_callback;
		}
	}
	if ((pSendContext->CurrentDisplayPTS) && (dataType == RM_STREAM_AUDIO))  {
		if ((Presentation_Time >= pSendContext->CurrentDisplayPTS) && 
		    (Is_Key_Frame) && 
		    (Offset_Into_Media_Object == 0) &&
		    (pSendContext->IgnoreAudio == FALSE)) {
			pSendContext->CurrentDisplayPTS = 0;
			RMDBGLOG((PAYLOADDBG, "will send audio MON=%lu, size=%lu, pts=%lu %s, %lu\n",
				  Media_Object_Number,
				  size,
				  Presentation_Time,
				  Is_Key_Frame == 1 ? "key":"",
				  Offset_Into_Media_Object));
		}
		else {
			RMDBGLOG((PAYLOADDBG, "dropping audio frame MON=%lu, size=%lu, pts=%lu < DisplayPTS(%llu)\n",
				  Media_Object_Number,
				  size,
				  Presentation_Time,
				  pSendContext->CurrentDisplayPTS));
			goto return_from_callback;
		}
	}

	/* senddata for video and wma audio */
	if (SendData) {

		RMDBGLOG((SENDDBG, "sending MON(%lu) %s, size %lu, pts %llu (%s), %s, %lu\n",
			  Media_Object_Number,
			  dataType == RM_STREAM_VIDEO ? "video":"audio",
			  size,
			  pInfo == NULL ? 0:pInfo->TimeStamp,
			  pInfo == NULL ? "no pts":(pInfo->ValidFields & TIME_STAMP_INFO ? "valid":""),
			  Is_Key_Frame == 1 ? "key":"",
			  Offset_Into_Media_Object));

		if (RUASendData(pSendContext->pRUA, decoder, pSendContext->pDMA, buf, size, pInfo, size_info) != RM_OK) 
		{
			PMAAddEvents(e,&nEvents,RUAEVENT_XFER_FIFO_READY,decoder);
			fprintf(stderr,"\nWMA send data failed");
		}
		goto callback_end; //callback end
	}

	
	/* wmapro decoding and senddata */	
	if ((dataType == RM_STREAM_AUDIO) && 
  	    /*(PlaybackStatus == RM_PSM_Playing) &&*/
  	    (pSendContext->compressed_audio)) {
 		struct wmapro_buffer_info *buf_info;
 		RMuint32 wr1, wr2, size1;
                 
 		while (RMfifo_get_writable_size(pSendContext->wmapro_fifo, &wr1, &size1, &wr2) < sizeof(struct wmapro_buffer_info)) {
			try_decode_wmapro(pSendContext, FALSE);
 			RMDBGLOG((WMAPRODBG, "WMAPRO fifo too small\n")); 			
  		}
 		
 		buf_info = (struct wmapro_buffer_info *) wr1;
  
 		buf_info->ptr = buf;
  
 		buf_info->size = size;
 		buf_info->new_buffer = TRUE;
 		buf_info->Info = Info;
 		buf_info->Stream_Number = Stream_Number;
 		buf_info->Media_Object_Number = Media_Object_Number;
 		buf_info->fSendPTS = 1;

 		RUAAcquireBuffer(pSendContext->pDMA, buf);
 		RMDBGLOG((WMAPRODBG, "Insert address %p into WMAPRO fifo size(%lu), valid(%lu) pts(%llu)\n", buf, size, Info.ValidFields, Info.TimeStamp));
 		RMfifo_incr_write_ptr(pSendContext->wmapro_fifo, sizeof(struct wmapro_buffer_info));
 		
 		try_decode_wmapro(pSendContext, FALSE);
  	}

 callback_end:

	/*************************************************************************************/
	/* video debug stuff */
	/*************************************************************************************/

	if (dataType == RM_STREAM_VIDEO) {
		if (Media_Object_Number_valid && (Media_Object_Number != PrevMON)) {
			

			pSendContext->video_frame_counter++;

		}


		if(pSendContext->ContiguousVideoLength == 0)
			pSendContext->video_time_start = get_ustime();
		pSendContext->ContiguousVideoLength +=size;
		if(pSendContext->ContiguousVideoLength > CONTIGUOUS_LENGHT) {
			pSendContext->video_time_end = get_ustime();
			//RMDBGLOG((ENABLE, "pSendContext->ContiguousVideoLength 0x%08lx = %8lldus\n", pSendContext->ContiguousVideoLength, pSendContext->video_time_end - pSendContext->video_time_start));
		}
		pSendContext->ContiguousAudioLength = 0;

		{
			RMstatus err;
			err = dump_data_into_file(asf_play_opt, RMVDEMUX_VIDEO, buf, size, Presentation_Time, Presentation_Time_valid, 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot dump data %d\n", err));
				goto return_from_callback;
			}
		}
	}

	/* audio debug stuff */

	if (dataType == RM_STREAM_AUDIO) {
		if (Media_Object_Number_valid && (Media_Object_Number != PrevMON)) {

			//RMDBGLOG((ENABLE, "\nFrame counter = %d, size = %d\n",(int)pSendContext->audio_frame_counter, (int)size));
			//fflush(stdout);
			pSendContext->audio_frame_counter++;

		}

		//RMDBGLOG((ENABLE, "audio = %ld\n", size)); 
		if(pSendContext->ContiguousVideoLength == 0)
			pSendContext->audio_time_start = get_ustime();
		pSendContext->ContiguousAudioLength = 0;
		pSendContext->ContiguousAudioLength +=size;
		if(pSendContext->ContiguousAudioLength > CONTIGUOUS_LENGHT) {
			pSendContext->audio_time_end = get_ustime();
			//RMDBGLOG((ENABLE, "pSendContext->ContiguousAudioLength 0x%08lx = %8lldus\n", pSendContext->ContiguousAudioLength, pSendContext->audio_time_end - pSendContext->audio_time_start));
		}
		pSendContext->ContiguousVideoLength = 0;


			err = dump_data_into_file(asf_play_opt, RMVDEMUX_AUDIO, buf, size, Presentation_Time, Presentation_Time_valid, 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot dump data %d\n", err));
				goto return_from_callback;
			}
	}

	return;

 return_from_callback:

	RMDBGLOG((PAYLOADDBG,"dropped ST:%02d,MON:%04d,Key:%01d,time:%05d.%03d,size:%05d,left:%05d\n",
		  (int)Stream_Number,
		  (int)Media_Object_Number,
		  (int)Is_Key_Frame,
		  (int)(Presentation_Time/1000),
		  (int)(Presentation_Time%1000),
		  (int)size,
		  (int)bytes_left));
	if ((Is_Key_Frame) && (dataType == RM_STREAM_VIDEO)) {
		RMDBGLOG((SENDDBG, "dropped a keyframe! ST:%02d,MON:%04d,Key:%01d,time:%05d.%03d,size:%05d,left:%05d\n",
		  (int)Stream_Number,
		  (int)Media_Object_Number,
		  (int)Is_Key_Frame,
		  (int)(Presentation_Time/1000),
		  (int)(Presentation_Time%1000),
		  (int)size,
		  (int)bytes_left));
	}

	return;
}



static RMstatus asfStop(struct asf_context *pSendContext, RMuint32 devices)
{
	RMstatus err = RM_OK;
	
	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "STOP: stc\n"));
		DCCSTCStop(pSendContext->dcc_info->pStcSource);
	}

	if (devices & RM_DEVICES_VIDEO) {
		if (pSendContext->SendVideoData) {
			RMDBGLOG((ENABLE, "STOP: video decoder\n"));
			err = DCCStopVideoSource(pSendContext->dcc_info->pVideoSource, DCCStopMode_LastFrame);
			if (RMFAILED(err)){
				RMDBGLOG((ENABLE, "Error stopping video source %d\n", err));
				return err;
			}
			pSendContext->video_decoder_initialized = FALSE;
		}
	}

	if (devices & RM_DEVICES_AUDIO) {
		if (pSendContext->SendAudioData) {
			RMDBGLOG((ENABLE, "STOP: audio decoder\n"));
			err = DCCStopAudioSource(pSendContext->dcc_info->pAudioSource);
			if (RMFAILED(err)){
				RMDBGLOG((ENABLE,"Error stopping audio source %d\n", err));
				return err;
			}
			pSendContext->audio_decoder_initialized = FALSE;
		}
	}

	if ((devices & RM_DEVICES_AUDIO) && (devices & RM_DEVICES_VIDEO)) {
		pSendContext->FirstSystemTimeStamp = TRUE;
	}

	return err;

}

static RMstatus asfPlay(struct asf_context * pSendContext, RMuint32 devices, enum DCCVideoPlayCommand mode)
{

	RMstatus err = RM_OK;
	
	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "PLAY: stc\n"));
		DCCSTCPlay(pSendContext->dcc_info->pStcSource);
	}

	if (devices & RM_DEVICES_AUDIO) {
		if (pSendContext->SendAudioData) {
			err = initAudioDecoder(pSendContext);
			if (err != RM_OK) {
				RMDBGLOG((ENABLE, "error during audio init\n"));
				return err;
			}

			RMDBGLOG((ENABLE, "PLAY: audio decoder\n"));
			err = DCCPlayAudioSource(pSendContext->dcc_info->pAudioSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot play video decoder %d\n", err));
				return err;
			}
		}
	}


	return err;

}


static RMstatus readBitstream(struct asf_context *pSendContext, RMuint8 *buffer, RMuint32 *bytesRead)
{
	RMstatus status;
	RMuint64 position;
	RMuint32 size, packet;
	RMuint32 count;
	RMuint32 buffersize;
	RMuint32 alignedPacket;

	buffersize = (1 << ASF_DMA_BUFFER_SIZE_LOG2);

	/* The Microsoft Janus DRM requires ASF data packets to be contiguous for decryption.
	 * If the file is Janus encrypted, an integer multiple of ASF data packets will be
	 * read into the RUA buffer (i.e. the read size is truncated).  If the file is not
	 * Janus encrypted, the entire RUA buffer will be filled. */
	if (pSendContext && pSendContext->asf_packetSize && pSendContext->isContentEncrypted) {
		/* In case we play the file completely sequentially, the
		 * asf_packetSize is not known at the first read, since we
		 * haven't parsed the stream yet, so use default size if
		 * asf_packetSize == 0 */
		alignedPacket = (buffersize/pSendContext->asf_packetSize)*pSendContext->asf_packetSize;
		buffersize = alignedPacket;
			
		if ((1 << ASF_DMA_BUFFER_SIZE_LOG2) < pSendContext->asf_packetSize) {
				RMDBGLOG((ENABLE, "** Read Buffers too small\n"));
				return RM_ERROR;
		}
	}
	
       

	if (pSendContext->dcc_info->state == RM_PLAYING_TRICKMODE) {
		if ((pSendContext->dcc_info->trickmode_id == RM_TRICKMODE_FWD_IFRAME) || 
		    (pSendContext->dcc_info->trickmode_id == RM_TRICKMODE_RWD_IFRAME)) {
			if (pSendContext->IFrameSize == 0) {
				RMuint32 sizeToRead;

				status = RMASFVDemuxGetNextIFrame(pSendContext->vASFDemux, &position, &size, &packet);
				if (status != RM_OK)
					return status;
				
				RMSeekFile(pSendContext->f_bitstream, position, RM_FILE_SEEK_START);

				pSendContext->IFrameFSMState = RMasfIFrameFSM_Init;
				pSendContext->IFrameSize = size;

				sizeToRead = RMmin(buffersize, size);

				status = RMReadFile(pSendContext->f_bitstream, buffer, sizeToRead, &count);
				
				pSendContext->IFrameSize -= (RMint32)count;
				if (pSendContext->IFrameSize <= 0)
					pSendContext->IFrameSize = 0;
				RMDBGLOG((TRICKDBG, "filled buffer with %lu bytes, should read %lu, left %lu\n", 
					  count, sizeToRead, pSendContext->IFrameSize));
			}
			else {
				RMuint32 sizeToRead = RMmin(buffersize, (RMuint32)pSendContext->IFrameSize);
				
				status = RMReadFile(pSendContext->f_bitstream, buffer, sizeToRead, &count);

				pSendContext->IFrameSize -= (RMint32)count;
				if (pSendContext->IFrameSize <= 0)
					pSendContext->IFrameSize = 0;
				RMDBGLOG((TRICKDBG, "filled buffer with %lu bytes, should read %lu, left %lu\n", 
					  count, sizeToRead, pSendContext->IFrameSize));
			}
				
		}
		else if (pSendContext->isAudioOnlyFile)
			return RM_SKIP_DATA;
		else
			status = RMReadFile(pSendContext->f_bitstream, buffer, buffersize, &count);
	} else {
		status = RMReadFile(pSendContext->f_bitstream, buffer, buffersize, &count);
	}

	*bytesRead = count;

	RMDBGLOG((DISABLE, "buf: %02x %02x %02x %02x %02x %02x %02x %02x \n", 
		  buffer[0],
		  buffer[1],
		  buffer[2],
		  buffer[3],
		  buffer[4],
		  buffer[5],
		  buffer[6],
		  buffer[7]));

	return status;
	
}

/**
 * Setup the video decoder, according to the given context
 *
 * @param pSendContext - context to use for the setup
 * @return RM_OK on sucess
 */
static RMstatus setup_audio_decoder(struct asf_context *pSendContext)
{
	struct DCCAudioProfile audio_profile;
	struct DCCAudioSource *pAudioSource = NULL;
	struct RUABufferPool *pDMAuncompressed;
	RMstatus err;

	if (pSendContext == NULL)
		return RM_ERROR;

	RMDBGLOG((ENABLE, "*** setup_audio_decoder ***\n"));
	audio_profile.BitstreamFIFOSize = ASF_AUDIO_FIFO_SIZE;
 	audio_profile.XferFIFOCount = AUDIO_XFER_FIFO_COUNT;
	audio_profile.DemuxProgramID = pSendContext->DemuxProgramID;
	audio_profile.AudioEngineID = asf_audio_opt->AudioEngineID;
	audio_profile.AudioDecoderID = asf_audio_opt->AudioDecoderID; // Jacques: not sure...
	audio_profile.STCID = pSendContext->STCID;

	RMDBGLOG((ENABLE, "opening audio source\n"));
	err = DCCOpenAudioDecoderSource(pSendContext->dcc_info->pDCC, &audio_profile, &pAudioSource);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot open audio decoder %d\n", err));
		return RM_ERROR;
	}
	pSendContext->dcc_info->pAudioSource = pAudioSource;

	if (pSendContext->compressed_audio) {
		RMDBGLOG((ENABLE, "opening WMAPro DMApool\n"));
		err = RUAOpenPool(pSendContext->dcc_info->pRUA, 0,
				AUDIO_DMA_BUFFER_COUNT, AUDIO_DMA_BUFFER_SIZE_LOG2, 
				RUA_POOL_DIRECTION_SEND, &pDMAuncompressed);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error: cannot open dmapool for compressed audio - %d\n", err));
			return RM_ERROR;
		}
		pSendContext->pDMAuncompressed = pDMAuncompressed;
	}
	
	RMDBGLOG((ENABLE, "get audio decoder info\n"));
	err = DCCGetAudioDecoderSourceInfo(pAudioSource, 
			&(pSendContext->dcc_info->audio_decoder), 
			&(pSendContext->dcc_info->audio_engine), 
			&(pSendContext->dcc_info->audio_timer));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting audio decoder source information %d\n", err));
		return RM_ERROR;
	}

	if (pSendContext->compressed_audio) {
		if(pSendContext->vDecoder == (void *)NULL) {
			RMDBGLOG((ENABLE,"******** using RMF's WMAPRO decoder ********\n"));
			err = RMCreateWMAProVDecoder(&(pSendContext->vDecoder));
			if (err != RM_OK) {
				RMDBGLOG((ENABLE,"error: cant create wmaproVdecoder!\n"));
				return RM_ERROR;
			}
			
			err = RMWMAProVDecoderOpen(pSendContext->vDecoder);
			if (err != RM_OK) {
				RMDBGLOG((ENABLE,"error: cant open wmaproVdecoder!\n"));
				return RM_ERROR;
			}
		}
	}

	return RM_OK;
}


	
//----------WMA
struct struct_context 
{
	struct RUABufferPool *pDMA;
	struct RUABufferPool *pPCMXDMA[9];
	RMbool FirstSystemTimeStamp;
	RMuint32 FirstPTS;
	struct dcc_context *dcc_info;

	RMfile		f_bitstream;
	RMfile		f_pcmxbitstream[9];

  RMuint8   pcmx_mode[9];
  RMuint8   pcmx_bps[9];
  RMuint8   pcmx_endian[9];
  RMint32   pcmx_gain[9];
  RMreal   pcmx_panx[9];
  RMreal   pcmx_pany[9];
  RMbool    nodata[9];
  RMuint32  PCMXfcnt[9];
  
	RMint64		fileSize;
	RMbool		audio_decoder_initialized;
	RMbool		trickMode;
	RMuint32	audio_vop_tir;
	RMuint64	Duration;
	RMuint64	lastSTC;
	RMuint32	id;
	RMuint32	Ntimes;
	RMuint8		*buf;
	RMbool		buffer_used;
	RMuint32	byte_counter;
	RMuint32	file_offset;
	RMstatus	status;
	RMuint32	cmd;
	RMuint32	cmd_ex;
};

/////////////////////////////Support Multiple Audio Decoder PlayBack
RMuint32 task_count = 0;
static struct struct_context	context[MAX_TASK_COUNT];  //Task list similar to ply_mul_video
static struct dcc_context	    dcc_info[MAX_TASK_COUNT] = { {0, }, {0, } };
static struct dcc_context	    *pdcc_info[MAX_TASK_COUNT];
static struct playback_cmdline	playback_options[MAX_TASK_COUNT]; /*access through play_opt*/
static struct audio_cmdline 	audio_options[MAX_TASK_COUNT];/*access through disp_opt*/
static struct playback_cmdline *play_opt;
static struct audio_cmdline *audio_opt;
static struct RM_PSM_Context PSMcontext;
static struct RM_PSM_Actions actions;
static struct asf_context SendContext[MAX_TASK_COUNT] = {{0,},{0,}};
static struct stream_options_s stream_options[MAX_TASK_COUNT];
static struct RMfifo wmapro_fifo[MAX_TASK_COUNT];
static struct wmapro_buffer_info wmapro_info_array[MAX_TASK_COUNT][MAX_WMAPRO_INFO];

/////////////////////////
#define db(txt) fprintf(stderr,txt);
#ifdef TMP_FIX_MIX_WEIGHT_KEYS   //
static void mixer_set_weight_index(int decoder, int step)
{
	RMDBGLOG((ENABLE, "mixer_set_weight_index, step=%d\n", step));
	if(step < 0)
	{
	  RMuint32 ch;
	  RMuint32 abs_step = -step;
	  for(ch=0; ch<8; ch++)
	    (weight[decoder][ch] > abs_step) ? weight[decoder][ch]-=abs_step : 0;
	}
	else
	{
	  RMuint32 ch;
	  RMASSERT((step<100));
	  for(ch=0; ch<8; ch++)
	    (weight[decoder][ch] < (RMuint32)(100 - step)) ? weight[decoder][ch]+=step : 100;

	}
}

static void mixer_set_weight(int decoder)
{
	RMuint32 *sweight = weight[decoder];
	RMuint32 *pMixerValue = &cmdblock.MixerValue_ch0;
	RMuint32 ch=0;

	RMDBGLOG((ENABLE, "mixer_set_weight, decoder=%d\n", decoder));

	for(ch=0; ch<8; ch++)
	{
		RMASSERT((sweight[ch]>0));
		RMASSERT((sweight[ch]<=100));
		*pMixerValue++=(RMuint32)0x10000000 / (RMuint32)100 *  sweight[ch] ;
	}

	RUASetProperty( pdcc_info[decoder]->pRUA,
					pdcc_info[decoder]->audio_decoder,
					RMAudioDecoderPropertyID_MixerWeight,
					&cmdblock,
					sizeof(cmdblock),
					0);
}
#endif

static RMstatus OpenPCMXAudioDecoderSource
(struct DCC *pDCC, struct DCCAudioProfile *dcc_profile, struct DCCAudioSource **ppAudioSource)
{
	struct AudioDecoder_DRAMSizePCMX_in_type dram_in;
	struct AudioDecoder_DRAMSizePCMX_out_type dram_out;
	struct AudioDecoder_OpenPCMX_type profile;
	RMuint32 audio_decoder, audio_engine;
	RMuint32 nb_audio_engines, nb_audio_decoders;
	RMuint32 temp;
	RMstatus err;
  	RMuint32 tmp = (RMuint32)gMixingMode;

   /* ************************* */
	RMuint32 sample_rate;
    	struct AudioEngine_Volume_type volume;
	/* ************************* */

	*ppAudioSource = (struct DCCAudioSource *) RMMalloc(sizeof(struct DCCAudioSource));
	if (*ppAudioSource == NULL) {
		RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in system memory %lu!\n", sizeof(struct DCCAudioSource)));
		return RM_FATALOUTOFMEMORY;
	}

	RMMemset((void*)(*ppAudioSource), 0, sizeof(struct DCCAudioSource));

	(*ppAudioSource)->pRUA = pDCC->pRUA;

	// Get number of audio engines and audio decoders
	temp = AudioEngine;
	err = RUAExchangeProperty(pDCC->pRUA, Enumerator, RMEnumeratorPropertyID_CategoryIDToNumberOfInstances,
				  &temp, sizeof(temp), &nb_audio_engines, sizeof(nb_audio_engines));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting property  RMEnumeratorPropertyID_CategoryIDToNumberOfInstances %s\n",
			  RMstatusToString(err)));
		return err;
	}
	else {
		if (dcc_profile->AudioEngineID < nb_audio_engines)
			RMDBGLOG((ENABLE, "Number of audio engines: %d%s\n", (int) nb_audio_engines));
		else {
			RMDBGLOG((ENABLE, "Error: audio engine index %d out of range!!! Should be < %d\n",
				  (int) dcc_profile->AudioEngineID, (int) nb_audio_engines));
			err = RM_PARAMETER_OUT_OF_RANGE;
			return err;
		}
	}

	temp = AudioDecoder;
	err = RUAExchangeProperty(pDCC->pRUA, Enumerator, RMEnumeratorPropertyID_CategoryIDToNumberOfInstances,
				  &temp, sizeof(temp), &nb_audio_decoders, sizeof(nb_audio_decoders));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting property  RMEnumeratorPropertyID_CategoryIDToNumberOfInstances %s\n",
			  RMstatusToString(err)));
		return err;
	}
	else {
		if (dcc_profile->AudioDecoderID < (nb_audio_decoders / nb_audio_engines))
			RMDBGLOG((ENABLE, "Number of audio decoders: %d%s\n", (int) nb_audio_decoders));
		else {
			RMDBGLOG((ENABLE, "Error: audio decoder index %d out of range!!! Should be < %d\n",
				  (int) dcc_profile->AudioDecoderID, (int) (nb_audio_decoders / nb_audio_engines)));
			err = RM_PARAMETER_OUT_OF_RANGE;
			return err;
		}
	}

	audio_engine = EMHWLIB_MODULE(AudioEngine, dcc_profile->AudioEngineID);
	(*ppAudioSource)->engine_moduleID = audio_engine;
	{
  int i=0;
  for (i = 0; i <= 11; i++) {
		volume.Channel = i;
		volume.Volume = 0x10000000;
		DCCSP(pDCC->pRUA, audio_engine, RMAudioEnginePropertyID_Volume, &volume, sizeof(volume));
	}
	}


  // !!Hack!! We assume there are an equal amount of decoders per engine; (nb_audio_decoders / nb_audio_engines)
	// gives the number of decoders per engine. This is always better then hardcoding number to 2 like before.
	audio_decoder = EMHWLIB_MODULE(AudioDecoder, dcc_profile->AudioEngineID * (nb_audio_decoders / nb_audio_engines)
				       + dcc_profile->AudioDecoderID);
	(*ppAudioSource)->decoder_moduleID = audio_decoder;
	RMDBGLOG((ENABLE, "AudioDecoder: 0x%08lX\n", audio_decoder));

	sample_rate = 44100;
	DCCSP(pDCC->pRUA, audio_engine, RMAudioEnginePropertyID_SampleFrequency, &sample_rate, sizeof(sample_rate));

	/* we need 8 x 0x300(0x180) for Ac3, 8 x 0xF00 for WMA, 8 x 0x400 for WMAPRO => allocate maximum=8 x 0xF00 */
	dram_in.BitstreamFIFOSize0 = dcc_profile->BitstreamFIFOSize;
	dram_in.XferFIFOCount0 = dcc_profile->XferFIFOCount;
 	dram_in.BitstreamFIFOSize1 = dcc_profile->BitstreamFIFOSize;
	dram_in.XferFIFOCount1 = dcc_profile->XferFIFOCount;
	dram_in.BitstreamFIFOSize2 = dcc_profile->BitstreamFIFOSize;
	dram_in.XferFIFOCount2 = dcc_profile->XferFIFOCount;
	dram_in.BitstreamFIFOSize3 = dcc_profile->BitstreamFIFOSize;
	dram_in.XferFIFOCount3 = dcc_profile->XferFIFOCount;
	dram_in.BitstreamFIFOSize4= dcc_profile->BitstreamFIFOSize;
	dram_in.XferFIFOCount4 = dcc_profile->XferFIFOCount;
	dram_in.BitstreamFIFOSize5= dcc_profile->BitstreamFIFOSize;
	dram_in.XferFIFOCount5 = dcc_profile->XferFIFOCount;
	dram_in.BitstreamFIFOSize6 = dcc_profile->BitstreamFIFOSize;
	dram_in.XferFIFOCount6 = dcc_profile->XferFIFOCount;
	dram_in.BitstreamFIFOSize7 = dcc_profile->BitstreamFIFOSize;
	dram_in.XferFIFOCount7 = dcc_profile->XferFIFOCount;
	dram_in.BitstreamFIFOSize8 = dcc_profile->BitstreamFIFOSize;
	dram_in.XferFIFOCount8 = dcc_profile->XferFIFOCount;


  err = RUAExchangeProperty(pDCC->pRUA, audio_decoder, RMAudioDecoderPropertyID_DRAMSizePCMX, &dram_in, sizeof(dram_in), &dram_out, sizeof(dram_out));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting property RMAudioDecoderPropertyID_DRAMSize! %s\n", RMstatusToString(err)));
		return err;
	}

	profile.BitstreamFIFOSize0  = dram_in.BitstreamFIFOSize0;
	profile.XferFIFOCount0 = dram_in.XferFIFOCount0;
	profile.BitstreamFIFOSize1  = dram_in.BitstreamFIFOSize1;
	profile.XferFIFOCount1 = dram_in.XferFIFOCount1;
	profile.BitstreamFIFOSize2  = dram_in.BitstreamFIFOSize2;
	profile.XferFIFOCount2 = dram_in.XferFIFOCount2;
	profile.BitstreamFIFOSize3  = dram_in.BitstreamFIFOSize3;
	profile.XferFIFOCount3 = dram_in.XferFIFOCount3;
	profile.BitstreamFIFOSize4  = dram_in.BitstreamFIFOSize4;
	profile.XferFIFOCount4 = dram_in.XferFIFOCount4;
	profile.BitstreamFIFOSize5  = dram_in.BitstreamFIFOSize5;
	profile.XferFIFOCount5 = dram_in.XferFIFOCount5;
	profile.BitstreamFIFOSize6  = dram_in.BitstreamFIFOSize6;
	profile.XferFIFOCount6 = dram_in.XferFIFOCount6;
	profile.BitstreamFIFOSize7  = dram_in.BitstreamFIFOSize7;
	profile.XferFIFOCount7 = dram_in.XferFIFOCount7;
	profile.BitstreamFIFOSize8  = dram_in.BitstreamFIFOSize8;
	profile.XferFIFOCount8 = dram_in.XferFIFOCount8;
	profile.UnProtectedAddress = 0;
	profile.UnProtectedSize = dram_out.UnProtectedSize;
//  profile.MixingMode = gMixingMode;
  tmp = (RMuint32)gMixingMode;
  err = RUASetProperty(pDCC->pRUA, audio_decoder, RMAudioDecoderPropertyID_PCMXMix, &tmp, sizeof(tmp),0);


  if (profile.UnProtectedSize > 0) {
		profile.UnProtectedAddress = DCCMalloc(pDCC, pDCC->dram, RUA_DRAM_UNCACHED, profile.UnProtectedSize);
		if (!profile.UnProtectedAddress) {
			RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in uncached DRAM %lu!\n", profile.UnProtectedSize, 0L));
			return RM_FATALOUTOFMEMORY;
		}
		RMDBGLOG((ENABLE, "(audio decoder : %lu) audio uncached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n", (*ppAudioSource)->decoder_moduleID, profile.UnProtectedAddress, profile.UnProtectedSize, profile.UnProtectedAddress + profile.UnProtectedSize));
	}
	(*ppAudioSource)->uncached_address = profile.UnProtectedAddress;

	DCCSP(pDCC->pRUA, audio_decoder, RMAudioDecoderPropertyID_OpenPCMX, &profile, sizeof(profile));

	return RM_OK;
}



static void init_globals(void)
{
	int i=0;
	for(i=0 ; i< MAX_TASK_COUNT;i++)
	SendContext[i].compressed_audio=FALSE;
	bypass_drm = FALSE;
	audioStreams = 0;
}

static void setcmd(struct RM_PSM_Context PSMcontex,RMbool sw)
{
	if(PSMcontext.currentActivePSMContext > 0)
	{
		sw?(context[0].cmd_ex |=  (RMuint32)(0x01)  << (PSMcontext.currentActivePSMContext-1)) : \
		   (context[0].cmd_ex &= ~((RMuint32)(0x01) << (PSMcontext.currentActivePSMContext-1)));
	}
}
static int iscmd(int decoder) 
{ 
	return	(context[decoder].status==0x00) && \
			((decoder==0)? (context[0].cmd_ex & 0x01) : (context[0].cmd_ex & 0x02)); 

}	

static void show_mixing_options()
{
   fprintf(stderr,"\n[Audio Mixing and Selection Commands]");
   fprintf(stderr,"\n----------------------");
   fprintf(stderr,"\nPAUSE: ? <dec#> space");
   fprintf(stderr,"\nPLAY:  ? <dec#> p");
   fprintf(stderr,"\nSTOP:  ? <dec#> s");
   fprintf(stderr,"\nQUIT:  q q");
   fprintf(stderr,"\nq k decrease weight 1st decoder");
   fprintf(stderr,"\nq l increase weight 1st decoder");
   fprintf(stderr,"\nq , decrease weight 2nd decoder");
   fprintf(stderr,"\nq . increase weight 2nd decoder\n");	
	
}

static void show_usage(char *progname)
{
	show_playback_options();
	show_audio_options();
	show_mixing_options();
	fprintf(stderr, "--------------------------------\n");
	fprintf(stderr, "Minimum cmd line: %s -task <task count> -c <codec> <file name>\n", progname);
	fprintf(stderr, "Minimum cmd line PCMX: %s -task 0 -c pcmx [stream count] [mode1] [bps1] [endian1] [gain1] [panx1] [pany1]... [file1.pcm]... -task 1 -c <codec> <file name>\n", progname);
	fprintf(stderr, "\t\tNote: Range for gain[i] is [-51, 12], -51 is muting, -50 = -50dB, -49 is -49dB, and so on\n");
	fprintf(stderr, "\t\tNote: Range for panx[i] and pany[i] is [-1.0, 1.0]\n");
	fprintf(stderr, "\nExample: %s -task 0 -ae 0 -ad 0 -c ac3 /media/elementary/ac3/SUZVGA1.AC3 -task 1 -ae 0 -ad 1 -c wma /media/asf/wma/music.wma", progname);
	fprintf(stderr, "\n1 channel PCMX/AC3 Mix Example: %s -task 0 -ae 0 -ad 0 -afreq 48000 -c ac3 /media/elementary/ac3/DOLBY.AC3 -task 1 -ae 0 -ad 1 -afreq 48000 -c pcmx 1 1 16 0 0 -1.0 -1.0 /media/elementary/pcm/pcm_greeting_16bit_msb_2ch_48k.pcm", progname);

	
	fprintf(stderr, "--------------------------------\n");

	exit(1);
}
static char* pcmx_filenames[9];
static int pcmx_fcnt=0;
static void parse_cmdline(int argc, char *argv[])
{
	int i;
	RMstatus err;
	
	if(task_count == 0) {
		play_opt = &playback_options[0];
		context[0].id = 0;
	}

	if (argc < 2) 
		show_usage(argv[0]);
	
	i = 1;
	while ((argc > i)) {
		if (argv[i][0] != '-') {
      if ((audio_opt->Codec!=AudioDecoder_Codec_PCMX) && (play_opt->filename == NULL))
			{
				play_opt->filename = argv[i];
				i++;
			}
      else if((audio_opt->Codec==AudioDecoder_Codec_PCMX) && (pcmx_fcnt < 9))
      {
        pcmx_filenames[pcmx_fcnt] = argv[i];
        pcmx_fcnt++;
        i++;
      }
			else
			{
				fprintf(stderr,"\nError Parse FILE "); fflush(stdout);
				show_usage(argv[0]);
			}
		}
		else if ( ! strcmp(argv[i], "-mix")) {
          gMixingMode =TRUE;
          i++;      
      }
		else if ( ! strcmp(argv[i], "-task")) {
			if (argc > i+1) {
				RMuint32 j = 0, task_index;
				task_index = strtol(argv[i+1], NULL, 10);
				i+=2;
			if (task_count > MAX_TASK_COUNT)
			{
				fprintf(stderr,"\nError Parse task-cnt "); fflush(stdout);
				show_usage(argv[0]);
				
			}
				for (j=0; j < task_count; j++) {
					if( task_index != context[j].id)
						continue;
				}
				if ( (task_count==0) || (j >= task_count)) {
					play_opt = &playback_options[task_count];
					audio_opt = &audio_options[task_count];
					context[task_count].id = task_index;
					task_count++;
				}
			}
			else
				{
				fprintf(stderr,"\nError Parse task "); fflush(stdout);
				show_usage(argv[0]);
				}
		}
		else {
			err = parse_playback_cmdline(argc, argv, &i, play_opt);
			if (err == RM_ERROR) 
			{
				fprintf(stderr,"\nError Parse play_opt\n"); fflush(stdout);
				show_usage(argv[0]);
			}

			if(!argv[i]) break;
			err = parse_audio_cmdline(argc, argv, &i, audio_opt);
			if (RMFAILED(err))
			{
				fprintf(stderr,"\nError Parse audio_opt\n"); fflush(stdout);
				show_usage(argv[0]);
			}
      //Special for PCMX
      if(audio_opt->Codec==AudioDecoder_Codec_PCMX)
      {
        int max_stream= strtol(argv[i], NULL, 10);
	int k=0;
	i++;
        for(k=0;k<max_stream;k++)
        {
           context[task_count-1].pcmx_mode[k] = strtol(argv[i], NULL, 10);
           i++;
           context[task_count-1].pcmx_bps[k] = strtol(argv[i], NULL, 10);
           i++;
           context[task_count-1].pcmx_endian[k] = strtol(argv[i], NULL, 10);
           i++;
           context[task_count-1].pcmx_gain[k] = strtol(argv[i], NULL, 10);
	   RMDBGLOG((ENABLE, "^^^^^^^^ Gain[%d]=%ld\n", k, context[task_count-1].pcmx_gain[k]));
           i++;
           //context[task_count-1].pcmx_pan[k] = strtol(argv[i], NULL, 10);
		   {
		   float tempf;
		   sscanf((const char*)argv[i], (const char*)"%f", &tempf);
		   context[task_count-1].pcmx_panx[k] = (RMreal)tempf;
		   RMDBGLOG((ENABLE, "^^^^^^^^^^^ pan_x = %f\n", k, context[task_count-1].pcmx_panx[k]));
           i++;
		   sscanf((const char*)argv[i], (const char*)"%f", &tempf);
		   context[task_count-1].pcmx_pany[k] = (RMreal)tempf;
		   RMDBGLOG((ENABLE, "^^^^^^^^^^^ pan_y = %f\n", k, context[task_count-1].pcmx_pany[k]));
           i++;
		   }
        }
      }
      
			if (err != RM_PENDING)
				continue;
		}
	}
}

static int Process_Key(RMbool release)
{
		RMstatus err = process_command(&PSMcontext, pdcc_info, &actions); 
		#ifdef TMP_FIX_MIX_WEIGHT_KEYS
			RMascii k;
		#endif
		if (RMFAILED(err)) 
		{
			fprintf(stderr, "Error while processing key %d\n", (unsigned int)err); 
			return PMA_QUIT;					
		}							
		if ((actions.cmd == RM_QUIT) && (!actions.cmdProcessed))  
		{					
		#ifdef TMP_FIX_MIX_WEIGHT_KEYS
			k= RMGetKey();
			switch(k)
				{
          case 'k':
						mixer_set_weight_index(0, -1);
						mixer_set_weight(0);
						break;
					case 'l':
						mixer_set_weight_index(0, 1);
						mixer_set_weight(0);
						break;
					case ',':
						mixer_set_weight_index(1, -1);
						mixer_set_weight(1);
						break;
					case '.':
						mixer_set_weight_index(1, 1);
						mixer_set_weight(1);
						break;
        default:
				if (release)	
				{	
					RUAReleaseBuffer(context[0].pDMA, context[0].buf);		
					RUAReleaseBuffer(context[1].pDMA, context[1].buf);		
				}	
				return PMA_QUIT;					
				break;
		
			}
				return 0x55;
		#else
				if (release)	
				{	
					RUAReleaseBuffer(context[0].pDMA, context[0].buf);		
					RUAReleaseBuffer(context[1].pDMA, context[1].buf);		
				}	
				return PMA_QUIT;					
		#endif
		}
		if ((actions.cmd == RM_PAUSED) && (!actions.cmdProcessed))  
		{					
				setcmd(PSMcontext,0x00);	
				return PMA_REDO;
		}
		if ((actions.cmd == RM_PLAY) && (!actions.cmdProcessed))  
		{					
  				setcmd(PSMcontext,0x01);	
				return PMA_REDO;
		}
		return PMA_OK;
}

static RMstatus StartAudioCapture(struct dcc_context *dcc_info, RMuint32 audio_capture, RMuint32 align, RMbool LSB_first,RMuint8 i)
{
	struct AudioCapture_Open_type capture_open;
	enum AudioCapture_Source_type capture_source;
	enum AudioCapture_SpdifDataType_type capture_type;
	enum AudioCapture_Capture_type cmd = AudioCapture_Capture_On;
	RMstatus err;

#if 1	//(EM86XX_CHIP == EM86XX_CHIPID_TANGO2)
{
	struct PLL_Frequency_type f;
	RMuint32 SampleClock;

	//printf("start set RCLK2...\n");
	SampleClock = 48000;
	f.PLL = PLLGen_cd_6;
	f.PLLOutput = PLLOut_1; // or _1 or _2
	f.MaxM = 31;
	f.Clock = ClockSignal_RClk2;
	f.Frequency = SampleClock * 256;
	RUASetProperty(dcc_info->pRUA, PLL, RMPLLPropertyID_Frequency, &f, sizeof(f), 0);
	//printf("finish set RCLK2...\n");
}
#endif


	memset(&capture_open, 0, sizeof(struct AudioCapture_Open_type));

	capture_open.CaptureMode = 1; // Pass-through
	capture_open.Delay = audio_options[i].CaptureDelay / 2; // Delay is 45000 Hz based start PTS
	capture_open.SI_CONF = 0x107 | (align << 3) | (LSB_first ? 0x200 : 0x000); // SerialIn Configuration
	capture_source = audio_options[i].CaptureSource;

	if (capture_source == 0)
		capture_open.SI_CONF = 0x109;
	else
		capture_open.SI_CONF = 0x100;


#if (EM86XX_CHIP == EM86XX_CHIPID_TANGO2)	//in 8634 Tango2 spdif is dedicated line
	if (capture_open.SI_CONF == 0x100)
		capture_open.SI_CONF = 0x900;	
#endif


	err = RUASetProperty(dcc_info[i].pRUA, audio_capture,
		RMAudioCapturePropertyID_Open,
		&capture_open, sizeof(capture_open), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error opening audio capture module!\n");
		return err;
	}

	capture_source = audio_options[i].CaptureSource;
	err = RUASetProperty(dcc_info[i].pRUA, audio_capture,
		RMAudioCapturePropertyID_Source,
		&capture_source, sizeof(capture_source), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error setting audio capture source!.\n");
		return err;
	}

	capture_type = audio_options[i].CaptureType;
	err = RUASetProperty(dcc_info[i].pRUA, audio_capture,
		RMAudioCapturePropertyID_SpdifDataType,
		&capture_type, sizeof(capture_type), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error setting audio capture type!.\n");
		return err;
	}

	err = RUASetProperty(dcc_info[i].pRUA, audio_capture,
		RMAudioCapturePropertyID_Capture,
		&cmd, sizeof(cmd), 0);
	if (RMFAILED(err))
		fprintf(stderr, "Error sending capture ON command.\n");

	return err;
}
#if 0
static RMstatus StopAudioCapture(struct dcc_context *dcc_info, RMuint32 audio_capture,RMuint8 i)
{
	enum AudioCapture_Capture_type cmd = AudioCapture_Capture_Off;
	RMuint32 temp = 0;
	RMstatus err;

	err = RUASetProperty(dcc_info[i].pRUA, audio_capture,
			     RMAudioCapturePropertyID_Capture, &cmd, sizeof(cmd), 0);
	if (RMFAILED(err))

		fprintf(stderr, "Error sending capture OFF command.\n");

	err = RUASetProperty(dcc_info[i].pRUA, audio_capture, RMAudioCapturePropertyID_Close,
			     &temp, sizeof(temp), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error closing capture module!\n");
		return err;
	}
	return err;
}
#endif

static int PMAApplyDemuxOptions(int decoder,struct DCC* pDCC, struct RUA* pRUA)
{
	int i= decoder;
	struct playback_cmdline* play_opt = &playback_options[i];
	RMstatus err=RM_OK;
		context[i].pDMA = NULL;
		context[i].buf = NULL;
		context[i].buffer_used = FALSE;
		context[i].f_bitstream = NULL;
		context[i].FirstSystemTimeStamp = TRUE;
		context[i].byte_counter = 0;

		dcc_info[i].chip_num = play_opt->chip_num;
		dcc_info[i].pRUA = pRUA;
		dcc_info[i].pDCC = pDCC;
		dcc_info[i].route = DCCRoute_Main;
		dcc_info[i].RM_PSM_commands |=RM_PSM_ENABLE_PAUSE;
		dcc_info[i].RM_PSM_commands |=RM_PSM_ENABLE_STOP;
		dcc_info[i].RM_PSM_commands |=RM_PSM_ENABLE_PLAY;
		pdcc_info[i] =&dcc_info[i];		
		err = apply_playback_options(&dcc_info[i], play_opt);
		if (RMFAILED(err)) 
		{
			fprintf(stderr, "Cannot set playback options %d\n", err);
			return -1;
		}
		
	return PMA_OK;
}

static int PMADemuxConfig(int decoder,struct DCC* pDCC, struct RUA* pRUA)
{
	int i =decoder;
	struct DCCStcProfile stc_profile;
	struct DCCAudioProfile audio_profile;
	struct playback_cmdline* play_opt = &playback_options[i];
	struct audio_cmdline* audio_opt   = &audio_options[i];
	RMstatus err=RM_OK;

	stc_profile.STCID = i;
	stc_profile.master = Master_STC;
	stc_profile.stc_timer_id = i*2; //0 2
	stc_profile.stc_time_resolution = 90000;
	stc_profile.video_timer_id = NO_TIMER;
	stc_profile.video_time_resolution = 0;
	stc_profile.video_offset = 0;
	stc_profile.audio_timer_id = i*2+1;  //1 3
			stc_profile.audio_time_resolution = 90000;
			stc_profile.audio_offset = 0;
		
		
			err = DCCSTCOpen(dcc_info[i].pDCC, &stc_profile, &dcc_info[i].pStcSource);
			if (RMFAILED(err)) 
			{
				fprintf(stderr, "Cannot open stc module %d\n", err);
				return -1;
			}

    //rex added audio in
	if (audio_opt->AudioIn) { // Audio pass-through
		struct AudioEngine_STC_type ae_stc;

		// Start Audio STC (has to be done before opening the AudioDecoder)
		ae_stc.Enable = TRUE;
		ae_stc.time_resolution = 90000;
		ae_stc.time = 0;
		err = RUASetProperty(dcc_info[i].pRUA,
			EMHWLIB_MODULE(AudioEngine, audio_opt->AudioEngineID),
			RMAudioEnginePropertyID_STC,
			&ae_stc, sizeof(ae_stc), 0);
	}
		
			//------Open Audio Profile Modules
			audio_profile.BitstreamFIFOSize = (audio_opt->Codec!=AudioDecoder_Codec_PCMX)?AUDIO_FIFO_SIZE : AUDIO_PCMX_FIFO_SIZE;
 			audio_profile.XferFIFOCount = (audio_opt->Codec!=AudioDecoder_Codec_PCMX)?XFER_FIFO_COUNT : XFER_PCMX_FIFO_COUNT;
			audio_profile.DemuxProgramID = i;
			audio_profile.AudioEngineID = audio_opt->AudioEngineID;
			audio_profile.AudioDecoderID = audio_opt->AudioDecoderID; // Jacques: not sure...
			audio_profile.STCID = i;
	
      if(audio_opt->Codec!=AudioDecoder_Codec_PCMX)
      {
        err = DCCOpenAudioDecoderSource(dcc_info[i].pDCC, &audio_profile, &dcc_info[i].pAudioSource);
  			if (RMFAILED(err)) 
	  		{
		  		fprintf(stderr, "Cannot open audio decoder %d\n", err);
			  	return -1;
  			}
     }
     else
     {
        err = OpenPCMXAudioDecoderSource(dcc_info[i].pDCC, &audio_profile, &dcc_info[i].pAudioSource);
//      err = DCCOpenAudioDecoderSource(dcc_info[i].pDCC, &audio_profile, &dcc_info[i].pAudioSource);
  			if (RMFAILED(err))
	  		{
		  		fprintf(stderr, "Cannot open audio decoder %d\n", err);
			  	return -1;
  			}
      }

			dcc_info[i].state = (play_opt->start_pause) ? RM_PAUSED : RM_PLAYING;
			dcc_info[i].trickmode_id = RM_NO_TRICKMODE;
			dcc_info[i].seek_supported = FALSE;

			//----------Retrieve SRC Info
			err = DCCGetAudioDecoderSourceInfo(dcc_info[i].pAudioSource, &dcc_info[i].audio_decoder, &dcc_info[i].audio_engine, &dcc_info[i].audio_timer);
			if (RMFAILED(err)) 
			{
				fprintf(stderr, "Error getting audio decoder source information %d\n", err);
				return PMA_ERROR;
			}

      if(audio_opt->Codec!=AudioDecoder_Codec_PCMX)
      {
			//--------Open DMA Pool	
			err = RUAOpenPool(dcc_info[i].pRUA, dcc_info[i].audio_decoder, DMA_BUFFER_COUNT, DMA_BUFFER_SIZE_LOG2, RUA_POOL_DIRECTION_SEND, &context[i].pDMA);
			if (RMFAILED(err)) 
			{
				fprintf(stderr, "Error cannot open dmapool %d\n", err);
				return PMA_ERROR;
			}
      }
      else
      {
        int j=0;
        RMuint32 mIndex = EMHWLIB_MODULE_INDEX(dcc_info[i].audio_decoder);
        RMuint32 mCat = EMHWLIB_MODULE_CATEGORY(dcc_info[i].audio_decoder);
    
        for(j=0;j<pcmx_fcnt;j++) //pcmx_fcnt
        {
          context[i].nodata[j]=FALSE;
          context[i].PCMXfcnt[j]=0;
          err = RUAOpenPool(dcc_info[i].pRUA, EMHWLIB_TARGET_MODULE(mCat,mIndex,j), DMA_PCMX_BUFFER_COUNT, DMA_PCMX_BUFFER_SIZE_LOG2, RUA_POOL_DIRECTION_SEND, &context[i].pPCMXDMA[j]);
    			if (RMFAILED(err))
		    	{
				    fprintf(stderr, "Error cannot open dmapool %d\n", err);
    				return PMA_ERROR;
		    	}
        }
      }
      
			//--------Apply Audio Decoder /Engine Options
			err = apply_audio_engine_options(&dcc_info[i], audio_opt);
			if (RMFAILED(err)) 
			{
				fprintf(stderr, "Error applying audio engine options %d\n", err);
				return PMA_ERROR;

			}

			err = apply_audio_decoder_options(&dcc_info[i], audio_opt);
			if (RMFAILED(err)) {
				fprintf(stderr, "Error applying audio_decoder_options %d\n", err);
				return PMA_ERROR;
			}
      
			if (audio_opt->AudioIn)
			{
				err = DCCPlayAudioSource(dcc_info[i].pAudioSource);
				if (RMFAILED(err)) {
					fprintf(stderr, "Cannot play audio decoder %d\n", err);
					return PMA_ERROR;
					}

				// Start audio capture hardcoded to zero maybe using 1 or 2 dsps?
				err = StartAudioCapture(&dcc_info[i], \
					EMHWLIB_MODULE(AudioCapture,0),\
					audio_opt->AudioInAlign,\
					audio_opt->AudioInLSBfirst,i);
				if (RMFAILED(err)) {
				fprintf(stderr, "Error starting audio capture! %s\n", RMstatusToString(err));
				}
			}
			

		
      if(audio_opt->Codec!=AudioDecoder_Codec_PCMX && !audio_opt->AudioIn)
      {
        //--------Open the audio Bitstreams
	  		context[i].f_bitstream = open_stream(play_opt->filename, RM_FILE_OPEN_READ, 0);
		  	if (context[i].f_bitstream == NULL) 
			  {
				  fprintf(stderr, "Cannot open file %s\n", play_opt->filename);
  				return PMA_ERROR;
	  		}
		  	RMSizeOfOpenFile(context[i].f_bitstream, &context[i].fileSize);
        context[i].Duration = play_opt->duration / 1000;
  			context[i].audio_vop_tir = 90000;
	  		RMDBGLOG((ENABLE, "file: %s, size %llu, duration %llu\n", play_opt->filename, context[i].fileSize, play_opt->duration / 1000));
      }
      else
      {
        int ik=0;
        for(ik=0;ik<pcmx_fcnt;ik++)
        {
   	    	context[i].f_pcmxbitstream[ik] = open_stream(pcmx_filenames[ik], RM_FILE_OPEN_READ, 0);
    	   	if (context[i].f_pcmxbitstream[ik] == NULL)
		      {
				     fprintf(stderr, "Cannot open file %s\n", pcmx_filenames[ik]);
  				   return PMA_ERROR;
  	  		}
        }
      }

    		
	return RM_OK;
}


static int PMAAsfDemuxConfig(int decoder,struct DCC* pDCC, struct RUA* pRUA)
{
	int i=decoder;
	struct audio_cmdline*    audio_opt = &audio_options[i];
	struct playback_cmdline* play_opt = &playback_options[i];
	RMstatus err= RM_OK;
	struct DCCStcProfile stc_profile;

	//-----ASF
		if(audio_opt->Codec == AudioDecoder_Codec_WMAPRO)
		{
			SendContext[i].compressed_audio = TRUE;
		}
		asf_audio_opt=audio_opt;
		asf_play_opt=play_opt;
	
		SendContext[i].pRUA = pRUA;
		RMDBGLOG((ENABLE, "cmdline options, codec = %s, outputchannels %s\n", 
			  audio_opt->Codec == AudioDecoder_Codec_WMAPRO ? "WMAPRO":"WMA", 
			  audio_opt->WmaParams.OutputChannels == M_Wmapro_6 ? "6":"2 (downmix if necessary)"));

		init_private_options(&priv_opt);
		init_stream_options(&stream_options[i]);
	
		SendContext[i].vDecoder = (ExternWMAProVdecoder)NULL;
		SendContext[i].vASFDemux = (ExternalRMASFDemux)NULL;

		SendContext[i].video_stream_index = 0;
		SendContext[i].SendVideoPts = play_opt->send_video_pts;

		SendContext[i].audio_stream_index = 0;
		SendContext[i].SendAudioPts = play_opt->send_audio_pts;
		SendContext[i].pRUA = pRUA;
		SendContext[i].DemuxProgramID=i;
		SendContext[i].STCID=i;
		
		if(audio_opt->Codec == AudioDecoder_Codec_WMAPRO)
				SendContext[i].wmapro_fifo = RMfifo_open ((RMuint32) wmapro_info_array, sizeof(wmapro_info_array), (RMuint32) &wmapro_fifo);


			RMDBGLOG((ENABLE, "opening bitstream %s\n", play_opt->filename));
			SendContext[i].f_bitstream = open_stream(play_opt->filename, RM_FILE_OPEN_READ, &stream_options[i]);
			if (SendContext[i].f_bitstream == NULL) 
			{
				RMDBGLOG((ENABLE, "Bitstream file not found: %s\n", play_opt->filename));
				err = RM_ERROROPENFILE;
				return PMA_ERROR;
			}
			RMDBGLOG((ENABLE, "create demux\n"));
			RMCreateASFVDemux(&SendContext[i].vASFDemux);
			RMASFVDemuxInit(SendContext[i].vASFDemux, &SendContext[i]);
			RMASFVDemuxSetCallbacks
				(
				SendContext[i].vASFDemux,
				NULL,
				NULL,
				NULL,
				NULL,
				print_Audio_Stream_Properties,
				NULL,
				NULL,
				NULL,
				NULL,
				NULL,
				NULL,
				NULL,
				play_Payload,
				NULL,
				NULL,
				NULL);


			SendContext[i].dcc_info = &dcc_info[i];
			SendContext[i].video_vop_tir = 1000;
			SendContext[i].audio_vop_tir = 1000;
			SendContext[i].unsupported_video = FALSE;
			dcc_info[i].trick_supported = TRUE;
			dcc_info[i].seek_supported = TRUE;
			dcc_info[i].iframe_supported = TRUE;
	
		
			stc_profile.STCID = i;
			stc_profile.master = Master_STC;
			stc_profile.stc_timer_id = i*2;
			stc_profile.stc_time_resolution = SendContext[i].video_vop_tir;
			stc_profile.video_timer_id = NO_TIMER;
			stc_profile.video_time_resolution = 0;
			stc_profile.video_offset = 0;
			stc_profile.audio_timer_id = i*2+1;
			stc_profile.audio_time_resolution = SendContext[i].audio_vop_tir;
			stc_profile.audio_offset = 0;
		
			err = DCCSTCOpen(dcc_info[i].pDCC, &stc_profile, &dcc_info[i].pStcSource);
			if (RMFAILED(err)) 
			{
				fprintf(stderr, "Cannot open stc module %d\n", err);
				return -1;
			}
		
			if (dcc_info[i].seek_supported)
			{
				RMDBGLOG((ENABLE,"Seek supported, building the index\n"));
				err = RMASFVDemuxBuildIndexWithHandle(
						SendContext[i].vASFDemux, 
						SendContext[i].f_bitstream, 
						&SendContext[i].asf_packetSize, 
					    &SendContext[i].asf_Header_Object_Size
						);
				if ((SendContext[i].AudioStreamFound) && (!SendContext[i].VideoStreamFound))
					  SendContext[i].isAudioOnlyFile = TRUE;
		
				if (err != RM_OK) 
				{
					if (SendContext[i].isAudioOnlyFile) 
					{
						RMDBGLOG((ENABLE, ">>> No index, will use alternate seek support for WMA,disabling iframe mode\n"));
						dcc_info[i].trick_supported = TRUE;
					}
					else 
					{
						RMDBGLOG((ENABLE, ">>> No index, IFrame and Seek modes not supported\n"));
						dcc_info[i].seek_supported = FALSE;
						dcc_info[i].trick_supported = FALSE;
					}
					dcc_info[i].iframe_supported = FALSE;
				}
			}

			if (SendContext[i].unsupported_video) 
				return PMA_ERROR;
		
			RMDBGLOG((ENABLE, "opening DMApool\n"));
 			err = RUAOpenPool(dcc_info[i].pRUA, 0, ASF_DMA_BUFFER_COUNT, ASF_DMA_BUFFER_SIZE_LOG2, 
				              RUA_POOL_DIRECTION_SEND, &context[i].pDMA);
			if (RMFAILED(err)) 
			{
				RMDBGLOG((ENABLE, "Error cannot open dmapool %d\n", err));
				return PMA_ERROR;
			}
			
			SendContext[i].pDMA = context[i].pDMA;
 			SendContext[i].UncompressedBuffer = NULL;
			SendContext[i].drmError = RMASFVDemuxIsContentEncrypted(SendContext[i].vASFDemux, 
									&SendContext[i].isContentEncrypted);
			if (SendContext[i].drmError != 0) 
			{
				RMDBGLOG((ENABLE, "there was a error during DRM init\n"));
				bypass_drm = TRUE;
				SendContext[i].isContentEncrypted = FALSE;
			}

			if (SendContext[i].isContentEncrypted)
				RMDBGLOG((ENABLE, "Encrypted Content!\n"));

			if (bypass_drm) 
			{
				RMDBGLOG((ENABLE, "bypass DRM actived, payload callback wont decrypt\n"));
				SendContext[i].isContentEncrypted = FALSE;
			}
	
		return PMA_OK;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////
static int PMARewindFile(int decoder)
{
	int	i = decoder;
	struct audio_cmdline* audio_opt = &audio_options[decoder];
	
	if(audio_opt->Codec == AudioDecoder_Codec_WMAPRO || audio_opt->Codec == AudioDecoder_Codec_WMA)
	{
			RMint64 position = 0;
			RMSeekFile(SendContext[i].f_bitstream, SendContext[i].asf_Header_Object_Size+50, RM_FILE_SEEK_START);
			RMASFVDemuxResetState(SendContext[i].vASFDemux);
			RMGetCurrentPositionOfFile (SendContext[i].f_bitstream, &position);
			RMDBGLOG((ENABLE, "current position %llu\n", position));
			SendContext[i].IFrameFSMState = RMasfIFrameFSM_Disabled;
			SendContext[i].video_decoder_initialized = FALSE;
			SendContext[i].audio_decoder_initialized = FALSE;
			SendContext[i].FirstSystemTimeStamp = TRUE;
			SendContext[i].cmd = RM_PLAY;
			SendContext[i].prev_video_media_object_number = 0;
			SendContext[i].video_frame_counter = 0;
			SendContext[i].VideoByteCounter = 0;
			SendContext[i].video_last_pts = 0;
			SendContext[i].prev_audio_media_object_number = 0;
			SendContext[i].audio_frame_counter = 0;
			SendContext[i].AudioByteCounter = 0;
			SendContext[i].start_ms = play_opt->start_ms;
			if (dcc_info[i].state == RM_PLAYING_TRICKMODE) 
			{
				dcc_info[i].state = RM_PLAYING;
				dcc_info[i].trickmode_id = RM_NO_TRICKMODE;
			}
			SendContext[i].isTrickMode = FALSE;
			SendContext[i].isIFrameMode = FALSE;
		}
		else
    if(audio_opt->Codec == AudioDecoder_Codec_PCMX)
    {
        int ik=0;
        for(ik=0;ik<pcmx_fcnt;ik++)
        {
    			if ((RMSeekFile(context[i].f_pcmxbitstream[ik], 0, RM_FILE_SEEK_START) == RM_ERRORSEEKFILE))
		    	{
				    fprintf(stderr, "%lx_seeking file to beginning\n", context[i].id);
    				return PMA_READFILE_ERROR;
		    	}
        }
    }
    else
		{
			if ((RMSeekFile(context[i].f_bitstream, 0, RM_FILE_SEEK_START) == RM_ERRORSEEKFILE))
			{	
				fprintf(stderr, "%lx_seeking file to beginning\n", context[i].id);
				return PMA_READFILE_ERROR;
			}
		}
		return PMA_OK;
}

static int PMAInit(int decoder)
{
	int i = decoder;
	struct playback_cmdline* play_opt  = &playback_options[i];
	struct audio_cmdline*	 audio_opt = &audio_options[i];
	RMstatus err;
	
	//--------ASF
	if(audio_opt->Codec == AudioDecoder_Codec_WMAPRO || audio_opt->Codec == AudioDecoder_Codec_WMA)
	{
		if (context[i].Ntimes) 
		{  
			asfStop(&SendContext[i], RM_DEVICES_STC | RM_DEVICES_AUDIO | RM_DEVICES_VIDEO);
		}
		DCCSTCSetTime(dcc_info[i].pStcSource, 0, SendContext[i].video_vop_tir);
		DCCSTCSetSpeed(dcc_info[i].pStcSource, play_opt->speed_N, play_opt->speed_M);
		err = asfPlay(&SendContext[i], RM_DEVICES_AUDIO | RM_DEVICES_VIDEO, DCCVideoPlayFwd);
		if (err != RM_OK)
				return PMA_ERROR;
	}
	else
	{//NOASF
			context[i].status =0x00;	//reset EOF Flags
			if ( (audio_opt->Codec == AudioDecoder_Codec_PCM) && context[i].file_offset) 
			{
				RMuint32 BitsPerSample = 0;
				if ( audio_opt->SubCodec == 0 ) {
					BitsPerSample = audio_opt->PcmCdaParams.BitsPerSample;
					} else if ( audio_opt->SubCodec == 1 ) {
						BitsPerSample = audio_opt->LpcmVobParams.BitsPerSample;
					} else if ( audio_opt->SubCodec == 2 ) {
						BitsPerSample = audio_opt->LpcmAobParams.BitsPerSampleGroup1;
					}
					if(BitsPerSample == 24) {
						(void) RMSeekFile(context[i].f_bitstream, 12 - context[i].file_offset % 12, RM_FILE_SEEK_CURRENT);
					} else if(BitsPerSample == 20) {
						(void) RMSeekFile(context[i].f_bitstream, 10 - context[i].file_offset % 10, RM_FILE_SEEK_CURRENT);
					} else {	// 16 bits
						(void) RMSeekFile(context[i].f_bitstream, 2 - context[i].file_offset % 2, RM_FILE_SEEK_CURRENT);
					}
				}	
				context[i].file_offset = 0;
				context[i].FirstPTS = 0;
				if (context[i].Ntimes) 
				{	// first time in loop no need to stop
					DCCSTCStop(dcc_info[i].pStcSource);
					err = DCCStopAudioSource(dcc_info[i].pAudioSource);
					if (RMFAILED(err)) 
					{
						fprintf(stderr, "Cannot stop audio decoder %d\n", err);
						return PMA_ERROR;

					}
					err = RUAResetPool(context[i].pDMA);	// needed for no dram copy version on standalone
					if (RMFAILED(err)) 
					{
						fprintf(stderr, "Error cannot reset dmapool\n");
						return PMA_ERROR;

					}
				}

				if(audio_opt->Codec == AudioDecoder_Codec_PCMX)
				{
					RMuint32 k;
					RMDBGLOG((ENABLE, "((((((( SETTING AUDIO PCMX mixing properties for BDJ)))))))))\n"));

					for(k=0; k<9; k++)
					{
					 struct AudioDecoder_AudioBDJPanning_type BDJ_panning;
					 struct AudioDecoder_AudioBDJGain_type BDJ_gain;

					 BDJ_panning.src = k;
					 BDJ_panning.x = (RMint32)(context[i].pcmx_panx[k]*RMAUDIO_4_28_CONVERT);
					 BDJ_panning.y = (RMint32)(context[i].pcmx_pany[k]*RMAUDIO_4_28_CONVERT);
			         err = RUASetProperty(dcc_info[i].pRUA,
						                 dcc_info[i].audio_decoder,
									     RMAudioDecoderPropertyID_AudioBDJPanning,
										 &BDJ_panning,
										 sizeof(struct AudioDecoder_AudioBDJPanning_type), 0);
					 if (err != RM_OK)
						 return err;

					 BDJ_gain.src = k;
					 BDJ_gain.gain = context[i].pcmx_gain[k];
			         err = RUASetProperty(dcc_info[i].pRUA,
						                 dcc_info[i].audio_decoder,
									     RMAudioDecoderPropertyID_AudioBDJGain,
										 &BDJ_gain,
										 sizeof(struct AudioDecoder_AudioBDJGain_type), 0);

					}
				}

				//We change to start any other time!!
				err = DCCPlayAudioSource(dcc_info[i].pAudioSource);
				if (RMFAILED(err)) 
				{
					sleep (10);
					fprintf(stderr, "Cannot play audio decoder %d\n", err);
					return PMA_ERROR;
				}
	}//NOASF

	return PMA_OK;
}

static void PMASetFirstPTS(int i,struct emhwlib_info Info, RMuint32* Info_size)
{
			struct emhwlib_info* pInfo= &Info;
			struct audio_cmdline* audio_opt  = &audio_options[i];
	
			if (context[i].FirstSystemTimeStamp && audio_opt->Codec != AudioDecoder_Codec_WMAPRO &&  audio_opt->Codec != AudioDecoder_Codec_WMA)
			{
					RMDBGLOG((ENABLE, "first PTS : %lu\n", context[i].FirstPTS));
					DCCSTCSetTime(dcc_info[i].pStcSource, context[i].FirstPTS, 90000);
					DCCSTCPlay(dcc_info[i].pStcSource);
					context[i].FirstSystemTimeStamp = FALSE;
					Info.ValidFields = TIME_STAMP_INFO;
					Info.TimeStamp = context[i].FirstPTS;
			}
			else 
			{
					pInfo = NULL;
					*Info_size = 0;
					Info.ValidFields = 0;
					Info.TimeStamp = 0;
			}
}
///-------------------------
static void PMAAddEvents(struct RUAEvent e[], RMuint32* nEvents, RMuint32 mask, RMuint32 decoder)
{
		e[(int)(*nEvents)].ModuleID = decoder;
		e[(int)(*nEvents)].Mask = mask;
		(*nEvents)++;
}
///-------------------------
static int PMAAllFileDone()
{
	RMuint32 i=0; RMuint32 sum=0;
		for(i=0;i<task_count;i++) //MAX_TASK_COUNT
    {
			if(audio_options[i].AudioIn)
				context[i].status=0;
      	sum+=context[i].status;
    }

		if(sum >= task_count) //MAX_TASK_COUNT
		{
			db("\nDecoder out of data, quitting");
			return PMA_OK;
		}
		else 
		{
			if(sum > 0 && sum < task_count)//MAX_TASK_COUNT
			{
				fprintf(stderr,"\nPending..dec1[%x] dec2[%x]",(unsigned int)context[0].status,(unsigned int)context[1].status);	
			}
			return PMA_DECODER_PENDING;
		}
}
///------------------------
static int PMAGetBuffer(int i,RMuint32 m)
{
//       fprintf(stderr,"\nentering getbuffer");


      if (context[i].buf == NULL) 
			{

         if(audio_options[i].Codec!=AudioDecoder_Codec_PCMX)
         {
          if (RUAGetBuffer(context[i].pDMA, &context[i].buf, GETBUFFER_TIMEOUT_US) != RM_OK) 
					{
						context[i].buf = NULL;
						#ifdef DBX
							fprintf(stderr,"\ngetbuf failed %d ",(unsigned int)i);
						#endif						
							return PMA_GETBUFFER_ERROR;
					}
					else
					{
						#ifdef DBX
							fprintf(stderr,"\ngetbuf succeed %d  obtained DMA [%x] BUF[%x]",(unsigned int)i,(unsigned int)context[i].pDMA, (unsigned int)context[i].buf);
						#endif
   							return PMA_OK;

					}
        }
        else //PCMX get buffer
        {
 					 //fprintf(stderr,"\ntry getbuffer pcmx# %d",(unsigned int)pcmx_rcnt);
           if (RUAGetBuffer(context[i].pPCMXDMA[pcmx_rcnt], &context[i].buf, 0) != RM_OK)
					 {
						context[i].buf = NULL;
						#if 0
							fprintf(stderr,"\ngetbuf failed pcmx# %d",(unsigned int)pcmx_rcnt);
						#endif
 							return PMA_GETBUFFER_ERROR;
					 }
				 	else
					{
						#if 0
							fprintf(stderr,"\ngetbuf %x succeed pcmx# %d",(unsigned int)context[i].buf,(unsigned int)pcmx_rcnt);
						#endif
   							return PMA_OK;

					}
        }
			}
			else
      {
         // fprintf(stderr,"buffer not null");
          return PMA_GETBUFFER_ERROR;
      }
}
///-----------------------
static int PMAReadData(int i,RMuint32* count)
{
			struct InbandCommand_type InbandCmd;
			struct playback_cmdline* play_opt =&playback_options[i];
			struct audio_cmdline* audio_opt =&audio_options[i];
			RMuint32 status=RM_OK;
			struct RUAEvent we;
      RMuint32 hdr=0;


			if(nEOS[i]!=0)
			{
				we.ModuleID = dcc_info[i].audio_decoder;
				we.Mask = RUAEVENT_INBAND_COMMAND;
				if(RUAWaitForMultipleEvents(dcc_info[i].pRUA, &we, 1, WAIT_EOS_TIMEOUT_US, 0) != RM_OK) 
				{
					nEOS[i]=1;
					return PMA_EOS_PENDING;		
				}
				else
				{
					nEOS[i]=0;
					if(play_opt->loop_count > 1 || play_opt->infinite_loop)
					{
							if(!play_opt->infinite_loop)
								play_opt->loop_count--;
							context[i].Ntimes++;
							fprintf(stderr,"\nLoop %d Times-dec %d",(unsigned int)context[i].Ntimes,(unsigned int)i);
					}
					return nStatus[i];
				}
			}

			//Codec Specific Read processing
			if(audio_opt->Codec == AudioDecoder_Codec_WMAPRO || audio_opt->Codec == AudioDecoder_Codec_WMA)
			{
				status = readBitstream(&SendContext[i], context[i].buf, (RMuint32*)count);
				if (status == RM_SKIP_DATA) 
				{
					RMuint64 currentTime;
					DCCSTCGetTime(SendContext[i].dcc_info->pStcSource, &currentTime, 
						          SendContext[i].video_vop_tir);
					if (currentTime > SendContext[i].lastSTC + SendContext[i].video_vop_tir) 
					{
						SendContext[i].lastSTC = currentTime;
					}
				}
			}
			else
			{
         if(audio_opt->Codec!=AudioDecoder_Codec_PCMX)
         {
     				status = RMReadFile(context[i].f_bitstream, context[i].buf,
  						  (1<<DMA_BUFFER_SIZE_LOG2), (RMuint32*)count);
         }
         else
         {
           //pcmx_rcnt
           //           pcmx_rcnt=0;
         
           RMuint32 tsz=0;
           RMuint32 currsz=0;
           RMuint8* wptr = context[i].buf;
           RMuint32 sync=0xAA00BB11;
           RMuint32 actualsz = 256 * (context[i].pcmx_bps[pcmx_rcnt])/8 * ((context[i].pcmx_mode[pcmx_rcnt]==1)?2:1)  ; //number of bytes in 256 samples
           hdr = 256; //calculate the number of samples
           hdr = hdr << 21;
           hdr = hdr | ((context[i].pcmx_mode[pcmx_rcnt]<<20) & 0x00100000);
           hdr = hdr | ((context[i].pcmx_bps[pcmx_rcnt]==8)?((0<<17)  & 0x000E0000) :
                       (context[i].pcmx_bps[pcmx_rcnt]==16)?((1<<17)  & 0x000E0000) :
                       (context[i].pcmx_bps[pcmx_rcnt]==20)?((2<<17)  & 0x000E0000) :((3<<17)  & 0x000E0000));

           hdr = hdr | ((context[i].pcmx_endian[pcmx_rcnt]<<16)  & 0x00010000);

		   // We don't need this pan mode since we use property call now.
		   // David, 12/12/2006
           //hdr = hdr | ((context[i].pcmx_gain[pcmx_rcnt]<<8)  & 0x0000ff00);           
		   //hdr = hdr | ((context[i].pcmx_pan[pcmx_rcnt])  & 0x000000ff);

          for(tsz=0;tsz+actualsz+8 < (1<<DMA_BUFFER_SIZE_LOG2);)
          {
              memcpy(wptr,&sync,4);
              wptr+=4;
              memcpy(wptr,&hdr,4);
              wptr+=4;
              tsz+=8;
              status = RMReadFile(context[i].f_pcmxbitstream[pcmx_rcnt], wptr,actualsz, &currsz); //pcmx_rcnt
              if(status ==RM_ERRORENDOFFILE)
	      {
	      	if(!rptpcmx)
		{
		 printf("\ncurrsz greater");
		 status=RM_OK;
		 rptpcmx=TRUE;
		 tsz-=8;
		 break;
		}
		else
		{
		  tsz=0;
		  break; 
		 }
		 
	      }
              if(currsz < actualsz )
              {
                hdr = hdr & 0x001fffff;
                hdr = hdr | ((currsz*8/((context[i].pcmx_mode[pcmx_rcnt]==1)?2:1)/(context[i].pcmx_bps[pcmx_rcnt]))<<21);
                memcpy(wptr-4,&hdr,4);
              }
              wptr+=currsz;
              tsz+=currsz;
          }
          *count =tsz;
          fprintf(stderr, "\n ------------Sent Chunk %d bytes",(unsigned int)tsz);

	  

         }
         
			}

    		
		//Common Routines
			if (status == RM_ERRORREADFILE) 
			{
						db("reading file ");
            RUAReleaseBuffer(context[i].pDMA, context[i].buf);
            return PMA_READFILE_ERROR;
			}
			else 
			{
				if (status == RM_ERRORENDOFFILE /*&& *count==0*/) 
				{
						fprintf(stderr,"\nEOF - dec %d",(unsigned int)i);
            fprintf(stderr,"\npcmx # %d",(int)pcmx_rcnt);

           if(audio_opt->Codec==AudioDecoder_Codec_PCMX)
           {
                    RUAReleaseBuffer(context[i].pPCMXDMA[pcmx_rcnt], context[i].buf);
                    context[i].buf=NULL;

                    context[i].nodata[pcmx_rcnt]=TRUE;
//       							fprintf(stderr,"\nrelease buffer %x succeed pcmx# %d",(unsigned int)context[i].buf,(unsigned int)pcmx_rcnt);

                return PMA_READFILE_ERROR;
       }
           else
           {
            RUAReleaseBuffer(context[i].pDMA, context[i].buf);
						context[i].buf = NULL;
            }
						//------------Send Inband EOS Command
						we.ModuleID = dcc_info[i].audio_decoder;
						we.Mask = RUAEVENT_INBAND_COMMAND;
						RUAResetEvent(dcc_info[i].pRUA, &we);
						
						InbandCmd.Tag = EMhwlibInbandCommand_EOS \
									  | INBAND_COMMAND_TYPE_BYTECOUNT	\
									  | INBAND_COMMAND_ACTION_STOP \
									  | INBAND_COMMAND_NO_COORDINATE  \
									  | INBAND_COMMAND_ACTION_CONTINUE;
						InbandCmd.Coordinate = 0;

            if(audio_opt->Codec!=AudioDecoder_Codec_PCMX)
            RUASetProperty(dcc_info[i].pRUA, dcc_info[i].audio_decoder, 
							           RMGenericPropertyID_InbandCommand, &InbandCmd, sizeof(InbandCmd), 0);

						//Wait for inband events
	
						if((audio_opt->Codec!=AudioDecoder_Codec_PCMX))
						{
              if(RUAWaitForMultipleEvents(dcc_info[i].pRUA, &we, 1, WAIT_EOS_TIMEOUT_US, 0) != RM_OK) 
              nEOS[i]=1;
							nStatus[i] = (play_opt->loop_count > 1 || play_opt->infinite_loop)?
											PMA_READFILE_EOF_LOOP :PMA_READFILE_EOF;

							return PMA_EOS_PENDING;		
						}


						
						if(play_opt->loop_count > 1 || play_opt->infinite_loop)
						{
							if(!play_opt->infinite_loop)
								play_opt->loop_count--;
							context[i].Ntimes++;
							fprintf(stderr,"\nLoop %d Times-dec %d",(unsigned int)context[i].Ntimes,(unsigned int)i);
							return PMA_READFILE_EOF_LOOP;
						}
						else
						{
							context[i].status=0x01; //MArk EOF
							return PMA_READFILE_EOF;
						}
				}	
			}
			return PMA_OK;
}
///-------------------------
static int PMASendData(int i, RMuint32 count, struct emhwlib_info Info, RMuint32 Info_size,RMuint32 m)
{
		 	
			
			struct audio_cmdline* audio_opt =&audio_options[i];
			RMuint32 status;
			
printf("i=%d ", i);

			if(audio_opt->Codec == AudioDecoder_Codec_WMAPRO || audio_opt->Codec == AudioDecoder_Codec_WMA)
			{
				RMASFVDemuxDEMUX(SendContext[i].vASFDemux,context[i].buf, count);
				status = RM_OK;	//release the buffer now
			}
			else
			{
				if(audio_opt->Codec!=AudioDecoder_Codec_PCMX)
				{
printf("RUASendData=%x\n", i);
					status= RUASendData(dcc_info[i].pRUA, dcc_info[i].audio_decoder, context[i].pDMA, 
					 	 		   context[i].buf, count, &Info, Info_size);
				}
				else
				{
					RMuint32 mIndex = EMHWLIB_MODULE_INDEX(dcc_info[i].audio_decoder);
					RMuint32 mCat = EMHWLIB_MODULE_CATEGORY(dcc_info[i].audio_decoder);
					RMuint32 mID= EMHWLIB_TARGET_MODULE(mCat,mIndex,pcmx_rcnt); //pcmx_rcnt
					//Send to the appropiate modules!
printf("RUASendData=%x\n", i);

					status= RUASendData(dcc_info[i].pRUA, mID , context[i].pPCMXDMA[pcmx_rcnt], //pcmx_rcnt
					 	 		   context[i].buf, count, &Info, Info_size);
	    
                  
				}
			}

		     
			if(status ==RM_OK)
			{
				//RUAReleaseBuffer(context[i].pDMA, context[i].buf);
				if(audio_opt->Codec==AudioDecoder_Codec_PCMX)
				{
					context[i].PCMXfcnt[pcmx_rcnt]+=count;
					RUAReleaseBuffer(context[i].pPCMXDMA[pcmx_rcnt], context[i].buf);//pcmx_rcnt
// 						fprintf(stderr,"\nrelease buffer %x succeed pcmx# %d sent %d bytes",(unsigned int)context[i].buf, (unsigned int)pcmx_rcnt,(unsigned int)context[i].PCMXfcnt[pcmx_rcnt]);
	
				}
				else
				{
					RUAReleaseBuffer(context[i].pDMA, context[i].buf);
				}

				context[i].buf=NULL;
#ifdef DBX
				fprintf(stderr,"\nsendbuf succeed %d release DMA [%x] BUF[%x]",(unsigned int)i,(unsigned int)context[i].pDMA, (unsigned int)context[i].buf);
#endif						
				context[i].buf = NULL;
				context[i].file_offset += count;
			 }
			 else
			 {
#ifdef DBX
					fprintf(stderr,"\nsendbuf fail %d ",(unsigned int)i);
#endif
					return PMA_SENDDATA_ERROR;
			 }

			 return PMA_OK;
}
///------------------------
static int PMAWaitEvents(struct RUAEvent e[],int nEvents)
{
				#ifdef DBX
					db("\nClearing Events");
				#endif
				if(RUAWaitForMultipleEvents(dcc_info[0].pRUA, e, nEvents, SENDDATA_TIMEOUT_US, 0) != RM_OK) 
				{	
					#ifdef DBX
						db("\nWait M-events Timeout but continue next GETBUFFER");
					#endif
						
				}
				else
				{
					#ifdef DBX
						db("\nI got all events cleared!");
					#endif
				}
			return PMA_OK;
}

////////////////////X START//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int main(int argc, char *argv[])
{
	RMuint32 i=0; //Loop temp counters
	RMstatus err;
	struct DCC *pDCC = NULL;
	struct RUA *pRUA = NULL;
	RMuint32 cmd;
	struct dh_context dh_info[MAX_TASK_COUNT] = {{0,},};
	time_t secold,secnow;
	
	//--------ASF
	init_globals();
	#ifdef TMP_FIX_MIX_WEIGHT_KEYS
//	cmdblock.MixerValue=(RMuint32)0x10000000; //100% mixing default
//	weight[0] =  weight[1] = 100;
	#endif

	cmd =0;
	//initialize the command extenstion
	context[0].cmd_ex = (RMuint32)0x03; //ALL ON

	//Initialize the Play otopions
	for( i=0; i < MAX_TASK_COUNT;i++) //MAX_TASK_COUNT
	{
		play_opt = &playback_options[i];
		audio_opt = &audio_options[i];
		audio_opt->dh_info = &dh_info[i];

		init_playback_options(play_opt);
		init_audio_options(audio_opt);
	}
	
	//Command Line Parsing and Initialize the Chip / uCode
	parse_cmdline(argc, argv);
	play_opt = &playback_options[0];
	audio_opt = &audio_options[0];
		

	err = RUACreateInstance(&pRUA, play_opt->chip_num);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error creating RUA instance! %d\n", err);
		return -1;
	}

	err = DCCOpen(pRUA, &pDCC);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error Open ing DCC! %d\n", err);
		return -1;
	}

	err = DCCInitMicroCodeEx(pDCC, DCCInitMode_LeaveDisplay);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot initialize microcode %d\n", err);
		return -1;
	}
	display_key_usage(KEYFLAGS);
	
	//Configure decoder parameters and allocate DMA spaces

	for( i=0 ; i < task_count ; i++) 
	{ 
		PMAApplyDemuxOptions(i, pDCC, pRUA);

		if( audio_options[i].Codec == AudioDecoder_Codec_WMAPRO 
		 || audio_options[i].Codec == AudioDecoder_Codec_WMA)
			PMAAsfDemuxConfig(i,pDCC,pRUA);
		else
			PMADemuxConfig(i,pDCC,pRUA);
#if 1		
		{
		 RMuint32 mIndex = EMHWLIB_MODULE_INDEX(dcc_info[i].audio_decoder);

		 if(task_count > 1 && mIndex == 1)
		 {
		   //+++++++++++++ Disable stc sync for play_multiple_audio +++++++++++++++++	
		   {		     
		     RMbool sync_stc = FALSE;

		     err = RUASetProperty(dcc_info[i].pRUA, dcc_info[i].audio_decoder, RMAudioDecoderPropertyID_SyncSTCEnable, &sync_stc, sizeof(RMbool), 0);
		
		     if (RMFAILED(err)) {
			fprintf(stderr, "Error disabling AV-Sync! %s\n", RMstatusToString(err));
			return err;
		     }	
		   }
		 }
		}
#endif        
	} 

	//Configure the State Machine

	RMTermInit(TRUE);    // don't allow ctrl-C and the like ...
	RMSignalInit(NULL, NULL);  // ... but catch other termination signals to call RMTermExit()
	PSMcontext.validPSMContexts = task_count;
	PSMcontext.currentActivePSMContext = 0;
	PSMcontext.keyflags = KEYFLAGS;


	//Seek the Playback files to appropiate positions and initialize decoders
	for(i=0; i<task_count;  i++)   
		if(!audio_options[i].AudioIn)
		PMARewindFile(i);	       	

	mainloop_no_seek:
	for (i=0; i< task_count; i++)
		if(!audio_options[i].AudioIn)
		PMAInit(i);

	//Loop for Sending Data / Reading Files
  secold=time(NULL);
	while(1)
	{ 
		RMuint32 count=0;
		struct emhwlib_info Info={0,};
		RMuint32 Info_size = 0;
		
		//-------Stop Condition----
		if(PMAAllFileDone()==PMA_OK)
			break;
		//-------Process Keys
			switch(Process_Key(FALSE))
			{
				case PMA_QUIT:
					goto cleanup;
					break;
				case PMA_REDO:
					goto mainloop_no_seek;
					break;
				default:
					break;
			}

 	//-------Send Data
		for(i=0; i < task_count; i++) //MAX_TASK_COUNT
		{ 
    //-------Profile
       secnow = time(NULL);
       if((unsigned long)secnow-(unsigned long)secold >= 1)
       {
         RMuint32 profile;
         secold = secnow;
        err = RUAGetProperty(dcc_info[i].pRUA,
                             dcc_info[i].audio_decoder,
                             RMGenericPropertyID_Profile,
                             &profile,
                             sizeof(profile));
          if (err == RM_OK) {
             printf("DSP %ld Usage = %lu%%\n", (unsigned long)i,profile);
          }
       }

      if(!audio_options[i].AudioIn && iscmd(i)) //Valid decoder to process
			{
					struct RUAEvent we;
					//Sneak in to decode as much WMAPRO as possible
					if(audio_opt->Codec == AudioDecoder_Codec_WMAPRO)
						try_decode_wmapro(&SendContext[i], FALSE);
					
					//InBand Command Event Arrive and we exit
					we.ModuleID = dcc_info[i].audio_decoder;
					we.Mask = RUAEVENT_INBAND_COMMAND;

          if((audio_opt->Codec!=AudioDecoder_Codec_PCMX) && !context[i].status && RUAWaitForMultipleEvents(dcc_info[i].pRUA, &we, 1, WAIT_EOS_TIMEOUT_US, 0) == RM_OK)
					{
						context[i].status=1; 
						break;
					} 
          
					//Try to get a buffer and send data
         	if(audio_options[i].Codec == AudioDecoder_Codec_PCMX)
          {
               pcmx_rcnt = (pcmx_rcnt+1) % pcmx_fcnt; //last step to increase the pcmx counter for next DMA
               if(context[i].nodata[pcmx_rcnt])
               {
    							fprintf(stderr,"\r EOF!!");
                  continue;
               }
          }

					if(PMAGetBuffer(i,0)==PMA_OK)	//pcmx_rcnt
					{
  					switch(PMAReadData(i,&count))
						{
							case PMA_EOS_PENDING:
								continue;
								break;
							case PMA_READFILE_ERROR:
								continue;
							case PMA_READFILE_EOF:	    //NO Rewind 
								continue;
								break;
							case PMA_READFILE_EOF_LOOP: //Have Rewind
							{
								PMARewindFile(i);
								PMAInit(i);
								continue;
							}
								break;
							default:
								break;
						}
						//Set the First PTS if necessary
						PMASetFirstPTS(i,Info,&Info_size);
						if(audio_options[i].Codec == AudioDecoder_Codec_WMAPRO 
						    || audio_options[i].Codec == AudioDecoder_Codec_WMA)
						{
							RMASFVDemuxDEMUX(SendContext[i].vASFDemux,context[i].buf, count);
							if (context[i].buf != NULL) 
							{
								RUAReleaseBuffer(SendContext[i].pDMA, context[i].buf);
								context[i].buf =NULL;	
							}
						}
						else
						{
							//Send data but if failed added event queue
							
							//if(i==0)
							//{
							if(PMASendData(i,count,Info,Info_size,pcmx_rcnt)==PMA_SENDDATA_ERROR)
							{
								PMAAddEvents(e,&nEvents,RUAEVENT_XFER_FIFO_READY,dcc_info[i].audio_decoder);
							}
							//}
    				}
					}
			}
		}
		//Wait for total events = task numbers
		if(nEvents==task_count)
				PMAWaitEvents(e,nEvents);
	} 

//-------------------CleanUp Routines	
cleanup:
	if( playback_options[0].waitexit || playback_options[1].waitexit ) 
	{
				RMascii key;
				if (audio_opt->AudioIn == 1) 
				{
					fprintf(stderr, "press q key to stop & quit, 's' to stop capture, 'g' to start capture...\n");
				} 
				else 
				{
					fprintf(stderr, "press q key again if you really want to stop & quit\n");
				}
				
				while ( !(RMGetKeyNoWait(&key) && ((key == 'q') || (key =='Q'))) );
	}
	
	for(i=0; i <task_count;i++) 
	{//for-5
		//-------TASK START	
			play_opt = &playback_options[i];
			audio_opt = &audio_options[i];
			
			if(audio_opt->Codec == AudioDecoder_Codec_WMAPRO || audio_opt->Codec == AudioDecoder_Codec_WMA)
			{
				RMuint32 i=0;
		
				if (SendContext[i].f_bitstream) 
				{
					RMDBGLOG((ENABLE, "closing bitstream %s\n", play_opt->filename));
					RMCloseFile(SendContext[i].f_bitstream);
				}	

				if (SendContext[i].vASFDemux) 
				{
					RMDBGLOG((ENABLE, "delete demux\n"));
					RMDeleteASFVDemux(SendContext[i].vASFDemux);
				}

				if (SendContext[i].vDecoder != (void *)NULL) 
				{
					RMDBGLOG((ENABLE, "closing WMAPRO decoder\n"));
					RMWMAProVDecoderClose(SendContext[i].vDecoder);
					RMDeleteWMAProVDecoder(SendContext[i].vDecoder);
					SendContext[i].vDecoder = (void *)NULL;
				}

				RMDBGLOG((ENABLE, "closing save files\n"));
				err = close_save_files(play_opt);
				if (RMFAILED(err)) 
				{
					RMDBGLOG((ENABLE, "Cannot close files used to save data %d\n", err));
				}
			}

			if (context[i].f_bitstream != NULL) 
				RMCloseFile(context[i].f_bitstream);

 			RMTermExit();

			DCCSTCStop(dcc_info[i].pStcSource);
			err=DCCStopAudioSource(dcc_info[i].pAudioSource);
			if (RMFAILED(err)) 
			{
				fprintf(stderr, "Cannot stop audio decoder \n");
			}
			else
				fprintf(stderr, "success Stop Audio Decoder \n");
		
			if (context[i].pDMA != NULL) 
			{
				err = RUAClosePool(context[i].pDMA);
				if (RMFAILED(err)) 
				{
					fprintf(stderr, "Error cannot close dmapool \n");
				}
			}
	
			if (dh_info[i].pDH != NULL) 
			{
				DHDone(dh_info[i].pDH);
				dh_info[i].pDH = NULL;
			}
	}//for-5

	for(i =0 ; i< task_count; i++)
	{
		err = DCCCloseAudioSource(dcc_info[i].pAudioSource);
		if (RMFAILED(err)) 
		{
			fprintf(stderr, "Error cannot close audio decoder \n");
		}
	}
	
	err = DCCClose(dcc_info[0].pDCC);
	if (RMFAILED(err)) 
	{
		fprintf(stderr, "Cannot close DCC \n");
	}

	err = RUADestroyInstance(dcc_info[0].pRUA);
	if (RMFAILED(err)) 
	{
		fprintf(stderr, "Cannot destroy RUA instance \n");
		return -1;
	}
	//------------------Return Routines
	return 0;
}
