#ifndef	__CHECKSUM_H__
#define __CHECKSUM_H__

#define CRCPOLY_BE 0x04c11db7
#define CRCPOLY_LE 0xedb88320

void crc32_init(void);
RMuint32 _crc32(RMuint8* buffer_start, RMuint32 buffer_width,
               RMuint32 xmin, RMuint32 xmax,
               RMuint32 ymin, RMuint32 ymax,
               RMuint8 hard_checksum, RMuint8 T);

RMuint32 crc32_be_h(void  *r, 
                  RMuint32 buffer_start, RMuint32 buffer_width,
                  RMuint32 xmin, RMuint32 xmax,
                  RMuint32 ymin, RMuint32 ymax);

#endif	// __CHECKSUM_H__

