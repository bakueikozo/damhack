
/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
*****************************************/

#include "../rmdef/rmdef.h"
#include "../rmdef/rmmm.h"
#include "../dcc/include/dcc.h"
#include "../emhwlib/include/emhwlib_propertytypes.h"
#include "../gbuslib/include/gbus_fifo.h"
#include "rmttx.h"

#if 0
#define RMTTXDBG ENABLE
#else
#define RMTTXDBG DISABLE
#endif

#if 1 
#define RMTTXERROR ENABLE
#else
#define RMTTXERROR DISABLE
#endif

#define EBU_LINE_COUNT 16 // per field
#define EBU_BYTES_PER_DATA_FIELD 44
#define EBU_SANE_BUF_SIZE ((EBU_BYTES_PER_DATA_FIELD+2)*EBU_LINE_COUNT + 10000000)

#define RMuint8mirrorBits( bits ) \
	( ( ((bits)&0x01)<<7 )  |  ( ((bits)&0x02)<<5 )  |  ( ((bits)&0x04)<<3 )  |  ( ((bits)&0x08)<<1 ) |   \
	  ( ((bits)&0x10)>>1 )  |  ( ((bits)&0x20)>>3 )  |  ( ((bits)&0x40)>>5 )  |  ( ((bits)&0x80)>>7 )  )

static void ttx_picture_init( struct EMhwlibTTXPicture * pic )
{
	RMuint32 i;
	for( i=0; i<2 ; i++ ) {
		pic->fields[i].field_parity = 0xff;
		pic->fields[i].framing_code = 0xff;
		pic->fields[i].line_mask = 0x00000000;
		RMMemset( (void*)(pic->fields[i].data), 0, TTX_MAX_LINES*TTX_MAX_BYTES_PER_LINE );
		pic->fields[i].display_flags = 0x00000000;
	}
	pic->pts = 0;
}


struct RMttx * RMTTXOpen( struct RUA * pRUA, RMuint32 fifo_module_id, RMuint32 ttx_fifo_size )
{
	struct RMttx * ttx;
	RMstatus err;
	struct TTXFifo_Open_type ttxopen;
	RMuint32 memorysize = 0;
	
	RMDBGLOG((RMTTXDBG, "RMTTXOpen open ttx\n" ));
	ttx = (struct RMttx * )RMMalloc( sizeof(struct RMttx) + RMTTX_BUFFER_SIZE ); 
	if( ! ttx ) {
		RMDBGLOG((RMTTXERROR, "RMTTXOpen cannot open ttx\n" ));
		return NULL;
	}
	
	ttx->pRUA = pRUA;
	ttx->fifo_module_id = fifo_module_id;
	ttx->decode_buffer = (RMuint8*)ttx + sizeof(struct RMttx);
	ttx->decode_buffer_size = 0;
	ttx_picture_init( &ttx->current_ttx ); // clean the memory contents

	// get memory size
	err = RUAExchangeProperty(pRUA, fifo_module_id, RMTTXFifoPropertyID_DRAMSize, &ttx_fifo_size, sizeof(ttx_fifo_size), &memorysize, sizeof(memorysize));
	if (RMFAILED(err)) {
		RMDBGLOG((RMTTXERROR, "RMTTXFifoPropertyID_DRAMSize %s\n", RMstatusToString(err) ));
		RMTTXClose( ttx );
		return NULL;
	}
	ttx->module_size = memorysize;
	RMDBGLOG((RMTTXDBG, "\n\nRMTTXFifoPropertyID_DRAMSize 0x%x\n", memorysize ));
	
	// allocate memory in phsical memory space
	ttx->module_address = RUAMalloc( pRUA, 0, RUA_DRAM_UNCACHED, memorysize ); // using dram 0 ?
	if (RMFAILED(err)) {
		RMDBGLOG((RMTTXERROR, "RUAMalloc error\n" ));
		RMTTXClose( ttx );
		return NULL;
	}
	RMDBGLOG((RMTTXDBG, "\n\nRUA_DRAM_UNCACHED 0x%lx\n", ttx->module_address ));
	
	// open the module
	ttxopen.EntryCount = ttx_fifo_size;
	ttxopen.UncachedAddress = ttx->module_address;
	ttxopen.UncachedSize = memorysize;
	ttxopen.STCModuleId = 0; // does not use stc at the memont
	err = RUASetProperty(pRUA, fifo_module_id, RMTTXFifoPropertyID_Open, &ttxopen, sizeof(ttxopen), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((RMTTXERROR, "RMTTXFifoPropertyID_Open %s\n", RMstatusToString(err) ));
		RMTTXClose( ttx );
		return NULL;
	}
	ttx->bts_byte_count = 0;
	return ttx;
}


void RMTTXClose( struct RMttx* ttx )
{
	RMstatus err;
	RMDBGLOG((RMTTXDBG, "RMTTXClose close ttx\n" ));
	if( !ttx ) {
		RMDBGLOG((RMTTXERROR, "RMTTXClose ttx does not exist\n" ));
		return;
	}
	err = RUASetProperty(ttx->pRUA, ttx->fifo_module_id, RMTTXFifoPropertyID_Close, 0, 0, 0);
	if (RMFAILED(err)) {
		RMDBGLOG((RMTTXERROR, "RMTTXFifoPropertyID_Close %s\n", RMstatusToString(err) ));
	}
	ttx->fifo_module_id = 0;
	RMDBGLOG((RMTTXDBG, "RMTTXFifoPropertyID_Close\n" ));

	if( ttx->module_address ) {
		RUAFree( ttx->pRUA, ttx->module_address );
	}
	else {
		RMDBGLOG((RMTTXERROR, "TTXFifo module memory does not exist\n" ));
	}
	RMFree( ttx );
	return;
}


void RMTTXFlush( struct RMttx* ttx )
{
	RMstatus err;
	RMDBGLOG((RMTTXDBG, "RMTTXFlush \n" ));
	
	if( !ttx ) {
		RMDBGLOG((RMTTXERROR, "RMTTXFlush module not exist\n"));
		return;
	}
	if( ttx->fifo_module_id == 0 ) {
		RMDBGLOG((RMTTXERROR, "TTXFifo emhwlib module does not exist\n"));
		return;
	}
	err = RUASetProperty(ttx->pRUA, ttx->fifo_module_id, RMTTXFifoPropertyID_Flush, 0, 0, 0);
	if (RMFAILED(err)) {
		RMDBGLOG((RMTTXERROR, "RMTTXFifoPropertyID_Flush %s\n", RMstatusToString(err) ));
	}
	ttx->bts_byte_count = 0;
	ttx->decode_buffer_size = 0;
 	return;
}


static void ttx_data_field( RMuint8* buf, RMuint32 size, struct EMhwlibTTXPicture * pic )
{
	RMuint32* linestart = 0;
	RMuint8 fp = 0;
	RMuint8 line = 0;
	RMuint32 i;
	RMuint8 tembuf[TTX_MAX_BYTES_PER_LINE];
	
	fp = (*buf & 0x20)>>5 ; // field_parity 0 or 1
	line = (*buf & 0x1f);   // line_offset 0 - 17 depending on tv system
	if( line < TTX_LINE_NUMBER_BASE || line >= TTX_MAX_LINES+TTX_LINE_NUMBER_BASE ) { // line is not defined
		RMDBGLOG((RMTTXDBG, "line number %d undefined or exceed max %d\n", line, TTX_MAX_LINES));
		return;
	}
	if( size >TTX_MAX_BYTES_PER_LINE ) {
		RMDBGLOG((RMTTXDBG, "line size %d exceed max, chop to %d \n", size, TTX_MAX_BYTES_PER_LINE));
		size = TTX_MAX_BYTES_PER_LINE;
	}
	line -= TTX_LINE_NUMBER_BASE; // pic->data starts from line 6 (or 318) regardless of tv system

	pic->fields[fp].line_mask |= (1<<line);
	pic->fields[fp].framing_code = *(buf+1); // frmaing code should not change
	buf += 2;
	size -= 2;

	linestart = pic->fields[fp].data;
	linestart += TTX_MAX_DWORD_PER_LINE * line;
	RMMemset( tembuf, 0, TTX_MAX_BYTES_PER_LINE );

	// arrange the bit order and byte order of ttx data to be the same as the ttx ram's arrangement
	// so less computation is needed in the irq
	for( i = 0; i < size; i++ ) {
		tembuf[i] = RMuint8mirrorBits(buf[i]);
	}
	for( i = 0; i < TTX_MAX_DWORD_PER_LINE; i++ ) {
		linestart[i] = RMleBufToUint32( &tembuf[i*4] );
	}
	RMDBGLOG((RMTTXDBG, "fp:%d, lo:%d, fc:0x%x mask 0x%lx  data 0x%08x 0x%08x ... 0x%08x 0x%08x\n", 
			fp, line, pic->fields[fp].framing_code, pic->fields[fp].line_mask,  linestart[0], linestart[1], linestart[TTX_MAX_DWORD_PER_LINE-2], linestart[TTX_MAX_DWORD_PER_LINE-1] ));
	return ;
}


// etsi en 300 472 implementation
static RMstatus RMTTXDecodePayload( struct RMttx* ttx, RMuint8* buf, RMuint32 size, RMuint64 pts )
{
	if( ttx == NULL ) {
		RMDBGLOG((RMTTXERROR, "RMTTXDecode Error No ttx decoder\n"));
		return RM_ERROR; 
	}
	if( size == 0 || size > EBU_SANE_BUF_SIZE ) {
		RMDBGLOG((RMTTXERROR, "RMTTXDecode empty buffer\n"));
		return RM_OK;
	}

	// check data identifier for EBU teletext data only
	if( *buf < 0x10 || *buf > 0x1f ) {
		RMDBGLOG((RMTTXERROR, "RMTTXDecode non-EBU data %d bytes\n", size));
		return RM_OK;
	}
	buf ++;
	size --;

	// start parsing data fields
	while( size > 0 && size < EBU_SANE_BUF_SIZE ) {
		RMuint8 data_unit_id;
		RMuint8 data_unit_length;
		data_unit_id = *buf;
		buf++; 
		data_unit_length = *buf;
		buf++; 
		size -=2;
		
		//RMassert( data_unit_length == EBU_BYTES_PER_DATA_FIELD );
						// data_unit_id defined by en300472
		if( data_unit_id == 0x02    // non-subtitle data, sent to composite out
		 || data_unit_id == 0x03    // subtitle data 
		 || data_unit_id == 0xc0 
		 || data_unit_id == 0xc1 
		) {
			RMDBGLOG((RMTTXDBG, "data id 0x%x\n", data_unit_id  ));
			ttx_data_field( buf, data_unit_length, &(ttx->current_ttx) );	
		}
		else if( data_unit_id == 0xc3 ) {  
			RMDBGLOG((RMTTXDBG, "vps data id 0x%x\n",data_unit_id ));
			//vps_data_field( pic );
		}
		else if( data_unit_id == 0xc4 ) { 
			RMDBGLOG((RMTTXDBG, "wss data id 0x%x\n",data_unit_id ));
			//wss_data_field( pic );
		}
		else if( data_unit_id == 0xc5 ) {
			RMDBGLOG((RMTTXDBG, "cc data id 0x%x\n",data_unit_id ));
			//closed_captioning_data_field( pic );
		}
		else if( data_unit_id == 0xc6 ) {
			RMDBGLOG((RMTTXDBG, "monochrome data id 0x%x\n",data_unit_id ));
			//monochrome_data_field( pic );
		}
		else if( data_unit_id == 0xff ) {
			//stuffing_data_field( pic );
		}
		else { // ignoreable data
			RMDBGLOG((RMTTXDBG, "ignor data id 0x%x\n",data_unit_id ));
		}
		buf += data_unit_length;
		size -= data_unit_length;
		//RMDBGLOG((RMTTXDBG, "%d\n", size));
	}

	return RM_OK;
}


// this function parse pes packet to extract pts and ttx data
RMstatus RMTTXDecode( struct RMttx* ttx, RMuint8* buf, RMuint32 size )
{
	if( ttx == NULL ) {
		RMDBGLOG((RMTTXERROR, "RMTTXDecode Error No ttx decoder\n"));
		return RM_ERROR; 
	}
	RMDBGLOG((RMTTXDBG, "\nRMTTXDecode new buffer size %d \n", size));
	ttx->bts_byte_count += size;

	if( ttx->decode_buffer_size ) { // if there is left over from last time use the leftover first
		if( size+ttx->decode_buffer_size <= RMTTX_BUFFER_SIZE ) {
			RMMemcpy( ttx->decode_buffer+ttx->decode_buffer_size, buf, size );
			buf = ttx->decode_buffer;
			size += ttx->decode_buffer_size;
		}
		else {
			RMDBGLOG((RMTTXDBG, "RMTTXDecode out of buffer space size %d \n", size+ttx->decode_buffer_size ));
		}
		ttx->decode_buffer_size = 0;
	}
	
	while( size > 0 ) { // decode a buffer with multiple PES packet
		RMuint32 length = 0;
		RMuint64 pts = 0;
		if( size < 6 ) {// less than minimum PES length
			RMDBGLOG((RMTTXERROR, "RMTTXDecode PES header error\n"));
			return RM_ERROR; 
		}
		while( ! (buf[0]==0x00 && buf[1]==0x00 && buf[2]==0x01 && buf[3]==0xbd) )
		{
			buf++;
			size--;
			if( size < 6 ) {
				RMDBGLOG((RMTTXDBG, "RMTTXDecode Error No PES sync\n"));
				return RM_OK; 
			}
		}
		buf += 4;
		size -= 4;
		length = ((RMuint32)buf[0] << 8) | (RMuint32)buf[1] ;
		RMDBGLOG((RMTTXDBG, "RMTTXDecode PES packet length %ld  size %ld \n", length, size));
		buf += 2;
		size -= 2;
		if( size < length ) { // incomplete pes
			size += 6;
			RMDBGLOG((RMTTXDBG, "RMTTXDecode imcomplete PES packet, keep data in the decode buffer, size %d \n", size));
			RMMemcpy(ttx->decode_buffer, buf-6, size);
			ttx->decode_buffer_size = size;
			return RM_OK; 
		}
		
		// get pts
		if( buf[1] & 0x80 ) { // pts exist
			pts = ( (RMuint64)(buf[3] & 0x0e) << 30 ) // bit 32:30  3
			    | ( (RMuint64)(buf[4] & 0xff) << 22 ) // bit 29:22  8
			    | ( (RMuint64)(buf[5] & 0xfe) << 15 ) // bit 21:15  7
			    | ( (RMuint64)(buf[6] & 0xff) << 7  ) // bit 14:7   8
			    | ( (RMuint64)(buf[7] & 0xfe) >> 1  );// bit  6:0   7 
			RMDBGLOG((RMTTXDBG, "RMTTXDecode PES pts 0x%llx\n", pts));
		}
		else {
			RMDBGLOG((RMTTXDBG, "RMTTXDecode Error No PTS\n"));
		}

		ttx->current_ttx.pts = pts;
		//RMDBGLOG((RMTTXDBG, "RMTTXDecode PES header length %d\n", buf[2]));
		if( RM_OK != RMTTXDecodePayload( ttx, buf+(buf[2]+3), length-(buf[2]+3), pts ) ) {
			RMDBGLOG((RMTTXERROR, "RMTTXDecode payload error\n"));
			return RM_ERROR; 
		}

		{
			RMstatus err;
			struct EMhwlibTTXPicture *pic = &(ttx->current_ttx);
			err = RUASetProperty(ttx->pRUA, ttx->fifo_module_id, RMTTXFifoPropertyID_TTXPicture, pic, sizeof(*pic), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((RMTTXERROR, "RMTTXFifoPropertyID_TTXPicture failed %s\n", RMstatusToString(err) ));
				return RM_ERROR;
			}
			RMDBGLOG((RMTTXDBG, "TTX decoded pts:0x%llx fc:0x%x mask1 0x%lx mask0 0x%lx\n", 
				  ttx->current_ttx.pts, 
				  ttx->current_ttx.fields[1].framing_code, 
				  ttx->current_ttx.fields[1].line_mask,
				  ttx->current_ttx.fields[0].line_mask  ));
			ttx_picture_init( &ttx->current_ttx ); // clean the memory contents
		}

		buf += length;
		size -= length;
	}
	return RM_OK;
}
