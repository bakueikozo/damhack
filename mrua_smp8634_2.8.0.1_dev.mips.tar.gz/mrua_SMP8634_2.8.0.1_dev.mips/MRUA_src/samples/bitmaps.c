/*****************************************
 Copyright © 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
*****************************************/


#include "sample_os.h"
#define ALLOW_OS_CODE 1
#include "common.h"
#include "bitmaps.h"	
#include "rmmemfile.h"
#include "rminputstream.h"
#if ((EM86XX_CHIP==EM86XX_CHIPID_TANGO15)&&(EM86XX_MODE==EM86XX_MODEID_STANDALONE))
#include "rua_memory.h"
#endif 


#define JPEG_MAX_LINES_PER_IMCU 32


static void create_gray_fields_420(RMuint32 width, RMuint32 height, RMuint8 *Y_plane, RMuint8 *UV_plane)
{
	RMuint32 i, j, k, x, y;
	RMuint8 luma;
	
	/* fill chroma buffer with 0x80 0x80 */
	for (y = 0; y < height; y+=2) {
		for (x = 0; x < width; x+=2) {
			*UV_plane++ = 0x80;
			*UV_plane++ = 0x80;
		}
	}
	
	/* slow but precise: fill luma buffer with zig-zag pattern from 0 to 255 */
	/* top 16th of image:   0 ..  15 */
	/* 2nd 16th of image:  31 ..  16 */
	/* 3rd 16th of image:  32 ..  47 etc. */
	/* bot 16th of image: 255 .. 240 */
	for (y = 0; y < height; y++) {
		j = y * 16 / height;
		for (x = 0; x < width; x++) {
			i = x * 16 / width;
			k = (j & 1) ? (15 - i) : i;
			luma = j * 16 + k;
			*Y_plane++ = luma;
		}
	}
}

static void create_gray_fields_RGB(RMuint32 width, RMuint32 height, RMuint8 *plane, RMuint8 alpha)
{
	RMuint32 i, j, k, x, y;
	RMuint32 pixel;
	
	/* slow but precise: fill pixel buffer with gray zig-zag pattern from 0 to 255 */
	/* top 16th of image:   0 ..  15 */
	/* 2nd 16th of image:  31 ..  16 */
	/* 3rd 16th of image:  32 ..  47 etc. */
	/* bot 16th of image: 255 .. 240 */
	for (y = 0; y < height; y++) {
		j = y * 16 / height;
		for (x = 0; x < width; x++) {
			i = x * 16 / width;
			k = (j & 1) ? (15 - i) : i;
			pixel = j * 16 + k;
			*plane++ = pixel;
			*plane++ = pixel;
			*plane++ = pixel;
			*plane++ = alpha;
		}
	}
}

static void create_burst_bit2_fields_RGB(RMuint32 width, RMuint32 height, RMuint8 *plane, RMuint8 alpha)
{
	RMuint32 x, y;
	
	for (y = 0; y < height; y++) {
		for (x = 0; x < width; x++) {
			*plane++ = (x & 1) ? 0 : 0xFB;
			*plane++ = (x & 1) ? 0 : 0xFF;
			*plane++ = (x & 1) ? 0 : 0xFF;
			*plane++ = alpha;
		}
	}
}

static void create_burst_bit2_1_fields_RGB(RMuint32 width, RMuint32 height, RMuint8 *plane, RMuint8 alpha)
{
	RMuint32 x, y;
	
	for (y = 0; y < height; y++) {
		for (x = 0; x < width; x++) {
			*plane++ = (x & 1) ? 0x04 : 0xFF;
			*plane++ = (x & 1) ? 0x00 : 0xFF;
			*plane++ = (x & 1) ? 0x00 : 0xFF;
			*plane++ = alpha;
		}
	}
}

static void rgb_to_yuv(RMuint8 r, RMuint8 g, RMuint8 b, RMuint8 *y, RMuint8 *cb, RMuint8 *cr)
{
	*y = r * 77 + g * 150 + b * 29;
	*cb = 128 + r * -43 + g * -85 + b * 128;
	*cr = 128 + r * 128 + g * 107 + b * 21;
}

static void create_grayrgb_fields_420(RMuint32 width, RMuint32 height, RMuint8 *Y_plane, RMuint8 *UV_plane)
{
	RMuint32 i, j, k, x, y, c;
	RMuint8 pixel, luma, cb, cr;
	
	/* slow but precise: fill luma buffer with zig-zag pattern from 0 to 255 */
	/* top 16th of image:   0 ..  15 */
	/* 2nd 16th of image:  31 ..  16 */
	/* 3rd 16th of image:  32 ..  47 etc. */
	/* bot 16th of image: 255 .. 240 */
	for (y = 0; y < height; y++) {
		j = y * 16 / height;
		c = (y * 64 / height) & 0x03;
		for (x = 0; x < width; x++) {
			i = x * 16 / width;
			k = (j & 1) ? (15 - i) : i;
			pixel = j * 16 + k;
			rgb_to_yuv(
				((c == 0) | (c == 1)) ? pixel : 0, 
				((c == 0) | (c == 2)) ? pixel : 0, 
				((c == 0) | (c == 3)) ? pixel : 0, 
				&luma, &cb, &cr);
			*Y_plane++ = luma;
			if (((x & 1) == 0) && ((y & 1) == 0)) {
				*UV_plane++ = cb;
				*UV_plane++ = cr;
			}
		}
	}
}

static void create_grayrgb_fields_RGB(RMuint32 width, RMuint32 height, RMuint8 *plane, RMuint8 alpha)
{
	RMuint32 i, j, k, x, y, c;
	RMuint32 pixel;
	
	/* slow but precise: fill pixel buffer with gray zig-zag pattern from 0 to 255 */
	/* top 16th of image:   0 ..  15 */
	/* 2nd 16th of image:  31 ..  16 */
	/* 3rd 16th of image:  32 ..  47 etc. */
	/* bot 16th of image: 255 .. 240 */
	for (y = 0; y < height; y++) {
		j = y * 16 / height;
		c = (y * 64 / height) & 0x03;
		for (x = 0; x < width; x++) {
			i = x * 16 / width;
			k = (j & 1) ? (15 - i) : i;
			pixel = j * 16 + k;
			*plane++ = ((c == 0) | (c == 3)) ? pixel : 0;  // blue
			*plane++ = ((c == 0) | (c == 2)) ? pixel : 0;  // green
			*plane++ = ((c == 0) | (c == 1)) ? pixel : 0;  // red
			*plane++ = alpha;  // alpha
		}
	}
}

static RMstatus open_bmp_file(struct RMbmpInfo *bmp_info, struct DCCOSDProfile  *profile )
{
	RMuint16 compression;
	RMuint32 p = 0, used_colors, read_size;
	RMstatus err;
	

	RMuint8 header_buf[54];

	err = RMReadFile(bmp_info->fp, header_buf, 54, &read_size); /*read the header */
	if(RMFAILED(err)){
		RMDBGLOG((ENABLE, "Failed to read the bmp header\n"));
		return RM_ERROR;
	}

	p = 18;
	bmp_info->width  = RMleBufToUint32(header_buf + p); p += 4;
	bmp_info->height = RMleBufToUint32(header_buf + p); p += 4;
	p += 2;
	bmp_info->bpp    = RMleBufToUint16(header_buf + p); p += 2;
	compression      = RMleBufToUint32(header_buf + p); p += 2;
	p += 14;
	used_colors      = RMleBufToUint32(header_buf + p); p += 4;

	if(compression != 0){
		RMDBGLOG((ENABLE, "BMP error: sub format not yet supported\n"));
		return RM_ERROR;
	}
		

	/* palette size */
	if (bmp_info->bpp < 16) 
		bmp_info->palette_size = (used_colors == 0) ? (RMuint32)(1<<bmp_info->bpp) : used_colors;
	else
		bmp_info->palette_size = 0;
	
	/* init profile structure */
	profile->ColorSpace = EMhwlibColorSpace_RGB_0_255;
	profile->SamplingMode = EMhwlibSamplingMode_444;
	profile->PixelAspectRatio.X = 1;
	profile->PixelAspectRatio.Y = 1;
	profile->Width = bmp_info->width;
	profile->Height = bmp_info->height;
 
	switch(bmp_info->bpp){
	case 1:
		profile->ColorMode = EMhwlibColorMode_LUT_1BPP;
		profile->ColorFormat = EMhwlibColorFormat_32BPP;
		profile->Width += (8-(bmp_info->width & 7))&7; /*make the image byte-aligned*/
		break;
	case 4:
		profile->ColorMode = EMhwlibColorMode_LUT_4BPP;
		profile->ColorFormat = EMhwlibColorFormat_32BPP;
		profile->Width += bmp_info->width & 1; /*make the image byte-aligned*/
		break;
	case 8:
		profile->ColorMode = EMhwlibColorMode_LUT_8BPP;
		profile->ColorFormat = EMhwlibColorFormat_32BPP;
		break;
	case 16:	
		profile->ColorFormat = EMhwlibColorFormat_16BPP_1555;
		profile->ColorMode = EMhwlibColorMode_TrueColor;
		break;
	case 24:
		profile->ColorFormat = EMhwlibColorFormat_32BPP;
		profile->ColorMode = EMhwlibColorMode_TrueColor;
		break;
	case 32: 
		profile->ColorFormat = EMhwlibColorFormat_32BPP;
		profile->ColorMode = EMhwlibColorMode_TrueColor;
		break;
	default:
		RMDBGLOG((ENABLE, "Invalid bitmap format: %ld bpp, has to be either 1, 4, 8, 16, 24 bpp!\n", bmp_info->bpp));
		return RM_ERROR;
	}


	return RM_OK;
}

static  RMstatus bmp_get_palette(RMuint32 *palette, struct RMbmpInfo *bmp_info)
{
	RMuint32 alpha_hi, read_size;
	RMstatus err;
	
	RMDBGLOG((ENABLE, "PALETTE SIZE is %ld\n", bmp_info->palette_size));

	err = RMSeekFile(bmp_info->fp, 54, RM_FILE_SEEK_START);
	if(RMFAILED(err)){
		RMDBGLOG((ENABLE, "RMSeekFile failed\n"));
		return RM_ERROR;
	}

	if (bmp_info->palette_size) {
		RMuint32 i;
		if (palette == NULL) {
			return RM_ERROR;
		}
		err = RMReadFile(bmp_info->fp, (RMuint8*)palette, 4*bmp_info->palette_size, &read_size);
		if(RMFAILED(err)){
			RMDBGLOG((ENABLE, "RMReadFile failed\n"));
			return RM_ERROR;
		}

		alpha_hi = (bmp_info->alpha<<24);
		for (i = 0; i < bmp_info->palette_size; i++) {
			palette[i] = (palette[i] & 0x00ffffff) | alpha_hi;
		}
	}
	return RM_OK;

}
static  RMstatus bmp_to_raw(RMuint8 *luma, struct RMbmpInfo *bmp_info)
{
	RMuint32 bpl, extrabytes, line, col, offs = 0, read_size; 
	RMuint32 *luma32;
	RMstatus err;
	RMuint8 *line_buf;
	
	/*replace this by a seek */
	err = RMSeekFile(bmp_info->fp, 54 + bmp_info->palette_size*4, RM_FILE_SEEK_START);
	if(RMFAILED(err)){
		RMDBGLOG((ENABLE, "RMSeekFile failed\n"));
		return RM_ERROR;
	}

	bpl = (bmp_info->width * bmp_info->bpp + 7) / 8; /* bytes per line */
	extrabytes =  (4 - ( bpl & 3)) & 3;  /* bytes to go after each line until a 4byte boundary */
	
	switch(bmp_info->bpp){
	case 1:
	case 4:
	case 8:
	case 16:
	case 32:
		for (line = 0; line < bmp_info->height; line++) {
			offs = (bmp_info->height - line - 1) * bpl;
			err = RMReadFile(bmp_info->fp, luma + offs, bpl, &read_size);
			if(RMFAILED(err)){
				RMDBGLOG((ENABLE, "RMReadFile failed\n"));
				return RM_ERROR;
			}
			if(extrabytes){
				err = RMSeekFile(bmp_info->fp, extrabytes, RM_FILE_SEEK_CURRENT);
				if(RMFAILED(err)){
					RMDBGLOG((ENABLE, "RMSeekFile failed\n"));
					return RM_ERROR;
				}
			}
		}
		
		break;
	case 24:
		luma32 = (RMuint32*) luma;
		line_buf = RMMalloc(bmp_info->width*4);
		for (line = 0; line < bmp_info->height; line++) {
			err = RMReadFile(bmp_info->fp, line_buf, bmp_info->width*3, &read_size);
			if(RMFAILED(err)){
				RMDBGLOG((ENABLE, "RMReadFile failed\n"));
				return RM_ERROR;
			}

			/* insert the unused bytes (!). Must be done
			   from end to beginning to not overwrite pixels*/
			for (col = 0; col < bmp_info->width; col++){
				line_buf[4*(bmp_info->width-col)-1] = bmp_info->alpha;
				line_buf[4*(bmp_info->width-col)-2] = line_buf[3*(bmp_info->width-col)-1];
				line_buf[4*(bmp_info->width-col)-3] = line_buf[3*(bmp_info->width-col)-2];
				line_buf[4*(bmp_info->width-col)-4] = line_buf[3*(bmp_info->width-col)-3];
			}

			offs = (bmp_info->height - line - 1) * 4 *(bmp_info->width);
			RMMemcpy(luma + offs, line_buf, bmp_info->width*4);
			if(extrabytes){
				err = RMSeekFile(bmp_info->fp, extrabytes, RM_FILE_SEEK_CURRENT);
				if(RMFAILED(err)){
					RMDBGLOG((ENABLE, "RMSeekFile failed\n"));
					return RM_ERROR;
				}
			}

		}
		RMFree(line_buf);
		break;
	default:
		break;
	}
	return RM_OK;
}


/* this is the callback used by libpng to read data */
static void png_read_data_rm_file(png_structp png_ptr, png_bytep buf, png_size_t size)
{
	RMfile fp = (RMfile)png_ptr->io_ptr;
	RMuint32 read_size;
	RMstatus err;
	do{	
		err = RMReadFile(fp, (RMuint8*)buf, (RMuint32)size, &read_size);
		size -= read_size;
	}while (RMSUCCEEDED(err) && (size));

	if(RMFAILED(err))
		png_error(png_ptr, "Read Error!");
}
/* this is the callback used by libungif to read data */
static int gif_read_data_rm_file(GifFileType *gif_ptr, GifByteType *buf, int size)
{
	RMfile fp = (RMfile)gif_ptr->UserData;
	RMuint32 read_size;
	RMstatus err;
	err = RMReadFile(fp, (RMuint8*)buf, (RMuint32)size, &read_size);
	if (RMFAILED(err)) 
		return -1;
	return (int)read_size;
}


static RMstatus open_png_file(struct RMpngInfo *png_info, struct DCCOSDProfile  *profile )
{
	png_uint_32 width, height;
	int bit_depth, color_type, interlace_type;

	png_info->gray_levels = 0;

	png_info->png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
	if (png_info->png_ptr == NULL){
		return RM_ERROR;
	}
	png_info->info_ptr = png_create_info_struct(png_info->png_ptr);
	if (png_info->info_ptr == NULL){
		goto cleanup;
	}
	if (setjmp(png_jmpbuf(png_info->png_ptr))){
		goto cleanup;
	}

	png_set_read_fn(png_info->png_ptr, (png_voidp)png_info->fp, png_read_data_rm_file);

	png_read_info(png_info->png_ptr, png_info->info_ptr);

	/*swap rgb */
	png_set_bgr(png_info->png_ptr);
	png_get_IHDR(png_info->png_ptr, png_info->info_ptr, &width , &height, &bit_depth, &color_type,
		&interlace_type, NULL, NULL);
	RMDBGLOG((ENABLE, "Width is %ld, Height is %ld, bit_depth %ld, color_type %ld\n", width, height, bit_depth, color_type));

	profile->ColorSpace = EMhwlibColorSpace_RGB_0_255;
	profile->SamplingMode = EMhwlibSamplingMode_444;
	profile->ColorFormat = EMhwlibColorFormat_32BPP;
	profile->PixelAspectRatio.X = 1;
	profile->PixelAspectRatio.Y = 1;
	profile->Width = png_info->width = width;
	profile->Height = png_info->height = height;
	/* we don't handle 16 bits per channel, strip to 8 */
	if (bit_depth == 16){
		png_set_strip_16(png_info->png_ptr);
		bit_depth = 8;
	}

	switch(color_type){
	case PNG_COLOR_TYPE_RGB:
		/* use the png transparency info for creating an alpha channel */
		if (png_get_valid(png_info->png_ptr, png_info->info_ptr, PNG_INFO_tRNS)) {
			png_set_tRNS_to_alpha(png_info->png_ptr);
			
		}
		/* or simply set the user's desired alpha */
		else{
			png_set_filler(png_info->png_ptr, png_info->alpha, PNG_FILLER_AFTER);
		}
		/* no break */
	case PNG_COLOR_TYPE_RGBA:
		profile->ColorMode = EMhwlibColorMode_TrueColor;
	        if(bit_depth != 8){
		}
		break;
	case PNG_COLOR_TYPE_GRAY:
		png_info->gray_levels = 1<<bit_depth;
		/*no break */
	case PNG_COLOR_TYPE_PALETTE:
		switch(bit_depth){
		case 8:	profile->ColorMode = EMhwlibColorMode_LUT_8BPP;	break;
		case 4:	profile->ColorMode = EMhwlibColorMode_LUT_4BPP;	break;
		case 2:	profile->ColorMode = EMhwlibColorMode_LUT_2BPP;	break;
		case 1:	profile->ColorMode = EMhwlibColorMode_LUT_1BPP;	break;
		default: goto cleanup;
		}
		break;
	default:
		goto cleanup;
		
	}
	/* this is possibly not needed...*/
	png_read_update_info(png_info->png_ptr, png_info->info_ptr);
	return RM_OK;
 cleanup:	
	png_destroy_read_struct(&(png_info->png_ptr), &(png_info->info_ptr), (png_infopp)NULL);
	return RM_ERROR;
	
}



static RMstatus png_to_raw(RMuint8 *luma, struct RMpngInfo *png_info)
{
	RMuint32 row;
	png_bytep row_pointers[png_info->height];
	RMuint8* row_start;
	row_start = luma;
	
	for (row = 0; row < png_info->height; row++){
		row_pointers[row] = row_start;
		row_start += png_get_rowbytes(png_info->png_ptr,png_info->info_ptr);
	}

	png_read_image(png_info->png_ptr, row_pointers);
	png_read_end(png_info->png_ptr, png_info->info_ptr);

	return RM_OK;
	
}

static  RMstatus png_get_palette(RMuint32 *palette, struct RMpngInfo *png_info)
{
	/* FIXME */
	png_colorp pal;
	int palette_size;
	RMuint32 row;
	palette_size = 256;
	if(png_info->gray_levels == 0){
		if(png_get_PLTE(png_info->png_ptr, png_info->info_ptr, &pal, &palette_size)){
			for(row = 0; row < (png_uint_32)palette_size; row++){
				palette[row] = (png_info->alpha<<24) | (pal[row].red<<16) | (pal[row].green<<8) | pal[row].blue;
			}
		}
		else
			return RM_ERROR;
	}
	else{
		RMuint32 level = 0, step = 0xff/(png_info->gray_levels-1);
		for(row = 0; row < png_info->gray_levels; row++){
			palette[row] = (png_info->alpha<<24) | (level<<16) | (level<<8) | level;
			level += step;
		}
	}
	return RM_OK;

}


static void png_cleanup(struct RMpngInfo *png_info)
{
	png_destroy_read_struct(&(png_info->png_ptr), &(png_info->info_ptr), (png_infopp)NULL);

}



static RMstatus jpeg_flip_rotate(RMfile in_fp, RMfile out_fp, JXFORM_CODE transform)
{
	struct jpeg_decompress_struct srcinfo;
	struct jpeg_compress_struct dstinfo;
	struct jpeg_error_mgr jsrcerr, jdsterr;
	jvirt_barray_ptr * src_coef_arrays;

	jvirt_barray_ptr * dst_coef_arrays;
	jpeg_transform_info transformoption; /* image transformation options */

	transformoption.transform = transform;
	transformoption.trim = FALSE;
	transformoption.force_grayscale = FALSE;
	transformoption.crop = FALSE;
	srcinfo.err = jpeg_std_error(&jsrcerr);
	jpeg_create_decompress(&srcinfo);
	dstinfo.err = jpeg_std_error(&jdsterr);
	jpeg_create_compress(&dstinfo);
	jsrcerr.trace_level = jdsterr.trace_level;
	srcinfo.mem->max_memory_to_use = dstinfo.mem->max_memory_to_use;
	jpeg_stdio_src_rm_file(&srcinfo, in_fp);
/* 	jcopy_markers_setup(&srcinfo, JCOPYOPT_DEFAULT); */

	(void) jpeg_read_header(&srcinfo, TRUE);
	jtransform_request_workspace(&srcinfo, &transformoption);
	src_coef_arrays = jpeg_read_coefficients(&srcinfo);
	jpeg_copy_critical_parameters(&srcinfo, &dstinfo);
	dst_coef_arrays = jtransform_adjust_parameters(&srcinfo, &dstinfo,
						       src_coef_arrays,
						       &transformoption);

	jpeg_stdio_dest_rm_file(&dstinfo, out_fp);
	jpeg_write_coefficients(&dstinfo, dst_coef_arrays);
/* 	jcopy_markers_execute(&srcinfo, &dstinfo, JCOPYOPT_DEFAULT); */
	jtransform_execute_transformation(&srcinfo, &dstinfo,
					  src_coef_arrays,
					  &transformoption);
	jpeg_finish_compress(&dstinfo);
	jpeg_destroy_compress(&dstinfo);
	(void) jpeg_finish_decompress(&srcinfo);
	jpeg_destroy_decompress(&srcinfo);
	return RM_OK;
}

static void my_jpeg_error_exit(j_common_ptr cinfo)
{
	jmp_buf env;
	RMbool do_longjmp = FALSE;

	if (cinfo->client_data != NULL) {
		RMMemcpy(&env, cinfo->client_data, sizeof(jmp_buf));
		do_longjmp = TRUE;
	}
	
	RMDBGLOG((ENABLE, "JPEG error: \n  "));
	(*cinfo->err->output_message)(cinfo);
	jpeg_destroy(cinfo);
	
	if (do_longjmp)
		longjmp(env, 1);
}

static RMstatus open_jpg_file(struct RMjpgInfo *jpg_info , struct DCCOSDProfile  *profile)
{

 	struct jpeg_decompress_struct *pCinfo = &(jpg_info->cinfo);
	jmp_buf long_jump_context;
	RMstatus err;
	
	if (setjmp(long_jump_context) != 0) {
		// we only get here due to a longjmp, so my_jpeg_error_exit was called, exit with error then
		pCinfo->client_data = NULL;
		return RM_ERROR;
	}
	// else, setjmp succeded and long_jump_context was saved


	pCinfo->err = jpeg_std_error(&(jpg_info->jerr));

	// setup our own exit handler
	pCinfo->err->error_exit = my_jpeg_error_exit;

	// setup our context
	pCinfo->client_data = (void *)&long_jump_context;

	jpeg_create_decompress(pCinfo);
#if ((EM86XX_CHIP==EM86XX_CHIPID_TANGO15)&&(EM86XX_MODE==EM86XX_MODEID_STANDALONE))
	jpeg_enable_special_large_memory_manager( (j_common_ptr)pCinfo, rua_malloc_large, rua_free_large );
#endif 

	jpeg_stdio_src_rm_file(pCinfo, jpg_info->fp);
	jpeg_read_header(pCinfo, TRUE);
	jpeg_calc_output_dimensions(pCinfo);

	jpg_info->force_420 = TRUE;

	if ((pCinfo->image_width <= 0) || (pCinfo->image_height <= 0)) {
		fprintf(stderr, "illegal image size: %d x %d pixel\n", pCinfo->image_width, pCinfo->image_height);
		err = RM_ERROR;
		goto exit_open_jpg;
	}
	

	if (!(jpg_info->force_rgb)){
		RMuint32 min_chunk, buf_width, buf_height;
		if (pCinfo->progressive_mode) {
			RMDBGLOG((ENABLE, "jpeg file must not be in progressive mode\n"));
			err = RM_ERROR;
			goto exit_open_jpg;
		}
		if (pCinfo->jpeg_color_space != JCS_YCbCr) {
			RMDBGLOG((ENABLE, "jpeg file needs to be in YUV color space\n"));
			err = RM_ERROR;
			goto exit_open_jpg;
		}

		if((pCinfo->comp_info[1].h_samp_factor != pCinfo->comp_info[2].h_samp_factor) ||
		   (pCinfo->comp_info[1].v_samp_factor != pCinfo->comp_info[2].v_samp_factor)){
			RMDBGLOG((ENABLE, "Unsupported jpeg type, different Cb and Cr sampling factors!\n"));
			err = RM_ERROR;
			goto exit_open_jpg;
		}
		if((pCinfo->comp_info[0].h_samp_factor == 2) && (pCinfo->comp_info[0].v_samp_factor == 2) &&
		   (pCinfo->comp_info[1].h_samp_factor == 1) && (pCinfo->comp_info[1].v_samp_factor == 1)){
			/*could change to support a more generic y:(2n,2n) u,v:(n,n) */
			jpg_info->sampling_mode = EMhwlibSamplingMode_420;
		}
		else if((pCinfo->comp_info[0].h_samp_factor == 2) && (pCinfo->comp_info[0].v_samp_factor == 1) &&
			(pCinfo->comp_info[1].h_samp_factor == 1) && (pCinfo->comp_info[1].v_samp_factor == 1)){
			/*could change to support a more generic y:(2n,n) u,v:(n,n) */
			jpg_info->sampling_mode = EMhwlibSamplingMode_422;
		}
		else if((pCinfo->comp_info[0].h_samp_factor == 1) && (pCinfo->comp_info[0].v_samp_factor == 1) &&
			(pCinfo->comp_info[1].h_samp_factor == 1) && (pCinfo->comp_info[1].v_samp_factor == 1)){
			/*could change to support a more generic y:(n,n) u,v:(n,n) */
			jpg_info->sampling_mode = EMhwlibSamplingMode_444;
			/* todo support 444->422 */
			jpg_info->force_420 = TRUE;
		}
		else{
			RMDBGLOG((ENABLE, 
				  "Unsupported jpeg type (luma(%d:%d), chroma(%d:%d))\n",
				  pCinfo->comp_info[0].v_samp_factor,
				  pCinfo->comp_info[0].h_samp_factor,
				  pCinfo->comp_info[1].v_samp_factor,
				  pCinfo->comp_info[1].h_samp_factor));
			err = RM_ERROR;
			goto exit_open_jpg;
		}


		if(pCinfo->max_v_samp_factor * pCinfo->min_DCT_scaled_size > JPEG_MAX_LINES_PER_IMCU){		
			RMDBGLOG((ENABLE, "Unsupported jpeg type (try setting a higher JPEG_MAX_LINES_PER_IMCU)\n"));
			err = RM_ERROR;
			goto exit_open_jpg;
		}

		pCinfo->raw_data_out = TRUE;
		pCinfo->out_color_space = JCS_YCbCr;
		profile->ColorSpace = EMhwlibColorSpace_YUV_601_0_255;
		profile->ColorMode = EMhwlibColorMode_VideoNonInterleaved;
		if(jpg_info->force_420)
			profile->SamplingMode = EMhwlibSamplingMode_420;
		else
			profile->SamplingMode = jpg_info->sampling_mode;

		profile->ColorFormat = EMhwlibColorFormat_32BPP;
		profile->PixelAspectRatio.X = 1;
		profile->PixelAspectRatio.Y = 1;

		buf_width = pCinfo->comp_info[0].width_in_blocks * pCinfo->min_DCT_scaled_size;
		min_chunk = pCinfo->comp_info[0].h_samp_factor * pCinfo->min_DCT_scaled_size;
		buf_width = (buf_width + min_chunk - 1) & ~(min_chunk -1);

		buf_height = pCinfo->comp_info[0].height_in_blocks * pCinfo->min_DCT_scaled_size;
		min_chunk = pCinfo->comp_info[0].v_samp_factor * pCinfo->min_DCT_scaled_size;
		buf_height = (buf_height + min_chunk - 1) & ~(min_chunk -1);

		profile->Width =  buf_width;
		profile->Height = buf_height;

	}
	else{
		profile->ColorSpace = EMhwlibColorSpace_RGB_0_255;
		profile->SamplingMode = EMhwlibSamplingMode_444;
		profile->ColorMode = EMhwlibColorMode_TrueColor;
		profile->ColorFormat = EMhwlibColorFormat_32BPP;
		profile->PixelAspectRatio.X = 1;
		profile->PixelAspectRatio.Y = 1;
		profile->Width = pCinfo->output_width;
		profile->Height = pCinfo->output_height;
		pCinfo->out_color_space = JCS_RGB;
	}


	pCinfo->dct_method = JDCT_ISLOW;
	pCinfo->scale_num = 1;
	pCinfo->scale_denom = 1;
	pCinfo->quantize_colors = FALSE;
	jpeg_start_decompress(pCinfo);
	jpg_info->width = pCinfo->output_width;
	jpg_info->height = pCinfo->output_height;
	err = RM_OK;
	
 exit_open_jpg:
	// remove our context. This context is invalid after the function returns
	pCinfo->client_data = (void *) NULL;
	if (RMFAILED(err)) {
		jpeg_destroy_decompress(pCinfo);
	}
	return err;
}	
	

static RMstatus jpg_to_raw(RMuint8 *luma, RMuint8 *chroma, struct RMjpgInfo *jpg_info)
{
 	struct jpeg_decompress_struct *pCinfo = &(jpg_info->cinfo);

	if(jpg_info->force_rgb){
		JSAMPARRAY 	buffer;			
		RMuint32	row_stride;		
		RMuint32	row;
		RMuint32	databyte, bufbyte;
		RMuint8		temp;
		row_stride = pCinfo->output_width * pCinfo->output_components;
		buffer = (*pCinfo->mem->alloc_sarray) ((j_common_ptr) pCinfo, JPOOL_IMAGE, row_stride, 1);

		for (row = 0; row < pCinfo->output_height; row++){
			jpeg_read_scanlines(pCinfo, buffer, 1);
			/* reverse row (gbr -> rgb) */
			/* todo: this can be done by the jpeglib -- see jmorecfg.h*/
			for(bufbyte = 0; bufbyte < row_stride; ){
				temp = (*buffer)[bufbyte];
				(*buffer)[bufbyte] = (*buffer)[bufbyte + 2];
				(*buffer)[bufbyte + 2] = temp;
				bufbyte += 3;
			}

			temp = 0;
 			for(databyte = 0, bufbyte = 0; databyte < 4 * pCinfo->output_width; databyte++){
				if((databyte + 1) % 4 != 0)
					luma[databyte + row * 4 * pCinfo->output_width]  = (*buffer)[bufbyte++];
				else
					luma[databyte + row * 4 * pCinfo->output_width]  = jpg_info->alpha;
			}
		}
	}
	else{
		JSAMPROW CB[JPEG_MAX_LINES_PER_IMCU], CR[JPEG_MAX_LINES_PER_IMCU], Y[JPEG_MAX_LINES_PER_IMCU];
		JSAMPARRAY jcomponents[3] = {Y, CB, CR};
		RMuint32 i, j, k, readlines = 0, lines_per_imcu, buffer_size = 0, chroma_offs, buf_offs, h_skip = 1, v_skip = 1, min_chunk; 
		RMuint32 luma_width, chroma_width, chroma_height, luma_height;
		RMuint8 *cr_buffer, *cb_buffer;
		if(jpg_info->force_420){
			switch(jpg_info->sampling_mode){
			case EMhwlibSamplingMode_422:
				v_skip = 2;
				h_skip = 1;
				break;
			case EMhwlibSamplingMode_444:
				v_skip = h_skip = 2;
				break;
			default:
				v_skip = h_skip = 1;
				break;
			}
		}
		
		lines_per_imcu = pCinfo->max_v_samp_factor * pCinfo->min_DCT_scaled_size;
		/*luma lines per imcu */	
		luma_height   = pCinfo->comp_info[0].v_samp_factor*pCinfo->min_DCT_scaled_size;
		/*chroma lines per imcu */	
		chroma_height = pCinfo->comp_info[1].v_samp_factor*pCinfo->min_DCT_scaled_size;
	       
		luma_width = pCinfo->comp_info[0].width_in_blocks * pCinfo->min_DCT_scaled_size;
		min_chunk = pCinfo->comp_info[0].h_samp_factor * pCinfo->min_DCT_scaled_size;
		luma_width = (luma_width + min_chunk - 1) & ~(min_chunk -1);
	
		chroma_width = pCinfo->comp_info[1].width_in_blocks * pCinfo->min_DCT_scaled_size;
		min_chunk = pCinfo->comp_info[1].h_samp_factor * pCinfo->min_DCT_scaled_size;
		chroma_width = (chroma_width + min_chunk - 1) & ~(min_chunk -1);

		if(pCinfo->comp_info[1].h_samp_factor != 1){
			RMuint32 min_chunk = pCinfo->comp_info[1].h_samp_factor * pCinfo->min_DCT_scaled_size;
			if((chroma_width % min_chunk) != 0)
				chroma_width += min_chunk -(chroma_width % min_chunk);
		}

		buffer_size = chroma_height * chroma_width;
		
		cr_buffer = RMMalloc(buffer_size);
		cb_buffer = RMMalloc(buffer_size);

		for(k = 0; k < chroma_height; k++){
			CB[k] = cb_buffer + k * chroma_width;
			CR[k] = cr_buffer + k * chroma_width;
		}
		chroma_offs = 0;
		for (i = 0; i < pCinfo->output_height; i += readlines){
			for(k = 0; k < luma_height; k++){
				Y[k] = luma + (i+k)*luma_width;
			}
			readlines = jpeg_read_raw_data (pCinfo, jcomponents, lines_per_imcu);
			/* interleave cb and cr */
			buf_offs = 0;
			for(j = 0; j < chroma_height; j += v_skip){
				for(k = 0; k < chroma_width; k += h_skip){
					chroma[chroma_offs++]  = cb_buffer[buf_offs];
					chroma[chroma_offs++]  = cr_buffer[buf_offs];
					buf_offs += h_skip;
				}
				buf_offs += (v_skip-1) * chroma_width;
			}
		}
		RMFree(cr_buffer);
		RMFree(cb_buffer);
	}
	
	return RM_OK;
}




static void jpg_cleanup(struct RMjpgInfo *jpg_info)
{
	jpeg_finish_decompress(&(jpg_info->cinfo));
#if ((EM86XX_CHIP==EM86XX_CHIPID_TANGO15)&&(EM86XX_MODE==EM86XX_MODEID_STANDALONE))
	jpeg_disable_special_large_memory_manager( (j_common_ptr)&(jpg_info->cinfo) );
#endif 
	jpeg_destroy_decompress(&(jpg_info->cinfo));
}



static RMstatus open_yuv_file(struct RMyuvInfo *yuv_info,  struct DCCOSDProfile *profile)
{
	RMuint32 read_size, marker, width, height, offs;
	RMstatus err;
	RMuint8 header_buf[128];
	// read whole file into a buffer
	err = RMReadFile(yuv_info->fp, header_buf, 128, &read_size); /*read the header */
	if(RMFAILED(err)){
		RMDBGLOG((ENABLE, "Failed to read the bmp header\n"));
		return RM_ERROR;
	}


	/* check header and get colorspace */
	offs = 0;
	while (offs < 128) {
		if (header_buf[offs] == ' ')
			break;
		offs ++;
	}
	header_buf[offs] = '\0';
	if (! (RMMemcmp( header_buf, "YUV601", 6))) {
		profile->ColorSpace = EMhwlibColorSpace_YUV_601_0_255;
	}
	else if (! (RMMemcmp( header_buf, "YUV709", 6))) {
		profile->ColorSpace = EMhwlibColorSpace_YUV_709_0_255;
	}
	else {
		fprintf(stderr, "Cannot find YUV header");
		return RM_ERROR;
	}
		
	/* get width */
	marker = offs + 1;
	while (offs < 128) {
		if (header_buf[offs] == ' ')
			break;
		offs ++;
	}
	header_buf[offs] = '\0';
	width = strtol((RMascii *)header_buf + marker, 0, 0);
	
	/* get height */
	marker = offs + 1;
	while (offs < 128) {
		if (header_buf[offs] == '\n')
			break;
		offs ++;
	}
	header_buf[offs] = '\0';
	height = strtol((RMascii *)header_buf + marker, 0, 0);
	offs += 2;
	
	yuv_info->offset = offs;

	profile->SamplingMode = EMhwlibSamplingMode_422;
	profile->ColorMode = EMhwlibColorMode_VideoInterleaved;
	profile->ColorFormat = EMhwlibColorFormat_32BPP; /* unused */
	profile->PixelAspectRatio.X = 1;
	profile->PixelAspectRatio.Y = 1;
	profile->Width = yuv_info->width = width;
	profile->Height = yuv_info->height = height;
	return RM_OK;
}


static RMstatus yuv_to_raw(RMuint8 *luma, struct RMyuvInfo *yuv_info)
{
	RMuint64 size;
	RMuint32 read_size;
	RMstatus err;
	err = RMSeekFile(yuv_info->fp, yuv_info->offset, RM_FILE_SEEK_START);
	if(RMFAILED(err)){
		RMDBGLOG((ENABLE, "RMSeekFile failed\n"));
		return RM_ERROR;
	}

	size = yuv_info->width * yuv_info->height * 2;
	err = RMReadFile(yuv_info->fp, luma, size - yuv_info->offset, &read_size);
	if(RMFAILED(err)){
		RMDBGLOG((ENABLE, "RMReadFile failed\n"));
		return RM_ERROR;
	}

	return RM_OK;
}

static RMstatus open_gif_file(struct RMgifInfo *gif_info,  struct DCCOSDProfile *profile)
{
/* 	RMstatus err; */
/* 	RMuint16 row, column, i, j; */

	gif_info->gif_hdr = DGifOpen((void*)gif_info->fp, gif_read_data_rm_file);
	if(gif_info->gif_hdr == NULL)
		return RM_ERROR;

	profile->ColorSpace = EMhwlibColorSpace_RGB_0_255;
	profile->SamplingMode = EMhwlibSamplingMode_444;
	profile->ColorMode = EMhwlibColorMode_LUT_8BPP;
	profile->ColorFormat = EMhwlibColorFormat_32BPP;
	profile->PixelAspectRatio.X = 1;
	profile->PixelAspectRatio.Y = 1;
	profile->Width = gif_info->width = gif_info->gif_hdr->SWidth;
	profile->Height = gif_info->height = gif_info->gif_hdr->SHeight;
	return RM_OK;
}
static  RMstatus gif_get_palette(RMuint32 *palette, struct RMgifInfo *gif_info)
{
	RMuint32 row;

	if (!gif_info)
		return RM_ERROR;

	if (!gif_info->gif_hdr)
		return RM_ERROR;

	if (!gif_info->gif_hdr->SColorMap) {
		RMDBGLOG((ENABLE, "no global color map\n"));

		if (gif_info->gif_hdr->Image.ColorMap) {
			RMDBGLOG((ENABLE, "using local color map\n"));

			for(row = 0; row < 256; row++){
				palette[row] = (gif_info->alpha<<24) & 0xff000000;
				palette[row] |= (gif_info->gif_hdr->Image.ColorMap->Colors[row].Red)<<16;
				palette[row] |= (gif_info->gif_hdr->Image.ColorMap->Colors[row].Green)<<8;
				palette[row] |=  gif_info->gif_hdr->Image.ColorMap->Colors[row].Blue;
			}
			return RM_OK;
		}

		fprintf(stderr, "gif without color map, revert to grayscale palette\n");

		for(row = 0; row < 256; row++) {
			palette[row] = (gif_info->alpha<<24) & 0xff000000;
			palette[row] |= (255 - row) << 16;
			palette[row] |= (255 - row) << 8;
			palette[row] |= 255 - row;
		}

		return RM_OK;
	}

	for(row = 0; row < 256; row++){
		palette[row] = (gif_info->alpha<<24) & 0xff000000;
		palette[row] |= (gif_info->gif_hdr->SColorMap->Colors[row].Red)<<16;
		palette[row] |= (gif_info->gif_hdr->SColorMap->Colors[row].Green)<<8;
		palette[row] |=  gif_info->gif_hdr->SColorMap->Colors[row].Blue;
	}
	return RM_OK;
}


static RMstatus gif_to_raw(RMuint8 *luma, struct RMgifInfo *gif_info)
{
	GifRecordType rtype;
	RMuint32 interlacedOffset[] = { 0, 4, 2, 1 };
	RMuint32 interlacedJumps[] = { 8, 8, 4, 2 };
	RMuint32 row, i, j;

	// read image record type
	rtype = UNDEFINED_RECORD_TYPE;
	DGifGetRecordType(gif_info->gif_hdr, &rtype);
	while(rtype != IMAGE_DESC_RECORD_TYPE){
		DGifGetRecordType(gif_info->gif_hdr, &rtype);
	}
	
	// read image data
	if(DGifGetImageDesc(gif_info->gif_hdr) == GIF_ERROR){
		DGifCloseFile(gif_info->gif_hdr);
		return RM_ERROR;
	}

	
	if(gif_info->gif_hdr->Image.Interlace){
		row = gif_info->gif_hdr->Image.Top;

		for(i = 0;  i < 4;  ++i) {
			for (j = row + interlacedOffset[i]; j < row + gif_info->height;  j+= interlacedJumps[i]){
	                   	if(DGifGetLine(gif_info->gif_hdr, luma + (j * gif_info->width), gif_info->width ) == GIF_ERROR){
					DGifCloseFile(gif_info->gif_hdr);
					return RM_ERROR;
				}
			}
		 }
	}
	else{
		for(j = 0;  j < gif_info->height;  j++) {
			if(DGifGetLine(gif_info->gif_hdr, luma + (j * gif_info->width), gif_info->width ) == GIF_ERROR){
				DGifCloseFile(gif_info->gif_hdr);
				return RM_ERROR;
			}
		}
	}
		
	return RM_OK;
}

static void gif_cleanup(struct RMgifInfo *gif_info)
{
	DGifCloseFile(gif_info->gif_hdr);
}



RMstatus RMOpenBitmapFile(RMascii *filename, struct RMBitmapFileInfo *bfi, struct RMBitmapFileOptions *opts, struct DCCOSDProfile  *profile )
{
	
	RMascii *file_ext = &(filename[strlen(filename) - 4]);
	RMfile fp;
	RMstatus status;


	if (! RMMemcmp(file_ext, "gray", 4) || ! RMMemcmp(file_ext, "grey", 4)) {
		bfi->file_format = RMBitmap_TestPattern;
		bfi->info.tp.pattern = 1; // gray zig-zag pattern, 16 by 16 fields
		bfi->info.tp.width = 512;
		bfi->info.tp.height = 384;
		bfi->info.tp.force_rgb = opts->force_rgb;
		bfi->info.tp.alpha = opts->alpha;
		if (bfi->info.tp.force_rgb) {
			profile->ColorSpace = EMhwlibColorSpace_RGB_0_255;
			profile->SamplingMode = EMhwlibSamplingMode_444;
			profile->ColorMode = EMhwlibColorMode_TrueColor;
		} else {
			profile->ColorSpace = EMhwlibColorSpace_YUV_601_0_255;
			profile->SamplingMode = EMhwlibSamplingMode_420;
			profile->ColorMode = EMhwlibColorMode_VideoNonInterleaved;
		}
		profile->ColorFormat = EMhwlibColorFormat_32BPP;
		profile->PixelAspectRatio.X = 1;
		profile->PixelAspectRatio.Y = 1;
		profile->Width = bfi->info.tp.width;
		profile->Height = bfi->info.tp.height;
		return RM_OK;
	}
	else if (! RMMemcmp(file_ext, "yrgb", 4)) {
		bfi->file_format = RMBitmap_TestPattern;
		bfi->info.tp.pattern = 2; // gray/red/green/blue zig-zag pattern, 16 by 16 fields
		bfi->info.tp.width = 512;
		bfi->info.tp.height = 384;
		bfi->info.tp.force_rgb = opts->force_rgb;
		bfi->info.tp.alpha = opts->alpha;
		if (bfi->info.tp.force_rgb) {
			profile->ColorSpace = EMhwlibColorSpace_RGB_0_255;
			profile->SamplingMode = EMhwlibSamplingMode_444;
			profile->ColorMode = EMhwlibColorMode_TrueColor;
		} else {
			profile->ColorSpace = EMhwlibColorSpace_YUV_601_0_255;
			profile->SamplingMode = EMhwlibSamplingMode_420;
			profile->ColorMode = EMhwlibColorMode_VideoNonInterleaved;
		}
		profile->ColorFormat = EMhwlibColorFormat_32BPP;
		profile->PixelAspectRatio.X = 1;
		profile->PixelAspectRatio.Y = 1;
		profile->Width = bfi->info.tp.width;
		profile->Height = bfi->info.tp.height;
		return RM_OK;
	}
	else if (! RMMemcmp(file_ext, "rst1", 4)) {
		//struct EMhwlibTVFormatDigital fmt;
		
		//err = RUAGetProperty(dcc_info->pRUA, DispDigitalOut, RMDispDigitalOutPropertyID_TVFormat, &fmt, sizeof(fmt));
		bfi->file_format = RMBitmap_TestPattern;
		bfi->info.tp.pattern = (! RMMemcmp(file_ext, "rst2", 4)) ? 3 : 4; // vertical burst pattern, bit 2 always zero(3) or one(4)
		//bfi->info.tp.width = fmt.ActiveWidth;
		//bfi->info.tp.height = fmt.ActiveHeight;
		bfi->info.tp.width = 1440;
		bfi->info.tp.height = 480;
		bfi->info.tp.force_rgb = TRUE;
		bfi->info.tp.alpha = opts->alpha;
		profile->ColorSpace = EMhwlibColorSpace_RGB_0_255;
		profile->SamplingMode = EMhwlibSamplingMode_444;
		profile->ColorMode = EMhwlibColorMode_TrueColor;
		profile->ColorFormat = EMhwlibColorFormat_32BPP;
		profile->PixelAspectRatio.X = 1;
		profile->PixelAspectRatio.Y = 1;
		profile->Width = bfi->info.tp.width;
		profile->Height = bfi->info.tp.height;
		return RM_OK;
	}
	else if ( (! RMMemcmp(file_ext, "rst2", 4)) || (! RMMemcmp(file_ext, "rst3", 4)) ) {
		//struct EMhwlibTVFormatDigital fmt;
		
		//err = RUAGetProperty(dcc_info->pRUA, DispDigitalOut, RMDispDigitalOutPropertyID_TVFormat, &fmt, sizeof(fmt));
		bfi->file_format = RMBitmap_TestPattern;
		bfi->info.tp.pattern = (! RMMemcmp(file_ext, "rst2", 4)) ? 3 : 4; // vertical burst pattern, bit 2 always zero(3) or one(4)
		//bfi->info.tp.width = fmt.ActiveWidth;
		//bfi->info.tp.height = fmt.ActiveHeight;
		bfi->info.tp.width = 1920;
		bfi->info.tp.height = 1080;
		bfi->info.tp.force_rgb = TRUE;
		bfi->info.tp.alpha = opts->alpha;
		profile->ColorSpace = EMhwlibColorSpace_RGB_0_255;
		profile->SamplingMode = EMhwlibSamplingMode_444;
		profile->ColorMode = EMhwlibColorMode_TrueColor;
		profile->ColorFormat = EMhwlibColorFormat_32BPP;
		profile->PixelAspectRatio.X = 1;
		profile->PixelAspectRatio.Y = 1;
		profile->Width = bfi->info.tp.width;
		profile->Height = bfi->info.tp.height;
		return RM_OK;
	}
	else if ( RMCompareAsciiCaseInsensitively(file_ext, ".bmp")) 
		bfi->file_format = RMBitmap_BMP_Format;
	else if ( (RMCompareAsciiCaseInsensitively(file_ext, ".jpg")) || (RMCompareAsciiCaseInsensitively(file_ext, "jpeg")) )
		bfi->file_format = RMBitmap_JPG_Format;
	else if ( RMCompareAsciiCaseInsensitively(file_ext, ".gif")) 
		bfi->file_format = RMBitmap_GIF_Format;
	else if ( RMCompareAsciiCaseInsensitively(file_ext, ".yuv")) 
		bfi->file_format = RMBitmap_YUV_Format;
	else if ( RMCompareAsciiCaseInsensitively(file_ext, ".png")) 
		bfi->file_format = RMBitmap_PNG_Format;
	else{
		RMDBGLOG((ENABLE, "Filename '%s' has wrong file extension '%s'\n", filename, file_ext));
		return RM_ERROR;
	}

	/* open the stream */
	fp = open_stream(filename, RM_FILE_OPEN_READ, 0);
	if (fp == NULL) {
		RMDBGLOG((ENABLE, "Cannot open file %s\n", filename));
		return RM_ERROR;
	}
	if(bfi->file_format == RMBitmap_JPG_Format){
		JXFORM_CODE transform1, transform2;
		transform1 = transform2 = JXFORM_NONE;
		switch(opts->orientation){
		case FRTop_FCLeft:
			break;
		case FRTop_FCRight:
			transform1 = JXFORM_FLIP_H;
			break;
		case FRBottom_FCRight:
			transform1 = JXFORM_ROT_180;
			break;
		case FRBottom_FCLeft:
			transform1 = JXFORM_FLIP_V;
			break;
		case FRLeft_FCTop:
			transform1 = JXFORM_ROT_270;
			transform2 = JXFORM_FLIP_V;
			break;
		case FRRight_FCTop:
			transform1 = JXFORM_ROT_90;
			break;
		case FRLeft_FCBottom:
			transform1 = JXFORM_ROT_270;
			break;
		case FRRight_FCBottom:
			transform1 = JXFORM_ROT_90;
			transform2 = JXFORM_FLIP_V;
			break;
		}
		if(transform1 != JXFORM_NONE){
			RMint64 size;
			RMfile mem_fp;
			RMSizeOfOpenFile(fp, &size);
			size += 1024;/*when rotating, files can get bigger*/
			mem_fp = RMCreateMemoryFile(size); 
			jpeg_flip_rotate(fp, mem_fp, transform1);
			RMSeekFile(mem_fp, 0, RM_FILE_SEEK_START);
			RMCloseFile(fp);
			fp = mem_fp;
			if(transform2 != JXFORM_NONE){
				mem_fp = RMCreateMemoryFile(size); 
				jpeg_flip_rotate(fp, mem_fp, transform2);
				RMSeekFile(mem_fp, 0, RM_FILE_SEEK_START);
				RMCloseFile(fp); /*free file with transform 1*/
				fp = mem_fp;
			}
		}
	}
					      
	switch(bfi->file_format){
	case RMBitmap_BMP_Format:
		bfi->info.bmp.fp = fp;
		if(opts != NULL)
			bfi->info.bmp.alpha = opts->alpha;
		else
			bfi->info.bmp.alpha = 0x80;

 		status = open_bmp_file(&(bfi->info.bmp), profile);
		if (status != RM_OK)
			RMCloseFile(fp);
		return status;

	
	case RMBitmap_JPG_Format:
		bfi->info.jpg.fp = fp;
		if(opts != NULL){
			bfi->info.jpg.force_rgb = opts->force_rgb;
			bfi->info.jpg.alpha = opts->alpha;
		}
		else{
			bfi->info.jpg.force_rgb = TRUE;
			bfi->info.jpg.alpha = 0x80;
		}
		status = open_jpg_file(&(bfi->info.jpg), profile);
		if (status != RM_OK)
			RMCloseFile(fp);
		return status;

	case RMBitmap_GIF_Format:
		bfi->info.gif.fp = fp;
		if(opts != NULL)
			bfi->info.gif.alpha = opts->alpha;
		else
			bfi->info.gif.alpha = 0x80;

 		status = open_gif_file(&(bfi->info.gif), profile);
		if (status != RM_OK)
			RMCloseFile(fp);
		return status;

	case RMBitmap_PNG_Format:
		bfi->info.png.fp = fp;
		if(opts != NULL)
			bfi->info.png.alpha = opts->alpha;
		else
			bfi->info.png.alpha = 0x80;

 		status = open_png_file(&(bfi->info.png), profile);
		if (status != RM_OK)
			RMCloseFile(fp);
		return status;


	case RMBitmap_YUV_Format:
		bfi->info.yuv.fp = fp;
		status = open_yuv_file(&(bfi->info.yuv), profile);
		if (status != RM_OK)
			RMCloseFile(fp);
		return status;
	
	case RMBitmap_TestPattern:
		return RM_ERROR;
	}
	return RM_ERROR;
}

RMstatus RMBitmapToRaw(RMuint8 *luma, RMuint8 *chroma, struct RMBitmapFileInfo *bfi)
{

	switch(bfi->file_format){
	case RMBitmap_BMP_Format:
		return bmp_to_raw(luma, &(bfi->info.bmp));
	case RMBitmap_JPG_Format:
		return jpg_to_raw(luma, chroma, &(bfi->info.jpg));
	case RMBitmap_GIF_Format:
		return gif_to_raw(luma, &(bfi->info.gif));
	case RMBitmap_PNG_Format:
		return png_to_raw(luma, &(bfi->info.png));
	case RMBitmap_YUV_Format:
		return yuv_to_raw(luma, &(bfi->info.yuv));
	case RMBitmap_TestPattern:
		switch (bfi->info.tp.pattern) {
		default:
		case 1:
			if (bfi->info.tp.force_rgb) {
				create_gray_fields_RGB(bfi->info.tp.width, bfi->info.tp.height, luma, bfi->info.tp.alpha);
			} else {
				create_gray_fields_420(bfi->info.tp.width, bfi->info.tp.height, luma, chroma);
			}
			break;
		case 2:
			if (bfi->info.tp.force_rgb) {
				create_grayrgb_fields_RGB(bfi->info.tp.width, bfi->info.tp.height, luma, bfi->info.tp.alpha);
			} else {
				create_grayrgb_fields_420(bfi->info.tp.width, bfi->info.tp.height, luma, chroma);
			}
			break;
		case 3:
			bfi->info.tp.force_rgb = TRUE;
			create_burst_bit2_fields_RGB(bfi->info.tp.width, bfi->info.tp.height, luma, bfi->info.tp.alpha);
			break;
		case 4:
			bfi->info.tp.force_rgb = TRUE;
			create_burst_bit2_1_fields_RGB(bfi->info.tp.width, bfi->info.tp.height, luma, bfi->info.tp.alpha);
			break;
		}
		return RM_OK;
	}
	return RM_ERROR;
}
RMstatus RMBitmapGetPalette(RMuint32 *palette, struct RMBitmapFileInfo *bfi)
{
	switch(bfi->file_format){
	case RMBitmap_BMP_Format:
		return bmp_get_palette(palette, &(bfi->info.bmp));
	case RMBitmap_PNG_Format:
		return png_get_palette(palette, &(bfi->info.png));
	case RMBitmap_GIF_Format:
		return gif_get_palette(palette, &(bfi->info.gif));
	case RMBitmap_JPG_Format:
	case RMBitmap_YUV_Format:
	case RMBitmap_TestPattern:
		return RM_ERROR;
	}
	return RM_ERROR;
}

void RMBitmapSetSourceWindow(struct EMhwlibDisplayWindow *window, struct RMBitmapFileInfo *bfi)
{
	window->X = 0;
	window->Y = 0;
	window->XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
	window->YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
	window->XMode = EMhwlibDisplayWindowValueMode_Fixed;
	window->YMode = EMhwlibDisplayWindowValueMode_Fixed;
	window->WidthMode = EMhwlibDisplayWindowValueMode_Fixed;
	window->HeightMode = EMhwlibDisplayWindowValueMode_Fixed;
	
	switch(bfi->file_format){
	case RMBitmap_BMP_Format:
		window->Width = bfi->info.bmp.width;
		window->Height = bfi->info.bmp.height;
		break;
	case RMBitmap_JPG_Format:
		window->Width = bfi->info.jpg.width;
		window->Height = bfi->info.jpg.height;
		break;
	case RMBitmap_GIF_Format:
		window->Width = bfi->info.gif.width;
		window->Height = bfi->info.gif.height;
		break;
	case RMBitmap_PNG_Format:
		window->Width = bfi->info.png.width;
		window->Height = bfi->info.png.height;
		break;
	case RMBitmap_YUV_Format:
		window->Width = bfi->info.yuv.width;
		window->Height = bfi->info.yuv.height;
		break;
	case RMBitmap_TestPattern:
		window->Width = bfi->info.tp.width;
		window->Height = bfi->info.tp.height;
		break;
	}
}


void RMCloseBitmapFile(struct RMBitmapFileInfo *bfi)
{
	RMfile fp = (RMfile)NULL;
	RMstatus err;
	switch(bfi->file_format){
	case RMBitmap_BMP_Format:
		fp = bfi->info.bmp.fp;
		break;
	case RMBitmap_JPG_Format:
		jpg_cleanup(&(bfi->info.jpg));
		fp = bfi->info.jpg.fp;
		break;
	case RMBitmap_GIF_Format:
		gif_cleanup(&(bfi->info.gif));
		fp = bfi->info.gif.fp;
		break;
	case RMBitmap_PNG_Format:
		png_cleanup(&(bfi->info.png));
		fp = bfi->info.png.fp;
		break;
	case RMBitmap_YUV_Format:
		fp = bfi->info.yuv.fp;
		break;
	default:
		return;
	}

	err = RMCloseFile(fp);
	if(RMFAILED(err)){
		RMDBGLOG((ENABLE, "Error closing bitmap file\n"));
	}
}




