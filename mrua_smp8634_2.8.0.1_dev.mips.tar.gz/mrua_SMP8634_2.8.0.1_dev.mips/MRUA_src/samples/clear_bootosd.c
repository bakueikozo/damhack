/*
 *
 * Copyright (c) Sigma Designs, Inc. 2002. All rights reserved.
 *
 */

/**
	@file colorbars.c
	@brief sample application to test output
	
	@author Julien Soulier
*/
/*
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>*/
#include "sample_os.h"

#define ALLOW_OS_CODE 1
#include "../dcc/include/dcc.h"
#include "common.h"

RMuint32 chip_num = 0;

static void show_usage(char *progname)
{
	fprintf(stderr, "usage: %s <options>\n"
		"\t-m chip: Select the board number [0]\n", progname);
	
	exit(1);
}

static void parse_cmdline(int argc, char *argv[], unsigned long *addr)
{
	RMint32 i;

	if (argc < 1) 
		show_usage(argv[0]);
	
 	i = 1;
	while ((argc > i) && (argv[i][0] == '-')) {
		switch (argv[i][1]) {			
		case 'm':
			chip_num = strtol(argv[i+1], NULL, 10);
			i+=2;
			break;

		default:
			show_usage(argv[0]);
		}
	}

	if (argc > i)
		show_usage(argv[0]);
}

int main(int argc, char *argv[])
{
	struct RUA *pInstance = NULL;
	RMstatus err;
	RMuint32 addr;
	RMbool enable;
	struct MM_TopRemovableArea_type removable_area;
	RMuint32 surface;

	parse_cmdline(argc, argv, &addr);

	if (RMFAILED(err = RUACreateInstance(&pInstance, chip_num))) {
		fprintf(stderr, "Error creating instance! %d\n", err);
		return -1;
	}

	enable = FALSE;
	surface = 0;

	err = RUAGetProperty(pInstance, EMHWLIB_MODULE(MM, 0), RMMMPropertyID_TopRemovableArea, &removable_area, sizeof(removable_area));
	if (RMFAILED(err)) {
		fprintf(stderr, "Error cannot get top removable area size! %d\n", err);
		return -1;
	}
	
	/* nothing to do */
	if (removable_area.Size == 0) {
		fprintf(stderr, "BOOTOSD inactive! Nothing to do\n");
		return 0;
	}

	err = RUASetProperty(pInstance, DispMainVideoScaler, RMGenericPropertyID_Surface, &surface, sizeof(surface), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error setting main video scaler surface to 0! %d\n", err);
		return -1;
	}

	err = RUASetProperty(pInstance, DispMainVideoScaler, RMGenericPropertyID_Enable, &enable, sizeof(enable), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error disabling main video scaler! %d\n", err);
		return -1;
	}

	err = RUASetProperty(pInstance, DispGFXMultiScaler, RMGenericPropertyID_Surface, &surface, sizeof(surface), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error setting GFX multi scaler surface to 0! %d\n", err);
		return -1;
	}
	
	err = RUASetProperty(pInstance, DispGFXMultiScaler, RMGenericPropertyID_Enable, &enable, sizeof(enable), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error disabling GXF multi scaler! %d\n", err);
		return -1;
	}

	/* do not check for error. Maybe not present (TANGO) */
	RUASetProperty(pInstance, DispCRTMultiScaler, RMGenericPropertyID_Surface, &surface, sizeof(surface), 0);
	RUASetProperty(pInstance, DispCRTMultiScaler, RMGenericPropertyID_Enable, &enable, sizeof(enable), 0);

	/* do not check for error. Maybe not present (TANGO) */
	RUASetProperty(pInstance, DispVCRMultiScaler, RMGenericPropertyID_Surface, &surface, sizeof(surface), 0);
 	RUASetProperty(pInstance, DispVCRMultiScaler, RMGenericPropertyID_Enable, &enable, sizeof(enable), 0);
	
	err = RUASetProperty(pInstance, DispOSDScaler, RMGenericPropertyID_Surface, &surface, sizeof(surface), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error setting OSD scaler surface to 0! %d\n", err);
		return -1;
	}

	err = RUASetProperty(pInstance, DispOSDScaler, RMGenericPropertyID_Enable, &enable, sizeof(enable), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error disabling OSD scaler! %d\n", err);
		return -1;
	}

	printf("Free boot OSD memory block at address 0x%08lx size %lu bytes\n", removable_area.Address, removable_area.Size);
	if (removable_area.Address != 0) {
		// RUAFree(pInstance, removable_area.Address);  application did not call malloc, so should not call free also

		err = RUASetProperty(pInstance, EMHWLIB_MODULE(MM, 0), RMMMPropertyID_RemoveTopRemovableArea, NULL, 0, 0);
		if (RMFAILED(err)) {
			fprintf(stderr, "Error cannot remove the top removable area size! %d\n", err);
			return -1;
		}
	}

	RUADestroyInstance(pInstance);

	return 0;
}
