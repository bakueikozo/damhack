/*****************************************
 Copyright � 2001-2005
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rminputstream.h
  @brief  Wrapper for custom FILE

  @author Julien Lerouge
  @date   2005-03-02
*/

#ifndef __RMINPUTSTREAM_H__
#define __RMINPUTSTREAM_H__

#include "../rmlibcw/include/rmlibcw.h"
#include "../rmlibhttp/include/rmlibhttp.h"
#include "../rmcdfs/include/rmcdfs.h"

/** 
 * Stream options
 *
 * This structure should hold all the possible options for all the possible
 * media. Options should be set through an accessor functions, like
 * set_http_options, to insure portability if new medias are added.
 */
struct stream_options_s {
	/* HTTP options */
	RMHTTPFlags http_flags;
	RMascii *http_custom_header;

	/* HTTP hook options */
	void *http_custom_cookie;
	void *http_custom_hooks;

	/* Other options ... */
};


RM_EXTERN_C_BLOCKSTART


/**
   Set default options for a stream

   For HTTP URL, the defaults are :
   	- RMHTTPFlags = 0
	- No custom header (NULL)

   @param options - struct stream_options_s to configure
   @return RM_OK on success
*/
RMstatus init_stream_options(struct stream_options_s *options);


/**
   Set HTTP options for open_stream

   @param options - struct stream_options_s to configure
   @param http_flags - HTTP flags to use 
   @param custom_header - HTTP header to use, NULL if none
   @return RM_OK on success
*/
RMstatus set_http_options(struct stream_options_s *options, RMHTTPFlags http_flags, RMascii *custom_header);


/**
   Set HTTP hook options for open_stream

   @param options - struct stream_options_s to configure
   @param http_flags - HTTP flags to use 
   @param custom_cookie - cookie use by the hooks
   @param custom_hooks - set of custom callbacks that use the cookie
   @return RM_OK on success
*/
RMstatus set_http_hook_options(struct stream_options_s *options, RMHTTPFlags http_flags, void *custom_cookie, void *custom_hooks);


/**
   Open a stream with custom options

   If the given filename begins with http://, this function will open a HTTP
   stream using the rmlibhttp and wrap it into a regular RMfile, so that it
   appears as a regular file for the end user. If the filename doesn't begin
   with http://, then a regular RMfile is opened. options are additional
   options the user can pass to the underlying library. options should be set
   with a proper accessor funtcion, see set_http_options for example.

   @param filename - URL to open
   @param mode - open mode, see rmfile.h (can be RM_FILE_OPEN_READ,
                 RM_FILE_OPEN_WRITE, or RM_FILE_OPEN_READ_WRITE)
   @param options - options to use for this stream (see set_http_options or
                    other option setting functions), NULL to use the defaults.
   @return RMfile, NULL on error
*/
RMfile _open_stream(const RMascii *filename, RMfileOpenMode mode, struct stream_options_s *options);

/* this is a wrapper around _open_stream in order to support PFS (rmpfs.c) caching */

RMfile open_stream(const RMascii *filename, RMfileOpenMode mode, struct stream_options_s *options);



/**
   Open a directory

   @param directoryname - Directory to open
   @return RMdirectory, NULL on error
*/
RM_EXTERN_C RMdirectory open_directory( const RMascii *directoryname );


/**
   Type definition for custom open_stream callback function

   @param filename - URL to open
   @param mode - open mode, see rmfile.h (can be RM_FILE_OPEN_READ,
                 RM_FILE_OPEN_WRITE, or RM_FILE_OPEN_READ_WRITE)
   @param options - options to use for this stream (see set_http_options or
                    other option setting functions), NULL to use the defaults.
   @return RMfile, NULL on error or to continue with default processing
*/
typedef RMfile (*custom_open_stream_function)(const RMascii *filename, RMfileOpenMode mode, struct stream_options_s *options);


/**
   Set custom open_stream callback function

   Allows you to hook-in a callback function in open_stream for using
   special file systems or access methods other than the default ones
   implemented in open_stream.

   Depending on the filename/-path the callback function might return NULL
   signaling that open_stream should process with its default handling.

   @param function - pointer to custom open_stream callback function
                     (pass NULL to unset any callback function)
   @return RM_OK on success
*/
RMstatus set_custom_open_stream(custom_open_stream_function function);



typedef RMfile (*custom_open_for_pfs_function)(const RMascii *filename, RMfileOpenMode mode, struct stream_options_s *options);

RMstatus set_custom_open_for_pfs(custom_open_for_pfs_function function);




RM_EXTERN_C_BLOCKEND


#endif /* __RMINPUTSTREAM_H__ */
