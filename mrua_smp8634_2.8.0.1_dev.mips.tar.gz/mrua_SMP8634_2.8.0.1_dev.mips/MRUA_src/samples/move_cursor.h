/*
 *
 * Copyright (c) Sigma Designs, Inc. 2003. All rights reserved.
 *
 */

/**
	@file move_cursor.h
	@brief sample application to access the Mambo chip
	
	@author Christian Wolff
*/

RMstatus move_cursor(
	struct RUA *pInstance, 
	RMuint32 x, 
	RMuint32 y);

