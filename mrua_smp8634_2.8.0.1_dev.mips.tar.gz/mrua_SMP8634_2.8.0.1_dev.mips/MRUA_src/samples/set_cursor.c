/*
 *
 * Copyright (c) Sigma Designs, Inc. 2003. All rights reserved.
 *
 */

/**
	@file set_cursor.c
	@brief sample application to access the Mambo chip
	
	@author Christian Wolff
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ALLOW_OS_CODE 1
#include "rua.h"
#include "rua_property.h"

#include "set_cursor.h"

#define setpix(x, y, col) format.Pixel.Data[(x) + (y) * format.XSize] = (col) & 0xF;

RMstatus set_cursor(struct RUA *pInstance) 
{
	RMstatus err;
	struct DispHardwareCursor_Format_type format;
	RMuint32 x, y;
	RMuint8 col;
	
	// example: cursor 32x32, 3 colors
	
	format.XSize = 32;
	format.YSize = 32;
	format.CursorEnable = TRUE;
	format.ParityF = FALSE;
	format.ParityI = TRUE;
	
	format.LUT.Data[0] = ( 0 << 26) | (32 << 18) | ( 4 << 10) | (32 << 2);    // transparent
	format.LUT.Data[1] = (40 << 26) | (32 << 18) | ( 4 << 10) | (32 << 2);   // black
	format.LUT.Data[2] = (40 << 26) | (32 << 18) | (63 << 10) | (32 << 2);  // white
	
	RMMemset(format.Pixel.Data, 0, sizeof(format.Pixel.Data));
	format.Pixel.Size = format.XSize * format.YSize;
	for (x = 0; x < 16; x++) {
		for (y = 0; y < 6; y++) {
			col = (y > 1) ? 1 : 2;
			if (x < 2) col = 1;
			if ((x - y) < 2) col = 1;
			if (x >= y) {
				setpix(x-y, x, col);
				setpix(31-x+y, x, col);
				setpix(x-y, 31 - x, col);
				setpix(31-x+y, 31 - x, col);
			}
			if ((x+y) < 16) {
				setpix(x+y, x, col);
				setpix(31-x-y, x, col);
				setpix(x+y, 31 - x, col);
				setpix(31-x-y, 31 - x, col);
			}
		}
	}
	
	err = RUASetProperty(pInstance, DispHardwareCursor, RMDispHardwareCursorPropertyID_Format, 
		&format, sizeof(format), 0);
	
	return err;
}

