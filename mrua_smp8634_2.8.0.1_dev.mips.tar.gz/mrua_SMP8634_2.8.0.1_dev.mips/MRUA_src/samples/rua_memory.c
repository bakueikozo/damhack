
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <rua/include/rua.h>
//#include <dcc/include/dcc.h>
#include "rua_memory.h"

#if 0
#define RUAMEMDBG ENABLE
#else
#define RUAMEMDBG DISABLE
#endif

#define MAX_MALLOC 512
#define MEM_CNTL_NUM 0 // hardcode the memory controller for now


struct c_memory
{
	RMuint32 phy;
	RMuint8* vir;
	RMuint32 size;
};

//
// static variables, only single instance is allowed
//
static struct RUA * c_pRUA;
static struct c_memory c_m_list[MAX_MALLOC];
static RMuint32 c_memory_count;


static RMstatus c_lock_map_buffer( struct RUA *pRUA, RMuint32 physicalAddress, RMuint32 bufferSize, RMuint8 ** pvirtualAddress )
{
	RMstatus err;
	err = RUALock(pRUA, physicalAddress, bufferSize);
	if(RMFAILED(err)) {
		RMDBGLOG((ENABLE, "RM_lock_map_buffer RUALock failed %d\n", err ));
		return err;
	}
	//fprintf( stderr, "RM_lock_map_buffer Locked 0x%lx, 0x%lx\n", physicalAddress, bufferSize );

	*pvirtualAddress = RUAMap( pRUA, physicalAddress, bufferSize );
	if(*pvirtualAddress == NULL) {
		RMDBGLOG((ENABLE, "RM_lock_map_buffer RUAMap failed\n" ));
		return RM_ERROR;
	}
	//fprintf( stderr, "RM_lock_map_buffer Mapped 0x%lx\n", (RMuint32)*pvirtualAddress );

	return RM_OK;
}

static RMstatus c_unlock_unmap_buffer( struct RUA *pRUA, RMuint32 physicalAddress, RMuint32 bufferSize, RMuint8 * virtualAddress )
{
	RMstatus err;

	RUAUnMap( pRUA, virtualAddress, bufferSize);

	err = RUAUnLock(pRUA, (RMuint32)physicalAddress, bufferSize);
	if(RMFAILED(err)) {
		RMDBGLOG((ENABLE, "RM_unlock_unmap_buffer RUAUnLock failed %d\n", err ));
		return err;
	}

	return RM_OK;
}

void c_malloc_init(struct RUA * rua)
{
	RMuint32 i;
	RMstatus err;
	RMDBGLOG((RUAMEMDBG, "c_malloc_init rua=0x%lx\n", rua ));
	if( rua != NULL ) {
		c_pRUA = (struct RUA * )rua;
	}
	else {
		err = RUACreateInstance( &c_pRUA, MEM_CNTL_NUM );
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error creating RUA instance! %d\n", err));
			return;
		}
	}
	for( i=0; i < MAX_MALLOC; i ++ ) {
		c_m_list[i].phy = (RMuint32)0;
		c_m_list[i].vir = (RMuint8*)0;
		c_m_list[i].size = (RMuint32)0;
	}
	c_memory_count = 0;
	return;
}

void c_malloc_uninit(struct RUA * rua)
{
	RMuint32 i ;
	RMstatus err;
	RMDBGLOG((RUAMEMDBG, "c_malloc_uninit rua=0x%lx\n", rua ));
	if(c_memory_count!= 0)
		RMDBGLOG((RUAMEMDBG, "!!! c_memory_count is not zero at uninitialize !!!\n"));
	for( i = 0; i<MAX_MALLOC; i++ )	{
		if( c_m_list[i].vir != NULL ) {
			c_free(c_m_list[i].vir);
		}
	}
	if( rua != NULL ) {
		return;
	}
	else {
		err = RUADestroyInstance( c_pRUA );
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error deleting RUA instance! %d\n", err));
			return;
		}
	}
	return;
}

void * c_malloc( RMuint32 numofbytes )
{
	RMuint32 i ;
	RMstatus err = RM_OK;
	for( i = 0; i<MAX_MALLOC; i++ ) {
		if( c_m_list[i].phy == 0 )
			break; // found a free slot
	}
	if( i == MAX_MALLOC ) {
		RMDBGLOG((ENABLE, "c_malloc failed, no free slot\n" ));
		return (void*)0;  // no free slot return fail
	}

	c_m_list[i].phy = (RMuint32)RUAMalloc( c_pRUA, MEM_CNTL_NUM, RUA_DRAM_UNCACHED, numofbytes); 
	if( c_m_list[i].phy == 0 ) {
		RMDBGLOG((ENABLE, "c_malloc RUAMalloc failed %d  size=%ld(0x%lx)\n", err, numofbytes, numofbytes ));
		return NULL;
	}
	
	// got buffer, map to get cpu address
	c_m_list[i].vir = (RMuint8*)0;
	err = c_lock_map_buffer( c_pRUA, c_m_list[i].phy, numofbytes, &(c_m_list[i].vir) );
	if(RMFAILED(err)) {
		RMDBGLOG((ENABLE, "c_malloc c_lock_map_buffer failed %d\n", err ));
		RUAFree( c_pRUA, c_m_list[i].phy ); 
		c_m_list[i].phy = (RMuint32)0;
	}
	c_m_list[i].size = numofbytes;
	c_memory_count ++;
	RMDBGLOG((RUAMEMDBG, "c_malloc 0x%lx -> 0x%lx size=%ld(0x%lx)\n", c_m_list[i].phy, c_m_list[i].vir, c_m_list[i].size, c_m_list[i].size ));
	return (void *)(c_m_list[i].vir);
}


void c_free( void * ptr )
{
	RMuint32 i;
	RMstatus err;
	for( i = 0; i<MAX_MALLOC; i++ )	{
		if( c_m_list[i].vir == (RMuint8*)ptr ) {
			RMDBGLOG((RUAMEMDBG, "c_free 0x%lx -> 0x%lx size=%ld(0x%lx)\n",c_m_list[i].phy, c_m_list[i].vir,  c_m_list[i].size, c_m_list[i].size ));
			err = c_unlock_unmap_buffer( c_pRUA, c_m_list[i].phy, c_m_list[i].size, c_m_list[i].vir ); 
			if(RMFAILED(err)) {
				RMDBGLOG((ENABLE, "RM_unlock_unmap_buffer RUAUnLock failed %d\n", err ));
			}
			RUAFree( c_pRUA, c_m_list[i].phy );
			c_m_list[i].phy = (RMuint32)0;
			c_m_list[i].vir = (RMuint8*)0;
			c_m_list[i].size = (RMuint32)0;
			c_memory_count --;
			return; // found entry
		}
	}
	if( i == MAX_MALLOC ){
		RMDBGLOG((ENABLE, "No memory allocation found 0x%lx\n", (RMuint32)ptr ));
	}

	return;
}




void * rua_malloc_large(size_t size)
{
	return c_malloc( size );
}

void rua_free_large(void *ptr)
{
	if( ptr != NULL )
		c_free( ptr );
	else 
		RMDBGLOG((ENABLE, "trying to free NULL pointer\n"));
}



