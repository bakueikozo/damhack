/*****************************************
 Copyright � 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   dvi_hdmi_update.c
  @brief  Wrapper function to update DVI, HDMI from emhwlib settings
  
  @author Christian Wolff
  @date   2007-04-18
*/

// to enable or disable the debug messages of this source file, put 1 or 0 below
#if 1
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

#include "sample_os.h"
#define ALLOW_OS_CODE 1

#include "../rua/include/rua.h"
#include "../rua/include/rua_property.h"
#include "../dcc/include/dcc.h"
#include "../rmcore/include/rmstatustostring.h"
#include "../rmlibcw/include/rmlibcw.h"

#include "dvi_hdmi_update.h"
#include "dvi_hdmi_internals.h"

// Pick one:
//#define DH_SEND_ISRC
#undef DH_SEND_ISRC

/** 
	Convert audio settings into a configuration for the HDMI output
	
	@param SampleRate        The respective audio option struct member
	@param mclk              The respective audio option struct member
	@param OutputChannels    The respective audio option struct member
	@param OutputLfe         The respective audio option struct member
	@param Spdif             The respective audio option struct member
	@param Codec             The respective audio option struct member
	@param HDMIPassThrough   The respective audio option struct member
	@param HDMIPassThroughI2SLines  The respective audio option struct member
	@param HBR_Enable        The respective audio option struct member
	@param HBR_Compressed    The respective audio option struct member
	@param HBR_HeaderID      The respective audio option struct member
	@param pDBC              The DBC blocks parsed from the current EDID
	@param nDBC              Number of DBC blocks in pDBC
	@param NumChannel        Number of audio channels (2..8: force channel number, 0: detect from OutputChannels)
	@param LowFreqChannel_3  TRUE if Low Frequency Effect audio is on channel 3
	@param FrontCenterChannel_4  TRUE if Front Center audio is on channel 4
	@param FrontLeftRightCenterChannels_7_8  If LeftCenter/RightCenter channels exist, are they in the Front(TRUE) or Rear(FALSE)?
	@param pAudioFormat      return value
	@param pAudioInfoFrame   return value
	@param pSupports_AI      return value
	See EIA/CEA-861-B Table 22 for possible channel assignments
*/
RMstatus convert_hdmi_audio_options(
	RMuint32 SampleRate, 
	enum MClkFactor mclk, 
	enum AudioOutputChannels_type OutputChannels, 
	RMbool OutputLfe, 
	enum OutputSpdif_type Spdif, 
	enum AudioDecoder_Codec_type Codec, 
	RMbool HDMIPassThrough, 
	RMuint32 HDMIPassThroughI2SLines, 
	RMbool HBR_Enable, 
	RMbool HBR_Compressed, 
	RMuint32 HBR_HeaderID, 
	struct CEA861BDataBlockCollection *pDBC, 
	RMuint32 nDBC, 
	RMuint32 NumChannel, 
	RMbool LowFreqChannel_3, 
	RMbool FrontCenterChannel_4, 
	RMbool FrontLeftRightCenterChannels_7_8, 
	struct DH_AudioFormat *pAudioFormat, 
	struct DH_AudioInfoFrame *pAudioInfoFrame, 
	RMbool *pSupports_AI)
{
	RMbool use_spdif = FALSE;
	RMuint8 BasicTVSupport = 0;
	RMuint8 FrequencyMask;
	const enum DH_AudioChannelCount dh_chancnt[] = {
		DH_AudioChannelCount_2, 
		DH_AudioChannelCount_3, 
		DH_AudioChannelCount_4, 
		DH_AudioChannelCount_5, 
		DH_AudioChannelCount_6, 
		DH_AudioChannelCount_7, 
		DH_AudioChannelCount_8
	};
	enum DH_AudioCodingType target_ac = DH_AudioCodingType_PCM;
	RMuint32 Factor = 1;
	enum DH_AudioCodingType ac;
	RMbool prohibit_spdif = FALSE;
	RMbool codec_match = FALSE;
	RMbool pcm = FALSE;
	RMuint32 max_chan = 0, pcm_max_chan = 0;
	RMuint32 pcm_freq_mask[8] = {0, 0, 0, 0, 0, 0, 0, 0};
	RMuint32 pcm_bits_mask[8] = {0, 0, 0, 0, 0, 0, 0, 0};
	RMbool pcm_on_i2s;
	RMuint32 pcm_bits = 0;
	
	*pSupports_AI = FALSE;
	
	if (HDMIPassThrough) {
		NumChannel = HDMIPassThroughI2SLines * 2;
		fprintf(stderr, "[HDMI audio]: high bitrate passthrough, using %lu I2S lines.\n", HDMIPassThroughI2SLines);
	} else if (! NumChannel) {
		// emhwlib channel mapping (OutputChannels, OutputLfe)
		//             I2S Channel:  3R  3L  2R  2L  1R  1L  0R  0L
		//            HDMI Channel:  8   7   6   5   3!  4!  2   1
		//   C = 0x01,               -   -   -   -   LFE C   -   -
		//   LR = 0x02,              -   -   -   -   LFE -   R   L
		//   LCR = 0x03,             -   -   -   -   LFE C   R   L
		//   LRS = 0x12,             -   -   -   S   LFE -   R   L
		//   LCRS = 0x13,            -   -   -   S   LFE C   R   L
		//   LRLsRs = 0x22,          -   -   Rs  Ls  LFE -   R   L
		//   LCRLsRs = 0x23,         -   -   Rs  Ls  LFE C   R   L
		//   LCRLsRsSs = 0x63        -   Ss  Rs  Ls  LFE C   R   L
		//   LRLsRsLssRss = 0xA2,    Rss Lss Rs  Ls  LFE -   R   L
		//   LCRLsRsLssRss = 0xA3    Rss Lss Rs  Ls  LFE C   R   L
		fprintf(stderr, "[HDMI audio]: Determining number of channels from channel mask 0x%02X (%s)%s\n", OutputChannels, 
			(OutputChannels == Audio_Out_Ch_C) ? "C" : 
			(OutputChannels == Audio_Out_Ch_LR) ? "LR" : 
			(OutputChannels == Audio_Out_Ch_LCR) ? "LCR" : 
			(OutputChannels == Audio_Out_Ch_LRS) ? "LRS" : 
			(OutputChannels == Audio_Out_Ch_LCRS) ? "LCRS" : 
			(OutputChannels == Audio_Out_Ch_LRLsRs) ? "LRLsRs" : 
			(OutputChannels == Audio_Out_Ch_LCRLsRs) ? "LCRLsRs" : 
			(OutputChannels == Audio_Out_Ch_LCRLsRsSs) ? "LCRLsRsSs" : 
			(OutputChannels == Audio_Out_Ch_LRLsRsLssRss) ? "LRLsRsLssRss" : 
			(OutputChannels == Audio_Out_Ch_LCRLsRsLssRss) ? "LCRLsRsLssRss" : 
			"UNKNOWN CHANNEL MASK!", 
			OutputLfe ? " + LFE" : "");
		NumChannel = 
			(OutputChannels & 0x03) + 
			((OutputChannels >> 4) & 0x03) + 
			((OutputChannels >> 6) & 0x03);
		if ((NumChannel >= 2) && OutputLfe) {  // 1.1 audio not supported
			NumChannel++;
			LowFreqChannel_3 = TRUE;
		} else {
			LowFreqChannel_3 = FALSE;
		}
		FrontCenterChannel_4 = ((OutputChannels & 0x03) == 0x03) ? TRUE : FALSE;
		FrontLeftRightCenterChannels_7_8 = FALSE;
		RMDBGLOG((LOCALDBG, "HDMI Audio AutoDetect: %lu channel%s%s%s.\n", NumChannel, 
			LowFreqChannel_3 ? ", LFE" : "", 
			FrontCenterChannel_4 ? ", FC" : "", 
			FrontLeftRightCenterChannels_7_8 ? ", FLRC" : ""));
		fprintf(stderr, "[HDMI audio]: Determined audio has %lu.%u channels\n", LowFreqChannel_3 ? NumChannel - 1 : NumChannel, LowFreqChannel_3 ? 1 : 0);
	} else {
		RMDBGLOG((LOCALDBG, "HDMI Audio: %lu channel%s%s%s.\n", NumChannel, 
			LowFreqChannel_3 ? ", LFE" : "", 
			FrontCenterChannel_4 ? ", FC" : "", 
			FrontLeftRightCenterChannels_7_8 ? ", FLRC" : ""));
		fprintf(stderr, "[HDMI audio]: Audio was set by application to have %lu.%u channels\n", LowFreqChannel_3 ? NumChannel - 1 : NumChannel, LowFreqChannel_3 ? 1 : 0);
	}
	
	RMDBGLOG((LOCALDBG, "HDMI Audio sample rate: %lu Hz.\n", SampleRate));
	fprintf(stderr, "[HDMI audio]: Audio sample rate set by application: %lu Hz, MClk factor %u\n", SampleRate, (mclk == MClkFactor_256Xfs) ? 256 : 128);
	switch (SampleRate) {
		case  32000: FrequencyMask = TV_SUPPORT_AUDIO_FREQ_32000; break;
		case  44100: FrequencyMask = TV_SUPPORT_AUDIO_FREQ_44100; break;
		case  48000: FrequencyMask = TV_SUPPORT_AUDIO_FREQ_48000; break;
		case  88200: FrequencyMask = TV_SUPPORT_AUDIO_FREQ_88200; break;
		case  96000: FrequencyMask = TV_SUPPORT_AUDIO_FREQ_96000; break;
		case 176400: FrequencyMask = TV_SUPPORT_AUDIO_FREQ_176400; break;
		case 192000: FrequencyMask = TV_SUPPORT_AUDIO_FREQ_192000; break;
		default: 
			RMDBGLOG((ENABLE, "Invalid HDMI Audio sample clock: %lu Hz\n", SampleRate));
			SampleRate = 0;
			FrequencyMask = 0;
			break;
	}
	
	pcm_on_i2s = (
		(Spdif == OutputSpdif_Disable) || 
		(Spdif == OutputSpdif_Uncompressed) || 
		(Spdif == OutputSpdif_Compressed)
	) ? TRUE : FALSE;
	
	// compressed audio over S/P-DIF or I2S
	if (
		(Spdif == OutputSpdif_Compressed) || 
		(Spdif == OutputSpdif_NoDecodeCompressed)
	) {
		switch (Codec) {
		case AudioDecoder_Codec_AC3:
			if (HDMIPassThrough) {
				RMDBGLOG((LOCALDBG, "Selecting DD+ (Dolby Digital Plus) codec\n"));
				target_ac = DH_AudioCodingType_DDPlus;
			} else {
				RMDBGLOG((LOCALDBG, "Selecting AC3 (DolbyDigital) codec\n"));
				target_ac = DH_AudioCodingType_AC3;
			}
			break;
		//case AudioDecoder_Codec_MPEG1:
		//	RMDBGLOG((LOCALDBG, "Selecting MPEG Audio codec\n"));
		//	target_ac = DH_AudioCodingType_MPEG1_3;  // also DH_AudioCodingType_MPEG1_12 ?
		//	break;
		case AudioDecoder_Codec_AAC:
		case AudioDecoder_Codec_BSAC:
			RMDBGLOG((LOCALDBG, "Selecting AAC codec\n"));
			target_ac = DH_AudioCodingType_AAC;
			break;
		case AudioDecoder_Codec_PCM:
			RMDBGLOG((LOCALDBG, "Selecting PCM codec\n"));
			target_ac = DH_AudioCodingType_PCM;
			break;
		case AudioDecoder_Codec_DTS:
			if (HDMIPassThrough) {
				RMDBGLOG((LOCALDBG, "Selecting DTS-HD codec\n"));
				target_ac = DH_AudioCodingType_DTSHD;
			} else {
				RMDBGLOG((LOCALDBG, "Selecting DTS codec\n"));
				target_ac = DH_AudioCodingType_DTS;
			}
			break;
		case AudioDecoder_Codec_WMAPRO:
		case AudioDecoder_Codec_WMAPRO_SPDIF:
			RMDBGLOG((LOCALDBG, "Selecting WMA Pro codec\n"));
			target_ac = DH_AudioCodingType_WMAPro;
			break;
		case AudioDecoder_Codec_DVDA:
			RMDBGLOG((LOCALDBG, "Selecting TrueHD codec\n"));
			target_ac = DH_AudioCodingType_MLP;
			break;
		case AudioDecoder_Codec_MPEG1:
		case AudioDecoder_Codec_WMA:
		case AudioDecoder_Codec_EXAC:
		case AudioDecoder_Codec_ATX:
		case AudioDecoder_Codec_PCMX:
		case AudioDecoder_Codec_TTONE:
			RMDBGLOG((LOCALDBG, "HDMI does not support the currently selected audio codec, sending uncompressed PCM over I2S\n"));
			target_ac = DH_AudioCodingType_PCM;
			prohibit_spdif = TRUE;
			break;
		// TODO: What to do about SACD Audio? (ACP type 3)
		}
	} else {  // uncompressed audio: PCM over I2S or S/P-DIF
		RMDBGLOG((LOCALDBG, "Selecting PCM codec\n"));
		target_ac = DH_AudioCodingType_PCM;
	}
	
	// check display's audio capabilities, if available
	if (pDBC && nDBC) {
		RMuint32 d, i;
		
		// Check all DBC entires for target codec
		for (d = 0; d < nDBC; d++) {
			if (pDBC[d].SinkCapability & SINK_SUPPORT_AI) {
				*pSupports_AI = TRUE;
			}
			if (pDBC[d].BasicTVValid) {
				BasicTVSupport |= pDBC[d].BasicTVSupport;
			}
			for (i = 0; i < pDBC[d].NbShortAudioDescriptors; i++) {
				if (pDBC[d].ShortAudioDescriptors[i].AudioFormatCode == DH_AudioCodingType_PCM) {
					RMuint32 j;
					for (j = 1; j < pDBC[d].ShortAudioDescriptors[i].MaxNumberOfChannels; j++) {
						pcm_freq_mask[j] |= pDBC[d].ShortAudioDescriptors[i].FrequencyMask;
						pcm_bits_mask[j] |= pDBC[d].ShortAudioDescriptors[i].u.BitMask;
					}
				}
				if (FrequencyMask & pDBC[d].ShortAudioDescriptors[i].FrequencyMask) {
					ac = pDBC[d].ShortAudioDescriptors[i].AudioFormatCode;
					if (ac == target_ac) {
						codec_match = TRUE;
						max_chan = RMmax(max_chan, pDBC[d].ShortAudioDescriptors[i].MaxNumberOfChannels);
						RMDBGLOG((LOCALDBG, "Display supports current codec with up to %lu channel\n", max_chan));
					} else if (ac == DH_AudioCodingType_PCM) {
						pcm = TRUE;
						pcm_max_chan = RMmax(pcm_max_chan, pDBC[d].ShortAudioDescriptors[i].MaxNumberOfChannels);
						RMDBGLOG((LOCALDBG, "Display supports PCM audio with up to %lu channel\n", pcm_max_chan));
					}
				}
			}
		}
	} else {
		RMDBGLOG((ENABLE, "No DBC from EDID provided, something is wrong!!! Fallback to basic audio\n"));
		BasicTVSupport |= TV_SUPPORT_BASIC_AUDIO;
	}
	if (BasicTVSupport & TV_SUPPORT_BASIC_AUDIO) {
		RMDBGLOG((LOCALDBG, "Display supports basic PCM audio with up to 2 channel\n"));
		pcm_freq_mask[1] |= (TV_SUPPORT_AUDIO_FREQ_32000 | TV_SUPPORT_AUDIO_FREQ_44100 | TV_SUPPORT_AUDIO_FREQ_48000);
		pcm_bits_mask[1] |= (TV_SUPPORT_AUDIO_PCM_16BIT);
		if (FrequencyMask & (TV_SUPPORT_AUDIO_FREQ_32000 | TV_SUPPORT_AUDIO_FREQ_44100 | TV_SUPPORT_AUDIO_FREQ_48000)) {
			if (target_ac == AudioDecoder_Codec_PCM) {
				codec_match = TRUE;
				max_chan = RMmax(max_chan, 2);
			} else {
				pcm = TRUE;
				pcm_max_chan = RMmax(pcm_max_chan, 2);
			}
		}
	}
	
	if (codec_match) {  // audio format supported by sink
		RMDBGLOG((LOCALDBG, "Display supports currently selected audio codec with up to %lu channel.\n", max_chan));
		if ((NumChannel > max_chan) && ! HDMIPassThrough) NumChannel = max_chan;
		// SPDIF uCode supports a maximum of 2 PCM channels
		if ((target_ac == DH_AudioCodingType_PCM) && (NumChannel > 2)) prohibit_spdif = TRUE;
		use_spdif = (! prohibit_spdif) && (Spdif != OutputSpdif_Disable);
	} else if (! pcm_on_i2s) {  // only compressed audio available
		RMDBGLOG((ENABLE, "Display does not support currently selected audio codec, and no PCM audio available!\n"));
		SampleRate = 0;
	} else if (pcm) {  // fall-back to PCM over I2S
		RMDBGLOG((LOCALDBG, "Display does not support currently selected audio codec, fallback to PCM with up to %lu channel!\n", pcm_max_chan));
		if ((NumChannel > pcm_max_chan) && ! HDMIPassThrough) NumChannel = pcm_max_chan;
		target_ac = DH_AudioCodingType_PCM;
	} else if (pcm_freq_mask[1]) {  // attempt to downsample first 2 channels to match sink
		RMDBGLOG((ENABLE, "Display only supports basic PCM audio, attempt to downsample/downmix!\n"));
		target_ac = DH_AudioCodingType_PCM;
		if (NumChannel > 2) NumChannel = 2;
		if ((FrequencyMask & (TV_SUPPORT_AUDIO_FREQ_88200 | TV_SUPPORT_AUDIO_FREQ_96000)) && (pcm_freq_mask[1] & (TV_SUPPORT_AUDIO_FREQ_44100 | TV_SUPPORT_AUDIO_FREQ_48000))) {
			Factor = 2;
			RMDBGLOG((ENABLE, "HDMI Audio sample clock not supported by display, downconverting from %lu to %lu Hz\n", SampleRate, SampleRate / Factor));
		} else if ((FrequencyMask & (TV_SUPPORT_AUDIO_FREQ_176400 | TV_SUPPORT_AUDIO_FREQ_192000)) && (pcm_freq_mask[1] & (TV_SUPPORT_AUDIO_FREQ_88200 | TV_SUPPORT_AUDIO_FREQ_96000))) {
			Factor = 2;
			RMDBGLOG((ENABLE, "HDMI Audio sample clock not supported by display, downconverting from %lu to %lu Hz\n", SampleRate, SampleRate / Factor));
		} else if ((FrequencyMask & (TV_SUPPORT_AUDIO_FREQ_176400 | TV_SUPPORT_AUDIO_FREQ_192000)) && (pcm_freq_mask[1] & (TV_SUPPORT_AUDIO_FREQ_44100 | TV_SUPPORT_AUDIO_FREQ_48000))) {
			Factor = 4;
			RMDBGLOG((ENABLE, "HDMI Audio sample clock not supported by display, downconverting from %lu to %lu Hz\n", SampleRate, SampleRate / Factor));
		} else {
			RMDBGLOG((ENABLE, "HDMI Audio sample clock not supported by display: %lu Hz\n", SampleRate));
			SampleRate = 0;
		}
	} else {
		RMDBGLOG((ENABLE, "HDMI Audio not supported by display\n"));
		SampleRate = 0;
	}
	if (target_ac == DH_AudioCodingType_PCM) {
		if (pcm_bits_mask[NumChannel - 1] & TV_SUPPORT_AUDIO_PCM_24BIT) {
			pcm_bits = 24;
		} else if (pcm_bits_mask[NumChannel - 1] & TV_SUPPORT_AUDIO_PCM_20BIT) {
			pcm_bits = 20;
		} else {
			pcm_bits = 16;
		}
		RMDBGLOG((LOCALDBG, "PCM audio with %lu bits\n", pcm_bits));
	}
	
	RMDBGLOG((LOCALDBG, "Setting up HDMI %lu.%lu kHz%s Audio with %lu channel%s%s%s%s.\n", 
		SampleRate / 1000, (SampleRate / 100) % 10, 
		(Factor == 2) ? " (halfed)" : (Factor == 4) ? " (quartered)" : "", 
		NumChannel, 
		LowFreqChannel_3 ? ", LFE on Ch.3" : "", 
		FrontCenterChannel_4 ? ", FrontCtr on Ch.4" : "", 
		(NumChannel > (RMuint32)(LowFreqChannel_3 ? (FrontCenterChannel_4 ? 4 : 3) : (FrontCenterChannel_4 ? 3 : 2))) ? ", RearLR on Chs.5&6" : "", 
		(NumChannel > (RMuint32)(LowFreqChannel_3 ? (FrontCenterChannel_4 ? 6 : 5) : (FrontCenterChannel_4 ? 5 : 4))) ? (FrontLeftRightCenterChannels_7_8 ? ", FrontLRCtr. on Chs.7&8" : ", RearLRCtr. on Chs.7&8") : ""));
	
	// Set up transmitter chip
	pAudioFormat->APIVersion = 4;
	pAudioFormat->NumChannel = NumChannel;
	pAudioFormat->SampleFrequency = SampleRate;
	pAudioFormat->MClkFrequency = pAudioFormat->SampleFrequency * ((mclk == MClkFactor_256Xfs) ? 256 : 128);
	pAudioFormat->SRC_Factor = Factor;
	pAudioFormat->PCM_Bits = pcm_bits;
	pAudioFormat->HBR_Enable = HBR_Enable;
	pAudioFormat->HBR_Compressed = HBR_Compressed;
	pAudioFormat->HBR_SamplePresentMask = (HBR_Enable ? 0x00 : 0x01);
	pAudioFormat->HBR_HeaderID = HBR_HeaderID;
	// Select audio input to SiI9030, either PCM over I2S or compressed over S/P-DIF
	if ((! use_spdif) || HDMIPassThrough || HBR_Enable) {  // take audio from I2S
		RMDBGLOG((LOCALDBG, "Using I2S to send %s audio to HDMI\n", 
			HBR_Enable ? "HighBitRate" : HDMIPassThrough ? "Compressed" : "PCM"));
		pAudioFormat->I2S0_Enable = (NumChannel >= 2);
		pAudioFormat->I2S1_Enable = (NumChannel > 2) || (NumChannel == 1);
		pAudioFormat->I2S2_Enable = (NumChannel > 4);
		pAudioFormat->I2S3_Enable = (NumChannel > 6);
		pAudioFormat->SPDIF_Enable = (HDMIPassThrough || HBR_Enable);
	} else { // take audio from S/P-DIF
		RMDBGLOG((LOCALDBG, "Using SPDIF to send audio to HDMI\n"));
		pAudioFormat->I2S0_Enable = FALSE;
		pAudioFormat->I2S1_Enable = FALSE;
		pAudioFormat->I2S2_Enable = FALSE;
		pAudioFormat->I2S3_Enable = FALSE;
		pAudioFormat->SPDIF_Enable = TRUE;
	}
	
	// Determine Audio InfoFrame parameter
	pAudioInfoFrame->Version = 0x01;
	pAudioInfoFrame->CodingType = DH_AudioCodingType_FromStreamHeader;
	pAudioInfoFrame->SampleFrequency = DH_AudioSampleFrequency_FromStreamHeader;
	pAudioInfoFrame->SampleSize = DH_AudioSampleSize_FromStreamHeader;
	pAudioInfoFrame->ChannelCount = DH_AudioChannelCount_FromStreamHeader;
	pAudioInfoFrame->DownMixInhibit = FALSE;  // change only if source is DVD-Audio
	pAudioInfoFrame->LevelShift = 0;  // leave at 0dB
	pAudioInfoFrame->MaxBitRate = 0;  // ignored with DH_AudioCodingType_FromStreamHeader
	pAudioInfoFrame->LFE_Ch3_Enable = FALSE;
	pAudioInfoFrame->FC_Ch4_Enable = FALSE;
	pAudioInfoFrame->CA = DH_Audio_CA_none;
	
	if (SampleRate && (target_ac == DH_AudioCodingType_PCM)) {
		// Make decision about channel map based on number of channels and hints:
		if (NumChannel < 2) {
			NumChannel = 2;
		} else {
			if (NumChannel > 8) NumChannel = 8;
		}
		pAudioInfoFrame->ChannelCount = dh_chancnt[NumChannel - 2];
		if (use_spdif) {  // actual speaker config unknown, only 2 ch audio for SPDIF
			pAudioInfoFrame->LFE_Ch3_Enable = FALSE;  // TRUE;
			pAudioInfoFrame->FC_Ch4_Enable = FALSE;  // TRUE;
			pAudioInfoFrame->CA = DH_Audio_CA_none;  // CA_RL5_RR6_RLC7_RRC8;
		} else {
			//   Ch1 Front Left, Ch2 Front Right: always on
			NumChannel -= 2;  // consume 2 channels
			//   Ch3 Low Frequency Effect
			pAudioInfoFrame->LFE_Ch3_Enable = ((NumChannel > 0) && LowFreqChannel_3);
			if (pAudioInfoFrame->LFE_Ch3_Enable) NumChannel--;  // consume 1 channel
			//   Ch4 Front Center
			pAudioInfoFrame->FC_Ch4_Enable = ((NumChannel > 0) && FrontCenterChannel_4);
			if (pAudioInfoFrame->FC_Ch4_Enable) NumChannel--;  // consume 1 channel
			//   Ch5 Rear Center -- or -- Ch5 Rear Left, Ch6 Rear Right
			//   Ch7 Rear Center -- or -- Ch7 Rear Left Center, Ch8 Rear Right Center -- or -- Ch7 Front Left Center, Ch8 Front Right Center
			// Note: (NumChannel && (! LFE_Ch3_Enable) && (! FC_Ch4_Enable)) does not work with SiI9030
			switch (NumChannel) {  // map remaining channels
				case 0: pAudioInfoFrame->CA = DH_Audio_CA_none; 
					break;
				case 1: pAudioInfoFrame->CA = DH_Audio_CA_RC5; 
					break;
				case 2: pAudioInfoFrame->CA = FrontLeftRightCenterChannels_7_8 ? 
						DH_Audio_CA_FLC7_FRC8 : // Note: Does not work with SiI9030
						DH_Audio_CA_RL5_RR6; 
					break;
				case 3: pAudioInfoFrame->CA = FrontLeftRightCenterChannels_7_8 ? 
						DH_Audio_CA_RC5_FLC7_FRC8 : 
						DH_Audio_CA_RL5_RR6_RC7; 
					break;
				default:
				case 4: pAudioInfoFrame->CA = FrontLeftRightCenterChannels_7_8 ? 
						DH_Audio_CA_RL5_RR6_FLC7_FRC8 : 
						DH_Audio_CA_RL5_RR6_RLC7_RRC8; 
					break;
			}
		}
	} else {  // no speaker config for compressed audio
		pAudioInfoFrame->LFE_Ch3_Enable = FALSE;  // TRUE;
		pAudioInfoFrame->FC_Ch4_Enable = FALSE;  // TRUE;
		pAudioInfoFrame->CA = DH_Audio_CA_none;  // RL5_RR6_RLC7_RRC8;
	}
	
	return RM_OK;
}

/** 
	Apply audio settings to the HDMI output
	
	@param pDH
	@param pAudioFormat
	@param pAudioInfoFrame
	@param Supports_AI
	@param AudioCP
	@param ChannelStat
	@param ChannelMask
*/
RMstatus apply_hdmi_audio(
	struct DH_control *pDH, 
	struct DH_AudioFormat *pAudioFormat, 
	struct DH_AudioInfoFrame *pAudioInfoFrame, 
	RMbool Supports_AI, 
	RMbool AudioCP, 
	RMuint32 ChannelStat, 
	RMuint32 ChannelMask)
{
	RMstatus err;
	
	DHSetAudioCP(pDH, AudioCP);
	DHSetAudioHeader(pDH, ChannelMask, ChannelStat);
	
	err = DHSetAudioFormat(pDH, pAudioFormat);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Can not enable HDMI audio!\n"));
		return err;
	}
	
	if (Supports_AI) {  // display supports ACP and ISRC
		struct CEA861InfoFrame InfoFrame;
		
		RMMemset(&InfoFrame, 0, sizeof(InfoFrame));
		InfoFrame.HeaderByte[0] = 0x04;  // Audio Content Protection (ACP) Packet
		InfoFrame.HeaderByte[1] = 0x00;  // Generic Audio
		InfoFrame.HeaderByte[2] = 0x00;
		
//		if (Codec == AudioDecoder_Codec_DVDA) {
//			InfoFrame.HeaderByte[1] = 0x02;  // DVD Audio
//			InfoFrame.DataByte[0] = 0;  // TODO: [7:0]DVD-Audio_Type_Dependent_Generation
//			InfoFrame.DataByte[1] = 0;  // TODO: [7:6]Copy_Permission [5:3]Copy_Number [2:1]Quality [0]Transaction
//		} else 
		if ((pAudioFormat->PCM_Bits == 0) || (pAudioInfoFrame->ChannelCount != DH_AudioChannelCount_2)) {
			InfoFrame.HeaderByte[1] = 0x01;  // IEC 60958 Audio
		}
		
		err = DHEnableInfoFrame(pDH, DH_InfoFrameOffset_Generic, &InfoFrame);
		if (RMFAILED(err)) RMDBGLOG((ENABLE, "Can not send ACP Info Frame!\n"));
		else RMDBGLOG((LOCALDBG, "Sending ACP Info Frame type 0x%02X\n", InfoFrame.HeaderByte[1]));
		
#ifdef DH_SEND_ISRC
		// put empty ISRC1 into DH_InfoFrameOffset_Generic2
		RMMemset(&InfoFrame, 0, sizeof(InfoFrame));
		InfoFrame.HeaderByte[0] = 0x05;  // International Standard Recording Code (ISRC) Packet, part 1
		InfoFrame.HeaderByte[1] = 0x80;  // [7]:continued in ISRC2, [6]:valid, [2:0]:status (001,010,100)
		InfoFrame.HeaderByte[2] = 0x00;
		//InfoFrame.DataByte[0] = 0;  // TODO: put UPC/EAN or ISRC code in to [0]-[15]
		err = DHEnableInfoFrame(pDH, DH_InfoFrameOffset_Generic2, &InfoFrame);
		if (RMFAILED(err)) RMDBGLOG((ENABLE, "Can not send ISRC1 Info Frame!\n"));
		else RMDBGLOG((LOCALDBG, "Sending ISRC1 Info Frame, status 0x%02X\n", InfoFrame.HeaderByte[1]));
		
		// put empty ISRC2 into DH_InfoFrameOffset_MPEG (MPEG curently not used by CEA 861-C)
		RMMemset(&InfoFrame, 0, sizeof(InfoFrame));
		InfoFrame.HeaderByte[0] = 0x06;  // International Standard Recording Code (ISRC) Packet, part 2
		InfoFrame.HeaderByte[1] = 0x00;
		InfoFrame.HeaderByte[2] = 0x00;
		//InfoFrame.DataByte[0] = 0;  // TODO: put rest of UPC/EAN or ISRC code in to [0]-[15]
		err = DHEnableInfoFrame(pDH, DH_InfoFrameOffset_MPEG, &InfoFrame);
		if (RMFAILED(err)) RMDBGLOG((ENABLE, "Can not send ISRC2 Info Frame!\n"));
		else RMDBGLOG((LOCALDBG, "Sending ISRC2 Info Frame, status 0x%02X\n", InfoFrame.HeaderByte[1]));
#endif
		
		/* Recommendation from SiI: when all of ACP, ISRC1, ISRC2, SPD and MPEG need to be enabled, do:
		   ACP into InfoFrame, DHEnableInfoFrame(InfoFrame, DH_InfoFrameOffset_SPD)
		   ISRC1 into InfoFrame, DHEnableInfoFrame(InfoFrame, DH_InfoFrameOffset_MPEG)
		   ISRC2 into InfoFrame, DHEnableInfoFrame(InfoFrame, DH_InfoFrameOffset_Generic)
		   SPD into SPDInfoFrame, DHEnableSPDInfoFrame(SPDInfoFrame, DH_InfoFrameOffset_Generic2)
		   DHWaitInfoFrame(DH_InfoFrameOffset_Generic2)
		   MPEG into MPEGInfoFrame, DHEnableMPEGInfoFrame(MPEGInfoFrame, DH_InfoFrameOffset_Generic2)
		*/
	} else {
		RMDBGLOG((LOCALDBG, "Display does not support ACP or ISRC!\n"));
		err = DHDisableInfoFrame(pDH, DH_InfoFrameOffset_Generic);
		if (RMFAILED(err)) RMDBGLOG((ENABLE, "Can not stop sending ACP Info Frame!\n"));
#ifdef DH_SEND_ISRC
		err = DHDisableInfoFrame(pDH, DH_InfoFrameOffset_Generic2);
		if (RMFAILED(err)) RMDBGLOG((ENABLE, "Can not stop sending ISRC1 Info Frame!\n"));
		err = DHDisableInfoFrame(pDH, DH_InfoFrameOffset_MPEG);
		if (RMFAILED(err)) RMDBGLOG((ENABLE, "Can not stop sending ISRC2 Info Frame!\n"));
#endif
	}
	
	return DHEnableAudioInfoFrame(pDH, pAudioInfoFrame);
}

/**
  Read the current status of the video and audio outputs and set up the HDMI connection accordingly
  
  @param  pDH                  DH handle
  @param  AudioEngineModuleID  ModuleID of the audio engine sending audio to the HDMI chip, e.g. EMHWLIB_MODULE(AudioEngine, 0)
  @param  AudioDecoderModuleID ModuleID of the audio decoder sending audio to the HDMI chip, e.g. EMHWLIB_MODULE(AudioDecoder, 0)
  @param  VideoOutputModuleID  ModuleID of the video output sending video to the HDMI chip, e.g. EMHWLIB_MODULE(DispDigitalOut, 0)
*/
RMstatus hdmi_update(struct DH_control *pDH, 
	RMuint32 AudioEngineModuleID, 
	RMuint32 AudioDecoderModuleID, 
	RMuint32 VideoOutputModuleID)
{
	RMstatus err;
	RMbool update = FALSE;
	RMuint32 AudioSampleRate;
//	enum MClkFactor mclk, hdmi_mclk;
//	enum AudioOutputChannels_type OutputChannels;
//	RMbool OutputLfe;
//	enum OutputSpdif_type Spdif;
//	enum AudioDecoder_Codec_type Codec;
//	RMbool HDMIPassThrough;
//	RMuint32 HDMIPassThroughI2SLines;
//	RMuint32 VideoPixelClock;
//	RMuint8 freq_sval;
	
	if ((pDH == NULL) || (pDH->pRUA == NULL)) {
		return RM_FATALINVALIDPOINTER;
	}
	
	// assemble current settings from HDMI
	AudioSampleRate = pDH->AudioFormat.SampleFrequency;
//	err = DH_i2c_read(pDH->pRUA, &(pDH->i2c_tx2), 0x02, &freq_sval);
//	if (RMFAILED(err)) return RM_PENDING;  // can't do it now
//	mclk = hdmi_mclk = ((freq_sval & 0x07) == 0x01) ? MClkFactor_256Xfs : MClkFactor_128Xfs;
//	OutputChannels = 
//	OutputLfe = 
//	Spdif = 
//	Codec = 
//	HDMIPassThrough = 
//	HDMIPassThroughI2SLines = 
	
	// Check if audio sample rate has changed
	err = RUAGetProperty(pDH->pRUA, AudioEngineModuleID, RMAudioEnginePropertyID_SampleFrequency, 
		&AudioSampleRate, sizeof(AudioSampleRate));
	if (RMSUCCEEDED(err) && AudioSampleRate && (AudioSampleRate != pDH->AudioFormat.SampleFrequency)) {
		fprintf(stderr, "\n\n\nSetting new Audio Sample Clock while polling in hdmi_update(): %lu Hz\n\n\n", AudioSampleRate);
		update = TRUE;
	}
	
	// Check if audio mclk factor has changed
//	err = RUAGetProperty(pDH->pRUA, AudioEngineModuleID, RMAudioEnginePropertyID_MasterClockFactor, 
//		&mclk, sizeof(mclk));
//	if (RMSUCCEEDED(err) && (mclk != hdmi_mclk)) {
//		fprintf(stderr, "\n\n\nSetting new Audio MClk factor while polling in hdmi_update(): %u X fs\n\n\n", (mclk == MClkFactor_256Xfs) ? 256 : 128);
//		update = TRUE;
//	}
	
	// Check if audio SPDIF status has changed
//	err = RUAGetProperty(pDH->pRUA, AudioEngineModuleID, RMAudioEnginePropertyID_SpdifOut, 
//		&Spdif, sizeof(Spdif));
//	if (RMSUCCEEDED(err) && (Spdif != )) {
//		fprintf(stderr, "\n\n\nSetting new Audio  while polling in hdmi_update(): %lu X fs\n\n\n", (mclk == MClkFactor_256Xfs) ? 256 : 128);
//		update = TRUE;
//	}
	
	// Check if audio codec has changed
//	err = RUAGetProperty(pDH->pRUA, AudioDecoderModuleID, RMAudioDecoderPropertyID_Codec, 
//		&Codec, sizeof(Codec));
//	if (RMSUCCEEDED(err) && (Codec != )) {
//		fprintf(stderr, "\n\n\nSetting new Audio  while polling in hdmi_update(): %lu X fs\n\n\n", (mclk == MClkFactor_256Xfs) ? 256 : 128);
//		update = TRUE;
//	}
	
	return RM_OK;
}
