/*
 *
 * Copyright (c) Sigma Designs, Inc. 2002. All rights reserved.
 *
 */

/**
	@file dcc_demo.c
	@brief sample application to access the Mambo chip and test DMA transfers
	
	@author Julien Soulier
	@ingroup dccsamplecode
*/


// utilizing mono so the main function can easily be attached as a thread function
// assuming software demux support only one demux task


#include <pthread.h>
#include "sample_os.h"

#define ENABLE_SPU_OP 1

#define ALLOW_OS_CODE 1
#include "../dcc/include/dcc.h"
#include "../dcc/src/dcc_common.h"
#include "common.h"
#include "psfdemux_common.h"
#include "play_psfdemux_helper.h"

#include "main_apps.h"

#include "../rmvdemux/include/rmvdemuxapi.h"
#include "play_vdemux.h"


#define PTS_DISCONTINUITY_DETECTION	/* defined for files with pts discontinuities */

#define GETBUFFER_TIMEOUT_US (TIMEOUT_10MS)
#define SENDDATA_TIMEOUT_US  (TIMEOUT_10MS)

#define DMA_BUFFER_SIZE_LOG2 15
#define DMA_BUFFER_COUNT     32

#define REPACK_SIZE (4096)

#define VIDEO_FIFO_SIZE (1792*1024)
#define AUDIO_FIFO_SIZE (128*1024)
#define SPU_FIFO_SIZE   (256*1024)
#define XFER_FIFO_COUNT (32)
#define VIDEO_PTS_FIFO_COUNT (512) /* ~8 sec fifo for 60 frames/sec */
#define VIDEO_INBAND_FIFO_COUNT (16)

#define RM_DEVICES_STC 0x1
#define RM_DEVICES_VIDEO 0x2
#define RM_DEVICES_AUDIO 0x4

#define KEYFLAGS (SET_KEY_DISPLAY | SET_KEY_PLAYBACK | SET_KEY_AUDIO | SET_KEY_DEBUG)

#define PTS_DISCONTINUITY_RANGE	0x20000	// ~1.4sec

#if 0
  #define SENDDBG ENABLE
#else
  #define SENDDBG DISABLE
#endif

#if 0
#define KEYDBG ENABLE
#else
#define KEYDBG DISABLE
#endif

#define WAIT_KEY()						\
{								\
	RMascii key;						\
	fprintf(stderr, "press key to continue\n");	        \
	while ( !(RMGetKeyNoWait(&key)) );			\
}							


#define GET_XFER_FIFO_INFO(pRUA, ModuleId)										\
{															\
	struct XferFIFOInfo_type XferFIFOInfo;										\
	fprintf(stderr, "( %lx: 0x%08lx %ld %ld %ld %ld ) ", ModuleId, XferFIFOInfo.StartAddress,          		\
		    XferFIFOInfo.Size, XferFIFOInfo.Writable,  XferFIFOInfo.Readable, XferFIFOInfo.Erasable);		\
	RUAGetProperty(pRUA, ModuleId, RMGenericPropertyID_XferFIFOInfo, &XferFIFOInfo, sizeof(XferFIFOInfo));		\
}														

// copy from dcc_multiple_audio.c
struct DCCMultipleAudioSource {
	struct RUA *pRUA;
	struct DCC *pDCC;

	RMuint32 instances;  //number of decoders opened

	struct DCCAudioSourceHandle AudioSourceHandles[MAX_AUDIO_DECODER_INSTANCES];

	RMuint32 nextInstance;
};


// hardcode the thread filename for now
//char alt_filename[] = "/media/transport/mpeg2/svt1.ts";
RMascii alt_filename[2048] = { 0, };

// software demux thread id
pthread_t software_demux_tid;
RMbool software_demux_in_action;
RMuint64 start_time_stamp;
RMuint64 start_file_position;

// mirror the task variables from 
static struct context_per_task  *Tasks;
static RMuint32 task_count;
static RMuint32 output_count_per_task;


// software demux keeps its own copy of dcc_info
// while command line options structures are shared with the hardware demux module
static struct dcc_context dcc_info = {0,};

extern RMbool manutest; // should be removed
static RMbool enable_spu = FALSE;
static RMuint32 NTimes = 0;
static RMuint32 file_offset = 0;

static RMuint32 trickBuffersToSend = 0;
static RMuint32 trickSizeToSend = 0;
static RMuint32 trickBuffersSent = 0;

static struct playback_cmdline *play_opt;
static struct video_cmdline *video_opt;
static struct audio_cmdline *audio_opt;
static struct demux_cmdline *demux_opt;

static RMuint32 manutest_res = 0;

static struct display_cmdline *disp_opt;


struct demux_context {
	struct RUA *pRUA;
	struct RUABufferPool *pDMA;
	RMbool FirstSystemTimeStamp;
	RMbool ResumeFromTrickMode;

	RMuint32 audio_byte_counter;
	RMuint32 video_byte_counter;
	RMbool repack_sample;
	RMuint8 *audio_repack_buf;
	RMuint8 *video_repack_buf;
	RMuint8 *spu_repack_buf;
	RMuint32 audio_repack_offset;
	RMuint32 video_repack_offset;
	RMuint32 spu_repack_offset;
	RMuint32 audio_repack_size;
	RMuint32 video_repack_size;
	RMuint32 spu_repack_size;
	RMuint64 audio_repack_pts;
	RMuint64 video_repack_pts;
	RMuint64 spu_repack_pts;
	RMbool audio_repack_pts_valid;
	RMbool video_repack_pts_valid;
	RMbool spu_repack_pts_valid;
	RMbool enable_spu;

	struct dcc_context *dcc_info;
	struct RM_PSM_Context   *PSMcontext;

	RMbool isTrickMode;
	RMbool isIFrameMode;
	RMbool initVideo;
	RMbool initAudio;

	RMbool waitForValidAudioPTS;
	RMbool waitForValidVideoPTS;

	RMuint32 cmd;
	RMuint32 audio_first_access_unit_pointer;	// a value of 0 is invalid - see DVD VI.5.2.4
	RMbool audio_first_access_unit_pointer_valid;
	
	RMuint32 start_90khz;
	RMint64 file_size;
	// test user data receive
	struct ReceiveObject_type *pReceive;
	struct RUABufferPool *pDmaUserData;
	struct RUAEvent EventUserData;
	FILE *f_record;
	RMuint32 f_record_size;

	RMbool ignoreCallback;
	RMbool fakePrevPts;

	RMuint32 prebufferedBytes;
	RMint64 realFirstPTS;
};

static RMstatus SyncTimerWithDecoderPTS(struct demux_context *pSendContext);

#define REPACK_AUDIO  1
#define REPACK_VIDEO  2
#define REPACK_SPU    4
#define REPACK_ALL    7

static void release_repacked_buffers(void *context, RMuint32 flag)
{
	struct demux_context *pSendContext = (struct demux_context *) context;
	
	if ((flag & REPACK_VIDEO) & (pSendContext->video_repack_buf != NULL)) {
		RUAReleaseBuffer(pSendContext->pDMA, pSendContext->video_repack_buf);
		pSendContext->video_repack_buf = (RMuint8 *) NULL;
		pSendContext->video_repack_offset = 0;
		pSendContext->video_repack_size = 0;
		pSendContext->video_repack_pts = 0;
		pSendContext->video_repack_pts_valid = FALSE;
	}

	if ((flag & REPACK_AUDIO) && (pSendContext->audio_repack_buf != NULL)) {
		RUAReleaseBuffer(pSendContext->pDMA, pSendContext->audio_repack_buf);
		pSendContext->audio_repack_buf = (RMuint8 *) NULL;
		pSendContext->audio_repack_offset = 0;
		pSendContext->audio_repack_size = 0;
		pSendContext->audio_repack_pts = 0;
		pSendContext->audio_repack_pts_valid = FALSE;
	}

	if ((flag & REPACK_SPU) && (pSendContext->spu_repack_buf != NULL)) {
		RUAReleaseBuffer(pSendContext->pDMA, pSendContext->spu_repack_buf);	
		pSendContext->spu_repack_buf = (RMuint8 *) NULL;
		pSendContext->spu_repack_offset = 0;
		pSendContext->spu_repack_size = 0;
		pSendContext->spu_repack_pts = 0;
		pSendContext->spu_repack_pts_valid = FALSE;
	}
}



static struct RM_PSM_Actions actions;

#define PROCESS_KEY(release, getkey)					\
do {								        \
	RMDBGLOG((KEYDBG, "processkey(%lu, %lu)\n", release, getkey));		\
	if (getkey) {							\
		PlaybackStatus = RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)); \
		if ((PlaybackStatus == RM_PSM_Stopped) || (PlaybackStatus == RM_PSM_Paused)) { \
			switch (play_opt->disk_ctrl_state) {		\
			case DISK_CONTROL_STATE_DISABLE:		\
			case DISK_CONTROL_STATE_SLEEPING:		\
				break;					\
			case DISK_CONTROL_STATE_RUNNING:		\
				if(play_opt->disk_ctrl_callback && play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_SLEEP) == RM_OK) \
					play_opt->disk_ctrl_state = DISK_CONTROL_STATE_SLEEPING; \
				break;					\
			}						\
		}							\
		err = process_command(&PSMContext, &(context.dcc_info), &actions); \
		if (RMFAILED(err)) {					\
			fprintf(stderr, "Error processing key %d\n", err); \
			goto cleanup;					\
		}							\
	}								\
	if (actions.toDoActions & RM_PSM_FLUSH_VIDEO) {			\
		RMDBGLOG((ENABLE, "flushVIDEO\n"));			\
		Stop(&context, RM_DEVICES_VIDEO, DCCStopMode_LastFrame); \
		actions.toDoActions &= ~RM_PSM_FLUSH_VIDEO;		\
	}								\
	if (actions.toDoActions & RM_PSM_FIRST_PTS) {			\
		RMDBGLOG((ENABLE, "firstPTS\n"));			\
		/*context.FirstSystemTimeStamp = TRUE;*/		\
		actions.toDoActions &= ~RM_PSM_FIRST_PTS;		\
	}								\
	if (actions.performedActions & RM_PSM_VIDEO_STOPPED) {		\
		RMDBGLOG((ENABLE, "video stopped\n"));			\
		context.initVideo = TRUE;				\
		actions.performedActions &= ~RM_PSM_VIDEO_STOPPED;	\
	}								\
	if (actions.performedActions & RM_PSM_AUDIO_STOPPED) {		\
		RMDBGLOG((ENABLE, "audio stopped\n"));			\
		if (release) {						\
			if (context.repack_sample) {			\
				RMDBGLOG((ENABLE, "release audio buffers\n")); \
				release_repacked_buffers(&context, REPACK_AUDIO); \
			}						\
			else  {						\
				RMDBGLOG((ENABLE, "release a buffer\n")); \
				RUAReleaseBuffer(pDMA, buf);		\
				buf = NULL;				\
			}						\
		}							\
		context.initAudio = TRUE;				\
		context.waitForValidAudioPTS = TRUE;			\
		actions.performedActions &= ~RM_PSM_AUDIO_STOPPED;	\
	}								\
	if ((actions.cmd == RM_QUIT) && (!actions.cmdProcessed)) {	\
		RMDBGLOG((ENABLE, "quit\n"));				\
		actions.cmdProcessed = TRUE;				\
		if (manutest == TRUE)                                   \
		        manutest_res = RM_QUIT;                         \
		if (release) {						\
			if (context.repack_sample) {			\
				RMDBGLOG((ENABLE, "release audio buffers\n")); \
				release_repacked_buffers(&context, REPACK_ALL); \
			}						\
			else  {						\
				RMDBGLOG((ENABLE, "release a buffer\n")); \
				RUAReleaseBuffer(pDMA, buf);		\
				buf = NULL;				\
			}						\
		}							\
		goto cleanup;						\
	}								\
	if ((manutest == TRUE) && (actions.cmd == RM_MANU_QUIT_OK) && (!actions.cmdProcessed)) { \
		if (manutest == TRUE)                                   \
		        manutest_res = RM_MANU_QUIT_OK;                 \
		if (release) {						\
			if (context.repack_sample) {			\
				RMDBGLOG((ENABLE, "release audio buffers\n")); \
				release_repacked_buffers(&context, REPACK_ALL); \
			}						\
			else  {						\
				RMDBGLOG((ENABLE, "release a buffer\n")); \
				RUAReleaseBuffer(pDMA, buf);		\
				buf = NULL;				\
			}						\
		}							\
		goto cleanup;						\
	}								\
	if (((RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Slow) || \
	     (RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Fast) || \
	     (RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_NextPic)) && \
	    (actions.cmdProcessed) && (!context.isTrickMode)) {		\
		RMDBGLOG((ENABLE, ">> trick mode all frames\n"));	\
		context.isTrickMode = TRUE;				\
	}								\
	if ((RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Playing) && \
	    (context.isTrickMode) &&					\
	    (actions.cmdProcessed)) {					\
		RMDBGLOG((ENABLE, ">> resume from trickmode\n"));	\
		context.isTrickMode = FALSE;				\
	}								\
	if (actions.toDoActions & RM_PSM_DEMUX_NORMAL) {		\
		RMDBGLOG((ENABLE, "demuxNormal\n"));			\
		context.isTrickMode = FALSE;				\
		Play(&context, RM_DEVICES_VIDEO, DCCVideoPlayFwd);	\
		actions.toDoActions &= ~RM_PSM_DEMUX_NORMAL;		\
	}								\
	if (actions.toDoActions & RM_PSM_DEMUX_IFRAME) {		\
		RMDBGLOG((ENABLE, "demuxIFrame\n"));			\
		Play(&context, RM_DEVICES_VIDEO | RM_DEVICES_STC, DCCVideoPlayIFrame);	\
		context.isIFrameMode = TRUE;				\
		if (context.ignoreCallback)				\
			context.ignoreCallback = FALSE;			\
		actions.toDoActions &= ~RM_PSM_DEMUX_IFRAME;		\
	}								\
	if (actions.toDoActions & RM_PSM_RESYNC_TIMER) {		\
		RMDBGLOG((ENABLE, "resyncTimer\n"));			\
		SyncTimerWithDecoderPTS(&context);			\
		actions.toDoActions &= ~RM_PSM_RESYNC_TIMER;		\
	}								\
	if ((RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Stopped) && (actions.cmdProcessed)) { \
		RMDBGLOG((ENABLE,"Got stop command\n"));		\
		if (release) {						\
			if (context.repack_sample) {			\
				RMDBGLOG((ENABLE, "release audio buffers\n")); \
				release_repacked_buffers(&context, REPACK_ALL); \
			}						\
			else  {						\
				RMDBGLOG((ENABLE, "release a buffer\n")); \
				RUAReleaseBuffer(pDMA, buf);		\
				buf = NULL;				\
			}						\
		}							\
		context.isIFrameMode = FALSE;				\
		context.FirstSystemTimeStamp = TRUE;			\
		goto mainloop_no_seek;					\
	}								\
	if ((actions.cmd == RM_STOP_SEEK_ZERO) && (!actions.cmdProcessed)) {	\
		RMDBGLOG((ENABLE,"Got stop seek zero command\n"));	\
		Stop(&context, RM_DEVICES_VIDEO | RM_DEVICES_AUDIO | RM_DEVICES_STC, DCCStopMode_BlackFrame); \
		RM_PSM_SetState(context.PSMcontext, &(context.dcc_info), RM_PSM_Stopped); \
		context.isIFrameMode = FALSE;				\
		context.FirstSystemTimeStamp = TRUE;				\
		actions.cmdProcessed = TRUE;				\
		if (release) {						\
			if (context.repack_sample) {			\
				RMDBGLOG((ENABLE, "release audio buffers\n")); \
				release_repacked_buffers(&context, REPACK_ALL); \
			}						\
			else  {						\
				RMDBGLOG((ENABLE, "release a buffer\n")); \
				RUAReleaseBuffer(pDMA, buf);		\
				buf = NULL;				\
			}						\
		}							\
		goto mainloop;						\
	}								\
	if ((actions.cmd == RM_SEEK) && (!actions.cmdProcessed)) {	\
		RMDBGLOG((ENABLE, "got seek command\n"));		\
		Stop(&context, RM_DEVICES_AUDIO | RM_DEVICES_VIDEO | RM_DEVICES_STC, DCCStopMode_LastFrame); \
		context.isIFrameMode = FALSE;				\
		context.FirstSystemTimeStamp = TRUE;			\
		context.ignoreCallback = FALSE;				\
		if (release) {						\
			if (context.repack_sample) {			\
				RMDBGLOG((ENABLE, "release audio buffers\n")); \
				release_repacked_buffers(&context, REPACK_ALL); \
			}						\
			else  {						\
				RMDBGLOG((ENABLE, "release a buffer\n")); \
				RUAReleaseBuffer(pDMA, buf);		\
				buf = NULL;				\
			}						\
		}							\
		goto mainloop_no_seek;					\
	}								\
	if ((actions.cmd == RM_DUALMODE_CHANGE) && (!actions.cmdProcessed)) { \
		RMDBGLOG((ENABLE, "got dualmode change\n"));		\
		fprintf(stderr, "Changing DualMode to :");		\
		switch(audio_opt->OutputDualMode) {								\
		case DualMode_LeftMono:										\
			fprintf(stderr, " RightMono\n");							\
			audio_opt->OutputDualMode = DualMode_RightMono;						\
			break;											\
		case DualMode_RightMono:									\
			fprintf(stderr, " MixMono\n");								\
			audio_opt->OutputDualMode = DualMode_MixMono;						\
			break;											\
		case DualMode_MixMono:										\
			fprintf(stderr, " Stereo\n");								\
			audio_opt->OutputDualMode = DualMode_Stereo;						\
			break;											\
		case DualMode_Stereo:										\
			fprintf(stderr, " LeftMono\n");								\
			audio_opt->OutputDualMode = DualMode_LeftMono;						\
			break;											\
		default:											\
			fprintf(stderr, " Unknown dual mode\n");						\
			break;											\
		}												\
		err = apply_audio_decoder_options_onthefly(&dcc_info,audio_opt);				\
		if (RMFAILED(err)) {										\
			fprintf(stderr, "Error applying audio decoder options on the fly %d\n", err);		\
		}												\
	}													\
} while (0)


#define PROCESS_KEY_INSIDE_FUNCTION()					\
do	{								\
	RMstatus err;							\
	enum RM_PSM_State PlaybackStatus;				\
									\
	RMDBGLOG((KEYDBG, "processkey_inside_function\n"));		\
	err = process_command(pSendContext->PSMcontext, &(pSendContext->dcc_info), &actions); \
	if (RMFAILED(err)) {						\
		RMDBGLOG((ENABLE, "Error while processing key %d\n", err)); \
		goto return_from_callback;				\
	}								\
	PlaybackStatus = RM_PSM_GetState(pSendContext->PSMcontext, &(pSendContext->dcc_info)); \
	if (actions.toDoActions & RM_PSM_RESYNC_TIMER) {		\
		RMDBGLOG((ENABLE, "resyncTimer\n"));			\
		SyncTimerWithDecoderPTS(pSendContext);			\
		actions.toDoActions &= ~RM_PSM_RESYNC_TIMER;		\
	}								\
	if ((actions.cmd == RM_QUIT) && (!actions.cmdProcessed)) {	\
		RMDBGLOG((ENABLE, "quit during callback\n"));		\
		pSendContext->ignoreCallback = TRUE;			\
		if (manutest == TRUE)                                   \
		    manutest_res = RM_QUIT;                             \
		goto return_from_callback;				\
	} 								\
	if ((manutest == TRUE) && (actions.cmd == RM_MANU_QUIT_OK) && (!actions.cmdProcessed)) {	\
		RMDBGLOG((ENABLE, "quit during callback\n"));		\
		pSendContext->ignoreCallback = TRUE;			\
		if (manutest == TRUE)                                   \
		    manutest_res = RM_MANU_QUIT_OK;                     \
		goto return_from_callback;				\
	} 								\
	if ((PlaybackStatus == RM_PSM_Stopped) && (actions.cmdProcessed)) { \
		RMDBGLOG((ENABLE, "stop during callback\n"));		\
		pSendContext->ignoreCallback = TRUE;			\
		goto return_from_callback;				\
	}								\
	if ((actions.cmd == RM_STOP_SEEK_ZERO) && (!actions.cmdProcessed)) { \
		RMDBGLOG((ENABLE, "seekzero during callback\n"));	\
		pSendContext->ignoreCallback = TRUE;			\
		goto return_from_callback;				\
	}								\
	if ((actions.cmd == RM_SEEK) && (!actions.cmdProcessed)){	\
		RMDBGLOG((ENABLE, "seek during callback\n"));		\
		pSendContext->ignoreCallback = TRUE;			\
		goto return_from_callback;				\
	}								\
	if (((PlaybackStatus == RM_PSM_IForward) ||			\
	    (PlaybackStatus == RM_PSM_IRewind)) && (actions.cmdProcessed)) {	\
		RMDBGLOG((ENABLE, "iframe trick during callback\n"));	\
		pSendContext->ignoreCallback = TRUE;			\
		goto return_from_callback;				\
	}								\
	if (((PlaybackStatus == RM_PSM_Slow) ||		\
	     (PlaybackStatus == RM_PSM_Fast)) && (actions.cmdProcessed)) { \
		RMDBGLOG((ENABLE,"trickmodes during callback\n"));	\
		pSendContext->isTrickMode = TRUE;			\
		pSendContext->ignoreCallback = FALSE;			\
	}								\
} while(0)





static RMstatus Stop(struct demux_context * pSendContext, RMuint32 devices, enum DCCStopMode mode)
{
	RMstatus err = RM_OK;
	struct dcc_context *dcc_info = pSendContext->dcc_info;
	
	if (devices & RM_DEVICES_VIDEO) {
		if (pSendContext->dcc_info->pVideoSource) {
			RMDBGLOG((ENABLE, "STOP: video decoder\n"));
			err = DCCStopVideoSource(dcc_info->pVideoSource, mode);
			if (RMFAILED(err)){
				RMDBGLOG((ENABLE, "Error stopping video source %d\n", err));
				return err;
			}
			pSendContext->initVideo = TRUE;

		}
	}

	if (devices & RM_DEVICES_AUDIO) {
		if (pSendContext->dcc_info->pAudioSource) {
			RMDBGLOG((ENABLE, "STOP: audio decoder\n"));
			err = DCCStopAudioSource(dcc_info->pAudioSource);
			if (RMFAILED(err)){
				RMDBGLOG((ENABLE,"Error stopping audio source %d\n", err));
				return err;
			}
		}
	}

	if ((devices & RM_DEVICES_AUDIO) && (devices & RM_DEVICES_VIDEO)) {
		pSendContext->FirstSystemTimeStamp = TRUE;
	}

	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "STOP: stc\n"));
		DCCSTCStop(dcc_info->pStcSource);
	}

	return err;

}

static RMstatus Play(struct demux_context * pSendContext, RMuint32 devices, enum DCCVideoPlayCommand mode)
{

	RMstatus err = RM_OK;
	struct dcc_context *dcc_info = pSendContext->dcc_info;
	
	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "PLAY: stc\n"));
		DCCSTCPlay(dcc_info->pStcSource);
	}

	if (devices & RM_DEVICES_VIDEO) {
		if (pSendContext->dcc_info->pVideoSource) {
			if (pSendContext->initVideo) {
				RMbool keep_sequence = TRUE;
				RMDBGLOG((ENABLE, "PLAY: initDecoder\n"));
				err = RUASetProperty(pSendContext->dcc_info->pRUA, pSendContext->dcc_info->video_decoder, RMVideoDecoderPropertyID_StorePreviousVideoHeader, &keep_sequence, sizeof(keep_sequence), 0);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Error setting video decoder to keep sequence header on Stop %d\n", err));
					return err;
				}
				pSendContext->initVideo = FALSE;
			}

			RMDBGLOG((ENABLE, "PLAY: video decoder %s\n", (mode == DCCVideoPlayIFrame ? "(iframe)":"")));
			err = DCCPlayVideoSource(pSendContext->dcc_info->pVideoSource, mode);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot play video decoder %d\n", err));
				return err;
			}
		}
	}

	if (devices & RM_DEVICES_AUDIO) {
		if (pSendContext->dcc_info->pAudioSource) {
			RMDBGLOG((ENABLE, "PLAY: audio decoder\n"));
			err = DCCPlayAudioSource(dcc_info->pAudioSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot play video decoder %d\n", err));
				return err;
			}
		}
	}


	return err;

}



// used for prebuffering
static RMstatus Pause(struct demux_context * pSendContext, RMuint32 devices)
{

	RMstatus err = RM_OK;
	
	if (devices & RM_DEVICES_VIDEO) {
		if (pSendContext->dcc_info->pVideoSource) {
			RMDBGLOG((ENABLE, "PAUSE: video decoder\n"));
			err = DCCPauseVideoSource(pSendContext->dcc_info->pVideoSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot pause video decoder %d\n", err));
				return err;
			}
		}
	}

	if (devices & RM_DEVICES_AUDIO) {
		if (pSendContext->dcc_info->pAudioSource) {
			RMDBGLOG((ENABLE, "PAUSE: audio decoder\n"));
			err = DCCPauseAudioSource(pSendContext->dcc_info->pAudioSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot pause video decoder %d\n", err));
				return err;
			}
		}
	}

	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "PAUSE: stc\n"));
		DCCSTCStop(pSendContext->dcc_info->pStcSource);
	}

	return err;

}


static RMstatus SyncTimerWithDecoderPTS(struct demux_context *pSendContext)
{
	RMuint64 videoPTS;
	RMuint64 CurrentSTC;
	RMstatus err = RM_OK;
	RMuint32 timeScale;

	/* we have to obtain the timeScale because in mpeg4 elementary 
	   streams, the time scale is not guaranteed to be 90KHz 
	*/
	DCCSTCGetTimeResolution(pSendContext->dcc_info->pStcSource, DCC_Video, &timeScale);

	DCCSTCGetTime(pSendContext->dcc_info->pStcSource, &CurrentSTC, timeScale);

	err = RUAGetProperty(pSendContext->pRUA, pSendContext->dcc_info->SurfaceID, RMGenericPropertyID_CurrentDisplayPTS, &videoPTS, sizeof(videoPTS));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "error %d while getting CurrentDisplayPTS\n", err));
		return err;
	}

	/* for MPEG1/2, timeScale 90000, videoPTS unit is 45000 always,
	   for MPEG4, timeScale is the same than videoPTS unit.
	   Note however, that we're just checking the value of timeScale, so
	   if we're in MPEG4 and timeScale 90000, this wont work. Also note that
	   this happens with elementary streams which are to be handled by
	   play_video not play_demux. 
	*/
	if (timeScale == 90000)
		videoPTS *= 2;
	

	RMDBGLOG((ENABLE, ">> resync timer (%llu) with videoDecoder current PTS (%llu), unit %lu\n", CurrentSTC, videoPTS, timeScale));
	DCCSTCSetTime(pSendContext->dcc_info->pStcSource, videoPTS, timeScale);

#ifdef PTS_DISCONTINUITY_DETECTION
	pSendContext->fakePrevPts = TRUE;
#endif


	return RM_OK;
	
}


static RMbool check_prebuf_state(struct demux_context *pSendContext, RMuint32 buffersize)
{
	RMbool quit_prebuf;
	enum RM_PSM_State PlaybackStatus = RM_PSM_GetState(pSendContext->PSMcontext, &(pSendContext->dcc_info));
	
	if (PlaybackStatus != RM_PSM_Prebuffering)
		return FALSE;

	/* if fail in getbuffer/senddata force quitting prebuffering state */
	quit_prebuf = ((buffersize == 0) || ((play_opt->prebuf_max > 0) && (pSendContext->prebufferedBytes >= play_opt->prebuf_max))) ? TRUE : FALSE;

	pSendContext->prebufferedBytes += buffersize;
//fprintf( stderr, "0x%lx \n", (long unsigned int)(pSendContext->prebufferedBytes) );
		
	if (quit_prebuf) {
		RMDBGLOG((ENABLE, "exit prebuffering state, enter play state (bufsize %lu, prebuffered %lu)\n", buffersize, pSendContext->prebufferedBytes));
		if (manutest != TRUE)
			fprintf(stderr, "now playing\n");
		RM_PSM_SetState(pSendContext->PSMcontext, &(pSendContext->dcc_info), RM_PSM_Playing);
		DCCSTCSetTime(pSendContext->dcc_info->pStcSource, pSendContext->realFirstPTS, 90000);
		Play(pSendContext, RM_DEVICES_STC | RM_DEVICES_VIDEO | RM_DEVICES_AUDIO, DCCVideoPlayFwd);
		pSendContext->prebufferedBytes = 0;
		return TRUE;
	}
	return FALSE;
}



static void flush_repacked_sample(void *context)
{
	struct demux_context *pSendContext = (struct demux_context *) context;
	RMuint8 *send_buffer = (RMuint8 *) NULL;
	RMuint32 send_length = 0;
	RMuint32 decoder;
	struct emhwlib_info Info;

	/* flush video data */
	if ( ! play_opt->send_video)
		goto flush_audio;

	if (pSendContext->video_repack_buf == NULL)
		goto flush_audio;

	decoder = pSendContext->dcc_info->video_decoder;
	send_buffer = pSendContext->video_repack_buf + pSendContext->video_repack_offset;
	send_length = pSendContext->video_repack_size;
	Info.ValidFields = (pSendContext->video_repack_pts_valid) ? TIME_STAMP_INFO : 0;
	Info.TimeStamp = pSendContext->video_repack_pts;

	while (RUASendData(pSendContext->pRUA, decoder, pSendContext->pDMA, send_buffer, send_length, (void*)&Info, sizeof(Info)) != RM_OK) {
		struct RUAEvent e;

		PROCESS_KEY_INSIDE_FUNCTION();

		e.ModuleID = decoder;
		e.Mask = RUAEVENT_XFER_FIFO_READY;
		RUAWaitForMultipleEvents(pSendContext->pRUA, &e, 1, SENDDATA_TIMEOUT_US, NULL);
	}

	RUAReleaseBuffer(pSendContext->pDMA, send_buffer);
		
 flush_audio:
	/* flush audio data */
	if ( ! play_opt->send_audio)
		goto flush_spu;

	if (pSendContext->audio_repack_buf == NULL)
		goto flush_spu;

	if (pSendContext->isTrickMode)
		goto flush_spu;
	
	decoder = pSendContext->dcc_info->audio_decoder;
	send_buffer = pSendContext->audio_repack_buf + pSendContext->audio_repack_offset;
	send_length = pSendContext->audio_repack_size;
	Info.ValidFields = (pSendContext->audio_repack_pts_valid) ? TIME_STAMP_INFO : 0;
	Info.TimeStamp = pSendContext->audio_repack_pts;

	while (RUASendData(pSendContext->pRUA, decoder, pSendContext->pDMA, send_buffer, send_length, (void*)&Info, sizeof(Info)) != RM_OK) {
		struct RUAEvent e;
		
		PROCESS_KEY_INSIDE_FUNCTION();

		e.ModuleID = decoder;
		e.Mask = RUAEVENT_XFER_FIFO_READY;
		RUAWaitForMultipleEvents(pSendContext->pRUA, &e, 1, SENDDATA_TIMEOUT_US, NULL);
	}

	RUAReleaseBuffer(pSendContext->pDMA, send_buffer);
	
 flush_spu:
	/* flush spu data */
	if ( ! play_opt->send_spu)
		return;

#ifdef	ENABLE_SPU_OP
	if (! pSendContext->enable_spu) {
		return;
	}
#else
	return;
#endif

	if (pSendContext->spu_repack_buf == NULL)
		return;

	decoder = pSendContext->dcc_info->spu_decoder;
	send_buffer = pSendContext->spu_repack_buf + pSendContext->spu_repack_offset;
	send_length = pSendContext->spu_repack_size;
	Info.ValidFields = (pSendContext->spu_repack_pts_valid) ? TIME_STAMP_INFO : 0;
	Info.TimeStamp = pSendContext->spu_repack_pts;

	while (RUASendData(pSendContext->pRUA, decoder, pSendContext->pDMA, send_buffer, send_length, (void*)&Info, sizeof(Info)) != RM_OK) {
		struct RUAEvent e;

		PROCESS_KEY_INSIDE_FUNCTION();

		e.ModuleID = decoder;
		e.Mask = RUAEVENT_XFER_FIFO_READY;
		RUAWaitForMultipleEvents(pSendContext->pRUA, &e, 1, SENDDATA_TIMEOUT_US, NULL);
	}

	RUAReleaseBuffer(pSendContext->pDMA, send_buffer);

 return_from_callback:
	return;

}

static void PESCallback(RMuint8 *buffer, RMuint32 length, RMuint64 PTS, RMbool isPtsValid,
			RMvdemuxDataType dataType, RMuint64 PESOffset, void *context)
{
	static RMascii *decoder_name[] = {"video", "audio", "spu"};
	RMascii *string;
	struct demux_context *pSendContext = (struct demux_context *) context;
	RMuint32 decoder;
	struct emhwlib_info Info;
	RMbool send_data = FALSE;
	RMuint8 *send_buffer = (RMuint8 *) NULL;
	RMuint32 send_length = 0;
	RMuint8 *repack_buffer;
	RMuint64 repack_pts;
	RMuint32 repack_offset, repack_size;
	RMbool repack_pts_valid;
	RMuint32 send_pts;
	RMuint32 *pbyte_counter = 0;
	RMuint32 first_access_unit_pointer = 0;
	RMbool isFirstAccessUnitValid = FALSE;

	enum RM_PSM_State PlaybackStatus = RM_PSM_GetState(pSendContext->PSMcontext, &(pSendContext->dcc_info));


#ifdef PTS_DISCONTINUITY_DETECTION
	static RMuint64 prevVpts = 0xffffffffffffffffll;
	static RMuint64 prevApts = 0xffffffffffffffffll;
#endif

	if (pSendContext->ignoreCallback) {

		if ((actions.cmd == RM_QUIT) && (!actions.cmdProcessed)) {
			RMDBGLOG((ENABLE, "callback called when 'quit' command was issued\n"));
			goto return_from_callback;
		}
		if ((PlaybackStatus == RM_PSM_Stopped) && (actions.cmdProcessed)) {
			RMDBGLOG((ENABLE, "callback called when 'stop' command was issued\n"));
			goto return_from_callback;
		}
		if ((actions.cmd == RM_STOP_SEEK_ZERO)  && (!actions.cmdProcessed)) {
			RMDBGLOG((ENABLE, "callback called when 'seekzero' command was issued\n"));
			goto return_from_callback;
		}
		if ((actions.cmd == RM_SEEK) && (!actions.cmdProcessed)) {	
			RMDBGLOG((ENABLE, "callback called when 'seek' command was issued\n"));
			goto return_from_callback;
		}
		if (((actions.cmd == RM_IFWD) || (actions.cmd == RM_IRWD)) && (actions.cmdProcessed)) {	
			RMDBGLOG((ENABLE, "callback called when 'iframe' command was issued\n"));
			goto return_from_callback;
		}

		RMDBGLOG((ENABLE, "********** ignoring Callback!! *********, cmd %lu, processed %lu\n", actions.cmd, actions.cmdProcessed));
		goto return_from_callback;
	}

	switch (dataType) {
		case RMVDEMUX_AUDIO:
			if (pSendContext->audio_first_access_unit_pointer_valid) {
				isFirstAccessUnitValid = TRUE;
				first_access_unit_pointer = pSendContext->audio_first_access_unit_pointer;
				pSendContext->audio_first_access_unit_pointer_valid = FALSE;
			}
			break;
		default:
			isFirstAccessUnitValid = FALSE;
			first_access_unit_pointer = 0;
			break;
	}

	switch (dataType) {
		case RMVDEMUX_VIDEO:
			if ( ! play_opt->send_video)
				return ;

			decoder = pSendContext->dcc_info->video_decoder;
			string = decoder_name[0];
			send_pts = play_opt->send_video_pts;
			repack_buffer = pSendContext->video_repack_buf;
			repack_offset = pSendContext->video_repack_offset;
			repack_size = pSendContext->video_repack_size;
			repack_pts = pSendContext->video_repack_pts;
			repack_pts_valid = pSendContext->video_repack_pts_valid;
			pbyte_counter = &pSendContext->video_byte_counter;
			//printf("Sending %lu bytes of video data\n", length);
			break;
		case RMVDEMUX_AUDIO:
			if ( ! play_opt->send_audio)
				return ;

			if ((PlaybackStatus != RM_PSM_Playing) && (PlaybackStatus != RM_PSM_Paused) && (PlaybackStatus != RM_PSM_Prebuffering))
				return;
	       
			decoder = pSendContext->dcc_info->audio_decoder;
			string = decoder_name[1];
			send_pts = play_opt->send_audio_pts;
			repack_buffer = pSendContext->audio_repack_buf;
			repack_offset = pSendContext->audio_repack_offset;
			repack_size = pSendContext->audio_repack_size;
			repack_pts = pSendContext->audio_repack_pts;
			repack_pts_valid = pSendContext->audio_repack_pts_valid;
			pbyte_counter = &pSendContext->audio_byte_counter;
			//printf("Sending Audio data\n");
			break;
		case RMVDEMUX_SUBPICTURE:
			if ( ! play_opt->send_spu)
				return ;

#ifdef	ENABLE_SPU_OP
			if (! pSendContext->enable_spu) {
				RMDBGPRINT((ENABLE, "disabled spu\n"));
				return;
			}
#else
			return;
#endif
			decoder = pSendContext->dcc_info->spu_decoder;
			string = decoder_name[2];
			send_pts = play_opt->send_spu_pts;
			repack_buffer = pSendContext->spu_repack_buf;
			repack_offset = pSendContext->spu_repack_offset;
			repack_size = pSendContext->spu_repack_size;
			repack_pts = pSendContext->spu_repack_pts;
			repack_pts_valid = pSendContext->spu_repack_pts_valid;
			break;
		case RMVDEMUX_NAVIGATION:
			RMDBGPRINT((ENABLE, "navigation\n"));
			return;
		default:
			RMDBGPRINT((ENABLE, "Unknown data type %d\n", dataType));
			return;
	}

	if ((pSendContext->repack_sample) && (repack_size>0) && 
	    ((isPtsValid) || (repack_offset + length > (RMuint32) (1<<play_opt->dmapool_log2size)) || (repack_size + length > REPACK_SIZE))) {
	    send_buffer = repack_buffer + repack_offset;
		send_length = repack_size;
		Info.ValidFields = (repack_pts_valid && send_pts) ? TIME_STAMP_INFO : 0;
		Info.TimeStamp = repack_pts;
		send_data = TRUE;
		
		repack_offset += repack_size;
		repack_size = 0;
		repack_pts = 0;
		repack_pts_valid = FALSE;
	}
	else if (!pSendContext->repack_sample) {
		send_buffer = buffer;
		send_length = length;
		Info.ValidFields = ((isPtsValid && send_pts) ? TIME_STAMP_INFO : 0) | (isFirstAccessUnitValid ? FIRST_ACCESS_UNIT_POINTER_INFO : 0);
		Info.TimeStamp = PTS;
		Info.FirstAccessUnitPointer = first_access_unit_pointer;
		send_data = TRUE;
	}

	if (send_data) {
		if (1/*(PlaybackStatus == RM_PSM_Playing) || (PlaybackStatus == RM_PSM_Paused) || (PlaybackStatus == RM_PSM_NextPic)*/) {
			if (pSendContext->FirstSystemTimeStamp) {
				if (Info.ValidFields & TIME_STAMP_INFO) {
					RMDBGLOG((ENABLE, "FirstSystemTimeStamp from %s = %llu = 0x%llx (0x%llx)\n", string, Info.TimeStamp, Info.TimeStamp, Info.TimeStamp/2));

					pSendContext->realFirstPTS = (RMint64) (Info.TimeStamp + pSendContext->start_90khz);

					// set the STC to 1sec before the real value, so that we dont the first frame when prebuffering
					DCCSTCSetTime(pSendContext->dcc_info->pStcSource, (RMuint64)(pSendContext->realFirstPTS - 90000), 90000);

					pSendContext->FirstSystemTimeStamp = FALSE;
#ifdef PTS_DISCONTINUITY_DETECTION
					if (dataType == RMVDEMUX_VIDEO)
						prevVpts = Info.TimeStamp;
				
					if (dataType == RMVDEMUX_AUDIO)
						prevApts = Info.TimeStamp;
#endif
				}
				else if (!(play_opt->send_audio_pts || play_opt->send_audio_pts)) {
					Info.TimeStamp = 0;
					RMDBGLOG((ENABLE, "No PTS -> Init FirstSystemTimeStamp = %llu\n", Info.TimeStamp));


					pSendContext->realFirstPTS = (RMint64) (Info.TimeStamp + pSendContext->start_90khz);

					// set the STC to 1sec before the real value, so that we dont the first frame when prebuffering
					DCCSTCSetTime(pSendContext->dcc_info->pStcSource, (RMuint64)(pSendContext->realFirstPTS - 90000), 90000);

					pSendContext->FirstSystemTimeStamp = FALSE;
#ifdef PTS_DISCONTINUITY_DETECTION
					prevVpts = Info.TimeStamp;
					prevApts = Info.TimeStamp;
#endif
				}
				else
					RMDBGLOG((ENABLE, "waiting for valid PTS\n"));
			}
		}

		//fprintf( stderr, "send buffer5  0x%lx, sendbuffer 0x%lx length 0x%lx\n", decoder, send_buffer, send_length );

		if ((pSendContext->waitForValidAudioPTS) && (dataType == RMVDEMUX_AUDIO) && (send_pts)) {
			if (Info.ValidFields & TIME_STAMP_INFO) {
				RMDBGLOG((ENABLE, "first valid audio PTS %llu(0x%09llx), start sending audio\n",Info.TimeStamp,Info.TimeStamp));
				pSendContext->waitForValidAudioPTS = FALSE;
#ifdef PTS_DISCONTINUITY_DETECTION
				prevApts = Info.TimeStamp;
#endif
			}
			else {
				// dont send audio with invalid pts
				RMDBGLOG((ENABLE, "audio pts not valid\n"));
				if (isPtsValid) {
					repack_pts_valid = TRUE;
					repack_pts = PTS;
				}
				goto end_data_callback;
			}
		}

		if ((pSendContext->waitForValidVideoPTS) && (dataType == RMVDEMUX_VIDEO) && (send_pts)) {
			if (Info.ValidFields & TIME_STAMP_INFO) {
				RMDBGLOG((ENABLE, "first valid video PTS %llu(0x%09llx), start sending video\n",Info.TimeStamp,Info.TimeStamp));
				pSendContext->waitForValidVideoPTS = FALSE;
#ifdef PTS_DISCONTINUITY_DETECTION
				prevVpts = Info.TimeStamp;
#endif
			}
			else {
				// dont send video with invalid pts
				RMDBGLOG((ENABLE, "video pts not valid\n"));
				if (isPtsValid) {
					repack_pts_valid = TRUE;
					repack_pts = PTS;
				}
				goto end_data_callback;
			}
		}

#ifdef PTS_DISCONTINUITY_DETECTION

		if (Info.ValidFields & TIME_STAMP_INFO) {
			RMint64 diff = 0;

			if ((pSendContext->fakePrevPts) && (dataType == RMVDEMUX_AUDIO)) {
				RMDBGPRINT((ENABLE, "Set prevAPTS to 0x%09llx\n", Info.TimeStamp));
				prevApts = Info.TimeStamp;
				pSendContext->fakePrevPts = FALSE;
			}

			if ((dataType == RMVDEMUX_VIDEO) && (prevVpts != 0xffffffffffffffffll)) {
				diff = Info.TimeStamp - prevVpts;
				prevVpts = Info.TimeStamp;
				RMDBGPRINT((DISABLE, "Vpts = %9llx %8lx (%lx)\n", Info.TimeStamp, pSendContext->video_byte_counter, file_offset));
			} 
			else if ((dataType == RMVDEMUX_AUDIO) && (prevApts != 0xffffffffffffffffll)) {
				diff = Info.TimeStamp - prevApts;
				prevApts = Info.TimeStamp;
				RMDBGPRINT((DISABLE, "Apts = %9llx %8lx (%lx)\n", Info.TimeStamp, pSendContext->audio_byte_counter, file_offset));
			}
			if ((diff < -PTS_DISCONTINUITY_RANGE) || (diff > PTS_DISCONTINUITY_RANGE)) {
				struct InbandCommand_type InbandCmd;

				RMDBGPRINT((ENABLE, "%spts discontinuity = %9llx -> %9llx\n", (dataType == RMVDEMUX_VIDEO)?"V":"A", Info.TimeStamp-diff, Info.TimeStamp));
				DCCSTCSetDiscontinuity(pSendContext->dcc_info->pStcSource, Info.TimeStamp-2*90000, 90000);
				
				InbandCmd.Tag = INBAND_COMMAND_TAG_DISCONTINUITY | INBAND_COMMAND_ACTION_STOP;
				InbandCmd.Coordinate = 0;
				RUASetProperty(pSendContext->pRUA, pSendContext->dcc_info->video_decoder, RMGenericPropertyID_InbandCommand, &InbandCmd, sizeof(InbandCmd), 0);
				RUASetProperty(pSendContext->pRUA, pSendContext->dcc_info->audio_decoder, RMGenericPropertyID_InbandCommand, &InbandCmd, sizeof(InbandCmd), 0);
			}
		}
#endif	// PTS_DISCONTINUITY_DETECTION

		if (PlaybackStatus == RM_PSM_Prebuffering) {
			RMDBGPRINT((ENABLE, "%s", dataType == RMVDEMUX_AUDIO ? "a":"v"));
		}

		{
			RMuint64 stc;
			DCCSTCGetTime(pSendContext->dcc_info->pStcSource, &stc, 90000);
			RMDBGLOG((SENDDBG, "sending %s, %lu, pts %llu(0x%09llx) %s stc %llu(0x%09llx)\n", 
				  dataType == RMVDEMUX_AUDIO ? "audio":"video",
				  send_length,
				  Info.TimeStamp,
				  Info.TimeStamp,
				  Info.ValidFields & TIME_STAMP_INFO ? "valid":"",
				  stc,
				  stc));
		}

		if (Info.ValidFields & TIME_STAMP_INFO) {
			static RMint64 max_diff = 0, min_diff = 0;
			RMint64 diff;
			if ( (prevVpts != 0xffffffffffffffffll) && (prevApts != 0xffffffffffffffffll) ) {
				diff = (RMint64)(prevVpts - prevApts) / (RMint64)90; /* diff in miliseconds */
				RMDBGLOG((DISABLE, "diff %lld %llx %llx\n", diff, prevVpts, prevApts));
				if ( (diff < -100) || (diff > 100)) {
					if ( (diff > 0) && (diff > max_diff+100) ) {
						max_diff = diff;
						RMDBGLOG((ENABLE, " %lld\n", diff));
					}
					if ( (diff < 0) && (diff < min_diff-100) ) {
						min_diff = diff;
						RMDBGLOG((ENABLE, " %lld\n", diff));
					}
				}
			}
		}
		

		while( RUASendData(pSendContext->pRUA, decoder, pSendContext->pDMA, send_buffer, send_length, (void*)&Info, sizeof(Info)) != RM_OK ) {
			struct RUAEvent e;
			check_prebuf_state(pSendContext, 0);

			PROCESS_KEY_INSIDE_FUNCTION();

			PlaybackStatus = RM_PSM_GetState(pSendContext->PSMcontext, &(pSendContext->dcc_info));

			/* skip audio in trickmode */
			if ((dataType == RMVDEMUX_AUDIO) && 
			    ((PlaybackStatus == RM_PSM_Slow) || (PlaybackStatus == RM_PSM_Fast) || (PlaybackStatus == RM_PSM_NextPic)))
				goto end_data_callback;


			e.ModuleID = decoder;
			e.Mask = RUAEVENT_XFER_FIFO_READY;
			RUAWaitForMultipleEvents(pSendContext->pRUA, &e, 1, SENDDATA_TIMEOUT_US, NULL);
		}
		
		if ( pbyte_counter )
			*pbyte_counter = *pbyte_counter + send_length;
			
		/* sendind data may fill-up the xfer fifo, so we reset the event */
		{
			struct RUAEvent e;
			
			e.ModuleID = decoder;
			e.Mask = RUAEVENT_XFER_FIFO_READY;
			RUAResetEvent(pSendContext->pRUA, &e);
		}
	}
	
	if (pSendContext->repack_sample) {
		RMuint32 val;

		val = RMmax(length, REPACK_SIZE);
		if ((repack_offset + val) > (RMuint32) (1<<play_opt->dmapool_log2size)) {
			RUAReleaseBuffer(pSendContext->pDMA, repack_buffer);
			repack_buffer = (RMuint8 *) NULL;
			repack_offset = 0;
		}

		if (repack_buffer == NULL) {
			while (RUAGetBuffer(pSendContext->pDMA, &repack_buffer,  GETBUFFER_TIMEOUT_US) != RM_OK) {

				PROCESS_KEY_INSIDE_FUNCTION();

				RMDBGLOG((DISABLE, "Wait for a buffer\n"));
			}
		}

		memcpy(repack_buffer + repack_offset + repack_size, buffer, length);
		repack_size += length;
		if (isPtsValid) {
			repack_pts_valid = TRUE;
			repack_pts = PTS;
		}
	}		

 end_data_callback:
	switch (dataType) {
	case RMVDEMUX_VIDEO:
		pSendContext->video_repack_buf = repack_buffer;
		pSendContext->video_repack_offset = repack_offset;
		pSendContext->video_repack_size = repack_size;
		pSendContext->video_repack_pts = repack_pts;
		pSendContext->video_repack_pts_valid = repack_pts_valid;
		break;
	case RMVDEMUX_AUDIO:
		pSendContext->audio_repack_buf = repack_buffer;
		pSendContext->audio_repack_offset = repack_offset;
		pSendContext->audio_repack_size = repack_size;
		pSendContext->audio_repack_pts = repack_pts;
		pSendContext->audio_repack_pts_valid = repack_pts_valid;
		break;
	case RMVDEMUX_SUBPICTURE:
		pSendContext->spu_repack_buf = repack_buffer;
		pSendContext->spu_repack_offset = repack_offset;
		pSendContext->spu_repack_size = repack_size;
		pSendContext->spu_repack_pts = repack_pts;
		pSendContext->spu_repack_pts_valid = repack_pts_valid;
		break;
	default:
		RMDBGLOG((ENABLE, "Invalid data type %d\n", dataType));
		return;
	}

 return_from_callback:	
	return;
}

static void AC3DTSCallback(RMuint8 numberOfFrameHeaders, RMuint16 firstAccessUnitPointer, void *context)
{
	struct demux_context *pSendContext = (struct demux_context *) context;
	//RMDBGPRINT((ENABLE, "AC3DTSCallback: firstAccessUnitPointer= %x\n", firstAccessUnitPointer));
	pSendContext->audio_first_access_unit_pointer_valid = TRUE;
	pSendContext->audio_first_access_unit_pointer = firstAccessUnitPointer;
	return;
}

static void LPCMCallback(RMuint8 numberOfFrameHeaders, RMuint16 firstAccessUnitPointer, RMuint32 frequency,
			 RMuint8 numberOfChannels, RMvdemuxQuantization quantizationWordLength, void *context)
{
	struct demux_context *pSendContext = (struct demux_context *) context;
	//RMDBGPRINT((ENABLE, "LPCMCallback: firstAccessUnitPointer= %x\n", firstAccessUnitPointer));
	pSendContext->audio_first_access_unit_pointer_valid = TRUE;
	pSendContext->audio_first_access_unit_pointer = firstAccessUnitPointer;
	return;
}

static void aobPcm_callback (RMuint16 firstAccessUnitPointer, 
			     RMvdemuxQuantization quantizationGr1,
			     RMvdemuxQuantization quantizationGr2,
			     RMuint32 samplingFreqGr1,
			     RMuint32 samplingFreqGr2,
			     RMuint8 bitShift,
			     RMuint8 channelAssign,
			     void * context)
{
}
	
static void mlp_callback (RMuint16 firstAccessUnitPointer, 
			  RMuint8 forwardAUSearchPointer,
			  RMuint8 backwardAUSearchPointer,
			  void *context)
{
}

static RMstatus WaitForEOS(struct demux_context *context, struct RM_PSM_Actions *pActions)
{
	RMuint32 eos_bit_field = 0;

	NTimes++;
	fprintf(stderr, "File ready %ld times, waiting for EOS\n", NTimes);

	if (context->video_byte_counter > 0) {
		eos_bit_field |= EOS_BIT_FIELD_VIDEO;
	}

	if (context->audio_byte_counter > 0) {
		eos_bit_field |= EOS_BIT_FIELD_AUDIO;
	}
	
	return WaitForEOSWithCommand(context->PSMcontext, &(context->dcc_info), pActions, eos_bit_field);

}


// thread function
void *main_vdemux( void * context_data )
{
	struct display_context disp_info;
	struct DCCVideoSource *pVideoSource = NULL;
	struct DCCAudioSource *pAudioSource = NULL;
	struct RUABufferPool *pDMA = NULL;
	ExternalRMvdemux demux;
	struct demux_context context;
	RMstatus err;
	RMfile file = NULL;
	RMuint32 videoscaler_id = 0;
	RMuint8 *repack_buf = (RMuint8 *) NULL;
	
	void **dmabuffer_array = (void **) NULL;
	RMuint32 dmabuffer_index = 0;

	RMuint32 error = 0;
	struct RM_PSM_Context PSMContext;


	RMMemset(&context, 0, sizeof(struct demux_context));

	{
		struct context_per_task * task = (struct context_per_task *)context_data;
		
		dcc_info.disp_info = &disp_info;
		play_opt = task->play_opt;
		video_opt = task->video_opt;
		audio_opt = task->audio_opt;
		demux_opt = task->demux_opt;
		disp_opt = task->disp_opt;
		dcc_info.pRUA = task->pRUA;
		dcc_info.pDCC = task->dcc_info->pDCC;
		dcc_info.disp_info = NULL;
		videoscaler_id = 0; //mono->video_scaler;
		dcc_info.route = DCCRoute_Main;
		
		RMDBGLOG((ENABLE, "created thread play_opt %lx, video_opt %lx, audio_opt %lx, disp_opt %lx, videoscaler %d\n", 
			play_opt, video_opt, audio_opt, demux_opt, videoscaler_id ));
		
		RMMemcpy( &dcc_info, task->dcc_info, sizeof( struct dcc_context ) );
		pVideoSource = task->dcc_info->pVideoSource;
		pAudioSource = task->dcc_info->pMultipleAudioSource->AudioSourceHandles[0].pAudioSource;
		dcc_info.pAudioSource = dcc_info.pMultipleAudioSource->AudioSourceHandles[0].pAudioSource;
		
		// the software demux thread has its own demux context with the main thread		
		context.pRUA = dcc_info.pRUA; // share the same rua,  however use separate pDMA for transfer
		context.dcc_info = &dcc_info; // separate copy of dcc
		context.PSMcontext = &PSMContext; 
		
		play_opt->prebuf_max = 1*1024*1024;  // force a limit on prebuffering
		context.repack_sample = TRUE; 
		demux_opt->repack_sample = TRUE;
	}

	// create software demux
	if(demux_opt->system_type != RM_SYSTEM_UNKNOWN) {
		err = RMCreateVdemux(&demux);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot create demux %d\n", err));
			goto exit_with_error;
		}
		//RMvdemuxSetType(demux, demux_opt->system_type);
		RMvdemuxSetType(demux, RM_SYSTEM_MPEG2_TRANSPORT);
		RMDBGLOG((ENABLE, "Cannot set system type %d.  ", err, demux_opt->system_type ));
		RMDBGLOG((ENABLE, "Force system type to %d\n", err, RM_SYSTEM_MPEG2_TRANSPORT ));
		
		RMvdemuxSetCallbackData(demux, PESCallback, &context);
		RMvdemuxSetAudioCallbacks(demux, AC3DTSCallback, LPCMCallback, aobPcm_callback, mlp_callback);
	}
	else {
		demux = (ExternalRMvdemux)NULL;
		RMDBGLOG((ENABLE, "System Type Unknown, exiting\n"));
		err = RM_ERROR;
		goto exit_with_error;
	}

	dcc_info.chip_num = play_opt->chip_num;

	RMDBGLOG((ENABLE, "disk_ctrl_low_level %d, disk_ctrl_log2_block_size %d, disk_ctrl_max_mem %d \n",
				 (int)play_opt->disk_ctrl_low_level, (int)play_opt->disk_ctrl_log2_block_size, (int)play_opt->disk_ctrl_max_mem ));
	/* if HD control is enabled and mode is auto, setup parameters */
	if ((play_opt->disk_ctrl_low_level) &&
	    (play_opt->disk_ctrl_log2_block_size) &&
	    (play_opt->disk_ctrl_max_mem)) {
		RMuint32 bufferSize = 0;
		RMuint32 bufferCount = 0;
		RMuint32 log2BlockSize = play_opt->disk_ctrl_log2_block_size;
		RMuint32 maxBufferingMem = play_opt->disk_ctrl_max_mem;

		bufferSize = (1 << log2BlockSize);
		bufferCount = maxBufferingMem >> log2BlockSize;
	
		play_opt->dmapool_count = bufferCount;
		play_opt->dmapool_log2size = log2BlockSize;
	
		if (play_opt->disk_ctrl_low_level >= bufferCount)
			play_opt->disk_ctrl_low_level = bufferCount >> 1;
	
		video_opt->fifo_size = 4 * (1024 * 1024);
		audio_opt->fifo_size = 2 * (1024 * 1024);

		fprintf(stderr, ">> low level %lu => %lu bytes bufferized (+ bitstreamFIFO)\n", 
			play_opt->disk_ctrl_low_level,
			play_opt->disk_ctrl_low_level * bufferSize);

	
		video_opt->xfer_count = (bufferSize / 512) * bufferCount;
		audio_opt->xfer_count = (bufferSize / 512) * bufferCount;

		err = setup_disk_control_parameters(&dcc_info, play_opt, audio_opt, video_opt, NULL);
		if (err != RM_OK) {
			fprintf(stderr, "Error %d trying to setup HD control params\n", err);
			goto exit_with_error;
		}
	}

	switch (play_opt->disk_ctrl_state) {
	case DISK_CONTROL_STATE_DISABLE:
		break;
	case DISK_CONTROL_STATE_SLEEPING:
	case DISK_CONTROL_STATE_RUNNING:
		dmabuffer_array = (void **) RMMalloc(sizeof(void*) * play_opt->dmapool_count);
		dmabuffer_index = 0;
		if (dmabuffer_array == NULL) {
			RMDBGLOG((ENABLE, "Cannot allocate dmapool array! Disable disk control\n"));
			play_opt->disk_ctrl_state = DISK_CONTROL_STATE_DISABLE;
		}
		break;
	}

	// dmapool must be created after the module open in case we do no copy transfers */
	RMDBGLOG((ENABLE, "Open pool %lu, %lu  0x%x\n", play_opt->dmapool_count, play_opt->dmapool_log2size, pDMA ));
	err = RUAOpenPool(dcc_info.pRUA, 0, play_opt->dmapool_count, play_opt->dmapool_log2size, RUA_POOL_DIRECTION_SEND, &pDMA);
	if (RMFAILED(err)) {
		RMuint32 poolSize = play_opt->dmapool_count << play_opt->dmapool_log2size;

		fprintf(stderr, "Error cannot open dmapool %d\n\n"
			"requested %lu bytes of dmapool (%lu buffers of %lu bytes), make sure you\n"
			"loaded llad with the right parameters. For example:\n"
			"max_dmapool_memory_size >= %lu max_dmabuffer_log2_size >= %lu\n\n",
			err,
			poolSize,
			play_opt->dmapool_count,
			(RMuint32)(1<<play_opt->dmapool_log2size),
			poolSize,
			play_opt->dmapool_log2size);

		goto exit_with_error;
	}
	RMDBGLOG((ENABLE, "Opened pool 0x%lx\n", pDMA ));


	dcc_info.pVideoSource = pVideoSource;
	dcc_info.pAudioSource = pAudioSource;
	dcc_info.trickmode_id = RM_NO_TRICKMODE;

	dcc_info.seek_supported = FALSE;

	err = DCCGetVideoDecoderSourceInfo(pVideoSource, &(dcc_info.video_decoder), &(dcc_info.spu_decoder), &(dcc_info.video_timer));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting video decoder source information %d\n", err));
		goto exit_with_error;
	}

	err = DCCGetAudioDecoderSourceInfo(pAudioSource, &(dcc_info.audio_decoder), &(dcc_info.audio_engine), &(dcc_info.audio_timer));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting audio decoder source information %d\n", err));
		goto exit_with_error;
	}


	context.pRUA = dcc_info.pRUA;
	context.pDMA = pDMA;
	context.repack_sample = demux_opt->repack_sample;
	context.enable_spu = enable_spu;
	context.cmd = 0;
	context.start_90khz = play_opt->start_ms * 90;

	context.dcc_info = &dcc_info;

	context.PSMcontext = &PSMContext;
	PSMContext.validPSMContexts = 1;
	PSMContext.currentActivePSMContext = 1;
	PSMContext.keyflags = KEYFLAGS;


	file = open_stream( alt_filename, RM_FILE_OPEN_READ, 0);
	if (file == NULL) {
		fprintf(stderr, "Cannot open file %s\n", alt_filename);
		goto exit_with_error;
	}

	err = RMSizeOfOpenFile(file, &(context.file_size));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot find file size\n"));
		context.file_size = (RMint64) -1;
	}

	RMDBGLOG((ENABLE, "file: %s, size %llu, duration %llu\n", alt_filename, context.file_size, play_opt->duration / 1000));
	if (play_opt->duration)
		fprintf(stderr, "duration %llu secs\n", play_opt->duration / 1000);

	dcc_info.RM_PSM_commands = RM_PSM_ENABLE_PLAY;
	dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_STOP;
	dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_PAUSE;

	dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_SPEED;
	dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_FASTER;
	dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_SLOWER;
	dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_NEXTPIC;

	if ((play_opt->duration > 1000) && (context.file_size > 0)) {
		RMDBGLOG((ENABLE, "seek and iframe mode enabled\n"));

		dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_SEEK;
		
		dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_IFWD;
		dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_IRWD;

		context.dcc_info->seek_supported = TRUE;
		context.dcc_info->iframe_supported = TRUE;
	}


	/* correct pids according to audio codec and system type */
	if ((demux_opt->system_type == RM_SYSTEM_MPEG2_DVD) || (demux_opt->system_type == RM_SYSTEM_MPEG2_PROGRAM)) {
		if (demux_opt->audio_pid == 0) {/* If audio PID==PES ID is not provided by user use audio codec option to detect */
			demux_opt->audio_pid = (audio_opt->Codec == AudioDecoder_Codec_MPEG1) ? 0xC0:0xBD;
		}
		if (audio_opt->Codec == AudioDecoder_Codec_MPEG1) {
			if ( demux_opt->audio_pid != (0xC0 + demux_opt->audio_subid)) {
				RMDBGPRINT((ENABLE, "\n***************** audio_pid audio_subid conflict *****************\n"));
				RMDBGPRINT((ENABLE, "*** for mpeg audio select either audio_pid, either audio_subid ***\n"));
				RMDBGPRINT((ENABLE, "******************************************************************\n\n"));
			}
			demux_opt->audio_pid = 0xC0 + demux_opt->audio_subid;
		}
	}

	RMTermInit(TRUE);    // don't allow ctrl-C and the like ...
	RMSignalInit(NULL, NULL);  // ... but catch other termination signals to call RMTermExit()

	repack_buf = (RMuint8 *) RMMalloc(1<<DMA_BUFFER_SIZE_LOG2);
	if (repack_buf == NULL)
		goto cleanup;


	do {
		RMuint8 *buf = NULL;
		enum RM_PSM_State PlaybackStatus;

		RMDBGLOG((ENABLE, "do-while\n"));
		if (play_opt->start_pause) {
			RMDBGLOG((ENABLE, "start in pause mode!\n"));
			/* required, because if we do 'next' the decoder *must* be running */
			err = Play(&context, RM_DEVICES_VIDEO, DCCVideoPlayFwd);
			if (RMFAILED(err)) {
				fprintf(stderr, "Cannot start decoders %d\n", err);
				goto cleanup;
			}
			
			err = Pause(&context, RM_DEVICES_VIDEO);
			if (RMFAILED(err)) {
				fprintf(stderr, "Cannot pause decoders %d\n", err);
				goto cleanup;
			}
			RM_PSM_SetState(context.PSMcontext, &(context.dcc_info), RM_PSM_Paused);
		}
		else 
			RM_PSM_SetState(context.PSMcontext, &(context.dcc_info), RM_PSM_Playing);
		play_opt->start_pause = FALSE;

	mainloop:
		
		RMDBGLOG((ENABLE, "mainloop\n"));
		file_offset = 0;
		err = RMSeekFile(file, start_file_position, RM_FILE_SEEK_START);
		if (err != RM_OK) {
			RMDBGLOG((ENABLE, "Error seeking file to beginning %d\n", err));
			goto cleanup;
		}
		{
			struct EMhwlibDisplayTimeInterval time_interval;
			time_interval.Mode = EMhwlibDisplayIntervalMode_Start;
			time_interval.StartPTSLo = (RMuint32)(start_time_stamp);
			time_interval.StartPTSHi = (RMuint32)(start_time_stamp>>32);
			time_interval.EndPTSLo = 0;
			time_interval.EndPTSHi = 0;
			while( (err = RUASetProperty(context.dcc_info->pRUA, context.dcc_info->SurfaceID, RMGenericPropertyID_DisplayTimeInterval, &(time_interval), sizeof(time_interval), 0)) == RM_PENDING )
				;
			if (RMFAILED(err) && (err != RM_INVALIDMODE)) {
				RMDBGLOG((ENABLE, "Cannot set time interval\n"));
				goto cleanup;
			}
			RMDBGLOG((ENABLE, "Time Interval: %d, 0x%lx%lx\n", time_interval.Mode, time_interval.StartPTSHi, time_interval.StartPTSLo)); 		
		}
	



	mainloop_no_seek:
		RMDBGLOG((ENABLE, "mainloop_noseek\n"));

		if (actions.cmd == RM_SEEK) {
			RMint64 seek_pos;

			seek_pos = (dcc_info.seek_time * context.file_size * 1000) / (play_opt->duration);
			RMDBGLOG((ENABLE, "seeking to %lu s, pos %llu\n", dcc_info.seek_time, seek_pos)); 

			if (RMSeekFile(file, seek_pos, RM_FILE_SEEK_START) != RM_OK) {
				RMDBGLOG((ENABLE, "Error: seeking file to position %lu s, %lld kB\n", dcc_info.seek_time, seek_pos/1024));
				goto cleanup;
			}

		}

		context.FirstSystemTimeStamp = TRUE;
		context.ResumeFromTrickMode = FALSE;
		context.audio_byte_counter = 0;
		context.video_byte_counter = 0;
		context.audio_repack_buf = (RMuint8 *) NULL;
		context.video_repack_buf = (RMuint8 *) NULL;
		context.spu_repack_buf = (RMuint8 *) NULL;
		context.audio_repack_offset = 0;
		context.video_repack_offset = 0;
		context.spu_repack_offset = 0;
		context.audio_repack_size = 0;
		context.video_repack_size = 0;
		context.spu_repack_size = 0;
		context.audio_repack_pts = 0;
		context.video_repack_pts = 0;
		context.spu_repack_pts = 0;
		context.audio_repack_pts_valid = FALSE;
		context.video_repack_pts_valid = FALSE;
		context.spu_repack_pts_valid = FALSE;
		context.audio_first_access_unit_pointer_valid = FALSE;
		context.audio_first_access_unit_pointer = 0;

		context.waitForValidAudioPTS = TRUE;
		context.waitForValidVideoPTS = TRUE;
		context.ignoreCallback = FALSE;

		if (demux) {
			
			RMvdemuxReset(demux);
			RMvdemuxSetVideoStream(demux, demux_opt->video_pid, 0);
			RMvdemuxSetSubpictureStream(demux, demux_opt->spu_subid);
			RMvdemuxSetAudioStream(demux, demux_opt->audio_pid, demux_opt->audio_subid);
		}

		DCCSTCSetSpeed(dcc_info.pStcSource, play_opt->speed_N, play_opt->speed_M);


		PlaybackStatus = RM_PSM_GetState(context.PSMcontext, &(context.dcc_info));
		if ((PlaybackStatus != RM_PSM_Paused) && (PlaybackStatus != RM_PSM_Stopped)) {
			RMDBGLOG((ENABLE, "setting play state\n"));
			RM_PSM_SetState(context.PSMcontext, &(context.dcc_info), RM_PSM_Playing);	
		}
		else 
			PROCESS_KEY(FALSE, TRUE);

		
		// the following call will configure the decoders, after that we can 'pause' them
		err = Play(&context, RM_DEVICES_AUDIO | RM_DEVICES_VIDEO, DCCVideoPlayFwd);
		RMDBGLOG((ENABLE, "audio module 0x%lx video module 0x%lx\n",context.dcc_info->audio_decoder,  context.dcc_info->video_decoder));
		if (err != RM_OK)
			goto exit_with_error;

		/* do prebufferization only when in playing state */
		if (RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Playing) {

			Pause(&context, RM_DEVICES_STC | RM_DEVICES_VIDEO | RM_DEVICES_AUDIO);
		
			RM_PSM_SetState(context.PSMcontext, &(context.dcc_info), RM_PSM_Prebuffering);
			fprintf(stderr, "prebuffering\n");
		}

		/* wake up disks if necessary */
		switch (play_opt->disk_ctrl_state) {
		case DISK_CONTROL_STATE_DISABLE:
		case DISK_CONTROL_STATE_RUNNING:
			break;
		case DISK_CONTROL_STATE_SLEEPING:
			if(play_opt->disk_ctrl_callback && play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_RUN) == RM_OK)
				play_opt->disk_ctrl_state = DISK_CONTROL_STATE_RUNNING;
			break;
		}

		while (1) { // additionnal while to handle commands issued during EOSWait
			RMuint32 total = 0;
			while (1) {
				
				RMuint32 count;
				RMstatus status;
				
				PROCESS_KEY(FALSE, TRUE);
				

							
				if (demux_opt->repack_sample) {
					buf = repack_buf;
				}
				else {
					if (buf) {
						RMDBGLOG((ENABLE, "******************** unreleased buffer found!\n"));
						RUAReleaseBuffer(pDMA, buf);
						buf = NULL;
					}

			get_buffer:
					switch (play_opt->disk_ctrl_state) {
					case DISK_CONTROL_STATE_DISABLE:
					case DISK_CONTROL_STATE_SLEEPING:
						break;
					case DISK_CONTROL_STATE_RUNNING:
						if (dmabuffer_index > 0) {
							dmabuffer_index--;
							buf = dmabuffer_array[dmabuffer_index];
							goto fill_buffer;
						}
						break;
					}
					
					while (RUAGetBuffer(pDMA, &buf,  GETBUFFER_TIMEOUT_US) != RM_OK) {

						//RMDBGLOG((ENABLE, "\t\t****************get buffer failed!\n"));

						check_prebuf_state(&context, 0);

						switch (play_opt->disk_ctrl_state) {
						case DISK_CONTROL_STATE_DISABLE:
						case DISK_CONTROL_STATE_SLEEPING:
							break;
						case DISK_CONTROL_STATE_RUNNING:
							if(play_opt->disk_ctrl_callback && play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_SLEEP) == RM_OK)
								play_opt->disk_ctrl_state = DISK_CONTROL_STATE_SLEEPING;
							break;
						}

						
						PROCESS_KEY(FALSE, TRUE);
					}
				}
				
				check_prebuf_state(&context, (RMuint32) (1<<(play_opt->dmapool_log2size)));
//	fprintf( stderr, "prebuf_max 0x%x prebuffered bytes 0x%x dampoollog2size %d\n", (int)play_opt->prebuf_max, (int)context.prebufferedBytes, (int)play_opt->dmapool_log2size);

				switch (play_opt->disk_ctrl_state) {
				case DISK_CONTROL_STATE_DISABLE:
				case DISK_CONTROL_STATE_RUNNING:
					break;
				case DISK_CONTROL_STATE_SLEEPING:
					dmabuffer_array[dmabuffer_index] = buf;
					dmabuffer_index ++;
					if (dmabuffer_index + play_opt->disk_ctrl_low_level >= play_opt->dmapool_count) {
						if(play_opt->disk_ctrl_callback && play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_RUN) == RM_OK)
							play_opt->disk_ctrl_state = DISK_CONTROL_STATE_RUNNING;
					}
					goto get_buffer;
				}
				
			fill_buffer:

				if (RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_IRewind) {
					RMint64 position;
					RMuint64 seekto;
					
					
					if (!trickSizeToSend) {
						trickSizeToSend = (RMuint32) (context.file_size / (play_opt->duration / 500)); //there are roughly 2 iframes per second
						trickBuffersToSend = trickSizeToSend >> play_opt->dmapool_log2size;
						RMDBGLOG((ENABLE, "size %llu, duration %lu s, iframeSize %lu, buffers %lu (of %lu bytes)\n", 
							  context.file_size, 
							  (RMuint32)(play_opt->duration / 1000), 
							  trickSizeToSend,
							  trickBuffersToSend,
							  (1<<play_opt->dmapool_log2size)));
						
					}
					if (trickBuffersSent >= trickBuffersToSend)
						trickBuffersSent = 0;
					
					if (trickBuffersSent == 0) {
						RMGetCurrentPositionOfFile(file, &position);
						seekto = position - (RMuint64) 2 * trickBuffersToSend * (1<<(play_opt->dmapool_log2size));
						RMDBGLOG((ENABLE, "pos %llu, seekto %llu\n", position, seekto));
						status = RMSeekFile(file, seekto, RM_FILE_SEEK_START);
						if (status != RM_OK) {
							perror("error seeking in rwd trickmode, assume EOS\n");
							break;
						}
					}
					
					status = RMReadFile(file, buf, (1<<play_opt->dmapool_log2size), &count);
					trickBuffersSent++;
					RMDBGLOG((ENABLE, "sent buffer %lu\n", trickBuffersSent));
				}
				else {
				
					status = RMReadFile(file, buf, (1<<play_opt->dmapool_log2size), &count);
					{	// sometimes the the main thread does not 
						// save enough data for the software demux thread
						RMuint32 maxretry = 3;
						RMuint32 i = 0;
						while( (i < maxretry) && (status == RM_ERRORENDOFFILE) ) {
							RMDBGLOG((ENABLE, "read file failed, retrying... %d status %d, buf 0x%lx, count %d\n", i, (int)status, buf, count));
							sleep( 1 );
							status = RMReadFile(file, buf, (1<<play_opt->dmapool_log2size), &count);
							if( (status != RM_ERRORENDOFFILE) && (status != RM_ERRORREADFILE) )
								RMDBGLOG((ENABLE, "succeed, got buffer, status %d, buf 0x%lx, count %d\n", (int)status, buf, count)); ;
							i ++;
							PROCESS_KEY(FALSE, TRUE);
						}
					}
					RMDBGLOG((SENDDBG, "Read file fill buffer  0x%lx %lu %lu %lu\n", buf, count, total, file_offset));
					trickBuffersSent = 0;
				}
					
				total += count;
				RMDBGLOG((DISABLE, "bytes read %lu, total %lu\n", count, total));
				
				if (status == RM_ERRORREADFILE) {
					RMDBGLOG((ENABLE, "Error reading file %d\n", status));
					goto cleanup;
				}
				
				if (status == RM_ERRORENDOFFILE) {
					RMDBGLOG((ENABLE, "End of time shift buffer file, read failed, status %d, buf 0x%lx, count %d\n", (int)status, buf, count));
					if (demux_opt->repack_sample) 
						flush_repacked_sample(&context);
					else {
						RMDBGLOG((ENABLE, "release a buffer\n"));
						RUAReleaseBuffer(pDMA, buf);
						buf = NULL;
					}
					goto cleanup;
				}

								
				file_offset += count;
				
				if (demux) {
					RMvdemuxDemux(demux, buf, count);
					/* check if the user pressed a key when we were processing a callback */
					RMDBGLOG((KEYDBG, "after callback\n"));
					PROCESS_KEY(FALSE, FALSE);
				}
				else {
					RMDBGLOG((ENABLE, "Error demux does not exit !\n" ));
					goto cleanup;
				}
				

				PROCESS_KEY(TRUE, TRUE);
				
				if (!demux_opt->repack_sample) {
					//RMDBGLOG((ENABLE, "release buffer 0x%lx\n", buf));
					RUAReleaseBuffer(pDMA, buf);
					buf = NULL;
				}
			} // while 1
			
			check_prebuf_state(&context, 0);

			switch (play_opt->disk_ctrl_state) {
			case DISK_CONTROL_STATE_DISABLE:
			case DISK_CONTROL_STATE_SLEEPING:
				break;
			case DISK_CONTROL_STATE_RUNNING:
				if(play_opt->disk_ctrl_callback && play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_SLEEP) == RM_OK)
					play_opt->disk_ctrl_state = DISK_CONTROL_STATE_SLEEPING;
				break;
			}

			
			// in case we're still in pause state, wait for a key
			PROCESS_KEY(FALSE, TRUE);
		

			err = WaitForEOS(&context, &actions);
			{
				RMuint64 stc;
				DCCSTCGetTime(dcc_info.pStcSource, &stc, 90000);
			
				RMDBGLOG((ENABLE, "Timer duration %llu s\n", stc/90000));
			}
			if (err == RM_KEY_WHILE_WAITING_EOS) {
				err = RM_OK;
				PROCESS_KEY(FALSE, FALSE);
				if ((manutest == TRUE) && (actions.cmd == RM_MANU_QUIT_OK)) {
					goto cleanup;
				}
			}
			else {
				break; //EOS
			}
		}

		if (play_opt->loop_count > 0)
			play_opt->loop_count --;

		/* if there is another loop, stop devices */
		if ((play_opt->loop_count > 0) || (play_opt->waitexit != TRUE) || (play_opt->infinite_loop))
			Stop(&context, RM_DEVICES_AUDIO | RM_DEVICES_VIDEO | RM_DEVICES_STC, DCCStopMode_BlackFrame);

	} while ((play_opt->infinite_loop) || (play_opt->loop_count > 0));

 cleanup:
	error = 0;

	RMTermExit();

 exit_with_error:
	if( play_opt->waitexit ) {
		RMascii key;
		fprintf(stderr, "press q key again if you really want to stop & quit\n");
		while ( !(RMGetKeyNoWait(&key) && ((key == 'q') || (key =='Q'))) );
	}
	
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "exiting due to error %d, %s\n", err, RMstatusToString(err)));
		error = -1; //exit with error
	}

	RMDBGLOG((ENABLE, "closing...\n"));

	if (repack_buf != NULL)
		RMFree(repack_buf);

	if (dmabuffer_index) {
		RMuint32 i;
		for (i = 0; i < dmabuffer_index; i++) {
			RUAReleaseBuffer(pDMA, dmabuffer_array[i]);
			RMDBGLOG((ENABLE, "released buffer[%lu] @ 0x%08lx\n", i, dmabuffer_array[i]));
		}
		RMFree(dmabuffer_array);
	}

	if (file) {
		RMDBGLOG((ENABLE, "closing bitstream %s\n", alt_filename));
		RMCloseFile(file);
		file = NULL;
	}

	if (pVideoSource) {
		RMDBGLOG((ENABLE, "stop video source\n"));
		err = DCCStopVideoSource(pVideoSource, DCCStopMode_LastFrame);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot stop video decoder %d\n", err));
			error = -1;
		}
	}
	
	if (pAudioSource) {
		RMDBGLOG((ENABLE, "stop audio source\n"));
		err = DCCStopAudioSource(pAudioSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot stop audio decoder %d\n", err));
			error = -1;
		}
	}

	if (dcc_info.pStcSource) {
		RMDBGLOG((ENABLE, "stop STC\n"));
		DCCSTCStop(dcc_info.pStcSource);
	}

	if (pDMA) {
		RMDBGLOG((ENABLE, "close DMA pool\n"));
		err = RUAClosePool(pDMA);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error cannot close dmapool %d\n", err));
			error = -1;
		}
	}

	if (context.pReceive)
		DCCCloseReceive (context.pReceive);

	err = ReconnectHardwareDemux();
	if( RMFAILED(err) ) {
		RMDBGLOG((ENABLE, "Error in reconnect hardware demux, %d\n", err));
	}
	software_demux_in_action = FALSE;
	start_time_stamp = 0;
	start_file_position = 0;
	RMDBGLOG((ENABLE, ">->->->->->->->->->->->->->->->->->->->->->->->->>> SwtichToHardwareDemux 0x%lx, count %d\n", (void*)Tasks, (int)task_count ));
	
	return (void*)error;
}



//
// functions related to hardware demux to software demux switching
//

void SetupSoftwareDemuxGlobal( struct context_per_task  *tasks, RMuint32 taskcount, RMuint32 outputcountpertask )
{
	Tasks = tasks;
	task_count = taskcount;
	output_count_per_task = outputcountpertask;
	software_demux_in_action = FALSE;
	start_time_stamp = 0;
	start_file_position = 0;
	return;
}

RMstatus send_disable_output_demux_command(struct RUA *pRUA, RMuint32 demux, struct EMhwlibOutputMask_type *discmd) 
{
	struct RUAEvent evt;
	RMuint32 index;
	RMstatus err;

	evt.ModuleID = demux;
	evt.Mask = RUAEVENT_COMMANDCOMPLETION;
	
	err = RUAResetEvent(pRUA, &evt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot reset demux OutputDisableCommand completion event, %s\n", RMstatusToString(err)));
		return err;
	}
	
	err = RUASetProperty(pRUA, demux, RMDemuxTaskPropertyID_OutputDisableCommand, discmd, sizeof(struct EMhwlibOutputMask_type), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot send demux OutputDisableCommand, %s\n", RMstatusToString(err)));
		return err;
	}
		
	evt.ModuleID = demux;
	evt.Mask = RUAEVENT_COMMANDCOMPLETION;
	err = RUAWaitForMultipleEvents(pRUA, &evt, 1, TIMEOUT_100MS, &index);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "wait for demux OutputDisableCommand completion %d failed, %s\n", RMstatusToString(err)));
		return err;
	}
	
	return RM_OK;
}



RMstatus DecoderStop(struct context_per_task *pContext, RMuint32 devices)
{
	RMstatus err = RM_OK;
	
	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "STOP: stc\n"));
		DCCSTCStop(pContext->dcc_info->pStcSource);
	}

	if (devices & RM_DEVICES_PSFDEMUX) {
		RMDBGLOG((ENABLE, "STOP: psfdemux\n"));
		
		err = DCCStopDemuxTask(pContext->dcc_info->pDemuxTask);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot stop demux %lx, err=%d\n", pContext->id, err);
			return err;
		}
//		err = StopCleanup(pContext);
	}

	if (err != RM_OK)
		return err;


	if (devices & RM_DEVICES_VIDEO) {
		if ((pContext->sendVideoData) && (pContext->dcc_info->pVideoSource)) {
			RMDBGLOG((ENABLE, "STOP: video decoder\n"));
			
			err = DCCStopVideoSource(pContext->dcc_info->pVideoSource, DCCStopMode_LastFrame);
			if (RMFAILED(err)) {
				fprintf(stderr, "Cannot stop video decoder %lx, err=%d\n", pContext->id, err);
				return err;
			}
		}
	}

	if (devices & RM_DEVICES_AUDIO) {
		if (pContext->sendAudioData) { 
			if (pContext->dcc_info->pAudioSource) {
				RMDBGLOG((ENABLE, "STOP: audio decoder\n"));
				
				err = DCCStopAudioSource(pContext->dcc_info->pAudioSource);
				if (RMFAILED(err)){
					fprintf(stderr, "Cannot stop audio decoder %lx, err=%d\n", pContext->id, err);
					return err;
				}
			}
			else if (pContext->dcc_info->pMultipleAudioSource) {
				RMDBGLOG((ENABLE, "STOP: multiple audio decoder\n"));
				
				err = DCCStopMultipleAudioSource(pContext->dcc_info->pMultipleAudioSource);
				if (RMFAILED(err)){
					fprintf(stderr, "Cannot stop multiple audio decoder %lx, err=%d\n", pContext->id, err);
					return err;
				}
			}
		}
	}


	return err;

}

RMstatus DecoderPlay(struct context_per_task *pContext, RMuint32 devices, enum DCCVideoPlayCommand mode)
{
	RMstatus err = RM_OK;

	if (devices & RM_DEVICES_PSFDEMUX) {
		RMDBGLOG((ENABLE, "PLAY: psfdemux\n"));
		
		err = DCCPlayDemuxTask(pContext->dcc_info->pDemuxTask);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot play demux %lx, err=%d\n", pContext->id, err);
			return err;
		}
	}

	if (devices & RM_DEVICES_VIDEO) {
		if ((pContext->sendVideoData) && (pContext->dcc_info->pVideoSource)) {
			RMDBGLOG((ENABLE, "PLAY: video decoder\n"));
			
			err = DCCPlayVideoSource(pContext->dcc_info->pVideoSource, mode);
			if (RMFAILED(err)) {
				fprintf(stderr, "Cannot play video decoder %lx, err=%d\n", pContext->id, err);
				return err;
			}
		}
	}

	if (devices & RM_DEVICES_AUDIO) {
		if (pContext->sendAudioData) {
			if (pContext->dcc_info->pAudioSource) {
				RMDBGLOG((ENABLE, "PLAY: audio decoder\n"));
				
				err = DCCPlayAudioSource(pContext->dcc_info->pAudioSource);
				if (RMFAILED(err)){
					fprintf(stderr, "Cannot play audio decoder %lx, err=%d\n", pContext->id, err);
					return err;
				}
			}
			else if (pContext->dcc_info->pMultipleAudioSource) {
				RMDBGLOG((ENABLE, "PLAY: multiple audio decoder\n"));
				
				err = DCCPlayMultipleAudioSource(pContext->dcc_info->pMultipleAudioSource);
				if (RMFAILED(err)){
					fprintf(stderr, "Cannot play multiple audio decoder %lx, err=%d\n", pContext->id, err);
					return err;
				}
			}
		}
	}

	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "PLAY: stc\n"));
		DCCSTCPlay(pContext->dcc_info->pStcSource);
	}


	return err;

}


RMstatus DecoderPause(struct context_per_task *pContext, RMuint32 devices)
{

	RMstatus err = RM_OK;
	
	if (devices & RM_DEVICES_PSFDEMUX) {
		RMDBGLOG((ENABLE, "PAUSE: psfdemux\n"));
		
		err = DCCPauseDemuxTask(pContext->dcc_info->pDemuxTask);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot pause demux %lx, err=%d\n", pContext->id, err);
			return err;
		}
	}

	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "PAUSE: stc\n"));
		DCCSTCStop(pContext->dcc_info->pStcSource);
	}



	if (devices & RM_DEVICES_VIDEO) {
		if ((pContext->sendVideoData) && (pContext->dcc_info->pVideoSource)) {
			RMDBGLOG((ENABLE, "PAUSE: video decoder\n"));

			err = DCCPauseVideoSource(pContext->dcc_info->pVideoSource);
			if (RMFAILED(err)) {
				fprintf(stderr, "Cannot pause video decoder %lx, err=%d\n", pContext->id, err);
				return err;
			}
		}
	}

	if (devices & RM_DEVICES_AUDIO) {
		if (pContext->sendAudioData) {
			if (pContext->dcc_info->pAudioSource) {
				RMDBGLOG((ENABLE, "PAUSE: audio decoder\n"));
				
				err = DCCPauseAudioSource(pContext->dcc_info->pAudioSource);
				if (RMFAILED(err)) {
					fprintf(stderr, "Cannot pause audio decoder %lx, err=%d\n", pContext->id, err);
					return err;
				}
			}
			else if (pContext->dcc_info->pMultipleAudioSource) {
				RMDBGLOG((ENABLE, "PAUSE: multiple audio decoder\n"));
				
				err = DCCPauseMultipleAudioSource(pContext->dcc_info->pMultipleAudioSource);
				if (RMFAILED(err)) {
					fprintf(stderr, "Cannot pause multiple audio decoder %lx, err=%d\n", pContext->id, err);
					return err;
				}
			}
		}
	}


	return err;

}

static RMstatus SendVideoCommand(struct RUA *pRUA, RMuint32 v_decoder, enum VideoDecoder_Command_type v_command) 
{
	struct RUAEvent evt;
 	enum VideoDecoder_State_type state;
	RMuint32 index;
	RMstatus err;
	RMstatus cmdStatus;

	evt.ModuleID = v_decoder;
	evt.Mask = RUAEVENT_COMMANDCOMPLETION;
	
	err = RUAResetEvent(pRUA, &evt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot reset video command completion event, %s\n", RMstatusToString(err)));
		return err;
	}


	err = RUASetProperty(pRUA, v_decoder, RMVideoDecoderPropertyID_Command, &v_command, sizeof(v_command), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot send video command, %s\n", RMstatusToString(err)));
		return err;
	}
	
	evt.ModuleID = v_decoder;
	evt.Mask = RUAEVENT_COMMANDCOMPLETION;
	err = RUAWaitForMultipleEvents(pRUA, &evt, 1, WAIT_COMMAND_TIMEOUT_US, &index);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "wait for video command completion failed, %s\n", RMstatusToString(err)));
		return err;
	}
	
	err = RUAGetProperty(pRUA, v_decoder, RMVideoDecoderPropertyID_State, &state, sizeof(state));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get video state, %s\n", RMstatusToString(err)));
		return err;
	}
	
	err = RUAGetProperty(pRUA, v_decoder, RMVideoDecoderPropertyID_CommandStatus, &cmdStatus, sizeof(cmdStatus));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get command status, %s\n", RMstatusToString(err)));
		return err;
	}

	return cmdStatus;
}


static RMstatus SendAudioCommand(struct RUA *pRUA, RMuint32 a_decoder, enum AudioDecoder_Command_type a_command) 
{
	struct RUAEvent evt;
 	//enum AudioDecoder_State_type state;
	RMuint32 index;
	RMstatus err;

	evt.ModuleID = a_decoder;
	evt.Mask = RUAEVENT_COMMANDCOMPLETION;
	
	err = RUAResetEvent(pRUA, &evt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot reset audio command completion event, %s\n", RMstatusToString(err)));
		return err;
	}


	err = RUASetProperty(pRUA, a_decoder, RMAudioDecoderPropertyID_Command, &a_command, sizeof(a_command), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot send audio command, %s\n", RMstatusToString(err)));
		return err;
	}
	
	evt.ModuleID = a_decoder;
	evt.Mask = RUAEVENT_COMMANDCOMPLETION;
	err = RUAWaitForMultipleEvents(pRUA, &evt, 1, WAIT_COMMAND_TIMEOUT_US, &index);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "wait for audio command completion failed, %s\n", RMstatusToString(err)));
		return err;
	}
	
	//err = RUAGetProperty(pRUA, a_decoder, RMAudioDecoderPropertyID_State, &state, sizeof(state));
	//if (RMFAILED(err)) {
	//	RMDBGLOG((ENABLE, "Cannot get audio state, %s\n", RMstatusToString(err)));
	//	return err;
	//}

	return RM_OK;
}



static RMstatus HardwareDemuxStartVideoOutput( struct context_per_task * task )
{
	RMstatus err;
	RMuint32 demux_output;
	RMuint32 dummy;
	struct DemuxOutput_Connect_type connect;

	RMDBGLOG((ENABLE, "HardwareDemuxStartVideoOutput 0x%lx\n", task ));
	demux_output = EMHWLIB_MODULE(DemuxOutput, output_count_per_task*task->id + task->videoDemuxOutputIndex );
	
	RMDBGLOG((ENABLE, "Init video decoder 0x%lx\n", (int)task->dcc_info->pVideoSource->decoder_moduleID ));
	// uninitialized video decoder
	err = SendVideoCommand( task->pRUA, task->dcc_info->pVideoSource->decoder_moduleID, VideoDecoder_Command_Uninit );
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_HardwareDemuxStartVideoOutput uninit video decoder Error\n", task->id));
		return err;
	}
	
	connect.demux_task_module_id = task->demux_task;
	connect.consumer_module_id = task->dcc_info->pVideoSource->decoder_moduleID;
	RMDBGLOG((ENABLE, "0x%x Connect 0x%lx to 0x%lx\n", demux_output, connect.demux_task_module_id, connect.consumer_module_id ));
	// connect video decoder to demux
	err = RUASetProperty( task->pRUA, demux_output, RMDemuxOutputPropertyID_Connect, &connect, sizeof(connect), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_HardwareDemuxStartVideoOutput connect video demux output Error\n", task->id));
		return err;
	}
	// initilaize video decoder
	err = SendVideoCommand( task->pRUA, task->dcc_info->pVideoSource->decoder_moduleID, VideoDecoder_Command_Init );
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_HardwareDemuxStartVideoOutput init video decoder Error\n", task->id));
		return err;
	}

	// enable demux output to video decoder
	err = RUASetProperty( task->pRUA, demux_output, RMDemuxOutputPropertyID_Enable, &dummy, sizeof(dummy), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_HardwareDemuxStartVideoOutput enable video Error\n", task->id));
	}
	

	err = DecoderPlay( task, RM_DEVICES_VIDEO, VideoDecoder_Command_PlayFwd );
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_HardwareDemuxStartVideoOutput start video Error\n", task->id));
	}

	return RM_OK;
}


static RMstatus HardwareDemuxStartAudioOutput( struct context_per_task * task )
{
	RMstatus err;
	RMuint32 demux_output;
	RMuint32 dummy;
	struct DemuxOutput_Connect_type connect;
	struct AudioDecoder_SynchroniseAudioWithDisplayPTS_type syncPTS;

	RMDBGLOG((ENABLE, "HardwareDemuxStartAudioOutput 0x%lx\n", task ));
	demux_output = EMHWLIB_MODULE(DemuxOutput, output_count_per_task*task->id + task->audioDemuxOutputIndex[0] );
	
	RMDBGLOG((ENABLE, "Init audio decoder 0x%lx \n", (int)task->dcc_info->pMultipleAudioSource->AudioSourceHandles[0].moduleID ));
	// uninitialise audio
	err = SendAudioCommand( task->pRUA, task->dcc_info->pMultipleAudioSource->AudioSourceHandles[0].moduleID, AudioDecoder_Command_Uninit );
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_HardwareDemuxStartAudioOutput uninit audio decoder Error\n", task->id));
		return err;
	}
	connect.demux_task_module_id = task->demux_task;
	connect.consumer_module_id = task->dcc_info->pMultipleAudioSource->AudioSourceHandles[0].moduleID;
	RMDBGLOG((ENABLE, "0x%x Connect 0x%lx to 0x%lx\n", demux_output, connect.demux_task_module_id, connect.consumer_module_id ));
	// connect audio decoder to demux
	err = RUASetProperty( task->pRUA, demux_output, RMDemuxOutputPropertyID_Connect, &connect, sizeof(connect), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_HardwareDemuxStartAudioOutput connect audio demux output Error\n", task->id));
		return err;
	}
	// initialise audio
	err = SendAudioCommand( task->pRUA, task->dcc_info->pMultipleAudioSource->AudioSourceHandles[0].moduleID, AudioDecoder_Command_Init );
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_HardwareDemuxStartAudioOutput init audio decoder Error\n", task->id));
		return err;
	}
	
	syncPTS.ModuleID = task->dcc_info->SurfaceID;
	syncPTS.Enable = FALSE;
	RMDBGLOG((ENABLE, "0x%x Sync Audio Decoder PTS\n",  task->dcc_info->pMultipleAudioSource->AudioSourceHandles[0].moduleID ));
	// sync audio with display PTS
	err = RUASetProperty( task->pRUA, task->dcc_info->pMultipleAudioSource->AudioSourceHandles[0].moduleID, RMAudioDecoderPropertyID_SynchroniseAudioWithDisplayPTS, &syncPTS, sizeof(syncPTS), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_HardwareDemuxStartAudioOutput connect audio demux output Error\n", task->id));
		return err;
	}
	// enable demux output to audio decoder
	err = RUASetProperty( task->pRUA, demux_output, RMDemuxOutputPropertyID_Enable, &dummy, sizeof(dummy), 0);
	if( RMFAILED(err) ) {
		RMDBGLOG((ENABLE, "%ld_HardwareDemuxStartAudioOutput enable audio Error\n", task->id));
	}
	err = DecoderPlay(task, RM_DEVICES_AUDIO, 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_HardwareDemuxStartAudioOutput start audio Error\n", task->id));
	}
	
	return RM_OK;
}


static RMstatus ReconnectHardwareDemuxPerTask(struct context_per_task * task)
{
	RMstatus err;
	enum EMhwlibTimerSync timer_sync;
	
	RMDBGLOG((ENABLE, "ReconnectHardwareDemuxPerTask 0x%lx \n", (void*)task ));

	timer_sync = EMhwlibTimerSync_FirstPcrSetPlayStc;
	err = RUASetProperty( task->pRUA, task->demux_task, RMDemuxTaskPropertyID_TimerSync, &timer_sync, sizeof(timer_sync), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_ReconnectHardwareDemuxPerTask Pcr Update STC Error\n", task->id));
	}
	// enable output entry and start video
	// set output entry for spu
	err = HardwareDemuxStartVideoOutput( task );
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "ReconnectHardwareDemuxPerTask Error in HardwareDemuxStartVideoOutput %d\n", err));
		return err;
	}
	// enable output entry and start audio
	err = HardwareDemuxStartAudioOutput( task );
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "ReconnectHardwareDemuxPerTask Error in HardwareDemuxStartAudioOutput %d\n", err));
		return err;
	}

	//err = DCCSTCStop( task->dcc_info->pStcSource );
	//if (RMFAILED(err)) {
	//	RMDBGLOG((ENABLE, "%ld_ReconnectHardwareDemuxPerTask Stop STC Error\n", task->id));
	//}
	//err = DCCSTCSetSpeed( task->dcc_info->pStcSource, 1, 1);
	//err = DCCSTCPlay( task->dcc_info->pStcSource );
	//if (RMFAILED(err)) {
	//	RMDBGLOG((ENABLE, "%ld_ReconnectHardwareDemuxPerTask Start STC Error\n", task->id));
	//}
	// set output entry for pcr
	// enable pid entries if applicable
	return RM_OK;
}


RMstatus ReconnectHardwareDemux(void)
{
	RMuint32 i;
	RMstatus err;
	
	RMDBGLOG((ENABLE, "ReconnectHardwareDemux task 0x%lx, count %d\n", (void*)Tasks, (int)task_count ));
	for( i =0; i < task_count; i++ ) {
		err = ReconnectHardwareDemuxPerTask( &Tasks[i] ); 
		if( RMFAILED(err) ) {
			RMDBGLOG((ENABLE, "Error in ReconnectHardwareDemux(%d), %d\n", (int)i, err));
			return err;
		}
	}
	
	return RM_OK;
}


// create a new thread, and let the thread function to start software demux playback
RMstatus RunSoftwareDemux( struct context_per_task * hwdemux_task )
{
	if (pthread_create(&software_demux_tid, NULL, main_vdemux, (void*)hwdemux_task )) {
		RMDBGLOG((ENABLE, "error creating thread\n"));
		return RM_ERROR;		
	}
//	pthread_join(software_demux_tid,NULL);	// wait for the folked thread to finish
//	RMDBGLOG((ENABLE, "waiting for thread finish\n" ));

	software_demux_in_action = TRUE;
	return RM_OK;
}


static RMstatus HardwareDemuxStopVideoOutput( struct context_per_task * task )
{
	RMstatus err;
	struct EMhwlibOutputMask_type discmd;
	struct DemuxOutput_Disconnect_type disconnect;
	RMuint32 demux_output;
	//RMuint32 dummy;

	RMDBGLOG((ENABLE, "HardwareDemuxStopVideoOutput 0x%lx\n", task ));
	// disable pid entry
	// do not disable input pid in case of recording in progress 
		// disable video pisoftwaredemuxd
		//err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryDisable, &task->video_pidentry, sizeof(task->video_pidentry), 0);
		//if (RMFAILED(err)) {
		//	RMDBGLOG((ENABLE, "%ld_HardwareDemuxStopVideoOutput Error video RMDemuxTaskPropertyID_PidEntryEnable", task->id));
		//	return err;
		//}
	// announce demux to disable and flush the context video output
	discmd.output_mask[0] = 1 << (task->videoDemuxOutputIndex);
	err = send_disable_output_demux_command( task->pRUA, task->demux_task, &discmd );
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_HardwareDemuxStopVideoOutput send_disable_output_demux_command Error\n", task->id));
		return err;
	}
	
	// video decoder stop - this will flush all the data from fifo
	err = DecoderStop( task, RM_DEVICES_VIDEO );
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_HardwareDemuxStopVideoOutput Stop video Error\n", task->id));
		return err;
	}

	//err = RUASetProperty( task->pRUA, task->dcc_info->pVideoSource->decoder_moduleID, RMVideoDecoderPropertyID_FlushReaderDisplayFIFO, &dummy, sizeof(dummy), 0);
	//if (RMFAILED(err)) {
	//	RMDBGLOG((ENABLE, "%ld_HardwareDemuxStopVideoOutput RMVideoDecoderPropertyID_FlushReaderDisplayFIFO Error\n", task->id));
	//	return err;
	//}

	RMDBGLOG((ENABLE, "uninit video decoder 0x%lx\n", (int)task->dcc_info->pVideoSource->decoder_moduleID ));
	err = SendVideoCommand( task->pRUA, task->dcc_info->pVideoSource->decoder_moduleID, VideoDecoder_Command_Uninit );
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_HardwareDemuxStopVideoOutput uninit video decoder Error\n", task->id));
		return err;
	}
	demux_output = EMHWLIB_MODULE(DemuxOutput, output_count_per_task*task->id + task->videoDemuxOutputIndex );
	disconnect.demux_task_module_id = task->demux_task;
	disconnect.consumer_module_id = task->dcc_info->pVideoSource->decoder_moduleID;
	RMDBGLOG((ENABLE, "0x%x disconnect 0x%lx to 0x%lx\n", demux_output, disconnect.demux_task_module_id, disconnect.consumer_module_id ));
	err = RUASetProperty( task->pRUA, demux_output, RMDemuxOutputPropertyID_Disconnect, &disconnect, sizeof(disconnect), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_HardwareDemuxStopVideoOutput disconnect video demux output Error\n", task->id));
		return err;
	}
	//RMDBGLOG((ENABLE, "Init video decoder 0x%lx\n", (int)task->dcc_info->pVideoSource->decoder_moduleID ));
	err = SendVideoCommand( task->pRUA, task->dcc_info->pVideoSource->decoder_moduleID, VideoDecoder_Command_Init );
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_HardwareDemuxStartVideoOutput init video decoder Error\n", task->id));
		return err;
	}

	return RM_OK;
}



static RMstatus HardwareDemuxStopAudioOutput( struct context_per_task * task )
{
	RMstatus err;
	struct EMhwlibOutputMask_type discmd;
	struct DemuxOutput_Disconnect_type disconnect;
	RMuint32 demux_output;

	RMDBGLOG((ENABLE, "HardwareDemuxStopAudioOutput 0x%lx\n", task ));
	// disable pid entry
	// do not disable input pid in case of recording in progress 
		// disable audio pid
		//err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryDisable, &task->audio_pidentry, sizeof(task->audio_pidentry), 0);
		//if (RMFAILED(err)) {
		//	RMDBGLOG((ENABLE, "%ld_HardwareDemuxStopAudioOutput Error audio RMDemuxTaskPropertyID_PidEntryEnable", task->id));
		//	return err;
	// announce demux to disable and flush the context audio output
	// assume only one audio instance
	discmd.output_mask[0] = 1 << (task->audioDemuxOutputIndex[0]);
	err = send_disable_output_demux_command( task->pRUA, task->demux_task, &discmd );
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_HardwareDemuxStopAudioOutput send_disable_output_demux_command Error\n", task->id));
		return err;
	}
		// audio decoder stop - this will flush all the data from fifo

	err = DecoderStop( task, RM_DEVICES_AUDIO );
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_HardwareDemuxStopAudioOutput Stop Audio Error\n", task->id));
		return err;
	}

				
	RMDBGLOG((ENABLE, "Uninit audio decoder 0x%lx \n", (int)task->dcc_info->pMultipleAudioSource->AudioSourceHandles[0].moduleID ));
	//RMDBGLOG((ENABLE, "Uninit multiple audio decoder 0x%lx \n", (int)task->dcc_info->pMultipleAudioSource->AudioSourceHandles[0].pAudioSource->decoder_moduleID ));
	err = SendAudioCommand( task->pRUA, task->dcc_info->pMultipleAudioSource->AudioSourceHandles[0].moduleID, AudioDecoder_Command_Uninit );
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_HardwareDemuxStopAudioOutput uninit audio decoder Error\n", task->id));
		return err;
	}
	demux_output = EMHWLIB_MODULE(DemuxOutput, output_count_per_task*task->id + task->audioDemuxOutputIndex[0] );
	disconnect.demux_task_module_id = task->demux_task;
	disconnect.consumer_module_id = task->dcc_info->pMultipleAudioSource->AudioSourceHandles[0].moduleID;
	RMDBGLOG((ENABLE, "0x%x disconnect 0x%lx to 0x%lx\n", demux_output, disconnect.demux_task_module_id, disconnect.consumer_module_id ));
	err = RUASetProperty( task->pRUA, demux_output, RMDemuxOutputPropertyID_Disconnect, &disconnect, sizeof(disconnect), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_HardwareDemuxStopVideoOutput disconnect audio demux output Error\n", task->id));
		return err;
	}
	//RMDBGLOG((ENABLE, "Init audio decoder 0x%lx \n", (int)task->dcc_info->pMultipleAudioSource->AudioSourceHandles[0].moduleID ));
	err = SendAudioCommand( task->pRUA, task->dcc_info->pMultipleAudioSource->AudioSourceHandles[0].moduleID, AudioDecoder_Command_Init );
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_HardwareDemuxStartAudioOutput init audio decoder Error\n", task->id));
		return err;
	}
	
	return RM_OK;
}


// disconnect the hardware demux without stopping
static RMstatus DisconnectHardwarePerTaskDemux( struct context_per_task * task )
{
	RMstatus err = RM_OK;
	RMDBGLOG((ENABLE, "DisconnectHardwarePerTaskDemux 0x%lx\n", task ));

	// ther		
			
	// disable output entry and flush output entry for video 
	// disable output entry and flush output entry for spu
	err = HardwareDemuxStopVideoOutput( task );
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error in HardwareDemuxStopVideoOutput %d\n", err));
		return err;
	}

	// disable output entry and flush output entry for audio
	err = HardwareDemuxStopAudioOutput( task );
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error in HardwareDemuxStopAudioOutput %d\n", err));
		return err;
	}

	// disable and flush output entry for pcr if pcr is send to a separate output
	// stop stc
	err = DecoderStop( task, RM_DEVICES_STC );
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "%ld_HardwareDemuxStopVideoOutput Stop STC Error\n", task->id));
	}

	return RM_OK;
}


static RMstatus DisconnectHardwareDemux( struct context_per_task * task, RMuint32 taskcount )
{
	RMuint32 i;
	RMstatus err;
	
	RMDBGLOG((ENABLE, "DisconnectHardwareDemux task 0x%lx, count %d\n", (void*)task, (int)taskcount ));
	for( i =0; i < taskcount; i++ ) {
		err = DisconnectHardwarePerTaskDemux( &task[i] ); 
		if( RMFAILED(err) ) {
			RMDBGLOG((ENABLE, "Error in DisconnectHardwarePerTaskDemux, %d\n", err));
			return err;
		}
	}
	return RM_OK;
}


#define MINIMUM_WIND_BACK (2*1024*1024)
// switch from hardware demux to software dRestartHardwareDemuxemux without stopping the demux module
//
static RMstatus SwtichFromHardwareDemuxToSoftwareDemux(void)
{
	RMstatus err;
	RMint64 outputbytecount = 0;
	//RMuint32 demux_output = EMHWLIB_MODULE(DemuxOutput, output_count_per_task*Tasks[0].id + 12);

	// before disconnect get the current file position 
	// wind it back a little
	//err = RUAGetProperty(Tasks[0].pRUA, demux_output, RMDemuxOutputPropertyID_OutputByteCount, &outputbytecount, sizeof(outputbytecount));
	err = RMSizeOfFile( (RMnonAscii*)alt_filename, &outputbytecount );
	if( RMFAILED(err) ) {
		RMDBGLOG((ENABLE, "Error %d while getting time_shift file\n", err));
		return err;
	}
	start_file_position = (RMuint64)outputbytecount;
	//assert( (start_file_position >= 0) && (start_file_position < Tasks[i].fileSize) );
	if( start_file_position >= MINIMUM_WIND_BACK )
		start_file_position -= MINIMUM_WIND_BACK;
	else
		start_file_position = 0;
	
	RMDBGLOG((ENABLE, "SwtichFromHardwareDemuxToSoftwareDemux bytecount %lld\n", start_file_position ));
	err = DisconnectHardwareDemux( Tasks, task_count );
	if( RMFAILED(err) ) {
		RMDBGLOG((ENABLE, "Error in disconnecting hardware demux, %d\n", err));
		return RM_ERROR;
	}

	// get the time stamp for the picture currently on display.
	err = RUAGetProperty(Tasks[0].pRUA, Tasks[0].dcc_info->SurfaceID, RMGenericPropertyID_CurrentDisplayPTS, &start_time_stamp, sizeof(start_time_stamp));
	if( RMFAILED(err) ) {
		RMDBGLOG((ENABLE, "Error %d while getting CurrentDisplayPTS\n", err));
		return err;
	}

#ifdef WITH_NEW_AUDIO_COMMON_CODE
 {
   struct AudioDecoder_AudioPlayTime_type Aplay_time;
	// get the time stamp for the picture currently on display.
	err = RUAGetProperty(Tasks[0].pRUA, Tasks[0].dcc_info->pMultipleAudioSource->AudioSourceHandles[0].moduleID, RMAudioDecoderPropertyID_AudioPlayTime, &Aplay_time, sizeof(struct AudioDecoder_AudioPlayTime_type));
	if( RMFAILED(err) ) {
		RMDBGLOG((ENABLE, "Error %d while getting CurrentDisplayPTS\n", err));
		return err;
	}
	start_time_stamp = Aplay_time.PlayStartPTS;
 }
#endif	


	RMDBGLOG((ENABLE, "Disconnected Video and Audio from hardware demux at %llu, ts 0x%llx\n", start_file_position, start_time_stamp ));

	err = RunSoftwareDemux( &Tasks[0] );
	if( RMFAILED(err) ) {
		RMDBGLOG((ENABLE, "Error in connecting software demux, %d\n", err));
		return RM_ERROR;
	}
	
	return RM_OK;	
}


// switching from hardware demux to software demux interface function
RMstatus SwtichToSoftwareDemux(void)
{
	RMDBGLOG((ENABLE, ">->->->->->->->->->->->->->->->->->->->->->->->->>> SwtichToSoftwareDemux 0x%lx, count %d\n", (void*)Tasks, (int)task_count ));
	RMDBGLOG((ENABLE, "Task 0 demux_task 0x%lx\n", (int)Tasks[0].demux_task ));
	return SwtichFromHardwareDemuxToSoftwareDemux( );
}


