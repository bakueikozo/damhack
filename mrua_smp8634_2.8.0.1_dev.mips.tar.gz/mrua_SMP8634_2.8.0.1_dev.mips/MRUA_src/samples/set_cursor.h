/*
 *
 * Copyright (c) Sigma Designs, Inc. 2003. All rights reserved.
 *
 */

/**
	@file set_cursor.h
	@brief sample application to access the Mambo chip and use the hardware cursor
	prototype header file
	
	@author Christian Wolff
   	@ingroup mruasamplecode
*/


/**
   Create a hardware cursor and display it.

   @param pInstance  
   @return RM_OK if success, otherwise returns an error code.
*/
RMstatus set_cursor(
	struct RUA *pInstance);

