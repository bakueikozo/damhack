/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   outports_options.c
  @brief  

  Contains functions to initialize, obtain from a commandline and apply
  the options that manage outports configuration.

  @author Oriol Prieto Gasco
  @date   2006-04-15
*/


#include "sample_os.h"

#define ALLOW_OS_CODE 1
#include "../rua/include/rua.h"
#include "../dcc/include/dcc.h"
#include "../rmcore/include/rmstatustostring.h"
#include "common.h"

/* to be removed */
#include "../dcc/src/dcc_common.h"

#include "outports_options.h"

#define SCART_ENABLE_GPIO 13
#define SCART_WIDESCREEN_GPIO 14

#define DHDBG DISABLE


/* this is defined in  "../emhwlib/include/emhwlib_videoformatnames.h", included in parse_display_options */
extern RMascii *TVFormatString[];

static RMstatus print_outports_options(void){
	fprintf(stdout,"\n\n\n" 
		"-help : Shows this message\n"
		"-analog : All options following this are applied to the analog outport\n"
		"-component : All options following this are applied to the component outport\n"
		"-digital : All options following this are applied to the digital outport\n"
		"-f <standard> : Sets output standard. -f \"list\" prints a list of available standards. [NTSC_M]\n"
		"-route <route_name> : Selects the display route to use. [main] vcr colorbars\n"
		"-vmf <filename.vmf> : Specify a filename with a video mode line, used instead of -f options\n"
		"-cs <colorspace> : Sets the output colorspace. [yuv_601] yuv_709 rgb_0_255 rgb_16_235\n"
		"-asp <x> <y>: Sets display aspect ratio  (x y in [0-255] range) [4 3]\n"
		"\t(0 0 means that the source aspect ratio is used for the display\n"
		"\taspect ratio (used with WSS).\n"
		"-afd <active format>: designate the portion of the screen containing actual picture information:\n"
		"\t[none], full, 16x9top, 14x9top, 64x27, 4x3, 16x9, 14x9, 4x3_14x9, 16x9_14x9, 16x9_4x3\n"
		"\tThe last 3 are optional clipping formats, e.g. the last is a 16x9 format that could be cropped to 4x3\n"
		"-dvi_hdmi <chip> : Selects supported DVI/HDMI chip.  [siI164] siI170 siI9030 siI9034 siI9134 anx9030 lvds none\n"
		"-hdmi <state> : Force HDMI (AVI info frames and audio) or DVI mode (no AVI/audio), state is optional: [1] 0\n"
		"-hdcp : Enable HDCP (only valid on siI170 and siI9030 DVI chip)\n"
		"-hdmi2c <n> [<speed>]: Use I2C module  for DVI/HDMI init (0=software, 1=hardware, 2=built-in hdmi)\n"
		"\t<speed>: optional, I2C bus speed in kHz\n"
		"-hdmi_ddc_tx: use same I2C bus for DDC and Tx-Chip access (on some standalone boards)\n"
		"-dvi_reset <GPIO>: use a GPIO pin to reset DVI chip [0](disabled) (use 4 or 11 on some standalone boards)\n"
		"-hdmi_de: Generate DE signal by HDMI chip instead of using the one from 86xx digital out\n"
		"-hdmi_act <active format>: designate the portion of the screen containing actual picture information:\n"
		"\t[none], full, 16x9top, 14x9top, 64x27, 4x3, 16x9, 14x9, 4x3_14x9, 16x9_14x9, 16x9_4x3\n"
		"\tThe last 3 are optional clipping formats, e.g. the last is a 16x9 format that could be cropped to 4x3\n"
		"-hdmi_bars <top> <bottom> <left> <right>: designate filler bars on the screen, 0..4096:\n"
		"\ttop:end of horizontal bar at top [0], bottom: start of horizontal bar at bottom [4096]\n"
		"\tleft:end of vertical bar at left [0], right: start of vertical bar at right [4096]\n"
		"-hdmi_scan [under|over]: tag picture as underscanned (computer) or overscanned (video)\n"
		"-hdmi_spd Vendor Product [<class>]: Send HDMI SPD infor frame, identifying source product\n"
		"\tclass: STB, DVD, DVHS, HDD, DVC, DSC, VCD, Game, PC, BluRay, SACD\n"
		"\t-tmds_mode <gpio> <threshold>: Set GPIO pin 'gpio' to 1 when HDMI pixel clock is above 'threshold' MHz\n"
		"-agc_version <version>: Sets the macrovision version [0] 1\n"
		"-agc <level>: Sets the macrovision level [0] 1 2 3\n"
		"-aps <level>: Sets the aps level [0] 1 2 3\n"
		"-cgmsa <level>: Sets the cgms level [0] 1 2 3\n"
		"-rcd <level>: Sets the rcd bit [0] 1 \n"
		"-asb <level>: Sets the asb bit [0] 1 \n"
		"-wss_625 <enable> <format> <position> <ar_x> <ar_y>.\n"
		"-wss_525 <enable> <format> <ar_x> <ar_y>. [3 0 0 0]\n"
		"\tOBSOLETE! use -afd instead of -wss_625 and -wss525.\n"
		"\t<enable>: 0: disable 1: enable bot 2: enable top [3]: enable top/bot\n"
		"\t<format>: [0]: fullformat 1: letterbox\n"
		"\t<position>: [0]: top 1: center\n"
		"\t<ar_x> <ar_y>: aspect ratio [4 3]\n"
		"-swap <order> : swaps the outputs color component order [rgb] rbg grb gbr brg bgr\n"
		"-dp <protocol> : Sets the protocol on the digital output (601, 656, vip) [601]\n"
		"-dig_dr [0|1] : Forces whether to use the DoubleRate feature or not. Default: on for HDMI 480i/576i modes\n"
		"-dclk : Do not invert the digital video clock (inverted by default)\n"
		"-ddr : Use double data rate mode on the digital out (data on both edges of the clock)\n"
		"-ddr_delay: set a DDR data delay (0..7) [2] -- Obsolete, use -dig_delay instead!\n"
		"-dig_no_delay: disable the 400 pSec data delay in non-DDR mode -- Obsolete, use -dig_delay instead!\n"
		"-dig_delay <n>: set a data delay of n picoseconds in both, DDR and non-DDR modes [2300/400]\n"
		"-vsync_delay: delay the VSync on the digital output port by one pixel clock\n"
		"-trailing_edge: enable the field ID logic on the HSync trailing edge of the digital output\n"
		"-chroma_sync <EIA|SMPTE>: sync on Pb/Pr of component output: EIA = no sync present (default), SMPTE = sync embedded\n"
		"-scart_en <0|1> <pio> <inv> : disable/standby (0) or enable (1) the SCART\n"
		"-scart_ws <0|1|a> <pio> <inv> : signal 4:3 (0) or 16:9 (1) or automatic (a) aspect ratio to\n"
		"-bus <n> : Is the bus size of the digital out. 8 16 [24]\n"
		"-cav_mode <mode> : sets the comopnent mode: rgb_scart,rgb_sog,rgb_smpte,yuv_betacam,yuv_m2,[yuv_smpte]\n"
		"-flags <flags> : Specific flags to apply to the outport. [0]\n"
		"-dac_comp <enable>: enable or disable DAC compensation on the component output, disable: 0, enable: 1 [0]\n"
		"-dis_pix_timer: disable timer-based pixel clock correction (enabled by default, on SMP8634 only)\n"
		"-filter_gpio <gpio> <num> <value>: Sets the <value> on <num> GPIO pins, starting at GPIO <gpio> (LSB first)\n"
		);
	return RM_OK;
}

		



// Turn on panel with GPIO 14 (Board dependent, might need to be changed!)
static RMstatus enable_lvds_panel(struct RUA *pRUA)
{
	RMstatus err;
	struct SystemBlock_GPIO_type gpio;
	
	gpio.Bit = GPIOId_Sys_14;
	gpio.Data = TRUE;
	err = RUASetProperty(pRUA, SystemBlock, RMSystemBlockPropertyID_GPIO, &gpio, sizeof(gpio), 0);
	
	return err;
}

static RMstatus setup_dvi_chip(struct RUA *pRUA, struct outport_config *config, struct dh_context *dh_info)
{
	RMstatus err;
	
	if ((dh_info->dvi_hdmi_part == DH_no_chip) || (dh_info->dvi_hdmi_part == DH_lvds)) {
		if (dh_info->pDH) {
			DHDone(dh_info->pDH);
			dh_info->pDH = NULL;
		}
		if (dh_info->dvi_hdmi_part == DH_lvds) {
			return enable_lvds_panel(pRUA);
		} else {
			return RM_OK;
		}
	}
	
	if (dh_info->pDH == NULL) {
		RMDBGPRINT((DHDBG, "+++++++++++++++++++++++++++++++++++++   outports_options: Opening new DVI/HDMI handle\n"));
		err = DHOpenChip(pRUA, dh_info->dvi_hdmi_part, 
			(dh_info->dvi_hdmi_part == DH_auto_detect),  // reset before auto-detect
			config->dvi_reset_gpio, 
			config->i2c_module, GPIOId_Sys_0, GPIOId_Sys_1, config->i2c_speed, 
			config->i2c_module, 
			config->i2c_ddc_on_tx ? GPIOId_Sys_0 : GPIOId_Sys_2, 
			config->i2c_ddc_on_tx ? GPIOId_Sys_1 : GPIOId_Sys_3, 
			config->i2c_speed, 
			&(dh_info->pDH));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot connect to DVI/HDMI chip!!!!\n"));
			return err;
		}
		dh_info->dvi_hdmi_state = DH_disabled;
		RMDBGLOG((DHDBG, "DCC-HDCP State is now: DISABLED\n"));
		
		DHSetDDRMode(dh_info->pDH, config->dig_ddr);
	} else {
		err = DHGetState(dh_info->pDH, 
			&(dh_info->dvi_hdmi_state), 
			&(dh_info->dvi_hdmi_cable));
	}
	
	return err;
}

static RMstatus fill_avi_info_frame(struct RUA *pRUA, 
				    struct outport_config *config, 
				    struct dh_context *dh_info, 
				    struct DH_AVIInfoFrame *pAVIInfoFrame)
{
	struct DH_VideoFormatInfo video_format_info;
	struct EMhwlibTVFormatDigital fmt_d;

	video_format_info.VIC = 0;
	DHGetVideoFormatInfo(config->standard, config->ar_x, config->ar_y, &video_format_info);
	
	RUAExchangeProperty(pRUA, DisplayBlock, 
			    RMDisplayBlockPropertyID_TVFormatDigital, 
			    &(config->standard), sizeof(config->standard), 
			    &fmt_d, sizeof(fmt_d));
	
	pAVIInfoFrame->Version = 0x02;
	pAVIInfoFrame->color_space = config->color_space;
	pAVIInfoFrame->sampling = (config->bus_size == 16) ? EMhwlibSamplingMode_422 : EMhwlibSamplingMode_444;
	pAVIInfoFrame->scan_info = 
		(config->hdmi_scan == EMhwlibScanInfo_Underscanned) ? DH_underscanned : 
		(config->hdmi_scan == EMhwlibScanInfo_Overscanned) ? DH_overscanned : 
		DH_scan_undefined;
	pAVIInfoFrame->aspect_ratio.X = config->ar_x;
	pAVIInfoFrame->aspect_ratio.Y = config->ar_y;
	pAVIInfoFrame->active_format_valid = config->use_active_format;
	pAVIInfoFrame->active_aspect_ratio = config->hdmi_active_format;
	pAVIInfoFrame->non_linear_scaling.Width = 0; /* FIXME */
	pAVIInfoFrame->non_linear_scaling.Level = 0; /* FIXME */
	pAVIInfoFrame->pixel_repetition = video_format_info.pixel_rep;
	pAVIInfoFrame->VIC = video_format_info.VIC;
	pAVIInfoFrame->info_bars = 
		(((config->hdmi_bar_top != 0) || (config->hdmi_bar_bottom != 4096)) ? DH_horiz_bar_info_valid : 0) | 
		(((config->hdmi_bar_left != 0) || (config->hdmi_bar_right != 4096)) ? DH_vert_bar_info_valid : 0);
	pAVIInfoFrame->end_top_bar_line_num = config->hdmi_bar_top * fmt_d.ActiveHeight / 4096;
	pAVIInfoFrame->start_bottom_bar_line_num = config->hdmi_bar_bottom * fmt_d.ActiveHeight / 4096 + 1;
	pAVIInfoFrame->end_left_bar_pixel_num = config->hdmi_bar_left * fmt_d.ActiveWidth / 4096;
	pAVIInfoFrame->start_right_bar_pixel_num = config->hdmi_bar_right * fmt_d.ActiveWidth / 4096 + 1;
	if (pAVIInfoFrame->info_bars) {
		RMDBGLOG((ENABLE, "Bars inside %lu*%lu frame (%lu:%lu): Hor.Bars to %lu, from %lu. Vert.Bars to %lu, from %lu\n", 
			fmt_d.ActiveWidth, fmt_d.ActiveHeight, 
			pAVIInfoFrame->aspect_ratio.X, pAVIInfoFrame->aspect_ratio.Y, 
			pAVIInfoFrame->end_top_bar_line_num, pAVIInfoFrame->start_bottom_bar_line_num, 
			pAVIInfoFrame->end_left_bar_pixel_num, pAVIInfoFrame->start_right_bar_pixel_num));
	} else // info bars have precedence over active format
	if (pAVIInfoFrame->active_format_valid) {
		RMDBGLOG((ENABLE, "Active format inside %lu*%lu frame (%lu:%lu): %s\n", 
			fmt_d.ActiveWidth, fmt_d.ActiveHeight, 
			pAVIInfoFrame->aspect_ratio.X, pAVIInfoFrame->aspect_ratio.Y, 
			(pAVIInfoFrame->active_aspect_ratio == DH_af_16x9_top) ? "16:9 content: at top of 4:3 frame, fills up 16:9 frame" : 
			(pAVIInfoFrame->active_aspect_ratio == DH_af_14x9_top) ? "14:9 content: at top of 4:3 frame, centered on 16:9 frame" : 
			(pAVIInfoFrame->active_aspect_ratio == DH_af_64x27_centered) ? "Cinemascope widesceeen (2.35:1, 64:27) content: centered on 4:3 or 16:9 frame" : 
			(pAVIInfoFrame->active_aspect_ratio == DH_af_same_as_picture) ? "content fills up frame" : 
			(pAVIInfoFrame->active_aspect_ratio == DH_af_4x3_centered) ? "4:3 content: fills up 4:3 frame, centered on 16:9 frame" : 
			(pAVIInfoFrame->active_aspect_ratio == DH_af_16x9_centered) ? "16:9 content: centered on 4:3 frame, fills up 16:9 frame" : 
			(pAVIInfoFrame->active_aspect_ratio == DH_af_14x9_centered) ? "14:9 content: centered on 4:3 frame, centered on 16:9 frame" : 
			(pAVIInfoFrame->active_aspect_ratio == DH_af_4x3_centered_prot_14x9) ? "4:3 content with essential content in 14:9 centered portion" : 
			(pAVIInfoFrame->active_aspect_ratio == DH_af_16x9_centered_prot_14x9) ? "16:9 content with essential content in 14:9 centered portion" : 
			(pAVIInfoFrame->active_aspect_ratio == DH_af_16x9_centered_prot_4x3) ? "16:9 content with essential content in 4:3 centered portion" : 
			"unknown format code!"));
	}
	
	return RM_OK;
}

static RMstatus apply_outport_hdcp(struct outport_config *config, struct dh_context *dh_info) 
{
	RMstatus err;
	
	// experimental SRMs
	static RMuint8 SRM0[] = {
		0x80, 0x00, 0x00, 0x02,  // version
		0x00, 0x00, 0x00, 0x31,  // length
		0x01,  // number of keys
		0x86, 0x88, 0x4d, 0x5d, 0x9f,  // key of Sony Wega KV-30HS420
		// invalid DSS signature
		0xe3, 0x17, 0xe6, 0x46, 0x6e, 0xc3, 0xef, 0xbd, 
		0x4c, 0xca, 0x0d, 0x4f, 0x76, 0x2a, 0x15, 0x96, 
		0xce, 0x62, 0x22, 0x2b, 0xe5, 0xc9, 0xa3, 0x72, 
		0xef, 0x26, 0x76, 0xcf, 0x30, 0x50, 0x4e, 0x55, 
		0x59, 0x9e, 0x79, 0xc3, 0x36, 0xe1, 0xaa, 0xfd, 
	};
	static RMuint8 SRM1[] = {
		0x80, 0x00, 0x00, 0x01,  // version
		0x00, 0x00, 0x00, 0x2b,  // length
		// no keys
		// "DCP LLC" production DSS signature
		0xd2, 0x48, 0x9e, 0x49, 0xd0, 0x57, 0xae, 0x31, 
		0x5b, 0x1a, 0xbc, 0xe0, 0x0e, 0x4f, 0x6b, 0x92, 
		0xa6, 0xba, 0x03, 0x3b, 0x98, 0xcc, 0xed, 0x4a, 
		0x97, 0x8f, 0x5d, 0xd2, 0x27, 0x29, 0x25, 0x19, 
		0xa5, 0xd5, 0xf0, 0x5d, 0x5e, 0x56, 0x3d, 0x0e 
	};
	static RMuint8 SRM2[] = {
		0x80, 0x00, 0x00, 0x02,  // version
		0x00, 0x00, 0x00, 0x31,  // length
		0x01,  // number of keys
		0x51, 0x1e, 0xf2, 0x1a, 0xcd,  // key
		// "facsimile" DSS signature
		0xe3, 0x17, 0xe6, 0x46, 0x6e, 0xc3, 0xef, 0xbd, 
		0x4c, 0xca, 0x0d, 0x4f, 0x76, 0x2a, 0x15, 0x96, 
		0xce, 0x62, 0x22, 0x2b, 0xe5, 0xc9, 0xa3, 0x72, 
		0xef, 0x26, 0x76, 0xcf, 0x30, 0x50, 0x4e, 0x55, 
		0x59, 0x9e, 0x79, 0xc3, 0x36, 0xe1, 0xaa, 0xfd, 
	};
	static RMuint8 SRM3[] = {
		0x80, 0x00, 0x00, 0x03,  // version
		0x00, 0x00, 0x00, 0x31,  // length
		0x01,  // number of keys
		0xe7, 0x26, 0x97, 0xf4, 0x01,  // key
		// "facsimile" DSS signature
		0xdd, 0x1f, 0x00, 0x30, 0x37, 0x0d, 0x0b, 0x54, 
		0xff, 0x91, 0x02, 0xbb, 0x07, 0x9e, 0x48, 0x3c, 
		0xfe, 0x58, 0x9b, 0xfc, 0x74, 0x57, 0xb7, 0x25, 
		0x67, 0xdd, 0x72, 0xc2, 0x55, 0xe4, 0x1a, 0xed, 
		0x99, 0x09, 0x47, 0xb8, 0x24, 0x21, 0x85, 0xcc, 
	};
	static RMuint8 SRM4[] = {
		0x80, 0x00, 0x00, 0x04,  // version
		0x00, 0x00, 0x00, 0x36,  // length
		0x02,  // number of keys
		0x51, 0x1e, 0xf2, 0x1a, 0xcd,  // key
		0xe7, 0x26, 0x97, 0xf4, 0x01,  // key
		// "facsimile" DSS signature
		0x7a, 0xdf, 0x4f, 0xd5, 0x66, 0xe0, 0x19, 0xeb, 
		0x4e, 0xd3, 0xe0, 0x1c, 0x1a, 0xb3, 0xc2, 0x8d, 
		0xec, 0x8b, 0xe8, 0x7f, 0x9d, 0xc0, 0x01, 0x2d, 
		0x1b, 0xda, 0xc8, 0x30, 0xd8, 0x30, 0x05, 0xa0, 
		0x66, 0x1d, 0x2d, 0x26, 0x25, 0x0d, 0x20, 0x66, 
	};
	
	if (dh_info->pSRM == NULL) {
		// Application needs to provide real SRM from DVD:/HDCP.SRM or BluRay:/HDCP.srm
		fprintf(stderr, "outports_options.c: Application did not specify HDCP SRM, providing empty SRM!\n");
		if (0) dh_info->pSRM = SRM0;
		if (1) dh_info->pSRM = SRM1;
		if (0) dh_info->pSRM = SRM2;
		if (0) dh_info->pSRM = SRM3;
		if (0) dh_info->pSRM = SRM4;
	}
	
	err = DHSetSRM(dh_info->pDH, dh_info->pSRM);
	
	if (config->dvi_hdmi_hdcp) {
		err = DHRequestHDCP(dh_info->pDH);
		if (RMSUCCEEDED(err)) {
			if (dh_info->dvi_hdmi_state != DH_enabled_encrypted) {
				RMDBGPRINT((ENABLE, "HDCP encrytion established, OK to play protected content!\n"));
				dh_info->dvi_hdmi_state = DH_enabled_encrypted;
				RMDBGLOG((ENABLE, "DCC-HDCP State is now: ENABLED-ENCRYPTED\n"));
			}
		} else {
			if (dh_info->dvi_hdmi_state != DH_enabled) {
				RMDBGPRINT((ENABLE, "Initial HDCP encrytion failed, can NOT yet play protected content!\n"));
				dh_info->dvi_hdmi_state = DH_enabled;
				RMDBGLOG((ENABLE, "DCC-HDCP State is now: ENABLED\n"));
			}
		}
	} else {
		err = DHCancelHDCP(dh_info->pDH);
	}
	
	return RM_OK;
}

static RMstatus apply_dvi_hdmi(struct RUA *pRUA, struct outport_config *config, struct dh_context *dh_info, RMbool DoubleRate)
{
	RMstatus err;
	
	dh_info->dvi_hdmi_part = config->dvi_hdmi_part;   /* FIXME */
	dh_info->dvi_hdmi_state = config->dvi_hdmi_state; /* FIXME */

	err = setup_dvi_chip(pRUA, config, dh_info);
	if (RMFAILED(err)){
		fprintf(stderr, "setup_dvi_chip failed\n");
		return err;
	}
	if (! dh_info->pDH) return RM_OK;  // nothing further to do
	
	err = DHSetTMDSMode(dh_info->pDH, 
		config->tmds_gpio,
		config->tmds_threshold * 1000000);
	
	// determine HDMI mode from display
	if (! config->hdmi_force) {
		RMDBGLOG((DHDBG, "NOT forcing HDMI\n"));
		err = DHGetHDMIModeFromEDID(dh_info->pDH, &(config->hdmi_monitor));
	}
	
	// let HDMI know about the current digital video mode
	{
		struct EMhwlibTVFormatDigital format_digital;
		RMbool EnableVVLDPAD;
		
		if (config->digital_protocol != EMhwlibDigitalTimingSignal_601) {
			config->hdmi_de = FALSE;
			EnableVVLDPAD = FALSE;
		} else {
			EnableVVLDPAD = TRUE;
		}
		
		DCCSPERR(pRUA, DispDigitalOut, RMDispDigitalOutPropertyID_EnableVVLDPAD, &EnableVVLDPAD, sizeof(EnableVVLDPAD), "Cannot set EnableVVLDPAD on DispDigitalOut output");
		DCCSPERR(pRUA, DispDigitalOut, RMGenericPropertyID_Validate, NULL, 0, "Can not Validate DispDigitalOut output");
		
		if (config->standard != EMhwlibTVStandard_Custom) {
			// get generic TVFormat struct for the current TVStandard
			err = RUAExchangeProperty(pRUA, DisplayBlock, 
				RMDisplayBlockPropertyID_TVFormatDigital, 
				&(config->standard), sizeof(config->standard), 
				&format_digital, sizeof(format_digital));
		} else {
			// get actual TVFormat from digital output
			err = RUAGetProperty(pRUA, DispDigitalOut, 
				RMGenericPropertyID_DigitalTVFormat, 
				&format_digital, sizeof(format_digital));
		}
		
		if (DoubleRate) format_digital.PixelClock *= 2;
		
		DHSetDEGeneratorFromTVFormat(dh_info->pDH, config->hdmi_de, config->digital_protocol != EMhwlibDigitalTimingSignal_601, config->bus_size == 8, &format_digital);
	}
	
	if (config->hdmi_monitor) {
		RMDBGLOG((DHDBG, "Monitor is HDMI\n"));
	} else {
		RMDBGLOG((DHDBG, "Monitor is DVI / VGA\n"));
	}
	err = DHSetHDMIMode(dh_info->pDH, config->hdmi_monitor);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Chipset does not support HDMI, defaulting to DVI\n"));
		config->hdmi_monitor = FALSE;
	}
	
	err = DHEnableOutput(dh_info->pDH);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot enable DVI/HDMI chip!!!!\n"));
	}
	if (config->dvi_hdmi_hdcp) {
		err = DHMuteOutput(dh_info->pDH, TRUE);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot mute DVI/HDMI output!!!!\n"));
		}
	}
	dh_info->dvi_hdmi_state = DH_enabled;
	RMDBGLOG((ENABLE, "DCC-HDCP State is now: ENABLED\n"));
	
	// Default setup: 24 bit video, no conversion inside HDMI chip
	err = DHSetConversionVideoFormat(dh_info->pDH, 
		config->color_space, EMhwlibSamplingMode_444, 8, 
		config->color_space, EMhwlibSamplingMode_444, 8);
	
	/* set up HDMI info frames */
	if (config->hdmi_monitor) {
		struct DH_AVIInfoFrame AVIInfoFrame;
		fill_avi_info_frame(pRUA, config, dh_info, &AVIInfoFrame);
		err = DHEnableAVIInfoFrame(dh_info->pDH, &AVIInfoFrame);
		if (RMFAILED(err)){
			fprintf(stderr, "HDMI Error, can not send AVI info frames!\n");
			return err;
		}
		if (config->hdmi_spd_vendor && config->hdmi_spd_product) {
			struct DH_SPDInfoFrame SPDInfoFrame;
			
			SPDInfoFrame.Version = 0x01;
			SPDInfoFrame.VendorName = config->hdmi_spd_vendor;
			SPDInfoFrame.ProductDescription = config->hdmi_spd_product;
			SPDInfoFrame.SDI = config->hdmi_spd_class;
			DHEnableSPDInfoFrame(config->dh_info->pDH, &SPDInfoFrame, 0);
		}
	} else { /* DVI mode */
		RMDBGLOG((DHDBG, "No HDMI monitor, can not send AVI info frames!\n"));
	}

	/* Prepare HDCP (content protection) */
	err = apply_outport_hdcp(config, dh_info);
	if (RMFAILED(err)){
		fprintf(stderr, "Error preparing HDCP content protection\n");
		return err;
	}
	
	return RM_OK;
}


static RMstatus set_up_pads(struct RUA *pRUA, RMuint32 module_id, struct outport_config *config)
{
	RMbool DVI = 
		(config->dvi_hdmi_part == DH_auto_detect) || 
		((config->dvi_hdmi_part >= DH_siI164) && (config->dvi_hdmi_part < DH_reserved));
	
#ifdef RMFEATURE_HAS_HDMI
	{  // enable/disable tango2 internal SiI9030
		RMstatus err = RM_OK;
		struct DisplayBlock_HDMIConfig_type hc;
		
		hc.ClkDiv = FALSE;
		hc.AudioClkInv = TRUE;
		if (DVI && (config->i2c_module == 2)) {
			hc.PowerUpPhy = TRUE;
			hc.OutputSelect = TRUE;
			// force DDR on digital pads when using internal SiI9030
			config->dig_ddr = TRUE;
		} else {
			hc.PowerUpPhy = FALSE;
			hc.OutputSelect = FALSE;
		}
		if (RMFAILED(err = RUASetProperty(pRUA, 
			DisplayBlock, RMDisplayBlockPropertyID_HDMIConfig, 
			&hc, sizeof(hc), 0))) {
			fprintf(stderr, "Error setting internal HDMI config! %s\n", RMstatusToString(err));
			return err;
		}
		
		// force DDR when using internal SiI9030
		if (config->i2c_module == 2) {
			config->dig_ddr = TRUE;
			if (! config->dig_force_delay) 
				config->dig_delay = 2300;
		}
	}
#endif
	
	if (DVI) {
		if (config->dig_ddr) {
			// set DDR delay 2 on HDMI when in DDR mode
			if (! config->dig_force_delay) config->dig_delay = 2300;
		} else {
			// set -dig_no_delay on HDMI when not in DDR mode
			if (! config->dig_force_delay) config->dig_delay = 0;
		}
	} else {
		if (! config->dig_ddr && ! config->dig_force_delay) config->dig_delay = 400;
	}
	
	{  // set up Digital Out Pads
		struct DispDigitalOut_PadsControl_type pads;
		RMMemset(&pads, 0, sizeof(pads));
		pads.APIVersion = 1;
		pads.ModifyInvertClock = TRUE;
		pads.InvertClock = ! config->dig_clk_normal;
		pads.ModifyDDRdout = TRUE;
		pads.DDRdout = config->dig_ddr;
		pads.ModifyInvertCaptureClock = TRUE;
		pads.InvertCaptureClock = config->dig_inv_cap_clk;
		pads.ModifyDelay = TRUE;
		pads.Delay = config->dig_delay;
		DCCSPERR(pRUA, DispDigitalOut, RMDispDigitalOutPropertyID_PadsControl, &pads, sizeof(pads), "Can not set PadsControl");
	}
	
	return RM_OK;
}



static RMstatus setup_scart(struct RUA *pRUA, RMuint32 module_id, struct outport_config *config)
{
	struct EMhwlibSCARTConfig conf;
	enum EMhwlibSCARTWideBitState wide_state;
	RMbool enable;

	if (config->scart_en_pio) {
		if (config->scart_ws_pio & 0x200) {
			wide_state = (config->scart_widescreen) ? EMhwlibSCARTWideState_16_9 : EMhwlibSCARTWideState_4_3;
		} else {
			wide_state = EMhwlibSCARTWideState_Auto;
		}
		
		enable = config->scart_enable;
		conf.EnableBit = (config->scart_en_pio & 0xFF) - 1;
		conf.EnableInvert = (config->scart_en_pio & 0x100) ? TRUE : FALSE;
		conf.WideBit = (config->scart_ws_pio & 0xFF) ? ((config->scart_ws_pio & 0xFF) - 1) : (config->scart_en_pio & 0xFF);
		conf.WideInvert = (config->scart_ws_pio & 0xFF) ? ((config->scart_ws_pio & 0x100) ? TRUE : FALSE) : FALSE;
	} else {
		/* if (config->connector == DCCVideoConnector_SCART) { */
			
/* 			DCCSetSCART(dcc_info->pDCC, dcc_info->route, config->connector,  */
/* 				TRUE, SCART_ENABLE_GPIO, FALSE, SCART_WIDESCREEN_GPIO, FALSE, EMhwlibSCARTWideState_Auto); */
/* 		} else  */{

			wide_state = EMhwlibSCARTWideState_Auto;
			enable = FALSE;
			conf.EnableBit = 0;
			conf.EnableInvert = FALSE;
			conf.WideBit = 0; 
			conf.WideInvert = FALSE;
		}
	}
	DCCSP(pRUA, module_id, RMGenericPropertyID_SCARTConfig, &conf, sizeof(conf));
	DCCSP(pRUA, module_id, RMGenericPropertyID_SCARTWideScreen, &wide_state, sizeof(wide_state));
	DCCSP(pRUA, module_id, RMGenericPropertyID_SCART, &(enable), sizeof(enable));
	return RM_OK;
}


static RMstatus setup_outport_config(struct RUA *pRUA, RMuint32 module_id, struct outport_config *config, struct global_config *global_config)
{
	RMstatus err;
	

	if(0){ /* i'm not sure when we have to do this */
		err = setup_scart(pRUA, module_id, config);
		if (RMFAILED(err))
			return err;
	}
	if(global_config->do_cs){
#ifdef RMFEATURE_HAS_DUAL_MAINANALOGOUT
		if(module_id == DispMainAnalogOut){
			DCCSP(pRUA, module_id, RMDispMainAnalogOutPropertyID_ColorSpaceCVBS, &(config->color_space), sizeof(config->color_space));
		}
#endif // RMFEATURE_HAS_DUAL_MAINANALOGOUT
		DCCSP(pRUA, module_id, RMGenericPropertyID_ColorSpace, &(config->color_space), sizeof(config->color_space));
	}

		
	if (module_id != DispCompositeOut) {
		DCCSPERR(pRUA, module_id, RMGenericPropertyID_ComponentOrder, &(config->component_order), sizeof(config->component_order), "Cannot set the component order");
	}
	
	if (module_id != DispDigitalOut) {

		enum EMhwlibCCEnable cc_enable = CC_DisableTopBottom;
		/* VGA requires that we enable digital timing pins via the DispDigitalOutput module */
		if(config->use_digital_timing){
			RMbool enable = TRUE;
			DCCSP(pRUA, DispDigitalOut, RMDispDigitalOutPropertyID_SyncControlModuleID, &module_id, sizeof(module_id));
			DCCSP(pRUA, DispDigitalOut, RMDispDigitalOutPropertyID_EnableSyncPAD, &enable, sizeof(enable));
			DCCSP(pRUA, DispDigitalOut, RMGenericPropertyID_Validate, NULL, 0);
			DCCSP(pRUA, DispDigitalOut, RMGenericPropertyID_Enable, &enable, sizeof(enable));
		}
		if (global_config->do_cp) {
			struct EMhwlibCopyControlWithVersion cciset;
			
			cciset.cci_version = EMhwlibCopyControlVersion_0;
			cciset.cci.agc_version = config->agc_version;
			cciset.cci.agc_level = config->agc_level;
			cciset.cci.aps_level = config->aps_level;
			cciset.cci.cgmsa = config->cgmsa;
			cciset.cci.rcd = config->rcd;
			cciset.cci.asb = config->asb;
			
			RMDBGLOG((ENABLE, "set agc=%d aps=%d cgmsa=%d rcd=%d asb=%d\n",
				config->agc_level, config->aps_level, config->cgmsa, config->rcd, config->asb));
			DCCSPERR(pRUA, module_id, RMGenericPropertyID_CopyControl, &(cciset), sizeof(cciset), "Cannot set CopyControl");
		}
		/* disable closed caption on formats other than NTSC */
		if(config->standard == EMhwlibTVStandard_NTSC_M){
			cc_enable = CC_EnableTopBottom;
		}
		DCCSPERR(pRUA, module_id, RMGenericPropertyID_ClosedCaption, &(cc_enable), sizeof(cc_enable), "Cannot set closed caption");

		if (config->afd_used) {
			struct EMhwlibActiveFormatDescription output_afd;
			
			output_afd.FrameAspectRatio.X = config->ar_x;
			output_afd.FrameAspectRatio.Y = config->ar_y;
			output_afd.ActiveFormat = config->active_format;
			output_afd.ActiveFormatValid = config->active_format_valid;
			apply_active_format_output_module(pRUA, module_id, 
				(config->dh_info) ? config->dh_info->pDH : NULL, 
				output_afd);
		} else if (config->wss_used) {
			DCCSPERR(pRUA, module_id, RMGenericPropertyID_CGMSWSS_625, &(config->wss_625), sizeof(config->wss_625), "Cannot set wss 625");
			DCCSPERR(pRUA, module_id, RMGenericPropertyID_CGMSWSS_525, &(config->wss_525), sizeof(config->wss_525), "Cannot set wss 525");
		}
	}

	{  // apply disable_pixel_timer, only if necessary
		RMbool PixelClockVCXOTimer;
		err = RUAGetProperty(pRUA, module_id, RMGenericPropertyID_PixelClockVCXOTimer, &PixelClockVCXOTimer, sizeof(PixelClockVCXOTimer));
		if (config->disable_pixel_timer == PixelClockVCXOTimer) {
			PixelClockVCXOTimer = ! config->disable_pixel_timer;
			DCCSPERR(pRUA, module_id, RMGenericPropertyID_PixelClockVCXOTimer, &PixelClockVCXOTimer, sizeof(PixelClockVCXOTimer), "Cannot set PixelClockVCXOTimer");
		}
	}
	
	if ((module_id == DispMainAnalogOut) || (module_id == DispComponentOut)) {
		if (config->force_DACCompDisable) {
			DCCSPERR(pRUA, module_id, RMGenericPropertyID_DACCompDisable, &(config->DACCompDisable), sizeof(config->DACCompDisable), "Cannot set property DACCompDisable");
		}
		DCCSPERR(pRUA, module_id, RMGenericPropertyID_SyncOnPbPr, &(config->chroma_sync), sizeof(config->chroma_sync), "Cannot set property SyncOnPbPr");
	}
	
	if(module_id == DispDigitalOut){
		/* 
		 *WARNING: THESE PROPERTIES ARE SET EVERY TIME THE DIGITAL OUTPORT IS ENABLED 
		 * AND DO NOT DEPEND ON THE INPUT PARAMETERS!
		 */
		RMbool clipping, enable;
		enum DispDigitalOut_ClippingLevel_type level;

		err = set_up_pads(pRUA, module_id, config);
		if (RMFAILED(err))
			return err;

		clipping = FALSE;
		level = DispDigitalOut_ClippingLevel_Clip_1_254;
		enable = TRUE;

		DCCSP(pRUA, module_id, RMDispDigitalOutPropertyID_EnableClipping, &clipping, sizeof(clipping));
		DCCSP(pRUA, module_id, RMDispDigitalOutPropertyID_ClippingLevel, &level, sizeof(level));
		DCCSP(pRUA, module_id, RMDispDigitalOutPropertyID_ColorOrder, &(config->color_order), sizeof(config->color_order));
		DCCSP(pRUA, module_id, RMDispDigitalOutPropertyID_TimingSignal, &(config->digital_protocol), sizeof(config->digital_protocol));
		DCCSP(pRUA, module_id, RMDispDigitalOutPropertyID_BusSize, &(config->bus_size), sizeof(config->bus_size));
		DCCSP(pRUA, module_id, RMDispDigitalOutPropertyID_VSyncDelay1PixClk, &(config->dig_vsync_delay), sizeof(config->dig_vsync_delay));
		DCCSP(pRUA, module_id, RMDispDigitalOutPropertyID_TrailingEdge, &(config->dig_trailing_edge), sizeof(config->dig_trailing_edge));
		DCCSP(pRUA, module_id, RMDispDigitalOutPropertyID_SyncControlModuleID, &module_id, sizeof(module_id));
		DCCSP(pRUA, module_id, RMDispDigitalOutPropertyID_EnableSyncPAD, &enable, sizeof(enable));
	}

	return RM_OK;
}
static RMstatus setup_aspect_ratio(struct RUA *pRUA, RMuint32 mixer_id, struct outport_config *config)
{
	struct EMhwlibAspectRatio dar;

	if ((mixer_id != DispColorBars) && (mixer_id > 0)) {
		dar.X = config->ar_x;
		dar.Y = config->ar_y;	
		RMDBGLOG((ENABLE, "ASP: setting %ld %ld on module id %ld\n", dar.X, dar.Y, mixer_id));
		DCCSP(pRUA, mixer_id, RMGenericPropertyID_DisplayAspectRatio, &dar, sizeof(dar));
		DCCSP(pRUA, mixer_id, RMGenericPropertyID_Validate, NULL, 0);
	}

	return RM_OK;
}



static RMstatus parse_color_space(RMascii *arg, enum EMhwlibColorSpace *pColorSpace)
{
	RMstatus err = RM_OK;
	
	if (RMCompareAsciiCaseInsensitively(arg, "none")) {
		*pColorSpace = EMhwlibColorSpace_None;
	// backwards compatibility
	} else if (RMCompareAscii(arg, "yuv_601")) {
		*pColorSpace = EMhwlibColorSpace_YUV_601;
	} else if (RMCompareAscii(arg, "yuv_709")) {
		*pColorSpace = EMhwlibColorSpace_YUV_709;
	} else if (RMCompareAscii(arg, "xv_601")) {
		*pColorSpace = EMhwlibColorSpace_xvYCC_601;
	} else if (RMCompareAscii(arg, "xv_709")) {
		*pColorSpace = EMhwlibColorSpace_xvYCC_709;
	} else if (RMCompareAscii(arg, "rgb_0_255")) {
		*pColorSpace = EMhwlibColorSpace_RGB_0_255;
	} else if (RMCompareAscii(arg, "rgb_16_235")) {
		*pColorSpace = EMhwlibColorSpace_RGB_16_235;
	// new notation
	} else if (RMCompareAsciiCaseInsensitively(arg, "YCC601")) {
		*pColorSpace = EMhwlibColorSpace_YUV_601;
	} else if (RMCompareAsciiCaseInsensitively(arg, "YCC601f")) {
		*pColorSpace = EMhwlibColorSpace_YUV_601_0_255;
	} else if (RMCompareAsciiCaseInsensitively(arg, "YCC709")) {
		*pColorSpace = EMhwlibColorSpace_YUV_709;
	} else if (RMCompareAsciiCaseInsensitively(arg, "YCC709f")) {
		*pColorSpace = EMhwlibColorSpace_YUV_709_0_255;
	} else if (RMCompareAsciiCaseInsensitively(arg, "xvYCC601")) {
		*pColorSpace = EMhwlibColorSpace_xvYCC_601;
	} else if (RMCompareAsciiCaseInsensitively(arg, "xvYCC601f")) {
		*pColorSpace = EMhwlibColorSpace_xvYCC_601_0_255;
	} else if (RMCompareAsciiCaseInsensitively(arg, "xvYCC709")) {
		*pColorSpace = EMhwlibColorSpace_xvYCC_709;
	} else if (RMCompareAsciiCaseInsensitively(arg, "xvYCC709f")) {
		*pColorSpace = EMhwlibColorSpace_xvYCC_709_0_255;
	} else if (RMCompareAsciiCaseInsensitively(arg, "RGB")) {
		*pColorSpace = EMhwlibColorSpace_RGB_0_255;
	} else if (RMCompareAsciiCaseInsensitively(arg, "RGBl")) {
		*pColorSpace = EMhwlibColorSpace_RGB_16_235;
	} else {
		err = RM_ERROR;
	}
	
	return err;
}

#ifdef RMFEATURE_HAS_DUAL_MAINANALOGOUT
static RMstatus compare_analog_component(struct outport_config *analog, struct outport_config *component)
{

	/* 
	   TODO:
	   Some checks are missing here.
	   The effect of this is that some invalid (on the chip this was compiled for) commandlines 
	   will not make set_ouports fail.
	   In those cases, set_outports will set a valid configuration, which may differ
	   from what the caller requested.
	*/
	
	if(analog->route != component->route){
		fprintf(stderr, "Analog and Component must have the same route\n");
		return RM_ERROR;
	}

	if(analog->standard != component->standard){
		fprintf(stderr, "Analog and Component must have the same standard\n");
		return RM_ERROR;
	}

	if(analog->flags != component->flags){
		fprintf(stderr, "Analog and Component must have the same parameters\n");
		return RM_ERROR;
	}


	return RM_OK;

}
#endif

/* this funtion parses the strings on argv[] array until it's finished (RM_OK) 
 * or until it finds an argument it cannot recognize (RM_PENDING)
 * or until it finds an option it recongnizes but with bad syntax (RM_ERROR)
 */

RMstatus parse_outports_options(RMuint32 argc, RMascii *argv[], RMuint32 *index, struct outports_options *options)
{               
	RMstatus err = RM_OK;
	RMuint32 i = *index;
	struct outport_config *active_outport = NULL;

	/* active_outports = 4;  don't allow global options */
	while((err == RM_OK) && (i<argc)){
		err = RM_PENDING;
		if (RMCompareAscii(argv[i], "-digital")) {
			active_outport = &options->digital;
			active_outport->action = DCCOutportState_Enable;
			i++;
			err = RM_OK;
		}
		else if (RMCompareAscii(argv[i], "-component")) {
			active_outport = &options->component;
			active_outport->action = DCCOutportState_Enable;
			i++;
			err = RM_OK;
		}
		else if (RMCompareAscii(argv[i], "-analog")) {
			active_outport = &options->analog;
			active_outport->action = DCCOutportState_Enable;
			i++;
			err = RM_OK;
		}
		else if (RMCompareAscii(argv[i], "-composite")) {
			active_outport = &options->composite;
			active_outport->action = DCCOutportState_Enable;
			i++;
			err = RM_OK;
		}
		else if(RMCompareAscii(argv[i], "-help")){
			print_outports_options();
			i++;
		}
		else if(RMCompareAscii(argv[i], "-keep")){
			active_outport->action = DCCOutportState_Keep;
			i++;
			err = RM_OK;
		}
		else if(RMCompareAscii(argv[i], "-disable")){
			active_outport->action = DCCOutportState_Disable;
			i++;
			err = RM_OK;
		}
		else if (RMCompareAscii(argv[i], "-f")) {
			if (argc > i+1) { 
				enum EMhwlibTVStandard standard;
				if(RMCompareAscii(argv[i+1], "list")){
					fprintf(stdout, "\n\nKnown standards (to use with -f option) are:\n\n");
					PrintTVStandardNames();
				}
				else{
					err = GetTVStandard(argv[i+1], &(standard));
					active_outport->standard = standard;
				}
				i += 2;
			}
			else 
				err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-cit")) {
			active_outport->flags |= DCC_OUTPORT_FLAG_CONSTRAINED;
			i ++;
			err = RM_OK;
		}		
		else if (RMCompareAscii(argv[i], "-digital_timing")) {
			active_outport->use_digital_timing = TRUE;
			i++;
			err = RM_OK;
		}
		else if (RMCompareAscii(argv[i], "-vmf")) {
			if (argc > i+1) { 
				strncpy(active_outport->vidmode_filename, argv[i + 1], 2048);
				active_outport->vidmode_filename[2047] = '\0';
				active_outport->standard = EMhwlibTVStandard_Custom;
				err = RM_OK;
				i += 2;
			}
			else 
				err = RM_ERROR;
		
		}
		else if (RMCompareAscii(argv[i], "-cs")) {
			if (argc > i+1) {
				err = parse_color_space(argv[i + 1], &(active_outport->color_space));
				if (active_outport->color_space == EMhwlibColorSpace_None) err = RM_ERROR;
				i += 2;
			}
			else
				err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-route")) {
			i++;
			if (argc > i) {
				err = RM_OK;
				if(RMCompareAscii(argv[i], "main")) {
					active_outport->route = DCCRoute_Main;
					i++;
				}
#ifdef RMFEATURE_HAS_VCR_CHANNEL
				else if(RMCompareAscii(argv[i], "vcr")) {
					active_outport->route = DCCRoute_Secondary;
					i++;
				}
#endif
				else if(RMCompareAscii(argv[i], "colorbars")) {
					active_outport->route = DCCRoute_ColorBars;
					i++;
				}
				else
					err = RM_ERROR;
			}
			else
				err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-asp")) {
			if (argc > i+2) {
				RMuint8 ar;
				RMasciiToUInt8(argv[i+1], &(ar));
				active_outport->ar_x = ar;
				RMasciiToUInt8(argv[i+2], &(ar));
				active_outport->ar_y = ar;
				i += 3;
				err = RM_OK;
			}
			else
				err = RM_ERROR;
		
		}
		else if (RMCompareAscii(argv[i], "-afd")) {
			if (argc > i+1) {
				active_outport->active_format_valid = TRUE;
				if (RMCompareAscii(argv[i+1], "none")) {
					active_outport->active_format_valid = FALSE;
				} else if (RMCompareAscii(argv[i+1], "full")) {
					active_outport->active_format = EMhwlibAF_same_as_picture;
				} else if (RMCompareAscii(argv[i+1], "16x9top")) {
					active_outport->active_format = EMhwlibAF_16x9_top;
				} else if (RMCompareAscii(argv[i+1], "14x9top")) {
					active_outport->active_format = EMhwlibAF_14x9_top;
				} else if (RMCompareAscii(argv[i+1], "64x27")) {
					active_outport->active_format = EMhwlibAF_64x27_centered;
				} else if (RMCompareAscii(argv[i+1], "4x3")) {
					active_outport->active_format = EMhwlibAF_4x3_centered;
				} else if (RMCompareAscii(argv[i+1], "16x9")) {
					active_outport->active_format = EMhwlibAF_16x9_centered;
				} else if (RMCompareAscii(argv[i+1], "14x9")) {
					active_outport->active_format = EMhwlibAF_14x9_centered;
				} else if (RMCompareAscii(argv[i+1], "4x3_14x9")) {
					active_outport->active_format = EMhwlibAF_4x3_centered_prot_14x9;
				} else if (RMCompareAscii(argv[i+1], "16x9_14x9")) {
					active_outport->active_format = EMhwlibAF_16x9_centered_prot_14x9;
				} else if (RMCompareAscii(argv[i+1], "16x9_4x3")) {
					active_outport->active_format = EMhwlibAF_16x9_centered_prot_4x3;
				} else {
					err = RM_ERROR;
				}
				if (err != RM_ERROR) {
					active_outport->afd_used = TRUE;
					err = RM_OK;
				}
				i += 2;
			}
			else 
				err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-wss_625")) {
			if (argc > i+5) {
				RMuint32 val;
				
				err = RM_OK;
				RMasciiToUInt32(argv[i+1], &val);
				switch (val) {
				case 0:
					active_outport->wss_625.Enable = CGMSWSS_DisableTopBottom; break;
				case 1:
					active_outport->wss_625.Enable = CGMSWSS_EnableBottom; break;
				case 2:
					active_outport->wss_625.Enable = CGMSWSS_EnableTop; break;
				case 3:
					active_outport->wss_625.Enable = CGMSWSS_EnableTopBottom; break;
				default:
					err = RM_ERROR;
					break;
				}
				
				RMasciiToUInt32(argv[i+2], &val);
				switch (val) {
				case 0:
					active_outport->wss_625.PictureFormat = WSSNormal; break;
				case 1:
					active_outport->wss_625.PictureFormat = WSSLetterBox; break;
				default:
					err = RM_ERROR;
				}
				
				RMasciiToUInt32(argv[i+3], &val);
				switch (val) {
				case 0:
					active_outport->wss_625.PicturePosition = WSSTop; break;
				case 1:
					active_outport->wss_625.PicturePosition = WSSCentre; break;
				default:
					err = RM_ERROR;
				}
				
				RMasciiToUInt32(argv[i+4], &(active_outport->wss_625.dar.X));
				RMasciiToUInt32(argv[i+5], &(active_outport->wss_625.dar.Y));
				
				i += 6;
				active_outport->wss_used = TRUE;
			}
			else err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-wss_525")) {
			if (argc > i+4) {
				RMuint32 val;
				
				err = RM_OK;
				RMasciiToUInt32(argv[i+1], &val);
				switch (val) {
				case 0:
					active_outport->wss_525.Enable = CGMSWSS_DisableTopBottom; break;
				case 1:
					active_outport->wss_525.Enable = CGMSWSS_EnableBottom; break;
				case 2:
					active_outport->wss_525.Enable = CGMSWSS_EnableTop; break;
				case 3:
					active_outport->wss_525.Enable = CGMSWSS_EnableTopBottom; break;
				default:
					err = RM_ERROR;
					break;
				}
				
				RMasciiToUInt32(argv[i+2], &val);
				switch (val) {
				case 0:
					active_outport->wss_525.PictureFormat = WSSNormal; break;
				case 1:
					active_outport->wss_525.PictureFormat = WSSLetterBox; break;
				default:
					err = RM_ERROR;
				}
				
				RMasciiToUInt32(argv[i+3], &(active_outport->wss_525.dar.X));
				RMasciiToUInt32(argv[i+4], &(active_outport->wss_525.dar.Y));
				
				i += 5;
				active_outport->wss_used = TRUE;
			}
		}
		else if (RMCompareAscii(argv[i], "-bus")) {
			if (argc > i+1) {
				RMuint32 bus_size;
				RMasciiToUInt32(argv[i+1], &(bus_size));
				active_outport->bus_size = bus_size;
				if ((bus_size != 8) &&
				    (bus_size != 16) &&
				    (bus_size != 24)){
					err = RM_ERROR;
				}
				else {
					i += 2;
					err = RM_OK;
				}
			}
			else
				err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-cav_mode")) {
			if (argc > i+1) {
				if(RMCompareAscii(argv[i+1], "rgb_scart")) {
					active_outport->component_mode = EMhwlibComponentMode_RGB_SCART;
					active_outport->valid_component_mode = TRUE;
				} 
				else if(RMCompareAscii(argv[i+1], "rgb_sog")) {
					active_outport->component_mode = EMhwlibComponentMode_RGB_SOG;
					active_outport->valid_component_mode = TRUE;
				}
				else if(RMCompareAscii(argv[i+1], "rgb_smpte")) {
					active_outport->component_mode = EMhwlibComponentMode_RGB_SMPTE;
					active_outport->valid_component_mode = TRUE;
				}
				else if(RMCompareAscii(argv[i+1], "yuv_betacam")) {
					active_outport->component_mode = EMhwlibComponentMode_YUV_BETACAM;
					active_outport->valid_component_mode = TRUE;
				}
				else if(RMCompareAscii(argv[i+1], "yuv_m2")) {
					active_outport->component_mode = EMhwlibComponentMode_YUV_M2;
					active_outport->valid_component_mode = TRUE;
				}
				else if(RMCompareAscii(argv[i+1], "yuv_smpte")) {
					active_outport->component_mode = EMhwlibComponentMode_YUV_SMPTE;
					active_outport->valid_component_mode = TRUE;
				}
				else 
					err = RM_ERROR;
#if 0
				if (err != RM_ERROR) {
					err = RM_OK;
					active_outport->composite_mode = EMhwlibCompositeMode_Disable;
					active_outport->valid_composite_mode = TRUE;
				}
#endif

				i += 2;
			}
			else
				err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-agc_version")) {
			if (argc > i+1) {
				RMasciiToUInt32(argv[i+1], &(active_outport->agc_version));
				if (active_outport->agc_version > EMhwlibAGCVersion_AlternateBPP)
					err = RM_ERROR;
				else {
					i += 2;
					err = RM_OK;
				}
			}
			else
				err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-m")) {
			if (argc > i+1) {
				RMasciiToUInt32(argv[i+1], &(options->global.chip));
				i += 2;
				err = RM_OK;
			}
			else
				err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-agc")) {
			if (argc > i+1) {
				RMasciiToUInt32(argv[i+1], &(active_outport->agc_level));
				if (active_outport->agc_level > 3)
					err = RM_ERROR;
				else {
					i += 2;
					err = RM_OK;
				}
			}
			else
				err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-aps")) {
			if (argc > i+1) {
				RMasciiToUInt32(argv[i+1], &(active_outport->aps_level));
				if (active_outport->aps_level > 3)
					err = RM_ERROR;
				else {
					i += 2;
					err = RM_OK;
				}
			}
			else
				err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-rcd")) {
			if (argc > i+1) {
				RMasciiToUInt32(argv[i+1], &(active_outport->rcd));
				if (active_outport->rcd > 1)
					err = RM_ERROR;
				else {
					i += 2;
					err = RM_OK;
				}
			}
			else
				err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-asb")) {
			if (argc > i+1) {
				RMasciiToUInt32(argv[i+1], &(active_outport->asb));
				if (active_outport->asb > 1)
					err = RM_ERROR;
				else {
					i += 2;
					err = RM_OK;
				}
			}
			else
				err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-cgmsa")) {
			if (argc > i+1) {
				RMasciiToUInt32(argv[i+1], &active_outport->cgmsa);
				if (active_outport->cgmsa > 3)
					err = RM_ERROR;
				else {
					i += 2;
					err = RM_OK;
				}
			}
			else
				err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-swap")) {
			if (argc > i+1) {
				if(RMCompareAscii(argv[i+1], "rgb")) {
					active_outport->component_order = EMhwlibComponentOrder_RGB;
				}
				else if(RMCompareAscii(argv[i+1], "rbg")) {
					active_outport->component_order = EMhwlibComponentOrder_RBG;
				}
				else if(RMCompareAscii(argv[i+1], "grb")) {
					active_outport->component_order = EMhwlibComponentOrder_GRB;
				}
				else if(RMCompareAscii(argv[i+1], "gbr")) {
					active_outport->component_order = EMhwlibComponentOrder_GBR;
				}
				else if(RMCompareAscii(argv[i+1], "brg")) {
					active_outport->component_order = EMhwlibComponentOrder_BRG;
				}
				else if(RMCompareAscii(argv[i+1], "bgr")) {
					active_outport->component_order = EMhwlibComponentOrder_BGR;
				}
				else
					err = RM_ERROR;
				if (err != RM_ERROR)
					err = RM_OK;
				i += 2;
			}
			else
				err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-dvi_hdmi")) {
			if (argc > i+1) {
				if (RMCompareAscii(argv[i+1], "siI164")) {
					active_outport->dvi_hdmi_part = DH_siI164;
				}
				else if (RMCompareAscii(argv[i+1], "siI170")) {
					active_outport->dvi_hdmi_part = DH_siI170;
				}
				else if (RMCompareAscii(argv[i+1], "siI9030")) {
					active_outport->dvi_hdmi_part = DH_siI9030;
				}
				else if (RMCompareAscii(argv[i+1], "siI9034")) {
					active_outport->dvi_hdmi_part = DH_siI9034;
				}
				else if (RMCompareAscii(argv[i+1], "siI9134")) {
					active_outport->dvi_hdmi_part = DH_siI9134;
				}
				else if (RMCompareAscii(argv[i+1], "anx9030")) {
					active_outport->dvi_hdmi_part = DH_ANX9030;
				}
				else if (RMCompareAscii(argv[i+1], "lvds")) {
					active_outport->dvi_hdmi_part = DH_lvds;
				}
				else if (RMCompareAscii(argv[i+1], "none")) {
					active_outport->dvi_hdmi_part = DH_no_chip;
				}
				else
					err = RM_ERROR;
				if (err != RM_ERROR)
					err = RM_OK;
				i += 2;
			}
			else
				err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-hdmi")) {
			active_outport->hdmi_force = TRUE;
			active_outport->hdmi_monitor = TRUE;
			i++;
			if ((argc > i) && (argv[i][0] != '-')) {
				// optional argument: force DVI or HDMI
				active_outport->hdmi_monitor = (((argv[i][0] == '0') || (argv[i][0] == 'd') || (argv[i][0] == 'D')) ? FALSE : TRUE);
				i++;
			}
			err = RM_OK;
		}
		else if (RMCompareAscii(argv[i], "-hdcp")) {
			active_outport->dvi_hdmi_hdcp = TRUE;
			i++;
			err = RM_OK;
		}


		else if (RMCompareAscii(argv[i], "-hdmi2c")) {
			if (argc > i+1) {
				RMuint32 i2c_module;
				RMasciiToUInt32(argv[i+1], &i2c_module);
				active_outport->i2c_module = i2c_module;
				i += 2;
				if ((argc > i) && (argv[i][0] >= '0') && (argv[i][0] <= '9')) {
					RMasciiToUInt32(argv[i], &(active_outport->i2c_speed));
					i++;
				}
				err = RM_OK;
			}
			else err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-hdmi_ddc_tx")) {
			active_outport->i2c_ddc_on_tx = TRUE;
			i++;
			err = RM_OK;
		}
		else if (RMCompareAscii(argv[i], "-dvi_reset")) {
			if (argc > i+1) {
				RMasciiToUInt32(argv[i+1], &(active_outport->dvi_reset_gpio));
				i += 2;
				err = RM_OK;
			}
			else err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-hdmi_de")) {
			active_outport->hdmi_de = TRUE;
			i++;
			err = RM_OK;
		}
		else if (RMCompareAscii(argv[i], "-hdmi_act")) {
			if (argc > i+1) {
				active_outport->use_active_format = TRUE;
				if (RMCompareAscii(argv[i+1], "none")) {
					active_outport->use_active_format = FALSE;
				} else if (RMCompareAscii(argv[i+1], "full")) {
					active_outport->hdmi_active_format = DH_af_same_as_picture;
				} else if (RMCompareAscii(argv[i+1], "16x9top")) {
					active_outport->hdmi_active_format = DH_af_16x9_top;
				} else if (RMCompareAscii(argv[i+1], "14x9top")) {
					active_outport->hdmi_active_format = DH_af_14x9_top;
				} else if (RMCompareAscii(argv[i+1], "64x27")) {
					active_outport->hdmi_active_format = DH_af_64x27_centered;
				} else if (RMCompareAscii(argv[i+1], "4x3")) {
					active_outport->hdmi_active_format = DH_af_4x3_centered;
				} else if (RMCompareAscii(argv[i+1], "16x9")) {
					active_outport->hdmi_active_format = DH_af_16x9_centered;
				} else if (RMCompareAscii(argv[i+1], "14x9")) {
					active_outport->hdmi_active_format = DH_af_14x9_centered;
				} else if (RMCompareAscii(argv[i+1], "4x3_14x9")) {
					active_outport->hdmi_active_format = DH_af_4x3_centered_prot_14x9;
				} else if (RMCompareAscii(argv[i+1], "16x9_14x9")) {
					active_outport->hdmi_active_format = DH_af_16x9_centered_prot_14x9;
				} else if (RMCompareAscii(argv[i+1], "16x9_4x3")) {
					active_outport->hdmi_active_format = DH_af_16x9_centered_prot_4x3;
				} else {
					err = RM_ERROR;
				}
				if (err != RM_ERROR)
				
					err = RM_OK;
				i += 2;
			}
			else 
				err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-hdmi_bars")) {
			if (argc > i+4) {
				RMasciiToUInt32(argv[i+1], &(active_outport->hdmi_bar_top));
				RMasciiToUInt32(argv[i+2], &(active_outport->hdmi_bar_bottom));
				RMasciiToUInt32(argv[i+3], &(active_outport->hdmi_bar_left));
				RMasciiToUInt32(argv[i+4], &(active_outport->hdmi_bar_right));
				err = RM_OK;
				i+=5;
			}
			else 
				err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-hdmi_underscan")) {
			active_outport->hdmi_scan = EMhwlibScanInfo_Underscanned;
			i++;
			err = RM_OK;
		}
		else if (RMCompareAscii(argv[i], "-hdmi_scan")) {
			if (argc > i + 1) {
				i++;
				err = RM_OK;
				if ((argv[i][0] == 'o') || (argv[i][0] == 'O')) {
					active_outport->hdmi_scan = EMhwlibScanInfo_Overscanned;
				} else if ((argv[i][0] == 'u') || (argv[i][0] == 'U')) {
					active_outport->hdmi_scan = EMhwlibScanInfo_Underscanned;
				} else {
					err = RM_ERROR;
				}
			} else err = RM_ERROR;
			i++;
		}
		else if (RMCompareAscii(argv[i], "-hdmi_spd")) {
			if (argc > i + 2) {
				active_outport->hdmi_spd_vendor = argv[i + 1];
				active_outport->hdmi_spd_product = argv[i + 2];
				active_outport->hdmi_spd_class = DH_source_dev_unknown;
				err = RM_OK;
				i += 3;
				if ((argc > i) && (argv[i][0] != '-')) {
					if (RMCompareAscii(argv[i], "STB")) {
						active_outport->hdmi_spd_class = DH_source_dev_DigitalSTB;
					} else if (RMCompareAscii(argv[i], "DVD")) {
						active_outport->hdmi_spd_class = DH_source_dev_DVD;
					} else if (RMCompareAscii(argv[i], "DVHS")) {
						active_outport->hdmi_spd_class = DH_source_dev_DVHS;
					} else if (RMCompareAscii(argv[i], "HDD")) {
						active_outport->hdmi_spd_class = DH_source_dev_HDDVideo;
					} else if (RMCompareAscii(argv[i], "DVC")) {
						active_outport->hdmi_spd_class = DH_source_dev_DVC;
					} else if (RMCompareAscii(argv[i], "DSC")) {
						active_outport->hdmi_spd_class = DH_source_dev_DSC;
					} else if (RMCompareAscii(argv[i], "VCD")) {
						active_outport->hdmi_spd_class = DH_source_dev_VideoCD;
					} else if (RMCompareAscii(argv[i], "Game")) {
						active_outport->hdmi_spd_class = DH_source_dev_Game;
					} else if (RMCompareAscii(argv[i], "PC")) {
						active_outport->hdmi_spd_class = DH_source_dev_PC;
					} else if (RMCompareAscii(argv[i], "BluRay")) {
						active_outport->hdmi_spd_class = DH_source_dev_BluRay;
					} else if (RMCompareAscii(argv[i], "SACD")) {
						active_outport->hdmi_spd_class = DH_source_dev_SACD;
					} else {
						fprintf(stderr, "Unknown HDMI SPD class: %s\n", argv[i]);
						err = RM_ERROR;
					}
					i++;
				}
			} else err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-tmds_mode")) {
			if (argc > i+2) {
				RMuint32 gpio;
				RMasciiToUInt32(argv[i+1], &(gpio));
				active_outport->tmds_gpio = (enum GPIOId_type)gpio;
				RMasciiToUInt32(argv[i+2], &(active_outport->tmds_threshold));
				i += 3;
				err = RM_OK;
			}
			else err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-filter_gpio")) {
			if (argc > i+3) {
				RMuint32 gpio;
				RMasciiToUInt32(argv[i+1], &(gpio));
				active_outport->filter_gpio_start = (enum GPIOId_type)gpio;
				RMasciiToUInt32(argv[i+2], &(active_outport->filter_gpio_num));
				RMasciiToUInt32(argv[i+3], &(active_outport->filter_gpio_val));
				i += 4;
				err = RM_OK;
			}
			else err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-dp")) {
			if (argc > i + 1) {
				if (RMCompareAscii(argv[i + 1], "601")) {
					active_outport->digital_protocol = EMhwlibDigitalTimingSignal_601;
				}
				else if (RMCompareAscii(argv[i + 1], "656")) {
					active_outport->digital_protocol = EMhwlibDigitalTimingSignal_656;
				}
				else if (RMCompareAscii(argv[i + 1], "vip")) {
					active_outport->digital_protocol = EMhwlibDigitalTimingSignal_656_VIP;
				}
				else
					err = RM_ERROR;
				if (err != RM_ERROR)
					err = RM_OK;
				i += 2;
			}
			else
				err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-dig_dr")) {
			if (argc > i+1) {
				RMuint32 param;
				RMasciiToUInt32(argv[i+1], &param);
				active_outport->dig_force_doublerate = TRUE;
				active_outport->dig_doublerate = param ? TRUE : FALSE;
				i += 2;
				err = RM_OK;
			}
			else err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-dclk")) {
			active_outport->dig_clk_normal = TRUE;
			i++;
			err = RM_OK;
		}
		else if (RMCompareAscii(argv[i], "-ddr")) {
			active_outport->dig_ddr = TRUE;
			i++;
			err = RM_OK;
		}
		else if (RMCompareAscii(argv[i], "-ddr_delay")) {
			fprintf(stderr, "outports_options.c: -ddr_delay option is obsolete, use -dig_delay instead!\n");
			if (argc > i+1) {
				RMuint32 dig_ddr_delay;
				RMasciiToUInt32(argv[i+1], &(dig_ddr_delay));
				dig_ddr_delay &= 0x07;
				active_outport->dig_delay = dig_ddr_delay * 800;
				active_outport->dig_force_delay = TRUE;
				err = RM_OK;
			} else {
				err = RM_ERROR;
			}
			i += 2;
		}
		else if (RMCompareAscii(argv[i], "-dig_delay")) {
			if (argc > i+1) {
				RMasciiToUInt32(argv[i+1], &(active_outport->dig_delay));
				active_outport->dig_force_delay = TRUE;
				err = RM_OK;
			} else {
				err = RM_ERROR;
			}
			i += 2;
		}
		else if (RMCompareAscii(argv[i], "-dig_no_delay")) {
			fprintf(stderr, "outports_options.c: -dig_no_delay option is obsolete, use -dig_delay instead!\n");
			active_outport->dig_force_delay = TRUE;
			if ((argc > i+1) && (argv[i+1][0] != '-')) {
				active_outport->dig_delay = (argv[i+1][0] != '0') ? 0 : 400;
				i++;
			} else {
				active_outport->dig_delay = 0;
			}
			i++;
			err = RM_OK;
		}
		else if (RMCompareAscii(argv[i], "-vsync_delay")) {
			active_outport->dig_vsync_delay = TRUE;
			i++;
			err = RM_OK;
		}
		else if (RMCompareAscii(argv[i], "-trailing_edge")) {
			active_outport->dig_trailing_edge = TRUE;
			i++;
			err = RM_OK;
		}
		else if (RMCompareAscii(argv[i], "-chroma_sync")) {
			if ((argc > i + 1) && (argv[i + 1][0] != '-')) {
				i++;
				if ((argv[i][0] == 's') || (argv[i][0] == 'S') || (argv[i][0] == '1'))
					active_outport->chroma_sync = TRUE;
			}
			i++;
			err = RM_OK;
		}
		else if (RMCompareAscii(argv[i], "-scart_en")) {
			if (argc > i + 1) {
				RMuint32 param;
				RMasciiToUInt32(argv[i + 1], &param);
				active_outport->scart_enable = param ? TRUE : FALSE;
				if ((argc > i + 2) && (argv[i + 2][0] != '-')) {
					RMuint32 scart_en_pio;
					RMasciiToUInt32(argv[i + 2], &scart_en_pio);
					scart_en_pio++;
					if ((argc > i + 3) && (argv[i + 3][0] != '-')) {
						if (argv[i + 3][0] != '0') scart_en_pio |= 0x100;
						i++;
					}
					active_outport->scart_en_pio = scart_en_pio;
					i++;
				} else {
					active_outport->scart_en_pio = SCART_ENABLE_GPIO + 1;
				}
				err = RM_OK;
			} else {
				err = RM_ERROR;
			}
			i += 2;
		}
		else if (RMCompareAscii(argv[i], "-scart_ws")) {
			if (argc > i + 1) {
				RMuint32 param;
				if (argv[i + 1][0] != 'a') {
					RMasciiToUInt32(argv[i + 1], &param);
					active_outport->scart_widescreen = param ? TRUE : FALSE;
					active_outport->scart_ws_pio |= 0x200; /* force WS */
					
				}
				if ((argc > i + 2) && (argv[i + 2][0] != '-')) {
					RMasciiToUInt32(argv[i + 2], &param);
						active_outport->scart_ws_pio = (active_outport->scart_ws_pio & 0xFF00) | (param + 1);
					
					if ((argc > i + 3) && (argv[i + 3][0] != '-')) {
						if (argv[i + 3][0] != '0'){
							active_outport->scart_ws_pio |= 0x100;
						}
						i++;
					}
					i++;
				} else {
						active_outport->scart_ws_pio = (active_outport->scart_ws_pio & 0xFF00) | (SCART_WIDESCREEN_GPIO + 1);
				}
				err = RM_OK;
			} else {
				err = RM_ERROR;
			}
			i += 2;
		}
		else if (RMCompareAscii(argv[i], "-dac_comp")) {
			if (argc > i + 1) {
				active_outport->force_DACCompDisable = TRUE;
				active_outport->DACCompDisable = (argv[i + 1][0] == '0');
				i += 2;
				err = RM_OK;
			}
			else err = RM_ERROR;
		}
		else if (RMCompareAscii(argv[i], "-dis_pix_timer")) {
			active_outport->disable_pixel_timer = TRUE;
			i++;
			err = RM_OK;
		}


		/* GLOBAL OPTIONS */
		else if (RMCompareAscii(argv[i], "-no_otf")) {
			if(active_outport == NULL){
				options->global.allow_otf = FALSE;
				i++;
				err = RM_OK;
			}
			else{
				fprintf(stderr, "-no_otf: misplaced global option\n");
				err = RM_ERROR;
			}
		}
		else if (RMCompareAscii(argv[i], "-no_buf")) {
			if(active_outport == NULL){
				options->global.allow_buf = FALSE;
				i++;
				err = RM_OK;
			}
			else{
				fprintf(stderr, "-no_buf: misplaced global option\n");
				err = RM_ERROR;
			}
		}
		else if (RMCompareAscii(argv[i], "-no_cs")) {
			if(active_outport == NULL){
				options->global.do_cs = FALSE;
				i++;
				err = RM_OK;
			}
			else{
				fprintf(stderr, "-no_cs: misplaced global option\n");
				err = RM_ERROR;
			}
		}
		else if (RMCompareAscii(argv[i], "-no_cp")) {
			if(active_outport == NULL){
				options->global.do_cp = FALSE;
				i++;
				err = RM_OK;
			}
			else{
				fprintf(stderr, "-no_cp: misplaced global option\n");
				err = RM_ERROR;
			}
		}


	}
	*index = i;
	return err;
}


static void set_default_values(struct outport_config *config)
{
	/* base */
	config->action = DCCOutportState_Disable;
	config->vidmode_filename[0] = '\0';
	config->standard = EMhwlibTVStandard_NTSC_M;
	config->flags = 0; /* no flag */
	config->route = DCCRoute_Main;
	/* video */
/* 	config->brightness = 0;  */
/* 	config->hue = 0; */
/* 	config->contrast = 128; */
/* 	config->saturation = 128; */
	/* aspect */
	config->ar_x = 4;
	config->ar_y = 3;
	config->afd_used = FALSE;
	config->active_format_valid = FALSE;
	config->active_format = EMhwlibAF_same_as_picture;
	/* wss backward compatibility */
	config->wss_used = FALSE;
	config->wss_625.Enable = CGMSWSS_EnableTopBottom;
	config->wss_625.PictureFormat = WSSNormal;
	config->wss_625.PicturePosition = WSSTop;
	config->wss_625.dar.X = 4;
	config->wss_625.dar.Y = 3;
	config->wss_525.Enable = CGMSWSS_EnableTopBottom;
	config->wss_525.PictureFormat = WSSNormal;
	config->wss_525.dar.X = 4;
	config->wss_525.dar.Y = 3;
	/* copy */
	config->agc_level = 0;
	config->agc_version = (RMuint32)EMhwlibAGCVersion_ConstantBPP;
	config->aps_level = 0;
	config->rcd = 0;
	config->asb = 0;
	config->cgmsa = 0;
	
	/* signal */
	config->color_space = EMhwlibColorSpace_YUV_601;
	config->component_order = EMhwlibComponentOrder_RGB;
	config->valid_component_mode = FALSE;
	config->component_mode = EMhwlibComponentMode_YUV_SMPTE;
	config->valid_composite_mode = FALSE;
	config->composite_mode = EMhwlibCompositeMode_NTSC_M;
	config->bus_size = 24;
	config->color_order = EMhwlibColorOrder_RGB;
 	config->digital_protocol = EMhwlibDigitalTimingSignal_601;
	/* hdmi / dvi / edid / hdcp */
	config->dh_info = &(config->dh_info_local);
	config->dh_info->pDH = NULL;
	config->dvi_hdmi_part = DH_auto_detect;
	config->dvi_hdmi_state = DH_uninitialized;
	config->dvi_hdmi_hdcp = FALSE;
	config->dvi_hdmi_display_edid = FALSE;
	config->hdmi_monitor = FALSE;
	config->hdmi_force = FALSE;
	config->hdmi_de = FALSE;
	config->dvi_hdmi_edid_file = NULL;
	config->i2c_module = 0;
	config->i2c_speed = 0;  // don't force
	config->i2c_ddc_on_tx = FALSE;
	config->dvi_reset_gpio = 0;  // no GPIO used to reset DVI chip
	config->hdmi_active_format = DH_af_same_as_picture;
	config->hdmi_bar_top = 0;
	config->hdmi_bar_bottom = 4096;
	config->hdmi_bar_left = 0;
	config->hdmi_bar_right = 4096;
	config->hdmi_scan = EMhwlibScanInfo_NoData;
	config->use_active_format = FALSE;
	config->hdmi_spd_vendor = NULL;
	config->hdmi_spd_product = NULL;
	config->hdmi_spd_class = DH_source_dev_unknown;
	config->tmds_threshold = 0;
	config->tmds_gpio = 0;
	config->filter_gpio_start = 0;
	config->filter_gpio_num = 0;
	config->filter_gpio_val = 0;

	config->dig_force_doublerate = FALSE;
	config->dig_doublerate = FALSE;
	config->dig_clk_normal = FALSE;
	config->dig_ddr = FALSE;
	config->dig_inv_cap_clk = FALSE;
	config->dig_delay = 2300;
	config->dig_force_delay = FALSE;
	config->dig_vsync_delay = FALSE;
	config->dig_trailing_edge = FALSE;
	config->chroma_sync = FALSE;

	config->scart_enable = FALSE;
	config->scart_en_pio = 0;
	config->scart_widescreen = FALSE;
	config->scart_ws_pio = 0;

	config->use_digital_timing = FALSE;
	
	config->force_DACCompDisable = FALSE;
	config->DACCompDisable = FALSE;
	config->force_DACDisable = FALSE;
	config->DACDisable.DAC1SVideoY = FALSE;
	config->DACDisable.DAC2SVideoC = FALSE;
	config->DACDisable.DAC3CVBS    = FALSE;
	config->DACDisable.DAC4Y  = FALSE;
	config->DACDisable.DAC5Cb = FALSE;
	config->DACDisable.DAC6Cr = FALSE;
	config->force_LumaChromaDelay = FALSE;
	config->LumaChromaDelay = EMhwlibLumaChromaDelay_NoDelay;
	config->force_TripleCVBS = FALSE;
	config->TripleCVBS = FALSE;
	config->force_LineCrop = FALSE;
	config->LineCrop.CropLeftPos = 0;
	config->LineCrop.CropRightPos = 4095;
	config->LineCrop.ColorSpace = config->color_space;
	config->LineCrop.CropControl = FALSE;
	config->disable_pixel_timer = FALSE;
}

RMstatus init_outports_options(struct outports_options *options)
{
	set_default_values(&(options->digital));
	set_default_values(&(options->analog));
	set_default_values(&(options->component));
	set_default_values(&(options->composite));
	options->global.allow_buf = TRUE;
	options->global.allow_otf = TRUE;
	options->global.do_cs = TRUE;
	options->global.do_cp = TRUE;
	options->global.chip = 0;

	return RM_OK;
}

RMstatus apply_outports_options(struct DCC *pDCC, struct outports_options *options)
{
	RMstatus err;
	struct DCCOutportsConfig config;
	struct DCCOutportsInfo info;

	/* setup some reasonable values first */
	err = DCCInitOutportsConfigStructure(pDCC, &config);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error initializing the outports info structure! %d\n", err);
		return err;
	}

	/* translate standard to format */
#ifdef RMFEATURE_HAS_DIGITAL_OUT
	config.digital.format.Type = EMhwlibTVFormatType_Digital;

	RUAExchangeProperty(pDCC->pRUA, DisplayBlock, RMDisplayBlockPropertyID_TVFormatDigital,
 			    &(options->digital.standard), sizeof(options->digital.standard),
			    &(config.digital.format.Format.Digital), sizeof(config.digital.format.Format.Digital));
	
	/* find out if standard requires DoubleRate feature */
	if (options->digital.dig_force_doublerate) {
		config.digital.format.Format.Digital.DoubleRateMode = options->digital.dig_doublerate;
	} else {
		config.digital.format.Format.Digital.DoubleRateMode = DCCGetDoubleRate(options->digital.standard);
	}
	
	/* if DoubleRate is enabled, disable all analog outputs on the same route (mixer size does not match) */
	if (0 && config.digital.format.Format.Digital.DoubleRateMode) {
#ifdef RMFEATURE_HAS_COMPONENT_OUT
		if (options->component.route == options->digital.route) {
			RMDBGLOG((ENABLE, "******** Disabling component outputs because of DoubleRate ********\n"));
			options->component.action = DCCOutportState_Disable;
		}
#endif
#ifdef RMFEATURE_HAS_MAIN_ANALOG_OUT
		if (options->analog.route == options->digital.route) {
			RMDBGLOG((ENABLE, "******** Disabling analog outputs because of DoubleRate ********\n"));
			options->analog.action = DCCOutportState_Disable;
		}
#endif
#ifdef RMFEATURE_HAS_COMPOSITE_OUT
		if (options->composite.route == options->digital.route) {
			RMDBGLOG((ENABLE, "******** Disabling composite outputs because of DoubleRate ********\n"));
			options->composite.action = DCCOutportState_Disable;
		}
#endif
	}

	config.digital.state = options->digital.action;
	config.digital.route = options->digital.route;
	config.digital.flags = options->digital.flags;

	if(options->digital.action == DCCOutportState_Enable){
		err = setup_outport_config(pDCC->pRUA, DispDigitalOut, &(options->digital), &(options->global));
		if (RMFAILED(err)) {
			fprintf(stderr, "Error configuring the display! %d\n", err);
			return err;
		}

	}


#endif

#ifdef RMFEATURE_HAS_COMPONENT_OUT
	config.component.format.Type = EMhwlibTVFormatType_Analog;
	RUAExchangeProperty(pDCC->pRUA, DisplayBlock, RMDisplayBlockPropertyID_TVFormatAnalog,
 			    &(options->component.standard), sizeof(options->component.standard),
			    &(config.component.format.Format.Analog), sizeof(config.component.format.Format.Analog));
	config.component.state = options->component.action;
	config.component.route = options->component.route;
	config.component.flags = options->component.flags;
	if(options->component.valid_component_mode){
		config.component.format.Format.Analog.ComponentMode = options->component.component_mode;
	}
	if(options->component.valid_composite_mode){
		config.component.format.Format.Analog.CompositeMode = options->component.composite_mode;
	}

	if(options->component.action == DCCOutportState_Enable){
		err = setup_outport_config(pDCC->pRUA, DispComponentOut, &(options->component), &(options->global));
		if (RMFAILED(err)) {
			fprintf(stderr, "Error configuring the display! %d\n", err);
			return err;
		}

	}

#endif
	/* 
	   8622 has only one outport (DispMainAnalogOutport) to provide both component and composite
	   signal.
	   
	   The ui makes some abstraction of this by allowing the user to use both -component and -analog
	   options. This is useful because some of the configurable parameters are specific to each set of DACs; 
	   notably it is possible to enable/disable the component and composite DACs separately.
	   
	   The abstraction is not total because the user is required to set the mostly the same parameters 
	   for component and analog.
	   
	   This abstraction is made entirely by outports_options: DCCSetOuports only knows about DispMainAnalog.
	*/
	   


#ifdef RMFEATURE_HAS_MAIN_ANALOG_OUT
#ifdef RMFEATURE_HAS_DUAL_MAINANALOGOUT

	if((options->analog.action == DCCOutportState_Enable) &&
	   (options->component.action == DCCOutportState_Disable)){
		options->analog.valid_component_mode = TRUE;
		options->analog.component_mode = EMhwlibComponentMode_Disable;
	}
	else if((options->analog.action == DCCOutportState_Disable) &&
		(options->component.action == DCCOutportState_Enable)){
		/* copy the component options into analog struct since it's 
		   the one we'll be using to configure the outport
		*/
		RMMemcpy(&(options->analog), &(options->component), sizeof(struct outport_config));
		options->analog.valid_composite_mode = TRUE;
		options->analog.composite_mode = EMhwlibCompositeMode_Disable;

	}
	else if((options->analog.action == DCCOutportState_Enable) &&
		(options->component.action == DCCOutportState_Enable)){
		err = compare_analog_component(&options->analog, &options->component);
		if(RMFAILED(err)){
			fprintf(stderr, "Error configuring the display!\n");
			return err;
		}
	}
	else if((options->analog.action == DCCOutportState_Disable) &&
		(options->component.action == DCCOutportState_Disable)){
		config.analog.state = DCCOutportState_Disable;
	}
	else if((options->analog.action == DCCOutportState_Keep) &&
		(options->component.action == DCCOutportState_Keep)){
		config.analog.state = DCCOutportState_Keep;
	}
	else{
		fprintf(stderr, "ERROR: Unsupported combination of component and analog parameters\n");
		fprintf(stderr, "Error configuring the display!\n");
		return RM_ERROR;
	}

#endif
	config.analog.format.Type = EMhwlibTVFormatType_Analog;
	RUAExchangeProperty(pDCC->pRUA, DisplayBlock, RMDisplayBlockPropertyID_TVFormatAnalog,
 			    &(options->analog.standard), sizeof(options->analog.standard), 
			    &(config.analog.format.Format.Analog), sizeof(config.analog.format.Format.Analog));

	config.analog.state = options->analog.action;
	config.analog.route = options->analog.route;
	config.analog.flags = options->analog.flags;
	if(options->analog.valid_component_mode){
		config.analog.format.Format.Analog.ComponentMode = options->analog.component_mode;
	}
	if(options->analog.valid_composite_mode){
		config.analog.format.Format.Analog.CompositeMode = options->analog.composite_mode;
	}

	if(options->analog.action == DCCOutportState_Enable){
		err = setup_outport_config(pDCC->pRUA, DispMainAnalogOut, &(options->analog), &(options->global));
		if (RMFAILED(err)) {
			fprintf(stderr, "Error configuring the display! %d\n", err);
			return err;
		}

	}

#endif


#ifdef RMFEATURE_HAS_COMPOSITE_OUT
	config.composite.format.Type = EMhwlibTVFormatType_Analog;
	RUAExchangeProperty(pDCC->pRUA, DisplayBlock, RMDisplayBlockPropertyID_TVFormatAnalog,
 			    &(options->composite.standard), sizeof(options->composite.standard), 
			    &(config.composite.format.Format.Analog), sizeof(config.composite.format.Format.Analog));


	config.composite.state = options->composite.action;
	config.composite.route = options->composite.route;
	config.composite.flags = options->composite.flags;

	if(options->composite.action == DCCOutportState_Enable){
		RMDBGLOG((ENABLE, "setup outport config composite\n"));
		err = setup_outport_config(pDCC->pRUA, DispCompositeOut, &(options->composite), &(options->global));
		if (RMFAILED(err)) {
			fprintf(stderr, "Error configuring the display! %d\n", err);
			return err;
		}

	}

#endif

	config.allow_hdsd_on_the_fly = options->global.allow_otf;
	config.allow_hdsd_buffered = options->global.allow_buf;


	if (options->digital.dh_info && options->digital.dh_info->pDH) {
		RMDBGLOG((ENABLE, "disable outport digital HDMI\n"));
		// Turn off TMDS to avoid video noise
		DHDisableOutput(options->digital.dh_info->pDH);
	}

	if (options->digital.action == DCCOutportState_Enable){
		RMDBGLOG((ENABLE, "Applying DoubleRate(%s)\n", config.digital.format.Format.Digital.DoubleRateMode ? "TRUE" : "FALSE"));
		DCCSP(pDCC->pRUA, DispDigitalOut, RMDispDigitalOutPropertyID_DoubleRate, 
			&(config.digital.format.Format.Digital.DoubleRateMode), 
			sizeof(config.digital.format.Format.Digital.DoubleRateMode));
	}

	err = DCCSetOutports(pDCC, &config, &info);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error on DCCSetOutports! %d\n", err);
		return err;
	}
#ifdef RMFEATURE_HAS_DIGITAL_OUT
	if (options->digital.action == DCCOutportState_Enable) {
		
		RMDBGLOG((ENABLE, "setup outport digital HDMI\n"));
		err = apply_dvi_hdmi(pDCC->pRUA,  &(options->digital), options->digital.dh_info, config.digital.format.Format.Digital.DoubleRateMode);
		if (RMFAILED(err)) {
			fprintf(stderr, "Error configuring the HDMI chip! %d\n", err);
			return err;
		}
		
		err = setup_aspect_ratio(pDCC->pRUA, info.digital.source_id, &(options->digital));
		if (RMFAILED(err) && (err != RM_NOT_FOUND)) {
			fprintf(stderr, "Error setting up aspect ratio! %d\n", err);
			return err;
		}
	}
#endif
#ifdef RMFEATURE_HAS_COMPONENT_OUT
	if (
		(options->component.action == DCCOutportState_Enable) && 
		((options->digital.action != DCCOutportState_Enable) || (info.digital.source_id != info.component.source_id)) 
	){
		err = setup_aspect_ratio(pDCC->pRUA, info.component.source_id, &(options->component));
		if (RMFAILED(err) && (err != RM_NOT_FOUND)) {
			fprintf(stderr, "Error setting up aspect ratio! %d\n", err);
			return err;
		}
	}
#endif
#ifdef RMFEATURE_HAS_MAIN_ANALOG_OUT
	if (
		(options->analog.action == DCCOutportState_Enable) && 
		((options->digital.action != DCCOutportState_Enable) || (info.digital.source_id != info.analog.source_id)) && 
		((options->component.action != DCCOutportState_Enable) || (info.component.source_id != info.analog.source_id)) 
	) {
		err = setup_aspect_ratio(pDCC->pRUA, info.analog.source_id, &(options->analog));
		if (RMFAILED(err) && (err != RM_NOT_FOUND)) {
			fprintf(stderr, "Error setting up aspect ratio! %d\n", err);
			return err;
		}
	}
#endif
#ifdef RMFEATURE_HAS_COMPOSITE_OUT
	if (
		(options->composite.action == DCCOutportState_Enable) && 
		((options->digital.action != DCCOutportState_Enable) || (info.digital.source_id != info.composite.source_id)) && 
		((options->component.action != DCCOutportState_Enable) || (info.component.source_id != info.composite.source_id)) && 
		((options->analog.action != DCCOutportState_Enable) || (info.analog.source_id != info.composite.source_id)) 
	) {
		err = setup_aspect_ratio(pDCC->pRUA, info.composite.source_id, &(options->composite));
		if (RMFAILED(err) && (err != RM_NOT_FOUND)) {
			fprintf(stderr, "Error setting up aspect ratio! %d\n", err);
			return err;
		}
	}
#endif
	
	/* Set up low pass filter for component output on the board
	Sigma BluRay eval. board:
	-filter_gpio 36 2 0 (8 MHz, 480i)
	-filter_gpio 36 2 1 (16 MHz, 480p)
	-filter_gpio 36 2 2 (32 MHz, 720p, 1080i)
	-filter_gpio 36 2 3 (bypass)
	Sigma Envision/Vantage eval. boards:
	-filter_gpio 36 1 0 (bypass, 480p, 720p, 1080i)
	-filter_gpio 36 1 1 (?? MHz, 480i)
	*/
#ifdef RMFEATURE_HAS_MAIN_ANALOG_OUT
	if (options->analog.valid_component_mode && options->analog.filter_gpio_num) {
		RMuint32 i;
		struct SystemBlock_GPIO_type gpio;
		
		for (i = 0; i < options->analog.filter_gpio_num; i++) {
			gpio.Bit = (enum GPIOId_type)(options->analog.filter_gpio_start + i);
			gpio.Data = (options->analog.filter_gpio_val & (1 << i)) ? TRUE : FALSE;
			if (RMFAILED(err = RUASetProperty(pDCC->pRUA, SystemBlock, RMSystemBlockPropertyID_GPIO, &gpio, sizeof(gpio), 0))) {
				RMDBGLOG((ENABLE, "Error setting GPIO %u to set external filter: %s\n", gpio.Bit, RMstatusToString(err)));
			}
		}
	}
#endif
#ifdef RMFEATURE_HAS_COMPONENT_OUT
	if (options->component.filter_gpio_num) {
		RMuint32 i;
		struct SystemBlock_GPIO_type gpio;
		
		for (i = 0; i < options->component.filter_gpio_num; i++) {
			gpio.Bit = (enum GPIOId_type)(options->component.filter_gpio_start + i);
			gpio.Data = (options->component.filter_gpio_val & (1 << i)) ? TRUE : FALSE;
			if (RMFAILED(err = RUASetProperty(pDCC->pRUA, SystemBlock, RMSystemBlockPropertyID_GPIO, &gpio, sizeof(gpio), 0))) {
				RMDBGLOG((ENABLE, "Error setting GPIO %u to set external filter: %s\n", gpio.Bit, RMstatusToString(err)));
			}
		}
	}
#endif
	
	return RM_OK;

}

