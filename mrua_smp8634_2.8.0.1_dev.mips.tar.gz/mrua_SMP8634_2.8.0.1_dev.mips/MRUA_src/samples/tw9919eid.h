#ifndef _TW9919EID_H
#define _TW9919EID_H
#include <stdio.h>
#include "../rua/include/rua.h"
#include "../rua/include/rua_property.h"
#include "common.h"
#include "../emhwlib/include/emhwlib_videoformats.h"
enum audio_frequency_type {
	audio_frequency_48khz=0, 
	audio_frequency_44khz, 
	audio_frequency_32khz,
	audio_frequency_8khz,		
};


RMstatus tw9919eid_getCaptureStandard(	struct RUA *pInstance,
									  RMuint32 numHsyncPerVsync,
									  enum EMhwlibTVStandard tvStandartSupportedList[],
									  RMuint8 sizeOftvStandartSupportedList,
									  enum EMhwlibTVStandard *newTVStandard);
RMstatus tw9919eid_setSizeOfSDRAM(struct RUA *pInstance,RMuint8 delay,RMuint32 dev,
						/*
							16 : 16 MB SDRAM
							32 : 32 MB SDRAM
							64 : 64 MB SDRAM
						 */
						  RMuint8 sizeOfRam
						) ;

RMstatus tw9919eid_setCapturePort(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,
	/*
	 	1 : Capture CVBS port
		2 : Capture S-Video port
	 */
	 RMuint8 port 
	);
/*
 *	
 */
RMuint8 tw9919eid_isVideoIn(struct RUA *pInstance, RMuint8 dev, RMuint8 delay);
RMuint8 tw9919eid_isStandardSignal(struct RUA *pInstance, RMuint8 dev, RMuint8 delay);
RMuint8 tw9919eid_isNTSC(struct RUA *pInstance, RMuint8 dev, RMuint8 delay);
RMstatus tw9919eid_setRegColorSystem(struct RUA *pInstance, 								  
						   RMuint8 dev, 
						   RMuint8 delay ,								  
						   RMuint8 isNTSC);
RMstatus tw9919eid_setRegOutputInterface(struct RUA *pInstance, 								  
									 RMuint8 dev, 
									 RMuint8 delay ,								  
									 RMuint8 isNTSC);
RMstatus tw9919eid_setAudioClock(
								 struct RUA *pInstance, 								  
								 RMuint8 dev, 
								 RMuint8 delay ,								  
								 RMuint8 isNTSC,
								 RMuint32 afreq);
								 
RMstatus tw9919eid_checkStandardDetected(struct RUA *pInstance, 								  
										 RMuint8 dev, 
										 RMuint8 delay );

RMstatus tw9919eid_checkRegisterSet(struct RUA *pInstance, 
										   RMuint32 dev ,
										   RMuint8 delay);
RMstatus tw9919eid_setStandardAutoDetect(struct RUA *pInstance, 								  
										 RMuint8 dev, 
										 RMuint8 delay );	
RMstatus tw9919eid_Enable3DNRDemo(struct RUA *pInstance, 								  
							  RMuint8 dev, 
							  RMuint8 delay);
RMstatus tw9919eid_Disable3DNRDemo(struct RUA *pInstance, 								  
							   RMuint8 dev, 
							   RMuint8 delay);
RMstatus tw9919eid_Enable3DCombFilter(struct RUA *pInstance, 								  
									  RMuint8 dev, 
									  RMuint8 delay);
RMstatus tw9919eid_Disable3DCombFilter(struct RUA *pInstance, 								  
									   RMuint8 dev, 
									   RMuint8 delay);
RMstatus tw9919eid_setContrast(struct RUA *pInstance, 								  
							   RMuint8 dev, 
							   RMuint8 delay,
							   /*
							    * contrastValue have value of 0 to 255
								* A value of 144,128 have no effect on the video data.
							    */
							   RMuint32 contrastValue);
RMstatus tw9919eid_getContrast(struct RUA *pInstance, 								  
							   RMuint8 dev, 
							   RMuint8 delay,
							   RMuint32 *contrastValue);
//if valid, return RM_OK , else return RM_ERROR;
RMstatus tw9919eid_isContrastValid(struct RUA *pInstance, 								  
								   RMuint8 dev, 
								   RMuint8 delay,
								   RMuint32 contrastValue);
RMstatus tw9919eid_setBrightness(struct RUA *pInstance, 								  
								 RMuint8 dev, 
								 RMuint8 delay,
								 /*
								  *	brightnessValue have value of -128 to 127
								  * A value 0 has no effect on the data.
								  */
								 RMint32 brightnessValue);
RMstatus tw9919eid_getBrightness(struct RUA *pInstance, 								  
								 RMuint8 dev, 
								 RMuint8 delay,
								 RMint32 *brightnessValue);
RMstatus tw9919eid_isBrightnessValid(struct RUA *pInstance, 								  
									 RMuint8 dev, 
									 RMuint8 delay,
									 RMint32 brightnessValue);

RMstatus tw9919eid_setSaturationU(struct RUA *pInstance, 								  
								  RMuint8 dev, 
								  RMuint8 delay,
								  RMuint32 saturationUValue);
RMstatus tw9919eid_setSaturationV(struct RUA *pInstance, 								  
								  RMuint8 dev, 
								  RMuint8 delay,
								  RMuint32 saturationVValue);
RMstatus tw9919eid_setSaturation(struct RUA *pInstance, 								  
								  RMuint8 dev, 
								  RMuint8 delay,
								  RMuint32 saturationValue);
RMstatus tw9919eid_setHue(struct RUA *pInstance, 								  
								 RMuint8 dev, 
								 RMuint8 delay,
								 RMint32 hueValue);
RMstatus tw9919eid_setSharpness(struct RUA *pInstance, 								  
						  RMuint8 dev, 
						  RMuint8 delay,
						  RMuint32 sharpnessValue);
RMstatus tw9919eid_setCTI(struct RUA *pInstance, 								  
								RMuint8 dev, 
								RMuint8 delay,
								RMuint32 ctiValue);
//Motion Adaptive test :
RMstatus tw9919eid_setYGain(struct RUA *pInstance, 								  
						  RMuint8 dev, 
						  RMuint8 delay,
						  RMuint32 value);
RMstatus tw9919eid_setCGain(struct RUA *pInstance, 								  
							RMuint8 dev, 
							RMuint8 delay,
							RMuint32 value);
RMstatus tw9919eid_setMDLevel1(struct RUA *pInstance, 								  
							RMuint8 dev, 
							RMuint8 delay,
							RMuint32 value);
RMstatus tw9919eid_setMDLevel2(struct RUA *pInstance, 								  
							   RMuint8 dev, 
							   RMuint8 delay,
							   RMuint32 value);
RMstatus tw9919eid_setMDLevel3(struct RUA *pInstance, 								  
							   RMuint8 dev, 
							   RMuint8 delay,
							   RMuint32 value);
RMstatus tw9919eid_setMIX(struct RUA *pInstance, 								  
							   RMuint8 dev, 
							   RMuint8 delay,
							   RMuint32 value);
RMstatus tw9919eid_PowerDown(struct RUA *pInstance, 								  
							 RMuint8 dev, 
							 RMuint8 delay);
RMstatus tw9919eid_PowerUp(struct RUA *pInstance, 								  
						   RMuint8 dev, 
						   RMuint8 delay);
RMstatus tw9919eid_EnableBlueScreen(struct RUA *pInstance, 								  
									RMuint8 dev, 
									RMuint8 delay);

RMstatus tw9919eid_DisableBlueScreen(struct RUA *pInstance, 								  
									 RMuint8 dev, 
									 RMuint8 delay);
void tw9919eid_Debug(struct 
					 RUA *pInstance, 								  
					 RMuint8 dev, 
					 RMuint8 delay,
					 RMuint8 key);
RMstatus tw9919eid_setManualColorSystem(struct RUA *pInstance,
										RMuint8 dev, 
										RMuint8 delay,
										RMuint8 isNTSC
										);
void tw9919eid_showMenu(void);
RMstatus tw9919eid_EnableCC(struct RUA *pInstance, 	//Enable Close Caption							  
							RMuint8 dev, 
							RMuint8 delay);

RMstatus tw9919eid_EnableTT(struct RUA *pInstance, 	//Enable Teletext
							RMuint8 dev, 
							RMuint8 delay);				  
#endif




