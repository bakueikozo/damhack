/*****************************************
 Copyright � 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   dvi_hdmi_update.h
  @brief  Wrapper function to update DVI, HDMI from emhwlib settings

  long description

  @author Christian Wolff
  @date   2007-04-18
*/

#ifndef __DVI_HDMI_UPDATE_H__
#define __DVI_HDMI_UPDATE_H__

#include "dvi_hdmi.h"

/** 
	Convert audio settings into a configuration for the HDMI output
	
	@param SampleRate        The respective audio option struct member
	@param mclk              The respective audio option struct member
	@param OutputChannels    The respective audio option struct member
	@param OutputLfe         The respective audio option struct member
	@param Spdif             The respective audio option struct member
	@param Codec             The respective audio option struct member
	@param HDMIPassThrough   The respective audio option struct member
	@param HDMIPassThroughI2SLines  The respective audio option struct member
	@param HBR_Enable        The respective audio option struct member
	@param HBR_Compressed    The respective audio option struct member
	@param HBR_HeaderID      The respective audio option struct member
	@param pDBC              The DBC blocks parsed from the current EDID
	@param nDBC              Number of DBC blocks in pDBC
	@param NumChannel   Number of audio channels (2..8: force channel number, 0: detect from OutputChannels)
	@param LowFreqChannel_3  TRUE if Low Frequency Effect audio is on channel 3
	@param FrontCenterChannel_4  TRUE if Front Center audio is on channel 4
	@param FrontLeftRightCenterChannels_7_8  If LeftCenter/RightCenter channels exist, are they in the Front(TRUE) or Rear(FALSE)?
	@param pAudioFormat     return value
	@param pAudioInfoFrame  return value
	@param pSupports_AI     return value
	See EIA/CEA-861-B Table 22 for possible channel assignments
*/
RMstatus convert_hdmi_audio_options(
	RMuint32 SampleRate, 
	enum MClkFactor mclk, 
	enum AudioOutputChannels_type OutputChannels, 
	RMbool OutputLfe, 
	enum OutputSpdif_type Spdif, 
	enum AudioDecoder_Codec_type Codec, 
	RMbool HDMIPassThrough, 
	RMuint32 HDMIPassThroughI2SLines, 
	RMbool HBR_Enable, 
	RMbool HBR_Compressed, 
	RMuint32 HBR_HeaderID, 
	struct CEA861BDataBlockCollection *pDBC, 
	RMuint32 nDBC, 
	RMuint32 NumChannel, 
	RMbool LowFreqChannel_3, 
	RMbool FrontCenterChannel_4, 
	RMbool FrontLeftRightCenterChannels_7_8, 
	struct DH_AudioFormat *pAudioFormat, 
	struct DH_AudioInfoFrame *pAudioInfoFrame, 
	RMbool *pSupports_AI);

/** 
	Apply audio settings to the HDMI output
	
	@param pDH
	@param pAudioFormat
	@param pAudioInfoFrame
	@param Supports_AI
	@param AudioCP
	@param ChannelStat
	@param ChannelMask
*/
RMstatus apply_hdmi_audio(
	struct DH_control *pDH, 
	struct DH_AudioFormat *pAudioFormat, 
	struct DH_AudioInfoFrame *pAudioInfoFrame, 
	RMbool Supports_AI, 
	RMbool AudioCP, 
	RMuint32 ChannelStat, 
	RMuint32 ChannelMask);


/**
  Read the current status of the video and audio outputs and set up the HDMI connection accordingly
  
  @param  pDH                  DH handle
  @param  AudioEngineModuleID  ModuleID of the audio engine sending audio to the HDMI chip, e.g. EMHWLIB_MODULE(AudioEngine, 0)
  @param  AudioDecoderModuleID ModuleID of the audio decoder sending audio to the HDMI chip, e.g. EMHWLIB_MODULE(AudioDecoder, 0)
  @param  VideoOutputModuleID  ModuleID of the video output sending video to the HDMI chip, e.g. EMHWLIB_MODULE(DispDigitalOut, 0)
*/
RMstatus hdmi_update(struct DH_control *pDH, 
	RMuint32 AudioEngineModuleID, 
	RMuint32 AudioDecoderModuleID, 
	RMuint32 VideoOutputModuleID);

#endif // __DVI_HDMI_UPDATE_H__
