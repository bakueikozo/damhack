#ifndef RM_CCPARSE_H_
#define RM_CCPARSE_H_

#include "rmdef/rmdef.h"
#include "emhwlib/include/emhwlib.h"

typedef struct rmbcc rmbcc_t;

rmbcc_t *rmbcc_create        (void);
RMstatus rmbcc_destroy       (rmbcc_t *);

RMbool   rmbcc_is_open       (rmbcc_t *);
RMstatus rmbcc_open          (rmbcc_t *, RMnonAscii *);
RMstatus rmbcc_close         (rmbcc_t *);

RMstatus rmbcc_get_next_entry(rmbcc_t *, struct CCFifo_CCEntry_type *);

#endif /* RM_CCPARSE_H_ */
