/*****************************************
 Copyright � 2006
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   play_psfdemux_helper.c
  @brief  
  
  Helper function for play_psfdemux

  @author Julien Lerouge
  @date   2006-02-14
*/
#include "play_psfdemux_helper.h"
#include "dcc/src/dcc_common.h"

#if 0
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

RMstatus PSFOpenDemuxTask(struct DCC *pDCC, 
			  struct PSFDemuxTaskProfile *dcc_profile,
			  struct DCCDemuxTask **ppDemuxTask)
{
	RMstatus err = RM_OK;
	RMuint32 demux_task = 0;
	struct DemuxTask_DRAMSizeX_in_type dram_in;
	struct DemuxTask_DRAMSize_out_type dram_out;
	struct DemuxTask_OpenX_type profile;

	*ppDemuxTask = (struct DCCDemuxTask *) RMMalloc(sizeof(struct DCCDemuxTask));
	if (*ppDemuxTask == NULL) {
		RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in system memory %lu!\n", sizeof(struct DCCDemuxTask)));
		return RM_FATALOUTOFMEMORY;
	}

	RMMemset((void*)(*ppDemuxTask), 0, sizeof(struct DCCDemuxTask));

	(*ppDemuxTask)->pRUA = pDCC->pRUA;
	(*ppDemuxTask)->pDCC = pDCC;
	
	demux_task = EMHWLIB_MODULE(DemuxTask, dcc_profile->DemuxTaskID);
	(*ppDemuxTask)->demux_task_moduleID = demux_task;
	
	dram_in.ProtectedFlags = dcc_profile->ProtectedFlags;
	dram_in.BitstreamFIFOSize = dcc_profile->BitstreamFIFOSize;
	dram_in.XferFIFOCount = dcc_profile->XferFIFOCount;
	dram_in.InbandFIFOCount = dcc_profile->InbandFIFOCount;
	dram_in.XTaskModuleId = dcc_profile->XTaskModuleId;
	dram_in.XTaskInbandFIFOCount = dcc_profile->XTaskInbandFIFOCount;

	err = RUAExchangeProperty(pDCC->pRUA, demux_task, RMDemuxTaskPropertyID_DRAMSizeX, &dram_in, sizeof(dram_in), &dram_out, sizeof(dram_out));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting property RMDemuxTaskPropertyID_DRAMSizeX! %s\n", RMstatusToString(err)));
		return err;
	}
	
	profile.ProtectedFlags = dram_in.ProtectedFlags;
	profile.BitstreamFIFOSize = dram_in.BitstreamFIFOSize;
	profile.XferFIFOCount = dram_in.XferFIFOCount;
	profile.InbandFIFOCount = dram_in.InbandFIFOCount;
	
	profile.InputPort = dcc_profile->InputPort;
	profile.PrimaryMPM = dcc_profile->PrimaryMPM;
	profile.SecondaryMPM = dcc_profile->SecondaryMPM;

	profile.BitstreamProtectedAddress = 0;
	profile.BitstreamProtectedSize = dram_out.BitstreamProtectedSize;

	profile.XTaskModuleId = dcc_profile->XTaskModuleId;
	profile.XTaskContext = dcc_profile->XTaskContext;
	profile.XTaskInbandFIFOCount = dcc_profile->XTaskInbandFIFOCount;

	if (profile.BitstreamProtectedSize > 0) {
		profile.BitstreamProtectedAddress = DCCMalloc(pDCC, pDCC->dram, RUA_DRAM_CACHED, profile.BitstreamProtectedSize);
		if (!profile.BitstreamProtectedAddress) {
			RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in cached DRAM %lu!\n", profile.BitstreamProtectedSize, 0L));
			return RM_FATALOUTOFMEMORY;
		}
		RMDBGLOG((LOCALDBG, "demux_task cached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
			profile.BitstreamProtectedAddress, profile.BitstreamProtectedSize, profile.BitstreamProtectedAddress + profile.BitstreamProtectedSize));
	}	
	(*ppDemuxTask)->protected_address = profile.BitstreamProtectedAddress;
	
	profile.UnprotectedAddress = 0;
	profile.UnprotectedSize = dram_out.UnprotectedSize;
	if (profile.UnprotectedSize > 0) {
		profile.UnprotectedAddress = DCCMalloc(pDCC, pDCC->dram, RUA_DRAM_UNCACHED, profile.UnprotectedSize);
		if (!profile.UnprotectedAddress) {
			RMDBGLOG((ENABLE, "ERROR: could not allocate 0x%08lX bytes in uncached DRAM %lu!\n", profile.UnprotectedSize, 0L));
			return RM_FATALOUTOFMEMORY;
		}
		RMDBGLOG((LOCALDBG, "demux_task uncached addr: 0x%08lX, size 0x%08lX, end: 0x%08lX\n",
			profile.UnprotectedAddress, profile.UnprotectedSize, profile.UnprotectedAddress + profile.UnprotectedSize));
	}	
	(*ppDemuxTask)->unprotected_address = profile.UnprotectedAddress;

	DCCSP(pDCC->pRUA, demux_task, RMDemuxTaskPropertyID_OpenX, &profile, sizeof(profile));
	
	return RM_OK;
}
