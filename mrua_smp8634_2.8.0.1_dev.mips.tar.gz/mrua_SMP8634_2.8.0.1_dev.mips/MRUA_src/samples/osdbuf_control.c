/*
 *
 * Copyright (c) Sigma Designs, Inc. 2002. All rights reserved.
 *
 */

/**
 * @file osdbuf_control.c
 * @brief application to control OSD buffers on 86XX
 * 
 * @author Julien Lerouge
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <getopt.h>

#define ALLOW_OS_CODE 1
#include "../dcc/include/dcc.h"
#include "common.h"
#include "osdlib.h"
#include "../rmcore/include/rmcore.h"
#include "../mambolfb/mambolfb.h"

/* For debug/verbose output */
#if 0
#define DEB(f) (f)
#else
#define DEB(f)
#endif

/* Default values */
#define DEFAULT_OSD_WIDTH 640
#define DEFAULT_OSD_HEIGHT 480
#define DEFAULT_OSD_COLOR_MODE EMhwlibColorMode_TrueColor
#define DEFAULT_OSD_COLOR_FORMAT EMhwlibColorFormat_32BPP
#define DEFAULT_OSD_CHIP 0

#define OSDGET_RUASP(pRUA, moduleID, propertyID, pValue, ValueSize)                                                    	\
{															\
	if (RMFAILED(get_osd_infos(&my_osd))){										\
		fprintf(stderr,"Error getting OSD buffer parameters.\n");						\
		goto wayout;												\
	}else if (my_osd.LumaSize == 0 && my_osd.ChromaSize == 0){							\
		fprintf(stderr,"No OSD buffer detected.\n");								\
		goto wayout;												\
	}else{														\
        	while ((status = RUASetProperty(pRUA, moduleID, propertyID, pValue, ValueSize, 0)) == RM_PENDING);	\
		DEB(fprintf(stderr,"Set property %d on module %ld, %d\n", propertyID, moduleID, status));		\
        	if (status != RM_OK) {                                                                                  \
        	        RMDBGLOG((ENABLE, "Cannot set Property %d on module %d, %d\n", propertyID, moduleID, status));  \
        	        goto wayout;                                                                                    \
        	}													\
	}														\
}

#define RUASP(pRUA, moduleID, propertyID, pValue, ValueSize)                           		                \
{														\
	while ((status = RUASetProperty(pRUA, moduleID, propertyID, pValue, ValueSize, 0)) == RM_PENDING);      \
	DEB(fprintf(stderr,"Set property %d on module %ld, %d\n", propertyID, moduleID, status));		\
	if (status != RM_OK) {                                                                                  \
		RMDBGLOG((ENABLE, "Cannot set Property %d on module %d, %d\n", propertyID, moduleID, status));  \
		goto wayout;                                                                                    \
	}													\
}


extern struct osd_format_string_s osd_color_mode_string[EMhwlibColorMode_TrueColorWithKey];
extern struct osd_format_string_s osd_color_format_string[EMhwlibColorFormat_16BPP_4444];

/* Globals*/
static struct display_cmdline disp_opt;
static RMuint32 command = 0;

static void print_osd_info(struct osd_descriptor *p_osd)
{
	if (p_osd == NULL)
		return;
	
	if (p_osd->LumaSize){
		DEB(fprintf(stderr,"LumaAddr :\n"));
		fprintf(stdout,"  videomemory=0x%08lx videomemorysize=%ld palette=0x%x mode=%ld:%ld:%ld\n",
		        p_osd->LumaAddr, p_osd->LumaSize, BASE_PALETTE, p_osd->profile.Width, p_osd->profile.Height, 
		        p_osd->bpp);
	}
	
	if (p_osd->ChromaSize){
		DEB(fprintf(stderr,"ChromaAddr :\n"));
		fprintf(stdout,"  videomemory=0x%08lx videomemorysize=%ld palette=0x%x mode=%ld:%ld:%ld\n",
		        p_osd->ChromaAddr, p_osd->ChromaSize, BASE_PALETTE, p_osd->profile.Width, p_osd->profile.Height, 
		        p_osd->bpp);
	}
	
	if (p_osd->ChromaSize == 0 && p_osd->LumaSize == 0){
		fprintf(stdout,"No persistent OSD buffer registered\n");
	}
}

/** Cleanup
 */
static void cleanup(void *param)
{
	RMstatus err;
	struct osd_descriptor *my_osd=(struct osd_descriptor *)param;

	if (my_osd == NULL)
		return;

	if (my_osd->dcc_info.pDCC){
		err = DCCClose(my_osd->dcc_info.pDCC);
		if (RMFAILED(err))
			fprintf(stderr, "Cannot close DCC %d\n", err); 
	}

	if (my_osd->dcc_info.pRUA){
		err = RUADestroyInstance(my_osd->dcc_info.pRUA);
		if (RMFAILED(err))
			fprintf(stderr, "Cannot destroy RUA instance %d\n", err);
	}

	DEB(fprintf(stderr,"end cleanup\n"));
}



static void osdbuf_control_usage (RMascii *name)
{
	RMuint32 i;
	
	fprintf(stderr,
	        "Usage :\n"
	        "\t%s [DISPLAY OPTIONS] -c[withxheigt] [-F <format:subformat>]\n"
	        "\t\tto create an OSD buffer\n"
	        "\t%s -p\n"
	        "\t\tto print parameters suitable for mambolfb\n"
	        "\t%s -d\n"
	        "\t\tto delete current OSD buffer\n"
	        "\t%s -i\n"
	        "\t\tto get full info on current OSD buffer\n"
	        "\t%s -x <fb device>\n"
		"\t\tto bind the current OSD buffer to a frame buffer device\n"
	        "\t%s -X <fb device>\n"
	        "\t\tto unbind the current OSD buffer from a frame buffer device\n"
	        "\t%s [-k <r,g,b:range>] [-e <0|1>] [-t <2|4>] [-l <c:a>] \n"
	        "\t\t[-0 <level>] [-1 <level>] [-z <x,y>] [-a <0|1>] [-O <0|1>]\n"
	        "\t\t[-C <csc>]\n"
	        "\t\tto tune the OSD buffer\n\n",
 		name, name, name, name, name, name, name);
	show_display_options();
	fprintf(stderr,"\nOSD specific options :\n"
	        "\t-0 set alpha0 level\n"
	        "\t-1 set alpha1 level\n"
	        "\t-a enable/disable fading\n"
	        "\t-m chip number\n"
	        "\t-e activate direction estimation in adaptive scaler\n"
	        "\t-d delete current OSD buffer\n"
	        "\t-i get complete info on current buffer\n"
	        "\t-k set the key color to (r,g,b) with given range (0->15).\n"
	        "\t   Matching range for each component : [keycolor, keycolor + 2 ^ range [\n"
	        "\t-l set anti flicker level for color and alpha (color:alpha)\n"
	        "\t   0 (no filtering) -> 3 (strong filtering)\n"
	        "\t-c create a new OSD buffer of size widhtxheight (%dx%d by default)\n"
	        "\t-p get OSD parameters suitable for mambolfb\n"
	        "\t-t set the number of taps used by adaptive scaler\n"
	        "\t-O enable/disable the OSD channel\n"
	        "\t-F color mode : color format to use (default %s:%s) \n"
	        "\t   color modes (for lut or tc selection) :\n",
		DEFAULT_OSD_WIDTH, DEFAULT_OSD_HEIGHT,
		osd_color_mode_string[DEFAULT_OSD_COLOR_MODE].name,
		osd_color_format_string[DEFAULT_OSD_COLOR_FORMAT].name);
	for (i=1;i<=EMhwlibColorMode_TrueColorWithKey;i++)
		if (osd_color_mode_string[i].name[0])
			fprintf(stderr,"\t\t%-12s - %s\n",osd_color_mode_string[i].name, osd_color_mode_string[i].comment);
	fprintf(stderr,"\t   color formats (for pixel or lut format selection) :\n");
	for (i=1;i<=EMhwlibColorFormat_16BPP_4444;i++)
		if(osd_color_format_string[i].name[0])
			fprintf(stderr,"\t\t%-12s - %s\n",osd_color_format_string[i].name, osd_color_format_string[i].comment);
	 fprintf(stderr,
	        "\t-x Bind the OSD buffer to the given frame buffer device\n"
		"\t-X Unbind the OSD buffer from the given frame buffer device\n");
	fprintf(stderr,"\n");
	exit(EXIT_FAILURE);
}

static void parse_cmdline(int argc, char *argv[], struct osd_descriptor *osd)
{
	int i,j;
	RMstatus err;
	int args;
	int cs_set=0;

	if (osd == NULL)
		exit(EXIT_FAILURE);
	
	if (argc < 2) 
		osdbuf_control_usage(argv[0]);

	/* Init the default osd descriptor */
	osd->profile.SamplingMode = EMhwlibSamplingMode_444;
	osd->profile.ColorMode = DEFAULT_OSD_COLOR_MODE;
	osd->profile.ColorFormat = DEFAULT_OSD_COLOR_FORMAT;
	osd->profile.ColorSpace = EMhwlibColorSpace_RGB_0_255;
	osd->profile.PixelAspectRatio.X = 4;
	osd->profile.PixelAspectRatio.Y = 3;
	osd->dcc_info.route = DCCRoute_Main; 
	osd->dcc_info.disp_info->osd_enable[0] = TRUE;
	osd->chip_num = DEFAULT_OSD_CHIP;

	i = 1;
        while (i < argc) {
		j = i;
		err = parse_display_cmdline(argc, argv, &i, &disp_opt);
		if (err == RM_ERROR){
			fprintf(stderr,"Error parsing display options.\n");
			osdbuf_control_usage(argv[0]);
		}
		if (err == RM_PENDING)
			i++;
		if (err == RM_OK){
			RMint32 k;
			for (k = j; k <i; k++)
				argv[k]="-?";
		}
	}

	/* Check duplicate parameter name since -cs was added and customer want
	 * stable command usage ... */
	for (i=1 ; i<argc; i++){
		if (! strcmp("-cs",argv[i])){
			cs_set=1;
			osd->profile.ColorSpace = disp_opt.color_space;
			break;
		}
	}
	
	/* Ok, parse command line now */
	while (( i = getopt(argc,argv, "c::l:p?idF:k:e:t:0:1:z:a:O:C:x:X:")) != EOF )
		switch(i){
		case '?': //skip it
			break;
		case 'c':
			if (optarg){
				args = sscanf(optarg,"%lux%lu", &osd->profile.Width, &osd->profile.Height);
				if ( args == 2 )
					printf("OSD buffer size : %lux%lu\n",
					       osd->profile.Width,osd->profile.Height);
				else{
					printf("Error parsing OSD size\n");
					osdbuf_control_usage(argv[0]);
				}
			}else{
				osd->profile.Width = DEFAULT_OSD_WIDTH;
				osd->profile.Height = DEFAULT_OSD_HEIGHT;
			}
			command |= OSD_CREATE;
			break;
		case 'F':
			DEB(fprintf(stderr,"F param, optarg=%s\n",optarg));
			if (optarg){
				RMascii osd_color_mode_string[256];
				RMascii osd_color_format_string[256];
				args = sscanf(optarg,"%[^:]:%s",osd_color_mode_string,osd_color_format_string);
				if ( args == 2 && 
				     get_osd_color_mode(osd_color_mode_string, (RMuint32 *)&osd->profile.ColorMode) &&
				     get_osd_color_format(osd_color_format_string, (RMuint32 *)&osd->profile.ColorFormat)){
					printf("OSD format : %s:%s\n",osd_color_mode_string, osd_color_format_string);
					command |= OSD_SET_FORMAT;
					break;
				}
			}
			printf("Error parsing OSD format\n");
			osdbuf_control_usage(argv[0]);
			break;
		case 'p':
			command |= OSD_GET_PARAMS;
			break;
		case 'd':
			command |= OSD_DEL;
			break;
		case 'i':
			command |= OSD_GET_INFOS;
			break;
		case 'm':
			args = sscanf(optarg,"%ld",&osd->chip_num);
			if ( args == 1 )
				printf("OSD chip number : %ld",osd->chip_num);
			else{
				printf("Error parsing chip number\n");
				osdbuf_control_usage(argv[0]);
			}
			break;
		case 'k':
			args = sscanf(optarg,"%lu,%lu,%lu:%lu", &osd->kcolor.R_Cr, 
				      &osd->kcolor.G_Y, &osd->kcolor.B_Cb, 
				      &osd->kcolor.Range); 
			if ( args == 4 ){
				CROP(osd->kcolor.Range,8);
				CROP(osd->kcolor.R_Cr,255);
				CROP(osd->kcolor.G_Y,255);
				CROP(osd->kcolor.B_Cb,255);
				printf("Key color (R/Cr,G/Y,B/Cb) : [%lu,%lu[, [%lu,%lu[, [%lu,%lu[\n", 
				       osd->kcolor.R_Cr, 
				       CROPV(osd->kcolor.R_Cr+(1<<osd->kcolor.Range), 256),
				       osd->kcolor.G_Y, 
				       CROPV(osd->kcolor.G_Y+(1<<osd->kcolor.Range), 256),
				       osd->kcolor.B_Cb,
				       CROPV(osd->kcolor.B_Cb+(1<< osd->kcolor.Range), 256));
				command |= OSD_SET_KCOLOR;
			}else{
				printf("Error parsing key color\n");
				osdbuf_control_usage(argv[0]);
			}
			break;
		case 'e':
			{
				RMuint32 tmp;
				args = sscanf(optarg,"%lu",&tmp);
				if ( args != 1 ){
					printf("Error parsing adaptive parameter\n");
					osdbuf_control_usage(argv[0]);
				}
				CROP(tmp,1);
				osd->scaling_config.AdaptativeEnable = (RMbool) tmp;
				printf("Direction estimation : %s\n", osd->scaling_config.AdaptativeEnable ?
				       "enabled" : "disabled");
				command |= OSD_SET_ADAPT;
			}
			break;
		case 't':
			args = sscanf(optarg,"%ld",&osd->scaling_config.Taps);
			if ( args != 1 || ( osd->scaling_config.Taps != 2 && osd->scaling_config.Taps != 4 ) ){
				printf("Error parsing taps parameter\n");
				osdbuf_control_usage(argv[0]);
			}
			osd->scaling_config.Taps = ( osd->scaling_config.Taps >> 1 ) - 1;
			printf("Taps : %d\n",osd->scaling_config.Taps ? 4 : 2);
			command |= OSD_SET_TAPS;
			break;
		case 'l':
			args = sscanf(optarg,"%ld:%ld",&osd->scaling_config.AntiFlickerColor,
				      &osd->scaling_config.AntiFlickerAlpha);
			if ( args != 2){
				printf("Error parsing anti flicker parameters\n");
				osdbuf_control_usage(argv[0]);
			}
			CROP(osd->scaling_config.AntiFlickerColor,3);
			CROP(osd->scaling_config.AntiFlickerAlpha,3);
			printf("Color Anti Flicker : %ld\n",osd->scaling_config.AntiFlickerColor);
			printf("Alpha Anti Flicker : %ld\n",osd->scaling_config.AntiFlickerAlpha);
			command |= OSD_SET_ANTIF;
			break;
		case '0':
			args = sscanf(optarg,"%ld",&osd->alpha0);
			if ( args != 1){
				printf("Error parsing alpha0\n");
				osdbuf_control_usage(argv[0]);
			}
			CROP(osd->alpha0,255);
			command |= OSD_SET_A0;
			printf("Alpha0 : %ld\n",osd->alpha0);
			break;
		case '1':
			args = sscanf(optarg,"%ld",&osd->alpha1);
			if ( args != 1){
				printf("Error parsing alpha1\n");
				osdbuf_control_usage(argv[0]);
			}
			CROP(osd->alpha1,255);
			command |= OSD_SET_A1;
			printf("Alpha1 : %ld\n",osd->alpha1);
			break;
		case 'a':
			{
				RMuint32 tmp;
				args = sscanf(optarg,"%lu",&tmp);
				if ( args != 1 ){
					printf("Error parsing fading parameter\n");
					osdbuf_control_usage(argv[0]);
				}
				CROP(tmp,1);
				osd->fading = (RMbool) tmp;
				printf("Fading : %s\n", osd->fading ?
				       "enabled" : "disabled");
				command |= OSD_SET_FADING;
			}
			break;
		case 'O':
			{
				RMuint32 tmp;
				args = sscanf(optarg,"%lu",&tmp);
				if ( args != 1 ){
					printf("Error parsing ouput parameter\n");
					osdbuf_control_usage(argv[0]);
				}
				CROP(tmp,1);
				osd->dcc_info.disp_info->osd_enable[0] = (RMbool) tmp;
				printf("OSD Channel : %s\n", osd->dcc_info.disp_info->osd_enable[0] ?
				       "enabled" : "disabled");
				command |= OSD_SET_OUTPUT;
			}
			break;
		case 'C':
			fprintf(stderr,"Warning : -C is deprecated, use -cs instead\n");
			break;
		case 'x':
			command |= OSD_BIND_FB;
			osd->fb = optarg;
			break;
		case 'X':
			command |= OSD_UNBIND_FB;
			osd->fb = optarg;
			break;
		default :
			osdbuf_control_usage(argv[0]);
		}

	/* Check the command line means something */
	if ( ((command & OSD_DEL) && (command & ~(OSD_DEL|OSD_UNBIND_FB))) ||	//no parameters with delete other than unbind
	     ((command & OSD_GET_INFOS) && (command & ~OSD_GET_INFOS)) ||	//idem for get infos
	     ((command & OSD_GET_PARAMS) && (command & ~OSD_GET_PARAMS)) ||	//idem for get params
	     ((command & OSD_SET_FORMAT) && !(command & OSD_CREATE)) )		//set format allowed only if create
		osdbuf_control_usage(argv[0]);

	/* Init other fields */
	osd->bpp = get_osd_bpp(osd->profile.ColorMode, osd->profile.ColorFormat);
}

/**
 * Unbind the given fb_dev
 * @param fb_dev
 * @return < 0 on error
 */
static int unbind_fb(RMascii *fb_dev)
{
	struct mambolfb_config_s config = {0,0,0,0,0,0};
	int fd;
		
	if (fb_dev == NULL)
		return -1;

	fd = open(fb_dev, O_RDONLY);
	if (fd < 0){
		perror("Error opening Mambo/Tango frame buffer");
		return -1;
	}

	if (ioctl(fd, MAMBOLFBIO_SETBUFFER, &config) < 0){
		perror("Error unbinding OSD buffer from frame buffer device");
		return -1;
	}

	fprintf(stderr,"Frame buffer %s unbound\n", fb_dev);
	return 0;
}

int main(int argc, char *argv[])
{
	RMstatus status = RM_OK;
	struct osd_descriptor my_osd, tmp_osd;
	struct display_context disp_info, tmp_disp_info;
	struct dh_context dh_info = {0,};


	
	status = init_display_options(&disp_opt);
	if (RMFAILED(status)){
		printf("Error initializing display options! %d\n", status);
		goto wayout;
	}
	disp_opt.dh_info = &dh_info;
	
	my_osd.dcc_info.disp_info = &disp_info;
	/* Init the descriptor with the command line*/
	parse_cmdline(argc, argv, &my_osd);

	/*  Catch all temination signals, call RMTermInit() and cleanup(), then exit(0). */
	RMSignalInit(cleanup, (void *) &my_osd);

	DEB(fprintf(stderr,"  RUACreateInstance\n"));
	
	status = RUACreateInstance(&my_osd.dcc_info.pRUA, my_osd.chip_num);
	if (RMFAILED(status)){
		printf("Error creating instance! %d\n", status);
		goto wayout;
	}

	DEB(fprintf(stderr,"  DCCOpen\n"));
	status = DCCOpen(my_osd.dcc_info.pRUA, &my_osd.dcc_info.pDCC);
        if (RMFAILED(status)) {
                fprintf(stderr, "Error Opening DCC! %d\n", status);
		goto wayout;
        }

	/* Keep a copy of the initialized osd for command line parameters */
	memcpy(&tmp_osd, &my_osd, sizeof(my_osd));
	tmp_osd.dcc_info.disp_info = &tmp_disp_info;
	memcpy(&tmp_disp_info, &disp_info, sizeof(disp_info));

	if ((command & OSD_BIND_FB) && (command & OSD_CREATE)){
		/* Create a new buffer and binds it. For safety, undbind the FB
		 * dev first in case it is currently used : we don't want the
		 * FB dev to write in a memory that is not an OSD buffer
		 * anymore */
		if (unbind_fb(my_osd.fb) < 0)
			goto wayout_error;
	}

	if (command & OSD_CREATE){
		struct osd_descriptor current_osd;

		memcpy(&current_osd, &my_osd, sizeof(my_osd));
		if (RMFAILED(get_osd_infos(&current_osd))){
			fprintf(stderr,"Error getting OSD buffer parameters.\n");
			goto wayout_error;
		}

		/* If there is already an OSD buffer registered, delete it */
		if (current_osd.LumaSize || current_osd.ChromaSize){
			RMuint32 surface=0;
			RUASP(current_osd.dcc_info.pRUA, current_osd.dcc_info.disp_info->osd_scaler[0], RMGenericPropertyID_Surface,
				(void *) &surface, sizeof(surface));
		}
		
		DEB(fprintf(stderr,"Creating new buffer\n"));
		
		status = DCCInitChainEx(my_osd.dcc_info.pDCC, disp_opt.init_mode);
		if (RMFAILED(status)) {
			fprintf(stderr, "Cannot initialize microcode %d\n", status);
			goto wayout;
		} 
		
		my_osd.dcc_info.SurfaceID = my_osd.dcc_info.disp_info->osd_scaler[0];
		DEB(fprintf(stderr,"  set_default_out_window\n"));
		set_default_out_window(&(my_osd.dcc_info.disp_info->osd_window[0]));
		my_osd.dcc_info.disp_info->active_window = &(my_osd.dcc_info.disp_info->osd_window[0]);

		status = apply_display_options(&my_osd.dcc_info, &disp_opt);
		if (RMFAILED(status)) {
			fprintf(stderr, "Cannot set display opions %s\n", RMstatusToString(status));
			goto wayout;
		}

		status = create_osd_buf(&my_osd);
		if(RMFAILED(status)){
			fprintf(stderr,"Error creating OSD : %d\n", status);
			goto wayout;
		}
	
		status = DCCGetOSDVideoSourceInfo(my_osd.dcc_info.pOSDSource[0], &my_osd.LumaAddr, &my_osd.LumaSize,
						  &my_osd.ChromaAddr, &my_osd.ChromaSize);
		if (RMFAILED(status)){
			fprintf(stderr,"Error getting OSD source infos\n");
			goto wayout;
		}

		status = DCCEnableVideoSource(my_osd.dcc_info.pOSDSource[0], TRUE);
		if (RMFAILED(status)){
			fprintf(stderr,"Error enabling OSD buffer : %d\n",status);
			goto wayout;
		}
		
		print_osd_info(&my_osd);
	}

	if ( command & OSD_BIND_FB ){
		struct mambolfb_config_s config;
		int fd;
		
		if (RMFAILED(get_osd_infos(&my_osd))){
			fprintf(stderr,"Error getting OSD buffer parameters.\n");
			goto wayout_error;
		}

		if (my_osd.ChromaSize == 0 && my_osd.LumaSize == 0){
			fprintf(stdout,"No persistent OSD buffer registered\n");
			goto wayout_error;
		} else {
			if (my_osd.LumaSize){
				config.videomemory = my_osd.LumaAddr;
				config.videomemorysize = my_osd.LumaSize;
			}else {
				config.videomemory = my_osd.ChromaAddr;
				config.videomemorysize = my_osd.ChromaSize;
			}
			config.palette = BASE_PALETTE;
			config.xres = my_osd.profile.Width;
			config.yres = my_osd.profile.Height;
			config.bits_per_pixel = my_osd.bpp;
		}

		fd = open(my_osd.fb, O_RDONLY);
		if (fd < 0){
			perror("Error opening Mambo/Tango frame buffer");
			goto wayout_error;
		}

		if (ioctl(fd, MAMBOLFBIO_SETBUFFER, &config) < 0){
			perror("Error binding OSD buffer to frame buffer device");
			goto wayout_error;
		}

		fprintf(stderr,"OSD buffer bound to %s.\n",my_osd.fb);
	}

	if ( command & OSD_SET_A0 ){
		DEB(fprintf(stderr,"Alpha0 = %ld\n", tmp_osd.alpha0));
		OSDGET_RUASP(my_osd.dcc_info.pRUA, my_osd.dcc_info.disp_info->osd_scaler[0], RMGenericPropertyID_Alpha0,
		             (void *) &tmp_osd.alpha0, sizeof(tmp_osd.alpha0));
	}

	if ( command & OSD_SET_A1 ){
		DEB(fprintf(stderr,"Alpha1 = %ld\n", tmp_osd.alpha1));
		OSDGET_RUASP(my_osd.dcc_info.pRUA, my_osd.dcc_info.disp_info->osd_scaler[0], RMGenericPropertyID_Alpha1,
		             (void *) &tmp_osd.alpha1, sizeof(tmp_osd.alpha1));
	}
		
	if ( command & OSD_SET_FADING )
		OSDGET_RUASP(my_osd.dcc_info.pRUA, my_osd.dcc_info.disp_info->osd_scaler[0], RMGenericPropertyID_EnableFading,
		             (void *) &tmp_osd.fading, sizeof(tmp_osd.fading));

	if ( command & OSD_SET_OUTPUT )
		OSDGET_RUASP(my_osd.dcc_info.pRUA, my_osd.dcc_info.disp_info->osd_scaler[0],RMGenericPropertyID_Enable,
		             (void *) &tmp_osd.dcc_info.disp_info->osd_enable[0], sizeof(tmp_osd.dcc_info.disp_info->osd_enable[0]));

	if ( command & ( OSD_SET_ADAPT | OSD_SET_ANTIF | OSD_SET_TAPS )) {
		get_osd_infos(&my_osd);
		if ( command & OSD_SET_ADAPT )
			my_osd.scaling_config.AdaptativeEnable = tmp_osd.scaling_config.AdaptativeEnable;
		if ( command & OSD_SET_ANTIF ){
			my_osd.scaling_config.AntiFlickerColor = tmp_osd.scaling_config.AntiFlickerColor;
			my_osd.scaling_config.AntiFlickerAlpha = tmp_osd.scaling_config.AntiFlickerAlpha;
		}
		if ( command & OSD_SET_TAPS )
			my_osd.scaling_config.Taps = tmp_osd.scaling_config.Taps;
		RUASP(my_osd.dcc_info.pRUA, my_osd.dcc_info.disp_info->osd_scaler[0], RMDispOSDScalerPropertyID_ScalingConfig,
		      &my_osd.scaling_config, sizeof(my_osd.scaling_config));
	}

	if ( command & OSD_SET_KCOLOR ){
		get_osd_infos(&my_osd);
		memcpy((void *)&my_osd.kcolor,(void *)&tmp_osd.kcolor, sizeof(my_osd.kcolor));
		RUASP(my_osd.dcc_info.pRUA, my_osd.dcc_info.disp_info->osd_scaler[0], RMGenericPropertyID_KeyColor,
		      &my_osd.kcolor, sizeof(my_osd.kcolor));
	}

	if ( command & OSD_SET_CSC )
		/* FIXME get the mixer from DCC */
		OSDGET_RUASP(my_osd.dcc_info.pRUA, EMHWLIB_MODULE(DispMainMixer,0), RMGenericPropertyID_ColorSpace,
		             (void *) &tmp_osd.profile.ColorSpace, sizeof(tmp_osd.profile.ColorSpace));

	if ( command & OSD_UNBIND_FB ){
		if (unbind_fb(my_osd.fb) <0)
			goto wayout_error;
	}

	if ( command & OSD_DEL ){
		RMuint32 surface=0;
		OSDGET_RUASP(my_osd.dcc_info.pRUA, my_osd.dcc_info.disp_info->osd_scaler[0], RMGenericPropertyID_Surface,
		             (void *) &surface, sizeof(surface));
		fprintf(stderr,"OSD buffer deleted.\n");
	}


	if( command & OSD_GET_INFOS ){
		if (RMFAILED(get_osd_infos(&my_osd)))
			my_osd.LumaAddr = 0;
		printf("===================== Buffer Infos ======================\n");
		print_osd_full_info(&my_osd);
		printf("=========================================================\n");
	}

	if ( command & OSD_GET_PARAMS ){
		get_osd_infos(&my_osd);
		print_osd_info(&my_osd);
	}

	/* Last but not least, validate changes */
	if ( command & ( OSD_SET_KCOLOR | OSD_SET_ADAPT | OSD_SET_TAPS | OSD_SET_ANTIF | 
			 OSD_SET_A0 | OSD_SET_A1 | OSD_SET_FADING | OSD_SET_OUTPUT) ){
		RMuint32 validate=0;
		RUASP(my_osd.dcc_info.pRUA, my_osd.dcc_info.disp_info->osd_scaler[0], RMGenericPropertyID_Validate,
		      (void *)&validate, sizeof(validate));
	}

	if ( command & OSD_SET_CSC ){
		RMuint32 validate=0;
		RUASP(my_osd.dcc_info.pRUA, EMHWLIB_MODULE(DispMainMixer,0), RMGenericPropertyID_Validate,
		      (void *)&validate, sizeof(validate));
	}
	
 wayout:
	cleanup((void *)&my_osd);
	DEB(fprintf(stderr,"end main\n"));
	if (RMFAILED(status))
		return EXIT_FAILURE;
	return EXIT_SUCCESS;
	
 wayout_error:
	status = RM_ERROR;
	goto wayout;

	return EXIT_SUCCESS;
}

