#include "bcc.h"

#include "rmdef/rmdef.h"

#define BCC_MAX_RUN	(255)
#define CC_FEED_ENABLE	DISABLE

RMstatus bcc_feed(struct bcc *pbcc, struct RUA *pRUA, RMuint64 preroll)
{
	RMstatus status = RM_OK;
	RMbool keep_feeding = TRUE;
	RMuint8 counter = 0;
	
	while (keep_feeding)
	{
		if (pbcc->CCentry_consumed)
		{
			RMDBGLOG((CC_FEED_ENABLE, "Previous entry consumed, getting a new one.\n"));
			status = rmbcc_get_next_entry(pbcc->bcc_parser, &pbcc->plast_CCentry);

			if (RM_ERRORENDOFFILE == status)
			{
				RMDBGLOG((CC_FEED_ENABLE, "At end of file, no more entries to get.\n"));
				keep_feeding = FALSE;
			}
			else
			{
				/* Not a hack (!): offsetting PTS by the preroll value */
				if (pbcc->plast_CCentry.Pts <= preroll)
				{
					pbcc->plast_CCentry.Pts = 0;
				}
				else
				{
					pbcc->plast_CCentry.Pts -= preroll;
				}
				RMDBGLOG((CC_FEED_ENABLE, "Got new entry\n"));
				pbcc->CCentry_consumed = FALSE;
			}
		}
		/* else, an entry should already be available in pbcc->plast_CCentry */

		if (! pbcc->CCentry_consumed)
		{
			status = RUASetProperty(pRUA, pbcc->ccfifo_id, RMCCFifoPropertyID_CCEntry,
				&pbcc->plast_CCentry, sizeof pbcc->plast_CCentry, 0);

			if (RM_PENDING != status)
			{
				RMDBGLOG((CC_FEED_ENABLE, 
					"Entry successfully dumped into the FIFO.\n"));
				pbcc->CCentry_consumed = TRUE;
				counter += 1;
			}
			else
			{
				RMDBGLOG((CC_FEED_ENABLE, "FIFO full, keeping entry for later.\n"));
				keep_feeding = FALSE;
			}
		}

		if (counter >= BCC_MAX_RUN) keep_feeding = FALSE;
	}
	RMDBGLOG((ENABLE, "Fed %u entries to the FIFO.\n", counter));

	return status;
}
