/*
 *
 * Copyright (c) Sigma Designs, Inc. 2002. All rights reserved.
 *
 */

/**
	@file play_jpeg_422.c
	@brief sample application to access the Mambo chip and display a JPEG picture on the graphic plane
	
	@author Pascal Cannenterre
   	@ingroup dccsamplecode
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define ALLOW_OS_CODE 1
#include "common.h"
#include "libjpeg/jpeglib.h"

#define KEYFLAGS (SET_KEY_DISPLAY | SET_KEY_PLAYBACK)

char *filename = (char *) NULL;

struct playback_cmdline play_opt;
struct display_cmdline disp_opt;
struct video_cmdline video_opt;

static void show_usage(char *progname)
{
	show_display_options();
	show_video_options();
	
	fprintf(stderr, "--------------------------------\n");
	fprintf(stderr, "Minimum cmd line: %s <file name>\n", progname);
	fprintf(stderr, "--------------------------------\n");

	exit(1);
}

static void parse_cmdline(int argc, char *argv[])
{
	RMint32 i;
	RMstatus err;

	if (argc < 2) 
		show_usage(argv[0]);
	
	i = 1;
	while ((argc > i)) {
		if (argv[i][0] != '-') {
			if (filename == NULL) {
				filename = argv[i];
				i++;
			}
			else
				show_usage(argv[0]);
		}
		else {
			err = parse_playback_cmdline(argc, argv, &i, &play_opt);
			if (err == RM_ERROR) 
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_display_cmdline(argc, argv, &i, &disp_opt);
			if (err == RM_ERROR) 
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_video_cmdline(argc, argv, &i, &video_opt);
			if (RMFAILED(err))
				show_usage(argv[0]);
		}
	}

	if (filename == NULL)
		show_usage(argv[0]);
}

static void myjpeg_error_exit(j_common_ptr cinfo)
{
	RMDBGLOG((ENABLE, "JPEG error: \n  "));
	(*cinfo->err->output_message)(cinfo);
	jpeg_destroy(cinfo);
	exit(1);
}

int main(int argc, char *argv[])
{
	FILE *fd;
	struct jpeg_decompress_struct cinfo;
	struct jpeg_error_mgr jerr;
	RMuint32 JpegWidth;
	RMuint32 JpegHeight;
	RMuint32 yuvWidth1;
	RMuint32 yuvHeight1;
	struct DCC *pDCC = NULL;
	struct DCCVideoSource *pOSDSource = NULL;
	struct DCCOSDProfile osd_profile = {0,};
	struct RUA *pRUA = NULL;
	RMstatus err;
	RMuint32 surfaceID;
	static struct dcc_context dcc_info = {0,};
	
	init_display_options(&disp_opt);
	init_video_options(&video_opt);

	parse_cmdline(argc, argv);

	err = RUACreateInstance(&pRUA, play_opt.chip_num);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error creating RUA instance! %d\n", err);
		return -1;
	}
	
	err = DCCOpen(pRUA, &pDCC);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error Opening DCC! %d\n", err);
		return -1;
	}

	err = DCCInitChain(pDCC);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot initialize microcode %d\n", err);
		goto cleanup2;
	}
	
	dcc_info.pRUA = pRUA;
	dcc_info.pDCC = pDCC;
	dcc_info.pDH = NULL;
	dcc_info.route = DCCRoute_Main;

	set_default_out_window(&(dcc_info.out_window));
	set_default_out_window(&(dcc_info.osd_window));

	dcc_info.active_window = &(dcc_info.osd_window);
     
	err = apply_display_options(&dcc_info, &disp_opt);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot set display options %d\n", err);
		goto cleanup2;
	}
	/* reading JPEG header and getting ready to decompress image */

	fd = fopen(filename, "rb");
	if (fd == NULL) {
		fprintf(stderr, "Bitmap file not found: %s\n", filename);
		goto cleanup2;
	}
	
	RMMemset(&cinfo, 0, sizeof(cinfo));
	cinfo.err = jpeg_std_error(&jerr);
	cinfo.err->error_exit = myjpeg_error_exit;
	jpeg_create_decompress(&cinfo);
	jpeg_stdio_src(&cinfo, fd);
	jpeg_read_header(&cinfo, TRUE);
	
	if (cinfo.progressive_mode) {
		fprintf(stderr, "jpeg file must not be in progressive mode\n");
		jpeg_destroy_decompress (&cinfo);
		fclose(fd);
		goto cleanup2;
	}
	if (cinfo.jpeg_color_space == JCS_GRAYSCALE || cinfo.jpeg_color_space == JCS_YCbCr) {
		cinfo.out_color_space = cinfo.jpeg_color_space;
		osd_profile.ColorSpace = EMhwlibColorSpace_YUV_601;
	} else {
		fprintf(stderr, "jpeg file needs to be in YUV color space\n");
		jpeg_destroy_decompress (&cinfo);
		fclose(fd);
		goto cleanup2;
	}
	if ((cinfo.image_width <= 0) || (cinfo.image_height <= 0)) {
		fprintf(stderr, "illegal image size: %d x %d pixel\n", cinfo.image_width, cinfo.image_height);
		jpeg_destroy_decompress (&cinfo);
		fclose(fd);
		goto cleanup2;
	}
	
	cinfo.dct_method = JDCT_IFAST;
	cinfo.scale_num = 1;
	cinfo.scale_denom = 1;
	cinfo.quantize_colors = FALSE;
	jpeg_start_decompress(&cinfo);
	
	JpegWidth  = cinfo.output_width;
	JpegHeight = cinfo.output_height;
	yuvWidth1  = (JpegWidth  + 15) & ~0xF;
	yuvHeight1 = (JpegHeight + 15) & ~0xF;
	
	fprintf(stdout, "\nOriginal JPEG image %lu x %lu pixels\n", 
		JpegWidth, 
		JpegHeight);
	fprintf(stdout, "Displayed image will be %lu x %lu pixels\n\n", 
		yuvWidth1, 
		yuvHeight1);
	
	osd_profile.SamplingMode = EMhwlibSamplingMode_422;
	osd_profile.ColorMode = EMhwlibColorMode_VideoNonInterleaved;
	osd_profile.ColorFormat = EMhwlibColorFormat_32BPP;
	osd_profile.PixelAspectRatio.X = 4;
	osd_profile.PixelAspectRatio.Y = 3;
	osd_profile.Width = yuvWidth1;
	osd_profile.Height = yuvHeight1;

	err = DCCOpenOSDVideoSource(pDCC, &osd_profile, &pOSDSource);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot open OSD decoder %d\n", err);
		goto cleanup2;
	}
	
	err = DCCClearOSDVideoSource(pOSDSource);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot clear OSD decoder %d\n", err);
		goto cleanup;
	}

	err = DCCGetScalerModuleID(pDCC, dcc_info.route, DCCSurface_OSD, 2, &surfaceID);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot get surface to display video source %d\n", err);
		goto cleanup;
	}

#define UV_FACTOR 1

	{
		RMuint32 i = 0, readline = 0;
		JSAMPARRAY pxline = (JSAMPARRAY)NULL;
		RMuint8 * Yline = (RMuint8 *)NULL;
		RMuint8 * UVline = (RMuint8 *)NULL;
		RMuint32 LumaAddr = 0, ChromaAddr = 0;
		RMuint32 LumaSize = 0, ChromaSize = 0;
		
		err = DCCGetOSDVideoSourceInfo(pOSDSource, &LumaAddr, &LumaSize, &ChromaAddr, &ChromaSize);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot get info om OSD plan/source %d\n", err);
			goto cleanup;
		}
		fprintf(stderr,"[DEBUG]Luma/Chroma buffer size : %d/%d \n",(int)LumaSize,(int)ChromaSize);
		fprintf(stderr,"[DEBUG]Minimum lines : %d \n",(int)cinfo.rec_outbuf_height);
		
		pxline = (JSAMPARRAY) RMMalloc(sizeof(JSAMPROW));
		pxline[0] = (JSAMPROW) RMMalloc(cinfo.output_width*cinfo.output_components*sizeof(JSAMPLE));
		Yline = (RMuint8 *)RMMalloc(cinfo.output_width*sizeof(RMuint8));
		UVline = (RMuint8 *)RMMalloc(UV_FACTOR*cinfo.output_width*sizeof(RMuint8));
		if( pxline && pxline[0] && Yline && UVline) {
			while(cinfo.output_scanline < cinfo.output_height) {
				// fprintf(stderr,"[DEBUG]scanline : %d\n",(int)cinfo.output_scanline);
				readline = jpeg_read_scanlines(&cinfo, pxline ,1);
				if( readline != 1 ) {
					fprintf(stderr,"jpeg_read_scanlines problem, read %d lines ...\n", (int)readline);
					break;
				}
				for(i=0; i < cinfo.output_width;i++) {
					Yline[i] = pxline[0][3*i];
					// UVUV 4:2:2
					if(i%2 == 0) {
						UVline[i] = (pxline[0][3*i+1])>>1;
						UVline[i+1] = (pxline[0][3*i+2])>>1;
					} else {
						UVline[i-1] += (pxline[0][3*i+1])>>1;
						UVline[i] += (pxline[0][3*i+2])>>1;
					}
				}
				
				err = DCCSetOSDLumaSource(pOSDSource,
							  (LumaAddr + (cinfo.output_width*cinfo.output_scanline)),
							  Yline, cinfo.output_width);
				if (RMFAILED(err)) {
					fprintf(stderr, "Cannot write to Luma buffer %d\n", err);
					break;
				}
				
				err = DCCSetOSDChromaSource(pOSDSource,
							    (ChromaAddr + (UV_FACTOR*cinfo.output_width*cinfo.output_scanline)),
							    UVline, UV_FACTOR*cinfo.output_width);
				if (RMFAILED(err)) {
					fprintf(stderr, "Cannot write to Chroma buffer %d\n", err);
					break;
				}
			}
			RMFree(pxline[0]); RMFree(pxline);
			RMFree(Yline); RMFree(UVline);
		} else
			fprintf(stderr,"Trouble with RMMalloc() ...\n");
	}

	jpeg_finish_decompress(&cinfo);
	jpeg_destroy_decompress(&cinfo);
	 
	fclose(fd);

	err = DCCSetSurfaceSource(pDCC, surfaceID, pOSDSource);
	if (RMFAILED(err)) {
			fprintf(stderr, "Cannot set the surface source %d\n", err);
			goto cleanup;
	}
	dcc_info.pOSDSource = pOSDSource;
	dcc_info.osd_scaler = surfaceID;
	dcc_info.osd_enable = TRUE;
	display_key_usage(KEYFLAGS);

	do {
		RMuint32 cmd;
		err = process_key(&dcc_info, &cmd, KEYFLAGS);
		if (RMFAILED(err)) {
			fprintf(stderr, "Error while processing key %d\n", err);
			break;
		}
		switch(cmd) {
		case RM_QUIT:
		case RM_STOP:
			goto cleanup;
			break;
		default:
			usleep(50*1000);
			break;
		}
		update_hdmi(&dcc_info, &disp_opt, NULL);
	} while(1);

cleanup:	
	err = DCCCloseVideoSource(pOSDSource);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error cannot close video decoder %d\n", err);
		return -1;
	}

cleanup2:
	
	clear_display_options(&dcc_info, &disp_opt);
	
	err = DCCClose(pDCC);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot close DCC %d\n", err);
		return -1;
	}

	err = RUADestroyInstance(pRUA);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot destroy RUA instance %d\n", err);
		return -1;
	}

	return 0;
}

