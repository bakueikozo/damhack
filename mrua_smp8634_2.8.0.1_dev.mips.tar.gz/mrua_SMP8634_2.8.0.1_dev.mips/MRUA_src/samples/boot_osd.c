/*
 *
 * Copyright (c) Sigma Designs, Inc. 2002. All rights reserved.
 *
 */

/**
	@file boot_osd.c
	@brief sample application to generate files to display a bitmap at boot time 
	
	@author Julien Soulier
   	@ingroup dccsamplecode
*/

#include "sample_os.h"

#define ALLOW_OS_CODE 1
#include "common.h"

#define USERPREF "userpref"
#define BITMAP "bitmap"
#define VSYNCPARAM "vsyncparam"
#define PALETTE "palette"
#define XENV "xenv"
#define _BIN ".bin"
#define _TXT ".txt"
#define TMPFILE_PATTERN "boot_osdXXXXXX"

#define RLED 0x44454c52
#define RAWD 0x44574152
#define CHUNK 4096

#define NO_COMPRESSION   0
#define COMPRESSION_4BPP 1
#define COMPRESSION_7BPP 2

static RMstatus read_memory(struct RUA *pRUA, RMuint32 rua_addr, RMuint32 size, RMuint8 *user_addr)
{
	RMuint32 chunk;
	RMuint8 *BaseAddr;
	RMstatus err;

#if (EM86XX_MODE == EM86XX_MODEID_WITHHOST) || (EM86XX_CHIP>=EM86XX_CHIPID_TANGO2)
	while (size) {
		chunk = RMmin(size, 0x100000);  // 1 MByte max
		
		err = RUALock(pRUA, rua_addr, chunk);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error locking OSD buffer at 0x%08lX (0x%08lX bytes): %d\n", rua_addr, chunk, err));
			return err;
		}
		BaseAddr = RUAMap(pRUA, rua_addr, chunk);
		if (BaseAddr == NULL) {
			RMDBGLOG((ENABLE, "Error mapping OSD buffer at 0x%08lX (0x%08lX bytes)\n", rua_addr, chunk));
			return RM_ERROR;
		}

		RMMemcpy(user_addr, BaseAddr, chunk);	
		
		RUAUnMap(pRUA, BaseAddr, chunk);

		err = RUAUnLock(pRUA, rua_addr, chunk);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error unlocking OSD buffer at 0x%08lX (0x%08lX bytes): %d\n", rua_addr, chunk, err));
			return err;
		}
		rua_addr += chunk;
		size -= chunk;
		user_addr += chunk;
	}
#else
	BaseAddr = (RMuint8 *)rua_addr;
	chunk = 0;
	err = RM_OK;
	RMMemcpy(user_addr, BaseAddr, size);
#endif
	return RM_OK;
}

static RMuint32 get_sum(RMuint8 *buf, RMuint32 size)
{
	RMuint32 sum = 0, i;

	for (i=0 ; i < (size >>2) ; i++ , buf += 4)
		sum += RMleBufToUint32(buf);
	
	if (size & 0x3) {
		RMuint8 c[4] = {0,};
		
		for (i = 0; i < (size & 0x3); i++)
			c[i] = *buf++;
		
		sum += RMleBufToUint32(c);
	}
	
	return sum;
}

#if (EM86XX_CHIP<EM86XX_CHIPID_TANGO2)
static RMstatus write_section_header(int fd, RMuint32 type, RMuint32 addr, RMuint32 size, RMuint32 *sum)
{
	RMuint8 out_buf[4];
	RMint32 len;

	RMuint32ToLeBuf(type, out_buf);
	len = write(fd, out_buf, 4);
	if (len < 4) {
		fprintf(stderr, "Error while writing type field in header! %ld\n", len);
		return RM_ERROR;
	}
	*sum += type;

	RMuint32ToLeBuf(addr, out_buf);
	len = write(fd, out_buf, 4);
	if (len < 4) {
		fprintf(stderr, "Error while writing address field in header! %ld\n", len);
		return RM_ERROR;
	}
	*sum += addr;
	
	RMuint32ToLeBuf(size, out_buf);
	len = write(fd, out_buf, 4);
	if (len < 4) {
		fprintf(stderr, "Error while writing size field in header! %ld\n", len);
		return RM_ERROR;
	}
	*sum += size;
	
	return RM_OK;
}
#endif // EM86XX_CHIP

static RMstatus write_data_chunk(struct RUA *pRUA, int fd, RMuint32 data_addr, RMuint32 data_size, RMuint32 *sum)
{
	RMuint8 out_buf[CHUNK];
	RMuint32 rd_size, wr_size, total_size;
	RMint32 len;
	RMstatus err;

	total_size = 0;
	while (total_size < data_size) {
		rd_size = RMmin(CHUNK, data_size - total_size);
		err = read_memory(pRUA, data_addr + total_size, rd_size, out_buf);
		if (RMFAILED(err)) {
			fprintf(stderr, "Error while reading data section! %d\n", err);
			return err;
		}
		
		*sum += get_sum(out_buf, rd_size);
		
		wr_size = 0;
		while (wr_size < rd_size) {
			len = write(fd, out_buf+wr_size, rd_size-wr_size);
			if (len <= 0) {
				fprintf(stderr, "Error while writing chunk of data section! %ld\n", len);
				return RM_ERROR;
			}
			wr_size += len;
		}			
				
		total_size += rd_size;
	}

	/* alignment on 32 bits */
	while (total_size & 0x3) {
		RMuint8 c=0;
		len = write(fd, &c, 1);
		if (len <= 0) {
			fprintf(stderr, "Error while making data alignment of data section! %ld\n", len);
			return RM_ERROR;
		}
		total_size ++;
	}

	return RM_OK;
}

#if (EM86XX_CHIP<EM86XX_CHIPID_TANGO2)
static RMstatus write_zero_chunk(int fd, RMuint32 data_size)
{
	RMuint8 out_buf[CHUNK];
	RMuint32 rd_size, wr_size, total_size;
	RMint32 len;

	memset(out_buf, 0, CHUNK);
	total_size = 0;
	while (total_size < data_size) {
		rd_size = RMmin(CHUNK, data_size - total_size);
		
		wr_size = 0;
		while (wr_size < rd_size) {
			len = write(fd, out_buf+wr_size, rd_size-wr_size);
			if (len <= 0) {
				fprintf(stderr, "Error while writing chunk of 0! %ld\n", len);
				return RM_ERROR;
			}
			wr_size += len;
		}			
				
		total_size += rd_size;
	}

	return RM_OK;
}
#endif // EM86XX_CHIP

static RMstatus create_vsyncparam(struct RUA *pRUA, RMuint32 vsyncapi_addr, RMuint32 vsyncapi_size, RMascii *dir_name)
{
	RMuint32 sum=0;
	int fd;
	RMstatus err;
	RMascii filename[2048];
	
#if (EM86XX_CHIP<EM86XX_CHIPID_TANGO2)
	snprintf(filename, 2048, "%s/%s%s", dir_name, VSYNCPARAM, _BIN); 
#else
	snprintf(filename, 2048, "%s/%s_0x%08lx%s", dir_name, VSYNCPARAM, vsyncapi_addr, _BIN); 
#endif // EM86XX_CHIP

	fd = open(filename, O_CREAT | O_WRONLY, S_IRWXU | S_IRWXG | S_IRWXO);
	if (fd == -1) {
		fprintf(stderr, "Could not open %s%s\n" , VSYNCPARAM, _BIN);
		return RM_ERROR;
	}

	/* write vsync api buffer */
	err = write_data_chunk(pRUA, fd, vsyncapi_addr, vsyncapi_size - 4, &sum);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot copy the vsync API inside userpref! %d\n", err);
		return err;
	}
	
#if (EM86XX_CHIP<EM86XX_CHIPID_TANGO2)
	{
		RMuint8 out_buf[4];
		RMint32 len;

		/* write sum */
		sum = ~sum + 1;
		RMuint32ToLeBuf(sum, out_buf);
		len = write(fd, out_buf, 4);
		if (len < 4) {
			fprintf(stderr, "Error while writing sum of vsync API! %ld\n", len);
			return RM_ERROR;
		}
	}
#endif // EM86XX_CHIP

	close(fd);
	
	return RM_OK;
}

#if (EM86XX_CHIP<EM86XX_CHIPID_TANGO2)
static RMstatus create_userpref(struct RUA *pRUA, RMuint32 vsyncapi_addr, RMuint32 vsyncapi_size, RMascii *dir_name)
{
	RMuint8 out_buf[CHUNK];
	RMuint32 sum=0;
	RMint32 len;
	int fd;
	RMstatus err;
	RMascii filename[2048];

	snprintf(filename, 2048, "%s/%s%s", dir_name, USERPREF, _BIN); 

	fd = open(filename, O_CREAT | O_WRONLY, S_IRWXU | S_IRWXG | S_IRWXO);
	if (fd == -1) {
		fprintf(stderr, "Could not open %s%s\n" , USERPREF, _BIN);
		return RM_ERROR;
	}

	/* first put to zero first 32KB */
	err = write_zero_chunk(fd, 32768);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot create the first 32KB of userpref! %d\n", err);
		return err;
	}
	
	/* write vsync api buffer */
	err = write_data_chunk(pRUA, fd, vsyncapi_addr, vsyncapi_size - 4, &sum);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot copy the vsync API inside userpref! %d\n", err);
		return err;
	}
	
	/* write sum */
	sum = ~sum + 1;
	RMuint32ToLeBuf(sum, out_buf);
	len = write(fd, out_buf, 4);
	if (len < 4) {
		fprintf(stderr, "Error while writing sum of vsync API! %ld\n", len);
		return RM_ERROR;
	}

	/* complete with 0 to have another 32KB */
	err = write_zero_chunk(fd, 32768-vsyncapi_size);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot create the last 0 to fill 32KB in userpref! %d\n", err);
		return err;
	}

	close(fd);
	
	return RM_OK;
}

static RMstatus add_raw_section(struct RUA *pRUA, int fd, RMuint32 addr, RMuint32 size, RMuint32 *sum)
{
	RMstatus err;

	err = write_section_header(fd, RAWD, addr, size, sum);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error while writing section header of raw data! %d\n", err);
		return err;
	}
	
	err = write_data_chunk(pRUA, fd, addr, size, sum);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error while writing data of raw data! %d\n", err);
		return err;
	}
	
	return RM_OK;
}

static RMuint8 bmp_get_4bits(RMuint8 **pin, RMuint32 *toggle)
{
	RMuint8 val;
	
	val = ((**pin) >> (*toggle * 4)) & 0xf;
	*toggle = 1 - *toggle;
	if (*toggle == 1)
		*pin = *pin + 1;

	return val;
}

static void bmp_set_4bits(RMuint8 **pout, RMuint8 val, RMuint32 *toggle)
{
	if (*toggle)
		**pout = (val & 0xf) << 4;
	else
		**pout |= (val & 0xf);

	*toggle = 1 - *toggle;
	if (*toggle == 1)
		*pout = *pout + 1;
}

static RMuint32 compress_line_4bpp(RMuint8 *in_buf, RMuint32 width, RMuint8 *out_buf, RMuint32 out_size)
{
	RMuint8 *pin = in_buf, *pout=out_buf;
	RMuint32 in_toggle = 1, out_toggle = 1;
	RMuint8 color, c;
	RMuint32 count, i;

	color = bmp_get_4bits(&pin, &in_toggle);
	count = 1;
	for (i=1 ; i<width ; i++) {
		c = bmp_get_4bits(&pin, &in_toggle);
		
		if (color != c) {
			bmp_set_4bits(&pout, color, &out_toggle);
			while (count > 7) {
				bmp_set_4bits(&pout, (0x8 | (count & 0x7)), &out_toggle);
				count = count >> 3;
			}
			bmp_set_4bits(&pout, (count & 0x7), &out_toggle);

			color = c;
			count = 1;
		}
		else
			count++;
	}
	
	bmp_set_4bits(&pout, color, &out_toggle);
	bmp_set_4bits(&pout, 0, &out_toggle);
	
	if (out_toggle == 0) {
		out_toggle = 1;
		pout ++;
	}

	return (pout - out_buf);
}

static RMuint32 compress_line_7bpp(RMuint8 *in_buf, RMuint32 width, RMuint8 *out_buf, RMuint32 out_size)
{
	RMuint8 *pin = in_buf, *pout=out_buf;
	RMuint32 toggle = 1;
	RMuint8 color, c;
	RMuint32 count, i;

	color = *pin; pin ++;
	count = 1;
	for (i=1 ; i<width ; i++) {
		c = *pin; pin ++;
		
		if (color != c) {
			if (count == 1) 
				bmp_set_4bits(&pout, (color >> 4) & 0x7, &toggle);
			else
				bmp_set_4bits(&pout, 0x8 | ((color >> 4) & 0x7), &toggle);
			bmp_set_4bits(&pout, (color & 0xf), &toggle);
				
			count --;
			while (count > 7) {
				bmp_set_4bits(&pout, (0x8 | (count & 0x7)), &toggle);
				count = count >> 3;
			}
			if (count > 0)
				bmp_set_4bits(&pout, (count & 0x7), &toggle);

			color = c;
			count = 1;
		}
		else
			count++;
	}
	
	if (count == 1) {
		bmp_set_4bits(&pout, (color >> 4) & 0x7, &toggle);
		bmp_set_4bits(&pout, (color & 0xf), &toggle);
	}
	else {
		bmp_set_4bits(&pout, 0x8 | ((color >> 4) & 0x7), &toggle);
		bmp_set_4bits(&pout, (color & 0xf), &toggle);
		bmp_set_4bits(&pout, 0, &toggle);
	}

	if (toggle == 0) {
		pout ++;
		toggle = 1;
	}
	
	return (pout - out_buf);
}

static RMstatus add_rled_section(struct RUA *pRUA, int fd, RMuint32 data_addr, RMuint32 data_size, RMuint32 width, RMuint32 compression, RMascii *dir_name, RMuint32 *sum)
{
	RMuint8 in_buf[CHUNK], out_buf[CHUNK];
	RMstatus err;
	RMuint32 byte_size, total_size, size, count;
	RMuint32 compress_size = 0, mod=0, i, val;
	RMint32 len;
	int tmp_fd;
	char tmp_string[2048];
	RMuint32 comp_mode = 0;
		
	snprintf(tmp_string, 2048, "%s/%s", dir_name, TMPFILE_PATTERN); 

	tmp_fd = mkstemp(tmp_string);
	if (tmp_fd == -1) {
		fprintf(stderr, "Error cannot create temporary file\n");
		return RM_ERROR;
	}
	
	byte_size = (compression == COMPRESSION_4BPP) ? ((width + 1) /2) : width;
		
	if (byte_size > CHUNK) {
		fprintf(stderr, "Error byte size %lu bigger than chunk size %d\n", byte_size, CHUNK);
		return RM_ERROR;
	}

	total_size = 0;
	while (total_size < data_size) {
		err = read_memory(pRUA, data_addr + total_size, byte_size, in_buf);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot read line of RLED section! %d\n", err);
			return err;
		}

		switch (compression) {
		case COMPRESSION_4BPP:
			size = compress_line_4bpp(in_buf, width, out_buf, CHUNK);
			comp_mode = 0;
			break;
		case COMPRESSION_7BPP:
			size = compress_line_7bpp(in_buf, width, out_buf, CHUNK);
			comp_mode = 1;
			break;
		default:
			fprintf(stderr, "Invalid compression %lu\n", compression);
			return RM_ERROR;
		}
		
		compress_size += size;
		val = 0;
		for (i=0 ; i<mod ; i++) {
			val |= out_buf[i] << ((i + 4 - mod)*8);
		}
		*sum += val;
		*sum += get_sum(out_buf+mod, size-mod);
		mod = ((size - mod) & 0x3) ? (4 - ((size - mod) & 0x3)) : 0;
		
		count = 0;
		while (count < size) {
			RMint32 len;
			len = write(tmp_fd, out_buf + count, size - count);
			if (len <= 0) {
				fprintf(stderr, "Error writing file\n");
				break;
			}
			count += len;
		}

		total_size += byte_size;
		fprintf(stderr, ".");
	}

	if (lseek(tmp_fd, 0, SEEK_SET) != 0) {
		fprintf(stderr, "Cannot seek at the begining of tmp file\n");
		return RM_ERROR;
	}
						    
	err = write_section_header(fd, RLED, data_addr, compress_size, sum);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error while writing section header of raw data! %d\n", err);
		return err;
	}


	val = (width | (comp_mode << 24));
	RMuint32ToLeBuf(val, out_buf);
	len = write(fd, out_buf, 4);
	if (len < 4) {
		fprintf(stderr, "Error while writing width field in header! %ld\n", len);
		return RM_ERROR;
	}
	*sum += val;
	
	while (1) {
		len = read(tmp_fd, in_buf, CHUNK);
		if (len == -1) {
			fprintf(stderr, "Error reading tmp file\n");
			return RM_ERROR;
		}

		if (len == 0)
			break;
		
		count = (RMuint32) len;
		size = 0;
		while (size < count) {
			len = write(fd, in_buf, count);
			if (len <= 0) {
				fprintf(stderr, "Error while making data alignment of data section! %ld\n", len);
				return RM_ERROR;
			}
			size += len;
		}
	}
	close(tmp_fd);

	/* alignment on 32 bits */
	while (compress_size & 0x3) {
		RMuint8 c=0;
		len = write(fd, &c, 1);
		if (len <= 0) {
			fprintf(stderr, "Error while making data alignment of data section! %ld\n", len);
			return RM_ERROR;
		}
		compress_size ++;
	}
	fprintf(stderr, "\n");


	
	return RM_OK;
}
#endif // EM86XX_CHIP

RMstatus dumpBitmapInfo(struct dcc_context *dcc_info, struct DCCVideoSource *pOSDSource, struct DCCOSDProfile *osd_profile, RMuint32 lutAddr, RMascii *dir_name)
{
	int fd;
	RMstatus err;
	RMuint32 surfaceAddr, surfaceSize;
	RMuint32 compression, lutSize;
	RMuint32 Y_addr, Y_size, UV_addr, UV_size;
	struct DisplayBlock_VsyncApiInfo_type vsyncapi;
	RMuint32 sum;
	RMascii filename[2048];
	struct MM_TopRemovableArea_type top_removable_size = {0,};

	/* check to make sure the current memory map does not contain any splash bitmap */
	err = RUAGetProperty(dcc_info->pRUA, EMHWLIB_MODULE(MM, 0), RMMMPropertyID_TopRemovableArea, &top_removable_size, sizeof(top_removable_size));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get the IRQ handler API information %d\n", err));
		return err;
	}
	if( top_removable_size.Size != 0 ) {
		fprintf(stderr, "Cannot generate odump bitmap, clear_bootosd first %lx %lx\n",top_removable_size.Size, top_removable_size.Address );
		return RM_ERROR;
	}

	err = RUAGetProperty(dcc_info->pRUA, EMHWLIB_MODULE(DisplayBlock, 0), RMDisplayBlockPropertyID_VsyncApiInfo, &vsyncapi, sizeof(vsyncapi));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get the IRQ handler API information %d\n", err));
		return err;
	}
	fprintf(stderr, "VSYNCAPI 0x%08lX 0x%08lX\n", vsyncapi.Address, vsyncapi.Size);
#if (EM86XX_CHIP<EM86XX_CHIPID_TANGO2)
	/* on smp8634, userpref does not exist */
	create_userpref(dcc_info->pRUA, vsyncapi.Address, vsyncapi.Size, dir_name);
#endif // EM86XX_CHIP
	create_vsyncparam(dcc_info->pRUA, vsyncapi.Address, vsyncapi.Size, dir_name);

	err = DCCGetOSDVideoSourceInfo(pOSDSource, &Y_addr, &Y_size, &UV_addr, &UV_size);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get OSD video info %d\n", err));
		return err;
	}

	err = DCCGetOSDSurfaceInfo(dcc_info->pDCC, pOSDSource, osd_profile, &surfaceAddr, &surfaceSize);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot get OSD surface info %d\n", err);
		return err;
	}

	sum = 0;

#if (EM86XX_CHIP<EM86XX_CHIPID_TANGO2)
	snprintf(filename, 2048, "%s/%s%s", dir_name, BITMAP, _BIN); 
#else
	snprintf(filename, 2048, "%s/%s_0x%08lx%s", dir_name, BITMAP, surfaceAddr, _BIN); 
#endif // EM86XX_CHIP

	fd = open(filename, O_CREAT | O_WRONLY | O_TRUNC, S_IRWXU | S_IRWXG | S_IRWXO);
	if (fd == -1) {
		fprintf(stderr, "Could not open %s%s\n" , BITMAP, _BIN);
		return RM_ERROR;
	}
	
	fprintf(stderr, "RAWD 0x%08lX 0x%08lX\n", surfaceAddr, surfaceSize - Y_size);
#if (EM86XX_CHIP<EM86XX_CHIPID_TANGO2)
	add_raw_section(dcc_info->pRUA, fd, surfaceAddr, surfaceSize - Y_size, &sum);
#else
	write_data_chunk(dcc_info->pRUA, fd, surfaceAddr, surfaceSize, &sum);	
#endif // EM86XX_CHIP
	
	switch (osd_profile->ColorMode) {
	case EMhwlibColorMode_LUT_1BPP:
	case EMhwlibColorMode_LUT_2BPP:
		//not supported yet
 		compression = NO_COMPRESSION;
		lutSize = 0;
		break;
	case EMhwlibColorMode_LUT_4BPP:
		compression = COMPRESSION_4BPP;
		lutSize = 16*4;
		break;
		
	case EMhwlibColorMode_LUT_8BPP:
		{
			RMuint32 palette[128];
			RMuint32 i;

			lutSize = 256*4;
			
			read_memory(dcc_info->pRUA, lutAddr + 128*4, 128*4, (RMuint8 *) palette);
			for (i=0 ; i<128 ; i++) {
				if (palette[i] != 0)
					break;
			}
			
			compression = (i == 128) ? COMPRESSION_7BPP : NO_COMPRESSION;
		}
		break;
	default:
 		compression = NO_COMPRESSION;
		lutSize = 0;
		break;
	}

#if (EM86XX_CHIP<EM86XX_CHIPID_TANGO2)
	if(lutSize) {
		fprintf(stderr, "RAWD 0x%08lX 0x%08lX\n", lutAddr, lutSize);
		err = add_raw_section(dcc_info->pRUA, fd, lutAddr, lutSize, &sum);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot add lut section! %d\n", err);
			return err;
		}
	}

	if (compression == NO_COMPRESSION) {
		fprintf(stderr, "RAWD 0x%08lX 0x%08lX\n", Y_addr, Y_size);
		add_raw_section(dcc_info->pRUA, fd, Y_addr, Y_size, &sum);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot add uncompressed bitmap section! %d\n", err);
			return err;
		}
	}
	else{
		fprintf(stderr, "RLED 0x%08lX 0x%08lX %lu %02lx\n", Y_addr, Y_size, osd_profile->Width, compression);
		add_rled_section(dcc_info->pRUA, fd,  Y_addr, Y_size, osd_profile->Width, compression, dir_name, &sum);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot add compressed bitmap section! %d\n", err);
			return err;
		}
	}

	{
		RMuint8 out_buf[4];
		RMint32 len;

		/* write sum */
		sum = ~sum + 1;
		RMuint32ToLeBuf(sum, out_buf);
		len = write(fd, out_buf, 4);
		if (len < 4) {
			fprintf(stderr, "Error while writing sum of vsync API! %ld\n", len);
			return RM_ERROR;
		}
	}
#else
	if (lutSize) {
		close(fd);
		snprintf(filename, 2048, "%s/%s_0x%08lx%s", dir_name, PALETTE, lutAddr, _BIN); 
		fd = open(filename, O_CREAT | O_WRONLY | O_TRUNC, S_IRWXU | S_IRWXG | S_IRWXO);
		if (fd == -1) {
			fprintf(stderr, "Could not open %s%s\n" , PALETTE, _BIN);
			return RM_ERROR;
		}
		fprintf(stderr, "RAWD 0x%08lX 0x%08lX\n", lutAddr, lutSize);
		err = write_data_chunk(dcc_info->pRUA, fd, lutAddr, lutSize, &sum);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot add lut section! %d\n", err);
			return err;
		}
	}
#endif // EM86XX_CHIP

	close(fd);

#if (EM86XX_CHIP<EM86XX_CHIPID_TANGO2)
#else
	snprintf(filename, 2048, "%s/%s%s", dir_name, XENV, _TXT); 
	fd = open(filename, O_CREAT | O_WRONLY | O_TRUNC, S_IRWXU | S_IRWXG | S_IRWXO);
	if (fd == -1) {
		fprintf(stderr, "Could not open %s%s\n" , PALETTE, _BIN);
		return RM_ERROR;
	}
	
	{
		struct PLL_BootirqSettings_type v;
		FILE *f=fdopen(fd,"w");
		
		err = RUAGetProperty(dcc_info->pRUA, PLL, RMPLLPropertyID_BootirqSettings, &v, sizeof(v));
		fprintf(f,"setxenv -b a.cd8_div 0x%08lx\n",v.SYS_cleandiv8_div_val);
		// fprintf(f,"setxenv -b a.SYS_cleandiv8_ctrl 0x%08lx\n",v.SYS_cleandiv8_ctrl_val);
		fprintf(f,"setxenv -b a.cd9_div 0x%08lx\n",v.SYS_cleandiv9_div_val);
		// fprintf(f,"setxenv -b a.SYS_cleandiv9_ctrl 0x%08lx\n",v.SYS_cleandiv9_ctrl_val);
		fprintf(f,"setxenv -b a.cd10_div 0x%08lx\n",v.SYS_cleandiv10_div_val);
		// fprintf(f,"setxenv -b a.SYS_cleandiv10_ctrl 0x%08lx\n",v.SYS_cleandiv10_ctrl_val);
		// fprintf(f,"setxenv -b a.SYS_clkgen1_pll 0x%08lx\n",v.SYS_clkgen1_pll_val);
		// fprintf(f,"setxenv -b a.SYS_clkgen1_div 0x%08lx\n",v.SYS_clkgen1_div_val);
			fprintf(f,"setxenv -b a.premux 0x%08lx\n",v.SYS_sysclk_premux_val);
			fprintf(f,"setxenv -b a.avclk_mux 0x%08lx\n",v.SYS_avclk_mux_val);
			
			fclose(f);
	}
		
	close(fd);
#endif
	
	return RM_OK;
}
