/*****************************************
 Copyright � 2001-2005  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   spuapi.c
  @brief  Nero Digital SPU API

  @author Sebastian Frias Feltrer
  @date   2005-08-11
*/

#define ALLOW_OS_CODE 1

#include "spuapi.h"

#include "ndsp/ndsp_subpic.h"

#define LOCALDBG DISABLE


unsigned char *sp_framebuffer;

RMNeroSPUDecoderHandle RMOpenNeroSPUDecoder(RMuint32 width, RMuint32 height, RMspuPalette_AYUV *palette, RMuint8 *buffer)
{

	RMDBGLOG((ENABLE, "OpenSPUDecoder(%lu, %lu, @0x%lx, @0x%lx)\n", width, height, palette, buffer));

	sp_framebuffer = buffer;

	return (RMNeroSPUDecoderHandle) ndsp_CreateInstance(width, height, (ndsp_ND_YUV *)palette);

}




void RMCloseNeroSPUDecoder(RMNeroSPUDecoderHandle pDecoder) 
{
	ndsp_Destroy((ndsp_Handle) pDecoder);

	return;
}

RMstatus RMNeroSPUDecoderProcessSample(RMNeroSPUDecoderHandle pDecoder, RMuint8 *data, RMuint32 len, RMuint64 pts, RMuint32 flags)
{
	DM4V_Status status;

	RMDBGLOG((LOCALDBG, "processSample(@0x%lx, %lu, %llu, %lu)\n", (RMuint32)data, len, pts, flags));
	status = ndsp_ProcessSampleData((ndsp_Handle) pDecoder, data, len, (RMint64)pts);
	if (status != DM4V_STATUS_OK)
		return RM_ERROR;
	
	return RM_OK;
}

RMstatus RMNeroSPUDecoderReset(RMNeroSPUDecoderHandle pDecoder)
{
	DM4V_Status status;

	RMDBGLOG((LOCALDBG, "decoderReset\n"));

	status  = ndsp_Reset((ndsp_Handle) pDecoder);
	if (status != DM4V_STATUS_OK)
		return RM_ERROR;

	return RM_OK;
}

RMstatus RMNeroSPUDecoderSetStatus(RMNeroSPUDecoderHandle pDecoder, RMbool state)
{
	DM4V_Status status;

	RMDBGLOG((LOCALDBG, "setStatus\n"));
	status  = ndsp_SetSubpicStatus((ndsp_Handle) pDecoder, state);
	if (status != DM4V_STATUS_OK)
		return RM_ERROR;

	return RM_OK;
}

RMbool RMNeroSPUDecoderBlend(RMNeroSPUDecoderHandle pDecoder, RMspuFrame **frame, RMuint64 time)
{
	*frame = (RMspuFrame *) ndsp_ShouldBlendSubpic((ndsp_Handle) pDecoder, (RMint64)time);
	if (*frame) {
		RMDBGLOG((LOCALDBG, "should blend at %llu\n", time));
		return TRUE;
	}

	return FALSE;
}
