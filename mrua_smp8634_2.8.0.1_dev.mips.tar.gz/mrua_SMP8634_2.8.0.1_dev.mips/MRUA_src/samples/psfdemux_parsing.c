/*
 *
 * Copyright (c) Sigma Designs, Inc. 2006. All rights reserved.
 *
 */

/*
 * ***********************************************************
 * This is UGLY, #including this file isnt the way to go, but
 * it's a fast way of cleaning play_psfdemux.c
 * The best approach will be to convert this into a library
 * which might be re-used by RMVDEMUX lib.
 * ***********************************************************
 */

/**
   @file psfdemux_parsing.c
   @brief PMT, PAT, etc parsing functionality for play_psfdemux
	
   @author Aurelia Popa-Radu
   @ingroup dccsamplecode
*/


#include "../samples/sample_os.h"

#define ALLOW_OS_CODE 1
#include "../dcc/include/dcc.h"
#include "../samples/common.h"

#include "../rmscc/include/rmscc.h"
#include "mp4descriptors.h"
#include "mp4scene.h"
#include "psfdemux_common.h"
#include "../samples/rmttx.h"

#if 0
#define CALLDBG ENABLE
#else
#define CALLDBG DISABLE
#endif

/* pid and output tables for app_type = pid_filter_section */
struct PidEntry_type gPidTable[] = {
	/*   pid,    input_type,   flags, enable,     output_mask[1],    cipher,           pid type,  index */
	/*                                           (where to send)  mask, index[1], (what to send)        */
#ifndef USE_HW_FIXED_PID_ENTRY /* defined in psfdemux_common.h only for EM8622 chip; undefined for EM863x */
	/* enable PAT, CAT in PidTable and disable the fixed PAT pid from hardware */
	{ 0x0000, EMhwlibPid_Ts, TS_FLAGS,  TRUE,   {PAT_OUTPUT_MASK},  0,  {0},   PAT_PID_ENTRY, },
	{ 0x0001, EMhwlibPid_Ts, TS_FLAGS,  TRUE,   {CAT_OUTPUT_MASK},  0,  {0},   CAT_PID_ENTRY, },
#endif
	{ 0x1fff, EMhwlibPid_Ts, TS_FLAGS, FALSE, {VIDEO_OUTPUT_MASK},  0,  {0}, VIDEO_PID_ENTRY, },
	{ 0x1fff, EMhwlibPid_Ts, TS_FLAGS, FALSE, {AUDIO_OUTPUT_MASK},  0,  {0}, AUDIO_PID_ENTRY, },

	{ 0x1fff, EMhwlibPid_Ts, TS_FLAGS, FALSE,   {PCR_OUTPUT_MASK},  0,  {0},   PCR_PID_ENTRY, },
	{ 0x1fff, EMhwlibPid_Ts, TS_FLAGS, FALSE,   {PMT_OUTPUT_MASK},  0,  {0},   PMT_PID_ENTRY, },
	{ 0x1fff, EMhwlibPid_Ts, TS_FLAGS, FALSE,  {ECM0_OUTPUT_MASK},	0,  {0},  ECM0_PID_ENTRY, },/* hardcoded for dvb encrypted files */
	{ 0x1fff, EMhwlibPid_Ts, TS_FLAGS, FALSE,  {ECM1_OUTPUT_MASK},	0,  {0},  ECM1_PID_ENTRY, },/* hardcoded for dvb encrypted files */

	// reserve two pid for mp4 bifs and od	
	{ 0x1fff, EMhwlibPid_Ts, TS_FLAGS, FALSE,  {BIFS_OUTPUT_MASK},	0,  {0},  BIFS_PID_ENTRY, },/* mp4 bifs stream */
	{ 0x1fff, EMhwlibPid_Ts, TS_FLAGS, FALSE,    {OD_OUTPUT_MASK},	0,  {0},    OD_PID_ENTRY, },/* mp4 od stream */
	{ 0x1fff, EMhwlibPid_Ts, TS_FLAGS,  TRUE,   {TTX_OUTPUT_MASK},  0,  {0},   TTX_PID_ENTRY, },/* teletext stream */
	
#ifdef MULTI2_EIGHT_KEYS
	{ 0x1fff, EMhwlibPid_Ts, TS_FLAGS, FALSE,   {1<<(DATA_OUT+0)},  0,  {0},    DATA_ENTRY+0, }, // data out13
	{ 0x1fff, EMhwlibPid_Ts, TS_FLAGS, FALSE,   {1<<(DATA_OUT+1)},  0,  {0},    DATA_ENTRY+1, },
	{ 0x1fff, EMhwlibPid_Ts, TS_FLAGS, FALSE,   {1<<(DATA_OUT+2)},  0,  {0},    DATA_ENTRY+2, },
	{ 0x1fff, EMhwlibPid_Ts, TS_FLAGS, FALSE,   {1<<(DATA_OUT+3)},  0,  {0},    DATA_ENTRY+3, },
	{ 0x1fff, EMhwlibPid_Ts, TS_FLAGS, FALSE,   {1<<(DATA_OUT+4)},  0,  {0},    DATA_ENTRY+4, },
	{ 0x1fff, EMhwlibPid_Ts, TS_FLAGS, FALSE,   {1<<(DATA_OUT+5)},  0,  {0},    DATA_ENTRY+5, },
	
	{ 0x1fff, EMhwlibPid_Ts, TS_FLAGS, FALSE,   {1<<(DATA_OUT+6 )}, 0,  {0},    DATA_ENTRY+6, }, // ecm out19
	{ 0x1fff, EMhwlibPid_Ts, TS_FLAGS, FALSE,   {1<<(DATA_OUT+7 )}, 0,  {0},    DATA_ENTRY+7, },
	{ 0x1fff, EMhwlibPid_Ts, TS_FLAGS, FALSE,   {1<<(DATA_OUT+8 )}, 0,  {0},    DATA_ENTRY+8, },
	{ 0x1fff, EMhwlibPid_Ts, TS_FLAGS, FALSE,   {1<<(DATA_OUT+9 )}, 0,  {0},    DATA_ENTRY+9, },
	{ 0x1fff, EMhwlibPid_Ts, TS_FLAGS, FALSE,   {1<<(DATA_OUT+10)}, 0,  {0},    DATA_ENTRY+10,},
	{ 0x1fff, EMhwlibPid_Ts, TS_FLAGS, FALSE,   {1<<(DATA_OUT+11)}, 0,  {0},    DATA_ENTRY+11,},
#endif //#ifdef MULTI2_EIGHT_KEYS

};

struct Output_type gOutputTable[] = {
	/*      data_type,      section_mask,   buffer    partial thrshld, pts,ibc,     consumer,    callback,       file,       output   receive_data */
        /*                                     count, size,  read,                                             name,handle,size, module_id, mode       */
	{ EMhwlibData_PSI,  PAT_SECTION_MASK,  4,  LOG2_4k,  TRUE,      0,   0,  0,            0, PATCallback, "0.out", NULL, 0, 0, receive_data_dma_no_delay, },
	{ EMhwlibData_PSI,  PMT_SECTION_MASK,  4,  LOG2_4k,  TRUE,      0,   0,  0,            0, PMTCallback, "1.out", NULL, 0, 0, receive_data_dma_no_delay, },
	{ EMhwlibData_Vpayload_pts,        0, 16, LOG2_32k, FALSE, 0x8000, 128, 64, VideoDecoder,        NULL, "2.out", NULL, 0, 0, receive_data_dma_backward_compatible, },
	{ EMhwlibData_ASpayload_pts,       0, 16, LOG2_32k, FALSE, 0x8000, 128, 64, AudioDecoder,        NULL, "3.out", NULL, 0, 0, receive_data_dma_backward_compatible, },

	{ EMhwlibData_PCR,                 0,  0,        0, FALSE,      0,   0,  0,            0,        NULL,      "", NULL, 0, 0, receive_data_dma_backward_compatible, },

	{ EMhwlibData_PSI,  CAT_SECTION_MASK,  4,  LOG2_4k,  TRUE,      0,   0,  0,            0, CATCallback, "5.out", NULL, 0, 0, receive_data_dma_no_delay, },
	{ EMhwlibData_PSI, ECM0_SECTION_MASK,  4,  LOG2_4k,  TRUE,      0,   0,  0,            0, ECMCallback, "6.out", NULL, 0, 0, receive_data_dma_no_delay, },
	{ EMhwlibData_PSI, ECM1_SECTION_MASK,  4,  LOG2_4k,  TRUE,      0,   0,  0,            0, ECMCallback, "7.out", NULL, 0, 0, receive_data_dma_no_delay, },

	// output used for recording TS - used when RECORD_AV_TS or WITH_TIME_SHIFT is defined in psfdemux_common.h
#ifdef RECORD_AV_TS
	{ EMhwlibData_TS,             0, REC_CNT, LOG2_32k, FALSE, 0x8000,   0, 64,            0,        NULL, "8.out", NULL, 0, 0, receive_data_dma_full_buffer, },
#else
	{ EMhwlibData_TS,             0,       0,        0, FALSE, 0x8000,   0,  0,            0,        NULL, "8.out", NULL, 0, 0, receive_data_dma_backward_compatible, },
#endif
	{ EMhwlibData_ASpayload_pts,  0,      16, LOG2_32k, FALSE, 0x8000, 128, 64, AudioDecoder,        NULL, "9.out", NULL, 0, 0, receive_data_dma_backward_compatible, },

	{ EMhwlibData_PSI, BIFS_SECTION_MASK,  4,  LOG2_4k,  TRUE,      0,   0,  0,            0,        NULL,"10.out", NULL, 0, 0, receive_data_dma_no_delay, },
	{ EMhwlibData_DMB_OD, OD_SECTION_MASK, 4,  LOG2_4k,  TRUE,      0,   0,  0,            0,        NULL,"11.out", NULL, 0, 0, receive_data_dma_no_delay, },
	{ EMhwlibData_APES,           0,       4, LOG2_32k,  TRUE,      0,   0,  0,            0, TTXCallback,"12.out", NULL, 0, 0, receive_data_dma_no_delay, },	
	{ EMhwlibData_TS,             0,      16, LOG2_32k, FALSE, 0x8000,   0,  0,            0,        NULL,"13.out", NULL, 0, 0, receive_data_dma_full_buffer, },	

#ifdef MULTI2_EIGHT_KEYS
	{ EMhwlibData_ASpayload_pts,  0,       4,  LOG2_4k, FALSE,      0,   0,  0,            0,        NULL,"13.out", NULL, 0, 0, receive_data_dma_backward_compatible, },  // data
//	{ EMhwlibData_DSM_CC,(1<<(DATA_SEC+1)),4,  LOG2_4k, FALSE,      0,   0,  0,            0,        NULL,"13.out", NULL, 0, 0, receive_data_dma_backward_compatible, },
	{ EMhwlibData_DSM_CC,(1<<(DATA_SEC+2)),4,  LOG2_4k, FALSE,      0,   0,  0,            0,        NULL,"14.out", NULL, 0, 0, receive_data_dma_backward_compatible, },
	{ EMhwlibData_DSM_CC,(1<<(DATA_SEC+3)),4,  LOG2_4k, FALSE,      0,   0,  0,            0,        NULL,"15.out", NULL, 0, 0, receive_data_dma_backward_compatible, },
	{ EMhwlibData_DSM_CC,(1<<(DATA_SEC+4)),4,  LOG2_4k, FALSE,      0,   0,  0,            0,        NULL,"16.out", NULL, 0, 0, receive_data_dma_backward_compatible, },
	{ EMhwlibData_DSM_CC,(1<<(DATA_SEC+5)),4,  LOG2_4k, FALSE,      0,   0,  0,            0,        NULL,"17.out", NULL, 0, 0, receive_data_dma_backward_compatible, },
	{ EMhwlibData_DSM_CC,(1<<(DATA_SEC+6)),4,  LOG2_4k, FALSE,      0,   0,  0,            0,        NULL,"18.out", NULL, 0, 0, receive_data_dma_backward_compatible, },

	{ EMhwlibData_PSI, (1<<(DATA_SEC+7 )), 4,  LOG2_4k,  TRUE,      0,   0,  0,            0, ECMCallback,"19.out", NULL, 0, 0, receive_data_dma_backward_compatible, },  // data
	{ EMhwlibData_PSI, (1<<(DATA_SEC+8 )), 4,  LOG2_4k,  TRUE,      0,   0,  0,            0, ECMCallback,"20.out", NULL, 0, 0, receive_data_dma_backward_compatible, },
	{ EMhwlibData_PSI, (1<<(DATA_SEC+9 )), 4,  LOG2_4k,  TRUE,      0,   0,  0,            0, ECMCallback,"21.out", NULL, 0, 0, receive_data_dma_backward_compatible, },
	{ EMhwlibData_PSI, (1<<(DATA_SEC+10)), 4,  LOG2_4k,  TRUE,      0,   0,  0,            0, ECMCallback,"22.out", NULL, 0, 0, receive_data_dma_backward_compatible, },
	{ EMhwlibData_PSI, (1<<(DATA_SEC+11)), 4,  LOG2_4k,  TRUE,      0,   0,  0,            0, ECMCallback,"23.out", NULL, 0, 0, receive_data_dma_backward_compatible, },
	{ EMhwlibData_PSI, (1<<(DATA_SEC+12)), 4,  LOG2_4k,  TRUE,      0,   0,  0,            0, ECMCallback,"24.out", NULL, 0, 0, receive_data_dma_backward_compatible, },
#endif //#ifdef MULTI2_EIGHT_KEYS
};

/* pid and output table for app_type = program_stream_parsing */
struct PesEntry_type gPesTable[] = {
	/* sid, ssid,      input_type, enable, output_mask[1], cipher_mask, cipher_index[1] */
	{ 0xE0, 0,    EMhwlibPes_packet, TRUE,    {1<<0},            0,          {0}, }, // video
	{ 0xBD, 0x80, EMhwlibPes_packet, TRUE,    {(1<<1) | (1<<3)}, 0,          {0}, }, // two audio outputs
	{ 0xBD, 0x20, EMhwlibPes_packet, TRUE,    {1<<2},            0,          {0}, }, // subpicture
};

struct Output_type gPesOutputTable[] = {
	/*      data_type,      section_mask,   buffer    partial thrshld, pts,ibc,     consumer,    callback,       file,       output   receive_data */
        /*                                     count, size,  read,                                             name,handle,size, module_id, mode       */
	{ EMhwlibData_Vpayload_pts,    0,    64, LOG2_32k, FALSE, 0x8000, 128, 64, VideoDecoder,         NULL, "0.out", NULL, 0, 0, receive_data_dma_backward_compatible, },
	{ EMhwlibData_ASpayload_pts,   0,    16, LOG2_32k, FALSE, 0x8000, 128, 64, AudioDecoder,         NULL, "1.out", NULL, 0, 0, receive_data_dma_backward_compatible, },
	{ EMhwlibData_ASpayload_pts,   0,    16,  LOG2_4k, FALSE, 0x1000, 128, 64,   SpuDecoder,         NULL, "2.out", NULL, 0, 0, receive_data_dma_backward_compatible, },
	{ EMhwlibData_ASpayload_pts,   0,    16, LOG2_32k, FALSE, 0x8000, 128, 64, AudioDecoder,         NULL, "3.out", NULL, 0, 0, receive_data_dma_backward_compatible, },
};

/* generic section filter - including PAT, PMT, DSM_CC */
struct MatchSectionEntry_type gmatchSectionTable[] = {
	{{ 0xff, 0xff,
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 0 mask
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // mode=positive match
	   {0x00, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}}}, // PAT
 
	{{ 0xff, 0xff,
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 1 mask
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // mode=positive match
	   {0x02, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}}},  // PMT

	{{ 0xff, 0xff,
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 2 mask 
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // mode=positive match
	   {0x3E, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}}}, // DSM_CC

	{{ 0xff, 0xff,
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 3 mask 
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // mode=positive match
	   {0x01, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}}}, // CAT

	{{ 0xff, 0xff,
	   {0xFC, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 4 mask 
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // mode=positive match
	   {0x80, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}}}, // ECM 0x80,0x81,0x82

	{{ 0xff, 0xff,
	   {0xFC, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 5 mask 
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // mode=positive match
	   {0x80, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}}}, // ECM 0x80,0x81,0x82
	   
	{{ 0xff, 0xff,
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 6 mask 
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // mode=positive match
	   {0x04, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}}}, // bifs streams

	{{ 0xff, 0xff,
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 7 mask 
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // mode=positive match
	   {0x05, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}}}, // od streams
	   
	{{ 0xff, 0xff,
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 8 not used
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  //
	   {0x05, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}}}, //

#ifdef MULTI2_EIGHT_KEYS
	// section for data outputs
	{{ 0xff, 0xff,
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 9  reserved for out 13
	   {0x00, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 
	   {0x00, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}}}, //
	{{ 0xff, 0xff,
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 10 
	   {0x00, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 
	   {0x00, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}}}, //
	{{ 0xff, 0xff,
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 11 
	   {0x00, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 
	   {0x00, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}}}, //
	{{ 0xff, 0xff,
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 12
	   {0x00, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 
	   {0x00, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}}}, //
	{{ 0xff, 0xff,
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 13
	   {0x00, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 
	   {0x00, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}}}, //
	{{ 0xff, 0xff,
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 14 
	   {0x00, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 
	   {0x00, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}}}, //
	
	// section for ecm outputs
	{{ 0xff, 0xff,
	   {0xFC, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 15 mask 
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // mode=positive match
	   {0x80, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}}}, // ECM 0x80,0x81,0x82
	{{ 0xff, 0xff,
	   {0xFC, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 16 mask 
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // mode=positive match
	   {0x80, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}}}, // ECM 0x80,0x81,0x82
	{{ 0xff, 0xff,
	   {0xFC, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 17 mask 
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // mode=positive match
	   {0x80, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}}}, // ECM 0x80,0x81,0x82
	{{ 0xff, 0xff,
	   {0xFC, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 18 mask 
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // mode=positive match
	   {0x80, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}}}, // ECM 0x80,0x81,0x82
	{{ 0xff, 0xff,
	   {0xFC, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 19 mask 
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // mode=positive match
	   {0x80, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}}}, // ECM 0x80,0x81,0x82
	{{ 0xff, 0xff,
	   {0xFC, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // 20 mask 
	   {0xFF, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},  // mode=positive match
	   {0x80, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}}}, // ECM 0x80,0x81,0x82
#endif //#ifdef MULTI2_EIGHT_KEYS
};


RMstatus ParsePAT(RMuint8 *pBuffer1, RMuint32 size1, RMuint8 *pBuffer2, RMuint32 size2, struct PATInfo_type *out)
{
	/* function assumes to be called on correct PAT boundaries */
#define PAT_TABLE_ID			1
#define PAT_LENGTH_HI			2
#define PAT_LENGTH_LO			3
#define PAT_TRANSPORT_STREAM_ID_HI	4
#define PAT_TRANSPORT_STREAM_ID_LO	5
#define PAT_VERSION_NUMBER		6
#define PAT_SECTION_NUMBER		7
#define PAT_LAST_SECTION_NUMBER		8
#define PAT_PROGRAM_NUMBER_HI		9
#define PAT_PROGRAM_NUMBER_LO		10
#define PAT_PROGRAM_MAP_PID_HI		11
#define PAT_PROGRAM_MAP_PID_LO		12
#define PAT_CRC_3			13
#define PAT_CRC_2			14
#define PAT_CRC_1			15
#define PAT_CRC_0			16

	RMuint32 PatState = PAT_TABLE_ID;
	RMuint16 length = 0, transport_stream_id = 0, program_number = 0, program_map_pid = 0;
	RMuint8 section_number, last_section_number;
	RMuint32 size = size1 + size2;
	RMuint16 len = 0;
	RMuint8 *p = NULL;
	
	RMDBGLOG((CALLDBG, "parsePAT\n"));

	if (out == NULL)
		return RM_ERROR;
		
	out->count = 0;
	
	if (pBuffer1 && size1) {
		p = pBuffer1;
	}
	while (size) {
		switch (PatState)
		{
		case PAT_TABLE_ID:
			if (*p != 0x00) {
				fprintf(stderr, "ParsePAT table_id=%02x instead of 0x00 !\n", *p);
				return RM_ERROR;
			}
			PatState++;
			break;
		case PAT_LENGTH_HI:	/* section_syntax_indicator and length_hi*/
			if ((*p & 0xc0) != 0x80) {
				fprintf(stderr, "ParsePAT section_syntax_indicator 0 !\n");
//				return RM_ERROR;
			}
			length = *p & 0x0f;
			length <<= 8;
			PatState++;
			break;
		case PAT_LENGTH_LO:
			length |= *p;
			len = length;
			PatState++;
			break;
		case PAT_TRANSPORT_STREAM_ID_HI:
			transport_stream_id = *p;
			transport_stream_id <<= 8;
			PatState++;
			len--;
			break;
		case PAT_TRANSPORT_STREAM_ID_LO:
			transport_stream_id |= *p;
			PatState++;
			len--;
			break;
		case PAT_VERSION_NUMBER:
			 /* version_number on bit 5..1, current_next_indicator on bit 0 */
			out->version_number_current_next_indicator = *p & 0x3f;
			RMDBGLOG((DISABLE, "ParsePAT version number = %x current_next_indicator = %x\n",
				out->version_number_current_next_indicator>>1,
				out->version_number_current_next_indicator & 1));
			PatState++;
			len--;
			break;
		case PAT_SECTION_NUMBER:
			if (*p != 0x00) {
				fprintf(stderr, "ParsePAT no multiple sections in PAT supported yet !\n");
				return RM_ERROR;
			}
			section_number = *p;
			PatState++;
			len--;
			break;
		case PAT_LAST_SECTION_NUMBER:
			last_section_number = *p;
			PatState++;
			len--;
			break;
		case PAT_PROGRAM_NUMBER_HI:
			if (len < 8) {
				fprintf(stderr, "ParsePAT not enough data for program and crc !\n");
				return RM_ERROR;
			}
			program_number = *p;
			program_number <<= 8;
			PatState++;
			len--;
			break;
		case PAT_PROGRAM_NUMBER_LO:
			program_number |= *p;
			PatState++;
			len--;
			out->program_number[out->count] = program_number;
			break;
		case PAT_PROGRAM_MAP_PID_HI:
			program_map_pid = *p & 0x1f;
			program_map_pid <<= 8;
			PatState++;
			len--;
			break;
		case PAT_PROGRAM_MAP_PID_LO:
			program_map_pid |= *p;
			/*fprintf(stderr, "\n %x %x", program_number, program_map_pid);*/
			len--;
			if (len > 4)	// another program follows
				PatState = PAT_PROGRAM_NUMBER_HI;
			else
				PatState++;
			out->program_map_pid[out->count] = program_map_pid;
			out->count++;
			if ( out->count > MAX_PROGRAM_NUMBER ) {
				fprintf(stderr, "ParsePAT has more programs than the max=0x%x !\n", MAX_PROGRAM_NUMBER);
				return RM_ERROR;
			}
			break;
		case PAT_CRC_3:
		case PAT_CRC_2:
		case PAT_CRC_1:
			PatState++;
			len--;
			break;
		case PAT_CRC_0:
			PatState++;
			len--;
			if (len) {
				fprintf(stderr, "ParsePAT reach CRC but there are 0x%x bytes left from 0x%x !\n", len, length);
				return RM_ERROR;
			}
			//uncomment next line to process all the sections in this buffer
			//PatState = PAT_TABLE_ID;
			break;
		}
		size--;
		size1--;
		if (size1 == 0)
			p = pBuffer2;
		else
			p++;
	}
	
	return RM_OK;
}



void ParseCADescriptor(RMuint8 *p, RMuint16 *ca_sys_id, RMuint16 *ecm_pid)
{
	RMDBGLOG((CALLDBG, "parseCADescriptor\n"));

	if (p == 0) 
		return;
 
	*ca_sys_id = (p[2] << 8) | p[3];
	*ecm_pid = ((p[4] << 8) | p[5]) & 0x1FFF;

	/* 
	 * PID=0x1FFF: Place a limited reception method descriptor and point out
	 * an ineffective ECM. There is no ECM stream.
	 */
}



/************************************************************************
 * Fetch the corresponding EMM pid from CA SYSTEM ID
 ************************************************************************/
RMuint16 GetEMMPid(struct context_per_task *context, RMuint16 ca_id)
{

	RMuint32 i;

	for (i = 0; i < context->cat_info.count; i++) {
		if (context->cat_info.ca_system_id[i] == ca_id) {
			return(context->cat_info.emm_pid[i]);
		}
	}
	return(0);
}

RMstatus ParsePMT(RMuint8 *pBuffer1, RMuint32 size1, RMuint8 *pBuffer2, RMuint32 size2, struct PMTInfo_type *out)
{
	/* function assumes to be called on correct PMT boundaries */
#define PMT_TABLE_ID			1
#define PMT_LENGTH_HI			2
#define PMT_LENGTH_LO			3
#define PMT_PROGRAM_NUMBER_HI		4
#define PMT_PROGRAM_NUMBER_LO		5
#define PMT_VERSION_NUMBER		6
#define PMT_SECTION_NUMBER		7
#define PMT_LAST_SECTION_NUMBER		8
#define PMT_PCR_PID_HI			9
#define PMT_PCR_PID_LO			10
#define PMT_PROGRAM_INFO_LENGHT_HI	11
#define PMT_PROGRAM_INFO_LENGHT_LO	12
#define PMT_DESCRIPTOR1			13
#define PMT_STREAM_TYPE			14
#define PMT_ELEMENTARY_PID_HI		15
#define PMT_ELEMENTARY_PID_LO		16
#define PMT_ES_INFO_LENGHT_HI		17
#define PMT_ES_INFO_LENGHT_LO		18
#define PMT_DESCRIPTOR2			19
#define PMT_CRC_3			20
#define PMT_CRC_2			21
#define PMT_CRC_1			22
#define PMT_CRC_0			23

	RMuint32 PmtState = PMT_TABLE_ID;
	RMuint16 length = 0, program_number = 0, pcr_pid = 0, program_info_length = 0, elementary_pid = 0, es_info_length = 0;
	RMuint8 section_number, last_section_number, stream_type = 0;
	RMuint32 size = size1 + size2;
	RMuint16 len = 0, info_len = 0, es_info_len = 0;
	RMuint8 *p = NULL;
	RMuint16 next_descriptor = 0;

	RMDBGLOG((CALLDBG, "parsePMT\n"));

	if (out == NULL)
		return RM_ERROR;
		
	out->count = 0;
	out->ecm_count = 0;
	out->es_ecm_count = 0;

	out->mp4 = 0;
	out->bifsID = 0;
	out->bifsPid = 0x1fff;
	out->odID = 0;
	out->odPid = 0x1fff;
	out->mp4VideoID = 0;
	out->mp4AudioID = 0;
	out->mp4VideoPid = 0x1fff;
	out->mp4AudioPid = 0x1fff;

	if (pBuffer1 && size1) {
		p = pBuffer1;
	}
	while (size) {
		switch (PmtState) {
		case PMT_TABLE_ID:
			if (*p != 0x02) {
				fprintf(stderr, "ParsePMT table_id=%02x instead of 0x02 !\n", *p);
				return RM_ERROR;
			}
			PmtState++;
			break;
		case PMT_LENGTH_HI:	// section_syntax_indicator and length_hi
			if ((*p & 0xc0) != 0x80) {
				fprintf(stderr, "ParsePMT section_syntax_indicator 0 !\n");
//				return RM_ERROR;
			}
			length = *p & 0x0f;
			length <<= 8;
			PmtState++;
			break;
		case PMT_LENGTH_LO:
			length |= *p;
			len = length;
			if (len > 0x3FD) {
				fprintf(stderr, "ParsePMT length greater than 0x3FD !\n");
				return RM_ERROR;
			}
			PmtState++;
			break;
		case PMT_PROGRAM_NUMBER_HI:
			program_number = *p;
			program_number <<= 8;
			PmtState++;
			len--;
			break;
		case PMT_PROGRAM_NUMBER_LO:
			program_number |= *p;
			out->program_number = program_number;
			PmtState++;
			len--;
			break;
		case PMT_VERSION_NUMBER:
			/* version_number on bit 5..1, current_next_indicator on bit 0 */
			out->version_number_current_next_indicator = *p & 0x3f;
			RMDBGLOG((DISABLE, "ParsePMT version number = %x current_next_indicator = %x\n",
				out->version_number_current_next_indicator>>1,
				out->version_number_current_next_indicator & 1));
			PmtState++;
			len--;
			break;
		case PMT_SECTION_NUMBER:
			if (*p != 0x00) {
				fprintf(stderr, "ParsePMT section not NULL !\n");
				return RM_ERROR;
			}
			section_number = *p;
			PmtState++;
			len--;
			break;
		case PMT_LAST_SECTION_NUMBER:
			if (*p != 0x00) {
				fprintf(stderr, "ParsePMT last_section not NULL !\n");
				return RM_ERROR;
			}
			last_section_number = *p;
			PmtState++;
			len--;
			break;
		case PMT_PCR_PID_HI:
			pcr_pid = *p & 0x1f;
			pcr_pid <<= 8;
			PmtState++;
			len--;
			break;
		case PMT_PCR_PID_LO:
			pcr_pid |= *p;
			PmtState++;
			len--;
			out->pcr_pid = pcr_pid;
			break;
		case PMT_PROGRAM_INFO_LENGHT_HI:
			program_info_length = *p & 0x0f;
			program_info_length <<= 8;
			PmtState++;
			len--;
			break;
		case PMT_PROGRAM_INFO_LENGHT_LO:
			program_info_length |= *p;
			if (program_info_length > 0x3FF) {
				fprintf(stderr, "ParsePMT program_info_length greater than 0x3FF !\n");
				return RM_ERROR;
			}
			info_len = program_info_length;
			next_descriptor = info_len;
			if (info_len == 0)
				PmtState = PMT_STREAM_TYPE;
			else
				PmtState++;
			len--;
			/*fprintf(stderr, "\n prog=%x len=%x pcr_pid=%x info_len=%x", program_number, length, pcr_pid, program_info_length);*/
			break;
		case PMT_DESCRIPTOR1:
			/*
			 * Conditional Accesss for entire program
			 * descriptor tag = 0x09
			 * CA system ID = ?
			 * PID = 0x????	(ECM)
			 */
			if (info_len == next_descriptor) {/* new descriptor*/
				//fprintf(stderr,"PMT_DESCRIPTOR1 = 0x%X\n", *p);
				if ((next_descriptor > 5) && (*p == 0x09)) {
					RMuint16 ca_sys_id = 0, ecm_pid = 0x1FFF;

					ParseCADescriptor(p, &ca_sys_id, &ecm_pid);
					out->ca_system_id[out->ecm_count] = ca_sys_id;	
					out->ecm_pid[out->ecm_count] = ecm_pid;
					//fprintf(stderr, "ParsePMT CA [%ld] descriptor CA_system_ID=0x%04x CA_PID=0x%03x\n", out->ecm_count, ca_sys_id, ecm_pid);
					out->ecm_count++;
				}
				else if ((next_descriptor > 5) && (*p == 0x1d) ) {
					out->mp4 = 1;
#ifdef WITH_MONO
					fprintf( stderr, "Mono cannot parse MP$ IOD\n" );
					out->odID = 0;
					out->bifsID = 0x1fff;
#else
					ParseIODDescriptor(p, & out->bifsID, & out->odID );
					//fprintf(stderr, "bifs id 0x%x and od id 0x%x\n",out->bifsID, out->odID  );
#endif 					
				}
				next_descriptor -= (p[1] + 2);
			}
			info_len--;
			len--;
			if (info_len == 0)
				PmtState++;
			break;
		case PMT_STREAM_TYPE:
			if (len == 4) {
				fprintf(stderr, "ParsePMT without stream info data, goto crc, len=%d !\n", len);
				PmtState = PMT_CRC_3;
				break;
			}
			if (len < 9) {
				fprintf(stderr, "ParsePMT not enough data for stream and crc, len=%d !\n", len);
				return RM_ERROR;
			}
			stream_type = *p;
			PmtState++;
			len--;
			out->stream_type[out->count] = stream_type;
			//printf("STREAM TYPE = 0x%X\n", out->stream_type[out->count]);
			break;
		case PMT_ELEMENTARY_PID_HI:
			elementary_pid = *p & 0x1f;
			elementary_pid <<= 8;
			PmtState++;
			len--;
			break;
		case PMT_ELEMENTARY_PID_LO:
			elementary_pid |= *p;
			PmtState++;
			len--;
			out->elementary_pid[out->count] = elementary_pid;
			break;
		case PMT_ES_INFO_LENGHT_HI:
			es_info_length = *p & 0x0f;
			es_info_length <<= 8;
			PmtState++;
			len--;
			break;
		case PMT_ES_INFO_LENGHT_LO:
			es_info_length |= *p;
			if (es_info_length > 0x3FF) {
				fprintf(stderr, "ParsePMT es_info_length greater than 0x3FF !\n");
				return RM_ERROR;
			}
			es_info_len = es_info_length;
			next_descriptor = es_info_len;
			len--;
			/*fprintf(stderr, "\n %2x %3x %3x", stream_type, elementary_pid, es_info_length);*/
			if ((es_info_len == 0) && (len > 4))		/* another stream follows	*/
				PmtState = PMT_STREAM_TYPE;
			else if ((es_info_len == 0) && (len <= 4))	/* CRC_32			*/
				PmtState = PMT_CRC_3;
			else						/* descriptor			*/
				PmtState++;
			out->es_ca_system_id[out->count] = 0;	
			out->es_ecm_pid[out->count] = 0x1FFF;
			out->descriptor_count[out->count] = 0;		
			out->count++;
			if ( out->count > MAX_STREAM_NUMBER ) {
				fprintf(stderr, "ParsePMT has more streams than the max=0x%x !\n", MAX_STREAM_NUMBER);
				return RM_ERROR;
			}
			break;
		case PMT_DESCRIPTOR2:
			if (es_info_len == next_descriptor) {		/* new descriptor		*/
				//fprintf(stderr, "ParsePMT elementary descriptor (2) tag=0x%X\n", *p);
				if((out->count>1) &&
				   (out->descriptor_count[out->count-1] < MAX_DESCRIPTOR_NUMBER)) {
					out->stream_descriptor[out->count-1][out->descriptor_count[out->count-1]] = *p;
					out->descriptor_count[out->count-1]++;	
				}

				out->descriptor_count[out->count] = 0;
				if ((next_descriptor > 5) && (*p == 0x09)) {
					RMuint16 ca_sys_id = 0, ecm_pid = 0x1FFF;
					ParseCADescriptor(p, &ca_sys_id, &ecm_pid);
					if ((ecm_pid != 0x1FFF) && (ca_sys_id != 0)) {
						out->es_ca_system_id[out->count - 1] = ca_sys_id;	
						out->es_ecm_pid[out->count - 1] = ecm_pid;
						fprintf(stderr, "ParsePMT elementary [%ld] descriptor CA_system_ID=0x%04x CA_PID=0x%03x\n", out->count-1, ca_sys_id, ecm_pid);
						out->es_ecm_count++;
					}
				}
				else if ((next_descriptor >=4) && (*p == 0x1e)) {
					RMuint16 id = (((RMuint16)p[2]<<8) | (RMuint16)p[3] );
					fprintf(stderr, "found id 0x%x \n", id );
					
					if( out->stream_type[out->count-1] == 0x13 ) { // sl section stream
						if( id == out->bifsID ) {
							out->bifsPid = out->elementary_pid[out->count-1];
							//fprintf(stderr, "found bifs id 0x%x pid 0x%x\n",out->bifsID, out->bifsPid  );
						}
						else if( id == out->odID ) {
							out->odPid = out->elementary_pid[out->count-1];
							//fprintf(stderr, "found od id 0x%x pid 0x%x\n",out->odID, out->odPid  );
						}
					}
					else if( out->stream_type[out->count-1] == 0x12 ) { // sl pes stream
						if( p[0] == 0x1e ) { // sl descriptor
							if( out->mp4AudioID != 0 ) {
								out->mp4VideoID = id;  // assume first pes is audio
								out->mp4VideoPid = out->elementary_pid[out->count-1];
							}
							else {
								out->mp4AudioID = id;
								out->mp4AudioPid = out->elementary_pid[out->count-1];
							}
						}
					}
				}
				next_descriptor -= (p[1] + 2);
			}
			len--;
			es_info_len--;
			if (es_info_len == 0) {
				if (len > 4) { // another stream follows
					PmtState = PMT_STREAM_TYPE;
				}
				else {
					PmtState++;
				}
			}
			break;
		case PMT_CRC_3:
		case PMT_CRC_2:
		case PMT_CRC_1:
			PmtState++;
			len--;
			break;
		case PMT_CRC_0:
			PmtState++;
			len--;
			if (len) {
				fprintf(stderr, "ParsePMT reach CRC but there are 0x%x bytes left from 0x%x !\n", len, length);
				return RM_ERROR;
			}
			//uncomment next line to process all the sections in this buffer
			//PatState = PMT_TABLE_ID;
			break;
		}
		size--;
		size1--;
		if (size1 == 0)
			p = pBuffer2;
		else
			p++;
	}
	//fprintf(stderr, "BIFS id 0x%x pid 0x%x, OD id 0x%x pid 0x%x,   ",out->bifsID, out->bifsPid, out->odID, out->odPid );
	//fprintf(stderr, "VIDEO id 0x%x pid 0x%x, AUDIO id 0x%x pid 0x%x \n",out->mp4VideoID, out->mp4VideoPid, out->mp4AudioID, out->mp4AudioPid );
	
	return RM_OK;
}

void PATCallback(RMuint8 *pBuffer1, RMuint32 size1, RMuint8 *pBuffer2, RMuint32 size2, RMstatus err, RMuint32 mask, void *context_in)
{
	/* the API is more general with two pointers - in current implementation we use only first buffer */
	struct context_per_task *context = (struct context_per_task *)context_in;
	struct PATInfo_type pat_info_temp;
	RMuint32 i;
	RMuint32 pat_compare_size;

	RMDBGLOG((CALLDBG, "PATCallback (context @0x%08lx)\n", (RMuint32)context_in));

	if(RMFAILED(err)) {
		fprintf(stderr, "%ld_PATCallback ERROR\n", context->id);
		return;
	}
	
	//	if (size1 > 188)
	//		fprintf(stderr, "multiple PAT sections %ld\n", size1);
	
	RMMemset(&pat_info_temp, 0, sizeof(struct PATInfo_type));
	err = ParsePAT(pBuffer1, size1, pBuffer2, size2, &pat_info_temp);
	if(RMFAILED(err)) {
		fprintf(stderr, "%ld_PATCallback ERROR\n", context->id);
		return;
	}
	/* compare the PAT content except for version */
	pat_compare_size = (RMuint32)&pat_info_temp.version_number_current_next_indicator - (RMuint32)&pat_info_temp.count;
	if ( RMMemcmp((void*)&context->pat_info, (void*)&pat_info_temp, pat_compare_size) != 0 ) {
		struct DemuxTask_PidEntry_type entry;

		context->pat_info = pat_info_temp;

		fprintf(stderr, "   %ld_PAT: ", context->id);
		for (i=0; i<pat_info_temp.count; i++) {
			fprintf(stderr, "[%4x %3x] ", pat_info_temp.program_number[i], pat_info_temp.program_map_pid[i]);
			/* allocate pid entries for every PMT and keep track of these PMT pid entries in one list */
		}
		fprintf(stderr, "\n");
	
		if (context->pmt_index >= pat_info_temp.count) {
			RMDBGLOG((ENABLE, "   %ld_PATCallback user selected pmt index is invalid(%ld), set pmt_index=0\n", context->id, context->pmt_index));
			context->pmt_index = 0;
		}
		if (pat_info_temp.program_number[context->pmt_index] == 0) {
			/* skip network PID*/
			context->pmt_index = (context->pmt_index + 1) % pat_info_temp.count;
		}
		RMDBGLOG((ENABLE, "   %ld_PATCallback sets pmt_pidentry_%lx pid=%lx\n", context->id,
			  context->pmt_pidentry, pat_info_temp.program_map_pid[context->pmt_index]));

		/* check if the new pmt pid is already used in the PidBank by this task.
		 The pid filter doesn't support more than one pid entry with same pid value. */
		{
			struct EMhwlibPidUsage_type pid_usage;
			RMuint32 pid_value = pat_info_temp.program_map_pid[context->pmt_index];
			err = RUAExchangeProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidUsage,
				&pid_value, sizeof(pid_value), &pid_usage, sizeof(pid_usage));
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error xchg property RMDemuxTaskPropertyID_PidUsage! %s\n", RMstatusToString(err)));
			}
			else if (pid_usage.flags) {
				if (pid_usage.flags && PID_USED_IN_PID_BANK) {
					for (i=0; i<RMmin(pid_usage.count, 4); i++) {
						// disable the same pid in the table
						entry.index = pid_usage.pid_entries[i];
						err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryDisable,
							&entry.index, sizeof(entry.index), 0);
					}
				}
				if (pid_usage.flags && PID_USED_AS_HWPCR) {
					// disable the hw pcr pid
					RMuint32 dummy;
					err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PCRPidEntryDisable, &dummy, sizeof(dummy), 0);
				}
				if ((pid_usage.flags & PID_USED_AS_PAT)
				 || (pid_usage.flags & PID_USED_AS_CAT)
				 || (pid_usage.flags & PID_USED_AS_MGT)) {
					RMDBGLOG((ENABLE, "New PMT pid is 0x%lx - is it correct PAT, CAT, MGT ?!\n", pid_value));
				}
			}
		}

		/* set the first pmt pid */
		entry.index = context->pmt_pidentry;
		entry.PidEntry.pid = pat_info_temp.program_map_pid[context->pmt_index];
		entry.PidEntry.input_type = EMhwlibPid_Ts;
		entry.PidEntry.flags = TS_FLAGS;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntry, &entry, sizeof(entry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_PMT Error RMDemuxTaskPropertyID_PidEntry", context->id));
		}

		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_PidEntryEnable, &entry.index, sizeof(entry.index), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "%ld_PMT Error RMDemuxTaskPropertyID_PidEntryEnable", context->id));
		}
		{
			struct DemuxTask_MatchSectionEntry_type section_entry;

			/* filter any version of pmt section in hardware section filter */
			context->match_section_table[1].section_entry.mask[5] = 0; 
			context->match_section_table[1].section_entry.mode[5] = 0;
			context->match_section_table[1].section_entry.comp[5] = 0;
		
			section_entry.Index = context->match_section_table[1].index;
			section_entry.SectionEntry = context->match_section_table[1].section_entry;
			err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_MatchSectionEntry,
					&section_entry, sizeof(section_entry), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error RMDemuxTaskPropertyID_MatchSectionEntry"));
			}
		}


		context->pat = TRUE;
		RMDBGLOG((ENABLE, "PAT SET!\n"));
	}

#ifndef WITH_TIME_SHIFT
	if(context->section_filter_based_on_new_version & 1) {
		/* filter only a new pat version in hardware section filter - in order to optimize CPU usage on standalone */
		struct DemuxTask_MatchSectionEntry_type section_entry;

		/* version_number on bit 5..1, current_next_indicator on bit 0 */
		context->match_section_table[0].section_entry.mask[5] = 0x3f; 
		context->match_section_table[0].section_entry.mode[5] = ~0x3f; 
		context->match_section_table[0].section_entry.comp[5] = pat_info_temp.version_number_current_next_indicator;
	

		section_entry.Index = context->match_section_table[0].index;
		section_entry.SectionEntry = context->match_section_table[0].section_entry;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_MatchSectionEntry,
				&section_entry, sizeof(section_entry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error RMDemuxTaskPropertyID_MatchSectionEntry"));
		}
	}
#endif
}

void PMTCallback(RMuint8 *pBuffer1, RMuint32 size1, RMuint8 *pBuffer2, RMuint32 size2, RMstatus err, RMuint32 mask, void *context_in)
{
	/* the API is more general with two pointers - in current implementation we use only first buffer */
	struct context_per_task *context = (struct context_per_task *)context_in;
	static struct PMTInfo_type pmt_info_temp;
	RMuint32 i, j;
	RMuint32 pmt_compare_size;
	RMDBGLOG((CALLDBG, "PMTCallback (context @0x%08lx)\n", (RMuint32)context_in));
	
	if(RMFAILED(err)) {
		fprintf(stderr, "%ld_PMTCallback ERROR\n", context->id);
		return;
	}
	
	//	if (size1 > 188)
	//		fprintf(stderr, "%ld_PMT multiple sections in callback %ld\n", context->id, size1);
	
	RMMemset(&pmt_info_temp, 0, sizeof(struct PMTInfo_type));
	err = ParsePMT(pBuffer1, size1, pBuffer2, size2, &pmt_info_temp);
	if(RMFAILED(err)) {
		fprintf(stderr, "%ld_PMTCallback ERROR\n", context->id);
		return;
	}
	for (i=0; i<context->pat_info.count; i++) {
		if ( pmt_info_temp.program_number == context->pat_info.program_number[i] )
			break;
	}
	if (i >= context->pat_info.count) {
		fprintf(stderr, " %ld_PMT - pat not found yet\n", context->id);
		return;
	}
	if (0) { /* debug messages */
		fprintf(stderr, "   %ld_PMT: index=%ld prog=0x%04x pid=0x%x ", context->id,
			i, pmt_info_temp.program_number, context->pat_info.program_map_pid[i]);
		for (j=0; j<pmt_info_temp.count; j++) {
			fprintf(stderr, "[0x%04x 0x%03x] ", pmt_info_temp.stream_type[j], pmt_info_temp.elementary_pid[j]);
		}
		fprintf(stderr, "\n");
	}
	/* compare the PMT content except for version and update */
	pmt_compare_size = (RMuint32)&pmt_info_temp.version_number_current_next_indicator - (RMuint32)&pmt_info_temp.count;
	if ( (RMMemcmp((void*)&context->pmt_info[i], (void*)&pmt_info_temp, pmt_compare_size) != 0) ) {

		pmt_info_temp.update = TRUE;
		context->pmt_info[i] = pmt_info_temp;
		
		fprintf(stderr, "   %ld_PMT: index=%ld prog=0x%04x pid=0x%x pcr_pid=0x%x ", context->id, i,
			pmt_info_temp.program_number, context->pat_info.program_map_pid[i], pmt_info_temp.pcr_pid);
		for (i=0; i<pmt_info_temp.count; i++) {
			fprintf(stderr, "[0x%04x 0x%03x] ", pmt_info_temp.stream_type[i], pmt_info_temp.elementary_pid[i]);
		}
		fprintf(stderr, "\n");
		for (i=0; i<pmt_info_temp.ecm_count; i++) {
			fprintf(stderr, "   %ld_PMT: ", context->id);
 			fprintf(stderr, "ecm=0x%04x ca=0x%04x emm=0x%04x\n", pmt_info_temp.ecm_pid[i], pmt_info_temp.ca_system_id[i],
				GetEMMPid(context, pmt_info_temp.ca_system_id[i]));
		}
		if (pmt_info_temp.es_ecm_count != 0) {
			for (i=0; i<pmt_info_temp.count; i++) {
				fprintf(stderr, "   %ld_PMT: ", context->id);
 				fprintf(stderr, "es_ecm=0x%04x es_ca=0x%04x es_emm=0x%04x\n", pmt_info_temp.es_ecm_pid[i], pmt_info_temp.es_ca_system_id[i],
					GetEMMPid(context, pmt_info_temp.es_ca_system_id[i]));
			}
		}
		context->pmt = TRUE;
	}

#ifndef WITH_TIME_SHIFT
	if(context->section_filter_based_on_new_version & 2) {
		/* filter only a new pmt version in hardware section filter - in order to optimize CPU usage on standalone */
		struct DemuxTask_MatchSectionEntry_type section_entry;
	
		/* version_number on bit 5..1, current_next_indicator on bit 0 */
		context->match_section_table[1].section_entry.mask[5] = 0x3f; 
		context->match_section_table[1].section_entry.mode[5] = ~0x3f; /* negative mode */
		context->match_section_table[1].section_entry.comp[5] = pmt_info_temp.version_number_current_next_indicator;
		
		section_entry.Index = context->match_section_table[1].index;
		section_entry.SectionEntry = context->match_section_table[1].section_entry;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_MatchSectionEntry,
				&section_entry, sizeof(section_entry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error RMDemuxTaskPropertyID_MatchSectionEntry"));
		}
	}
#endif
}


/************************************************************************
 * MPEG-2-system.pdf (ISO/IEC 13818-1: 1994(E)
 * 2.4.4.6 Conditional access table
 ************************************************************************/
RMstatus ParseCAT(RMuint8 *pBuffer1, RMuint32 size1, RMuint8 *pBuffer2, RMuint32 size2, struct CATInfo_type *out)
{

	/*
	 * function assumes to be called on correct CAT boundaries
	 */
#define CAT_TABLE_ID			1
#define CAT_LENGTH_HI			2
#define CAT_LENGTH_LO			3
#define CAT_RESERVED_0			4
#define CAT_RESERVED_1			5
#define CAT_VERSION_NUMBER		6
#define CAT_SECTION_NUMBER		7
#define CAT_LAST_SECTION_NUMBER		8
#define CAT_DESCRIPTOR_TAG		9
#define CAT_DESCRIPTOR_LENGTH		10
#define CAT_CA_SYSTEM_ID_HI		11
#define CAT_CA_SYSTEM_ID_LO		12
#define	CAT_CA_PID_HI			13
#define	CAT_CA_PID_LO			14
#define	CAT_CA_PRIVATE_DATA		15
#define CAT_CRC_3			16
#define CAT_CRC_2			17
#define CAT_CRC_1			18
#define CAT_CRC_0			19

	RMuint32 CatState = CAT_TABLE_ID;
	RMuint16 length = 0, descriptor_tag = 0, descriptor_length = 0,
		ca_system_id = 0, ca_pid = 0;
	RMuint8	section_number, last_section_number;
	RMuint32 size = size1 + size2;
	RMuint16 len = 0;
	RMuint8 *p = NULL;

	RMDBGLOG((CALLDBG, "parseCAT\n"));
	
	if (out == 0) return RM_ERROR;
		
	out->count = 0;
	if (pBuffer1 && size1) p = pBuffer1;

	while (size) {
		switch (CatState) {
		case CAT_TABLE_ID:
			if (*p != 0x01) {
				fprintf(stderr, "ParseCAT table_id=%02x instead of 0x01 !\n", *p);
				return RM_ERROR;
			}
			CatState++;
			break;
			
		case CAT_LENGTH_HI:	/* section_syntax_indicator and length_hi*/
			if ((*p & 0xC0) != 0x80) {
				fprintf(stderr, "ParseCAT section_syntax_indicator 0 !\n");
				return RM_ERROR;
			}
			length = *p & 0x0F;
			length <<= 8;
			CatState++;
			break;
			
		case CAT_LENGTH_LO:
			length |= *p;
			len = length;
			CatState++;
			break;
			
		case CAT_RESERVED_0:
			CatState++;
			len--;
			break;
			
		case CAT_RESERVED_1:
			CatState++;
			len--;
			break;
			
		case CAT_VERSION_NUMBER:
			/* version_number on bit 5..1, current_next_indicator on bit 0 */
			out->version_number_current_next_indicator = *p & 0x3F;
			if ((*p & 1) == 0x00) {
				fprintf(stderr, "ParseCAT the Conditional Access Table sent is not yet applicable!\n");
				return RM_ERROR;
			}
			RMDBGLOG((DISABLE, "ParseCAT version number = %x current_next_indicator = %x\n",
				out->version_number_current_next_indicator>>1,
				out->version_number_current_next_indicator & 1));
			CatState++;
			len--;
			break;
			
		case CAT_SECTION_NUMBER:
			if (*p != 0x00) {
				fprintf(stderr, "ParseCAT no multiple sections in CAT supported yet !\n");
				return RM_ERROR;
			}
			section_number = *p;
			CatState++;
			len--;
			break;
			
		case CAT_LAST_SECTION_NUMBER:
			last_section_number = *p;
			CatState++;
			len--;
			break;
			
		case CAT_DESCRIPTOR_TAG:
			if (len < 10) {
				fprintf(stderr, "ParseCAT not enough data for descriptor and crc !\n");
				return RM_ERROR;
			}
			descriptor_tag = *p;
			CatState++;
			len--;
			break;

		case CAT_DESCRIPTOR_LENGTH:
			descriptor_length = *p;
			if (descriptor_tag != 0x09) {	/* not CA descriptor	*/
				CatState = CAT_CA_PRIVATE_DATA;
				if (descriptor_length == 0) descriptor_length = 1;
			}
			else {
				CatState++;
			}
			len--;
			break;
			
		case CAT_CA_SYSTEM_ID_HI:
			ca_system_id = *p;
			ca_system_id <<= 8;
			descriptor_length--;
			CatState++;
			len--;
			break;
			
		case CAT_CA_SYSTEM_ID_LO:
			ca_system_id |= *p;
			out->ca_system_id[out->count] = ca_system_id;
			descriptor_length--;
			CatState++;
			len--;
			break;
			
		case CAT_CA_PID_HI:
			ca_pid = *p & 0x1F;
			ca_pid <<= 8;
			descriptor_length--;
			CatState++;
			len--;
			break;
			
		case CAT_CA_PID_LO:
			ca_pid |= *p;
			out->emm_pid[out->count] = ca_pid;
			out->count++;
			if (out->count > MAX_PROGRAM_NUMBER) {
				fprintf(stderr, "ParseCAT has more programs than the max=0x%x !\n", MAX_PROGRAM_NUMBER);
				return RM_ERROR;
			}
			
			len--;
			descriptor_length--;
			if (descriptor_length > 0) {		/* private_data_byte	*/
				
				CatState = CAT_CA_PRIVATE_DATA;
			}
			else {				/* no private_data_byte	*/
				if (len > 4) {			/* another CA descriptor*/
					CatState = CAT_DESCRIPTOR_TAG;
				}
				else {
					CatState = CAT_CRC_3;
				}
			}
			break;

		case CAT_CA_PRIVATE_DATA:
			len--;
			descriptor_length--;
			if (descriptor_length == 0) {
				if (len > 4) {		/* another CA descriptor*/
					CatState = CAT_DESCRIPTOR_TAG;
				}
				else {
					CatState = CAT_CRC_3;
				}
			}
			break;
			
		case CAT_CRC_3:
		case CAT_CRC_2:
		case CAT_CRC_1:
			CatState++;
			len--;
			break;

		case CAT_CRC_0:
			CatState++;
			len--;
			if (len) {
				fprintf(stderr, "ParseCAT reach CRC but there are 0x%x bytes"
					" left from 0x%x !\n", len, length);
				return RM_ERROR;
			}
			break;
		}
		size--;
		size1--;
		if (size1 == 0) 
			p = pBuffer2;
		else 
			p++;
	}
	
	return RM_OK;
}

/************************************************************************
 *
 ************************************************************************/
void CATCallback(RMuint8 *pBuffer1, RMuint32 size1, RMuint8 *pBuffer2, RMuint32	size2, RMstatus	err, RMuint32 mask, void *context_in)
{

	/*
	 * The API is more general with two pointers
	 * - in current implementation we use only first buffer
	 */
	struct context_per_task *context = (struct context_per_task *)context_in;
	struct	CATInfo_type cat_info_temp;
	RMuint32	i;
	RMuint32	cat_compare_size;

	RMDBGLOG((CALLDBG, "CATCallback (context @0x%08lx)\n", (RMuint32)context_in));

	if (RMFAILED(err)) {
		fprintf(stderr, "CATCallback ERROR\n");
		return;
	}
	
#if (0)	
	if (size1 > 188) 
		fprintf(stderr, "multiple CAT sections %ld\n", size1);
#endif
	
	RMMemset(&cat_info_temp, 0, sizeof(struct CATInfo_type));
	ParseCAT(pBuffer1, size1, pBuffer2, size2, &cat_info_temp);

	/* compare the CMT content except for version and update */
	cat_compare_size = (RMuint32)&cat_info_temp.version_number_current_next_indicator - (RMuint32)&cat_info_temp.count;
	if (RMMemcmp((void*)&context->cat_info, (void*)&cat_info_temp, cat_compare_size) != 0) {
		context->cat_info = cat_info_temp;
		
		fprintf(stderr, "   %ld_CAT: ", context->id);
		for (i = 0; i < cat_info_temp.count; i++) {
			fprintf(stderr, "[%04x %04x] ", cat_info_temp.ca_system_id[i], cat_info_temp.emm_pid[i]);
			/*
			 * Allocate pid entries for every PMT and keep track of these
			 * PMT pid entries in one list
			 */
		}
		fprintf(stderr, "\n");
		
		context->cat = TRUE;
	}

	{ /* filter only a new cat version in hardware section filter - in order to optimize CPU usage on standalone */
		struct DemuxTask_MatchSectionEntry_type section_entry;

		/* version_number on bit 5..1, current_next_indicator on bit 0 */
		context->match_section_table[3].section_entry.mask[5] = 0x3f; 
		context->match_section_table[3].section_entry.mode[5] = ~0x3f; 
		context->match_section_table[3].section_entry.comp[5] = cat_info_temp.version_number_current_next_indicator;
	

		section_entry.Index = context->match_section_table[3].index;
		section_entry.SectionEntry = context->match_section_table[3].section_entry;
		err = RUASetProperty(context->pRUA, context->demux_task, RMDemuxTaskPropertyID_MatchSectionEntry,
				&section_entry, sizeof(section_entry), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error RMDemuxTaskPropertyID_MatchSectionEntry"));
		}
	}
}


RMstatus InitTableVariables(struct context_per_task *context)
{

	RMDBGLOG((CALLDBG, "initTableVariables (context @0x%08lx)\n", (RMuint32)context));
	
	/* ############## AES_CBC_PRECIPHER CODE BEGIN ############# */
	if (context->dtcpip_streaming == TRUE || context->test_aes_precipher == TRUE) 
		context->key_size = 16;
	/* ############## AES_CBC_PRECIPHER CODE BEGIN ############# */
		
	if (context->app_type == input_record) {
		context->match_section_table_count = 0;
		context->pid_table_count = 0;
		
		context->output_table = (struct Output_type *) RMMalloc(sizeof(struct Output_type));
		if (context->output_table == NULL) {
			return RM_FATALOUTOFMEMORY;
		}
		context->output_table_count = 1;
	}
	else if (context->app_type != program_stream_parsing) {
		context->match_section_table = (struct  MatchSectionEntry_type *) RMMalloc(sizeof(gmatchSectionTable));
		if (context->match_section_table == NULL) {
			return RM_FATALOUTOFMEMORY;
		}
		RMMemcpy(context->match_section_table, gmatchSectionTable, sizeof(gmatchSectionTable));
		context->match_section_table_count = sizeof(gmatchSectionTable)/sizeof(struct MatchSectionEntry_type);
		
		context->pid_table = (struct PidEntry_type *) RMMalloc(sizeof(gPidTable));
		if (context->pid_table == NULL) {
			return RM_FATALOUTOFMEMORY;
		}
		RMMemcpy(context->pid_table, gPidTable, sizeof(gPidTable));
		context->pid_table_count = sizeof(gPidTable)/sizeof(struct PidEntry_type);
		
		context->output_table = (struct Output_type *) RMMalloc(sizeof(gOutputTable));
		if (context->output_table == NULL) {
			return RM_FATALOUTOFMEMORY;
		}
		RMMemcpy(context->output_table, gOutputTable, sizeof(gOutputTable));
		context->output_table_count = sizeof(gOutputTable)/sizeof(struct Output_type);
		RMDBGLOG((ENABLE, "init output_table 0x%lx with statically defined gOutputTable, count %lu\n", context->output_table, context->output_table_count));

		if (context->app_type == dvbcsa_decryption) {
			RMDBGLOG((ENABLE, "\ndvbcsa_decryption application\n"));
			context->key_size = 8;
		}
		if ((context->app_type == aes_cbc_decryption) || 
			(context->app_type == aes_ecb_decryption) ||
			(context->app_type == aes_nsa_decryption) ||
			(context->app_type == aes_ofb_decryption) ) {
			RMDBGLOG((ENABLE, "\naes_?_decryption application\n"));
			context->key_size = 16;
		}

		RMDBGLOG((ENABLE, "\npid_filter_section application: pid_table_count=%ld output_table_count=%ld\n",
			  context->pid_table_count, context->output_table_count));
	}
	else {
		context->pes_table = (struct PesEntry_type *) RMMalloc(sizeof(gPesTable));
		if (context->pes_table == NULL) {
			return RM_FATALOUTOFMEMORY;
		}
		RMMemcpy(context->pes_table, gPesTable, sizeof(gPesTable));
		if( context->SourceType == SourceType_m1s ) {      // if the app type is m1s
			context->pes_table[1].stream_id = 0xc0 | context->audio_subid; 
			context->pes_table[1].substream_id = 0x0;
			context->pes_table[2].stream_id = 0x0;     // zeroed spu
			context->pes_table[2].substream_id = 0x0;
		}
		else if (context->SourceType == SourceType_dvd) {
			context->pes_table[0].stream_id = 0xe0;    // video
			context->audio_pid = (context->audio_opt->Codec == AudioDecoder_Codec_MPEG1) ? 0xC0:0xBD;
			switch(context->audio_opt->Codec) {
				case AudioDecoder_Codec_PCM:
					context->pes_table[1].substream_id = 0xa0 | context->audio_subid;
					break;
				case AudioDecoder_Codec_DTS:
					context->pes_table[1].substream_id = 0x88 | context->audio_subid;
					break;
				case AudioDecoder_Codec_MPEG1:
					if (context->audio_pid != (0xC0 /*+ Tasks[i].audio_subid*/)) {
						fprintf(stderr, "\n***************** audio_pid audio_subid conflict *****************\n");
						fprintf(stderr, "*** for mpeg audio select either audio_pid, either audio_subid ***\n");
						fprintf(stderr, "******************************************************************\n\n");
					}
					context->pes_table[1].stream_id = 0xc0 | context->audio_subid;
					context->pes_table[1].substream_id = 0;
					break;
				default:
					context->pes_table[1].substream_id = 0x80 | context->audio_subid;
					break;
			}
			context->pes_table[2].stream_id = 0xbd;
			context->pes_table[2].substream_id = 0x20 | context->spu_subid;
		}
		context->pes_table_count = sizeof(gPesTable)/sizeof(struct PesEntry_type);
		
		context->output_table = (struct Output_type *) RMMalloc(sizeof(gPesOutputTable));
		if (context->output_table == NULL) {
			return RM_FATALOUTOFMEMORY;
		}
		RMMemcpy(context->output_table, gPesOutputTable, sizeof(gPesOutputTable));
		context->output_table_count = sizeof(gPesOutputTable)/sizeof(struct Output_type);
		RMDBGLOG((ENABLE, "\nprogram_stream_parsing application\n"));
	}

	return RM_OK;
}


void TTXCallback(RMuint8 *pBuffer1, RMuint32 size1, RMuint8 *pBuffer2, RMuint32 size2, RMstatus err, RMuint32 mask, void *context_in)
{
	struct context_per_task *context = (struct context_per_task *)context_in;
	if( context->dcc_info->ttx_sw_decoder ) {
		RMstatus err = RMTTXDecode( context->dcc_info->ttx_sw_decoder, pBuffer1, size1 );
		if( RMFAILED(err) ) { // flush the buffer and start filling buffer again
			RMTTXFlush( context->dcc_info->ttx_sw_decoder );
		}
	}
	else
		RMDBGLOG((ENABLE, "No TTX DECODER\n"));

	return;
}

