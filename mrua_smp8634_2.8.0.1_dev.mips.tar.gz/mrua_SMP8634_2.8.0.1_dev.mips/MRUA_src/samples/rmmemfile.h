/*****************************************
 Copyright © 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmmemfile.h
  @brief  

  Implement file operations on a memory region.

  @author Oriol Prieto Gasco
  @date   2005-04-18
*/

#ifndef __RMMEMFILE_H__
#define __RMMEMFILE_H__

RM_EXTERN_C_BLOCKSTART

/** 
    Allocate 'size' bytes and creates an RMfile handler.
    The buffer will be freed when RMCloseFile is called 
    on the returned RMfile.
*/
RMfile RMCreateMemoryFile(RMuint32 size);

/** 
    Create an RMfile handler on a memory region starting 
    at position 'buf', of size 'size'.
    The memory region is NOT freed when RMCloseFile is 
    called on the returned RMfile.
*/

RMfile RMOpenMemoryFile(RMuint8 *buf, RMuint32 size);

RM_EXTERN_C_BLOCKEND

#endif // __RMMEMFILE_H__
