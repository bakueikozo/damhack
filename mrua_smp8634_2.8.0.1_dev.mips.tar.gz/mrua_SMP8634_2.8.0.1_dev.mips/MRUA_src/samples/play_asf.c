/*
 *
 * Copyright (c) Sigma Designs, Inc. 2002. All rights reserved.
 *
 */

/**
	@file play_asf.c
	@brief sample application to access the Mambo chip and test DMA transfers
	
	@author Julien Soulier
   	@ingroup dccsamplecode
*/

/*
  ******************************************************************************************
  This file is part of libsamples library, therefore *NO* static variables should be defined
  ******************************************************************************************
*/


#define RELEASE_BUFFER_ENABLE	DISABLE

#ifdef CHECK_BUFFER_PTS
#define CHECK_BUFFER_4_FREAD	1
#define CHECK_BUFFER_4_AUDIO	1
#define CHECK_BUFFER_4_VIDEO	1
#endif

#define _LARGEFILE64_SOURCE 1 // Required for large files (> 4GB)

#include "sample_os.h"


#define ALLOW_OS_CODE 1
#include "../dcc/include/dcc.h"

#include "../rmasfdemux/include/rmasfdemuxapi.h"
#include "../rmasfdemux/include/wmdrm.h"
#include "../rmasfdemux/include/wmdrmopl.h"

#include "common.h"

#include "../rmwmaprodecoder/include/rmwmaprodefine.h"
#include "../rmwmaprodecoder/include/rmwmaprodecoderapi.h"

/* #### Begin CARDEA code #### */
#include "rmupnp/rmlibwmdrmnd/include/ms_cardea.h"
#if (EM86XX_CHIP == EM86XX_CHIPID_TANGO2)
void test_cci( void *cardea_context );
#endif
/* #### End CARDEA code #### */

/* ################## Begin DTCP code ################### */
#if (EM86XX_CHIP == EM86XX_CHIPID_TANGO15)
#include "../rmdtcp/include/dtcp_session.h"
#else
#include "../rmdtcpapi/include/dtcp_session.h"
#endif
/* ############### End DTCP code ####################### */

#include "bcc.h"

#define WAIT_COMMAND_TIMEOUT_US	(TIMEOUT_10MS)	  // 10 ms
#define GETBUFFER_TIMEOUT_US	(TIMEOUT_10MS)	  // 10 ms
#define SENDDATA_TIMEOUT_US		1000000	  //  1 sec
#define WAIT_EOS_TIMEOUT_US		20000000  // 20 sec

#define CODEC_SPECIFIC_DATA_MAX_SIZE_BYTES  32

/*
To correctly dimension the fifos for wmv we have to find the average of:
 - VideoBitRate, VideoFrameRate
 - AudioBitRate, AudioFrameRate, that will be determined from AudioBlockSize.
The video PTS fifo size is 600 entries ~= 10 sec at 60frames/sec.
The audio PTS fifo size is 300 entries ~= 10 sec at 30frames/sec.
We could dimension the bitstream fifos to 10 seconds of video/audio in order to
compensate for the wmv files with video/audio not well interleaved.
The drift vpts-apts can be 1.5 sec for Dolphins, 3 sec for KidRock, 4 sec for liquid_1.
Ex: For liquid_1.wmv:
	VideoBitRate = 8,494,469bits => 1063kBytes/sec. FrameRate = 60.
	AudioBitRate =   193,758bits => 25kBytes/sec. BlockSize = 0x1000 bytes.
	Max vpts-apts = 5sec.
*/


#define ASF_DMA_BUFFER_SIZE_LOG2	16		// 64kB
#define ASF_DMA_BUFFER_COUNT		64		// 32*64kB ~= 2MB

#ifdef WMAPRO_V1
#define AUDIO_DMA_BUFFER_SIZE_LOG2	16		// 64kB
#define AUDIO_DMA_BUFFER_COUNT		2		// 2*64kB ~= 128KB
#else
#define AUDIO_DMA_BUFFER_SIZE_LOG2	17		// 128kB
#define AUDIO_DMA_BUFFER_COUNT		2		// 2*128kB ~= 256KB
#endif

#define VIDEO_XFER_FIFO_COUNT	(ASF_DMA_BUFFER_COUNT * (1<<ASF_DMA_BUFFER_SIZE_LOG2) / 2048)		// average video packet size = 2k
#define AUDIO_XFER_FIFO_COUNT	(AUDIO_DMA_BUFFER_COUNT * (1<<AUDIO_DMA_BUFFER_SIZE_LOG2) / 2048)	// average audio packet size = 2k


/* do NOT increase these values unless you have a reason to, otherwise, curacao wont be able to run due to lack of memory */
#define VIDEO_FIFO_SIZE		(5*1024*1024)	// 5s @ 1MB/s
#define AUDIO_FIFO_SIZE		(1*1024*1024)	// 1s @ 1MB/s 

#define ADDITIONAL_WMAPRO_FIFO_SIZE	1024*1024 

#define KEYFLAGS (SET_KEY_DISPLAY | SET_KEY_PLAYBACK | SET_KEY_AUDIO | SET_KEY_DEBUG | SET_KEY_SPI)

// uncomment next line for debug information
//#define DISPLAY_VIDEO_STREAM_PAYLOAD_INFO
// uncomment next line to save all input compressed frames into separate files
//#define SAVE_INPUT_FRAMES



#if 0
#define PAYLOADDBG ENABLE
#else
#define PAYLOADDBG DISABLE
#endif

#if 0
#define IFRAMEDBG ENABLE
#else
#define IFRAMEDBG DISABLE
#endif


#if 0
#define TRICKDBG ENABLE
#else
#define TRICKDBG DISABLE
#endif

#if 0
#define SENDDBG ENABLE
#else
#define SENDDBG DISABLE
#endif

#if 0
#define WMAPRODBG	ENABLE
#else
#define WMAPRODBG	DISABLE
#endif

#if 0
#define DISPLAY_AUDIO_BITRATE
#endif

#if 0
#define DISPLAY_VIDEO_BITRATE
#endif

#if 0
#define KEYDBG ENABLE
#else
#define KEYDBG DISABLE
#endif

#if 0
#define VC1_STARTCODE_DBG ENABLE
#else
#define VC1_STARTCODE_DBG DISABLE
#endif

#define READ_DBG DISABLE


#define MAX_INDEX_NUMBER 5
#define INDEX_BUFFER_SIZE (200 * 1024)


typedef enum {
	RMasfIFrameFSM_Disabled = 0,
	RMasfIFrameFSM_Init,
	RMasfIFrameFSM_WaitIFrameMONChange,
	RMasfIFrameFSM_SkipNext
}RMasfIFrameFSMstates;

#ifndef WITH_MONO
typedef struct {
	RMuint16 languageIDCount;
	RMuint16 languageIDIndex;
	RMnonAscii * languageID;
	RMuint8 languageIDLength;
} RMasfdemuxLanguageID;
#endif //WITH_MONO


#define RM_DEVICES_STC 0x1
#define RM_DEVICES_VIDEO 0x2
#define RM_DEVICES_AUDIO 0x4

#define RM_STREAM_VIDEO 0x1
#define RM_STREAM_AUDIO 0x2

#define RM_SKIP_TO_RESYNC 0x1

#define MAX_NUMBER_OF_AUDIO_STREAMS 16

struct wmapro_buffer_info {
	RMbool new_buffer;
	RMuint8 *ptr;
	RMuint32 size;
	struct emhwlib_info Info;
	RMuint32 Stream_Number;
	RMuint32 Media_Object_Number;
	RMuint32 fSendPTS;
#ifndef _ENABLE_WMALSL_
	void *pBuffer;
#endif // _ENABLE_WMALSL_
};


struct priv_cmdline {
	RMuint32 dummy;
};

struct stream_info {
 	RMuint32		stream_number;
 	RMuint8			*aes_buf;
 	RMuint32		aes_buf_len;
};


enum RMProcess_key_goto
{
    RMProcess_key_goto_none=1,
    RMProcess_key_goto_got_key_but_noaction,
    RMProcess_key_goto_nojump_but_exit,
    RMProcess_key_goto_cleanup,
    RMProcess_key_goto_mainloop_seek,
    RMProcess_key_goto_wmapro_decoder_delete
};

struct RMaudio_parameters {

      RMbool enabled;
      unsigned short Codec_ID;
      unsigned short Number_of_Channels; 
      unsigned long Samples_Per_Second;
      unsigned long Average_Number_of_Bytes_Per_Second;
      unsigned short Block_Alignment;
      unsigned short Bits_Per_Sample;
      unsigned char Codec_Specific_Data[CODEC_SPECIFIC_DATA_MAX_SIZE_BYTES];
      unsigned long Codec_Specific_Data_Size;
}; 

RMuint32 RMSupported_codec_list[] = {0x161,0x7A21,0x7A21,0x162,0x163,0x1};

struct asf_context {
	struct RUA *pRUA;
	struct RUABufferPool *pDMA;
	struct RUABufferPool *pDMAuncompressed;
	unsigned char *UncompressedBuffer;
	unsigned char *SequenceHeaderBuffer;
	RMbool FirstSystemTimeStamp;

	struct dcc_context *dcc_info;
	struct RM_PSM_Context *PSMcontext;

	RMuint32 video_stream_index;
	RMint32 audio_stream_index;
	RMuint32 cmd;
	RMbool SendVideoData;
	RMuint32 prev_video_media_object_number;
	RMuint32 video_frame_counter;
	RMuint32 VideoByteCounter;
	RMbool SendVideoPts;
	RMuint32 video_last_pts;	// used for video hack
	RMuint32 video_vop_tir;
#ifdef CHECK_BUFFER_PTS
	RMuint32 video_pts;
#endif
	RMuint32 videoscaler_id;

	RMbool SendAudioData;
	RMuint32 prev_audio_media_object_number;
	RMuint32 audio_frame_counter;
	RMuint32 AudioByteCounter;
	RMbool SendAudioPts;
 	RMuint32 audio_vop_tir;

	RMbool isWMAPRO;

	RMuint32 start_ms; 	

#ifdef CHECK_BUFFER_PTS
	RMuint32 audio_pts;
	RMuint32 max_avpts_diff;
#endif

	ExternWMAProVdecoder vDecoder;

	ExternalRMASFDemux vASFDemux;

	RMbool firstIFrame;
	RMbool isIFrameMode;
	RMbool isTrickMode;
	RMint32 IFrameSize;
	RMbool SeekAudio;
	RMbool SeekVideo;
	RMuint32 PrevAudioMON;
	RMuint32 PrevVideoMON;


//	struct AudioDecoder_WMAParameters_type wma_params[MAX_NUMBER_OF_AUDIO_STREAMS];	// David: I want it to pass information to payload decoder
	RMuint32 WMAPROBitsPacketLength;
    struct RMaudio_parameters audio_parameters[MAX_NUMBER_OF_AUDIO_STREAMS];
	
    RMfile f_bitstream;

#ifdef _DUMP_INT_FILE_
	FILE *intfile;
#endif

	
#ifdef SAVE_INPUT_FRAMES
	int f_compressed_frames;
#endif

	RMbool video_decoder_initialized;
	RMbool audio_decoder_initialized;

	RMuint32 Compression_ID;
	struct VideoDecoder_WMV9VSProp_type wmv9_prop;
	struct VideoDecoder_DIVX3VSProp_type divx3_prop;

	RMuint32 asf_packetSize;
	RMuint64 asf_Header_Object_Size;

	RMasfIFrameFSMstates IFrameFSMState;
	RMuint32 inband_aspect_ratio_x;
	RMuint32 inband_aspect_ratio_y;
	RMuint32 save_inband_aspect_ratio_y;
	RMuint32 save_inband_aspect_ratio_x;
	RMuint16 inband_aspect_ratio_stream_index;

	RMint32 drmError;
	RMbool isContentEncrypted;
	RMbool unsupported_video;

	struct SurfaceAspectRatio_type InBandAspectRatioParams;
	RMbool setAspectRatio;
	RMuint64 Preroll;
	RMbool PrerollSET;
	RMuint64 Duration;
	RMbool ignoreCallback; /* when we catch a key during a callback, we must ignore all subsequent calls to the payload
				  callback  until 'PROCESS_KEY' process it. 
				  Required for 'stop', 'quit', 'seek[zero]' and 'iframe' */
	RMuint64 CurrentDisplayPTS; /*used for 'accurate' iframe seeking when resuming from iframe mode */
	RMint32 IFrameDirection;
	RMbool VideoStreamFound;
	RMbool AudioStreamFound;
	RMuint64 lastSTC;
	RMuint64 accurateAudioSeekTo;
	RMbool IgnoreAudio;

	RMuint32 Video_Codec_Specific_Data_Received;
	RMuint32 Audio_Codec_Specific_Data_Received;

	RMuint32 ContiguousVideoLength;
	RMuint32 ContiguousAudioLength;
	RMuint64 video_time_start;
	RMuint64 video_time_end;
	RMuint64 audio_time_start;
	RMuint64 audio_time_end;
	RMuint64 video_time_stamp;
	RMuint64 audio_time_stamp;
	RMint32 min_diff;
	RMint32 max_diff;
	RMuint32 packet_counter;

	RMbool filePropSET;
	RMbool langPropSET;
	RMasfdemuxLanguageID lang[MAX_NUMBER_OF_AUDIO_STREAMS];

#ifdef DISPLAY_AUDIO_BITRATE
	RMuint32 prev_timeA;
	RMuint32 prev_MON_A;
	RMuint32 nb_bytes_since_prev_timeA;
	RMuint32 byteRateA;
	RMuint32 maxByteRateA;
#endif

#ifdef DISPLAY_VIDEO_BITRATE
	RMuint32 prev_timeV;
	RMuint32 prev_MON_V;
	RMuint32 nb_bytes_since_prev_timeV;
	RMuint32 byteRateV;
	RMuint32 maxByteRateV;
#endif

	/* #### Begin CARDEA code #### */
	void * cardea_context;
	RMuint8 sample_id[8];
	/* #### End CARDEA code #### */

	RMbool fDecodingWMAPROPacket;
	struct RMfifo *wmapro_fifo;
	struct wmapro_buffer_info *pread_wmapro_info;

	RMbool bcc_enabled;
	struct bcc *pbcc;

	RMuint32 prebufferedBytes;

	// for VC1
	RMuint8 *seqHeader;
	RMuint32 seqHeaderSize;
	RMbool addSeqHeader;
	RMbool addEntryHeader;
	RMbool addFrameHeader;
	RMuint8 *entryHeader;
	RMuint32 entryHeaderSize;
	RMbool isVC1;
	RMbool getStartCodeBuffer;
	RMuint8 *startCodeBuffer;
	RMuint32 startCodeBufferSize;
	RMuint32 startCodeBufferLeft;

	// to allow sending audio when in trickmodes
	RMbool sendAudioTrickmode;

	RMbool monitorFIFOs;
	struct timeval last;

	RMbool bypass_drm;
	RMbool linear_playback;

	RMuint32 audioStreams;
	RMuint32 audioStreamTable[10];

	RMuint32 audioInstances;

	struct video_cmdline *video_opt;
	struct display_cmdline *disp_opt;
	struct audio_cmdline *audio_opt;
	struct playback_cmdline *play_opt;
#ifndef WITH_MONO
	struct display_context disp_info;
#endif

	struct priv_cmdline priv_opt;

	struct RM_PSM_Actions actions;
 	struct stream_info stream_table[4];

	RMuint64 lastVideoPTS;

	void **dmabuffer_array;
	RMuint32 dmabuffer_index;
	
	RMbool audioSamplesDropped;
	RMstatus audioSetupStatus;
	RMstatus videoSetupStatus;
    
	enum RMProcess_key_goto gotoRequest; 
	
	RMuint64 stc_offset_ms;
};





/* prototypes */
static RMstatus Stop(struct asf_context *pSendContext, RMuint32 devices);
static RMstatus Play(struct asf_context * pSendContext, RMuint32 devices, enum DCCVideoPlayCommand mode);
static RMstatus setup_video_decoder(struct asf_context *pSendContext);
static RMstatus setup_audio_decoder(struct asf_context *pSendContext);
static RMstatus SyncTimerWithDecoderPTS(struct asf_context *pSendContext);
static RMstatus restartAudioDecoder(struct asf_context * pSendContext);
static void flush_wmaproFIFO(struct asf_context *pSendContext);

static RMuint64 round_int_div(RMuint64 numerator, RMuint32 divisor);

static RMstatus asf_FastAudioRecovery(struct asf_context * pSendContext);
static RMstatus asf_ResumeFromIFrameTrickMode(struct asf_context * pSendContext);
static RMstatus asf_seek(struct asf_context * pSendContext, RMuint64 time);
static RMstatus asf_InitIFrameTrickMode(struct asf_context* pSendContext);



#define GET_DATA_FIFO_INFO(pRUA, ModuleId)				\
	{								\
		struct DataFIFOInfo DataFIFOInfo;			\
		RMuint32 fullness;					\
		RUAGetProperty(pRUA, ModuleId, RMGenericPropertyID_DataFIFOInfo, &DataFIFOInfo, sizeof(DataFIFOInfo)); \
		fullness = (100*DataFIFOInfo.Readable)/DataFIFOInfo.Size; \
		fprintf(stderr, "Data %lx: st=%08lx sz=%ld wr=%ld rd=%ld --> f : %lu/100\n", ModuleId, DataFIFOInfo.StartAddress,	\
			DataFIFOInfo.Size, DataFIFOInfo.Writable,  DataFIFOInfo.Readable, fullness); \
	}								\


#define GET_XFER_FIFO_INFO(pRUA, ModuleId)				\
	{								\
		struct XferFIFOInfo_type XferFIFOInfo;			\
		RMuint32 fullness;					\
		RUAGetProperty(pRUA, ModuleId, RMGenericPropertyID_XferFIFOInfo, &XferFIFOInfo, sizeof(XferFIFOInfo)); \
		fullness = (100*XferFIFOInfo.Readable)/XferFIFOInfo.Size; \
		fprintf(stderr, "XFER %lx: st=%08lx sz=%ld wr=%ld rd=%ld er=%lx --> f : %lu/100\n", ModuleId, XferFIFOInfo.StartAddress, \
			XferFIFOInfo.Size, XferFIFOInfo.Writable,  XferFIFOInfo.Readable, XferFIFOInfo.Erasable, fullness); \
	}

#define GET_XFER_FIFO_BYTES_QUEUED(pRUA, ModuleId)			\
	{								\
		RMuint32 bytes_queued;					\
		RUAGetProperty(pRUA, ModuleId, RMGenericPropertyID_XferFIFOBytesQueued, &bytes_queued, sizeof(bytes_queued)); \
		fprintf(stderr, "XFER %lx: %lu\n", ModuleId, bytes_queued); \
	}


#define MONITOR_FIFO_INTERVAL_US 250000

static void monitorFIFO(struct asf_context *context, RMbool alwaysShow)
{	
	struct timeval now;	
	RMint32 elapsed; 	
	RMuint64 ptime; 	
	struct dcc_context *dcc_info = context->dcc_info;

	gettimeofday(&now, NULL);
	elapsed = (now.tv_sec - context->last.tv_sec) * 1000000;		
	elapsed += (now.tv_usec - context->last.tv_usec);

	if (elapsed > MONITOR_FIFO_INTERVAL_US || alwaysShow){			
		DCCSTCGetTime(dcc_info->pStcSource, &ptime, 90000);			
		fprintf(stderr, "\n*****************************\n");			
		fprintf(stderr, "STC = %lld (%lld secs)	\n", ptime, (ptime/90000));
		/* sample code to get fifo info */
		
        if (dcc_info->pVideoSource)
        {
            fprintf(stderr, "Video :\n"); 			
            GET_DATA_FIFO_INFO(dcc_info->pRUA, dcc_info->video_decoder);
            GET_XFER_FIFO_INFO(dcc_info->pRUA, dcc_info->video_decoder);
            GET_XFER_FIFO_BYTES_QUEUED(dcc_info->pRUA, dcc_info->video_decoder);
        }

		if (dcc_info->pMultipleAudioSource) {
			struct DCCAudioSourceHandle audioHandle;
			RMuint32 i;

			for (i = 0; i < context->audioInstances; i++) {
				fprintf(stderr, "Audio[%lu] :\n", i);
				
				DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(dcc_info->pMultipleAudioSource, i, &audioHandle);
						
				GET_DATA_FIFO_INFO(dcc_info->pRUA, audioHandle.moduleID);
				GET_XFER_FIFO_INFO(dcc_info->pRUA, audioHandle.moduleID);
				GET_XFER_FIFO_BYTES_QUEUED(dcc_info->pRUA, audioHandle.moduleID);
			}
		}

		fprintf(stderr, "*****************************\n");
		gettimeofday(&context->last, NULL);
		fflush(stderr);
		
	}					        

	return;
}


static enum RMProcess_key_goto process_key_sub(struct asf_context *pProcessContext,RMuint8 release,RMuint8 getkey,RMuint8 incallback,RMuint32 dataType)
{
    RMuint32 i;
    RMstatus err;
    RMuint32 dummy;
    RMuint8 *buffer = (RMuint8*)&dummy;
    enum RM_PSM_State OldPlaybackState = RM_PSM_GetState(pProcessContext->PSMcontext, &(pProcessContext->dcc_info));
    enum RM_PSM_State PlaybackStatus = RM_PSM_GetState(pProcessContext->PSMcontext, &(pProcessContext->dcc_info));
    RMuint8 got_key=0;
    
    if (getkey) {
		if ((OldPlaybackState == RM_PSM_Stopped) || (OldPlaybackState == RM_PSM_Paused)) {
			switch (pProcessContext->play_opt->disk_ctrl_state) {
			case DISK_CONTROL_STATE_DISABLE:
			case DISK_CONTROL_STATE_SLEEPING:
				break;
			case DISK_CONTROL_STATE_RUNNING:
				if(pProcessContext->play_opt->disk_ctrl_callback && pProcessContext->play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_SLEEP) == RM_OK)
					pProcessContext->play_opt->disk_ctrl_state = DISK_CONTROL_STATE_SLEEPING;
				break;
			}
		}
        
    	RMDBGLOG((KEYDBG, "process_key\n"));
		err = process_command(pProcessContext->PSMcontext, &(pProcessContext->dcc_info), &pProcessContext->actions);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error while processing key %d\n", err));
				return RMProcess_key_goto_cleanup;
			}
            if ((pProcessContext->actions.performedActions) || (pProcessContext->actions.toDoActions) || (pProcessContext->actions.cmd != RM_NONE))
                got_key=1;
	}
    
	if (pProcessContext->actions.toDoActions & RM_PSM_RESYNC_TIMER) {
		RMDBGLOG((ENABLE, "resyncTimer\n"));
		SyncTimerWithDecoderPTS(pProcessContext);
		pProcessContext->actions.toDoActions &= ~RM_PSM_RESYNC_TIMER;
	}
	if (pProcessContext->actions.toDoActions & RM_PSM_FLUSH_VIDEO) {
		RMDBGLOG((ENABLE, "flushVIDEO\n"));
		Stop(pProcessContext, RM_DEVICES_VIDEO);
		pProcessContext->actions.toDoActions &= ~RM_PSM_FLUSH_VIDEO;
	}
	if (pProcessContext->actions.toDoActions & RM_PSM_DEMUX_NORMAL) {
		RMDBGLOG((ENABLE, "demuxNormal\n"));
		if (RMFAILED(asf_ResumeFromIFrameTrickMode(pProcessContext))) {
			RMDBGLOG((ENABLE,"Error during resume from trickmode, abort.\n"));
             return RMProcess_key_goto_cleanup;
		}
		pProcessContext->isIFrameMode = FALSE;
		pProcessContext->actions.toDoActions &= ~RM_PSM_DEMUX_NORMAL;
	}
	if (pProcessContext->actions.toDoActions & RM_PSM_DEMUX_IFRAME) {
		RMDBGLOG((ENABLE, "demuxIFrame\n"));
		if (release) {
			if (buffer != NULL) {
				RMDBGLOG((ENABLE, "release a buffer\n"));
				RUAReleaseBuffer(pProcessContext->pDMA, buffer);
				buffer = NULL;
            }
			else
				RMDBGLOG((ENABLE, "no buffer to release\n"));
		}
        
        if (RMFAILED(asf_InitIFrameTrickMode(pProcessContext))) {
			RMDBGLOG((ENABLE,"Error during init trickmode, abort.\n"));
            return RMProcess_key_goto_cleanup;
		}
        
		pProcessContext->isIFrameMode = TRUE;
		pProcessContext->ignoreCallback = FALSE;
		pProcessContext->actions.toDoActions &= ~RM_PSM_DEMUX_IFRAME;
	}
	if (pProcessContext->actions.toDoActions & RM_PSM_FIRST_PTS) {
		RMDBGLOG((ENABLE, "firstPTS\n"));
		/*pProcessContext->FirstSystemTimeStamp = TRUE;*/
		pProcessContext->actions.toDoActions &= ~RM_PSM_FIRST_PTS;
	}
	if (pProcessContext->actions.toDoActions & RM_PSM_NORMAL_PLAY) {
		RMDBGLOG((ENABLE, "normal play\n"));
		if ((pProcessContext->audio_parameters[pProcessContext->audio_stream_index].enabled) &&
		    (pProcessContext->AudioStreamFound) &&
		    (pProcessContext->sendAudioTrickmode)) {
			RMDBGLOG((ENABLE, "******* reset audio timer routing\n"));
			routeAudioTimerToDisplayPTS(pProcessContext->dcc_info, FALSE);
			unMuteAudio(pProcessContext->dcc_info);
		}
		if ((pProcessContext->play_opt->fast_audio_recovery) && (pProcessContext->VideoStreamFound) && !(pProcessContext->linear_playback))
			asf_FastAudioRecovery(pProcessContext);
		pProcessContext->actions.toDoActions &= ~RM_PSM_NORMAL_PLAY;
	}								\
	if (pProcessContext->actions.performedActions & RM_PSM_VIDEO_STOPPED) {
		RMDBGLOG((ENABLE, "video stopped\n"));
		pProcessContext->video_decoder_initialized = FALSE;
		if (pProcessContext->isVC1) {
			RMDBGLOG((ENABLE, "codec: VC1 Advanced Profile, will add seqHeader to bitstream\n"));
			pProcessContext->addSeqHeader = TRUE;
		}
		pProcessContext->actions.performedActions &= ~RM_PSM_VIDEO_STOPPED;
	}
	if (pProcessContext->actions.performedActions & RM_PSM_AUDIO_STOPPED) {
		RMDBGLOG((ENABLE, "audio stopped\n"));
		Stop(pProcessContext, RM_DEVICES_AUDIO);
		pProcessContext->actions.performedActions &= ~RM_PSM_AUDIO_STOPPED;
	}
	if (pProcessContext->actions.performedActions & RM_PSM_STC_STOPPED) {
		RMDBGLOG((ENABLE, "stc stopped\n"));
		pProcessContext->actions.performedActions &= ~RM_PSM_STC_STOPPED;
	}
	if ((pProcessContext->actions.cmd == RM_QUIT) && (!pProcessContext->actions.cmdProcessed)) {
		RMDBGLOG((ENABLE, "got quit\n"));
		pProcessContext->ignoreCallback = FALSE;
		pProcessContext->actions.cmdProcessed = TRUE;
        if (incallback)
            pProcessContext->ignoreCallback = TRUE;
        return RMProcess_key_goto_cleanup;
	}
	if ((!pProcessContext->audio_decoder_initialized) &&
	    (OldPlaybackState != RM_PSM_Playing) &&
	    (RM_PSM_GetState(pProcessContext->PSMcontext, &(pProcessContext->dcc_info)) == RM_PSM_Playing)) {
		RMDBGLOG((ENABLE, "restart audio decoder due to play\n"));
		restartAudioDecoder(pProcessContext);
		RMDBGLOG((ENABLE, "syncTimer\n"));
		SyncTimerWithDecoderPTS(pProcessContext);
		if ((pProcessContext->AudioStreamFound) && (!pProcessContext->VideoStreamFound))
                return RMProcess_key_goto_mainloop_seek;
	}
	if ((RM_PSM_GetState(pProcessContext->PSMcontext, &(pProcessContext->dcc_info)) == RM_PSM_Stopped) && (pProcessContext->actions.cmdProcessed)) {
		RMDBGLOG((ENABLE,"Got stop command\n"));
		pProcessContext->ignoreCallback = FALSE;
		pProcessContext->isIFrameMode = FALSE;
		pProcessContext->video_decoder_initialized = FALSE;
		pProcessContext->audio_decoder_initialized = FALSE;
		pProcessContext->FirstSystemTimeStamp = TRUE;
        if (incallback)
            pProcessContext->ignoreCallback = TRUE;
        return RMProcess_key_goto_wmapro_decoder_delete;
	}								\
	if ((pProcessContext->actions.cmd == RM_STOP_SEEK_ZERO) && (!pProcessContext->actions.cmdProcessed)) {
		RMDBGLOG((ENABLE,"Got stop seek zero command\n"));
		if (release) {
			if (buffer != NULL) {
				RMDBGLOG((ENABLE, "release a buffer\n"));
				RUAReleaseBuffer(pProcessContext->pDMA, buffer);
				buffer = NULL;
			}
			else
				RMDBGLOG((ENABLE, "no buffer to release\n"));
		}
		Stop(pProcessContext, RM_DEVICES_STC | RM_DEVICES_AUDIO | RM_DEVICES_VIDEO);
		RM_PSM_SetState(pProcessContext->PSMcontext, &(pProcessContext->dcc_info), RM_PSM_Stopped);
		pProcessContext->ignoreCallback = FALSE;
		pProcessContext->isIFrameMode = FALSE;
		pProcessContext->video_decoder_initialized = FALSE;
		pProcessContext->audio_decoder_initialized = FALSE;
		pProcessContext->FirstSystemTimeStamp = TRUE;
		pProcessContext->actions.cmdProcessed = TRUE;
        if (incallback)
            pProcessContext->ignoreCallback = TRUE;
        return RMProcess_key_goto_wmapro_decoder_delete;
	}
	if ((pProcessContext->actions.cmd == RM_SEEK) && (!pProcessContext->actions.cmdProcessed)){
		RMDBGLOG((ENABLE,"Got seek command\n"));
		if (release) {
			if (buffer != NULL) {
				RMDBGLOG((ENABLE, "release a buffer\n"));
				RUAReleaseBuffer(pProcessContext->pDMA, buffer);
				buffer = NULL;
			}
			else
				RMDBGLOG((ENABLE, "no buffer to release\n"));
		}
                if (RMFAILED(asf_seek(pProcessContext, pProcessContext->dcc_info->seek_time))) {
			RMDBGLOG((ENABLE,"Error during seek, abort.\n"));
            return RMProcess_key_goto_cleanup;
		}
		RM_PSM_SetState(pProcessContext->PSMcontext, &(pProcessContext->dcc_info), RM_PSM_Playing);
		DCCSTCSetSpeed(pProcessContext->dcc_info->pStcSource, pProcessContext->play_opt->speed_N, pProcessContext->play_opt->speed_M);
		pProcessContext->ignoreCallback = FALSE;
		pProcessContext->isIFrameMode = FALSE;
		pProcessContext->actions.cmdProcessed = TRUE;
        if (incallback)
            pProcessContext->ignoreCallback = TRUE;
        return RMProcess_key_goto_mainloop_seek;
	}
    
	if ((pProcessContext->actions.cmd == RM_DUALMODE_CHANGE) && (!pProcessContext->actions.cmdProcessed)) {
		fprintf(stderr, "Changing DualMode to :");
		switch(pProcessContext->audio_opt[0].OutputDualMode) {
		case DualMode_LeftMono:
			fprintf(stderr, " RightMono\n");
			pProcessContext->audio_opt[0].OutputDualMode = DualMode_RightMono;
			break;
		case DualMode_RightMono:
			fprintf(stderr, " MixMono\n");
			pProcessContext->audio_opt[0].OutputDualMode = DualMode_MixMono;
			break;
		case DualMode_MixMono:
			fprintf(stderr, " Stereo\n");
			pProcessContext->audio_opt[0].OutputDualMode = DualMode_Stereo;
			break;
		case DualMode_Stereo:
			fprintf(stderr, " LeftMono\n");
			pProcessContext->audio_opt[0].OutputDualMode = DualMode_LeftMono;
			break;
		default:
			fprintf(stderr, " Unknown dual mode\n");
			break;
		}
		for (i=0; i < pProcessContext->audioInstances; i++) {
			pProcessContext->audio_opt[i].OutputDualMode = pProcessContext->audio_opt[0].OutputDualMode;
			err = apply_audio_decoder_options_onthefly(pProcessContext->dcc_info, &(pProcessContext->audio_opt[i]));
			if (RMFAILED(err)) {
				fprintf(stderr, "Error applying audio decoder options on the fly %d\n", err);
			}
		}
		pProcessContext->actions.cmdProcessed = TRUE;
	}

    if (incallback)
    {
        if ((dataType == RM_STREAM_AUDIO) &&
            (PlaybackStatus != RM_PSM_Playing) &&
            (PlaybackStatus != RM_PSM_Paused) &&
            (PlaybackStatus != RM_PSM_Prebuffering) &&
            (pProcessContext->actions.cmdProcessed)) {
            RMDBGLOG((ENABLE, "trickmode during audio callback\n"));
            if (!pProcessContext->sendAudioTrickmode) {
                RMDBGLOG((ENABLE, "ignoring audio payload\n"));
                pProcessContext->ignoreCallback = TRUE;
                return RMProcess_key_goto_nojump_but_exit;
            }
            RMDBGLOG((ENABLE, "sending audio while in trickmodes\n"));
        }
        if (((PlaybackStatus == RM_PSM_IForward) ||
            (PlaybackStatus == RM_PSM_IRewind)) && (pProcessContext->actions.cmdProcessed)) {
            RMDBGLOG((ENABLE, "iframe trick during callback\n"));
            pProcessContext->ignoreCallback = TRUE;
            return RMProcess_key_goto_nojump_but_exit;
        }
        if (((PlaybackStatus == RM_PSM_Slow) ||
             (PlaybackStatus == RM_PSM_Fast)) && (pProcessContext->actions.cmdProcessed)) {
            RMDBGLOG((ENABLE, "trickmodes during callback\n"));
                    pProcessContext->isTrickMode = TRUE;
            pProcessContext->ignoreCallback = FALSE;
            SyncTimerWithDecoderPTS(pProcessContext);
        }
    }

	pProcessContext->ignoreCallback = FALSE;
	if (pProcessContext->monitorFIFOs)
		monitorFIFO(pProcessContext, FALSE);
    
    // No goto request
    if (got_key)
        return RMProcess_key_goto_got_key_but_noaction;
    else
        return 0;
    
}

#define PROCESS_KEY(release, getkey)\
do {\
        enum RMProcess_key_goto exit_goto;\
        RMuint8 from_callback;\
        if (SendContext.gotoRequest > RMProcess_key_goto_nojump_but_exit)\
        {\
            RMDBGLOG((ENABLE, "pProcessContext->gotoRequest not null, asking for jump\n"));\
            from_callback=TRUE;\
            exit_goto = SendContext.gotoRequest;\
        }\
        else\
        {\
            from_callback=FALSE;\
            exit_goto = process_key_sub(&SendContext,release, getkey,FALSE,0);\
        }\
        SendContext.gotoRequest = RMProcess_key_goto_none;\
        switch (exit_goto)\
        {\
            case RMProcess_key_goto_none:\
            case RMProcess_key_goto_got_key_but_noaction:\
            case RMProcess_key_goto_nojump_but_exit:\
                break;\
            case RMProcess_key_goto_cleanup:\
                RMDBGLOG((ENABLE, "Executing goto cleanup requested from %s process\n",from_callback?"callback":"main")); \
                goto cleanup;\
            case RMProcess_key_goto_mainloop_seek:\
                RMDBGLOG((ENABLE, "Executing goto mainloop_seek requested from %s process\n",from_callback?"callback":"main")); \
                goto mainloop_seek;\
            case RMProcess_key_goto_wmapro_decoder_delete:\
                RMDBGLOG((ENABLE, "Executing goto wmapro_decoder_delete requested from %s process\n",from_callback?"callback":"main")); \
                goto wmapro_decoder_delete;\
        }\
} while (0)

#define PROCESS_KEY_INCALLBACK(getkey,return_if_any_key)\
do {\
      if (pSendContext->gotoRequest <= RMProcess_key_goto_got_key_but_noaction)\
            pSendContext->gotoRequest = process_key_sub(pSendContext,FALSE, getkey,TRUE,dataType);\
      else\
            RMDBGLOG((ENABLE, "GotoRequest already on the way (%d)\n",pSendContext->gotoRequest));\
      if ( ((return_if_any_key)&&(pSendContext->gotoRequest > RMProcess_key_goto_none))\
         ||((!return_if_any_key)&&(pSendContext->gotoRequest > RMProcess_key_goto_got_key_but_noaction))\
         )\
      {\
            RMDBGLOG((ENABLE, "GotoRequest %d from callback process\n",pSendContext->gotoRequest));\
            goto return_from_callback;\
      }\
} while (0)

/* function implementation */
static RMuint64 round_int_div(RMuint64 numerator, RMuint32 divisor) 
{
	RMuint64 temp;
	temp = numerator / divisor;
	if ((numerator % divisor) * 2 > divisor)
		temp++;
	return temp;
}

static RMstatus init_private_options(struct priv_cmdline *options)
{
	options->dummy = 0;
	return RM_OK;
}



#ifndef WITH_MONO


static void show_usage(char *progname)
{
	show_playback_options();
	show_display_options();
	show_video_options();
	show_audio_options();
	
	fprintf(stderr, 
		"DEBUG OPTIONS:\n"
		"\t-bypassDecryption: bypass payload decryption\n"
		"\t-linear_playback: perform linear playback, that is, avoids seeking\n"
		"\t-monitor: monitor fifos and xfer tasks status\n"
		"-------------------------------------------------------------------\n"
		"Minimum cmd line: %s -pv [video codec] -c [audio codec] <file name>\n"
		"-------------------------------------------------------------------\n", progname);

	exit(1);
}

static void parse_cmdline(struct asf_context *pSendContext, int argc, char *argv[])
{
	int i;
	RMstatus err;

	if (argc < 2) 
		show_usage(argv[0]);
	
	i = 1;
	while ((argc > i)) {
		if (argv[i][0] != '-') {
			if (pSendContext->play_opt->filename == NULL) {
				pSendContext->play_opt->filename = argv[i];
				i++;
			}
			else
				show_usage(argv[0]);
		}
		else {
			RMDBGLOG((ENABLE,"command = %s\n", argv[i]));

			if (! strcmp(argv[i], "-bypassDecryption")) {
				pSendContext->bypass_drm = TRUE;
				i++;
				continue;
			}

			if (! strcmp(argv[i], "-linear_playback")) {
				pSendContext->linear_playback = TRUE;
				i++;
				continue;
			}

			if (! strcmp(argv[i], "-monitor")) {
				pSendContext->monitorFIFOs = TRUE;
				i++;
				continue;
			}


			err = parse_playback_cmdline(argc, argv, &i, pSendContext->play_opt);
			if (err == RM_ERROR)
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_display_cmdline(argc, argv, &i, pSendContext->disp_opt);
			if (err == RM_ERROR)
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_video_cmdline(argc, argv, &i, pSendContext->video_opt);
			if (err == RM_ERROR)
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_audio_cmdline2(argc, argv, &i, pSendContext->audio_opt, MAX_AUDIO_DECODER_INSTANCES, &pSendContext->audioInstances);
			if (RMFAILED(err))
				show_usage(argv[0]);
		}
	}

	if (pSendContext->play_opt->filename == NULL)
		show_usage(argv[0]);
}
#endif // WITH_MONO


static void print_GUID(void *context,
		       unsigned char GUID[16], 
		       unsigned char *Name, 
		       unsigned char *Data, 
		       unsigned long long Partial_Size, 
		       unsigned long long Size) 
{
	char s[256];
	sprintf(s, "%02x%02x%02x%02x-%02x%02x-%02x%02x-%02x%02x-%02x%02x%02x%02x%02x%02x",
		  GUID[3], GUID[2], GUID[1], GUID[0],
		  GUID[5], GUID[4],
		  GUID[7], GUID[6],
		  GUID[8], GUID[9],
		  GUID[10], GUID[11], GUID[12], GUID[13], GUID[14], GUID[15]);
	
	RMDBGLOG((ENABLE, "Skipping %llu/%llu bytes (%s) (%s)\n", Partial_Size, Size, s, Name));
}

static void print_File_Properties(void *context,
				  unsigned long long File_Size,
				  unsigned long long Creation_Date,
				  unsigned long long Data_Packets_Count,
				  unsigned long long Play_Duration,
				  unsigned long long Send_Duration,
				  unsigned long long Preroll,
				  unsigned long Minimum_Data_Packet_Size,
				  unsigned long Maximum_Data_Packet_Size,
				  unsigned long Maximum_Bitrate,
				  unsigned char Broadcast,
				  unsigned char Seekable) 
{	
	RMuint64 duration;
	RMuint64 hour, min, sec, milisec;
	struct asf_context *pSendContext = (struct asf_context *) context;

	RMDBGLOG((ENABLE, "    Send Duration = %llu ms\n", Send_Duration / 10000));
	RMDBGLOG((ENABLE, "    Preroll = %llu ms\n", Preroll));
	
	RMDBGLOG((ENABLE, "    Play Duration = %llu ms\n", (Play_Duration / 10000) - Preroll));
	
	RMDBGLOG((ENABLE, "    Maximum_Bitrate = %lu bits/s\n", Maximum_Bitrate));
	RMDBGLOG((ENABLE, "    Minimum_Data_Packet_Size = %lu, Maximum_Data_Packet_Size = %lu\n",
		  Minimum_Data_Packet_Size, Maximum_Data_Packet_Size));

	pSendContext->Preroll = Preroll;
	pSendContext->PrerollSET = FALSE;
	pSendContext->Duration = (Play_Duration / 10000) - Preroll;
	/* store the duration in play_opt */
	pSendContext->play_opt->duration = pSendContext->Duration;

	pSendContext->filePropSET = TRUE;

	duration = pSendContext->Duration;
	hour = duration / (3600 * 1000);
	duration -= (hour * 3600 * 1000);
	min = duration / (60 * 1000);
	duration -= min * 60 * 1000;
	sec = duration / 1000;
	duration -= sec * 1000;
	milisec = duration;
	RMDBGLOG((ENABLE, ">>> Duration %ldh %ldm %lds %ldms\n", (RMuint32)hour, (RMuint32)min, (RMuint32)sec, (RMuint32)milisec));
	fprintf(stderr, "duration %llu secs\n", pSendContext->Duration / 1000);

	RMDBGLOG((ENABLE, "\tCreation Data = %llu\n", Creation_Date));
	RMDBGLOG((ENABLE, "\tFile Size = %llu %s %s\n", File_Size, ((Broadcast) ? "[Broadcast (play and send duration invalid!)]":""), ((Seekable) ? "[Seekable]":"")));
	RMDBGLOG((ENABLE, "\tData Packets Count = %llu\n", Data_Packets_Count));
	
}

static void print_Stream_Bitrate_Properties(void *context,
					    unsigned char Stream_Number, 
					    unsigned long Average_Bitrate) 
{

	RMDBGLOG((ENABLE, "    Stream #%hu: %lu bits/second\n", Stream_Number, Average_Bitrate));
}


static RMbool parseVC1SeqHeader(struct asf_context *pSendContext, RMuint8 *buffer, RMuint32 size)
{
	RMuint32 i;
	RMuint32 entryHeaderFound = 0;
	RMuint32 entryHeaderSize = 0;

	if (size < 3)
		return FALSE;

	for (i = 3; i < size; i++) {

		if ((entryHeaderFound) && (buffer[i-2] != 0) && (buffer[i-1] != 0) && (buffer[i] != 1))
			entryHeaderSize++;
		
		if ((buffer[i-3] == 0) && (buffer[i-2] == 0) && (buffer[i-1] == 1) && (buffer[i] == 0xe)) {
			pSendContext->entryHeader = (buffer + i - 3);
			entryHeaderFound = i;
		}
	}

	pSendContext->entryHeaderSize = entryHeaderSize + 4;

	if (entryHeaderFound) {
		RMDBGLOG((ENABLE, "entryHeader found at i=%lu, size %lu\n", entryHeaderFound - 3, pSendContext->entryHeaderSize));

#if 0
		RMDBGLOG((ENABLE, "hacking it by clearing Broken_link and setting Closed_entry\n"));

		*(pSendContext->entryHeader + 4) = *(pSendContext->entryHeader + 4) | 0xC;
#endif

		for (i = 0; i < pSendContext->entryHeaderSize; i++)
			fprintf(stderr, "0x%02X ", *(pSendContext->entryHeader + i));

		fprintf(stderr, "\n");

		return TRUE;
	}

	return FALSE;

}




static void print_Video_Stream_Properties(void *context,
					  unsigned char Stream_Number, 
					  unsigned long Compression_ID, 
					  unsigned long Image_Width, 
					  unsigned long Image_Height,
					  unsigned char *Codec_Specific_Data, 
					  unsigned long Partial_Codec_Specific_Data_Size, 
					  unsigned long Codec_Specific_Data_Size) 
{
	struct asf_context *pSendContext = (struct asf_context *) context;

#ifdef _DEBUG
	int i, j;
#endif
	RMstatus status;

	if (!pSendContext->SendVideoData) {
		RMDBGLOG((ENABLE, ">>> video disabled by cmdline, skip video detection\n"));
		return;
	}

	RMDBGLOG((ENABLE, "Stream #%hu - Video\n", Stream_Number));

	if (pSendContext->VideoStreamFound) {
		RMDBGLOG((ENABLE, ">>> there's a video stream already setup, skip this one\n"));
		return;
	}

	if (Partial_Codec_Specific_Data_Size) {

		if(pSendContext->Video_Codec_Specific_Data_Received == 0)
			RMDBGLOG((ENABLE, "    Video Codec Specific Data: (%lu bytes, partial size %lu)\n",
				  Codec_Specific_Data_Size,
				  Partial_Codec_Specific_Data_Size));

#ifdef _DEBUG
		for(i = 0; i < (int)Partial_Codec_Specific_Data_Size; i++) {
			for(j = 7; j >= 0; j--)
				fprintf(stderr, "%c", (((*(Codec_Specific_Data + i)) >> j) & 1) + 48);

		}

		fprintf(stderr, "\n");

		for(i = 0; i < (int)Partial_Codec_Specific_Data_Size; i++) {
			fprintf(stderr, "0x%02X ", *(Codec_Specific_Data + i));

		}


#endif

		pSendContext->Video_Codec_Specific_Data_Received += Partial_Codec_Specific_Data_Size;
#ifdef _DEBUG
		if (pSendContext->Video_Codec_Specific_Data_Received == Codec_Specific_Data_Size)
			fprintf(stderr, "\n");
#endif
	}

	if (pSendContext->Video_Codec_Specific_Data_Received == Codec_Specific_Data_Size) {

		pSendContext->video_stream_index = Stream_Number;
		pSendContext->Compression_ID = Compression_ID;
		
		RMDBGLOG((ENABLE, "    Image Width = %lu, Image Height = %lu, Codec = ", Image_Width, Image_Height));
#ifdef _DEBUG
		for(i = 0; i < 4; i++)
			fprintf(stderr, "%c", (char)(Compression_ID >> (i * 8)) & 255);

		fprintf(stderr, " (0x");

		for(i = 0; i < 4; i++)
			fprintf(stderr, "%02x", (char)(Compression_ID >> (i * 8)) & 255);


		fprintf(stderr, ")\n");
#endif

		if(Compression_ID == 0x33564D57) { // WMV3
			int bit_select;

			/* when used in mono, use codec auto detection */
#ifdef WITH_MONO
			if ((Image_Width <= 720) && (Image_Height <= 576)) {
				pSendContext->video_opt->Codec = VideoDecoder_Codec_WMV_SD;
				pSendContext->video_opt->MPEGProfile = Profile_WMV_SD;
				RMDBGLOG((ENABLE, "MONO: Selecting wmv9 SD\n"));
			}
			else if ((Image_Width <= 1440) && (Image_Height <= 816)) {
				pSendContext->video_opt->Codec = VideoDecoder_Codec_WMV_816P;
				pSendContext->video_opt->MPEGProfile = Profile_WMV_816P;
				RMDBGLOG((ENABLE, "MONO: Selecting wmv9 816P\n"));
			}
			else if ((Image_Width <= 1920) && (Image_Height <= 1088)) {
				pSendContext->video_opt->Codec = VideoDecoder_Codec_WMV_HD;
				pSendContext->video_opt->MPEGProfile = Profile_WMV_HD;
				RMDBGLOG((ENABLE, "MONO: Selecting wmv9 HD\n"));
			}
			else {
				RMDBGLOG((ENABLE, "MONO: Unsupported wmv9 video size %lu %lu\n", Image_Width, Image_Height));
			}
#endif // WITH_MONO

			bit_select = (Codec_Specific_Data[0] >> 6) & 3;
			switch (bit_select) {
			case 0: RMDBGLOG((ENABLE, "    Simple Profile\n")); break; // Supported
			case 1: RMDBGLOG((ENABLE, "    Main Profile\n")); break; // Supported
			case 2: { // Not supported
				RMDBGLOG((ENABLE, "    Complex Profile\n")); 
				fprintf(stderr, " Complex Profile is not supported by this hardware! \n"); 
				pSendContext->unsupported_video = TRUE;
				return;
			}
			case 3: RMDBGLOG((ENABLE, "    Error in PROFILE\n")); break;
			}
			
			bit_select = (Codec_Specific_Data[0] >> 5) & 1;      
			if (bit_select) {
				RMDBGLOG((ENABLE, "    Interlaced mode\n"));
				fprintf(stderr, ">>> WARNING: this stream is marked as interlaced and it's not supported by the hardware, playback might fail\n");
			}
			else
				RMDBGLOG((ENABLE, "    Progressive mode\n"));
			
			bit_select = (Codec_Specific_Data[0] >> 4) & 1;      
			if(bit_select) {
				RMDBGLOG((ENABLE, "    Sprite mode on\n")); // Not supported
				fprintf(stderr, " Sprite mode is not supported by this hardware! \n"); 
				pSendContext->unsupported_video = TRUE;
				return;
			}
			else
				RMDBGLOG((ENABLE, "    Sprite mode off\n"));
			
			bit_select = (Codec_Specific_Data[0] >> 1) & 7;            
			RMDBGLOG((ENABLE, "    Framerate is %0d fps\n", bit_select * 4 + 2));
			
			bit_select = (((Codec_Specific_Data[0] >> 0) & 1) << 4) + ((Codec_Specific_Data[1] >> 4) & 15); 
			if(bit_select == 31) // All supported
				RMDBGLOG((ENABLE, "    Bitrate is > 4064 kbps\n"));
			else
				RMDBGLOG((ENABLE, "    Bitrate is %0d kbps\n", bit_select * 64 + 32));
			
			
			bit_select = (Codec_Specific_Data[1] >> 3) & 1;            
			if(bit_select) {// All supported
					RMDBGLOG((ENABLE, "    Loop filter on\n")); // Supported
					bit_select = (Codec_Specific_Data[0] >> 6) & 3;
					if(bit_select == 0)
						RMDBGLOG((ENABLE, "Loop filter incompatible with simple profile\n"));
			} else
				RMDBGLOG((ENABLE, "    Loop filter off\n"));
			
			bit_select = (Codec_Specific_Data[1] >> 2) & 1;            
			if(bit_select) { // Simple and main, should be 0
				RMDBGLOG((ENABLE, "    XINTRA8 on\n"));  // Not supported
				fprintf(stderr, " XINTRA8 ON is only valid with complex profile and is not supported by this hardware! \n"); 
				pSendContext->unsupported_video = TRUE;
				return;
				bit_select = (Codec_Specific_Data[0] >> 6) & 3;
				if(bit_select != 2)
					RMDBGLOG((ENABLE, "XINTRA8 only present in complex profile\n"));
			} else
				RMDBGLOG((ENABLE, "    XINTRA8 off\n"));
			
			bit_select = (Codec_Specific_Data[1] >> 1) & 1;            
			if(bit_select) { // All supported
				RMDBGLOG((ENABLE, "    Multiresolution on\n"));
				bit_select = (Codec_Specific_Data[0] >> 6) & 3;
				if(bit_select == 0)
					RMDBGLOG((ENABLE, "Multiresolution incompatible with simple profile\n"));
			}
			else
				RMDBGLOG((ENABLE, "    Multiresolution off\n"));
			
			bit_select = (Codec_Specific_Data[1] >> 0) & 1;            
			if(bit_select) // Simple and main should be 1
				RMDBGLOG((ENABLE, "    Fast Transform on\n"));  
			else {
				RMDBGLOG((ENABLE, "    Fast Transform off\n")); // Not supported
				fprintf(stderr, " Fast transform OFF is only valid with complex profile and is not supported by this hardware! \n");
				pSendContext->unsupported_video = TRUE;
				return;
				if(bit_select != 2)
					RMDBGLOG((ENABLE, " IDCT is present\n"));
			}
			
			bit_select = (Codec_Specific_Data[2] >> 7) & 1;            
			if(bit_select)  // All supported
				RMDBGLOG((ENABLE, "    Fast UVMC on\n"));
			else
				RMDBGLOG((ENABLE, "    Fast UVMC off\n"));
			
			bit_select = (Codec_Specific_Data[2] >> 6) & 1;            
			if(bit_select) {
				RMDBGLOG((ENABLE, " Broadcast ON\n")); 
			}
			else
				RMDBGLOG((ENABLE, "    Broadcast off\n"));
			
			bit_select = (Codec_Specific_Data[2] >> 4) & 3;        
			switch(bit_select) { // All supported
			case 0: RMDBGLOG((ENABLE, "    Frame quantization step size\n")); break;
			case 1: 
				{
					RMDBGLOG((ENABLE, "    Macroblock quantization step size\n"));
					bit_select = (Codec_Specific_Data[0] >> 6) & 3;
					if(bit_select == 0)
						RMDBGLOG((ENABLE, "DQUANT incompatible with simple profile\n"));
					break;
				}
			case 2:
				{
					RMDBGLOG((ENABLE, "    Boundary alternate quantization\n"));
					bit_select = (Codec_Specific_Data[0] >> 6) & 3;
					if(bit_select == 0)
						RMDBGLOG((ENABLE, "DQUANT incompatible with simple profile\n"));
					break;
				}
			case 3: RMDBGLOG((ENABLE, "Error in DQUANT\n")); break;
			}
			
			bit_select = (Codec_Specific_Data[2] >> 3) & 1;        
			if(bit_select)
				RMDBGLOG((ENABLE, "    Variable size transform on\n")); // Supported
			else
				RMDBGLOG((ENABLE, "    Variable size transform off\n"));
			
			bit_select = (Codec_Specific_Data[2] >> 2) & 1;        
			if(bit_select)
				RMDBGLOG((ENABLE, "    Transform table switching on\n"));  // Supported
			else
				RMDBGLOG((ENABLE, "    Transform table switching off\n"));
			
			bit_select = (Codec_Specific_Data[2] >> 1) & 1;        
			if(bit_select)
				RMDBGLOG((ENABLE, "    Overlap filter on\n"));  // Supported
			else
				RMDBGLOG((ENABLE, "    Overlap filter off\n"));
			
			bit_select = (Codec_Specific_Data[2] >> 0) & 1;        
			if(bit_select) {
				RMDBGLOG((ENABLE, "    Startcodes present\n")); // Not supported by microcode if 1 - Could be written
				RMDBGLOG((ENABLE, " ***************** WARNING ************************\n"));
				RMDBGLOG((ENABLE, " ***************** WARNING ************************\n"));
				RMDBGLOG((ENABLE, " Start code present not be supported yet! \n")); 
				RMDBGLOG((ENABLE, " ***************** WARNING ************************\n"));
				RMDBGLOG((ENABLE, " ***************** WARNING ************************\n"));
			}
			else
				RMDBGLOG((ENABLE, "    No startcodes\n"));
			
			bit_select = (Codec_Specific_Data[3] >> 7) & 1;        
			if(bit_select)
				RMDBGLOG((ENABLE, "    Preprocessing on\n")); // Supported
			else
				RMDBGLOG((ENABLE, "    Preprocessing off\n"));
			
			bit_select = (Codec_Specific_Data[3] >> 4) & 7; // Supported
			if(bit_select)
				RMDBGLOG((ENABLE, "    %d consecutive B-frames\n", bit_select));
			else
				RMDBGLOG((ENABLE, "    No B-frames\n"));
			
			bit_select = (Codec_Specific_Data[3] >> 2) & 3;
			switch(bit_select) { // All supported
			case 0: RMDBGLOG((ENABLE, "    Quantizer implicitly specified at frame level\n")); break;
			case 1: RMDBGLOG((ENABLE, "    Quantizer explicitly specified at frame level\n")); break;
			case 2: RMDBGLOG((ENABLE, "    5QP deadzone quantizer user for all frames\n")); break;
			case 3: RMDBGLOG((ENABLE, "    3QP deadzone quantizer user for all frames\n")); break;
			}
			
			bit_select = (Codec_Specific_Data[3] >> 1) & 1;        
			if(bit_select) { // Not in spec... Usefull? (Frederic)
				RMDBGLOG((ENABLE, "    Frame interpolation on\n"));
				RMDBGLOG((ENABLE, " ***************** WARNING ************************\n"));
				RMDBGLOG((ENABLE, " ***************** WARNING ************************\n"));
				RMDBGLOG((ENABLE, " Frame interpolation may not be supported! \n")); 
				RMDBGLOG((ENABLE, " ***************** WARNING ************************\n"));
				RMDBGLOG((ENABLE, " ***************** WARNING ************************\n"));
			}
			else
				RMDBGLOG((ENABLE, "    Frame interpolation off\n"));
			
			bit_select = (Codec_Specific_Data[3] >> 0) & 1;        
			if(bit_select)
				RMDBGLOG((ENABLE, "    Release encoder used\n"));
			else {
				RMDBGLOG((ENABLE, "    Beta encoder used\n")); // Not supported
				fprintf(stderr, " This file has been created by a WMV9 BETA encoder! \n"); 
				fprintf(stderr, " This file is not supported due to changes that\n"); 
				fprintf(stderr, " may have occured between this BETA version and the\n"); 
				fprintf(stderr, " final version off Microsoft WMV9 encoder.\n"); 
				pSendContext->unsupported_video = TRUE;
				return;
			}
		} 
		else if(Compression_ID == 0x3334504D) { // MP43
			pSendContext->video_stream_index = Stream_Number;

			pSendContext->divx3_prop.Image_Width = (RMuint16) Image_Width;
			pSendContext->divx3_prop.Image_Height = (RMuint16) Image_Height;

			/* when used in mono, use codec auto detection */
#ifdef WITH_MONO
			if ((Image_Width <= 720) && (Image_Height <= 576)) {
				pSendContext->video_opt->Codec = VideoDecoder_Codec_DIVX3_SD;
				pSendContext->video_opt->MPEGProfile = Profile_DIVX3_SD;
				RMDBGLOG((ENABLE, "MONO: Selecting divx3 SD\n"));
			}
			else if ((Image_Width <= 1920) && (Image_Height <= 1088)) {
				pSendContext->video_opt->Codec = VideoDecoder_Codec_DIVX3_HD;
				pSendContext->video_opt->MPEGProfile = Profile_DIVX3_HD;
				RMDBGLOG((ENABLE, "MONO: Selecting divx3 HD\n"));
			}
			else {
				pSendContext->unsupported_video = TRUE;
				RMDBGLOG((ENABLE, "MONO: Unsupported divx3 video size %lu %lu\n", Image_Width, Image_Height));
			}
#endif // WITH_MONO
			RMDBGLOG((ENABLE, "    Found old WMV format (DivX3.11): %d x %d\n", 
				  (int) pSendContext->divx3_prop.Image_Width, (int) pSendContext->divx3_prop.Image_Height));
		}
		else if ((Compression_ID == 0x41564D57) //WMVA - Windows Media Video 9 Advanced Profile
			 || 
			 (Compression_ID == 0x31435657) // WVC1 
			 ) { 
			RMuint8 *pByte;
			int index;

			RMDBGLOG((ENABLE, ">> VC1 Advanced Profile\n"));

			if (Codec_Specific_Data[0] & (1<<5))
				RMDBGLOG((ENABLE, ">> progressive sequence\n"));
			
			if (Codec_Specific_Data[0] & (1<<4))
				RMDBGLOG((ENABLE, ">> single sequence header\n"));
			
			if (Codec_Specific_Data[0] & (1<<3))
				RMDBGLOG((ENABLE, ">> single entry point header\n"));
			
			if (Codec_Specific_Data[0] & (1<<2))
				RMDBGLOG((ENABLE, ">> single slice pictures\n"));
			
			if (Codec_Specific_Data[0] & (1<<1))
				RMDBGLOG((ENABLE, ">> no B frames\n"));


			pSendContext->seqHeader = (RMuint8 *)RMMalloc((Partial_Codec_Specific_Data_Size - 1) * sizeof(RMuint8));
			pSendContext->seqHeaderSize = (Partial_Codec_Specific_Data_Size - 1);
#ifdef _DEBUG
			fprintf(stderr, "VC1 seqHeader size %lu, seqHeader:\n", pSendContext->seqHeaderSize);
#endif
			for(index = 1; index < (int)Partial_Codec_Specific_Data_Size; index++) {
				pByte = (Codec_Specific_Data + index);

#ifdef _DEBUG
				fprintf(stderr, "0x%02X ", *pByte);
#endif
				*(pSendContext->seqHeader + index - 1) = *pByte;

			}
#ifdef _DEBUG
			fprintf(stderr, "\n");
#endif
			parseVC1SeqHeader(pSendContext, pSendContext->seqHeader, pSendContext->seqHeaderSize);

			pSendContext->video_vop_tir = 90000;
			DCCSTCSetTimeResolution(pSendContext->dcc_info->pStcSource, DCC_Video, pSendContext->video_vop_tir);

			pSendContext->isVC1 = TRUE;
			pSendContext->getStartCodeBuffer = TRUE;
			pSendContext->addSeqHeader = TRUE;
			pSendContext->addEntryHeader = TRUE;
			pSendContext->addFrameHeader = TRUE;

			/* when used in mono, use codec auto detection */
#ifdef WITH_MONO
			pSendContext->video_opt->Codec = VideoDecoder_Codec_VC1_HD;
			pSendContext->video_opt->MPEGProfile = Profile_VC1_HD;
			RMDBGLOG((ENABLE, "MONO: Selecting VC1 HD\n"));
#endif // WITH_MONO


		}
		else 
			pSendContext->unsupported_video = TRUE;
		
		if (pSendContext->unsupported_video) {
			pSendContext->SendVideoData = FALSE;
			RMDBGLOG((ENABLE, ">> unsupported video codec, disabling video\n"));
			return;
		}

	}

	if ((Codec_Specific_Data_Size >= sizeof(RMuint32)) && 
	    (Compression_ID != 0x41564D57) && 
	    (Compression_ID != 0x31435657)) { // only for non VC1 codec
		// hack! communicate this properly... (inband?)
		RMDBGLOG((ENABLE, "    Sequence header 0x%lx\n", RMbeBufToUint32(Codec_Specific_Data)));
		
		pSendContext->wmv9_prop.Sequence = RMbeBufToUint32(Codec_Specific_Data);
		pSendContext->wmv9_prop.Image_Width = Image_Width;
		pSendContext->wmv9_prop.Image_Height = Image_Height;
		pSendContext->wmv9_prop.MB_Width = (Image_Width + 15) / 16;
		pSendContext->wmv9_prop.MB_Height = (Image_Height + 15) / 16;
	}

	status = setup_video_decoder(pSendContext);
	pSendContext->videoSetupStatus = status;
	if (RMFAILED(status)){
		fprintf(stderr, "Error initializing video (%s)\n", RMstatusToString(status));
	} else {
		RMDBGLOG((ENABLE, ">>> video stream found, enabling video playback\n"));
		pSendContext->VideoStreamFound = TRUE;
		if (pSendContext->linear_playback)
			/* Seek is not supported, do play now */
			Play(pSendContext, RM_DEVICES_VIDEO | RM_DEVICES_STC, DCCVideoPlayFwd);
	}
}

static RMstatus initVideoDecoder(struct asf_context * context)
{
	if(context->video_decoder_initialized == FALSE) {
		RMstatus err = RM_ERROR;

		RMDBGLOG((ENABLE, "initVideoDecoder\n"));

		switch(context->Compression_ID) {
		case 0x3334504D: // MP43
			err = RUASetProperty(context->pRUA, 
					     context->dcc_info->video_decoder, 
					     RMVideoDecoderPropertyID_DIVX3VSProp, 
					     &context->divx3_prop, sizeof(context->divx3_prop), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE,"Error setting DIVX3 video info : %d !\n", err));
				return err;
			}
			break;
		case 0x33564D57: //WMV3

			RMDBGLOG((ENABLE, "video prop : seq 0x%08lx, %ld x %ld\n", 
				  context->wmv9_prop.Sequence, 
				  context->wmv9_prop.Image_Width,
			          context->wmv9_prop.Image_Height));
			
			err = RUASetProperty(context->pRUA, 
					     context->dcc_info->video_decoder,
					     RMVideoDecoderPropertyID_WMV9VSProp, 
					     &context->wmv9_prop, sizeof(context->wmv9_prop), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE,"Error setting WMV9 video info : %d !\n", err));
				return RM_ERROR;
			}
			break;
		case 0x41564D57: //WMVA - Windows Media Video 9 Advanced Profile
		case 0x31435657: //WVC1
			RMDBGLOG((ENABLE, "VC1 Advanced Profile\n"));
			//context->addSeqHeader = TRUE;
			break;
		default:
			fprintf(stderr,"FourCC: 0x%lx not supported !!!\n",context->Compression_ID);
			return RM_VIDEO_CODEC_NOT_SUPPORTED;
		}
		context->video_decoder_initialized = TRUE;
	}
	return RM_OK;
}


static void languagelistcb(void *context,
			   RMuint16 Language_ID_Records_Count,
			   RMuint16 Language_ID_Records_Index,
			   RMuint8 *Language_ID,
			   RMuint8 Partial_Language_ID_Length,
			   RMuint8 Language_ID_Length) {
	
	struct asf_context *pSendContext = (struct asf_context *) context;

	RMDBGLOG((ENABLE, "languagelist called\n"));

	if( (Language_ID_Length != 0) && (Partial_Language_ID_Length == Language_ID_Length) ) {
#ifdef _DEBUG
		RMuint32 i;
#endif
		pSendContext->lang[Language_ID_Records_Index].languageIDCount = Language_ID_Records_Count;
		pSendContext->lang[Language_ID_Records_Index].languageIDIndex = Language_ID_Records_Index;

		if (pSendContext->lang[Language_ID_Records_Index].languageID)
			RMFree(pSendContext->lang[Language_ID_Records_Index].languageID);

		pSendContext->lang[Language_ID_Records_Index].languageID = (RMnonAscii *) RMMalloc(Language_ID_Length*sizeof(RMuint8));

		RMMemcpy(pSendContext->lang[Language_ID_Records_Index].languageID, Language_ID, Language_ID_Length);

		pSendContext->lang[Language_ID_Records_Index].languageIDLength = Language_ID_Length;

		RMDBGLOG((ENABLE,"Language %hu/%hu ->",  Language_ID_Records_Index, pSendContext->lang[Language_ID_Records_Index].languageIDCount));
#ifdef _DEBUG
		for(i=0;i<Language_ID_Length;i++)
			fprintf(stderr, "%c", (RMuint8)pSendContext->lang[Language_ID_Records_Index].languageID[i]);
		fprintf(stderr, "\n");
#endif
		pSendContext->langPropSET = TRUE;
	}
}


static void print_Audio_Stream_Properties(void *context,
					  unsigned char Stream_Number, 
					  unsigned short Codec_ID,
					  unsigned short Number_of_Channels, 
					  unsigned long Samples_Per_Second,
					  unsigned long Average_Number_of_Bytes_Per_Second,
					  unsigned short Block_Alignment, 
					  unsigned short Bits_Per_Sample,
					  unsigned char *Codec_Specific_Data, 
					  unsigned long Partial_Codec_Specific_Data_Size, 
					  unsigned long Codec_Specific_Data_Size) 
{
	struct asf_context *pSendContext = (struct asf_context *) context;
    struct RMaudio_parameters *audio_params;

    if (!pSendContext->SendAudioData)
    {
		RMDBGLOG((ENABLE, ">>> audio disabled by cmdline, skip audio detection\n"));
		return;
    }
	
    // Check stream number
    if (Stream_Number >= MAX_NUMBER_OF_AUDIO_STREAMS)
    {
        RMDBGLOG((ENABLE, "Invalid audio track\n"));
        return;
    }
    
    if (Codec_Specific_Data_Size >  CODEC_SPECIFIC_DATA_MAX_SIZE_BYTES)
    {
        RMDBGLOG((ENABLE, ">>> Error Codec_Specific_Data_Size to high (%d>%d)\n",
                        Codec_Specific_Data_Size, Codec_Specific_Data));
        return;
    }

    pSendContext->WMAPROBitsPacketLength = 0;

    // Set pointer to current parameters list
    audio_params = &(pSendContext->audio_parameters[Stream_Number]);
    
	// Store partial specific data
    memcpy( audio_params->Codec_Specific_Data+pSendContext->Audio_Codec_Specific_Data_Received,
            Codec_Specific_Data,
            Partial_Codec_Specific_Data_Size);
    
    // Update received size, WE SUPPOSE HERE THAT AUDIO HEADERS ARE NOT INTERLEAVED
    pSendContext->Audio_Codec_Specific_Data_Received += Partial_Codec_Specific_Data_Size;
    
    if (pSendContext->Audio_Codec_Specific_Data_Received != Codec_Specific_Data_Size)
        RMDBGLOG((ENABLE, "########## Received %d bytes on %d bytes for stream %d",
                            pSendContext->Audio_Codec_Specific_Data_Received,Codec_Specific_Data_Size));

	// End of data
    if (pSendContext->Audio_Codec_Specific_Data_Received == Codec_Specific_Data_Size)
    {
        RMuint32 cnt;
        
        // Store size
        audio_params->Codec_Specific_Data_Size = pSendContext->Audio_Codec_Specific_Data_Received;
        
        RMDBGLOG((ENABLE,"print_Audio_Stream_Properties %lu, %lu, %lu\n", 
                pSendContext->Audio_Codec_Specific_Data_Received, 
                Partial_Codec_Specific_Data_Size, 
                Codec_Specific_Data_Size));

        // Reset value for next stream
        pSendContext->Audio_Codec_Specific_Data_Received = 0;
        
		// Store and increments audio streams
        pSendContext->audioStreamTable[pSendContext->audioStreams++] = Stream_Number;

		// Print Infos
        RMDBGLOG((ENABLE, "Stream #%hu - Audio with codec 0x%x\n", Stream_Number,Codec_ID));
		RMDBGLOG((ENABLE, "    %hu channel(s), %lu samples/second, %hu bits/sample\n",
			  Number_of_Channels, Samples_Per_Second, Bits_Per_Sample));
		RMDBGLOG((ENABLE, "    Bitrate: %lu bit/s, Block size is 0x%04x bytes [0x%05x bits]\n", 
			  Average_Number_of_Bytes_Per_Second * 8, Block_Alignment, Block_Alignment * 8));
        
        // Check that codec is supported
        for (cnt=0;cnt<(sizeof(RMSupported_codec_list)/sizeof(RMuint32));cnt++)
        {
            if (Codec_ID == RMSupported_codec_list[cnt])
                break;
        }
        
        // Enable codec only if it is in our supported codecs list
        if (cnt < (sizeof(RMSupported_codec_list)/sizeof(RMuint32)))
        {
            audio_params->enabled = TRUE;

            // Store codec parameters
            audio_params->Codec_ID = Codec_ID;
            audio_params->Number_of_Channels = Number_of_Channels;
            audio_params->Samples_Per_Second = Samples_Per_Second;
            audio_params->Average_Number_of_Bytes_Per_Second = Average_Number_of_Bytes_Per_Second;
            audio_params->Block_Alignment = Block_Alignment;
            audio_params->Bits_Per_Sample = Bits_Per_Sample;

    		// Set first audio stream as default
            if (pSendContext->audio_stream_index == -1)
                pSendContext->audio_stream_index = Stream_Number;

         }
        else
        {
            RMDBGLOG((ENABLE, "    UNSUPPORTED CODEC #\n"));
            audio_params->enabled = FALSE;
        }
        
		RMDBGLOG((ENABLE, "audioStreamTable[%ld]=%ld\n", pSendContext->audioStreams-1, Stream_Number));		

        // Pre Setup audio decoders if not done yet
        if (!pSendContext->AudioStreamFound)
        {
            RMstatus status;
            status = setup_audio_decoder(context);
            pSendContext->audioSetupStatus = status;
            if (RMFAILED(status))
            {
                fprintf(stderr, "Error initializing audio (%s)\n", RMstatusToString(status));
                pSendContext->SendAudioData = FALSE;
                return ; 
            }
            else
            {
                RMDBGLOG((ENABLE, ">>> audio stream found, enabling audio playback\n"));
                pSendContext->AudioStreamFound = TRUE;

                /* Seek is not supported, do play now */
                if (pSendContext->linear_playback)
                    Play(pSendContext, RM_DEVICES_AUDIO | RM_DEVICES_STC, DCCVideoPlayFwd);
            }
        }
 
	}
}

static RMuint32 ResyncAudio(struct asf_context *pSendContext, struct emhwlib_info *pInfo)
{
	RMuint64 CurrentSTC;
	RMuint32 CutSTC;	
	RMuint32 Presentation_Time;
	
	// Check that stream is enabled
    if (pSendContext->audio_parameters[pSendContext->audio_stream_index].enabled != TRUE)
        return 0;
    
    if (pInfo->ValidFields & TIME_STAMP_INFO)
		Presentation_Time = pInfo->TimeStamp;
	else
		return 0;

	if (!pSendContext->FirstSystemTimeStamp) {
 		//get the time in 1000th units because presentation time from ASF is always in 1/1000
 		DCCSTCGetTime(pSendContext->dcc_info->pStcSource, &CurrentSTC, 1000); 

		CutSTC = CurrentSTC & 0xffffffff;
		
		if( (RMint32)(Presentation_Time - CutSTC) <= 0) {

			RMDBGLOG((ENABLE, "Current STC = %lld PTS=%lu skipping to resync\n", CurrentSTC, Presentation_Time));
			if (pSendContext->isWMAPRO) {
				pSendContext->audioSamplesDropped = TRUE;
				RMWMAProVDecoderFlushParser(pSendContext->vDecoder);
				return RM_SKIP_TO_RESYNC;
			}                         
		}
	}
	return 0;
}

static RMstatus initAudioDecoder(struct asf_context * context)
{
    RMstatus status = RM_ERROR;
    RMuint32 i;
    RMuint16 EncoderOptions = 0;
    RMuint16 wValidBitsPerSample = 0;
    RMuint32 dwChannelMask = 0;
    struct RMaudio_parameters *audio_params;
    RMuint32 codec;
    
    // Check that stream is enabled
    if (context->audio_parameters[context->audio_stream_index].enabled != TRUE)
    {
        RMDBGLOG((ENABLE, "Audio channel #%d is disabled, audio init bypassed\n",context->audio_stream_index));
        return RM_ERROR;
    }
 
    // Set audio decoder for current stream
    if (context->audio_decoder_initialized == TRUE)
        return RM_OK;
	
    // Get audio parameters
    audio_params = &(context->audio_parameters[context->audio_stream_index]);
	codec = (RMuint32) audio_params->Codec_ID;

	RMDBGLOG((ENABLE, "initAudioDecoder: Stream %d instance %lu codec 0x%08lx\n",context->audio_stream_index, context->audioInstances, codec));

	// Codec specific switch
    switch (codec)
    {
	case 0x161:
	case 0x7A21:
	case 0x7A22:
    {
        //WMA
        if (audio_params->Codec_Specific_Data_Size == 10)
        { // 4 + 2 + 4
            RMuint32      dwSamplesPerBlock;

            dwSamplesPerBlock = 
                  (((RMuint32) audio_params->Codec_Specific_Data[3]) << 24)
                + (((RMuint32) audio_params->Codec_Specific_Data[2]) << 16)
                + (((RMuint32) audio_params->Codec_Specific_Data[1]) << 8)
                +  ((RMuint32) audio_params->Codec_Specific_Data[0]);

            EncoderOptions = 
                + (((RMuint16) audio_params->Codec_Specific_Data[5]) << 8)
                +  ((RMuint16) audio_params->Codec_Specific_Data[4]);

            RMDBGLOG((ENABLE, 
                "    Audio codec ID: %04x,\n"
                "    Bits per block: 0x%04x\n"
                "    Encode option: 0x%04x \n",
                        (int) audio_params->Codec_ID, (int) dwSamplesPerBlock, 
                        (int) EncoderOptions));
    
        }
        else
        {
            RMDBGLOG((ENABLE, "Error: audio specific data has invalid size (%d)\n",
                              (int) audio_params->Codec_Specific_Data_Size));
            context->audio_parameters[context->audio_stream_index].enabled = FALSE;
            return RM_ERROR;
        }

#ifdef WITH_MONO
        RMDBGLOG((ENABLE, "set audio codec to WMA\n"));
        for (i = 0; i < context->audioInstances; i++)
            context->audio_opt[i].Codec = AudioDecoder_Codec_WMA;
       
        context->isWMAPRO = FALSE;
#endif
    
		break;
    }

	case 0x162:
	{
        // WMAPro
        
		RMstatus err;
		RMMetaWMAParameters temp_wmaparams;


        wValidBitsPerSample = 
            + (((RMuint16) audio_params->Codec_Specific_Data[1]) << 8)
            +  ((RMuint16) audio_params->Codec_Specific_Data[0]);
        dwChannelMask = 
              (((RMuint32) audio_params->Codec_Specific_Data[5]) << 24)
            + (((RMuint32) audio_params->Codec_Specific_Data[4]) << 16)
            + (((RMuint32) audio_params->Codec_Specific_Data[3]) << 8)
            +  ((RMuint32) audio_params->Codec_Specific_Data[2]);
        EncoderOptions = 
            + (((RMuint16) audio_params->Codec_Specific_Data[15]) << 8)
            +  ((RMuint16) audio_params->Codec_Specific_Data[14]);
        
        RMDBGLOG((ENABLE, 
              "    Audio codec ID: %04x,\n"
              "    %u valid bits/sample, %08X channel mask\n"
              "    0x%04x encode options\n",
                      (int) audio_params->Codec_ID,   (int) wValidBitsPerSample, 
                      (int) dwChannelMask, (int) EncoderOptions));
   
        // Get stored values
		temp_wmaparams.VersionNumber = audio_params->Codec_ID;
		temp_wmaparams.SamplingFrequency = audio_params->Samples_Per_Second;
		temp_wmaparams.NumberOfChannels = audio_params->Number_of_Channels;
		temp_wmaparams.Bitrate = audio_params->Average_Number_of_Bytes_Per_Second * 8;
		temp_wmaparams.PacketSize = audio_params->Block_Alignment * 8;
		temp_wmaparams.EncoderOptions = EncoderOptions;
		temp_wmaparams.BitsPerSample = audio_params->Bits_Per_Sample;
		temp_wmaparams.WMAProValidBitsPerSample = wValidBitsPerSample;
		temp_wmaparams.WMAProChannelMask = dwChannelMask;
		temp_wmaparams.WMAProVersionNumber = 0;
		//temp_wmaparams.OutputChannels = audio_params->OutputChannels;
		
		// Create video decoder only once
        if(context->vDecoder == (void *)NULL)
        {
			RMDBGLOG((ENABLE,"******** using RMF's WMAPRO decoder ********\n"));
			err = RMCreateWMAProVDecoder(&(context->vDecoder));
			if (err != RM_OK)
            {
				RMDBGLOG((ENABLE,"error: cant create wmaproVdecoder!\n"));
                context->audio_parameters[context->audio_stream_index].enabled = FALSE;
				return RM_ERROR;
			}
			
			err = RMWMAProVDecoderOpen(context->vDecoder);
			if (err != RM_OK)
            {
				RMDBGLOG((ENABLE,"error: cant open wmaproVdecoder!\n"));
                context->audio_parameters[context->audio_stream_index].enabled = FALSE;
				return RM_ERROR;
			}
		}
		
		// Init video decoder
        if (context->vDecoder != (void *)NULL)
        {
			err = RMWMAProVDecoderInit(context->vDecoder, 
						   EncoderOptions,
						   temp_wmaparams.PacketSize,
						   &temp_wmaparams);
			if (err != RM_OK)
            {
				RMDBGLOG((ENABLE, "wmaprodecoder init error\n"));
                context->audio_parameters[context->audio_stream_index].enabled = FALSE;
				return RM_ERROR;
			}
		}
        else
        {
			RMDBGLOG((ENABLE, "calling wmaprodecoder init before open!\n"));
            context->audio_parameters[context->audio_stream_index].enabled = FALSE;
            return RM_ERROR;
		}

#ifdef WITH_MONO
        RMDBGLOG((ENABLE, "set audio codec to WMAPro\n"));
        for (i = 0; i < context->audioInstances; i++)
            context->audio_opt[i].Codec = AudioDecoder_Codec_WMAPRO;

        context->isWMAPRO = TRUE;
#endif // WITH_MONO


	if ((context->isWMAPRO) && (!context->pDMAuncompressed)) {
		RMDBGLOG((ENABLE, "opening WMAPro DMApool, size %lu, bufferCount %lu bufferSize %lu\n",
			  AUDIO_DMA_BUFFER_COUNT*(1<<AUDIO_DMA_BUFFER_SIZE_LOG2),
			  AUDIO_DMA_BUFFER_COUNT,
			  (1<<AUDIO_DMA_BUFFER_SIZE_LOG2)));

		err = RUAOpenPool(context->dcc_info->pRUA, 0, AUDIO_DMA_BUFFER_COUNT, AUDIO_DMA_BUFFER_SIZE_LOG2, RUA_POOL_DIRECTION_SEND, &(context->pDMAuncompressed));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error: cannot open dmapool for compressed audio - %d\n", err));
			return err;
		}

	}


        break;
    }
        
	case 0x1: //PCM on ASF
    {
		RMDBGLOG((ENABLE, "PCM on ASF\n"));
        context->audio_vop_tir = 90000;
        DCCSTCSetTimeResolution(context->dcc_info->pStcSource, DCC_Audio, context->audio_vop_tir);

#ifdef WITH_MONO
        for (i = 0; i < context->audioInstances; i++)
        {
            context->audio_opt[i].PcmCdaParams.MsbFirst = FALSE;
            context->audio_opt[i].Codec = AudioDecoder_Codec_PCM;
            context->audio_opt[i].SubCodec = 0;
            
            if (audio_params->Number_of_Channels == 6)
                context->audio_opt[i].PcmCdaParams.ChannelAssign = PcmCda6_LfRfCLfeLsRs;
            else
                context->audio_opt[i].PcmCdaParams.ChannelAssign = PcmCda2_LR;
            
            context->audio_opt[i].PcmCdaParams.BitsPerSample = audio_params->Bits_Per_Sample;
            
            if (!context->audio_opt[i].OutputChannelsExplicitAssign)
                context->audio_opt[i].OutputChannels = Audio_Out_Ch_LR;
        }

        context->isWMAPRO = FALSE;
#endif
        break;
    }

    default:
    {	
        // wrong codec, should not happend as it is filtered before the call
		fprintf(stderr, "error wrong codec %lx, disabling audio\n", codec);
		context->audio_parameters[context->audio_stream_index].enabled = FALSE;
		return RM_AUDIO_CODEC_NOT_SUPPORTED;
	}
    }
	

    if ((context->audio_opt[0].Spdif == OutputSpdif_NoDecodeCompressed) || (context->audio_opt[0].Spdif == OutputSpdif_Compressed))
        context->isWMAPRO = FALSE;

	// Send audio for this channel
    context->audio_parameters[context->audio_stream_index].enabled = TRUE;
    
    // Apply parameters
    if (codec != 0x163)
    { // any different from WMALSL
		
		struct AudioDecoder_WMAParameters_type wma_params;
        
        // apply the audio format - uninit, set codec, set specific parameters, init
		RMDBGLOG((ENABLE, "apply audio decoder options\n"));
		
        // Fill wmaparams structure
        wma_params.VersionNumber = audio_params->Codec_ID;
        wma_params.SamplingFrequency = audio_params->Samples_Per_Second;
        wma_params.NumberOfChannels = audio_params->Number_of_Channels;
        wma_params.Bitrate = audio_params->Average_Number_of_Bytes_Per_Second * 8;
        wma_params.PacketSize = audio_params->Block_Alignment * 8;
        wma_params.EncoderOptions = EncoderOptions;
        wma_params.BitsPerSample = audio_params->Bits_Per_Sample;
        wma_params.WMAProValidBitsPerSample = wValidBitsPerSample;
        wma_params.WMAProChannelMask = dwChannelMask;
        wma_params.WMAProVersionNumber = 0;
        /* TODO: need to handle dualmode for each audio decoder */
        wma_params.OutputDualMode = context->audio_opt[0].OutputDualMode;
        wma_params.OutputSpdif = context->audio_opt[0].Spdif;
            
        for (i = 0; i < context->audioInstances; i++)
        {
            memcpy(&context->audio_opt[i].WmaParams, &wma_params, sizeof(struct AudioDecoder_WMAParameters_type));
            
			/*******************************************************************************
			  Upsampling WMA or WMAPRO audio for SPDIF and HDMI output
			********************************************************************************/
			if(context->audio_opt[i].ForceSampleRate != TRUE)
			{
				context->audio_opt[i].SampleRate = wma_params.SamplingFrequency;

				if(wma_params.SamplingFrequency < 32000)
				{
					if(wma_params.SamplingFrequency == 8000)
					{
						context->audio_opt[i].SampleRate = 32000;
					}
					else if(wma_params.SamplingFrequency == 11025)
					{
						context->audio_opt[i].SampleRate = 44100;
					}
					else if(wma_params.SamplingFrequency == 12000)
					{
						context->audio_opt[i].SampleRate = 48000;
					}
					else if(wma_params.SamplingFrequency == 16000)
					{
						context->audio_opt[i].SampleRate = 32000;
					}
					else if(wma_params.SamplingFrequency == 22050)
					{
						context->audio_opt[i].SampleRate = 44100;
					}
					else if(wma_params.SamplingFrequency == 24000)
					{
						context->audio_opt[i].SampleRate = 48000;
					}
				}

				RMDBGLOG((ENABLE, ">> forcing output sample rate to %lu (stream sample rate %lu)\n",
                                    context->audio_opt[i].SampleRate, wma_params.SamplingFrequency));
			}
			/**************************************************************************/

			// apply the sample rate, serial out status
			RMDBGLOG((ENABLE, "apply audio engine options\n"));
			status = apply_audio_engine_options(context->dcc_info, &(context->audio_opt[i]));
			if(status != RM_OK)
            {			
				RMDBGLOG((ENABLE, "Cannot apply audio engine options ... disabling audio, error = %d\n", status));
				context->audio_parameters[context->audio_stream_index].enabled = FALSE;
                return RM_ERROR;
			}
			
			status = apply_audio_decoder_options(context->dcc_info, &(context->audio_opt[i]));
			if (RMFAILED(status))
            {
				RMDBGLOG((ENABLE, "Error applying audio_decoder_options %d\n", status));
    					context->audio_parameters[context->audio_stream_index].enabled = FALSE;
    					return RM_ERROR;
            }
    				
    			apply_dvi_hdmi_audio_options(context->dcc_info, &(context->audio_opt[i]),
                                                wma_params.NumberOfChannels, TRUE, TRUE, FALSE);
        }

#ifndef WITH_MONO
        if (! context->disp_opt->configure_outports)
                apply_hdcp(context->dcc_info, context->disp_opt);
#endif
    }

#ifdef _ENABLE_WMALSL_
    else
    { // WMALSL
       for (i = 0; i < context->audioInstances; i++)
       {
 			context->audio_opt[i].Codec = AudioDecoder_Codec_PCM;
			context->audio_opt[i].SubCodec = 0;
			context->audio_opt[i].SampleRate = audio_params->Samples_Per_Second;
			context->audio_opt[i].OutputChannels = Audio_Out_Ch_LR;
			context->audio_opt[i].PcmCdaParams.ChannelAssign = PcmCda2_LR;
			context->audio_opt[i].PcmCdaParams.BitsPerSample = audio_params;
			context->audio_opt[i].PcmCdaParams.MsbFirst = FALSE;
			
			// apply the sample rate, serial out status
			status = apply_audio_engine_options(context->dcc_info, &(context->audio_opt[i]));
			if(status != RM_OK)
            {
				RMDBGLOG((ENABLE, "Cannot apply audio engine options ... disabling audio, error = %d\n", status));
				context->audio_parameters[context->audio_stream_index].enabled = FALSE;
                return RM_ERROR;
			}
			
			status = apply_audio_decoder_options(context->dcc_info, &(context->audio_opt[i]));
			RMDBGLOG((ENABLE, " set PCM codec for WMALSL, Sampling Freq=%lu\n", context->audio_opt[i].SampleRate));
			DCCSTCSetTimeResolution(context->dcc_info->pStcSource, DCC_Audio, 90000);
			if(status != RM_OK)
            {			
				RMDBGLOG((ENABLE, "Cannot apply audio decoder options ... disabling audio, error = %d\n", status));
        					context->audio_parameters[context->audio_stream_index].enabled = FALSE;
        		return RM_ERROR;
            }
        				
            apply_dvi_hdmi_audio_options(context->dcc_info, &(context->audio_opt[i]), 0, FALSE, FALSE, FALSE);
        }

#ifndef WITH_MONO
        if (! context->disp_opt->configure_outports)
            apply_hdcp(context->dcc_info, context->disp_opt);
#endif

    }    			
#endif
    
    context->audio_decoder_initialized = TRUE;

	return RM_OK;
}


static RMbool SwitchAudio(struct asf_context *pSendContext, RMuint32 Media_Object_Number)
{
	
	RMDBGLOG((ENABLE, "got audio stream change command\n"));

	pSendContext->dcc_info->state = RM_PLAYING;

	if ((pSendContext->dcc_info->selectAudioStream > (RMint32)pSendContext->audioStreams) || 
	    (pSendContext->dcc_info->selectAudioStream == 0) ||
	    (pSendContext->audioStreams <= 1) || 
	    (pSendContext->dcc_info->selectAudioStream == (RMint32)pSendContext->audio_stream_index)) {
		RMDBGLOG((ENABLE, "audio stream change ignored (total audioStreams %lu, selected %ld, current %lu)\n", 
			  pSendContext->audioStreams, 
			  pSendContext->dcc_info->selectAudioStream,
			  pSendContext->audio_stream_index));
		return FALSE;
	}

	Stop(pSendContext, RM_DEVICES_AUDIO);
	
	if (pSendContext->isWMAPRO) {		

		if (pSendContext->vDecoder != NULL) {
			RMDBGLOG((ENABLE, "close wmapro decoder\n"));
			RMWMAProVDecoderClose(pSendContext->vDecoder);
			
			RMDBGLOG((ENABLE, "open wmapro decoder\n"));
			RMWMAProVDecoderOpen(pSendContext->vDecoder);

		}
		else
			RMDBGLOG((ENABLE, "no wmapro decoder created!\n"));
	}
	
	pSendContext->dcc_info->state = RM_PLAYING;
	pSendContext->audio_decoder_initialized = FALSE;
	pSendContext->prev_audio_media_object_number = Media_Object_Number;
	
	RMDBGLOG((ENABLE, "total audio streams %lu\n", pSendContext->audioStreams));
	if (pSendContext->dcc_info->selectAudioStream == -1) {
		RMuint32 i;		

		
		for (i = 0; i < pSendContext->audioStreams ; i++) {
			if (pSendContext->audioStreamTable[i] != (RMuint32) pSendContext->audio_stream_index)
				break;
		}
		RMDBGLOG((ENABLE, "current stream %lu, switch to %lu\n", pSendContext->audio_stream_index, pSendContext->audioStreamTable[i]));
		pSendContext->audio_stream_index = pSendContext->audioStreamTable[i];
	}
	else {
		RMDBGLOG((ENABLE, "current stream %lu, switch to %lu\n", pSendContext->audio_stream_index, pSendContext->dcc_info->selectAudioStream));
		pSendContext->audio_stream_index = pSendContext->dcc_info->selectAudioStream;
	}
	
	if (RM_PSM_GetState(pSendContext->PSMcontext, &(pSendContext->dcc_info)) != RM_PSM_Stopped)
		Play(pSendContext, RM_DEVICES_AUDIO, 0);

	return TRUE;
}


static void print_Bitrate_Mutual_Exclusion(void *context,
					   unsigned long mutex_index, 
					   unsigned short Stream_Numbers_Count,
					   unsigned char bitrate_exclusion,
					   unsigned char Stream_Number) 
{
	// one thread only here
}


static void check_prebuf_state(struct asf_context *pSendContext, RMuint32 buffersize)
{
	RMbool quit_prebuf;
	enum RM_PSM_State PlaybackStatus = RM_PSM_GetState(pSendContext->PSMcontext, &(pSendContext->dcc_info));
	
	if (PlaybackStatus != RM_PSM_Prebuffering)
		return;

	/* if fail in getbuffer/senddata force quitting prebuffering state */
	quit_prebuf = ((buffersize == 0) || ((pSendContext->play_opt->prebuf_max > 0) && (pSendContext->prebufferedBytes >= pSendContext->play_opt->prebuf_max))) ? TRUE : FALSE;

	pSendContext->prebufferedBytes += buffersize;
		
	if (quit_prebuf) {

		monitorFIFO(pSendContext, TRUE);

		RMDBGLOG((ENABLE, "exit prebuffering state, enter play state (bufsize %lu, prebuffered %lu)\n", buffersize, pSendContext->prebufferedBytes));
		fprintf(stderr, "now playing\n");
		RM_PSM_SetState(pSendContext->PSMcontext, &(pSendContext->dcc_info), RM_PSM_Playing);
		Play(pSendContext, RM_DEVICES_STC | RM_DEVICES_VIDEO | RM_DEVICES_AUDIO, DCCVideoPlayFwd);
		pSendContext->prebufferedBytes = 0;
	}
}



static RMbool try_decode_wmapro(struct asf_context *pSendContext, RMbool EOS)
{
	enum RM_PSM_State PlaybackStatus = RM_PSM_GetState(pSendContext->PSMcontext, &(pSendContext->dcc_info));
	RMuint8 *wmaproBuffer;
	struct wmapro_buffer_info *buf_info = pSendContext->pread_wmapro_info;
 
    RMuint8 dataType=RM_STREAM_AUDIO;

	/* wmapro decoding and senddata */	
	if (
	    ((PlaybackStatus != RM_PSM_Playing) && 
	     (PlaybackStatus != RM_PSM_Paused) && 
	     (PlaybackStatus != RM_PSM_Prebuffering) &&
	     (!pSendContext->sendAudioTrickmode)) ||
	    (!pSendContext->isWMAPRO) ||
         (!pSendContext->audio_parameters[pSendContext->audio_stream_index].enabled)) {		
		return FALSE;
	}

  if (pSendContext->gotoRequest > RMProcess_key_goto_none) {
        RMDBGLOG((ENABLE, "command processing under way, do not decode wmapro\n"));
        return FALSE;
    }

	/* when no video is present we need to block here to avoid filling the wmapro bufer info fifo */
	if (pSendContext->VideoByteCounter == 0)
		EOS = TRUE;

   do {
		RMuint32 rd1, rd2;
		RMuint32 size1;
		RMstatus status;
		
        if(pSendContext->fDecodingWMAPROPacket == FALSE) {
			if(RMfifo_get_readable_size(pSendContext->wmapro_fifo, &rd1, &size1, &rd2) >= sizeof(struct wmapro_buffer_info))  {		  	  
				buf_info = (struct wmapro_buffer_info *) rd1;
				
				pSendContext->pread_wmapro_info = buf_info;

				RMDBGLOG((WMAPRODBG, "reading wmapro audio from fifo %p ST %d, MON %d, %ld bytes, pts %llu\n",
					  buf_info->ptr,
					  (int)buf_info->Stream_Number,
					  (int)buf_info->Media_Object_Number,
					  buf_info->size,
					  buf_info->Info.TimeStamp));

				
				
				RMDBGLOG((WMAPRODBG, "To ResyncAudio wmapro\n"));			
#if 1
				if (ResyncAudio(pSendContext, &(buf_info->Info)) == RM_SKIP_TO_RESYNC) {
					pSendContext->fDecodingWMAPROPacket = FALSE;
					goto next_wmapro_packet;
				}
#endif
				
				wmaproBuffer = buf_info->ptr;
				
				RMDBGLOG((WMAPRODBG, "Reset WMAPRO decoder with buffer(%p) size(%lu)\n", wmaproBuffer, buf_info->size));				
				
                status = RMWMAProVDecoderResetParser(pSendContext->vDecoder, wmaproBuffer, buf_info->size);
				if (status != RM_OK) {
					RMDBGLOG((WMAPRODBG, "Cannot reset wmapro parser)\n"));
					goto next_wmapro_packet;
				}
				
				pSendContext->packet_counter ++;
				pSendContext->fDecodingWMAPROPacket = TRUE;
				
				RMDBGLOG((WMAPRODBG, ">>>>>>>>>fSameWMAPROPacket == FALSE, Packet No.#%d\n", pSendContext->packet_counter));			  
			}
			else {
				RMDBGLOG((WMAPRODBG, "Insufficient data in wmapro FIFO\n"));			  
				return FALSE;
			}
		}
		
		//play_asf_decode_wmapro_payload:
		while(1) {
			while (pSendContext->fDecodingWMAPROPacket) {

				RMstatus status, decode_status;
				RMuint32 size_audio, size_info;	
				RMuint8 *pFrameBuffer;
				RMuint8 *buf_audio;
				struct emhwlib_info *pInfo;

                PROCESS_KEY_INCALLBACK(TRUE,TRUE);

				if (pSendContext->UncompressedBuffer != NULL) {
					RUAReleaseBuffer(pSendContext->pDMAuncompressed, pSendContext->UncompressedBuffer);
					pSendContext->UncompressedBuffer = NULL;
				}
				
				if (EOS) {
					while (RUAGetBuffer(pSendContext->pDMAuncompressed, &pSendContext->UncompressedBuffer, GETBUFFER_TIMEOUT_US) != RM_OK) {
						
						check_prebuf_state(pSendContext, 0);
						
                        PROCESS_KEY_INCALLBACK(TRUE,TRUE);
					}
				}
				else {
					if (RUAGetBuffer(pSendContext->pDMAuncompressed, &pSendContext->UncompressedBuffer, 0) != RM_OK) {
						
						RMDBGLOG((WMAPRODBG, "Cannot get buffer\n"));
						
						check_prebuf_state(pSendContext, 0);

                        PROCESS_KEY_INCALLBACK(TRUE,TRUE);
						
						return FALSE;
					}
				}
				
				
				status = RMWMAProVDecoderGetFrame(pSendContext->vDecoder, (void **)&pFrameBuffer);
				
				if (status == RM_WMAPRO_SKIPFRAME) {						
					RMDBGLOG((WMAPRODBG, "SKIP FRAME\n"));
					continue;
				}
				else if (status != RM_OK) {
					RMDBGLOG((WMAPRODBG, "Error get frame\n"));
					break;
				}
				
				buf_audio = pSendContext->UncompressedBuffer;
				
#if (EM86XX_MODE == EM86XX_MODEID_STANDALONE) && (EM86XX_CHIP != EM86XX_CHIPID_TANGO2)
				// Make sure the output address uncacheable for DMA
				buf_audio = (RMuint8 *)((RMuint32)buf_audio & 0x7fffffff);
#endif
				
#if 0			// just for debugging
				memset(buf_audio, 0, 128*1024 - 4);
				
#endif
				/* this status will be checked after sending the data */
				decode_status = RMWMAProVDecoderDecode(pSendContext->vDecoder, pFrameBuffer, buf_audio, &size_audio);				
				RMDBGLOG((WMAPRODBG, "size_audio = %d on buffer %p\n", size_audio, buf_audio));
				
				if (size_audio > (1<<AUDIO_DMA_BUFFER_SIZE_LOG2)) {
					RMDBGLOG((ENABLE, "size_audio (%ld) > dmabuffersize (%ld), disabling audio\n", size_audio, (1<<AUDIO_DMA_BUFFER_SIZE_LOG2)));
					pSendContext->audio_parameters[pSendContext->audio_stream_index].enabled = FALSE;
					break;
				}
				
				if(size_audio > 0) {
					
					RMbool broken_frame;
					
					pInfo = NULL;
					size_info = 0;
					
#ifdef _DUMP_INT_FILE_								
					fwrite(buf_audio, 1, size_audio, pSendContext->intfile);
#endif				
					
					/* need to be the first test to do it every time */
					broken_frame = RMWMAProVDecodeGetFlag(pSendContext->vDecoder, INQUIRE_BROKEN_FRAME_FLAG);
					RMDBGLOG((WMAPRODBG, "broken %lu, sendpts %lu, audiopts %lu\n", broken_frame, buf_info->fSendPTS, pSendContext->SendAudioPts));
					if (buf_info->fSendPTS == 1 && pSendContext->SendAudioPts && !broken_frame && buf_info->Info.ValidFields) {
						pInfo = &(buf_info->Info);
						
						size_info = sizeof(struct emhwlib_info);
						buf_info->fSendPTS = 0;						
					}
					else if (buf_info->fSendPTS && pSendContext->SendAudioPts && !broken_frame)
					{
						buf_info->fSendPTS -= 1;
					}
					else if (broken_frame)
					{
						buf_info->fSendPTS = 2;
					}
					
					if (pInfo != NULL)
						RMDBGLOG((WMAPRODBG, "sending wmapro audio %d, MON %d, %ld bytes, pts %llu = 0x%09llx, bytecnt = 0x%08lx, validField=%lu\n",
							  (int)buf_info->Stream_Number,
							  (int)buf_info->Media_Object_Number,
							  size_audio,
							  pInfo->TimeStamp,
							  pInfo->TimeStamp,
							  pSendContext->AudioByteCounter, 
							  pInfo->ValidFields));										

					
					if (PlaybackStatus == RM_PSM_Prebuffering)
						fprintf(stderr, "w");
					
					{
						RMint32 lastOKinstance=-1;
						
						status = DCCMultipleAudioSendData(pSendContext->dcc_info->pMultipleAudioSource, 
										  pSendContext->pDMAuncompressed, 
										  buf_audio, size_audio, pInfo, size_info,
										  &lastOKinstance);
							
						if (status != RM_OK) {
							check_prebuf_state(pSendContext, 0);
							
							RMDBGLOG((ENABLE, "WmaPro Xfer task too small\n"));
							break;
						}
						pSendContext->AudioByteCounter += size_audio;
					}
				}
				else {
					RMDBGLOG((ENABLE, "Flush WmaPro decoder due to error\n"));
					RMWMAProVDecoderFlushParser(pSendContext->vDecoder);
					pSendContext->fDecodingWMAPROPacket = FALSE;
					break;
				}
				
				if (decode_status != RM_OK)
					break;
			}
			RMWMAProVDecodeAdjustPayload(pSendContext->vDecoder);
			
			if(RMWMAProVDecodeIsPacket2Decode(pSendContext->vDecoder) && pSendContext->fDecodingWMAPROPacket) {
				RMWMAProVDecodeResetPacket(pSendContext->vDecoder);
				continue;
			}
			else {
				pSendContext->fDecodingWMAPROPacket = FALSE;
				break;	 
			}
		}
	next_wmapro_packet:
		RMDBGLOG((WMAPRODBG, "release buffer %lx\n", buf_info->ptr));
		RUAReleaseBuffer(pSendContext->pDMA, buf_info->ptr);
		RMfifo_incr_read_ptr(pSendContext->wmapro_fifo, sizeof(struct wmapro_buffer_info));
	} while(1);
	
    // This is a normal return
	return FALSE;

return_from_callback:
    
      return TRUE;

#if 0
	// handle the fifo error (haven't been seen yet)
 wmapro_fifo_error:
	RMDBGLOG((ENABLE, "Flush WmaPro FIFO due to error in fifo, !!!urgent!!!\n"));
	flush_wmaproFIFO(pSendContext);
	return FALSE;
#endif
}

static void flush_wmaproFIFO(struct asf_context *pSendContext)
{
	struct wmapro_buffer_info *buf_info = NULL;
	RMuint32 rd1, rd2;
	RMuint32 size1;

	RMDBGLOG((ENABLE, "flushWMAProFIFO\n"));

	while (RMfifo_get_readable_size(pSendContext->wmapro_fifo, &rd1, &size1, &rd2) >= sizeof(struct wmapro_buffer_info))  {
		buf_info = (struct wmapro_buffer_info *) rd1;
		
		RMDBGLOG((ENABLE, "releasing wmapro audio from fifo %p ST %d, MON %d, %ld bytes, pts %llu\n",
			  buf_info->ptr,
			  (int)buf_info->Stream_Number,
			  (int)buf_info->Media_Object_Number,
			  buf_info->size,
			  buf_info->Info.TimeStamp));
		
		RUAReleaseBuffer(pSendContext->pDMA, buf_info->ptr);
		buf_info->ptr = NULL;
		RMfifo_incr_read_ptr(pSendContext->wmapro_fifo, sizeof(struct wmapro_buffer_info));
	}

	RMfifo_flush(pSendContext->wmapro_fifo);
	pSendContext->fDecodingWMAPROPacket = FALSE;

}


static void play_Payload2(void *context,
			  unsigned char Stream_Number,  
			  unsigned char *buf, 
			  unsigned long size,
			  unsigned long bytes_left,
			  unsigned char Is_Key_Frame,
			  unsigned long Media_Object_Number, 
			  unsigned char Media_Object_Number_valid,
			  unsigned long Presentation_Time, 
			  unsigned char Presentation_Time_valid,
			  unsigned long Offset_Into_Media_Object)
{
	struct asf_context *pSendContext = (struct asf_context *) context;
	struct emhwlib_info Info = {0,};
	struct emhwlib_info *pInfo = NULL;
	RMuint32 size_info = 0;

	//struct RUABufferPool *pDMA_audio;
	RMint32 diff;
	#define DELTA_PTS 100			// 1 sec
	#define CONTIGUOUS_LENGHT 0x100000	// 1 MB

/*	RMuint32 e = 0;*/
	RMbool SetPTS = FALSE;
	RMbool SendPTS = FALSE;
	RMbool SendData = FALSE;
	RMuint32 PrevMON = 0;
	RMuint32 decoder = 0;

    RMuint8 dataType=RM_STREAM_AUDIO;
    
	//RMbool ptsAlreadyScaled = FALSE;

	// dummy init
	RMbool *seeking = &(pSendContext->SeekVideo);
	RMuint32 *previousMON = &(pSendContext->PrevVideoMON);

	enum RM_PSM_State PlaybackStatus = RM_PSM_GetState(pSendContext->PSMcontext, &(pSendContext->dcc_info));

	RMuint32 dumpedFrameSize = 0;

    if (Stream_Number == pSendContext->video_stream_index)
        dataType = RM_STREAM_VIDEO;
    else if (Stream_Number == pSendContext->audio_stream_index)
        dataType = RM_STREAM_AUDIO;
    else
        goto return_from_callback;

	/* #### Begin CARDEA code #### */
	/** Add physical buffer address to cardea interface 		**/
	/** Flush buffer from cache before passing to cardealib		**/
	if ( (pSendContext->cardea_context != NULL ) && 
		(should_decrypt(pSendContext->cardea_context))) {
		RMuint32 buf_phys;
		RMstatus status;

		status = RUAGetPhysicalAddress(pSendContext->pDMA, buf, size, &buf_phys);
		if ( RMFAILED(status)) {
			fprintf( stderr, "%s:%d\n", __FILE__, __LINE__ );
			RMDBGLOG((ENABLE,"Error getting CARDEA data buffer physical addr\n"));
			goto return_from_callback;
		}
		status = RUACleanCache( pSendContext->pDMA, buf, size );
		if ( RMFAILED(status)) {
			fprintf( stderr, "%s:%d\n", __FILE__, __LINE__ );
			RMDBGLOG((ENABLE,"Error flusing CARDEA data buffer from cache\n"));
			goto return_from_callback;
		}
		status = RUAInvalidateCache( pSendContext->pDMA, buf, size );
		if ( RMFAILED(status)) {
			fprintf( stderr, "%s:%d\n", __FILE__, __LINE__ );
			RMDBGLOG((ENABLE,"Error flusing CARDEA data buffer from cache\n"));
			goto return_from_callback;
		}
#if (EM86XX_CHIP == EM86XX_CHIPID_TANGO2)
		status = decrypt_cardea_sample(pSendContext->cardea_context,
					       Stream_Number,
					       Media_Object_Number,
					       buf_phys,
					       buf,
					       size);
#else
		status = decrypt_cardea_sample(pSendContext->cardea_context,
					       Stream_Number,
					       Media_Object_Number,
					       buf,
					       size);
#endif
		if (RMFAILED(status)) {
			fprintf( stderr, "%s:%d\n", __FILE__, __LINE__ );
			RMDBGLOG((ENABLE,"Error decrypting CARDEA data\n"));
			goto return_from_callback;
		}
	}
	/* #### End CARDEA code #### */

	if ((!pSendContext->VideoStreamFound) && (pSendContext->SendVideoData)) {
		RMDBGLOG((ENABLE, ">> no video stream found, disable video\n"));
		pSendContext->SendVideoData = FALSE;

		if (pSendContext->linear_playback) {
			RMDBGLOG((ENABLE, "seek not supported, disable trickmodes\n"));
			pSendContext->dcc_info->RM_PSM_commands &= ~RM_PSM_ENABLE_SPEED;
			pSendContext->dcc_info->RM_PSM_commands &= ~RM_PSM_ENABLE_FASTER;
			pSendContext->dcc_info->RM_PSM_commands &= ~RM_PSM_ENABLE_SLOWER;
		}
	}

	if ((!pSendContext->AudioStreamFound) && (pSendContext->SendAudioData)) {
		RMDBGLOG((ENABLE, ">> no audio stream found, disable audio\n"));
		pSendContext->SendAudioData = FALSE;
	}

	
	if (pSendContext->drmError != 0) {
		RMDBGLOG((ENABLE, "there was a decryption error, callback ignored\n"));
		goto return_from_callback;
	}

	if ((pSendContext->isContentEncrypted) && (bytes_left != 0))
		RMDBGLOG((ENABLE, "non aligned read, offset %ld!\n", bytes_left));


	RMDBGLOG((PAYLOADDBG,"ST:%02d,MON:%04d, (valid %ld), Key:%01d,time:%05d.%03d,(valid %ld), size:%05d, left:%05d, offset:%05d \n",
		  (int)Stream_Number,
		  (int)Media_Object_Number,
		  (int)Media_Object_Number_valid,
		  (int)Is_Key_Frame,
		  (int)(Presentation_Time/1000),
		  (int)(Presentation_Time%1000),
		  (int)Presentation_Time_valid,
		  (int)size,
		  (int)bytes_left,
		  (int)Offset_Into_Media_Object));
  
  	
	if (Stream_Number == pSendContext->video_stream_index)
		dataType = RM_STREAM_VIDEO;
	else if (Stream_Number == pSendContext->audio_stream_index)
		dataType = RM_STREAM_AUDIO;
  	else
		goto return_from_callback;

	if (pSendContext->ignoreCallback) {

		if ((pSendContext->actions.cmd == RM_QUIT) && (!pSendContext->actions.cmdProcessed)) {
			RMDBGLOG((ENABLE, "callback called when 'quit' command was issued\n"));
			goto return_from_callback;
		}
		if ((PlaybackStatus == RM_PSM_Stopped) && (pSendContext->actions.cmdProcessed)) {
			RMDBGLOG((ENABLE, "callback called when 'stop' command was issued\n"));
			goto return_from_callback;
		}
		if ((pSendContext->actions.cmd == RM_STOP_SEEK_ZERO)  && (!pSendContext->actions.cmdProcessed)) {
			RMDBGLOG((ENABLE, "callback called when 'seekzero' command was issued\n"));
			goto return_from_callback;
		}
		if (((PlaybackStatus == RM_PSM_IForward) ||
		     (PlaybackStatus == RM_PSM_IRewind)) && (pSendContext->actions.cmdProcessed)) {
			RMDBGLOG((ENABLE, "callback called when 'iframe' command was issued\n"));
			goto return_from_callback;
		}
		if ((pSendContext->actions.cmd == RM_SEEK) && (!pSendContext->actions.cmdProcessed)) {	
			RMDBGLOG((ENABLE, "callback called when 'seek' command was issued\n"));
			goto return_from_callback;
		}

		if ((PlaybackStatus != RM_PSM_Playing) && (PlaybackStatus != RM_PSM_Paused) && (dataType == RM_STREAM_AUDIO)) {
			RMDBGLOG((ENABLE, "audio callback when trickmodes were initiated, skip payload\n"));
			goto return_from_callback;
		}

		if ((PlaybackStatus != RM_PSM_Playing) && (dataType == RM_STREAM_VIDEO)) {
			RMDBGLOG((ENABLE, "video callback when trickmodes were initiated, send payload\n"));
			goto send_payload;
  		}
  
		// we should not get to this point under any circumstances
		RMDBGLOG((ENABLE, "********** ignoring Callback!! *********\n")); 
		RMDBGLOG((ENABLE, "playstat %lu, cmd %lu, cmdprocessed %lu\n", PlaybackStatus, pSendContext->actions.cmd, pSendContext->actions.cmdProcessed));
		goto return_from_callback;
	}

 send_payload:


	// Decrypt packet, if necessary
	if (pSendContext->isContentEncrypted) {
		if ((pSendContext->drmError = WMDRM_decrypt_packet(buf, size)) != 0) {
			RMASFVDemuxSetDRMError(pSendContext->vASFDemux, pSendContext->drmError);
			fprintf(stderr, "DECRYPTION FAILED\n");
			goto return_from_callback;
		}
	}

	/* adjust PTS if necessary */
	if ((pSendContext->PrerollSET) && (pSendContext->Preroll)) {
		RMDBGLOG((DISABLE, "pts %llu, adjusted pts %llu\n", (RMuint64)Presentation_Time, (RMuint64)Presentation_Time - pSendContext->Preroll));
		
		if ((RMuint32) pSendContext->Preroll > Presentation_Time) {
			RMDBGLOG((ENABLE, "Skipping packets with negative PTS\n"));
			goto return_from_callback;
		}
		else
			Presentation_Time -= (RMuint32)pSendContext->Preroll;
	}

	/* wait for first IFrame, some streams dont start with a IFrame!! */
	if ((!pSendContext->firstIFrame) && (dataType == RM_STREAM_VIDEO)) {
		if ((Is_Key_Frame) && (Offset_Into_Media_Object == 0)) {
			fprintf(stderr, ">> first IFrame found, start sending video. MON(%lu), Stream(%lu)\n", (RMuint32)Media_Object_Number, (RMuint32)Stream_Number);
			pSendContext->firstIFrame = TRUE;
		}
		else {
			fprintf(stderr, "waiting for first IFrame, skipping MON(%lu) Stream(%lu) \n", (RMuint32)Media_Object_Number, (RMuint32)Stream_Number);
			goto return_from_callback;
		}
	}


	/* accurate audio seek, required for WMA FFWD trickmode */
	if (dataType == RM_STREAM_AUDIO) {
		if (pSendContext->accurateAudioSeekTo > (RMuint64)Presentation_Time) {
			RMDBGLOG((ENABLE, "skipping audio %lu < %llu\n", Presentation_Time, pSendContext->accurateAudioSeekTo));
			goto return_from_callback;
		}
		else if (pSendContext->accurateAudioSeekTo != 0) {
			RMDBGLOG((ENABLE, "start sending audio %lu\n", Presentation_Time));
			pSendContext->accurateAudioSeekTo = 0;
		}
	}



	switch (dataType) {
	case RM_STREAM_VIDEO: 
		if (!pSendContext->SendVideoData)
			goto return_from_callback;
		SendPTS = pSendContext->SendVideoPts;
		PrevMON = pSendContext->prev_video_media_object_number;
		pSendContext->VideoByteCounter += size;
		pSendContext->prev_video_media_object_number = Media_Object_Number;
		decoder = pSendContext->dcc_info->video_decoder;
		SendData = TRUE;
		seeking = &(pSendContext->SeekVideo);
		previousMON = &(pSendContext->PrevVideoMON);
#ifdef CHECK_BUFFER_4_VIDEO
		{
			RMint32 avpts_diff;
			pSendContext->video_pts = Presentation_Time;
			avpts_diff = (RMint32)pSendContext->video_pts - (RMint32)pSendContext->audio_pts;
			if((RMuint32)abs(avpts_diff) > pSendContext->max_avpts_diff && pSendContext->audio_pts)	{
				pSendContext->max_avpts_diff = abs(avpts_diff);
				printf("Max_AVPTS_DIFF = %ld\n", avpts_diff);
			}
		}
#endif
		break;
	case RM_STREAM_AUDIO: 
		if (!pSendContext->audio_parameters[pSendContext->audio_stream_index].enabled)
			goto return_from_callback;
		SendPTS = pSendContext->SendAudioPts;
		PrevMON = pSendContext->prev_audio_media_object_number;
		decoder = 0; //pSendContext->dcc_info->audio_decoder;
		if (!pSendContext->isWMAPRO)
			pSendContext->AudioByteCounter += size;

		pSendContext->prev_audio_media_object_number = Media_Object_Number;
		
		Is_Key_Frame = 1; /* audio payload doesnt set the keyframe flag, so we must 
				     force it to one, see "if (*seeking)" below */
				     
		seeking = &(pSendContext->SeekAudio);
		previousMON = &(pSendContext->PrevAudioMON);

		if (((PlaybackStatus == RM_PSM_Playing) || 
		     (PlaybackStatus == RM_PSM_Paused) || 
		     (PlaybackStatus == RM_PSM_Prebuffering) ||
		     (pSendContext->sendAudioTrickmode)) 
		    &&
		    (!pSendContext->isWMAPRO)) 
			SendData = TRUE;
		else
			SendData = FALSE;
			    
			    
			
			

#ifdef CHECK_BUFFER_4_VIDEO
		{
			RMint32 avpts_diff;
			pSendContext->audio_pts = Presentation_Time;
			avpts_diff = (RMint32)pSendContext->video_pts - (RMint32)pSendContext->audio_pts;
			if((RMuint32)abs(avpts_diff) > pSendContext->max_avpts_diff && pSendContext->video_pts) {
				pSendContext->max_avpts_diff = abs(avpts_diff);
				printf("Max_AVPTS_DIFF = %ld\n", avpts_diff);
			}
		}
#endif
		if (PlaybackStatus == RM_PSM_Playing) {
			struct emhwlib_info PTSInfo;
			PTSInfo.ValidFields = TIME_STAMP_INFO;
			PTSInfo.TimeStamp = (RMuint64)Presentation_Time;
			
			if ((!pSendContext->isWMAPRO) && (ResyncAudio(pSendContext, &PTSInfo) == RM_SKIP_TO_RESYNC))
					goto return_from_callback;


			if ((pSendContext->actions.asyncCmd == RM_AUDIO_STREAM_CHANGE) && (pSendContext->actions.asyncCmdPending)) {
				RMbool status;
				RMDBGLOG((ENABLE, "got async cmd switch audio stream\n"));
				pSendContext->actions.asyncCmd = RM_NONE;
				pSendContext->actions.asyncCmdPending = FALSE;
				status = SwitchAudio(pSendContext, Media_Object_Number);
				if (status == TRUE)
					goto return_from_callback;
			}
			break;
		}
	}

#if 0
	if (PlaybackStatus == RM_PSM_Paused) {
		if (SendData)
			RMDBGLOG((ENABLE, "sending %s data in pause\n", (dataType == RM_STREAM_VIDEO) ? "video":"audio"));
		else
			RMDBGLOG((ENABLE, "skip %s data in pause\n", (dataType == RM_STREAM_VIDEO) ? "video":"audio"));
	}
#endif

	if (((PlaybackStatus == RM_PSM_Slow) || (PlaybackStatus == RM_PSM_Fast)) && (SendData) && (dataType == RM_STREAM_AUDIO) ) {
		RMDBGLOG((ENABLE, "sending audio while in trickmodes\n"));
	}

	
	if (*seeking) {
		if ((Is_Key_Frame) && (Offset_Into_Media_Object == 0)) {
			RMDBGLOG((ENABLE, ">>first %s payload after a seek, MON %lu, size %ld, pts %lu\n", (dataType == RM_STREAM_VIDEO) ? "video":"audio", Media_Object_Number, size, Presentation_Time));
			*previousMON = Media_Object_Number;
			SetPTS = TRUE;
		}
		else
			goto return_from_callback;
		
		*seeking = FALSE;
	}

	if ((pSendContext->isIFrameMode) && (dataType == RM_STREAM_VIDEO)) {
		switch (pSendContext->IFrameFSMState) {
		case RMasfIFrameFSM_Disabled: 
			break;
		case RMasfIFrameFSM_Init: 
			if ((Is_Key_Frame) && (Offset_Into_Media_Object == 0)) {
				RMDBGLOG((TRICKDBG, ">>this payload will be sent, MON %lu, size %ld, pts %lu\n", Media_Object_Number, size, Presentation_Time));
				pSendContext->PrevVideoMON = Media_Object_Number;
				pSendContext->IFrameFSMState = RMasfIFrameFSM_WaitIFrameMONChange;
				SetPTS = TRUE;
			}
			else {
			        RMDBGLOG((TRICKDBG, "++skip payload MON %lu, size %ld until KEY & OFF=0, pts %lu\n", Media_Object_Number, size, Presentation_Time));
				goto return_from_callback;
			}
			break;
		case RMasfIFrameFSM_WaitIFrameMONChange: 
			if (pSendContext->PrevVideoMON != Media_Object_Number) {
				RMDBGLOG((TRICKDBG,"++skipping video because IFrame MON(%lu) changed to %lu, size %lu\n", pSendContext->PrevVideoMON, Media_Object_Number, size));
				pSendContext->IFrameFSMState = RMasfIFrameFSM_SkipNext;
				goto return_from_callback;
			}

			break;
		case RMasfIFrameFSM_SkipNext: 
			RMDBGLOG((TRICKDBG, "++skippingNEXT video because IFrame MON(%lu) changed to %lu, size %lu\n", pSendContext->PrevVideoMON, Media_Object_Number, size));
			goto return_from_callback;
			break;
		default: 
			goto return_from_callback;
		}
		
	} else if (pSendContext->isIFrameMode) {
		// skip all other streams
		goto return_from_callback;
	}
	

	RMDBGLOG((DISABLE, "prevMON %s is %lu pts %lu\n", (dataType == RM_STREAM_VIDEO) ? "video":"audio", PrevMON, Presentation_Time));

	//  do not resend pts at each subpacket
	if ((Media_Object_Number_valid && (Media_Object_Number != PrevMON)) || SetPTS) {
		Info.ValidFields = TIME_STAMP_INFO;
		Info.TimeStamp = (RMuint64)Presentation_Time;

		pInfo = &Info;
		size_info = sizeof(Info);

		if (dataType == RM_STREAM_VIDEO) {
			pSendContext->video_last_pts = Presentation_Time;
			pSendContext->video_time_stamp = Presentation_Time;
		} 
		else if (dataType == RM_STREAM_AUDIO)
			pSendContext->audio_time_stamp = Presentation_Time;
			
		if ( pSendContext->FirstSystemTimeStamp ) {
			pSendContext->min_diff = 0;
			pSendContext->max_diff = 0;

			pSendContext->lastVideoPTS = 0;

			if (dataType == RM_STREAM_VIDEO)
				pSendContext->audio_time_stamp = pSendContext->video_time_stamp;
			else
				pSendContext->video_time_stamp = pSendContext->audio_time_stamp;
		}

		if (pSendContext->VideoStreamFound) {
			diff = pSendContext->video_time_stamp - pSendContext->audio_time_stamp;
			RMDBGLOG((DISABLE, "diff %lu\n", diff));
			if ( (diff < -DELTA_PTS) || (diff > DELTA_PTS)) {
				if ( (diff > 0) && (diff > pSendContext->max_diff+100) ) {
					pSendContext->max_diff = diff;
					if(PlaybackStatus == RM_PSM_Playing)
						RMDBGLOG((ENABLE, " %ld\n", diff));
				}
				if ( (diff < 0) && (diff < pSendContext->min_diff-100) ) {
					pSendContext->min_diff = diff;
					if(PlaybackStatus == RM_PSM_Playing)
						RMDBGLOG((ENABLE, " %ld\n", diff));
				}
			}
		}

		


	} 
	
	if (!SendPTS) {
		pInfo = NULL;
		size_info = 0;
	}


	
	if ((pSendContext->CurrentDisplayPTS) && (dataType == RM_STREAM_VIDEO))  {
		if ((Presentation_Time >= pSendContext->CurrentDisplayPTS) && (Is_Key_Frame) && (Offset_Into_Media_Object == 0)) {
			pSendContext->CurrentDisplayPTS = 0;
			pSendContext->SeekAudio = TRUE;
			pSendContext->IgnoreAudio = FALSE;
			RMDBGLOG((ENABLE, "will send video MON=%lu, size=%lu, pts=%lu %s, %lu\n",
				  Media_Object_Number, 
				  size, 
				  Presentation_Time,
				  Is_Key_Frame == 1 ? "key":"", 
				  Offset_Into_Media_Object));
		}
		else {
			RMDBGLOG((ENABLE, "dropping video frame MON=%lu, size=%lu, pts=%lu < DisplayPTS(%llu), %s, %lu\n", 
				  Media_Object_Number,
				  size, 
				  Presentation_Time, 
				  pSendContext->CurrentDisplayPTS,
				  Is_Key_Frame == 1 ? "key":"", 
				  Offset_Into_Media_Object));
			pSendContext->IgnoreAudio = TRUE;
			goto return_from_callback;
		}
	}
	if ((pSendContext->CurrentDisplayPTS) && (dataType == RM_STREAM_AUDIO)) {
		if ((Presentation_Time >= pSendContext->CurrentDisplayPTS) && 
		    (Is_Key_Frame) && (Offset_Into_Media_Object == 0) &&
		    (pSendContext->IgnoreAudio == FALSE)) {
			pSendContext->CurrentDisplayPTS = 0;
			RMDBGLOG((ENABLE, "will send audio MON=%lu, size=%lu, pts=%lu %s, %lu\n",
				  Media_Object_Number, 
				  size, 
				  Presentation_Time, 
				  Is_Key_Frame == 1 ? "key":"", 
				  Offset_Into_Media_Object));
		}
		else {
			RMDBGLOG((ENABLE, "dropping audio frame MON=%lu, size=%lu, pts=%lu < DisplayPTS(%llu)\n", 
				  Media_Object_Number, 
				  size,
				  Presentation_Time, 
				  pSendContext->CurrentDisplayPTS));
			goto return_from_callback;
		}
	}


	if ( pSendContext->FirstSystemTimeStamp && pInfo && (pInfo->ValidFields & TIME_STAMP_INFO)) {
		if ( (!pSendContext->PrerollSET) && pSendContext->Preroll ) {
			if (pInfo->TimeStamp < pSendContext->Preroll) {
				RMDBGLOG((ENABLE, "First PTS (%llu) < Preroll (%llu), adjusting Preroll to %llu so first PTS=0\n",
					  pInfo->TimeStamp, pSendContext->Preroll,
					  pInfo->TimeStamp));
				pSendContext->Preroll = pInfo->TimeStamp;
				pInfo->TimeStamp = 0;
			}
			else {
				RMDBGLOG((ENABLE, "Preroll is %llu: first PTS %llu needs to be adjusted to %llu\n", 
					  pSendContext->Preroll, pInfo->TimeStamp,
					  pInfo->TimeStamp - pSendContext->Preroll));
				pInfo->TimeStamp -= pSendContext->Preroll;
			}
			pSendContext->PrerollSET = TRUE;
		}

	}


#ifndef WITH_MONO
	if ((dataType == RM_STREAM_VIDEO) && SendData && pSendContext->play_opt->savems) {
        RMstatus err;
		RMuint64 pts = (pInfo == NULL) ? (RMuint64)-1 : pInfo->TimeStamp;
		RMuint64 dummy;
        RMuint8 *buffer = (RMuint8*)&dummy;
		RMuint64ToLeBuf(pts, buffer);

		err = dump_data_into_file(pSendContext->play_opt, RMVDEMUX_VIDEO, buffer, sizeof(RMuint64), Presentation_Time, Presentation_Time_valid, 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot dump pts data %d\n", err));
			goto return_from_callback;
		}
		RMDBGLOG((ENABLE, "dumped pts %lld (0x%llx)\n", pts, pts));
	}
#endif // WITH_MONO


	if ((pSendContext->audio_vop_tir != 1000) && (dataType == RM_STREAM_AUDIO)) {
		RMuint64 pts = (pInfo == NULL) ? 0 : pInfo->TimeStamp;
		RMuint64 scaledPTS;
		
		scaledPTS = (pts * pSendContext->audio_vop_tir) / 1000;
		RMDBGLOG((SENDDBG, "scaling audio pts %llu thru a factor %lu/1000 -> %llu\n", pts, pSendContext->audio_vop_tir, scaledPTS));
		if (pInfo)
			pInfo->TimeStamp = scaledPTS;
	}

	if ((pSendContext->video_vop_tir != 1000) && (dataType == RM_STREAM_VIDEO)) {
		RMuint64 pts = (pInfo == NULL) ? 0 : pInfo->TimeStamp;
		RMuint64 scaledPTS;
		
		scaledPTS = (pts * pSendContext->video_vop_tir) / 1000;
		RMDBGLOG((SENDDBG, "scaling video pts %llu thru a factor %lu/1000 -> %llu\n", pts, pSendContext->video_vop_tir, scaledPTS));
		if (pInfo)
			pInfo->TimeStamp = scaledPTS;
	}


	if ( pSendContext->FirstSystemTimeStamp && pInfo && (pInfo->ValidFields & TIME_STAMP_INFO)) {
		
		RMint64 firstPTS=0;
				
		RMuint32 timeScale = (dataType == RM_STREAM_VIDEO) ? pSendContext->video_vop_tir : pSendContext->audio_vop_tir;
			
		RMDBGLOG((ENABLE, "FirstSystemTimeStamp for %s = %llu(0x%llx) at %ld/sec = %lu s\n",
			  dataType == RM_STREAM_VIDEO ? "video":"audio",
			  pInfo->TimeStamp, 
			  pInfo->TimeStamp, 
			  timeScale,
			  (RMuint32)pInfo->TimeStamp / timeScale)); 
		

		if(pSendContext->isWMAPRO) {
			//this is correct because wmapro has timescale = 1000

			firstPTS = (RMint64)pInfo->TimeStamp + (RMint64)pSendContext->start_ms - (RMint64)(pSendContext->audio_vop_tir>>1);
			RMDBGLOG((ENABLE, "Set STC at least %ld clicks before PTS for WMAPRO decoding \n", pSendContext->audio_vop_tir>>1));
			RMDBGLOG((ENABLE, "firstPTS %lld %s\n", firstPTS, (firstPTS < 0) ? ">>> timer is negative!":""));
		}
		else {
			RMuint32 startms = (pSendContext->start_ms * timeScale) / 1000;
			RMuint32 offset = (300 * timeScale) / 1000;

			firstPTS = (RMint64)pInfo->TimeStamp + (RMint64)startms - (RMint64)offset;

			RMDBGLOG((ENABLE, "timer will be set to %lld %s\n", firstPTS, (firstPTS < 0) ? ">>> timer is negative!":""));
		}

		DCCSTCSetTime(pSendContext->dcc_info->pStcSource, RMmax(0, (RMuint64)firstPTS)+pSendContext->stc_offset_ms*((RMint64)(timeScale/1000)), timeScale);
		
		pSendContext->FirstSystemTimeStamp = FALSE;
		RMDBGLOG((ENABLE, "vpts-apts[ms]= 0\n"));
	}

	/* senddata for video and wma audio */
	if (SendData) {

#ifdef CHECK_BUFFER_4_VIDEO
	
		int cWait = 0;
#endif

		if (pInfo && (dataType == RM_STREAM_VIDEO)) {
			RMuint64 diff;
			
			diff = (RMuint64)pInfo->TimeStamp - pSendContext->lastVideoPTS;

			RMDBGLOG((DISABLE, "MON %3lu last pts %8llu current %8llu diff %4llu\n", 
				  Media_Object_Number, 
				  pSendContext->lastVideoPTS,
				  pInfo->TimeStamp,
				  diff));

			pSendContext->lastVideoPTS = pInfo->TimeStamp;
		}


		if (PlaybackStatus == RM_PSM_Prebuffering)
			RMDBGPRINT((ENABLE, "%s", dataType == RM_STREAM_VIDEO ? "v":"a"));


		RMDBGLOG((SENDDBG, "sending MON(%lu) %s, size %lu, pts %llu = 0x%llx (%s), %s, %lu\n",
			  Media_Object_Number, 
			  dataType == RM_STREAM_VIDEO ? "video":"audio",
			  size, 
			  pInfo == NULL ? 0:pInfo->TimeStamp, 
			  pInfo == NULL ? 0:pInfo->TimeStamp,
			  pInfo == NULL ? "no pts":(pInfo->ValidFields & TIME_STAMP_INFO ? "valid":""),
			  Is_Key_Frame == 1 ? "key":"", 
			  Offset_Into_Media_Object));
		
		if ((Is_Key_Frame) && (!Offset_Into_Media_Object) && (dataType == RM_STREAM_VIDEO))
			RMDBGLOG((IFRAMEDBG, "sending video keyframe MON(%lu) size %lu, pts %llu = 0x%llx (%s), %lu\n", 
				  Media_Object_Number, 
				  size,
				  pInfo == NULL ? 0:pInfo->TimeStamp,
				  pInfo == NULL ? 0:pInfo->TimeStamp,
				  pInfo == NULL ? "no pts" : (pInfo->ValidFields & TIME_STAMP_INFO ? "valid":""), 
				  Offset_Into_Media_Object));


		// send VC1 start codes
		if ((dataType == RM_STREAM_VIDEO) && (pSendContext->isVC1)) {

			if (pSendContext->getStartCodeBuffer) {
				if (pSendContext->startCodeBuffer) {
					RMDBGLOG((VC1_STARTCODE_DBG, "releasing startCodeBuffer @0x%08lx, bytes left %lu\n", (RMuint32)pSendContext->startCodeBuffer, pSendContext->startCodeBufferLeft));
					RUAReleaseBuffer(pSendContext->pDMA, pSendContext->startCodeBuffer);
				}
				while(RUAGetBuffer(pSendContext->pDMA, &(pSendContext->startCodeBuffer), GETBUFFER_TIMEOUT_US) != RM_OK) {
					RMDBGLOG((ENABLE, "cant get buffer for VC1 startcode\n"));
					PROCESS_KEY_INCALLBACK(TRUE,FALSE);
 				}
				pSendContext->startCodeBufferSize = (1 << pSendContext->play_opt->dmapool_log2size);
				pSendContext->startCodeBufferLeft = (1 << pSendContext->play_opt->dmapool_log2size);
				RMDBGLOG((VC1_STARTCODE_DBG, "got a new startCodeBuffer @0x%08lx, size %lu\n", (RMuint32)pSendContext->startCodeBuffer, pSendContext->startCodeBufferSize));
				pSendContext->getStartCodeBuffer = FALSE;
			}

			// check for start code presence in bitstream from ASF


			if ((buf[0] == 0) && (buf[1] == 0) && (buf[2] == 1)) {
				if (buf[3] == 0x0F) {
					// all start codes are already present in the bitstream
					// dont add any
					pSendContext->addSeqHeader = FALSE;
					pSendContext->addEntryHeader = FALSE;
					pSendContext->addFrameHeader = FALSE;
				}
				else if (buf[3] == 0x0E) {
					// dont add entryHeader nor frameHeader
					pSendContext->addEntryHeader = FALSE;
					pSendContext->addFrameHeader = FALSE;
				}
				else if (buf[3] == 0x0D) {
					// dont add frameHeader
					pSendContext->addFrameHeader = FALSE;
				}
				// no start code present, add them (default)
			}

			dumpedFrameSize += size;
			if (pSendContext->addSeqHeader)
				dumpedFrameSize += pSendContext->seqHeaderSize;
			if ((pSendContext->addEntryHeader) && Media_Object_Number_valid && (Media_Object_Number != PrevMON) && Is_Key_Frame && (Offset_Into_Media_Object == 0))
				dumpedFrameSize += pSendContext->entryHeaderSize;
			if ((pSendContext->addFrameHeader) && Media_Object_Number_valid && (Media_Object_Number != PrevMON))
				dumpedFrameSize += 4;

#ifndef WITH_MONO
			if (pSendContext->play_opt->savems) {
				RMstatus err;
				RMuint32 dummy;
				RMuint8 *buffer = (RMuint8*)&dummy;
				
				RMuint32ToLeBuf(dumpedFrameSize, buffer);

				RMDBGLOG((ENABLE, "frameSize %lu, dumpedFrameSize %lu (0x%lx)\n", size, dumpedFrameSize, dumpedFrameSize));
				err = dump_data_into_file(pSendContext->play_opt, RMVDEMUX_VIDEO, buffer, sizeof(RMuint32), Presentation_Time, Presentation_Time_valid, 0);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Cannot dump pts data %d\n", err));
					goto return_from_callback;
				}
				
			}
#endif // WITH_MONO

			

			// sequence header
			if (pSendContext->addSeqHeader) {
				RMuint32 i;

				// copy the seqHeader
				RMDBGLOG((ENABLE, "adding seqHeader, size %lu, startCodeBufferLeft %lu\n", pSendContext->seqHeaderSize, pSendContext->startCodeBufferLeft));
				for (i = 0; i < pSendContext->seqHeaderSize; i++)
					*(pSendContext->startCodeBuffer + i) = *(pSendContext->seqHeader + i);
				
				// send the seqHeader
				while (RUASendData(pSendContext->pRUA, decoder, pSendContext->pDMA, pSendContext->startCodeBuffer, pSendContext->seqHeaderSize, pInfo, size_info) != RM_OK) {
					RMDBGLOG((ENABLE, "waiting for sendSeqHeader to complete\n"));
				}
				
				// we only send the PTS with the first chunk
				pInfo = NULL;
				size_info = 0;

				// eventually, dump it to a file
				{
					RMstatus err;
					err = dump_data_into_file(pSendContext->play_opt, RMVDEMUX_VIDEO, pSendContext->startCodeBuffer, pSendContext->seqHeaderSize, Presentation_Time, Presentation_Time_valid, 0);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Cannot dump data %d\n", err));
						goto return_from_callback;
					}
				}

				pSendContext->startCodeBuffer += pSendContext->seqHeaderSize;
				pSendContext->startCodeBufferLeft -= pSendContext->seqHeaderSize;
				pSendContext->addSeqHeader = FALSE;

			}

			// entry header (for iframes)
			if ((pSendContext->addEntryHeader) && Media_Object_Number_valid && (Media_Object_Number != PrevMON) && Is_Key_Frame && (Offset_Into_Media_Object == 0))  {
				RMuint32 i;

				// copy the entryHeader
				RMDBGLOG((VC1_STARTCODE_DBG, "adding entryHeader (size %lu) to iframe MON %lu, startCodeBufferLeft %lu\n", pSendContext->entryHeaderSize, (RMuint32) Media_Object_Number, pSendContext->startCodeBufferLeft ));

				for (i = 0; i < pSendContext->entryHeaderSize; i++)
					*(pSendContext->startCodeBuffer + i) = *(pSendContext->entryHeader + i);
				
				// send the entryHeader
				while (RUASendData(pSendContext->pRUA, decoder, pSendContext->pDMA, pSendContext->startCodeBuffer, pSendContext->entryHeaderSize, pInfo, size_info) != RM_OK) {
					RMDBGLOG((ENABLE, "waiting for sendEntryHeader to complete\n"));
				}

				// we only send the PTS with the first chunk
				pInfo = NULL;
				size_info = 0;
				
				// eventually, dump it to a file
				{
					RMstatus err;
					err = dump_data_into_file(pSendContext->play_opt, RMVDEMUX_VIDEO, pSendContext->startCodeBuffer, pSendContext->entryHeaderSize, Presentation_Time, Presentation_Time_valid, 0);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Cannot dump data %d\n", err));
						goto return_from_callback;
					}
				}

				pSendContext->startCodeBuffer += pSendContext->entryHeaderSize;
				pSendContext->startCodeBufferLeft -= pSendContext->entryHeaderSize;

			}

			// picture header (for all frames)
			if ((pSendContext->addFrameHeader) && Media_Object_Number_valid && (Media_Object_Number != PrevMON)) {
				// new picture, add picture header startcode "00 00 01 0D"
				RMDBGLOG((VC1_STARTCODE_DBG, "add newPic startcode to MON %lu, startCodeBufferLeft %lu\n", (RMuint32) Media_Object_Number, pSendContext->startCodeBufferLeft ));
				*(pSendContext->startCodeBuffer) = 0x00;
				*(pSendContext->startCodeBuffer + 1) = 0x00;
				*(pSendContext->startCodeBuffer + 2) = 0x01;
				*(pSendContext->startCodeBuffer + 3) = 0x0D;

				// send the startcode
				while (1) {
					RMstatus err;

					err = RUASendData(pSendContext->pRUA, decoder, pSendContext->pDMA, pSendContext->startCodeBuffer, 4, pInfo, size_info);
					if (err == RM_OK) 
						break;
					/* exit prebuf state if fifo is full */
					else if (err == RM_PENDING) {
						struct RUAEvent e;

						check_prebuf_state(pSendContext, 0);						
						
						e.ModuleID = decoder;
						e.Mask = RUAEVENT_XFER_FIFO_READY;
						RUAWaitForMultipleEvents(pSendContext->pRUA, &e, 1, SENDDATA_TIMEOUT_US, NULL);
						RMDBGLOG((ENABLE, "waiting for sendNewPicSC to complete\n"));
					}
					else
						goto return_from_callback;
				}

				// we only send the PTS with the first chunk
				pInfo = NULL;
				size_info = 0;
				
				// eventually, dump it to a file
				{
					RMstatus err;
					err = dump_data_into_file(pSendContext->play_opt, RMVDEMUX_VIDEO, pSendContext->startCodeBuffer, 4, Presentation_Time, Presentation_Time_valid, 0);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Cannot dump data %d\n", err));
						goto return_from_callback;
					}
				}

				pSendContext->startCodeBuffer += 4;
				pSendContext->startCodeBufferLeft -= 4;
			}

			if (pSendContext->startCodeBufferLeft < (pSendContext->seqHeaderSize + pSendContext->entryHeaderSize + 4))
				pSendContext->getStartCodeBuffer = TRUE;
			
		}


		// send the data from the asf packet
		if (dataType == RM_STREAM_AUDIO) {
			RMint32 lastOKinstance = -1;

			while (DCCMultipleAudioSendData(pSendContext->dcc_info->pMultipleAudioSource, pSendContext->pDMA, buf, size, pInfo, size_info, &lastOKinstance) != RM_OK) {
				struct RUAEvent e;
				struct DCCAudioSourceHandle audioHandle;
				//RMbool gotKey;
				RMstatus status;

				if (lastOKinstance == -1) {
					fprintf(stderr, "cant wait on unknown instance!!\n");
					goto return_from_callback;
				}
								
				check_prebuf_state(pSendContext, 0);						
				
#if 0
				//impossible, if we are here, it's wma and not wmapro
				gotKey = try_decode_wmapro(pSendContext, FALSE);
				if (gotKey)
					RMDBGLOG((ENABLE, "*************gotkey\n"));
#endif

				PROCESS_KEY_INCALLBACK(TRUE,FALSE);
				
				status = DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(pSendContext->dcc_info->pMultipleAudioSource, lastOKinstance, &audioHandle);
				if (status != RM_OK)
					goto return_from_callback;
				
#ifdef CHECK_BUFFER_4_VIDEO
				cWait ++;
#endif

				e.ModuleID = audioHandle.moduleID;
				e.Mask = RUAEVENT_XFER_FIFO_READY;
				RUAWaitForMultipleEvents(pSendContext->pRUA, &e, 1, SENDDATA_TIMEOUT_US, NULL);

				RUAResetEvent(pSendContext->pRUA, &e);				
			}
		}
		else {
			while (RUASendData(pSendContext->pRUA, decoder, pSendContext->pDMA, buf, size, pInfo, size_info) != RM_OK) {
				struct RUAEvent e;
				
				RMDBGLOG((ENABLE, "waiting for senddata %s\n", dataType == RM_STREAM_VIDEO ? "video":"audio"));
				
				check_prebuf_state(pSendContext, 0);							
				
				try_decode_wmapro(pSendContext, FALSE);
				PROCESS_KEY_INCALLBACK(TRUE,FALSE);
				
#ifdef CHECK_BUFFER_4_VIDEO
				cWait ++;
#endif
				e.ModuleID = decoder;
				e.Mask = RUAEVENT_XFER_FIFO_READY;
				RUAWaitForMultipleEvents(pSendContext->pRUA, &e, 1, SENDDATA_TIMEOUT_US, NULL);
			}

			/* sendind data may fill-up the xfer fifo, so we reset the event */
			{
				struct RUAEvent e;
				
				e.ModuleID = decoder;
				e.Mask = RUAEVENT_XFER_FIFO_READY;
				RUAResetEvent(pSendContext->pRUA, &e);
			}
		}
		
#ifdef CHECK_BUFFER_4_VIDEO
		if(cWait)
			printf("Wait %d cycle to send video data\n", cWait);

#endif
		goto callback_end; //callback end
	}

	
#if 1
	/* wmapro decoding and senddata */	
	if ((dataType == RM_STREAM_AUDIO) && 
	    ((PlaybackStatus == RM_PSM_Playing) || 
	     (PlaybackStatus == RM_PSM_Paused) || 
	     (PlaybackStatus == RM_PSM_Prebuffering) ||
	     (pSendContext->sendAudioTrickmode)) &&
	    (pSendContext->isWMAPRO)) {
		RMuint32 wr1, wr2;
 		RMuint32 size1;
		struct wmapro_buffer_info *buf_info;

		RMDBGLOG((SENDDBG, "sending (wmapro) MON(%lu) %s, size %lu, pts %llu = 0x%llx (%s), %s, %lu\n",
			  Media_Object_Number, 
			  dataType == RM_STREAM_VIDEO ? "video":"audio",
			  size, 
			  pInfo == NULL ? 0:pInfo->TimeStamp, 
			  pInfo == NULL ? 0:pInfo->TimeStamp,
			  pInfo == NULL ? "no pts":(pInfo->ValidFields & TIME_STAMP_INFO ? "valid":""),
			  Is_Key_Frame == 1 ? "key":"", 
			  Offset_Into_Media_Object));

 		while (RMfifo_get_writable_size(pSendContext->wmapro_fifo, &wr1, &size1, &wr2) < sizeof(struct wmapro_buffer_info)) {

			RMDBGLOG((WMAPRODBG, "WMAPRO fifo too small\n"));

			try_decode_wmapro(pSendContext, FALSE);
			PROCESS_KEY_INCALLBACK(TRUE,FALSE);
  		} 

 		buf_info = (struct wmapro_buffer_info *) wr1;
  
#if (EM86XX_MODE == EM86XX_MODEID_STANDALONE)

#if (EM86XX_CHIP == EM86XX_CHIPID_TANGO2)
		buf_info->ptr = buf;
#else
 		buf_info->ptr = (RMuint8 *)((RMuint32)buf & 0x7fffffff);
#endif

#else
 		buf_info->ptr = buf;
#endif
  
 		buf_info->size = size;
 		buf_info->new_buffer = TRUE;
 		buf_info->Info = Info;
 		buf_info->Stream_Number = Stream_Number;
 		buf_info->Media_Object_Number = Media_Object_Number;
 		buf_info->fSendPTS = 2;

 		RUAAcquireBuffer(pSendContext->pDMA, buf);
 		RMDBGLOG((WMAPRODBG, "Insert address %p into WMAPRO fifo size(%lu), valid(%lu) "
			"pts(%llu), MON(%lu)\n", buf, size, Info.ValidFields, Info.TimeStamp,
			 Media_Object_Number));
 		RMfifo_incr_write_ptr(pSendContext->wmapro_fifo, sizeof(struct wmapro_buffer_info));



  	        RMDBGLOG((WMAPRODBG, "buf 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x\n", 
		  *(RMuint8*)buf, 
		  *(RMuint8*)(buf+1), 
		  *(RMuint8*)(buf+2), 
		  *(RMuint8*)(buf+3), 
		  *(RMuint8*)(buf+4), 
		  *(RMuint8*)(buf+5)));

		{
			try_decode_wmapro(pSendContext, FALSE);
			PROCESS_KEY_INCALLBACK(TRUE,FALSE);
		}
	}
#endif
  
 callback_end:

	/*************************************************************************************/
	/* video debug stuff */
	/*************************************************************************************/

	if (dataType == RM_STREAM_VIDEO) {
		if (Media_Object_Number_valid && (Media_Object_Number != PrevMON)) {
#ifdef SAVE_INPUT_FRAMES
			char szTemp[50];
			if (pSendContext->f_compressed_frames >= 0)
				close(pSendContext->f_compressed_frames);
			sprintf(szTemp, "frame%d.bin", (int) pSendContext->video_frame_counter + 1);
			pSendContext->f_compressed_frames = open(szTemp, 
				O_CREAT | O_RDWR | O_TRUNC, S_IREAD | S_IWRITE | S_IRGRP);
#endif
			pSendContext->video_frame_counter++;

#ifdef DISPLAY_VIDEO_STREAM_PAYLOAD_INFO
			RMDBGLOG((ENABLE, "VideoFrameCnt=%ld VideoByteCounter=0x%lx (size=0x%lx)",
				  pSendContext->video_frame_counter, pSendContext->VideoByteCounter, size))
#if 0
			if (Presentation_Time_valid)
				RMDBGLOG((ENABLE, " - PTS = 0x%lx", Presentation_Time))
			if (Media_Object_Number_valid)
				RMDBGLOG((ENABLE, " - Media_Object_Number = %lx", Media_Object_Number))
			if (Is_Key_Frame)
				RMDBGLOG((ENABLE, " (key frame)"));
#endif
			RMDBGLOG((ENABLE,"\n"));
			RMDBGLOG((ENABLE,"%02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x...\n",
				  (int)(buf[0]), (int)(buf[1]), (int)(buf[2]), (int)(buf[3]), 
				  (int)(buf[4]), (int)(buf[5]), (int)(buf[6]), (int)(buf[7]), 
				  (int)(buf[8]), (int)(buf[9]), (int)(buf[10])))
#endif
		}

#ifdef SAVE_INPUT_FRAMES
		if (pSendContext->f_compressed_frames >= 0)
			write(pSendContext->f_compressed_frames, buf, size);
#endif

		if(pSendContext->ContiguousVideoLength == 0)
			pSendContext->video_time_start = get_ustime();
		pSendContext->ContiguousVideoLength +=size;
		if(pSendContext->ContiguousVideoLength > CONTIGUOUS_LENGHT) {
			pSendContext->video_time_end = get_ustime();
		}
		pSendContext->ContiguousAudioLength = 0;

#ifndef WITH_MONO
		if ((!pSendContext->isVC1) && (pSendContext->play_opt->savems)) {
			// dump size, then data
			
			RMstatus err;
			RMuint32 dummy;
			RMuint8 *buffer = (RMuint8*)&dummy;
			
			RMuint32ToLeBuf(size, buffer);
			
			RMDBGLOG((ENABLE, "frameSize %lu (0x%lx)\n", size, size));
			err = dump_data_into_file(pSendContext->play_opt, RMVDEMUX_VIDEO, buffer, sizeof(RMuint32), Presentation_Time, Presentation_Time_valid, 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot dump frameSize data %d\n", err));
				goto return_from_callback;
			}
			
		}

		{
			RMstatus err;
			err = dump_data_into_file(pSendContext->play_opt, RMVDEMUX_VIDEO, buf, size, Presentation_Time, Presentation_Time_valid, 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot dump data %d\n", err));
				goto return_from_callback;
			}
		}
#endif // WITH_MONO


#ifdef DISPLAY_VIDEO_BITRATE
	
 		if (pSendContext->prev_timeV == 0) {
			pSendContext->prev_timeV = Presentation_Time;
		}
		else if (Presentation_Time - pSendContext->prev_timeV > 1000) {
			RMuint32 delta = Presentation_Time - pSendContext->prev_timeV;
			RMuint32 factor = (RMuint32)round_int_div((RMuint64)delta, 1000);
			if (factor == 0)
				factor = 1;

			RMDBGLOG((ENABLE,"video bitrate = %d.%dMBit/s, %lu bytes/sec, delta %lu, factor %lu, max %lu\n", 
				  (int) ((pSendContext->nb_bytes_since_prev_timeV * 8) / 1000000),
				  (int) (((pSendContext->nb_bytes_since_prev_timeV * 8) % 1000000) / 1000),
				  (pSendContext->nb_bytes_since_prev_timeV / factor),
				  delta,
				  factor,
				  pSendContext->maxByteRateV));
			if (pSendContext->maxByteRateV < (pSendContext->nb_bytes_since_prev_timeV / factor))
				pSendContext->maxByteRateV = (pSendContext->nb_bytes_since_prev_timeV / factor);
			pSendContext->prev_timeV = Presentation_Time;
			pSendContext->nb_bytes_since_prev_timeV = 0;
		}
		pSendContext->nb_bytes_since_prev_timeV += size;
		
	
#endif
	}

	/* audio debug stuff */

	if (dataType == RM_STREAM_AUDIO) {
		if (Media_Object_Number_valid && (Media_Object_Number != PrevMON)) {

			pSendContext->audio_frame_counter++;

#ifdef DISPLAY_AUDIO_STREAM_PAYLOAD_INFO
			if (size == 0) 
				RMDBGLOG((ENABLE, "Audio frame #%ld, audio byte count = %ld : empty size\n", 
					  pSendContext->audio_frame_counter, pSendContext->AudioByteCounter));
			else
				RMDBGLOG((ENABLE, "Audio frame #%ld, audio byte count = %ld\n", 
					  pSendContext->audio_frame_counter, pSendContext->AudioByteCounter));

			if (Media_Object_Number_valid && (Media_Object_Number != pSendContext->prev_audio_media_object_number)) {
				RMDBGLOG((ENABLE, "Stream #%d, writing %lu bytes (total = %ld)", Stream_Number, size, pSendContext->AudioByteCounter));
				if (Presentation_Time_valid)
					RMDBGLOG((ENABLE, " - PTS = %lu", Presentation_Time));
				if (Media_Object_Number_valid)
					RMDBGLOG((ENABLE, " - Media_Object_Number = %lu", Media_Object_Number));
				if (Is_Key_Frame)
					RMDBGLOG((ENABLE, " (key frame)"));
				RMDBGLOG((ENABLE,"\n"));
			}
#endif
		}

		if(pSendContext->ContiguousVideoLength == 0)
			pSendContext->audio_time_start = get_ustime();
		pSendContext->ContiguousAudioLength = 0;
		pSendContext->ContiguousAudioLength +=size;
		if(pSendContext->ContiguousAudioLength > CONTIGUOUS_LENGHT) {
			pSendContext->audio_time_end = get_ustime();
		}
		pSendContext->ContiguousVideoLength = 0;


#ifdef DISPLAY_AUDIO_BITRATE
	
 		if (pSendContext->prev_timeA == 0) {
			pSendContext->prev_timeA = Presentation_Time;
		}
		else if (Presentation_Time - pSendContext->prev_timeA > 1000) {
			RMuint32 delta = Presentation_Time - pSendContext->prev_timeA;
			RMuint32 factor = (RMuint32)round_int_div((RMuint64)delta, 1000);
			if (factor == 0)
				factor = 1;

			RMDBGLOG((ENABLE,"audio bitrate = %d.%dMBit/s, %lu bytes/sec, delta %lu, factor %lu, max %lu\n", 
				  (int) ((pSendContext->nb_bytes_since_prev_timeA * 8) / 1000000),
				  (int) (((pSendContext->nb_bytes_since_prev_timeA * 8) % 1000000) / 1000),
				  (pSendContext->nb_bytes_since_prev_timeA / factor),
				  delta,
				  factor,
				  pSendContext->maxByteRateA));
			if (pSendContext->maxByteRateA < (pSendContext->nb_bytes_since_prev_timeA / factor))
				pSendContext->maxByteRateA = (pSendContext->nb_bytes_since_prev_timeA / factor);

			pSendContext->prev_timeA = Presentation_Time;
			pSendContext->nb_bytes_since_prev_timeA = 0;
		}
		pSendContext->nb_bytes_since_prev_timeA += size;
		
	
#endif

#ifndef WITH_MONO
		{
			RMstatus err;

			err = dump_data_into_file(pSendContext->play_opt, RMVDEMUX_AUDIO, buf, size, Presentation_Time, Presentation_Time_valid, 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot dump data %d\n", err));
				goto return_from_callback;
			}
		}
#endif // WITH_MONO
	}

	return;

 return_from_callback:

	RMDBGLOG((PAYLOADDBG,"dropped ST:%02d,MON:%04d,Key:%01d,time:%05d.%03d,size:%05d,left:%05d\n",
		  Stream_Number, Media_Object_Number, Is_Key_Frame, Presentation_Time / 1000,
		  Presentation_Time % 1000, size, bytes_left));
	if ((Is_Key_Frame) && (dataType == RM_STREAM_VIDEO) && (!Offset_Into_Media_Object)) 
	{
		RMDBGLOG((IFRAMEDBG, "dropped a keyframe! ST:%02d MON:%04d Key:%01d time:%05d.%03d = "
			"0x%lx size:%05d left:%05d\n", Stream_Number, Media_Object_Number,
			Is_Key_Frame,  Presentation_Time / 1000, Presentation_Time % 1000,
			Presentation_Time, size, bytes_left));
	}

	return;
}

static void play_Payload(void *context,
			 unsigned char Stream_Number,  
			 unsigned char *buf, 
			 unsigned long size,
			 unsigned long bytes_left,
			 unsigned char Is_Key_Frame,
			 unsigned long Media_Object_Number, 
			 unsigned char Media_Object_Number_valid,
			 unsigned long Presentation_Time, 
			 unsigned char Presentation_Time_valid,
			 unsigned long Offset_Into_Media_Object)
{
	struct asf_context *pSendContext = (struct asf_context *) context;

	if ( pSendContext->cardea_context == NULL ) {
 
		play_Payload2(context,
			      Stream_Number, 
			      buf, 
			      size, 
			      0, 
			      Is_Key_Frame, 
			      Media_Object_Number,
			      Media_Object_Number_valid, 
			      Presentation_Time, 
			      Presentation_Time_valid, 
			      Offset_Into_Media_Object);
		
	} else {
		
		struct stream_info *pSt;
		RMuint32	buf_off;
		RMuint32	i;
	
		pSt = pSendContext->stream_table;
		for( i=0; i < sizeof(pSendContext->stream_table)/sizeof(struct stream_info); i++, pSt++ ) {
			if ( pSt->stream_number == Stream_Number || pSt->stream_number == (RMuint32)-1 ) {
				break;
			}
		}
		if ( i >= sizeof(pSendContext->stream_table)/sizeof(struct stream_info) ) {
			return;
		}
		if ( pSt->stream_number == (RMuint32)-1 ) {
			pSt->stream_number = Stream_Number;
			pSt->aes_buf = 0;
			pSt->aes_buf_len = 0;
		}	
	
		if ( pSt->aes_buf == 0 ) {
			while(1) {
				if ( RUAGetBuffer( pSendContext->pDMA, &pSt->aes_buf, 0 ) == RM_OK ) {
					break;
				}
				try_decode_wmapro(pSendContext, FALSE);
				if ( RUAGetBuffer( pSendContext->pDMA, &pSt->aes_buf, GETBUFFER_TIMEOUT_US ) != RM_OK ) {
					RMDBGLOG(( DISABLE, "Waiting for RUA buffer\n"));
					try_decode_wmapro(pSendContext, FALSE);
				}
				else
					break;
			}

			pSt->aes_buf = (RMuint8 *)(((RMuint32)pSt->aes_buf + 15) & ~15);
  		}
  
		buf_off = Offset_Into_Media_Object & 0x0f;

		memcpy( pSt->aes_buf+buf_off+pSt->aes_buf_len, buf, size );
		pSt->aes_buf_len += size;

		if ( bytes_left == 0 ) {
			play_Payload2(context,
				      Stream_Number, 
				      pSt->aes_buf+buf_off, 
				      pSt->aes_buf_len, 
				      0, 
				      Is_Key_Frame, 
				      Media_Object_Number,
				      Media_Object_Number_valid, 
				      Presentation_Time, 
				      Presentation_Time_valid, 
				      Offset_Into_Media_Object );
			
			RUAReleaseBuffer( pSendContext->pDMA, pSt->aes_buf );
			pSt->aes_buf = 0;
			pSt->aes_buf_len = 0;	
		}
	}
   
}




static void inband_AspectRatio(void *context,
			RMuint16 Stream_Num,
			RMuint32 aspectRatioX,
			RMuint32 aspectRatioY)
{
	struct asf_context *pSendContext = (struct asf_context *) context;
       	struct SurfaceAspectRatio_type param;
	RMstatus err;

	if((pSendContext->video_stream_index != 0) /* the video stream number is not yet known at this point */
		&& (Stream_Num != pSendContext->video_stream_index))
		return;

	if ((aspectRatioX == pSendContext->inband_aspect_ratio_x) && (aspectRatioY == pSendContext->inband_aspect_ratio_y))
		return;

	RMDBGLOG((ENABLE,"Got inband aspect ratio to %lu:%lu\n", aspectRatioX, aspectRatioY));

	param.type = EMhwlibAspectRatio_Pixel;
	param.ar.X = aspectRatioX;
	param.ar.Y = aspectRatioY;

	RMDBGLOG((ENABLE,"will set inband aspect ratio to %lu:%lu\n", param.ar.X, param.ar.Y));
	
	if (pSendContext->pRUA && pSendContext->video_stream_index) {
		err = RUASetProperty(pSendContext->pRUA, pSendContext->dcc_info->video_decoder, RMVideoDecoderPropertyID_InbandSurfaceAspectRatio, &param, sizeof(param), 0);
		if (err != RM_OK) {
			RMDBGLOG((ENABLE, "Cannot set video inband aspect ratio\n"));
		}
		else {
			pSendContext->setAspectRatio = FALSE;
		}
	}
	else {
		/*
		 * if RUA hasn't been yet open OR if the video stream number that we will be playing is not yet known, 
		 * we've to schedule the command for later 
		 */
		pSendContext->setAspectRatio = TRUE;
		pSendContext->InBandAspectRatioParams = param;
		pSendContext->inband_aspect_ratio_stream_index = Stream_Num;
		RMDBGLOG((ENABLE, "rua not open yet OR the video stream number that we will be playing is not yet known: scheduling aspect ratio change for later\n"));
	}
	pSendContext->inband_aspect_ratio_x = aspectRatioX;
	pSendContext->inband_aspect_ratio_y = aspectRatioY;
}

static void payload_extension (void *context,
			       unsigned short Stream_Number,
			       unsigned long Media_Object_Number,
			       unsigned char Media_Object_Number_valid,
			       unsigned short Payload_Extension_System_ID,
			       unsigned char *Payload_Extension_System_Data,
			       unsigned short Partial_Payload_Extension_System_Data_Size,
			       unsigned short Payload_Extension_System_Data_Size,
			       unsigned short bytes_left) 
{
	struct asf_context *pSendContext = (struct asf_context *) context;

	if(pSendContext->video_stream_index == Stream_Number) {
		if(
		   (Payload_Extension_System_ID & RMASFPayloadExtensionSystemPixelAspectRatio)
		   &&
		   (Payload_Extension_System_Data_Size == 2)
		   ) {
			/* data might be fragmented (split on 2 buffers) */

			/* note that the ASF spec says that aspect ratio is given in y:x order (section 7.3.2.4)
			   however, in practice, streams have the aspect ratio encoded in x:y order, that's why we
			   need to inverse them here */

			if(Partial_Payload_Extension_System_Data_Size == 1) {
				if(bytes_left == 1) 
					pSendContext->save_inband_aspect_ratio_x = Payload_Extension_System_Data[0];
				else
					inband_AspectRatio(context, 
							   Stream_Number,
							   pSendContext->save_inband_aspect_ratio_x,
							   Payload_Extension_System_Data[0]);
			} else { /* Partial_Payload_Extension_System_Data_Size will never be 0 */
				inband_AspectRatio(context, 
						   Stream_Number,
						   Payload_Extension_System_Data[0],
						   Payload_Extension_System_Data[1]);
			}
		}
	}
	/* #### Begin CARDEA code #### */
	if (pSendContext->cardea_context != NULL && (Payload_Extension_System_ID & RMASFPayloadExtensionSystemEncryptionSampleID)){
		if (Partial_Payload_Extension_System_Data_Size != Payload_Extension_System_Data_Size){
			RMDBGLOG((DISABLE,"Partial Sample ID extension : %lu bytes\n", Partial_Payload_Extension_System_Data_Size));
			RMMemcpy(pSendContext->sample_id + Payload_Extension_System_Data_Size - bytes_left - Partial_Payload_Extension_System_Data_Size, 
					Payload_Extension_System_Data, 
					Partial_Payload_Extension_System_Data_Size);
		}else{
			RMDBGLOG((DISABLE,"Complete Sample ID extension : %lu bytes\n", Payload_Extension_System_Data_Size));
			RMMemcpy(pSendContext->sample_id, Payload_Extension_System_Data, Partial_Payload_Extension_System_Data_Size);
			RMDBGLOG((DISABLE,"Sample ID = 0x%08lx%08lx\n", 
						RMbeBufToUint32((RMuint8 *)pSendContext->sample_id),
						RMbeBufToUint32((RMuint8 *)pSendContext->sample_id+4)));
		}
		if (bytes_left == 0)
			update_cardea_sample_id(
					pSendContext->cardea_context, 
					Stream_Number, 
					Media_Object_Number, 
					pSendContext->sample_id, 
					Payload_Extension_System_Data_Size);

	}
	/* #### End CARDEA code #### */


}

static void dummy_drm_init(void *context,
			   RMuint8 *Data,
			   RMuint32 Partial_Data_Size,
			   RMuint32 Data_Size)
{
	return;
}


static void dummy_content_encryption_callback(void *context,
					      RMuint8 *Secret_Data,
					      RMuint32 Partial_Secret_Data_Length,
					      RMuint32  Secret_Data_Length,
					      RMuint8 *Key_ID,                                // ASCII char
					      RMuint32 Partial_Key_ID_Length,
					      RMuint32 Key_ID_Length,
					      RMuint8 *License_URL,                           // ASCII char
					      RMuint32 Partial_License_URL_Length,
					      RMuint32 License_URL_Length)
{
	//struct asf_context *pSendContext = (struct asf_context *) context;

	RMDBGLOG((ENABLE, "content_encryption_callback:\n"
		  "KeyID: %s partial_len %lu len %lu\n"
		  "License URL: %s partial_len %lu len %lu\n",
		  Key_ID,
		  Partial_Key_ID_Length,
		  Key_ID_Length,
		  License_URL,
		  Partial_License_URL_Length,
		  License_URL_Length));

	return;

}

static RMstatus WaitForEOS(struct asf_context *context, struct RM_PSM_Actions *pActions)
{
	RMuint32 eos_bit_field = 0;
	enum RM_PSM_State PlaybackStatus = RM_PSM_GetState(context->PSMcontext, &(context->dcc_info));
	
	if (context->VideoByteCounter > 0) {
		RMuint32 byteRate;

		
#if 1
		// Hack: send last PTS again so that video ucode can get the EOS. The problem is that
		// there is still data in the FIFO and the next inband command is not read by the video microcode.
		struct emhwlib_info Info;
		RMuint8 *buffer;
		

		while(RUAGetBuffer(context->pDMA, &buffer, GETBUFFER_TIMEOUT_US) != RM_OK) {
			/* should never happen since we released an empty buffer before getting here */
			RMDBGLOG((ENABLE,"Cannot get buffer for EOS\n"));
		}

		buffer[0] = 0;
		
		Info.ValidFields = TIME_STAMP_INFO;
		Info.TimeStamp = context->video_last_pts;
		while (RUASendData(context->pRUA, context->dcc_info->video_decoder, context->pDMA, buffer, 1, &Info, sizeof(Info)) != RM_OK) {
			usleep(SENDDATA_TIMEOUT_US); // Should rarelly happen...
		}

		RUAReleaseBuffer(context->pDMA, buffer);
#endif
		eos_bit_field |= EOS_BIT_FIELD_VIDEO;
		
		byteRate = context->VideoByteCounter / (context->Duration / 1000);
		RMDBGLOG((ENABLE, "TotalVideoSent %lu bytes, %lubytes/sec, wait for video EOS\n", 
			  context->VideoByteCounter,
			  byteRate));
	}

	if (context->AudioByteCounter > 0) {
		RMuint32 byteRate;

		if ((PlaybackStatus == RM_PSM_Playing) ||
		    (PlaybackStatus == RM_PSM_Prebuffering))
			eos_bit_field |= EOS_BIT_FIELD_AUDIO;

		byteRate = context->AudioByteCounter / (context->Duration / 1000);
		
		RMDBGLOG((ENABLE, "TotalAudioSent %lu bytes, %lubytes/sec, wait for audio EOS\n", 
			  context->AudioByteCounter,
			  byteRate));
	}
	
	return WaitForEOSWithCommand(context->PSMcontext, &(context->dcc_info), pActions, eos_bit_field);
	//return CommonWaitForEOS(context->dcc_info, pcmd, eos_bit_field, KEYFLAGS);
}


static RMstatus Stop(struct asf_context *pSendContext, RMuint32 devices)
{
	RMstatus err = RM_OK;
	
	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "STOP: stc\n"));
		DCCSTCStop(pSendContext->dcc_info->pStcSource);
	}

	if (devices & RM_DEVICES_VIDEO) {
		if ((pSendContext->SendVideoData) && (pSendContext->VideoStreamFound)) {

			if (pSendContext->play_opt->disk_ctrl_state != DISK_CONTROL_STATE_DISABLE) {
				while (pSendContext->dmabuffer_index > 0) {
					pSendContext->dmabuffer_index--;
					if (pSendContext->dmabuffer_array[pSendContext->dmabuffer_index]) {
						RMDBGLOG((ENABLE, "releasing buffer index %lu buffer %p\n", pSendContext->dmabuffer_index, pSendContext->dmabuffer_array[pSendContext->dmabuffer_index]));
						RUAReleaseBuffer(pSendContext->pDMA, pSendContext->dmabuffer_array[pSendContext->dmabuffer_index]);
					}
				}
			}


			RMDBGLOG((ENABLE, "STOP: video decoder\n"));
			err = DCCStopVideoSource(pSendContext->dcc_info->pVideoSource, DCCStopMode_LastFrame);
			if (RMFAILED(err)){
				RMDBGLOG((ENABLE, "Error stopping video source %d\n", err));
				return err;
			}
			pSendContext->video_decoder_initialized = FALSE;
			//sleep(1);

			if (pSendContext->isVC1) {
				RMDBGLOG((ENABLE, "codec: VC1 Advanced Profile, will add seqHeader to bitstream\n"));
				pSendContext->addSeqHeader = TRUE;
			}
		}
	}

	if (devices & RM_DEVICES_AUDIO) {
		if ((pSendContext->audio_parameters[pSendContext->audio_stream_index].enabled) && (pSendContext->AudioStreamFound)) {
			if (pSendContext->sendAudioTrickmode) {
				RMDBGLOG((ENABLE, "******* reset audio timer routing\n"));
				unMuteAudio(pSendContext->dcc_info);
				routeAudioTimerToDisplayPTS(pSendContext->dcc_info, FALSE);
			}
				
			RMDBGLOG((ENABLE, "STOP: audio decoder\n"));
            if (pSendContext->dcc_info->pMultipleAudioSource) {
				err = DCCStopMultipleAudioSource(pSendContext->dcc_info->pMultipleAudioSource);
				if (RMFAILED(err)){
					RMDBGLOG((ENABLE,"Error stopping audio source %d\n", err));
					return err;
				}
				if (pSendContext->isWMAPRO) {
					flush_wmaproFIFO(pSendContext);
				}
				pSendContext->audio_decoder_initialized = FALSE;
			}
		}
	}

	if ((devices & RM_DEVICES_AUDIO) && (devices & RM_DEVICES_VIDEO)) {
		pSendContext->FirstSystemTimeStamp = TRUE;
	}

	return err;

}

static RMstatus Play(struct asf_context * pSendContext, RMuint32 devices, enum DCCVideoPlayCommand mode)
{

	RMstatus err = RM_OK;
	
	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "PLAY: stc\n"));
		DCCSTCPlay(pSendContext->dcc_info->pStcSource);
	}

	if (devices & RM_DEVICES_VIDEO) {
		if ((pSendContext->SendVideoData) && (pSendContext->VideoStreamFound)) {
			err = initVideoDecoder(pSendContext);
			if (err != RM_OK) {
				RMDBGLOG((ENABLE, "error during video init, disable video\n"));
				pSendContext->SendVideoData = FALSE;
				return err;
			}

			RMDBGLOG((ENABLE, "PLAY: video decoder %s\n", (mode == DCCVideoPlayIFrame ? "(iframe)":"")));
			err = DCCPlayVideoSource(pSendContext->dcc_info->pVideoSource, mode);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot play video decoder %d\n", err));
				return err;
			}
		}
	}

	if (devices & RM_DEVICES_AUDIO)
    {
		if ((pSendContext->SendAudioData) && (pSendContext->AudioStreamFound)) 
        {
			RMDBGLOG((ENABLE, "Initialisating decoder\n"));
            err = initAudioDecoder(pSendContext);
			if (err == RM_OK)
            {
                RMDBGLOG((ENABLE, "PLAY: audio decoder\n"));
                if (pSendContext->dcc_info->pMultipleAudioSource)
                {
                    err = DCCPlayMultipleAudioSource(pSendContext->dcc_info->pMultipleAudioSource);
                    if (RMFAILED(err))
                    {
                        RMDBGLOG((ENABLE, "Cannot play video decoder %d\n", err));
                        return err;
                    }
                    return RM_OK;
                }
            }
            else
            {
                RMDBGLOG((ENABLE, "error during audio init, disabling audio for this channel\n"));
				return RM_OK; 
			}
		}
	}


	return err;

}

// used for prebuffering
static RMstatus Pause(struct asf_context * pSendContext, RMuint32 devices)
{

	RMstatus err = RM_OK;
	
	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "PAUSE: stc\n"));
		DCCSTCStop(pSendContext->dcc_info->pStcSource);
	}

	if (devices & RM_DEVICES_VIDEO) {
		if ((pSendContext->SendVideoData) && (pSendContext->VideoStreamFound)) {
			RMDBGLOG((ENABLE, "PAUSE: video decoder\n"));
			err = DCCPauseVideoSource(pSendContext->dcc_info->pVideoSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot pause video decoder %d\n", err));
				return err;
			}
		}
	}

	if (devices & RM_DEVICES_AUDIO) {
		if ((pSendContext->audio_parameters[pSendContext->audio_stream_index].enabled) && (pSendContext->AudioStreamFound)) {
			RMDBGLOG((ENABLE, "PAUSE: audio decoder\n"));
			if (pSendContext->dcc_info->pMultipleAudioSource) {
				err = DCCPauseMultipleAudioSource(pSendContext->dcc_info->pMultipleAudioSource);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Cannot pause video decoder %d\n", err));
					return err;
				}
			}
		}
	}


	return err;

}


static RMstatus asf_seek(struct asf_context * pSendContext, RMuint64 time)
{
	RMuint32 seekTo;
	RMint64 position;

	seekTo = (RMuint32) time;
		
	RMDBGLOG((ENABLE, "Should seek to %ld s\n", seekTo));

	// must be in milliseconds
	seekTo *= 1000;

#ifndef EM86XX_DEBUG_AUDIO
	Stop(pSendContext, RM_DEVICES_STC | RM_DEVICES_AUDIO | RM_DEVICES_VIDEO);
#endif

	position = RMASFVDemuxSeek(pSendContext->vASFDemux, &seekTo);
	if (position == 0) {
		RMDBGLOG((ENABLE, "seek failed, restarting\n"));
		RMSeekFile(pSendContext->f_bitstream, pSendContext->asf_Header_Object_Size+50, RM_FILE_SEEK_START);
		/* presets the demux to start parsing first packet */
		RMASFVDemuxResetState(pSendContext->vASFDemux);
		seekTo = 0;
	}
	else
		RMSeekFile(pSendContext->f_bitstream, position, RM_FILE_SEEK_START);

	RMGetCurrentPositionOfFile (pSendContext->f_bitstream, &position);
	RMDBGLOG((ENABLE, "Seeked to %ld s, pos %llu\n", seekTo/1000, position));
	       
	pSendContext->FirstSystemTimeStamp = TRUE;

	if ((pSendContext->isWMAPRO) && (pSendContext->audio_parameters[pSendContext->audio_stream_index].enabled)) {
		if (pSendContext->vDecoder != NULL) {
			RMDBGLOG((ENABLE, "close wmapro decoder\n"));
			RMWMAProVDecoderClose(pSendContext->vDecoder);
			
			RMDBGLOG((ENABLE, "open wmapro decoder\n"));
			RMWMAProVDecoderOpen(pSendContext->vDecoder);

		}
		else
			RMDBGLOG((ENABLE, "no wmapro decoder created!\n"));
	}
	
	pSendContext->IFrameFSMState = RMasfIFrameFSM_Disabled;
	pSendContext->SeekAudio = TRUE;
	pSendContext->SeekVideo = TRUE;

	pSendContext->audioSamplesDropped = FALSE;

#ifndef EM86XX_DEBUG_AUDIO
	/* the stc will be put into "play" mode with the first pts */
	Play(pSendContext, RM_DEVICES_AUDIO | RM_DEVICES_VIDEO, DCCVideoPlayFwd);
#endif

#if 0
	{
		RMstatus err;
		/* restart recording data after the seek */
		RMDBGLOG((ENABLE, "restarting save data\n"));
		err = close_save_files(pSendContext->play_opt);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot close files used to save data %d\n", err);
			return RM_ERROR;
		}
		err = open_save_files(pSendContext->play_opt);
		if (RMFAILED(err)) {
			fprintf(stderr, "cannot open files to save data %d\n", err);
			return RM_ERROR;
		}
	}
#endif

	return RM_OK;

}


static RMstatus asf_InitIFrameTrickMode(struct asf_context* pSendContext)
{
	RMstatus err = RM_OK;
	RMint64 position = 0;
	RMuint32 size, packet;
	RMint32 N;
	RMuint32 M;
	enum RM_PSM_State PlaybackStatus = RM_PSM_GetState(pSendContext->PSMcontext, &(pSendContext->dcc_info));
	
	DCCSTCGetSpeed(pSendContext->dcc_info->pStcSource, &N, &M);

	RMDBGLOG((ENABLE, "Init IFrame trickmode, speed is %ld/%lu\n", N, M));

	if (PlaybackStatus == RM_PSM_IForward) 
		pSendContext->IFrameDirection = 1;
	else if (PlaybackStatus == RM_PSM_IRewind) 
		pSendContext->IFrameDirection = -1;
	else {
		RMDBGLOG((ENABLE, "cant determine iframe trickmode playback direction, defaulting to forward!"));
		pSendContext->IFrameDirection = 1;
	}


	{
		RMuint64 currentPTS;

		RUAGetProperty(pSendContext->pRUA, pSendContext->dcc_info->SurfaceID, RMGenericPropertyID_CurrentDisplayPTS, &(pSendContext->CurrentDisplayPTS), sizeof(RMuint64));

		if (pSendContext->video_vop_tir == 90000)
			pSendContext->CurrentDisplayPTS *= 2;
		
		RMDBGLOG((ENABLE, "updated display pts %llu s\n", pSendContext->CurrentDisplayPTS));

		currentPTS = round_int_div(pSendContext->CurrentDisplayPTS, (RMuint32) pSendContext->video_vop_tir);

		RMDBGLOG((ENABLE, "has to find position of time %llu s\n", currentPTS));

		asf_seek(pSendContext, currentPTS);

		RMGetCurrentPositionOfFile(pSendContext->f_bitstream, &position);

		RMDBGLOG((ENABLE, "setting start position to %llu\n", position));

		pSendContext->CurrentDisplayPTS = 0;
	}

	RMDBGLOG((ENABLE, "playing trickmode...direction %s\n", (pSendContext->IFrameDirection >= 0) ? "forward":"backward"));

	err = RMASFVDemuxSetTrickModeDirection(pSendContext->vASFDemux, pSendContext->IFrameDirection);
	if (err != RM_OK)
		return RM_ERROR;

	err = RMASFVDemuxInitTrickMode(pSendContext->vASFDemux, (RMuint64 *)&position);
	if (err != RM_OK)
		return RM_ERROR;

	
	/* skip the IFrame we just seeked to */
	err = RMASFVDemuxGetNextIFrame(pSendContext->vASFDemux, (RMuint64 *)&position, &size, &packet);
	if (err != RM_OK)
		return RM_ERROR;
	
	RMSeekFile(pSendContext->f_bitstream, position, RM_FILE_SEEK_START);

	RMDBGLOG((ENABLE, "skipping one iframe at pos %llu, size %lu, packet %lu\n", position, size, packet));

	RMDBGLOG((ENABLE, "flush video...\n"));

	Stop(pSendContext, RM_DEVICES_VIDEO);

	pSendContext->IFrameSize = 0;

	pSendContext->IFrameFSMState = RMasfIFrameFSM_Init;
	pSendContext->SeekAudio = FALSE;
	pSendContext->SeekVideo = FALSE;

	Play(pSendContext, RM_DEVICES_VIDEO | RM_DEVICES_STC, DCCVideoPlayIFrame);

#if 0
	{
		RMstatus err;
		/* restart recording data after the seek */
		RMDBGLOG((ENABLE, "restarting save data\n"));
		err = close_save_files(pSendContext->play_opt);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot close files used to save data %d\n", err);
			return RM_ERROR;
		}
		err = open_save_files(pSendContext->play_opt);
		if (RMFAILED(err)) {
			fprintf(stderr, "cannot open files to save data %d\n", err);
			return RM_ERROR;
		}
	}
#endif
	
	return RM_OK;

}

static RMstatus asf_ResumeFromIFrameTrickMode(struct asf_context * pSendContext)
{
	RMstatus err = RM_OK;
	RMuint64 time;
	RMuint64 roundUpTime;

	err = RUAGetProperty(pSendContext->pRUA, pSendContext->dcc_info->SurfaceID, RMGenericPropertyID_CurrentDisplayPTS, &time, sizeof(time));

	if (pSendContext->video_vop_tir == 90000)
		time *= 2;

	RMDBGLOG((ENABLE, "resume from trickmode at %llu in %ld units\n", time, pSendContext->video_vop_tir));
	pSendContext->CurrentDisplayPTS = (time * 1000) / pSendContext->video_vop_tir;

	roundUpTime = time / pSendContext->video_vop_tir;
	if ((time - (roundUpTime * pSendContext->video_vop_tir)) > 0)
		roundUpTime++;

	RMDBGLOG((ENABLE, "seeking to %llu ms => adj time is %llu\n", time, roundUpTime));

	asf_seek(pSendContext, roundUpTime);


	DCCSTCSetSpeed(pSendContext->dcc_info->pStcSource, pSendContext->play_opt->speed_N, pSendContext->play_opt->speed_M);
	//Stop(pSendContext, RM_DEVICES_STC);
	Pause(pSendContext, RM_DEVICES_STC | RM_DEVICES_VIDEO | RM_DEVICES_AUDIO);
	RM_PSM_SetState(pSendContext->PSMcontext, &(pSendContext->dcc_info), RM_PSM_Prebuffering);

	return RM_OK;

}


static RMstatus asf_FastAudioRecovery(struct asf_context * pSendContext)
{
	RMstatus err = RM_OK;
	RMuint64 time;
	RMuint64 roundUpTime;

	if ((!pSendContext->audioSamplesDropped) && (pSendContext->sendAudioTrickmode)) {
		RMDBGLOG((ENABLE, "FastAudioRecovery: -sat was also enabled and there were no audio samples dropped during trickmodes, ignore\n"));
		return RM_OK;
	}
	else if (pSendContext->sendAudioTrickmode)
		RMDBGLOG((ENABLE, "FastAudioRecovery: -sat was also enabled but we dropped audio samples\n"));

	err = RUAGetProperty(pSendContext->pRUA, pSendContext->dcc_info->SurfaceID, RMGenericPropertyID_CurrentDisplayPTS, &time, sizeof(time));

	if (pSendContext->video_vop_tir == 90000)
		time *= 2;

	RMDBGLOG((ENABLE, "FastAudioRecovery: resume from trickmode at %llu in %ld units\n", time, pSendContext->video_vop_tir));

	roundUpTime = time / pSendContext->video_vop_tir;
	if ((time - (roundUpTime * pSendContext->video_vop_tir)) > 0)
		roundUpTime++;

	RMDBGLOG((ENABLE, "seeking to %llu ms => adj time is %llu\n", time, roundUpTime));

	asf_seek(pSendContext, roundUpTime);

	DCCSTCSetSpeed(pSendContext->dcc_info->pStcSource, pSendContext->play_opt->speed_N, pSendContext->play_opt->speed_M);
	//Stop(pSendContext, RM_DEVICES_STC);
	Pause(pSendContext, RM_DEVICES_STC | RM_DEVICES_VIDEO | RM_DEVICES_AUDIO);
	RM_PSM_SetState(pSendContext->PSMcontext, &(pSendContext->dcc_info), RM_PSM_Prebuffering);

	return RM_OK;

}


static RMstatus SyncTimerWithDecoderPTS(struct asf_context *pSendContext)
{
	RMuint64 videoPTS;
	RMuint64 CurrentSTC;
	RMstatus err = RM_OK;

	if (pSendContext->VideoStreamFound) {
		DCCSTCGetTime(pSendContext->dcc_info->pStcSource, &CurrentSTC, pSendContext->video_vop_tir);
		RMDBGLOG((ENABLE, "resync timer, video stc is %llu\n", CurrentSTC));
		
		err = RUAGetProperty(pSendContext->pRUA, pSendContext->dcc_info->SurfaceID, RMGenericPropertyID_CurrentDisplayPTS, &videoPTS, sizeof(videoPTS));
		if (err != RM_OK) {
			RMDBGLOG((ENABLE, "error %d while getting CurrentDisplayPTS\n", err));
			return err;
		}

		if (pSendContext->video_vop_tir == 90000)
			videoPTS *= 2;

		RMDBGLOG((ENABLE, ">> resync timer (%llu) with videoDecoder current PTS (%llu)\n", CurrentSTC, videoPTS));
		DCCSTCSetTime(pSendContext->dcc_info->pStcSource, videoPTS, pSendContext->video_vop_tir);
		return err;
	}
	else if (pSendContext->AudioStreamFound) {
		//get the time in 1000th units because presentation time from ASF is always in 1/1000
		DCCSTCGetTime(pSendContext->dcc_info->pStcSource, &CurrentSTC, 1000);
		RMDBGLOG((ENABLE, "audio stc is %llu at 1/1000\n", CurrentSTC));
		pSendContext->lastSTC = CurrentSTC;
	}

	return RM_OK;

}


static RMstatus restartAudioDecoder(struct asf_context * pSendContext)
{
	RMuint64 stc;

	if (!pSendContext->audio_parameters[pSendContext->audio_stream_index].enabled)
		return RM_ERROR;

	RMDBGLOG((ENABLE, "restart audio decoder\n"));

#ifndef	EM86XX_DEBUG_AUDIO
	Stop(pSendContext, RM_DEVICES_AUDIO);
#endif

	if (pSendContext->isWMAPRO) {
		if (pSendContext->vDecoder != NULL) {
			RMDBGLOG((ENABLE, "close wmapro decoder\n"));
			RMWMAProVDecoderClose(pSendContext->vDecoder);
			
			RMDBGLOG((ENABLE, "open wmapro decoder\n"));
			RMWMAProVDecoderOpen(pSendContext->vDecoder);
		}
		else
			RMDBGLOG((ENABLE, "no wmapro decoder created!\n"));
	}

	pSendContext->audio_decoder_initialized = FALSE;
	
 	//get the time in 1000th units because presentation time from ASF is always in 1/1000
 	DCCSTCGetTime(pSendContext->dcc_info->pStcSource, &stc, 1000);

	RMDBGLOG((ENABLE, ">> stc is %llu\n", stc));
	if ((!pSendContext->VideoStreamFound) && (pSendContext->AudioStreamFound)) {
		RMuint64 time;

		pSendContext->accurateAudioSeekTo = stc;

		time = stc / 1000;
		time -= 2;
		RMDBGLOG((ENABLE, "seeking to %llu s\n", time));

		if ((RMint64)time >= 0)
			asf_seek(pSendContext, time);
		else
			asf_seek(pSendContext, 0);
		
		DCCSTCSetSpeed(pSendContext->dcc_info->pStcSource, pSendContext->play_opt->speed_N, pSendContext->play_opt->speed_M);
		RM_PSM_SetState(pSendContext->PSMcontext, &(pSendContext->dcc_info), RM_PSM_Playing);

		RMDBGLOG((ENABLE, "accurate audio seek to %llu\n", stc));
		Stop(pSendContext, RM_DEVICES_STC);
	}

#ifndef	EM86XX_DEBUG_AUDIO
	Play(pSendContext, RM_DEVICES_AUDIO, 0);
#endif

	return RM_OK;

}



static RMstatus readBitstream(struct asf_context *pSendContext, RMuint8 *buffer, RMuint32 *bytesRead)
{
	RMstatus status;
	RMuint64 position;
	RMuint32 size, packet;
	RMuint32 count;
	RMuint32 buffersize;
	RMuint32 alignedPacket;
	enum RM_PSM_State PlaybackStatus = RM_PSM_GetState(pSendContext->PSMcontext, &(pSendContext->dcc_info));

	buffersize = (1 << pSendContext->play_opt->dmapool_log2size);

	if (pSendContext->drmError) {
		RMDBGLOG((ENABLE, "there was a decryption error, abort playback\n"));
		return RM_DRM_DECRYPTION_FAILED;
	}

	/* The Microsoft Janus DRM requires ASF data packets to be contiguous for decryption.
	 * If the file is Janus encrypted, an integer multiple of ASF data packets will be
	 * read into the RUA buffer (i.e. the read size is truncated).  If the file is not
	 * Janus encrypted, the entire RUA buffer will be filled. */
	if (pSendContext && pSendContext->asf_packetSize && pSendContext->isContentEncrypted) {
		/* In case we play the file completely sequentially, the
		 * asf_packetSize is not known at the first read, since we
		 * haven't parsed the stream yet, so use default size if
		 * asf_packetSize == 0 */
		alignedPacket = (buffersize/pSendContext->asf_packetSize)*pSendContext->asf_packetSize;
		buffersize = alignedPacket;
			
		if (((RMuint32) (1 << pSendContext->play_opt->dmapool_log2size)) < pSendContext->asf_packetSize) {
				RMDBGLOG((ENABLE, "** Read Buffers too small\n"));
				return RM_ERROR;
		}
	}

	if ((PlaybackStatus != RM_PSM_Playing) && (PlaybackStatus != RM_PSM_Prebuffering)) {
		if (pSendContext->isIFrameMode) {

			if (pSendContext->IFrameSize == 0) {
				RMuint32 sizeToRead;

				status = RMASFVDemuxGetNextIFrame(pSendContext->vASFDemux, &position, &size, &packet);
				RMDBGLOG((TRICKDBG, "got iframe at pos(%llu), size(%lu), packet(%lu)\n", position, size, packet));
				if (status != RM_OK) {
					RMDBGLOG((ENABLE, "error getting next iframe\n"));
					return status;
				}
				
				RMSeekFile(pSendContext->f_bitstream, position, RM_FILE_SEEK_START);

				pSendContext->IFrameFSMState = RMasfIFrameFSM_Init;
				pSendContext->IFrameSize = size;

				sizeToRead = RMmin(buffersize, size);

				RMDBGLOG((READ_DBG, "read %lu bytes\n", sizeToRead));
				status = RMReadFile(pSendContext->f_bitstream, buffer, sizeToRead, &count);
				
				pSendContext->IFrameSize -= (RMint32)count;
				if (pSendContext->IFrameSize <= 0)
					pSendContext->IFrameSize = 0;
				RMDBGLOG((TRICKDBG, "filled buffer with %lu bytes, should read %lu, left %lu\n", count, sizeToRead, pSendContext->IFrameSize));
			}
			else {
				RMuint32 sizeToRead = RMmin(buffersize, (RMuint32)pSendContext->IFrameSize);

				RMDBGLOG((READ_DBG, "read %lu bytes\n", sizeToRead));				
				status = RMReadFile(pSendContext->f_bitstream, buffer, sizeToRead, &count);

				pSendContext->IFrameSize -= (RMint32)count;
				if (pSendContext->IFrameSize <= 0)
					pSendContext->IFrameSize = 0;
				RMDBGLOG((TRICKDBG, "filled buffer with %lu bytes, should read %lu, left %lu\n", count, sizeToRead, pSendContext->IFrameSize));
			}
				
		}
		else if ((!pSendContext->VideoStreamFound) && (pSendContext->AudioStreamFound))
			return RM_SKIP_DATA;
		else {
			RMDBGLOG((READ_DBG, "read %lu bytes\n", buffersize));

			status = RMReadFile(pSendContext->f_bitstream, buffer, buffersize, &count);
			if (status == RM_OK && pSendContext && pSendContext->asf_packetSize && pSendContext->isContentEncrypted && buffersize != count) {
				RMDBGLOG((ENABLE, "ERROR: buffersize=%lu, count=%lu, status=%d\n", buffersize, count, (int)status));
				count = (count/pSendContext->asf_packetSize)*pSendContext->asf_packetSize;
				RMDBGLOG((ENABLE,"SOLVE: count=%lu, asf_packet_size=%lu\n", count, pSendContext->asf_packetSize));
				status = RM_ERRORENDOFFILE;
			}
		}
	} 
	else {
		RMDBGLOG((READ_DBG, "read %lu bytes\n", buffersize));

		status = RMReadFile(pSendContext->f_bitstream, buffer, buffersize, &count);

		if (status == RM_OK && pSendContext && pSendContext->asf_packetSize && pSendContext->isContentEncrypted && buffersize != count) {
			RMDBGLOG((ENABLE, "ERROR: buffersize=%lu, count=%lu, status=%d\n", buffersize, count, (int)status));
			count = (count/pSendContext->asf_packetSize)*pSendContext->asf_packetSize;
			RMDBGLOG((ENABLE,"SOLVE: count=%lu, asf_packet_size=%lu\n", count, pSendContext->asf_packetSize));
			//			status = RM_ERRORENDOFFILE;
		}
	}

	*bytesRead = count;

	RMDBGLOG((DISABLE, "buf: %02x %02x %02x %02x %02x %02x %02x %02x \n", 
		  buffer[0],
		  buffer[1],
		  buffer[2],
		  buffer[3],
		  buffer[4],
		  buffer[5],
		  buffer[6],
		  buffer[7]));

	return status;
	
}

/**
 * Setup the audio decoder, according to the given context
 *
 * @param pSendContext - context to use for the setup
 * @return RM_OK on sucess
 */
static RMstatus setup_audio_decoder(struct asf_context *pSendContext)
{
	struct dcc_context *dcc_info = pSendContext->dcc_info;
	struct DCCAudioProfile audio_profiles[MAX_AUDIO_DECODER_INSTANCES];
	//struct RUABufferPool *pDMAuncompressed;
	RMstatus err;
	RMuint32 i;

	if (!pSendContext->audio_parameters[pSendContext->audio_stream_index].enabled)
		return RM_ERROR;

	RMDBGLOG((ENABLE, "*** setup_audio_decoder ***\n"));
	for (i = 0 ; i < pSendContext->audioInstances; i++) {
		audio_profiles[i].BitstreamFIFOSize = pSendContext->audio_opt[i].fifo_size;
		audio_profiles[i].XferFIFOCount = pSendContext->audio_opt[i].xfer_count;
		audio_profiles[i].DemuxProgramID = pSendContext->audio_opt[i].AudioEngineID * 2;
		audio_profiles[i].AudioEngineID = pSendContext->audio_opt[i].AudioEngineID;
		audio_profiles[i].AudioDecoderID = pSendContext->audio_opt[i].AudioDecoderID;
		audio_profiles[i].STCID = pSendContext->play_opt->STCid;
	}
	
	err = DCCOpenMultipleAudioDecoderSource(dcc_info->pDCC, audio_profiles, pSendContext->audioInstances, &(dcc_info->pMultipleAudioSource));
	
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot open multiple audio decoder %d\n", err));
		return err;
	}

	
	

	return RM_OK;
}



/**
 * Setup the video decoder, according to the given context
 *
 * @param pSendContext - context to use for the setup
 * @return RM_OK on sucess
 */
static RMstatus setup_video_decoder(struct asf_context *pSendContext)
{
	struct DCCVideoSource *pVideoSource = NULL;
	RMuint32 surfaceID;
	RMstatus err;
	
	if (pSendContext == NULL)
		return RM_ERROR;


	{
		struct DCCXVideoProfile video_profile;
		enum EMhwlibVideoCodec vcodec;

		RMDBGLOG((ENABLE, "*** setup_video_decoder ***\n"));
		video_profile.ProtectedFlags = 0;
		video_profile.BitstreamFIFOSize = pSendContext->video_opt->fifo_size;
		video_profile.XferFIFOCount = pSendContext->video_opt->xfer_count;
		RMDBGLOG((ENABLE, "bitstream fifo %ld, count %ld\n", pSendContext->video_opt->fifo_size, pSendContext->video_opt->xfer_count));
		video_profile.MpegEngineID = pSendContext->video_opt->MpegEngineID;
		video_profile.VideoDecoderID = pSendContext->video_opt->VideoDecoderID;
		video_profile.PtsFIFOCount = 180;
		video_profile.InbandFIFOCount = 16;
		video_profile.XtaskInbandFIFOCount = 0;
		video_profile.SPUBitstreamFIFOSize = 0;
		video_profile.SPUXferFIFOCount = 0;
		video_profile.STCID = pSendContext->play_opt->STCid;
	
		/* set codec based on command line options either "-pv" or "-vcodec" */
		if (pSendContext->video_opt->vcodec_max_width) {
			video_profile.Codec = pSendContext->video_opt->vcodec;
			video_profile.Profile = pSendContext->video_opt->vcodec_profile;
			video_profile.Level = pSendContext->video_opt->vcodec_level;
			video_profile.MaxWidth = pSendContext->video_opt->vcodec_max_width;
			video_profile.MaxHeight = pSendContext->video_opt->vcodec_max_height;
		}
		else {
			err = video_profile_to_codec(pSendContext->video_opt->Codec, 
						     &video_profile.Codec,
						     &video_profile.Profile, 
						     &video_profile.Level, 
						     &video_profile.ExtraPictureBufferCount,
						     &video_profile.MaxWidth, 
						     &video_profile.MaxHeight);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Unknown video decoder codec \n"));
				return err;
			}
		}
		/* set the extra pictures after the profile to codec conversion */
		video_profile.ExtraPictureBufferCount = pSendContext->video_opt->vcodec_extra_pictures;

		err = DCCXOpenVideoDecoderSource(pSendContext->dcc_info->pDCC, &video_profile, &pVideoSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot open video decoder %d\n", err));
			return err;
		}

		
		vcodec = video_profile.Codec;
		err = DCCXSetVideoDecoderSourceCodec(pVideoSource, vcodec);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set video decoder codec %d\n", err));
			return err;
		}
	}

	pSendContext->dcc_info->pVideoSource = pVideoSource;

#if 0	// test for uninit/init problem seen when we set 816P then DIVX3 codec
	err = DCCSetVideoDecoderSourceCodec(pVideoSource, VideoDecoder_Codec_DIVX3_SD);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set video decoder codec %d\n", err));
		goto exit_with_error;
	}
#endif

	RMDBGLOG((ENABLE, "get scaler module\n"));
	err = DCCGetScalerModuleID(pSendContext->dcc_info->pDCC, pSendContext->dcc_info->route , DCCSurface_Video, pSendContext->videoscaler_id, &surfaceID);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get surface to display video source %d\n", err));
		return RM_ERROR;
	}
	pSendContext->dcc_info->SurfaceID = surfaceID;

	RMDBGLOG((ENABLE, "set surface\n"));
	err = DCCSetSurfaceSource(pSendContext->dcc_info->pDCC, surfaceID, pVideoSource);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set the surface source %d\n", err));
		return err;
	}

	RMDBGLOG((ENABLE, "get video decoder info\n"));
	err = DCCGetVideoDecoderSourceInfo(pVideoSource, 
			&(pSendContext->dcc_info->video_decoder), 
			&(pSendContext->dcc_info->spu_decoder), 
			&(pSendContext->dcc_info->video_timer));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting video decoder source information %d\n", err));
		return err;
	}

#ifndef WITH_MONO
	pSendContext->dcc_info->disp_info = &pSendContext->disp_info;
	set_default_out_window(&(pSendContext->dcc_info->disp_info->out_window));
	set_default_out_window(&(pSendContext->dcc_info->disp_info->osd_window[0]));
	set_default_out_window(&(pSendContext->dcc_info->disp_info->osd_window[1]));
	pSendContext->dcc_info->disp_info->active_window = &(pSendContext->dcc_info->disp_info->out_window);
	pSendContext->dcc_info->disp_info->video_enable = TRUE;

	RMDBGLOG((ENABLE, "apply display options\n"));
	err = apply_display_options(pSendContext->dcc_info, pSendContext->disp_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set display opions %d\n", err));
		return err;
	}
#endif /*WITH_MONO*/

	// apply the fixed vop rate if required
	RMDBGLOG((ENABLE, "apply video decoder options\n"));
	err = apply_video_decoder_options(pSendContext->dcc_info, pSendContext->video_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error applying video_decoder_options %d\n", err));
		return err;
	}

#if 0
	{

		struct DisplayBlock_SurfaceAspectRatio_type param;
		
		param.type = EMhwlibAspectRatio_Display;
		param.ar.Y = pSendContext->wmv9_prop.Image_Height;
		param.ar.X = pSendContext->wmv9_prop.Image_Width;
		RMDBGLOG((ENABLE, "******************set aspect ratio\n"));
		if (pSendContext->pRUA) {
			err = RUASetProperty(pSendContext->pRUA, DisplayBlock, RMDisplayBlockPropertyID_SurfaceAspectRatio, &param, sizeof(param), 0);
			if (err != RM_OK) {
				RMDBGLOG((ENABLE, "errrrrrrrrrrrrrrrrrrrrroooooooooooor!\n"));
			}
		}
	}
#endif

	return RM_OK;
}
	

#ifdef WITH_MONO


RMstatus asf_get_video_duration(void *context, RMuint32 *time_sec)
{
	struct asf_context *pSendContext = (struct asf_context *)context;
	if(pSendContext == NULL)
		return RM_ERROR;
	if (!pSendContext->filePropSET)
		return RM_ERROR;
	else {
		if (pSendContext->Duration >= 1000)
			*time_sec = pSendContext->Duration / 1000;
		else
			*time_sec = 0;
		if (*time_sec == 0)
			return RM_ERROR;

		RMDBGLOG((ENABLE, "asf_get_video_duration: %lu s\n", *time_sec));
		return RM_OK;
	}
}

RMstatus asf_get_playback_position(void *context, RMuint32 *time_sec)
{
	struct asf_context *pSendContext = (struct asf_context *)context;
	RMstatus err = RM_OK;

	if(pSendContext == NULL)
		return RM_ERROR;

	if (pSendContext->VideoStreamFound) {
		RMuint64 videoPTS;

		err = RUAGetProperty(pSendContext->pRUA, pSendContext->dcc_info->SurfaceID, RMGenericPropertyID_CurrentDisplayPTS, &videoPTS, sizeof(videoPTS));
		if (err != RM_OK) {
			RMDBGLOG((ENABLE, "error getting current display pts property, error %lu\n", (RMuint32)err));
			return RM_ERROR;
		}

		if (pSendContext->video_vop_tir == 90000)
			videoPTS *= 2;

		*time_sec = (RMuint32) round_int_div(videoPTS, (RMuint32) pSendContext->video_vop_tir);
		if (*time_sec == 0)
			return RM_ERROR;
		
		RMDBGLOG((ENABLE, "asf_get_playback_position: %lu s (video)\n", *time_sec));
		return RM_OK;
	}
	else if (pSendContext->AudioStreamFound) {
		RMuint32 audioPTS;
		struct DCCAudioSourceHandle audioHandle;
		
		if (pSendContext->dcc_info->pMultipleAudioSource) {
			err = DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(pSendContext->dcc_info->pMultipleAudioSource, 0, &audioHandle);
			if (err != RM_OK)
				return RM_ERROR;
			
			err = RUAGetProperty(pSendContext->pRUA, audioHandle.moduleID, RMAudioDecoderPropertyID_CurrentPTS, &audioPTS, sizeof(audioPTS));
			if (err != RM_OK) {
				RMDBGLOG((ENABLE, "error getting current pts property for audio, error %lu\n", (RMuint32)err));
				return RM_ERROR;
			}
			*time_sec = (RMuint32) round_int_div((RMuint64)audioPTS, (RMuint32) pSendContext->audio_vop_tir);
			if (*time_sec == 0)
				return RM_ERROR;
			
			RMDBGLOG((ENABLE, "asf_get_playback_position: %lu s (audio only)\n", *time_sec));
			return RM_OK;
		}
	}
	
	
	return RM_OK;
}


RMstatus asf_get_audio_languageId(void *context, RMasfdemuxLanguageID * languageID)
{
	struct asf_context *pSendContext = (struct asf_context *)context;
	if(pSendContext == NULL)
		return RM_ERROR;


	if (pSendContext->langPropSET) {
		if ((languageID) &&  (languageID->languageIDIndex < MAX_NUMBER_OF_AUDIO_STREAMS)) {
			RMDBGLOG((ENABLE, "asf_get_audio_languageId: index %lu\n", languageID->languageIDIndex));
			languageID->languageIDCount = pSendContext->lang[languageID->languageIDIndex].languageIDCount;
			languageID->languageIDLength = pSendContext->lang[languageID->languageIDIndex].languageIDLength;
			languageID->languageID = pSendContext->lang[languageID->languageIDIndex].languageID;
			return RM_OK;
		}
	}

	return RM_ERROR;
}

RMstatus asf_get_current_audio_stream(void *context, RMuint32 *stream)
{
	struct asf_context *pSendContext = (struct asf_context *)context;
	if(pSendContext == NULL)
		return RM_ERROR;

	*stream = (RMuint32)pSendContext->audio_stream_index;
	RMDBGLOG((ENABLE, "asf_get_current_audio_stream: %lu\n", *stream));

	return RM_OK;
}


RMstatus asf_get_audio_stream_count(void *context, RMuint32 *count)
{
	struct asf_context *pSendContext = (struct asf_context *)context;
	*count = (RMuint32)pSendContext->audioStreams;
	RMDBGLOG((ENABLE, "asf_get_audio_stream_count: %lu\n", *count));
	return RM_OK;
}

RMstatus asf_get_real_seek_position(void *context, RMuint32 time_sec, RMuint32 *true_time_sec)
{
	struct asf_context *pSendContext = (struct asf_context *)context;
	RMuint64 position;
	RMuint32 time = time_sec * 1000;

	if(pSendContext == NULL)
		return RM_ERROR;


	position = RMASFVDemuxSeekToTime(pSendContext->vASFDemux, &time);
	if (position == 0) {
		RMDBGLOG((ENABLE, "asf_get_real_seek_position: error seeking\n"));
		return RM_ERROR;
	}
	*true_time_sec = time / 1000;
	RMDBGLOG((ENABLE, "asf_get_real_seek_position: seek to %lu s will seek to %lu s\n", time_sec, *true_time_sec));
	return RM_OK;
}

#endif //WITH_MONO


#ifdef WITH_MONO
int main_asf(struct mono_info *mono)
{
#else
int main(int argc, char *argv[])
{
	/*for MONO compatibility, always access these variables through the global pointers*/
	struct playback_cmdline playback_options; /*access through play_opt*/
	struct display_cmdline  display_options;/*access through disp_opt*/
	struct video_cmdline video_options;
	struct audio_cmdline audio_options[MAX_AUDIO_DECODER_INSTANCES]; /*access through audio_opt*/
	struct dh_context dh_info = {0,};

#endif //WITH_MONO

	struct RUABufferPool *pDMA = NULL;
	struct asf_context SendContext = {0,};
	RMstatus err = RM_OK;
	RMint32 rc = 0;
	RMint32 error = 0;
	struct dcc_context dcc_info = {0,};
	struct stream_options_s stream_options;
	RMuint32 NTimes = 0;
	struct RMfifo wmapro_fifo;
	RMuint8  *wmapro_fifo_buffer=NULL;
	RMuint8  *wmapro_fifo_buffer_original=NULL;
	RMuint32 i;

	struct RM_PSM_Context PSMContext;


	/* #### Begin DTCP code #### */
	struct dtcp_cookie *dtcpCookieHandle = NULL;
         /* #### End DTCP code #### */

	SendContext.dcc_info = &dcc_info;
	dcc_info.disp_info = NULL;

	init_private_options(&SendContext.priv_opt);

#ifdef WITH_MONO
	/*make the mono arguments global*/
	SendContext.video_opt = mono->video_opt;
	SendContext.disp_opt =  mono->disp_opt;
	SendContext.audio_opt = mono->audio_opt;
	SendContext.play_opt = mono->play_opt;
	
	SendContext.audioInstances = SendContext.audio_opt[0].audioInstances;
	
	dcc_info.pRUA = mono->pRUA;
	dcc_info.pDCC = mono->pDCC;
	dcc_info.route = DCCRoute_Main;

	mono->context = (void*) &SendContext;
	SendContext.videoscaler_id = mono->video_scaler;

    // To identify WMAPRO stream
    if(SendContext.audio_opt[0].Codec == AudioDecoder_Codec_WMAPRO) {
        if(SendContext.audio_opt[0].Spdif != OutputSpdif_NoDecodeCompressed && SendContext.audio_opt[0].Spdif != OutputSpdif_Compressed)
            SendContext.isWMAPRO = TRUE;
    }

#else

	SendContext.video_opt = &video_options;
	SendContext.audio_opt = audio_options;
	SendContext.play_opt = &playback_options;
	SendContext.disp_opt = &display_options;	

	init_display_options(SendContext.disp_opt);
	init_playback_options(SendContext.play_opt);
	init_video_options(SendContext.video_opt);

	init_audio_options2(SendContext.audio_opt, MAX_AUDIO_DECODER_INSTANCES);

	SendContext.disp_opt->dh_info = &dh_info;
 	for (i = 0; i < MAX_AUDIO_DECODER_INSTANCES; i++)
		SendContext.audio_opt[i].dh_info = &dh_info;

	parse_cmdline(&SendContext, argc, argv);
	SendContext.audioInstances++;
	
	dcc_info.route = SendContext.disp_opt->route;
	dcc_info.dh_info = &dh_info;

	SendContext.videoscaler_id = SendContext.disp_opt->video_scaler;

    // To identify WMAPRO stream
    if(SendContext.audio_opt[0].Codec == AudioDecoder_Codec_WMAPRO) {
        if(SendContext.audio_opt[0].Spdif != OutputSpdif_NoDecodeCompressed && SendContext.audio_opt[0].Spdif != OutputSpdif_Compressed)
            SendContext.isWMAPRO = TRUE;
    }

	RMDBGLOG((ENABLE, "opening RUA\n"));
	err = RUACreateInstance(&dcc_info.pRUA, SendContext.play_opt->chip_num);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error creating RUA instance! %d\n", err));
		goto exit_with_error;
	}

	RMDBGLOG((ENABLE, "opening DCC\n"));
	err = DCCOpen(dcc_info.pRUA, &dcc_info.pDCC);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error Opening DCC! %d\n", err));
		goto exit_with_error;
	}

	if (!SendContext.play_opt->noucode) {
		RMDBGLOG((ENABLE, "init microcode\n"));
		err = DCCInitMicroCodeEx(dcc_info.pDCC, SendContext.disp_opt->init_mode);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot initialize microcode %d\n", err));
			goto exit_with_error;
		}
	}
	else
		RMDBGLOG((ENABLE, "microcode not loaded\n"));


	display_key_usage(KEYFLAGS);
#endif // WITH_MONO

	SendContext.pRUA = dcc_info.pRUA;
	SendContext.PSMcontext = &PSMContext;

 	for (i=0; i < sizeof(SendContext.stream_table)/sizeof(SendContext.stream_table[0]); i++ ) {
 		SendContext.stream_table[i].stream_number = -1;
 	}

  	PSMContext.keyflags = KEYFLAGS;
	PSMContext.keyflags = KEYFLAGS;
	PSMContext.currentActivePSMContext = 1;
	PSMContext.validPSMContexts = 1;

	// allows sending audio while in trickmodes
	SendContext.sendAudioTrickmode = SendContext.play_opt->send_audio_trickmode;
	

	if (SendContext.audio_opt[0].Codec == AudioDecoder_Codec_WMAPRO) {
		RMDBGLOG((ENABLE, "cmdline options, codec = WMAPro, outputchannels %s (0x%lx)\n", 
			  SendContext.audio_opt[0].WmaParams.OutputChannels == Audio_Out_Ch_LCRLsRs ? "6":"2 (downmix if necessary)",
			  SendContext.audio_opt[0].WmaParams.OutputChannels));
	}
	else {
		RMDBGLOG((ENABLE, "cmdline options, codec = WMA, outputchannels %lu\n", SendContext.audio_opt[0].OutputChannels));
	}

	init_stream_options(&stream_options);
	
	SendContext.vDecoder = NULL;
	SendContext.vASFDemux = NULL;
	
	SendContext.video_stream_index = 0;
	SendContext.inband_aspect_ratio_stream_index = 0;
	SendContext.SendVideoPts = SendContext.play_opt->send_video_pts;
	SendContext.SendVideoData = SendContext.play_opt->send_video;


	SendContext.audio_stream_index = -1;
	SendContext.SendAudioPts = SendContext.play_opt->send_audio_pts;
    SendContext.SendAudioData = SendContext.play_opt->send_audio;

	SendContext.pRUA = dcc_info.pRUA;

#ifdef CHECK_BUFFER_PTS
	SendContext.max_avpts_diff = 0;
	SendContext.audio_pts = 0;
	SendContext.video_pts = 0;
#endif


	wmapro_fifo_buffer_original = (RMuint8 *)RMMalloc(ADDITIONAL_WMAPRO_FIFO_SIZE*sizeof(RMuint8));
	if(wmapro_fifo_buffer_original == NULL) {
		RMDBGLOG((ENABLE,"Can't allocate %ld bytes for wmapro_buffer\n",  ADDITIONAL_WMAPRO_FIFO_SIZE));
		goto exit_with_error;
	}	
#if (EM86XX_MODE == EM86XX_MODEID_STANDALONE) && (EM86XX_CHIP != EM86XX_CHIPID_TANGO2)
	wmapro_fifo_buffer = (RMuint8 *)((RMuint32)wmapro_fifo_buffer_original | 0x80000000);
#else
	wmapro_fifo_buffer = wmapro_fifo_buffer_original;
#endif

	SendContext.wmapro_fifo = RMfifo_open ((RMuint32) wmapro_fifo_buffer, ADDITIONAL_WMAPRO_FIFO_SIZE*sizeof(RMuint8), (RMuint32) &wmapro_fifo);
	


	
	/* #### Begin CARDEA code #### */
	// first we initialize cardea
	if ( init_cardea(SendContext.play_opt->filename) != 0 ) {
		RMDBGLOG((ENABLE, "Error setting CARDEA session parameter.\n"));
		SendContext.cardea_context = NULL;
	}
	else {
		// then we figure out which device we are actually talking to...
		SendContext.cardea_context = find_cardea_device(SendContext.play_opt->filename);
	}

	if (SendContext.cardea_context != NULL) {



		RMascii *session_header = NULL;

		RMDBGLOG((ENABLE, "CARDEA drm context 0x%08x\n", SendContext.cardea_context));
		/* #### Begin CARDEA code #### */
		session_header = get_ms_session_header(SendContext.play_opt->filename);
		SendContext.cardea_context = find_cardea_url(SendContext.play_opt->filename);
		if (session_header != NULL) {
			RMDBGLOG((ENABLE, "got CARDEA session header '%s'\n", session_header));
			
			if (RMFAILED(set_http_options(&stream_options, RM_HTTP_CUSTOM_HEADER, session_header)) || (SendContext.cardea_context == NULL)) {
				RMDBGLOG((ENABLE, "Error setting CARDEA session parameter.\n"));
				err = RM_ERROR;
				goto exit_with_error;
			}
		}
		/* #### End CARDEA code #### */



#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
		test_cci( (void*)SendContext.cardea_context );
#else
		{
			struct cardea_opl_s cardea_opl;
			/* OPL */
			err = get_cardea_opl(SendContext.cardea_context, &cardea_opl);
			if (RMFAILED(err)){
				// this is not a fatal error
				RMDBGLOG((ENABLE,"Cannot retrieve CARDEA output protection level.\n"));
			} else {
				fprintf(stderr,"Minimum Digital Uncompressed Video OPL : %lu\n", 
					cardea_opl.min_digital_uncompressed_video);
				fprintf(stderr,"Minimum Digital Uncompressed Audio OPL : %lu\n", 
					cardea_opl.min_digital_uncompressed_audio);
				fprintf(stderr,"Minimum Analog Video OPL : %lu\n", cardea_opl.min_analog_video);
			}
		}

#endif /* (EM86XX_CHIP==EM86XX_CHIPID_TANGO2) */
	}

	/* #### End CARDEA code #### */


	/* #### Begin DTCP code #### */
#ifdef WITH_MONO	
	if (mono->dtcpCookieHandle) {
		// If MONO is present, simply use MONO's DTCP cookie handle
		dtcpCookieHandle = mono->dtcpCookieHandle;
		stream_options = mono->stream_opts;
	}
#else
	// Parse the URL searching for DTCP parameters.
	// If found, initialize the DTCP subsystem.
	err = init_DTCP_session (&dtcpCookieHandle,
				 &stream_options,
				 dcc_info.pRUA,
				 SendContext.play_opt->filename,
				 FALSE);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot initialize or check for DTCP-IP session correctly !!!\n");
		goto cleanup;
	}
#endif // WITH_MONO
	/* #### End DTCP code #### */

	RMDBGLOG((ENABLE, "opening bitstream\n%s\n", SendContext.play_opt->filename));
	SendContext.f_bitstream = open_stream(SendContext.play_opt->filename, RM_FILE_OPEN_READ, &stream_options);
	if (SendContext.f_bitstream == NULL) {
		RMDBGLOG((ENABLE, "couldn't open stream\n", SendContext.play_opt->filename));
		err = RM_ERROROPENFILE;
		goto exit_with_error;
	}

	RMDBGLOG((ENABLE, "create demux\n"));
	RMCreateASFVDemux(&SendContext.vASFDemux);
	RMASFVDemuxInit(SendContext.vASFDemux, &SendContext);

	RMASFVDemuxSetCallbacks(SendContext.vASFDemux,
				print_GUID,
				print_File_Properties,
				print_Stream_Bitrate_Properties,
				print_Video_Stream_Properties,
				print_Audio_Stream_Properties,
				print_Bitrate_Mutual_Exclusion,
				(0) ? dummy_content_encryption_callback : NULL,
				(SendContext.bypass_drm) ? dummy_drm_init : NULL,
				payload_extension,
				NULL,
				languagelistcb,
				NULL,
				play_Payload,
				NULL,
				NULL,
				inband_AspectRatio);

	RMDBGLOG((ENABLE, "opening save files\n"));
	err = open_save_files(SendContext.play_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error %s: cannot open files to save data\n", RMstatusToString(err)));
		goto exit_with_error;
	}


	/* if HD control is enabled and mode is auto, setup parameters */
	if ((SendContext.play_opt->disk_ctrl_low_level) &&
	    (SendContext.play_opt->disk_ctrl_log2_block_size) &&
	    (SendContext.play_opt->disk_ctrl_max_mem)) {
		RMuint32 bufferSize = 0;
		RMuint32 bufferCount = 0;
		RMuint32 log2BlockSize = SendContext.play_opt->disk_ctrl_log2_block_size;
		RMuint32 maxBufferingMem = SendContext.play_opt->disk_ctrl_max_mem;
		enum MPEG_Profile temp;

		bufferSize = (1 << log2BlockSize);
		bufferCount = maxBufferingMem >> log2BlockSize;
	
		SendContext.play_opt->dmapool_count = bufferCount;
		SendContext.play_opt->dmapool_log2size = log2BlockSize;
	
		/* from #4005
		   
		videoOpt.fifo_size = 4*1024*1024; 
		videoOpt.xfer_count = (1<<playOpt.dmapool_log2size)/1024*playOpt.dmapool_count;
		audioOpt.fifo_size = 1*1024*1024; 
		audioOpt.xfer_count = (1<<playOpt.dmapool_log2size)/512*playOpt.dmapool_count;
		
		*/

		if (SendContext.play_opt->disk_ctrl_low_level >= bufferCount)
			SendContext.play_opt->disk_ctrl_low_level = bufferCount >> 1;
	
		SendContext.video_opt->fifo_size = 4 * (1024 * 1024);
		for (i=0 ; i < SendContext.audioInstances ; i++)
			SendContext.audio_opt[i].fifo_size = 2 * (1024 * 1024);

		fprintf(stderr, ">> low level %lu => %lu bytes bufferized (+ bitstreamFIFO)\n", 
			SendContext.play_opt->disk_ctrl_low_level,
			SendContext.play_opt->disk_ctrl_low_level * bufferSize);

		SendContext.video_opt->xfer_count = (bufferSize / 1024) * bufferCount;
		for (i=0 ; i < SendContext.audioInstances ; i++)
			SendContext.audio_opt[i].xfer_count = (bufferSize / 1024) * bufferCount;

		
		temp = SendContext.video_opt->MPEGProfile;
#ifdef WITH_MONO
		// we still dont know if it's HD or SD, check for WMV HD 
		SendContext.video_opt->MPEGProfile = Profile_WMV_HD;
#endif
		err = setup_disk_control_parameters(&dcc_info, SendContext.play_opt, &(SendContext.audio_opt[0]), SendContext.video_opt, NULL);
		SendContext.video_opt->MPEGProfile = temp;

		if (err != RM_OK) {
			fprintf(stderr, "Error %d trying to setup HD control params\n", err);
			goto exit_with_error;
		}

	}


	/* update fifo and xfer size */
	if (SendContext.video_opt->fifo_size == 0) 
		SendContext.video_opt->fifo_size = VIDEO_FIFO_SIZE;

	if (SendContext.video_opt->xfer_count == 0)
		SendContext.video_opt->xfer_count = VIDEO_XFER_FIFO_COUNT;

	for (i=0 ; i< SendContext.audioInstances ; i++) {
		if (SendContext.audio_opt[i].fifo_size == 0) 
			SendContext.audio_opt[i].fifo_size = AUDIO_FIFO_SIZE;

		if (SendContext.audio_opt[i].xfer_count == 0)
			SendContext.audio_opt[i].xfer_count = AUDIO_XFER_FIFO_COUNT;
	
		RMDBGLOG((ENABLE, "Audio %lu:\n\tBitstreamFIFOSize: %lu\n\tFIFOXFERCount: %lu\n", 
			  i,
			  SendContext.audio_opt[i].fifo_size, 
			  SendContext.audio_opt[i].xfer_count));
	}

	/* update dmapool size and count */
	if (SendContext.play_opt->dmapool_count == 0)
		SendContext.play_opt->dmapool_count = ASF_DMA_BUFFER_COUNT;

	if (SendContext.play_opt->dmapool_log2size == 0)
		SendContext.play_opt->dmapool_log2size = ASF_DMA_BUFFER_SIZE_LOG2;


    RMDBGLOG((ENABLE, "Video:\n\tBitstreamFIFOSize: %lu\n\tFIFOXFERCount: %lu\n", 
		  SendContext.video_opt->fifo_size , 
		  SendContext.video_opt->xfer_count));
	RMDBGLOG((ENABLE, "DMA Pool:\n\tSize: %ld\n\tBufferCount: %ld\n\tBufferSize: %ld\n", 
		  (SendContext.play_opt->dmapool_count << SendContext.play_opt->dmapool_log2size), 
		  SendContext.play_opt->dmapool_count, 
		  (1 << SendContext.play_opt->dmapool_log2size)));

	SendContext.dmabuffer_array = (void **) NULL;
	SendContext.dmabuffer_index = 0;

	switch (SendContext.play_opt->disk_ctrl_state) {
	case DISK_CONTROL_STATE_DISABLE:
		break;
	case DISK_CONTROL_STATE_SLEEPING:
	case DISK_CONTROL_STATE_RUNNING:
		SendContext.dmabuffer_array = (void **) RMMalloc(sizeof(void*) * SendContext.play_opt->dmapool_count);
		SendContext.dmabuffer_index = 0;
		if (SendContext.dmabuffer_array == NULL) {
			RMDBGLOG((ENABLE, "Cannot allocate dmapool array! Disable disk control\n"));
			SendContext.play_opt->disk_ctrl_state = DISK_CONTROL_STATE_DISABLE;
		}
		break;
	}

	RMDBGLOG((ENABLE, "apply playback options\n"));
	err = apply_playback_options(&dcc_info, SendContext.play_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set playback options %d\n", err));
		goto exit_with_error;
	}


	SendContext.video_vop_tir = 1000;
	SendContext.audio_vop_tir = 1000;
	SendContext.unsupported_video = FALSE;

	{
		// open first stc module
		struct DCCStcProfile stc_profile;

		RMDBGLOG((ENABLE, "using STC ID %lu\n", SendContext.play_opt->STCid));
		stc_profile.STCID = SendContext.play_opt->STCid;
		stc_profile.master = Master_STC;

		stc_profile.stc_timer_id = 3*stc_profile.STCID+0;
		stc_profile.stc_time_resolution = SendContext.video_vop_tir;
	
		stc_profile.video_timer_id = 3*stc_profile.STCID+1;
		stc_profile.video_time_resolution = SendContext.video_vop_tir;
		stc_profile.video_offset = 0;
	
		stc_profile.audio_timer_id = 3*stc_profile.STCID+2;
		stc_profile.audio_time_resolution = SendContext.audio_vop_tir;
		stc_profile.audio_offset = 0;
		
		SendContext.stc_offset_ms = -SendContext.play_opt->audio_delay_ms;
		
	
		RMDBGLOG((ENABLE, "opening STC\n"));
		err = DCCSTCOpen(dcc_info.pDCC, &stc_profile, &dcc_info.pStcSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot open stc module %d\n", err));
			goto exit_with_error;
		}
	}


	/* playback commands enabled */
	SendContext.dcc_info->RM_PSM_commands = RM_PSM_ENABLE_PLAY;
	SendContext.dcc_info->RM_PSM_commands |= RM_PSM_ENABLE_STOP;
	SendContext.dcc_info->RM_PSM_commands |= RM_PSM_ENABLE_PAUSE;
	SendContext.dcc_info->RM_PSM_commands |= RM_PSM_ENABLE_SPEED;
	SendContext.dcc_info->RM_PSM_commands |= RM_PSM_ENABLE_FASTER;
	SendContext.dcc_info->RM_PSM_commands |= RM_PSM_ENABLE_SLOWER;
	SendContext.dcc_info->RM_PSM_commands |= RM_PSM_ENABLE_SWITCHAUDIO;

	SendContext.dcc_info->RM_PSM_commands |= RM_PSM_ENABLE_NEXTPIC;


	if (SendContext.sendAudioTrickmode) {
		fprintf(stderr, ">> sendAudioTrickmode enabled, will mute audio during trickmodes\n");
		SendContext.dcc_info->RM_PSM_commands |= RM_PSM_USE_MUTE_DURING_TRICKMODES;
	}

	/* seek and iframe enabled by default */
	SendContext.dcc_info->RM_PSM_commands |= RM_PSM_ENABLE_IFWD;
	SendContext.dcc_info->RM_PSM_commands |= RM_PSM_ENABLE_IRWD;
	SendContext.dcc_info->RM_PSM_commands |= RM_PSM_ENABLE_SEEK;

	/* #### Begin CARDEA code #### No seeking if a cardea context exists */
	if (SendContext.cardea_context != NULL) {
		RMDBGLOG((ENABLE, "CARDEA context, forcing linear playback\n"));

		SendContext.linear_playback = TRUE;
	} 
	/* #### End CARDEA code #### */

	// force linear playback
	//SendContext.linear_playback = TRUE;	

	if (SendContext.linear_playback) {
		RMDBGLOG((ENABLE, ">> linear playback enabled: avoiding file seek, trickmodes disabled\n"));

		SendContext.dcc_info->RM_PSM_commands &= ~RM_PSM_ENABLE_SEEK;
		
		SendContext.dcc_info->RM_PSM_commands &= ~RM_PSM_ENABLE_IFWD;
		SendContext.dcc_info->RM_PSM_commands &= ~RM_PSM_ENABLE_IRWD;

		// init variables here because in linear playback we do Play() before main_loop
		SendContext.IFrameFSMState = RMasfIFrameFSM_Disabled;
		SendContext.firstIFrame = FALSE;

		SendContext.video_decoder_initialized = FALSE;
		SendContext.audio_decoder_initialized = FALSE;
		SendContext.FirstSystemTimeStamp = TRUE;

		SendContext.prev_video_media_object_number = -1;
		SendContext.video_frame_counter = 0;
		SendContext.VideoByteCounter = 0;
		SendContext.video_last_pts = 0;

		SendContext.prev_audio_media_object_number = -1;
		SendContext.audio_frame_counter = 0;
		SendContext.AudioByteCounter = 0;

		SendContext.start_ms = SendContext.play_opt->start_ms;		

		SendContext.isTrickMode = FALSE;
		SendContext.isIFrameMode = FALSE;
	}

	/* Build the index now if seeking is supported */
	if (!SendContext.linear_playback){
		RMDBGLOG((ENABLE,"Seek supported, building the index\n"));
		/* call the video and audio callback properties. This has to be called
		 * after DCCInitMicroCodeEx, otherwise in case the media is encrypted,
		 * decryption will fail (TD in unconsistent state) */
		err = RMASFVDemuxBuildIndexWithHandle(SendContext.vASFDemux, 
				SendContext.f_bitstream, &SendContext.asf_packetSize, 
				&SendContext.asf_Header_Object_Size);

		if (err != RM_OK) {
			if ((SendContext.AudioStreamFound) && (!SendContext.VideoStreamFound)) {
				RMDBGLOG((ENABLE, ">>> No index, will use alternate seek support for WMA, disabling iframe mode\n"));
			}
			else {
				RMDBGLOG((ENABLE, ">>> No index, IFrame, trickmode and Seek modes not supported\n"));
				SendContext.dcc_info->RM_PSM_commands &= ~RM_PSM_ENABLE_SEEK;

				SendContext.dcc_info->RM_PSM_commands &= ~RM_PSM_ENABLE_SPEED;
				SendContext.dcc_info->RM_PSM_commands &= ~RM_PSM_ENABLE_FASTER;
				SendContext.dcc_info->RM_PSM_commands &= ~RM_PSM_ENABLE_SLOWER;
				SendContext.dcc_info->RM_PSM_commands &= ~RM_PSM_ENABLE_REWIND;

			}
			/* disable iframe mode */
			SendContext.dcc_info->RM_PSM_commands &= ~RM_PSM_ENABLE_IFWD;
			SendContext.dcc_info->RM_PSM_commands &= ~RM_PSM_ENABLE_IRWD;

		}

		if ((SendContext.AudioStreamFound) && (!SendContext.VideoStreamFound)) {
			RMDBGLOG((ENABLE, "audio only file, disabling 'nextpic' command\n"));
			SendContext.dcc_info->RM_PSM_commands &= ~RM_PSM_ENABLE_NEXTPIC;

			/* disable iframe mode */
			SendContext.dcc_info->RM_PSM_commands &= ~RM_PSM_ENABLE_IFWD;
			SendContext.dcc_info->RM_PSM_commands &= ~RM_PSM_ENABLE_IRWD;

			/* activate rewind mode */
			SendContext.dcc_info->RM_PSM_commands |= RM_PSM_ENABLE_REWIND;

			if (!SendContext.play_opt->prebuf_max) {
				SendContext.play_opt->prebuf_max = 200 * 1024;
				RMDBGLOG((ENABLE, "set prebuf_max to %lu Kb\n", SendContext.play_opt->prebuf_max));
			}
		}
	}
	else {
		RMDBGLOG((ENABLE, ">> seek not supported, index not built\n"));
	}

	


	if (SendContext.unsupported_video && SendContext.play_opt->require_video_audio){
		fprintf(stderr, "video not supported and video is required, use -past if you want to 'play any supported track'\n");
		err = RM_VIDEO_CODEC_NOT_SUPPORTED;
		goto exit_with_error;
	}

	if ((SendContext.videoSetupStatus == RM_FATALOUTOFMEMORY) || (SendContext.audioSetupStatus == RM_FATALOUTOFMEMORY)) {
		fprintf(stderr, "out of memory!\n");
		err = RM_FATALOUTOFMEMORY;
		goto exit_with_error;
	}
		
		
	{
		RMuint32 mainDMApoolSize   = SendContext.play_opt->dmapool_count * (1<< SendContext.play_opt->dmapool_log2size);
		RMuint32 wmaproDMApoolSize = AUDIO_DMA_BUFFER_COUNT  * (1<<AUDIO_DMA_BUFFER_SIZE_LOG2);

		RMDBGLOG((ENABLE, "wanted DMApool size %lu, bufferCount %lu bufferSize %lu\n",
			  mainDMApoolSize,
			  SendContext.play_opt->dmapool_count,
			  (1<<SendContext.play_opt->dmapool_log2size)));
		RMDBGLOG((ENABLE, "WMAPro DMApool size %lu, bufferCount %lu, bufferSize %lu, wmapro/main %lu per cent\n",
			  wmaproDMApoolSize,
			  AUDIO_DMA_BUFFER_COUNT,
			  (1<<AUDIO_DMA_BUFFER_SIZE_LOG2),
			  (wmaproDMApoolSize * 100) / mainDMApoolSize));

		mainDMApoolSize -= wmaproDMApoolSize;
		SendContext.play_opt->dmapool_count = mainDMApoolSize / (1<<SendContext.play_opt->dmapool_log2size);

		RMDBGLOG((ENABLE, "adjusted DMApool size %lu (optimal size %lu, really wasted %lu), bufferCount %lu bufferSize %lu, \n",
			  SendContext.play_opt->dmapool_count * (1<<SendContext.play_opt->dmapool_log2size),
			  mainDMApoolSize,
			  (SendContext.play_opt->dmapool_count * (1<<SendContext.play_opt->dmapool_log2size)) - mainDMApoolSize,
			  SendContext.play_opt->dmapool_count,
			  (1<<SendContext.play_opt->dmapool_log2size)));
		
		err = RUAOpenPool(dcc_info.pRUA, 0, SendContext.play_opt->dmapool_count, SendContext.play_opt->dmapool_log2size, RUA_POOL_DIRECTION_SEND, &pDMA);
		if (RMFAILED(err)) {

			RMuint32 poolSize = SendContext.play_opt->dmapool_count << SendContext.play_opt->dmapool_log2size;
			
			fprintf(stderr, "Error cannot open dmapool %d\n\n"
				"requested %lu bytes of dmapool (%lu buffers of %lu bytes), make sure you\n"
				"loaded llad with the right parameters. For example:\n"
				"max_dmapool_memory_size >= %lu and max_dmabuffer_log2_size >= %lu\n\n",
				err,
				poolSize,
				SendContext.play_opt->dmapool_count,
				(RMuint32)(1<<SendContext.play_opt->dmapool_log2size),
				poolSize,
				SendContext.play_opt->dmapool_log2size);

			goto exit_with_error;
		}
	}

	dcc_info.chip_num = SendContext.play_opt->chip_num;
	dcc_info.trickmode_id = RM_NO_TRICKMODE;

	SendContext.pDMA = pDMA;
 	SendContext.UncompressedBuffer = NULL;

	/* #### Begin DTCP code #### */       
#if (EM86XX_CHIP != EM86XX_CHIPID_TANGO15)
	if ((dtcpCookieHandle != NULL) && (dtcpCookieHandle->dtcp_emi != 0)) {
	/* Make sure that decrypt buffer from pool. */
		dtcpCookieHandle->BufferPoolDecryptionFlag = 1;
		dtcpCookieHandle->dtcp_DMA_ptr = SendContext.pDMA;
	}
#endif
	/* #### End DTCP code #### */
	
#ifdef _DUMP_INT_FILE_
	SendContext.intfile = fopen("temp.wmapro_asf", "wb");
	if(SendContext.intfile == NULL) {
		RMDBGLOG((ENABLE,"ERROR: can't create temp.wmapro\n"));
		err = RM_ERROR;
		goto exit_with_error;
	}			
#endif

#ifdef SAVE_INPUT_FRAMES
	SendContext.f_compressed_frames = -1;
#endif

#ifndef WITH_MONO	
	RMTermInit(TRUE);    // don't allow ctrl-C and the like ...
	RMSignalInit(NULL, NULL);  // ... but catch other termination signals to call RMTermExit()
#endif
	/* #### Begin CARDEA code #### If there is a cardea context, then we
	 * already know it is encrypted */
	if (SendContext.cardea_context == NULL){
		SendContext.drmError = RMASFVDemuxIsContentEncrypted(SendContext.vASFDemux, &SendContext.isContentEncrypted);
		if (SendContext.drmError != 0) {
			fprintf(stderr, ">> there was an error during DRM init\n");
			SendContext.bypass_drm = TRUE;

			if (SendContext.isContentEncrypted) {
				fprintf(stderr, ">> content is encrypted, unable to play\n");
				err = RM_DRM_PREVENTS_PLAYBACK;
				goto exit_with_error;
			}
		}

		if (SendContext.isContentEncrypted)
			RMDBGLOG((ENABLE, "Encrypted Content!\n"));

		if (SendContext.bypass_drm) {
			RMDBGLOG((ENABLE, "bypass DRM actived, payload callback wont decrypt\n"));
			SendContext.isContentEncrypted = FALSE;
		}
	}
	/* #### End CARDEA code #### */


	// by default, ASF has square pixels
	if (SendContext.inband_aspect_ratio_x == SendContext.inband_aspect_ratio_y) {
		struct SurfaceAspectRatio_type param;

		param.type = EMhwlibAspectRatio_Pixel;
		param.ar.X = 1;
		param.ar.Y = 1;

		RMDBGLOG((ENABLE, "set square pixels, %lu:%lu\n", SendContext.inband_aspect_ratio_x, SendContext.inband_aspect_ratio_y));

		RUASetProperty(SendContext.pRUA, SendContext.dcc_info->video_decoder, 
			       RMVideoDecoderPropertyID_InbandSurfaceAspectRatio, 
			       &param, 
			       sizeof(param), 0);
	}


	/* check for a scheduled aspect ratio change */
	if ((SendContext.setAspectRatio) && (SendContext.video_stream_index == SendContext.inband_aspect_ratio_stream_index) ) {
		err = RUASetProperty(SendContext.pRUA, SendContext.dcc_info->video_decoder, 
				     RMVideoDecoderPropertyID_InbandSurfaceAspectRatio, 
				     &(SendContext.InBandAspectRatioParams), 
				     sizeof(struct SurfaceAspectRatio_type), 0);
		if (err != RM_OK) {
			RMDBGLOG((ENABLE, "error setting scheduled aspect ratio\n"));
		}
		RMDBGLOG((ENABLE, ">>> scheduled aspect ratio set, ratio %lu:%lu\n", 
			  SendContext.InBandAspectRatioParams.ar.X,
			  SendContext.InBandAspectRatioParams.ar.Y));
	}

	/* initialize the external close caption source */
	if (NULL == SendContext.play_opt->bcc_filename) {
		SendContext.bcc_enabled = FALSE;
	}
	else {
		RMnonAscii *naname;

		SendContext.bcc_enabled = TRUE;

		naname = RMnonAsciiFromAscii(SendContext.play_opt->bcc_filename);
		err = bcc_init(&SendContext.pbcc, naname, SendContext.pRUA, SendContext.dcc_info);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error %s: failed to init BCC subsystem.\n", RMstatusToString(err)));
			SendContext.bcc_enabled = FALSE;
		}
		RMFreeNonAscii(naname);

	}


	RM_PSM_SetState(SendContext.PSMcontext, &(SendContext.dcc_info), RM_PSM_Playing);

	// main do-while
	do {
		RMuint8 *buffer = NULL;
		enum RM_PSM_State PlaybackStatus;

		if (SendContext.play_opt->start_pause) {
			RMDBGLOG((ENABLE, "start in pause mode!\n"));
			/* required, because if we do 'next' the decoder *must* be running */
			err = Play(&SendContext, RM_DEVICES_VIDEO, /*DCCVideoPlayIFrame*/DCCVideoPlayFwd);
			if (RMFAILED(err)) {
				fprintf(stderr, "Cannot start decoders %d\n", err);
				goto cleanup;
			}
			
			err = Pause(&SendContext, RM_DEVICES_VIDEO);
			if (RMFAILED(err)) {
				fprintf(stderr, "Cannot pause decoders %d\n", err);
				goto cleanup;
			}
			RM_PSM_SetState(SendContext.PSMcontext, &(SendContext.dcc_info), RM_PSM_Paused);
		}
		
		/* 
		   do not change PSM state in case there is no start_pause. 
		   Otherwise after pressing STOP the application play again immediately
		*/

		SendContext.play_opt->start_pause = FALSE;


		RMDBGLOG((ENABLE, "mainloop\n"));

		SendContext.IFrameFSMState = RMasfIFrameFSM_Disabled;
		SendContext.firstIFrame = FALSE;

		SendContext.video_decoder_initialized = FALSE;
		SendContext.audio_decoder_initialized = FALSE;
		SendContext.FirstSystemTimeStamp = TRUE;

		SendContext.prev_video_media_object_number = -1;
		SendContext.video_frame_counter = 0;
		SendContext.VideoByteCounter = 0;
		SendContext.video_last_pts = 0;

		SendContext.prev_audio_media_object_number = -1;
		SendContext.audio_frame_counter = 0;
		SendContext.AudioByteCounter = 0;

		SendContext.start_ms = SendContext.play_opt->start_ms;		

		SendContext.isTrickMode = FALSE;
		SendContext.isIFrameMode = FALSE;

		SendContext.audioSamplesDropped = FALSE;
		SendContext.gotoRequest=RMProcess_key_goto_none;
        
		if (SendContext.isVC1) {
			SendContext.getStartCodeBuffer = TRUE;
			SendContext.addSeqHeader = TRUE;
			SendContext.addEntryHeader = TRUE;
			SendContext.addFrameHeader = TRUE;
		}
		
		if (!SendContext.linear_playback) {
			RMint64 position = 0;

			/* seek to first packet, at position [headerSize+50] */
			RMSeekFile(SendContext.f_bitstream, SendContext.asf_Header_Object_Size+50, 
				   RM_FILE_SEEK_START);

			/* presets the demux to start parsing first packet */
			RMASFVDemuxResetState(SendContext.vASFDemux);

			/* Check current position only if seek is supported */
			RMGetCurrentPositionOfFile (SendContext.f_bitstream, &position);
			RMDBGLOG((ENABLE, "current position %lld\n", position));
		}


		DCCSTCSetTime(dcc_info.pStcSource, SendContext.stc_offset_ms*((RMint64)(SendContext.video_vop_tir/1000)), SendContext.video_vop_tir);
		DCCSTCSetSpeed(dcc_info.pStcSource, SendContext.play_opt->speed_N, SendContext.play_opt->speed_M);

		PlaybackStatus = RM_PSM_GetState(SendContext.PSMcontext, &(SendContext.dcc_info));
		if ((PlaybackStatus != RM_PSM_Paused) && (PlaybackStatus != RM_PSM_Stopped)) {
			RMDBGLOG((ENABLE, "setting play state\n"));
			RM_PSM_SetState(SendContext.PSMcontext, &(SendContext.dcc_info), RM_PSM_Playing);	
		}
		else {
			PROCESS_KEY(FALSE, TRUE);
			update_hdmi(SendContext.dcc_info, SendContext.disp_opt, &(SendContext.audio_opt[0]));
		}


	mainloop_seek:
		RMDBGLOG((ENABLE, "mainloop_seek\n"));
		
		if (!SendContext.linear_playback) {
			// the following call will configure the decoders, after that we can 'pause' them
			err = Play(&SendContext, RM_DEVICES_AUDIO | RM_DEVICES_VIDEO, DCCVideoPlayFwd);
			if (err != RM_OK)
				goto exit_with_error;
			
			/* do prebufferization only when in playing state */
			if (RM_PSM_GetState(SendContext.PSMcontext, &(SendContext.dcc_info)) == RM_PSM_Playing) {
				
				Pause(&SendContext, RM_DEVICES_STC | RM_DEVICES_VIDEO | RM_DEVICES_AUDIO);
				
				RM_PSM_SetState(SendContext.PSMcontext, &(SendContext.dcc_info), RM_PSM_Prebuffering);
				fprintf(stderr, "prebuffering\n");
			}
		}
		


#ifdef WITH_MONO
		RMDCCInfo(&dcc_info); // pass DCC context to application
#endif

		/* wake up disks if necessary */
		switch (SendContext.play_opt->disk_ctrl_state) {
		case DISK_CONTROL_STATE_DISABLE:
		case DISK_CONTROL_STATE_RUNNING:
			break;
		case DISK_CONTROL_STATE_SLEEPING:
			if (SendContext.play_opt->disk_ctrl_callback) {
				RMuint32 poll_count = DISK_CONTROL_MAX_WAKEUP_COUNT;
				
				/* software decode wmapro while polling disk ready status, otherwise
				   we might run out of buffer in case buffer size is too small or
				   when spinning up the disk takes too long.

				   probably not necessary in this case, since we are coming from a seek
				   and buffers are flushed anyway */
				while (poll_count--) {
					if (SendContext.play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_RUN_NOWAIT) == RM_OK) {
						SendContext.play_opt->disk_ctrl_state = DISK_CONTROL_STATE_RUNNING;
						break;
					}

					try_decode_wmapro(&SendContext, FALSE);
					PROCESS_KEY(TRUE, TRUE);

					usleep(TIMEOUT_100MS);
				}

				if (SendContext.play_opt->disk_ctrl_state != DISK_CONTROL_STATE_RUNNING)
					RMDBGLOG((ENABLE, "warning, couldn't wakeup disk in time\n"));
			}
			break;
		}


		while (1) { // additional 'while' used for taking care of commands issued during EOSWait
			while(1) {
				RMuint32 count;
				

				/* first, try to fill up the CC fifo */
				if (SendContext.bcc_enabled) {
					bcc_feed(SendContext.pbcc, SendContext.pRUA, SendContext.Preroll);
				}
				
				//try_decode_wmapro(&SendContext, FALSE);
				//PROCESS_KEY(TRUE);

				PROCESS_KEY(FALSE, TRUE);
				update_hdmi(SendContext.dcc_info, SendContext.disp_opt, &(SendContext.audio_opt[0]));

				/* wake up disks if necessary */
				switch (SendContext.play_opt->disk_ctrl_state) {
				case DISK_CONTROL_STATE_DISABLE:
				case DISK_CONTROL_STATE_RUNNING:
					break;
				case DISK_CONTROL_STATE_SLEEPING:
					if (SendContext.play_opt->disk_ctrl_callback) {
						RMuint32 poll_count = DISK_CONTROL_MAX_WAKEUP_COUNT;
						
						/* software decode wmapro while polling disk ready status, otherwise
						   we might run out of buffer in case buffer size is too small or
						   when spinning up the disk takes too long.
						   
						   probably not necessary in this case, since we are coming from a seek
						   and buffers are flushed anyway */
						while (poll_count--) {
							if (SendContext.play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_RUN_NOWAIT) == RM_OK) {
								SendContext.play_opt->disk_ctrl_state = DISK_CONTROL_STATE_RUNNING;
								break;
							}
							
							try_decode_wmapro(&SendContext, FALSE);
							PROCESS_KEY(TRUE, TRUE);
							
							usleep(TIMEOUT_100MS);
						}
						
						if (SendContext.play_opt->disk_ctrl_state != DISK_CONTROL_STATE_RUNNING)
							RMDBGLOG((ENABLE, "warning, couldn't wakeup disk in time\n"));
					}
					break;
				}


#ifdef CHECK_BUFFER_4_FREAD
				{
				int cWait = 0;
#endif

				
				get_buffer:
				switch (SendContext.play_opt->disk_ctrl_state) {
				case DISK_CONTROL_STATE_DISABLE:
				case DISK_CONTROL_STATE_SLEEPING:
					break;
				case DISK_CONTROL_STATE_RUNNING:
					if (SendContext.dmabuffer_index > 0) {
						SendContext.dmabuffer_index--;
						buffer = SendContext.dmabuffer_array[SendContext.dmabuffer_index];
						RMDBGLOG((ENABLE, "fill buffer phase: got buffer %p (index %lu, level %lu, count %lu)\n", 
							  buffer,
							  SendContext.dmabuffer_index,
							  SendContext.play_opt->disk_ctrl_low_level,
							  SendContext.play_opt->dmapool_count));
						goto fill_buffer;
					}
					break;
				}


				RMDBGLOG((DISABLE, "try to RUAGetBuffer. AvailableBufferCount= %ld\n",
					RUAGetAvailableBufferCount(SendContext.pDMA)));
				while(RUAGetBuffer(SendContext.pDMA, &buffer, GETBUFFER_TIMEOUT_US) != RM_OK) {
					/*RMbool gotKey;*/
					
					check_prebuf_state(&SendContext, 0);

#ifdef CHECK_BUFFER_4_FREAD
					cWait ++;
#endif

					switch (SendContext.play_opt->disk_ctrl_state) {
					case DISK_CONTROL_STATE_DISABLE:
					case DISK_CONTROL_STATE_SLEEPING:
						break;
					case DISK_CONTROL_STATE_RUNNING:
						if(SendContext.play_opt->disk_ctrl_callback && SendContext.play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_SLEEP) == RM_OK)
							SendContext.play_opt->disk_ctrl_state = DISK_CONTROL_STATE_SLEEPING;
						break;
					}

					try_decode_wmapro(&SendContext, FALSE);
					PROCESS_KEY(FALSE, TRUE);
					update_hdmi(SendContext.dcc_info, SendContext.disp_opt, &(SendContext.audio_opt[0]));
				}
#ifdef CHECK_BUFFER_4_FREAD
				if(cWait>0)printf("FRead wait: %d\n", cWait);
				}
#endif			

#if (EM86XX_MODE == EM86XX_MODEID_STANDALONE) && (EM86XX_CHIP != EM86XX_CHIPID_TANGO2)
				buffer = (RMuint8 *)((RMuint32)buffer & 0x7fffffff);
#endif
				
				check_prebuf_state(&SendContext, (1 << SendContext.play_opt->dmapool_log2size));


				switch (SendContext.play_opt->disk_ctrl_state) {
				case DISK_CONTROL_STATE_DISABLE:
				case DISK_CONTROL_STATE_RUNNING:
					break;
				case DISK_CONTROL_STATE_SLEEPING:
					SendContext.dmabuffer_array[SendContext.dmabuffer_index] = buffer;
					SendContext.dmabuffer_index ++;
					if (SendContext.dmabuffer_index + SendContext.play_opt->disk_ctrl_low_level >= SendContext.play_opt->dmapool_count) {
						if (SendContext.play_opt->disk_ctrl_callback) {
							RMuint32 poll_count = DISK_CONTROL_MAX_WAKEUP_COUNT;
							
							/* software decode wmapro while polling disk ready status, otherwise
							   we might run out of buffer in case buffer size is too small or
							   when spinning up the disk takes too long */
							while (poll_count--) {
								if (SendContext.play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_RUN_NOWAIT) == RM_OK) {
									SendContext.play_opt->disk_ctrl_state = DISK_CONTROL_STATE_RUNNING;
									break;
								}

								try_decode_wmapro(&SendContext, FALSE);
								PROCESS_KEY(TRUE, TRUE);

								usleep(TIMEOUT_100MS);
							}

							if (SendContext.play_opt->disk_ctrl_state != DISK_CONTROL_STATE_RUNNING)
								RMDBGLOG((ENABLE, "warning, couldn't wakeup disk in time\n"));
						}
					}
					RMDBGLOG((ENABLE, "recycle buffer phase: got buffer %p (index %lu, level %lu, count %lu)\n", 
						  buffer,
						  SendContext.dmabuffer_index,
						  SendContext.play_opt->disk_ctrl_low_level,
						  SendContext.play_opt->dmapool_count));

					goto get_buffer;
				}
				
			fill_buffer:

				err = readBitstream(&SendContext, buffer, &count);

				if (err == RM_OK) {
					rc = RMASFVDemuxDEMUX(SendContext.vASFDemux,buffer, count);
				}
				else if (err == RM_EOS) {
					RMDBGLOG((ENABLE, "wait for eos\n"));
					if (buffer != NULL) 
						RUAReleaseBuffer(SendContext.pDMA, buffer);
					break;
				}
				else if (err == RM_SKIP_DATA) {
					RMint64 currentTime;
					RMuint64 stc;
 					//get the time in 1000th units because presentation time from ASF is always in 1/1000
					//!!! the above assumption might be wrong see #5529, however it doesnt change this routine
 					DCCSTCGetTime(SendContext.dcc_info->pStcSource, &stc, 1000);

					currentTime = (RMuint64)stc;

 					if ((currentTime > (RMint64)SendContext.lastSTC + 1000) ||
					    (currentTime < (RMint64)SendContext.lastSTC - 1000)) {
						SendContext.lastSTC = stc;
						RMDBGLOG((ENABLE, "time = %llu/%llu (%ld/100)\n", currentTime, SendContext.Duration, (currentTime * 100) / SendContext.Duration));
					}

					if (currentTime > (RMint64)SendContext.Duration) {
						RMDBGLOG((ENABLE, "currentTime > duration!\n"));
						goto signal_eos;
						break;
					}
					else if (currentTime <= 0) {
						RMDBGLOG((ENABLE, "currentTime <= 0\n"));
						goto signal_eos;
						break;
					}
					usleep(100000); // to prevent high CPU usage

				}
				else if (err == RM_DRM_DECRYPTION_FAILED) {
					RMDBGLOG((ENABLE, "decrytion error, abort\n"));
					if (buffer != NULL) 
						RUAReleaseBuffer(SendContext.pDMA, buffer);

					goto exit_with_error;
				}
				else if (err == RM_ERRORENDOFFILE) {
					RMDBGLOG((ENABLE, "EOF %s (%ld), wait for eos\n", RMstatusToString(err), err));
					if (buffer != NULL) 
						RUAReleaseBuffer(SendContext.pDMA, buffer);

					break;
				}
				else {
					RMDBGLOG((ENABLE, "error %s (%ld), exit\n", RMstatusToString(err), err));
					if (buffer != NULL) 
						RUAReleaseBuffer(SendContext.pDMA, buffer);

					goto exit_with_error;
				}
			
				if (buffer != NULL) {
					RMDBGLOG((RELEASE_BUFFER_ENABLE, "Releasing buffer %p\n", buffer));
					RUAReleaseBuffer(SendContext.pDMA, buffer);
					buffer = NULL;
				}


#if 0
				/* TODO: This code should use multiple audio. Get profiling value */
				
				{
					RMreal profile;
					err = RUAGetProperty(SendContext.pRUA,
							     SendContext.dcc_info->audio_decoder,
							     RMGenericPropertyID_Profile,
							     &profile,
							     sizeof(profile));
					if (err == RM_OK) {
						printf("Audio DSP Usage = %02.2f%%\n", profile);
					}
				}
#endif

				/* check if the user pressed a key when we were processing a callback */
				RMDBGLOG((DISABLE, "process_key after demuxing, actions 0x%lx toDo 0x%lx\n",
					  SendContext.actions.cmd,
					  SendContext.actions.toDoActions));
				PROCESS_KEY(TRUE, FALSE);
				update_hdmi(SendContext.dcc_info, SendContext.disp_opt, &(SendContext.audio_opt[0]));

				{
					try_decode_wmapro(&SendContext, FALSE);
					PROCESS_KEY(TRUE, TRUE);
				}
			}

			check_prebuf_state(&SendContext, 0);

			switch (SendContext.play_opt->disk_ctrl_state) {
			case DISK_CONTROL_STATE_DISABLE:
			case DISK_CONTROL_STATE_SLEEPING:
				break;
			case DISK_CONTROL_STATE_RUNNING:
				if(SendContext.play_opt->disk_ctrl_callback && SendContext.play_opt->disk_ctrl_callback(DISK_CONTROL_ACTION_SLEEP) == RM_OK)
					SendContext.play_opt->disk_ctrl_state = DISK_CONTROL_STATE_SLEEPING;
				break;
			}


			// in case we're still in pause state, wait for a key
			PROCESS_KEY(FALSE, TRUE);

		check_wmapro_fifo_emptiness_on_eos:
			if (!RMfifo_is_empty(SendContext.wmapro_fifo)) {

				RMDBGLOG((ENABLE, "WMAPRO FIFO is not empty before EOS\n"));

				try_decode_wmapro(&SendContext, TRUE);
				PROCESS_KEY(TRUE, TRUE);
				goto check_wmapro_fifo_emptiness_on_eos;
			}

			fprintf(stderr, "File ready %ld times, waiting for EOS\n", NTimes+1);
			err = WaitForEOS(&SendContext, &SendContext.actions);
			{
				RMuint64 stc;
				DCCSTCGetTime(dcc_info.pStcSource, &stc, SendContext.video_vop_tir);

				RMDBGLOG((ENABLE, "Timer duration %llu ms, Header Duration %llu ms\n", stc, SendContext.Duration));
			}
			

			if (err == RM_KEY_WHILE_WAITING_EOS) {
				err = RM_OK;
				PROCESS_KEY(FALSE, FALSE);
				continue;
			}
			else {
				if ((SendContext.isIFrameMode) && (SendContext.IFrameDirection < 0) && 0)
					goto wmapro_decoder_delete;
				else {

				signal_eos:
#ifdef WITH_MONO
					/* callback to signal EOS to curacao/mono */
					RMEOSCallback(); 
					/* process any command that might be issued after an EOS signalling */
					PROCESS_KEY(FALSE, TRUE);
					/* after processing the key, if we are still here, proceed with EOS */
#endif
					break;	// EOS	
				}
			}
		}

		if (SendContext.play_opt->loop_count > 0)
			SendContext.play_opt->loop_count --;

wmapro_decoder_delete:
		if (SendContext.vDecoder != (void *)NULL) {			

			RMDBGLOG((ENABLE, "closing wmaprodecoder\n"));
			RMWMAProVDecoderClose(SendContext.vDecoder);
			RMDeleteWMAProVDecoder(SendContext.vDecoder);
			SendContext.vDecoder = (void *)NULL;
			flush_wmaproFIFO(&SendContext);

		}
		NTimes++;

		/* if there is another loop, stop devices */
		if ((SendContext.play_opt->loop_count > 0) || (SendContext.play_opt->waitexit != TRUE) || (SendContext.play_opt->infinite_loop))
			Stop(&SendContext, RM_DEVICES_STC | RM_DEVICES_AUDIO | RM_DEVICES_VIDEO);

	} while ((SendContext.play_opt->infinite_loop) || (SendContext.play_opt->loop_count > 0));
	
 cleanup:

	error = 0; //normal exit

 exit_with_error:

	if( SendContext.play_opt->waitexit ) {
		RMascii key;
		fprintf(stderr, "press q key again if you really want to stop & quit\n");
		while ( !(RMGetKeyNoWait(&key) && ((key == 'q') || (key =='Q'))) );
		Stop(&SendContext, RM_DEVICES_STC);
		Stop(&SendContext, RM_DEVICES_STC | RM_DEVICES_AUDIO | RM_DEVICES_VIDEO);
	}

#ifndef WITH_MONO	
	RMTermExit();
#endif

	if (err != RM_OK) {
		fprintf(stderr, "quitting due to error %s (%d)...\n", RMstatusToString(err), err);
		error = err; //exit with error
	}

	RMDBGLOG((ENABLE, "closing...\n"));

#ifdef WITH_MONO
	RMDCCInfo(NULL); // invalidate DCC context
#endif


	{
		RMuint32 i;
		
		for(i=0;i<MAX_NUMBER_OF_AUDIO_STREAMS;i++) {
			if(SendContext.lang[i].languageID) {
				RMFree(SendContext.lang[i].languageID);
				SendContext.lang[i].languageID = (RMnonAscii *) 0;
			}
		}
	}

	if (SendContext.dmabuffer_array) {
		RMuint32 i;
		for (i = 0; i < SendContext.dmabuffer_index; i++) {
			RUAReleaseBuffer(pDMA, SendContext.dmabuffer_array[i]);
			RMDBGLOG((ENABLE, "released buffer[%lu] @ 0x%08lx\n", i, SendContext.dmabuffer_array[i]));
		}
		RMFree(SendContext.dmabuffer_array);
		SendContext.dmabuffer_index = 0;
		SendContext.dmabuffer_array = NULL;
	}

#if !(EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
	/* #### Begin CARDEA code #### */
	if (SendContext.cardea_context != NULL){
		RMDBGLOG((ENABLE,"Terminate CARDEA session\n"));
		err = term_cardea();
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE,"Error terminating CARDEA session\n"));
			//error = -1;
		}
	}
	/* #### End CARDEA code #### */
#endif

	/* #### Begin DTCP code #### */
#ifndef WITH_MONO	
	if (dtcpCookieHandle) {
		err = term_DTCP_session(dtcpCookieHandle, dcc_info.pRUA);
		if (RMFAILED(err)) 
			RMDBGLOG((ENABLE, "Cannot terminate DTCP-IP session !!!\n"));
	}
#endif // WITH_MONO
	/* #### End DTCP code #### */

	if (SendContext.f_bitstream) {
		RMDBGLOG((ENABLE, "closing bitstream %s\n", SendContext.play_opt->filename));
		RMCloseFile(SendContext.f_bitstream);
	}

	if (SendContext.vASFDemux) {
		RMDBGLOG((ENABLE, "delete demux\n"));
		RMDeleteASFVDemux(SendContext.vASFDemux);
	}
	
	/* ##### Begin CARDEA code #### */

	if ( SendContext.cardea_context != NULL ) {
		RMDBGLOG((ENABLE, "Destroying cardea license data\n"));
		RMDBGLOG((ENABLE, "0x%08x : 0x%08x\n", SendContext.cardea_context));
		destroy_cardea_license_data(SendContext.cardea_context);
	}

	/* ##### End CARDEA code #### */

#ifdef SAVE_INPUT_FRAMES
	if (SendContext.f_compressed_frames >= 0)
		close(SendContext.f_compressed_frames);
#endif

	if (SendContext.vDecoder != (void *)NULL) {

		RMDBGLOG((ENABLE, "closing WMAPRO decoder\n"));
		RMWMAProVDecoderClose(SendContext.vDecoder);
		RMDeleteWMAProVDecoder(SendContext.vDecoder);
		SendContext.vDecoder = (void *)NULL;
		flush_wmaproFIFO(&SendContext);
	}


#ifdef _DUMP_INT_FILE_
	fclose(SendContext.intfile);
#endif

	RMDBGLOG((ENABLE, "closing save files\n"));
	err = close_save_files(SendContext.play_opt);

	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot close files used to save data %d\n", err));
		//error = -1;
	}
	
#ifndef WITH_MONO	
	if (dh_info.pDH != NULL) {
		DHDone(dh_info.pDH);
		dh_info.pDH = NULL;
	}
#endif
	if (dcc_info.pStcSource) {
		RMDBGLOG((ENABLE, "stopping STC\n"));
		DCCSTCStop(dcc_info.pStcSource);
	}

	if (dcc_info.pVideoSource) {
		RMDBGLOG((ENABLE, "stopping video source\n"));
		err = DCCStopVideoSource(dcc_info.pVideoSource, DCCStopMode_LastFrame);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot stop video decoder %d\n", err));
			//error = -1;
		}
	}
	
	if (dcc_info.pMultipleAudioSource) {
		RMDBGLOG((ENABLE, "stopping audio source\n"));
		err = DCCStopMultipleAudioSource(dcc_info.pMultipleAudioSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot stop audio decoder %d\n", err));
			//error = -1;
		}
	}
	
	if (pDMA) {
		RMDBGLOG((ENABLE, "closing DMApool\n"));
		err = RUAClosePool(pDMA);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error cannot close dmapool %d\n", err));
			//error = -1;
		}
	}

	if (SendContext.pDMAuncompressed) {
		RMDBGLOG((ENABLE, "closing WMAPRO DMA pool\n"));
		err = RUAClosePool(SendContext.pDMAuncompressed);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error cannot close compressed dmapool %d\n", err));
			//error = -1;
		}
	}

	if (dcc_info.pVideoSource) {
		RMDBGLOG((ENABLE, "closing video source\n"));
		err = DCCCloseVideoSource(dcc_info.pVideoSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error cannot close video decoder %d\n", err));
			//error = -1;
		}
	}

	if (dcc_info.pMultipleAudioSource) {
		RMDBGLOG((ENABLE, "closing audio source\n"));
		err = DCCCloseMultipleAudioSource(dcc_info.pMultipleAudioSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error cannot close video decoder %d\n", err));
			//error = -1;
		}
	}

	if (dcc_info.pStcSource) {
		RMDBGLOG((ENABLE, "closing STC\n"));
		err = DCCSTCClose(dcc_info.pStcSource);
		if (RMFAILED(err)){
			fprintf(stderr, "Error cannot close STC %d\n", err);
			//error = -1;
		}
	}

	if (SendContext.bcc_enabled)
	{
		bcc_close(SendContext.pbcc, SendContext.pRUA);
		SendContext.bcc_enabled = FALSE;
	}
	
	clear_video_options(&dcc_info, SendContext.video_opt);

#ifndef WITH_MONO

	clear_display_options(&dcc_info, SendContext.disp_opt);

	if (dcc_info.pDCC) {
		RMDBGLOG((ENABLE, "closing DCC\n"));
		err = DCCClose(dcc_info.pDCC);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot close DCC %d\n", err));
			//error = -1;
		}
	}

	if (dcc_info.pRUA) {
		RMDBGLOG((ENABLE, "closing RUA\n"));
		err = RUADestroyInstance(dcc_info.pRUA);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot destroy RUA instance %d\n", err));
			//error = -1;
		}
	}
#endif

	RMfifo_close(SendContext.wmapro_fifo);

	if(wmapro_fifo_buffer_original != NULL) {
		// we free the "original" pointer
		RMFree(wmapro_fifo_buffer_original);
	}



	if (error)
		RMDBGLOG((ENABLE, "exiting with error %s (%d)\n", RMstatusToString(error), error));


	return error;
}


#if (EM86XX_CHIP == EM86XX_CHIPID_TANGO2)
void test_cci( void *cardea_context ) 
{
	struct rmcci	cci_info;
	RMstatus	status;

	memset( &cci_info, 0xff, sizeof(cci_info) );

	status = get_cardea_cci( cardea_context, &cci_info );

	if ( status == RM_OK ) {
		fprintf(stderr, "----   CCI information   ----\n");
		fprintf(stderr, "Dirty                   : %d\n", cci_info.DirtyBit);
		fprintf(stderr, "Audio disable\n");
		fprintf(stderr, " Analog                 : %d\n", cci_info.AnalogAudio_disable);
		fprintf(stderr, " Digital Compressed     : %d\n", cci_info.DigitalCompressedAudio_disable);
		fprintf(stderr, " Digital Uncompressed   : %d\n", cci_info.DigitalUncompressedAudio_disable);
		fprintf(stderr, "SPDIF PCM limit         : %d\n", cci_info.SPDIF_PCMLimit);
		fprintf(stderr, "SPDIF Cp Bit            : %d\n", cci_info.SPDIF_CpBit);
		fprintf(stderr, "SPDIF L Bit             : %d\n", cci_info.SPDIF_LBit);
		fprintf(stderr, "Analog Video disable    : %d\n", cci_info.AnalogVideo_disable);
		fprintf(stderr, "Video AGC               : %lu\n", cci_info.Video_agc);
		fprintf(stderr, "Video CGMSA             : %lu\n", cci_info.Video_CGMSA);
		fprintf(stderr, "Digital Video disable   : %d\n", cci_info.DigitalVideo_disable);
		fprintf(stderr, "Analog Video Constraint : %d\n", cci_info.AnalogVideo_imageConstraint);
		fprintf(stderr, "HDCP Enable             : %d\n", cci_info.HDCP_Enable);
	}
}
#endif
