/*****************************************
 Copyright © 2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#include "../rua/include/rua.h"
#include "parsemp4dsi.h"

#define DBG_MAX_STRING 2000

#if 0
#define TRACE ENABLE
#else
#define TRACE DISABLE
#endif


//MPEG 4 visual object defines
#define VIDEO_OBJECT_SEQUENCE_START_CODE        0x000001B0      // reserved in Mpeg2
#define VIDEO_OBJECT_SEQUENCE_END_CODE          0x000001B1      // reserved in Mpeg2
#define USER_DATA_START_CODE                    0x000001B2      // same as Mpeg2
#define GROUP_VOP_START_CODE                    0x000001B3      // SEQUENCE_HEADER for Mpeg2
#define VIDEO_SESSION_ERROR_CODE                0x000001B4      // SEQUENCE_ERROR_CODE for Mpeg2
#define VISUAL_OBJECT_START_CODE                0x000001B5      // EXTENSION_START_CODE for Mpeg2
#define VIDEO_OBJECT_START_CODE_BEGIN           0x00000100      // ??
#define VOP_START_CODE                          0x000001B6      // reserved in Mpeg2
// 0x000001B6 - 0x000001B9 reserved for Mpeg4
#define FACE_OBJECT_START_CODE                  0x000001BA      // PACK_START_CODE for Mpeg2
#define FACE_OBJECT_PLANE_START_CODE            0x000001BB      // SYSTEM_START_CODE for Mpeg2
#define MESH_OBJECT_START_CODE                  0x000001BC      // PROGRAM_STREAM_MAP for Mpeg2
#define MESH_OBJECT_PLANE_START_CODE            0x000001BD      // PRIVATE_STREAM_1 for Mpeg2
#define STILL_TEXTURE_OBJECT_START_CODE         0x000001BE      // PADDING_STREAM for Mpeg2
#define TEXTURE_SPATIAL_LAYER_START_CODE        0x000001BF      // PRIVATE_STREAM_2 for Mpeg2
#define TEXTURE_SNR_LAYER_START_CODE            0x000001C0      // AUDIO_STREAM for Mpeg2
// 0x000001C1 - 0x000001C5 reserved for Mpeg4
// TBD system start codes 0x000001C6 - 0x000001FF	// AUDIO_STREAM for Mpeg2


struct BitStreamParserContext {

	RMuint32 m_incnt;
	RMuint8 *m_rdbfr;
	RMuint32 m_rdbfr_length;
	RMuint8 *m_rdptr;
	RMuint8 *m_rdmax;
	RMuint32 m_bitcnt;
	RMuint32 m_bfr;
	
};

// return next n bits (right adjusted) without advancing
static RMuint32 hwl_showbits (struct BitStreamParserContext *pContext, RMuint32 n)
{
	return pContext->m_bfr >> (32-n);
}

// advance by n bits
static void hwl_flushbits (struct BitStreamParserContext *pContext, RMuint32 n, RMuint32 *Err)
{
	RMuint32 incnt;

	if(n<=31)
		pContext->m_bfr <<= n;
	else
		pContext->m_bfr = 0;

	incnt = pContext->m_incnt -= n;
	if (incnt <= 24)
	{
		if (pContext->m_rdptr < pContext->m_rdbfr + (pContext->m_rdbfr_length - 4))
		{
			do
			{
				pContext->m_bfr |= *(pContext->m_rdptr++) << (24 - incnt);
				incnt += 8;
			}
			while (incnt <= 24);
		}
		else
		{
			do
			{
				if (pContext->m_rdptr >= pContext->m_rdbfr + pContext->m_rdbfr_length)
				{
					(*Err)++;
					pContext->m_bfr |= 0 << (24 - incnt);
				}
				else
					pContext->m_bfr |= *(pContext->m_rdptr++) << (24 - incnt);
				incnt += 8;
			}
			while (incnt <= 24);
		}
		pContext->m_incnt = incnt;
	}
}


// return next n bits (right adjusted) + advance
static RMuint32 hwl_getbits (struct BitStreamParserContext *pContext, RMuint32 n, RMuint32 *Err)
{
	RMuint32 l;

	l = hwl_showbits (pContext, n);
	hwl_flushbits (pContext, n, Err);

	return l;
}

// hwl_align to the next byte
static void hwl_align (struct BitStreamParserContext *pContext, RMuint32 *Err)
{
	RMuint32 incnt;

	if (pContext->m_incnt != 32)
	{
		incnt = pContext->m_incnt % 8;
		hwl_flushbits (pContext, incnt, Err);
	}
}

static void BitStream (struct BitStreamParserContext *pContext, RMuint8 *pBuffer, RMuint32 Length, RMuint32 *Err)
{
	pContext->m_rdbfr = pBuffer;
	pContext->m_rdbfr_length = Length;
	pContext->m_incnt = 0;
	pContext->m_rdptr = pContext->m_rdbfr + pContext->m_rdbfr_length;
	pContext->m_rdmax = pContext->m_rdptr;
	pContext->m_bitcnt = 0;
	pContext->m_bfr = 0;
	pContext->m_rdptr = pContext->m_rdbfr;
	hwl_flushbits (pContext, 0, Err);
}


RMstatus ParseMP4VideoDSI(void* pDsiIn, RMuint32 dwDsiInSize, void* pDsiOut, RMuint32 dwDsiOutSize)
{
	RMuint32 Err = 0;
	RMuint32 vop_time_increment_resolution;
	RMuint32 temp;
	struct BitStreamParserContext BitParserContext;

 	if( (pDsiIn == NULL) || (dwDsiInSize == 0) )
	{
		RMDBGLOG((TRACE,"NULL DSI\n"));
		return RM_ERROR;
	}
 	if( (pDsiOut == NULL) || (dwDsiOutSize == 0) )
	{
		RMDBGLOG((TRACE, "NULL DSIout\n"));
		return RM_ERROR;
	}

	BitStream (&BitParserContext, (RMuint8*)pDsiIn, dwDsiInSize, &Err);

	temp = hwl_getbits(&BitParserContext,32,&Err);	// visual_object_sequence_start_code
	if( !Err && (temp != VIDEO_OBJECT_SEQUENCE_START_CODE) )
	{
		if( (temp & 0x000001E0) == VIDEO_OBJECT_START_CODE_BEGIN )	// vweb files
			goto VideoObjectLayer;

		if (temp == VISUAL_OBJECT_START_CODE)
			goto VisualObject;
	}
	if( Err || (temp != VIDEO_OBJECT_SEQUENCE_START_CODE) )
	{
		RMDBGLOG((TRACE, "NO VIDEO_OBJECT_SEQUENCE_START_CODE\n"));
		return RM_ERROR;
	}
	temp = hwl_getbits(&BitParserContext,8,&Err);	// profile_and_level_indication
	if( Err )
	{
		RMDBGLOG((TRACE, "NO profile_and_level_indication\n"));
		return RM_ERROR;
	}
	while( (temp = hwl_showbits(&BitParserContext,32)) != VISUAL_OBJECT_START_CODE)
	{
		temp = hwl_getbits(&BitParserContext,8,&Err);	// USER_DATA_START_CODE, user data
		if( Err )
		{
			RMDBGLOG((TRACE, "NO VISUAL_OBJECT_START_CODE\n"));
			return RM_ERROR;
		}
	}
	temp = hwl_getbits(&BitParserContext,32,&Err);//VISUAL_OBJECT_START_CODE

 VisualObject:
	temp = hwl_getbits(&BitParserContext,1,&Err);	// is_visual_object_identifier
	if( temp )
	{
		temp = hwl_getbits(&BitParserContext,4,&Err);	// visual_object_verid should be 1
		RMDBGLOG((TRACE, "visual_obj_verID %lu\n", temp));
		if (temp != 1)
			RMDBGLOG((ENABLE, "*** visual_obj_verID %lu != 1!!\n", temp));
		temp = hwl_getbits(&BitParserContext,3,&Err);	// visual_object_priority should be 1..7, no 0
		RMDBGLOG((TRACE, "visual_obj_priority %lu\n", temp));
	}
	temp = hwl_getbits(&BitParserContext,4,&Err);	// visual_object_type should be 1 = video id
	if( temp != 1 )
	{
		RMDBGLOG((TRACE, "NO visual_object_type == video id\n"));
		return RM_ERROR;
	}
	else
	{
		temp = hwl_getbits(&BitParserContext,1,&Err);	// video_signal_type
		if( temp == 1 )
		{
			temp = hwl_getbits(&BitParserContext,3,&Err);	// video_format
			RMDBGLOG((TRACE, "\tvideo_format %lu\n", temp));
			temp = hwl_getbits(&BitParserContext,1,&Err);	// video_range
			RMDBGLOG((TRACE, "\tvideo_range %lu\n", temp));
			temp = hwl_getbits(&BitParserContext,1,&Err);	// colour_description
			if( temp == 1 )
			{
				temp = hwl_getbits(&BitParserContext,8,&Err);	// colour_primaries
				RMDBGLOG((TRACE, "\t\tcolour_primaries %lu\n", temp));
				temp = hwl_getbits(&BitParserContext,8,&Err);	// transfer_characteristics
				RMDBGLOG((TRACE, "\t\ttransfer_characteristics %lu\n", temp));
				temp = hwl_getbits(&BitParserContext,8,&Err);	// matrix_coefficients
				RMDBGLOG((TRACE, "\t\tmatrix_coeff %lu\n", temp));
			}
		}
	}

	hwl_align(&BitParserContext,&Err);
	while( ((temp = hwl_showbits(&BitParserContext,32)) & 0x000001E0) != 0x00000100 )
	{
		temp = hwl_getbits(&BitParserContext,8,&Err);	// USER_DATA_START_CODE, user data
		if( Err )
		{
			RMDBGLOG((TRACE, "NO video object start code\n"));
			return RM_ERROR;
		}
	}
	temp = hwl_getbits(&BitParserContext,32,&Err);	// video_object_start_code
	RMDBGLOG((TRACE, "video_obj_start_code 0x%lx\n", temp));
VideoObjectLayer:
	temp = hwl_showbits(&BitParserContext,32);		// video_object_layer_start_code
	if( (temp & 0x000001E0) == 0x00000120 )
	{
		// short_video_header = 0
		temp = hwl_getbits(&BitParserContext,32,&Err);// video_object_layer_start_code
		RMDBGLOG((TRACE, "\tvideo_obj_layer_start_code 0x%lx\n", temp));
		temp = hwl_getbits(&BitParserContext,1,&Err);	// random_accessible_vol
		RMDBGLOG((TRACE, "\trandom_accessible %lu\n", temp));
		temp = hwl_getbits(&BitParserContext,8,&Err);	// video_object_type_indication
		RMDBGLOG((TRACE, "\tvideo_obj_type %lu\n", temp));
		temp = hwl_getbits(&BitParserContext,1,&Err);	// is_object_layer_identifier
		if( temp == 1 )
		{
			temp = hwl_getbits(&BitParserContext,4,&Err);	// video_object_layer_verid should be 1
			RMDBGLOG((TRACE, "\tvideo_obj_layer_verID %lu\n", temp));
			if (temp != 1)
				RMDBGLOG((ENABLE, "*** video_obj_layer_verID %lu != 1!!\n", temp));
			temp = hwl_getbits(&BitParserContext,3,&Err);	// video_object_layer_priority
			RMDBGLOG((TRACE, "\tvideo_obj_layer_priority %lu\n", temp));
		}
		temp = hwl_getbits(&BitParserContext,4,&Err);	// aspect_ratio_info
		RMDBGLOG((TRACE, "\taspect_ratio_info 0x%lx\n", temp));
		if( temp == 0xf )	// extended par
		{
			temp = hwl_getbits(&BitParserContext,8,&Err);	// par_width
			RMDBGLOG((TRACE, "\t\twidth %lu\n", temp));
			temp = hwl_getbits(&BitParserContext,8,&Err);	// par_height
			RMDBGLOG((TRACE, "\t\theight %lu\n", temp));
		}
		temp = hwl_getbits(&BitParserContext,1,&Err);	// vol_control_parameters
		if( temp == 1 )
		{
			temp = hwl_getbits(&BitParserContext,2,&Err);	// chroma_format
			RMDBGLOG((TRACE, "\t\tchroma_format %lu\n", temp));
			temp = hwl_getbits(&BitParserContext,1,&Err);	// low_delay
			RMDBGLOG((TRACE, "\t\tlow_delay %lu\n", temp));
			temp = hwl_getbits(&BitParserContext,1,&Err);	// vbv_parameters
			if( temp == 1 )
			{
				temp = hwl_getbits(&BitParserContext,15,&Err);// first_half_bit_rate
				RMDBGLOG((TRACE, "\t\t\tfirst_half_bit_rate %lu\n", temp));
				temp = hwl_getbits(&BitParserContext,1,&Err);	// marker_bit
				temp = hwl_getbits(&BitParserContext,15,&Err);// latter_half_bit_rate
				RMDBGLOG((TRACE, "\t\t\tlatter_half_bit_rate %lu\n", temp));
				temp = hwl_getbits(&BitParserContext,1,&Err);	// marker_bit
				temp = hwl_getbits(&BitParserContext,15,&Err);// first_half_vbv_buffer_size
				RMDBGLOG((TRACE, "\t\t\tfirst_half_vbv_buffer_size %lu\n", temp));
				temp = hwl_getbits(&BitParserContext,1,&Err);	// marker_bit
				temp = hwl_getbits(&BitParserContext,3,&Err);	// latter_half_vbv_buffer_size
				RMDBGLOG((TRACE, "\t\t\tlatter_half_vbv_buffer_size %lu\n", temp));
				temp = hwl_getbits(&BitParserContext,11,&Err);// first_half_vbv_occupancy
				RMDBGLOG((TRACE, "\t\t\tfirst_half_vbv_occupancy %lu\n", temp));
				temp = hwl_getbits(&BitParserContext,1,&Err);	// marker_bit
				temp = hwl_getbits(&BitParserContext,15,&Err);// latter_half_vbv_occupancy
				RMDBGLOG((TRACE, "\t\t\tlatter_half_vbv_occupancy %lu\n", temp));
				temp = hwl_getbits(&BitParserContext,1,&Err);	// marker_bit
			}
		}
		temp = hwl_getbits(&BitParserContext,2,&Err);	// video_object_layer_shape
		RMDBGLOG((TRACE, "\tvideo_obj_layer_shape %lu\n", temp));
		temp = hwl_getbits(&BitParserContext,1,&Err);	// marker_bit
		vop_time_increment_resolution = hwl_getbits(&BitParserContext,16,&Err);
		RMDBGLOG((ENABLE, ">>> DSI vop_time_increment_resolution = %d\n", vop_time_increment_resolution ));
		
		// for now the output is a RMuint32 = vop_time_increment_resolution
		*(RMuint32*)pDsiOut = vop_time_increment_resolution;

		temp = hwl_getbits(&BitParserContext,1,&Err);	// marker_bit
		temp = hwl_getbits(&BitParserContext,1,&Err);	// fixed_vop_rate
		if(temp)
		{
			temp = 0;
			while( vop_time_increment_resolution )
			{
				vop_time_increment_resolution >>= 1;
				temp++;
			}
			temp = hwl_getbits(&BitParserContext,temp,&Err);	// fixed_vop_time_increment
			RMDBGLOG((TRACE, "fixed_vop_rate %lu\n", temp));
		}
	}
	return RM_OK;
}

static void hackDSI(RMuint8 *data, RMuint32 *size, RMuint32 samplingfreq, RMuint32 *channelCount, RMuint8 *objectID)
{
	RMuint32 i;
	RMuint8 hackedDSI[5];
	RMDBGLOG((ENABLE, ">>>>> hacking DSI\n"));
	hackedDSI[0] = 0;
	hackedDSI[1] = 0;
	hackedDSI[2] = 0;
	hackedDSI[3] = 2;
	
	hackedDSI[4] = *objectID << 3;
	hackedDSI[4] |= samplingfreq >> 1;
	hackedDSI[5] = samplingfreq << 7;
	hackedDSI[5] |= 2 << 3;
	
	*channelCount = 2;
	
	*size = 6;
	for (i = 0; i < 6; i++)
		data[i] = hackedDSI[i];

	return;
}
	
RMstatus ParseMP4AudioDSI(RMuint8 *data, RMuint32 *size, RMuint32 *sampleRate, RMuint32 *channelCount, RMuint8 *objectID)
{
	RMuint8 samplingfreq;
	RMuint8 channels;
	RMuint32 Err = 0;
	RMuint32 temp;
	struct BitStreamParserContext BitParserContext;

	BitStream(&BitParserContext, (RMuint8*)data, *size, &Err);

	/* audio DSI read by hw decoder needs the size as header! This is not part of the MP4 DSI though */
	temp = hwl_getbits(&BitParserContext,5,&Err);
	*objectID = (RMuint8) temp;
	RMDBGLOG((ENABLE, "\tobj id %x\n", *objectID));

	temp = hwl_getbits(&BitParserContext,4,&Err);
	samplingfreq = (RMuint8) temp;
	RMDBGLOG((ENABLE, "\tsampling id %x\n", samplingfreq));

	if (samplingfreq == 0xf) {
		
		temp = hwl_getbits(&BitParserContext,24,&Err);
		*sampleRate = temp;
	}
	else {
		switch(samplingfreq) {
		case 0x0 :		//  96000
			*sampleRate = 96000;
			break;
		case 0x1 : 		//  88200
			*sampleRate = 88200;
			break;
		case 0x2 : 		//  64000
			*sampleRate = 64000;
			break;
		case 0x3 : 		// 48000
			*sampleRate = 48000;
			break;
		case 0x4 : 		//  44100										
			*sampleRate = 44100;
			break;
		case 0x5 : 		//  32000
			*sampleRate = 32000;
			break;
		case 0x6 : 		//  24000
			*sampleRate = 24000;
			break;
		case 0x7 : 		//  22050
			*sampleRate = 22050;
			break;
		case 0x8 : 		//  16000
			*sampleRate = 16000;
			break;
		case 0x9 : 		//  12000
			*sampleRate = 12000;
			break;
		case 0xa : 		//  11025
			*sampleRate = 11025;
			break;
		case 0xb : 		//  8000
			*sampleRate = 8000;
			break;
		default :		//  44100
			*sampleRate = 44100;
			break;
		}
	}

	RMDBGLOG((ENABLE, "\tsampling rate %lx(%ldHz)\n", *sampleRate, *sampleRate));

	temp = hwl_getbits(&BitParserContext,4,&Err);
	channels = (RMuint8) temp;

	*channelCount = (RMuint32) channels;


	if (*channelCount == 7) {
		*channelCount = 8;
	}else if (*channelCount == 0) { //number of channels is in Program_config_element
		RMDBGLOG((ENABLE,"number of channels is in Program_Config_Element\n"));
		if ((*objectID <= 7) && (*objectID != 5)) {
			//GASpecificConfig

			RMbool flag;
			
			temp = hwl_getbits(&BitParserContext,1,&Err); //frameLengthFlag
			flag = (temp != 0) ? TRUE : FALSE;
			
			temp = hwl_getbits(&BitParserContext,1,&Err); //dependsOnCoreCoder
			flag = (temp != 0) ? TRUE : FALSE;

			if (flag) {
				temp = hwl_getbits(&BitParserContext,14,&Err); //coreCoderDelay
				RMDBGLOG((ENABLE, "coreCoderDelay: 0x%lx\n", temp));
			}

			temp = hwl_getbits(&BitParserContext,1,&Err); //extensionFlag
			flag = (temp != 0) ? TRUE : FALSE;

			if (*channelCount == 0) {
				// ProgramConfigElement
				temp = hwl_getbits(&BitParserContext,4,&Err); //element_instance_tag
				RMDBGLOG((ENABLE, "element_instance_tag: 0x%lx\n", temp));

				temp = hwl_getbits(&BitParserContext,2,&Err); //obj_type
				RMDBGLOG((ENABLE, "obj_type: 0x%lx\n", temp));

				temp = hwl_getbits(&BitParserContext,4,&Err); //sampling_freq_index
				RMDBGLOG((ENABLE, "samplingFreqIndex: 0x%lx\n", temp));
				if (temp != (RMuint32)samplingfreq) {
					RMDBGLOG((ENABLE, ">>>>> Error: PCE samplingfreq != DSI samplingfreq, hacking DSI\n"));

					hackDSI(data, size, samplingfreq, channelCount, objectID);

				}
			}

			if ((*objectID == 6) || (*objectID == 20)) {
				RMDBGLOG((ENABLE, "layerNr not supported\n"));
			}

			if (flag) { //extensionFlag
				RMDBGLOG((ENABLE, "extensionFlag not supported\n"));
			}

		}
	}

	RMDBGLOG((ENABLE, "\tchannels %lx\n", *channelCount));


	return RM_OK;
}

