/*
 *
 * Copyright (c) Sigma Designs, Inc. 2002. All rights reserved.
 *
 */


#include "../samples/sample_os.h"

#define ALLOW_OS_CODE 1
#include "../dcc/include/dcc.h"
#include "../rmlibcw/include/rmfile.h"
#include "../samples/common.h"
#include "../rmsoftmixer/include/rmsoftmixer.h"
#include "../samples/command_ids.h"

#define KEY_CMD_FULLSCREEN   'F'

#undef RMFEATURE_HAS_VIDEOPLANE /* defined in rmfeatures.h but not yet implemented on this branch */

#define COMMON_TIMEOUT_US	10000
#define DMA_BUFFER_SIZE_LOG2	12
#define DMA_BUFFER_COUNT	12

#define VIDEO_FIFO_SIZE		(1024*1024)
#define XFER_FIFO_COUNT		(32)

#define KEYFLAGS (SET_KEY_DISPLAY | SET_KEY_PLAYBACK | SET_KEY_DEBUG)
#define ALLOW_OS_CODE 1

#define MAX_TASK_COUNT	20

struct task_context {
	RMuint32 id;
	struct RUABufferPool *pDMA;
	RMuint8 *buf;
	RMbool buffer_used;
	RMfile file;
	RMuint32 byte_counter;
	RMstatus file_status;
	RMuint32 nTimes;
	RMbool sync_timer;
	struct emhwlib_info send_info;

	struct rmsmx_window smx_window;
	struct rmsmx_window smx_thumb_window;

	RMbool smx_eos_wait;
};


enum mosaic_layout_mode{
	mosaic_portrait_layout,
	mosaic_landscape_layout,
	mosaic_square_layout
};

static struct RM_PSM_Context PSMcontext;

RMuint32			task_count = 0;
static struct task_context	task_list[MAX_TASK_COUNT];
static struct dcc_context	dcc_info[MAX_TASK_COUNT] = { {0, }, {0, } };
static struct dcc_context	*pdcc_info[MAX_TASK_COUNT];

static struct playback_cmdline	*play_opt;
static struct display_cmdline	*disp_opt;
static struct video_cmdline	*video_opt;

static struct playback_cmdline	playback_options[MAX_TASK_COUNT]; /*access through play_opt*/
static struct display_cmdline 	display_options[MAX_TASK_COUNT];/*access through disp_opt*/
static struct video_cmdline	video_options[MAX_TASK_COUNT]; /*access through video_opt*/

static RMsmx smx;
static enum mosaic_layout_mode layout_mode = mosaic_portrait_layout;

#ifdef RMFEATURE_HAS_GRAPHACC_CSCONV
static enum EMhwlibSamplingMode sampling_mode = EMhwlibSamplingMode_422;
#else
static enum EMhwlibSamplingMode sampling_mode = EMhwlibSamplingMode_444;
#endif


static void show_usage(char *progname)
{
	show_playback_options();
	show_display_options();
	show_video_options();
	fprintf(stderr, "MOSAIC OPTIONS (default values inside brackets)\n"
		"\t-layout layout_mode: Selects the mosaic's layout mode \n"
		"\t\t[portrait] landscape square \n"
		"\t-sampling sampling_mode: Selects the mosaic's sampling mode \n"
		"\t\t[422] 444 \n"

		);
	fprintf(stderr, "--------------------------------\n");
	fprintf(stderr, "Minimum cmd line: %s  <filename> \n", progname);
	fprintf(stderr, "--------------------------------\n");

	exit(1);
}

static void parse_cmdline(int argc, char *argv[])
{
	int i;
	RMstatus err;
	
	if(task_count == 0) {
		play_opt = &playback_options[0];
		disp_opt = &display_options[0];
		video_opt = &video_options[0];
		task_list[0].id = 0;
		
	}

	if (argc < 2) 
		show_usage(argv[0]);
	
	i = 1;
	while ((argc > i)) {
		if (argv[i][0] != '-') {
			if (play_opt->filename == NULL) {
				play_opt->filename = argv[i];
				i++;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-task")) {
			if (argc > i+1) {
				RMuint32 j = 0, task_index;
				task_index = strtol(argv[i+1], NULL, 10);
				i+=2;
				if (task_count > MAX_TASK_COUNT)
					show_usage(argv[0]);
				for (j=0; j < task_count; j++) {
					if( task_index != task_list[j].id)
						continue;
				}
				if ( (task_count==0) || (j >= task_count)) {
					fprintf(stderr, "initing %ld\n", task_count);
					play_opt = &playback_options[task_count];
					disp_opt = &display_options[task_count];
					video_opt = &video_options[task_count];
					task_list[task_count].id = task_index;
					task_count++;
					
				}
			}
			else
				show_usage(argv[0]);
		}
#ifdef RMFEATURE_HAS_GRAPHACC_CSCONV
		else if ( ! strcmp(argv[i], "-sampling")) {
			if (argc > i+1) {
				if ( ! strcmp(argv[i+1], "422")){
					sampling_mode = EMhwlibSamplingMode_422; 
				}
				else if ( ! strcmp(argv[i+1], "444")){
					sampling_mode = EMhwlibSamplingMode_444; 
				}
				else
					show_usage(argv[0]);
			}
			else
				show_usage(argv[0]);
			i += 2;
		}
#endif
		else if ( ! strcmp(argv[i], "-layout")) {
			if (argc > i+1) {
				if ( ! strcmp(argv[i+1], "square")){
					layout_mode = mosaic_square_layout;
				}
				else if ( ! strcmp(argv[i+1], "landscape")){
					layout_mode = mosaic_landscape_layout;
				}
				else if ( ! strcmp(argv[i+1], "portrait")){
					layout_mode = mosaic_portrait_layout;
				}
				else
					show_usage(argv[0]);
			}
			else
				show_usage(argv[0]);
			i += 2;
		}

		else {
			err = parse_playback_cmdline(argc, argv, &i, play_opt);
			if (err == RM_ERROR) 
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_display_cmdline(argc, argv, &i, disp_opt);
			if (err == RM_ERROR) 
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_video_cmdline(argc, argv, &i, video_opt);
			if (RMFAILED(err))
				show_usage(argv[0]);
		}
	}

	if (play_opt->filename == NULL)
		show_usage(argv[0]);
	
	if(task_count == 0) {
		task_count = 1;
	}
}




int main(int argc, char *argv[])
{
	RMstatus err;
	struct DCC *pDCC = NULL;
	struct RUA *pRUA = NULL;
	/* each task can only wait on one event */
	/* the event_list[MAX_TASK_COUNT] entry is for next_picture event */
	struct RUAEvent event_list[MAX_TASK_COUNT+1];
	struct dh_context dh_info[MAX_TASK_COUNT] = {{0,},};
	RMuint32 i, n = 0, m = 0;
	static struct RM_PSM_Actions actions;
	struct EMhwlibTVFormatAnalog tv_format;

	RMuint32 col_no = 0; /* number of windows on a row */
	RMuint32 row_no = 0; /* number of windows on a column */


	RMuint32 mosaic_width; /* width of the mosaic in pixels */
	RMuint32 mosaic_height; /* height of the mosaic in pixels */

	RMbool fullscreen = FALSE;

	for (i=0; i< MAX_TASK_COUNT; i++) {
		play_opt = &playback_options[i];
		disp_opt = &display_options[i];
		video_opt = &video_options[i];

		init_display_options(disp_opt);
		init_video_options(video_opt);
		init_playback_options(play_opt);
		disp_opt->dh_info = &dh_info[i];
		video_opt->display_cc = FALSE; /* we cannot display multiple cc streams! */
		pdcc_info[i] = &dcc_info[i];
	}
	
	parse_cmdline(argc, argv);
	/* use the options parsed before any '-task' tag as global options */
	play_opt = &playback_options[0];
	disp_opt = &display_options[0];
	video_opt = &video_options[0];



	while((n*m) < task_count){
		if(n == m)
			n++;
		else
			m++;
	}

	switch(layout_mode){
	case mosaic_square_layout:
		col_no = n;
		row_no = n;
		break;
	case mosaic_landscape_layout:
		col_no = m;
		row_no = n;
		break;
	case mosaic_portrait_layout:
		col_no = n;
		row_no = m;
		break;
	}




	err = RUACreateInstance(&pRUA, play_opt->chip_num);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error creating RUA instance! %d\n", err);
		return -1;
	}

	err = DCCOpen(pRUA, &pDCC);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error Opening DCC! %d\n", err);
		return -1;
	}

	err = DCCInitMicroCodeEx(pDCC, disp_opt->init_mode);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot initialize microcode %d\n", err);
		return -1;
	}

	for (i=0; i< task_count; i++) {
		dcc_info[i].chip_num = play_opt->chip_num;
		dcc_info[i].pRUA = pRUA;
		dcc_info[i].pDCC = pDCC;
		dcc_info[i].route = disp_opt->route;
		dcc_info[i].disp_info = NULL;
	}


	/* set first decoder in top corner, second decoder in bottom corner */
	set_display_out_window(&dcc_info[0]);
	
	err = apply_display_options(&dcc_info[0], disp_opt);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot set display options %d\n", err);
		goto cleanup;
	}
		
	err = RUAExchangeProperty(pRUA, DisplayBlock, RMDisplayBlockPropertyID_TVFormatAnalog, &(disp_opt->standard), sizeof(disp_opt->standard), &tv_format, sizeof(tv_format));
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot get TV format %d\n", err);
		goto cleanup;
	}
	mosaic_width = tv_format.ActiveWidth;
	mosaic_height = tv_format.ActiveHeight;
	fprintf(stderr, "active width %ld, active height %ld\n", tv_format.ActiveWidth, tv_format.ActiveHeight);

	/* open rmsmx */
	{
		struct rmsmx_config config;

		config.pDCC = pDCC;
		config.pRUA = pRUA;
		config.canvas_profile.SamplingMode = sampling_mode;

		if(sampling_mode == EMhwlibSamplingMode_422){
			
#ifdef RMFEATURE_HAS_VIDEOPLANE
			RMDBGLOG((ENABLE, "422 picture on DispVideoPlane\n"));
			config.canvas_scaler = DispVideoPlane;
#else
 			RMDBGLOG((ENABLE, "422 picture on DispMainVideoScaler\n"));
			config.canvas_scaler = DispMainVideoScaler;
#endif
			config.canvas_color = 0xff808080;
			config.canvas_profile.ColorMode = EMhwlibColorMode_VideoInterleaved;
		}
		else{
#ifdef RMFEATURE_HAS_VIDEOPLANE
 			RMDBGLOG((ENABLE, "444 picture on DispVideoPlane\n"));
			config.canvas_scaler = DispVideoPlane;
#else
 			RMDBGLOG((ENABLE, "444 picture on DispOSDScaler\n"));
			config.canvas_scaler = DispOSDScaler;
#endif
			config.canvas_color = 0xff808080;
			config.canvas_profile.ColorMode = EMhwlibColorMode_TrueColor;
			config.canvas_profile.SamplingMode = EMhwlibSamplingMode_444;
		}

		config.canvas_profile.ColorSpace = EMhwlibColorSpace_YUV_601;
		config.canvas_profile.ColorFormat = EMhwlibColorFormat_32BPP;
		config.canvas_profile.PixelAspectRatio.X = 1;
		config.canvas_profile.PixelAspectRatio.Y = 1;
		config.canvas_profile.Width = mosaic_width;
		config.canvas_profile.Height = mosaic_height;

		smx = RMSMXOpen(&config);
		if(smx == NULL){
			fprintf(stderr, "Cannot open the softmixer %d\n", err);
			return -1;
		}
		event_list[0].ModuleID = DisplayBlock;									
		event_list[0].Mask = EMHWLIB_DISPLAY_EVENT_ID(config.canvas_scaler); 
	}

	PSMcontext.validPSMContexts = task_count;
	PSMcontext.currentActivePSMContext = 0;
	PSMcontext.keyflags = KEYFLAGS;

	for (i=0; i< task_count; i++) {
		struct DCCStcProfile stc_profile;

		fprintf(stderr, "****************** open video %lx/%lx: instance = %lx ******************\n", i+1, task_count, task_list[i].id);
		play_opt = &playback_options[i];
		video_opt = &video_options[i];
		disp_opt = &display_options[i];

		task_list[i].pDMA = NULL;
		task_list[i].buf = NULL;
		task_list[i].buffer_used = FALSE;
		task_list[i].file = NULL;
		task_list[i].byte_counter = 0;
		task_list[i].smx_eos_wait = FALSE;
		task_list[i].send_info.ValidFields = 0;


		dcc_info[i].RM_PSM_commands = RM_PSM_ENABLE_PLAY;
		dcc_info[i].RM_PSM_commands |= RM_PSM_ENABLE_STOP;
		dcc_info[i].RM_PSM_commands |= RM_PSM_ENABLE_PAUSE;
		dcc_info[i].RM_PSM_commands |= RM_PSM_ENABLE_SPEED;

		err = apply_playback_options(&dcc_info[i], play_opt);
		if (RMFAILED(err)) {
			fprintf(stderr, "%lx_Cannot set playback options err=%d\n", task_list[i].id, err);
			goto cleanup;
		}

		/* open stc module */
		if (i == 0) {
			stc_profile.STCID = task_list[i].id;
			stc_profile.master = Master_STC;

			stc_profile.stc_timer_id = 2*(task_list[i].id);
			stc_profile.stc_time_resolution = 90000;

			stc_profile.video_timer_id = 2*task_list[i].id+1;
			stc_profile.video_time_resolution = 90000;
			stc_profile.video_offset = 0;

			stc_profile.audio_timer_id = NO_TIMER;
			stc_profile.audio_time_resolution = 0;
			stc_profile.audio_offset = 0;

			err = DCCSTCOpen(pDCC, &stc_profile, &dcc_info[i].pStcSource);
			if (RMFAILED(err)) {
				fprintf(stderr, "%lx_Cannot open stc module err=%d\n", task_list[i].id, err);
				goto cleanup;
			}
		}
		else {
			dcc_info[i].pStcSource = dcc_info[0].pStcSource;
		}

#if 1
		{
			/* open video decoder using DCCX functions */
			struct DCCXVideoProfile video_profile;
			enum EMhwlibVideoCodec vcodec;

			video_profile.ProtectedFlags = 0;
			video_profile.BitstreamFIFOSize = VIDEO_FIFO_SIZE;
			video_profile.XferFIFOCount = XFER_FIFO_COUNT;
			video_profile.PtsFIFOCount = 180;
			video_profile.InbandFIFOCount = 16;
			video_profile.XtaskInbandFIFOCount = 0;
			video_profile.MpegEngineID = video_opt->MpegEngineID;
			video_profile.VideoDecoderID = task_list[i].id;
			video_profile.SPUBitstreamFIFOSize = 0;
			video_profile.SPUXferFIFOCount = 0;
			video_profile.STCID = task_list[i].id;
	
			/* set codec based on command line options either "-pv" or "-vcodec" */
			if (video_opt->vcodec_max_width) {
				video_profile.Codec = video_opt->vcodec;
				video_profile.Profile = video_opt->vcodec_profile;
				video_profile.Level = video_opt->vcodec_level;
				video_profile.MaxWidth = video_opt->vcodec_max_width;
				video_profile.MaxHeight = video_opt->vcodec_max_height;
			}
			else {
				err = video_profile_to_codec(video_opt->Codec, &video_profile.Codec,
					&video_profile.Profile, &video_profile.Level, &video_profile.ExtraPictureBufferCount,
					&video_profile.MaxWidth, &video_profile.MaxHeight);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Unknown video decoder codec \n"));
					goto cleanup;
				}
			}

			/* set the extra pictures after the profile to codec conversion */
			video_profile.ExtraPictureBufferCount = video_opt->vcodec_extra_pictures;

			err = DCCXOpenVideoDecoderSource(pDCC, &video_profile, &dcc_info[i].pVideoSource);
			if (RMFAILED(err)) {
				fprintf(stderr, "%lx_Cannot open video decoder err=%d\n", task_list[i].id, err);
				goto cleanup;
			}
			
			vcodec = video_profile.Codec;
			err = DCCXSetVideoDecoderSourceCodec(dcc_info[i].pVideoSource, vcodec);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot set video decoder codec %d\n", err));
				goto cleanup;
			}
		}
#else
		{
			struct DCCVideoProfile video_profile;
			video_profile.MPEGProfile = video_opt->MPEGProfile;
			video_profile.BitstreamFIFOSize = VIDEO_FIFO_SIZE;
			video_profile.XferFIFOCount = XFER_FIFO_COUNT;
			video_profile.DemuxProgramID = task_list[i].id;
			video_profile.MpegEngineID = video_opt->MpegEngineID;
			video_profile.VideoDecoderID = task_list[i].id;
			video_profile.SPUBitstreamFIFOSize = 0;
			video_profile.SPUXferFIFOCount = 0;
			video_profile.STCID = task_list[i].id;

			err = DCCOpenVideoDecoderSource(pDCC, &video_profile, &dcc_info[i].pVideoSource);
			if (RMFAILED(err)) {
				fprintf(stderr, "%lx_Cannoth open video decoder err=%d\n", task_list[i].id, err);
				goto cleanup;
			}

			err = DCCSetVideoDecoderSourceCodec(dcc_info[i].pVideoSource, video_opt->Codec);
			if (RMFAILED(err)) {
				fprintf(stderr, "%lx_Cannot set video decoder codec err=%d\n", task_list[i].id, err);
				goto cleanup;
			}
		}
#endif

		err = DCCGetVideoDecoderSourceInfo(dcc_info[i].pVideoSource, &(dcc_info[i].video_decoder), &(dcc_info[i].spu_decoder), &(dcc_info[i].video_timer));
		if (RMFAILED(err)) {
			fprintf(stderr, "%lx_Error getting video decoder source information err=%d\n", task_list[i].id, err);
			goto cleanup;
		}
		dcc_info[i].SurfaceID = 0;
		dcc_info[i].state = RM_PLAYING;
		dcc_info[i].trickmode_id = RM_NO_TRICKMODE;
		dcc_info[i].seek_supported = FALSE;


	
		// apply the fixed vop rate if required
		err = apply_video_decoder_options(&dcc_info[i], video_opt);
		if (RMFAILED(err)) {
			fprintf(stderr, "%lx_Error applying video_decoder_options err=%d\n", task_list[i].id, err);
			goto cleanup;
		}


		/* dmapool must be created after the module open in case we do no copy transfers */
		err = RUAOpenPool(pRUA, dcc_info[i].video_decoder, DMA_BUFFER_COUNT, DMA_BUFFER_SIZE_LOG2, RUA_POOL_DIRECTION_SEND, &task_list[i].pDMA);
		if (RMFAILED(err)) {
			fprintf(stderr, "%lx_Error cannot open dmapool err=%d\n", task_list[i].id, err);
			goto cleanup;
		}

		task_list[i].file = open_stream(play_opt->filename, RM_FILE_OPEN_READ, 0);
		if (task_list[i].file == NULL) {
			fprintf(stderr, "%lx_Cannot open file %s\n", task_list[i].id, play_opt->filename);
			goto cleanup;
		}

		{
			struct rmsmx_source source;
			RMuint32 border_width = 2;
			RMuint32 col, row;
			row = i / col_no;
			col = i - row*col_no;
			fprintf(stderr, "i %ld col %ld row %ld\n", i, col, row);
			DCCSTCGetModuleId(dcc_info[i].pStcSource, &source.stc_id);
			source.decoder_id = dcc_info[i].video_decoder;

/* 			task_list[i].smx_thumb_window.x = 560; */
/* 			task_list[i].smx_thumb_window.y = 42; */
/* 			task_list[i].smx_thumb_window.width = 100; */
/* 			task_list[i].smx_thumb_window.height = 75; */
/* 			task_list[i].smx_thumb_window.border_width = 2; */
/* 			task_list[i].smx_thumb_window.border_color = 0xff808080; */

			task_list[i].smx_window.x = border_width + col*mosaic_width/col_no;
			task_list[i].smx_window.y = border_width + row*mosaic_height/row_no;
			task_list[i].smx_window.width = mosaic_width/col_no - 2*border_width;
			task_list[i].smx_window.height = mosaic_height/row_no - 2*border_width;
			task_list[i].smx_window.border_width = border_width;
			task_list[i].smx_window.border_color = 0xffff8023;

			fprintf(stderr, "x %ld y %ld  w %ld  h %ld\n",
				task_list[i].smx_window.x,
				task_list[i].smx_window.y,
				task_list[i].smx_window.width,
				task_list[i].smx_window.height
				);
						
			err = RMSMXSetOutputWindow(smx, &(task_list[i].smx_window), i);
			if(RMFAILED(err)){
				fprintf(stderr, "Error while setting the output window\n");
				goto cleanup;
			}
				
			RMSMXSetInputSource(smx, &source, i);
			if(RMFAILED(err)){
				fprintf(stderr, "Error while setting the input source\n");
				goto cleanup;
			}

		}

	}



	display_key_usage(KEYFLAGS);

	RMTermInit(TRUE);    // don't allow ctrl-C and the like ...
	RMSignalInit(NULL, NULL);  // ... but catch other termination signals to call RMTermExit()
			
	for (i=0; i< task_count; i++) {
		if (RMSeekFile(task_list[i].file, 0, RM_FILE_SEEK_START) == RM_ERRORSEEKFILE) {
			fprintf(stderr, "%lx_seeking file to beginning\n", task_list[i].id);
			goto cleanup;
		}
		task_list[i].byte_counter = 0;
		task_list[i].buf = NULL;
		
		if (task_list[i].nTimes) {	/* first time in loop no need to stop */
			DCCSTCStop(dcc_info[i].pStcSource);
			err = DCCStopVideoSource(dcc_info[i].pVideoSource, DCCStopMode_LastFrame);
			if (RMFAILED(err)) {
				fprintf(stderr, "%lx_Cannot stop video decoder err=%d\n", task_list[i].id, err);
				goto cleanup;
			}
			err = RMSMXFlushSlot(smx, i);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "[%ld] Cannot flush video display fifo err %d\n",i, err));
				goto cleanup;
			}
			err = RUAResetPool(task_list[i].pDMA);	/* needed for no dram copy version on standalone */
			if (RMFAILED(err)) {
				fprintf(stderr, "%lx_Error cannot reset dmapool\n", task_list[i].id);
				goto cleanup;
			}
		}
		
		DCCSTCSetSpeed(dcc_info[i].pStcSource, play_opt->speed_N, play_opt->speed_M);
	
		err = DCCPlayVideoSource(dcc_info[i].pVideoSource, DCCVideoPlayFwd);
		if (RMFAILED(err)) {
			fprintf(stderr, "%lx_Cannot play video decoder %d\n", task_list[i].id, err);
			goto cleanup;
		}

		DCCSTCSetTime(dcc_info[i].pStcSource,  0, 90000);
		DCCSTCPlay(dcc_info[i].pStcSource);
		RM_PSM_SetState(&(PSMcontext), pdcc_info, RM_PSM_Playing);
	}

	/* we need to refresh once before entering the loop to trigger the next_pictures events 
	 * RMSMXRefresh() might return pending here because RMSMXOpen() uses the GFXEngine to draw the 
	 * background. RMSMXRefresh() requires the engine not to be busy.
	 */
	do{
		err = RMSMXRefresh(smx);
		if(err == RM_PENDING){
			struct RUAEvent evt;
			evt.ModuleID = GFXEngine;
			evt.Mask = RUAEVENT_COMMANDCOMPLETION;
			RUAWaitForMultipleEvents(pRUA, &evt, 1, 10000, NULL);
		}
	}while(err == RM_PENDING);

	while (1) {
		RMuint32 count;
		struct InbandCommand_type InbandCmd;
		RMuint32 event_index, nEvents;
		
		nEvents = 1; /* the wait for picture event */
		
		for (i=0; i< task_count; i++) {
			/* check if the task finished */
			if(task_list[i].smx_eos_wait)
				continue;
			if ((playback_options[i].loop_count == 0) && (playback_options[i].infinite_loop == FALSE))
				continue;

			if(task_list[i].sync_timer){
				RMuint64 stc_time64;
				RMuint32 timescale;
				task_list[i].sync_timer = FALSE;
				DCCSTCGetTimeResolution(dcc_info[i].pStcSource, DCC_Video, &timescale);
				DCCSTCGetTime(dcc_info[i].pStcSource, &stc_time64, timescale);
				task_list[i].send_info.ValidFields = TIME_STAMP_INFO;
				task_list[i].send_info.TimeStamp = stc_time64;
			}
			
			if ((task_list[i].buf == NULL) && (task_list[i].buffer_used == FALSE)) {
				err = RUAGetBuffer(task_list[i].pDMA, &task_list[i].buf,  0);
				if(err != RM_OK) {
					/* no buffer prepare to wait */
					event_list[nEvents].ModuleID = dcc_info[i].video_decoder;
					event_list[nEvents].Mask = RUAEVENT_XFER_FIFO_READY;
					nEvents++;
				}
			}
			if (task_list[i].buf) {
				if (task_list[i].buffer_used == FALSE) {
					task_list[i].file_status = RMReadFile(task_list[i].file, task_list[i].buf, (1<<DMA_BUFFER_SIZE_LOG2), &count);
					task_list[i].buffer_used = TRUE;
					if (task_list[i].file_status == RM_ERRORREADFILE) {
						fprintf(stderr, "%lx_Error reading file\n", task_list[i].id);
						goto cleanup;
					}
		
					if (task_list[i].file_status == RM_ERRORENDOFFILE) {
						/*fprintf(stderr, "%lx_EndOfFile\n", task_list[i].id);*/
					
						RUAReleaseBuffer(task_list[i].pDMA, task_list[i].buf);
						task_list[i].buf = NULL;
						/*send eos inband command */
						InbandCmd.Tag = EMhwlibInbandCommand_EOS | INBAND_COMMAND_TYPE_BYTECOUNT | INBAND_COMMAND_NO_COORDINATE | INBAND_COMMAND_ACTION_CONTINUE;
						RUASetProperty(pRUA, dcc_info[i].video_decoder, RMGenericPropertyID_InbandCommand, &InbandCmd, sizeof(InbandCmd), 0);
						continue;
					}
				}
				
				
				err = RUASendData(pRUA, dcc_info[i].video_decoder, task_list[i].pDMA, task_list[i].buf, 
						  count, &(task_list[i].send_info), sizeof(task_list[i].send_info));
				if (err == RM_OK) {
					if(task_list[i].send_info.ValidFields == TIME_STAMP_INFO){
						fprintf(stderr, "set video pts to %lld at bc=%ld\n", task_list[i].send_info.TimeStamp, task_list[i].byte_counter);
					}
					task_list[i].send_info.ValidFields = 0;
					task_list[i].byte_counter += count;
					RUAReleaseBuffer(task_list[i].pDMA, task_list[i].buf);
					task_list[i].buf = 0;
					task_list[i].buffer_used = FALSE;
				}
				else {
					event_list[nEvents].ModuleID = dcc_info[i].video_decoder;
					event_list[nEvents].Mask = RUAEVENT_XFER_FIFO_READY;
					nEvents++;
				}

			}
		}
		for (i=0; i< task_count; i++) {
			/* add eos event in list */
			if (task_list[i].file_status == RM_ERRORENDOFFILE) {
				event_list[nEvents].ModuleID = dcc_info[i].video_decoder;
				event_list[nEvents].Mask = RUAEVENT_INBAND_COMMAND;
				nEvents++;
			}
		}

check_other_events:
		event_index = task_count+1;

		/*each task can add as much as one event */
		if (nEvents == task_count + 1) {
		all_blocked:
			/*all tasks are blocked: wait until something happens */
			while ( RUAWaitForMultipleEvents(pRUA, event_list, nEvents, COMMON_TIMEOUT_US, &event_index) != RM_OK) {
				goto get_command;
			}
			nEvents--;
		}
		else {
			/*as long as one task can go on, don't wait too much for the other events */
			if(RUAWaitForMultipleEvents(pRUA, event_list, nEvents, 0, &event_index) != RM_OK){
				/* no events to process */
				goto get_command;
			}
		}



		/*** PROCESS EVENTS *****/
		if ((event_index == 0)){ 
			/* next picture event recieved: refresh the mosaic */

			err = RMSMXRefresh(smx);
				 
			for(i = 0; i < task_count; i++){
				if(task_list[i].smx_eos_wait){
					struct rmsmx_slot_status status;
					RMSMXGetSlotStatus(smx, &status, i);
					if(status.starved){
						task_list[i].smx_eos_wait = FALSE;
						task_list[i].nTimes++;
						fprintf(stderr, "%lx_WaitForEOS OK %ld times bc=%ld\n", task_list[i].id, task_list[i].nTimes, task_list[i].byte_counter);
						if (playback_options[i].loop_count > 0)
							playback_options[i].loop_count --;
						/* restart the playback if necessary */
						if ((playback_options[i].loop_count > 0) || (playback_options[i].infinite_loop)) {
							/* restart playback */
							/* fprintf(stderr, "%lx_Restart playback\n", task_list[i].id); */
							if (RMSeekFile(task_list[i].file, 0, RM_FILE_SEEK_START) == RM_ERRORSEEKFILE) {
								fprintf(stderr, "%lx_Error seeking file to beginning\n", task_list[i].id);
								goto cleanup;
							}
							task_list[i].buf = NULL;
							task_list[i].buffer_used = FALSE;
							task_list[i].byte_counter = 0;
							task_list[i].sync_timer = TRUE;
							if (dcc_info[i].state == RM_PLAYING_TRICKMODE) {
								dcc_info[i].state = RM_PLAYING;
								dcc_info[i].trickmode_id = RM_NO_TRICKMODE;
							}
							
							err = DCCStopVideoSource(dcc_info[i].pVideoSource, DCCStopMode_LastFrame);
							if (RMFAILED(err)) {

								fprintf(stderr, "%lx_Cannot stop video decoder err=%d\n", task_list[i].id, err);
								goto cleanup;
							}
							err = RMSMXFlushSlot(smx, i);
							if (RMFAILED(err)) {
								RMDBGLOG((ENABLE, "[%ld] Cannot flush video display fifo err %d\n",i, err));
								goto cleanup;
							}
							err = RUAResetPool(task_list[i].pDMA);	/* needed for no dram copy version on standalone */
							if (RMFAILED(err)) {
								fprintf(stderr, "%lx_Error cannot reset dmapool\n", task_list[i].id);
								goto cleanup;
							}
							err = DCCPlayVideoSource(dcc_info[i].pVideoSource, DCCVideoPlayFwd);
							if (RMFAILED(err)) {
								fprintf(stderr, "%lx_Cannot play video decoder %d\n", task_list[i].id, err);
								goto cleanup;
							}
						}
						else if (playback_options[i].loop_count == 0) {
							/* check if all tasks are done */
							RMuint32 done_tasks = 0;
							RMSMXSetInputSource(smx, NULL, i);
							for (i=0; i< task_count; i++) {
								play_opt = &playback_options[i];
								if ((play_opt->loop_count > 0) || (play_opt->infinite_loop))
									done_tasks++;
							}
							if(done_tasks == 0)
								goto cleanup;
						}
						break;
					}
				}
			}
		}
		else if (event_index < (task_count+1)) {
			nEvents--;
			/* got the videodecoder eos */
			if(event_list[event_index].Mask == RUAEVENT_INBAND_COMMAND){
				for(i = 0; i < task_count; i++){
					if(event_list[event_index].ModuleID == dcc_info[i].video_decoder){
						break;
					}
				}
				/* 				if(i == task_count){/\*error*\/} */
				task_list[i].smx_eos_wait = TRUE;
			}
		}
		goto check_other_events;
		
	get_command:
		{
			RMuint32 decoder, new_decoder;
			struct rmsmx_window *win  = NULL;

			decoder = PSMcontext.currentActivePSMContext;
			if(decoder && (!fullscreen)){
				win = &(task_list[decoder - 1].smx_window);
			}

			err = process_command(&PSMcontext, pdcc_info, &actions);
			if (RMFAILED(err)) {
				fprintf(stderr, "Error while processing key %d\n", err);
				goto cleanup;
			}
			switch(actions.cmd){
#if 0
			case KEY_CMD_FULLSCREEN:
				if(decoder != 0){
					if (!fullscreen){
						fprintf(stderr, "going fullscreen\n");
						for(i = 0; i < task_count; i++){
							RMSMXSetOutputWindow(smx, &(task_list[i].smx_thumb_window), i);
						}
						
						RMSMXSetInputSource(smx, NULL, decoder - 1);
						RMSMXSetCanvasColor(smx, 0x00404020);
						
						err = DCCSetSurfaceSource(pDCC, DispMainVideoScaler, dcc_info[decoder - 1].pVideoSource);
						if (RMFAILED(err)) {
							fprintf(stderr, "%lx_Cannot set the surface source err=%d\n", task_list[decoder - 1].id, err);
							goto cleanup;
						}
					}
					else{
						struct rmsmx_source source;
						fprintf(stderr, "ungoing fullscreen\n");
						err = DCCSetSurfaceSource(pDCC, DispMainVideoScaler, NULL);
						if (RMFAILED(err)) {
							fprintf(stderr, "%lx_Cannot set the surface source err=%d\n", task_list[decoder - 1].id, err);
							goto cleanup;
						}
						usleep(40000);
						DCCSTCGetModuleId(dcc_info[decoder - 1].pStcSource, &source.stc_id);
						source.decoder_id = dcc_info[decoder - 1].video_decoder;
						RMSMXSetInputSource(smx, &source, decoder - 1);
						RMSMXSetCanvasColor(smx, 0xff808080);
						
						for(i = 0; i < task_count; i++){
							RMSMXSetOutputWindow(smx, &(task_list[i].smx_window), i);
						}
					}
					fullscreen = !fullscreen;
				}
				break;
#endif
			case KEY_CMD_PLUS_OUTPUT_SIZE:
				for(i = 0; i < task_count; i++){
					if(decoder == i+1 || decoder == 0){
						win = &(task_list[i].smx_window);
						if((win->x > 10 + win->border_width) &&
						   (win->x > 10 + win->border_width) &&
						   (win->width + win->x + 20 + 2*win->border_width < 720) &&
						   (win->height + win->y + 20 + 2*win->border_width < 480)){
							win->x -= 10;
							win->y -= 10;
							win->width += 20;
							win->height += 20;
							RMSMXSetOutputWindow(smx, win, i);
						}
					}
				}
				break;
			case KEY_CMD_MINUS_OUTPUT_SIZE:
				for(i = 0; i < task_count; i++){
					if(decoder == i+1 || decoder == 0){
						win = &(task_list[i].smx_window);
						if((win->width > 20) && (win->height > 20)){
							win->x += 10;
							win->y += 10;
							win->width -= 20;
							win->height -= 20;
							RMSMXSetOutputWindow(smx, win, i);
						}
					}
				}
				break;
			case KEY_CMD_LEFT_OUTPUT:
				for(i = 0; i < task_count; i++){
					if(decoder == i+1 || decoder == 0){
						win = &(task_list[i].smx_window);

						if(win->x > 10 + win->border_width){
							win->x -= 10;
							RMSMXSetOutputWindow(smx, win, i);
						}
					}
				}
				break;
			case KEY_CMD_RIGHT_OUTPUT:
				for(i = 0; i < task_count; i++){
					if(decoder == i+1 || decoder == 0){
						win = &(task_list[i].smx_window);

						if(win->x + win->width + 2*win->border_width + 10 < 720){
							win->x += 10;
							RMSMXSetOutputWindow(smx, win, i);
						}
					}
				}
				break;
			case KEY_CMD_TOP_OUTPUT:
				for(i = 0; i < task_count; i++){
					if(decoder == i+1 || decoder == 0){
						win = &(task_list[i].smx_window);

						if(win->y > 10 + win->border_width){
							win->y -= 10;
							RMSMXSetOutputWindow(smx, win, i);
						}
					}
				}
				break;
			case KEY_CMD_BOTTOM_OUTPUT:
				for(i = 0; i < task_count; i++){
					if(decoder == i+1 || decoder == 0){
						win = &(task_list[i].smx_window);
						if(win->y + win->height + 2*win->border_width + 10 < 480){
							win->y += 10;
							RMSMXSetOutputWindow(smx, win, i);
						}
					}
				}
				break;

			case RM_DECODER_CHANGE:
				if(fullscreen){
					PSMcontext.currentActivePSMContext = decoder;
				 	break;
				}
				new_decoder = PSMcontext.currentActivePSMContext;
				if(new_decoder != decoder){
					for(i = 0; i < task_count; i++){
						if(decoder == i+1 || decoder == 0){							
							task_list[i].smx_window.border_width = 0;
							RMSMXSetOutputWindow(smx, &(task_list[i].smx_window), i);
						}
						if(new_decoder == i+1 || new_decoder == 0){						
							task_list[i].smx_window.border_width = 3;
							RMSMXSetOutputWindow(smx, &(task_list[i].smx_window), i);
					 	}
					}
				}
				break;
			case RM_STOP:
				for(i = 0; i < task_count; i++){
					if(decoder == i+1 || decoder == 0){
						err = RMSMXFlushSlot(smx, i);
						if (RMFAILED(err)) {
							RMDBGLOG((ENABLE, "[%ld] Cannot flush video display fifo err %d\n",i, err));
						}
						if(task_list[i].buf){
							RUAReleaseBuffer(task_list[i].pDMA, task_list[i].buf);
							task_list[i].buf = NULL;
						}
						task_list[i].sync_timer = TRUE;
					}
				}
				break;
			case RM_QUIT:
				goto cleanup;
				break;
			}
		
			if (decoder != 0) update_hdmi(&(dcc_info[decoder - 1]), disp_opt, NULL);
		}
		
		if(nEvents == task_count + 1){
			goto all_blocked;
		}
		
						
	}

 cleanup:
	RMTermExit();

	for (i=0; i< task_count; i++) {
					
		if(task_list[i].buf){
			RUAReleaseBuffer(task_list[i].pDMA, task_list[i].buf);
		}

		if (task_list[i].file != NULL){
			RMCloseFile(task_list[i].file);
		}
			
		if (dcc_info[i].pVideoSource) {
			err = DCCStopVideoSource(dcc_info[i].pVideoSource, DCCStopMode_LastFrame);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "[%ld] Cannot stop video decoder err %d\n",i, err));
			}
			
			err = RMSMXFlushSlot(smx, i);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "[%ld] Cannot flush video display fifo err %d\n",i, err));
			}
		}
	}

	/* 
	 * this also flushes the display fifo
	 * and needs to be done before closing the decoder
	 */
	RMSMXClose(smx);

	for (i=0; i< task_count; i++) {
		if (dcc_info[i].pVideoSource) {
			err = DCCCloseVideoSource(dcc_info[i].pVideoSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "[%ld] Cannot close video decoder err %d\n",i, err));
			}			
		}
		
		if (task_list[i].pDMA) {
			err = RUAClosePool(task_list[i].pDMA);
			if (RMFAILED(err)) {
				fprintf(stderr, "%lx_Error cannot close dmapool err=%d\n", task_list[i].id, err);
			}
		}
		clear_display_options(&dcc_info[i], disp_opt);
	}

	err = DCCClose(pDCC);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot close DCC %d\n", err);
	}

	err = RUADestroyInstance(pRUA);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot destroy RUA instance %d\n", err);
		return -1;
	}
	return 0;
}

