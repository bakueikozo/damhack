/*****************************************
 Copyright � 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   dvi_hdmi_internals.h
  @brief  DVI, HDMI, and CEA/EIA 861 implementation

  long description

  @author Christian Wolff
  @date   2007-04-18
*/

#ifndef __DVI_HDMI_INTERNALS_H__
#define __DVI_HDMI_INTERNALS_H__

#include "dvi_hdmi.h"

// TODO implement own SHA1 function, this one came from the PuTTY SSH client
#include "dss_sha.h"

#define EDID_BLOCKS 8  // how many EDID blocks to hold in pDH
#define EDID_SIZE 128

#define SRM_SIZE 5 * 1024

struct DH_I2C {
	RMuint32 I2C;
	struct EMhwlibI2CDeviceParameter dev;
};

enum DH_i2cdbgstate {
	DH_i2cdbgstate_idle = 0, 
	DH_i2cdbgstate_dispatch, 
	DH_i2cdbgstate_read_addr_hi, 
	DH_i2cdbgstate_read_addr_lo, 
	DH_i2cdbgstate_blockread_addr_hi, 
	DH_i2cdbgstate_blockread_addr_lo, 
	DH_i2cdbgstate_blockread_size_hi, 
	DH_i2cdbgstate_blockread_size_lo, 
	DH_i2cdbgstate_ddcread_addr_hi, 
	DH_i2cdbgstate_ddcread_addr_lo, 
	DH_i2cdbgstate_ddcread_size_hi, 
	DH_i2cdbgstate_ddcread_size_lo, 
	DH_i2cdbgstate_ddcwrite_addr_hi, 
	DH_i2cdbgstate_ddcwrite_addr_lo, 
	DH_i2cdbgstate_ddcwrite_data_hi, 
	DH_i2cdbgstate_ddcwrite_data_lo, 
	DH_i2cdbgstate_edidread_block_hi, 
	DH_i2cdbgstate_edidread_block_lo, 
	DH_i2cdbgstate_edidread_size_hi, 
	DH_i2cdbgstate_edidread_size_lo, 
	DH_i2cdbgstate_write_addr_hi, 
	DH_i2cdbgstate_write_addr_lo, 
	DH_i2cdbgstate_write_data_hi, 
	DH_i2cdbgstate_write_data_lo, 
	DH_i2cdbgstate_device_hi, 
	DH_i2cdbgstate_device_lo, 
	DH_i2cdbgstate_module, 
};

// Capabilities of a Transmitter (source) chip/part
struct DH_part_caps {
	RMuint32 HDMI;       // part supports HDMI (audio etc.) (set to HDMI version * 10)
	RMuint32 HDCP;       // part supports HDCP (set to HDCP version * 10)
	RMuint32 DeepColor;  // part supports this many bits per video component (8, 10, 12, 14, 16)
	RMbool DDC;          // part provides access to the DDC I2C bus
	RMbool GPIOReset;    // part requires hard reset via a GPIO pin
	RMbool Burst;        // part supports I2C burst read and write
	RMuint32 I2S2;       // maximum sample frequency for 2 channel I2S audio
	RMuint32 I2S8;       // maximum sample frequency for 8 channel I2S audio
	RMuint32 SPDIF;      // maximum sample frequency for S/P-DIF audio
	RMbool HBR;          // part supports HDMI 1.3 HighBitrateAudio
};

struct DH_control {
	struct RUA *pRUA;
	enum DH_vendor_parts part;  // "source"
	struct DH_part_caps part_caps;
	RMuint32 i2c_module;
	struct DH_I2C i2c_tx;   // Transmitter (DVI/HDMI chipset)
	struct DH_I2C i2c_tx2;  // Transmitter 2nd address
	struct DH_I2C i2c_rx;   // Receiver (DDC bus to the monitor, HDCP device)
	RMuint32 i2c_buf_module;
	struct DH_I2C i2c_bx;   // Buffer/Switch (DVI/HDMI chipset)
	enum DH_device_state state;            // State of the DVI/HDMI connector
	enum DH_connection cable;              // Are we connected? (Used for Hot Plug Detect)
	RMuint8 gpio_reset;
	RMuint32 info_frame_enable;             // See INFO_FRAME_xxxx flags
	RMuint32 VideoPixelClock;
	struct DH_AudioFormat AudioFormat;
	struct dss_key SRM_dss;
	RMuint8 SRM[SRM_SIZE];
	RMuint32 SRM_Size;
	RMbool CPDesired;
	RMbool SilentAuth;
	struct DH_DriverOptions DriverOptions;
	RMbool HDMI_mode;
	RMbool CEA_Support;       // EDID says, sink is HDMI, not DVI
	RMbool CEA_QuantSupport;  // EDID says, Q entry in AVI infor frame is supported
	RMuint16 HDMI_PhysAddr;
	RMbool HDMI_audio;
	enum DCCRoute route;
	enum DH_EDID_select EDID_select;
	RMuint32 EDID_selection;  // force mode to this entry from EDID short descriptor list, when EDID_select == DH_EDID_force
	RMuint32 EDID_vfreq;  // preferred vsync frequency (50, 59, 60 etc.)
	RMuint32 EDID_hsize;  // preferred horizontal active size
	RMuint32 EDID_vsize;  // preferred vertical active size
	RMbool EDID_intl;     // preferred interlaced (TRUE) / progressive (FALSE) mode
	RMuint64 EDID_force_mask;  // try these VICs first (bit 1 = VIC 1, bit 2 = VIC 2 etc.)
	RMuint64 EDID_exclude_mask; // never use these VICs
	RMuint32 EDID_max_pixclk;
	RMuint32 EDID_min_pixclk;
	RMuint32 EDID_max_hfreq;
	RMuint32 EDID_min_hfreq;
	RMuint32 EDID_max_vfreq;
	RMuint32 EDID_min_vfreq;
	RMbool RxPresent;     // True if a Rx signal has ever been detected on this connector
	RMbool RxLost;        // True if Rx signal went down while hot plug active
	RMbool Repeater;      // TRUE if Rx is repeater
	RMuint64 RepeaterTimeout;
	RMuint64 HDCPTimeout;
	RMuint32 AudioHeader;
	RMuint64 HotPlugLastCheck;
	RMuint64 IntegrityLastCheck;
	RMuint16 last_ri;
	RMbool Mute;
	RMuint32 TMDS_Threshold;
	enum GPIOId_type TMDS_GPIO;
	struct DH_HDMI_state HDMIState;
	RMbool HotPlugChanged;      // hardware state: HotPlug state has changed
	RMbool HotPlugState;        // hardware state: current HotPlug state
	RMbool HotPlugGuarded;
	RMuint64 HotPlugGuardTime;
	RMuint8 EDID[EDID_BLOCKS][EDID_SIZE];
	RMuint32 EDID_blocks;
	RMbool EDID_override;
	RMbool EDID_override_first;
	RMuint32 EDID_override_blocks;
	RMbool CheckClock;  // TRUE if input clock stability is polled by DHCheckHDMI()
	RMbool ForceCTS;
	RMuint8 audio_mode;
	RMbool GuardTMDS;  // if TRUE, prevent TMDS from being turned on until PStable
	RMbool RequestTMDS;  // if TRUE, app would like to enable TMDS after GuardTMDS = FALSE
	RMbool IgnoreStable;  // ignore p_stable between soft reset and TMDS enable
	RMbool RequestIntegrityCheck;  // if set, perform HDCP integrity check reasonably soon
	RMbool ForceIntegrityCheck;  // if set, perform HDCP integrity check as soon as possible
	RMbool HDCPKeySyncErrorPrev;
	enum EMhwlibColorSpace InputColorSpace;
	enum EMhwlibSamplingMode InputSamplingMode;
	RMuint32 InputComponentBitDepth;
	enum EMhwlibColorSpace OutputColorSpace;
	enum EMhwlibSamplingMode OutputSamplingMode;
	RMuint32 OutputComponentBitDepth;
	enum DH_i2cdbgstate i2cdbgstate;
	struct DH_I2C i2cdbg;
	RMuint8 i2cdbgaddr;
	RMuint8 i2cdbgsize;
	RMuint8 i2cdbgdata;
	RMuint32 i2cdbgdatasize;
	
	// ANX9030 state machine
	RMbool ANX_hdcp_auth_en;
	RMbool ANX_bksv_ready;
	RMbool ANX_hdcp_auth_pass;
	RMuint32 ANX_hdcp_auth_fail_counter;
	RMbool ANX_hdcp_encryption;
	RMbool ANX_send_blue_screen;
	RMbool ANX_hdcp_init_done;
	RMbool ANX_hdcp_wait_100ms_needed;
	RMbool ANX_auth_fully_pass;
	RMbool ANX_srm_checked;
	RMbool ANX_ksv_srm_pass;
};

struct DH_part_info {
	RMuint8 i2c_tx_pri_addr;     // Primary I2C device address of the transmitter chip
	RMuint8 i2c_tx_sec_addr;     // Secondary I2C device address of the transmitter chip
	RMuint8 i2c_2nd_offs;        // Offset from the first to the second device address, if any
	RMuint32 i2c_tx_speed_kHz;   // Speed, in kHz, for the I2C bus
	RMuint32 i2c_tx_delay_us;    // Delay, in microseconds, for the I2C bus
	RMuint32 i2c_rx_speed_kHz;   // Speed, in kHz, for the DDC I2C bus (HDCP Bcaps bit 4: 0=100kHz, 1=400kHz to dev 0x74)
	RMuint32 i2c_rx_delay_us;    // Delay, in microseconds, for the DDC I2C bus
	RMuint8 id_sub_address;      // Vendor/Device ID subaddress used for check part
	RMuint16 vendor_ID;          // 16 bit Vendor ID that should be read
	RMuint16 device_ID;          // 16 bit Device ID that should be read
	RMuint8 device_rev;          // specific revision of the device, or 0 for all
	RMascii *part_name;          // The name of the part
	struct DH_part_caps part_caps;
};

#endif // __DVI_HDMI_INTERNALS_H__

