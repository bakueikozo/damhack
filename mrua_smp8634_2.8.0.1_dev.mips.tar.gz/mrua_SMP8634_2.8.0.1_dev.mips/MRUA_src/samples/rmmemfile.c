/*****************************************
 Copyright © 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/


#include "../rmdef/rmdef.h"
#include "../rmlibcw/include/rmlibcw.h"
#include "rmmemfile.h"

struct rm_memory_file_cookie{
	RMuint8 *mem_base;
	RMuint32 size;
	RMint64 position;
	RMbool free_on_close;
};

static RMint32 rm_memory_file_read(void *cookie, RMuint8 *buffer, RMuint32 size);
static RMint32 rm_memory_file_write (void *cookie, const RMuint8 *buffer, RMuint32 size);
static RMint32 rm_memory_file_seek (void *cookie, RMint64 *position, RMfileSeekPos whence);
static RMint32 rm_memory_file_close (void *cookie);

static RMFileOps mem_file_ops = { read: (void *) rm_memory_file_read, 
				  write:(void *) rm_memory_file_write, 
				  seek:(void *) rm_memory_file_seek, 
				  close:(void *) rm_memory_file_close
};

static RMint32 rm_memory_file_read(void *cookie, RMuint8 *buffer, RMuint32 size)
{
	RMuint32 read_size;
	struct rm_memory_file_cookie *file_info =  (struct rm_memory_file_cookie*)cookie;
 	if(file_info->mem_base == NULL)
		return -1;
	if(file_info->position >= file_info->size)
		return 0; /*EOF*/
	read_size = RMmin(file_info->size - file_info->position, size);
	RMMemcpy(buffer, file_info->mem_base + file_info->position, read_size);
	file_info->position += read_size;
	return read_size;
	
}
static RMint32 rm_memory_file_write (void *cookie, const RMuint8 *buffer, RMuint32 size)
{
	RMuint32 write_size;
	struct rm_memory_file_cookie *file_info =  (struct rm_memory_file_cookie*)cookie;
 	if(file_info->mem_base == NULL)
		return -1;
	if(file_info->position >= file_info->size)
		return 0; /*EOF*/
	write_size = RMmin(file_info->size - file_info->position, size);
	RMMemcpy(file_info->mem_base + file_info->position, buffer, write_size);
	file_info->position += write_size;
	return write_size;

}
static RMint32 rm_memory_file_seek (void *cookie, RMint64 *position, RMfileSeekPos whence)
{
	struct rm_memory_file_cookie *file_info =  (struct rm_memory_file_cookie*)cookie;
	
 	if(file_info->mem_base == NULL)
		return -1;

	switch(whence) {
	case RM_FILE_SEEK_START:
		file_info->position = *position;
		break;
	case RM_FILE_SEEK_CURRENT:
		file_info->position += *position;
		break;
	case RM_FILE_SEEK_END:
		file_info->position = file_info->size + *position;
		break;
	default:
		return -1;
	}

	if((file_info->position < 0 ) || (file_info->position >= file_info->size))
		return -1;
	
	if (position != NULL)
		*position = file_info->position;

	return 0;
}
static RMint32 rm_memory_file_close (void *cookie)
{
	struct rm_memory_file_cookie *file_info =  (struct rm_memory_file_cookie*)cookie;
 	if(file_info->mem_base == NULL)
		return -1;
	if(file_info->free_on_close){
		RMFree(file_info->mem_base);
	}
	file_info->mem_base = NULL;
	RMFree(file_info);
	return 0;
}

RMfile RMOpenMemoryFile(RMuint8 *buf, RMuint32 size)
{
	struct rm_memory_file_cookie *cookie;

	cookie = RMMalloc(sizeof(struct rm_memory_file_cookie));
	if(cookie == NULL){
		RMDBGLOG((ENABLE, "RMOpenMemoryFile: Fatal out of memory\n"));
		return (RMfile)NULL;
	}
	cookie->mem_base= buf;
	cookie->size = size;
	cookie->position = 0;
	cookie->free_on_close = FALSE;
	return RMOpenFileCookie((void*)cookie, RM_FILE_OPEN_READ_WRITE /*unused*/, &mem_file_ops);
}

RMfile RMCreateMemoryFile(RMuint32 size)
{
	struct rm_memory_file_cookie *cookie;

	cookie = RMMalloc(sizeof(struct rm_memory_file_cookie));
	if(cookie == NULL){
		RMDBGLOG((ENABLE, "RMCreateMemoryFile: Fatal out of memory\n"));
		return (RMfile)NULL;
	}
	cookie->mem_base= RMMalloc(size);
	if(cookie->mem_base == NULL){
		RMDBGLOG((ENABLE, "RMCreateMemoryFile: Fatal out of memory\n"));
		RMFree(cookie);
		return (RMfile)NULL;
	}
	cookie->size = size;
	cookie->position = 0;
	cookie->free_on_close = TRUE;
	return RMOpenFileCookie((void*)cookie, RM_FILE_OPEN_READ_WRITE /*unused*/, &mem_file_ops);
}
