/*****************************************
 Copyright © 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   bitmaps.h
  @brief  high level bitmap decoding
  
  @author Oriol Prieto
  @date   2005-03-09
*/

#ifndef __BITMAPS_H__
#define __BITMAPS_H__

#include "sample_os.h"

#ifndef ALLOW_OS_CODE
#define ALLOW_OS_CODE 1
#endif /* ALLOW_OS_CODE */

#define YYYY_UV
#include "../rmlibjpeg/src/libjpeg/jpeglib.h"
#include "../rmlibjpeg/src/libjpeg/transupp.h"
#include "../rmlibpng/src/libpng/png.h"
#include "../rmlibungif/src/libungif/gif_lib.h"

struct RMbmpInfo{
	RMfile fp;
	RMuint32 palette_size;
	RMuint16 bpp;
	RMuint32 width;
	RMuint32 height;
	RMuint32 alpha;
};

struct RMjpgInfo{
	RMfile fp;
	struct jpeg_decompress_struct cinfo;
	struct jpeg_error_mgr jerr;
	RMuint32 alpha;
	RMbool force_rgb;
	RMuint32 width;
	RMuint32 height;
	RMbool force_420;
	enum EMhwlibSamplingMode sampling_mode;
};

struct RMgifInfo{
	GifFileType *gif_hdr;
	RMfile fp;
	RMuint32 width;
	RMuint32 height;
	RMuint32 alpha;
};


struct RMpngInfo{
	RMfile fp;
	png_structp png_ptr;
	png_infop info_ptr;
	RMuint32 width;
	RMuint32 height;
	RMuint32 alpha;
	RMuint32 gray_levels;
};


struct RMyuvInfo{
	RMfile fp;
	RMuint32 offset;
	RMuint32 width;
	RMuint32 height;
};

struct RMtpInfo {
	RMuint32 pattern;
	RMuint32 width;
	RMuint32 height;
	RMuint8 alpha;
	RMbool force_rgb;
};

enum RMBitmapFileFormat{
 	RMBitmap_BMP_Format = 1,
 	RMBitmap_JPG_Format,
 	RMBitmap_GIF_Format,
 	RMBitmap_PNG_Format,
 	RMBitmap_YUV_Format,
 	RMBitmap_TestPattern
};

struct RMBitmapFileInfo {
	enum RMBitmapFileFormat file_format;
	union {
		struct RMbmpInfo bmp;
		struct RMjpgInfo jpg;
		struct RMgifInfo gif;
		struct RMpngInfo png;
		struct RMyuvInfo yuv;
		struct RMtpInfo tp;
	} info;
};

struct RMBitmapFileOptions {
	RMuint8 alpha;
	RMbool force_rgb;
	enum PictureOrientation orientation;
};

RMstatus RMOpenBitmapFile(RMascii *filename, struct RMBitmapFileInfo *bfi,struct RMBitmapFileOptions *opts, struct DCCOSDProfile  *profile );
RMstatus RMBitmapToRaw(RMuint8 *luma, RMuint8 *chroma, struct RMBitmapFileInfo *bfi);
RMstatus RMBitmapGetPalette(RMuint32 *palette, struct RMBitmapFileInfo *bfi);
void RMBitmapSetSourceWindow(struct EMhwlibDisplayWindow *window, struct RMBitmapFileInfo *bfi);
void RMCloseBitmapFile(struct RMBitmapFileInfo *bfi);


#endif // __BITMAPS_H__
