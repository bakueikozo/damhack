/*****************************************
 Copyright 2001-2007
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmpfs.c
  @brief  

  The pfs (Play For Sure) functions are used to start the
  bufferisation of files before the user asks for the playback.  This
  way when the user asks for a given url to be played, the first
  kilobytes of the files are already stored in memory and they can be
  demuxed and play without delay. The caller of these functions has to
  know which urls are likely to be played next so that they are
  already buffered when the user requests to play them.

  ** THIS IS NOT A REAL LIBRARY, since there's no 'handle', therefore only one
  instance can be used.

  How to use this lib:

  **************** Beginning of pseudo code ****************

  allocate a memory area to use by the prefetch function;
  fill up the pfs_profile struct;
  rmpfs_open(...);
  allocate a slot for each URL with rmpfs_allocate_slot_to_url(...);
  if (threaded) {
     LaunchThread(rmpfs_prefetch_slot(...));
     LaunchThread(rmpfs_prefetch_slot(...));
     ...
  }
  else {
     rmpfs_prefetch_slot(...);
     rmpfs_prefetch_slot(...);
     ...
  }
  play a given url;

  close the slots if necessary
  rmpfs_close_slot(...);
  rmpfs_close_slot(...);
  ...

  close the library before exiting the application
  rmpfs_close(...);

  ******************* End of pseudo code *******************

  **************************
  NOTE:
  **************************

  -Any seek call will interrupt prefetching.
  -The library works with or without threads.
  -This library is for 'reading' streams only, it cannot write to files.



  @author Sebastian Frias Feltrer
  @date   2007-01-15


  reported issues:
  
  bugct 2208: original feature request
  bugct 2719: allow prefetching to be interrupted by rmpfs_close_slot; 
              robustness
  bugct 2844: issue with seeking, seeking inside the cache is now possible;
              forbid multiple open request linked to the same url, only the first will pass thru cache.
  bugct 2885: do not close file handle on prefetch error, improved handling
              remove unnecessary critical sections
              reset stopPrefetch variable (might be linked to bugct 3029)


*/




#include <unistd.h>

#include "sample_os.h"

#include "rmpfs.h"
#include "rminputstream.h"

#include "rmupnp/rmlibwmdrmnd/include/ms_cardea.h"

#ifdef WITH_THREADS
#include "../rmlibcw/include/rmsemaphores.h"
#endif

/* #### Begin CARDEA code #### */
#include "rmupnp/rmlibwmdrmnd/include/ms_cardea.h"
/* #### End CARDEA code #### */



#if 1
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

#if 0
#define READDBG ENABLE
#else
#define READDBG DISABLE
#endif

#if 0
#define SEEKDBG ENABLE
#else
#define SEEKDBG DISABLE
#endif


/*
  if KEEP_CACHE_AND_FILE_IN_SYNC is set to 1 then the file pointer will be 
  always synced with the cache pos;
  else, the file pointer will be synced with the cache pos only when a
  switch from cache to file is required.

  case 1) sync enabled:

  Everything works as usual until a seek call is performed. Prefetching will be
  interrupted to honor the seek. The file and pfs pointers will be set to the
  seeking destination.
  After this, all reads inside the cache will update the file pointer to match
  that of pfs.

  case 2) sync disabled:

  Everything works as usual until a seek call is performed. Prefetching will be
  interrupted to honor the seek. The file and pfs pointers will be set to the
  seeking destination.
  After this, if a seek to a destination inside the cache is performed only the
  pfs pointer will be updated (thus the non-synced nature of this mode). The file
  and pfs pointers will be updated only when a switch from cache to file is needed.

  case 1) is default although there are no differences from the functionality point
  of view.
*/

#define KEEP_CACHE_AND_FILE_IN_SYNC 1



#define PREFETCH_CHUNK_SIZE (4 * 1024)



#ifdef WITH_THREADS

#define ENTER_CS(x) do {			\
		RMEnterCriticalSection(x);	\
	} while (0);

#define LEAVE_CS(x) do {			\
		RMLeaveCriticalSection(x);	\
	} while (0);

#define SEMAPHORE_P(x) do {			\
		RMReleaseSemaphore(x, 1);	\
	} while (0);

#define SEMAPHORE_V(x) do {			\
		RMWaitForSemaphore(x);		\
	} while (0);
#else
#define ENTER_CS(x) do { } while(0);
#define LEAVE_CS(x) do { } while(0);
#define SEMAPHORE_P(x) do { } while(0);
#define SEMAPHORE_V(x) do { } while(0);
#endif

//FILE *saveFile;


static struct pfs_handle {
	struct pfs_profile *pfsProfile;
	RMuint32 url_prefetch_size;
	RMfile fileHandleTable[MAX_NUMBER_OF_CACHEABLE_URL];
	RMascii fileNameTable[MAX_NUMBER_OF_CACHEABLE_URL][256];
	RMbool urlAllocated[MAX_NUMBER_OF_CACHEABLE_URL];
	RMbool prefetchDone[MAX_NUMBER_OF_CACHEABLE_URL];
	RMbool stopPrefetch[MAX_NUMBER_OF_CACHEABLE_URL];

	/*
	  the slot in being used thru RMFile* calls by an application
	*/
	RMbool inUse[MAX_NUMBER_OF_CACHEABLE_URL];                
	
	/*
	  force all reads to be in sync with the original file handle
	*/
	RMbool forceSyncReads[MAX_NUMBER_OF_CACHEABLE_URL];

	RMuint32 prefetchedSize[MAX_NUMBER_OF_CACHEABLE_URL];

#ifdef WITH_THREADS
	RMsemaphore pfsOpenSemaphore[MAX_NUMBER_OF_CACHEABLE_URL];
	RMsemaphore pfsReadSemaphore[MAX_NUMBER_OF_CACHEABLE_URL];
	RMcriticalsection criticalSection[MAX_NUMBER_OF_CACHEABLE_URL];
#endif



} pfsHandle;




/* internal functions */

struct _pfs_cookie {
	RMuint32 slot;
	RMint64 position;
	
};


static RMint32 pfs_read(void *cookie, RMuint8 *buffer, RMuint32 size)
{
	struct _pfs_cookie *pfsCookie = (struct _pfs_cookie *)cookie;
	RMstatus status;
	RMint64 actualFilePos;

	RMint32 bytesLeft = size;
	RMint32 cache_size;
	RMint32 read_from_cache;
	RMint32 read_from_file = 0;
	RMint32 offset = 0;
	RMuint32 count = 0;
	

	RMGetCurrentPositionOfFile(pfsHandle.fileHandleTable[pfsCookie->slot], &actualFilePos);

	RMDBGLOG((READDBG, ">>>>\n"));
	RMDBGLOG((READDBG, "pfs_read(slot:%lu, size:%lu, buffer:%p)\n", pfsCookie->slot, size, buffer));
	RMDBGLOG((READDBG, "pos %lld (actual %lld), range[%lld, %lld], prefetchedSize %lu/%lu prefetchDone %lu\n",
		  pfsCookie->position,
		  actualFilePos,
		  pfsCookie->position,
		  pfsCookie->position + size,
		  pfsHandle.prefetchedSize[pfsCookie->slot],
		  pfsHandle.url_prefetch_size,
		  (RMuint32)pfsHandle.prefetchDone[pfsCookie->slot]));

	while (bytesLeft > 0) {
		RMbool forceSyncReads = FALSE;

		RMDBGLOG((READDBG, "bytesLeft %lu, offset %lu, pos %lld\n",
			  bytesLeft,
			  offset,
			  pfsCookie->position));


		if ((pfsCookie->position % PREFETCH_CHUNK_SIZE) == 0) {
			RMDBGLOG((READDBG, "check semaphore\n"));

			if (!pfsHandle.prefetchDone[pfsCookie->slot]) {
				SEMAPHORE_V(pfsHandle.pfsReadSemaphore[pfsCookie->slot]);
			}
		}
		cache_size = pfsHandle.prefetchedSize[pfsCookie->slot];

		count = 0;
		read_from_cache = RMmin(PREFETCH_CHUNK_SIZE, bytesLeft);
		read_from_cache = RMmin(read_from_cache, cache_size - pfsCookie->position);
		
		forceSyncReads = pfsHandle.forceSyncReads[pfsCookie->slot];

#if 0
		if (forceSyncReads) {
			// all reads will be from the file, caching disabled
			RMDBGLOG((READDBG, "forcing sync reads\n"));
			read_from_cache = 0;
		}
#endif


		if (read_from_cache > 0) {
			// read from cache

			RMDBGLOG((READDBG, "A: read_from_cache %ld read_from_file %ld cache_size %lu\n",
				  read_from_cache,
				  read_from_file,
				  cache_size));

			RMMemcpy(buffer + offset, (pfsHandle.pfsProfile->prefetch_area + (pfsCookie->slot * pfsHandle.url_prefetch_size) + pfsCookie->position), read_from_cache);
			
			count = read_from_cache;
			RMDBGLOG((READDBG, "read_from_cache %lu bytes\n", count));

		}
		else if (pfsHandle.prefetchDone[pfsCookie->slot]) {
			// read from file
			RMuint32 bytesRead;
		
			read_from_file = bytesLeft;

			RMDBGLOG((READDBG, "B: read_from_cache %ld read_from_file %ld cache_size %lu\n",
				  read_from_cache,
				  read_from_file,
				  cache_size));
	
			RMGetCurrentPositionOfFile(pfsHandle.fileHandleTable[pfsCookie->slot], &actualFilePos);
			
			RMDBGLOG((READDBG, "read_from_file[%lu] cachePos %llu, actualPos %llu\n", pfsCookie->slot, pfsCookie->position, actualFilePos));
			
			if (actualFilePos != pfsCookie->position) {
				RMDBGLOG((ENABLE, "[%lu] resyncing cache (%llu) and file (%llu) pointers\n", pfsCookie->slot, pfsCookie->position, actualFilePos));
				RMSeekFile(pfsHandle.fileHandleTable[pfsCookie->slot], pfsCookie->position, RM_FILE_SEEK_START);
			}
			
			status = RMReadFile(pfsHandle.fileHandleTable[pfsCookie->slot], buffer + offset, read_from_file, &bytesRead);
			if (status == RM_ERRORENDOFFILE) {
				RMDBGLOG((ENABLE, "[%lu] EOF\n", pfsCookie->slot));
				//quit loop gracefully
				bytesLeft = 0;
			}
			else if (status != RM_OK) {
				RMDBGLOG((ENABLE, "error %s prefetch slot %lu, aborting\n", RMstatusToString(status), pfsCookie->slot));
				return -1;
			}
			
			count = bytesRead;
			RMDBGLOG((READDBG, "read_from_file %lu bytes\n", count));
		}
		else
			RMDBGLOG((ENABLE, "need to wait\n"));

		bytesLeft -= count;
		pfsCookie->position += count;
		offset += count;

		if (bytesLeft < 0)
			RMDBGLOG((ENABLE, "bytesLeft %ld  is negative!!\n", bytesLeft));


#if KEEP_CACHE_AND_FILE_IN_SYNC
		if (forceSyncReads) {
			// sync read pointers
			
			RMGetCurrentPositionOfFile(pfsHandle.fileHandleTable[pfsCookie->slot], &actualFilePos);
			
			if (actualFilePos != pfsCookie->position) {
				RMDBGLOG((READDBG, "[%lu] Forced: resyncing cache (%llu) and file (%llu) pointers\n", pfsCookie->slot, pfsCookie->position, actualFilePos));
				RMSeekFile(pfsHandle.fileHandleTable[pfsCookie->slot], pfsCookie->position, RM_FILE_SEEK_START);
			}
		}
#endif
	}

	//fwrite(buffer, offset, 1, saveFile);

	RMGetCurrentPositionOfFile(pfsHandle.fileHandleTable[pfsCookie->slot], &actualFilePos);

	RMDBGLOG((READDBG, "total bytes read %lu curretFilePos %lld currentCachePos %lld\n", offset, actualFilePos, pfsCookie->position));
	RMDBGLOG((READDBG, "<<<<\n"));
	if (offset < 0)
		RMDBGLOG((ENABLE, "\n\noffset is negative! = %ld\n", offset));

	return offset;

}

static RMint32 pfs_write(void *cookie, const RMuint8 *buffer, RMuint32 size)
{
#ifndef NDEBUG
	struct _pfs_cookie *pfsCookie = (struct _pfs_cookie *)cookie;
#endif
	RMDBGLOG((LOCALDBG, "pfs_write(slot:%lu) not handled!!\n", pfsCookie->slot));

	return -1;
}

static RMint32 pfs_seek(void *cookie, RMint64 *position, RMfileSeekPos whence)
{
	struct _pfs_cookie *pfsCookie = (struct _pfs_cookie *)cookie;
	RMstatus status;
	RMint64 currentPosition;
	RMint32 error = 0;

	ENTER_CS(pfsHandle.criticalSection[pfsCookie->slot]);

	currentPosition = pfsCookie->position;

	RMDBGLOG((SEEKDBG, "pfs_seek(slot:%lu, pos:%lld, from:%lu [%s])\n", 
		  pfsCookie->slot, 
		  *position, 
		  (RMuint32)whence,
		  (whence == RM_FILE_SEEK_START) ? "from start": (whence == RM_FILE_SEEK_CURRENT) ? "current":"from the end" ));


	// if forceSyncReads is enabled, always perform real seeks
	if (KEEP_CACHE_AND_FILE_IN_SYNC && pfsHandle.forceSyncReads[pfsCookie->slot])
		goto perform_real_seek;


	switch (whence) {
	case RM_FILE_SEEK_START:
		if (*position < 0) {
			RMDBGLOG((ENABLE, "trying to seek beyond start of file\n"));
			error = -1;
			goto exit;
		}
		
		if (*position < pfsHandle.prefetchedSize[pfsCookie->slot]) {
			// seek is within cached data
			currentPosition = *position;

			RMDBGLOG((SEEKDBG, "seek to %lld is inside cache [0;%lu]\n", currentPosition, pfsHandle.prefetchedSize[pfsCookie->slot]));

			goto exit;
		}
		// else perform a 'real' seek and stop prefetching

		break;
	case RM_FILE_SEEK_CURRENT:

		currentPosition += *position;

		if (currentPosition < 0) {
			RMDBGLOG((ENABLE, "trying to seek beyond start of file\n"));
			error = -1;
			goto exit;
		}

		if (currentPosition < pfsHandle.prefetchedSize[pfsCookie->slot]) {
			// seek is within cached data

			RMDBGLOG((SEEKDBG, "seek to %lld is inside cache [0;%lu]\n", currentPosition, pfsHandle.prefetchedSize[pfsCookie->slot]));
			
			goto exit;
		}
		// else perform a 'real' seek and stop prefetching

		break;
	case RM_FILE_SEEK_END:
		if (*position > 0) {
			RMDBGLOG((ENABLE, "trying to seek beyond end of file\n"));
			error = -1;
			goto exit;
		}

		/* 
		   in order to handle this case correctly we'd need to know the length of the file,
		   we might not be able to do that in all cases, therefore we forward the request 
		   straight to the 'real' seek
		*/

		break;
	};

	if (!pfsHandle.prefetchDone[pfsCookie->slot]) 
		RMDBGLOG((ENABLE, "disabling prefetch for slot %lu (%lu bytes prefetched) since a real seek needs to be performed\n", pfsCookie->slot, pfsHandle.prefetchedSize[pfsCookie->slot]));

	// stop prefetching the url because we're performing a 'real' seek

	pfsHandle.prefetchDone[pfsCookie->slot] = TRUE;

 perform_real_seek:
	RMDBGLOG((SEEKDBG, "real seek(%llu, %lu) for slot %lu\n", *position, (RMuint32)whence, pfsCookie->slot));

	if (!pfsHandle.forceSyncReads[pfsCookie->slot]) {
		RMDBGLOG((ENABLE, "force sync reads for slot %lu due to seeking\n", pfsCookie->slot));
		pfsHandle.forceSyncReads[pfsCookie->slot] = TRUE;
	}

	status = RMSeekFile(pfsHandle.fileHandleTable[pfsCookie->slot], *position, whence);
	if (status != RM_OK) {
		RMDBGLOG((ENABLE, "error seeking\n"));
		error = -1;
		goto exit;
	}

	RMGetCurrentPositionOfFile(pfsHandle.fileHandleTable[pfsCookie->slot], &currentPosition);

 exit:
	pfsCookie->position = currentPosition;
	*position = currentPosition;

	RMDBGLOG((SEEKDBG, "current position %llu\n", pfsCookie->position));

	LEAVE_CS(pfsHandle.criticalSection[pfsCookie->slot]);

	return error;
}

static RMint32 pfs_close(void *cookie)
{
	struct _pfs_cookie *pfsCookie = (struct _pfs_cookie *)cookie;

	RMDBGLOG((LOCALDBG, "pfs_close(slot:%lu)\n", pfsCookie->slot));

	ENTER_CS(pfsHandle.criticalSection[pfsCookie->slot]);
	pfsHandle.inUse[pfsCookie->slot] = FALSE;
	pfsHandle.forceSyncReads[pfsCookie->slot] = FALSE;
	LEAVE_CS(pfsHandle.criticalSection[pfsCookie->slot]);

	RMFree(cookie);

	return 0;
}

static RMbool is_url_in_cache(RMascii *url, RMuint32 *slot)
{
	RMuint32 i;

	if (!pfsHandle.pfsProfile) {
		RMDBGLOG((ENABLE, "need to call rmpfs_open first\n"));
		return FALSE;
	}

	for (i = 0; i < pfsHandle.pfsProfile->prefetch_slots; i++) {
		if (RMCompareAscii(url, pfsHandle.fileNameTable[i])) {
			RMDBGLOG((LOCALDBG, "found '%s' at slot %lu\n", url, i));
			*slot = i;
			return TRUE;
		}
	}
	
	return FALSE;
}


RMFileOps ops = {
	pfs_read,
	pfs_write,
	pfs_seek,
	pfs_close
};



static RMfile open_for_pfs(const RMascii *filename, RMfileOpenMode mode, struct stream_options_s *options)
{
	RMuint32 slot;
	RMfile file = NULL;
	struct _pfs_cookie *cookie;

	RMDBGLOG((LOCALDBG, "_open_for_pfs(url:'%s')\n", filename));

	if (!is_url_in_cache((RMascii*)filename, &slot)) {
		RMDBGLOG((ENABLE, "url not prefetched\n"));
		return NULL;
	}

	RMDBGLOG((LOCALDBG, "found url in slot %lu\n", slot));

#ifdef WITH_THREADS
	// wait until we're ready
	SEMAPHORE_V(pfsHandle.pfsOpenSemaphore[slot]);

	RMDBGLOG((LOCALDBG, "open_for_pfs[%lu]: ...done\n", slot));
#else
	if (!pfsHandle.prefetchDone[slot]) {
		RMDBGLOG((ENABLE, "\nopen_for_pfs called before prefetch for the given url was completed\n"
			  "prefetch will be unusable for this url\n"));
		return NULL;
	}
#endif


	if (pfsHandle.inUse[slot]) {
		RMDBGLOG((ENABLE, "\nurl already opened, prefetch disabled for this handle\n"));
		return NULL;
	}
		

	if (pfsHandle.fileHandleTable[slot]) {

		RMDBGLOG((LOCALDBG, "internal open\n"));

		cookie = (struct _pfs_cookie *) RMMalloc(sizeof(struct _pfs_cookie));
		cookie->slot = slot;
		cookie->position = 0;
		
		file = RMOpenFileCookie((void*)cookie, mode, &ops);

		/*
		  used to signal ERROR if rmpfs_close_slot is called (this is just for robustness)
		*/
		ENTER_CS(pfsHandle.criticalSection[slot]);
		pfsHandle.inUse[slot] = TRUE; 
		LEAVE_CS(pfsHandle.criticalSection[slot]);

	}
	else
		RMDBGLOG((LOCALDBG, "external open\n"));

	// we might want to open several times the same url, so unblock the semaphore
	SEMAPHORE_P(pfsHandle.pfsOpenSemaphore[slot]);

	return file;
}


/* previously it was in rminputstream.c, in order to not break set_rua_test/test compilation without adding
   the required libraries (CARDEA) to the Makefile, we moved the functions from rminputstream to here.
*/
/* this is the open function used by rmpfs.c */

static RMfile open_url(RMascii *url)
{
	RMfile file;
	RMascii *session_header;
	struct stream_options_s stream_options;

	RMDBGLOG((LOCALDBG, "open_url\n"));

	init_stream_options(&stream_options);

/* #### Begin CARDEA code #### */
	session_header = get_ms_session_header(url);
	if (session_header) {
		RMDBGLOG((ENABLE, "got CARDEA session header '%s'\n", session_header));

		if (RMFAILED(set_http_options(&stream_options, RM_HTTP_CUSTOM_HEADER, session_header))) {
			RMDBGLOG((ENABLE, "Error setting CARDEA session parameter.\n"));
			return NULL;
		}
	}
/* #### End CARDEA code #### */


/*

  DTCP initialisation should be here 

*/

	RMDBGLOG((LOCALDBG, "about to call open_stream for '%s'\n", url));
	file = _open_stream(url, RM_FILE_OPEN_READ, &stream_options);
	if (!file)
		RMDBGLOG((ENABLE, "open error!\n"));

	return file;

}


/* exported functions */

RMstatus rmpfs_open(struct pfs_profile *profile)
{
	RMuint32 i;

	if (!profile)
		return RM_ERROR;
	
	if (!profile->prefetch_area_size)
		return RM_ERROR;
	
	if (!profile->prefetch_slots)
		return RM_ERROR;

	pfsHandle.pfsProfile = profile;
	pfsHandle.url_prefetch_size = pfsHandle.pfsProfile->prefetch_area_size / pfsHandle.pfsProfile->prefetch_slots;

	// round down
	pfsHandle.url_prefetch_size = (pfsHandle.url_prefetch_size / PREFETCH_CHUNK_SIZE) * PREFETCH_CHUNK_SIZE;


	if (pfsHandle.pfsProfile->prefetch_slots >= MAX_NUMBER_OF_CACHEABLE_URL) {
		RMDBGLOG((ENABLE, "can't cache more than %lu URLs\n", MAX_NUMBER_OF_CACHEABLE_URL));
		return RM_ERROR;
	}

	RMDBGLOG((LOCALDBG, "rmpfs_open: buffer @%p, size %lu, urlSize %lu, numURL %lu\n",
		  pfsHandle.pfsProfile->prefetch_area,
		  pfsHandle.pfsProfile->prefetch_area_size,
		  pfsHandle.url_prefetch_size,
		  pfsHandle.pfsProfile->prefetch_slots));

	for (i = 0; i < pfsHandle.pfsProfile->prefetch_slots; i++) {

		pfsHandle.prefetchDone[i] = FALSE;
		pfsHandle.fileHandleTable[i] = NULL;
		pfsHandle.fileNameTable[i][0] = '\0';
		pfsHandle.prefetchedSize[i] = 0;
		pfsHandle.urlAllocated[i] = FALSE;
		pfsHandle.stopPrefetch[i] = FALSE;
		pfsHandle.inUse[i] = FALSE;
		pfsHandle.forceSyncReads[i] = FALSE;

#ifdef WITH_THREADS
		// create semaphore to block open_for_pfs calls until we have opened the url
		pfsHandle.pfsOpenSemaphore[i] = RMCreateSemaphore(0);

		// create semaphore to block pfs_read calls until requested data has been prefetched
		pfsHandle.pfsReadSemaphore[i] = RMCreateSemaphore(0);

		// critical sections
		pfsHandle.criticalSection[i] = RMCreateCriticalSection();
#endif

	}

	set_custom_open_for_pfs(open_for_pfs);

	//saveFile = fopen("read.dump", "wb");

#ifdef WITH_THREADS
	RMDBGLOG((ENABLE, "rmpfs is thread-safe\n"));
#else
	RMDBGLOG((ENABLE, "rmpfs is NOT thread-safe\n"));
#endif

	return RM_OK;
}

RMstatus rmpfs_close(void)
{
	RMuint32 i;

	RMDBGLOG((LOCALDBG, "rmpfs_close\n"));
	
	for (i = 0; i < pfsHandle.pfsProfile->prefetch_slots; i++) {
		if (pfsHandle.fileHandleTable[i]) {
			RMDBGLOG((ENABLE, "slot %lu was not properly closed, closing\n"));
			RMCloseFile(pfsHandle.fileHandleTable[i]);
			pfsHandle.fileHandleTable[i] = NULL;
		}
		
#ifdef WITH_THREADS
		RMDeleteSemaphore(pfsHandle.pfsOpenSemaphore[i]);
		RMDeleteSemaphore(pfsHandle.pfsReadSemaphore[i]);
		RMDeleteCriticalSection(pfsHandle.criticalSection[i]);
#endif
	}

	pfsHandle.pfsProfile = NULL;

	set_custom_open_for_pfs(NULL);

	return RM_OK;
}

RMstatus rmpfs_allocate_slot_to_url(RMascii *url, RMuint32 slot)
{
	RMDBGLOG((LOCALDBG, "rmpfs_allocate_slot_to_url(slot:%lu, url:'%s')\n", slot, (RMuint8*)url));

	if (!pfsHandle.pfsProfile) {
		RMDBGLOG((ENABLE, "need to call rmpfs_open first\n"));
		return RM_ERROR;
	}

	if ((slot > (MAX_NUMBER_OF_CACHEABLE_URL)) || (slot > (pfsHandle.pfsProfile->prefetch_slots - 1))) {
		RMDBGLOG((ENABLE, "requested slot is out of range\n"));
		return RM_ERROR;
	}

	if (pfsHandle.fileHandleTable[slot]) {
		RMDBGLOG((ENABLE, "slot already in use\n"));
		return RM_ERROR;
	}



	RMCopyAscii(pfsHandle.fileNameTable[slot], url);

	pfsHandle.stopPrefetch[slot] = FALSE;
	pfsHandle.urlAllocated[slot] = TRUE;

	return RM_OK;
}



RMstatus rmpfs_prefetch_slot(RMuint32 slot)
{
	RMfile file;
	RMstatus status = RM_OK;

	RMDBGLOG((LOCALDBG, "rmpfs_prefetch_slot(slot:%lu)=%s\n", slot, pfsHandle.fileNameTable[slot]));

	if (!pfsHandle.pfsProfile) {
		RMDBGLOG((ENABLE, "need to call rmpfs_open first\n"));
		return RM_ERROR;
	}

	if ((slot > (MAX_NUMBER_OF_CACHEABLE_URL)) || (slot > (pfsHandle.pfsProfile->prefetch_slots - 1))) {
		RMDBGLOG((ENABLE, "requested slot is out of range\n"));
		return RM_ERROR;
	}

	if (pfsHandle.fileHandleTable[slot]) {
		RMDBGLOG((ENABLE, "slot already in use\n"));
		return RM_ERROR;
	}

	if (!pfsHandle.urlAllocated[slot]) {
		RMDBGLOG((ENABLE, "seems the slot has not been allocated\n"));
		return RM_ERROR;
	}

	file = open_url(pfsHandle.fileNameTable[slot]);

	if (file) {
		RMuint32 count;
		RMuint32 bytesLeft = pfsHandle.url_prefetch_size;
		RMuint32 bytesToRead = RMmin(pfsHandle.url_prefetch_size, PREFETCH_CHUNK_SIZE);
		RMuint8 *buffer = pfsHandle.pfsProfile->prefetch_area + (pfsHandle.url_prefetch_size * slot);


		pfsHandle.fileHandleTable[slot] = file;

		// unblock open_for_pfs
		SEMAPHORE_P(pfsHandle.pfsOpenSemaphore[slot]);

		/* 
		   using prefetchDone here is correct even if it can be modified by another thread since we
		   have a second check inside a critical section
		*/
		while (bytesLeft && !pfsHandle.prefetchDone[slot]) {
		
			ENTER_CS(pfsHandle.criticalSection[slot]);

			if (pfsHandle.stopPrefetch[slot]) {
				RMDBGLOG((ENABLE, "prefetching for slot %lu interrupted\n", slot));

				pfsHandle.prefetchDone[slot] = TRUE;
			}

			if (!pfsHandle.prefetchDone[slot]) {

				status = RMReadFile(file, buffer + pfsHandle.prefetchedSize[slot], bytesToRead, &count);
				if (status == RM_ERRORENDOFFILE) {
					RMDBGLOG((LOCALDBG, "[%lu] EOF\n", slot));
					pfsHandle.prefetchDone[slot] = TRUE;
				}
				else if (status != RM_OK) {
					// do not do anything (just like EOF), pfs_read will fail by itself when switching to file reading
					RMDBGLOG((ENABLE, "error prefetch slot %lu, aborting\n", slot));

					pfsHandle.prefetchDone[slot] = TRUE;
				}

				bytesLeft -= count;
				pfsHandle.prefetchedSize[slot] += count;
				bytesToRead = RMmin(bytesLeft, PREFETCH_CHUNK_SIZE);
				
				// unblock pfs_read
				SEMAPHORE_P(pfsHandle.pfsReadSemaphore[slot]);
			}

			LEAVE_CS(pfsHandle.criticalSection[slot]);
			RMDBGPRINT((ENABLE, "%ld ", slot));

		}
		
		pfsHandle.prefetchDone[slot] = TRUE;

		RMDBGLOG((LOCALDBG, "prefetch[%lu] end: cached %lu bytes\n", slot, pfsHandle.prefetchedSize[slot]));
		
		if ((status == RM_OK) || (status == RM_ERRORENDOFFILE))
			return status;
	} else
		status = RM_ERROR;

	RMDBGLOG((ENABLE, "rmpfs_prefetch_slot[%lu] error!\n", slot));

	return status;
}

RMstatus rmpfs_close_slot(RMuint32 slot)
{
	struct ms_url_ctx *url_ctx = NULL;
	RMDBGLOG((LOCALDBG, "rmpfs_close_slot %lu\n", slot));

	if (!pfsHandle.pfsProfile) {
		RMDBGLOG((ENABLE, "need to call rmpfs_open first\n"));
		return RM_ERROR;
	}

	if (pfsHandle.inUse[slot]) {
		RMDBGLOG((ENABLE, "slot is in use, can't close\n"));
		return RM_ERROR;
	}

	// stop the prefetching thread
	ENTER_CS(pfsHandle.criticalSection[slot]);
	pfsHandle.stopPrefetch[slot] = TRUE;

	if (pfsHandle.fileHandleTable[slot]) {
		RMCloseFile(pfsHandle.fileHandleTable[slot]);
	}
	else
		RMDBGLOG((ENABLE, "not open!\n"));


	if ( (url_ctx = find_cardea_url(pfsHandle.fileNameTable[slot])) != NULL) 
			destroy_cardea_license_data(url_ctx);

	pfsHandle.fileNameTable[slot][0] = '\0';
	pfsHandle.fileHandleTable[slot] = NULL;
	
	pfsHandle.prefetchedSize[slot] = 0;
	pfsHandle.prefetchDone[slot] = FALSE;
	pfsHandle.urlAllocated[slot] = FALSE;
	pfsHandle.inUse[slot] = FALSE;
	pfsHandle.forceSyncReads[slot] = FALSE;
	
	LEAVE_CS(pfsHandle.criticalSection[slot]);


	return RM_OK;
}





