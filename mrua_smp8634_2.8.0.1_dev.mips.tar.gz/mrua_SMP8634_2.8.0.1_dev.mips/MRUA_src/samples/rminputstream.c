/*****************************************
 Copyright � 2001-2005
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rminputstream.c
  @brief  Wrapper for custom FILE

  @author Julien Lerouge
  @date   2005-03-02
*/

#include "../rmlibhttp/include/rmlibhttp.h"
#include "../rmlibcw/include/rmlibcw.h"
#include "../rmcore/include/rmcore.h"
#include "rminputstream.h"

#ifdef WITH_SEMIHOSTING
#include "../semihosting/files/hostfile.h"
#endif


#include "../dcc/include/dcc.h"



#if 1
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif



/**
   Set default options for a stream

   For HTTP URL, the defaults are :
   	- RMHTTPFlags = 0
	- No custom header (NULL)

   @param options - struct stream_options_s to configure
   @return RM_OK on success
*/
RMstatus init_stream_options(struct stream_options_s *options)
{
	if (options == NULL)
		return RM_ERROR;

	/* Defaults for HTTP */
	options->http_flags = 0;
	options->http_custom_header = NULL;

	/* Defaults for HTTP hook options */
	options->http_custom_cookie = NULL;
	options->http_custom_hooks = NULL;

	/* Defaults for other medias */
	/* ... */
	
	return RM_OK;
}


/**
   Set HTTP options for open_stream

   @param options - struct stream_options_s to configure
   @param http_flags - HTTP flags to use 
   @param custom_header - HTTP header to use
   @return RM_OK on success
*/
RMstatus set_http_options(struct stream_options_s *options, RMHTTPFlags http_flags, RMascii *custom_header)
{
	if (options == NULL)
		return RM_ERROR;

	options->http_flags |= http_flags;
	options->http_custom_header = custom_header;

	return RM_OK;
}


/**
   Set HTTP hook options for open_stream

   @param options - struct stream_options_s to configure
   @param http_flags - HTTP flags to use 
   @param custom_cookie - cookie use by the hooks
   @param custom_hooks - set of custom callbacks that use the cookie
   @return RM_OK on success
*/
RMstatus set_http_hook_options(struct stream_options_s *options, RMHTTPFlags http_flags, void *custom_cookie, void *custom_hooks)
{
	if (options == NULL)
		return RM_ERROR;

	options->http_flags |= http_flags;
	options->http_custom_cookie = custom_cookie;
	options->http_custom_hooks = custom_hooks;

	return RM_OK;
}


/**
   Custom open_stream callback function - not set by default
*/
static custom_open_stream_function custom_open_stream_callback = NULL;


/**
   Set custom open_stream callback function

   Allows you to hook-in a callback function in open_stream for using
   special file systems or access methods other than the default ones
   implemented in open_stream.

   Depending on the filename/-path the callback function might return NULL
   signaling that open_stream should process with its default handling.

   @param function - pointer to custom open_stream callback function
                     (pass NULL to unset any callback function)
   @return RM_OK on success
*/
RMstatus set_custom_open_stream(custom_open_stream_function function)
{
	custom_open_stream_callback = function;
	return RM_OK;
}



/**
   Custom open_for_pfs callback function - not set by default
*/
static custom_open_for_pfs_function custom_open_for_pfs_callback = NULL;


RMstatus set_custom_open_for_pfs(custom_open_for_pfs_function function)
{
	if (function)
		RMDBGLOG((ENABLE, "set custom open for pfs\n"));
	else
		RMDBGLOG((ENABLE, "clear custom open for pfs\n"));
	custom_open_for_pfs_callback = function;
	return RM_OK;
}



/**
   Set custom ATAPI send command callback function

   @param bDrive - Always 0, it seems.
   @param pCmd - The ATAPI packet command.
   @param pbIoBuf - Pointer to the buffer associated w/ the packet command (in/out).
   @param dwBufSizeInBytes - Size of pbIoBuf.

   @return RM_OK on success

   This function must not write more than dwBufSizeInBytes in the buffer.
*/

#define TEMP_READ_BUFFER_SIZE	(64 * 1024)

static RMuint32 RMAtapiSendCommand(RMuint8 bDrive, RMuint8  *pCmd, RMuint8  *pbIoBuf,
				   RMuint32 dwBufSizeInBytes, void *cookie)
{
	RMpacketCommand command;
	RMint32 retval;
	RMuint8 temp[TEMP_READ_BUFFER_SIZE];
	void *phandle = ((struct RM_CDFS_UDF_FOPS_COOKIE *) cookie)->user_cookie;

	RMMemset(&command,0,sizeof(RMpacketCommand));
	RMMemcpy(command.cmd, pCmd, sizeof(command.cmd));
	command.packetDataDirection = RM_ATAPI_DATA_DIRECTION_READ;

	if (((RMuint32) pbIoBuf) & 3) { // !!!! Note: copied from a sample but untested yet!!!!
		RMDBGLOG((ENABLE,"Buffer is not aligned!!!\n"));
		
		if (dwBufSizeInBytes > sizeof(temp))
			return (RMuint32) -1;
		else {
			command.buffer = temp;
			command.buflen = dwBufSizeInBytes;
			retval = RMIoctlPacketCommand(phandle, &command);
			RMMemcpy(pbIoBuf, temp, dwBufSizeInBytes); 
		}
	
	} else {
		command.buffer = pbIoBuf;
		command.buflen = dwBufSizeInBytes;
		retval = RMIoctlPacketCommand(phandle, &command);
	}

	return retval;
}

/**
   Set custom memory allocation callback function.

   @return address off newly allocated buffer or NULL when failing.

*/

static void *RMMemAlloc(RMuint32 dwNumBytes) 
{
	return RMMalloc(dwNumBytes);
}

/**
   Set custom memory free callback function.

   @return void

*/

static void RMMemFree(void *address)
{
	RMFree(address);
}

/**
   Set custom file close callback function.

   We need to unmount here.

   @return void

*/

static void RMFileClose(void *cookie)
{
	struct RM_CDFS_UDF_FOPS_COOKIE *fops_cookie = (struct RM_CDFS_UDF_FOPS_COOKIE *) cookie;
	RMstatus status;

	if (RMFAILED(status = RMudfs_umount(fops_cookie->volume))) {
		RMDBGLOG((ENABLE,"Cannot unmount UDF device\n"));
	}
}

/**
   Custom CDFS/UDF callback structure

   RM_ATA_SEND_CMD      Allows to specify the ATAPI callback that will be used to access 
                        the drive from the CDFS/UDF library.
   RM_MEMALLOC          Mem allocation callback used by the CDFS/UDF libraryto allocate memory.
   RM_MEMFREE           Mem free callback used by the CDFS/UDF library to free memory 
                        allocated by a previous call to mmalloc callback.
   RM_CLOSE_FILE        Called when the file is closed in order for the application
                        to clean-up any auxiliary data used while file is opened.
*/

struct RM_CDFS_UDF_CALLBACK_TABLE cdfs_udf_callback_table = {
	RMAtapiSendCommand,
	RMMemAlloc,
	RMMemFree,
	RMFileClose
}; 

/*
 * wide character helper function
 */
static RMuint16 *disc_wcstrncpy(RMuint16 *dest, const RMascii *src, RMuint32 count) {
	if(count > 0) {
		RMuint16 *s = dest;
		s[--count] = 0; //BSD style - zero terminate in any case!!!
		while(count && (*s++ = ((RMuint16)(*src++) << 8)))
			count--;
	}
	return dest;
}


/**
     Find the root device name based on a string such as:
         "/dev/cdrom//MPEG/OPERA1.MPG"
     where "/dev/cdrom" is a non-mounted CDROM.

     Note: the RMascii **devicename should be RMFreeAscii 

*/

#define MAX_PATH 256

static RMstatus FindCDROMRootName(const RMascii *const filename, RMascii **devicename,
				  RMascii const **mountname)	
{
	RMascii test_file_name[MAX_PATH];
	RMascii *double_slash = 0;

	*mountname = 0;

	// We will use a temporary copy where we will replace "/" with "0" to test 
	// if name matches a directory.
	RMNCopyAscii(test_file_name, filename, MAX_PATH);

	if (*test_file_name != '/') {
		RMDBGLOG((ENABLE,"Device %s should start with ""/""\n", test_file_name));
		return RM_ERROR;
	}

	if (RMFindAsciiString(test_file_name + 1, "//", &double_slash) != -1) {
		*double_slash = 0; // Terminate string
		*mountname = filename + (double_slash - test_file_name) + 1;
		*devicename = RMMallocAndDuplicateAscii(test_file_name);
		return (*devicename == 0) ? RM_ERROR : RM_OK;
	}
	else {
		*devicename = 0;
		return RM_ERROR;
	}
}





/**
   Open a stream with custom options

   If the given filename begins with http://, this function will open a HTTP
   stream using the rmlibhttp and wrap it into a regular RMfile, so that it
   appears as a regular file for the end user. If the filename doesn't begin
   with http://, then a regular RMfile is opened. options are additional
   options the user can pass to the underlying library. options should be set
   with a proper accessor funtcion, see set_http_options for example.

   @param filename - URL to open
   @param mode - open mode, see rmfile.h (can be RM_FILE_OPEN_READ,
                 RM_FILE_OPEN_WRITE, or RM_FILE_OPEN_READ_WRITE)
   @param options - options to use for this stream (see set_http_options or
                    other option setting functions), NULL to use the defaults.
   @return RMfile, NULL on error
*/

RMfile _open_stream(const RMascii *filename, RMfileOpenMode mode, struct stream_options_s *options)
{ 
	RMfile m_file = NULL;
	struct stream_options_s *poptions = options;
	struct stream_options_s default_options;
	struct RM_CDFS_UDF_FOPS_COOKIE *pcdfs_udf_fops_cookie;
	RMuint16 wcfilename[256];

	if (poptions == NULL){
		RMstatus status;
		
		status = init_stream_options(&default_options);
		if (RMFAILED(status)){
			RMDBGLOG((ENABLE,"Error setting default options for %s.\n"));
			return NULL;
		}
		poptions = &default_options;
	}

	if(custom_open_stream_callback) {
		m_file = custom_open_stream_callback(filename, mode, poptions);
		if(m_file)
			return m_file;
		//continue with default processing...
	}

	if (RMNCompareAsciiCaseInsensitively((const RMascii *) filename, "http://", 7)){
		HTTPFile *httpFile = NULL;
		
		/* HTTP lib only supports reading right now */
		if (mode != RM_FILE_OPEN_READ)
			return NULL;
		
		if ((poptions->http_custom_header != NULL) && (poptions->http_flags & RM_HTTP_CUSTOM_HEADER)){
			RMDBGLOG((ENABLE,"Session header for %s : %s\n", filename, poptions->http_custom_header));
			fetchSetCustomHeader(poptions->http_custom_header);
		}
		
		if ((poptions->http_custom_cookie != NULL) &&
		    (poptions->http_custom_hooks != NULL) &&
		    (poptions->http_flags & RM_HTTP_CUSTOM_HOOKS))
			fetchSetCustomHooks(poptions->http_custom_cookie, poptions->http_custom_hooks);

		/* Opening a HTTP stream */
		httpFile = fetchOpen((const RMascii *) filename, poptions->http_flags);
		if (httpFile == NULL)
			return NULL;

		m_file = RMOpenFileCookie(httpFile, mode, (RMFileOps *) httpFileOps);
		if (m_file == NULL){
			fetchClose(httpFile);
			return NULL;
		}
#ifdef WITH_SEMIHOSTING
	} else if( RMNCompareAsciiCaseInsensitively( (const RMascii *)filename, "host:", 5 ) ) {
		void* cookie;
		if( mode != RM_FILE_OPEN_READ ) {
			return NULL;
		}
		cookie = open_host( (char *)(filename+5), mode );
		m_file = RMOpenFileCookie( cookie, mode, HostFileOps );
		if (m_file == NULL){
			return NULL;
		}
#endif //WITH_SEMIHOSTING
	} else if (RMNCompareAsciiCaseInsensitively((const RMascii *) filename, "udf://", 6)) { 
		// We use "iso" or "udf" in the URL to find the filesystem)
		// example: "udf://dev/cdrom//MPEG/OPERA1.MPG" will use device "/dev/cdrom"
		// and read the udf file system to find "/MPEG/OPERA1.MPG".

		RMascii *deviceName = NULL; // "/dev/cdrom"
		RMascii TempFileName[MAX_PATH];
		RMascii const *mount_name = NULL;
		RMnonAscii *naname;
		RMstatus status = RM_OK;

		if (FindCDROMRootName(filename + 5, &deviceName, &mount_name) != RM_OK)
			return NULL;

		naname = RMnonAsciiFromAscii(deviceName); // deviceName will need to be freed below

		pcdfs_udf_fops_cookie = RMMalloc(sizeof(struct RM_CDFS_UDF_FOPS_COOKIE));
		RMMemset(pcdfs_udf_fops_cookie, 0, sizeof(struct RM_CDFS_UDF_FOPS_COOKIE));

		pcdfs_udf_fops_cookie->user_cookie = RMOpenPacketCommand(naname); // We use the user cookie to store the packet command handle
		if (pcdfs_udf_fops_cookie->user_cookie == NULL) {                 // packet command handle. Lucky, same type!
			RMDBGLOG((ENABLE,"Cannot open device %s\n", deviceName));
			RMFreeNonAscii(naname);
			return NULL;
		}

		// Mount CDROM drive
		if (RMFAILED(status = RMudfs_mount(&cdfs_udf_callback_table, 
						   &pcdfs_udf_fops_cookie->volume,
						   pcdfs_udf_fops_cookie))) {
			RMDBGLOG((ENABLE,"Cannot mount device %s as UDF\n", deviceName));
			return NULL;
		}

		// Open file
		RMCopyAscii(TempFileName, "/CDROM"); // The library from Olga must have "/CDROM" first in the  file name
		RMAppendAscii(TempFileName, mount_name);
		disc_wcstrncpy(wcfilename, TempFileName, sizeof(wcfilename)/sizeof(RMuint16));

		if (RMFAILED(status = RMudfs_fopen(wcfilename, 
						   &(pcdfs_udf_fops_cookie->hFileHandle)))) {
			RMDBGLOG((ENABLE,"Cannot open file %s\n", mount_name));
			RMDBGLOG((ENABLE,"Note that UDF usually uses upper case names\n"));
			return NULL;
		}

		// Finally set the RMFileOps for all other file operations
		m_file = RMOpenFileCookie(pcdfs_udf_fops_cookie, mode, pudfsFileOps);

		// Clean-up
		RMFreeAscii(deviceName);
		RMFreeNonAscii(naname);
		
	} else {
		RMnonAscii *naname = RMnonAsciiFromAscii(filename);
		m_file = RMOpenFile(naname, mode); // Will be NULL when failing
		RMFreeNonAscii(naname);
	}

	return m_file;
}


/* 
   this is the open function used by the applications play_xxx 
   if PFS prefetching is enabled, the open will be redirected to rmpfs.c
   else _open_stream will be called
*/


RMfile open_stream(const RMascii *filename, RMfileOpenMode mode, struct stream_options_s *options)
{
	RMfile file;
	if (custom_open_for_pfs_callback) {
		file = custom_open_for_pfs_callback(filename, mode, options);
		if (file)
			return file;
		//continue with default processing...
	}

	RMDBGLOG((ENABLE, "regular open\n"));
	return _open_stream(filename, mode, options);
}


RMdirectory open_directory( const RMascii *directoryname )
{
	RMdirectory directory = NULL;
#ifdef WITH_SEMIHOSTING
	if( RMNCompareAsciiCaseInsensitively( directoryname, "host:", 5 ) ) {
		void *cookie = open_host_dir( directoryname+5 );
		if( cookie == NULL ){
			return NULL;
		} else {
			RMOpenDirectoryCookie( &directory, cookie, HostDirOps );
		}
	} else 
#endif //WITH_SEMIHOSTING
	{
		RMnonAscii *dirname = RMnonAsciiFromAscii( directoryname );
		RMOpenDirectory( dirname, &directory );
		RMFreeNonAscii( dirname );
	}
	return directory;
}

