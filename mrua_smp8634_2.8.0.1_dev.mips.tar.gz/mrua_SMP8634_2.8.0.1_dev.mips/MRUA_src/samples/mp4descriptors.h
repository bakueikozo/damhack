/*
 *
 * Copyright (c) Sigma Designs, Inc. 2006. All rights reserved.
 *
 */


/**
   @file mp4descriptors.h
   @brief IOD parsing for MP4 streams
	
   @author Yifan Liu
   @ingroup dccsamplecode
*/



#ifndef __MP4DESCRIPTORS_H__
#define __MP4DESCRIPTORS_H__


typedef void AnyDescriptor;

struct MP4_DecoderConfigDescriptor {
	RMuint8 tag;     /* 8 bits, default to 0x04 */
	RMuint8 size;    /* 8 bits */
	RMuint8 objectTypeIndication;  /* 8 bits */
	RMuint8 streamType;  /* 6 bits */
	RMuint8 upstream;   /* 1 bit */
	/* 1 bit reserved */
	RMuint32 bufferSizeDB;   /* 24 bits */
	RMuint32 maxBitrate;     /* 32 bits */
	RMuint32 avgBitrate;     /* 32 bits */
};


struct MP4_SLConfigDescriptor {
	RMuint8 tag;     /* 8 bits, default to 0x06 */
	RMuint8 size;    /* 8 bits */
	RMuint8 predefined;  /* 8 bits default 0*/
	
	RMuint8 useAccessUnitStartFlag;  /* 1 bit */
	RMuint8 useAccessUnitEndFlag;    /* 1 bit */
	RMuint8 useRandomAccessPointFlag;/* 1 bit */
	RMuint8 hasRandomAccessUnitsOnlyFlag; /* 1 bit */
	
	RMuint8 usePaddingFlag;          /* 1 bit */
	RMuint8 useTimeStampsFlag;       /* 1 bit */
	RMuint8 useIdleFlag;             /* 1 bit */
	RMuint8 durationFlag;            /* 1 bit */
	
	RMuint32 timeStampResolution;    /* 32 bits */
	RMuint32 OCRResolution;          /* 32 bits */
	
	RMuint8 timeStampLength;         /* 8 bits */
	RMuint8 OCRLength;               /* 8 bits */
	RMuint8 AU_Length;               /* 8 bits */
	RMuint8 instantBitrateLength;    /* 8 bits */
	
	RMuint8 degradationPriorityLength; /* 4 bits */
	RMuint8 AU_seqNumLength;           /* 5 bits */
	RMuint8 packet_SeqNumLength;       /* 5 bits */
	/* 2 bits reserved deault to 0b11 */
	
	RMuint32 timeScale;                /* 32 bits */
	RMuint16 accessUnitDuration;       /* 16 bits */
	RMuint16 compositionUnitDuration;  /* 16 bits */
};


struct MP4_ES_Descriptor {
	RMuint8 tag;     /* 8 bits, default to 0x03 */
	RMuint8 size;    /* 8 bits */
	RMuint16 ES_id;  /* 16 bits */
	RMuint8 streamDependentFlag; /* 1 bit */
	RMuint8 URL_flag;            /* 1 bit */
	RMuint8 OCRstreamFlag;       /* 1 bit */
	RMuint8 streamPriority;      /* 5 bits */
	RMuint16 dependsOn_ES_id;    /* 16 bits if streamDependentFlag */

	RMuint8 URLlength;           /* 8 bits  if url_flag */
	RMuint8 URLstring[256];      /* 8 bits * n if url_flag */
	RMuint16 OCR_ES_id;          /* 16 bits if OCRstreamFlag */
	
	AnyDescriptor * esDescr[256];
	RMuint8 esDescrNum;
};


struct MP4_IOD {
	RMuint8 tag;     /* 8 bits, default to 0x02 */
	RMuint8 size;    /* 8 bits, spec says 16 bits */
	RMuint16 id;     /* 10 bits */
	RMuint8 URL_flag;/* 1 bit */
	RMuint8 includeInlineProfiles;  /* 1 bit */
	/* 4 bits reserved default to 0b1111 */
	RMuint8 profileLevelIndication1; /* 8 bits */
	RMuint8 sceneProfileLevelIndication; /* 8 bits   0x01 */
	RMuint8 audioProfileLevelIndication; /* 8 bits   0x0c*/
	RMuint8 visualProfileLevelIndication;/* 8 bits */
	RMuint8 graphicsProfileLevelIndication; /* 8 bits 0x04*/
	
	AnyDescriptor * esDescr[256];
	RMuint8 esDescrNum;
};


extern AnyDescriptor * CreateDescriptor( RMuint8 * p, RMuint16* count );
extern void DestoryDescriptor( AnyDescriptor * des );

extern struct MP4_IOD * CreateIODDescriptor(RMuint8 *p, RMuint16 * count );
extern void DestoryIODDescriptor(struct MP4_IOD * iod);

extern struct MP4_ES_Descriptor * CreateESDescriptor(RMuint8 *p, RMuint16 * count );
extern void DestoryESDescriptor(struct MP4_ES_Descriptor * des);

extern struct MP4_DecoderConfigDescriptor * CreateDecoderConfigDescriptor(RMuint8 *p, RMuint16 * count);
extern void DestoryDecoderConfigDescriptor(struct MP4_DecoderConfigDescriptor * des);

extern struct MP4_SLConfigDescriptor * CreateSLConfigDescriptor(RMuint8 *p, RMuint16 * count);
extern void DestorySLConfigDescriptor(struct MP4_SLConfigDescriptor * des);


extern void ParseIODDescriptor(RMuint8 *p, RMuint16 * bifs, RMuint16 * od  );


#endif // __MP4DESCRIPTORS_H__



