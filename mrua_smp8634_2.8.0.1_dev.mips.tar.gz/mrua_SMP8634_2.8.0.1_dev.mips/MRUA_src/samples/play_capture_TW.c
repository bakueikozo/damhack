/*
 *
 * Copyright (c) Sigma Designs, Inc. 2003. All rights reserved.
 *
 */

/**
	@file play_capture.c
	@brief sample application to access the 86xx chip family
	
	@author Christian Wolff
*/

#include "i2c.h"

#include "play_capture_TW.h"
#include "tw9919eid.h"
#ifndef NO_AUDIO
#include "msp4450g.h"
#endif


#include "cpu_uart_gpio.h"




#define STOP_AUDIO_IF_NO_VIDEO 1
#include "ad9380.h"
#include "mcp23008.h"
RMuint32 ad9380_dev=0x98;
RMuint32 ad9380_delay=10;

RMuint32 I2C_ModuleID = I2C;

static RMuint8 cc_buf[256], dtv_buf[128];
static RMuint32 cc_size = 0, dtv_size = 0;

RMuint32 TimerNumber = 3;

#define SCANPARAM(x, msg, skip) do {	argi++;	if (argi < argc) {		param = strtoul(argv[argi], &endptr, 0);	if (endptr[0] == '\0') x = param;	else {			fprintf(stderr, msg " after %s\n", argv[argi - skip]);			err = RM_ERROR;	}} else {	fprintf(stderr, "Please specify %d number%s after %s\n", skip, (skip == 1) ? "" : "s", argv[argi - skip]);	err = RM_ERROR;	}} while(0)
#define RUASetPendingProperty(inst, mod, prop, paramptr, paramsize, text) do { 	do { 	err = RUASetProperty(inst, mod, prop, paramptr, paramsize, 0); 	} while (err == RM_PENDING); 	if (RMFAILED(err)) { 	RMDBGLOG((ENABLE, text ": %s\n", RMstatusToString(err))); 	return err; 	} } while (0)

struct display_cmdline disp_opt;
struct capture_cmdline capture_opt[2];
struct audio_cmdline audio_opt;


RMuint32 chip_num;
RMuint32 input_num;

// options->output_window needs to be set when calling this!
static RMstatus init_local_options(
	struct local_cmdline *options)
{
	options->zoom_force = FALSE;
	options->zoom_x = ZOOM_0;
	options->zoom_y = ZOOM_0;
	options->zoom_w = ZOOM_1;
	options->zoom_h = ZOOM_1;
	options->zoomstep = 1;
	set_default_out_window(options->output_window);
	options->force_overscan_crop = FALSE;
	options->overscan_crop = 0;
	options->overscan_crop_amount = 5;  // 2.5% on each edge. ITU Bt.1379.1 specifies 3.5% "safe action" and 5% "safe title"
	options->arg_vbi = 0;
	options->parse_anc = FALSE;
	options->print_anc = FALSE;
	options->dump_vbi = FALSE;
	options->i2c_init = FALSE;
	options->i2c_module = 0;
	options->enable_i2c_cc = FALSE;
	options->enable_i2c_wss = FALSE;
	options->ccfifo_print = FALSE;
	options->use_soft_cc_decoder = 0;
	options->ccfifo_id_in = 0;
	options->ccfifo_id_send = 0;
	options->ccfifo_id_out = 0;
	options->ccfifo_addr_in = 0;
	options->ccfifo_addr_out = 0;
	options->VBIOffs = 0;
	options->pVBIData = NULL;
	options->vbidump = NULL;
	options->update = FALSE;
	options->use_gpio_fid = FALSE;
	options->invert_fid = FALSE;
	options->last_hotplug = FALSE;
	options->pR = NULL;
	options->pDmaReceive = NULL;
	options->force_active_format = FALSE;
	options->active_format = EMhwlibAF_same_as_picture;
	options->force_wide_screen = FALSE;
	options->wide_screen = FALSE;
	options->wss_odd = 0;
	options->wss_even = 0;
	options->last_hdcp_ok = FALSE;
	options->last_power = FALSE;
	options->last_sync = FALSE;
	options->last_clock = FALSE;
	options->last_auth = FALSE;
	options->last_crypt = FALSE;
	options->cable_eq = 0x0C;
	options->last_avi.valid = FALSE;
	options->new_avi = FALSE;
	options->update_videomode = FALSE;
	options->follow_vfreq = FALSE;
	options->verbouse = FALSE;
	options->green_bg = FALSE;
	options->hdmi_mode = mode_unknown;
	options->upsample_from_422 = FALSE;
	//options->last_isrc_header = 0;
	//options->last_isrc2 = FALSE;
	//RMMemset(options->last_isrc, 0xFF, sizeof(options->last_isrc));
	options->i2c_init = TRUE;
	options->i2c_port = cap_CVBS1;
	//options->i2c_port = cap_SVideo1;
	//options->i2c_video_chip = cap_SAA7119;
	//options->i2c_video_dev = 0x20;
	options->i2c_video_chip = cap_TW9919;
	options->i2c_video_dev = 0x44;
	options->i2c_video_delay = 10;
	
	options->i2c_audio1_chip = cap_WM8775;
	options->i2c_audio1_dev = 0x1A;
	options->i2c_audio1_delay = 10;
	
	//options->i2c_board = cap_sigma760e2hdlcd;
	options->i2c_board = cap_sigma895e1;
	
	options->i2c_audio2_chip = cap_MSP34x5;
	options->i2c_audio2_dev = 0x44;
	options->i2c_audio2_delay = 10;
	
	return RM_OK;
}

static void show_local_options(void)
{
	fprintf(stderr, "PLAY_CAPTURE OPTIONS\n");
	fprintf(stderr, "  -v: verbouse (twice for more verbouse)\n");
	fprintf(stderr, "  -m <chip>: number of the mambo chip (default: 0)\n");
	fprintf(stderr, "  -window <x> <y> <w> <h>: specify position, width and height of the scaler window\n");
	fprintf(stderr, "  -zoom <x> <y> <w> <h>: zoom window into the captured video\n");
	fprintf(stderr, "    all zoom values: 0..4095: absolute pixel, 4096..8192: 0%%..100%% relative size\n");
	fprintf(stderr, "  -inclip <mode>: set clipping or wide mode of input: (n)ormal, (w)ide, (l)etterbox\n");
	fprintf(stderr, "  -vbidump <filename>: dump received VBI data to a binary file\n");
	fprintf(stderr, "  -vbiprint: print a hex-dump of the received VBI data block\n");
	fprintf(stderr, "  -anc: parse VBI data for ANC header and print any Line21-CC text or TeleText\n");
	fprintf(stderr, "  -ancprint: print also the ANC header info and a payload hex dump\n");
	fprintf(stderr, "  -i2c <module>: which i2c module to use (0=software, 1=hardware)\n");
	fprintf(stderr, "  -I <board> <port> [<dev> [<delay>]]: do i2c initialisation, defaults in []\n");
	fprintf(stderr, "    chip or board:\n");
	fprintf(stderr, "      [775]  (A/V-Input with saa7119, WM8775), \n");
	fprintf(stderr, "      760e1  (HD Ref. w/ adv7402, MSP34x5), \n");
	fprintf(stderr, "      760e2  (LCD Ref. w/ saa7119, WM8775, MSP34x5), \n");
	fprintf(stderr, "      844e1  (DTV Ref. w/ saa7119, SiI9031, AD9883, WM8775, MSP34x5), \n");
	fprintf(stderr, "      jamo   (KiSS Jamo plasma w/ 2 saa7119, AD9888, MSP34x5)\n");
	fprintf(stderr, "      809e1  (Pioneer Video Card w/ saa7119, SiI9031, WM8738)\n");
	fprintf(stderr, "    port: [cvbs1], cvbs2, svideo1, svideo2, vga, yuv1, yuv2, \n");
	fprintf(stderr, "      scart1, scart2, tuner1, tuner2, hdmi0, hdmi1\n");
	fprintf(stderr, "    dev: i2c device address of the video chip [0x40] (optional)\n");
	fprintf(stderr, "    delay: i2c delay [0] (optional)\n");
	fprintf(stderr, "  -i2ccc: enable CC passthrough from Philips 7119 via i2c\n");
	fprintf(stderr, "  -ccprint: print closed caption data from the CC fifo\n");
	fprintf(stderr, "    (passing through the app instead of direct passthrough)\n");
	fprintf(stderr, "  -softcc, -softcc608: enable NTSC software CC decoding on top of output picture\n");
	fprintf(stderr, "  -softcc708: enable PAL software CC decoding on top of output picture\n");
	fprintf(stderr, "  -i2cwss: enable WSS passthrough from Philips 7119 via i2c\n");
	fprintf(stderr, "  -update: continuusly check for video mode change and adjust\n");
	fprintf(stderr, "  -gpiofid: use input field ID from GPIO pin\n");
	fprintf(stderr, "  -fidinv: invert detected field ID\n");
	fprintf(stderr, "  -eq <len>: cable length equalisation, 0..15 [12]\n");
	fprintf(stderr, "  -fv: follow the vertical frequency of the capture on the output\n");
	fprintf(stderr, "  -bg: use a different background color than black\n");
	fprintf(stderr, "  -ov <crop>: percentage of frame size to crop around edge for overscanned pictures [5] (applies to VGA, LVDS and digital outputs only)\n");
}

static RMstatus parse_local_cmdline(
	int argc, 
	char **argv, 
	int *index, 
	struct local_cmdline *options)
{
	RMstatus err = RM_OK;
	int argi = *index;
	RMuint32 param;
	RMascii *endptr;
	
	if (argv[argi][0] == '-') {
		if (! strcmp(&(argv[argi][1]), "zoom")) {
			options->zoom_force = TRUE;
			SCANPARAM(options->zoom_x, "please specify a x value", 1);
			SCANPARAM(options->zoom_y, "please specify a y value", 2);
			SCANPARAM(options->zoom_w, "please specify a w value", 3);
			SCANPARAM(options->zoom_h, "please specify a h value", 4);
		}
		else if (! strcmp(&(argv[argi][1]), "inclip")) {
			argi++;
			if (argi < argc) {
				switch (argv[argi][0]) {
					default:
					case 'n':  // NTSC WSS "4:3 frame"
					case 'N':
						options->force_active_format = TRUE;
						options->active_format = EMhwlibAF_same_as_picture;
						options->force_wide_screen = TRUE;
						options->wide_screen = FALSE;
						break;
					case 'w':  // NTSC WSS "16:9 frame"
					case 'W':
						options->force_active_format = TRUE;
						options->active_format = EMhwlibAF_same_as_picture;
						options->active_format = EMhwlibAF_same_as_picture;
						options->force_wide_screen = TRUE;
						options->wide_screen = TRUE;
						break;
					case 'l':  // NTSC WSS "16:9 in 4:3 frame"
					case 'L':
						options->force_active_format = TRUE;
						options->active_format = EMhwlibAF_16x9_centered;
						options->force_wide_screen = TRUE;
						options->wide_screen = FALSE;
						break;
				}
			} else {
				fprintf(stderr, "please specify a mode (normal, wide or letterbox) after %s\n", argv[argi - 1]);
				err = RM_ERROR;
			}
		}
		else if (! strcmp(&(argv[argi][1]), "window")) {
			SCANPARAM(options->output_window->X, "please specify a x value", 1);
			SCANPARAM(options->output_window->Y, "please specify a y value", 2);
			SCANPARAM(options->output_window->Width, "please specify a w value", 3);
			SCANPARAM(options->output_window->Height, "please specify a h value", 4);
			options->output_window->XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
			options->output_window->YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
			options->output_window->XMode = EMhwlibDisplayWindowValueMode_Fixed;
			options->output_window->YMode = EMhwlibDisplayWindowValueMode_Fixed;
			options->output_window->WidthMode = EMhwlibDisplayWindowValueMode_Fixed;
			options->output_window->HeightMode = EMhwlibDisplayWindowValueMode_Fixed;
		}
		else if (! strcmp(&(argv[argi][1]), "vbidump")) {
			argi++;
			if (argi < argc) {
				options->arg_vbi = argi;
			} else {
				fprintf(stderr, "please specify a file name after %s\n", argv[argi - 1]);
				err = RM_ERROR;
			}
		}
		else if (! strcmp(&(argv[argi][1]), "vbiprint")) {
			options->dump_vbi = TRUE;
		}
		else if (! strcmp(&(argv[argi][1]), "anc")) {
			options->parse_anc = TRUE;
		}
		else if (! strcmp(&(argv[argi][1]), "ancprint")) {
			options->parse_anc = TRUE;
			options->print_anc = TRUE;
		}
		else if (! strcmp(&(argv[argi][1]), "m")) {
			SCANPARAM(chip_num, "please specify a chip number", 1);
		}
		else if (! strcmp(&(argv[argi][1]), "i2ccc")) {
			options->enable_i2c_cc = TRUE;
		}
		else if (! strcmp(&(argv[argi][1]), "i2cwss")) {
			options->enable_i2c_wss = TRUE;
		}
		else if (! strcmp(&(argv[argi][1]), "ccprint")) {
			options->ccfifo_print = TRUE;
		}
		else if (! strcmp(&(argv[argi][1]), "softcc")) {
			options->use_soft_cc_decoder = 1;
		}
		else if (! strcmp(&(argv[argi][1]), "softcc608")) {
			options->use_soft_cc_decoder = 1;
		}
		else if (! strcmp(&(argv[argi][1]), "softcc708")) {
			options->use_soft_cc_decoder = 2;
		}
		else if (! strcmp(&(argv[argi][1]), "i2c")) {
			SCANPARAM(options->i2c_module, "please specify a i2c module number", 1);
		}
		else if (! strcmp(&(argv[argi][1]), "I")) {
			options->i2c_init = TRUE;
			options->i2c_board = cap_sigma775avinput;
			options->i2c_port = cap_CVBS1;
			options->i2c_video_chip = cap_SAA7119;
			options->i2c_video_dev = 0x20;
			options->i2c_video_delay = 10; //0;
			options->i2c_audio1_chip = cap_WM8775;
			options->i2c_audio1_dev = 0x1A;
			options->i2c_audio1_delay = 10; //0;
			options->i2c_audio2_chip = cap_NoChip;
			options->i2c_audio2_dev = 0x00;
			options->i2c_audio2_delay = 10; //0;
			if (argi + 1 >= argc) goto SKIP;
			if (argv[argi + 1][0] == '-') goto SKIP;
			argi++;
			if (! strcmp(argv[argi], "775")) {
				options->i2c_board = cap_sigma775avinput;
			} else if (! strcmp(argv[argi], "760e2")) {
				options->i2c_video_chip = cap_SAA7119;
				options->i2c_video_dev = 0x20;
				options->i2c_video_delay = 10;				
				options->i2c_board = cap_sigma760e2hdlcd;
				options->i2c_audio2_chip = cap_MSP34x5;
				options->i2c_audio2_dev = 0x44;
				options->i2c_audio2_delay = 10;
			} else if (! strcmp(argv[argi], "760e1")) {
				options->i2c_board = cap_sigma760e1hdref;
				options->i2c_video_chip = cap_ADV7402;
				options->i2c_video_dev = 0x21;
				options->i2c_audio1_chip = cap_MSP34x5;
				options->i2c_audio1_dev = 0x44;
			} else if (! strcmp(argv[argi], "844e1")) {
				options->i2c_board = cap_sigma844e1dtv;
				options->i2c_audio1_chip = cap_MSP34x5;
				options->i2c_audio1_dev = 0x44;
			} else if (! strcmp(argv[argi], "809e1")) {
				options->i2c_board = cap_pioneer809e1video;
				options->i2c_audio1_chip = cap_NoChip;
				options->i2c_audio1_dev = 0x00;
			} else if (! strcmp(argv[argi], "jamo")) {
				options->i2c_board = cap_kissjamoplasma;
				options->i2c_audio1_chip = cap_MSP34x5;
				options->i2c_audio1_dev = 0x40;
			} else if (! strcmp(argv[argi], "895e1")) {  //TW9919
				options->i2c_board = cap_sigma895e1;
				//				options->i2c_video_chip=cap_TW9919;
				//				options->i2c_video_dev=0x88>>1; // 0x44 << 1 = 0x88
				//				options->i2c_video_delay=10;
				//				options->i2c_audio1_chip = cap_MSP34x5;  // ?
				//				options->i2c_audio1_dev = 0x40; //0x44 ?
			} else {
				fprintf(stderr, "unknown capture board: %s\n", argv[argi]);
				err = RM_ERROR;
				goto SKIP;
			}
			if (argi + 1 >= argc) goto SKIP;
			if (argv[argi + 1][0] == '-') goto SKIP;
			argi++;
			if (! strcmp(argv[argi], "direct")) {
				options->i2c_port = cap_Direct;
			} else if (! strcmp(argv[argi], "cvbs1")) {
				options->i2c_port = cap_CVBS1;
			} else if (! strcmp(argv[argi], "cvbs2")) {
				options->i2c_port = cap_CVBS2;
			} else if (! strcmp(argv[argi], "svideo1")) {
				options->i2c_port = cap_SVideo1;
			} else if (! strcmp(argv[argi], "svideo2")) {
				options->i2c_port = cap_SVideo2;
			} else if (! strcmp(argv[argi], "vga")) {
				options->i2c_port = cap_VGA;
			} else if (! strcmp(argv[argi], "yuv1")) {
				options->i2c_port = cap_Component1;
			} else if (! strcmp(argv[argi], "yuv2")) {
				options->i2c_port = cap_Component2;
			} else if (! strcmp(argv[argi], "scart1")) {
				options->i2c_port = cap_ScartCVBS1;
			} else if (! strcmp(argv[argi], "scart2")) {
				options->i2c_port = cap_ScartCVBS2;
			} else if (! strcmp(argv[argi], "tuner1")) {
				options->i2c_port = cap_Tuner1;
			} else if (! strcmp(argv[argi], "tuner2")) {
				options->i2c_port = cap_Tuner2;
			} else if (! strcmp(argv[argi], "hdmi0")) {
				options->i2c_port = cap_HDMI0;
			} else if (! strcmp(argv[argi], "hdmi1")) {
				options->i2c_port = cap_HDMI1;
			} else {
				fprintf(stderr, "unknown capture port: %s\n", argv[argi]);
				err = RM_ERROR;
				goto SKIP;
			}
			if (argi + 1 >= argc) goto SKIP;
			if (argv[argi + 1][0] == '-') goto SKIP;
			SCANPARAM(options->i2c_video_dev, "please specify a video i2c device address", 1);
			options->i2c_video_dev >>= 1;
			if (err == RM_ERROR) goto SKIP;
			if (argi + 1 >= argc) goto SKIP;
			if (argv[argi + 1][0] == '-') goto SKIP;
			SCANPARAM(options->i2c_video_delay, "please specify a delay value", 1);
			options->i2c_audio1_delay = options->i2c_video_delay;
			options->i2c_audio2_delay = options->i2c_video_delay;
		}
		else if (! strcmp(&(argv[argi][1]), "update")) {
			options->update = TRUE;
		}
		else if (! strcmp(&(argv[argi][1]), "gpiofid")) {
			options->use_gpio_fid = TRUE;
		}
		else if (! strcmp(&(argv[argi][1]), "fidinv")) {
			options->invert_fid = TRUE;
		}
		else if (! strcmp(&(argv[argi][1]), "eq")) {
			SCANPARAM(options->cable_eq, "please specify a cable length", 1);
			options->cable_eq &= 0x0F;
		}
		else if (! strcmp(&(argv[argi][1]), "fv")) {
			options->follow_vfreq = TRUE;
		}
		else if (! strcmp(&(argv[argi][1]), "v")) {
			if (options->verbouse) options->intr_debug = TRUE;
			options->verbouse = TRUE;
		}
		else if (! strcmp(&(argv[argi][1]), "bg")) {
			options->green_bg = TRUE;
		}
		else {
			err = RM_PENDING;
		}
	}
SKIP:
	if (err == RM_OK) 
		*index = argi + 1;
	
	return err;
}

static RMstatus init_capture_ADV7402(
	struct RUA *pInstance, 
	struct capture_cmdline *capture_opt, 
	struct local_cmdline *local_opt, 
	RMuint8 dev, 
	RMuint8 delay)
{
	// ADV7402 setup
	RMuint8 i2c_data_cvbs[][2] = {
		// CVBS in
		{0x00, 0x0F},  // PAL/NTSC auto detect, CVBS in
		{0x03, 0x0C},  // OF_SEL: 8 bit 4:2:2, enabled
		{0x05, 0x00},  // CVBS in
		{0x15, 0x41},  // dig. clamp time const.
		{0x17, 0x41},  // 
		{0x39, 0x40},  // PAL Comb
		{0x3A, 0x16},  // power down ADC 1&2
		{0x3B, 0x80},  // ext. bias res.
		{0x4D, 0xEF},  // enable CTI
		{0x69, 0x01},  // SDM for CVBS on AIN11
		{0xCD, 0x00},  // 
		{0xCE, 0x01},  // 
		{0xDB, 0xBB},  //
		// setup decoder
	//	{0x0E, 0x80},  // 
	//	{0xB4, 0x13},  // 
	//	{0xB5, 0x03},  // 
	//	{0xD0, 0x4A},  // 
	//	{0xDC, 0xEF},  // 
	//	{0x0E, 0x00},  // 
	};
	RMuint8 i2c_data_yuv[][2] = {
		// YUV in
		{0x00, 0x09},  // PAL/NTSC auto detect, YUV in
		{0x05, 0x01},  // Component in
		{0x15, 0x41},  // dig. clamp time const.
		{0x27, 0xE1},  // 
		{0x3B, 0x80},  // ext. bias res.
		{0x4D, 0xEF},  // enable CTI
		{0x51, 0x24},  // 
		{0xC3, 0x46},  // route Ain6 to ADC0, Ain4 to ADC1
		{0xC4, 0xF5},  // route Ain5 to ADC2
		{0xCD, 0x00},  // 
		{0xCE, 0x01},  // 
		{0xDB, 0xBB},  //
		// setup decoder
		{0x0E, 0x80},  // 
		{0xB5, 0x03},  // 
		{0xD0, 0x44},  // 
		{0xDC, 0xEF},  // 
		{0x0E, 0x00},  // 
	};
	RMuint8 i2c_data_vga[][2] = {
		// VGA:
		{0x05, 0x02},  // VGA RGB in
		{0x06, 0x08},  // 640x480@60Hz
		{0x3A, 0x10},  // set latch clock settings to 001b
		{0x3B, 0x80},  // External Bias Enable
		{0x3C, 0x5C},  // PLL_QPUMP to 011b
		// RGB->YUV CSC
		{0x52, 0x00}, 
		{0x53, 0x00}, 
		{0x54, 0x07}, 
		{0x55, 0x0C}, 
		{0x56, 0x94}, 
		{0x57, 0x89}, 
		{0x58, 0x48}, 
		{0x59, 0x08}, 
		{0x5A, 0x00}, 
		{0x5B, 0x20}, 
		{0x5C, 0x03}, 
		{0x5D, 0xA9}, 
		{0x5E, 0x1A}, 
		{0x5F, 0xB8}, 
		{0x60, 0x08}, 
		{0x61, 0x00}, 
		{0x62, 0x7A}, 
		{0x63, 0xE1}, 
		{0x64, 0x00}, 
		{0x65, 0x19}, 
		{0x66, 0x48}, 
		// 8 bit 4:2:2 output
		{0x67, 0x03},  // DPP decimation 4:2:2 oversampled
	//	{0x67, 0x01},  // DPP decimation 4:2:2
		{0x68, 0x00},  // 
		{0x6A, 0x80},  // double output clock
		{0x6B, 0x83},  // 8/16 bit 4:2:2
		{0x73, 0x90},  // manual gain mode
		{0x74, 0xB4},  // gain
		// 8 bit prec., 64 Y offset, 512 Cb and Cr offset
		{0x77, 0x84}, 
		{0x78, 0x08}, 
		{0x79, 0x02}, 
		{0x7A, 0x00}, 
		{0xB3, 0xFE},  // STDI & Free Run tweek
		{0xF4, 0x3F},  // Max Drive Strength
		{0xC9, 0x0C},  // Enable DDR Mode
	//	{0x0E, 0x80},  // Enable Hidden Space
	//	{0x58, 0xED},  // Change Xtal power to PVDD
	//	{0x0E, 0x00},  // Disable Hidden Space
	};
	switch (local_opt->i2c_port) {
		case cap_CVBS1:
		case cap_CVBS2:
		case cap_SVideo1:
		case cap_SVideo2:
			return init_i2c(pInstance, delay, dev, i2c_data_cvbs, sizeof(i2c_data_cvbs) / sizeof (RMuint8) / 2);
		case cap_VGA:
			return init_i2c(pInstance, delay, dev, i2c_data_vga, sizeof(i2c_data_vga) / sizeof (RMuint8) / 2);
		case cap_Component1:
		case cap_Component2:
			return init_i2c(pInstance, delay, dev, i2c_data_yuv, sizeof(i2c_data_yuv) / sizeof (RMuint8) / 2);
		default:
			return RM_ERROR;
	}
	return RM_OK;
}

/* calculates nominal increment with 32 bit integer arithmetic */
/* returns (f_in / f_out * 2 ^ frac_bits */
static RMuint32 nominal_increment(RMuint32 f_in, RMuint32 f_out, RMuint32 frac_bits) 
{
	RMuint32 div;
	RMint32 shift;
	
	/* sanity check */
	if (!f_out) {
		RMDBGLOG((ENABLE, "Error: clean divider output frequency not set!\n"));
		return 0;
	}
	
	/* align denominator to enumerator */
	div = 0;
	shift = 0;
	while ((f_out < f_in) && ((f_out & 0x80000000) == 0)) {
		f_out <<= 1;
		shift++;
	}
	
	/* calculate integer part of division */
	while (1) {
		if (f_in >= f_out) {
			f_in -= f_out;
			div |= 1;
		}
		if (! shift) break;
		f_out >>= 1;
		div <<= 1;
		shift--;
	}
	
	div <<= 1;
	
	/* calculate first frac_bits bits of fractional part */
	while (1) {
		if (f_in & 0x80000000) {
			if ( ((f_in == (f_out >> 1)) && (!(f_out & 1))) || (f_in > (f_out >> 1))) {
				f_in -= (f_out >> 1);
				div |= 1;
			}
			f_in <<= 1;
			if (f_out & 1) f_in -= 1;
		} else {
			f_in <<= 1;
			if (f_in >= f_out) {
				f_in -= f_out;
				div |= 1;
			}
		}
		if (shift <= (((RMint32)frac_bits - 1) * -1)) break;
		if (div & 0x80000000) RMDBGLOG((ENABLE, "Overflow!\n"));
		div <<= 1;
		shift--;
	}
	
	return div;
}

static RMstatus init_capture_SAA7119_amclk(
	struct RUA *pInstance, 
	struct capture_cmdline *capture_opt, 
	struct local_cmdline *local_opt, 
	RMuint8 dev, 
	RMuint8 delay, 
	RMuint32 sample_clk, 
	RMuint32 xtal_clk, 
	RMbool use_cg2)
{
	RMstatus err;
	RMuint32 mclk, acpf = 0, acni = 0;
	struct EMhwlibTVFormatDigital fmt;
	RMuint32 vfreq_n, vfreq_m;
	
	// Philips SAA 7119 audio PLL setup
	//   mclk = sample_clk * 256
	//   sclk = sample_clk * 64
	//   lrclk = sample_clk
	RMuint8 i2c_data[][2] = {
		{0x30, 0x00},  // 0  [7:0] acfp = mclk / v-freq
		{0x31, 0xc0},  // 1  [15:8]
		{0x32, 0x03},  // 2  [17:16]
		{0x34, 0xce},  // 3  [7:0] acni = mclk * 2^23 / xtal_clk
		{0x35, 0xfb},  // 4  [15:8]
		{0x36, 0x30},  // 5  [21:16]
		{0x38, 0x01},  // 6  sdiv = (mclk / (2 * sclk)) - 1;
		{0x39, 0x20},  // 7  lrdiv = sclk / lrclk / 2
		{0x3a, 0x00},  // 8  80:use CG2, 08:freerunning/00:fieldlocked  
		{0x3b, 0x3f},  //    3b-3f recommended values
		{0x3c, 0xd1},
		{0x3d, 0x31},
		{0x3e, 0x03},
	};
	
	RMuint8 i2c_data_ext[][2] = {
		{0xE0, 0x00},  // 0  [7:0] splpl = clk_lfco / h-freq * 2
		{0xE1, 0x08},  // 1  [3:0]sppi=0, [1:0]spmod=2 [9:8]splpl
		{0xE2, 0x03},  // 2  [7:0] spninc = 2^17 * clk_lfco / xtal_clk
		{0xE3, 0xce},  // 3  [15:8]spninc
		{0xE4, 0x88},  // 4  [3:0]spthrl=8, [3:0]spthrm=8
		{0xE5, 0x00},  // 5  spbypns=0, [6:0]cg2fbd
		{0xE6, 0xd0},  // 6  cg2divres=1, cg2en=1, sphsel=0, [2:0]cg2ckdl=4, [1:0]cg2od
		{0xE7, 0x31},  // 7  [3:0]cg2r=3, [3:0]cg2i=1
		{0xE8, 0x03},  // 8  [4:0]cg2p=3
	};
	
	mclk = sample_clk * 256;
	
	// get current capture video format
	err = RUAGetProperty(pInstance, capture_opt->InputModuleID, 
		RMGenericPropertyID_TVFormat, &fmt, sizeof(fmt));
	if (RMFAILED(err) || (fmt.HTotalSize == 0) || (fmt.VTotalSize == 0)) {
		fprintf(stderr, "Failed to get valid TVFormat from input, assuming 59.94 Hz video\n");
		vfreq_m = 1001;
		vfreq_n = 60000;
	} else {
		if ((fmt.PixelClock == 74175824) || (fmt.PixelClock == 148351648)) vfreq_m = 1001;
		else vfreq_m = ((fmt.HTotalSize * fmt.VTotalSize) % 1001 == 0) ? 1001 : 1000;
		vfreq_n = ((RMuint64)fmt.PixelClock * (RMuint64)vfreq_m * (fmt.TopFieldHeight ? 2 : 1)) / fmt.HTotalSize / fmt.VTotalSize;
	}
	
	if (use_cg2) {
		// Audio PLL --> CG2 PLL --> MClk,SClk,LRClk
		RMuint32 LFCO_freq, k;
		RMuint32 splpl, spninc, cg2fbd, cg2od;
		
		k = (mclk + (3375000 / 2)) / 3375000;
		if (k < 4) k = 4;
		LFCO_freq = mclk / k;
		acpf = (RMuint32)(((RMuint64)vfreq_m * (RMuint64)LFCO_freq * 2) / vfreq_n);
		acni = nominal_increment(LFCO_freq, xtal_clk, 24);
		// mclk = LFCO_freq * 2 * (cg2fbd + 1) / (cg2od + 1) / 4, cg2fbd=31..92(94?), cg2od=0..3
		for (cg2od = 0; cg2od < 4; cg2od++) {
			cg2fbd = k * 4 * (cg2od + 1) / 2 - 1;  // LFCO_freq * 2 * mclk / (cg2od + 1) / 4 - 1;
			if ((cg2fbd >= 31) && (cg2fbd <= 94)) {
				// Check PLL internal frequency range, for square pixel mode only
				//RMuint32 clk_int = LFCO_freq * 2 * (cg2fbd + 1);
				//if ((clk_int >= 275000000) && (clk_int <= 550000000)) break;
				break;
			}
		}
		if (cg2od >= 4) {
			fprintf(stderr, "Can not use CG2, fall back to audio PLL\n");
			use_cg2 = FALSE;
		} else {
			if (fmt.PixelClock) {
				splpl = (RMuint32)(((RMuint64)LFCO_freq * (RMuint64)fmt.HTotalSize * 2) / fmt.PixelClock);
			} else {
				splpl = 0;
			}
			spninc = nominal_increment(LFCO_freq, xtal_clk, 17);
			i2c_data_ext[0][1] = RMunshiftBits(splpl, 8, 0);
			i2c_data_ext[1][1] |= RMunshiftBits(splpl, 2, 8);
			i2c_data_ext[2][1] = RMunshiftBits(spninc, 8, 0);
			i2c_data_ext[3][1] = RMunshiftBits(spninc, 8, 8);
			i2c_data_ext[5][1] |= RMunshiftBits(cg2fbd, 7, 0);
			i2c_data_ext[6][1] |= RMunshiftBits(cg2od, 2, 0);
			err = init_i2c(pInstance, delay, dev + 4, i2c_data_ext, sizeof(i2c_data_ext) / sizeof (RMuint8) / 2);
			if (RMFAILED(err)) return err;
			i2c_data[8][1] = 0x80;  // enable CG2
		}
	}
	if (! use_cg2) {
		// Audio PLL --> MClk,SClk,LRClk
		acpf = (RMuint32)((((RMuint64)vfreq_m * (RMuint64)mclk) + (vfreq_n / 2)) / vfreq_n);
		acni = nominal_increment(mclk, xtal_clk, 23);
	}
	i2c_data[0][1] = RMunshiftBits(acpf, 8, 0);
	i2c_data[1][1] = RMunshiftBits(acpf, 8, 8);
	i2c_data[2][1] = RMunshiftBits(acpf, 2, 16);
	i2c_data[3][1] = RMunshiftBits(acni, 8, 0);
	i2c_data[4][1] = RMunshiftBits(acni, 8, 8);
	i2c_data[5][1] = RMunshiftBits(acni, 6, 16);
	err = init_i2c(pInstance, delay, dev, i2c_data, sizeof(i2c_data) / sizeof (RMuint8) / 2);
	if (RMFAILED(err)) return err;
	return err;
}

static RMstatus init_capture_SiI9031_amclk(
	struct RUA *pInstance, 
	RMuint8 dev, 
	RMuint8 delay, 
	RMbool enable)
{
	RMstatus err;
	RMuint8 i2c_data_ext[][2] = {
		{0x00, 0x85},  // init ACR in auto mode, no overrides
		{0x02, 0x52},  // MClk=256*fs
		{0x13, 0x03},  // recommended WINDIV value
		{0x14, 0x00},  // recommended LKTHRESH value
		{0x15, 0x00}, 
		{0x16, 0x00}, 
		{0x17, 0x10},  // enable fs filter
		{0x18, 0x0C},  // enable MClk loop back
		{0x26, 0xC0},  // I2S: 32 bit frames, align 1 (philips format)
		{0x28, 0xE4},  // default FIFO mapping
		{0x2E, 0x00},  // no swap
		{0x32, 0x00},  // no mute
	};
	
	err = init_i2c(pInstance, delay, dev + 4, i2c_data_ext, sizeof(i2c_data_ext) / sizeof (RMuint8) / 2);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to init SiI9031!\n");
		return err;
	}
	if (enable) {
		err = write_i2c(pInstance, delay, dev + 4, 0x27, 0x19);  // Enable I2S0 out and MClk, send PCM only on I2S
		err = write_i2c(pInstance, delay, dev + 4, 0x29, 0x3D);  // Enable I2S and SPDIF signals and HW-mute
	} else {
		err = write_i2c(pInstance, delay, dev + 4, 0x27, 0x01);  // Disable I2S0 out and MClk, send PCM only on I2S
		err = write_i2c(pInstance, delay, dev + 4, 0x29, 0x38);  // Disable I2S and SPDIF signals
	}
	err = write_i2c(pInstance, delay, dev, 0x05, 0xD2); // reset of audio FIFO, put HDCP and ACR in auto-reset
	err = write_i2c(pInstance, delay, dev, 0x05, 0xD0); // end reset
	
	return RM_OK;
}

static RMstatus tristate_AD9883(
	struct RUA *pInstance, 
	RMuint8 delay, 
	RMuint8 dev)
{
	RMstatus err;
	err = write_i2c(pInstance, delay, dev, 0x0F, 0x4C); // power down AD9883A
	return err;
}

static RMstatus tristate_SiI9031(
	struct RUA *pInstance, 
	RMuint8 delay, 
	RMuint8 dev)
{
	RMstatus err;
	err = write_i2c(pInstance, delay, dev, 0x08, 0x04); // power down SiI9031
	err = write_i2c(pInstance, delay, dev, 0x09, 0x00); // tri-state SiI9031
	err = write_i2c(pInstance, delay, dev + 4, 0x27, 0x01); // Disable I2S out and MClk
	err = write_i2c(pInstance, delay, dev + 4, 0x29, 0x18); // Disable I2S signals
	err = write_i2c(pInstance, delay, dev + 4, 0x3C, 0x00); // power down and tri-state chip.
	err = write_i2c(pInstance, delay, dev + 4, 0x3E, 0x00); // power down and tri-state chip.
	err = write_i2c(pInstance, delay, dev + 4, 0x3F, 0x00); // power down and tri-state chip.
	return err;
}

static RMstatus tristate_SAA7119(
	struct RUA *pInstance, 
	RMuint8 delay, 
	RMuint8 dev)
{
	RMstatus err;
	err = write_i2c(pInstance, delay, dev, 0x83, 0x10); // tri-state xport
	err = write_i2c(pInstance, delay, dev, 0x87, 0x10); // tri-state iport
	err = write_i2c(pInstance, delay, dev, 0x88, 0x0D); // reset and power down scaler, tri-state audio clocks
	return err;
}

static RMstatus init_capture_AD9883(
	struct RUA *pInstance, 
	struct capture_cmdline *capture_opt, 
	struct local_cmdline *local_opt, 
	RMuint8 dev, 
	RMuint8 delay)
{
	RMstatus err;
	RMuint8 range, current;
	struct EMhwlibTVFormatDigital fmt;
	RMuint32 vcogain, postdiv, plldiv, bp;
	RMreal c;
	RMbool yuv;
	
	// Analog Devices 9883 setup
	RMuint8 i2c_data[][2] = {
		{0x01, 0x69},  // PLL Div MSB
		{0x02, 0xD0},  // PLL Div LSB
		{0x03, 0x48},  // VCO
		{0x04, 0x80},  // Phase adj.
		{0x05, 0x80},  // Clamp plcemnt.
		{0x06, 0x80},  // Clamp dur.
		{0x07, 0x20},  // HSync out width
		{0x08, 0x80},  // R gain
		{0x09, 0x80},  // G gain
		{0x0a, 0x80},  // B gain
		{0x0b, 0x80},  // R offs.
		{0x0c, 0x80},  // G offs.
		{0x0d, 0x80},  // B offs.
		{0x0e, 0x40},  // Sync ctrl.
		{0x0f, 0x6E},  // Ctrl.
		{0x10, 0xB8},  // SOG Thr.
		{0x11, 0x20},  // Sync Sep. Thr.
		{0x12, 0x01},  // Pre-Coast
		{0x13, 0x01},  // Post-Coast
		{0x15, 0xFE},  // Test reg.
	};
	
	err = RUAExchangeProperty(pInstance, DisplayBlock, 
		RMDisplayBlockPropertyID_TVFormatDigital, 
		&(capture_opt->TVStandard), sizeof(capture_opt->TVStandard), 
		&fmt, sizeof(fmt));
	if (RMFAILED(err)) fprintf(stderr, "Failed to get TV format, %s\n", RMstatusToString(err));
	
	vcogain = 150;
	postdiv = 1;
	if (fmt.PixelClock < 32000000) {
		range = 0;
		postdiv = 4;
	} else if (fmt.PixelClock < 64000000) {
		range = 1;
		postdiv = 2;
	} else if (fmt.PixelClock < 125000000) {
		range = 2;
	} else {
		range = 3;
		vcogain = 180;
	}
	plldiv = fmt.HTotalSize;
	
	// Formula from AD's Excel sheet 249461068RevAD9883_PLL.xls:
	// c=((HFreq*6.28/((PixClk<32000000)?12.5:15))^2*((0.082*0.000001*plldiv*postdiv)/(vcogain*1000000))*1000000
	c = fmt.PixelClock;
	c *= 6.28 / fmt.HTotalSize;
	c /= ((fmt.PixelClock < 32000000) ? 12.5 : 15.0);
	c *= c;
	c *= (0.082 * plldiv * postdiv) / (vcogain * 1000000.0);
	current = 
		(c <   75.0) ? 0 : 
		(c <  125.0) ? 1 : 
		(c <  200.0) ? 2 : 
		(c <  300.0) ? 3 : 
		(c <  425.0) ? 4 : 
		(c <  625.0) ? 5 : 
		(c < 1125.0) ? 6 : 
		               7;
	fprintf(stderr, "AD9883 calc - PixClk=%lu range=%u c=%f current=%u\n", fmt.PixelClock, range, c, current);
	
	bp = fmt.XOffset - fmt.HSyncWidth;  // BackPorch
	yuv = (local_opt->i2c_port == cap_Component1);  // sync on green
	
	i2c_data[0x01 - 1][1] = (plldiv >> 4) & 0xFF;
	i2c_data[0x02 - 1][1] = (plldiv << 4) & 0xF0;
	i2c_data[0x03 - 1][1] = (range << 6) | (current << 3);
	i2c_data[0x05 - 1][1] = (bp >= 4) ? 0x04 : (bp / 4);  // clamp placement
	i2c_data[0x06 - 1][1] = (bp >= 4) ? (bp - 8) : (bp / 2);  // clamp duration
	
	//i2c_data[0x07 - 1][1] = fmt.HSyncWidth;  // TODO
	i2c_data[0x07 - 1][1] = 0x10;
	
	// set contrast
	i2c_data[0x08 - 1][1] = yuv ? 0x80 : 0xF0;  // R gain
	i2c_data[0x09 - 1][1] = yuv ? 0x80 : 0xF0;  // G gain
	i2c_data[0x0A - 1][1] = yuv ? 0x80 : 0xF0;  // B gain
	
	// set brightness
	i2c_data[0x0B - 1][1] = yuv ? 0x60 : 0x80;  // R offs
	i2c_data[0x0C - 1][1] = yuv ? 0x80 : 0x80;  // G offs
	i2c_data[0x0D - 1][1] = yuv ? 0x60 : 0x80;  // B offs
	
	i2c_data[0x0E - 1][1] |= yuv ? 0x1B : 0x10;  // select sync source, sog or h-sync. force vsync from sog for yuv.
	i2c_data[0x10 - 1][1] |= yuv ? 0x05 : 0x00;  // clamp red and blue to center for YUV
	
	err = init_i2c(pInstance, delay, dev, i2c_data, sizeof(i2c_data) / sizeof (RMuint8) / 2);
	
	return err;
}

static RMstatus set_cable_comp_SiI9031(
	struct RUA *pInstance, 
	struct capture_cmdline *capture_opt, 
	struct local_cmdline *local_opt, 
	RMuint8 dev, 
	RMuint8 delay)
{
	RMuint8 eq;
	
	eq = local_opt->cable_eq & 0x0F;
	eq = (eq << 4) | (0x0F - eq);
	return write_i2c(pInstance, delay, dev, 0x81, eq);
}

static RMstatus set_422_to_444_upsampling_SiI9031(
	struct RUA *pInstance, 
	RMbool upsampling, 
	RMuint8 dev, 
	RMuint8 delay)
{
	RMstatus err;
	RMuint32 reg;
	
	err = read_i2c(pInstance, delay, dev, 0x4A, &reg);
	if (RMFAILED(err)) reg = 0x01;  // default value
	if (upsampling) reg |= 0x04;
	else reg &= ~0x04;
	err = write_i2c(pInstance, delay, dev, 0x4A, reg);
	
	return err;
}

static RMstatus set_blanking_color_SiI9031(
	struct RUA *pInstance, 
	struct capture_cmdline *capture_opt, 
	struct local_cmdline *local_opt, 
	RMuint8 dev, 
	RMuint8 delay)
{
	RMstatus err;
	RMuint8 r, g, b;
	
	r = g = b = 0x00;
	
	if (
		(capture_opt->InputColorSpace != EMhwlibColorSpace_RGB_0_255) && 
		(capture_opt->InputColorSpace != EMhwlibColorSpace_RGB_16_235)
	) {
		//rgb_to_yuv(r, g, b, &g, &b, &r);
		g = 0x10;
		r = b = 0x80;
	}
	
	err = write_i2c(pInstance, delay, dev, 0x4B, b);
	if (RMFAILED(err)) RMDBGLOG((ENABLE, "Error writing I2C!\n"));
	err = write_i2c(pInstance, delay, dev, 0x4C, g);
	if (RMFAILED(err)) RMDBGLOG((ENABLE, "Error writing I2C!\n"));
	err = write_i2c(pInstance, delay, dev, 0x4D, r);
	if (RMFAILED(err)) RMDBGLOG((ENABLE, "Error writing I2C!\n"));
	
	return RM_OK;
}

static RMstatus get_spdif_codec(
	struct dcc_context *dcc_info, 
	struct audio_cmdline *audio_opt, 
	struct AudioEngine_InputSPDIFStatus_type *stat)
{
	if ((stat->ChannelStatus & 0x0002) && ((stat->Pc & 0x1F) == 0)) return RM_OK;  // Null data, no change
	
	audio_opt->auto_detect_codec = TRUE;
	
	fprintf(stderr, "Audio Input channel status [18:0]: 0x%05lX Pc:%04X Pd:%04X Pe:%04X Pf:%04X\n", stat->ChannelStatus, stat->Pc, stat->Pd, stat->Pe, stat->Pf);
	audio_opt->auto_detect_codec = FALSE;
	if (stat->ChannelStatus & 0x0002) {
		fprintf(stderr, "Detected Codec: ");
		switch (stat->Pc & 0x1F) {
		default:
			fprintf(stderr, "Unknown or reserved codec type: %u\n", stat->Pc & 0x1F);
			if (0)
		case 0: 
			fprintf(stderr, "Null Data\n");
			if (0)
		case 3: 
			fprintf(stderr, "Pause\n");
			if (0)
		case 2: 
			fprintf(stderr, "SMPTE 338M Time Stamp Data\n");
			if (0)
		case 27: 
			fprintf(stderr, "SMPTE 338M KLV Data\n");
			if (0)
		case 28: 
			fprintf(stderr, "SMPTE 338M Dolby E Data\n");
			if (0)
		case 29: 
			fprintf(stderr, "SMPTE 338M Captioning Data\n");
			if (0)
		case 30: 
			fprintf(stderr, "SMPTE 338M User Data\n");
			audio_opt->auto_detect_codec = TRUE; 
			break;
		case 1:
			fprintf(stderr, "AC3\n");
			audio_opt->Codec = AudioDecoder_Codec_AC3;
			audio_opt->Ac3Params.OutputChannels = Ac3_LR;
			break;
		case 4:
			fprintf(stderr, "MPEG 1 Layer 1\n");
			audio_opt->Codec = AudioDecoder_Codec_MPEG1;
			break;
		case 5:
			fprintf(stderr, "MPEG 1 Layer 2 or 3, MPEG 2 w/o extension\n");
			audio_opt->Codec = AudioDecoder_Codec_MPEG1;
			break;
		case 6:
			fprintf(stderr, "MPEG 2 w/ extension\n");
			audio_opt->Codec = AudioDecoder_Codec_MPEG1;
			break;
		case 7:
			fprintf(stderr, "MPEG 2 AAC\n");
			audio_opt->Codec = AudioDecoder_Codec_AAC;
			// TODO 0, 1, 2 or 3?
			audio_opt->AACParams.InputFormat = 0;
			audio_opt->AACParams.OutputChannels = Aac_LR;
			break;
		case 8:
			fprintf(stderr, "MPEG 2 Layer 1\n");
			audio_opt->Codec = AudioDecoder_Codec_MPEG1;
			break;
		case 9:
			fprintf(stderr, "MPEG 2 Layer 2\n");
			audio_opt->Codec = AudioDecoder_Codec_MPEG1;
			break;
		case 10:
			fprintf(stderr, "MPEG 2 Layer 3\n");
			audio_opt->Codec = AudioDecoder_Codec_MPEG1;
			break;
		case 11:
			fprintf(stderr, "DTS Type I\n");
			audio_opt->Codec = AudioDecoder_Codec_DTS;
			audio_opt->DtsParams.OutputChannels = Dts_LR;
			break;
		case 12:
			fprintf(stderr, "DTS Type II\n");
			audio_opt->Codec = AudioDecoder_Codec_DTS;
			audio_opt->DtsParams.OutputChannels = Dts_LR;
			break;
		case 13:
			fprintf(stderr, "DTS Type III\n");
			audio_opt->Codec = AudioDecoder_Codec_DTS;
			audio_opt->DtsParams.OutputChannels = Dts_LR;
			break;
		case 14:
			fprintf(stderr, "ATRAC (unsupported)\n");
			audio_opt->auto_detect_codec = TRUE;
			//audio_opt->Codec = ;
			break;
		case 15:
			fprintf(stderr, "ATRAC 2/3 (unsupported)\n");
			audio_opt->auto_detect_codec = TRUE;
			//audio_opt->Codec = ;
			break;
		case 18:
			fprintf(stderr, "WMA Pro\n");
			audio_opt->Codec = AudioDecoder_Codec_WMAPRO;
			break;
		case 31:
			switch (stat->Pe) {
			default:
				fprintf(stderr, "Unknown extended data-type: %u\n", stat->Pe);
				audio_opt->auto_detect_codec = TRUE; 
				break;
			}
			break;
		}
	} else {
		fprintf(stderr, "Detected Codec: PCM\n");
		audio_opt->auto_detect_codec = FALSE;
		audio_opt->Codec = AudioDecoder_Codec_PCM;
		audio_opt->SubCodec = 1;
		audio_opt->LpcmVobParams.ChannelAssign = LpcmVob2_LR;
		audio_opt->LpcmVobParams.BitsPerSample = 16;
		audio_opt->OutputChannels = Audio_Out_Ch_LR;
	}
	
	return RM_OK;
}

// Read sample frequency from HDMI chip and set audio_opt->SampleRate
static RMstatus setup_HDMI_audio(
	struct dcc_context *dcc_info, 
	struct local_cmdline *local_opt,
	struct audio_cmdline *audio_opt, 
	RMuint8 dev, 
	RMuint8 delay)
{
	RMstatus err;
	RMuint32 pclk;
	RMuint8 data[5];
	
	init_capture_SiI9031_amclk(dcc_info->pRUA, dev, delay, local_opt->hdmi_mode == mode_HDMI);
	
	if (local_opt->hdmi_mode != mode_HDMI) {
		audio_opt->SamplingFrequency = 0;
		audio_opt->SampleRate = 0;
		return RM_OK;
	}
	
	//err = read_i2c(dcc_info->pRUA, delay, dev + 4, 0x17, &pclk);
	//if (RMFAILED(err)) return err;
	err = read_i2c_data(dcc_info->pRUA, delay, dev + 4, 0x2A, &data[0], 3); if (RMFAILED(err)) return err; 
	err = read_i2c_data(dcc_info->pRUA, delay, dev + 4, 0x30, &data[3], 2); if (RMFAILED(err)) return err; 
	fprintf(stderr, "SiI9031 audio channel status [39:0]: %02X.%02X.%02X.%02X.%02X\n", data[4], data[3], data[2], data[1], data[0]);
	
	fprintf(stderr, "\n\n");
	pclk = data[3] & 0x0F;
	fprintf(stderr, "\tAudio fs: %s\n", 
		(pclk == 0) ? "44.1 kHz" : 
		(pclk == 1) ? "<unknown>" : 
		(pclk == 2) ? "48 kHz" : 
		(pclk == 3) ? "32 kHz" : 
		(pclk == 4) ? "22.05 kHz <invalid>" : 
		(pclk == 5) ? "11.025 kHz <invalid>" : 
		(pclk == 6) ? "24 kHz <invalid>" : 
		(pclk == 7) ? "16 kHz <invalid>" : 
		(pclk == 8) ? "88.2 kHz" : 
		(pclk == 9) ? "768 kHz" : 
		(pclk == 10) ? "96 kHz" : 
		(pclk == 11) ? "<reserved>" : 
		(pclk == 12) ? "176.4 kHz" : 
		(pclk == 13) ? "12 kHz <invalid>" : 
		(pclk == 14) ? "192 kHz" : 
		(pclk == 15) ? "<not indicated>" : "-");
	
	// SamplingFrequency: sample rate of the audio content
	// SampleRate: sample rate of the audio output
	switch (pclk) {
		case  0: audio_opt->SamplingFrequency =  44100; break;
		case  1: audio_opt->SamplingFrequency =      0; break;  // no audio
		case  2: audio_opt->SamplingFrequency =  48000; break;
		case  3: audio_opt->SamplingFrequency =  32000; break;
		//case  4: audio_opt->SamplingFrequency =  22050; break;
		//case  5: audio_opt->SamplingFrequency =  11025; break;
		//case  6: audio_opt->SamplingFrequency =  24000; break;
		//case  7: audio_opt->SamplingFrequency =  16000; break;
		case  8: audio_opt->SamplingFrequency =  88200; break;
		case  9: audio_opt->SamplingFrequency = 768000; break;
		case 10: audio_opt->SamplingFrequency =  96000; break;
		case 12: audio_opt->SamplingFrequency = 176400; break;
		//case 13: audio_opt->SamplingFrequency =  12000; break;
		case 14: audio_opt->SamplingFrequency = 192000; break;
		default: return RM_ERROR;
	}
	audio_opt->SampleRate = audio_opt->SamplingFrequency;  // no sample rate conversion
	
	if (data[0] & 0x02) {  // compressed audio
		fprintf(stderr, "\tAudio is compressed (assuming AC3 for now)\n");
		audio_opt->auto_detect_codec = TRUE;
		audio_opt->Codec = AudioDecoder_Codec_AC3;
		audio_opt->Ac3Params.OutputChannels = Ac3_LR;
	} else {  // PCM audio
		fprintf(stderr, "\tAudio is PCM\n");
		audio_opt->auto_detect_codec = FALSE;
		audio_opt->Codec = AudioDecoder_Codec_PCM;
		audio_opt->SubCodec = 1;
		audio_opt->LpcmVobParams.ChannelAssign = LpcmVob2_LR;
		audio_opt->LpcmVobParams.BitsPerSample = 16;
		audio_opt->OutputChannels = Audio_Out_Ch_LR;
	}
	
	fprintf(stderr, "\n\n");
	return err;
}


static RMstatus init_capture_SiI9031(
	struct RUA *pInstance, 
	struct capture_cmdline *capture_opt, 
	struct local_cmdline *local_opt, 
	RMuint8 dev, 
	RMuint8 delay)
{
	RMstatus err;
	
	// Silicon Image 9031 setup
	RMuint8 i2c_data[][2] = {
		{0x05, 0xD0},  // end reset, enable auto reset modes
		{0x08, 0x05},  // start chip
		{0x09, 0x11},  // select input 0
		{0x4A, 0x01},  // CCIR601, RGB 4:4:4 24 bit
		{0x49, 0x01},  // RGB input
		{0x48, 0x00},  // BT601 output colorspace
		{0x7A, 0x3F},  // ip_ctrl: initially, intr on all frames
		{0x88, 0x88},  // ACR1 magic value
		{0x89, 0x16},  // ACR2 magic value
		{0xB5, 0x00},  // enable auto audio control incl. I2S outputs
		{0xB6, 0xFF},  // enable mute conditions
		{0xB7, 0xFF},  //   "     "       "
		{0xB8, 0x07},  //   "     "       "
		{0xBB, 0x01},  // enable clear of error counts
	};
	RMuint8 i2c_data_ext[][2] = {
		//{0xBF, 0x85},  // default: receive MPEG frames in MPEG area
		{0xBF, 0x05},  // receive ISRC1 frames in MPEG area
	};
	
	if (local_opt->intr_debug) {
		local_opt->intr_mask[0] = 0x7F;  // intr1_mask: all but acrhwcts
		local_opt->intr_mask[1] = 0xB9;  // intr2_mask: all but vsync, gotcts, gotaud
		local_opt->intr_mask[2] = 0x7F;  // intr3_mask: all but new_cp
		local_opt->intr_mask[3] = 0x7F;  // intr4_mask: all
		local_opt->intr_mask[4] = 0xFF;  // intr5_mask: all
		local_opt->intr_mask[5] = 0x05;  // intr6_mask: all
	} else {
		local_opt->intr_mask[0] = 0x03;  // intr1_mask: authstart, authdone
		local_opt->intr_mask[1] = 0x99;  // intr2_mask: hdmimode, ckdt, scdt, vidchg
		//local_opt->intr_mask[2] = 0x1F;  // intr3_mask: newunr, newmpeg, newaud, newspd, newavi
		local_opt->intr_mask[2] = 0x0F;  // intr3_mask: newmpeg, newaud, newspd, newavi
		local_opt->intr_mask[3] = 0x1C;  // intr4_mask: no_avi, cts_drop, cts_reuse
		local_opt->intr_mask[4] = 0xFF;  // intr5_mask: fnchg, aac_mute, aul_err, vrchg, hrchg, pochg, ilchg, fschg
		local_opt->intr_mask[5] = 0x05;  // intr6_mask: new_acp, unplug
	}
	
	if (local_opt->i2c_port == cap_HDMI1) {
		i2c_data[2][1] = 0x22;  // select input 1
	}
	
	// for pioneer video card (8620L/8bit/656):
	if (local_opt->i2c_board == cap_pioneer809e1video) {
		i2c_data[3][1] = 0xFB;  // CCIR656, convert RGB 4:4:4 24 bit to YUV 4:2:2 8+8 bit
		i2c_data[5][1] = 0x01;  // BT709 output colorspace
	}
	
	err = write_i2c(pInstance, delay, dev + 4, 0x3C, 0x01); // power up chip.
	err = write_i2c(pInstance, delay, dev + 4, 0x3E, 0xFF); // power up chip.
	err = write_i2c(pInstance, delay, dev + 4, 0x3F, 0xFF); // power up chip.
	err = write_i2c(pInstance, delay, dev, 0x05, 0xC3); // reset of audio FIFO and chip, put HDCP and ACR in auto-reset
//	err = write_i2c(pInstance, delay, dev, 0x05, 0x0F); // reset
	err = init_i2c(pInstance, delay, dev, i2c_data, sizeof(i2c_data) / sizeof (RMuint8) / 2);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to init SiI9031!\n");
		return err;
	}
	err = write_i2c(pInstance, delay, dev, 0x75, local_opt->intr_mask[0]);
	err = write_i2c(pInstance, delay, dev, 0x76, local_opt->intr_mask[1]);
	err = write_i2c(pInstance, delay, dev, 0x77, local_opt->intr_mask[2]);
	err = write_i2c(pInstance, delay, dev, 0x78, local_opt->intr_mask[3]);
	err = write_i2c(pInstance, delay, dev, 0x7D, local_opt->intr_mask[4]);
	err = write_i2c(pInstance, delay, dev, 0x7E, local_opt->intr_mask[5]);
	err = init_i2c(pInstance, delay, dev + 4, i2c_data_ext, sizeof(i2c_data_ext) / sizeof (RMuint8) / 2);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to init SiI9031!\n");
		return err;
	}
	
	init_capture_SiI9031_amclk(pInstance, dev, delay, FALSE);
	set_cable_comp_SiI9031(pInstance, capture_opt, local_opt, dev, delay);
	set_blanking_color_SiI9031(pInstance, capture_opt, local_opt, dev, delay);
	set_422_to_444_upsampling_SiI9031(pInstance, local_opt->upsample_from_422, dev, delay);
	//HCInit();
	
	return err;
}

RMuint8 edid_info[0x80] = {
	0x00, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x00, 
	0x40, 0xf3, 0x11, 0x03, 0xa4, 0x0c, 0x00, 0x00, 
	0x0e, 0x0e, 0x01, 0x03, 0x81, 0x22, 0x1b, 0x78, 
	0x2a, 0x0b, 0x32, 0x9c, 0x5a, 0x4d, 0x8c, 0x26, 
	0x20, 0x4e, 0x57, 0xa1, 0x08, 0x00, 0x81, 0x40, 
	0x71, 0x4f, 0x81, 0x80, 0x01, 0x01, 0x01, 0x01, 
	0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x30, 0x2a, 
	0x00, 0x98, 0x51, 0x00, 0x2a, 0x40, 0x30, 0x70, 
	0x13, 0x00, 0x52, 0x0e, 0x11, 0x00, 0x00, 0x1e, 
	0x00, 0x00, 0x00, 0xfc, 0x00, 0x4c, 0x43, 0x44, 
	0x20, 0x31, 0x37, 0x44, 0x0a, 0x20, 0x20, 0x20, 
	0x20, 0x20, 0x00, 0x00, 0x00, 0xfd, 0x00, 0x3c, 
	0x3c, 0x1f, 0x40, 0x0b, 0x00, 0x0a, 0x20, 0x20, 
	0x20, 0x20, 0x20, 0x20, 0x00, 0x00, 0x00, 0xff, 
	0x00, 0x57, 0x43, 0x43, 0x45, 0x31, 0x34, 0x30, 
	0x33, 0x32, 0x33, 0x36, 0x0a, 0x20, 0x00, 0xd8, 
};

/* CEA 861C subset of all EMhwlib video modes */
enum EMhwlibTVStandard cea861c[] = {
	EMhwlibTVStandard_HDMI_640x480p60, // 1
	EMhwlibTVStandard_HDMI_480p60, // 2
	EMhwlibTVStandard_HDMI_480p60, // 3
	EMhwlibTVStandard_HDMI_720p60, // 4
	EMhwlibTVStandard_HDMI_1080i60, // 5
	EMhwlibTVStandard_HDMI_480i60, // 6
	EMhwlibTVStandard_HDMI_480i60, // 7
	EMhwlibTVStandard_HDMI_240p60, // 8
	EMhwlibTVStandard_HDMI_240p60, // 9
	EMhwlibTVStandard_HDMI_2880x480i60, // 10
	EMhwlibTVStandard_HDMI_2880x480i60, // 11
	EMhwlibTVStandard_HDMI_2880x240p60, // 12
	EMhwlibTVStandard_HDMI_2880x240p60, // 13
	EMhwlibTVStandard_HDMI_1440x480p60, // 14
	EMhwlibTVStandard_HDMI_1440x480p60, // 15
	EMhwlibTVStandard_HDMI_1080p60, // 16
	EMhwlibTVStandard_HDMI_576p50, // 17
	EMhwlibTVStandard_HDMI_576p50, // 18
	EMhwlibTVStandard_HDMI_720p50, // 19
	EMhwlibTVStandard_HDMI_1080i50, // 20
	EMhwlibTVStandard_HDMI_576i50, // 21
	EMhwlibTVStandard_HDMI_576i50, // 22
	EMhwlibTVStandard_HDMI_288p50, // 23
	EMhwlibTVStandard_HDMI_288p50, // 24
	EMhwlibTVStandard_HDMI_2880x576i50, // 25
	EMhwlibTVStandard_HDMI_2880x576i50, // 26
	EMhwlibTVStandard_HDMI_2880x288p50, // 27
	EMhwlibTVStandard_HDMI_2880x288p50, // 28
	EMhwlibTVStandard_HDMI_1440x576p50, // 29
	EMhwlibTVStandard_HDMI_1440x576p50, // 30
	EMhwlibTVStandard_HDMI_1080p50, // 31
	EMhwlibTVStandard_HDMI_1080p24, // 32
	EMhwlibTVStandard_HDMI_1080p25, // 33
	EMhwlibTVStandard_HDMI_1080p30, // 34
	EMhwlibTVStandard_HDMI_2880x480p60, // 35
	EMhwlibTVStandard_HDMI_2880x480p60, // 36
	EMhwlibTVStandard_HDMI_2880x576p50, // 37
	EMhwlibTVStandard_HDMI_2880x576p50, // 38
	EMhwlibTVStandard_HDMI_1080i50_1250, // 39
	EMhwlibTVStandard_HDMI_1080i100, // 40
	EMhwlibTVStandard_HDMI_720p100, // 41
	EMhwlibTVStandard_HDMI_576p100, // 42
	EMhwlibTVStandard_HDMI_576p100, // 43
	EMhwlibTVStandard_HDMI_576i100, // 44
	EMhwlibTVStandard_HDMI_576i100, // 45
	EMhwlibTVStandard_HDMI_1080i120, // 46
	EMhwlibTVStandard_HDMI_720p120, // 47
	EMhwlibTVStandard_HDMI_480p120, // 48
	EMhwlibTVStandard_HDMI_480p120, // 49
	EMhwlibTVStandard_HDMI_480i120, // 50
	EMhwlibTVStandard_HDMI_480i120, // 51
	EMhwlibTVStandard_HDMI_576p200, // 52
	EMhwlibTVStandard_HDMI_576p200, // 53
	EMhwlibTVStandard_HDMI_576i200, // 54
	EMhwlibTVStandard_HDMI_576i200, // 55
	EMhwlibTVStandard_HDMI_480p240, // 56
	EMhwlibTVStandard_HDMI_480p240, // 57
	EMhwlibTVStandard_HDMI_480i240, // 58
	EMhwlibTVStandard_HDMI_480i240, // 59
};

/* Compare two values and return a weighted match value. 
   Return value is 'weight' if both values are equal, 
   or 50% of 'weight' minus the percentage points 'a' is away from 'b'. */
static inline RMuint32 comp_weight(RMuint32 a, RMuint32 b, RMuint32 weight) {
	RMuint32 dist;
	if (a == b) return weight;
	dist = (a > b) ? a - b : b - a;
//	weight /= 2;
	dist = (dist * 100) / b;
	return (weight > dist) ? weight - dist : 0;
}

static RMascii *CEA861_ShortDescriptorVideoResolutions[] = {
	"Unknown",
	"VGA 640x480 60Hz",  // 1
	"480p 60Hz (4:3)",   // 2
	"480p 60Hz (16:9)",  // 3
	"720p 60Hz",         // 4
	"1080i 60Hz",        // 5
	"480i 60Hz (4:3)",   // 6
	"480i 60Hz (16:9)",  // 7
	"240p 60Hz (4:3)",   // 8
	"240p 60Hz (16:9)",  // 9
	"480i 60Hz (4:3)",   // 10
	"480i 60Hz (16:9)",  // 11
	"240p 60Hz (4:3)",   // 12
	"240p 60Hz (16:9)",  // 13
	"480p 60Hz (4:3)",   // 14
	"480p 60Hz (16:9)",  // 15
	"1080p 60Hz",        // 16
	"576p 50Hz (4:3)",   // 17
	"576p 50Hz (16:9)",  // 18
	"720p 50Hz",         // 19
	"1080i 50Hz",        // 20
	"576i 50Hz (4:3)",   // 21
	"576i 50Hz (16:9)",  // 22
	"288p 50Hz (4:3)",   // 23
	"288p 50Hz (16:9)",  // 24
	"576i 50Hz (4:3)",   // 25
	"576i 50Hz (16:9)",  // 26
	"288p 50Hz (4:3)",   // 27
	"288p 50Hz (16:9)",  // 28
	"576p 50Hz (4:3)",   // 29
	"576p 50Hz (16:9)",  // 30
	"1080p 50Hz",        // 31
	"1080p 24Hz",        // 32
	"1080p 25Hz",        // 33
	"1080p 30Hz",        // 34
	"480p 60Hz (4:3)",   // 35
	"480p 60Hz (16:9)",  // 36
	"576p 50Hz (4:3)",   // 37
	"576p 50Hz (16:9)",  // 38
	"1080i 50Hz",        // 39
	"1080i 100Hz",       // 40
	"720p 100Hz",        // 41
	"576p 100Hz (4:3)",  // 42
	"576p 100Hz (16:9)", // 43
	"576i 100Hz (4:3)",  // 44
	"576i 100Hz (16:9)", // 45
	"1080i 120Hz",       // 46
	"720p 120Hz",        // 47
	"480p 120Hz (4:3)",  // 48
	"480p 120Hz (16:9)", // 49
	"480i 120Hz (4:3)",  // 50
	"480i 120Hz (16:9)", // 51
	"576p 200Hz (4:3)",  // 52
	"576p 200Hz (16:9)", // 53
	"576i 200Hz (4:3)",  // 54
	"576i 200Hz (16:9)", // 55
	"480p 240Hz (4:3)",  // 56
	"480p 240Hz (16:9)", // 57
	"480i 240Hz (4:3)",  // 58
	"480i 240Hz (16:9)", // 59
};

/* Detect video format from the line and pixel counter in the SiI9031 */
static RMstatus get_format_SiI9031(
	struct dcc_context *dcc_info, 
	struct capture_cmdline *options, 
	struct local_cmdline *local_opt, 
	RMuint8 dev, 
	RMuint8 delay, 
	RMbool *update)
{
	RMstatus err;
	RMuint32 reg;
	RMuint8 data[17];
	RMuint32 h_res, v_res, de_pix, de_lin, vid_vtavl, vid_vfp, vid_hfp, vid_hswidth, vid_xpcnt;
	RMbool intrl, vspol, hspol;
	RMuint32 i, best_match;
	enum EMhwlibTVStandard mode, old;
	RMascii *StandardName;
	RMbool limit861 = FALSE;  /* whether to limit to CEA 861 modes */
	
	if (update) *update = FALSE;
	old = options->TVStandard;
	
	/* read measurement registers from SiI9031 */
	err = read_i2c(dcc_info->pRUA, delay, dev, 0x06, &reg); if (RMFAILED(err)) return err; 
	if ((reg & 0x03) != 0x03) {
		fprintf(stderr, "no %s%s%s!\n", 
			(reg & 0x08) ? "" : "power", 
			(reg & 0x02) ? "" : (reg & 0x08) ? "clock" : (reg & 0x01) ? " or clock" : ", clock", 
			(reg & 0x01) ? "" : ((reg & 0x02) && (reg & 0x08)) ? "sync" : " or sync");
		return RM_ERROR;
	}
	
	err = read_i2c_data(dcc_info->pRUA, delay, dev, 0x3A, &data[0], 4); if (RMFAILED(err)) return err; 
	err = read_i2c_data(dcc_info->pRUA, delay, dev, 0x4E, &data[4], 8); if (RMFAILED(err)) return err; 
	err = read_i2c_data(dcc_info->pRUA, delay, dev, 0x59, &data[12], 4); if (RMFAILED(err)) return err; 
	err = read_i2c_data(dcc_info->pRUA, delay, dev, 0x6F, &data[16], 1); if (RMFAILED(err)) return err; 
	h_res = (data[0] & 0xFF);
	h_res |= ((data[1] & 0x1F) << 8);
	v_res = (data[2] & 0xFF);
	v_res |= ((data[3] & 0x07) << 8);
	de_pix = (data[4] & 0xFF);
	de_pix |= ((data[5] & 0x1F) << 8);
	de_lin = (data[6] & 0xFF);
	de_lin |= ((data[7] & 0x07) << 8);
	vid_vtavl = (data[8] & 0x3F);
	vid_vfp = (data[9] & 0x3F);
	intrl = (data[11] & 0x04) ? TRUE : FALSE;
	vspol = (data[11] & 0x02) ? TRUE : FALSE;
	hspol = (data[11] & 0x01) ? TRUE : FALSE;
	vid_hfp = (data[12] & 0xFF);
	vid_hswidth = (data[14] & 0xFF);
	vid_hswidth |= ((data[15] & 0x03) << 8);
	vid_xpcnt = (data[16] & 0xFF);
	
	fprintf(stderr, "SiI9031 - %lux%lu%c, total:%lux%lu, vsync:%lu-%lu-x-%s., hsync:%lu-%lu-%lu-%s., xpcnt:%lu\n", 
		de_pix, de_lin * (intrl ? 2 : 1), intrl ? 'i' : 'p', 
		h_res, intrl ? v_res * 2 + 1 : v_res, 
		vid_vfp, vid_vtavl, vspol ? "pos" : "neg", 
		vid_hfp, vid_hswidth, h_res - de_pix - vid_hfp - vid_hswidth, hspol ? "pos" : "neg", 
		vid_xpcnt);
	
	if (! update) return RM_OK;
	
	best_match = 0;
	i = limit861 ? 0 : 1;
	while (limit861 ? (i < (sizeof(cea861c) / sizeof(enum EMhwlibTVStandard))) : RMSUCCEEDED(GetTVStandardName((enum EMhwlibTVStandard)i, &StandardName))) {
		struct EMhwlibTVFormatDigital dig;
		RMuint32 match;
		RMbool dig_Intrl, dig_1001;
		
		// skip dual-aspect-ratio modes, checking for one is enough
		if (limit861 && (i > 0) && (cea861c[i - 1] == cea861c[i])) {
			i++;
			continue;
		}
		mode = limit861 ? cea861c[i] : (enum EMhwlibTVStandard)i;
		err = RUAExchangeProperty(dcc_info->pRUA, DisplayBlock, 
			RMDisplayBlockPropertyID_TVFormatDigital, 
			&mode, sizeof(mode), 
			&dig, sizeof(dig));
		if RMFAILED(err) {
			fprintf(stderr, "Could not get format!\n");
			return err;
		}
		dig_1001 = (
			(dig.PixelClock == 25174825) || 
			(dig.PixelClock == 74175824) || 
			(dig.PixelClock == 148351648) || 
			((
				(dig.ActiveHeight == 240) || 
				(dig.ActiveHeight == 480)
			) && (
				(dig.PixelClock == 27000000) || 
				(dig.PixelClock == 54000000) || 
				(dig.PixelClock == 108000000) 
			))
		);
		// skip X*1000/1001 frame rate modes, capture does not discriminate between those and X*1 modes
		if (dig_1001) {
			i++;
			continue;
		}
		dig_Intrl = (dig.TopFieldHeight != 0);
		if (dig_Intrl) dig.VTotalSize = (dig.VTotalSize + 1) / 2;
		
/*if (mode == EMhwlibTVStandard_HDMI_1080i60) {
	fprintf(stderr, "1080i60 video format: \nh_res = %lu\nv_res = %lu\nde_pix = %lu\nde_lin = %lu\nvid_vtavl = %lu\nvid_vfp = %lu\nvid_hfp = %lu\nvid_hswidth = %lu\nvid_xpcnt = %lu\nintrl = %u\nvspol = %u\nhspol = %u\n", 
		dig.HTotalSize, dig.VTotalSize, dig.ActiveWidth, dig.ActiveHeight, dig.YOffsetTop, 
		dig.VTotalSize - dig.ActiveHeight - dig.YOffsetTop, 
		dig.HTotalSize - dig.ActiveWidth - dig.XOffset, 
		dig.HSyncWidth, (RMuint32)(28322000LL * 128LL / dig.PixelClock), dig_Intrl, ! dig.VSyncActiveLow, ! dig.HSyncActiveLow);
}*/
		match = 0;
		match += comp_weight(h_res, dig.HTotalSize, 20);
		match += comp_weight(v_res, dig.VTotalSize, 20);
		match += comp_weight(de_pix, dig.ActiveWidth, 20);
		match += comp_weight(de_lin, dig.ActiveHeight, 20);
		//match += comp_weight(vid_vtavl, dig.YOffsetTop, 12);
		//match += comp_weight(vid_vfp, dig.VTotalSize - dig.ActiveHeight - dig.YOffsetTop, 12);
		//match += comp_weight(vid_hfp, dig.HTotalSize - dig.ActiveWidth - dig.XOffset, 12);
		//match += comp_weight(vid_hswidth, dig.HSyncWidth, 12);
		match += comp_weight(vid_xpcnt, RM64mult32div32(28322000, 128, dig.PixelClock), 20);
		if (intrl == dig_Intrl) match += 32;
		if (vspol == ! dig.VSyncActiveLow) match += 20;
		if (hspol == ! dig.HSyncActiveLow) match += 20;
		
		if (match > best_match) {
			best_match = match;
			options->TVStandard = mode;
			//GetTVStandardName(mode, &StandardName);
			//fprintf(stderr, "%s scores %lu\n", StandardName, match);
		}
		i++;
	}
	
	if (options->TVStandard != old) {
		GetTVStandardName(options->TVStandard, &StandardName);
		fprintf(stderr, "Detected new mode from timing: %s\n", StandardName);
		*update = TRUE;
	}
	
	err = read_i2c_data(dcc_info->pRUA, delay, dev + 4, 0x2A, &data[0], 3); if (RMFAILED(err)) return err; 
	err = read_i2c_data(dcc_info->pRUA, delay, dev + 4, 0x30, &data[3], 2); if (RMFAILED(err)) return err; 
	fprintf(stderr, "SiI9031 audio channel status [39:0]: %02X %02X %02X %02X %02X\n", data[4], data[3], data[2], data[1], data[0]);
	
	return RM_OK;
}

// Set up local and capture options (zoom, aspect ratio etc.) based on capture_opt->TVStandard
static RMstatus setup_format_options(
	struct dcc_context *dcc_info, 
	struct capture_cmdline *capture_opt, 
	struct display_cmdline *disp_opt, 
	struct local_cmdline *local_opt, 
	RMuint32 input)
{
	struct EMhwlibActiveFormatDescription afd;
	
	afd.ActiveFormat = local_opt->active_format;
	afd.ActiveFormatValid = TRUE;
	afd.FrameAspectRatio.X = 4;
	afd.FrameAspectRatio.Y = 3;
	
	switch (capture_opt->TVStandard) {
	case EMhwlibTVStandard_Custom:
		fprintf(stderr, "No sync or video detected!\n");
		break;
	case EMhwlibTVStandard_ITU_Bt656_525:
	case EMhwlibTVStandard_ITU_Bt656_240p:
		{  // NTSC only part
			capture_opt->PixelAspectRatio.X = 8;
			capture_opt->PixelAspectRatio.Y = 9;
			if (local_opt->parse_anc) {
				capture_opt->vbianc_w = 12;
				capture_opt->vbianc_h = 3;
				capture_opt->vbianc_ytop = 16;
				capture_opt->vbianc_ybot = 17;
				capture_opt->vbianc_enable = TRUE;
				//capture_opt->vbi_dma = FALSE;
				fprintf(stderr, "*** NTSC ClosedCaption, setting up capture window w=%lu, h=%lu, ytop=%lu, ybot=%lu ***\n", 
					capture_opt->vbianc_w, capture_opt->vbianc_h, capture_opt->vbianc_ytop, capture_opt->vbianc_ybot);
			} else {
				capture_opt->vbianc_enable = FALSE;
			}
			// full screen minus top 4 and bottom 3 lines of each frame
			if (! local_opt->zoom_force) {
				local_opt->zoom_x = 0;
				local_opt->zoom_y = 4;  // discard top 2 lines of each field, containing VBI data in ITU656-525 mode
				local_opt->zoom_w = 720;
				local_opt->zoom_h = 480;  // discard bottom 3 lines of each frame to match standard picture size
			}
			if (capture_opt->TVStandard == EMhwlibTVStandard_ITU_Bt656_240p) {
				capture_opt->PixelAspectRatio.Y *= 2;
				if (! local_opt->zoom_force) {
					local_opt->zoom_h /= 2;
				}
			}
		}
		if (0) 
	case EMhwlibTVStandard_ITU_Bt656_625:
	case EMhwlibTVStandard_ITU_Bt656_288p:
		{  // PAL only part
			capture_opt->PixelAspectRatio.X = 16;
			capture_opt->PixelAspectRatio.Y = 15;
			if (local_opt->parse_anc) {
				//////////////////////////////////////////////////////////////////////////
				capture_opt->vbianc_w = 52;// for SAA
				if(local_opt->i2c_board==cap_sigma895e1) 	capture_opt->vbianc_w = 56; //for TW9919				
				capture_opt->vbianc_h = 18;
				capture_opt->vbianc_ytop = 5;
				capture_opt->vbianc_ybot = 5;
				capture_opt->vbianc_enable = TRUE;
				//capture_opt->vbi_dma = TRUE;
				fprintf(stderr, "*** PAL TeleText, setting up capture window w=%lu, h=%lu, ytop=%lu, ybot=%lu ***\n", 
					capture_opt->vbianc_w, capture_opt->vbianc_h, capture_opt->vbianc_ytop, capture_opt->vbianc_ybot);
			} else {
				capture_opt->vbianc_enable = FALSE;
			}
			// full screen capture
			if (! local_opt->zoom_force) {
				local_opt->zoom_x = 0;
				local_opt->zoom_y = 0;
				local_opt->zoom_w = 720;
				local_opt->zoom_h = 576;
			}
			if (capture_opt->TVStandard == EMhwlibTVStandard_ITU_Bt656_288p) {
				capture_opt->PixelAspectRatio.Y *= 2;
				if (! local_opt->zoom_force) {
					local_opt->zoom_h /= 2;
				}
			}
		}
		
		{  // PAL/NTSC common part
			// disable picture aspect ratio, using pixel aspect ratio
			capture_opt->PictureAspectRatio.X  = 0;
			capture_opt->PictureAspectRatio.Y  = 0;
			
			// Set up wide and clipping mode
			if (local_opt->wide_screen) {  // 16:9 output
				capture_opt->PixelAspectRatio.X *= 4;
				capture_opt->PixelAspectRatio.Y *= 3;
				afd.FrameAspectRatio.X *= 4;
				afd.FrameAspectRatio.Y *= 3;
			}
			if (! local_opt->zoom_force) {
				RMstatus err;
				struct EMhwlibAspectRatio scaler_ar;
				RMbool output_variable_ar, variable_output;
				struct EMhwlibActiveFormatDescription output_afd;
				RMuint32 w = local_opt->zoom_w, h = local_opt->zoom_h, adj;
				
				err = get_scaler_output_aspect_ratio(
					dcc_info->pRUA, 
					dcc_info->disp_info->osd_scaler[input], 
					(dcc_info->route == DCCRoute_Secondary) ? DispVCRMixer : DispMainMixer, 
					&scaler_ar, &variable_output);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Can not get scaler output aspect ratio! %s\n", RMstatusToString(err)));
					// fallback, this assumes full screen scaler window.
					return err;
				} else {
					RMDBGLOG((LOCALDBG, "Scaler output aspect ratio: %lu:%lu\n", scaler_ar.X, scaler_ar.Y));
				}
				
				output_afd.FrameAspectRatio.X = disp_opt->ar_x;
				output_afd.FrameAspectRatio.Y = disp_opt->ar_y;
				output_afd.ActiveFormat = disp_opt->active_format;
				output_afd.ActiveFormatValid = disp_opt->active_format_valid;
				if (variable_output) {
					get_output_variable_aspect_ratio(disp_opt->standard, &output_variable_ar);
				} else {
					output_variable_ar = FALSE;
				}
				apply_active_format_abs(
					afd, scaler_ar, 
					output_variable_ar, &output_afd, 
					&(local_opt->zoom_x), &(local_opt->zoom_y), 
					&(local_opt->zoom_w), &(local_opt->zoom_h), 
					NULL);
				
				// Apply overscan crop, if any
				if (local_opt->overscan_crop) {
					adj = w * local_opt->overscan_crop / 200;
					local_opt->zoom_x += adj;
					local_opt->zoom_w -= (adj * 2);
					adj = h * local_opt->overscan_crop / 200;
					local_opt->zoom_y += adj;
					local_opt->zoom_h -= (adj * 2);
				}
				
				if (variable_output && (
					(output_afd.FrameAspectRatio.X != disp_opt->ar_x) || 
					(output_afd.FrameAspectRatio.Y != disp_opt->ar_y) || 
					(output_afd.ActiveFormatValid && (output_afd.ActiveFormat != disp_opt->active_format)) || 
					(output_afd.ActiveFormatValid != disp_opt->active_format_valid)
				)) {
					apply_active_format_output(dcc_info->pRUA, 
						(dcc_info->route == DCCRoute_Secondary) ? DispVCRMixer : DispMainMixer, 
						disp_opt->dh_info->pDH, 
						output_afd);
					disp_opt->ar_x = output_afd.FrameAspectRatio.X;
					disp_opt->ar_y = output_afd.FrameAspectRatio.Y;
					disp_opt->active_format_valid = output_afd.ActiveFormatValid;
					disp_opt->active_format = output_afd.ActiveFormat;
				}
			}
		}
		break;
	default:
		// other standard, no need to do anything
		break;
	}
	
	return RM_OK;
}

static RMstatus get_format_SAA7119(
	struct dcc_context *dcc_info, 
	struct capture_cmdline *capture_opt, 
	struct local_cmdline *local_opt, 
	RMuint8 dev, 
	RMuint8 delay, 
	RMbool *update)
{
	RMstatus err;
	RMuint32 reg1e, reg1f;
	RMbool u = FALSE;
	enum EMhwlibTVStandard TVStandard;
	
	u = FALSE;
	err = read_i2c(dcc_info->pRUA, delay, dev, 0x1E, &reg1e); 
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read status at 0x1E\n");
		return err;
	}
	err = read_i2c(dcc_info->pRUA, delay, dev, 0x1F, &reg1f); 
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read status at 0x1F\n");
		return err;
	}
	//fprintf(stderr, "SAA7119 Status 1E/1F: %02lX %02lX\n", reg1e, reg1f);
	// TODO detect HDTV modes
	if ((reg1f & (1 << 6)) || !(reg1f & (1 << 0))) {  // ready to capture?
//		if (capture_opt->TVStandard != EMhwlibTVStandard_Custom) {
//			fprintf(stderr, "SAA7119 Status 1E/1F: %02lX %02lX\n", reg1e, reg1f);
//			fprintf(stderr, "No sync or video detected!\n");
//			u = TRUE;
//		}
//		capture_opt->TVStandard = EMhwlibTVStandard_Custom;
	} else 
	//if (reg1f & (1 << 7)) {  // interlaced
	if (reg1f & (1 << 5)) {  // NTSC 525/59.94
		TVStandard = (reg1f & (1 << 7)) ? EMhwlibTVStandard_ITU_Bt656_525 : EMhwlibTVStandard_ITU_Bt656_240p;
		if (capture_opt->TVStandard != TVStandard) {
			fprintf(stderr, "SAA7119 Status 1E/1F: %02lX %02lX\n", reg1e, reg1f);
			fprintf(stderr, "SAA7119: Detected 60Hz %s%s, setting up CC\n", 
				((reg1e & 3) == 1) ? "NTSC" : 
				((reg1e & 3) == 2) ? "PAL" : 
				((reg1e & 3) == 3) ? "SECAM" : 
				"b/w", 
				(reg1f & (1 << 7)) ? "" : " PROGRESSIVE");
			if ((reg1e & 3) == 0) return RM_OK;  // wait until color
			capture_opt->TVStandard = TVStandard;
			u = TRUE;
		}
		// read WSS525, set local_opt->wide_screen, local_opt->active_format and u
		{  // TODO: use WSS Fifo to read back changed data from VSync IRQ handler
			RMuint8 wss_data[7];
			RMuint32 wss;
			RMbool uw = FALSE;
			RMbool active_format_valid;
			enum EMhwlibActiveFormat active_format = local_opt->active_format;
			RMbool wide_screen = local_opt->wide_screen;
			
			err = read_i2c_data(dcc_info->pRUA, delay, dev, 0x6B, wss_data, 7); 
			if (RMFAILED(err)) {
				//fprintf(stderr, "Failed to read WSS data at 0x6B\n");
				return err;
			}
			//fprintf(stderr, "SAA7119 WSS: %02X %02X %02X %02X %02X %02X %02X\n", 
			//	wss_data[0], wss_data[1], wss_data[2], wss_data[3], wss_data[4], wss_data[5], wss_data[6]);
			if (((wss_data[0] & 0xC0) == 0) && ((wss_data[3] & 0x80) == 0)) {
				wss = ((wss_data[3] & 0x0F) << 16) | (wss_data[2] << 8) | wss_data[1];
				if (local_opt->wss_odd != wss) {
					fprintf(stderr, "SAA7119 WSS odd: 0x%05lX\n", wss);
					local_opt->wss_odd = wss;
					uw = TRUE;
				}
			}
			if (((wss_data[0] & 0x30) == 0) && ((wss_data[6] & 0x80) == 0)) {
				wss = ((wss_data[6] & 0x0F) << 16) | (wss_data[5] << 8) | wss_data[4];
				if (local_opt->wss_even != wss) {
					fprintf(stderr, "SAA7119 WSS evn: 0x%05lX\n", wss);
					local_opt->wss_even = wss;
					/*uw = TRUE;*/
				}
			}
			if (uw /*&& (local_opt->wss_odd == local_opt->wss_even)*/) {
				active_format_valid = TRUE;
				active_format = EMhwlibAF_same_as_picture;
				wide_screen = FALSE;
				switch (local_opt->wss_odd & 0x03) {
					case 0:  // NTSC WSS "4:3 frame"
						fprintf(stderr, "SAA7119 WSS.525: 4:3 Frame, Full Picture\n");
						break;
					case 1:  // NTSC WSS "16:9 frame"
						fprintf(stderr, "SAA7119 WSS.525: 16:9 Frame, Full Picture\n");
						wide_screen = TRUE;
						break;
					case 2:  // NTSC WSS "16:9 in 4:3 frame"
						fprintf(stderr, "SAA7119 WSS.525: 4:3 Frame, Letterbox 16:9 Picture\n");
						active_format = EMhwlibAF_16x9_centered;
						break;
					default:
						active_format_valid = FALSE;
						break;
				}
				if (active_format_valid && (! local_opt->force_active_format) && (local_opt->active_format != active_format)) {
					fprintf(stderr, "SAA7119 new active format from WSS: %s\n", 
						(active_format == EMhwlibAF_same_as_picture) ? "Full" : "Letterbox");
					local_opt->active_format = active_format;
					u = TRUE;
				}
				if (active_format_valid && (! local_opt->force_wide_screen) && (local_opt->wide_screen != wide_screen)) {
					fprintf(stderr, "SAA7119 new aspect ratio from WSS: %s\n", 
						wide_screen ? "Wide" : "Normal");
					local_opt->wide_screen = wide_screen;
					u = TRUE;
				}
			}
		}
	} else {  // PAL 625/50
		TVStandard = (reg1f & (1 << 7)) ? EMhwlibTVStandard_ITU_Bt656_625 : EMhwlibTVStandard_ITU_Bt656_288p;
		if (capture_opt->TVStandard != TVStandard) {
			fprintf(stderr, "SAA7119 Status 1E/1F: %02lX %02lX\n", reg1e, reg1f);
			fprintf(stderr, "SAA7119: Detected 50Hz %s%s, setting up TT\n", 
				((reg1e & 3) == 1) ? "NTSC" : 
				((reg1e & 3) == 2) ? "PAL" : 
				((reg1e & 3) == 3) ? "SECAM" : 
				"b/w", 
				(reg1f & (1 << 7)) ? "" : " PROGRESSIVE");
			if ((reg1e & 3) == 0) return RM_OK;  // wait until color
			capture_opt->TVStandard = TVStandard;
			u = TRUE;
		}
		// read WSS, set local_opt->wide_screen, local_opt->active_format and u
		{  // TODO: use WSS Fifo to read back changed data from VSync IRQ handler
			RMuint8 wss_data[7];
			RMuint32 wss;
			RMbool uw = FALSE;
			RMbool active_format_valid;
			enum EMhwlibActiveFormat active_format = local_opt->active_format;
			RMbool wide_screen = local_opt->wide_screen;
			
			err = read_i2c_data(dcc_info->pRUA, delay, dev, 0x6B, wss_data, 7); 
			if (RMFAILED(err)) {
				//fprintf(stderr, "Failed to read WSS data at 0x6B\n");
				return err;
			}
			//fprintf(stderr, "SAA7119 WSS: %02X %02X %02X %02X %02X %02X %02X\n", 
			//	wss_data[0], wss_data[1], wss_data[2], wss_data[3], wss_data[4], wss_data[5], wss_data[6]);
			if ((wss_data[0] & 0xC0) == 0) {
				wss = ((wss_data[2] & 0x3F) << 8) | wss_data[1];
				if (local_opt->wss_odd != wss) {
					fprintf(stderr, "SAA7119 WSS odd: 0x%04lX\n", wss);
					local_opt->wss_odd = wss;
					uw = TRUE;
				}
			}
			if ((wss_data[0] & 0x30) == 0) {
				wss = ((wss_data[5] & 0x3F) << 8) | wss_data[4];
				if (local_opt->wss_even != wss) {
					fprintf(stderr, "SAA7119 WSS evn: 0x%04lX\n", wss);
					local_opt->wss_even = wss;
					/*uw = TRUE;*/
				}
			}
			if (uw /*&& (local_opt->wss_odd == local_opt->wss_even)*/) {
				active_format_valid = TRUE;
				active_format = EMhwlibAF_same_as_picture;
				wide_screen = FALSE;
				switch (local_opt->wss_odd & 0x0F) {
					case 0x8 | 0x0:  // PAL WSS "4:3 frame"
						fprintf(stderr, "SAA7119 WSS.625: 4:3 Frame, Full Picture\n");
						break;
					case 0x0 | 0x1:  // PAL WSS "14:9 letterbox in 4:3 frame"
						fprintf(stderr, "SAA7119 WSS.625: 4:3 Frame, 14:9 Picture, at center\n");
						active_format = EMhwlibAF_14x9_centered;
						break;
					case 0x0 | 0x2:  // PAL WSS "14:9 letterbox at top of 4:3 frame"
						fprintf(stderr, "SAA7119 WSS.625: 4:3 Frame, 14:9 Picture, at top\n");
						active_format = EMhwlibAF_14x9_top;
						break;
					case 0x8 | 0x3:  // PAL WSS "16:9 letterbox in 4:3 frame"
						fprintf(stderr, "SAA7119 WSS.625: 4:3 Frame, 16:9 Picture, at center\n");
						active_format = EMhwlibAF_16x9_centered;
						break;
					case 0x0 | 0x4:  // PAL WSS "16:9 letterbox at top of 4:3 frame"
						fprintf(stderr, "SAA7119 WSS.625: 4:3 Frame, 16:9 Picture, at top\n");
						active_format = EMhwlibAF_16x9_top;
						break;
					case 0x8 | 0x5:  // PAL WSS "> 16:9 letterbox in 4:3 frame"
						fprintf(stderr, "SAA7119 WSS.625: 4:3 Frame, 64:27 Picture, at center\n");
						active_format = EMhwlibAF_64x27_centered;
						break;
					case 0x8 | 0x6:  // PAL WSS "4:3/14:9 letterbox in 4:3 frame"
						fprintf(stderr, "SAA7119 WSS.625: 4:3 Frame, 4:3 Picture with relevant content in 14:9 portion, at center\n");
						active_format = EMhwlibAF_4x3_centered_prot_14x9;
						break;
					case 0x0 | 0x7:  // PAL WSS "16:9 frame"
						fprintf(stderr, "SAA7119 WSS.625: 16:9 Frame, Full Picture\n");
						wide_screen = TRUE;
						break;
					default:
						fprintf(stderr, "SAA7119 WSS.625: Parity Error!\n");
						active_format_valid = FALSE;
						break;
				}
				if (active_format_valid && (! local_opt->force_active_format) && (local_opt->active_format != active_format)) {
					fprintf(stderr, "SAA7119 new active format from WSS: \"%s\" (%u)\n", 
						get_afd_name(active_format), active_format);
					local_opt->active_format = active_format;
					u = TRUE;
				}
				if (active_format_valid && (! local_opt->force_wide_screen) && (local_opt->wide_screen != wide_screen)) {
					fprintf(stderr, "SAA7119 new aspect ratio from WSS: %s\n", 
						wide_screen ? "Wide" : "Normal");
					local_opt->wide_screen = wide_screen;
					u = TRUE;
				}
			}
		}
	}
	
	if (update) *update = u;
	return err;
}

static RMstatus init_capture_SAA7119(
	struct RUA *pInstance, 
	struct capture_cmdline *capture_opt, 
	struct local_cmdline *local_opt, 
	RMuint8 dev, 
	RMuint8 delay)
{
	RMstatus err;
	RMuint32 reg;
	RMuint32 xtal_clk;
	//RMbool SD, ED, HD;
	struct SystemBlock_GPIO_type gpio;
	
	// Philips SAA 7119 setup (CVBS on AI11, auto PAL-BG/NTSC-M, 8 bit 656/601 on i-port, h- and v-sync on RTS0 and RTS1)
	RMuint8 i2c_data[][2] = {
		{0x88, 0x20}, // take scaler out of reset
		{0x83, 0x11}, // xport enabled
		{0x01, 0x17},
		{0x02, 0x00},  // input CVBS on AI11
		{0x03, 0x40},
		{0x04, 0xe0},
		{0x05, 0xe0},
		{0x06, 0xf4}, // (0xeb) Horizontal Sync Start @ 0
		{0x07, 0xe2}, // (0xe0) Horizontal Sync is 4 Clk long
		{0x08, 0x90},
		{0x09, 0x80}, // (0x40 for cvbs)
		{0x0a, 0x80},
		{0x0b, 0x44},
		{0x0c, 0x40},
		{0x0d, 0x00},
		{0x0e, 0x03}, // pref. 50/60 Hz auto detect: 00:PAL-BG/NTSC-M 40:PAL-BG/NTSC-Japan 50:SECAM/NTSC-M
		{0x0f, 0x37},
		{0x10, 0x06},
	//	{0x11, 0x68},		// RTS0 and RTS1 pins are inverted
		{0x11, 0x20},		// RTS0 and RTS1 pins are not inverted
	//	{0x12, 0xc8},		// RTS0 is HSync and RTS1 is VSync
		{0x12, 0xc9},		// RTS0 is HS and RTS1 is VSync
		{0x13, 0x80},
		{0x14, 0xc0},
		{0x15, 0x15},
		{0x16, 0x20},
		{0x17, 0xe8}, // tri-state LLC, LLC2, 5 field loop search
		{0x18, 0x40},
		{0x19, 0x80},
		{0x1a, 0x77},
		{0x1b, 0x42},
		{0x1c, 0xa9}, // 0xdd
		{0x1d, 0x01},
		{0x21, 0x03},
		{0x22, 0x96},
		{0x23, 0x96},
		{0x24, 0x6e},
		{0x25, 0x07},
		{0x26, 0xa0},
		{0x27, 0x00},
		{0x28, 0x10},
		{0x29, 0x00},
		{0x2a, 0x80},
		{0x2b, 0x40},
		{0x2c, 0x40},
		{0x2d, 0x00}, // Disable Interrupts
		{0x2e, 0x00}, // Disable Interrupts
		{0x2f, 0x00}, // Disable Interrupts
		
		// Audio PLL setup (0x30 - 0x3f) is done in init_capture_SAA7119_amclk()
		
		{0x40, 0x40},  // VBI slicer
		{0x41, 0xff},  // lines 2 / 266/316
		{0x42, 0xff},  // lines 3 / 267/317
		{0x43, 0xff},  // lines 4 / 268/318
		{0x44, 0xff},  // lines 5 / 269/319
		{0x45, 0xff},  // lines 6 / 270/320
		{0x46, 0xff},  // lines 7 / 271/321
		{0x47, 0xff},  // lines 8 / 272/322
		{0x48, 0xff},  // lines 9 / 273/323
		{0x49, 0xff},  // lines 10 / 274/324
		{0x4a, 0xff},  // lines 11 / 275/325
		{0x4b, 0xff},  // lines 12 / 276/326
		{0x4c, 0xff},  // lines 13 / 277/327
		{0x4d, 0xff},  // lines 14 / 278/328
		{0x4e, 0xff},  // lines 15 / 279/329
		{0x4f, 0xff},  // lines 16 / 280/330
		{0x50, 0xff},  // lines 17 / 281/331
		{0x51, 0xff},  // lines 18 / 282/332
		{0x52, 0xff},  // lines 19 / 283/333
		{0x53, 0xff},  // lines 20 / 284/334
		{0x54, 0xff},  // lines 21 / 285/335
		{0x55, 0xff},  // lines 22 / 286/336
		{0x56, 0xff},  // lines 23 / 287/337
		{0x57, 0xff},  // lines 24 / 288/338
		{0x58, 0x40},
		{0x59, 0x47},
		{0x5a, 0x06}, // 0x03 for PAL
		{0x5b, 0x83},
		{0x5d, 0x66}, // 0C: SAV/EAV 00:no VBI data 62:ANC
		{0x5e, 0x00}, 
		{0x5f, 0x00},
		
		{0x80, 0x90}, 
		{0x81, 0x00},
		{0x84, 0x0a},
		{0x85, 0x00},
		{0x86, 0x40},
		{0x87, 0x11}, // iport enabled
		{0x8e, 0x00},
		{0x90, 0x00},
		{0x91, 0x08},
		{0x92, 0x00},
		{0x93, 0xc0}, // 80:656 40:yuv-black at blanking ; 00=4:2:2 01=4:1:1 02=4:2:0 03=4:1:0 04=Y only
		{0x94, 0x04},
		{0x95, 0x00},
		{0x96, 0xd0},
		{0x97, 0x02},
		{0x98, 0x07},
		{0x99, 0x01},
		{0x9a, 0x06},
		{0x9b, 0x01},
		{0x9c, 0xd0},
		{0x9d, 0x02},
		{0x9e, 0x07},
		{0x9f, 0x01},
		{0xa0, 0x01},
		{0xa1, 0x00},
		{0xa2, 0x00},
		{0xa4, 0x80}, // brightness
		{0xa5, 0x40}, // contrast
		{0xa6, 0x40}, // saturation
		{0xa8, 0x00},
		{0xa9, 0x04},
		{0xaa, 0x00},
		{0xac, 0x00},
		{0xad, 0x02},
		{0xae, 0x00},
		{0xb0, 0x00},
		{0xb1, 0x04},
		{0xb4, 0x41},
		{0xb5, 0x15},
		{0xb6, 0x33},
		{0xb7, 0xe3},
		{0xb8, 0x00},
		{0xb9, 0x00},
		{0xba, 0x00},
		{0xbb, 0x00},
		{0xc0, 0x03},
		{0xc1, 0x08},
		{0xc2, 0x00},
		{0xc3, 0x80},
		{0xc4, 0x03},
		{0xc5, 0x00},
		{0xc6, 0xd0},
		{0xc7, 0x02},
		{0xc8, 0x18},
		{0xc9, 0x00},
		{0xca, 0x18},
		{0xcb, 0x01},
		{0xcc, 0xce},
		{0xcd, 0x02},
		{0xce, 0x18},
		{0xcf, 0x01},
		{0xd0, 0x02},
		{0xd1, 0x01},
		{0xd2, 0x01},
		{0xd4, 0x80},
		{0xd5, 0x20},
		{0xd6, 0x20},
		{0xd8, 0x00},
		{0xd9, 0x04},
		{0xda, 0x00},
		{0xdc, 0x00},
		{0xdd, 0x02},
		{0xde, 0x00},
		{0xe0, 0xf8},
		{0xe1, 0x07},
		{0xe4, 0x41},
		{0xe5, 0x05},
		{0xe6, 0x00},
		{0xe7, 0x00},
		{0xe8, 0x07},
		{0xe9, 0x07},
		{0xea, 0x07},
		{0xeb, 0x07},
		{0x88, 0x00}, // set scaler reset bit
		{0x88, 0x30}, // take scaler out of reset, set DPROG signal (device has been programmed)
		{0x83, 0x10}, // xport disabled
	};
	RMuint8 i2c_data_tt[][2] = {  // Enable PAL TeleText slicing
		{0x41, 0xff},  // lines 2 / 316
		{0x42, 0xff},  // lines 3 / 317
		{0x43, 0xff},  // lines 4 / 318
		{0x44, 0xf1},  // lines 5 / 319
		{0x45, 0x11},  // lines 6 / 320
		{0x46, 0x11},  // lines 7 / 321
		{0x47, 0x11},  // lines 8 / 322
		{0x48, 0x11},  // lines 9 / 323
		{0x49, 0x11},  // lines 10 / 324
		{0x4a, 0x11},  // lines 11 / 325
		{0x4b, 0x11},  // lines 12 / 326
		{0x4c, 0x11},  // lines 13 / 327
		{0x4d, 0x11},  // lines 14 / 328
		{0x4e, 0x11},  // lines 15 / 329
		{0x4f, 0x11},  // lines 16 / 330
		{0x50, 0x11},  // lines 17 / 331
		{0x51, 0x11},  // lines 18 / 332
		{0x52, 0x11},  // lines 19 / 333
		{0x53, 0x11},  // lines 20 / 334
		{0x54, 0x11},  // lines 21 / 335
		{0x55, 0x1f},  // lines 22 / 336
		{0x56, 0xff},  // lines 23 / 337
		{0x57, 0xff},  // lines 24 / 338
	};
	RMuint8 i2c_data_cc[][2] = {  // Enable NTSC ClosedCaption/WSS525/CGMS slicing
		{0x41, 0xff},  // lines 2 / 266
		{0x42, 0xff},  // lines 3 / 267
		{0x43, 0xff},  // lines 4 / 268
		{0x44, 0xff},  // lines 5 / 269
		{0x45, 0xff},  // lines 6 / 270
		{0x46, 0xff},  // lines 7 / 271
		{0x47, 0xff},  // lines 8 / 272
		{0x48, 0xff},  // lines 9 / 273
		{0x49, 0xff},  // lines 10 / 274
		{0x4a, 0xff},  // lines 11 / 275
		{0x4b, 0xff},  // lines 12 / 276
		{0x4c, 0xff},  // lines 13 / 277
		{0x4d, 0xff},  // lines 14 / 278
		{0x4e, 0xff},  // lines 15 / 279
		{0x4f, 0xff},  // lines 16 / 280
		{0x50, 0xff},  // lines 17 / 281
		{0x51, 0xff},  // lines 18 / 282
		{0x52, 0xf5},  // lines 19 / 283
		{0x53, 0x54},  // lines 20 / 284
		{0x54, 0x4f},  // lines 21 / 285
		{0x55, 0xff},  // lines 22 / 286
		{0x56, 0xff},  // lines 23 / 287
		{0x57, 0xff},  // lines 24 / 288
	};
	
	/*
	SD = ED = HD = FALSE;
	switch (capture_opt->TVStandard) {
		case EMhwlibTVStandard_ITU_Bt656_525:
		case EMhwlibTVStandard_ITU_Bt656_625:
		case EMhwlibTVStandard_NTSC_M_Japan:
		case EMhwlibTVStandard_NTSC_M:
		case EMhwlibTVStandard_PAL_60:
		case EMhwlibTVStandard_PAL_M:
		case EMhwlibTVStandard_NTSC_M_Japan_714:
		case EMhwlibTVStandard_NTSC_M_714:
		case EMhwlibTVStandard_PAL_60_714:
		case EMhwlibTVStandard_PAL_M_714:
		case EMhwlibTVStandard_PAL_BG:
		case EMhwlibTVStandard_PAL_BG_702:
		case EMhwlibTVStandard_PAL_N:
		case EMhwlibTVStandard_PAL_N_702:
			SD = TRUE;
			break;
		case EMhwlibTVStandard_480p59:
		case EMhwlibTVStandard_480p59_714:
		case EMhwlibTVStandard_576p50:
		case EMhwlibTVStandard_576p50_702:
			ED = TRUE;
			break;
		default:
			HD = TRUE;
			break;
	}
	*/
	
	err = init_i2c(pInstance, delay, dev, i2c_data, sizeof(i2c_data) / sizeof (RMuint8) / 2);
	if (RMFAILED(err)) return err;
	err = read_i2c(pInstance, delay, dev, 0x8F, &reg);
	if (RMFAILED(err)) return err;
	if (! (reg & 0x08)) {
		fprintf(stderr, "Philips 7119 power-up or start-up failed!\n");
		return RM_ERROR;
	}
	
	switch (local_opt->i2c_board) {
		case cap_kissjamoplasma:
			if (dev == 0x21) {  // second chip, 16 bit I/F
				write_i2c(pInstance, delay, dev, 0x0F, 0x3E);
				write_i2c(pInstance, delay, dev, 0x80, 0x9C);
			}
			switch (local_opt->i2c_port) {
				case cap_CVBS1:      err = write_i2c(pInstance, delay, dev, 0x02, 0x00); break;
				case cap_CVBS2:      err = write_i2c(pInstance, delay, dev, 0x02, 0x1C); break;
				case cap_SVideo1:    err = write_i2c(pInstance, delay, dev, 0x02, 0xD6); break;
				case cap_SVideo2:    err = write_i2c(pInstance, delay, dev, 0x02, 0xD7); break;
				case cap_ScartCVBS1: err = write_i2c(pInstance, delay, dev, 0x02, 0xCE); break;
				case cap_ScartCVBS2: err = write_i2c(pInstance, delay, dev, 0x02, 0xCF); break;
				case cap_ScartRGB1:  err = write_i2c(pInstance, delay, dev, 0x02, 0x3E); break;
				case cap_ScartRGB2:  err = write_i2c(pInstance, delay, dev, 0x02, 0x3F); break;
				case cap_Tuner1:     err = write_i2c(pInstance, delay, dev, 0x02, 0xC2); break;
				case cap_Tuner2:     err = write_i2c(pInstance, delay, dev, 0x02, 0xC3); break;
				case cap_Component1: err = write_i2c(pInstance, delay, dev, 0x02, 0x2E); break;
				case cap_Component2: err = write_i2c(pInstance, delay, dev, 0x02, 0x2F); break;
				default: err = RM_ERROR;
			}
			break;
		case cap_pioneer809e1video:
			// HDMI input
			gpio.Bit = GPIOId_Sys_6;
			if ((local_opt->i2c_port == cap_HDMI0) || (local_opt->i2c_port == cap_HDMI1)) {
				gpio.Data = FALSE;  // switch to SiI9031
				RUASetProperty(pInstance, SystemBlock, RMSystemBlockPropertyID_GPIO, &gpio, sizeof(gpio), 0);
				return init_capture_SiI9031(pInstance, capture_opt, local_opt, 0x30, delay);
			}
			gpio.Data = TRUE;  // switch to saa7119
			RUASetProperty(pInstance, SystemBlock, RMSystemBlockPropertyID_GPIO, &gpio, sizeof(gpio), 0);
			switch (local_opt->i2c_port) {
				case cap_CVBS1:      err = write_i2c(pInstance, delay, dev, 0x02, 0x01); break;
				case cap_SVideo1:    err = write_i2c(pInstance, delay, dev, 0x02, 0x19); break;
				case cap_Component1: err = write_i2c(pInstance, delay, dev, 0x02, 0x20); break;
				default: err = RM_ERROR;
			}
			break;
		case cap_sigma844e1dtv:
			// AD9883 and SiI9031 have to be connected to 24 bit GraphicIn
			if (capture_opt->InputModuleID == DispGraphicInput) {
				// HDMI input
				if ((local_opt->i2c_port == cap_HDMI0) || (local_opt->i2c_port == cap_HDMI1)) {
					err = tristate_AD9883(pInstance, delay, 0x4C);
					if (RMFAILED(err)) fprintf(stderr, "Failed to Tri-State AD9883!\n");
					gpio.Bit = GPIOId_Sys_15;
					gpio.Data = FALSE;  // route HDMI audio to I2S input
					RUASetProperty(pInstance, SystemBlock, RMSystemBlockPropertyID_GPIO, &gpio, sizeof(gpio), 0);
					// Init SiI9031 and return, no SAA7119 init
					return init_capture_SiI9031(pInstance, capture_opt, local_opt, 0x30, delay);
				} else 
				
				// VGA input or Component in with HDTV signal
				if ((local_opt->i2c_port == cap_VGA) || (local_opt->i2c_port == cap_Component1)) {
					gpio.Bit = GPIOId_Sys_14;
					gpio.Data = (local_opt->i2c_port == cap_VGA);  // route YUV or VGA to AD9883
					RUASetProperty(pInstance, SystemBlock, RMSystemBlockPropertyID_GPIO, &gpio, sizeof(gpio), 0);
					err = tristate_SiI9031(pInstance, delay, 0x30);
					if (RMFAILED(err)) fprintf(stderr, "Failed to Tri-State SiI9031!\n");
					// Init AD9883 and return, no SAA7119 init
					return init_capture_AD9883(pInstance, capture_opt, local_opt, 0x4C, delay);
				}
			}
			gpio.Bit = GPIOId_Sys_15;
			gpio.Data = TRUE;  // route Analog audio to I2S input
			RUASetProperty(pInstance, SystemBlock, RMSystemBlockPropertyID_GPIO, &gpio, sizeof(gpio), 0);
			// No break, fall through to SAA7119 init
		case cap_sigma775avinput: 
		case cap_sigma760e2hdlcd:
			switch (local_opt->i2c_port) {
				case cap_Direct:     return tristate_SAA7119(pInstance, delay, dev);
				case cap_CVBS1:      err = write_i2c(pInstance, delay, dev, 0x02, 0x0E); break;
				case cap_SVideo1:    err = write_i2c(pInstance, delay, dev, 0x02, 0x0D); break;
				case cap_ScartCVBS1: err = write_i2c(pInstance, delay, dev, 0x02, 0x01); break;
				case cap_ScartRGB1:  err = write_i2c(pInstance, delay, dev, 0x02, 0x33); break;
				case cap_Component1: err = write_i2c(pInstance, delay, dev, 0x02, 0x20); break;
				case cap_Tuner1:     err = write_i2c(pInstance, delay, dev, 0x02, 0x04); break;
				default: err = RM_ERROR;
			}
			break;
		default:
			err = RM_ERROR;
			break;
	}
	if (RMFAILED(err)) return err;
	
	switch (local_opt->i2c_port) {
		case cap_CVBS1:
		case cap_CVBS2:
		case cap_ScartCVBS1:
		case cap_ScartCVBS2: 
		case cap_Tuner1:
		case cap_Tuner2:
			// activate chrominance trap and comb filter for CVBS
			err = write_i2c(pInstance, delay, dev, 0x09, 0x40); 
			break;
		case cap_Component1: 
		case cap_Component2: 
		case cap_ScartRGB1: 
		case cap_ScartRGB2: 
			// activate overlay channel for component video
			err = write_i2c(pInstance, delay, dev, 0x27, 0x01);
			break;
		default:
			break;
	}
	if (RMFAILED(err)) return err;
	
	switch (capture_opt->TVStandard) {  // select VBI data slicing
		case EMhwlibTVStandard_ITU_Bt656_625:
		case EMhwlibTVStandard_ITU_Bt656_288p:
		case EMhwlibTVStandard_PAL_BG:
		case EMhwlibTVStandard_PAL_BG_702:
		case EMhwlibTVStandard_PAL_N:
		case EMhwlibTVStandard_PAL_N_702:
			if (capture_opt->vbianc_enable) { // TeleText data has to be handled by ANC capture
				fprintf(stderr, "Setting up PAL TeleText VBI slicing/\n");
				err = init_i2c(pInstance, delay, dev, i2c_data_tt, sizeof(i2c_data_tt) / sizeof (RMuint8) / 2);
				if (RMFAILED(err)) return err;
			}
			// enable WSS625 slicing
			err = read_i2c(pInstance, delay, dev, 0x55, &reg);
			reg = (reg & 0xF0) | 0x05;
			err = write_i2c(pInstance, delay, dev, 0x55, reg);
			err = read_i2c(pInstance, delay, dev, 0x56, &reg);
			reg = (reg & 0x0F) | 0x50;
			err = write_i2c(pInstance, delay, dev, 0x56, reg);
			break;
		case EMhwlibTVStandard_ITU_Bt656_525:
		case EMhwlibTVStandard_ITU_Bt656_240p:
		case EMhwlibTVStandard_NTSC_M_Japan:
		case EMhwlibTVStandard_NTSC_M_Japan_714:
		case EMhwlibTVStandard_NTSC_M:
		case EMhwlibTVStandard_NTSC_M_714:
			fprintf(stderr, "Setting up NTSC ClosedCaption VBI slicing/\n");
			err = init_i2c(pInstance, delay, dev, i2c_data_cc, sizeof(i2c_data_cc) / sizeof (RMuint8) / 2);
			if (RMFAILED(err)) return err;
			break;
		default:
			break;
	}
	switch (capture_opt->TVStandard) {  // vertical offset
		case EMhwlibTVStandard_ITU_Bt656_625:
		case EMhwlibTVStandard_ITU_Bt656_288p:
		case EMhwlibTVStandard_PAL_BG:
		case EMhwlibTVStandard_PAL_BG_702:
		case EMhwlibTVStandard_PAL_N:
		case EMhwlibTVStandard_PAL_N_702:
			err = write_i2c(pInstance, delay, dev, 0x5a, 0x03);
			err = write_i2c(pInstance, delay, dev, 0x5b, 0x03);
		case EMhwlibTVStandard_ITU_Bt656_525:
		case EMhwlibTVStandard_ITU_Bt656_240p:
		case EMhwlibTVStandard_NTSC_M_Japan:
		case EMhwlibTVStandard_NTSC_M_Japan_714:
		case EMhwlibTVStandard_NTSC_M:
		case EMhwlibTVStandard_NTSC_M_714:
		case EMhwlibTVStandard_PAL_60:
		case EMhwlibTVStandard_PAL_60_714:
		case EMhwlibTVStandard_PAL_M:
		case EMhwlibTVStandard_PAL_M_714:
			err = write_i2c(pInstance, delay, dev + 4, 0x09, 0x00);
			break;
		case EMhwlibTVStandard_480p59:
		case EMhwlibTVStandard_480p59_714:
		case EMhwlibTVStandard_576p50:
		case EMhwlibTVStandard_576p50_702:
			err = write_i2c(pInstance, delay, dev + 4, 0x02, 0x33);
			err = write_i2c(pInstance, delay, dev + 4, 0x03, 0xFC);
			err = write_i2c(pInstance, delay, dev + 4, 0x04, (capture_opt->TVStandard == EMhwlibTVStandard_576p50) ? 0x6c : 0x72);
			err = write_i2c(pInstance, delay, dev + 4, 0x08, 0xa0);
			err = write_i2c(pInstance, delay, dev + 4, 0x09, 0x01);
			err = write_i2c(pInstance, delay, dev + 4, 0x15, 0x01);
			err = write_i2c(pInstance, delay, dev + 4, 0x16, 0x03);
			err = write_i2c(pInstance, delay, dev + 4, 0x17, 0x00);
			break;
		case EMhwlibTVStandard_720p60:
		case EMhwlibTVStandard_720p59:
		case EMhwlibTVStandard_720p50:
			err = write_i2c(pInstance, delay, dev + 4, 0x09, 0x13);
			// TODO
			break;
		case EMhwlibTVStandard_1080i60:
		case EMhwlibTVStandard_1080i59:
		case EMhwlibTVStandard_1080i50:
			err = write_i2c(pInstance, delay, dev + 4, 0x09, 0x0b);
			// TODO
			break;
		default:
			break;
	}
	if (RMFAILED(err)) return err;
	
	switch (local_opt->i2c_board) {
		case cap_kissjamoplasma:
		case cap_sigma775avinput:
		case cap_sigma760e2hdlcd:
		case cap_sigma844e1dtv:
		case cap_pioneer809e1video:
			xtal_clk = 32110000;
			break;
		default:
			xtal_clk = 32110000;  // or 24576000 ?
			break;
	}
	if (audio_opt.SampleRate) {
		err = init_capture_SAA7119_amclk(pInstance, capture_opt, local_opt, dev, delay, audio_opt.SampleRate, xtal_clk, TRUE);
		if (RMFAILED(err)) return err;
	}
	
	return err;
}

static RMstatus setCaptureVideoPort(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,enum capture_port port)
{
	RMstatus err=RM_OK;
	switch (port) {
				case cap_CVBS1:    
				case cap_CVBS2:
					printf("***CVBS1 Input (Audio out HeadPhone) ***\n");
					err=tw9919eid_setCapturePort(pInstance,dev,delay,1);									
					break;					
				case cap_SVideo1:    
				case cap_SVideo2:
					printf("***S-Video 1 Input (Audio out Headphone) ***\n");
					tw9919eid_setCapturePort(pInstance,dev,delay,2);
					break;
				case cap_Tuner1:
				case cap_Tuner2:
					printf("***Tuner 1 Input (Audio out Headphone)***\n");
					tw9919eid_setCapturePort(pInstance,dev,delay,3);
					break;
				case cap_Component1:					
				case cap_Component2:
					printf("***YUV Input ***\n");
					mcp23008_selectAnalogAudio(pInstance);
					ad9380_setCapturePort(pInstance,dev,delay,1);
					break;
				case cap_VGA:
					printf("***VGA Input ***\n");
					ad9380_setCapturePort(pInstance,dev,delay,2);
					break;
				case cap_HDMI0:
					printf("***HDMI 0 Input ***\n");
					mcp23008_openHDMIPort(pInstance,2);					
					mcp23008_setEQForHDMI(pInstance,3);
					ad9380_setCapturePort(pInstance,dev,delay,3);
					break;
				case cap_HDMI1:
					printf("***HDMI 1 Input ***\n");
					mcp23008_openHDMIPort(pInstance,3);
					mcp23008_setEQForHDMI(pInstance,2);
					ad9380_setCapturePort(pInstance,dev,delay,3);
					
					break;
				default: 
					printf("Only support CVBS and S-Video Capture Port ! CVBS By default !\n");
					//tw9919eid_setCapturePort(pInstance,dev,delay,1);
					break;
				}
	usleep(50);	
	return err;
}

#ifndef NO_AUDIO
static RMstatus setCaptureAudioPort(struct RUA *pInstance,enum capture_port port,RMuint8 isHeadphoneOutput,RMuint8 isScart1Input,RMuint8 headPhoneVolume,RMuint8 loudSpeakerVolume)
{
	RMstatus err=RM_OK;
/*
	err= msp4450g_InitScart4InHeadPhoneOut(pInstance);
	return RM_OK;
*/
	if (isHeadphoneOutput) {
		switch (port) {
		case cap_CVBS1:    
		case cap_SVideo1: 
			err=mcp23008_selectAnalogAudio(pInstance);
			if (isScart1Input) {
				err=msp4450g_initScartInputThoughtI2s(pInstance,0,1,0,32,0,1,0);
			}else {
				//err= msp4450g_InitScart4InHeadPhoneOut(pInstance);
				err=msp4450g_initScartInputThoughtI2s(pInstance,0,4,0,32,0,1,0);				
			}
			break;
		case cap_Tuner1:
			err=mcp23008_selectAnalogAudio(pInstance);
			err=msp4450g_InitMonoInHeadPhoneOut(pInstance);
			break;
		case cap_Component1:
		case cap_Component2:
			err=mcp23008_selectAnalogAudio(pInstance);
			//err=msp4450g_initScartInputThoughtI2s(pInstance,1,3,0,24,0,1,0);
			err=msp4450g_initScartInputThoughtI2s(pInstance,1,3,0,32,0,1,0);
			break;
		case cap_VGA:
			err=mcp23008_selectAnalogAudio(pInstance);
			break;
		case cap_HDMI0:
		case cap_HDMI1:
			err=mcp23008_selectHDMIAudio(pInstance);
			err=msp4450g_InitI2s3InAndHeadPhoneOut(pInstance);
			break;
		default: 
			printf("Only support CVBS and S-Video Capture Port ! CVBS By default !\n");
			if (isScart1Input) {
				err= msp4450g_InitScart1InHeadPhoneOut(pInstance);
			}else {
				err= msp4450g_InitScart4InHeadPhoneOut(pInstance);
			}
			break;
		}
	}
	else {
		switch (port) {
		case cap_CVBS1:    
		case cap_SVideo1: 
			err=mcp23008_selectAnalogAudio(pInstance);			
			if (isScart1Input) {
				err=msp4450g_initScartInputThoughtI2s(pInstance,0,1,0,32,1,1,0);
			}else {
				//err= msp4450g_InitScart4InHeadPhoneOut(pInstance);
				err=msp4450g_initScartInputThoughtI2s(pInstance,0,4,0,32,1,1,0);				
			}
			break;
		case cap_Tuner1:
			err=mcp23008_selectAnalogAudio(pInstance);			
			err=msp4450g_InitMonoInLoudSpeakerOut(pInstance);
			break;
		case cap_Component1:			
		case cap_Component2:
			err=mcp23008_selectAnalogAudio(pInstance);
			//err=msp4450g_initScartInputThoughtI2s(pInstance,1,3,1,32,1,1,1);
			//err=msp4450g_initScartInputThoughtI2s(pInstance,1,3,0,24,1,1,0);
			//err=msp4450g_initScartInputThoughtI2s(pInstance,1,3,1,32,1,1,0);
			err=msp4450g_initScartInputThoughtI2s(pInstance,1,3,0,32,1,1,0);


			break;
		case cap_VGA:
			err=mcp23008_selectAnalogAudio(pInstance);
			break;
		case cap_HDMI0:
			
		case cap_HDMI1:
			err=mcp23008_selectHDMIAudio(pInstance);
			err=msp4450g_InitI2s3InAndLoudSpeakerOut(pInstance);
			break;
		default: 
			printf("No support capture port Audio !\n");			
			return RM_ERROR;
			break;
		}
		
	}	
	//volume :
	err=msp4450g_headphone_SetVolume(pInstance,headPhoneVolume);
	err=msp4450g_loudspeaker_SetVolume(pInstance,loudSpeakerVolume);
	return err;
}
#endif

static void writeGpio(struct RUA *pInstance, enum GPIOId_type pin,RMbool val)
{
	struct SystemBlock_GPIO_type gpio;
	gpio.Bit = pin;
	//gpio.Data = FALSE;  
	gpio.Data = val;
	RUASetProperty(pInstance, SystemBlock, RMSystemBlockPropertyID_GPIO, &gpio, sizeof(gpio), 0);
	
}

static RMstatus init_capture_TW9919(
	struct RUA *pInstance, 
	struct capture_cmdline *capture_opt, 
	struct local_cmdline *local_opt, 
	RMuint8 dev, 
	RMuint8 delay)
{
	RMstatus err;
	RMuint32 xtal_clk;	
	
//	xtal_clk = 32110000;  // or 24576000 ?
	xtal_clk = 27110000;
	
	switch (local_opt->i2c_board) {		
		default:
			fprintf(stderr, "No support that board .  895e1 board bydefault !\n");
		case cap_sigma895e1:
			{
#ifndef NO_AUDIO
				/*
				struct SystemBlock_GPIO_type gpio;
								gpio.Bit = GPIOId_Sys_15;
								gpio.Data = FALSE;  
								RUASetProperty(pInstance, SystemBlock, RMSystemBlockPropertyID_GPIO, &gpio, sizeof(gpio), 0);*/
				
				writeGpio(pInstance,GPIOId_Sys_15,FALSE);
			
/*
				
				gpio.Bit = GPIOId_uart1_3; //UART1_DCD
				gpio.Data = FALSE;  // Power up MSP			
				//gpio.Data = TRUE;  // Power up MSP			
				//RUASetProperty(pInstance, SystemBlock, RMSystemBlockPropertyID_GPIO, &gpio, sizeof(gpio), 0);
				RUASetProperty(pInstance, CPUBlock, RMSystemBlockPropertyID_GPIO, &gpio, sizeof(gpio), 0);
				
				gpio.Bit = GPIOId_uart1_2;//UART1_DSR
				//gpio.Data = TRUE;  // Audio_mute
				gpio.Data = FALSE;  // Audio_mute
				//RUASetProperty(pInstance, SystemBlock, RMSystemBlockPropertyID_GPIO, &gpio, sizeof(gpio), 0);
				RUASetProperty(pInstance, CPUBlock, RMSystemBlockPropertyID_GPIO, &gpio, sizeof(gpio), 0);*/

				
#endif
				
				usleep(10);	
				err=setCaptureVideoPort(pInstance,dev,delay,local_opt->i2c_port);
				if (RMFAILED(err)) {
					fprintf(stderr, "Only support CVBS and S-Video port capture !\n");
					return err;
				}											
				//Set SDRAM memory (64 MB)
				tw9919eid_setSizeOfSDRAM(pInstance,delay,dev,64);	
				//err=tw9919eid_Disable3DCombFilter(pInstance,dev,delay);
				err=tw9919eid_Enable3DCombFilter(pInstance,dev,delay);
				//err=tw9919eid_Enable3DNRDemo(pInstance,dev,delay);					
				err=tw9919eid_Disable3DNRDemo(pInstance,dev,delay);	
				
			}
			break;
	}
	if (RMFAILED(err))
	{
		printf("init_capture_TW9919 error <1>\n");
		return err;
	}

	return err;
}

static RMstatus init_capture_AD9380(
									struct RUA *pInstance, 
									struct capture_cmdline *capture_opt, 
									struct local_cmdline *local_opt, 
									RMuint8 dev, 
									RMuint8 delay)
{
	RMstatus err=RM_OK;			
	switch (local_opt->i2c_board) 
	{		
	default:
		fprintf(stderr, "No support that board .  895e1 board bydefault !\n");
	case cap_sigma895e1:
		{	
			
			writeGpio(pInstance,GPIOId_Sys_15,TRUE); //Disable TW Audio Clock.
			err=setCaptureVideoPort(pInstance,dev,delay,local_opt->i2c_port);				
			
		}
		break;
	}
	if (RMFAILED(err))
	{
		printf("init_capture_AD9380 error <1>\n");
		return err;
	}
	
	return err;
}

static RMstatus init_capture_WM8775(
	struct RUA *pInstance, 
	struct capture_cmdline *capture_opt, 
	struct local_cmdline *local_opt, 
	RMuint8 dev, 
	RMuint8 delay)
{
	RMuint16 input;
	
	// Wolfson WM8775 setup
	RMuint16 i2c_data[][2] = {
		{0x17, 0x0000},  // 0  reset
		{0x0D, 0x0000},  // 1  power up
		{0x0C, 0x0002},  // 2  256fs, slave mode
		{0x0B, 0x0022},  // 3  i2s, 24bit
		{0x15, 0x000f},  // 4  all inputs
	};
	input = i2c_data[4][1];
	switch (local_opt->i2c_board) {
		case cap_sigma775avinput: 
			switch (local_opt->i2c_port) {
				case cap_CVBS1:      input = 0x0001; break;
				case cap_SVideo1:    input = 0x0002; break;
				case cap_Component1: input = 0x0004; break;
				case cap_ScartCVBS1: input = 0x0008; break;
				case cap_ScartRGB1:  input = 0x0008; break;
				default: break;
			}
			break;
		case cap_sigma760e2hdlcd:
		case cap_sigma844e1dtv:
			switch (local_opt->i2c_port) {
				case cap_CVBS1:      input = 0x0001; break;
				case cap_SVideo1:    input = 0x0002; break;
				case cap_Component1: input = 0x0004; break;
				case cap_ScartCVBS1: input = 0x0008; break;
				case cap_ScartRGB1:  input = 0x0008; break;
				case cap_Tuner1:     input = 0x0008; break;
				default: break;
			}
			break;
		default:
			break;
	}
	i2c_data[4][1] = input;
	return init_i2c_WM(pInstance, delay, dev, i2c_data, sizeof(i2c_data) / sizeof (RMuint16) / 2);
}

static RMstatus init_capture_MSP34x5(
	struct RUA *pInstance, 
	struct capture_cmdline *capture_opt, 
	struct local_cmdline *local_opt, 
	RMuint8 dev, 
	RMuint8 delay)
{
	RMstatus err;
	
	// Micronas MSP 34x5 setup
	return RM_OK;
	// TODO
	if (local_opt->i2c_board == cap_kissjamoplasma) {
		switch (local_opt->i2c_port) {
			case cap_CVBS1:      err = write_i2c(pInstance, delay, dev, 0x02, 0x00); break;
			case cap_CVBS2:      err = write_i2c(pInstance, delay, dev, 0x02, 0x1C); break;
			case cap_SVideo1:    err = write_i2c(pInstance, delay, dev, 0x02, 0xD6); break;
			case cap_SVideo2:    err = write_i2c(pInstance, delay, dev, 0x02, 0xD7); break;
			case cap_ScartCVBS1: err = write_i2c(pInstance, delay, dev, 0x02, 0xCE); break;
			case cap_ScartCVBS2: err = write_i2c(pInstance, delay, dev, 0x02, 0xCF); break;
			case cap_ScartRGB1:  err = write_i2c(pInstance, delay, dev, 0x02, 0x3E); break;
			case cap_ScartRGB2:  err = write_i2c(pInstance, delay, dev, 0x02, 0x3F); break;
			case cap_Tuner1:     err = write_i2c(pInstance, delay, dev, 0x02, 0xC2); break;
			case cap_Tuner2:     err = write_i2c(pInstance, delay, dev, 0x02, 0xC3); break;
			case cap_Component1: err = write_i2c(pInstance, delay, dev, 0x02, 0x2E); break;
			case cap_Component2: err = write_i2c(pInstance, delay, dev, 0x02, 0x2F); break;
			default: err = RM_ERROR;
		}
	} else if (local_opt->i2c_board == cap_sigma760e2hdlcd) {
		switch (local_opt->i2c_port) {
			case cap_CVBS1:      err = write_i2c(pInstance, delay, dev, 0x02, 0x0E); break;
			case cap_SVideo1:    err = write_i2c(pInstance, delay, dev, 0x02, 0x0D); break;
			case cap_ScartCVBS1: err = write_i2c(pInstance, delay, dev, 0x02, 0x01); break;
			case cap_ScartRGB1:  err = write_i2c(pInstance, delay, dev, 0x02, 0x33); break;
			case cap_Component1: err = write_i2c(pInstance, delay, dev, 0x02, 0x20); break;
			case cap_Tuner1:     err = write_i2c(pInstance, delay, dev, 0x02, 0x04); break;
			default: err = RM_ERROR;
		}
	} else if (local_opt->i2c_board == cap_sigma844e1dtv) {
		switch (local_opt->i2c_port) {
			case cap_CVBS1:      err = write_i2c(pInstance, delay, dev, 0x02, 0x0E); break;
			case cap_SVideo1:    err = write_i2c(pInstance, delay, dev, 0x02, 0x0D); break;
			case cap_ScartCVBS1: err = write_i2c(pInstance, delay, dev, 0x02, 0x01); break;
			case cap_ScartRGB1:  err = write_i2c(pInstance, delay, dev, 0x02, 0x33); break;
			case cap_Component1: err = write_i2c(pInstance, delay, dev, 0x02, 0x20); break;
			case cap_Tuner1:     err = write_i2c(pInstance, delay, dev, 0x02, 0x04); break;
			default: err = RM_ERROR;
		}
	} else {
		err = RM_ERROR;
	}
	return err;
}
static RMstatus setContrast(struct RUA *pInstance, 								  
							   RMuint8 dev, 
							   RMuint8 delay,
							   RMuint8 i2c_port,
							   RMint8 type,
							   RMuint32 *contrastValue)
{
	RMstatus err=RM_OK;
	switch(i2c_port) {
	case cap_Component1:
	case cap_Component2:
	case cap_VGA:
	case cap_HDMI0:
	case cap_HDMI1:
		if (type==0) {
			if (ad9380_isContrastValid(pInstance,dev,delay,*contrastValue+2)==RM_OK) {
				err=ad9380_setContrast(pInstance,dev,delay,*contrastValue);
			}
		}else
			if (type<0) { //decrease
				err=ad9380_getContrast(pInstance,dev,delay,contrastValue);
				if (ad9380_isContrastValid(pInstance,dev,delay,*contrastValue-2)==RM_OK) {
					*contrastValue-=2;
					err=ad9380_setContrast(pInstance,dev,delay,*contrastValue);
				}
			}else {  //increase
				err=ad9380_getContrast(pInstance,dev,delay,contrastValue);
				if (ad9380_isContrastValid(pInstance,dev,delay,*contrastValue+2)==RM_OK) {
					*contrastValue+=2;
					err=ad9380_setContrast(pInstance,dev,delay,*contrastValue);
				}
			}		
		break;
	case cap_Tuner1:
	case cap_Tuner2:
	case cap_CVBS1:
	case cap_CVBS2:
	case cap_SVideo1:
	case cap_SVideo2:
		if (type==0) {
			if (tw9919eid_isContrastValid(pInstance,dev,delay,*contrastValue+2)) {
				err=tw9919eid_setContrast(pInstance,dev,delay,*contrastValue);
			}
		}else
			if (type<0) { //decrease
				err=tw9919eid_getContrast(pInstance,dev,delay,contrastValue);
				if (tw9919eid_isContrastValid(pInstance,dev,delay,*contrastValue-2)) {
					*contrastValue-=2;
					err=tw9919eid_setContrast(pInstance,dev,delay,*contrastValue);
				}
			}else {  //increase
				err=tw9919eid_getContrast(pInstance,dev,delay,contrastValue);
				if (tw9919eid_isContrastValid(pInstance,dev,delay,*contrastValue+2)) {
					*contrastValue+=2;
					err=tw9919eid_setContrast(pInstance,dev,delay,*contrastValue);
				}
			}	
		break;		
	default:
		return RM_ERROR;
		break;
	}	
	return err;
}

static RMstatus setBrightness(struct RUA *pInstance, 								  
					 RMuint8 dev, 
					 RMuint8 delay,
					 RMuint8 i2c_port,
					 RMint8 type,
					 RMint32 *brightnessValue)
{
	RMstatus err=RM_OK;
	switch(i2c_port) {
	case cap_Component1:
	case cap_Component2:
	case cap_VGA:
	case cap_HDMI0:
	case cap_HDMI1:
		if (0) {
			if (type==0) {
				if (ad9380_isBrightnessValid(pInstance,dev,delay,*brightnessValue+2)==RM_OK) {
					err=ad9380_setBrightness(pInstance,dev,delay,*brightnessValue);
				}
			}else
				if (type<0) { //decrease
					err=ad9380_getBrightness(pInstance,dev,delay,brightnessValue);
					if (ad9380_isBrightnessValid(pInstance,dev,delay,*brightnessValue-2)==RM_OK) {
						*brightnessValue-=2;
						err=ad9380_setBrightness(pInstance,dev,delay,*brightnessValue);
					}
				}else {  //increase
					err=ad9380_getBrightness(pInstance,dev,delay,brightnessValue);
					if (ad9380_isBrightnessValid(pInstance,dev,delay,*brightnessValue+2)==RM_OK) {
						*brightnessValue+=2;
						err=ad9380_setBrightness(pInstance,dev,delay,*brightnessValue);
					}
				}
		}else{
			if (type==0) {
				if (ad9380_isBrightnessAdjustValid(pInstance,dev,delay,*brightnessValue+2)==RM_OK) {
					err=ad9380_setBrightnessAdjust(pInstance,dev,delay,*brightnessValue);
				}
			}else
				if (type<0) { //decrease
					err=ad9380_getBrightnessAdjust(pInstance,dev,delay,brightnessValue);
					if (ad9380_isBrightnessAdjustValid(pInstance,dev,delay,*brightnessValue-2)==RM_OK) {
						*brightnessValue-=2;
						err=ad9380_setBrightnessAdjust(pInstance,dev,delay,*brightnessValue);
					}
				}else {  //increase
					err=ad9380_getBrightnessAdjust(pInstance,dev,delay,brightnessValue);
					if (ad9380_isBrightnessAdjustValid(pInstance,dev,delay,*brightnessValue+2)==RM_OK) {
						*brightnessValue+=2;
						err=ad9380_setBrightnessAdjust(pInstance,dev,delay,*brightnessValue);
					}
				}
		}
		
		break;
	case cap_Tuner1:
	case cap_Tuner2:
	case cap_CVBS1:
	case cap_CVBS2:
	case cap_SVideo1:
	case cap_SVideo2:
		if (type==0) {
			if (tw9919eid_isBrightnessValid(pInstance,dev,delay,*brightnessValue+2)) {
				err=tw9919eid_setBrightness(pInstance,dev,delay,*brightnessValue);
			}
		}else
			if (type<0) { //decrease
				err=tw9919eid_getBrightness(pInstance,dev,delay,brightnessValue);
				if (tw9919eid_isContrastValid(pInstance,dev,delay,*brightnessValue-2)) {
					*brightnessValue-=2;
					err=tw9919eid_setContrast(pInstance,dev,delay,*brightnessValue);
				}
			}else {  //increase
				err=tw9919eid_getBrightness(pInstance,dev,delay,brightnessValue);
				if (tw9919eid_isBrightnessValid(pInstance,dev,delay,*brightnessValue+2)) {
					*brightnessValue+=2;
					err=tw9919eid_setContrast(pInstance,dev,delay,*brightnessValue);
				}
			}	
		
		break;		
	default:
		return RM_ERROR;
		break;
	}	
	return err;
}

static RMstatus init_capture_chip_tw9919eid_ad9380(
												   struct RUA *pInstance, 
												   struct capture_cmdline *capture_opt, 
												   struct local_cmdline *local_opt)
{
#ifndef NO_AUDIO
	Write_Gpio_Uart1(UART_DCD,0);//enable MSP
	Write_Gpio_Uart1(UART_DSR,0);//Audio Unmute
#endif
	switch(local_opt->i2c_port) {
	case cap_Component1:
	case cap_Component2:
	case cap_VGA:
	case cap_HDMI0:
	case cap_HDMI1:
		printf("USING AD9380 CAPTURE CHIP \n");
		local_opt->i2c_video_chip=cap_AD9380;
		local_opt->i2c_video_delay=10;
		local_opt->i2c_video_dev=0x98>>1;
		Write_Gpio_Uart0(UART_DTR,1);
		break;
	case cap_Tuner1:
	case cap_Tuner2:
	case cap_CVBS1:
	case cap_CVBS2:
	case cap_SVideo1:
	case cap_SVideo2:
		Write_Gpio_Uart0(UART_DTR,0);
		printf("USING TW9919EID CAPTURE CHIP \n");
		local_opt->i2c_video_chip=cap_TW9919;
		local_opt->i2c_video_delay=10;
		local_opt->i2c_video_dev=0x88>>1;
		//local_opt->i2c_video_dev=0x8a>>1;
		break;		
	default:
		return RM_ERROR;
		break;
	}		
	switch (local_opt->i2c_video_chip) {
	case cap_NoChip:
		return RM_OK;
	case cap_TW9919:
		return init_capture_TW9919(pInstance, capture_opt, local_opt, local_opt->i2c_video_dev, local_opt->i2c_video_delay); 
	case cap_AD9380:
		return init_capture_AD9380(pInstance, capture_opt, local_opt, local_opt->i2c_video_dev, local_opt->i2c_video_delay);
		
	default:
		return RM_ERROR;
	}
	return RM_ERROR;
}


static RMstatus init_capture(
	struct RUA *pInstance, 
	struct capture_cmdline *capture_opt, 
	struct local_cmdline *local_opt, 
	enum capture_chip chip, 
	RMuint8 dev, 
	RMuint8 delay)
{
	switch(local_opt->i2c_board) {
	case cap_sigma895e1:
		return init_capture_chip_tw9919eid_ad9380(pInstance,capture_opt,local_opt);
		break;
	default:
		break;
	}

	switch (chip) {
		case cap_NoChip:
			return RM_OK;
		case cap_ADV7402:
			return init_capture_ADV7402(pInstance, capture_opt, local_opt, dev, delay); // 0x21, 0);
		case cap_SAA7119:
			return init_capture_SAA7119(pInstance, capture_opt, local_opt, dev, delay); // 0x20/0x21, 0);
		case cap_WM8775:
			return init_capture_WM8775(pInstance, capture_opt, local_opt, dev, delay); // 0x1A, 0);
		case cap_MSP34x5:
			return init_capture_MSP34x5(pInstance, capture_opt, local_opt, dev, delay); // 0x40, 0);
		default:
			return RM_ERROR;
	}
	return RM_ERROR;
}

// Perform Hamming 8/4 check and return data in low 4 bits, or 0xFF on error
/*
static RMuint8 unham[256] = {
	0x01,0xff,0x01,0x01,0xff,0x00,0x01,0xff, 0xff,0x02,0x01,0xff,0x0a,0xff,0xff,0x07,
	0xff,0x00,0x01,0xff,0x00,0x00,0xff,0x00, 0x06,0xff,0xff,0x0b,0xff,0x00,0x03,0xff,
	0xff,0x0c,0x01,0xff,0x04,0xff,0xff,0x07, 0x06,0xff,0xff,0x07,0xff,0x07,0x07,0x07,
	0x06,0xff,0xff,0x05,0xff,0x00,0x0d,0xff, 0x06,0x06,0x06,0xff,0x06,0xff,0xff,0x07,
	0xff,0x02,0x01,0xff,0x04,0xff,0xff,0x09, 0x02,0x02,0xff,0x02,0xff,0x02,0x03,0xff,
	0x08,0xff,0xff,0x05,0xff,0x00,0x03,0xff, 0xff,0x02,0x03,0xff,0x03,0xff,0x03,0x03,
	0x04,0xff,0xff,0x05,0x04,0x04,0x04,0xff, 0xff,0x02,0x0f,0xff,0x04,0xff,0xff,0x07,
	0xff,0x05,0x05,0x05,0x04,0xff,0xff,0x05, 0x06,0xff,0xff,0x05,0xff,0x0e,0x03,0xff,
	0xff,0x0c,0x01,0xff,0x0a,0xff,0xff,0x09, 0x0a,0xff,0xff,0x0b,0x0a,0x0a,0x0a,0xff,
	0x08,0xff,0xff,0x0b,0xff,0x00,0x0d,0xff, 0xff,0x0b,0x0b,0x0b,0x0a,0xff,0xff,0x0b,
	0x0c,0x0c,0xff,0x0c,0xff,0x0c,0x0d,0xff, 0xff,0x0c,0x0f,0xff,0x0a,0xff,0xff,0x07,
	0xff,0x0c,0x0d,0xff,0x0d,0xff,0x0d,0x0d, 0x06,0xff,0xff,0x0b,0xff,0x0e,0x0d,0xff,
	0x08,0xff,0xff,0x09,0xff,0x09,0x09,0x09, 0xff,0x02,0x0f,0xff,0x0a,0xff,0xff,0x09,
	0x08,0x08,0x08,0xff,0x08,0xff,0xff,0x09, 0x08,0xff,0xff,0x0b,0xff,0x0e,0x03,0xff,
	0xff,0x0c,0x0f,0xff,0x04,0xff,0xff,0x09, 0x0f,0xff,0x0f,0x0f,0xff,0x0e,0x0f,0xff,
	0x08,0xff,0xff,0x05,0xff,0x0e,0x0d,0xff, 0xff,0x0e,0x0f,0xff,0x0e,0x0e,0xff,0x0e,
};

static RMascii LatinG0[128] = {
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', // 0
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', // 1
	' ', '!', '"', '#', '$', '%', '&', '`', '(', ')', '*', '+', ',', '-', '.', '/', // 2
	'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?', // 3
	'@', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', // 4
	'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\', ']', '^', '_', // 5
	'e', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', // 6
	'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~', '#', // 7
};
*/

static RMbool odd_par(RMuint8 d)
{
	d ^= (d >> 4);
	d ^= (d >> 2);
	d ^= (d >> 1);
	return (d & 1);
}

static void tt_print_data(RMuint8 *data, RMuint32 size) 
{
	RMuint32 i;
	for (i = 0; i < size; i++) {
		if (odd_par(data[i])) {
			fprintf(stderr, "%c", LatinG0[data[i] & 0x7F]);
		} else {
			fprintf(stderr, "?");
		}
	}
}

// sample code for handling teletext data, only prints page header info
static RMstatus handle_teletext_data(
									 RMbool fid, 
									 RMuint32 line, 
									 RMuint16 *pData, 
									 RMuint32 count)
{
	RMuint8 i=0;
	RMuint8 h, ttbyte[46];
	RMuint32 Mag, Pkt;
	
	
	// Translate 16 bit data to 8 bit, establish byte numbering from ETS 300 706
	if (count > 20) count = 20; //20; org
	for (i = 0; i < count; i++) {
		ttbyte[i * 2 + 4] = pData[i] & 0xFF;
		ttbyte[i * 2 + 5] = pData[i] >> 8;
	}
	switch(local_opt->i2c_board) {
	case cap_sigma895e1:i=1; //have byte 9th is framecode (27) but SAA don't have.
		break;
	default: i=0;
	}
	fprintf(stderr, "TT@%02ld%c: ", line, fid ? 'B' : 'T');
	if ((h = unham[ttbyte[4+i]]) == 0xFF) { 
		fprintf(stderr, "HmErr[%u] 0x%02X\n", 4+i, ttbyte[4+i]);
		return RM_ERROR;
	}
	
	Mag = h & 0x07;
	Pkt = h >> 3;
	if ((h = unham[ttbyte[5+i]]) == 0xFF) {
		fprintf(stderr, "HmErr[%u] 0x%02X\n", 5+i, ttbyte[5+i]);
		return RM_ERROR;
	}
	
	Pkt |= (h << 1);
	fprintf(stderr, "Mag%lu/Pkt%02lu ", Mag, Pkt);
	i=1;
	if (Pkt == 0) {
		RMuint32 Pg0, Pg1, S1, S2, S3, S4, Ctl0, Ctl1;
		if ((Pg0 = unham[ttbyte[6+i]]) == 0xFF) {
			fprintf(stderr, "HmErr[%u] 0x%02X\n", 6+i, ttbyte[6+i]);
			return RM_ERROR;
		}
		if ((Pg1 = unham[ttbyte[7+i]]) == 0xFF) {
			fprintf(stderr, "HmErr[%u] 0x%02X\n", 7+i, ttbyte[7+i]);
			return RM_ERROR;
		}
		if ((S1 = unham[ttbyte[8+i]]) == 0xFF) {
			fprintf(stderr, "HmErr[%u] 0x%02X\n", 8+i, ttbyte[8+i]);
			return RM_ERROR;
		}
		if ((S2 = unham[ttbyte[9+i]]) == 0xFF) {
			fprintf(stderr, "HmErr[%u] 0x%02X\n", 9+i, ttbyte[9+i]);
			return RM_ERROR;
		}
		if ((S3 = unham[ttbyte[10+i]]) == 0xFF) {
			fprintf(stderr, "HmErr[%u] 0x%02X\n", 10+i, ttbyte[10+i]);
			return RM_ERROR;
		}
		if ((S4 = unham[ttbyte[11+i]]) == 0xFF) {
			fprintf(stderr, "HmErr[%u] 0x%02X\n", 11+i, ttbyte[11+i]);
			return RM_ERROR;
		}
		fprintf(stderr, "Pg%lu%lX%lX S%lX%lX-%lX%lX ", Mag, Pg1, Pg0, S4 & 0x03, S3, S2 & 0x07, S1);
		if ((Ctl0 = unham[ttbyte[12+i]]) == 0xFF) {
			fprintf(stderr, "HmErr[%u] 0x%02X\n", 12+i, ttbyte[12+i]);
			return RM_ERROR;
		}
		if ((Ctl1 = unham[ttbyte[13+i]]) == 0xFF) {
			fprintf(stderr, "HmErr[%u] 0x%02X\n", 13+i, ttbyte[13+i]);
			return RM_ERROR;
		}
		fprintf(stderr, "C%ld%ld%ld%ld%ld%ld%ld%ld%ld%ld%ld ", 
			(S2>>3)&1, (S4>>3)&1, (S4>>2)&1, 
			(Ctl1>>3)&1, (Ctl1>>2)&1, (Ctl1>>1)&1, Ctl1&1, 
			(Ctl0>>3)&1, (Ctl0>>2)&1, (Ctl0>>1)&1, Ctl0&1);
		//tt_print_data(&ttbyte[14], count * 2 - 10); //org
		tt_print_data(&ttbyte[14], count * 2 - 10);
	} else if ((Pkt >= 1) && (Pkt <= 25)) {
		//tt_print_data(&ttbyte[6], count * 2 - 2 );//org
		tt_print_data(&ttbyte[6], count * 2 - 2  );
	}
	fprintf(stderr, "\n");
	
	return RM_OK;
}


// sample code for closed caption data, only prints plain text
static RMstatus handle_line21cc_data(
	RMbool fid, 
	RMuint32 line, 
	RMuint16 *pData, 
	RMuint32 count)
{
	static RMbool last_cr = FALSE;
	RMascii ch1, ch2;
	
	//fprintf(stderr, " %02X %02X ", pData[0] & 0x7F, (pData[0] >> 8) & 0x7F);
	if (fid) return RM_OK;  // only handle field 1 data for now
	ch1 = pData[0] & 0x7F;
	ch2 = (pData[0] >> 8) & 0x7F;
	if (ch1 >= 0x20) {
		if (ch1 <= 0x7E) fprintf(stderr, "%c", ch1);
		if ((ch2 >= 0x20) && (ch2 <= 0x7E)) fprintf(stderr, "%c", ch2);
		last_cr = FALSE;
	} else {
		switch (ch1) {
			case 0x00:
			case 0x11:
			case 0x13:
			case 0x19:
			case 0x1b:
				break;
			case 0x14:
			case 0x1c:
				if (! last_cr) {
					fprintf(stderr, "\n"); 
					last_cr = TRUE;
				}
				break;
			default:
				//fprintf(stderr, " %02X %02X ", ch1, ch2);
				break;
		}
	}
	return RM_OK;
}

static RMstatus handle_anc_data(
	RMuint32 type,
	RMbool fid, 
	RMuint32 line, 
	RMuint16 *pData, 
	RMuint32 count)
{
	switch (type) {
		case 1:  // PAL teletext data
			return handle_teletext_data(fid, line, pData, count);
		case 4:  // SAA7119 line 21 Closed Captioning
			return handle_line21cc_data(fid, line, pData, count);
		default:
			break;
	}
	return RM_OK;
}

struct RUA *pInstance = NULL;

static void show_usage(char *progname)
{
	show_local_options();
	show_display_options();
	show_capture_options();
	show_audio_options();
	fprintf(stderr, "--------------------------------\n");
	fprintf(stderr, "Minimum cmd line: %s -i video\n", progname);
	fprintf(stderr, "--------------------------------\n");
	
	exit(1);
}

static void parse_cmdline(int argc, char *argv[])
{
	int i;
	RMstatus err;
	RMbool do_show = FALSE;
	
	if (argc < 2) 
		show_usage(argv[0]);
	
	i = 1;
	while ((! do_show) && (argc > i)) {
		if (argv[i][0] == '-') {
			/* switch to second input with '--' */
			if (! strcmp(&(argv[i][1]), "-")) {
				input_num = 1;
				i++;
				err = RM_OK;
				continue;
			}
			
			err = parse_local_cmdline(argc, argv, &i, &local_opt[input_num]);
			if (err != RM_PENDING) {
				if (RMFAILED(err)) {
					printf("failed in local option: %s\n", argv[i]);
					do_show = TRUE;
				}
				continue;
			}
			
			err = parse_display_cmdline(argc, argv, &i, &disp_opt);
			if (err != RM_PENDING) {
				if (RMFAILED(err)) {
					printf("failed in display option: %s\n", argv[i]);
					do_show = TRUE;
				}
				continue;
			}
			
			err = parse_capture_cmdline(argc, argv, &i, &capture_opt[input_num]);
			if (err != RM_PENDING) {
				if (RMFAILED(err)) {
					printf("failed in capture option: %s\n", argv[i]);
					do_show = TRUE;
				}
				continue;
			}
			
			err = parse_audio_cmdline(argc, argv, &i, &audio_opt);
			if (err != RM_PENDING) {
				if (RMFAILED(err)) {
					printf("failed in audio option: %s\n", argv[i]);
					do_show = TRUE;
				}
				continue;
			}
			
			printf("unknown option: %s\n", argv[i]);
			err = RM_ERROR;
			do_show = TRUE;
		}
	}
	if (do_show) show_usage(argv[0]);
}

// determine best match for mixer color space, 
// from scaler cs and output cs.
static void get_mixer_color_space(
	enum EMhwlibColorSpace ScalerColorSpace, 
	enum EMhwlibColorSpace OutputColorSpace, 
	enum EMhwlibColorSpace *pMixerColorSpace)
{
	switch (ScalerColorSpace) {
	case EMhwlibColorSpace_RGB_16_235:
	case EMhwlibColorSpace_RGB_0_255:
		switch (OutputColorSpace) {
		case EMhwlibColorSpace_RGB_16_235:
		case EMhwlibColorSpace_RGB_0_255:
			*pMixerColorSpace = ScalerColorSpace;
			break;
		case EMhwlibColorSpace_YUV_601:
		case EMhwlibColorSpace_YUV_601_0_255:
		case EMhwlibColorSpace_YUV_709:
		case EMhwlibColorSpace_YUV_709_0_255:
			*pMixerColorSpace = OutputColorSpace;
			break;
		case EMhwlibColorSpace_None:
			break; /* ERROR */
		default:;
		}
		break;
	case EMhwlibColorSpace_YUV_601:
	case EMhwlibColorSpace_YUV_601_0_255:
	case EMhwlibColorSpace_YUV_709:
	case EMhwlibColorSpace_YUV_709_0_255:
		*pMixerColorSpace = ScalerColorSpace;
		break;
	case EMhwlibColorSpace_None:
		break; /* ERROR */
	default: ;
	}
}

// determine if video mode (4:2:2) or graphics mode (RGB, 4:4:4) is used
static void set_graphics_mode(
	enum EMhwlibColorSpace MixerColorSpace, 
	struct capture_cmdline *ip)
{
	RMbool graphics_mode = FALSE;
	
	// detect 4:4:4 YUV or (8:)8:8:8 RGB modes
	if (ip->InputModuleID == DispGraphicInput) {
		graphics_mode = (ip->bussize > 16) || (
			((ip->SurfaceColorSpace == EMhwlibColorSpace_RGB_0_255) || (ip->SurfaceColorSpace == EMhwlibColorSpace_RGB_16_235)) && 
			((MixerColorSpace == EMhwlibColorSpace_RGB_0_255) || (MixerColorSpace == EMhwlibColorSpace_RGB_16_235))
		);
		if (ip->override.Enable) switch (ip->override.ColorFormat) {
			case EMhwlibInputColorFormat_24BPP:
			case EMhwlibInputColorFormat_24BPP_8565:
			case EMhwlibInputColorFormat_24BPP_5676:
			case EMhwlibInputColorFormat_32BPP:
			case EMhwlibInputColorFormat_31BPP_7888:
				graphics_mode = TRUE;
			default:
				break;
		}
	}
	
	if (graphics_mode) {
		ip->SamplingMode   = EMhwlibSamplingMode_444;
		ip->ColorMode      = EMhwlibColorMode_TrueColor;
	}
}

static RMstatus StartAudioCapture(struct dcc_context *dcc_info, RMuint32 audio_capture, struct audio_cmdline *audio_opt, RMuint32 CaptureDelay)
{
	struct AudioCapture_Open_type capture_open;
	enum AudioCapture_Capture_type cmd;
	enum AudioCapture_Source_type src;
	RMstatus err;
	
#if (EM86XX_CHIP == EM86XX_CHIPID_TANGO2) 	
	struct PLL_Frequency_type f;
	RMuint32 SampleClock;

	//printf("start set RCLK2...\n");
	SampleClock = 48000;
	f.PLL = PLLGen_cd_6;
	f.PLLOutput = PLLOut_1;	// or _1 or _2
	f.MaxM = 31;
	f.Clock = ClockSignal_RClk2;
	f.Frequency = SampleClock * 256;
	RUASetProperty(dcc_info->pRUA, PLL, RMPLLPropertyID_Frequency, &f, sizeof(f), 0);
	//printf("finish set RCLK2...\n");
#endif
	
	memset(&capture_open, 0, sizeof(struct AudioCapture_Open_type));
	
	capture_open.CaptureMode = 1; // Pass-through
	capture_open.Delay = (CaptureDelay ? CaptureDelay : (audio_opt->CaptureDelay ? audio_opt->CaptureDelay : 7200)) / 2; // Delay is 45000 Hz based start PTS
	
	if (audio_opt->CaptureSource == 0) {
		// Capture from I2S, 32 bit frames
		//capture_open.SI_CONF = 0x109;  // 16 bit I2S frames
		capture_open.SI_CONF = 0x107 |  // SerialIn Configuration, 32 bit frames
			(audio_opt->AudioInAlign << 3) | 
			(audio_opt->AudioInLSBfirst ? 0x200 : 0x000);
		src = AudioCapture_Source_I2S;
	} else {
		// Capture from SPDIF, always 16 bit frames
		if (audio_opt->CaptureSource == 1) {
#if (EM86XX_CHIP >= EM86XX_CHIPID_TANGO15)  // in 8622/24 Tango 1.5 and 8634 Tango 2 spdif is dedicated line, use it with source=1
			capture_open.SI_CONF = 0x900;  // capture from SI_SPDIF
		} else if (audio_opt->CaptureSource == 2) {
#endif
			capture_open.SI_CONF = 0x100;  // capture from SI_DATA
		} else {
			fprintf(stderr, "Error, wrong audio source: %lu\n", audio_opt->CaptureSource);
			return RM_ERROR;
		}
		src = AudioCapture_Source_SPDIF;
	}
	
	//printf("capture source = %x  spdif=%x SI_CONF = %x\n", audio_opt->CaptureSource, audio_opt->Spdif, capture_open.SI_CONF);
	
	err = RUASetProperty(dcc_info->pRUA, audio_capture, RMAudioCapturePropertyID_Open, 
		&capture_open, sizeof(capture_open), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error opening audio capture module! %s\n", RMstatusToString(err));
		return err;
	}
	
	err = RUASetProperty(dcc_info->pRUA, audio_capture, RMAudioCapturePropertyID_Source, 
		&(src), sizeof(src), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error setting audio capture source! %s\n", RMstatusToString(err));
		return err;
	}
	
	err = RUASetProperty(dcc_info->pRUA, audio_capture, RMAudioCapturePropertyID_SpdifBitstreamNumber, 
		&(audio_opt->CaptureBitstream), sizeof(audio_opt->CaptureBitstream), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error setting audio capture bitstream number! %s\n", RMstatusToString(err));
		return err;
	}
	
	err = RUASetProperty(dcc_info->pRUA, audio_capture, RMAudioCapturePropertyID_SpdifDataType, 
		&(audio_opt->CaptureType), sizeof(audio_opt->CaptureType), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error setting audio capture type! %s\n", RMstatusToString(err));
		return err;
	}
	
	cmd = AudioCapture_Capture_On;
	err = RUASetProperty(dcc_info->pRUA, audio_capture,
		RMAudioCapturePropertyID_Capture, &cmd, sizeof(cmd), 0);
	if (RMFAILED(err)) 
		fprintf(stderr, "Error sending capture ON command. %s\n", RMstatusToString(err));
	
	return err;
}

static RMstatus StopAudioCapture(struct dcc_context *dcc_info, RMuint32 audio_capture)
{
	enum AudioCapture_Capture_type cmd = AudioCapture_Capture_Off;
	RMuint32 temp = 0;
	RMstatus err;
	
	err = RUASetProperty(dcc_info->pRUA, audio_capture,
		RMAudioCapturePropertyID_Capture, &cmd, sizeof(cmd), 0);
	if (RMFAILED(err)) 
		fprintf(stderr, "Error sending capture OFF command. %s\n", RMstatusToString(err));
	
	err = RUASetProperty(dcc_info->pRUA, audio_capture, RMAudioCapturePropertyID_Close, 
		&temp, sizeof(temp), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error closing capture module! %s\n", RMstatusToString(err));
		return err;
	}
	return err;
}

static void cleanup(void *param)
{
	if (pInstance) {
		RUADestroyInstance(pInstance);
		pInstance = NULL;
	}
}

/*
static void print_audio_fifo(struct dcc_context *dcc_info, RMuint32 threshold)
{
	RMstatus err;
	struct DataFIFOInfo audio_info;
	
	err = RUAGetProperty(dcc_info->pRUA, dcc_info->audio_decoder, 
		RMGenericPropertyID_DataFIFOInfo, 
		&audio_info, sizeof(audio_info));
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot retreive A.FIFO!\n");
	} else {
		if (audio_info.Readable * 100 / audio_info.Size >= threshold) 
			fprintf(stderr, "A.FIFO: St.0x%08lX Sz.0x%08lX Wr.0x%08lX Rd.0x%08lX %3lu%% full, %lu readable\n", 
				audio_info.StartAddress, audio_info.Size, audio_info.Writable, audio_info.Readable, 
				audio_info.Readable * 100 / audio_info.Size, audio_info.Readable);
		if (audio_info.Readable > audio_info.Size) {
			fprintf(stderr, "FATAL ERROR: audio playback has crashed!\n");
		}
	}
}
*/

static RMstatus stop_audio_passthrough(
	struct dcc_context *dcc_info, 
	struct audio_cmdline *audio_opt)
{
	RMstatus err;
	
	if (audio_opt->ExternalClk && audio_opt->SampleRate) {
		// Restore internal audio engine clock
		audio_opt->ExternalClk = FALSE;
		err = apply_audio_engine_options(dcc_info, audio_opt);
		audio_opt->ExternalClk = TRUE;
	}
	
	err = StopAudioCapture(dcc_info, EMHWLIB_MODULE(AudioCapture, 0));
	
	err = DCCStopAudioSource(dcc_info->pAudioSource);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot stop audio decoder! %s\n", RMstatusToString(err));
	}
	
	err = DCCCloseAudioSource(dcc_info->pAudioSource);
	dcc_info->pAudioSource = NULL;
	if (RMFAILED(err)) {
		fprintf(stderr, "Error, cannot close audio decoder! %s\n", RMstatusToString(err));
	}
	
	return err;
}

static RMstatus init_audio_passthrough(
	struct dcc_context *dcc_info, 
	struct audio_cmdline *audio_opt, 
	struct capture_cmdline *capture_opt)
{
	RMstatus err;
	RMuint32 CaptureDelay;
	struct DCCAudioProfile audio_profile;
	
	if (dcc_info->pAudioSource) {
		stop_audio_passthrough(dcc_info, audio_opt);
	}
	
	// Retreive video delay and apply to audio, unless specified on command line
	if (audio_opt->CaptureDelay) {
		CaptureDelay = audio_opt->CaptureDelay;
	} else {
		// actual delay is plus/minus one field durations of this value, depending on input-to-output vsync phase
		err = RUAGetProperty(dcc_info->pRUA, capture_opt->InputModuleID, 
			RMGenericPropertyID_CaptureDelay, &CaptureDelay, sizeof(CaptureDelay));
		if (RMFAILED(err) || (CaptureDelay == 0)) {
			CaptureDelay = 6004; // NTSC
			// audio_opt->CaptureDelay = 7200; // PAL
		}
		else fprintf(stderr, "Audio Delay from Video Passthrough: %ld PTS, %ld ms\n", CaptureDelay, CaptureDelay / 90);
	}
	fprintf(stderr, "Audio Delay: %ld PTS, %ld ms\n", CaptureDelay, CaptureDelay / 90);
	
	// Open AudioDecoder
	audio_profile.BitstreamFIFOSize = AUDIO_FIFO_SIZE;
	audio_profile.XferFIFOCount = XFER_FIFO_COUNT;
	audio_profile.DemuxProgramID = audio_opt->AudioEngineID * 2;
	audio_profile.AudioEngineID = audio_opt->AudioEngineID;
	audio_profile.AudioDecoderID = audio_opt->AudioDecoderID;
	audio_profile.STCID = TimerNumber;
	err = DCCOpenAudioDecoderSource(dcc_info->pDCC, &audio_profile, &(dcc_info->pAudioSource));
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot open audio decoder! %s\n", RMstatusToString(err));
		return err;
	}
	
	err = DCCGetAudioDecoderSourceInfo(dcc_info->pAudioSource, &(dcc_info->audio_decoder), &(dcc_info->audio_engine), &(dcc_info->audio_timer));
	if (RMFAILED(err)) {
		fprintf(stderr, "Error getting audio decoder source information! %s\n", RMstatusToString(err));
		return err;
	}
	
	// apply the sample rate, serial out status
	err = apply_audio_engine_options(dcc_info, audio_opt);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error applying audio engine options! %s\n", RMstatusToString(err));
		return err;
	}
	
	// apply the audio format - uninit, set codec, set specific parameters, init
	err = apply_audio_decoder_options(dcc_info, audio_opt);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error applying audio_decoder_options! %s\n", RMstatusToString(err));
		return err;
	}
	
	// Send Play command to audio playback
	err = DCCPlayAudioSource(dcc_info->pAudioSource);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot play audio decoder! %s\n", RMstatusToString(err));
		return err;
	}
	
	// Start audio capture
	err = StartAudioCapture(dcc_info, EMHWLIB_MODULE(AudioCapture, 0), audio_opt, CaptureDelay);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error starting audio capture! %s\n", RMstatusToString(err));
		return err;
	}
	
	if (capture_opt->audio_free_run) {
		RMbool AVSyncEnable = FALSE;
		struct DCCAudioSourceHandle audioHandle1;
		
		// wait until audio decoder has started the delayed playback
		RMMicroSecondSleep(CaptureDelay * 200 / 9);  // actual delay in uSec: CaptureDelay * 100 / 9
		
		// Disable AV-Sync (for now, because STC is running on asynchronous clock, which breaks the passthrough after some time.)
		err = DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(dcc_info->pMultipleAudioSource, 0, &audioHandle1);
		if (RMFAILED(err)) {
			audioHandle1.moduleID = dcc_info->audio_decoder;
		}
		err = RUASetProperty(dcc_info->pRUA, audioHandle1.moduleID, 
			RMAudioDecoderPropertyID_SyncSTCEnable, 
			&AVSyncEnable, sizeof(AVSyncEnable), 0);
		if (RMFAILED(err)) {
			fprintf(stderr, "Error disabling AV-Sync! %s\n", RMstatusToString(err));
			return err;
		}
	}
	
	return err;
}

static RMstatus close_CCFifo(
	struct dcc_context *dcc_info, 
	struct local_cmdline *local_opt, 
	RMuint32 input)
{
	RMstatus err;
	
	if (local_opt->ccfifo_id_in) {
		RUASetPendingProperty(dcc_info->pRUA, 
			local_opt->ccfifo_id_in, 
			RMCCFifoPropertyID_Close, NULL, 0, 
			"Can not close ccfifo");
	}
	if (local_opt->ccfifo_id_out) {
		RUASetPendingProperty(dcc_info->pRUA, 
			local_opt->ccfifo_id_out, 
			RMCCFifoPropertyID_Close, NULL, 0, 
			"Can not close ccfifo");
	}
	
	if (local_opt->ccfifo_addr_in) {
		DCCFree(dcc_info->pDCC, local_opt->ccfifo_addr_in);
		local_opt->ccfifo_addr_in = 0;
	}
	if (local_opt->ccfifo_addr_out) {
		DCCFree(dcc_info->pDCC, local_opt->ccfifo_addr_out);
		local_opt->ccfifo_addr_out = 0;
	}
	if (local_opt->use_soft_cc_decoder) {
		RMFRTKClose(dcc_info->rtk);
		
		err = DCCCloseVideoSource(dcc_info->pCCOSDSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot close cc-osd source: %s\n", RMstatusToString(err)));
		}
		dcc_info->pCCOSDSource = NULL;
	}
	
	return RM_OK;
}

/* Open CCFifo */
static RMstatus open_CCFifo(
	struct dcc_context *dcc_info, 
	struct local_cmdline *local_opt, 
	RMuint32 input)
{
	RMstatus err;
	RMuint32 entry_count, fifo_size, stc_id;
	struct CCFifo_Open_type cc_open;
	entry_count = 80;
	
	/* set up 1st CCFifo for receiving */
	local_opt->ccfifo_id_in = EMHWLIB_MODULE(CCFifo, input * 2 + 0);
	
	err = RUAExchangeProperty(dcc_info->pRUA, local_opt->ccfifo_id_in, 
		RMCCFifoPropertyID_DRAMSize, 
		&entry_count, sizeof(entry_count), 
		&fifo_size, sizeof(fifo_size));
	if (RMFAILED(err)) {
		fprintf(stderr, "CCfifo error %s\n", RMstatusToString(err));
		return err;
	}
	
	local_opt->ccfifo_addr_in = DCCMalloc(dcc_info->pDCC, 0, RUA_DRAM_UNCACHED, fifo_size);
	DCCSTCGetModuleId(dcc_info->pStcSource, &stc_id);
	cc_open.UncachedAddress = local_opt->ccfifo_addr_in;
	cc_open.EntryCount = entry_count;
	cc_open.UncachedSize = fifo_size;
	cc_open.STCModuleId = stc_id;
	
	err = RUASetProperty(dcc_info->pRUA, local_opt->ccfifo_id_in, 
		RMCCFifoPropertyID_Open, 
		&cc_open, sizeof(cc_open), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "Can not open ccfifo: %s\n", RMstatusToString(err));
		return err;
	}
	
	/* set up 2nd CCFifo for sending (if needed) */
	local_opt->ccfifo_id_out = EMHWLIB_MODULE(CCFifo, input * 2 + 1);
	
	err = RUAExchangeProperty(dcc_info->pRUA, local_opt->ccfifo_id_out, 
		RMCCFifoPropertyID_DRAMSize, 
		&entry_count, sizeof(entry_count), 
		&fifo_size, sizeof(fifo_size));
	if (RMFAILED(err)) {
		fprintf(stderr, "CCfifo error %s\n", RMstatusToString(err));
		return err;
	}
	
	local_opt->ccfifo_addr_out = DCCMalloc(dcc_info->pDCC, 0, RUA_DRAM_UNCACHED, fifo_size);
	DCCSTCGetModuleId(dcc_info->pStcSource, &stc_id);
	cc_open.UncachedAddress = local_opt->ccfifo_addr_out;
	cc_open.EntryCount = entry_count;
	cc_open.UncachedSize = fifo_size;
	cc_open.STCModuleId = stc_id;
	
	err = RUASetProperty(dcc_info->pRUA, local_opt->ccfifo_id_out, 
		RMCCFifoPropertyID_Open, 
		&cc_open, sizeof(cc_open), 0);
	if (RMFAILED(err)) {
		fprintf(stderr, "Can not open output ccfifo: %s\n", RMstatusToString(err));
		return err;
	}
	return RM_OK;
}

static RMstatus apply_CCFifo(
	struct dcc_context *dcc_info, 
	struct local_cmdline *local_opt, 
	RMuint32 input)
{
	RMstatus err;
	RMuint32 mixer_id;
	
	if (local_opt->ccfifo_print || local_opt->use_soft_cc_decoder) {
		/* route CC data through app */
		local_opt->ccfifo_id_send = local_opt->ccfifo_id_out;
	} else {
		/* direct CC passthrough from capture to mixer */
		local_opt->ccfifo_id_send = local_opt->ccfifo_id_in;
	}
	dcc_info->ccfifo_out_id = local_opt->ccfifo_id_send;
	
	switch (dcc_info->route) {
		case DCCRoute_Main:
			mixer_id = EMHWLIB_MODULE(DispMainMixer, 0);
			break;
		case DCCRoute_Secondary:
			mixer_id = EMHWLIB_MODULE(DispVCRMixer, 0);
			break;
		default:
			return RM_ERROR;
	}
	
	if (local_opt->use_soft_cc_decoder) {
		struct DCCOSDProfile osd_profile;
		Rtk86Handle rtk_handle;
		struct EMhwlibDisplayWindow window;
		struct rmscc_init scc_init;
		RMuint32 mixer, scaler, src_index;
		
		if ((dcc_info->disp_info->osd_scaler[0] != DispOSDScaler) && ((input_num == 0) || (dcc_info->disp_info->osd_scaler[1] != DispOSDScaler))) {
			scaler = DispOSDScaler;
		} else if ((dcc_info->disp_info->osd_scaler[0] != DispGFXMultiScaler) && ((input_num == 0) || (dcc_info->disp_info->osd_scaler[1] != DispGFXMultiScaler))) {
			scaler = DispGFXMultiScaler;
		} else {
			scaler = DispVCRMultiScaler;
		}
		
		/* create a buffer to draw the closed caption on */
		osd_profile.ColorSpace = EMhwlibColorSpace_RGB_0_255;
		osd_profile.ColorMode = EMhwlibColorMode_TrueColor;
		osd_profile.SamplingMode = EMhwlibSamplingMode_444;
		osd_profile.ColorFormat = EMhwlibColorFormat_32BPP;
		osd_profile.PixelAspectRatio.X = 1;
		osd_profile.PixelAspectRatio.Y = 1;
		osd_profile.Width = 640;
		osd_profile.Height = 480;
		
		window.X = 2048;
		window.Y = 2048;
		window.Width = 4096;
		window.Height = 4096;
		
		window.XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToCenter;
		window.YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToCenter;
		window.XMode = EMhwlibDisplayWindowValueMode_Relative;
		window.YMode = EMhwlibDisplayWindowValueMode_Relative;
		window.WidthMode = EMhwlibDisplayWindowValueMode_Relative;
		window.HeightMode = EMhwlibDisplayWindowValueMode_Relative;
		
		err = DCCOpenOSDVideoSource(dcc_info->pDCC, &osd_profile, &(dcc_info->pCCOSDSource));
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot open OSD decoder: %s\n", RMstatusToString(err));
			return err;
		}
		
		err = DCCClearOSDVideoSource(dcc_info->pCCOSDSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot clear the surface source: %s\n", RMstatusToString(err)));
			return err;
		}
		
		while ((err = RUASetProperty(dcc_info->pRUA, scaler, RMGenericPropertyID_ScalerInputWindow, &(window), sizeof(window), 0)) == RM_PENDING);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set scaler input window on OSD surface: %s\n", RMstatusToString(err)));
			return err;
		}
		
		err = DCCSetSurfaceSource(dcc_info->pDCC, scaler, dcc_info->pCCOSDSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set the surface source: %s\n", RMstatusToString(err)));
			return err;
		}
		
		err = RUAExchangeProperty(dcc_info->pRUA, mixer_id, RMGenericPropertyID_MixerSourceIndex, &scaler, sizeof(scaler), &src_index, sizeof(src_index));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot get scaler index\n"));
			return err;
		}
		mixer = EMHWLIB_TARGET_MODULE(mixer_id, 0, src_index);
		
		window.Width  = 8 * 4096 / 10;
		window.Height = 8 * 4096 / 10;
		
		// TODO align CC window with active_window
		while ((err = RUASetProperty(dcc_info->pRUA, mixer, RMGenericPropertyID_MixerSourceWindow, &(window), sizeof(window), 0)) == RM_PENDING);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set scaler output window: %s\n", RMstatusToString(err)));
			return err;
		}
		
		err = DCCEnableVideoSource(dcc_info->pCCOSDSource, TRUE);
		if (RMFAILED(err)){
			RMDBGLOG((ENABLE, "Error enabling OSD buffer: %s\n", RMstatusToString(err)));
			return err;
		}
		
		rtk_handle.pOSDSource = dcc_info->pCCOSDSource;
		rtk_handle.pRUA = dcc_info->pRUA;
		
		scc_init.rtk = RMFRTKOpen(&rtk_handle);
		if(scc_init.rtk == NULL){
			RMDBGLOG((ENABLE, "Error opening rtk: %s\n", RMstatusToString(err)));
			return err;
		}
		
		scc_init.resize_callback = NULL;
		if (local_opt->use_soft_cc_decoder == 2) {
			struct CCFifo_AllowedTypes_type allowed_types;
			/* this asks the video decoder to put only the eia708 closed caption
			 * data into the fifo. Its default is to put only eia608 so we don't need
			 * to handle this when use_soft_cc_decoder == 1
			 */
			allowed_types.Allow608 = FALSE;
			allowed_types.Allow708 = TRUE;
			err = RUASetProperty(dcc_info->pRUA, local_opt->ccfifo_id_in, RMCCFifoPropertyID_AllowedTypes, &(allowed_types), sizeof(allowed_types), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot set scaler input window on OSD surface %d\n", err));
				return err;
			}
			/* make this instance of rmscc a eia708 decoder */
			scc_init.format = rmscc_eia_708;
		} else if (local_opt->use_soft_cc_decoder == 1) {
			/* make this instance of rmscc a eia608 decoder */
			scc_init.format = rmscc_eia_608;
		}
		dcc_info->scc = RMSCCOpen(&scc_init);
		dcc_info->rtk = scc_init.rtk;
		if (dcc_info->scc == NULL) {
			local_opt->use_soft_cc_decoder = 0;
		}
	}
	
	if (input == 0) {
		RMuint32 ccfifo_id = 0;
		
		/* clear previous fifo on the mixer */
		RUASetPendingProperty(dcc_info->pRUA, mixer_id, 
			RMGenericPropertyID_CCFifo, 
			&ccfifo_id, sizeof(ccfifo_id), 
			"Cannot clear CC_fifo");
		
		/* set the fifo on the mixer */
		RUASetPendingProperty(dcc_info->pRUA, mixer_id, 
			RMGenericPropertyID_CCFifo, 
			&(local_opt->ccfifo_id_send), sizeof(local_opt->ccfifo_id_send), 
			"Cannot set CC_fifo");
		
		RUASetPendingProperty(dcc_info->pRUA, mixer_id, 
			RMGenericPropertyID_Validate, NULL, 0, 
			"Cannot validate mixer settings");
	}
	
	/* set the fifo on the input */
	RUASetPendingProperty(dcc_info->pRUA, capture_opt->InputModuleID, 
		RMGenericPropertyID_CCFifo, 
		&(local_opt->ccfifo_id_in), sizeof(local_opt->ccfifo_id_in), 
		"Cannot set CC_fifo on input");
	RUASetPendingProperty(dcc_info->pRUA, capture_opt->InputModuleID, 
		RMGenericPropertyID_Validate, NULL, 0, 
		"Cannot validate mixer settings");
	
	if (local_opt->enable_i2c_cc || local_opt->enable_i2c_wss) {
		struct Input_VBIReadbackI2C_type rb;
		rb.I2CDevice = local_opt->i2c_video_dev;
		rb.I2CDelay = local_opt->i2c_video_delay;
		rb.Enable_CC = local_opt->enable_i2c_cc;
		rb.Enable_WSS = local_opt->enable_i2c_wss;
		RUASetPendingProperty(dcc_info->pRUA, capture_opt->InputModuleID, 
			RMGenericPropertyID_VBIReadbackI2C, &rb, sizeof(rb), 
			"Failed to set property VBIReadbackI2C");
		RUASetPendingProperty(dcc_info->pRUA, capture_opt->InputModuleID, 
			RMGenericPropertyID_Validate, NULL, 0, 
			"Failed to validate input");
	}
	
	return RM_OK;
}

// corresponding video modes in 50, 59.94, 60, 75 and 85 Hz	
static enum EMhwlibTVStandard vfreq_matrix[][5] = {
	{EMhwlibTVStandard_CVT_640x480x50,    EMhwlibTVStandard_Custom,            EMhwlibTVStandard_CVT_640x480x60,    EMhwlibTVStandard_CVT_640x480x75,    EMhwlibTVStandard_CVT_640x480x85}, 
	{EMhwlibTVStandard_CVT_800x600x50,    EMhwlibTVStandard_Custom,            EMhwlibTVStandard_CVT_800x600x60,    EMhwlibTVStandard_CVT_800x600x75,    EMhwlibTVStandard_CVT_800x600x85}, 
	{EMhwlibTVStandard_CVT_1024x768x50,   EMhwlibTVStandard_Custom,            EMhwlibTVStandard_CVT_1024x768x60,   EMhwlibTVStandard_CVT_1024x768x75,   EMhwlibTVStandard_CVT_1024x768x85}, 
	{EMhwlibTVStandard_CVT_1152x864x50,   EMhwlibTVStandard_Custom,            EMhwlibTVStandard_CVT_1152x864x60,   EMhwlibTVStandard_CVT_1152x864x75,   EMhwlibTVStandard_CVT_1152x864x85}, 
	{EMhwlibTVStandard_CVT_1280x960x50,   EMhwlibTVStandard_Custom,            EMhwlibTVStandard_CVT_1280x960x60,   EMhwlibTVStandard_CVT_1280x960x75,   EMhwlibTVStandard_CVT_1280x960x85}, 
	{EMhwlibTVStandard_CVT_1280x1024x50,  EMhwlibTVStandard_Custom,            EMhwlibTVStandard_CVT_1280x1024x60,  EMhwlibTVStandard_CVT_1280x1024x75,  EMhwlibTVStandard_CVT_1280x1024x85}, 
	{EMhwlibTVStandard_CVT_1600x1200x50,  EMhwlibTVStandard_Custom,            EMhwlibTVStandard_CVT_1600x1200x60,  EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_Custom,            EMhwlibTVStandard_HDMI_640x480p59,   EMhwlibTVStandard_HDMI_640x480p60,   EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_HDMI_576p50,       EMhwlibTVStandard_HDMI_480p59,       EMhwlibTVStandard_HDMI_480p60,       EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_HDMI_720p50,       EMhwlibTVStandard_HDMI_720p59,       EMhwlibTVStandard_HDMI_720p60,       EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_HDMI_1080i50,      EMhwlibTVStandard_HDMI_1080i59,      EMhwlibTVStandard_HDMI_1080i60,      EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_HDMI_576i50,       EMhwlibTVStandard_HDMI_480i59,       EMhwlibTVStandard_HDMI_480i60,       EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_HDMI_288p50,       EMhwlibTVStandard_HDMI_240p59,       EMhwlibTVStandard_HDMI_240p60,       EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_HDMI_2880x576i50,  EMhwlibTVStandard_HDMI_2880x480i59,  EMhwlibTVStandard_HDMI_2880x480i60,  EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_HDMI_2880x288p50,  EMhwlibTVStandard_HDMI_2880x240p59,  EMhwlibTVStandard_HDMI_2880x240p60,  EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_HDMI_1440x576p50,  EMhwlibTVStandard_HDMI_1440x480p59,  EMhwlibTVStandard_HDMI_1440x480p60,  EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_HDMI_1080p50,      EMhwlibTVStandard_HDMI_1080p59,      EMhwlibTVStandard_HDMI_1080p60,      EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_HDMI_1080p25,      EMhwlibTVStandard_HDMI_1080p29,      EMhwlibTVStandard_HDMI_1080p30,      EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_HDMI_2880x576p50,  EMhwlibTVStandard_HDMI_2880x480p59,  EMhwlibTVStandard_HDMI_2880x480p60,  EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_HDMI_1080i50_1250, EMhwlibTVStandard_HDMI_1080i59,      EMhwlibTVStandard_HDMI_1080i60,      EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_HDMI_1080i100,     EMhwlibTVStandard_HDMI_1080i119,     EMhwlibTVStandard_HDMI_1080i120,     EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_HDMI_720p100,      EMhwlibTVStandard_HDMI_720p119,      EMhwlibTVStandard_HDMI_720p120,      EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_HDMI_576p100,      EMhwlibTVStandard_HDMI_480p119,      EMhwlibTVStandard_HDMI_480p120,      EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_HDMI_576i100,      EMhwlibTVStandard_HDMI_480i119,      EMhwlibTVStandard_HDMI_480i120,      EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_HDMI_576p200,      EMhwlibTVStandard_HDMI_480p239,      EMhwlibTVStandard_HDMI_480p240,      EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_HDMI_576i200,      EMhwlibTVStandard_HDMI_480i239,      EMhwlibTVStandard_HDMI_480i240,      EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_1080p50,           EMhwlibTVStandard_1080p59,           EMhwlibTVStandard_1080p60,           EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_1080i50,           EMhwlibTVStandard_1080i59,           EMhwlibTVStandard_1080i60,           EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_1080p25,           EMhwlibTVStandard_1080p29,           EMhwlibTVStandard_1080p30,           EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_1080i50_1250,      EMhwlibTVStandard_1080i59,           EMhwlibTVStandard_1080i60,           EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_1080p50_1250,      EMhwlibTVStandard_1080p59,           EMhwlibTVStandard_1080p60,           EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_720p50,            EMhwlibTVStandard_720p59,            EMhwlibTVStandard_720p60,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_720p25,            EMhwlibTVStandard_720p29,            EMhwlibTVStandard_720p30,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_ITU_Bt656_625,     EMhwlibTVStandard_ITU_Bt656_525,     EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_PAL_BG,            EMhwlibTVStandard_NTSC_M,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_PAL_BG,            EMhwlibTVStandard_NTSC_M_Japan,      EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_PAL_BG,            EMhwlibTVStandard_PAL_M,             EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_PAL_BG,            EMhwlibTVStandard_PAL_60,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_576p50,            EMhwlibTVStandard_480p59,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_PAL_BG_702,        EMhwlibTVStandard_NTSC_M_714,        EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_PAL_BG_702,        EMhwlibTVStandard_NTSC_M_Japan_714,  EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_PAL_BG_702,        EMhwlibTVStandard_PAL_M_714,         EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_PAL_BG_702,        EMhwlibTVStandard_PAL_60_714,        EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_576p50_702,        EMhwlibTVStandard_480p59_714,        EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_VESA_640x350x85}, 
	{EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_VESA_640x400x85}, 
	{EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_VESA_720x400x85}, 
	{EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_VESA_640x480x60,   EMhwlibTVStandard_VESA_640x480x75,   EMhwlibTVStandard_VESA_640x480x85}, 
	{EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_VESA_800x600x60,   EMhwlibTVStandard_VESA_800x600x75,   EMhwlibTVStandard_VESA_800x600x85}, 
	{EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_VESA_1024x768x60,  EMhwlibTVStandard_VESA_1024x768x75,  EMhwlibTVStandard_VESA_1024x768x85}, 
	{EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_VESA_1280x768x60,  EMhwlibTVStandard_VESA_1280x768x75,  EMhwlibTVStandard_VESA_1280x768x85}, 
	{EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_VESA_1280x768x60RB,  EMhwlibTVStandard_VESA_1280x768x75,  EMhwlibTVStandard_VESA_1280x768x85}, 
	{EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_VESA_1280x960x60,  EMhwlibTVStandard_Custom,            EMhwlibTVStandard_VESA_1280x960x85}, 
	{EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_VESA_1280x1024x60, EMhwlibTVStandard_VESA_1280x1024x75, EMhwlibTVStandard_VESA_1280x1024x85}, 
	{EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_VESA_1360x768x60,  EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_VESA_1400x1050x60, EMhwlibTVStandard_VESA_1400x1050x75, EMhwlibTVStandard_VESA_1400x1050x85}, 
	{EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_VESA_1400x1050x60RB, EMhwlibTVStandard_VESA_1400x1050x75, EMhwlibTVStandard_VESA_1400x1050x85}, 
	{EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_VESA_1600x1200x60, EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_VESA_1920x1200x60RB, EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}, 
	{EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom,            EMhwlibTVStandard_VESA_1920x1200x60, EMhwlibTVStandard_Custom,            EMhwlibTVStandard_Custom}
};

// Set up the 86xx input port and VBI capture, initialize the capture chip
static RMstatus setup_input(
	struct dcc_context *dcc_info, 
	struct DCCVideoSource **ppVideoSource, 
	struct capture_cmdline *capture_opt, 
	struct display_cmdline *disp_opt, 
	struct local_cmdline *local_opt, 
	RMuint32 input)
{
	RMstatus err;
	
	setup_format_options(dcc_info, capture_opt, disp_opt, local_opt, input);
	
fprintf(stderr, "setup_capture() VBI: %s, %luX%lu@%lu,%lu dma:%s\n", 
	capture_opt[input].vbianc_enable ? "On" : "Off", 
	capture_opt[input].vbianc_w, 
	capture_opt[input].vbianc_h, 
	capture_opt[input].vbianc_ytop, 
	capture_opt[input].vbianc_ybot, 
	capture_opt[input].vbi_dma ? "On" : "Off" 
);
	err = setup_capture(dcc_info, 
		ppVideoSource, 
		capture_opt, 
		&local_opt->pVBIData, 
		&local_opt->pR, 
		&local_opt->pDmaReceive, 
		3 * TimerNumber + 1, 
		local_opt->use_gpio_fid, 
		local_opt->invert_fid);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to set up capture port! %s\n", RMstatusToString(err));
		if (err == RM_FATALOUTOFMEMORY) {
			fprintf(stderr, "Can not set up capture picture buffer, OUT OF MEMORY!\n");
			exit(1);
		}
		return err;
	}
	
	open_CCFifo(dcc_info, local_opt, input);
	apply_CCFifo(dcc_info, local_opt, input);
	
	if (local_opt->i2c_init) {
		init_capture(dcc_info->pRUA, capture_opt, local_opt, local_opt->i2c_video_chip, local_opt->i2c_video_dev, local_opt->i2c_video_delay);
		init_capture(dcc_info->pRUA, capture_opt, local_opt, local_opt->i2c_audio1_chip, local_opt->i2c_audio1_dev, local_opt->i2c_audio1_delay);
		init_capture(dcc_info->pRUA, capture_opt, local_opt, local_opt->i2c_audio2_chip, local_opt->i2c_audio2_dev, local_opt->i2c_audio2_delay);
	}

	
	if (local_opt->follow_vfreq) {
		RMuint32 in_vfreq = 0, in_row = 0, out_vfreq = 0, out_row = 0, i;
		// find input v-freq
		for (i = 0; i < sizeof(vfreq_matrix) / sizeof(enum EMhwlibTVStandard); i++) {
			if (capture_opt->TVStandard == vfreq_matrix[i / 5][i % 5]) {
				in_vfreq = (i % 5) + 1;
				in_row = i / 5;
				break;
			}
		}
		// find current output v-freq
		for (i = 0; i < sizeof(vfreq_matrix) / sizeof(enum EMhwlibTVStandard); i++) {
			if (disp_opt->standard == vfreq_matrix[i / 5][i % 5]) {
				out_vfreq = (i % 5) + 1;
				out_row = i / 5;
				break;
			}
		}
		// 50Hz capture on non-50Hz output
		if ((in_vfreq == 1) && out_vfreq && (out_vfreq != 1)) {
			fprintf(stderr, "Input is 50Hz\n");
			if (vfreq_matrix[out_row][0] != EMhwlibTVStandard_Custom) {
				fprintf(stderr, "Changing output to 50Hz\n");
				disp_opt->standard = vfreq_matrix[out_row][0];
			}
		} else 
		// 59.94Hz capture on non-59.94Hz output
		if ((in_vfreq == 2) && out_vfreq && (out_vfreq != 2)) {
			fprintf(stderr, "Input is 59.94Hz\n");
			if (vfreq_matrix[out_row][1] != EMhwlibTVStandard_Custom) {
				fprintf(stderr, "Changing output to 59.94Hz\n");
				disp_opt->standard = vfreq_matrix[out_row][1];
			} else 
			// 60Hz as second choice
			if (vfreq_matrix[out_row][2] != EMhwlibTVStandard_Custom) {
				fprintf(stderr, "Changing output to 60Hz\n");
				disp_opt->standard = vfreq_matrix[out_row][2];
			}
		} else 
		// 60Hz capture on non-60Hz output
		if ((in_vfreq == 3) && out_vfreq && (out_vfreq != 3)) {
			fprintf(stderr, "Input is 60Hz\n");
			if (vfreq_matrix[out_row][2] != EMhwlibTVStandard_Custom) {
				fprintf(stderr, "Changing output to 60Hz\n");
				disp_opt->standard = vfreq_matrix[out_row][2];
			} else 
			// 59.94Hz as second choice
			if (vfreq_matrix[out_row][1] != EMhwlibTVStandard_Custom) {
				fprintf(stderr, "Changing output to 59.94Hz\n");
				disp_opt->standard = vfreq_matrix[out_row][1];
			}
		}
		else {
			fprintf(stderr, "Input vfreq is unknown\n");
		}
	}
	
	apply_display_options(dcc_info, disp_opt);
	
	set_scaler_source_zoom(dcc_info->pRUA, dcc_info->disp_info->osd_scaler[input], local_opt->zoom_x, local_opt->zoom_y, local_opt->zoom_w, local_opt->zoom_h);
	
	return RM_OK;
}

static RMstatus close_input(
	struct dcc_context *dcc_info, 
	struct DCCVideoSource **ppVideoSource, 
	struct capture_cmdline *capture_opt, 
	struct display_cmdline *disp_opt, 
	struct local_cmdline *local_opt, 
	RMuint32 input)
{
	RMstatus err;
	
	if (local_opt->enable_i2c_cc || local_opt->enable_i2c_wss) {
		struct Input_VBIReadbackI2C_type rb;
		rb.I2CDevice = local_opt->i2c_video_dev;
		rb.I2CDelay = local_opt->i2c_video_delay;
		rb.Enable_CC = FALSE;
		rb.Enable_WSS = FALSE;
		RUASetPendingProperty(dcc_info->pRUA, capture_opt->InputModuleID, 
			RMGenericPropertyID_VBIReadbackI2C, &rb, sizeof(rb), 
			"Failed to set property VBIReadbackI2C");
		RUASetPendingProperty(dcc_info->pRUA, capture_opt->InputModuleID, 
			RMGenericPropertyID_Validate, NULL, 0, 
			"Failed to validate input");
	}
	
	close_CCFifo(dcc_info, local_opt, input);
	
	return close_capture(dcc_info, 
		ppVideoSource, 
		capture_opt, 
		&(local_opt->pVBIData), 
		&(local_opt->pR), 
		&(local_opt->pDmaReceive));
}

//To known NTSC OR PAL ? (detect HDTV modes)
//#if AUTODETECT_BY_EM
#if 0
static RMstatus get_format_TW9919(
								  struct dcc_context *dcc_info, 
								  struct capture_cmdline *capture_opt, 
								  struct local_cmdline *local_opt, 
								  RMuint8 dev, 
								  RMuint8 delay, 
								  RMbool *update)
{
	RMstatus err=RM_OK;	
	enum EMhwlibTVStandard old_std;
	enum EMhwlibTVStandard cur_std=0;
	struct Input_Detect_type detectInput;
	RMuint8 i=0;
	RMuint64 linesPerField = 0;
	RMuint32 samples = 0;	
	RMuint32 numHsyncPerVsync;

	enum EMhwlibTVStandard cvbs_svideoTVStandartSupportedList[]= 
	{
		EMhwlibTVStandard_ITU_Bt656_525,
		EMhwlibTVStandard_ITU_Bt656_625,		
	};

	if (update) *update = FALSE;
	
	old_std = capture_opt->TVStandard;
	cur_std = (RMuint8) old_std;
	
	for (i = 0; i < 50; i++) {  // half second		
		err = RUAGetProperty(dcc_info->pRUA, capture_opt->InputModuleID,
			RMGenericPropertyID_Detect, 
			&detectInput, sizeof(detectInput));
		if (RMFAILED(err)) 
		{
			printf("Error getting property Detect: %s\n", RMstatusToString(err));		
			//usleep(10000);		
			usleep(1000);
		}
		if (i >= 3) {  // skip first three measurements
			linesPerField += detectInput.LinesPerField;
			samples++;
		}
		//usleep(10000);
		usleep(1000);
		
	}
	//get Avg of detectInput.LinesPerField
	numHsyncPerVsync=linesPerField/samples;	
	
	switch (local_opt->i2c_port) {			
	case cap_CVBS1:					
	case cap_CVBS2:
	case cap_SVideo1:
	case cap_SVideo2:			
		//Detect signal by EM
		err=tw9919eid_getCaptureStandard(dcc_info->pRUA,numHsyncPerVsync,cvbs_svideoTVStandartSupportedList,sizeof(cvbs_svideoTVStandartSupportedList)/sizeof(enum EMhwlibTVStandard),&cur_std);
		
		break;
	default: 
		printf("No support this capture Port ! \n");
		break;
	}
	if (cur_std != old_std) {
		capture_opt->TVStandard=cur_std;
		if (cur_std!=EMhwlibTVStandard_Custom) {

			switch(cur_std) {
			case EMhwlibTVStandard_ITU_Bt656_525://NTSC
				err=tw9919eid_setRegColorSystem(dcc_info->pRUA,local_opt->i2c_video_dev,local_opt->i2c_video_delay,1);
				tw9919eid_setRegOutputInterface(dcc_info->pRUA,local_opt->i2c_video_dev,local_opt->i2c_video_delay,1);
				
				if (1) {					
					Write_Gpio_Uart(UART1_DSR,1);//Mute Audio
					
					if (audio_opt.SampleRate) {
						tw9919eid_setAudioClock(dcc_info->pRUA,local_opt->i2c_video_dev,local_opt->i2c_video_delay,1,audio_opt.SampleRate);
					}else
						tw9919eid_setAudioClock(dcc_info->pRUA,local_opt->i2c_video_dev,local_opt->i2c_video_delay,1,48000);
					
					sleep(1);
					Write_Gpio_Uart(UART1_DSR,0);//UnMute Audio
					tw9919eid_checkStandardDetected(dcc_info->pRUA,local_opt->i2c_video_dev,local_opt->i2c_video_delay);
				}
				if (0) {
					tw9919eid_setManualColorSystem(dcc_info->pRUA,dev,delay,1);
				}
				break;
			case EMhwlibTVStandard_ITU_Bt656_625://PAL
				err=tw9919eid_setRegColorSystem(dcc_info->pRUA,local_opt->i2c_video_dev,local_opt->i2c_video_delay,0);
				if (err!=RM_OK) {
					printf("get_format_TW9919() Error <2>\n");
				}							
				tw9919eid_setRegOutputInterface(dcc_info->pRUA,local_opt->i2c_video_dev,local_opt->i2c_video_delay,0);
				if (1) {						
					Write_Gpio_Uart(UART1_DSR,1);//Mute Audio					
					if (audio_opt.SampleRate) {
						tw9919eid_setAudioClock(dcc_info->pRUA,local_opt->i2c_video_dev,local_opt->i2c_video_delay,0,audio_opt.SampleRate);						
					}else
						tw9919eid_setAudioClock(dcc_info->pRUA,local_opt->i2c_video_dev,local_opt->i2c_video_delay,0,48000);
					
					sleep(1);
					Write_Gpio_Uart(UART1_DSR,0);//Unmute Audio
					tw9919eid_checkStandardDetected(dcc_info->pRUA,local_opt->i2c_video_dev,local_opt->i2c_video_delay);						
				}
				
				if (0) {
					tw9919eid_setManualColorSystem(dcc_info->pRUA,dev,delay,0);
				}
				break;
			default:
				break;
			}
		}
		if (update) *update=TRUE;
		
		
	}
	return err;
}
#else
static RMstatus get_format_TW9919(
								  struct dcc_context *dcc_info, 
								  struct capture_cmdline *capture_opt, 
								  struct local_cmdline *local_opt, 
								  RMuint8 dev, 
								  RMuint8 delay, 
								  RMbool *update)
{
	RMstatus err=RM_OK;	
	RMbool u = FALSE;
	RMuint8 isNTSC=0;
	static RMuint8 isVideoIn_local;
	u = FALSE;
	tw9919eid_setStandardAutoDetect(dcc_info->pRUA,dev,delay);
	// TODO detect HDTV modes

	//if (reg01 & 0x80) {  //make sure signal is standard
	//if ((reg01 & 0x80)||(!(reg31 & 0x10))){
	if((tw9919eid_isVideoIn(dcc_info->pRUA,dev,delay)!=1)||(tw9919eid_isStandardSignal(dcc_info->pRUA,dev,delay)!=1)
	  ){
		if (isVideoIn_local) {
			fprintf(stderr, "No sync or video detected!\n");
			isVideoIn_local=0;
			capture_opt->TVStandard = EMhwlibTVStandard_Custom;
			Write_Gpio_Uart1(UART_DSR,1);//Mute Audio
		}
	} else 
	{
		
		isNTSC=tw9919eid_isNTSC(dcc_info->pRUA,dev,delay);
			if (isNTSC) {  // NTSC 525/59.94	

//				printf("get_format_TW9919 <1>\n");
				
				if (capture_opt->TVStandard != EMhwlibTVStandard_ITU_Bt656_525) {															
					//if ((reg1e & 3) == 0) return RM_OK;  // wait until color
					u = TRUE;
				}
				// TODO read WSS, set local_opt->wide_screen, local_opt->active_format and u
				if (! local_opt->force_wide_screen) {
					// TODO set local_opt->wide_screen from WSS
				}
				if (! local_opt->force_active_format) {
					// TODO set local_opt->active_format from WSS
				}
				if (u) {

					

					capture_opt->TVStandard = EMhwlibTVStandard_ITU_Bt656_525;
					err=tw9919eid_setRegColorSystem(dcc_info->pRUA,local_opt->i2c_video_dev,local_opt->i2c_video_delay,isNTSC);
					tw9919eid_setRegOutputInterface(dcc_info->pRUA,local_opt->i2c_video_dev,local_opt->i2c_video_delay,isNTSC);

					if (1) {											
								
						Write_Gpio_Uart1(UART_DSR,1);//Mute Audio
						if (audio_opt.SampleRate) {
							tw9919eid_setAudioClock(dcc_info->pRUA,local_opt->i2c_video_dev,local_opt->i2c_video_delay,isNTSC,audio_opt.SampleRate);
						}else
							tw9919eid_setAudioClock(dcc_info->pRUA,local_opt->i2c_video_dev,local_opt->i2c_video_delay,isNTSC,48000);

						sleep(1);
						Write_Gpio_Uart1(UART_DSR,0);//Un mute Audio
						tw9919eid_checkStandardDetected(dcc_info->pRUA,local_opt->i2c_video_dev,local_opt->i2c_video_delay);
					}
					if (1) {
						tw9919eid_setManualColorSystem(dcc_info->pRUA,dev,delay,1);
					}

					if (1) {
						///enable Close caption
						if (local_opt->ccfifo_print || local_opt->use_soft_cc_decoder)
							err=tw9919eid_EnableCC(dcc_info->pRUA,dev,delay);
						
						
					}
					if(1) {
						//if (!isVideoIn_local) { //For debug . Print all register set.
						if(tw9919eid_checkRegisterSet(dcc_info->pRUA,dev,delay)!=RM_OK)
						{
							printf("Can't checkRegisterSet !\n");
						}						
					}
					
				}
			} else {  // PAL 625/50
				if (capture_opt->TVStandard != EMhwlibTVStandard_ITU_Bt656_625) {
					//printf("get_format_TW9919 <2-2>\n");										
					//if ((reg1e & 3) == 0) return RM_OK;  // wait until color
					u = TRUE;
				}
				// TODO read WSS, set local_opt->wide_screen, local_opt->active_format and u
				if (! local_opt->force_wide_screen) {
					// TODO set local_opt->wide_screen from WSS
				}
				if (! local_opt->force_active_format) {
					// TODO set local_opt->active_format from WSS
				}
				if (u) {

					//printf("get_format_TW9919 <2-3>\n");
					capture_opt->TVStandard = EMhwlibTVStandard_ITU_Bt656_625;
					//printf("Init i2c PAL \n");
					err=tw9919eid_setRegColorSystem(dcc_info->pRUA,local_opt->i2c_video_dev,local_opt->i2c_video_delay,isNTSC);
					if (err!=RM_OK) {
						printf("get_format_TW9919() Error <2>\n");
					}							
					tw9919eid_setRegOutputInterface(dcc_info->pRUA,local_opt->i2c_video_dev,local_opt->i2c_video_delay,isNTSC);
					if (1) {						
						Write_Gpio_Uart1(UART_DSR,1);//Un mute Audio
						if (audio_opt.SampleRate) {
							tw9919eid_setAudioClock(dcc_info->pRUA,local_opt->i2c_video_dev,local_opt->i2c_video_delay,isNTSC,audio_opt.SampleRate);
						}	
						
						sleep(1);
						Write_Gpio_Uart1(UART_DSR,0);//Un mute Audio
						tw9919eid_checkStandardDetected(dcc_info->pRUA,local_opt->i2c_video_dev,local_opt->i2c_video_delay);						
					}

					if (1) {
						tw9919eid_setManualColorSystem(dcc_info->pRUA,dev,delay,0);
						//enable teletext
						if ((capture_opt->vbianc_enable) && (local_opt->use_soft_cc_decoder==0))
							err=tw9919eid_EnableTT(dcc_info->pRUA,dev,delay);
						printf("Set up Teletext \n");
						
					}

					if(0) {
					//if (!isVideoIn_local) { //For debug . Print all register set.
						if(tw9919eid_checkRegisterSet(dcc_info->pRUA,dev,delay)!=RM_OK)
						{
							printf("Can't checkRegisterSet !\n");
						}						
					}

				}
			}		

			if (!isVideoIn_local) {
				isVideoIn_local=1;
				fprintf(stderr, "sync or video detected OK!\n");
			}
			
	}
	if (update) *update = u;
	return err;
}
#endif

#if AUTODETECT_BY_EM

static RMstatus get_format_AD9380(
								  struct dcc_context *dcc_info, 
								  struct capture_cmdline *capture_opt, 
								  struct local_cmdline *local_opt, 
								  RMuint8 dev, 
								  RMuint8 delay, 
								  RMbool *update)
{
	RMstatus err=RM_OK;	
	enum EMhwlibTVStandard old_std;
	enum EMhwlibTVStandard cur_std=0;
	struct Input_Detect_type detectInput;
	RMuint8 i=0;
	RMuint64 linesPerField = 0;
	RMuint32 samples = 0;	
	RMuint32 numHsyncPerVsync;
	if (update) *update = FALSE;
	
	old_std = capture_opt->TVStandard;
	cur_std = (RMuint8) old_std;
	
	for (i = 0; i < 50; i++) {  // half second		
		err = RUAGetProperty(dcc_info->pRUA, capture_opt->InputModuleID,
			RMGenericPropertyID_Detect, 
			&detectInput, sizeof(detectInput));
		if (RMFAILED(err)) 
		{
			printf("Error getting property Detect: %s\n", RMstatusToString(err));		
			//usleep(10000);		
			usleep(1000);
		}
		if (i >= 3) {  // skip first three measurements
			linesPerField += detectInput.LinesPerField;
			samples++;
		}
		//usleep(10000);
		usleep(1000);
		
	}
	//get Avg of detectInput.LinesPerField
	numHsyncPerVsync=linesPerField/samples;	
	
	switch (local_opt->i2c_port) {			
		case cap_Component1:					
		case cap_Component2:
			//err=ad9380_getCaptureStandardYUV(dcc_info->pRUA,dev,delay,numHsyncPerVsync,&cur_std);
			err=ad9380_autoUpdateCaptureStandardYUV(dcc_info->pRUA,dev,delay,numHsyncPerVsync,&cur_std);
						
			break;
		case cap_VGA:
			//err=ad9380_autoUpdateCaptureStandardVGA(dcc_info->pRUA,dev,delay,&cur_std);
			err=ad9380_autoUpdateCaptureStandardVGA(dcc_info->pRUA,dev,delay,numHsyncPerVsync,&cur_std);
			
			break;
		case cap_HDMI0:
		case cap_HDMI1:	
			{
				
				
			err=ad9380_autoUpdateCaptureStandardHDMI(dcc_info->pRUA,dev,delay,numHsyncPerVsync,&cur_std);
			
			
			}
				break;
		default: 
			printf("No support this capture Port ! \n");
			break;
	}

	if (cur_std != old_std) {
		capture_opt->TVStandard=cur_std;
		*update=TRUE;
	}	
	return err;
}
#else
static RMstatus get_format_AD9380(
								  struct dcc_context *dcc_info, 
								  struct capture_cmdline *capture_opt, 
								  struct local_cmdline *local_opt, 
								  RMuint8 dev, 
								  RMuint8 delay, 
								  RMbool *update)
{
	RMstatus err=RM_OK;	
	enum EMhwlibTVStandard old_std;
	enum EMhwlibTVStandard cur_std;
	if (update) *update = FALSE;

	old_std = capture_opt->TVStandard;
	cur_std = (RMuint8) old_std;
	switch (local_opt->i2c_port) {			
		case cap_Component1:					
		case cap_Component2:
			err=ad9380_autoUpdateCaptureStandardYUV(dcc_info->pRUA,dev,delay,&cur_std);
			break;
		case cap_VGA:
			err=ad9380_autoUpdateCaptureStandardVGA(dcc_info->pRUA,dev,delay,&cur_std);
			
			break;
		case cap_HDMI0:
		case cap_HDMI1:
				err=ad9380_autoUpdateCaptureStandardHDMI(dcc_info->pRUA,dev,delay,&cur_std);
				break;
		default: 
			printf("No support this capture Port ! \n");
			break;
	}

	if (cur_std != old_std) {
		capture_opt->TVStandard=cur_std;
		*update=TRUE;
	}	
	return err;
}

#endif

// Auto-detect the video mode on the current input and set up the options struct members accordingly
static RMstatus auto_detect_input(
	struct dcc_context *dcc_info, 
	struct capture_cmdline *capture_opt, 
	struct local_cmdline *local_opt, 
	RMbool *i2c_detect, 
	RMbool *update)
{
	RMstatus err=RM_OK;
	enum EMhwlibTVStandard old_std;
	
	if (update) *update = FALSE;
	if (i2c_detect) *i2c_detect = FALSE;
	old_std = capture_opt->TVStandard;
	
	// attempt to determine input video mode from capture chip
	if (local_opt->i2c_init) {
				switch(local_opt->i2c_board) {
		case cap_sigma895e1:
			{
				switch(local_opt->i2c_video_chip) {
				case cap_TW9919:
					if (RMSUCCEEDED((err = get_format_TW9919(dcc_info, capture_opt, local_opt, local_opt->i2c_video_dev, local_opt->i2c_video_delay, update)))) {
						if (i2c_detect) *i2c_detect = TRUE;
						return RM_OK;
					} else {
						if (err == RM_TIMEOUT) return err;  // temporary I2C problem						
						fprintf(stderr, "get_format_TW9919() failed! %s\n", RMstatusToString(err));
						return RM_ERROR;
					}
					break;
				case cap_AD9380:
					if (RMSUCCEEDED((err = get_format_AD9380(dcc_info, capture_opt, local_opt, local_opt->i2c_video_dev, local_opt->i2c_video_delay, update)))) {
						if (i2c_detect) *i2c_detect = TRUE;
						return RM_OK;
					} else {
						if (err == RM_TIMEOUT) return err;  // temporary I2C problem						
						fprintf(stderr, "get_format_AD9380() failed! %s\n", RMstatusToString(err));
						return RM_ERROR;
					}
					break;
				default:
					break;
				}
			}
			break;
		default:
			break;
		}

if ((local_opt->i2c_port == cap_HDMI0) || (local_opt->i2c_port == cap_HDMI1)) {
			if (RMSUCCEEDED((err = get_format_SiI9031(dcc_info, capture_opt, local_opt, 0x30, local_opt->i2c_video_delay, update)))) {
				if (i2c_detect) *i2c_detect = TRUE;
				return RM_OK;
			} else {
				if (err == RM_TIMEOUT) return err;  // temporary I2C problem
				fprintf(stderr, "get_format_SiI9031() failed! %s\n", RMstatusToString(err));
			}
		}
			if (((local_opt->i2c_board != cap_sigma844e1dtv) || (capture_opt->InputModuleID != DispGraphicInput)) && (local_opt->i2c_video_chip == cap_SAA7119)) {
			//if (i2c_detect) *i2c_detect = TRUE;
			if (RMSUCCEEDED((err = get_format_SAA7119(dcc_info, capture_opt, local_opt, local_opt->i2c_video_dev, local_opt->i2c_video_delay, update)))) {
				if (i2c_detect) *i2c_detect = TRUE;
				return RM_OK;
			} else {
				if (err == RM_TIMEOUT) return err;  // temporary I2C problem
				fprintf(stderr, "get_format_SAA7119() failed! %s\n", RMstatusToString(err));
			}
		}
	}
	
	// determine input video mode from EM86xx registers
//	err = (i2c_detect) ? guess_capture_format(dcc_info, capture_opt) : RM_ERROR;
//	if (update && (capture_opt->TVStandard != old_std)) *update = TRUE;
	
	return err;
}

static RMstatus flush_scaler(
	struct dcc_context *dcc_info, 
	RMuint32 input)
{
	RMstatus err;
	fprintf(stderr, "flushing scaler\n");
	err = RUASetProperty(dcc_info->pRUA, dcc_info->disp_info->osd_scaler[input], RMGenericPropertyID_Stop, NULL, 0, 0);
	if RMFAILED(err) fprintf(stderr, "Error flushing scaler, err=%s\n", RMstatusToString(err));
	return err;
}

static RMstatus handle_hdmi_audio_cp_info_frame(
	struct dcc_context *dcc_info, 
	struct local_cmdline *local_opt, 
	struct capture_cmdline *capture_opt, 
	struct display_cmdline *disp_opt, 
	struct DCCVideoSource **ppVideoSource, 
	RMuint32 input, 
	RMuint8 *header, 
	RMuint8 *data)
{
	RMuint32 Type;
	
	fprintf(stderr, "new Audio CP InfoFrame\n");
	
	Type = header[1];
	switch (Type) {
		case 0: fprintf(stderr, "  Generic Audio\n"); break;
		case 1: fprintf(stderr, "  IEC 60958 Audio\n"); break;
		case 2: {
			RMuint32 Generation, Transaction, Quality, CopyNumber, CopyPermission;
			Generation = data[0];
			Transaction = RMunshiftBits(data[1], 1, 0);
			Quality = RMunshiftBits(data[1], 2, 1);
			CopyNumber = RMunshiftBits(data[1], 3, 3);
			CopyPermission = RMunshiftBits(data[1], 2, 6);
			fprintf(stderr, "  DVD Audio, Generation=%lu, Transaction=%lu, Quality=%lu, CopyNumber=%lu, CopyPermission=%lu\n", 
				Generation, Transaction, Quality, CopyNumber, CopyPermission);
		}
		break;
		case 3: {
			RMuint32 i;
			fprintf(stderr, "  Super Audio CD, CCI_1 =");
			for (i = 0; i < 16; i++) {
				if (i % 4 == 0) fprintf(stderr, " ");
				fprintf(stderr, "%02X", data[i]);
			}
			fprintf(stderr, "\n");
		}
		break;
		default: fprintf(stderr, "  Unknown AudioCP: %lu\n", Type);
	}
	
	return RM_OK;
}

static RMstatus handle_hdmi_isrc1_info_frame(
	struct dcc_context *dcc_info, 
	struct local_cmdline *local_opt, 
	struct capture_cmdline *capture_opt, 
	struct display_cmdline *disp_opt, 
	struct DCCVideoSource **ppVideoSource, 
	RMuint32 input, 
	RMuint8 *header, 
	RMuint8 *data)
{
	RMuint32 i, Status;
	RMbool Continued, Valid;
	
	if ((header[1] == local_opt->last_isrc_header) && ! RMMemcmp(&(local_opt->last_isrc[0]), data, 16)) {
		return RM_PENDING;
	}
	fprintf(stderr, "new ISRC1 InfoFrame\n");
	
	local_opt->last_isrc_header = header[1];
	local_opt->last_isrc2 = FALSE;
	RMMemcpy(&(local_opt->last_isrc[0]), data, 16);
	
	Status = RMunshiftBits(header[1], 3, 0);
	Valid = RMunshiftBool(header[1], 6);
	Continued = RMunshiftBool(header[1], 7);
	
	fprintf(stderr, "  ISRC Valid: %s, Cont. in ISRC2: %s, %s position\n", 
		Valid ? "yes" : "no", 
		Continued ? "yes" : "no", 
		(Status == 1) ? "starting" : 
		(Status == 2) ? "intermediate" : 
		(Status == 4) ? "ending" : 
		"unknown");
	if (! Continued) {
		fprintf(stderr, "  ISRC 0..15 =");
		for (i = 0; i < 16; i++) {
			if (i % 4 == 0) fprintf(stderr, " ");
			fprintf(stderr, "%02X", data[i]);
		}
		fprintf(stderr, "\n");
	}
	
	return RM_OK;
}

static RMstatus handle_hdmi_isrc2_info_frame(
	struct dcc_context *dcc_info, 
	struct local_cmdline *local_opt, 
	struct capture_cmdline *capture_opt, 
	struct display_cmdline *disp_opt, 
	struct DCCVideoSource **ppVideoSource, 
	RMuint32 input, 
	RMuint8 *header, 
	RMuint8 *data)
{
	RMuint32 i;
	
	fprintf(stderr, "new ISRC2 InfoFrame\n");
	
	local_opt->last_isrc2 = TRUE;
	RMMemcpy(&(local_opt->last_isrc[16]), data, 16);
	
	if (local_opt->last_isrc_header & 0x80) {
		fprintf(stderr, "  ISRC 0..31 =");
		for (i = 0; i < 32; i++) {
			if (i % 4 == 0) fprintf(stderr, " ");
			fprintf(stderr, "%02X", local_opt->last_isrc[i]);
		}
		fprintf(stderr, "\n");
	}
	
	return RM_OK;
}

static RMstatus handle_hdmi_gamut_info_frame(
	struct dcc_context *dcc_info, 
	struct local_cmdline *local_opt, 
	struct capture_cmdline *capture_opt, 
	struct display_cmdline *disp_opt, 
	struct DCCVideoSource **ppVideoSource, 
	RMuint32 input, 
	RMuint8 *header, 
	RMuint8 *data)
{
	RMuint32 GBDProfile, AffSeqNum, PacketSeq, CurrSeqNum;
	RMbool NextField, NoCurrGBD;
	RMuint32 i, start, len;
	
	fprintf(stderr, "new Gamut InfoFrame\n");
	
	NextField = RMunshiftBool(header[1], 7);
	GBDProfile = RMunshiftBits(header[1], 3, 4);
	AffSeqNum = RMunshiftBits(header[1], 4, 0);
	NoCurrGBD = RMunshiftBool(header[2], 7);
	PacketSeq = RMunshiftBits(header[2], 2, 4);
	CurrSeqNum = RMunshiftBits(header[2], 4, 0);
	
	fprintf(stderr, "  Gamut Boundary Description Profile: P%lu\n", GBDProfile);
	fprintf(stderr, "  Next Field: %s, No Current GBD: %s, Affected Seq.#%lu, Current Seq.#%lu, %s Packet\n", 
		NextField ? "yes" : "no", 
		NoCurrGBD ? "yes" : "no", 
		AffSeqNum, CurrSeqNum, 
		(PacketSeq == 0) ? "Intermediate" : 
		(PacketSeq == 1) ? "First" : 
		(PacketSeq == 2) ? "Last" : 
		(PacketSeq == 3) ? "Only" : 
		"Invalid");
	start = 0;
	len = 28;
	if ((GBDProfile > 0) && (PacketSeq & 1)) {
		RMuint32 Length;
		Length = data[0];
		Length = (Length << 8) | data[1];
		fprintf(stderr, "  GBD Length: %lu, checksum: 0x%02X\n", 
			Length, data[2]);
		start = 3;
		len -= start;
	}
	fprintf(stderr, "  GBD =");
	for (i = start; i < len; i++) {
		if ((i - start) % 4 == 0) fprintf(stderr, " ");
		fprintf(stderr, "%02X", data[i]);
	}
	fprintf(stderr, "\n");
	
	return RM_OK;
}

static RMstatus handle_hdmi_vendor_info_frame(
	struct dcc_context *dcc_info, 
	struct local_cmdline *local_opt, 
	struct capture_cmdline *capture_opt, 
	struct display_cmdline *disp_opt, 
	struct DCCVideoSource **ppVideoSource, 
	RMuint32 input, 
	RMuint8 *header, 
	RMuint8 *data)
{
	RMuint32 Version, Length, VendorID;
	
	fprintf(stderr, "new Vendor InfoFrame\n");
	
	Version = header[1];
	Length = header[2];
	VendorID = 0;
	RMinsShiftBits(&VendorID, data[1], 8,  0);
	RMinsShiftBits(&VendorID, data[2], 8,  8);
	RMinsShiftBits(&VendorID, data[3], 8, 16);
	
	fprintf(stderr, "  IEEE Vendor ID: 0x%06lX, Version: %lu, Length: %lu\n", VendorID, Version, Length);
	
	return RM_OK;
}

static RMstatus handle_hdmi_avi_info_frame(
	struct dcc_context *dcc_info, 
	struct local_cmdline *local_opt, 
	struct capture_cmdline *capture_opt, 
	struct display_cmdline *disp_opt, 
	struct audio_cmdline *audio_opt, 
	struct DCCVideoSource **ppVideoSource, 
	RMuint32 input, 
	RMuint8 dev, 
	RMuint8 delay, 
	RMuint8 *avi_data)  // avi_data[1] through avi_data[13] are used
{
	RMstatus err;
	RMuint32 aspx, aspy;
	RMbool update_mode = FALSE;
	RMuint32 x, y, w, h;
	struct avi_info avi;
	RMbool force;  // force update, even if information is unchanged
	RMbool update_zoom = FALSE;
	enum EMhwlibScanInfo scan = EMhwlibScanInfo_NoData;
	
	force = ! local_opt->last_avi.valid;
	
	avi.valid = TRUE;
	avi.color_format = (avi_data[1] >> 5) & 0x03;
	avi.active_format = (avi_data[1] & 0x10) | (avi_data[2] & 0x0F);
	avi.h_bar = (avi_data[1] & 0x08) ? TRUE : FALSE;
	avi.v_bar = (avi_data[1] & 0x04) ? TRUE : FALSE;
	avi.scan_info = avi_data[1] & 0x03;
	avi.color_space = (avi_data[2] >> 6) & 0x03;
	avi.aspect_ratio = (avi_data[2] >> 4) & 0x03;
	avi.scaling = avi_data[3] & 0x03;
	avi.quantisation = (avi_data[3] >> 2) & 0x03;
	avi.ext_col = (avi_data[3] >> 4) & 0x07;
	avi.it_content = (avi_data[3] & 0x80) ? TRUE : FALSE;
	avi.vic = avi_data[4] & 0x7F;
	avi.pixel_rep = avi_data[5] & 0x0F;
	avi.top = (avi_data[7] << 8) | avi_data[6];
	avi.bottom = (avi_data[9] << 8) | avi_data[8];
	avi.left = (avi_data[11] << 8) | avi_data[10];
	avi.right = (avi_data[13] << 8) | avi_data[12];
	
	if (avi.pixel_rep != local_opt->last_avi.pixel_rep) {
		// unused for now
		fprintf(stderr, "newavi - each pixel sent %lu times by source\n", avi.pixel_rep + 1);
	}
	
	if (avi.pixel_rep != local_opt->last_avi.pixel_rep) {
		// unused for now
		fprintf(stderr, "newavi - each pixel sent %lu times by source\n", avi.pixel_rep + 1);
	}
	
	// Apply new color space and color format from AVI
	if (force || (avi.color_format != local_opt->last_avi.color_format) || (avi.color_space != local_opt->last_avi.color_space)) {
		enum EMhwlibColorSpace cs = capture_opt->InputColorSpace;
		enum EMhwlibInputColorFormat icf = capture_opt->InputColorFormat;
		
		local_opt->upsample_from_422 = FALSE;
		switch (avi.color_format) {
		case 0: 
			fprintf(stderr, "newavi - RGB 888\n");
			icf = EMhwlibInputColorFormat_24BPP;
			switch (avi.quantisation) {
				case 0: cs = (avi.vic > 1) ? EMhwlibColorSpace_RGB_16_235 : EMhwlibColorSpace_RGB_0_255; break;
				case 1: cs = EMhwlibColorSpace_RGB_16_235; break;
				case 2: cs = EMhwlibColorSpace_RGB_0_255; break;
				default: fprintf(stderr, "newavi - unknown RGB quantisation range code: %lu\n", avi.quantisation); break;
			}
			break;
		case 1: 
			fprintf(stderr, "newavi - YCbCr 4:2:2\n");
			local_opt->upsample_from_422 = TRUE;
			if (0)  // prevent first line of next case from being executed
			// no break;
		case 2: 
			fprintf(stderr, "newavi - YCbCr 4:4:4\n");
			icf = EMhwlibInputColorFormat_24BPP;
			switch (avi.color_space) {
				case 0: break;  // no data
				case 1: cs = EMhwlibColorSpace_YUV_601; break;
				case 2: cs = EMhwlibColorSpace_YUV_709; break;
				case 3: // extended
					switch (avi.ext_col) {
						case 0: cs = EMhwlibColorSpace_YUV_601; break;  // TODO EMhwlibColorSpace_xvYCC_601
						case 1: cs = EMhwlibColorSpace_YUV_709; break;  // TODO EMhwlibColorSpace_xvYCC_709
						default: fprintf(stderr, "newavi - unknown extended color space code: %lu\n", avi.ext_col); break;
					}
					break;
				default: fprintf(stderr, "newavi - unknown color space code: %lu\n", avi.color_space); break;
			}
			break;
		default: 
			fprintf(stderr, "newavi - unknown color sampling code: %lu\n", avi.color_format);
			break;
		}
		set_422_to_444_upsampling_SiI9031(dcc_info->pRUA, local_opt->upsample_from_422, dev, delay);
		if (cs != capture_opt->InputColorSpace) {
			fprintf(stderr, "newavi - color space: %s\n", 
				(cs == EMhwlibColorSpace_RGB_0_255) ? "RGB 0-255" : 
				(cs == EMhwlibColorSpace_RGB_16_235) ? "RGB 16-235" : 
				(cs == EMhwlibColorSpace_YUV_601) ? "YUV601" : 
				(cs == EMhwlibColorSpace_YUV_709) ? "YUV709" : 
//				(cs == EMhwlibColorSpace_xvYCC_601) ? "xvYCC709" : 
//				(cs == EMhwlibColorSpace_xvYCC_709) ? "xvYCC709" : 
				"unknown");
			capture_opt->InputColorSpace = cs;
			// Set up color space on Input
			RUASetPendingProperty(dcc_info->pRUA, capture_opt->InputModuleID, 
				RMGenericPropertyID_ColorSpace, &cs, sizeof(cs), 
				"Failed to set property ColorSpace on Input");
			RUASetPendingProperty(dcc_info->pRUA, capture_opt->InputModuleID, 
				RMGenericPropertyID_Validate, NULL, 0, 
				"Failed to validate input");
			// Set HDMI blank color (for HDCP mute)
			set_blanking_color_SiI9031(dcc_info->pRUA, capture_opt, local_opt, dev, delay);
		}
		if (icf != capture_opt->InputColorFormat) {
			fprintf(stderr, "newavi - sampling mode: %s\n", (icf == EMhwlibInputColorFormat_24BPP) ? ((cs == EMhwlibColorSpace_RGB_0_255) ? "RGB" : "4:4:4") : "4:2:2");
			capture_opt->InputColorFormat = icf;
			update_mode = TRUE;
		}
	}
	
	// Check aspect ratio from AVI (don't override VIC mode default)
	aspx = capture_opt->PictureAspectRatio.X;
	aspy = capture_opt->PictureAspectRatio.Y;
	switch (avi.aspect_ratio) {
		case DH_ar_no_info: break;  // no data in AVI about aspect ratio, use implicit aspect ratio from VIC
		case DH_ar_4x3: aspx =  4; aspy =  3; break;
		case DH_ar_16x9: aspx = 16; aspy =  9; break;
		default: 
			if (force || (avi.aspect_ratio != local_opt->last_avi.aspect_ratio)) 
				fprintf(stderr, "newavi - unknown aspect ratio code: %lu\n", avi.aspect_ratio); 
			break;
	}
	
	// Apply new video mode from AVI
	if (force || (local_opt->last_avi.vic != avi.vic) || ((capture_opt->TVStandard == EMhwlibTVStandard_Custom) && avi.vic)) {
		fprintf(stderr, "newavi - VIC: %lu\n", avi.vic);
		if (avi.vic == 0) {
			local_opt->update_videomode = TRUE;
			update_mode = FALSE;
			capture_opt->PictureAspectRatio.X = aspx;
			capture_opt->PictureAspectRatio.Y = aspy;
		} else if (avi.vic - 1 < (sizeof(cea861c) / sizeof(enum EMhwlibTVStandard))) {
			// Use TVStandard from VIC
			if (cea861c[avi.vic - 1] != capture_opt->TVStandard) {
				RMascii *StandardName;
				GetTVStandardName(cea861c[avi.vic - 1], &StandardName);
				fprintf(stderr, "newavi - video mode from VIC %lu: %s\n", avi.vic, StandardName);
				capture_opt->TVStandard = cea861c[avi.vic - 1];
				update_mode = TRUE;
			}
			if (local_opt->last_avi.vic != avi.vic) {
				fprintf(stderr, "\n\n\t\t%s %s\n\n\n", 
					CEA861_ShortDescriptorVideoResolutions[avi.vic], 
					(capture_opt->InputColorSpace == EMhwlibColorSpace_RGB_0_255) ? "RGB 0-255" : 
					(capture_opt->InputColorSpace == EMhwlibColorSpace_RGB_16_235) ? "RGB 16-235" : 
					(capture_opt->InputColorSpace == EMhwlibColorSpace_YUV_601) ? "YCbCr 601" : 
					(capture_opt->InputColorSpace == EMhwlibColorSpace_YUV_709) ? "YCbCr 709" : 
//					(capture_opt->InputColorSpace == EMhwlibColorSpace_xvYCC_601) ? "xvYCC709" : 
//					(capture_opt->InputColorSpace == EMhwlibColorSpace_xvYCC_709) ? "xvYCC709" : 
					"unknown");
			}
			// 640x480 or first of two identical modes: 4:3
			if ((avi.vic == 1) || ((avi.vic < (sizeof(cea861c) / sizeof(enum EMhwlibTVStandard))) && (cea861c[avi.vic - 1] == cea861c[avi.vic]))) {
				if ((capture_opt->PictureAspectRatio.X != 4) || (capture_opt->PictureAspectRatio.Y != 3)) {
					fprintf(stderr, "newavi - aspect ratio from VIC %lu: 4 by 3\n", avi.vic);
					capture_opt->PictureAspectRatio.X = 4;
					capture_opt->PictureAspectRatio.Y = 3;
					update_mode = TRUE;
				}
			} else {  // otherwise 16:9
				if ((capture_opt->PictureAspectRatio.X != 16) || (capture_opt->PictureAspectRatio.Y != 9)) {
					fprintf(stderr, "newavi - aspect ratio from VIC %lu: 16 by 9\n", avi.vic);
					capture_opt->PictureAspectRatio.X = 16;
					capture_opt->PictureAspectRatio.Y = 9;
					update_mode = TRUE;
				}
			}
		} else {
			fprintf(stderr, "Error, unknown CEA 861-C timing descriptor in AVI: %lu\n", avi.vic);
		}
	}
	
	if ((aspx != capture_opt->PictureAspectRatio.X) || (aspy != capture_opt->PictureAspectRatio.Y)) {
		if (avi.vic > 0) {
			fprintf(stderr, "newavi - aspect ratio in AVI does not match VIC %ld: %lu by %lu\n", avi.vic, aspx, aspy);
			//capture_opt->PictureAspectRatio.X = aspx;
			//capture_opt->PictureAspectRatio.Y = aspy;
			//update_mode = TRUE;
		}
	}
	
	// set to neutral zoom window
	x = ZOOM_0; y = ZOOM_0; w = ZOOM_1; h = ZOOM_1;
	
	// apply active format
	if (avi.active_format & 0x10) {
		enum DH_active_format_aspect_ratio act = (enum DH_active_format_aspect_ratio)(avi.active_format & 0x0F);
		struct EMhwlibActiveFormatDescription afd;
		struct EMhwlibAspectRatio scaler_ar;
		RMbool output_variable_ar, variable_output;
		struct EMhwlibActiveFormatDescription output_afd;
		
		if (force || (avi.active_format != local_opt->last_avi.active_format)) {
			fprintf(stderr, "newavi - active format: %u - %s\n", act, 
				(act == DH_af_reserved_0) ? "No info" : 
				(act == DH_af_16x9_top) ? "16:9 content: at top of 4:3 frame, fills up 16:9 frame" : 
				(act == DH_af_14x9_top) ? "14:9 content: at top of 4:3 frame, centered on 16:9 frame" : 
				(act == DH_af_64x27_centered) ? "Cinemascope widescreen (2.35:1, 64:27) content: centered on 4:3 or 16:9 frame" : 
				(act == DH_af_same_as_picture) ? "content fills up frame" : 
				(act == DH_af_4x3_centered) ? "4:3 content: fills up 4:3 frame, centered on 16:9 frame" : 
				(act == DH_af_16x9_centered) ? "16:9 content: centered on 4:3 frame, fills up 16:9 frame" : 
				(act == DH_af_14x9_centered) ? "14:9 content: centered on 4:3 frame, centered on 16:9 frame" : 
				(act == DH_af_4x3_centered_prot_14x9) ? "4:3 content with essential content in 14:9 centered portion" : 
				(act == DH_af_16x9_centered_prot_14x9) ? "16:9 content with essential content in 14:9 centered portion" : 
				(act == DH_af_16x9_centered_prot_4x3) ? "16:9 content with essential content in 4:3 centered portion" : 
				"unknown format code!");
		}
		afd.ActiveFormat = (enum EMhwlibActiveFormat)act;
		afd.ActiveFormatValid = TRUE;
		afd.FrameAspectRatio = capture_opt->PictureAspectRatio;
		err = get_scaler_output_aspect_ratio(
			dcc_info->pRUA, 
			dcc_info->disp_info->osd_scaler[input], 
			(dcc_info->route == DCCRoute_Secondary) ? DispVCRMixer : DispMainMixer, 
			&scaler_ar, &variable_output);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Can not get scaler output aspect ratio! %s\n", RMstatusToString(err)));
			// fallback, this assumes full screen scaler window.
			scaler_ar.X = disp_opt->ar_x;
			scaler_ar.Y = disp_opt->ar_y;
		}
		RMDBGLOG((LOCALDBG, "Scaler output aspect ratio: %lu:%lu\n", scaler_ar.X, scaler_ar.Y));
		output_afd.FrameAspectRatio.X = disp_opt->ar_x;
		output_afd.FrameAspectRatio.Y = disp_opt->ar_y;
		output_afd.ActiveFormat = disp_opt->active_format;
		output_afd.ActiveFormatValid = disp_opt->active_format_valid;
		if (variable_output) {
			get_output_variable_aspect_ratio(disp_opt->standard, &output_variable_ar);
		} else {
			output_variable_ar = FALSE;
		}
		err = apply_active_format_rel(
			afd, scaler_ar, 
			output_variable_ar, &output_afd, 
			&x, &y, &w, &h, 
			&update_zoom);
		if (variable_output && (
			(output_afd.FrameAspectRatio.X != disp_opt->ar_x) || 
			(output_afd.FrameAspectRatio.Y != disp_opt->ar_y) || 
			(output_afd.ActiveFormatValid && (output_afd.ActiveFormat != disp_opt->active_format)) || 
			(output_afd.ActiveFormatValid != disp_opt->active_format_valid)
		)) {
			apply_active_format_output(dcc_info->pRUA, 
				(dcc_info->route == DCCRoute_Secondary) ? DispVCRMixer : DispMainMixer, 
				disp_opt->dh_info->pDH, 
				output_afd);
			disp_opt->ar_x = output_afd.FrameAspectRatio.X;
			disp_opt->ar_y = output_afd.FrameAspectRatio.Y;
			disp_opt->active_format_valid = output_afd.ActiveFormatValid;
			disp_opt->active_format = output_afd.ActiveFormat;
		}
		if (RMFAILED(err) && (force || (avi.active_format != local_opt->last_avi.active_format))) {
			fprintf(stderr, "newavi - failed to apply active format: %u\n", act);
		}
	} else if (local_opt->last_avi.active_format & 0x10) {
		// no more active format, return to full screen
		update_zoom = TRUE;
	}
	
	// apply horizontal bars
	if (avi.h_bar) {
		if (avi.bottom > avi.top) {
			if (force || 
				(avi.h_bar != local_opt->last_avi.h_bar) || 
				(avi.top != local_opt->last_avi.top) || 
				(avi.bottom != local_opt->last_avi.bottom)
			) fprintf(stderr, "newavi - horizontal bars to line %ld, from line %ld\n", avi.top, avi.bottom);
			y = avi.top;
			h = avi.bottom - avi.top - 1;
			update_zoom = TRUE;
		}
	} else if (local_opt->last_avi.h_bar) {
		// no more horizontal bars, return to full height
		update_zoom = TRUE;
	}
	
	// apply vertical bars
	if (avi.v_bar) {
		if (avi.right > avi.left) {
			if (force || 
				(avi.v_bar != local_opt->last_avi.v_bar) || 
				(avi.left != local_opt->last_avi.left) || 
				(avi.right != local_opt->last_avi.right)
			) fprintf(stderr, "newavi - vertical bars to col %ld, from col %ld\n", avi.left, avi.right);
			x = avi.left;
			w = avi.right - avi.left - 1;
			update_zoom = TRUE;
		}
	} else if (local_opt->last_avi.v_bar) {
		// no more vertical bars, return to full width
		update_zoom = TRUE;
	}
	
	// determine default scan mode from video mode
	scan = (avi.vic > 1) ? EMhwlibScanInfo_Overscanned : EMhwlibScanInfo_Underscanned;
	// override scan mode from AVI
	if (avi.scan_info != local_opt->last_avi.scan_info) {
		// unused for now
		fprintf(stderr, "newavi - picture scan info: %s\n", 
			(avi.scan_info == DH_overscanned) ? "overscanned (will be cropped)" : 
			(avi.scan_info == DH_underscanned) ? "underscanned (will not be cropped)" : 
			"no data");
	}
	switch (avi.scan_info) {
	case DH_overscanned:
		scan = EMhwlibScanInfo_Overscanned;
		break;
	case DH_underscanned:
		scan = EMhwlibScanInfo_Underscanned;
		break;
	}
	// picture is overscanned, need to crop "dirty" edge
	if (scan == EMhwlibScanInfo_Overscanned) {
		RMuint32 adj = (ZOOM_0 * local_opt->overscan_crop + 100) / 200;  // cut off half of the percentage on each side
		fprintf(stderr, "newavi - applying %lu%% overscan crop\n", local_opt->overscan_crop);
		if ((x >= ZOOM_0) && (w >= ZOOM_0)) {
			x += adj;
			w -= (adj * 2);
		} else {
			// TODO
			fprintf(stderr, "newavi - vertical bar info present, overscan crop not applied\n");
		}
		if ((y >= ZOOM_0) && (h >= ZOOM_0)) {
			y += adj;
			h -= (adj * 2);
		} else {
			// TODO
			fprintf(stderr, "newavi - horizontal bar info present, overscan crop not applied\n");
		}
	}
	
	// update bar information
	if ((! local_opt->zoom_force) && (
		(local_opt->zoom_x != x) || 
		(local_opt->zoom_y != y) || 
		(local_opt->zoom_w != w) || 
		(local_opt->zoom_h != h)
	)) {
		if ((x == ZOOM_0) && (y == ZOOM_0) && (w == ZOOM_1) && (h == ZOOM_1)) {
			fprintf(stderr, "newavi - full screen zoom window\n");
		} else {
			fprintf(stderr, "newavi - zoom window: ");
			if (x >= ZOOM_0) {
				RMuint32 xx = (((x - ZOOM_0) * 10000) + ((ZOOM_1 - ZOOM_0) / 2)) / (ZOOM_1 - ZOOM_0);
				fprintf(stderr, "x=%ld.%02ld%% ", xx / 100, xx % 100);
			} else fprintf(stderr, "x=%ld ", x);
			if (y >= ZOOM_0) {
				RMuint32 yy = (((y - ZOOM_0) * 10000) + ((ZOOM_1 - ZOOM_0) / 2)) / (ZOOM_1 - ZOOM_0);
				fprintf(stderr, "y=%ld.%02ld%% ", yy / 100, yy % 100);
			} else fprintf(stderr, "y=%ld ", y);
			if (w >= ZOOM_0) {
				RMuint32 ww = (((w - ZOOM_0) * 10000) + ((ZOOM_1 - ZOOM_0) / 2)) / (ZOOM_1 - ZOOM_0);
				fprintf(stderr, "w=%ld.%02ld%% ", ww / 100, ww % 100);
			} else fprintf(stderr, "w=%ld ", w);
			if (h >= ZOOM_0) {
				RMuint32 hh = (((h - ZOOM_0) * 10000) + ((ZOOM_1 - ZOOM_0) / 2)) / (ZOOM_1 - ZOOM_0);
				fprintf(stderr, "h=%ld.%02ld%% ", hh / 100, hh % 100);
			} else fprintf(stderr, "h=%ld ", h);
			fprintf(stderr, "\n");
		}
		local_opt->zoom_x = x;
		local_opt->zoom_y = y;
		local_opt->zoom_w = w;
		local_opt->zoom_h = h;
		if (! update_mode) {
			// when update_mode, setup_input() is already performing set_scaler_source_zoom()
			set_scaler_source_zoom(dcc_info->pRUA, dcc_info->disp_info->osd_scaler[input], local_opt->zoom_x, local_opt->zoom_y, local_opt->zoom_w, local_opt->zoom_h);
		}
	}
	
	// update capture, if neccessary
	if (update_mode) {
		fprintf(stderr, "newavi - updating capture mode\n");
		err = close_input(dcc_info, ppVideoSource, capture_opt, disp_opt, local_opt, input);
		if (RMFAILED(err)) RMDBGLOG((ENABLE, "Error closing capture!\n"));
		err = setup_input(dcc_info, ppVideoSource, capture_opt, disp_opt, local_opt, input);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "FATAL: Error setting up capture!\n"));
			exit(1);
		}
		err = setup_HDMI_audio(dcc_info, local_opt, audio_opt, dev, delay);
		if (audio_opt->AudioIn && audio_opt->SampleRate) {
			err = init_audio_passthrough(dcc_info, audio_opt, capture_opt);
			if (RMFAILED(err)) {
				fprintf(stderr, "Error starting audio capture! %s\n", RMstatusToString(err));
			}
		}
	}
	
	local_opt->last_avi = avi;
	
	return RM_OK;
}

static RMstatus handle_hdmi_spd_info_frame(
	struct dcc_context *dcc_info, 
	struct local_cmdline *local_opt, 
	struct capture_cmdline *capture_opt, 
	struct display_cmdline *disp_opt, 
	struct DCCVideoSource **ppVideoSource, 
	RMuint32 input, 
	RMuint8 *spd_data)  // spd_data[1] through spd_data[25] are used
{
	RMascii Vendor[9], Product[17];
	enum DH_source_dev_info sdi;
	RMuint32 i;
	
	for (i = 0; i < 8; i++) Vendor[i] = (RMascii)spd_data[i + 1];
	Vendor[8] = '\0';
	for (i = 0; i < 16; i++) Product[i] = (RMascii)spd_data[i + 9];
	Product[16] = '\0';
	sdi = (enum DH_source_dev_info)spd_data[25];
	
	fprintf(stderr, "SPD Info - Vendor: \"%s\", Product: \"%s\" - Category: %s (0x%02X)\n", 
		Vendor, Product, 
		(sdi == DH_source_dev_unknown) ? "unknown" : 
		(sdi == DH_source_dev_DigitalSTB) ? "DigitalSTB" : 
		(sdi == DH_source_dev_DVD) ? "DVD" : 
		(sdi == DH_source_dev_DVHS) ? "DVHS" : 
		(sdi == DH_source_dev_HDDVideo) ? "HDDVideo" : 
		(sdi == DH_source_dev_DVC) ? "DVC" : 
		(sdi == DH_source_dev_DSC) ? "DSC" : 
		(sdi == DH_source_dev_VideoCD) ? "VideoCD" : 
		(sdi == DH_source_dev_Game) ? "Game" : 
		(sdi == DH_source_dev_PC) ? "PC" : 
		(sdi == DH_source_dev_BluRay) ? "BluRay" : 
		(sdi == DH_source_dev_SACD) ? "SACD" : 
		"invalid value!", (RMuint8)sdi);
	
	return RM_OK;
}

static RMstatus handle_hdmi_audio_info_frame(
	struct dcc_context *dcc_info, 
	struct local_cmdline *local_opt, 
	struct capture_cmdline *capture_opt, 
	struct display_cmdline *disp_opt, 
	struct audio_cmdline *audio_opt, 
	struct DCCVideoSource **ppVideoSource, 
	RMuint32 input, 
	RMuint8 *data)
{
	struct DH_AudioInfoFrame aif;
	
	fprintf(stderr, "new Audio InfoFrame\n");
	
	aif.Version = 1;
	aif.CodingType = (enum DH_AudioCodingType)RMunshiftBits(data[1], 4, 4);
	aif.ChannelCount = (enum DH_AudioChannelCount)RMunshiftBits(data[1], 3, 0);
	aif.SampleFrequency = (enum DH_AudioSampleFrequency)RMunshiftBits(data[2], 3, 2);
	aif.SampleSize = (enum DH_AudioSampleSize)RMunshiftBits(data[2], 2, 0);
	aif.LFE_Ch3_Enable = RMunshiftBool(data[4], 0);
	aif.FC_Ch4_Enable = RMunshiftBool(data[4], 1);
	aif.CA = (enum DH_Audio_ChannelAssignment)RMunshiftBits(data[4], 6, 2);
	aif.DownMixInhibit = RMunshiftBool(data[5], 7);
	aif.LevelShift = RMunshiftBits(data[5], 4, 3);
	aif.MaxBitRate = data[3];  // codec dependent
	
	fprintf(stderr, "  Audio Coding Type: ");
	switch (aif.CodingType) {
		case DH_AudioCodingType_FromStreamHeader: fprintf(stderr, "Refer to stream header\n"); break;
		case DH_AudioCodingType_PCM: fprintf(stderr, "IEC60958 PCM\n"); break;
		case DH_AudioCodingType_AC3: fprintf(stderr, "AC-3\n"); break;
		case DH_AudioCodingType_MPEG1_12: fprintf(stderr, "MPEG1 Layer 1/2\n"); break;
		case DH_AudioCodingType_MPEG1_3: fprintf(stderr, "MPEG1 Layer 3\n"); break;
		case DH_AudioCodingType_MPEG2: fprintf(stderr, "MPEG2\n"); break;
		case DH_AudioCodingType_AAC: fprintf(stderr, "AAC\n"); break;
		case DH_AudioCodingType_DTS: fprintf(stderr, "DTS\n"); break;
		case DH_AudioCodingType_ATRAC: fprintf(stderr, "ATRAC\n"); break;
		case DH_AudioCodingType_OneBit: fprintf(stderr, "One Bit Audio\n"); break;
		case DH_AudioCodingType_DDPlus: fprintf(stderr, "Dolby Digital +\n"); break;
		case DH_AudioCodingType_DTSHD: fprintf(stderr, "DTS-HD\n"); break;
		case DH_AudioCodingType_MLP: fprintf(stderr, "MAT (MLP)\n"); break;
		case DH_AudioCodingType_DST: fprintf(stderr, "DST\n"); break;
		case DH_AudioCodingType_WMAPro: fprintf(stderr, "WMA Pro\n"); break;
		default: fprintf(stderr, "Unknown!\n"); break;
	}
	fprintf(stderr, "  Audio Channel Count: ");
	switch (aif.ChannelCount) {
		case DH_AudioChannelCount_FromStreamHeader: fprintf(stderr, "Refer to stream header\n"); break;
		case DH_AudioChannelCount_2: 
		case DH_AudioChannelCount_3: 
		case DH_AudioChannelCount_4: 
		case DH_AudioChannelCount_5: 
		case DH_AudioChannelCount_6: 
		case DH_AudioChannelCount_7: 
		case DH_AudioChannelCount_8: 
			fprintf(stderr, "%u channel\n", 2 + (aif.ChannelCount - DH_AudioChannelCount_2)); 
			break;
		default: fprintf(stderr, "Unknown!\n"); break;
	}
	fprintf(stderr, "  Audio Sample Frequency: ");
	switch (aif.SampleFrequency) {
		case DH_AudioSampleFrequency_FromStreamHeader: fprintf(stderr, "Refer to stream header\n"); break;
		case DH_AudioSampleFrequency_32000: fprintf(stderr, "32 kHz\n"); break;
		case DH_AudioSampleFrequency_44100: fprintf(stderr, "44.1 kHz\n"); break;
		case DH_AudioSampleFrequency_48000: fprintf(stderr, "48 kHz\n"); break;
		case DH_AudioSampleFrequency_88200: fprintf(stderr, "88.2 kHz\n"); break;
		case DH_AudioSampleFrequency_96000: fprintf(stderr, "96 kHz\n"); break;
		case DH_AudioSampleFrequency_176400: fprintf(stderr, "176.4 kHz\n"); break;
		case DH_AudioSampleFrequency_192000: fprintf(stderr, "192 kHz\n"); break;
		default: fprintf(stderr, "Unknown!\n"); break;
	}
	fprintf(stderr, "  Audio Sample Size: ");
	switch (aif.SampleSize) {
		case DH_AudioSampleSize_FromStreamHeader: fprintf(stderr, "Refer to stream header\n"); break;
		case DH_AudioSampleSize_16: fprintf(stderr, "16 bit\n"); break;
		case DH_AudioSampleSize_20: fprintf(stderr, "20 bit\n"); break;
		case DH_AudioSampleSize_24: fprintf(stderr, "24 bit\n"); break;
		default: fprintf(stderr, "Unknown!\n"); break;
	}
	fprintf(stderr, "  Channel Assignment: ");
	switch (aif.CA) {
		case DH_Audio_CA_none: 
			fprintf(stderr, "--- --- -- --"); break;
		case DH_Audio_CA_RC5: 
			fprintf(stderr, "--- --- -- RC"); break;
		case DH_Audio_CA_RL5_RR6: 
			fprintf(stderr, "--- --- RR RL"); break;
		case DH_Audio_CA_RL5_RR6_RC7: 
			fprintf(stderr, "---  RC RR RL"); break;
		case DH_Audio_CA_RL5_RR6_RLC7_RRC8: 
			fprintf(stderr, "RRC RLC RR RL"); break;
		case DH_Audio_CA_FLC7_FRC8: 
			fprintf(stderr, "FRC FLC -- --"); break;
		case DH_Audio_CA_RC5_FLC7_FRC8: 
			fprintf(stderr, "FRC FLC -- RC"); break;
		case DH_Audio_CA_RL5_RR6_FLC7_FRC8: 
			fprintf(stderr, "FRC FLC RR RL"); break;
		default: 
			fprintf(stderr, "XXX XXX XX XX"); break;
	}
	fprintf(stderr, " %s %s FR FL\n", 
		aif.FC_Ch4_Enable ? "FC" : "--", 
		aif.LFE_Ch3_Enable ? "LFE" : "---");
	fprintf(stderr, "  Level Shift: %lu dB\n", aif.LevelShift);
	fprintf(stderr, "  Down Mix %s\n", aif.DownMixInhibit ? "Prohibited" : "Permitted");
	if ((aif.CodingType >= DH_AudioCodingType_AC3) && (aif.CodingType <= DH_AudioCodingType_ATRAC)) {
		fprintf(stderr, "  Maximum Bit Rate: %lu kHz\n", aif.MaxBitRate * 8);
	}
	
	return RM_OK;
}

static RMstatus handle_hdmi_mpeg_info_frame(
	struct dcc_context *dcc_info, 
	struct local_cmdline *local_opt, 
	struct capture_cmdline *capture_opt, 
	struct display_cmdline *disp_opt, 
	struct DCCVideoSource **ppVideoSource, 
	RMuint32 input, 
	RMuint8 *data)
{
	struct DH_MPEGInfoFrame mpeg;
	
	fprintf(stderr, "new MPEG InfoFrame\n");
	
	mpeg.Version = 1;
	mpeg.BitRate = 0;
	RMinsShiftBits(&(mpeg.BitRate), data[1], 8,  0);
	RMinsShiftBits(&(mpeg.BitRate), data[2], 8,  8);
	RMinsShiftBits(&(mpeg.BitRate), data[3], 8, 16);
	RMinsShiftBits(&(mpeg.BitRate), data[4], 8, 24);
	mpeg.RepeatedField = RMunshiftBool(data[5], 4);
	mpeg.Frame = (enum DH_MPEG_Frame)RMunshiftBits(data[5], 2, 0);
	
	fprintf(stderr, "  MPEG Bit Rate: %lu Hz\n", mpeg.BitRate);
	fprintf(stderr, "  %s Field\n", mpeg.RepeatedField ? "Repeated" : "New");
	fprintf(stderr, "  MPEG Frame: %s\n", 
		(mpeg.Frame == DH_MPEG_Frame_unknown) ? "Unknown" : 
		(mpeg.Frame == DH_MPEG_Frame_I) ? "I Picture" : 
		(mpeg.Frame == DH_MPEG_Frame_B) ? "B Picture" : 
		(mpeg.Frame == DH_MPEG_Frame_P) ? "P Picture" : 
		"Invalid");
	
	return RM_OK;
}

static RMstatus handle_hdmi_info_frame(
	struct dcc_context *dcc_info, 
	struct local_cmdline *local_opt, 
	struct capture_cmdline *capture_opt, 
	struct display_cmdline *disp_opt, 
	struct audio_cmdline *audio_opt, 
	struct DCCVideoSource **ppVideoSource, 
	RMuint32 input, 
	RMuint8 dev, 
	RMuint8 delay, 
	RMuint8 *header, 
	RMuint8 *data)
{
	RMstatus err;
	RMuint32 mask;
	
	switch (header[0]) {
	case 0x04:  // Audio CP
		return handle_hdmi_audio_cp_info_frame(dcc_info, local_opt, capture_opt, disp_opt, ppVideoSource, input, header, data);
	case 0x05:  // ISRC1
		err = handle_hdmi_isrc1_info_frame(dcc_info, local_opt, capture_opt, disp_opt, ppVideoSource, input, header, data);
		if (RMSUCCEEDED(err) && (header[1] & 0x80)) {  // was different ISRC1, 
			write_i2c(dcc_info->pRUA, delay, dev + 4, 0xBF, 0x06);  // expect ISRC2, use MPEG receive area
			read_i2c(dcc_info->pRUA, delay, dev, 0x7A, &mask);
			if (! (mask & 0x08)) {
				write_i2c(dcc_info->pRUA, delay, dev, 0x7A, mask | 0x08);
			}
		}
		return (err == RM_PENDING) ? RM_OK : err;
	case 0x06:  // ISRC2
		err = handle_hdmi_isrc2_info_frame(dcc_info, local_opt, capture_opt, disp_opt, ppVideoSource, input, header, data);
		write_i2c(dcc_info->pRUA, delay, dev + 4, 0xBF, 0x05);  // expect next ISRC1, use MPEG receive area
		read_i2c(dcc_info->pRUA, delay, dev, 0x7A, &mask);
		if (! (mask & 0x08)) {
			write_i2c(dcc_info->pRUA, delay, dev, 0x7A, mask | 0x08);
		}
		return (err == RM_PENDING) ? RM_OK : err;
	case 0x0A:  // Gamut Boundary Description
		return handle_hdmi_gamut_info_frame(dcc_info, local_opt, capture_opt, disp_opt, ppVideoSource, input, header, data);
	case 0x81:  // Vendor specific block
		return handle_hdmi_vendor_info_frame(dcc_info, local_opt, capture_opt, disp_opt, ppVideoSource, input, header, data);
	case 0x82:  // Auxiliary Video Information
		if (header[1] == 0x02) {  // Version 2
			return handle_hdmi_avi_info_frame(dcc_info, local_opt, capture_opt, disp_opt, audio_opt, ppVideoSource, input, dev, delay, data);
		} else {
			RMDBGLOG((ENABLE, "Wrong version number in AVI info frame: 0x%02X\n", header[1]));
			break;
		}
	case 0x83:  // Source Product Description Info Frame
		if (header[1] == 0x01) {  // Version 1
			return handle_hdmi_spd_info_frame(dcc_info, local_opt, capture_opt, disp_opt, ppVideoSource, input, data);
		} else {
			RMDBGLOG((ENABLE, "Wrong version number in SPD info frame: 0x%02X\n", header[1]));
			break;
		}
	case 0x84:  // Audio Info Frame
		if (header[1] == 0x01) {  // Version 1
			return handle_hdmi_audio_info_frame(dcc_info, local_opt, capture_opt, disp_opt, audio_opt, ppVideoSource, input, data);
		} else {
			RMDBGLOG((ENABLE, "Wrong version number in Audio info frame: 0x%02X\n", header[1]));
			break;
		}
	case 0x85:  // MPEG Info Frame
		if (header[1] == 0x01) {  // Version 1
			return handle_hdmi_mpeg_info_frame(dcc_info, local_opt, capture_opt, disp_opt, ppVideoSource, input, data);
		} else {
			RMDBGLOG((ENABLE, "Wrong version number in MPEG info frame: 0x%02X\n", header[1]));
			break;
		}
	default:
		RMDBGLOG((ENABLE, "Unknown info frame type: 0x%02X\n", header[0]));
		break;
	}
	return RM_ERROR;
}

static RMstatus read_SiI9031_info_frame(
	struct dcc_context *dcc_info, 
	RMuint8 dev, 
	RMuint8 delay, 
	RMuint8 offset, 
	RMuint8 type, 
	RMuint8 version, 
	RMuint8 *header, 
	RMuint8 *data, 
	RMuint32 size)
{
	RMuint32 i, checksum;
	RMbool honor_checksum = TRUE;
	
	if (RMFAILED(read_i2c_data(dcc_info->pRUA, delay, dev + 4, offset, header, 3))) return RM_ERROR;;
	if (RMFAILED(read_i2c_data(dcc_info->pRUA, delay, dev + 4, offset + 3, data, RMmin((RMuint32)header[2] + 1, size)))) return RM_ERROR;
	
	if (header[0] & 0x80) {
		// calculate checksum
		checksum = 0;
		for (i = 0; i < 3; i++) checksum += header[i];
		for (i = 0; i < RMmin((RMuint32)header[2] + 1, size); i++) checksum += data[i];
	} else {
		checksum = 0;
	}
	
	if (checksum & 0xFF) {
		if (header[0]) {
			fprintf(stderr, "info frame checksum error at 0x%02X, type 0x%02X: 0x%02lX\n", offset, header[0], checksum & 0xFF);
		}
		if (honor_checksum) return RM_ERROR;
	} else if ((type && (header[0] != type)) || (version && (header[1] != version))) {
		if (header[0]) {
			RMDBGLOG((ENABLE, "Error, wrong Info Frame Type/Version: 0x%02X/0x%02X\n", header[0], header[1]));
			RMDBGPRINT((ENABLE, "type=0x%02lX ", header[0]));
			RMDBGPRINT((ENABLE, " ver=0x%02lX ", header[1]));
			RMDBGPRINT((ENABLE, " len=0x%02lX ", header[2]));
			RMDBGPRINT((ENABLE, " chk=0x%02X ", data[0]));
			for (i = 1; i < size; i++) {
				RMDBGPRINT((ENABLE, "%4l=0x%02X ", i, data[i]));
			}
			RMDBGPRINT((ENABLE, "\n"));
		}
		return RM_ERROR;
	}
	return RM_OK;
}
static RMstatus detect_hdmi_mode(
								 struct dcc_context *dcc_info, 
								 struct local_cmdline *local_opt, 
								 struct audio_cmdline *audio_opt, 
								 RMuint8 dev, 
								 RMuint8 delay)
{
	RMstatus err;
	RMuint32 data;
	enum hdmi_mode hdmi_mode;
	err = read_i2c(dcc_info->pRUA, delay, dev + 4, 0x34, &data);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error reading I2C!\n"));
		hdmi_mode = mode_unknown;
	} else {
		hdmi_mode = (data & 0x02) ? mode_HDMI : mode_DVI;
	}
	if (hdmi_mode != local_opt->hdmi_mode) {
		local_opt->hdmi_mode = hdmi_mode;
		fprintf(stderr, "    %s mode detected\n", (hdmi_mode == mode_HDMI) ? "HDMI" : (hdmi_mode == mode_DVI) ? "DVI" : "unkown");
		err = read_i2c(dcc_info->pRUA, delay, dev, 0xD6, &data);
		if (hdmi_mode == mode_HDMI) {
			fprintf(stderr, "    re-reading AVI InfoFrame\n");
			local_opt->new_avi = TRUE;
			err = write_i2c(dcc_info->pRUA, delay, dev, 0xD6, data | 0x10);
		} else if (hdmi_mode == mode_DVI) {
			fprintf(stderr, "    re-detecting video mode\n");
			local_opt->update_videomode = TRUE;
			err = write_i2c(dcc_info->pRUA, delay, dev, 0xD6, data & ~0x10);
		}
		setup_HDMI_audio(dcc_info, local_opt, audio_opt, dev, delay);
	}
	return err;
}

static RMstatus prepare_dvi_mode(
	struct local_cmdline *local_opt, 
	struct capture_cmdline *capture_opt, 
	RMbool wide)
{
	capture_opt->InputColorSpace = EMhwlibColorSpace_RGB_0_255;
	capture_opt->InputColorFormat = EMhwlibInputColorFormat_24BPP;
	local_opt->upsample_from_422 = FALSE;
	local_opt->zoom_x = ZOOM_0;
	local_opt->zoom_y = ZOOM_0;
	local_opt->zoom_w = ZOOM_1;
	local_opt->zoom_h = ZOOM_1;
	
	// determine aspect ratio from video mode
	get_aspect_ratio_from_video_mode(
		capture_opt->TVStandard, 
		NULL, 
		wide, 
		&(capture_opt->PictureAspectRatio.X), 
		&(capture_opt->PictureAspectRatio.Y));
	fprintf(stderr, "Aspect Ratio from Video Mode: %lu:%lu\n", capture_opt->PictureAspectRatio.X, capture_opt->PictureAspectRatio.Y);
	
	return RM_OK;
}

static RMstatus handle_SiI9031_int(
	struct dcc_context *dcc_info, 
	struct local_cmdline *local_opt, 
	struct capture_cmdline *capture_opt, 
	struct display_cmdline *disp_opt, 
	struct audio_cmdline *audio_opt, 
	struct DCCVideoSource **ppVideoSource, 
	RMuint32 input, 
	RMuint8 dev, 
	RMuint8 delay)
{
	RMstatus err;
	RMuint32 reg, mask;
	
	// Check HDCP status
	err = read_i2c(dcc_info->pRUA, delay, dev, 0x32, &reg);
	if (RMFAILED(err)) RMDBGLOG((ENABLE, "Error reading I2C!\n"));
	else {
		RMbool auth, crypt;
		auth = (reg & 0x10);
		crypt = (reg & 0x20);
		if (auth != local_opt->last_auth) {
			local_opt->last_auth = auth;
			fprintf(stderr, "HDCP: devices are %sauthenticated\n", auth ? "" : "not ");
		}
		if (crypt != local_opt->last_crypt) {
			local_opt->last_crypt = crypt;
			fprintf(stderr, "HDCP: video is %sencrypted\n", crypt ? "" : "not ");
		}
	}
	
	// Check if any interrupts are pending
	err = read_i2c(dcc_info->pRUA, delay, dev, 0x70, &reg);
	if (RMFAILED(err)) RMDBGLOG((ENABLE, "Error reading I2C!\n"));
	else if (reg & 0x01) {
		// Check INTR1
		err = read_i2c(dcc_info->pRUA, delay, dev, 0x71, &reg);
		if (RMFAILED(err)) RMDBGLOG((ENABLE, "Error reading I2C!\n"));
		else if (reg & local_opt->intr_mask[0]) {
			//fprintf(stderr, "INTR1: 0x%02lX\n", reg);
			err = write_i2c(dcc_info->pRUA, delay, dev, 0x71, reg); /* clear intr */
			if (RMFAILED(err)) RMDBGLOG((ENABLE, "Error writing I2C!\n"));
			if (local_opt->verbouse && (reg & 0x80)) {
				RMuint8 cts[3];
				read_i2c_data(dcc_info->pRUA, delay, dev + 4, 0x0C, cts, 3);
				fprintf(stderr, "INTR1.7 - New CTS: 0x%01X%02X%02X\n", cts[2] & 0x0F, cts[1], cts[0]);
			}
			if (local_opt->verbouse && (reg & 0x40)) {
				RMuint8 n[3];
				read_i2c_data(dcc_info->pRUA, delay, dev + 4, 0x06, n, 3);
				fprintf(stderr, "INTR1.6 - New N: 0x%01X%02X%02X\n", n[2] & 0x0F, n[1], n[0]);
			}
			if (local_opt->verbouse && (reg & 0x20)) fprintf(stderr, "INTR1.5 - N/CTS decode error!\n");
			if (local_opt->verbouse && (reg & 0x10)) fprintf(stderr, "INTR1.4 - Audio PLL unlocked!\n");
			if (local_opt->verbouse && (reg & 0x08)) fprintf(stderr, "INTR1.3 - AudioFIFO error!\n");
			if (reg & 0x04) {
				if (local_opt->verbouse) fprintf(stderr, "INTR1.2 - ECC data island error!\n");
				// TODO need to soft-reset chip?
			}
			if (local_opt->verbouse && (reg & 0x02)) fprintf(stderr, "INTR1.1 - HDCP authentication started\n");
			if (local_opt->verbouse && (reg & 0x01)) fprintf(stderr, "INTR1.0 - HDCP authentication done\n");
		}
		
		// Check INTR2
		err = read_i2c(dcc_info->pRUA, delay, dev, 0x72, &reg);
		if (RMFAILED(err)) RMDBGLOG((ENABLE, "Error reading I2C!\n"));
		else if (reg & local_opt->intr_mask[1]) {
			//fprintf(stderr, "INTR2: 0x%02lX\n", reg);
			err = write_i2c(dcc_info->pRUA, delay, dev, 0x72, reg & 0xFB); /* clear intr */
			if (RMFAILED(err)) RMDBGLOG((ENABLE, "Error writing I2C!\n"));
			if (local_opt->verbouse && (reg & 0x80)) {
				if (local_opt->verbouse) fprintf(stderr, "INTR2.7 - HDMI/DVI mode change\n");
				detect_hdmi_mode(dcc_info, local_opt, audio_opt, dev, delay);
			}
			if (local_opt->verbouse && (reg & 0x10)) fprintf(stderr, "INTR2.4 - video clock detect changed\n");
			if (local_opt->verbouse && (reg & 0x08)) fprintf(stderr, "INTR2.3 - sync/DE detect changed\n");
			if (local_opt->verbouse && (reg & 0x01)) fprintf(stderr, "INTR2.0 - video clock frequency changed\n");
			if (reg & 0x19) {
				err = read_i2c(dcc_info->pRUA, delay, dev, 0x06, &mask);
				if (RMFAILED(err)) RMDBGLOG((ENABLE, "Error reading I2C!\n"));
				else {
					RMbool power, clock, sync;
					power = (mask & 0x08);
					clock = (mask & 0x02);
					sync = (mask & 0x01);
					if (power != local_opt->last_power) {
						local_opt->last_power = power;
						fprintf(stderr, "connector power %s\n", power ? "up" : "down");
					}
					if (clock != local_opt->last_clock) {
						local_opt->last_clock = clock;
						fprintf(stderr, "video clock %s\n", clock ? "present" : "lost");
					}
					if (sync != local_opt->last_sync) {
						local_opt->last_sync = sync;
						fprintf(stderr, "video sync %s\n", sync ? "present" : "lost");
						if (sync) {
							detect_hdmi_mode(dcc_info, local_opt, audio_opt, dev, delay);
						} else {
							flush_scaler(dcc_info, input);
							local_opt->last_avi.valid = FALSE;
						}
					}
					// DVI mode detection and set up
					if ((reg & 0x09) && clock && sync) {
						fprintf(stderr, "clock and sync are now present, detecting video mode.\n");
						local_opt->update_videomode = TRUE;
					}
				}
			}
		}
		
		// Check INTR3
		err = read_i2c(dcc_info->pRUA, delay, dev, 0x73, &reg);
		if (RMFAILED(err)) RMDBGLOG((ENABLE, "Error reading I2C!\n"));
		else if (reg & local_opt->intr_mask[2]) {
			//fprintf(stderr, "INTR3: 0x%02lX\n", reg);
			err = write_i2c(dcc_info->pRUA, delay, dev, 0x73, reg); /* clear intr */
			if (RMFAILED(err)) RMDBGLOG((ENABLE, "Error writing I2C!\n"));
			if (reg & 0x1F) {
				// Further ints on changed frame only
				err = read_i2c(dcc_info->pRUA, delay, dev, 0x7A, &mask);
				if (mask & reg & 0x1F) {
					err = write_i2c(dcc_info->pRUA, delay, dev, 0x7A, mask & ~(reg & 0x1F));
				}
			}
			if (reg & 0x01) {  // AVI Info Frame
				//RMuint8 header[3], data[16];
				if (local_opt->verbouse) fprintf(stderr, "INTR3.0 - new or changed AVI Info Frame detected.\n");
				//if (RMSUCCEEDED(read_SiI9031_info_frame(dcc_info, dev, delay, 0x40, 0x82, 0x02, header, data, sizeof(data) / sizeof(RMuint8)))) {
				//	handle_hdmi_avi_info_frame(dcc_info, local_opt, capture_opt, disp_opt, audio_opt, ppVideoSource, input, dev, delay, data);
				//}
				local_opt->new_avi = TRUE;
			}
			if (reg & 0x02) {  // SPD Info Frame
				RMuint8 header[3], data[26];
				if (local_opt->verbouse) fprintf(stderr, "INTR3.1 - new or changed SPD Info Frame detected.\n");
				if (RMSUCCEEDED(read_SiI9031_info_frame(dcc_info, dev, delay, 0x60, 0x83, 0x01, header, data, sizeof(data) / sizeof(RMuint8)))) {
					handle_hdmi_spd_info_frame(dcc_info, local_opt, capture_opt, disp_opt, ppVideoSource, input, data);
				} else {
					if (local_opt->verbouse) fprintf(stderr, "  Wrong type or version! 0x%02X 0x%02X\n", header[0], header[1]);
				}
			}
			if (reg & 0x04) {  // Audio Info Frame
				RMuint8 header[3], data[26];
				if (local_opt->verbouse) fprintf(stderr, "INTR3.2 - new or changed Audio Info Frame detected.\n");
				if (RMSUCCEEDED(read_SiI9031_info_frame(dcc_info, dev, delay, 0x80, 0x84, 0x01, header, data, sizeof(data) / sizeof(RMuint8)))) {
					handle_hdmi_audio_info_frame(dcc_info, local_opt, capture_opt, disp_opt, audio_opt, ppVideoSource, input, data);
				} else {
					if (local_opt->verbouse) fprintf(stderr, "  Wrong type or version! 0x%02X 0x%02X\n", header[0], header[1]);
				}
			}
			if (reg & 0x08) {  // MPEG Info Frame
				RMuint8 header[3], data[26];
				if (RMSUCCEEDED(read_SiI9031_info_frame(dcc_info, dev, delay, 0xA0, 0x00, 0x00, header, data, sizeof(data) / sizeof(RMuint8)))) {
					if (local_opt->verbouse) fprintf(stderr, "INTR3.3 - new or changed other (MPEG) Info Frame detected, type=0x%02X.\n", header[0]);
					err = read_i2c(dcc_info->pRUA, delay, dev + 4, 0xBF, &mask);
					if (header[0] == mask) {
						handle_hdmi_info_frame(dcc_info, local_opt, capture_opt, disp_opt, audio_opt, ppVideoSource, input, dev, delay, header, data);
					} else {  // try again
						if (local_opt->verbouse) fprintf(stderr, "  Unexpected type in MPEG receive area.\n");
						read_i2c(dcc_info->pRUA, delay, dev, 0x7A, &mask);
						if (! (mask & 0x08)) {
							write_i2c(dcc_info->pRUA, delay, dev, 0x7A, mask | 0x08);
						}
					}
				} else {
					if (local_opt->verbouse) fprintf(stderr, "  Wrong type or version! 0x%02X 0x%02X\n", header[0], header[1]);
				}
			}
			//if (reg & 0x10) {  // Other Info Frame
			//	RMuint8 header[3], data[26];
			//	if (local_opt->verbouse) fprintf(stderr, "INTR3.4 - new or changed other Info Frame detected.\n");
			//	if (RMSUCCEEDED(read_SiI9031_info_frame(dcc_info, dev, delay, 0xC0, 0x00, 0x00, header, data, sizeof(data) / sizeof(RMuint8)))) {
			//		handle_hdmi_info_frame(dcc_info, local_opt, capture_opt, disp_opt, audio_opt, ppVideoSource, input, dev, delay, header, data);
			//	}
			//}
			if (local_opt->verbouse && (reg & 0x40)) fprintf(stderr, "INTR3.6 - HDMI A/V Mute!\n");
		}
		
		// Check INTR4
		err = read_i2c(dcc_info->pRUA, delay, dev, 0x74, &reg);
		if (RMFAILED(err)) RMDBGLOG((ENABLE, "Error reading I2C!\n"));
		else if (reg & local_opt->intr_mask[3]) {
			//fprintf(stderr, "INTR4: 0x%02lX\n", reg);
			err = write_i2c(dcc_info->pRUA, delay, dev, 0x74, reg); /* clear intr */
			if (RMFAILED(err)) RMDBGLOG((ENABLE, "Error writing I2C!\n"));
			if (reg & 0x40) {
				if (local_opt->last_hdcp_ok) {
					if (local_opt->verbouse) fprintf(stderr, "INTR4.6 - hdcp link quality error\n");
					local_opt->last_hdcp_ok = FALSE;
				}
			} else {
				if (! local_opt->last_hdcp_ok) {
					if (local_opt->verbouse) fprintf(stderr, "INTR4.6 - hdcp link quality is now OK\n");
					local_opt->last_hdcp_ok = TRUE;
				}
			}
			if (reg & 0x10) {
				if (local_opt->verbouse) fprintf(stderr, "INTR4.4 - no AVI info frame received!\n");
				if (local_opt->last_avi.valid) fprintf(stderr, "Lost AVI InfoFrames!\n");
				local_opt->last_avi.valid = FALSE;
			}
			if (local_opt->verbouse && (reg & 0x08)) fprintf(stderr, "INTR4.3 - a CTS value has been dropped.\n");
			if (local_opt->verbouse && (reg & 0x04)) fprintf(stderr, "INTR4.2 - a CTS value has been re-used.\n");
			if (local_opt->verbouse && (reg & 0x02)) fprintf(stderr, "INTR4.1 - Audio FIFO Overrun.\n");
			if (local_opt->verbouse && (reg & 0x01)) fprintf(stderr, "INTR4.0 - Audio FIFO Underrun.\n");
		}
		
		// Check INTR5
		err = read_i2c(dcc_info->pRUA, delay, dev, 0x7B, &reg);
		if (RMFAILED(err)) RMDBGLOG((ENABLE, "Error reading I2C!\n"));
		else if (reg & local_opt->intr_mask[4]) {
			//fprintf(stderr, "INTR5: 0x%02lX\n", reg);
			err = write_i2c(dcc_info->pRUA, delay, dev, 0x7B, reg); /* clear intr */
			if (RMFAILED(err)) RMDBGLOG((ENABLE, "Error writing I2C!\n"));
			if (local_opt->verbouse && (reg & 0x80)) fprintf(stderr, "INTR5.7 - ACR ref. clk has changed\n");
			if (local_opt->verbouse && (reg & 0x40)) fprintf(stderr, "INTR5.6 - audio auto config has muted the audio\n");
			if (local_opt->verbouse && (reg & 0x20)) fprintf(stderr, "INTR5.5 - audio-related link error!\n");
			if (local_opt->verbouse && (reg & 0x10)) fprintf(stderr, "INTR5.4 - vertical resolution has changed\n");
			if (local_opt->verbouse && (reg & 0x08)) fprintf(stderr, "INTR5.3 - horizontal resolution has changed\n");
			if (local_opt->verbouse && (reg & 0x04)) fprintf(stderr, "INTR5.2 - sync polarity has changed\n");
			if (local_opt->verbouse && (reg & 0x02)) fprintf(stderr, "INTR5.1 - progressive/interlaced has changed\n");
			if (reg & 0x01) {
				RMuint32 CurrSampleRate = audio_opt->SampleRate;
				enum AudioDecoder_Codec_type CurrCodec = audio_opt->Codec;
				if (local_opt->verbouse) fprintf(stderr, "INTR5.0 - audio fs has changed\n");
				err = setup_HDMI_audio(dcc_info, local_opt, audio_opt, dev, delay);
				if (audio_opt->AudioIn && ((CurrSampleRate != audio_opt->SampleRate) || (CurrCodec != audio_opt->Codec))) {
					if (CurrSampleRate) {  // audio passthrough was active, stop it
						err = stop_audio_passthrough(dcc_info, audio_opt);
						if (RMFAILED(err)) {
							fprintf(stderr, "Error stopping audio capture! %s\n", RMstatusToString(err));
						}
					}
					if (audio_opt->SampleRate) {  // set up new audio passthrough
						err = init_audio_passthrough(dcc_info, audio_opt, capture_opt);
						if (RMFAILED(err)) {
							fprintf(stderr, "Error starting audio capture! %s\n", RMstatusToString(err));
						}
					}
				}
			}
			if (reg & 0x1E) {
				fprintf(stderr, "Video signal timing has changed!\n");
				local_opt->update_videomode = TRUE;
			}
		}
		
		// Check INTR6
		err = read_i2c(dcc_info->pRUA, delay, dev, 0x7C, &reg);
		if (RMFAILED(err)) RMDBGLOG((ENABLE, "Error reading I2C!\n"));
		else if (reg & local_opt->intr_mask[5]) {
			//fprintf(stderr, "INTR6: 0x%02lX\n", reg);
			err = write_i2c(dcc_info->pRUA, delay, dev, 0x7C, reg & 0x05); /* clear intr */
			if (RMFAILED(err)) RMDBGLOG((ENABLE, "Error writing I2C!\n"));
			if (reg & 0x04) {  // Audio Content Protection Frame
				RMuint8 header[3], data[26];
				if (local_opt->verbouse) fprintf(stderr, "INTR6.2 - new or changed Audio Content Protection Info Frame detected.\n");
				if (RMSUCCEEDED(read_SiI9031_info_frame(dcc_info, dev, delay, 0xE0, 0x04, 0x00, header, data, sizeof(data) / sizeof(RMuint8)))) {
					handle_hdmi_audio_cp_info_frame(dcc_info, local_opt, capture_opt, disp_opt, ppVideoSource, input, header, data);
				}
				// Further ints on changed frame only
				err = read_i2c(dcc_info->pRUA, delay, dev, 0x7A, &mask);
				err = write_i2c(dcc_info->pRUA, delay, dev, 0x7A, mask & ~0x20);
			}
			if (local_opt->last_hotplug == (reg & 0x01)) {
				local_opt->last_hotplug = ! (reg & 0x01);
				if (local_opt->verbouse) fprintf(stderr, "INTR6.0 - %splug\n", (reg & 0x01) ? "un" : "");
				if (reg & 0x01) {
					flush_scaler(dcc_info, input);
					local_opt->last_avi.valid = FALSE;
					local_opt->hdmi_mode = mode_unknown;
				} else {
					detect_hdmi_mode(dcc_info, local_opt, audio_opt, dev, delay);
				}
			}
		}
	}
	
	if (audio_opt->AudioIn && audio_opt->SampleRate) {
		struct AudioEngine_InputSPDIFStatus_type stat;
		
		err = RUAGetProperty(dcc_info->pRUA, 
			EMHWLIB_MODULE(AudioEngine, audio_opt->AudioEngineID), 
			RMAudioEnginePropertyID_InputSPDIFStatus, 
			&stat, sizeof(stat));
		if (RMSUCCEEDED(err) && 
			(((local_opt->CurrChStat & 0x02) != (stat.ChannelStatus & 0x02)) || 
			((stat.Pc & 0x1F) && (RMunshiftBits(stat.Pc, 3, 13) == audio_opt->CaptureBitstream) && ((stat.Pc & 0x1F) != (local_opt->CurrPc & 0x1F))))
		) {
			enum AudioDecoder_Codec_type CurrCodec = audio_opt->Codec;
			local_opt->CurrChStat = stat.ChannelStatus;
			if (stat.ChannelStatus & 0x02) {
				if ((stat.Pc & 0x1F) && (RMunshiftBits(stat.Pc, 3, 13) == audio_opt->CaptureBitstream)) local_opt->CurrPc = stat.Pc;
			} else {
				local_opt->CurrPc = 0;
			}
			err = get_spdif_codec(dcc_info, audio_opt, &stat);
			if (RMSUCCEEDED(err) && (! audio_opt->auto_detect_codec) && (CurrCodec != audio_opt->Codec)) {
				err = init_audio_passthrough(dcc_info, audio_opt, capture_opt);
				if (RMFAILED(err)) {
					fprintf(stderr, "Error starting audio capture! %s\n", RMstatusToString(err));
				}
			}
		}
	}
	
	if (local_opt->update_videomode) {
		RMbool update = FALSE;
		RMascii *StandardName;
		enum EMhwlibTVStandard TVStandard;
		
		fprintf(stderr, "%s video mode detection!\n", (local_opt->hdmi_mode == mode_HDMI) ? "HDMI" : "DVI");
		do {
			RMbool u;
			TVStandard = capture_opt->TVStandard;
			err = get_format_SiI9031(dcc_info, capture_opt, local_opt, 0x30, local_opt->i2c_video_delay, &u);
			if (RMSUCCEEDED(err) && u) update = TRUE;
		} while (RMSUCCEEDED(err) && (TVStandard != capture_opt->TVStandard));
		detect_hdmi_mode(dcc_info, local_opt, audio_opt, dev, delay);
		if ((local_opt->hdmi_mode == mode_HDMI) || local_opt->new_avi || local_opt->last_avi.valid) {
			RMuint8 header[3], data[16];
			local_opt->new_avi = FALSE;
			if (RMSUCCEEDED(read_SiI9031_info_frame(dcc_info, dev, delay, 0x40, 0x82, 0x02, header, data, sizeof(data) / sizeof(RMuint8)))) {
				// TODO compare VIC against capture_opt[input].TVStandard
				if (update) {
					capture_opt->TVStandard = EMhwlibTVStandard_Custom;
				}
				err = handle_hdmi_avi_info_frame(dcc_info, local_opt, capture_opt, disp_opt, audio_opt, ppVideoSource, input, dev, delay, data);
				update = (RMFAILED(err) || (local_opt->last_avi.vic == 0));
			}
		} else {
			update = TRUE;
		}
		if (update) {
			err = close_input(dcc_info, ppVideoSource, capture_opt, disp_opt, local_opt, input);
			if (capture_opt->TVStandard != EMhwlibTVStandard_Custom) {
				if (local_opt->hdmi_mode == mode_DVI) {
					prepare_dvi_mode(local_opt, capture_opt, FALSE);
				}
				err = setup_input(dcc_info, ppVideoSource, capture_opt, disp_opt, local_opt, input);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "FATAL: Error setting up capture!\n"));
					exit(1);
				}
			}
			if (RMSUCCEEDED(GetTVStandardName(capture_opt->TVStandard, &StandardName))) {
				printf("New TV Standard: %s\n", StandardName);
			} else {
				printf("New TV Standard: # %d\n", capture_opt[input].TVStandard);
			}
			TVStandard = capture_opt->TVStandard;
			err = get_format_SiI9031(dcc_info, capture_opt, local_opt, 0x30, local_opt->i2c_video_delay, &update);
			if (RMFAILED(err) || (TVStandard == capture_opt->TVStandard)) {
				err = write_i2c(dcc_info->pRUA, delay, dev, 0x72, 0x01); /* clear intr */
				err = write_i2c(dcc_info->pRUA, delay, dev, 0x7B, 0x1E); /* clear intr */
				local_opt->update_videomode = FALSE;
			}
		} else {
			local_opt->update_videomode = FALSE;
		}
		if (audio_opt->AudioIn && audio_opt->SampleRate) {
			err = init_audio_passthrough(dcc_info, audio_opt, capture_opt);
			if (RMFAILED(err)) {
				fprintf(stderr, "Error starting audio capture! %s\n", RMstatusToString(err));
			}
		}
	}
	
	if (local_opt->new_avi) {
		RMuint8 header[3], data[16];
		if (RMSUCCEEDED(read_SiI9031_info_frame(dcc_info, dev, delay, 0x40, 0x82, 0x02, header, data, sizeof(data) / sizeof(RMuint8)))) {
			handle_hdmi_avi_info_frame(dcc_info, local_opt, capture_opt, disp_opt, audio_opt, ppVideoSource, input, dev, delay, data);
		}
		local_opt->new_avi = FALSE;
	}
	
	return RM_OK;
}

static void handle_vbi_data(struct local_cmdline *local_opt, struct capture_cmdline *capture_opt)
{
	// handle VBIPTS, pVBIData[VBISize]
//	fprintf(stderr, "handle_vbi_data khoa here\n");
	
	if (local_opt->arg_vbi) {  // binary dump to file
		RMuint32 i;
		fwrite("VBI:", 1, 4, local_opt->vbidump);
		fwrite(&(local_opt->VBIPTS), 4, 1, local_opt->vbidump);
		fwrite(&(local_opt->VBISize), 4, 1, local_opt->vbidump);
		for (i = 0; i < local_opt->VBISize; i += 2) {
			RMuint8 lsb, msb;
			lsb = local_opt->pVBIData[i / 2] & 0xFF;
			msb = local_opt->pVBIData[i / 2] >> 8;
			fwrite(&lsb, 1, 1, local_opt->vbidump);
			fwrite(&msb, 1, 1, local_opt->vbidump);
		}
	}
//		fprintf(stderr, "handle_anc_data ----parse_anc = %d khoa here\n",local_opt->parse_anc);
	if (local_opt->parse_anc) {
		RMuint32 line, i, n, field, inc, fid, offs, count, ancstart;
		RMuint16 d;
		switch ((local_opt->VBIFlags >> 2) & 0x03) {  // Flags[3:2]: 00: interlaced data from two fields, 01: data from progressive frame, 10: data from top field, 11: data from bottom field
			default:
			case 0:  // interlaced
				inc = 2; fid = (local_opt->VBIFlags & 0x02) ? FALSE : TRUE; break;  // Flags[1]: 0: bottom field first, 1: top field first
			case 1:  // progressive
				inc = 1; fid = 0; break;
			case 2:  // top field
				inc = 1; fid = 0; break;
			case 3:  // bottom field
				inc = 1; fid = 1; break;
		}
//		fprintf(stderr, "handle_anc_data ----inc = %ld khoa here\n",inc);
		
		for (field = 0; field < inc; field++) {
	//				fprintf(stderr, "for khoa here\n");
			for (line = fid; line < local_opt->VBISize / 2 / capture_opt->vbi_w; line += inc) {
				offs = line * capture_opt->vbi_w;
				n = 0;
				ancstart = 0;
				count = capture_opt->vbi_w;
				for (i = 0; i < count; i++) {
					d = local_opt->pVBIData[offs + i];
//					fprintf(stderr,"%x",d);
//						if((i%10)==0)fprintf(stderr,"\n"); //khoa
					if (n == 0) {
						if (d == 0xFF00) n++;
						else n = 0;
					} else if (n == 1) {
						if ((d & 0x00FF) == 0x00FF) {
							n++; 
							if (local_opt->print_anc) printf("  ANC data in row %2lu%c, DID=%02X ", (line / 2) + 1, (line & 1) ? 'B' : 'T', d >> 8);
								fprintf(stderr, "ANC data in row %2lu%c, DID=%02X \n", (line / 2) + 1, (line & 1) ? 'B' : 'T', d >> 8);
						} else n = 0;
					} else if (n == 2) {
						if (local_opt->print_anc) printf("SDID=%02X DC=%02X ", d & 0xFF, d >> 8);
						fprintf(stderr, "SDID=%02X DC=%02X \n", d & 0xFF, d >> 8);
						
						ancstart = offs + i;
						count = i + ((d >> 8) & 0x3F) * 2;
						if (count > capture_opt->vbi_w) {
							if (local_opt->print_anc) printf("MISSING %ld bytes at end! ", (count - capture_opt->vbi_w) * 2);
							ancstart = 0;
							count = capture_opt->vbi_w;
						}
						n++;
					} else if (n == 3) {
						if (local_opt->print_anc) printf("ID1=%02X ID2=%02X ", d & 0xFF, d >> 8);
							fprintf(stderr, "ID1=%02X ID2=%02X ", d & 0xFF, d >> 8);
						n++;
					} else if (n >= 4) {
						if (local_opt->print_anc) printf("%02X%02X ", d & 0xFF, d >> 8);
						fprintf(stderr, "%02X%02X ", d & 0xFF, d >> 8);
						
						n++;
					}
				}
				if (local_opt->print_anc && n >= 2) printf("\n");
				if (ancstart) {
					RMuint8 SDID, DC, ID1, ID2, CS, cs, BC,CS1;
					RMuint32 i,j, line, type, dc, bc, payload;
					RMbool fid;
	
					SDID = local_opt->pVBIData[ancstart + 0] & 0xFF;
					DC = local_opt->pVBIData[ancstart + 0] >> 8;
					dc = DC & 0x3F;
					
					ID1 = local_opt->pVBIData[ancstart + 1] & 0xFF;
					ID2 = local_opt->pVBIData[ancstart + 1] >> 8;
					fid = ((ID1 >> 6) & 0x01);
					// TODO check parity of DC, ID1, ID2
					line = ((ID1 & 0x3F) << 3) | ((ID2 >> 4) & 0x07); //org //khoa
					//	line = ((ID2 << 8) & 0x3ff) |ID1 ;
					type = ID2 & 0x0F;
					BC = local_opt->pVBIData[ancstart + dc * 2 - 1] >> 8; //org
					CS = local_opt->pVBIData[ancstart + dc * 2 - 1] & 0xFF;  //org
					if(local_opt->i2c_board==cap_sigma895e1) {
						dc = DC& 0x3F;
						dc=dc*4 + 8; //56 bytes
						BC = local_opt->pVBIData[ancstart + dc  - 3] >> 8; //org
						CS = local_opt->pVBIData[ancstart + dc - 3] & 0xFF;  //org
					}
					printf("CS:%02X, BC=%02X dc = %ld, khoa vo\n",CS,BC,dc);
					CS1=0;
					j=0;
					for(i = 0; i < 100; i ++)
					{
						CS1=local_opt->pVBIData[ancstart + i] & 0xFF;	
						printf("i=%ld byte0= %02X \n",j+i,CS1);
						CS1=local_opt->pVBIData[ ancstart + i]>>8;
						printf("i=%ld byte1= %02X \n",j+i+1,CS1);
						j++;
					}


//						printf("CS= %02X  CS1= %02X \n",CS,CS1);
//					if(CS>128)CS1=CS-128;
//					else if (CS<128) CS1=CS+128;
//					CS=CS1;



//					printf("ancstart=%ld,dc =%02lX DC =%02X CS= %02X  CS1= %02X BC=%02X \n",ancstart,dc,DC,CS,CS1,BC);
					bc = BC & 0x3F; //for SAA
					if(local_opt->i2c_board==cap_sigma895e1)
					{
						bc =  BC;
						
					}// & 0x3F;//0xae;//BC & 0x3F;  // should be payload * 2 //org
					payload = dc * 2 - 3;
					cs = local_opt->pVBIData[ancstart - 1] >> 8;  // DID
					for (i = 0; i < dc * 2; i ++) {
						cs += (local_opt->pVBIData[ancstart + i] & 0xFF);
						cs += (local_opt->pVBIData[ancstart + i] >> 8);
					}
						
					handle_anc_data(type, fid, line, &(local_opt->pVBIData[ancstart + 2]), bc / 2);
					if (local_opt->print_anc) printf("CS:%02X, bc=%lu, line=%lu, type = %lu, fid=%c\n", cs, bc, line, type, fid ? 'B' : 'T');
					printf("CS:%02X, bc=%lu, line=%lu, type = %lu, fid=%c\n", cs, bc, line, type, fid ? 'B' : 'T');
				}
			}
			
			fid = 1 - fid;
		}
	}
	if (local_opt->dump_vbi) {  // hex dump to screen
		RMuint32 i;
		RMbool bottom_first = ! (local_opt->VBIFlags & 0x02);
		RMuint32 frame_info = (local_opt->VBIFlags >> 2) & 0x03;
		printf("VBI data, %ld bytes, PTS 0x%08lX, line: %ld bytes, %s field 1st, %s fld./fr.:\n", 
			local_opt->VBISize, local_opt->VBIPTS, capture_opt->vbi_w, 
			bottom_first ? "bottom" : "top", 
			(frame_info == 0) ? "intl." : (frame_info == 1) ? "progr." : (frame_info == 2) ? "top" : "bottom");
			
		for (i = 0; i < local_opt->VBISize; i += 2) {
			if (i % (capture_opt->vbi_w * 2) == 0) printf("  ");
			printf("%02X%02X ", local_opt->pVBIData[i / 2] & 0xFF, local_opt->pVBIData[i / 2] >> 8);
			if (i % (capture_opt->vbi_w * 2) == (capture_opt->vbi_w * 2) - 2) printf("\n");
		}
		printf("\n");
	}
}


static RMstatus autoDetectHDMISampleRate(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,
										 RMuint32 *sampleOld,RMuint32 *samplePre,RMuint32 *sampleCur,RMuint32 *sampleCountDif,RMbool *isUpdate)
{
	RMstatus err=RM_OK;
	RMuint32 sampleNew=0;
	*isUpdate=FALSE;	
	err=ad9380_getAudioSampleRateHDMI(pInstance,dev,delay,&sampleNew);
	
	if (err!=RM_OK) { //must set sampleNew = 0 to stop audio if neccessary.
		sampleNew=0;
	}
	
	*sampleCur=sampleNew;
	if (*sampleCur==*sampleOld) {
		*sampleCountDif=0;
	}else	{
		if (*sampleCur!=*samplePre) {
			*samplePre=*sampleCur;
			*sampleCountDif=0;
		}else {
			*sampleCountDif = *sampleCountDif + 1;
		}
	}
	
	if (*sampleCountDif>=10) {
		*isUpdate=TRUE;
		*sampleOld=*sampleCur;
		*samplePre=*sampleCur;
	}
	
	return err;
}


//#include "debug_capture.h"

int main(int argc, char *argv[])
{
	RMstatus err;
	RMbool run, wait;
	RMascii key;
	struct DCCVideoSource *pVideoSource[2] = {NULL, NULL};
	struct DCC *pDCC = NULL;
	static struct dcc_context dcc_info = {0,};
	struct display_context disp_info;
	RMascii *StandardName;
	struct Input_GPIOFieldID_type gpio;
	struct dh_context dh_info = {0,};
	RMbool KeepInvalidPicture;
	RMuint8 i2c_device, i2c_delay;
//	RMint32 shift_x = 0, shift_y = 0;
	RMuint32 default_audio_delay;
	RMbool update_out_window = FALSE;
	RMbool update_scaler_zoom = FALSE;
	RMuint32 input=0;
//////////////////////////////////////////////////////////////////////////

	RMuint32 contrast=0x5c;
	RMint32 brightness=0;
//	RMuint32 saturation=128;
//	RMint32 hue=0;
//	RMuint32 sharpness=1;

	//Audio test :

	RMuint8 isHeadPhoneOut=1;
	RMuint8 isScart1In=1;
	RMuint8 headphoneVolume=0;
	RMuint8 loudspeakerVolume=0;
//////////////////////////////////////////////////////////////////////////
	static RMuint32 w=720;
//////////////////////////////////////////////////////////////////////////
	//Detect HDMI SampleRate
	RMuint32 sampleCur=0;
	RMuint32 sampleOld=0;
	RMuint32 samplePre=0;
	RMuint32 sampleCountDif=0;
	RMbool isUpdateSampleRate=FALSE;
	RMuint32 sampleErrCount=0;
//////////////////////////////////////////////////////////////////////////

	headphoneVolume=0x73;
	loudspeakerVolume=0x60;
	isScart1In=1;
	isHeadPhoneOut=0;
	chip_num = 0;
	input_num = 0;
	local_opt[0].output_window = &(disp_info.osd_window[0]);
	init_local_options(&local_opt[0]);
	local_opt[1].output_window = &(disp_info.osd_window[1]);
	init_local_options(&local_opt[1]);
	init_display_options(&disp_opt);
	init_capture_options(&capture_opt[0]);
	init_capture_options(&capture_opt[1]);
	init_audio_options(&audio_opt);
	disp_opt.dh_info = &dh_info;
	audio_opt.dh_info = &dh_info;
	KeepInvalidPicture = FALSE;
	
	default_audio_delay = audio_opt.CaptureDelay;

	RMMemset(&disp_info, 0, sizeof(struct dcc_context));
	
	parse_cmdline(argc, argv);

	printf("capture_opt[0].vbianc_w=%ld \n",capture_opt[0].vbianc_w);
	printf("capture_opt[1]=vbianc_w=%ld \n",capture_opt[1].vbianc_w);
//	SCANPARAM(options->vbianc_w, "please specify a w value", 1);
//	SCANPARAM(options->vbianc_h, "please specify a h value", 2);
//	SCANPARAM(options->vbianc_ytop, "please specify a ytop value", 3);
//	SCANPARAM(options->vbianc_ybot)
	RMSignalInit(cleanup, NULL);  // catch all temination signals, call RMTermInit() and cleanup(), then exit(0).
	
	I2C_ModuleID = EMHWLIB_MODULE(I2C, local_opt[0].i2c_module);
	
	if (RMFAILED(err = RUACreateInstance(&pInstance, chip_num))) {
		printf("Error creating instance! %s\n", RMstatusToString(err));
		exit(1);
	}	


	err = DCCOpen(pInstance, &pDCC);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error Opening DCC! %s\n", RMstatusToString(err));
		return -1;
	}
	
	err = DCCInitMicroCodeEx(pDCC, disp_opt.init_mode);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot initialize microcode! %s\n", RMstatusToString(err));
		return -1;
	}
	
	if (local_opt[0].green_bg || local_opt[1].green_bg) {
		// TODO this has little effect, since the scaler is normally covering the background.
		// On tango3, change scaler's "black bar" color instead.
		struct EMhwlibColor color;
		color.R_Cr = 16;
		color.G_Y  = 240;
		color.B_Cb = 16;
		RUASetPendingProperty(pInstance, DispMainMixer, RMGenericPropertyID_BackgroundColor, &color, sizeof(color), "Failed to set BackgroundColor on mixer");
	}
	

	dcc_info.chip_num = chip_num;
	dcc_info.pRUA = pInstance;
	dcc_info.pDCC = pDCC;
	dcc_info.route = DCCRoute_Main;  // TODO use op.RouteModuleID
	dcc_info.scc = NULL;
	dcc_info.rtk = NULL;
	
	dcc_info.state = RM_PLAYING;
	dcc_info.trickmode_id = RM_NO_TRICKMODE;
	dcc_info.seek_supported = FALSE;
	dcc_info.disp_info = &disp_info;
	dcc_info.pStcSource = NULL;
	dcc_info.pAudioSource = NULL;

	set_default_out_window(&(dcc_info.disp_info->out_window));
	err = apply_display_options(&dcc_info, &disp_opt);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot set display opions! %s\n", RMstatusToString(err));
		return RM_ERROR;
	}else
		fprintf(stderr, "Set display opions OK! \n");




input_num=0;


if (! dcc_info.pStcSource) {
	struct DCCStcProfile stc_profile;
	
	// open first stc module
	stc_profile.STCID = 0;
	stc_profile.master = Master_STC;
	
	stc_profile.stc_timer_id = 0;
	stc_profile.stc_time_resolution = 90000;
	
	stc_profile.video_timer_id = TimerNumber;
	stc_profile.video_time_resolution = 90000;
	stc_profile.video_offset = 0;
	
	stc_profile.audio_timer_id = 1;
	stc_profile.audio_time_resolution = 90000;
	stc_profile.audio_offset = 0;
	
	err = DCCSTCOpen(dcc_info.pDCC, &stc_profile, &dcc_info.pStcSource);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot open stc module %d\n", err);
		return RM_ERROR;
	}
}

DCCSTCSetTime(dcc_info.pStcSource, 0, 90000);
DCCSTCPlay(dcc_info.pStcSource);

	for (input = 0; input <= input_num; input++) {
		if (capture_opt[input].InputModuleID == DispGraphicInput) {
			gpio.GPIONumber = 3;
		} else {
			gpio.GPIONumber = 2;
		}
		gpio.Enable = local_opt[input].use_gpio_fid;
		gpio.Invert = local_opt[input].invert_fid;
		capture_opt[input].TVStandard = EMhwlibTVStandard_Custom;
		fprintf(stderr, "Performing auto detect of video mode from capture chip (Use -I \n");
		init_capture(pInstance, &capture_opt[input], &local_opt[input], local_opt[input].i2c_video_chip, local_opt[input].i2c_video_dev, local_opt[input].i2c_video_delay);
#ifndef NO_AUDIO
		err=setCaptureAudioPort(pInstance,local_opt->i2c_port,isHeadPhoneOut,isScart1In,headphoneVolume,loudspeakerVolume); 
#endif			
		
		// find out if capture is YUV-4:2:2 or YUV-4:4:4/RGB-8:8:8
		if (input == 0) {
			enum EMhwlibColorSpace MixerColorSpace;
			
			if (capture_opt[input].SurfaceColorSpace == EMhwlibColorSpace_None) 
				capture_opt[input].SurfaceColorSpace = capture_opt[input].InputColorSpace;
			get_mixer_color_space(capture_opt[input].SurfaceColorSpace, disp_opt.color_space, &MixerColorSpace);
			set_graphics_mode(MixerColorSpace, &capture_opt[input]);
			RUASetPendingProperty(pInstance, DispMainMixer, 
				RMGenericPropertyID_ColorSpace, &MixerColorSpace, sizeof(MixerColorSpace), 
				"Failed to set ColorSpace on mixer");
			RUASetPendingProperty(pInstance, DispMainMixer, 
				RMGenericPropertyID_Validate, NULL, 0, 
				"Failed to validate input");
		}
		
		// get Scaler ModuleID
		if (capture_opt[input].DeInt) {
			if (capture_opt[input].SamplingMode != EMhwlibSamplingMode_422) {
				fprintf(stderr, "De-Interlacing with 4:2:2 video only!\n");
				exit(1);
			}
			if (capture_opt[input].SurfaceColorSpace == EMhwlibColorSpace_None) {
				if (
					(capture_opt[input].InputColorSpace != EMhwlibColorSpace_YUV_601) && 
					(capture_opt[input].InputColorSpace != EMhwlibColorSpace_YUV_709)
					) {
					if (
						(disp_opt.color_space != EMhwlibColorSpace_YUV_601) && 
						(disp_opt.color_space != EMhwlibColorSpace_YUV_709)
						) {
						capture_opt[input].SurfaceColorSpace = EMhwlibColorSpace_YUV_709;
					} else {
						capture_opt[input].SurfaceColorSpace = disp_opt.color_space;
					}
				} else {
					capture_opt[input].SurfaceColorSpace = capture_opt[input].InputColorSpace;
				}
			}
			if (
				(capture_opt[input].SurfaceColorSpace != EMhwlibColorSpace_YUV_601) && 
				(capture_opt[input].SurfaceColorSpace != EMhwlibColorSpace_YUV_709)
				) {
				fprintf(stderr, "No De-Interlacing with RGB color spaces!\n");
				exit(1);
			}
			dcc_info.disp_info->osd_scaler[input] = EMHWLIB_MODULE(DispMainVideoScaler, 0);
		} else if (capture_opt[input].SamplingMode == EMhwlibSamplingMode_422) {
			if (input && (EMHWLIB_MODULE_CATEGORY(dcc_info.disp_info->osd_scaler[0]) == DispMainVideoScaler)) {
				err = DCCGetScalerModuleID(dcc_info.pDCC, DCCRoute_Main, 
					DCCSurface_Video, 					
			input, &(dcc_info.disp_info->osd_scaler[input]));
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot get surface to display video source! %s\n", RMstatusToString(err));
			//exit(1);
		}
			} else {
				dcc_info.disp_info->osd_scaler[input] = EMHWLIB_MODULE(DispMainVideoScaler, 0);
			}
		} else {
			if (input && (EMHWLIB_MODULE_CATEGORY(dcc_info.disp_info->osd_scaler[0]) == DispOSDScaler)) {
				err = DCCGetScalerModuleID(dcc_info.pDCC, DCCRoute_Main, 
					DCCSurface_OSD, 
					input, &(dcc_info.disp_info->osd_scaler[input]));
				if (RMFAILED(err)) {
					fprintf(stderr, "Cannot get surface to display video source! %s\n", RMstatusToString(err));
					//exit(1);
				}
			} else {
				dcc_info.disp_info->osd_scaler[input] = EMHWLIB_MODULE(DispOSDScaler, 0);
			}
		}
		
		
		if (dcc_info.disp_info->osd_scaler[input] == DispVCRMultiScaler) 
			dcc_info.disp_info->osd_scaler[input] = DispGFXMultiScaler;
		fprintf(stderr, "Using scaler 0x%08lX for input %lu\n", dcc_info.disp_info->osd_scaler[input], input);
		dcc_info.SurfaceID = dcc_info.disp_info->osd_scaler[input];
		dcc_info.disp_info->active_window = &(dcc_info.disp_info->osd_window[input]);
		dcc_info.disp_info->osd_enable[input] = TRUE;
		
		// Open the 86xx capture port and call setup_capture()
//		setup_format_options(&dcc_info, &capture_opt[input], &local_opt[input]);
		setup_format_options(&dcc_info, &capture_opt[input], &disp_opt, &local_opt[input], input);		
//////////////////////////////////////////////////////////////////////////
		

		//khoa
		//////////////////////////////////////////////////////////////////////////

		if (input == 0) {
			dcc_info.pVideoSource = pVideoSource[input];
		}
		

		// Set debug option
		RUASetPendingProperty(pInstance, capture_opt[input].InputModuleID, 
			RMGenericPropertyID_KeepInvalidPicture, &KeepInvalidPicture, sizeof(KeepInvalidPicture), 
			"Failed to set property KeepInvalidPicture");
		RUASetPendingProperty(pInstance, capture_opt[input].InputModuleID, 
			RMGenericPropertyID_Validate, NULL, 0, 
			"Failed to validate input");
		/*
		
						if (open_CCFifo(&dcc_info, &local_opt[input], input)!=RM_OK) {
									printf("open_CCFifo Error \n");
								}
				*/
		
		//apply_CCFifo(&dcc_info, &local_opt[input], input);
		
		
		apply_display_options(&dcc_info, &disp_opt);

		if (local_opt[input].arg_vbi) {
			local_opt[input].vbidump = fopen(argv[local_opt[input].arg_vbi], "wb");
			if (local_opt[input].vbidump == NULL) {
				printf("Can't create VBI dump file: %s\n", argv[local_opt[input].arg_vbi]);
				//exit(1);
			}
		} 
		//else  if (capture_opt[input].TVStandard == EMhwlibTVStandard_Custom) 
		//			capture_opt[input].TVStandard = EMhwlibTVStandard_ITU_Bt656_525;
		  // fallback to NTSC
			
	}
	
	if (local_opt[0].i2c_init) {
		i2c_device = local_opt[0].i2c_video_dev;
		i2c_delay = local_opt[0].i2c_video_delay;
	} else {
		i2c_device = 0x20;
		i2c_delay = 0;
	}
	
#if 1	//Reset Audio.
	if (audio_opt.AudioIn) {
		RMuint32 bkSampleRate;
		bkSampleRate=audio_opt.SampleRate;
		audio_opt.SampleRate=48000;				
		printf("\nInit And Reset Audio passthrough for HDMI\n");

		err = init_audio_passthrough(&dcc_info, &audio_opt, &(capture_opt[0]));
		if (RMFAILED(err)) {
			fprintf(stderr, "Error starting audio capture! %s\n", RMstatusToString(err));
		}else {
			stop_audio_passthrough(&dcc_info, &audio_opt);
		}						
		switch(local_opt->i2c_port) {
		case cap_HDMI0:
		case cap_HDMI1:
			audio_opt.SampleRate=0;				
			/*
			printf("***Init Reset AD***\n");
						ad9380_PowerDown(dcc_info.pRUA,local_opt[0].i2c_video_dev, local_opt[0].i2c_video_delay);
						usleep(1000);
						ad9380_PowerUp(dcc_info.pRUA,local_opt[0].i2c_video_dev, local_opt[0].i2c_video_delay);*/
			if (ad9380_ResetClockTermination(pInstance,local_opt[0].i2c_video_dev,local_opt[0].i2c_video_delay)==RM_OK) {
				printf("Reset Clock Ter !\n");
			}
			break;		
		default:
			audio_opt.SampleRate=bkSampleRate;
			break;
		}
	}
#endif	
	apply_dvi_hdmi_audio_options(&dcc_info, &audio_opt, 2, FALSE, FALSE, FALSE);
	printf(" \n ******************** MENU ************************\n");
	printf("  c: decrease contrast   - C: increase contrast\n");
	printf("  b: decrease brightness - B: increase brightness\n");
//	printf("  t: decrease saturation - T: increase saturation\n");
//	printf("  h: decrease hue		 - H: increase hue\n");
//	printf("  s: decrease sharpness	 - S: increase sharpness\n");
	printf("  2: 2 D Comfilter (for CVBS Capture) \n");
	printf("  3: 3 D Comfilter (for CVBS Capture) \n");
	printf("  /: Switch debug chip TW - AD - MSP  \n");
//#ifndef NO_AUDIO
//	printf("  v: decrease Volume	 - V: increase Volume\n");
//#endif
//	printf("  z: Switch CVBS -> SVIDEO -> TUNER.\n");
//#ifndef NO_AUDIO
//	printf("  x: Switch Audio Output HeadPhone <--> LoudSpeaker.\n");
//	printf("  y: Switch Audio Input Scart1 <--> Audio Input Scart4.\n");
//#endif	
	printf(" a : Show all register Value of cur chip debug \n ");
	printf(" r : Read a regisger . Ex : regAdd = 2f <enter>\n");
	printf(" w : write a regVal to regAdd . Ex regAdd = 2a <enter> regVal= 1c <enter>\n");
	printf(" M: enter video mode modificator\n");
	
	printf("  q: Exit .\n");
	printf(" \n **************************************************\n");

	

	RMTermInit(TRUE);    // don't allow ctrl-C and the like ...
	RMSignalInit(NULL, NULL);  // ... but catch other termination signals to call RMTermExit(), but not RUADestroyInstance()
	
	input = 0;
	dcc_info.SurfaceID = dcc_info.disp_info->osd_scaler[input];
	dcc_info.disp_info->active_window = &(dcc_info.disp_info->osd_window[input]);
	
	run = TRUE;
	while (run) {
		RMuint32 in, cmd;
		static RMuint8 isUseTW;
		wait = TRUE;
		if (RMGetKeyNoWait(&key)) {
			wait = FALSE;
			//err = handle_key(&dcc_info, &cmd, SET_KEY_DEBUG | SET_KEY_AUDIO, key);
			err = handle_key(&dcc_info, &cmd, SET_KEY_DEBUG, key);
			if (cmd == RM_QUIT)
			{
				printf("Quit...\n");
				run = FALSE;
				goto CAPTURE_EXIT0;
			}
			if (err == RM_PENDING){
				switch (key) {
					case 'c':						
							setContrast(pInstance,i2c_device,i2c_delay,local_opt[0].i2c_port,-1,&contrast);
							printf("Contrast = %lx\n",contrast);						
						break;
					case 'C':
						setContrast(pInstance,i2c_device,i2c_delay,local_opt[0].i2c_port,1,&contrast);
						printf("Contrast = %lx\n",contrast);
						break;
					case 'b':
						setBrightness(pInstance,i2c_device,i2c_delay,local_opt[0].i2c_port,-1,&brightness);
						printf("Brightness = %ld\n",brightness);					
						break;
					case 'B':
						setBrightness(pInstance,i2c_device,i2c_delay,local_opt[0].i2c_port,1,&brightness);
						printf("Brightness = %ld\n",brightness);
						break;
					case 'o':
						{
							w=w-10;														
							//set_scaler_source_zoom(pInstance, dcc_info.disp_info->osd_scaler[0], ZOOM_0, ZOOM_0, w, ZOOM_1);
							set_scaler_source_zoom(pInstance, dcc_info.disp_info->osd_scaler[0], 0, 0, w, 480);
						}
						break;
					case 'O':
						{
							w=w+10;
							set_scaler_source_zoom(pInstance, dcc_info.disp_info->osd_scaler[0], ZOOM_0, ZOOM_0, w, ZOOM_1);
						}
						break;

#ifndef NO_AUDIO				
					case 'v':
						if (isHeadPhoneOut) {
							headphoneVolume-=2;
							msp4450g_headphone_DecreaseVolume(pInstance);
						}else {
							loudspeakerVolume-=2;
							msp4450g_loudspeaker_DecreaseVolume(pInstance);
						}
						
						
						break;
					case 'V':					
						if (isHeadPhoneOut) {
							headphoneVolume+=2;
							msp4450g_headphone_IncreaseVolume(pInstance);
						}else {
							loudspeakerVolume+=2;
							msp4450g_loudspeaker_IncreaseVolume(pInstance);
						}
						break;

#endif
					case 'z':
					case 'Z':
						if (local_opt[0].i2c_port>=cap_HDMI0) {
							local_opt[0].i2c_port=cap_CVBS1;
							err=init_capture_chip_tw9919eid_ad9380(pInstance,&capture_opt[0],&local_opt[0]);

							//err=setCaptureVideoPort(pInstance,i2c_device,i2c_delay,local_opt[0].i2c_port);
#ifndef NO_AUDIO
							err=setCaptureAudioPort(pInstance,local_opt[0].i2c_port,isHeadPhoneOut,isScart1In,headphoneVolume,loudspeakerVolume);
#endif
						}else
						{
							local_opt[0].i2c_port+=1;
							err=init_capture_chip_tw9919eid_ad9380(pInstance,&capture_opt[0],&local_opt[0]);
							//err=setCaptureVideoPort(pInstance,i2c_device,i2c_delay,local_opt[0].i2c_port);
#ifndef NO_AUDIO
							err=setCaptureAudioPort(pInstance,local_opt[0].i2c_port,isHeadPhoneOut,isScart1In,headphoneVolume,loudspeakerVolume);
#endif
						}

						
						
						break;
#ifndef NO_AUDIO
					case 'x':
					case 'X':
							if (isHeadPhoneOut) {								
								isHeadPhoneOut=0;
							}else {
								isHeadPhoneOut=1;
							}
							err=setCaptureAudioPort(pInstance,local_opt[0].i2c_port,isHeadPhoneOut,isScart1In,headphoneVolume,loudspeakerVolume);
													
						break;
					case 'y':
					case 'Y':
						if (isScart1In) {								
							isScart1In=0;
						}else {
							isScart1In=1;
						}
						err=setCaptureAudioPort(pInstance,local_opt[0].i2c_port,isHeadPhoneOut,isScart1In,headphoneVolume,loudspeakerVolume);
						
						break;
#endif

					case 'k':
						
						err = stop_audio_passthrough(&dcc_info, &audio_opt);
						audio_opt.SampleRate=0;
						
						break;
					case 'l':
						printf("Sample Rate : ");
						scanf("%ld",&audio_opt.SampleRate);
						err = init_audio_passthrough(&dcc_info, &audio_opt, &(capture_opt[0]));
						break;

					case '/':
						switch(isUseTW) {
						case 0:
							isUseTW=1;
							printf("* * Debug Analog device * *\n");
							break;

#ifndef NO_AUDIO
						case 1:
							isUseTW=2;							
							printf("* * Debug MSP * *\n");						
							break;
#endif
						default:
							isUseTW=0;
							printf("* * Debug techwell * *\n");
							break;
						}						
					
						break;
					default:

						switch(isUseTW) {
						case 0:
							tw9919eid_Debug(pInstance,i2c_device,i2c_delay,key);
							break;
#ifndef NO_AUDIO
						case 2:
							msp4450g_Debug(pInstance,key);
							break;
#endif
						default:
							ad9380_Debug(pInstance,i2c_device,i2c_delay,key);
							break;
						}	

						
						break;
				}

				
				printf(" \n ******************** MENU ************************\n");
					printf("  c: decrease contrast   - C: increase contrast\n");
					printf("  b: decrease brightness - B: increase brightness\n");
//					printf("  t: decrease saturation - T: increase saturation\n");
//					printf("  h: decrease hue		 - H: increase hue\n");
//					printf("  s: decrease sharpness	 - S: increase sharpness\n");
//	#ifndef NO_AUDIO
//					printf("  v: decrease Volume	 - V: increase Volume\n");
//	#endif
//					printf("  z: Switch CVBS -> SVIDEO -> TUNER.\n");
//	#ifndef NO_AUDIO
//					printf("  x: Switch Audio Output HeadPhone <--> LoudSpeaker.\n");
//					printf("  y: Switch Audio Input Scart1 <--> Audio Input Scart4.\n");
//	#endif	
				printf("  2: 2 D Comfilter (for CVBS Capture) \n");
				printf("  3: 3 D Comfilter (for CVBS Capture) \n");
				printf(" a : Show all register Value of Techwell \n ");
				printf(" r : Read a regisger . Ex : regAdd = 2f <enter>\n");
				printf(" w : write a regVal to regAdd . Ex regAdd = 2a <enter> regVal= 1c <enter>\n");
				//printf(" M: enter video mode modificator\n");
				printf("  /: Switch debug chip TW - AD - MSP  \n");
				printf("  q: Exit .\n");
				printf(" \n **************************************************\n");
				
			}
					

		}
		
		update_hdmi(&dcc_info, &disp_opt, &audio_opt);

		if (update_out_window) {
		//if (1) { //may be not need
		
			if (0) {
			
					err = set_display_out_window(&dcc_info);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Error setting out window %d\n", err));
					}
			}
					update_out_window = FALSE;
				
				if (update_scaler_zoom) {
					set_scaler_source_zoom(pInstance, dcc_info.disp_info->osd_scaler[0], local_opt[0].zoom_x, local_opt[0].zoom_y, local_opt[0].zoom_w, local_opt[0].zoom_h);
					update_scaler_zoom = FALSE;
				}
		}
		
	
		input_num=0;
		for (in = 0; in <= input_num; in++) {
			if ((local_opt[in].i2c_board)!=cap_sigma895e1) {
				if ((local_opt[in].i2c_port == cap_HDMI0) || (local_opt[in].i2c_port == cap_HDMI1)) {
					// handle HDMI interrupt, query HDMI related information
					err = handle_SiI9031_int(
						&dcc_info, 
						&local_opt[in], 
						&capture_opt[in], 
						&disp_opt, 
						&audio_opt, 
						&(pVideoSource[in]), 
						in, 
						0x30, 
						local_opt[in].i2c_video_delay);
				}
				
			}

			if (((local_opt->i2c_board != cap_sigma844e1dtv) || (capture_opt->InputModuleID != DispGraphicInput)) && (local_opt->i2c_video_chip == cap_SAA7119)) {
				// handle Philips SAA7119 interrups
			}			

			
			

			/* auto-detect of video mode change */
			input=0;
//			if (local_opt[in].update) {
			if (1) { //Alway autodetect .			
				static enum EMhwlibTVStandard old_std[2];
				static enum EMhwlibTVStandard prev_std[2];			
				static RMuint32 same_ct[2] = {0, 0};
				RMbool i2c_detect, update;
				
				if (same_ct[in] == 0) old_std[in] = capture_opt[in].TVStandard;

				if (same_ct[in] < 2) prev_std[in] = capture_opt[in].TVStandard;

				err = auto_detect_input(&dcc_info, &capture_opt[in], &local_opt[in], &i2c_detect, &update);
				
				if (RMSUCCEEDED(err)) {
					if (i2c_detect) {
						same_ct[in] = 10;
					} else 
						if (capture_opt[input].TVStandard == prev_std[in]) {
							if (same_ct[in] < 10) same_ct[in]++;
						} else same_ct[in] = 1;

					
					if (((capture_opt[input].TVStandard != old_std[in]) || update) && (same_ct[in] == 10)) {

						//if (old_std != EMhwlibTVStandard_Custom) {
						if (old_std[0] != EMhwlibTVStandard_Custom) {
//fprintf(stderr, "AutoDetect: Closing input %d %lu\n", __LINE__, in); RMGetKey();
if (0) {

							run = FALSE;
							goto CAPTURE_EXIT0;
}
							err = close_input(&dcc_info, &(pVideoSource[input]), &capture_opt[input], &disp_opt, &local_opt[input], input);
							if (RMFAILED(err))
								printf("close_input failed \n");
							else{
								printf("Closed Input \n");
								
								/*
								if ((local_opt[0].i2c_port == cap_HDMI0) || (local_opt[0].i2c_port == cap_HDMI1)) {
																	if (ad9380_ResetClockTermination(pInstance,local_opt[0].i2c_video_dev,local_opt[0].i2c_video_delay)==RM_OK) {
																		printf("Reset Clock Ter\n");
																	}
																}*/
								
								
								if (audio_opt.AudioIn && dcc_info.pAudioSource) {		
#if STOP_AUDIO_IF_NO_VIDEO

									if ((local_opt[0].i2c_port == cap_HDMI0) || (local_opt[0].i2c_port == cap_HDMI1)) {
										//printf("Not stop audio HDMI here but three state output \n");
										//ad9380_threeStateOutput(dcc_info.pRUA,local_opt[0].i2c_video_dev,local_opt[0].i2c_video_delay,TRUE);
#ifndef NO_AUDIO 
										
										
										err=msp4450g_reset(pInstance); 
#endif	
										
										if (audio_opt.SampleRate) {

											if (stop_audio_passthrough(&dcc_info, &audio_opt)==RM_OK) {
												printf("stop_audio_passthrough Called Ok <1>. \n");
												audio_opt.SampleRate=0;
												sampleCur=0;
												sampleOld=0;
												sampleErrCount=0;
												sampleOld=0;
												samplePre=0;
											}											
										}

									}else{
#ifndef NO_AUDIO 
										err=msp4450g_reset(pInstance); 
#endif
										if (audio_opt.SampleRate) {
											stop_audio_passthrough(&dcc_info, &audio_opt);
										}
									}
									
									
#endif
								}								
							}

							

						}
						if (capture_opt[input].TVStandard != EMhwlibTVStandard_Custom) {
							if (((local_opt[0].i2c_port == cap_HDMI0) || (local_opt[0].i2c_port == cap_HDMI1))) {
								RMuint8 isHDMIMode=0;
								RMuint8 i=0;
								sampleErrCount=0;
								printf("Wait for loading ");
								for(i=0;i<20;i++)
								{
									
									//detect_hdmi_mode(&dcc_info, &local_opt[in], 0x30, local_opt[in].i2c_video_delay);
									err=ad9380_isHdmiMode(dcc_info.pRUA,local_opt[0].i2c_video_dev,local_opt[0].i2c_video_delay,&isHDMIMode);
									if (isHDMIMode) {
										if (ad9380_getAudioSampleRateHDMI(dcc_info.pRUA,local_opt[0].i2c_video_dev, local_opt[0].i2c_video_delay,&sampleCur)!=RM_OK) {
											//printf("can't get HDMI Audio sampleRate\n");
											sampleErrCount++;
											if (sampleErrCount>=1) {
												sampleErrCount=0;
												
												//err = close_input(&dcc_info, &(pVideoSource[0]), &capture_opt[0], &disp_opt, &local_opt[0], 0);
												capture_opt[0].TVStandard = EMhwlibTVStandard_Custom;
												printf(".");
												ad9380_PowerDown(dcc_info.pRUA,local_opt[0].i2c_video_dev, local_opt[0].i2c_video_delay);
												usleep(1000);
												ad9380_PowerUp(dcc_info.pRUA,local_opt[0].i2c_video_dev, local_opt[0].i2c_video_delay);											
												if (ad9380_ResetClockTermination(pInstance,local_opt[0].i2c_video_dev,local_opt[0].i2c_video_delay)==RM_OK) {
													//printf("Reset OutPut !\n");
												}												
											}											
										}
									}
									
									
									usleep(1000);
									
								}
								printf("\n");
								
							}
							
							if (capture_opt[0].TVStandard == EMhwlibTVStandard_Custom) {
								continue;
							}else{
								err = setup_input(&dcc_info, &(pVideoSource[input]), &capture_opt[input], &disp_opt, &local_opt[input], input);
							}							
							if (RMFAILED(err)) {
								run = FALSE;
								printf("Setup Input Failed\n");
							}
							else {
								update_out_window=TRUE;
								update_scaler_zoom=TRUE;
								printf("Setup Input \n");
								if (1) {
									switch(local_opt[0].i2c_board) {
									case cap_sigma895e1:
										{
											switch(local_opt[0].i2c_video_chip) {
												case cap_AD9380:
												switch(local_opt[0].i2c_port) {
												case cap_Component1:
												case cap_Component2:
													if (capture_opt[input].TVStandard != EMhwlibTVStandard_ITU_Bt656_525) {
														local_opt[0].zoom_x = ZOOM_0;
														local_opt[0].zoom_y = ZOOM_0;
														local_opt[0].zoom_w = ZOOM_1;
														local_opt[0].zoom_h = ZOOM_1;									
													}
													break;
												case cap_HDMI0:
												case cap_HDMI1:
													
													if (capture_opt[input].TVStandard != EMhwlibTVStandard_ITU_Bt656_525) {
														local_opt[0].zoom_x = ZOOM_0;
														local_opt[0].zoom_y = ZOOM_0;
														local_opt[0].zoom_w = ZOOM_1;
														local_opt[0].zoom_h = ZOOM_1;									
													}
													
													break;
												default:
													break;
												}
												break;
											default:
												break;
											}
										}
										break;
									default:
										break;
									}
									
								}

								if (audio_opt.AudioIn) {
									if ((local_opt[0].i2c_port == cap_HDMI0) || (local_opt[0].i2c_port == cap_HDMI1)) {
										//printf("With HDMI, not init audio here but open output\n");
										//ad9380_threeStateOutput(dcc_info.pRUA,local_opt[0].i2c_video_dev,local_opt[0].i2c_video_delay,FALSE);										
									}else{
										
										
										if (audio_opt.SampleRate) {
#if STOP_AUDIO_IF_NO_VIDEO
											printf("init_audio_passthrough . SampleRate = %ld\n",audio_opt.SampleRate);
											err = init_audio_passthrough(&dcc_info, &audio_opt, &(capture_opt[0]));
#ifndef NO_AUDIO //need to reset MSP ?
											err=setCaptureAudioPort(pInstance,local_opt->i2c_port,isHeadPhoneOut,isScart1In,headphoneVolume,loudspeakerVolume); 
#endif	
											
#endif
											if (RMFAILED(err)) {
												fprintf(stderr, "Error starting audio capture! %s\n", RMstatusToString(err));
											}
										}
										
									}


									
								}
								
							}

							
						}
						if (RMSUCCEEDED(GetTVStandardName(capture_opt[input].TVStandard, &StandardName))) {
							printf("New TV Standard: %s\n", StandardName);							
						} else {
							printf("New TV Standard: # %d\n", capture_opt[input].TVStandard);
						}
						same_ct[in] = 0;
					}else	{ //Signal video No Change. But Audio Sample Rate HDMI need to handle :
						

						if (((local_opt[0].i2c_port == cap_HDMI0) || (local_opt[0].i2c_port == cap_HDMI1))&&(capture_opt[0].TVStandard != EMhwlibTVStandard_Custom)){
						//if ((local_opt[0].i2c_port == cap_HDMI0) || (local_opt[0].i2c_port == cap_HDMI1)) {
						   
							RMuint8 isHDMIMode=0;
							//detect_hdmi_mode(&dcc_info, &local_opt[in], 0x30, local_opt[in].i2c_video_delay);
							err=ad9380_isHdmiMode(dcc_info.pRUA,local_opt[0].i2c_video_dev,local_opt[0].i2c_video_delay,&isHDMIMode);
							if (isHDMIMode) {
								RMuint8 i=0;
								for(i=0;i<5;i++)
								{
									if (autoDetectHDMISampleRate(dcc_info.pRUA,local_opt[0].i2c_video_dev, local_opt[0].i2c_video_delay,&sampleOld,&samplePre,&sampleCur,&sampleCountDif,&isUpdateSampleRate)!=RM_OK) {

										//printf("can't detect HDMI sampleRate\n");
										//sampleErrCount++;

										//if (((local_opt[0].i2c_port == cap_HDMI0) || (local_opt[0].i2c_port == cap_HDMI1))&&(isUpdateSampleRate)) {
										/*
										if (sampleErrCount>=10) {
																					sampleErrCount=0;
																					/ *
																					err = close_input(&dcc_info, &(pVideoSource[0]), &capture_opt[0], &disp_opt, &local_opt[0], 0);
																																capture_opt[0].TVStandard = EMhwlibTVStandard_Custom;
																																printf("***Reset AD***\n");
																																ad9380_PowerDown(dcc_info.pRUA,local_opt[0].i2c_video_dev, local_opt[0].i2c_video_delay);
																																usleep(1000);
																																ad9380_PowerUp(dcc_info.pRUA,local_opt[0].i2c_video_dev, local_opt[0].i2c_video_delay);											
																																* /
																					
																					if (ad9380_ResetClockTermination(pInstance,local_opt[0].i2c_video_dev,local_opt[0].i2c_video_delay)==RM_OK) {
																						printf("Reset OutPut !\n");
																					}
																					
										
											break;
										}				
										*/						
									
									}else{
										sampleErrCount=0;
									}
									if (isUpdateSampleRate) {
										break;
									}
									usleep(100);
								}
							if (!audio_opt.SampleRate) {//If No audio or current Audio SampleRate not support.
								
								if (isUpdateSampleRate) {
									printf("Audio Sample Rate Change from %ld to %ld \n",audio_opt.SampleRate,sampleCur);
									audio_opt.SampleRate=sampleCur;
								}
#if STOP_AUDIO_IF_NO_VIDEO
								
								if((isUpdateSampleRate) && (audio_opt.SampleRate)){										
									err = init_audio_passthrough(&dcc_info, &audio_opt, &(capture_opt[0]));
									
									
#ifndef NO_AUDIO //need to reset MSP ?
									err=setCaptureAudioPort(pInstance,local_opt->i2c_port,isHeadPhoneOut,isScart1In,headphoneVolume,loudspeakerVolume); 
#endif	
								
#endif
								}
									
							}else{ //Check if sampleRate Change :
								if (isUpdateSampleRate) {
									printf("Audio Sample Rate Change from %ld to %ld \n",audio_opt.SampleRate,sampleCur);
									err = stop_audio_passthrough(&dcc_info, &audio_opt);
									usleep(2000);
									audio_opt.SampleRate=sampleCur;									
									if (audio_opt.SampleRate) {
										err = init_audio_passthrough(&dcc_info, &audio_opt, &(capture_opt[0]));
#ifndef NO_AUDIO //need to reset MSP ?
										err=setCaptureAudioPort(pInstance,local_opt->i2c_port,isHeadPhoneOut,isScart1In,headphoneVolume,loudspeakerVolume); 
#endif	
										
									}else{
										if (local_opt[0].hdmi_mode == mode_HDMI) {
											printf("No audio HDMI !\n");
										}										
									}
								}
							}
						  }else
							{
							  printf("DVI Mode detected \n");
							}
							
						}
						




						}
				}else
					printf("Auto detect Error \n");
			}
			
//				fprintf(stderr,"003	khoa*** \n");

			in=0;
			if (local_opt[in].ccfifo_print || local_opt[in].use_soft_cc_decoder) { /* reading the CC Fifo */
//			if(0){
				
				struct CCFifo_CCEntry_type cc;
				RMuint16 cc_data;
				do {
					err = RUAGetProperty(pInstance, local_opt[in].ccfifo_id_in, RMCCFifoPropertyID_CCEntry, &cc, sizeof(cc));
					if (err!=RM_OK) {
						//printf("Can't get cc data \n");
						//printf("local_opt[in].ccfifo_id_in = %ld\n",local_opt[in].ccfifo_id_in);
					}else{
						//fprintf(stderr, "khoa --------- cc.Enable = %d cc.Type= %d \n",cc.Enable,cc.Type);
						//printf("local_opt[in].ccfifo_id_in = %ld\n",local_opt[in].ccfifo_id_in);
					}
					if (RMSUCCEEDED(err)) {
						if (cc.Enable){
							switch(cc.Type) {
							case EMhwlibCCType_BottomField:
								if (local_opt[in].ccfifo_print) {
									cc_data = (cc.CC2 << 8) | cc.CC1;
									handle_line21cc_data(1, 21, &cc_data, 1);
										fprintf(stderr, "EMhwlibCCType_BottomField\n");
								}
								break;
							case EMhwlibCCType_TopField:
								fprintf(stderr, "EMhwlibCCType_TopField\n");
								if (local_opt[in].use_soft_cc_decoder) {
									if (cc_size >= 128 - 2){
										RMSCCDecode(dcc_info.scc, cc_buf, cc_size, get_ustime() );
										//	RMSCCDecode(dcc_info.scc, cc_buf, cc_size, get_ustime() );
										cc_size = 0;
									}
									cc_buf[cc_size++] = cc.CC1;
									cc_buf[cc_size++] = cc.CC2;
								}
								if (local_opt[in].ccfifo_print) {
									cc_data = (cc.CC2 << 8) | cc.CC1;
									handle_line21cc_data(0, 21, &cc_data, 1);
								}
								break;
							case EMhwlibCCType_DTVCCHeader:
								fprintf(stderr, "EMhwlibCCType_DTVCCHeader\n");
								if (dtv_size){
									//RMSCCDecode(dcc_info.scc, dtv_buf, dtv_size);
									RMSCCDecode(dcc_info.scc, dtv_buf, dtv_size, get_ustime() );
									dtv_size = 0;
								}
								// no break;
							case EMhwlibCCType_DTVCCData:
									fprintf(stderr, "EMhwlibCCType_DTVCCData\n");
								if (local_opt[in].use_soft_cc_decoder) {
									if (dtv_size < 128 - 1) {
										dtv_buf[dtv_size++] = cc.CC1;
										dtv_buf[dtv_size++] = cc.CC2;
									}
								}
								if (local_opt[in].ccfifo_print) {
									cc_data = (cc.CC2 << 8) | cc.CC1;
									handle_line21cc_data(0, 21, &cc_data, 1);
								}
								break;
							default:
								break;
							}
						}
						RUASetProperty(pInstance, local_opt[0].ccfifo_id_send, RMCCFifoPropertyID_CCEntry, &cc, sizeof(cc), 0);
					}
				} while (RMSUCCEEDED(err));
				if (cc_size){
					//RMSCCDecode(dcc_info.scc, cc_buf, cc_size);
						fprintf(stderr, "RMSCCDecode khoa here\n");
					RMSCCDecode(dcc_info.scc, cc_buf, cc_size, get_ustime() );
					cc_size = 0;
				}
			}
			
			if (local_opt[in].pDmaReceive) {
				struct RUAEvent Event;
				RMuint8 *pBuf = NULL;
				RMuint32 size = 0;
				RMuint32 targetModule = EMHWLIB_TARGET_MODULE(
					EMHWLIB_MODULE_CATEGORY(capture_opt[in].InputModuleID), 
					EMHWLIB_MODULE_INDEX(capture_opt[in].InputModuleID), 
					1);
//TODO

				Event.ModuleID = EMHWLIB_MODULE(DisplayBlock, 0);
				Event.Mask = RUAEVENT_XFER_FIFO_READY; // EMHWLIB_DISPLAY_EVENT_ID(capture_opt[in].InputModuleID);
		fprintf(stderr, "khoa Received DMA buffer at 0x%p to 0x%p\n", pBuf, pBuf + size);
if (1) {
			//	if (RMSUCCEEDED(err = DCCGetReceiveEvent(local_opt[in].pR, &Event))) {
if (1) {
	//if (RMSUCCEEDED(err = RUAWaitForMultipleEvents(pInstance, &Event, 1, TIMEOUT_1MS, NULL))) {
					err = RUAReceiveData(pInstance, targetModule, local_opt[in].pDmaReceive, &pBuf, &size, NULL, NULL);
						fprintf(stderr, "khoa Received DMA buffer at 0x%p to 0x%p\n", pBuf, pBuf + size);
						if (RMSUCCEEDED(err) && pBuf && size) {
							fprintf(stderr, "r");
							fprintf(stderr, "Received DMA buffer at 0x%p to 0x%p\n", pBuf, pBuf + size);
							local_opt[in].pVBIData = (RMuint16 *)pBuf;
							
							// handle all complete VBI buffers that end before or within current pBuf
							while ((RMuint32)(local_opt[in].pVBIData) + capture_opt[in].vbi_size <= (RMuint32)(pBuf) + size) {
								fprintf(stderr, "Handling VBI data block at 0x%p in DMA buf at 0x%08lX-0x%08lX\n", local_opt[in].pVBIData, (RMuint32)(pBuf), (RMuint32)(pBuf) + size);
								local_opt[in].VBIFlags = ((RMuint32 *)(local_opt[in].pVBIData))[0];
								local_opt[in].VBIPTS = ((RMuint32 *)(local_opt[in].pVBIData))[1];
								local_opt[in].VBISize = ((RMuint32 *)(local_opt[in].pVBIData))[2];
								fprintf(stderr, "VBI: Flags=0x%08lX PTS=0x%08lX %lu bytes\n", local_opt[in].VBIFlags, local_opt[in].VBIPTS, local_opt[in].VBISize);
								if (local_opt[in].VBISize + 12 != capture_opt[in].vbi_size) {
									fprintf(stderr, "Data size from block header mismatch: %lu instead of %lu\n", local_opt[in].VBISize, capture_opt[in].vbi_size - 12);
									//exit(1);
								}
								local_opt[in].pVBIData += 12 / 2;  // skip over header, 16 bit pointer
								handle_vbi_data(&local_opt[in], &capture_opt[in]);
								local_opt[in].pVBIData += (local_opt[in].VBISize / 2);
							}
							// release DMA buffer (might contain unused data at the end)
							fprintf(stderr, "Releasing DMA buffer at 0x%p\n", pBuf);
							RUAReleaseBuffer(local_opt[in].pDmaReceive, pBuf);
						} else {
							RMDBGLOG((LOCALDBG, "RUAReceiveData() failed! %s (size=%lu)\n", RMstatusToString(err), size));
						}
						} else {
						RMDBGLOG((ENABLE, "RUAWaitForMultipleEvents() failed! %s\n", RMstatusToString(err)));
					}
				} else {
					RMDBGLOG((ENABLE, "DCCGetReceiveEvent() failed! %s\n", RMstatusToString(err)));
				}
			}
			
			if (local_opt[in].pVBIData) {
				struct RUAEvent evt;
				fprintf(stderr, "pVBIdata khoa here ***************8\n");
				
				evt.Mask = EMHWLIB_DISPLAY_EVENT_ID(capture_opt[in].InputModuleID);
				if (evt.Mask > 0) {
					evt.ModuleID = EMHWLIB_MODULE(DisplayBlock, 0);
					err = RUAResetEvent(pInstance, &evt);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Cannot reset display event, %s\n", RMstatusToString(err)));
						continue;
					}
				}
				err = DCCGetVBIData(pDCC, 
					capture_opt[in].InputModuleID, 
					&(local_opt[in].VBIFlags), 
					&(local_opt[in].VBIPTS), 
					&(local_opt[in].VBISequence), 
					&(local_opt[in].VBISize), 
					&(local_opt[in].pVBIChunk));
//				fprintf(stderr, "Get in=[%ld] ModID =%lx Flags=%lx PTS= %lx Seq =%lx 
//					Size=%lx,Chunk = %x \n",	
//					in,capture_opt[in].InputModuleID,local_opt[in].VBIFlags, 
//					local_opt[in].VBIPTS ,local_opt[in].VBISequence,	
//					local_opt[in].VBISize ,
//					*(local_opt[in].pVBIChunk)); //khoa

				if ((err == RM_PENDING) && (evt.Mask > 0)) {
					RMuint32 index;
					err = RUAWaitForMultipleEvents(pInstance, &evt, 1, TIMEOUT_1SEC, &index);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "wait for display update event completion failed, %s\n", RMstatusToString(err)));
						if (err != RM_PENDING) continue;
					}
					err = DCCGetVBIData(pDCC, 
						capture_opt[in].InputModuleID, 
						&(local_opt[in].VBIFlags), 
						&(local_opt[in].VBIPTS), 
						&(local_opt[in].VBISequence), 
						&(local_opt[in].VBISize), 
						&(local_opt[in].pVBIChunk));
				}
				if (RMFAILED(err)) continue;
				wait = FALSE;
				RMMemcpy(&(local_opt[in].pVBIData[local_opt[in].VBIOffs / sizeof(RMuint16)]), local_opt[in].pVBIChunk, local_opt[in].VBISize);
				local_opt[in].VBIOffs += local_opt[in].VBISize;
				while (local_opt[in].VBISequence) {
					err = DCCGetVBIData(pDCC, 
						capture_opt[in].InputModuleID, 
						&(local_opt[in].VBIFlags), 
						&(local_opt[in].VBIPTS), 
						&(local_opt[in].VBISequence), 
						&(local_opt[in].VBISize), 
						&(local_opt[in].pVBIChunk));
					
					RMMemcpy(&(local_opt[in].pVBIData[local_opt[in].VBIOffs / sizeof(RMuint16)]), local_opt[in].pVBIChunk, local_opt[in].VBISize);
					local_opt[in].VBIOffs += local_opt[in].VBISize;
				}
				local_opt[in].VBISize = local_opt[in].VBIOffs;
				local_opt[in].VBIOffs = 0;
			
				handle_vbi_data(&local_opt[in], &capture_opt[in]);
			}
		}
		
		if (wait) usleep(10000);
		//if (wait) usleep(5000);
	}
//	RMTermExit();
	
	input = 0;
	goto CAPTURE_EXIT0;
CAPTURE_EXIT0:
	if (local_opt[input].arg_vbi) fclose(local_opt[input].vbidump);
	
	if (local_opt[input].ccfifo_id_in) {
		RUASetPendingProperty(dcc_info.pRUA, 
			local_opt[input].ccfifo_id_in, 
			RMCCFifoPropertyID_Close, NULL, 0, 
			"Can not close ccfifo");
	}
	if (local_opt[input].ccfifo_id_out) {
		RUASetPendingProperty(dcc_info.pRUA, 
			local_opt[input].ccfifo_id_out, 
			RMCCFifoPropertyID_Close, NULL, 0, 
			"Can not close ccfifo");
	}
	if (local_opt[input].ccfifo_addr_in) {
		DCCFree(dcc_info.pDCC, local_opt[input].ccfifo_addr_in);		
		local_opt[input].ccfifo_addr_in = 0;
	}
	if (local_opt[input].ccfifo_addr_out) {
		DCCFree(dcc_info.pDCC, local_opt[input].ccfifo_addr_out);		
		local_opt[input].ccfifo_addr_out = 0;
	}
	if (local_opt[input].use_soft_cc_decoder) {
		RMFRTKClose(dcc_info.rtk);
		
		err = DCCCloseVideoSource(dcc_info.pCCOSDSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot close cc-osd source: %s\n", RMstatusToString(err)));
		}
		dcc_info.pCCOSDSource = NULL;
	}
	if (input_num && (input == 0)) {
		input = 1;
		goto CAPTURE_EXIT0;
	}
	
	if (audio_opt.AudioIn && dcc_info.pAudioSource) {		
		stop_audio_passthrough(&dcc_info, &audio_opt);
	}
	
	DCCSTCStop(dcc_info.pStcSource);
	
	for (input = 0; input <= input_num; input++) {
//fprintf(stderr, "Exiting %d %lu\n", __LINE__, input); RMGetKey();
		err = close_input(&dcc_info, &(pVideoSource[input]), &capture_opt[input], &disp_opt, &local_opt[input], input);
	
	}
	
	clear_display_options(&dcc_info, &disp_opt);
	
	err = DCCClose(pDCC);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot close DCC %d\n", err);
	}	
	
	cleanup(NULL);
	return 0;
}
