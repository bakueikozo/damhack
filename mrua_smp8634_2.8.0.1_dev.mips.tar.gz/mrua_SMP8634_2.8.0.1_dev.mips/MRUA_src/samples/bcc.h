#ifndef BCC_H__
#define BCC_H__

#include "ccparse.h"
#include "common.h"

#include "rmdef/rmdef.h"
#include "rua/include/rua.h"

struct bcc
{
	rmbcc_t *bcc_parser;
	RMuint32 ccfifo_id;
	RMuint32 ccfifo_buffer;

	struct CCFifo_CCEntry_type plast_CCentry;
	RMbool CCentry_consumed;
};

#define DEFAULT_CC_FIFO_SIZE	(80)

RMstatus bcc_init (struct bcc **, RMnonAscii *, struct RUA *, struct dcc_context *);
RMstatus bcc_close(struct bcc *, struct RUA *);
RMstatus bcc_feed (struct bcc *, struct RUA *, RMuint64);

#endif /* BCC_H__ */
