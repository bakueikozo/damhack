/*
 *
 * Copyright (c) Sigma Designs, Inc. 2006. All rights reserved.
 *
 */


/**
   @file mp4scene.h
   @brief limited BIFS parsing for MP4 streams
	
   @author Yifan Liu
   @ingroup dccsamplecode
*/



#ifndef __MP4SCENE_H__
#define __MP4SCENE_H__


struct BIFSInfo_type {
        RMuint32 vidOD;
        RMuint32 vidESID;
        RMuint32 audOD;
        RMuint32 audESID;
};

extern RMstatus ParseBIFS(RMuint8 *pBuffer1, RMuint32 size1, RMuint8 *pBuffer2, RMuint32 size2, struct BIFSInfo_type *out);

#endif  // __MP4SCENE_H__

