/*
 *
 * Copyright (c) Sigma Designs, Inc. 2005. All rights reserved.
 *
 */

/**
	@file parse_capture_cmdline.c
	@brief sample application to access the 86xx chip family
	
	@author Christian Wolff
*/

#include "sample_os.h"

#define ALLOW_OS_CODE 1
#include "../rua/include/rua.h"
#include "../dcc/include/dcc.h"
#include "../rmcore/include/rmstatustostring.h"
#include "common.h"

#define SCANPARAM(x, msg, skip)\
do {\
	argi++;\
	if (argi < argc) {\
		param = strtoul(argv[argi], &endptr, 0);\
		if (endptr[0] == '\0') x = param;\
		else {\
			RMDBGPRINT((ENABLE, msg " after %s\n", argv[argi - skip]));\
			err = RM_ERROR;\
		}\
	} else {\
		RMDBGPRINT((ENABLE, "Please specify %d number%s after %s\n", skip, (skip == 1) ? "" : "s", argv[argi - skip]));\
		err = RM_ERROR;\
	}\
} while(0)

void show_capture_options(void)
{
	fprintf(stderr, "CAPTURE INPUT OPTIONS\n");
	fprintf(stderr, "	note: video input can capture video at 8 or 16 bit,\n");
	fprintf(stderr, "		graphic input can capture video at 8 or 16 bit, or graphics at 24 and 32 bit\n");
	fprintf(stderr, "	-i <input>: input block, 'graphic', 'video' or 'colorbars' (default: video)\n");
	fprintf(stderr, "	-if <input format>: tv standard of the input, same list as -f option (default: ntsc)\n");
	fprintf(stderr, "	-prot <video protcol>: 656, 601 or 601v (with vvld signal) (default: 601)\n");
	fprintf(stderr, "	-bus <bus size>: 8, 16, 24 or 32, use 8/16 bit data bus for video capture, 8/16/24/32 bit for graphics capture (default: 8)\n");
	fprintf(stderr, "	-format <in_format>: bit size and pixel formatting for graphics capture\n");
	fprintf(stderr, "		24_888 24_8565 24_5676 32_8888 16_565 16_1555 16_4444 31_7888 (default: 24_888)\n");
	fprintf(stderr, "	-inasp <x> <y>: picture aspect ratio of the input frame (default: 4 by 3)\n");
	fprintf(stderr, "	-inaspix <x> <y>: alternatively, pixel aspect ratio of the input frame (picture asp. is used by default)\n");
	fprintf(stderr, "	-in_deint: allow De-Interlacing (increases memory usage)\n");
	fprintf(stderr, "	-ics <cs>: color space of the input (default: yuv_601)\n");
	fprintf(stderr, "		yuv_601, yuv_709, rgb_0_255, rgb_16_235\n");
	fprintf(stderr, "	-scs <cs>: color space of the scaler, allows conversion on graphic input (default: same as -ics)\n");
	fprintf(stderr, "		yuv_601, yuv_709, rgb_0_255, rgb_16_235\n");
	fprintf(stderr, "	-disablescaler: don't connect capture input to scaler (useful for other usage of captured pics, for instance, capture_crc\n");
	fprintf(stderr, "	-ddr, -ddri: enable dual edge / double data rate mode\n");
	fprintf(stderr, "		ddr: LSB on positive edge, MSB on negative edge\n");
	fprintf(stderr, "		ddri: MSB on positive edge, LSB on negative edge\n");
	fprintf(stderr, "		ddrw: cature full 16 bit DDR instead of 12 bit video + 4 bit alpha\n");
	fprintf(stderr, "	-X <hor.shift> -Y <vert.shift>: shift input frame\n");
	fprintf(stderr, "	-over <top> <bottom> <left> <right>: over-scan the input on each edge by as many pixels\n");
	fprintf(stderr, "	-vbi <x> <y> <w> <h>: window of VBI data in the captured video (w in pixel)\n");
	fprintf(stderr, "	-vbiraw <top_start> <top_mask> <bot_start> <bot_mask>: capture raw VBI data from vertical blanking area\n");
	fprintf(stderr, "	-vbianc <w> <h> <y_top> <y_bot>: cature sliced VBI data (h lines with w bytes each, starting at line y_top in top fields and line y_bot in bottom fields) from horizontal blanking area (w in bytes, h in lines per field)\n");
	fprintf(stderr, "	-vbidma: Use DMA to retreive VBI data, instead of CPU copy (useful for TeleText)\n");
	fprintf(stderr, "	-TT: PAL TeleText shortcut for '-vbianc 52 18 5 5' (with 656 capture on EM8622 and up, use with -anc -vbidma)\n");
	fprintf(stderr, "	-CC: NTSC ClosedCaption shortcut for '-vbianc 12 3 16 17' (with 656 capture on EM8622 and up, use with -softcc608)\n");
	fprintf(stderr, "	-dram <x>: DRAM bank to be used for the capture buffer\n");
	fprintf(stderr, "	-invv: invert V-Sync of capture format\n");
	fprintf(stderr, "	-invh: invert H-Sync of capture format\n");
	fprintf(stderr, "	-v2: Use alternate input pads on lower 8 bits of the input\n");
	fprintf(stderr, "	-inpicovr <format> <width> <height>: Override displayed picture format with different pixel format and frame size.\n");
	fprintf(stderr, "   -freerun [0|1]: disable/enable free running audio capture (no more PTS to STC sync after initial delay enforcement)\n");
}

RMstatus init_capture_options(
	struct capture_cmdline *options)
{
	options->TVStandard = EMhwlibTVStandard_Custom;  // none
	options->guess = TRUE;  // probe input sync params unless a standard is forced
	options->dram = 0;
	options->InputColorSpace = EMhwlibColorSpace_YUV_601;
	options->SurfaceColorSpace = EMhwlibColorSpace_None;
	options->SamplingMode = EMhwlibSamplingMode_422;
	options->ColorMode = EMhwlibColorMode_VideoInterleaved;
	options->InputColorFormat = EMhwlibInputColorFormat_16BPP_565;
	options->PictureAspectRatio.X  = 4;
	options->PictureAspectRatio.Y  = 3;
	options->PixelAspectRatio.X = 0;  // disable
	options->PixelAspectRatio.Y = 0;  // disable
	options->InputModuleID = DispVideoInput;
	options->DigitalTimingSignal = EMhwlibDigitalTimingSignal_601;
	options->UseVideoValid = FALSE;
	options->bussize = 8;
	options->DualEdge = FALSE;
	options->DualEdgeWidth = FALSE;
	options->DualEdgeInvert = FALSE;
	options->InvertVSync = FALSE;
	options->InvertHSync = FALSE;
	options->shift_x = 0;
	options->shift_y = 0;
	options->ov_top = 0;
	options->ov_bot = 0;
	options->ov_lft = 0;
	options->ov_rgt = 0;
	options->vbi_x = 0;
	options->vbi_y = 0;
	options->vbi_w = 0;
	options->vbi_h = 0;
	options->vbiraw_topstart = 0;
	options->vbiraw_topmask = 0;
	options->vbiraw_botstart = 0;
	options->vbiraw_botmask = 0;
	options->vbianc_enable = FALSE;
	options->vbianc_w = 0;
	options->vbianc_h = 0;
	options->vbianc_ytop = 0;
	options->vbianc_ybot = 0;
	options->vbi_buf = 0;
	options->vbi_size = 0;
	options->vbi_dma = FALSE;
	options->DeInt = FALSE;
	options->UseV2Pads = FALSE;
	options->disablescaler = FALSE;
	options->override.Enable = FALSE;
	options->override.ColorFormat = EMhwlibInputColorFormat_32BPP;
	options->override.Width = 0;
	options->override.Height = 0;
	options->audio_free_run = TRUE;  // default: disable AV-Sync after audio passthrough has started up with the expected delay. This is necessary because the STC can not run syncronous to an external clock and the phantom PTS of the audio SO ucode lacks the precision for long time playback
	options->AudioGuardTime = 0;
	
	return RM_OK;
}

RMstatus parse_capture_cmdline(
	int argc, 
	char **argv, 
	int *index, 
	struct capture_cmdline *options)
{
	RMstatus err = RM_OK;
	int argi = *index;
	RMuint32 param;
	RMascii *endptr;
	
	if (argv[argi][0] == '-') {
		if (! strcmp(&(argv[argi][1]), "if")) {
			// TODO check if options == NULL
			argi++;
			if (argi < argc) {
				if (RMFAILED(GetTVStandard(argv[argi], &(options->TVStandard)))) {
					RMDBGPRINT((ENABLE, "unknown TV standard: %s %s!\n", argv[argi - 1], argv[argi]));
					err = RM_ERROR;
				}
				options->guess = FALSE;
			} else {
				RMDBGPRINT((ENABLE, "please specify a TV standard after -f\n"));
				err = RM_ERROR;
			}
		}
		else if (! strcmp(&(argv[argi][1]), "ics")) {
			argi++;
			if (argi < argc) {
				if (! strcmp(argv[argi], "yuv_601")) {
					options->InputColorSpace = EMhwlibColorSpace_YUV_601;
				} else if (! strcmp(argv[argi], "yuv_709")) {
					options->InputColorSpace = EMhwlibColorSpace_YUV_709;
				} else if (! strcmp(argv[argi], "xv_601")) {
					options->InputColorSpace = EMhwlibColorSpace_xvYCC_601;
				} else if (! strcmp(argv[argi], "xv_709")) {
					options->InputColorSpace = EMhwlibColorSpace_xvYCC_709;
				} else if (! strcmp(argv[argi], "rgb_0_255")) {
					options->InputColorSpace = EMhwlibColorSpace_RGB_0_255;
				} else if (! strcmp(argv[argi], "rgb_16_235")) {
					options->InputColorSpace = EMhwlibColorSpace_RGB_16_235;
				} else {
					RMDBGPRINT((ENABLE, "unknown ColorSpace: -ics %s!\n", argv[argi]));
					err = RM_ERROR;
				}
			} else {
				RMDBGPRINT((ENABLE, "please specify a ColorSpace after -ics\n"));
				err = RM_ERROR;
			}
		}
		else if (! strcmp(&(argv[argi][1]), "scs")) {
			argi++;
			if (argi < argc) {
				if (! strcmp(argv[argi], "yuv_601")) {
					options->SurfaceColorSpace = EMhwlibColorSpace_YUV_601;
				} else if (! strcmp(argv[argi], "yuv_709")) {
					options->SurfaceColorSpace = EMhwlibColorSpace_YUV_709;
				} else if (! strcmp(argv[argi], "xv_601")) {
					options->SurfaceColorSpace = EMhwlibColorSpace_xvYCC_601;
				} else if (! strcmp(argv[argi], "xv_709")) {
					options->SurfaceColorSpace = EMhwlibColorSpace_xvYCC_709;
				} else if (! strcmp(argv[argi], "rgb_0_255")) {
					options->SurfaceColorSpace = EMhwlibColorSpace_RGB_0_255;
				} else if (! strcmp(argv[argi], "rgb_16_235")) {
					options->SurfaceColorSpace = EMhwlibColorSpace_RGB_16_235;
				} else {
					RMDBGPRINT((ENABLE, "unknown ColorSpace: -scs %s!\n", argv[argi]));
					err = RM_ERROR;
				}
			} else {
				RMDBGPRINT((ENABLE, "please specify a ColorSpace after -scs\n"));
				err = RM_ERROR;
			}
		}
		else if (! strcmp(&(argv[argi][1]), "disablescaler")) {
			options->disablescaler = TRUE;
		}
		else if (! strcmp(&(argv[argi][1]), "inaspix")) {
			SCANPARAM(options->PixelAspectRatio.X, "please specify a number for pixel aspect x", 1);
			SCANPARAM(options->PixelAspectRatio.Y, "please specify a number for pixel aspect y", 2);
			options->PictureAspectRatio.X = 0;
			options->PictureAspectRatio.Y = 0;
		}
		else if (! strcmp(&(argv[argi][1]), "inasp")) {
			SCANPARAM(options->PictureAspectRatio.X, "please specify a number for picture aspect x", 1);
			SCANPARAM(options->PictureAspectRatio.Y, "please specify a number for picture aspect y", 2);
			options->PixelAspectRatio.X = 0;
			options->PixelAspectRatio.Y = 0;
		}
		else if (! strcmp(&(argv[argi][1]), "i")) {
			argi++; 
			if (argi < argc) {
				if (argv[argi][0] == 'g') {
					options->InputModuleID = DispGraphicInput;
				} else if (argv[argi][0] == 'v') {
					options->InputModuleID = DispVideoInput;
				} else if (argv[argi][0] == 'c') {
					options->InputModuleID = DispColorBars;
				} else {
					RMDBGPRINT((ENABLE, "unknown input: %s\n", argv[argi]));
					err = RM_ERROR;
				}
			}
		}
		else if (! strcmp(&(argv[argi][1]), "ddri")) {
			options->DualEdge = TRUE;
			options->DualEdgeInvert = TRUE;
		}
		else if (! strcmp(&(argv[argi][1]), "ddrw")) {
			options->DualEdge = TRUE;
			options->DualEdgeWidth = TRUE;
		}
		else if (! strcmp(&(argv[argi][1]), "ddr")) {
			options->DualEdge = TRUE;
		}
		else if (! strcmp(&(argv[argi][1]), "bus")) {
			SCANPARAM(options->bussize, "please specify a bus size (8, 16, 24 or 32 bit)", 1);
			if (options->bussize == 24) options->bussize = 32;
			if ((options->bussize != 8) && (options->bussize != 16) && (options->bussize != 32)) {
				RMDBGPRINT((ENABLE, "ERROR: bus size must be 8, 16, 24 or 32 bit\n"));
				err = RM_ERROR;
			}
		}
		else if (! strcmp(&(argv[argi][1]), "format")) {
			argi++; 
			if (argi < argc) {
				if (! strcmp(argv[argi], "24_888")) {
					options->InputColorFormat = EMhwlibInputColorFormat_24BPP;
				} else if (! strcmp(argv[argi], "24_8565")) {
					options->InputColorFormat = EMhwlibInputColorFormat_24BPP_8565;
				} else if (! strcmp(argv[argi], "24_5676")) {
					options->InputColorFormat = EMhwlibInputColorFormat_24BPP_5676;
				} else if (! strcmp(argv[argi], "32_8888")) {
					options->InputColorFormat = EMhwlibInputColorFormat_32BPP;
				} else if (! strcmp(argv[argi], "16_565")) {
					options->InputColorFormat = EMhwlibInputColorFormat_16BPP_565;
				} else if (! strcmp(argv[argi], "16_1555")) {
					options->InputColorFormat = EMhwlibInputColorFormat_16BPP_1555;
				} else if (! strcmp(argv[argi], "16_4444")) {
					options->InputColorFormat = EMhwlibInputColorFormat_16BPP_4444;
				} else if (! strcmp(argv[argi], "31_7888")) {
					options->InputColorFormat = EMhwlibInputColorFormat_31BPP_7888;
				} else {
					RMDBGPRINT((ENABLE, "unknown color format: %s!\n", argv[argi]));
					err = RM_ERROR;
				}
			} else {
				RMDBGPRINT((ENABLE, "please specify a color format after %s\n", argv[argi - 1]));
				err = RM_ERROR;
			}
		}
		else if (! strcmp(&(argv[argi][1]), "prot")) {
			argi++;
			if (argi < argc) {
				if (! strcmp(argv[argi], "601")) {
					options->DigitalTimingSignal = EMhwlibDigitalTimingSignal_601;
					options->UseVideoValid = FALSE;
				} else if (! strcmp(argv[argi], "601v")) {
					options->DigitalTimingSignal = EMhwlibDigitalTimingSignal_601;
					options->UseVideoValid = TRUE;
				} else if (! strcmp(argv[argi], "656")) {
					options->DigitalTimingSignal = EMhwlibDigitalTimingSignal_656;
				} else {
					RMDBGPRINT((ENABLE, "unknown protocol: %s!\n", argv[argi]));
					err = RM_ERROR;
				}
			} else {
				RMDBGPRINT((ENABLE, "please specify a video protocol after %s\n", argv[argi - 1]));
				err = RM_ERROR;
			}
		}
		else if (! strcmp(&(argv[argi][1]), "X")) {
			SCANPARAM(options->shift_x, "please specify a horizontal input frame shift", 1);
		}
		else if (! strcmp(&(argv[argi][1]), "Y")) {
			SCANPARAM(options->shift_y, "please specify a vertical input frame shift", 1);
		}
		else if (! strcmp(&(argv[argi][1]), "over")) {
			SCANPARAM(options->ov_top, "please specify a top value", 1);
			SCANPARAM(options->ov_bot, "please specify a bottom value", 2);
			SCANPARAM(options->ov_lft, "please specify a left value", 3);
			SCANPARAM(options->ov_rgt, "please specify a right value", 4);
		}
		else if (! strcmp(&(argv[argi][1]), "vbi")) {
			SCANPARAM(options->vbi_x, "please specify a x value", 1);
			SCANPARAM(options->vbi_y, "please specify a y value", 2);
			SCANPARAM(options->vbi_w, "please specify a w value", 3);
			SCANPARAM(options->vbi_h, "please specify a h value", 4);
		}
		else if (! strcmp(&(argv[argi][1]), "vbiraw")) {
			SCANPARAM(options->vbiraw_topstart, "please specify a topstart value", 1);
			SCANPARAM(options->vbiraw_topmask, "please specify a topmask value", 2);
			SCANPARAM(options->vbiraw_botstart, "please specify a botstart value", 3);
			SCANPARAM(options->vbiraw_botmask, "please specify a botmask value", 4);
		}
		else if (! strcmp(&(argv[argi][1]), "vbianc")) {
			SCANPARAM(options->vbianc_w, "please specify a w value", 1);
			SCANPARAM(options->vbianc_h, "please specify a h value", 2);
			SCANPARAM(options->vbianc_ytop, "please specify a ytop value", 3);
			SCANPARAM(options->vbianc_ybot, "please specify a ybot value", 4);
			options->vbianc_enable = TRUE;
		}
		else if (! strcmp(&(argv[argi][1]), "vbidma")) {
			options->vbi_dma = TRUE;
		}
		else if (! strcmp(&(argv[argi][1]), "TT")) {
			options->vbianc_w = 52;
			options->vbianc_h = 18;
			options->vbianc_ytop = 5;
			options->vbianc_ybot = 5;
			options->vbianc_enable = TRUE;
		}
		else if (! strcmp(&(argv[argi][1]), "CC")) {
			options->vbianc_w = 12;
			options->vbianc_h = 3;
			options->vbianc_ytop = 16;
			options->vbianc_ybot = 17;
			options->vbianc_enable = TRUE;
		}
		else if (! strcmp(&(argv[argi][1]), "in_deint")) {
			options->DeInt = TRUE;
		}
		else if (! strcmp(&(argv[argi][1]), "invv")) {
			options->InvertVSync = TRUE;
		}
		else if (! strcmp(&(argv[argi][1]), "invh")) {
			options->InvertHSync = TRUE;
		}
		else if (! strcmp(&(argv[argi][1]), "dram")) {
			SCANPARAM(options->dram, "please specify a DRAM bank value", 1);
		}
		else if (! strcmp(&(argv[argi][1]), "v2")) {
			options->UseV2Pads = TRUE;
		}
		else if (! strcmp(&(argv[argi][1]), "inpicovr")) {
			if (argi + 3 < argc) {
				options->override.Enable = TRUE;
				argi++; 
				if (! strcmp(argv[argi], "24_888")) {
					options->override.ColorFormat = EMhwlibInputColorFormat_24BPP;
				} else if (! strcmp(argv[argi], "24_8565")) {
					options->override.ColorFormat = EMhwlibInputColorFormat_24BPP_8565;
				} else if (! strcmp(argv[argi], "24_5676")) {
					options->override.ColorFormat = EMhwlibInputColorFormat_24BPP_5676;
				} else if (! strcmp(argv[argi], "32_8888")) {
					options->override.ColorFormat = EMhwlibInputColorFormat_32BPP;
				} else if (! strcmp(argv[argi], "16_565")) {
					options->override.ColorFormat = EMhwlibInputColorFormat_16BPP_565;
				} else if (! strcmp(argv[argi], "16_1555")) {
					options->override.ColorFormat = EMhwlibInputColorFormat_16BPP_1555;
				} else if (! strcmp(argv[argi], "16_4444")) {
					options->override.ColorFormat = EMhwlibInputColorFormat_16BPP_4444;
				} else if (! strcmp(argv[argi], "31_7888")) {
					options->override.ColorFormat = EMhwlibInputColorFormat_31BPP_7888;
				} else {
					RMDBGPRINT((ENABLE, "unknown color format: %s!\n", argv[argi]));
					err = RM_ERROR;
				}
				SCANPARAM(options->override.Width, "please specify a width", 2);
				SCANPARAM(options->override.Height, "please specify a height", 3);
			} else {
				RMDBGPRINT((ENABLE, "please specify a color format after %s\n", argv[argi - 1]));
				err = RM_ERROR;
			}
		}
		else if (! strcmp(&(argv[argi][1]), "freerun")) {
			if ((argi + 1 < argc) && (argv[argi + 1][0] != '-')) {
				SCANPARAM(options->audio_free_run, "please specify a value", 1);
			} else {
				options->audio_free_run = TRUE;
			}
		}
		else {
			err = RM_PENDING;
		}
	}
	if (err == RM_OK) 
		*index = argi + 1;
	
	return err;
}

// return frame size and interlaced status
static RMstatus get_video_size(
	struct RUA *pInstance, 
	enum EMhwlibTVStandard standard,
	RMuint32 *x_size,
	RMuint32 *y_size, 
	RMbool *interlaced)
{
	RMstatus err;
	struct EMhwlibTVFormatDigital format;
	
	err = RUAExchangeProperty(pInstance, DisplayBlock, 
		RMDisplayBlockPropertyID_TVFormatDigital, 
		&standard, sizeof(standard), 
		&format, sizeof(format));
	if (RMSUCCEEDED(err)) {
		*interlaced = format.TopFieldHeight ? TRUE : FALSE;
		*x_size = format.ActiveWidth;
		*y_size = format.ActiveHeight;
		if (*interlaced) {
			*y_size += format.ActiveHeight - format.YOffsetBottom + format.YOffsetTop;
		}
	}
	
	return err;
}

void get_aspect_ratio_from_video_mode(
	enum EMhwlibTVStandard TVStandard, 
	struct EMhwlibTVFormatDigital *pTVFormat, 
	RMbool wide,  // ambiguous modes (SDTV,EDTV): FALSE=4:3, TRUE=16:9 anamorphic
	RMuint32 *asp_x, 
	RMuint32 *asp_y)
{
	if (!asp_x || !asp_y) return;
	
	// determine aspect ratio from video mode
	switch (TVStandard) {
	case EMhwlibTVStandard_Custom:
		if (pTVFormat) {
			*asp_x = pTVFormat->ActiveWidth;
			*asp_y = pTVFormat->ActiveHeight;
			reduce_aspect_ratio(asp_x, asp_y, 0);
		} else {
			*asp_x = 4;
			*asp_y = 3;
		}
		break;
	case EMhwlibTVStandard_HDMI_720p59: 
	case EMhwlibTVStandard_HDMI_720p60: 
	case EMhwlibTVStandard_HDMI_1080i59: 
	case EMhwlibTVStandard_HDMI_1080i60: 
	case EMhwlibTVStandard_HDMI_1080p59: 
	case EMhwlibTVStandard_HDMI_1080p60: 
	case EMhwlibTVStandard_HDMI_720p50: 
	case EMhwlibTVStandard_HDMI_1080i50: 
	case EMhwlibTVStandard_HDMI_1080p50: 
	case EMhwlibTVStandard_HDMI_1080p23: 
	case EMhwlibTVStandard_HDMI_1080p24: 
	case EMhwlibTVStandard_HDMI_1080p25: 
	case EMhwlibTVStandard_HDMI_1080p29: 
	case EMhwlibTVStandard_HDMI_1080p30: 
	case EMhwlibTVStandard_HDMI_1080i50_1250: 
	case EMhwlibTVStandard_HDMI_1080i100: 
	case EMhwlibTVStandard_HDMI_720p100: 
	case EMhwlibTVStandard_HDMI_1080i119: 
	case EMhwlibTVStandard_HDMI_1080i120: 
	case EMhwlibTVStandard_HDMI_720p119: 
	case EMhwlibTVStandard_HDMI_720p120: 
	case EMhwlibTVStandard_1080p60: 
	case EMhwlibTVStandard_1080p59: 
	case EMhwlibTVStandard_1080p50: 
	case EMhwlibTVStandard_1080i60: 
	case EMhwlibTVStandard_1080i59: 
	case EMhwlibTVStandard_1080i50: 
	case EMhwlibTVStandard_1080i48: 
	case EMhwlibTVStandard_1080i47: 
	case EMhwlibTVStandard_1080p30: 
	case EMhwlibTVStandard_1080p29: 
	case EMhwlibTVStandard_1080p25: 
	case EMhwlibTVStandard_1080p24: 
	case EMhwlibTVStandard_1080p23: 
	case EMhwlibTVStandard_1080i50_1250: 
	case EMhwlibTVStandard_1080p50_1250: 
	case EMhwlibTVStandard_720p60: 
	case EMhwlibTVStandard_720p59: 
	case EMhwlibTVStandard_720p50: 
	case EMhwlibTVStandard_720p30: 
	case EMhwlibTVStandard_720p29: 
	case EMhwlibTVStandard_720p25: 
	case EMhwlibTVStandard_720p24: 
	case EMhwlibTVStandard_720p23: 
	case EMhwlibTVStandard_VESA_1360x768x60: 
	case EMhwlibTVStandard_VESA_1280x720x60: 
	case EMhwlibTVStandard_VESA_1280x720x75: 
	case EMhwlibTVStandard_VESA_1920x1080x60i: 
		*asp_x = 16;
		*asp_y = 9;
		break;
	case EMhwlibTVStandard_VESA_1280x768x60RB: 
	case EMhwlibTVStandard_VESA_1280x768x60: 
	case EMhwlibTVStandard_VESA_1280x768x75: 
	case EMhwlibTVStandard_VESA_1280x768x85: 
		*asp_x = 5;
		*asp_y = 3;
		break;
	case EMhwlibTVStandard_VESA_1280x1024x60: 
	case EMhwlibTVStandard_VESA_1280x1024x75: 
	case EMhwlibTVStandard_VESA_1280x1024x85: 
	case EMhwlibTVStandard_CVT_1280x1024x50: 
	case EMhwlibTVStandard_CVT_1280x1024x60: 
	case EMhwlibTVStandard_CVT_1280x1024x75: 
	case EMhwlibTVStandard_CVT_1280x1024x85: 
		*asp_x = 5;
		*asp_y = 4;
		break;
	case EMhwlibTVStandard_VESA_1920x1200x60RB: 
	case EMhwlibTVStandard_VESA_1920x1200x60: 
	case EMhwlibTVStandard_VESA_1920x1200x75: 
	case EMhwlibTVStandard_VESA_1920x1200x85: 
	case EMhwlibTVStandard_VESA_1440x900x60RB: 
	case EMhwlibTVStandard_VESA_1440x900x60: 
	case EMhwlibTVStandard_VESA_1440x900x75: 
	case EMhwlibTVStandard_VESA_1680x1050x60RB: 
	case EMhwlibTVStandard_VESA_1680x1050x60: 
		*asp_x = 8;
		*asp_y = 5;
		break;
	case EMhwlibTVStandard_VESA_720x400x70: 
		*asp_x = 9;
		*asp_y = 5;
		break;
	
	// SD/ED modes, ambiguous
	case EMhwlibTVStandard_HDMI_480p59: 
	case EMhwlibTVStandard_HDMI_480p60: 
	case EMhwlibTVStandard_HDMI_480i59: 
	case EMhwlibTVStandard_HDMI_480i60: 
	case EMhwlibTVStandard_HDMI_1440x480i59: 
	case EMhwlibTVStandard_HDMI_1440x480i60: 
	case EMhwlibTVStandard_HDMI_240p59: 
	case EMhwlibTVStandard_HDMI_240p60: 
	case EMhwlibTVStandard_HDMI_1440x240p59: 
	case EMhwlibTVStandard_HDMI_1440x240p60: 
	case EMhwlibTVStandard_HDMI_2880x480i59: 
	case EMhwlibTVStandard_HDMI_2880x480i60: 
	case EMhwlibTVStandard_HDMI_2880x240p59: 
	case EMhwlibTVStandard_HDMI_2880x240p60: 
	case EMhwlibTVStandard_HDMI_1440x480p59: 
	case EMhwlibTVStandard_HDMI_1440x480p60: 
	case EMhwlibTVStandard_HDMI_576p50: 
	case EMhwlibTVStandard_HDMI_576i50: 
	case EMhwlibTVStandard_HDMI_1440x576i50: 
	case EMhwlibTVStandard_HDMI_288p50: 
	case EMhwlibTVStandard_HDMI_1440x288p50: 
	case EMhwlibTVStandard_HDMI_2880x576i50: 
	case EMhwlibTVStandard_HDMI_2880x288p50: 
	case EMhwlibTVStandard_HDMI_1440x576p50: 
	case EMhwlibTVStandard_HDMI_2880x480p59: 
	case EMhwlibTVStandard_HDMI_2880x480p60: 
	case EMhwlibTVStandard_HDMI_2880x576p50: 
	case EMhwlibTVStandard_HDMI_576p100: 
	case EMhwlibTVStandard_HDMI_576i100: 
	case EMhwlibTVStandard_HDMI_1440x576i100: 
	case EMhwlibTVStandard_HDMI_480p119: 
	case EMhwlibTVStandard_HDMI_480p120: 
	case EMhwlibTVStandard_HDMI_480i119: 
	case EMhwlibTVStandard_HDMI_480i120: 
	case EMhwlibTVStandard_HDMI_1440x480i119: 
	case EMhwlibTVStandard_HDMI_1440x480i120: 
	case EMhwlibTVStandard_HDMI_576p200: 
	case EMhwlibTVStandard_HDMI_576i200: 
	case EMhwlibTVStandard_HDMI_1440x576i200: 
	case EMhwlibTVStandard_HDMI_480p239: 
	case EMhwlibTVStandard_HDMI_480p240: 
	case EMhwlibTVStandard_HDMI_480i239: 
	case EMhwlibTVStandard_HDMI_480i240: 
	case EMhwlibTVStandard_HDMI_1440x480i239: 
	case EMhwlibTVStandard_HDMI_1440x480i240: 
	case EMhwlibTVStandard_ITU_Bt656_525: 
	case EMhwlibTVStandard_ITU_Bt656_240p: 
	case EMhwlibTVStandard_NTSC_M_Japan: 
	case EMhwlibTVStandard_NTSC_M: 
	case EMhwlibTVStandard_PAL_60: 
	case EMhwlibTVStandard_PAL_M: 
	case EMhwlibTVStandard_480p59: 
	case EMhwlibTVStandard_NTSC_M_Japan_714: 
	case EMhwlibTVStandard_NTSC_M_714: 
	case EMhwlibTVStandard_PAL_60_714: 
	case EMhwlibTVStandard_PAL_M_714: 
	case EMhwlibTVStandard_480p59_714: 
	case EMhwlibTVStandard_ITU_Bt656_625: 
	case EMhwlibTVStandard_ITU_Bt656_288p: 
	case EMhwlibTVStandard_PAL_BG: 
	case EMhwlibTVStandard_PAL_N: 
	case EMhwlibTVStandard_576p50: 
	case EMhwlibTVStandard_PAL_BG_702: 
	case EMhwlibTVStandard_PAL_N_702: 
	case EMhwlibTVStandard_576p50_702: 
		if (wide) {
			*asp_x = 16;
			*asp_y = 9;
			break;
		}
	
	// all others, 4:3
	default:
		*asp_x = 4;
		*asp_y = 3;
		break;
	}
}

static RMstatus build_capture_profile(
	struct RUA *pInstance, 
	struct capture_cmdline *ip, 
	struct DCCCaptureProfile *cp)
{
	RMstatus err;
	RMuint32 x_size, y_size;
	RMbool interlaced;
	
	if (ip->SurfaceColorSpace == EMhwlibColorSpace_None) 
		ip->SurfaceColorSpace = ip->InputColorSpace;
	
	err = get_video_size(pInstance, ip->TVStandard, &x_size, &y_size, &interlaced);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Could not find video format #%u: %s\n", ip->TVStandard, RMstatusToString(err)));
		return err;
	}
	
	ip->over_pos_x = ip->shift_x - (ip->ov_lft << ((ip->bussize == 8) ? 1 : 0));
	ip->over_pos_y = ip->shift_y - ip->ov_top;
	ip->over_width = (ip->ov_lft + ip->ov_rgt) << ((ip->bussize == 8) ? 1 : 0);
	ip->over_height = ip->ov_top + ip->ov_bot;
	
	cp->SamplingMode = ip->SamplingMode;
	cp->ColorMode = ip->ColorMode;
	cp->Width = x_size + ip->over_width;
	cp->Height = y_size + ip->over_height;
	cp->OrigWidth = x_size;
	cp->OrigHeight = y_size;
	cp->Interlaced = interlaced;
	cp->ColorSpace = ip->SurfaceColorSpace;
	cp->DeInt = ip->DeInt;
	cp->UseV2Pads = ip->UseV2Pads;
	
	if (ip->bussize == 8) {
		cp->ColorFormat = EMhwlibColorFormat_16BPP_565;
	} else if (ip->bussize == 16) {
		switch(ip->InputColorFormat) {
		case EMhwlibInputColorFormat_24BPP:
		case EMhwlibInputColorFormat_16BPP_565:
			cp->ColorFormat = EMhwlibColorFormat_16BPP_565;
			break;
		case EMhwlibInputColorFormat_24BPP_8565:
		case EMhwlibInputColorFormat_24BPP_5676:
		case EMhwlibInputColorFormat_32BPP:
		case EMhwlibInputColorFormat_16BPP_4444:
		case EMhwlibInputColorFormat_31BPP_7888:
			cp->ColorFormat = EMhwlibColorFormat_16BPP_4444;
			break;
		case EMhwlibInputColorFormat_16BPP_1555:
			cp->ColorFormat = EMhwlibColorFormat_16BPP_1555;
			break;
		}
	} else if (ip->bussize == 32) {
		switch(ip->InputColorFormat) {
		case EMhwlibInputColorFormat_24BPP:
		case EMhwlibInputColorFormat_16BPP_565:
			cp->ColorFormat = EMhwlibColorFormat_24BPP;
			break;
		case EMhwlibInputColorFormat_24BPP_8565:
		case EMhwlibInputColorFormat_24BPP_5676:
		case EMhwlibInputColorFormat_32BPP:
		case EMhwlibInputColorFormat_16BPP_1555:
		case EMhwlibInputColorFormat_16BPP_4444:
		case EMhwlibInputColorFormat_31BPP_7888:
			cp->ColorFormat = EMhwlibColorFormat_32BPP;
			break;
		}
	}
	
	// convert picture aspect ratio to pixel aspect ratio or vice versa
	// TODO use picture aspect ratio directly, when implemented in irq handler.
	if (ip->PixelAspectRatio.X && ip->PixelAspectRatio.Y) {
		cp->PixelAspectRatio = ip->PixelAspectRatio;
		cp->PictureAspectRatio.X = cp->PixelAspectRatio.X * cp->OrigWidth;
		cp->PictureAspectRatio.Y = cp->PixelAspectRatio.Y * cp->OrigHeight;
		reduce_aspect_ratio(&(cp->PictureAspectRatio.X), &(cp->PictureAspectRatio.Y), 255);
	} else {
		cp->PictureAspectRatio = ip->PictureAspectRatio;
		cp->PixelAspectRatio.X = cp->PictureAspectRatio.X * cp->OrigHeight;
		cp->PixelAspectRatio.Y = cp->PictureAspectRatio.Y * cp->OrigWidth;
		reduce_aspect_ratio(&(cp->PixelAspectRatio.X), &(cp->PixelAspectRatio.Y), 255);
	}
	
	return err;
}

RMstatus setup_capture(
	struct dcc_context *dcc_info, 
	struct DCCVideoSource **ppVideoSource, 
	struct capture_cmdline *capture_opt, 
	RMuint16 **ppVBIData, 
	struct ReceiveObject_type **ppR, 
	struct RUABufferPool **ppDmaReceive, 
	RMuint32 TimerNumber, 
	RMbool use_gpio, 
	RMbool inv_fid)
{
	RMstatus err;
	struct DCCCaptureProfile cp;
	RMuint32 old_vbi_size;
	
	if (! ppVideoSource) {
		RMDBGLOG((ENABLE, "ppVideoSource can not be NULL!\n"));
		return RM_FATALINVALIDPOINTER;
	}
	// create capture profile from options
	err = build_capture_profile(dcc_info->pRUA, capture_opt, &cp);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Could not build capture profile: %s\n", RMstatusToString(err)));
		return err;
	}
	
	// open (and potentially create) video source
	if (EMHWLIB_MODULE_CATEGORY(capture_opt->InputModuleID) == DispVideoInput) {
		err = DCCOpenVideoInputSource(dcc_info->pDCC, &cp, TimerNumber, capture_opt->dram, ppVideoSource);
	} else if (EMHWLIB_MODULE_CATEGORY(capture_opt->InputModuleID) == DispGraphicInput) {
		err = DCCOpenGraphicInputSource(dcc_info->pDCC, &cp, TimerNumber, capture_opt->dram, ppVideoSource);
	} else if (EMHWLIB_MODULE_CATEGORY(capture_opt->InputModuleID) == DispColorBars) {
		capture_opt->disablescaler = TRUE;
		capture_opt->guess = FALSE;
		return RM_OK;
	} else {
		err = RM_ERROR;
	}
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Could not open video source: %s\n", RMstatusToString(err)));
		return err;
	}
	
	// set up input
	if (capture_opt->InputModuleID == DispGraphicInput) {
		err = DCCSetupGraphicInput(dcc_info->pDCC, 
			capture_opt->TVStandard, 
			capture_opt->DigitalTimingSignal, 
			capture_opt->UseVideoValid, 
			capture_opt->bussize, 
			capture_opt->over_pos_x, 
			capture_opt->over_pos_y, 
			capture_opt->over_width, 
			capture_opt->over_height, 
			capture_opt->DualEdge, 
			capture_opt->DualEdgeWidth, 
			capture_opt->DualEdgeInvert, 
			capture_opt->InputColorFormat, 
			capture_opt->InputColorSpace, 
			capture_opt->InvertVSync, 
			capture_opt->InvertHSync, 
			inv_fid, use_gpio);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error setting graphic input: %s\n", RMstatusToString(err)));
			return err;
		}
	} else if (capture_opt->InputModuleID == DispVideoInput) {
		if (capture_opt->bussize > 16) {
			RMDBGLOG((ENABLE, "video input can't capture 24 or 32 bit video!\n"));
			return RM_ERROR;
		}
		err = DCCSetupVideoInput(dcc_info->pDCC, 
			capture_opt->TVStandard, 
			capture_opt->DigitalTimingSignal, 
			capture_opt->UseVideoValid, 
			capture_opt->bussize, 
			capture_opt->over_pos_x, 
			capture_opt->over_pos_y, 
			capture_opt->over_width, 
			capture_opt->over_height, 
			capture_opt->InvertVSync, 
			capture_opt->InvertHSync, 
			inv_fid, use_gpio);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error setting video input: %s\n", RMstatusToString(err)));
			return err;
		}
	}
	
	while ((err = RUASetProperty(dcc_info->pRUA, capture_opt->InputModuleID, RMGenericPropertyID_PictureOverride, &(capture_opt->override), sizeof(capture_opt->override), 0)) == RM_PENDING);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set PictureOverride on input: %s\n", RMstatusToString(err)));
	}
	
	if (! capture_opt->disablescaler) {
		// set surface into scaler
		err = DCCSetSurfaceSource(dcc_info->pDCC, dcc_info->SurfaceID, *ppVideoSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set the surface source %d\n", err));
			return err;
		}
	}
	
	// set up VBI capture
	old_vbi_size = capture_opt->vbi_size;
	capture_opt->vbi_size = 0;
	
	// determine vbi capture mode and depending window size
	if (capture_opt->vbianc_enable) {
		capture_opt->vbi_h = capture_opt->vbianc_h * 2;  // assume interlaced - TODO look at input format
		capture_opt->vbi_w = capture_opt->vbianc_w / 2;
	} else if (capture_opt->vbiraw_topmask || capture_opt->vbiraw_botmask) {
		RMuint32 top_lines, bot_lines, mask, i;
		top_lines = 0;
		mask = capture_opt->vbiraw_topmask;
		for (i = 0; i < 24; i++) {
			if (mask & 1) top_lines++;
			mask >>= 1;
		}
		bot_lines = 0;
		mask = capture_opt->vbiraw_botmask;
		for (i = 0; i < 24; i++) {
			if (mask & 1) bot_lines++;
			mask >>= 1;
		}
		capture_opt->vbi_h = ((top_lines > bot_lines) ? top_lines : bot_lines) * 2;  // assume interlaced - TODO
		capture_opt->vbi_w = 720;  // assume PAL or NTSC - TODO
	}
	
	// allocate VBI buffer
	if (capture_opt->vbi_w && capture_opt->vbi_h) {
		capture_opt->vbi_size = capture_opt->vbi_w * capture_opt->vbi_h * 2;
		if (capture_opt->vbi_dma) {
			if (ppR && ppDmaReceive) {
				struct Receive_type Receive;
				Receive.pRUA = dcc_info->pRUA;
				Receive.targetModule = EMHWLIB_TARGET_MODULE(
					EMHWLIB_MODULE_CATEGORY(capture_opt->InputModuleID), 
					EMHWLIB_MODULE_INDEX(capture_opt->InputModuleID), 
					1);
				Receive.buffer_count = 4;
				Receive.buffer_size_log2 = 15;  // 32k per buffer -> 128k
				Receive.threshold_size = 1 << Receive.buffer_size_log2;  /* every buffer we receive interrupt */
				Receive.partial_read = FALSE;
				err = DCCOpenReceive(&Receive, ppR, ppDmaReceive);
			}
//			capture_opt->vbi_buf = 0;
			capture_opt->vbi_size += 12;  // size of one VBI data block, including header
//			if (ppVBIData) *ppVBIData = NULL;
		} else {
			if (ppVBIData) {
				if (((old_vbi_size / 300 - 12) != capture_opt->vbi_size) && *ppVBIData) {
					RMFree(*ppVBIData);
					*ppVBIData = NULL;
					if (capture_opt->vbi_buf) {
						RUAFree(dcc_info->pRUA, capture_opt->vbi_buf);
						capture_opt->vbi_buf = 0;
					}
				}
				if (! *ppVBIData) *ppVBIData = (RMuint16 *)RMMalloc(capture_opt->vbi_size);
			}
			capture_opt->vbi_size = (capture_opt->vbi_size + 12) * 300;  // number of VBI buffers
			if (! capture_opt->vbi_buf) {
				capture_opt->vbi_buf = DCCMalloc(dcc_info->pDCC, 0, RUA_DRAM_UNCACHED, capture_opt->vbi_size);
			}
			printf("Storing 0x%08lX bytes of VBI data from 0x%08lX to 0x%08lX\n", 
				capture_opt->vbi_size, capture_opt->vbi_buf, capture_opt->vbi_buf + capture_opt->vbi_size);
//			if (ppDmaReceive) *ppDmaReceive = NULL;
//			if (ppR) *ppR = NULL;
		}
	}
	
	// enable/disable ANC type vbi capture
	err = DCCSetupVBICaptureANC(dcc_info->pDCC, capture_opt->InputModuleID, 
		capture_opt->vbianc_enable, 
		capture_opt->vbianc_w, capture_opt->vbianc_h, 
		capture_opt->vbianc_ytop, capture_opt->vbianc_ybot, 
		capture_opt->vbi_dma ? 0 : capture_opt->vbi_buf, capture_opt->vbi_dma ? 0 : capture_opt->vbi_size);
	if (RMFAILED(err)) return err;
	
	// enable/disable Raw type vbi capture
	err = DCCSetupVBICaptureRaw(dcc_info->pDCC, capture_opt->InputModuleID, 
		capture_opt->vbiraw_topstart, capture_opt->vbiraw_topmask, 
		capture_opt->vbiraw_botstart, capture_opt->vbiraw_botmask, 
		capture_opt->vbi_dma ? 0 : capture_opt->vbi_buf, capture_opt->vbi_dma ? 0 : capture_opt->vbi_size);
	if (RMFAILED(err)) return err;
	
	// enable 601 type vbi capture
	if (
		(! capture_opt->vbianc_enable) &&  // is not ANC,
		(! (capture_opt->vbiraw_topmask || capture_opt->vbiraw_botmask)) &&  // is not Raw,
		capture_opt->vbi_w && capture_opt->vbi_h  // but window defined --> is 601
	) {
		err = DCCSetupVBICapture(dcc_info->pDCC, capture_opt->InputModuleID, 
			capture_opt->vbi_x, capture_opt->vbi_y, 
			capture_opt->vbi_w, capture_opt->vbi_h, 
			capture_opt->vbi_dma ? 0 : capture_opt->vbi_buf, capture_opt->vbi_dma ? 0 : capture_opt->vbi_size);
		if (RMFAILED(err)) return err;
	}
	
	return RM_OK;
}

RMstatus apply_capture_options(
	struct dcc_context *dcc_info, 
	struct DCCVideoSource **ppVideoSource, 
	struct capture_cmdline *options, 
	RMuint16 **ppVBIData, 
	struct ReceiveObject_type **ppR, 
	struct RUABufferPool **ppDmaReceive, 
	RMuint32 TimerNumber, 
	RMbool use_gpio, 
	RMbool inv_fid)
{
	RMstatus err;
	
	// set up the input
	err = setup_capture(dcc_info, ppVideoSource, options, ppVBIData, ppR, ppDmaReceive, TimerNumber, use_gpio, inv_fid);
	if (RMFAILED(err)) return err;
	
	return RM_OK;
}

RMstatus guess_capture_format(
	struct dcc_context *dcc_info, 
	struct capture_cmdline *options)
{
	RMstatus err;
	RMuint64 XtalPerField = 0, ClocksPerField = 0, LinesPerField = 0, ClocksPerLine = 0;
	RMuint32 i, samples = 0;
	RMuint32 VFreq;
	
	// sample sets of values for averaging
	for (i = 0; i < 50; i++) {  // half second
		struct Input_Detect_type det;
		err = RUAGetProperty(dcc_info->pRUA, options->InputModuleID, 
			RMGenericPropertyID_Detect, 
			&det, sizeof(det));
		if (RMFAILED(err)) printf("Error getting property Detect: %s\n", RMstatusToString(err));
		if (i >= 3) {  // skip first three measurements
			XtalPerField += det.XtalPerField;
			ClocksPerField += det.ClocksPerField;
			LinesPerField += det.LinesPerField;
			ClocksPerLine += det.ClocksPerLine;
			samples++;
		}
		usleep(10000);
	}
	
	// average sampled values
	VFreq = XtalPerField ? 2700000000U / (RMuint32)(XtalPerField / samples) : 0;
	ClocksPerField /= samples;
	LinesPerField /= samples;
	ClocksPerLine /= samples;
	
	//printf("Guessing captured video format\n  Measured values are: %ld.%02ld Hz, %ld pix/field, %ld lines/field, %ld pix/line\n", 
	//	VFreq / 100, VFreq % 100, 
	//	(RMuint32)ClocksPerField, 
	//	(RMuint32)LinesPerField, 
	//	(RMuint32)ClocksPerLine);
	
	// maintain minimum thresholds: 10 Hz, 10000 cpf, 48 lpf, 128 cpl
	if (
		(VFreq && (VFreq < 1000)) || 
		(ClocksPerField && (ClocksPerField < 10000)) || 
		(LinesPerField && (LinesPerField < 48)) || 
		(ClocksPerLine && (ClocksPerLine < 128))
	) {
		printf("No Video!\n");
		return RM_ERROR;
	}
	
	// match with closest TVStandard
	{
		enum EMhwlibTVStandard prevTVStandard = options->TVStandard;
		enum EMhwlibTVStandard best_match = EMhwlibTVStandard_Custom;
		RMuint32 curr_VFreq, curr_ClocksPerField, curr_HalfLinesPerField, curr_ClocksPerLine;
		RMint32 diff_VFreq, diff_ClocksPerField, diff_LinesPerField, diff_ClocksPerLine;
		RMuint64 err, min_err = 0xFFFFFFFFFFFFFFFFULL;
		RMascii *StandardName;
		
		options->TVStandard = 1;
		while (RMSUCCEEDED(GetTVStandardName(options->TVStandard, &StandardName))) {
			struct EMhwlibTVFormatDigital dig;
			RMuint32 dig_clk;
			
			err = RUAExchangeProperty(dcc_info->pRUA, DisplayBlock, 
				RMDisplayBlockPropertyID_TVFormatDigital, 
				&(options->TVStandard), sizeof(options->TVStandard), 
				&dig, sizeof(dig));
			if RMFAILED(err) {
				RMDBGLOG((ENABLE, "Could not get format for TV Standard %s!\n", StandardName));
				return err;
			}
			err = RUAExchangeProperty(dcc_info->pRUA, DisplayBlock, 
				RMDisplayBlockPropertyID_TVPixelClockDigital, 
				&(options->TVStandard), sizeof(options->TVStandard), 
				&dig_clk, sizeof(dig_clk));
			if RMFAILED(err) {
				RMDBGLOG((ENABLE, "Could not get pixel clock for TV Standard %s!\n", StandardName));
				return err;
			}
			curr_HalfLinesPerField = dig.VTotalSize;
			if (! dig.TopFieldHeight) curr_HalfLinesPerField *= 2;
			curr_ClocksPerLine = dig.HTotalSize;
			if (options->bussize == 8) curr_ClocksPerLine *= 2;
			curr_ClocksPerField = curr_HalfLinesPerField * curr_ClocksPerLine / 2;
			if (options->bussize == 8) dig_clk *= 2;
			curr_VFreq = (RMuint32)((RMuint64)dig_clk * 100L / curr_ClocksPerField);
			
			if (0) printf("Mode: %s - %ld Hz, %ld.%02ld Hz, %ld pix/field, %ld lines/field, %ld pix/line\n", 
				StandardName, dig_clk, 
				curr_VFreq / 100, curr_VFreq % 100, 
				curr_ClocksPerField, 
				curr_HalfLinesPerField / 2, 
				curr_ClocksPerLine);
			
			diff_VFreq = (VFreq) ? VFreq - curr_VFreq : 0;
			diff_ClocksPerField = (ClocksPerField) ? ClocksPerField - curr_ClocksPerField : 0;
			diff_LinesPerField = (LinesPerField) ? LinesPerField - curr_HalfLinesPerField / 2 : 0;
			diff_ClocksPerLine = (ClocksPerLine) ? ClocksPerLine - curr_ClocksPerLine : 0;
			err = diff_VFreq * diff_VFreq + diff_ClocksPerField * diff_ClocksPerField +
				diff_LinesPerField * diff_LinesPerField + diff_ClocksPerLine * diff_ClocksPerLine;
			
			if (0) printf("deviation: dist^2: %llu (min = %llu) diff: %s%d.%02d Hz, %ld pix/field, %ld lines/field, %ld pix/line\n", 
				err, min_err, 
				(diff_VFreq < 0) ? "-" : "", abs(diff_VFreq) / 100, abs(diff_VFreq) % 100, 
				diff_ClocksPerField, 
				diff_LinesPerField / 2, 
				diff_ClocksPerLine);
			
			if (err < min_err) {
				min_err = err;
				best_match = options->TVStandard;
			}
			
			options->TVStandard ++;
		}
		
		if (best_match != EMhwlibTVStandard_Custom) {
			options->TVStandard = best_match;
		} else {
			options->TVStandard = prevTVStandard;
		}
	}
	
	return RM_OK;
}

RMstatus close_capture(
	struct dcc_context *dcc_info, 
	struct DCCVideoSource **ppVideoSource, 
	struct capture_cmdline *capture_opt, 
	RMuint16 **ppVBIData, 
	struct ReceiveObject_type **ppR, 
	struct RUABufferPool **ppDmaReceive)
{
	RMstatus err;
	
	// disable ANC type vbi capture
	err = DCCSetupVBICaptureANC(dcc_info->pDCC, capture_opt->InputModuleID, 
		FALSE, 0, 0, 0, 0, 0, 0);
	if (RMFAILED(err)) return err;
	
	// disable Raw type vbi capture
	err = DCCSetupVBICaptureRaw(dcc_info->pDCC, capture_opt->InputModuleID, 
		0, 0, 0, 0, 0, 0);
	if (RMFAILED(err)) return err;
	
	// disable 601 type vbi capture
	err = DCCSetupVBICapture(dcc_info->pDCC, capture_opt->InputModuleID, 
		0, 0, 0, 0, 0, 0);
	if (RMFAILED(err)) return err;
	
	// close input and remove old surface
	if (ppVideoSource && *ppVideoSource) {
		//fprintf(stderr, "Closing VideoSource\n");
		err = DCCCloseVideoSource(*ppVideoSource);
		*ppVideoSource = NULL;
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Could not clean surface: %s\n", RMstatusToString(err)));
		}
	}
	
	// TODO closing DMA fails, needs to be fixed!!!
	// close old VBI capture, if any
	if (ppR && *ppR) {
//		RMuint32 n;
		fprintf(stderr, "Closing DMA VBI receiver\n");
//		n = 25;
//		do {
//			if (ppDmaReceive && *ppDmaReceive) {
//				RMuint8 *pBuf = NULL;
//				RMuint32 size = 0;
//				RMuint32 targetModule = EMHWLIB_TARGET_MODULE(
//					EMHWLIB_MODULE_CATEGORY(capture_opt->InputModuleID), 
//					EMHWLIB_MODULE_INDEX(capture_opt->InputModuleID), 
//					1);
//				fprintf(stderr, "Receiving remaining DMA buffers\n");
//				do {
//					err = RUAReceiveData(dcc_info->pRUA, targetModule, *ppDmaReceive, &pBuf, &size, NULL, NULL);
//					fprintf(stderr, "RUAReceiveData(): %s, %p, %lu\n", RMstatusToString(err), pBuf, size);
//					if (RMSUCCEEDED(err) && pBuf && size) {
//						RUAReleaseBuffer(*ppDmaReceive, pBuf);
//					}
//				} while (RMSUCCEEDED(err) /*|| (err == RM_PENDING)*/);
//			}
//			if ((*ppR)->pDMA) err = RUAResetPool((*ppR)->pDMA);
//			else err = RM_OK;
//		} while (--n && RMFAILED(err));
		//DCCResetReceive(*ppR);
//		DCCCloseReceive(*ppR);
		//*ppR = NULL;
	}
	if (ppVBIData && *ppVBIData) {
		fprintf(stderr, "Releasing VBIData buffer\n");
		RMFree(*ppVBIData);
		*ppVBIData = NULL;
	}
	if (capture_opt->vbi_buf) {
		fprintf(stderr, "Releasing vbi_buf\n");
		DCCFree(dcc_info->pDCC, capture_opt->vbi_buf);
		capture_opt->vbi_buf = 0;
	}
	
	return err;
}

