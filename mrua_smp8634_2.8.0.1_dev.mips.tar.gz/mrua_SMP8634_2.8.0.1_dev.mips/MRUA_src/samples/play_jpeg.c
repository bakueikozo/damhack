/*
 *
 * Copyright (c) Sigma Designs, Inc. 2002. All rights reserved.
 *
 */

/**
	@file play_jpeg.c
	@brief sample application to access the Mambo chip and display JPEG pictures on the video plane
	
	@author Pascal Cannenterre
   	@ingroup dccsamplecode
*/

#if 0
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>

#define ALLOW_OS_CODE 1
#include "common.h"
#define YYYY_UV
#include "../rmlibjpeg/src/libjpeg/jpeglib.h"

#define KEYFLAGS (SET_KEY_DISPLAY | SET_KEY_PLAYBACK | SET_KEY_DEBUG)

#define WAIT_SURFACE_READY (250*1000)
int surface_is_ready = 0;

char *filename = (char *) NULL;
char *filename2 = (char *) NULL;
RMuint32 grey_w, grey_h;
struct playback_cmdline play_opt = {0,};
struct display_cmdline disp_opt = {0,};
struct video_cmdline video_opt = {0,};

void * main2(void * thread_arg);
void show_usage(char *progname);
void parse_cmdline(int argc, char *argv[]);
void myjpeg_error_exit(j_common_ptr cinfo);
FILE *load_jpg_file
(
 struct jpeg_decompress_struct *cinfo,
 struct jpeg_error_mgr *jerr,
 RMascii *filename, 
 struct DCCOSDProfile * posd_profile
 );
RMstatus decompress_jpg_file 
(
 struct jpeg_decompress_struct *cinfo,
 FILE *fd,
 RMuint8 * pLuma,
 RMuint8 * pChroma
 );
void create_grey_420(RMuint32 width, RMuint32 height, RMuint8 *Y_plane, RMuint8 *UV_plane);

void show_usage(char *progname)
{
	show_display_options();
	show_video_options();
	
	fprintf(stderr, "\t-grey <w> <h>: display a zig-zag grey pattern of the specified size\n");
	fprintf(stderr, "---------------------------------------------------------------\n");
	fprintf(stderr, "Minimum cmd line: %s <filename1.jpg> [<filename2.jpg>]\n", progname);
	fprintf(stderr, "---------------------------------------------------------------\n");

	exit(1);
}

void parse_cmdline(int argc, char *argv[])
{
	RMint32 i;
	RMstatus err;
	
	grey_w = grey_h = 0;

	if (argc < 2) 
		show_usage(argv[0]);
	
	i = 1;
	while ((argc > i)) {
		if (argv[i][0] != '-') {
			if (filename == NULL) {
				filename = argv[i];
				i++;
			}
			else if(filename2 == NULL) {
				filename2 = argv[i];
				i++;
			} 
			else
				show_usage(argv[0]);
		}
		else {
			err = RM_PENDING;
			if (RMCompareAscii(argv[i], "-grey")) {
				if (argc > i+2) {
					RMasciiToUInt32(argv[i+1], &grey_w);
					RMasciiToUInt32(argv[i+2], &grey_h);
					i += 3;
					err = RM_OK;
				}
				else
					err = RM_ERROR;
			}
			if (err == RM_ERROR)
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_playback_cmdline(argc, argv, &i, &play_opt);
			if (err == RM_ERROR) 
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_display_cmdline(argc, argv, &i, &disp_opt);
			if (err == RM_ERROR) 
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_video_cmdline(argc, argv, &i, &video_opt);
			if (RMFAILED(err))
				show_usage(argv[0]);
		}
	}

	if ((filename == NULL) && (!grey_w || !grey_h))
		show_usage(argv[0]);
}

void myjpeg_error_exit(j_common_ptr cinfo)
{
	RMDBGLOG((ENABLE, "JPEG error: \n  "));
	(*cinfo->err->output_message)(cinfo);
	jpeg_destroy(cinfo);
	exit(1);
}

FILE *load_jpg_file
(
 struct jpeg_decompress_struct *cinfo,
 struct jpeg_error_mgr *jerr,
 RMascii *filename, 
 struct DCCOSDProfile * posd_profile
 )
{
	FILE *fd;
	
	RMuint32 JpegWidth;
	RMuint32 JpegHeight;
	RMuint32 yuvWidth1;
	RMuint32 yuvHeight1;
	
	if((cinfo == NULL) || 
	   (filename == NULL) || 
	   (posd_profile == NULL))
		return (FILE*)NULL;
	
	fd = fopen(filename, "rb");
	if (fd == NULL) {
		fprintf(stderr, "Bitmap file not found: %s\n", filename);
		return (FILE*)NULL;
	}

	RMMemset(cinfo, 0, sizeof(struct jpeg_decompress_struct));
	
	cinfo->err = jpeg_std_error(jerr);
	cinfo->err->error_exit = myjpeg_error_exit;
	jpeg_create_decompress(cinfo);
	jpeg_stdio_src(cinfo, fd);
	jpeg_read_header(cinfo, TRUE);
	
	if (cinfo->progressive_mode) {
		fprintf(stderr, "jpeg file must not be in progressive mode\n");
		jpeg_destroy_decompress (cinfo);
		fclose(fd);
		return (FILE*)NULL;
	}
	if (cinfo->jpeg_color_space == JCS_GRAYSCALE || cinfo->jpeg_color_space == JCS_YCbCr) {
		cinfo->out_color_space = cinfo->jpeg_color_space;
		posd_profile->ColorSpace = EMhwlibColorSpace_YUV_601;
	} else {
		fprintf(stderr, "jpeg file needs to be in YUV color space\n");
		jpeg_destroy_decompress (cinfo);
		fclose(fd);
		return (FILE*)NULL;
	}
	if ((cinfo->image_width <= 0) || (cinfo->image_height <= 0)) {
		fprintf(stderr, "illegal image size: %d x %d pixel\n", cinfo->image_width, cinfo->image_height);
		jpeg_destroy_decompress (cinfo);
		fclose(fd);
		return (FILE*)NULL;
	}
	
	cinfo->dct_method = JDCT_IFAST;
	cinfo->scale_num = 1;
	cinfo->scale_denom = 1;
	cinfo->quantize_colors = FALSE;
	cinfo->raw_data_out = TRUE;
	jpeg_start_decompress(cinfo);
	
	JpegWidth  = cinfo->output_width;
	JpegHeight = cinfo->output_height;
	yuvWidth1  = (JpegWidth  + 15) & ~0xF;
	yuvHeight1 = (JpegHeight + 15) & ~0xF;
	
	posd_profile->SamplingMode = EMhwlibSamplingMode_420;
	posd_profile->ColorMode = EMhwlibColorMode_VideoNonInterleaved;
	posd_profile->ColorFormat = EMhwlibColorFormat_32BPP;
	posd_profile->PixelAspectRatio.X = 1;
	posd_profile->PixelAspectRatio.Y = 1;
	posd_profile->Width = yuvWidth1;
	posd_profile->Height = yuvHeight1;

	fprintf(stdout, "\nOriginal JPEG image %lu x %lu pixels\n", 
		JpegWidth, 
		JpegHeight);
	fprintf(stdout, "Displayed image will be %lu x %lu pixels\n\n", 
		yuvWidth1, 
		yuvHeight1);
	
	return fd;
}

void create_grey_420(RMuint32 width, RMuint32 height, RMuint8 *Y_plane, RMuint8 *UV_plane)
{
	RMuint32 i, j, k, x, y;
	RMuint8 luma;
	
	/* fill chroma buffer with 0x80 0x80 */
	for (y = 0; y < height; y+=2) {
		for (x = 0; x < width; x+=2) {
			*UV_plane++ = 0x80;
			*UV_plane++ = 0x80;
		}
	}
	
	/* slow but precise: fill luma buffer with zig-zag pattern from 0 to 255 */
	/* top 16th of image:   0 ..  15 */
	/* 2nd 16th of image:  31 ..  16 */
	/* 3rd 16th of image:  32 ..  47 etc. */
	/* bot 16th of image: 255 .. 240 */
	for (y = 0; y < height; y++) {
		j = y * 16 / height;
		for (x = 0; x < width; x++) {
			i = x * 16 / width;
			k = (j & 1) ? (15 - i) : i;
			luma = j * 16 + k;
			*Y_plane++ = luma;
		}
	}
}


RMstatus decompress_jpg_file 
(
 struct jpeg_decompress_struct *cinfo,
 FILE *fd,
 RMuint8 * pLuma,
 RMuint8 * pChroma
 )
{
	RMuint32 yuvWidth1=0,yuvHeight1=0;
	
	if( (cinfo == NULL) || 
	    (fd == NULL) || 
	    (pLuma == NULL) || 
	    (pChroma == NULL))
		return RM_ERROR;
		
	yuvWidth1  = (cinfo->output_width + 15) & ~0xF;
	yuvHeight1 = (cinfo->output_height + 15) & ~0xF;
 
	jpeg_read_image_420(cinfo, pLuma, pChroma);

	{
		RMuint32 i,j;
		RMuint32 jpeg_width_rounded = ((cinfo->output_width + 1) & ~0x1) + 2;
		RMuint32 jpeg_height_rounded = ((cinfo->output_height + 1) & ~0x1);
		// chroma treatment
		for(j=0;j<(yuvHeight1/2);j++) {
			if(j>=(jpeg_height_rounded/2)) {
				for(i=0;i<yuvWidth1;i++) {
					pChroma[i+j*yuvWidth1] = 128;
				}
			} else {
				for(i=jpeg_width_rounded;i<yuvWidth1;i++) {
					pChroma[i+j*yuvWidth1] = 128;
				}
			}
		}
		// luma treatment
		for(j=0;j<yuvHeight1;j++) {
			if(j>=jpeg_height_rounded) {
				for(i=0;i<yuvWidth1;i++) {
					pLuma[i+j*yuvWidth1] = 16;
				}
			} else {
				for(i=jpeg_width_rounded;i<yuvWidth1;i++) {
					pLuma[i+j*yuvWidth1] = 16;
				}
			}
		}
	}
	
	jpeg_destroy_decompress(cinfo);
	
	fclose(fd);
	
	return RM_OK;
}

void * main2(void * thread_arg)
{
	struct DCC *pDCC = NULL;
	struct DCCVideoSource *pOSDSource = NULL;
	struct DCCOSDProfile osd_profile = {0,};
	struct RUA *pRUA = NULL;
	struct jpeg_decompress_struct cinfo;
	struct jpeg_error_mgr jerr;
	FILE *fd = (FILE*)NULL;
	RMstatus err;
	RMuint32 surfaceID;
	static struct dcc_context dcc_info = {0,};
	RMuint32 bitmapLumaSize = 0;
	RMuint32 bitmapChromaSize = 0;
	RMuint8 * pLuma = (RMuint8 *)NULL;
	RMuint8 * pChroma = (RMuint8 *)NULL;

	char * filename = (char *)thread_arg;
	
	init_display_options(&disp_opt);
	init_video_options(&video_opt);
	init_playback_options(&play_opt);

	err = RUACreateInstance(&pRUA, play_opt.chip_num);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error creating RUA instance! %d\n", err);
		return NULL;
	}
	
	err = DCCOpen(pRUA, &pDCC);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error Opening DCC! %d\n", err);
		return NULL;
	}

	err = DCCInitChainEx(pDCC, disp_opt.init_mode);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot initialize microcode %d\n", err);
		return NULL;
	}
	
	dcc_info.chip_num = play_opt.chip_num;
	dcc_info.pRUA = pRUA;
	dcc_info.pDCC = pDCC;
	dcc_info.pDH = NULL;
	dcc_info.route = DCCRoute_Main;

	err = apply_playback_options(&dcc_info, &play_opt);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot set playback options %d\n", err);
		return NULL;
	}
	
	set_default_out_window(&(dcc_info.out_window));
	set_default_out_window(&(dcc_info.osd_window));

	dcc_info.active_window = &(dcc_info.osd_window);
     
	err = apply_display_options(&dcc_info, &disp_opt);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot set display options %d\n", err);
		return NULL;
	}
	
	fd = load_jpg_file(&cinfo, &jerr, filename, &osd_profile);
	if (fd == NULL) {
		fprintf(stderr, "Cannot load JPEG file\n");
		return NULL;
	}

	err = DCCOpenOSDVideoSource(pDCC, &osd_profile, &pOSDSource);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot open OSD decoder %d\n", err);
		return NULL;
	}

#if (EM86XX_MODE == EM86XX_MODEID_WITHHOST)
	bitmapLumaSize = (osd_profile.Width)*(osd_profile.Height);
	bitmapChromaSize = (bitmapLumaSize/2); // only true for YUV 420 !!!

	pLuma = (RMuint8 *)RMMalloc(bitmapLumaSize*sizeof(RMuint8));
	if(pLuma == (RMuint8 *)NULL) {
		fprintf(stderr, "Cannot RMMalloc() LUMA buffer !!\n");
		return NULL;
	}
	
	pChroma = (RMuint8 *)RMMalloc(bitmapChromaSize*sizeof(RMuint8));
	if(pChroma == (RMuint8 *)NULL) {
		fprintf(stderr, "Cannot RMMalloc() CHROMA buffer !!\n");
		return NULL;
	}

	decompress_jpg_file(&cinfo, fd, pLuma, pChroma);

	err = DCCSetOSDVideoSource(pOSDSource, pLuma, pChroma);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot load image to RUA buffer %d\n", err);
		return NULL;
	}
#else
	{
		RMuint32 LumaAddr=0,ChromaAddr=0;
		err = DCCGetOSDVideoSourceInfo(pOSDSource, &LumaAddr, &bitmapLumaSize, &ChromaAddr, &bitmapChromaSize);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot get osd buffer info %d\n", err);
			return NULL;
		}
		
		pLuma = (RMuint8 *)LumaAddr;
		pChroma = (RMuint8 *)ChromaAddr;
	}
	
	decompress_jpg_file(&cinfo, fd, pLuma, pChroma);
#endif


	err = DCCGetScalerModuleID(pDCC, dcc_info.route, DCCSurface_OSD, 2, &surfaceID);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot get surface to display video source %d\n", err);
		return NULL;
	}

	err = DCCEnableSPUSurface(pDCC, dcc_info.route, 0, (struct DCCVideoSource *) NULL, FALSE);
	
	dcc_info.pOSDSource = pOSDSource;
	dcc_info.osd_scaler = surfaceID;
	dcc_info.osd_enable = TRUE;

	{
		RMbool set_surface_once = FALSE;
		while(surface_is_ready != -1) {
			if(surface_is_ready == 1) {
				if(!set_surface_once) {
					DCCSetSurfaceSource(pDCC, surfaceID, pOSDSource);
					set_surface_once = TRUE;
				}
			} else {
				set_surface_once = FALSE;
			}
			usleep(WAIT_SURFACE_READY);
		}
	}
       
#if (EM86XX_MODE == EM86XX_MODEID_WITHHOST)
	RMFree(pLuma);
	RMFree(pChroma);
#endif

	clear_display_options(&dcc_info, &disp_opt);
	
	err = DCCClose(pDCC);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot close DCC %d\n", err);
		return NULL;
	}

	err = RUADestroyInstance(pRUA);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot destroy RUA instance %d\n", err);
		return NULL;
	}

	return thread_arg;
}

int main(int argc, char *argv[])
{
	pthread_t pth = {0,};
	int rc = -1;
	void *rc_pth = NULL;
	
	struct DCC *pDCC = NULL;
	struct DCCVideoSource *pOSDSource = NULL;
	struct DCCOSDProfile osd_profile = {0,};
	struct RUA *pRUA = NULL;
	struct jpeg_decompress_struct cinfo;
	struct jpeg_error_mgr jerr;
	FILE *fd = (FILE*)NULL;
	RMstatus err;
	RMuint32 surfaceID;
	static struct dcc_context dcc_info = {0,};
	RMuint32 bitmapLumaSize = 0;
	RMuint32 bitmapChromaSize = 0;
	RMuint8 * pLuma = (RMuint8 *)NULL;
	RMuint8 * pChroma = (RMuint8 *)NULL;

	init_display_options(&disp_opt);
	init_video_options(&video_opt);
	init_playback_options(&play_opt);

	parse_cmdline(argc, argv);

	err = RUACreateInstance(&pRUA, play_opt.chip_num);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error creating RUA instance! %d\n", err);
		return -1;
	}
	
	err = DCCOpen(pRUA, &pDCC);
	if (RMFAILED(err)) {
		fprintf(stderr, "Error Opening DCC! %d\n", err);
		return -1;
	}

	err = DCCInitChainEx(pDCC, disp_opt.init_mode);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot initialize microcode %d\n", err);
		return -1;
	}
	
	dcc_info.pRUA = pRUA;
	dcc_info.pDCC = pDCC;
	dcc_info.pDH = NULL;
	dcc_info.route = DCCRoute_Main;

	err = apply_playback_options(&dcc_info, &play_opt);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot set playback options %d\n", err);
		return -1;
	}

	set_default_out_window(&(dcc_info.out_window));
	set_default_out_window(&(dcc_info.osd_window));

	dcc_info.active_window = &(dcc_info.osd_window);
     
	err = apply_display_options(&dcc_info, &disp_opt);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot set display options %d\n", err);
		return -1;
	}
	
	if (grey_w && grey_h) {
		osd_profile.ColorSpace = EMhwlibColorSpace_YUV_601;
		osd_profile.SamplingMode = EMhwlibSamplingMode_420;
		osd_profile.ColorMode = EMhwlibColorMode_VideoNonInterleaved;
		osd_profile.ColorFormat = EMhwlibColorFormat_32BPP;
		osd_profile.PixelAspectRatio.X = 1;
		osd_profile.PixelAspectRatio.Y = 1;
		osd_profile.Width = grey_w;
		osd_profile.Height = grey_h;
	} else {
		fd = load_jpg_file(&cinfo, &jerr, filename, &osd_profile);
		if (fd == NULL) {
			fprintf(stderr, "Cannot load JPEG file\n");
			return -1;
		}
	}

	err = DCCOpenOSDVideoSource(pDCC, &osd_profile, &pOSDSource);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot open OSD decoder %d\n", err);
		return -1;
	}

	// use main video scaler for large JPEG pictures (more than 2047 pixels per line)
	err = DCCGetScalerModuleID(pDCC, dcc_info.route, DCCSurface_OSD, 2, &surfaceID);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot get surface to display video source %d\n", err);
		return -1;
	}

	err = DCCEnableSPUSurface(pDCC, dcc_info.route, 0, (struct DCCVideoSource *) NULL, FALSE);
	
#if (EM86XX_MODE == EM86XX_MODEID_WITHHOST)
	bitmapLumaSize = (osd_profile.Width)*(osd_profile.Height);
	bitmapChromaSize = (bitmapLumaSize/2); // only true for YUV 420 !!!

	pLuma = (RMuint8 *)RMMalloc(bitmapLumaSize*sizeof(RMuint8));
	if(pLuma == (RMuint8 *)NULL) {
		fprintf(stderr, "Cannot RMMalloc() LUMA buffer !!\n");
		return -1;
	}
	
	pChroma = (RMuint8 *)RMMalloc(bitmapChromaSize*sizeof(RMuint8));
	if(pChroma == (RMuint8 *)NULL) {
		fprintf(stderr, "Cannot RMMalloc() CHROMA buffer !!\n");
		return -1;
	}

	if (grey_w && grey_h) {
		create_grey_420(osd_profile.Width, osd_profile.Height, pLuma, pChroma);
	} else {
		decompress_jpg_file(&cinfo, fd, pLuma, pChroma);
	}

	err = DCCSetOSDVideoSource(pOSDSource, pLuma, pChroma);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot load image to RUA buffer %d\n", err);
		return -1;
	}
#else
	{
		RMuint32 LumaAddr=0,ChromaAddr=0;
		err = DCCGetOSDVideoSourceInfo(pOSDSource, &LumaAddr, &bitmapLumaSize, &ChromaAddr, &bitmapChromaSize);
		if (RMFAILED(err)) {
			fprintf(stderr, "Cannot get osd buffer info %d\n", err);
			return -1;
		}
		
		pLuma = (RMuint8 *)LumaAddr;
		pChroma = (RMuint8 *)ChromaAddr;
	}
	
	if (grey_w && grey_h) {
		create_grey_420(osd_profile.Width, osd_profile.Height, pLuma, pChroma);
	} else {
		decompress_jpg_file(&cinfo, fd, pLuma, pChroma);
	}
#endif
	if(filename2) {
		// spawning thread
		rc = pthread_create(&pth,(pthread_attr_t *)NULL, main2, filename2);
		if(rc != 0) fprintf(stderr, "Cannot spawn thread %d\n", rc);
	}

	err = DCCSetSurfaceSource(pDCC, surfaceID, pOSDSource);
	if (RMFAILED(err)) {
			fprintf(stderr, "Cannot set the surface source %d\n", err);
			return -1;
	}
	
	dcc_info.pOSDSource = pOSDSource;
	dcc_info.osd_scaler = surfaceID;
	dcc_info.osd_enable = TRUE;
	display_key_usage(KEYFLAGS);
	// specific key usage for play_jpeg
	fprintf(stdout,"\nSpecific commands  for %s :\n",argv[0]);
	fprintf(stdout,"\tS - Display second picture (if second picture on command line)\n");
	fprintf(stdout,"\tP - Display first picture\n");

	RMTermInit(TRUE);    // don't allow ctrl-C and the like ...
	RMSignalInit(NULL, NULL);  // ... but catch other termination signals to call RMTermExit()
	do {
		RMuint32 cmd;
		err = process_key(&dcc_info, &cmd, KEYFLAGS);
		if (RMFAILED(err)) {
			fprintf(stderr, "Error while processing key %d\n", err);
			break;
		}
		switch(cmd) {
		case RM_STOP:
			DCCSetSurfaceSource(pDCC, surfaceID, (struct DCCVideoSource *)NULL);
			surface_is_ready = 1;
			break;
		case RM_PLAY:
			surface_is_ready = 0;
			DCCSetSurfaceSource(pDCC, surfaceID, (struct DCCVideoSource *)NULL);
			while(RMFAILED( DCCSetSurfaceSource(pDCC, surfaceID, pOSDSource))) {
				fprintf(stderr,"Waiting for surface to be ready ...\n");
				usleep(WAIT_SURFACE_READY);
			}
			break;
		case RM_SEEK:
 			fprintf(stderr, "Unsuported command\n");
			cmd = RM_PLAY;
			break;
		case RM_QUIT:
			surface_is_ready = -1;
			goto cleanup;
			break;
		default:
			usleep(50*1000);
			break;
		}
		update_hdmi(&dcc_info, &disp_opt, NULL);
	} while(1);

cleanup:
	RMTermExit();
#if (EM86XX_MODE == EM86XX_MODEID_WITHHOST)
	RMFree(pLuma);
	RMFree(pChroma);
#endif
	// clear_display_options() calls DCCCloseVideoSource()
	clear_display_options(&dcc_info, &disp_opt);
	
	err = DCCClose(pDCC);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot close DCC %d\n", err);
		return -1;
	}

	err = RUADestroyInstance(pRUA);
	if (RMFAILED(err)) {
		fprintf(stderr, "Cannot destroy RUA instance %d\n", err);
		return -1;
	}

	if(filename2) {
		rc = pthread_join(pth,&rc_pth);
		if(rc != 0) fprintf(stderr, "Can't wait for thread to terminate %d\n", rc);
		if(rc_pth == NULL) fprintf(stderr, "Something went wrong with the other thread !!!\n");
	}
	
	return 0;
}

#else
int main(int argc, char *argv[])
{
	return 0;
}
#endif
