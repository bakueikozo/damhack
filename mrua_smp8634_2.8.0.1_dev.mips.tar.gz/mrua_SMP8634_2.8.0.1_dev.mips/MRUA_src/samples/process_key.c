#define ALLOW_OS_CODE 1

#include "../rua/include/rua.h"
#include "../dcc/include/dcc.h"
#include "../emhwlib_hal/pll/include/pll_hal.h"
#include "common.h"

#include "command_ids.h"
#include "get_key.h"
#include "sample_os.h"
#include "dvi_hdmi.h"

#ifdef WITH_TIME_SHIFT
#include <pthread.h>
#include "play_vdemux.h"
#endif

#define MAX_SPEED 64

#define VOLUME_0DB		0x10000000
#define VOLUME_INDEX_0DB	49

extern RMbool manutest;

#if 0
#define MULTIDECODERDBG ENABLE
#else
#define MULTIDECODERDBG DISABLE
#endif

extern int verbose_stdout;
extern int verbose_stderr;

static RMuint32 VolumeTable[VOLUME_INDEX_0DB+1+24] = {
	0x00000000,								// mute
	0x00100000, 0x0011f59c, 0x001428a4, 0x0016a09f, 0x001965ff, 0x001c823e, // -48dB ... -43dB
	0x00200000, 0x0023eb35, 0x00285145, 0x002d413c, 0x0032cbfc, 0x0039047b, // -42dB ... -37dB
	0x00400000, 0x0047d66a, 0x0050a28b, 0x005a8279, 0x006597fa, 0x007208f8, // -36dB ... -31dB
	0x00800000, 0x008facd6, 0x00a14518, 0x00b504f3, 0x00cb2ff5, 0x00e411f0, // -30dB ... -25dB
	0x01000000, 0x011f59ac, 0x01428a2f, 0x016a09e6, 0x01965fea, 0x01c823e0, // -24dB ... -19dB
	0x02000000, 0x023eb358, 0x0285145f, 0x02d413cd, 0x032cbfd5, 0x039047c1, // -18dB ... -13dB
	0x04000000, 0x047d66b1, 0x050a28be, 0x05a82799, 0x06597fa9, 0x07208f82, // -12dB ...  -7dB
	0x08000000, 0x08facd62, 0x0a14517d, 0x0b504f34, 0x0cb2ff53, 0x0e411f04, //  -6dB ...  -1dB
	0x10000000, 0x11f59ac4, 0x1428a2fa, 0x16a09e67, 0x1965fea6, 0x1c823e08, //   0dB ...   5dB
	0x20000000, 0x23eb3589, 0x285145f5, 0x2d413ccf, 0x32cbfd4c, 0x39047c10, //   6dB ...  11dB
	0x40000000, 0x47d66b10, 0x50a28be7, 0x5a82799a, 0x6597fa95, 0x7208f81d, //  12dB ...  17dB
	0x80000000, 0x8facd61c, 0xa14517c9, 0xb504f32f, 0xcb2ff523, 0xe411f032, //  18dB ...  23dB
	0xffffffff  // ~24dB
};

static void PGCD(RMint32 *N, RMuint32 *M)
{
 	RMuint32 num, den, mod;

	/* compute PGCD */
	num = *N;
	den = *M;
	while ((mod=num%den) > 0) {
		num = den;
		den = mod;
	}
	
	/* reduce in an exact way first */
	*N /= den;
	*M /= den;
}

static RMint32 ppm = 0;

struct VideoMode {
	RMuint32 PixelClock;
	RMuint32 HActive;
	RMuint32 HFrontPorch;
	RMuint32 HSyncWidth;
	RMuint32 HBackPorch;
	RMbool HSyncPolarity;  /* TRUE: positive, FALSE: negative */
	RMuint32 VActive;
	RMuint32 VFrontPorch;
	RMuint32 VSyncWidth;
	RMuint32 VBackPorch;
	RMbool VSyncPolarity;  /* TRUE: positive, FALSE: negative */
	RMbool Interlaced;
	enum EMhwlibColorSpace dig_color_space;
	enum EMhwlibDigitalTimingSignal dig_timing;
	RMuint32 dig_bus_size;
	enum EMhwlibColorSpace analog_color_space;
};

static RMstatus GetVideoModeStructFromEmhwlibDigitalFormat(
	struct EMhwlibTVFormatDigital *format_dig, 
	struct VideoMode *pVidMode)
{
	if ((pVidMode == NULL) || (format_dig == NULL)) {
		return RM_ERROR;
	}
	pVidMode->PixelClock = format_dig->PixelClock;
	pVidMode->HActive = format_dig->ActiveWidth;
	pVidMode->VActive = format_dig->ActiveHeight;
	pVidMode->HSyncWidth = format_dig->HSyncWidth;
	pVidMode->VSyncWidth = format_dig->VSyncWidth / 2;
	pVidMode->HBackPorch = format_dig->XOffset - pVidMode->HSyncWidth;
	pVidMode->VBackPorch = format_dig->YOffsetTop - pVidMode->VSyncWidth;
	pVidMode->Interlaced = format_dig->TopFieldHeight ? TRUE : FALSE;
	pVidMode->HFrontPorch = format_dig->HTotalSize - pVidMode->HActive - pVidMode->HBackPorch - pVidMode->HSyncWidth;
	pVidMode->VFrontPorch = (pVidMode->Interlaced ? format_dig->VTotalSize / 2 : format_dig->VTotalSize) - pVidMode->VActive - pVidMode->VBackPorch - pVidMode->VSyncWidth;
	pVidMode->HSyncPolarity = ! format_dig->HSyncActiveLow;
	pVidMode->VSyncPolarity = ! format_dig->VSyncActiveLow;
	return RM_OK;
}

static RMstatus GetEmhwlibDigitalFormatFromVideoModeStruct(
	struct VideoMode *pVidMode,
	struct EMhwlibTVFormatDigital *format_dig)
{
	if ((pVidMode == NULL) || (format_dig == NULL)) {
		return RM_ERROR;
	}
	format_dig->PixelClock = pVidMode->PixelClock;
	format_dig->ActiveWidth = pVidMode->HActive;
	format_dig->ActiveHeight = pVidMode->VActive;
	format_dig->XOffset = pVidMode->HSyncWidth + pVidMode->HBackPorch;
	format_dig->YOffsetTop = pVidMode->VSyncWidth + pVidMode->VBackPorch;
	format_dig->YOffsetBottom = (pVidMode->Interlaced) ? format_dig->YOffsetTop : 0;;
	format_dig->VSyncActiveLow = ! pVidMode->VSyncPolarity;
	format_dig->HSyncActiveLow = ! pVidMode->HSyncPolarity;
	format_dig->HTotalSize = pVidMode->HActive + pVidMode->HFrontPorch + pVidMode->HSyncWidth + pVidMode->HBackPorch;
	format_dig->VTotalSize = pVidMode->VActive + pVidMode->VFrontPorch + pVidMode->VSyncWidth + pVidMode->VBackPorch;
	if (pVidMode->Interlaced) format_dig->VTotalSize = format_dig->VTotalSize * 2 + 1;
	format_dig->TopFieldHeight = (pVidMode->Interlaced) ? format_dig->VTotalSize : 0;
	format_dig->HSyncWidth = pVidMode->HSyncWidth;
	format_dig->VSyncWidth = pVidMode->VSyncWidth * 2;
	format_dig->VSyncFineAdjust = 0;
	format_dig->ColorSpace = EMhwlibColorSpace_RGB_0_255;
	format_dig->TrailingEdge = FALSE;
	format_dig->VSyncDelay1PixClk = FALSE;
	format_dig->Progressive = ! pVidMode->Interlaced;
	format_dig->HDTVMode = TRUE;
	format_dig->VbiStandard = EMhwlibVbiStandard_Custom;
	return RM_OK;
}

static RMstatus GetEmhwlibAnalogFormatFromVideoModeStruct(
	struct VideoMode *pVidMode,
	struct EMhwlibTVFormatAnalog *format_analog)
{
	if ((pVidMode == NULL) || (format_analog == NULL)) {
		return RM_ERROR;
	}
	format_analog->PixelClock = pVidMode->PixelClock;
	format_analog->ActiveWidth = pVidMode->HActive;
	format_analog->ActiveHeight = pVidMode->VActive;
	format_analog->XOffset = pVidMode->HSyncWidth + pVidMode->HBackPorch;
	format_analog->YOffsetTop = pVidMode->VSyncWidth + pVidMode->VBackPorch;
	format_analog->YOffsetBottom = (pVidMode->Interlaced) ? format_analog->YOffsetTop : 0;
	format_analog->VSyncActiveLow = ! pVidMode->VSyncPolarity;
	format_analog->HSyncActiveLow = ! pVidMode->HSyncPolarity;
	format_analog->Width = pVidMode->HActive + pVidMode->HFrontPorch + pVidMode->HSyncWidth + pVidMode->HBackPorch;
	format_analog->Height = pVidMode->VActive + pVidMode->VFrontPorch + pVidMode->VSyncWidth + pVidMode->VBackPorch;
	if (pVidMode->Interlaced) format_analog->Height = format_analog->Height * 2 + 1;
	format_analog->ColorSpace = EMhwlibColorSpace_RGB_0_255;
	format_analog->Progressive = ! pVidMode->Interlaced;
	format_analog->ComponentMode = EMhwlibComponentMode_RGB_SCART;
	format_analog->CompositeMode = EMhwlibCompositeMode_Disable;
	format_analog->HDTVMode = TRUE;
	format_analog->VbiStandard = EMhwlibVbiStandard_Custom;
	format_analog->HDSyncDown = TRUE;
	format_analog->OversampledInput = FALSE;
	format_analog->ChromaFilter = EMhwlibChromaFilter_3_25_MHz;
	format_analog->LumaFilter = EMhwlibLumaFilter_6_5_MHz;
	format_analog->SyncOnPbPr = FALSE;
	format_analog->Pedestal = FALSE;
	format_analog->HSync0 = format_analog->HSyncActiveLow ? 0 : pVidMode->HSyncWidth;
	format_analog->HSync1 = format_analog->HSyncActiveLow ? pVidMode->HSyncWidth : 0;
	format_analog->VSyncO0Line = format_analog->VSyncActiveLow ? 0 : pVidMode->VSyncWidth;
	format_analog->VSyncO0Pixel = format_analog->HSync0;
	format_analog->VSyncO1Line = format_analog->VSyncActiveLow ? pVidMode->VSyncWidth : 0;
	format_analog->VSyncO1Pixel = format_analog->HSync1;
	if (pVidMode->Interlaced) {
		format_analog->VSyncE0Line = format_analog->Height / 2 + (format_analog->VSyncActiveLow ? 0 : pVidMode->VSyncWidth);
		format_analog->VSyncE0Pixel = format_analog->Width / 2 + format_analog->HSync0;
		format_analog->VSyncE1Line = format_analog->Height / 2 + (format_analog->VSyncActiveLow ? pVidMode->VSyncWidth : 0);
		format_analog->VSyncE1Pixel = format_analog->Width / 2 + format_analog->HSync1;
	} else {
		format_analog->VSyncE0Line = 0;
		format_analog->VSyncE0Pixel = 0;
		format_analog->VSyncE1Line = 0;
		format_analog->VSyncE1Pixel = 0;
	}
	format_analog->HDHSyncWidth = pVidMode->HSyncWidth;
	format_analog->HDVSyncWidth = 0;
	format_analog->HDVSyncStart = 0;
	return RM_OK;
}

static RMstatus get_current_video_mode(struct dcc_context *dcc_info, struct VideoMode *pVidMode)
{
	RMstatus err;
	struct EMhwlibTVFormatDigital format_digital;
	
	if (! pVidMode) return RM_ERROR;
	
	err = RUAGetProperty(dcc_info->pRUA, DispDigitalOut, 
		RMGenericPropertyID_DigitalTVFormat, &format_digital, sizeof(format_digital));
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to get property TVFormat\n");
	}
	
	GetVideoModeStructFromEmhwlibDigitalFormat(&format_digital, pVidMode);
	
	err = RUAGetProperty(dcc_info->pRUA, DispDigitalOut, 
		RMGenericPropertyID_ColorSpace, &(pVidMode->dig_color_space), sizeof(pVidMode->dig_color_space));
	err = RUAGetProperty(dcc_info->pRUA, DispDigitalOut, 
		RMDispDigitalOutPropertyID_TimingSignal, &(pVidMode->dig_timing), sizeof(pVidMode->dig_timing));
	err = RUAGetProperty(dcc_info->pRUA, DispDigitalOut, 
		RMDispDigitalOutPropertyID_BusSize, &(pVidMode->dig_bus_size), sizeof(pVidMode->dig_bus_size));
	err = RUAGetProperty(dcc_info->pRUA, DispMainAnalogOut, 
		RMGenericPropertyID_ColorSpace, &(pVidMode->analog_color_space), sizeof(pVidMode->analog_color_space));
	
	return RM_OK;
}

static RMstatus set_modifyed_video_mode(struct dcc_context *dcc_info, struct VideoMode *pVidMode)
{
	RMstatus err;
	struct EMhwlibTVFormatDigital format_digital;
	struct EMhwlibTVFormatAnalog format_analog;
	
	if (RMFAILED(err = GetEmhwlibDigitalFormatFromVideoModeStruct(pVidMode, &format_digital)))
		return err;
	if (RMFAILED(err = GetEmhwlibAnalogFormatFromVideoModeStruct(pVidMode, &format_analog)))
		return err;
	
	err = DCCSetTVFormat(dcc_info->pDCC, dcc_info->route, &format_digital, &format_analog);
	if (RMFAILED(err)) return err;
	
	while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_ColorSpace, &(pVidMode->dig_color_space), sizeof(pVidMode->dig_color_space), 0)) == RM_PENDING);
	while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMDispDigitalOutPropertyID_TimingSignal, &(pVidMode->dig_timing), sizeof(pVidMode->dig_timing), 0)) == RM_PENDING);
	while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMDispDigitalOutPropertyID_BusSize, &(pVidMode->dig_bus_size), sizeof(pVidMode->dig_bus_size), 0)) == RM_PENDING);
	while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
	while ((err = RUASetProperty(dcc_info->pRUA, DispMainAnalogOut, RMGenericPropertyID_ColorSpace, &(pVidMode->analog_color_space), sizeof(pVidMode->analog_color_space), 0)) == RM_PENDING);
	while ((err = RUASetProperty(dcc_info->pRUA, DispMainAnalogOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
#ifdef RMFEATURE_HAS_COMPONENT_OUT
	while ((err = RUASetProperty(dcc_info->pRUA, DispComponentOut, RMGenericPropertyID_ColorSpace, &(pVidMode->analog_color_space), sizeof(pVidMode->analog_color_space), 0)) == RM_PENDING);
	while ((err = RUASetProperty(dcc_info->pRUA, DispComponentOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
#endif
	
	return RM_OK;
}

void set_default_out_window(struct EMhwlibDisplayWindow *window) 
{
	window->X = 2048;
	window->Y = 2048;
	window->Width = 4096;
	window->Height = 4096;
	window->XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToCenter;
	window->YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToCenter;
	window->XMode = EMhwlibDisplayWindowValueMode_Relative;
	window->YMode = EMhwlibDisplayWindowValueMode_Relative;
	window->WidthMode = EMhwlibDisplayWindowValueMode_Relative;
	window->HeightMode = EMhwlibDisplayWindowValueMode_Relative;
}

//------------------------------------------------------------------------------
//	Keyboard layout
//------------------------------------------------------------------------------
// 	0 = Enable output
//	1 =	Half size
// 	2 = Move scaler
//	3 = Decrease size
//	4 = Move scaler
//	5 = Video/OSD switch
//	6 = Move scaler
//	7 = Full size
//	8 = Move scaler
//	9 = Increase size
//	+ = Increase speed
//	- = Decrease speed
//	= = Set speed
//	[ = Backward I-Frame
//	] = Forward I-Frame
//	< = Dec aud playback speed
//	> = Inc aud playback speed
//	| = print STC drift information
//	A = SPI Video stream change		a = cycle Audio stream change
//	B = Increase brightness			b = Decrease brightness
//	C = Increase contrast			c = Decrease contrast
//	D = Prev Chapter			d = Dump OSD info
//	E = Dualmode toggle			e =
//	F = 					f = Seek
//	G = Cycle Subtitle			g = Debug read/write/freq
//	H = Increase hue			h = Decrease hue
//	I = I2C debug access			i = SPI PAT info
//	J =					j =
//	K = switch between spi & file playback	k = SPI channel change
//	L =					l = Change audio
//	M = Video mode				m = SPI PMT change
//	N = Next track				n = Next picture
//	O =					o =
//	P = Previous track			p = Play
//	Q =					q = quit
//	R =					r = Rotate picture
//	S = Next Chapter			s = Stop
//	T = Increase saturation			t = Decrease saturation
//	U =					u =
//	V = Increase volume			v = Decrease volume
//	W = Non-linear level			w = Non-linear width
//	X = Change video			x = Toggle Video output on/off
//	Y = Display Info			y = Manu test (?!?)
//	Z =	debug vsync time diff				z = Stop
//	  = Pause
//------------------------------------------------------------------------------

void display_key_usage(RMuint32 keyflags)
{
 	if (verbose_stderr == 0)
 		return;
 
	fprintf(stderr, "Commands: (press enter to validate a command)\n");
	fprintf(stderr, "  q: Quit\n");
	
	if (keyflags & SET_KEY_PLAYBACK) 
		fprintf(stderr, 
			"  s,z - Stop, p - Play, <space> - Pause, n - Next picture (after PAUSE only) \n"
			"  + increase speed, - decrease speed, = set speed\n"
			"  ] Forward I-frame 1x, [ Backward I-frame 1x, R rewind (if supported, adjust speed with +/-)\n"
			"  f: seek (if supported)\n");
	
	if (keyflags & SET_KEY_DISPLAY)
		fprintf(stderr, 
			"  c: decrease contrast - C: increase contrast\n"
			"  b: decrease brightness - B: increase brightness\n"
			"  t: decrease saturation - T: increase saturation\n"
			"  h: decrease hue - H: increase hue\n"
			"  x: toggle video output enable/disable\n"
			"  9: increase size, 3: decrease size, 2,4,6,8: move scaler window\n"
			"  1: half size, 7: full size (use numerical key block)\n"
			"  5: switch from VIDEO to OSD control (valid only if OSD is present)\n"
			"  w: change non-linear width\n"
			"  W: change non-linear level\n"
			"  d: Dump OSD Info\n"
			"  r: rotate picture\n");

	if (keyflags & SET_KEY_SPI) 
		fprintf(stderr, 
			"  k - SPI channel change\n"
			"  i - SPI PAT info\n"
			"  m - SPI PMT change\n"
			"  A - SPI audio stream change\n"
			"  X - SPI video stream change\n"
			"  a - Cycle through audio streams\n"
			"  l - Choose audio stream\n"
			"  K - switch between spi and file playback\n");
	
	if (keyflags & SET_KEY_AUDIO) 
		fprintf(stderr,
			"  v: decrease volume - V: increase volume - _: mute\n"
			"  E: toggle between dual modes (Stereo->LeftMono->RightMono->Mono)\n"
			"  <, >: decrease/increase playback speed by 1 ppm\n");
	
	if (keyflags & SET_KEY_DEBUG) 
		fprintf(stderr, 
			"  gr<A>: read 32 bits from gbus address A (hex)\n"
			"  gw<A> <D>: write D (hex) to gbus address A (hex)\n"
			"  gf<A>: measure frequency of the 32 bit register at gbus address A (hex)\n"
			"  I: enter I2C debug access mode (HDMI only)\n"
			"  M: enter video mode modificator\n"
			"  |: print STC drift information\n"
			"  !: show debug informations\n"
			"  Y: show display debug informations\n"
			"  Z: show vsync debug information\n"
			"  *: force filter settings on main video scaler\n"
			"  #: Turn HDCP on/off (HDMI only)\n");
	
}

static void print_hz(RMuint32 f) 
{
	if (f >= 1000000) fprintf(stderr, "%3lu,%03lu,%03lu", f / 1000000, (f / 1000) % 1000, f % 1000);
	else if (f >= 1000) fprintf(stderr, "%7lu,%03lu", f / 1000, f % 1000);
	else fprintf(stderr, "%11lu", f);
}

static RMuint32 get_freqency(
	struct gbus *pGBus, 
	RMuint32 addr, 
	RMuint32 uSecDelay)
{
	RMuint32 ref0, ref1, refd, ctr0, ctr1, ctrd;
	
	/* avoid integer overflow */
	if (uSecDelay > 159) uSecDelay = 159;
	
	/* initial counter values */
	ref0 = gbus_read_uint32(pGBus, 0x10048);  // REG_BASE_system_block + SYS_xtal_in_cnt
	ctr0 = gbus_read_uint32(pGBus, addr);
	
	/* loop for specified time, at least once */
	do {
		/* final counter values */
		ref1 = gbus_read_uint32(pGBus, 0x10048);  // REG_BASE_system_block + SYS_xtal_in_cnt
		ctr1 = gbus_read_uint32(pGBus, addr);
		
		/* delta values */
		refd = (ref1 > ref0) ? ref1 - ref0 : 0xFFFFFFFF - ref0 + ref1 + 1;
		ctrd = (ctr1 > ctr0) ? ctr1 - ctr0 : 0xFFFFFFFF - ctr0 + ctr1 + 1;
		
		/* check if xtal_in_ctr is stagnant */
		if (! refd) return 0;
	} while (refd < XTAL_HZ * uSecDelay / 1000);
	
	/* return ctrd, normalized to Hz */
	return (RMuint32)RM64mult32div32(ctrd, XTAL_HZ, refd);
}

RMstatus process_key(struct dcc_context *dcc_info, RMuint32 *cmd, RMuint32 keyflags)
{
	RMascii key;
	RMstatus err;

 in_key:	
	
	key = 0;
	if (((dcc_info->state == RM_STOPPED) || (dcc_info->state == RM_PAUSED)) || (RMKeyAvailable())) 
		key = RMGetKey();
	
	err = handle_key(dcc_info, cmd, keyflags, key);
	if (err == RM_PENDING) err = RM_OK;
	
	if (RMSUCCEEDED(err) && (*cmd == RM_UNKNOWN) && ((dcc_info->state == RM_STOPPED) || (dcc_info->state == RM_PAUSED))) {
		goto in_key;
	}
	
	return err;
}

RMstatus handle_debug_key(struct dcc_context *dcc_info, RMascii key, RMbool *processed);
void send_hilight_button(struct dcc_context *dcc_info);

RMstatus handle_debug_key(struct dcc_context *dcc_info, RMascii key, RMbool *processed)
{
	static RMuint32 last_gr = 0;
	RMstatus err;
	
	*processed = TRUE;
	
	// Debug access to HDMI I2C busses
	if (dcc_info->dh_info && dcc_info->dh_info->pDH) {
		err = DHDebugI2C(dcc_info->dh_info->pDH, KEY_CMD_I2C, key);
		if (RMSUCCEEDED(err)) return RM_OK; //we processed the key
	}
	
	switch (key) {
	case KEY_CMD_GBUS: {
		RMascii k;
		fprintf(stderr, "%c", key);
		k = RMGetKey(); fprintf(stderr, "%c", k);
		if ((k == 'r') || (k == 'w') || (k == 'f')) {
			RMascii command = k;
			RMbool error = FALSE;
			RMuint32 a = 0, d = 0;
			RMascii device[40];
			struct llad *pLLAD;
			struct gbus *pGBus;
			RMPrintAscii(device, "%lu", dcc_info->chip_num);
			pLLAD = llad_open(device);
			pGBus = gbus_open(pLLAD);
			do {
				k = RMGetKey(); fprintf(stderr, "%c", k);
				if ((k >= '0') && (k <= '9')) a = (a << 4) + (k - '0'); 
				else if ((k >= 'A') && (k <= 'F')) a = (a << 4) + (k - 'A' + 10); 
				else if ((k >= 'a') && (k <= 'f')) a = (a << 4) + (k - 'a' + 10); 
				else if ((k == '\b') || (k == '\177')) a >>= 4; 
				else {
					if ((k != ' ') && (k != '\n')) error = TRUE; 
					break;
				}
			} while (!(a & 0xF0000000));
			if ((! error) && ((command == 'r') || (command == 'f'))) {
				if (! a) {
					a = last_gr;
					fprintf(stderr, "%08lX", a);
				} else last_gr = a;
				if (command == 'r') {
					fprintf(stderr, " = %08lX\n", gbus_read_uint32(pGBus, a));
				} else {
					fprintf(stderr, " @ ");
					print_hz(get_freqency(pGBus, a, 100));
					fprintf(stderr, " Hz\n");
				}
				k = '\n';
			} else if (! error) {
				do {
					k = RMGetKey(); fprintf(stderr, "%c", k);
					if ((k >= '0') && (k <= '9')) d = (d << 4) + (k - '0'); 
					else if ((k >= 'A') && (k <= 'F')) d = (d << 4) + (k - 'A' + 10); 
					else if ((k >= 'a') && (k <= 'f')) d = (d << 4) + (k - 'a' + 10); 
					else if ((k == '\b') || (k == '\177')) d >>= 4; 
					else {
						if ((k != ' ') && (k != '\n')) error = TRUE; 
						break;
					}
				} while (!(d & 0xF0000000));
				if (! error) gbus_write_uint32(pGBus, a, d);
			}
			if (error) fprintf(stderr, " input error!\n");
			gbus_close(pGBus);
			llad_close(pLLAD);
		}
		if (k != '\n') fprintf(stderr, "\n");
		break;
	}
	case KEY_CMD_VIDEOMODE: {
		struct VideoMode VM;
		RMascii k;
		RMuint32 *mod;
		err = get_current_video_mode(dcc_info, &VM);
		if (RMFAILED(err)) break;
		do {
			mod = NULL;
			fprintf(stderr, "Current video mode: (press corresponding key to modify value)\n");
			fprintf(stderr, "  [a] PixelClock:     %lu\n", VM.PixelClock);
			fprintf(stderr, "  [b] HActive:        %lu\n", VM.HActive);
			fprintf(stderr, "  [c] HFrontPorch:    %lu\n", VM.HFrontPorch);
			fprintf(stderr, "  [d] HSyncWidth:     %lu\n", VM.HSyncWidth);
			fprintf(stderr, "  [e] HBackPorch:     %lu\n", VM.HBackPorch);
			fprintf(stderr, "  [f] HSyncPolarity:  %s\n", VM.HSyncPolarity ? "positive" : "negative");
			fprintf(stderr, "  [g] VActive:        %lu\n", VM.VActive);
			fprintf(stderr, "  [h] VFrontPorch:    %lu\n", VM.VFrontPorch);
			fprintf(stderr, "  [i] VSyncWidth:     %lu\n", VM.VSyncWidth);
			fprintf(stderr, "  [j] VBackPorch:     %lu\n", VM.VBackPorch);
			fprintf(stderr, "  [k] VSyncPolarity:  %s\n", VM.VSyncPolarity ? "positive" : "negative");
			fprintf(stderr, "  [l] Interlaced:     %s\n", VM.Interlaced ? "yes" : "no");
			fprintf(stderr, "  <enter> to quit\n");
			k = RMGetKey();
			if (k == '\n') {
				RMuint32 HTotal, VTotal;
				HTotal = VM.HActive + VM.HFrontPorch + VM.HSyncWidth + VM.HBackPorch;
				VTotal = VM.VActive + VM.VFrontPorch + VM.VSyncWidth + VM.VBackPorch;
				if (VM.Interlaced) VTotal = VTotal * 2 + 1;
				fprintf(stderr, "New mode line for vesa.tbl:\n"
					"%9lu, %4lu, %4lu, %4lu, %3lu, %3lu, %3lu, %d, %4lu, %2lu, %2lu, %2lu, %d, NewMode_%lux%lux%lu%s\n", 
					VM.PixelClock, VM.HActive, VM.VActive, 
					HTotal, VM.HFrontPorch, VM.HSyncWidth, VM.HBackPorch, VM.HSyncPolarity, 
					VTotal, VM.VFrontPorch, VM.VSyncWidth, VM.VBackPorch, VM.VSyncPolarity, 
					VM.HActive, VM.VActive, 
					VM.PixelClock / (VTotal * HTotal), 
					VM.Interlaced ? "i" : "");
				break;
			}
			fprintf(stderr, "%c\n", k);
			switch (k) {
			case 'a': mod = &VM.PixelClock; break;
			case 'b': mod = &VM.HActive; break;
			case 'c': mod = &VM.HFrontPorch; break;
			case 'd': mod = &VM.HSyncWidth; break;
			case 'e': mod = &VM.HBackPorch; break;
			case 'f': VM.HSyncPolarity = ! VM.HSyncPolarity; break;
			case 'g': mod = &VM.VActive; break;
			case 'h': mod = &VM.VFrontPorch; break;
			case 'i': mod = &VM.VSyncWidth; break;
			case 'j': mod = &VM.VBackPorch; break;
			case 'k': VM.VSyncPolarity = ! VM.VSyncPolarity; break;
			case 'l': {
				VM.Interlaced = ! VM.Interlaced; 
				if (VM.Interlaced) {
					VM.VActive /= 2;
					VM.VFrontPorch /= 2;
					VM.VSyncWidth /= 2;
					VM.VBackPorch /= 2;
				} else {
					VM.VActive *= 2;
					VM.VFrontPorch *= 2;
					VM.VSyncWidth *= 2;
					VM.VBackPorch *= 2;
				}
				break;
			}
			}
			if (mod) {
				RMuint32 new = 0;
				RMbool parse = FALSE;
				fprintf(stderr, "press '+' or '-', or enter new value, <enter> to end\n");
				do {
					if (! parse) fprintf(stderr, "(%lu) ", *mod);
					k = RMGetKey();
							
					switch (k) {
					case '+': parse = FALSE; (*mod)++; break;
					case '-': parse = FALSE; if (*mod) (*mod)--; break;
					case '0': case '1': case '2': case '3': case '4': 
					case '5': case '6': case '7': case '8': case '9': 
						if (! parse) {
							new = 0;
							parse = TRUE;
						}
						fprintf(stderr, "%c", k);
						new = (new * 10) + (k - '0');
						break;
					case '\b': case '\177':
						if (parse) {
							fprintf(stderr, "%c", k);
							new /= 10;
						}
						break;
					case '\n': 
						if (parse) {
							*mod = new; 
							parse = FALSE; 
							k = ' ';
						}
						break;
					default: parse = FALSE; break;
					}
					if (!parse) {
						fprintf(stderr, "\n");
						err = set_modifyed_video_mode(dcc_info, &VM);
					}
				} while (k != '\n');
			} else {
				err = set_modifyed_video_mode(dcc_info, &VM);
			}
			if (RMFAILED(err)) {
				fprintf(stderr, "Error setting new mode!\n");
			}
		} while (TRUE);
		break;
	}
	case KEY_CMD_HIGHLIGHT:
		send_hilight_button(dcc_info);	
		break;
	case KEY_CMD_STCDRIFT: {
		RMuint32 STCModuleID = EMHWLIB_MODULE(STC, 0);
		RMuint32 stc_freq, xtal_freq, rounds;
		RMuint64 stc_curr;
		RMuint32 xtal_curr;
		RMint32 dist;
		static RMint32 initialdist = 0;
		enum ClockCounter ctr = ClockCounter_xtal_in;
		enum PLLSource xtal = PLLSource_xtal;
		
		err = RUAExchangeProperty(dcc_info->pRUA, PLL, RMPLLPropertyID_QuerySourceFrequency, 
			&xtal, sizeof(xtal), &xtal_freq, sizeof(xtal_freq));
		if (RMFAILED(err)) {
			fprintf(stderr, "Can not get XTAL speed, %s\n", RMstatusToString(err));
		}
		err = RUAGetProperty(dcc_info->pRUA, STCModuleID, RMSTCPropertyID_StcTimeResolution, &stc_freq, sizeof(stc_freq));
		if (RMFAILED(err)) {
			fprintf(stderr, "Can not get STC speed, %s\n", RMstatusToString(err));
		}
		fprintf(stderr, "STC running at %lu Hz, Xtal running at %lu Hz\n", stc_freq, xtal_freq);
		err = RUAExchangeProperty(dcc_info->pRUA, STCModuleID, RMSTCPropertyID_TimeInfo,
			&xtal_freq, sizeof(xtal_freq), &stc_curr, sizeof(stc_curr));
		if (RMFAILED(err)) {
			fprintf(stderr, "Can not get STC, %s\n", RMstatusToString(err));
		}
		err = RUAExchangeProperty(dcc_info->pRUA, PLL, RMPLLPropertyID_QueryCounter,
			&ctr, sizeof(ctr), &xtal_curr, sizeof(xtal_curr));
		if (RMFAILED(err)) {
			fprintf(stderr, "Can not get XTAL, %s\n", RMstatusToString(err));
		}
		if (! initialdist) initialdist = xtal_curr - (RMuint32)stc_curr;
		xtal_curr -= initialdist;
		rounds = (xtal_curr + xtal_freq) / xtal_freq;
		dist = xtal_curr - (RMuint32)stc_curr;
		if ((RMuint32)(RMabs(dist)) > (RMuint32)(xtal_freq * 10)) initialdist = 0;
		fprintf(stderr, "stc:%lu - xtal:%lu = %ld, avrg: %ld ppm\n", 
			(RMuint32)stc_curr, xtal_curr, dist, 
			(dist < 0) ? -(((-dist) / rounds) / (xtal_freq / 1000000)) : (dist / rounds) / (xtal_freq / 1000000));
		break;
	}
	case KEY_CMD_DISPLAY_INFO: {
		if (dcc_info->SurfaceID) {
			RMuint32 skip, dup;
			
			err = RUAGetProperty(dcc_info->pRUA, dcc_info->SurfaceID, RMGenericPropertyID_DisplaySkipCount, &skip, sizeof(skip));
			if (RMFAILED(err)) 
				fprintf(stderr, "Cannot get skip count\n");
			
			err = RUAGetProperty(dcc_info->pRUA, dcc_info->SurfaceID, RMGenericPropertyID_DisplayDuplicateCount, &dup, sizeof(dup));
			if (RMFAILED(err)) 
				fprintf(stderr, "Cannot get dup count\n");
			
			fprintf(stderr, "SKIP: %lu, DUP: %lu\n", skip, dup);
		}	
		else {
			fprintf(stderr, "No video scaler\n");
		}
		break;
	}
	case KEY_CMD_VSYNCTIMES: {
		struct DispDigitalOut_VSyncTimes_type VSyncTimes;
		static const RMascii PortName[6][4] = {"CVB", "YUV", "MAO", "DIG", "VID", "GFX"};
		#define VSYNCTIMES_THRESHOLD 2700000
		
		while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMDispDigitalOutPropertyID_UpdateVSyncTimes, NULL, 0, 0)) == RM_PENDING);
		while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
		while ((err = RUAGetProperty(dcc_info->pRUA, DispDigitalOut, RMDispDigitalOutPropertyID_VSyncTimes, &VSyncTimes, sizeof(VSyncTimes))) == RM_PENDING);
		if (RMFAILED(err)) {
			fprintf(stderr, "Error getting VSyncTimes!\n");
		} else {
			RMuint32 i, VSyncTime, FrameTime;
			RMint32 VSyncDelay, FrameDelay;
			
			fprintf(stderr, " -- Xtal values at VSync:\n");
			for (i = 0; i < 6; i++) {
				VSyncTime = RMCyclesElapsed32(VSyncTimes.VSyncTime[i][1], VSyncTimes.VSyncTime[i][0]);
				FrameTime = RMCyclesElapsed32(VSyncTimes.FrameTime[i][1], VSyncTimes.FrameTime[i][0]);
				//fprintf(stderr, "%s, VSync: 0x%08lX-0x%08lX=%lu %3lu.%03llu Hz, Frame: 0x%08lX-0x%08lX=%lu %3lu.%03llu Hz\n", PortName[i], 
				//	VSyncTimes.VSyncTime[i][1], VSyncTimes.VSyncTime[i][0], VSyncTime, VSyncTime ? (27000000 / VSyncTime) : 0, VSyncTime ? ((27000000000LL / VSyncTime) % 1000) : 0, 
				//	VSyncTimes.FrameTime[i][1], VSyncTimes.FrameTime[i][0], FrameTime, FrameTime ? (27000000 / FrameTime) : 0, FrameTime ? ((27000000000LL / FrameTime) % 1000) : 0);
				if ((VSyncTime || FrameTime) && (VSyncTime < VSYNCTIMES_THRESHOLD) && (FrameTime < VSYNCTIMES_THRESHOLD)) {
					fprintf(stderr, "%s, VSync: %3lu.%03llu Hz, %6lu uSec; Frame: %3lu.%03llu Hz, %6lu uSec\n", PortName[i], 
						VSyncTime ? (27000000 / VSyncTime) : 0, VSyncTime ? ((27000000000LL / VSyncTime) % 1000) : 0, VSyncTime / 27, 
						FrameTime ? (27000000 / FrameTime) : 0, FrameTime ? ((27000000000LL / FrameTime) % 1000) : 0, FrameTime / 27);
				}
			}
			
			VSyncDelay = RMCyclesElapsed32(VSyncTimes.VSyncTime[3][0], VSyncTimes.VSyncTime[2][0]);
			if (VSyncDelay < 0) VSyncDelay = -RMCyclesElapsed32(VSyncTimes.VSyncTime[2][0], VSyncTimes.VSyncTime[3][0]);
			FrameDelay = RMCyclesElapsed32(VSyncTimes.FrameTime[3][0], VSyncTimes.FrameTime[2][0]);
			if (FrameDelay < 0) FrameDelay = -RMCyclesElapsed32(VSyncTimes.FrameTime[2][0], VSyncTimes.FrameTime[3][0]);
			//fprintf(stderr, "%s to %s delay, VSync: %ld, %ld uSec, Frame: %ld, %ld uSec\n", 
			//	PortName[3], PortName[2], 
			//	VSyncDelay, VSyncDelay / 27, 
			//	FrameDelay, FrameDelay / 27);
			if ((VSyncDelay < VSYNCTIMES_THRESHOLD) && (VSyncDelay > -VSYNCTIMES_THRESHOLD) && (FrameDelay < VSYNCTIMES_THRESHOLD) && (FrameDelay > -VSYNCTIMES_THRESHOLD)) {
				fprintf(stderr, "%s to %s delay, VSync: %+6ld uSec, Frame: %+6ld uSec\n", 
					PortName[3], PortName[2], VSyncDelay / 27, FrameDelay / 27);
			}
			
			VSyncDelay = RMCyclesElapsed32(VSyncTimes.VSyncTime[3][0], VSyncTimes.VSyncTime[1][0]);
			if (VSyncDelay < 0) VSyncDelay = -RMCyclesElapsed32(VSyncTimes.VSyncTime[1][0], VSyncTimes.VSyncTime[3][0]);
			FrameDelay = RMCyclesElapsed32(VSyncTimes.FrameTime[3][0], VSyncTimes.FrameTime[1][0]);
			if (FrameDelay < 0) FrameDelay = -RMCyclesElapsed32(VSyncTimes.FrameTime[1][0], VSyncTimes.FrameTime[3][0]);
			if ((VSyncDelay < VSYNCTIMES_THRESHOLD) && (VSyncDelay > -VSYNCTIMES_THRESHOLD) && (FrameDelay < VSYNCTIMES_THRESHOLD) && (FrameDelay > -VSYNCTIMES_THRESHOLD)) {
				fprintf(stderr, "%s to %s delay, VSync: %+6ld uSec, Frame: %+6ld uSec\n", 
					PortName[3], PortName[1], VSyncDelay / 27, FrameDelay / 27);
			}
			
			VSyncDelay = RMCyclesElapsed32(VSyncTimes.VSyncTime[3][0], VSyncTimes.VSyncTime[4][0]);
			if (VSyncDelay < 0) VSyncDelay = -RMCyclesElapsed32(VSyncTimes.VSyncTime[4][0], VSyncTimes.VSyncTime[3][0]);
			FrameDelay = RMCyclesElapsed32(VSyncTimes.FrameTime[3][0], VSyncTimes.FrameTime[4][0]);
			if (FrameDelay < 0) FrameDelay = -RMCyclesElapsed32(VSyncTimes.FrameTime[4][0], VSyncTimes.FrameTime[3][0]);
			if ((VSyncDelay < VSYNCTIMES_THRESHOLD) && (VSyncDelay > -VSYNCTIMES_THRESHOLD) && (FrameDelay < VSYNCTIMES_THRESHOLD) && (FrameDelay > -VSYNCTIMES_THRESHOLD)) {
				fprintf(stderr, "%s to %s delay, VSync: %+6ld uSec, Frame: %+6ld uSec\n", 
					PortName[3], PortName[4], VSyncDelay / 27, FrameDelay / 27);
			}
			
			VSyncDelay = RMCyclesElapsed32(VSyncTimes.VSyncTime[3][0], VSyncTimes.VSyncTime[5][0]);
			if (VSyncDelay < 0) VSyncDelay = -RMCyclesElapsed32(VSyncTimes.VSyncTime[5][0], VSyncTimes.VSyncTime[3][0]);
			FrameDelay = RMCyclesElapsed32(VSyncTimes.FrameTime[3][0], VSyncTimes.FrameTime[5][0]);
			if (FrameDelay < 0) FrameDelay = -RMCyclesElapsed32(VSyncTimes.FrameTime[5][0], VSyncTimes.FrameTime[3][0]);
			if ((VSyncDelay < VSYNCTIMES_THRESHOLD) && (VSyncDelay > -VSYNCTIMES_THRESHOLD) && (FrameDelay < VSYNCTIMES_THRESHOLD) && (FrameDelay > -VSYNCTIMES_THRESHOLD)) {
				fprintf(stderr, "%s to %s delay, VSync: %+6ld uSec, Frame: %+6ld uSec\n", 
					PortName[3], PortName[5], VSyncDelay / 27, FrameDelay / 27);
			}
			
		}
		break;
	}
	case KEY_CMD_FILTER_SELECT: {
		struct DispMainVideoScaler_FilterSelection_type filtermode;
		RMuint32 i;
		
		RUAGetProperty(dcc_info->pRUA, DispMainVideoScaler, RMDispMainVideoScalerPropertyID_FilterSelection, &(filtermode), sizeof(filtermode));
		if (! filtermode.Boundary_2_3) {
			i = 4;
		} else if (! filtermode.Boundary_1_2) {
			i = 3;
		} else if (! filtermode.Boundary_0_1) {
			i = 2;
		} else if (filtermode.Boundary_0_1 < 0x2000) {
			i = 0;
		} else {
			i = 1;
		}
		i = (i + 1) % 5;
		switch (i) {
		case 0:
			fprintf(stderr, "Filter config: normal\n");
			filtermode.Boundary_0_1 = 0x1400;
			filtermode.Boundary_1_2 = 0x1c00;
			filtermode.Boundary_2_3 = 0x2c00;
			break;
		case 1:
			fprintf(stderr, "Filter config: always 0\n");
			filtermode.Boundary_0_1 = 0x4000;
			filtermode.Boundary_1_2 = 0x4000;
			filtermode.Boundary_2_3 = 0x4000;
			break;
		case 2:
			fprintf(stderr, "Filter config: always 1\n");
			filtermode.Boundary_0_1 = 0x0000;
			filtermode.Boundary_1_2 = 0x4000;
			filtermode.Boundary_2_3 = 0x4000;
			break;
		case 3:
			fprintf(stderr, "Filter config: always 2\n");
			filtermode.Boundary_0_1 = 0x0000;
			filtermode.Boundary_1_2 = 0x0000;
			filtermode.Boundary_2_3 = 0x4000;
			break;
		case 4:
			fprintf(stderr, "Filter config: always 3\n");
			filtermode.Boundary_0_1 = 0x0000;
			filtermode.Boundary_1_2 = 0x0000;
			filtermode.Boundary_2_3 = 0x0000;
			break;
		}
		while ((err = RUASetProperty(dcc_info->pRUA, DispMainVideoScaler, RMDispMainVideoScalerPropertyID_FilterSelection, &(filtermode), sizeof(filtermode), 0)) == RM_PENDING);
		while ((err = RUASetProperty(dcc_info->pRUA, DispMainVideoScaler, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
		break;
	}
	case KEY_CMD_HDCP_TOGGLE:
		if (dcc_info->dh_info && dcc_info->dh_info->pDH) {
			RMascii k;
			fprintf(stderr, "HDCP ");
			k = RMGetKey(); fprintf(stderr, "'%c':", k);
			switch (k) {
			case '0':
				fprintf(stderr, " Off\n");
				DHCancelHDCP(dcc_info->dh_info->pDH);
				break;
			case '1':
				fprintf(stderr, " On\n");
				DHRequestHDCP(dcc_info->dh_info->pDH);
				break;
			case '2':
				fprintf(stderr, " Silent On\n");
				DHRequestSilentHDCP(dcc_info->dh_info->pDH);
				break;
			default:
				fprintf(stderr, " ERROR: 0, 1 or 2\n");
			}
		}
		break;
	default:
		*processed = FALSE;
	}
	return RM_OK;
}

RMstatus handle_key(struct dcc_context *dcc_info, RMuint32 *cmd, RMuint32 keyflags, RMascii key)
{
	RMbool update_out_window, processed;
	RMstatus err;
	
	update_out_window = FALSE;
	processed = FALSE;
	*cmd = RM_UNKNOWN;
	
	if ((key == KEY_CMD_NONE1) || (key == KEY_CMD_NONE2)) {
		goto out_key;
	}
	
	if (keyflags & SET_KEY_DEBUG) {
		handle_debug_key(dcc_info, key, &processed);
		if (processed == TRUE)
			goto out_key;
	}
	
	if (keyflags & SET_KEY_PLAYBACK) {
		processed = TRUE;
		switch (key) {
		case KEY_CMD_MANU_YES:
			if (manutest == TRUE) {
				*cmd = RM_MANU_QUIT_OK;
				break;
			}

		case KEY_CMD_PAUSE:
			if ((dcc_info->state != RM_PAUSED) && (dcc_info->state != RM_PLAYING) && (dcc_info->state != RM_PLAYING_TRICKMODE)) {
				fprintf(stderr, "Enter Play state first...\n");
				break;
			}

			fprintf(stderr, "Pausing...\n");
			if (dcc_info->pDemuxTask) {
				err = DCCPauseDemuxTask(dcc_info->pDemuxTask);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Error pausing demux source %d\n", err));
					return err;
				}
			}
			if (dcc_info->pVideoSource) {
				err = DCCPauseVideoSource(dcc_info->pVideoSource);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Error pausing video source %d\n", err));
					return err;
				}
			}
			
			if (dcc_info->pAudioSource) {
				err = DCCPauseAudioSource(dcc_info->pAudioSource);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Error pausing audio source %d\n", err));
					return err;
				}
			}

			if (dcc_info->pStcSource) {
				DCCSTCStop(dcc_info->pStcSource);
			}

			dcc_info->state = RM_PAUSED;
			dcc_info->trickmode_id = RM_NO_TRICKMODE;
			*cmd = RM_PAUSE;
			break;
		
		case KEY_CMD_PLAY:
			fprintf(stderr, "Running...\n");
			if (dcc_info->pVideoSource) {
				err = DCCPlayVideoSource(dcc_info->pVideoSource, DCCVideoPlayFwd);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Error playing video source %d\n", err));
					return err;
 				}
			}

			if (dcc_info->pAudioSource) {
				err = DCCPlayAudioSource(dcc_info->pAudioSource);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Error playing audio source %d\n", err));
					return err;
				}
			}
			
			if (dcc_info->pDemuxTask) {
				err = DCCPlayDemuxTask(dcc_info->pDemuxTask);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Error playing demux source %d\n", err));
					return err;
				}
			}

			if (dcc_info->pStcSource) {
				DCCSTCSetSpeed(dcc_info->pStcSource, 1, 1);
				DCCSTCPlay(dcc_info->pStcSource);
			}

			dcc_info->state = RM_PLAYING;
			dcc_info->trickmode_id = RM_NO_TRICKMODE;
			*cmd = RM_PLAY;
			break;
			
		case KEY_CMD_NEXT_PICTURE:
			if ((dcc_info->state != RM_PAUSED) && (dcc_info->trickmode_id != RM_TRICKMODE_NEXT_PIC)){
				fprintf(stderr, "Enter Pause state first...\n");
				break;
			}

			fprintf(stderr, "Next Picture...\n");
			if (dcc_info->pVideoSource) {
				/* 
				   IMPORTANT NOTE: This call only affects the display, so the video decoder remains in the current
				   playback state, ie: playFwd, playIFrame, etc.
				*/
				err = DCCPlayVideoSource(dcc_info->pVideoSource, DCCVideoPlayNextFrame);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Error playing (next frame) video source %d\n", err));
					return err;
				}
			}
			if (dcc_info->pAudioSource) {
				err = DCCStopAudioSource(dcc_info->pAudioSource);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Error stopping audio source %d\n", err));
					return err;
				}
			}

			dcc_info->state = RM_PLAYING_TRICKMODE;
			dcc_info->trickmode_id = RM_TRICKMODE_NEXT_PIC;
			*cmd = RM_PLAY;
			break;

		case KEY_CMD_STOP_ZERO:
		case KEY_CMD_STOP:
			fprintf(stderr, "Stopping...\n");
			if (dcc_info->pDemuxTask) {
				err = DCCStopDemuxTask(dcc_info->pDemuxTask);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Error stopping demux source %d\n", err));
					return err;
				}
			}
			if (dcc_info->pVideoSource) {
				err = DCCStopVideoSource(dcc_info->pVideoSource, DCCStopMode_LastFrame);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Error stopping video source %d\n", err));
					return err;
				}
			}
			
			if (dcc_info->pAudioSource) {
				err = DCCStopAudioSource(dcc_info->pAudioSource);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Error stopping audio source %d\n", err));
					return err;
				}
			}

			if (dcc_info->pStcSource) {
				DCCSTCStop(dcc_info->pStcSource);
			}

			dcc_info->state = RM_STOPPED;
			dcc_info->trickmode_id = RM_NO_TRICKMODE;
			*cmd = (key==KEY_CMD_STOP) ? RM_STOP : RM_STOP_SEEK_ZERO;
			break;
			
		case KEY_CMD_SLOW_FWD:
			if (dcc_info->trick_supported) {
				if ((dcc_info->state != RM_PLAYING) && (dcc_info->state != RM_PLAYING_TRICKMODE)) {
					fprintf(stderr, "Enter Play state first...\n");
					break;
				}
				
				if (((dcc_info->pVideoSource) || (dcc_info->pAudioSource)) && (dcc_info->pStcSource)) {
					RMint32 N;
					RMuint32 M, positiveN;
					
					DCCSTCGetSpeed(dcc_info->pStcSource, &N, &M);

					if ((N == 0) || (M == 0)) {
						N = 1;
						M = 1;
					}

					positiveN = (N<0) ? (RMuint32) (-N) : (RMuint32) N;

					positiveN = 3*positiveN;
					M = 4*M;
					PGCD((RMint32 *)&positiveN, &M);
					if ((positiveN >= M) && (positiveN > MAX_SPEED)) {
						RMuint32 f = (positiveN + MAX_SPEED - 1) / MAX_SPEED;
						M = RMmax(1, M/f);
						positiveN = MAX_SPEED;
					}
					else if (M > MAX_SPEED) {
						RMuint32 f = (M + MAX_SPEED - 1) / MAX_SPEED;
						positiveN = RMmax(1, positiveN/f);
						M = MAX_SPEED;
					} 

					N = (N<0) ? (RMint32) -positiveN : (RMint32) positiveN;

					DCCSTCSetSpeed(dcc_info->pStcSource, N, M);

					fprintf(stderr, "Slow forward %ld/%ld...\n", N, M);
				}
			
				if (dcc_info->pAudioSource) {
					err = DCCStopAudioSource(dcc_info->pAudioSource);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Error stopping audio source %d\n", err));
						return err;
					}
				}
				dcc_info->state = RM_PLAYING_TRICKMODE;
				dcc_info->trickmode_id = RM_TRICKMODE_SLOW_FWD;
			}
			else {
				fprintf(stderr, "trickmodes not supported\n");
			}
			*cmd = RM_PLAY;
			break;
		case KEY_CMD_FAST_FWD:
			if (dcc_info->trick_supported) {
				if ((dcc_info->state != RM_PLAYING) && (dcc_info->state != RM_PLAYING_TRICKMODE)) {
					fprintf(stderr, "Enter Play state first...\n");
					break;
				}

				if (((dcc_info->pVideoSource) || (dcc_info->pAudioSource)) && (dcc_info->pStcSource)) {
					RMint32 N;
					RMuint32 M, positiveN;
				

					DCCSTCGetSpeed(dcc_info->pStcSource, &N, &M);

					if ((N == 0) || (M == 0)) {
						N = 1;
						M = 1;
					}

					positiveN = (N<0) ? (RMuint32) (-N) : (RMuint32) N;

					positiveN = 4*positiveN;
					M = 3*M;
					PGCD((RMint32 *)&positiveN, &M);
					if ((positiveN >= M) && (positiveN > MAX_SPEED)) {
						RMuint32 f = (positiveN + MAX_SPEED - 1) / MAX_SPEED;
						M = RMmax(1, M/f);
						positiveN = MAX_SPEED;
					}
					else if (M > MAX_SPEED) {
						RMuint32 f = (M + MAX_SPEED - 1) / MAX_SPEED;
						positiveN = RMmax(1, positiveN/f);
						M = MAX_SPEED;
					} 
				
					N = (N<0) ? (RMint32) -positiveN : (RMint32) positiveN;


					DCCSTCSetSpeed(dcc_info->pStcSource, N, M);

					fprintf(stderr, "Fast forward %ld/%ld...\n", N, M);
				}
			
				if (dcc_info->pAudioSource) {
					err = DCCStopAudioSource(dcc_info->pAudioSource);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Error stopping audio source %d\n", err));
						return err;
					}
				}
				if (dcc_info->state != RM_PLAYING_TRICKMODE) {
					dcc_info->state = RM_PLAYING_TRICKMODE;
					dcc_info->trickmode_id = RM_TRICKMODE_FAST_FWD;
				}
			}
			else {
				fprintf(stderr, "trickmodes not supported\n");
			}
			*cmd = RM_PLAY;
			break;
		case KEY_CMD_SPEED_FACTOR:
			if ((dcc_info->state != RM_PLAYING) && (dcc_info->state != RM_PLAYING_TRICKMODE)) {
				fprintf(stderr, "Enter Play state first...\n");
				break;
			}

			if ((dcc_info->pVideoSource) && (dcc_info->pStcSource)) {
				RMint32 N, speed;
				RMuint32 M;
				RMint32 direction;

				fprintf(stderr, "Speed factor [1/256] : ");

				RMTermGetUint32((RMuint32 *) &speed);
				
				direction = (speed > 0) ? 1 : -1;
				speed *= direction;
				if (speed >= 256) {
					M = 1;
					N = (speed * direction) / 256;
				}
				else {
					N = direction;
					M = 256 / speed;
				}


				DCCSTCSetSpeed(dcc_info->pStcSource, N, M);

				fprintf(stderr, "Fast forward %ld/%ld...\n", N, M);
			}

			if (dcc_info->pAudioSource) {
				err = DCCStopAudioSource(dcc_info->pAudioSource);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Error stopping audio source %d\n", err));
					return err;
				}
			}
			if (dcc_info->state != RM_PLAYING_TRICKMODE) {
				dcc_info->state = RM_PLAYING_TRICKMODE;
				dcc_info->trickmode_id = RM_TRICKMODE_FAST_FWD;
			}
			*cmd = RM_PLAY;
			break;
		case KEY_CMD_IFRAME_FWD:
			if (dcc_info->iframe_supported) {
				if ((dcc_info->state != RM_PLAYING) && (dcc_info->state != RM_PLAYING_TRICKMODE)) {
					fprintf(stderr, "Enter Play state first...\n");
					break;
				}
				fprintf(stderr, "Forward I-Frame mode. Use + to set the speed...\n");
				dcc_info->state = RM_PLAYING_TRICKMODE;
				dcc_info->trickmode_id = RM_TRICKMODE_FWD_IFRAME;
				*cmd = RM_PLAY;
			} else {
				fprintf(stderr, "iframe mode not supported...\n");
			}
			break;
		case KEY_CMD_IFRAME_BWD:
			if (dcc_info->iframe_supported) {
				if ((dcc_info->state != RM_PLAYING) && (dcc_info->state != RM_PLAYING_TRICKMODE)) {
					fprintf(stderr, "Enter Play state first...\n");
					break;
				}
				fprintf(stderr, "Backward I-Frame mode. Use + to set the speed...\n");
				dcc_info->state = RM_PLAYING_TRICKMODE;
				dcc_info->trickmode_id = RM_TRICKMODE_RWD_IFRAME;
				*cmd = RM_PLAY;
			} else {
				fprintf(stderr, "iframe mode not supported...\n");
			}
			break;	

		case KEY_CMD_SEEK:
			if (dcc_info->seek_supported) {
				fprintf(stderr, "Seeking ...\n");
				fprintf(stderr, "Seek time (s) : ");

				RMTermGetUint32(&(dcc_info->seek_time));
				
 				dcc_info->state = RM_PLAYING;
				dcc_info->trickmode_id = RM_NO_TRICKMODE;

				if (dcc_info->pStcSource)
					DCCSTCSetSpeed(dcc_info->pStcSource, 1, 1);

			} else {
				fprintf(stderr, "Seeking not supported ...\n");
			}
			*cmd = RM_SEEK;
			break;

		default:
			processed = FALSE;
		}
	}
	
	if (processed == TRUE)
		goto out_key;

	if (keyflags & SET_KEY_AUDIO) {
		processed = TRUE;
		switch (key) {
		case KEY_CMD_DUALMODE_AUDIO:
			*cmd = RM_DUALMODE_CHANGE;
			break;
		case KEY_CMD_VOLUME_PLUS:
		case KEY_CMD_VOLUME_MINUS:
			{
#if 0
				// Method to build the volume table. Volume = VOLUME_0DB * 2^(Gain/6), where Gain is expressed in dB.
#define CTN216_M	1122462048	// 2^(1/6) = 1.12246204830937298...
#define CTN216_N	1000000000
				VolumeTable[VOLUME_INDEX_0DB] = VOLUME_0DB;
				for ( dcc_info->volume = VOLUME_INDEX_0DB; dcc_info->volume >= 0; dcc_info->volume-- ) {
					VolumeTable[dcc_info->volume-1] = (((RMuint64)VolumeTable[dcc_info->volume] * CTN216_N + CTN216_M/2)/ CTN216_M);
				}
				for ( dcc_info->volume = VOLUME_INDEX_0DB; dcc_info->volume < sizeof(VolumeTable)/sizeof(RMuint32); dcc_info->volume_index++ ) {
					VolumeTable[dcc_info->volume_index+1] = (((RMuint64)VolumeTable[dcc_info->volume_index] * CTN216_M + CTN216_N/2)/ CTN216_N);
				}
				for ( dcc_info->volume_index = 0; dcc_info->volume_index < sizeof(VolumeTable)/sizeof(RMuint32); dcc_info->volume_index++ ) {
					fprintf(stdout, "0x%08lx, // %2lddB\n", VolumeTable[dcc_info->volume_index], dcc_info->volume_index-VOLUME_INDEX_0DB);
				};
#endif
				if ((key == KEY_CMD_VOLUME_PLUS) && (dcc_info->volume_index < 24))
					dcc_info->volume_index++;
				else if ((key == KEY_CMD_VOLUME_MINUS) && (dcc_info->volume_index > -VOLUME_INDEX_0DB))
					dcc_info->volume_index--;
				
				fprintf(stderr, "[0]Now volume is %ld dB = 0x%lx \n", dcc_info->volume_index, VolumeTable[VOLUME_INDEX_0DB+dcc_info->volume_index] );
				
				err = DCCSetAudioSourceVolume(dcc_info->pAudioSource, VolumeTable[VOLUME_INDEX_0DB+dcc_info->volume_index]);
				
				{
					RMuint32 volume;

					err = DCCGetAudioSourceVolume(dcc_info->pAudioSource, &volume);
					if (err == RM_OK)
						RMDBGLOG((ENABLE, "volume for all channels is = 0x%lx \n", volume));
					else
						fprintf(stderr, "error getting volume\n");
				}
			}
			break;
		case KEY_CMD_VOLUME_MUTE:
			{
				RMuint32 vol;
				
				dcc_info->mute = !dcc_info->mute;
				vol = (dcc_info->mute) ? 0 : VolumeTable[VOLUME_INDEX_0DB+dcc_info->volume_index];

				err = DCCSetAudioSourceVolume(dcc_info->pAudioSource, vol);
			}
			break;
			
		case KEY_CMD_SPEED_UP:
		case KEY_CMD_SPEED_DOWN:
			{
				if (key == KEY_CMD_SPEED_UP) ppm++;
				else ppm--;
				DCCSTCSetSpeedCleanDiv(dcc_info->pStcSource, 1000000 + ppm, 1000000);
			}
			break;
		
		default:
			processed = FALSE;
		}
	}
	
	if (processed == TRUE)
		goto out_key;

	if ((keyflags & SET_KEY_DISPLAY) && (dcc_info->disp_info != NULL) ) {
		processed = TRUE;
		switch (key) {
		case KEY_CMD_DAC_ON_OFF:
			{
				RMstatus err;
				static RMbool dac_on_off = TRUE;

				dac_on_off = !dac_on_off;

				while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_Enable, &dac_on_off, sizeof(dac_on_off), 0)) == RM_PENDING);
				while ((err = RUASetProperty(dcc_info->pRUA, DispMainAnalogOut, RMGenericPropertyID_Enable, &dac_on_off, sizeof(dac_on_off), 0)) == RM_PENDING);
				while ((err = RUASetProperty(dcc_info->pRUA, DispComponentOut, RMGenericPropertyID_Enable, &dac_on_off, sizeof(dac_on_off), 0)) == RM_PENDING);
				while ((err = RUASetProperty(dcc_info->pRUA, DispCompositeOut, RMGenericPropertyID_Enable, &dac_on_off, sizeof(dac_on_off), 0)) == RM_PENDING);

				while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
				while ((err = RUASetProperty(dcc_info->pRUA, DispMainAnalogOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
				while ((err = RUASetProperty(dcc_info->pRUA, DispComponentOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
				while ((err = RUASetProperty(dcc_info->pRUA, DispCompositeOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
			}

			break;
		case KEY_CMD_CONTRAST_PLUS:
		case KEY_CMD_CONTRAST_MINUS:
			if ((key == KEY_CMD_CONTRAST_PLUS) && (dcc_info->disp_info->contrast < 240))
				dcc_info->disp_info->contrast += 16;
			else if ((key == KEY_CMD_CONTRAST_MINUS) && (dcc_info->disp_info->contrast > 15))
				dcc_info->disp_info->contrast -= 16;

			fprintf(stderr, "Now contrast is %hu\n", dcc_info->disp_info->contrast);
			
			while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_Contrast, &(dcc_info->disp_info->contrast), sizeof(dcc_info->disp_info->contrast), 0)) == RM_PENDING);
			if (RMFAILED(err)) RMDBGLOG((ENABLE, "Cannot set the contrast on the Digital output\n"));
			while ((err = RUASetProperty(dcc_info->pRUA, DispMainAnalogOut, RMGenericPropertyID_Contrast, &(dcc_info->disp_info->contrast), sizeof(dcc_info->disp_info->contrast), 0)) == RM_PENDING);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot set the contrast %d\n", err));
				return err;
			}
			while ((err = RUASetProperty(dcc_info->pRUA, DispComponentOut, RMGenericPropertyID_Contrast, &(dcc_info->disp_info->contrast), sizeof(dcc_info->disp_info->contrast), 0)) == RM_PENDING);
			while ((err = RUASetProperty(dcc_info->pRUA, DispCompositeOut, RMGenericPropertyID_Contrast, &(dcc_info->disp_info->contrast), sizeof(dcc_info->disp_info->contrast), 0)) == RM_PENDING);
			//These will fail normally on EM862xL & SMP863x, no need to alarm people, deactivate error message. If you are using EM8605 or EM8610, put this sample error msg
			//if (RMFAILED(err)) RMDBGPRINT((ENABLE, "Cannot set the contrast on DispComponentOut %d; if you do NOT have EM8605 or EM8610, this is normal\n"));
			
			while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
			if (RMFAILED(err)) RMDBGLOG((ENABLE, "Cannot validate contrast on Digital output %d\n", err));
			while ((err = RUASetProperty(dcc_info->pRUA, DispMainAnalogOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot validate contrast on main analog out %d\n", err));
				return err;
			}
			while ((err = RUASetProperty(dcc_info->pRUA, DispComponentOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
			while ((err = RUASetProperty(dcc_info->pRUA, DispCompositeOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
			//These will fail normally on EM862xL & SMP863x, no need to alarm people, deactivate error message. If you are using EM8605 or EM8610, put the sample error msg
			
			break;
		case KEY_CMD_BRIGHTNESS_PLUS:
		case KEY_CMD_BRIGHTNESS_MINUS:
			if ((key == KEY_CMD_BRIGHTNESS_PLUS) && (dcc_info->disp_info->brightness < 120))
				dcc_info->disp_info->brightness += 8;
			else if ((key == KEY_CMD_BRIGHTNESS_MINUS) && (dcc_info->disp_info->brightness > -121))
				dcc_info->disp_info->brightness -= 8;

			fprintf(stderr, "Now brightness is %d\n", dcc_info->disp_info->brightness);
			
			while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_Brightness, &(dcc_info->disp_info->brightness), sizeof(dcc_info->disp_info->brightness), 0)) == RM_PENDING);
			if (RMFAILED(err)) RMDBGLOG((ENABLE, "Cannot set the brightness on the Digital output\n"));
			while ((err = RUASetProperty(dcc_info->pRUA, DispMainAnalogOut, RMGenericPropertyID_Brightness, &(dcc_info->disp_info->brightness), sizeof(dcc_info->disp_info->brightness), 0)) == RM_PENDING);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot set the brightness %d\n", err));
				return err;
			}
			while ((err = RUASetProperty(dcc_info->pRUA, DispComponentOut, RMGenericPropertyID_Brightness, &(dcc_info->disp_info->brightness), sizeof(dcc_info->disp_info->brightness), 0)) == RM_PENDING);
			while ((err = RUASetProperty(dcc_info->pRUA, DispCompositeOut, RMGenericPropertyID_Brightness, &(dcc_info->disp_info->brightness), sizeof(dcc_info->disp_info->brightness), 0)) == RM_PENDING);
			//These will fail normally on EM862xL & SMP863x, no need to alarm people, deactivate error message. If you are using EM8605 or EM8610, put this sample error msg
			//if (RMFAILED(err)) RMDBGPRINT((ENABLE, "Cannot set the brightness on DispComponentOut %d; if you do NOT have EM8605 or EM8610, this is normal\n"));
			
			while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
			if (RMFAILED(err)) RMDBGLOG((ENABLE, "Cannot validate brightness on Digital output %d\n", err));
			while ((err = RUASetProperty(dcc_info->pRUA, DispMainAnalogOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot validate brightness on main analog out %d\n", err));
				return err;
			}
			while ((err = RUASetProperty(dcc_info->pRUA, DispComponentOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
			while ((err = RUASetProperty(dcc_info->pRUA, DispCompositeOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
			//These will fail normally on EM862xL & SMP863x, no need to alarm people, deactivate error message. If you are using EM8605 or EM8610, put the sample error msg
			break;
		case KEY_CMD_SATURATION_PLUS:
		case KEY_CMD_SATURATION_MINUS:
			if ((key == KEY_CMD_SATURATION_PLUS) && (dcc_info->disp_info->saturation < 240))
				dcc_info->disp_info->saturation += 16;
			else if ((key == KEY_CMD_SATURATION_MINUS) && (dcc_info->disp_info->saturation > 15))
				dcc_info->disp_info->saturation -= 16;

			fprintf(stderr, "Now saturation is %hu\n", dcc_info->disp_info->saturation);

			while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_CbSaturation, &(dcc_info->disp_info->saturation), sizeof(dcc_info->disp_info->saturation), 0)) == RM_PENDING);
			if (RMFAILED(err)) RMDBGLOG((ENABLE, "Cannot set the Cb saturation on the Digital output\n"));
			while ((err = RUASetProperty(dcc_info->pRUA, DispMainAnalogOut, RMGenericPropertyID_CbSaturation, &(dcc_info->disp_info->saturation), sizeof(dcc_info->disp_info->saturation), 0)) == RM_PENDING);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot set the Cb saturation %d\n", err));
				return err;
			}
			while ((err = RUASetProperty(dcc_info->pRUA, DispComponentOut, RMGenericPropertyID_CbSaturation, &(dcc_info->disp_info->saturation), sizeof(dcc_info->disp_info->saturation), 0)) == RM_PENDING);
			while ((err = RUASetProperty(dcc_info->pRUA, DispCompositeOut, RMGenericPropertyID_CbSaturation, &(dcc_info->disp_info->saturation), sizeof(dcc_info->disp_info->saturation), 0)) == RM_PENDING);
			//These will fail normally on EM862xL & SMP863x, no need to alarm people, deactivate error message. If you are using EM8605 or EM8610, put this sample error msg
			//if (RMFAILED(err)) RMDBGPRINT((ENABLE, "Cannot set the Cb saturation on DispComponentOut %d; if you do NOT have EM8605 or EM8610, this is normal\n"));
	
			while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_CrSaturation, &(dcc_info->disp_info->saturation), sizeof(dcc_info->disp_info->saturation), 0)) == RM_PENDING);
			if (RMFAILED(err)) RMDBGLOG((ENABLE, "Cannot set the Cr saturation %d on the Digital output\n", err));
			
			while ((err = RUASetProperty(dcc_info->pRUA, DispMainAnalogOut, RMGenericPropertyID_CrSaturation, &(dcc_info->disp_info->saturation), sizeof(dcc_info->disp_info->saturation), 0)) == RM_PENDING);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot set the Cr saturation %d\n", err));
				return err;
			}
			while ((err = RUASetProperty(dcc_info->pRUA, DispComponentOut, RMGenericPropertyID_CrSaturation, &(dcc_info->disp_info->saturation), sizeof(dcc_info->disp_info->saturation), 0)) == RM_PENDING);
			while ((err = RUASetProperty(dcc_info->pRUA, DispCompositeOut, RMGenericPropertyID_CrSaturation, &(dcc_info->disp_info->saturation), sizeof(dcc_info->disp_info->saturation), 0)) == RM_PENDING);
			//These will fail normally on EM862xL & SMP863x, no need to alarm people, deactivate error message. If you are using EM8605 or EM8610, put this sample error msg
			//if (RMFAILED(err)) RMDBGPRINT((ENABLE, "Cannot set the Cr saturation on DispComponentOut %d; if you do NOT have EM8605 or EM8610, this is normal\n"));
			
			while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
			if (RMFAILED(err)) RMDBGLOG((ENABLE, "Cannot validate saturation on the Digital output %d\n", err));
			while ((err = RUASetProperty(dcc_info->pRUA, DispMainAnalogOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot validate main analog out saturation %d\n", err));
				return err;
			}
			while ((err = RUASetProperty(dcc_info->pRUA, DispComponentOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
			while ((err = RUASetProperty(dcc_info->pRUA, DispCompositeOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
			//These will fail normally on EM862xL & SMP863x, no need to alarm people, deactivate error message. If you are using EM8605 or EM8610, put the example
			break;
		case KEY_CMD_HUE_PLUS:
		case KEY_CMD_HUE_MINUS:
			if ((key == KEY_CMD_HUE_PLUS) && (dcc_info->disp_info->hue < 61))
				dcc_info->disp_info->hue += 4;
			else if ((key == KEY_CMD_HUE_MINUS) && (dcc_info->disp_info->hue > -61))
				dcc_info->disp_info->hue -= 4;
			
			fprintf(stderr, "Now hue is %d\n", dcc_info->disp_info->hue);
			
			while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_Hue, &(dcc_info->disp_info->hue), sizeof(dcc_info->disp_info->hue), 0)) == RM_PENDING);
			if (RMFAILED(err)) RMDBGLOG((ENABLE, "Cannot set the hue on the Digital output\n"));
			while ((err = RUASetProperty(dcc_info->pRUA, DispMainAnalogOut, RMGenericPropertyID_Hue, &(dcc_info->disp_info->hue), sizeof(dcc_info->disp_info->hue), 0)) == RM_PENDING);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot set the hue %d\n", err));
				return err;
			}
			while ((err = RUASetProperty(dcc_info->pRUA, DispComponentOut, RMGenericPropertyID_Hue, &(dcc_info->disp_info->hue), sizeof(dcc_info->disp_info->hue), 0)) == RM_PENDING);
			while ((err = RUASetProperty(dcc_info->pRUA, DispCompositeOut, RMGenericPropertyID_Hue, &(dcc_info->disp_info->hue), sizeof(dcc_info->disp_info->hue), 0)) == RM_PENDING);
			//These will fail normally on EM862xL & SMP863x, no need to alarm people, deactivate error message. If you are using EM8605 or EM8610, put this sample error msg
			//if (RMFAILED(err)) RMDBGPRINT((ENABLE, "Cannot set the hue on DispComponentOut %d; if you do NOT have EM8605 or EM8610, this is normal\n"));
			
			while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
			if (RMFAILED(err)) RMDBGLOG((ENABLE, "Cannot validate hue on Digital output %d\n", err));
			while ((err = RUASetProperty(dcc_info->pRUA, DispMainAnalogOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot validate hue on main analog out %d\n", err));
				return err;
			}
			while ((err = RUASetProperty(dcc_info->pRUA, DispComponentOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
			while ((err = RUASetProperty(dcc_info->pRUA, DispCompositeOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
			//These will fail normally on EM862xL & SMP863x, no need to alarm people, deactivate error message. If you are using EM8605 or EM8610, put the sample error msg
			break;
		case KEY_CMD_DEFAULT_OUTPUT:
			set_default_out_window(dcc_info->disp_info->active_window);
			update_out_window = TRUE;
			break;
		case KEY_CMD_HALF_OUTPUT:
			dcc_info->disp_info->active_window->X = 2048;
			dcc_info->disp_info->active_window->Y = 2048;
			dcc_info->disp_info->active_window->Width  = 2048;
			dcc_info->disp_info->active_window->Height = 2048;
			update_out_window = TRUE;
			break;
		case KEY_CMD_MINUS_OUTPUT_SIZE:
			if (dcc_info->disp_info->active_window->Width > 128) 
				dcc_info->disp_info->active_window->Width  -= 128;
			else
				dcc_info->disp_info->active_window->Width = 0;
			
			if (dcc_info->disp_info->active_window->Height > 128) 
				dcc_info->disp_info->active_window->Height  -= 128;
			else
				dcc_info->disp_info->active_window->Height = 0;
			update_out_window = TRUE;
			break;
		case KEY_CMD_PLUS_OUTPUT_SIZE:
			dcc_info->disp_info->active_window->Width  += 128;
			dcc_info->disp_info->active_window->Height += 128;
			update_out_window = TRUE;
			break;
		case KEY_CMD_TOP_OUTPUT:
			dcc_info->disp_info->active_window->Y -= 128;
			update_out_window = TRUE;
			break;
		case KEY_CMD_BOTTOM_OUTPUT:
			dcc_info->disp_info->active_window->Y += 128;
			update_out_window = TRUE;
			break;	
		case KEY_CMD_LEFT_OUTPUT:
			dcc_info->disp_info->active_window->X -= 128;
			update_out_window = TRUE;
			break;
		case KEY_CMD_RIGHT_OUTPUT:
			dcc_info->disp_info->active_window->X += 128;
			update_out_window = TRUE;
			break;
		
		case KEY_CMD_SWITCH_OUTPUT:
			if (dcc_info->disp_info->active_window == &(dcc_info->disp_info->out_window)) {
				if (dcc_info->pOSDSource[0] != NULL){
					dcc_info->disp_info->active_window = &(dcc_info->disp_info->osd_window[0]);
				}
			}
			else {
				if (dcc_info->pVideoSource != NULL){
					dcc_info->disp_info->active_window = &(dcc_info->disp_info->out_window);
				}
			}
			
			break;
			
		case KEY_CMD_ENABLE_OUTPUT:
			if (dcc_info->disp_info->active_window == &(dcc_info->disp_info->out_window)) 
				dcc_info->disp_info->video_enable = ! dcc_info->disp_info->video_enable;
			else
				dcc_info->disp_info->osd_enable[0] = ! dcc_info->disp_info->osd_enable[0];
			update_out_window = TRUE;
			break;
			
		case KEY_CMD_DUMP_OSD_INFO:
			if (dcc_info->pOSDSource[0] != NULL) {
				RMuint32 Y_addr, Y_size, UV_addr, UV_size;
				err = DCCGetOSDVideoSourceInfo(dcc_info->pOSDSource[0], &Y_addr, &Y_size, &UV_addr, &UV_size);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Cannot get OSD information %d\n", err));
					return err;
				}
				fprintf(stderr,"OSD is 0x%08lx %lu 0x%08lx %lu\n", Y_addr, Y_size, UV_addr, UV_size);
				
				err = DCCClearOSDVideoSource(dcc_info->pOSDSource[0]);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Cannot clear OSD %d\n", err));
					return err;
				}
			}
			break;
		
		case KEY_CMD_NONLINEAR_MINUS:
			if (dcc_info->disp_info->nonlinearmode.Width >= 3) dcc_info->disp_info->nonlinearmode.Width = 0;
			else dcc_info->disp_info->nonlinearmode.Width ++;
			if (dcc_info->disp_info->nonlinearmode.Width) dcc_info->disp_info->blackstrip.Vertical = 256;
			else dcc_info->disp_info->blackstrip.Vertical = 4096;
			fprintf(stderr, "Non-linear scaling width: %ld\n", dcc_info->disp_info->nonlinearmode.Width);
			update_out_window = TRUE;
			break;
		case KEY_CMD_NONLINEAR_PLUS:
			if (dcc_info->disp_info->nonlinearmode.Level >= 3) dcc_info->disp_info->nonlinearmode.Level = 0;
			else dcc_info->disp_info->nonlinearmode.Level ++;
			fprintf(stderr, "Non-linear scaling level: %ld\n", dcc_info->disp_info->nonlinearmode.Level);
			update_out_window = TRUE;
			break;
		case KEY_CMD_ROTATE_PICTURE:
			*cmd = RM_ROTATE_PICTURE;
			break;
		
		default:
			processed = FALSE;
		}
	}
	
	if (processed == TRUE)
		goto out_key;

	if (keyflags & SET_KEY_SPI) {
		processed = TRUE;
		switch (key) {
		case KEY_CMD_CHANGE_CHANNEL:
			*cmd = RM_CHANNEL_CHANGE;
			break;
		case KEY_CMD_PAT_INFO:
			*cmd = RM_PAT_INFO;
			break;
		case KEY_CMD_CHANGE_PMT:
			*cmd = RM_PMT_CHANGE;
			break;
		case KEY_CMD_CHANGE_AUDIO: {
			RMuint32 streamNumber;
			RMDBGLOG((ENABLE,"audio stream change (select mode)\n"));

			RMDBGLOG((ENABLE, "switch to audio stream: "));
			RMTermGetUint32(&streamNumber);
			dcc_info->selectAudioStream = (RMint32) streamNumber;

			dcc_info->state = RM_AUDIO_STREAM_CHANGE;
			dcc_info->trickmode_id = RM_NO_TRICKMODE;
			*cmd = RM_PLAY;
			break;
		}
		case KEY_CMD_CYCLE_AUDIO:
			RMDBGLOG((ENABLE,"audio stream change (cycle mode)\n"));
			dcc_info->selectAudioStream = -1;
			dcc_info->state = RM_AUDIO_STREAM_CHANGE;
			dcc_info->trickmode_id = RM_NO_TRICKMODE;
			*cmd = RM_PLAY;
			break;

		case KEY_CMD_CHANGE_VIDEO:
			*cmd = RM_VIDEO_STREAM_CHANGE;
			break;
		default:
			processed = FALSE;
		}
	}
	
	if ( key ==  KEY_CMD_QUIT){
		*cmd = RM_QUIT;
		goto out_key;
	}
	
 out_key:
	if (update_out_window) {
		err = set_display_out_window(dcc_info);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error setting out window %d\n", err));
			return err;
		}
	}
	
	return processed ? RM_OK : RM_PENDING;
}


/* prototypes required for process_command() */

RMbool handle_audio_keys(struct dcc_context *dcc_info, struct RM_PSM_Actions *actions, RMascii key);
RMbool handle_spi_keys(struct dcc_context *dcc_info, struct RM_PSM_Actions *actions, RMascii key);
RMstatus handle_playback_keys(struct dcc_context *dcc_info, struct RM_PSM_Actions *actions, RMascii key);
RMstatus handle_display_keys(struct dcc_context *dcc_info, struct RM_PSM_Actions *actions, RMascii key);

enum RM_PSM_State RM_PSM_GetState(struct RM_PSM_Context *PSMcontext, struct dcc_context *dcc_info_array[]) 
{
	struct dcc_context *dcc_info;

	if ((PSMcontext->currentActivePSMContext <= PSMcontext->validPSMContexts) &&
	    (PSMcontext->currentActivePSMContext != 0)) {
		RMDBGLOG((DISABLE, "GetState for context %lu\n", PSMcontext->currentActivePSMContext));
		dcc_info = dcc_info_array[PSMcontext->currentActivePSMContext - 1];
		switch (dcc_info->FSMstate) {
		case RM_PSM_IPaused:
			return RM_PSM_Paused;
		case RM_PSM_INextPic:
			return RM_PSM_NextPic;
		default:
			return dcc_info->FSMstate;
		}
	}
	RMDBGLOG((DISABLE, "GetState for defaut context\n"));
	dcc_info = dcc_info_array[0];

	switch (dcc_info->FSMstate) {
	case RM_PSM_IPaused:
		return RM_PSM_Paused;
	case RM_PSM_INextPic:
		return RM_PSM_NextPic;
	default:
		return dcc_info->FSMstate;
	}
		
}

void RM_PSM_SetState(struct RM_PSM_Context *PSMcontext, struct dcc_context *dcc_info_array[], enum RM_PSM_State newstate)
{
	RMascii buffer[256];
	enum RM_PSM_State oldstate;
	struct dcc_context *dcc_info;

	if ((PSMcontext->currentActivePSMContext <= PSMcontext->validPSMContexts) &&
	    (PSMcontext->currentActivePSMContext != 0)) {
		RMDBGLOG((DISABLE, "SetState for context %lu\n", PSMcontext->currentActivePSMContext));
		dcc_info = dcc_info_array[PSMcontext->currentActivePSMContext - 1];
	}
	else {
		RMDBGLOG((DISABLE, "SetState for defaut context\n"));
		dcc_info = dcc_info_array[0];
	}


	oldstate = dcc_info->FSMstate;

	dcc_info->FSMstate = newstate;

	switch (dcc_info->FSMstate) {
	case RM_PSM_Playing:
		sprintf(buffer, "playing");
		break;
	case RM_PSM_Stopped:
		sprintf(buffer, "stopped");
		break;
	case RM_PSM_Paused:
		sprintf(buffer, "paused");
		break;
	case RM_PSM_NextPic:
		sprintf(buffer, "nextpic");
		break;
	case RM_PSM_Slow:
		sprintf(buffer, "slow");
		break;
	case RM_PSM_Fast:
		sprintf(buffer, "fast");
		break;
	case RM_PSM_IForward:
		sprintf(buffer, "ifwd");
		break;
	case RM_PSM_IRewind:
		sprintf(buffer, "irwd");
		break;
	case RM_PSM_Prebuffering:
		sprintf(buffer, "prebuf");
		break;
	case RM_PSM_IPaused:
		sprintf(buffer, "ipaused");
		break;
	case RM_PSM_INextPic:
		sprintf(buffer, "inextpic");
		break;
	case RM_PSM_Rewind:
		sprintf(buffer, "rewind");
		break;
	}
		
	if (dcc_info->FSMstate == oldstate)
		sprintf(buffer+strlen(buffer), " (unchanged)");
	
	RMDBGLOG((ENABLE, "set_PlaybackState to: %s\n", buffer));

	
}


/* NOTES:

   Sending audio while in trickmodes. Instead of stopping the audio decoder, we mute the output
   and reconfigure the audio decoder to read the value of the displayPTS as it's "stc".

   Currently only works for WMV9 files because the timeScale for audio and video is the same
   
   This works for FFwd and SFwd, it doesnt work for IFrame modes because IFrame mode involves seeking

   muteAudio, unMuteAudio and routeAudioTimer are the functions implementing this functionality

*/



void muteAudio(struct dcc_context *dcc_info)
{
	RMstatus err;

	RMDBGLOG((ENABLE, ">>> mute audio\n"));

	if (dcc_info->pAudioSource) {
		err = DCCSetAudioSourceVolume(dcc_info->pAudioSource, 0);
		if (err != RM_OK)
			fprintf(stderr, "error setting volume\n");
	}
	else if (dcc_info->pMultipleAudioSource) {
		err = DCCSetMultipleAudioSourceVolume(dcc_info->pMultipleAudioSource, 0);
		if (err != RM_OK)
			fprintf(stderr, "error setting multiple source volume\n");
	}

	return;
}

void unMuteAudio(struct dcc_context *dcc_info)
{
	RMstatus err;
	RMuint32 volume;

	RMDBGLOG((ENABLE, ">>> unmute audio\n"));
	
	volume = VolumeTable[VOLUME_INDEX_0DB+dcc_info->volume_index];

	if (dcc_info->pAudioSource) {
		err = DCCSetAudioSourceVolume(dcc_info->pAudioSource, volume);
		if (err != RM_OK)
			fprintf(stderr, "error setting volume\n");
	}
	else if (dcc_info->pMultipleAudioSource) {
		err = DCCSetMultipleAudioSourceVolume(dcc_info->pMultipleAudioSource, volume);
		if (err != RM_OK)
			fprintf(stderr, "error setting multiple source volume\n");
	}

	return;
}



void routeAudioTimerToDisplayPTS(struct dcc_context *dcc_info, RMbool enable)
{
	if (dcc_info->pVideoSource) {
		struct AudioDecoder_SynchroniseAudioWithDisplayPTS_type syncProp;
		RMuint32 audioTIR;
		RMstatus err;

		if (enable) {
			RMDBGLOG((ENABLE, "********************* rerouting audio timer to display\n"));

			DCCSTCGetTimeResolution(dcc_info->pStcSource, DCC_Audio, &audioTIR);
			//RUAGetProperty(dcc_info->pRUA, dcc_info->pStcSource->StcModuleId, RMSTCPropertyID_AudioTimeResolution, &audioTIR, sizeof(RMuint32));
		}
		else {
			RMDBGLOG((ENABLE, "********************* rerouting audio timer to STC\n"));

			audioTIR = 0;
		}
		
		syncProp.ModuleID = dcc_info->SurfaceID;
		syncProp.Enable = enable;

		if (dcc_info->pAudioSource) {
			err = RUASetProperty(dcc_info->pRUA, dcc_info->audio_decoder, RMAudioDecoderPropertyID_SynchroniseAudioWithDisplayPTS, &syncProp, sizeof(syncProp), 0);
		}
		else if (dcc_info->pMultipleAudioSource) {
			RMuint32 i;
			RMuint32 instances;
			struct DCCAudioSourceHandle audioHandle;

			DCCMultipleAudioSourceGetNumberOfInstances(dcc_info->pMultipleAudioSource, &instances);

			for (i = 0; i < instances; i++) {
				RMDBGLOG((ENABLE, "routing instance %lu\n", i));
				err = DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(dcc_info->pMultipleAudioSource, i, &audioHandle);
				if (err != RM_OK)
					break;
				err = RUASetProperty(dcc_info->pRUA, audioHandle.moduleID, RMAudioDecoderPropertyID_SynchroniseAudioWithDisplayPTS, &syncProp, sizeof(syncProp), 0);
			}
		}
	}

	return;
}



/* process_command, Finite State Machine */
RMstatus process_command(struct RM_PSM_Context *PSMcontext, struct dcc_context *dcc_info_array[], struct RM_PSM_Actions *actions)
{
	RMascii key;
	RMstatus err;

	RMbool keyProcessed;
	//RMbool processAllDecoders = FALSE;
	RMuint32 keyflags = PSMcontext->keyflags;
	RMbool getKey = FALSE;
	RMbool gotKey = FALSE;
	RMint32 i = 0, stopped = 0;
	struct dcc_context *dcc_info;

#ifdef _DEBUG
	enum RM_PSM_State oldstate;
#endif
	
	for ( i = 0; i < PSMcontext->validPSMContexts; i++) {
		if(dcc_info_array[i]->scc)
			refresh_soft_cc(dcc_info_array[i]);
	}


	/* verify decoder status */
	for ( i = 0; i < PSMcontext->validPSMContexts; i++) {
		if ((dcc_info_array[i]->FSMstate == RM_PSM_Stopped) || 
		    (dcc_info_array[i]->FSMstate == RM_PSM_Paused) ||
		    (dcc_info_array[i]->FSMstate == RM_PSM_IPaused)) {
			RMDBGLOG((DISABLE, "decoder %ld is %s\n", 
				  i+1, 
				  dcc_info_array[i]->FSMstate == RM_PSM_Stopped ? "stopped":"paused"));
			stopped++;
		}
	}

	if (stopped == PSMcontext->validPSMContexts) {
		RMDBGLOG((ENABLE, "all decoders are stopped or paused, awaiting command\n"));
		getKey = TRUE;
	}


 get_key:	

	key = 0;

	/* init FSM outputs */

	/* because async commands are application specific and due to their asynchronous nature, they must survive
	   succesive calls to process_command, that's why they are not initialized here */

	actions->performedActions = 0;
	actions->toDoActions = 0;
	actions->cmd = RM_NONE;
	actions->cmdProcessed = FALSE;

	if ((getKey) || (RMKeyAvailable())){
		key = RMGetKey();
		gotKey = TRUE;
	}

	
	if (!gotKey) 
		return RM_OK;
#ifdef _DEBUG
	else {
		if ((key == KEY_CMD_NONE1) || (key == KEY_CMD_NONE2))
			RMDBGLOG((DISABLE, "key none\n"));
	}
#endif

	keyProcessed = TRUE; //we assume the key will be treated

	/* the selection key shall be treated outside the for() */
	if (key == KEY_CMD_SELECT_DECODER){
		RMint32 decoder;
		actions->cmdProcessed = TRUE;
 		actions->cmd = RM_DECODER_CHANGE;

		fprintf(stderr, "select decoder [0: all]: ");
		RMTermGetUint32((RMuint32 *)&decoder);
		
		if (decoder > PSMcontext->validPSMContexts) {
			fprintf(stderr, "invalid decoder(%lu), valid decoders 1...%lu or 0 for all decoders\n", decoder, PSMcontext->validPSMContexts);
			actions->cmdProcessed = FALSE;
		        return RM_OK;
		}
		if (decoder != 0)
			fprintf(stderr, "selecting decoder %lu\n", decoder);
		else
			fprintf(stderr, "selecting all decoders\n");
		
		PSMcontext->currentActivePSMContext = decoder;
		return RM_OK;
	}

	if (PSMcontext->currentActivePSMContext == 0) {
		RMDBGLOG((DISABLE, "all decoders selected\n"));
		PSMcontext->selectedPSMContextMask = 0xF;
	}
	else if (PSMcontext->currentActivePSMContext <= PSMcontext->validPSMContexts) {
		PSMcontext->selectedPSMContextMask = (1<< (PSMcontext->currentActivePSMContext - 1));
		RMDBGLOG((ENABLE, "selecting single decoder, mask 0x%08lx\n", PSMcontext->selectedPSMContextMask));
	}
	else {
		RMDBGLOG((ENABLE, "ERROR: invalid PSMcontext\n"));
		return RM_ERROR;
	}


	/* we process all decoders */
	for (i = 0; i < PSMcontext->validPSMContexts; i++) {

		if ((PSMcontext->selectedPSMContextMask & (1<<i))) {
			RMDBGLOG((DISABLE, "processing decoder %lu\n", i+1));
			dcc_info = dcc_info_array[i];
		}
		else {
			RMDBGLOG((DISABLE, "decoder %lu skipped\n", i+1));
			continue;
		}
		
#ifdef _DEBUG
		oldstate = dcc_info->FSMstate;
#endif

		if (keyflags & SET_KEY_DEBUG) {
			if (key == KEY_CMD_GET_DEBUG_INFO) {
				actions->cmd = KEY_CMD_GET_DEBUG_INFO;
				actions->cmdProcessed = FALSE;
				RMDBGLOG((DISABLE, "goto after debugKeys!\n"));
				goto out_key_debug;
			} else {
				handle_debug_key(dcc_info, key, &(actions->cmdProcessed));
				if (actions->cmdProcessed) {
					RMDBGLOG((DISABLE, "goto after debugKeys!\n"));
					goto out_key_debug;
				}
			}
		}
	
		if (dcc_info->FSMstate == RM_PSM_Prebuffering) {
			if (key == KEY_CMD_QUIT) {
				fprintf(stderr, "Quitting during prebuffering...\n");
				actions->cmd = RM_QUIT;
				actions->cmdProcessed = FALSE;
				goto out_key;
			}
			else {
				fprintf(stderr, "commands other than 'quit' are not allowed while prebuffering, skip\n");
				return RM_OK;
			}
		}

		if (keyflags & SET_KEY_PLAYBACK) {
			err = handle_playback_keys(dcc_info, actions, key);
			if (err == RM_OK) {
				RMDBGLOG((ENABLE, "goto after playbackKeys!\n"));
				goto out_key;
			}
			else if (err != RM_NOTIMPLEMENTED) {
				RMDBGLOG((DISABLE, "handle_playback_keys returned error!\n"));
				return err;
			}
		}
	
		if (keyflags & SET_KEY_AUDIO) {
			if (handle_audio_keys(dcc_info, actions, key) == TRUE) {
				RMDBGLOG((DISABLE, "goto after audioKeys!\n"));
				goto out_key;
			}
		}

		if ((keyflags & SET_KEY_DISPLAY) && (dcc_info->disp_info != NULL) ) {
			err = handle_display_keys(dcc_info, actions, key);
			if (err == RM_OK) {
				RMDBGLOG((DISABLE, "goto after displayKeys!\n"));
				goto out_key;
			}
			else if (err != RM_NOTIMPLEMENTED) {
				RMDBGLOG((DISABLE, "handle_display_keys returned error!\n"));
				return err;
			}
		}

		if (keyflags & SET_KEY_SPI) {
			if (handle_spi_keys(dcc_info, actions, key) == TRUE) {
				RMDBGLOG((DISABLE, "goto after spiKeys!\n"));
				goto out_key;
			}
		}

		//RMDBGLOG((ENABLE, "unhandled key '%c', passing it to the application\n", key));
		actions->cmdProcessed = FALSE;
		keyProcessed = FALSE;

	
	out_key:


#ifdef _DEBUG
		if (keyProcessed) {
			char buffer[256];

			switch (dcc_info->FSMstate) {
			case RM_PSM_Playing:
				sprintf(buffer, "state is: playing");
				break;
			case RM_PSM_Stopped:
				sprintf(buffer, "state is: stopped");
				break;
			case RM_PSM_Paused:
				sprintf(buffer, "state is: paused");
				break;
			case RM_PSM_NextPic:
				sprintf(buffer, "state is: nextpic");
				break;
			case RM_PSM_Slow:
				sprintf(buffer, "state is: slow");
				break;
			case RM_PSM_Fast:
				sprintf(buffer, "state is: fast");
				break;
			case RM_PSM_IForward:
				sprintf(buffer, "state is: ifwd");
				break;
			case RM_PSM_IRewind:
				sprintf(buffer, "state is: irwd");
				break;
			case RM_PSM_Prebuffering:
				sprintf(buffer, "state is: prebuf");
				break;
			case RM_PSM_IPaused:
				sprintf(buffer, "state is: ipaused");
				break;
			case RM_PSM_INextPic:
				sprintf(buffer, "state is: inextpic");
				break;
			case RM_PSM_Rewind:
				sprintf(buffer, "state is: rewind");
				break;
			}
		
			if (dcc_info->FSMstate == oldstate)
				sprintf(buffer+strlen(buffer), " (unchanged)");

			RMDBGLOG((ENABLE, "%s\n", buffer));

				
			buffer[0] = '\0';
			if (actions->performedActions & RM_PSM_AUDIO_STOPPED)
				sprintf(buffer+strlen(buffer), "audioStopped, ");
			if (actions->performedActions & RM_PSM_VIDEO_STOPPED)
				sprintf(buffer+strlen(buffer), "videoStopped, ");
			if (actions->performedActions & RM_PSM_DEMUX_STOPPED)
				sprintf(buffer+strlen(buffer), "demuxStopped, ");
			if (actions->performedActions & RM_PSM_STC_STOPPED)
				sprintf(buffer+strlen(buffer), "stcStopped, ");

			if (actions->toDoActions & RM_PSM_FIRST_PTS)
				sprintf(buffer, "firstPTS, ");
			if (actions->toDoActions & RM_PSM_RESYNC_TIMER)
				sprintf(buffer+strlen(buffer), "resyncTimer, ");
			if (actions->toDoActions & RM_PSM_DEMUX_IFRAME)
				sprintf(buffer+strlen(buffer), "demuxIFrame, ");
			if (actions->toDoActions & RM_PSM_DEMUX_NORMAL)
				sprintf(buffer+strlen(buffer), "demuxNormal, ");
			if (actions->toDoActions & RM_PSM_FLUSH_VIDEO)
				sprintf(buffer+strlen(buffer), "flushVideo, ");
			if (actions->toDoActions & RM_PSM_NORMAL_PLAY)
				sprintf(buffer+strlen(buffer), "normalPlay, ");

			if (actions->cmdProcessed)
				sprintf(buffer+strlen(buffer), "cmdProcessed, ");
			if (actions->asyncCmdPending)
				sprintf(buffer+strlen(buffer), "asyncCmdPending, ");

			if (!strlen(buffer))
				sprintf(buffer, "none, ");

			if (((!actions->cmdProcessed) && 
			     (actions->cmd != RM_NONE) &&
			     (actions->cmd != RM_UNKNOWN)) ||
			    (actions->asyncCmdPending))
				sprintf(buffer+strlen(buffer), "(app_specific_cmd), ");

			RMDBGLOG((ENABLE, "flags: %s cmd=%lu, asyncCmd=%lu\n", buffer, (RMuint32)actions->cmd, (RMuint32)actions->asyncCmd));
		
		}

#endif //DEBUG
	out_key_debug:
		/* the key is application specific (rm_unknown) */
		if (!keyProcessed)
			break;
	}

	/* verify decoder status */
	stopped = 0;
	for ( i = 0; i < PSMcontext->validPSMContexts; i++) {
		if ((dcc_info_array[i]->FSMstate == RM_PSM_Stopped) || 
		    (dcc_info_array[i]->FSMstate == RM_PSM_Paused) ||
		    (dcc_info_array[i]->FSMstate == RM_PSM_IPaused)) {
			RMDBGLOG((DISABLE, "decoder %ld is %s\n", 
				  i+1, 
				  dcc_info_array[i]->FSMstate == RM_PSM_Stopped ? "stopped":"paused"));
			stopped++;
		}
	}

	if ((stopped == PSMcontext->validPSMContexts) && (actions->cmd == RM_NONE)) {
		RMDBGLOG((ENABLE, ">>> awaiting command\n"));
		goto get_key;
	}

	return RM_OK;
}

RMbool handle_spi_keys(struct dcc_context *dcc_info, struct RM_PSM_Actions *actions, RMascii key)
{
	actions->cmdProcessed = TRUE;

	switch (key) {
	case KEY_CMD_CHANGE_CHANNEL:
		actions->cmd = KEY_CMD_CHANGE_CHANNEL;
		actions->cmdProcessed = FALSE;
		break;
	case KEY_CMD_PAT_INFO:
		actions->cmd = KEY_CMD_PAT_INFO;
		actions->cmdProcessed = FALSE;
		break;
	case KEY_CMD_CHANGE_PMT:
		actions->cmd = KEY_CMD_CHANGE_PMT;
		actions->cmdProcessed = FALSE;
		break;
	case KEY_CMD_SWITCH_SPI_FILE:
		actions->cmd = KEY_CMD_SWITCH_SPI_FILE;
		actions->cmdProcessed = FALSE;
		break;
	case KEY_CMD_CHANGE_AUDIO: 
		if (dcc_info->RM_PSM_commands & RM_PSM_ENABLE_SWITCHAUDIO) {
			RMuint32 streamNumber;
				
			if (actions->asyncCmdPending) {
				fprintf(stderr, "there's a previous async cmd(%lu) pending, ignoring\n", actions->asyncCmd);
				actions->cmdProcessed = FALSE;
				break;
			}
				
			fprintf(stderr, "audio stream change (select mode)\n");
				
			fprintf(stderr, "switch to audio stream: ");
			RMTermGetUint32(&streamNumber);
			dcc_info->selectAudioStream = (RMint32) streamNumber;
				
			actions->asyncCmd = RM_AUDIO_STREAM_CHANGE;
			actions->asyncCmdPending = TRUE;
				
			actions->cmdProcessed = FALSE;
			break;
		}
		fprintf(stderr, "switchAudio command not enabled!\n");
		actions->cmdProcessed = FALSE;
		break;
			
	case KEY_CMD_CHANGE_AUDIO_PID: 
		if (dcc_info->RM_PSM_commands & RM_PSM_ENABLE_SWITCHAUDIO) {
			actions->cmd = RM_AUDIO_STREAM_CHANGE;
			actions->cmdProcessed = FALSE;
			break;
		}

		fprintf(stderr, "switchAudio command not enabled!\n");
		actions->cmdProcessed = FALSE;
		break;
			
	case KEY_CMD_CYCLE_AUDIO:
		if (dcc_info->RM_PSM_commands & RM_PSM_ENABLE_SWITCHAUDIO) {
			if (actions->asyncCmdPending) {
				fprintf(stderr, "there's a previous async cmd(%lu) pending, ignoring\n", actions->asyncCmd);
				actions->cmdProcessed = FALSE;
				break;
			}
				
			fprintf(stderr, "audio stream change (cycle mode)\n");
			dcc_info->selectAudioStream = -1;
					
			actions->asyncCmd = RM_AUDIO_STREAM_CHANGE;
			actions->asyncCmdPending = TRUE;
				
			actions->cmdProcessed = FALSE;
			break;
		}
		fprintf(stderr, "switchAudio command not enabled!\n");
		actions->cmdProcessed = FALSE;
		break;
	case KEY_CMD_NERO_NEXT_CHAPTER:
		if (dcc_info->RM_PSM_commands & RM_PSM_ENABLE_CHAPTERS) {
			RMDBGLOG((ENABLE,"advance to next chapter\n"));
		
			actions->cmd = RM_NERO_NEXT_CHAPTER;
			actions->cmdProcessed = FALSE;
			break;
		}
		fprintf(stderr, "chapters not enabled!\n");
		actions->cmdProcessed = FALSE;
		break;
	case KEY_CMD_NERO_PREV_CHAPTER:
		if (dcc_info->RM_PSM_commands & RM_PSM_ENABLE_CHAPTERS) {
			RMDBGLOG((ENABLE,"go to prev chapter\n"));
			
			actions->cmd = RM_NERO_PREV_CHAPTER;
			actions->cmdProcessed = FALSE;
			break;
		}
		fprintf(stderr, "chapters not enabled!\n");
		actions->cmdProcessed = FALSE;
		break;
	case KEY_CMD_NERO_CYCLE_SUBTITLE:
		if (dcc_info->RM_PSM_commands & RM_PSM_ENABLE_SWITCHSUBTITLE) {
			RMDBGLOG((ENABLE,"switch subtitle\n"));
			
			actions->cmd = RM_NERO_SWITCH_SUBTITLE;
			actions->cmdProcessed = FALSE;
			break;
		}
		fprintf(stderr, "subtitles not enabled!\n");
		actions->cmdProcessed = FALSE;
		break;

	case KEY_CMD_CHANGE_VIDEO:
		if (dcc_info->RM_PSM_commands & RM_PSM_ENABLE_SWITCHVIDEO) {
			actions->cmd = KEY_CMD_CHANGE_VIDEO;
			actions->cmdProcessed = FALSE;
			break;
		}
		fprintf(stderr, "switchVideo command not enabled!\n");
		actions->cmdProcessed = FALSE;
		break;
	default:
		actions->cmdProcessed = FALSE;
		return FALSE;
	}

	return TRUE;

}


RMstatus handle_display_keys(struct dcc_context *dcc_info, struct RM_PSM_Actions *actions, RMascii key)
{
	RMstatus err;
	RMbool update_out_window = FALSE;

	actions->cmdProcessed = TRUE; //will be set to false if we dont process the key

	switch (key) {
	case KEY_CMD_CONTRAST_PLUS:
	case KEY_CMD_CONTRAST_MINUS:
		if ((key == KEY_CMD_CONTRAST_PLUS) && (dcc_info->disp_info->contrast < 240))
			dcc_info->disp_info->contrast += 16;
		else if ((key == KEY_CMD_CONTRAST_MINUS) && (dcc_info->disp_info->contrast > 15))
			dcc_info->disp_info->contrast -= 16;

		fprintf(stderr, "Now contrast is %hu\n", dcc_info->disp_info->contrast);
			
		while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_Contrast, &(dcc_info->disp_info->contrast), sizeof(dcc_info->disp_info->contrast), 0)) == RM_PENDING);
		if (RMFAILED(err)) RMDBGLOG((ENABLE, "Cannot set the contrast on the Digital output\n"));
		while ((err = RUASetProperty(dcc_info->pRUA, DispMainAnalogOut, RMGenericPropertyID_Contrast, &(dcc_info->disp_info->contrast), sizeof(dcc_info->disp_info->contrast), 0)) == RM_PENDING);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set the contrast %d\n", err));
			return err;
		}
		while ((err = RUASetProperty(dcc_info->pRUA, DispComponentOut, RMGenericPropertyID_Contrast, &(dcc_info->disp_info->contrast), sizeof(dcc_info->disp_info->contrast), 0)) == RM_PENDING);
		while ((err = RUASetProperty(dcc_info->pRUA, DispCompositeOut, RMGenericPropertyID_Contrast, &(dcc_info->disp_info->contrast), sizeof(dcc_info->disp_info->contrast), 0)) == RM_PENDING);
		//These will fail normally on EM862xL & SMP863x, no need to alarm people, deactivate error message. If you are using EM8605 or EM8610, put this sample error msg
		//if (RMFAILED(err)) RMDBGPRINT((ENABLE, "Cannot set the contrast on DispComponentOut %d; if you do NOT have EM8605 or EM8610, this is normal\n"));
			
		while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
		if (RMFAILED(err)) RMDBGLOG((ENABLE, "Cannot validate contrast on Digital output %d\n", err));
		while ((err = RUASetProperty(dcc_info->pRUA, DispMainAnalogOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot validate contrast on main analog out %d\n", err));
			return err;
		}
		while ((err = RUASetProperty(dcc_info->pRUA, DispComponentOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
		while ((err = RUASetProperty(dcc_info->pRUA, DispCompositeOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
		//These will fail normally on EM862xL & SMP863x, no need to alarm people, deactivate error message. If you are using EM8605 or EM8610, put the sample error msg
			
		break;
	case KEY_CMD_BRIGHTNESS_PLUS:
	case KEY_CMD_BRIGHTNESS_MINUS:
		if ((key == KEY_CMD_BRIGHTNESS_PLUS) && (dcc_info->disp_info->brightness < 120))
			dcc_info->disp_info->brightness += 8;
		else if ((key == KEY_CMD_BRIGHTNESS_MINUS) && (dcc_info->disp_info->brightness > -121))
			dcc_info->disp_info->brightness -= 8;

		fprintf(stderr, "Now brightness is %d\n", dcc_info->disp_info->brightness);
			
		while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_Brightness, &(dcc_info->disp_info->brightness), sizeof(dcc_info->disp_info->brightness), 0)) == RM_PENDING);
		if (RMFAILED(err)) RMDBGLOG((ENABLE, "Cannot set the brightness on the Digital output\n"));
		while ((err = RUASetProperty(dcc_info->pRUA, DispMainAnalogOut, RMGenericPropertyID_Brightness, &(dcc_info->disp_info->brightness), sizeof(dcc_info->disp_info->brightness), 0)) == RM_PENDING);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set the brightness %d\n", err));
			return err;
		}
		while ((err = RUASetProperty(dcc_info->pRUA, DispComponentOut, RMGenericPropertyID_Brightness, &(dcc_info->disp_info->brightness), sizeof(dcc_info->disp_info->brightness), 0)) == RM_PENDING);
		while ((err = RUASetProperty(dcc_info->pRUA, DispCompositeOut, RMGenericPropertyID_Brightness, &(dcc_info->disp_info->brightness), sizeof(dcc_info->disp_info->brightness), 0)) == RM_PENDING);
		//These will fail normally on EM862xL & SMP863x, no need to alarm people, deactivate error message. If you are using EM8605 or EM8610, put this sample error msg
		//if (RMFAILED(err)) RMDBGPRINT((ENABLE, "Cannot set the brightness on DispComponentOut %d; if you do NOT have EM8605 or EM8610, this is normal\n"));
			
		while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
		if (RMFAILED(err)) RMDBGLOG((ENABLE, "Cannot validate brightness on Digital output %d\n", err));
		while ((err = RUASetProperty(dcc_info->pRUA, DispMainAnalogOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot validate brightness on main analog out %d\n", err));
			return err;
		}
		while ((err = RUASetProperty(dcc_info->pRUA, DispComponentOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
		while ((err = RUASetProperty(dcc_info->pRUA, DispCompositeOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
		//These will fail normally on EM862xL & SMP863x, no need to alarm people, deactivate error message. If you are using EM8605 or EM8610, put the sample error msg
		break;
	case KEY_CMD_SATURATION_PLUS:
	case KEY_CMD_SATURATION_MINUS:
		if ((key == KEY_CMD_SATURATION_PLUS) && (dcc_info->disp_info->saturation < 240))
			dcc_info->disp_info->saturation += 16;
		else if ((key == KEY_CMD_SATURATION_MINUS) && (dcc_info->disp_info->saturation > 15))
			dcc_info->disp_info->saturation -= 16;

		fprintf(stderr, "Now saturation is %hu\n", dcc_info->disp_info->saturation);

		while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_CbSaturation, &(dcc_info->disp_info->saturation), sizeof(dcc_info->disp_info->saturation), 0)) == RM_PENDING);
		if (RMFAILED(err)) RMDBGLOG((ENABLE, "Cannot set the Cb saturation on the Digital output\n"));
		while ((err = RUASetProperty(dcc_info->pRUA, DispMainAnalogOut, RMGenericPropertyID_CbSaturation, &(dcc_info->disp_info->saturation), sizeof(dcc_info->disp_info->saturation), 0)) == RM_PENDING);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set the Cb saturation %d\n", err));
			return err;
		}
		while ((err = RUASetProperty(dcc_info->pRUA, DispComponentOut, RMGenericPropertyID_CbSaturation, &(dcc_info->disp_info->saturation), sizeof(dcc_info->disp_info->saturation), 0)) == RM_PENDING);
		while ((err = RUASetProperty(dcc_info->pRUA, DispCompositeOut, RMGenericPropertyID_CbSaturation, &(dcc_info->disp_info->saturation), sizeof(dcc_info->disp_info->saturation), 0)) == RM_PENDING);
		//These will fail normally on EM862xL & SMP863x, no need to alarm people, deactivate error message. If you are using EM8605 or EM8610, put this sample error msg
		//if (RMFAILED(err)) RMDBGPRINT((ENABLE, "Cannot set the Cb saturation on DispComponentOut %d; if you do NOT have EM8605 or EM8610, this is normal\n"));
	
		while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_CrSaturation, &(dcc_info->disp_info->saturation), sizeof(dcc_info->disp_info->saturation), 0)) == RM_PENDING);
		if (RMFAILED(err)) RMDBGLOG((ENABLE, "Cannot set the Cr saturation %d on the Digital output\n", err));
			
		while ((err = RUASetProperty(dcc_info->pRUA, DispMainAnalogOut, RMGenericPropertyID_CrSaturation, &(dcc_info->disp_info->saturation), sizeof(dcc_info->disp_info->saturation), 0)) == RM_PENDING);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set the Cr saturation %d\n", err));
			return err;
		}
		while ((err = RUASetProperty(dcc_info->pRUA, DispComponentOut, RMGenericPropertyID_CrSaturation, &(dcc_info->disp_info->saturation), sizeof(dcc_info->disp_info->saturation), 0)) == RM_PENDING);
		while ((err = RUASetProperty(dcc_info->pRUA, DispCompositeOut, RMGenericPropertyID_CrSaturation, &(dcc_info->disp_info->saturation), sizeof(dcc_info->disp_info->saturation), 0)) == RM_PENDING);
		//These will fail normally on EM862xL & SMP863x, no need to alarm people, deactivate error message. If you are using EM8605 or EM8610, put this sample error msg
		//if (RMFAILED(err)) RMDBGPRINT((ENABLE, "Cannot set the Cr saturation on DispComponentOut %d; if you do NOT have EM8605 or EM8610, this is normal\n"));
			
		while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
		if (RMFAILED(err)) RMDBGLOG((ENABLE, "Cannot validate saturation on the Digital output %d\n", err));
		while ((err = RUASetProperty(dcc_info->pRUA, DispMainAnalogOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot validate main analog out saturation %d\n", err));
			return err;
		}
		while ((err = RUASetProperty(dcc_info->pRUA, DispComponentOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
		while ((err = RUASetProperty(dcc_info->pRUA, DispCompositeOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
		//These will fail normally on EM862xL & SMP863x, no need to alarm people, deactivate error message. If you are using EM8605 or EM8610, put the example
		break;
	case KEY_CMD_HUE_PLUS:
	case KEY_CMD_HUE_MINUS:
		if ((key == KEY_CMD_HUE_PLUS) && (dcc_info->disp_info->hue < 61))
			dcc_info->disp_info->hue += 4;
		else if ((key == KEY_CMD_HUE_MINUS) && (dcc_info->disp_info->hue > -61))
			dcc_info->disp_info->hue -= 4;

		fprintf(stderr, "Now hue is %d\n", dcc_info->disp_info->hue);
			
		while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_Hue, &(dcc_info->disp_info->hue), sizeof(dcc_info->disp_info->hue), 0)) == RM_PENDING);
		if (RMFAILED(err)) RMDBGLOG((ENABLE, "Cannot set the hue on the Digital output\n"));
		while ((err = RUASetProperty(dcc_info->pRUA, DispMainAnalogOut, RMGenericPropertyID_Hue, &(dcc_info->disp_info->hue), sizeof(dcc_info->disp_info->hue), 0)) == RM_PENDING);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set the hue %d\n", err));
			return err;
		}
		while ((err = RUASetProperty(dcc_info->pRUA, DispComponentOut, RMGenericPropertyID_Hue, &(dcc_info->disp_info->hue), sizeof(dcc_info->disp_info->hue), 0)) == RM_PENDING);
		while ((err = RUASetProperty(dcc_info->pRUA, DispCompositeOut, RMGenericPropertyID_Hue, &(dcc_info->disp_info->hue), sizeof(dcc_info->disp_info->hue), 0)) == RM_PENDING);
		//These will fail normally on EM862xL & SMP863x, no need to alarm people, deactivate error message. If you are using EM8605 or EM8610, put this sample error msg
		//if (RMFAILED(err)) RMDBGPRINT((ENABLE, "Cannot set the hue on DispComponentOut %d; if you do NOT have EM8605 or EM8610, this is normal\n"));
			
		while ((err = RUASetProperty(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
		if (RMFAILED(err)) RMDBGLOG((ENABLE, "Cannot validate hue on Digital output %d\n", err));
		while ((err = RUASetProperty(dcc_info->pRUA, DispMainAnalogOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot validate hue on main analog out %d\n", err));
			return err;
		}
		while ((err = RUASetProperty(dcc_info->pRUA, DispComponentOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
		while ((err = RUASetProperty(dcc_info->pRUA, DispCompositeOut, RMGenericPropertyID_Validate, NULL, 0, 0)) == RM_PENDING);
		//These will fail normally on EM862xL & SMP863x, no need to alarm people, deactivate error message. If you are using EM8605 or EM8610, put the sample error msg
		break;
	case KEY_CMD_DEFAULT_OUTPUT:
		set_default_out_window(dcc_info->disp_info->active_window);
		update_out_window = TRUE;
		break;
	case KEY_CMD_HALF_OUTPUT:
		dcc_info->disp_info->active_window->X = 2048;
		dcc_info->disp_info->active_window->Y = 2048;
		dcc_info->disp_info->active_window->Width  = 2048;
		dcc_info->disp_info->active_window->Height = 2048;
		update_out_window = TRUE;
		break;
	case KEY_CMD_MINUS_OUTPUT_SIZE:
		if (dcc_info->disp_info->active_window->Width > 128) 
			dcc_info->disp_info->active_window->Width  -= 128;
		else
			dcc_info->disp_info->active_window->Width = 0;
			
		if (dcc_info->disp_info->active_window->Height > 128) 
			dcc_info->disp_info->active_window->Height  -= 128;
		else
			dcc_info->disp_info->active_window->Height = 0;
		update_out_window = TRUE;
		break;
	case KEY_CMD_PLUS_OUTPUT_SIZE:
		dcc_info->disp_info->active_window->Width  += 128;
		dcc_info->disp_info->active_window->Height += 128;
		update_out_window = TRUE;
		break;
	case KEY_CMD_TOP_OUTPUT:
		dcc_info->disp_info->active_window->Y -= 128;
		update_out_window = TRUE;
		break;
	case KEY_CMD_BOTTOM_OUTPUT:
		dcc_info->disp_info->active_window->Y += 128;
		update_out_window = TRUE;
		break;	
	case KEY_CMD_LEFT_OUTPUT:
		dcc_info->disp_info->active_window->X -= 128;
		update_out_window = TRUE;
		break;
	case KEY_CMD_RIGHT_OUTPUT:
		dcc_info->disp_info->active_window->X += 128;
		update_out_window = TRUE;
		break;
		
	case KEY_CMD_SWITCH_OUTPUT:
		if (dcc_info->disp_info->active_window == &(dcc_info->disp_info->out_window)) {
			if (dcc_info->pOSDSource[0] != NULL){
				dcc_info->disp_info->active_window = &(dcc_info->disp_info->osd_window[0]);
			}
		}
		else {
			if (dcc_info->pVideoSource != NULL){
				dcc_info->disp_info->active_window = &(dcc_info->disp_info->out_window);
			}
		}
			
		break;
			
	case KEY_CMD_ENABLE_OUTPUT:
		if (dcc_info->disp_info->active_window == &(dcc_info->disp_info->out_window)) 
			dcc_info->disp_info->video_enable = ! dcc_info->disp_info->video_enable;
		else
			dcc_info->disp_info->osd_enable[0] = ! dcc_info->disp_info->osd_enable[0];
		update_out_window = TRUE;
		break;
			
	case KEY_CMD_DUMP_OSD_INFO:
		if (dcc_info->pOSDSource[0] != NULL) {
			RMuint32 Y_addr, Y_size, UV_addr, UV_size;
			err = DCCGetOSDVideoSourceInfo(dcc_info->pOSDSource[0], &Y_addr, &Y_size, &UV_addr, &UV_size);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot get OSD information %d\n", err));
				return err;
			}
			fprintf(stderr,"OSD is 0x%08lx %lu 0x%08lx %lu\n", Y_addr, Y_size, UV_addr, UV_size);
				
			err = DCCClearOSDVideoSource(dcc_info->pOSDSource[0]);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot clear OSD %d\n", err));
				return err;
			}
		}
		break;
		
	case KEY_CMD_NONLINEAR_MINUS:
		if (dcc_info->disp_info->nonlinearmode.Width >= 3) dcc_info->disp_info->nonlinearmode.Width = 0;
		else dcc_info->disp_info->nonlinearmode.Width ++;
		if (dcc_info->disp_info->nonlinearmode.Width) dcc_info->disp_info->blackstrip.Vertical = 256;
		else dcc_info->disp_info->blackstrip.Vertical = 4096;
		fprintf(stderr, "Non-linear scaling width: %ld\n", dcc_info->disp_info->nonlinearmode.Width);
		update_out_window = TRUE;
		break;
	case KEY_CMD_NONLINEAR_PLUS:
		if (dcc_info->disp_info->nonlinearmode.Level >= 3) dcc_info->disp_info->nonlinearmode.Level = 0;
		else dcc_info->disp_info->nonlinearmode.Level ++;
		fprintf(stderr, "Non-linear scaling level: %ld\n", dcc_info->disp_info->nonlinearmode.Level);
		update_out_window = TRUE;
		break;
	case KEY_CMD_ROTATE_PICTURE:
		actions->cmd = RM_ROTATE_PICTURE;
		actions->cmdProcessed = FALSE;
		break;

		
	default:
		actions->cmdProcessed = FALSE;
		return RM_NOTIMPLEMENTED; // we didnt process the key because it was not implemented
	}

	if (update_out_window) {
		err = set_display_out_window(dcc_info);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error setting out window %d\n", err));
			return err;
		}
	}

	return RM_OK;


}


RMbool handle_audio_keys(struct dcc_context *dcc_info, struct RM_PSM_Actions *actions, RMascii key)
{
	RMstatus err;

	actions->cmdProcessed = TRUE; //will be set to false if we dont process the key

	switch (key) {
	case KEY_CMD_DUALMODE_AUDIO: {
		actions->cmd = RM_DUALMODE_CHANGE;
		actions->cmdProcessed = FALSE;
		break;
	}
	case KEY_CMD_VOLUME_PLUS:
	case KEY_CMD_VOLUME_MINUS:
		{
#if 0
			// Method to build the volume table. Volume = VOLUME_0DB * 2^(Gain/6), where Gain is expressed in dB.
#define CTN216_M	1122462048	// 2^(1/6) = 1.12246204830937298...
#define CTN216_N	1000000000
			VolumeTable[VOLUME_INDEX_0DB] = VOLUME_0DB;
			for ( dcc_info->volume = VOLUME_INDEX_0DB; dcc_info->volume >= 0; dcc_info->volume-- ) {
				VolumeTable[dcc_info->volume-1] = (((RMuint64)VolumeTable[dcc_info->volume] * CTN216_N + CTN216_M/2)/ CTN216_M);
			}
			for ( dcc_info->volume = VOLUME_INDEX_0DB; dcc_info->volume < sizeof(VolumeTable)/sizeof(RMuint32); dcc_info->volume_index++ ) {
				VolumeTable[dcc_info->volume_index+1] = (((RMuint64)VolumeTable[dcc_info->volume_index] * CTN216_M + CTN216_N/2)/ CTN216_N);
			}
			for ( dcc_info->volume_index = 0; dcc_info->volume_index < sizeof(VolumeTable)/sizeof(RMuint32); dcc_info->volume_index++ ) {
				fprintf(stdout, "0x%08lx, // %2lddB\n", VolumeTable[dcc_info->volume_index], dcc_info->volume_index-VOLUME_INDEX_0DB);
			};
#endif
			if ((key == KEY_CMD_VOLUME_PLUS) && (dcc_info->volume_index < 24))
				dcc_info->volume_index++;
			else if ((key == KEY_CMD_VOLUME_MINUS) && (dcc_info->volume_index > -VOLUME_INDEX_0DB))
				dcc_info->volume_index--;
				
			fprintf(stderr, "[1]Now volume is %ld dB = 0x%lx \n", dcc_info->volume_index, VolumeTable[VOLUME_INDEX_0DB+dcc_info->volume_index] );

			if (dcc_info->pAudioSource) {
				RMuint32 volume;

				err = DCCSetAudioSourceVolume(dcc_info->pAudioSource, VolumeTable[VOLUME_INDEX_0DB+dcc_info->volume_index]);
				
				err = DCCGetAudioSourceVolume(dcc_info->pAudioSource, &volume);
				if (err == RM_OK)
					RMDBGLOG((ENABLE, "volume for all channels is = 0x%lx \n", volume));
				else
					fprintf(stderr, "error getting volume\n");
			}
			else if (dcc_info->pMultipleAudioSource) {
				
				err = DCCSetMultipleAudioSourceVolume(dcc_info->pMultipleAudioSource, VolumeTable[VOLUME_INDEX_0DB+dcc_info->volume_index]);
				if (err != RM_OK)
					fprintf(stderr, "error setting multiple source volume\n");
			}

		}
		break;
	case KEY_CMD_VOLUME_MUTE:
		{
			dcc_info->mute = !dcc_info->mute;

			if (dcc_info->mute)
				muteAudio(dcc_info);
			else
				unMuteAudio(dcc_info);
			
		}
		break;
			
		case KEY_CMD_SPEED_UP:
		case KEY_CMD_SPEED_DOWN:
			{
				if (key == KEY_CMD_SPEED_UP) ppm++;
				else ppm--;
				if (dcc_info->pStcSource)
					DCCSTCSetSpeedCleanDiv(dcc_info->pStcSource, 1000000 + ppm, 1000000);
			}
			break;
		
	default:
		actions->cmdProcessed = FALSE;
		return FALSE; // we didnt processed the key
	}

	return TRUE; // we processed the key
}


RMstatus handle_playback_keys(struct dcc_context *dcc_info, struct RM_PSM_Actions *actions, RMascii key)
{
	RMstatus err;
	actions->cmdProcessed = TRUE; //will be set to false if we dont process the key

	switch (key) {
	case KEY_CMD_PAUSE:
		if (!(dcc_info->RM_PSM_commands & RM_PSM_ENABLE_PAUSE)) {
			actions->cmd = RM_PAUSE;
			actions->cmdProcessed = FALSE;
			break;
		}

		if (dcc_info->FSMstate == RM_PSM_Stopped) {
			fprintf(stderr, "Enter Play state first...\n");
			break;
		}

		actions->cmd = RM_NONE;

		if ((dcc_info->FSMstate == RM_PSM_Paused) || (dcc_info->FSMstate == RM_PSM_IPaused))
			break;

		fprintf(stderr, "Pausing...\n");

		if (dcc_info->pDemuxTask) {
			err = DCCPauseDemuxTask(dcc_info->pDemuxTask);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error pausing demuxtask source %d\n", err));
				return err;
			}
		}
		if (dcc_info->pVideoSource) {
			err = DCCPauseVideoSource(dcc_info->pVideoSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error pausing video source %d\n", err));
				return err;
			}
		}


		if (dcc_info->pAudioSource) {
			err = DCCPauseAudioSource(dcc_info->pAudioSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error pausing audio source %d\n", err));
				return err;
			}
		}
		else if (dcc_info->pMultipleAudioSource) {
			err = DCCPauseMultipleAudioSource(dcc_info->pMultipleAudioSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error pausing multiple audio source %d\n", err));
				return err;
			}	
		}


		if (dcc_info->pStcSource) {
			DCCSTCStop(dcc_info->pStcSource);
		}


		switch (dcc_info->FSMstate) {
		case RM_PSM_Prebuffering:
		case RM_PSM_Playing:
		case RM_PSM_Stopped:
		case RM_PSM_Paused:
		case RM_PSM_NextPic:
		case RM_PSM_IPaused:
		case RM_PSM_INextPic:
		case RM_PSM_Rewind:
			break;
		case RM_PSM_Slow:
		case RM_PSM_Fast:
			actions->toDoActions |= RM_PSM_RESYNC_TIMER;
			break;
		case RM_PSM_IForward:
		case RM_PSM_IRewind:
			actions->toDoActions |= RM_PSM_RESYNC_TIMER;
			break;
		}

		dcc_info->previousFSMState = dcc_info->FSMstate;
		actions->performedActions = RM_PSM_STC_STOPPED;
		actions->cmd = RM_PAUSED;

		if ((dcc_info->FSMstate != RM_PSM_IForward) && (dcc_info->FSMstate != RM_PSM_IRewind))
			dcc_info->FSMstate = RM_PSM_Paused;
		else
			dcc_info->FSMstate = RM_PSM_IPaused;

		break;
		
	case KEY_CMD_PLAY:
		if (!(dcc_info->RM_PSM_commands & RM_PSM_ENABLE_PLAY)) {
			actions->cmd = RM_PLAY;
			actions->cmdProcessed = FALSE;
			break;
		}
			
		actions->cmd = RM_NONE;

		if (dcc_info->FSMstate == RM_PSM_Playing) {
			break;
		}
		fprintf(stderr, "Running...\n");

		if (dcc_info->pVideoSource) {
			err = DCCPlayVideoSource(dcc_info->pVideoSource, DCCVideoPlayFwd);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error playing video source %d\n", err));
				return err;
			}
		}

		if (dcc_info->pAudioSource) {
#if 0
			if (dcc_info->RM_PSM_commands & RM_PSM_USE_MUTE_DURING_TRICKMODES) {
				unMuteAudio(dcc_info);
				routeAudioTimerToDisplayPTS(dcc_info, FALSE);
			}
#endif
			err = DCCPlayAudioSource(dcc_info->pAudioSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error playing audio source %d\n", err));
				return err;
			}
		}
		else if (dcc_info->pMultipleAudioSource) {
#if 0
			if (dcc_info->RM_PSM_commands & RM_PSM_USE_MUTE_DURING_TRICKMODES) {
				unMuteAudio(dcc_info);
				routeAudioTimerToDisplayPTS(dcc_info, FALSE);
			}
#endif

			err = DCCPlayMultipleAudioSource(dcc_info->pMultipleAudioSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error playing multiple audio source %d\n", err));
				return err;
			}
		}


		if (dcc_info->pDemuxTask) {
			err = DCCPlayDemuxTask(dcc_info->pDemuxTask);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error playing demuxtask source %d\n", err));
				return err;
			}
		}

		if (dcc_info->pStcSource) {
			DCCSTCSetSpeed(dcc_info->pStcSource, 1, 1);
			DCCSTCPlay(dcc_info->pStcSource);
		}

		actions->toDoActions = RM_PSM_RESYNC_TIMER;

		switch (dcc_info->FSMstate) {
		case RM_PSM_Prebuffering:
		case RM_PSM_Playing:
			break;
		case RM_PSM_Stopped:
			actions->toDoActions |= RM_PSM_FIRST_PTS;
			actions->toDoActions &= ~RM_PSM_RESYNC_TIMER;
			break;
		case RM_PSM_Paused:
			actions->toDoActions &= ~RM_PSM_RESYNC_TIMER;
			if ((dcc_info->previousFSMState == RM_PSM_IForward) || (dcc_info->previousFSMState == RM_PSM_IRewind)) {
				RMDBGLOG((ENABLE, "previous was IFrame\n"));
				actions->toDoActions |= RM_PSM_DEMUX_NORMAL;
			}
			break;
		case RM_PSM_Rewind:
			actions->toDoActions |= RM_PSM_FIRST_PTS;
			actions->toDoActions &= ~RM_PSM_RESYNC_TIMER;
			break;
		case RM_PSM_NextPic:
		case RM_PSM_Slow:
		case RM_PSM_Fast:
			actions->toDoActions |= RM_PSM_NORMAL_PLAY;
			break;
		case RM_PSM_IForward:
		case RM_PSM_IRewind:
			actions->toDoActions |= RM_PSM_DEMUX_NORMAL;
			break;
		case RM_PSM_IPaused:
		case RM_PSM_INextPic:
			actions->toDoActions |= RM_PSM_DEMUX_NORMAL;
			actions->toDoActions &= ~RM_PSM_RESYNC_TIMER;
			if ((dcc_info->previousFSMState == RM_PSM_IForward) || (dcc_info->previousFSMState == RM_PSM_IRewind)) {
				RMDBGLOG((ENABLE, "previous was IFrame\n"));
				actions->toDoActions |= RM_PSM_DEMUX_NORMAL;
			}
			break;
		}

		if ((dcc_info->FSMstate == RM_PSM_IRewind) || (dcc_info->previousFSMState == RM_PSM_IRewind)) {
			RMDBGLOG((ENABLE, "irewind to play transition, flushing fifos...\n"));
			actions->toDoActions |= RM_PSM_FLUSH_VIDEO;
		}

		dcc_info->previousFSMState = dcc_info->FSMstate;
		dcc_info->FSMstate =  RM_PSM_Playing;
			
		actions->cmd = RM_PLAY;

		break;
			
	case KEY_CMD_NEXT_PICTURE:
		if (!(dcc_info->RM_PSM_commands & RM_PSM_ENABLE_NEXTPIC)) {
			actions->cmd = RM_NEXTPIC;
			actions->cmdProcessed = FALSE;
			break;
		}

		actions->cmd = RM_NONE;

		if ((dcc_info->FSMstate != RM_PSM_Paused) && 
		    (dcc_info->FSMstate != RM_PSM_NextPic) &&
		    (dcc_info->FSMstate != RM_PSM_IPaused) &&
		    (dcc_info->FSMstate != RM_PSM_INextPic)) {
			fprintf(stderr, "Enter Pause state first...\n");
			break;
		}
#if 0
		if (((dcc_info->previousFSMState == RM_PSM_IForward) || (dcc_info->previousFSMState == RM_PSM_IRewind))
		    && (dcc_info->FSMstate == RM_PSM_Paused)) {
			fprintf(stderr, "not allowed now: previous mode was IFrame...\n");
			break;
		}
#endif
			
		fprintf(stderr, "Next Picture...\n");

		if (dcc_info->pVideoSource) {
			/* 
			   IMPORTANT NOTE: This call only affects the display, so the video decoder remains in the current
			   playback state, ie: playFwd, playIFrame, etc.
			*/
			err = DCCPlayVideoSource(dcc_info->pVideoSource, DCCVideoPlayNextFrame);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error playing (next frame) video source %d\n", err));
				return err;
			}
		}
		else
			fprintf(stderr, "no effect: it seems 'next' shouldn't have been enabled in this context\n");

		if ((dcc_info->FSMstate != RM_PSM_NextPic) &&
		    (dcc_info->FSMstate != RM_PSM_INextPic) ) {
			/* play demux, was paused by pause state */
			if (dcc_info->pDemuxTask) {
				err = DCCPlayDemuxTask(dcc_info->pDemuxTask);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Error playing demuxtask source %d\n", err));
					return err;
				}
			}


			/* stop audio, was paused by pause state */
			if (dcc_info->pAudioSource) {

				if (dcc_info->RM_PSM_commands & RM_PSM_USE_MUTE_DURING_TRICKMODES) {
					muteAudio(dcc_info);
					routeAudioTimerToDisplayPTS(dcc_info, TRUE);
				}
				else {
					err = DCCStopAudioSource(dcc_info->pAudioSource);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Error stopping audio source %d\n", err));
						return err;
					}
					actions->performedActions = RM_PSM_AUDIO_STOPPED;
				}
			}
			else if (dcc_info->pMultipleAudioSource) {
				if (dcc_info->RM_PSM_commands & RM_PSM_USE_MUTE_DURING_TRICKMODES) {
					muteAudio(dcc_info);
					routeAudioTimerToDisplayPTS(dcc_info, TRUE);
				}
				else {
					err = DCCStopMultipleAudioSource(dcc_info->pMultipleAudioSource);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Error stopping multiple audio source %d\n", err));
						return err;
					}
					actions->performedActions = RM_PSM_AUDIO_STOPPED;
				}
			}

		}

		//dcc_info->previousFSMState = dcc_info->FSMstate;
		if ((dcc_info->FSMstate == RM_PSM_IPaused) || (dcc_info->FSMstate == RM_PSM_INextPic))
			dcc_info->FSMstate = RM_PSM_INextPic;
		else
			dcc_info->FSMstate = RM_PSM_NextPic;

		//actions->toDoActions = RM_PSM_RESYNC_TIMER;
		actions->cmd = RM_NEXTPIC;
			
		break;
	case KEY_CMD_STOP:
		if (!(dcc_info->RM_PSM_commands & RM_PSM_ENABLE_STOP)) {
			actions->cmd = RM_STOP;
			actions->cmdProcessed = FALSE;
			break;
		}

		actions->cmd = RM_NONE;

		if (dcc_info->FSMstate == RM_PSM_Stopped)
			break;

		fprintf(stderr, "Stopping...\n");

		if (dcc_info->pDemuxTask) {
			err = DCCStopDemuxTask(dcc_info->pDemuxTask);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error stopping demuxtask source %d\n", err));
				return err;
			}
			actions->performedActions |= RM_PSM_DEMUX_STOPPED;
		}
		if (dcc_info->pVideoSource) {
			err = DCCStopVideoSource(dcc_info->pVideoSource, DCCStopMode_LastFrame);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error stopping video source %d\n", err));
				return err;
			}
			actions->performedActions |= RM_PSM_VIDEO_STOPPED;
		}


		if (dcc_info->pAudioSource) {
			err = DCCStopAudioSource(dcc_info->pAudioSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error stopping audio source %d\n", err));
				return err;
			}
			actions->performedActions |= RM_PSM_AUDIO_STOPPED;
		}
		else if (dcc_info->pMultipleAudioSource) {
			err = DCCStopMultipleAudioSource(dcc_info->pMultipleAudioSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error stopping multiple audio source %d\n", err));
				return err;
			}
			actions->performedActions = RM_PSM_AUDIO_STOPPED;
		}


		if (dcc_info->pStcSource) {
			DCCSTCStop(dcc_info->pStcSource);
			actions->performedActions |= RM_PSM_STC_STOPPED;
		}

		dcc_info->previousFSMState = dcc_info->FSMstate;
		dcc_info->FSMstate = RM_PSM_Stopped;
		actions->cmd = RM_STOP;
			
		break;
	case KEY_CMD_STOP_ZERO:
		fprintf(stderr, "Stopping and seeking to zero...\n");
		actions->cmd = RM_STOP_SEEK_ZERO;
		actions->cmdProcessed = FALSE;
		break;
	case KEY_CMD_SLOW_FWD:
		if (!(dcc_info->RM_PSM_commands & RM_PSM_ENABLE_SLOWER)) {
			actions->cmd = RM_SLOW_FWD;
			actions->cmdProcessed = FALSE;
			break;
		}
			
		actions->cmd = RM_NONE;

		if ((dcc_info->FSMstate == RM_PSM_Stopped) || 
		    (dcc_info->FSMstate == RM_PSM_Paused) ||
		    (dcc_info->FSMstate == RM_PSM_NextPic)) {
			fprintf(stderr, "Enter Play state first...\n");
			break;
		}

		if (((dcc_info->pVideoSource) || (dcc_info->pAudioSource) || (dcc_info->pMultipleAudioSource)) && (dcc_info->pStcSource)) {
			RMint32 N;
			RMuint32 M, positiveN;
				
			DCCSTCGetSpeed(dcc_info->pStcSource, &N, &M);
				
			if ((N == 0) || (M == 0)) {
				N = 1;
				M = 1;
			}
				
			positiveN = (N<0) ? (RMuint32) (-N) : (RMuint32) N;
				
			positiveN = 3*positiveN;
			M = 4*M;
			PGCD((RMint32 *)&positiveN, &M);
			if ((positiveN >= M) && (positiveN > MAX_SPEED)) {
				RMuint32 f = (positiveN + MAX_SPEED - 1) / MAX_SPEED;
				M = RMmax(1, M/f);
				positiveN = MAX_SPEED;
			}
			else if (M > MAX_SPEED) {
				RMuint32 f = (M + MAX_SPEED - 1) / MAX_SPEED;
				positiveN = RMmax(1, positiveN/f);
				M = MAX_SPEED;
			} 
				
			N = (N<0) ? (RMint32) -positiveN : (RMint32) positiveN;

			DCCSTCSetSpeed(dcc_info->pStcSource, N, M);
				
			fprintf(stderr, "Speed %ld/%ld...", N, M);

			dcc_info->previousFSMState = dcc_info->FSMstate;

			if ((dcc_info->FSMstate != RM_PSM_IForward) && (dcc_info->FSMstate != RM_PSM_IRewind) && (dcc_info->FSMstate != RM_PSM_Rewind)) {
				if (positiveN < M) {
					dcc_info->FSMstate = RM_PSM_Slow;
					fprintf(stderr, "slow forward\n");
				}
				else if (positiveN > M) {
					dcc_info->FSMstate = RM_PSM_Fast;
					fprintf(stderr, "fast forward\n");
				}
				else if (positiveN == M) {
					dcc_info->FSMstate = RM_PSM_Playing;
					fprintf(stderr, "normal play\n");
				}
			}
			else
				fprintf(stderr, "\n");
		}

		if (dcc_info->FSMstate != RM_PSM_Rewind)
			actions->toDoActions = RM_PSM_RESYNC_TIMER;

		actions->cmd = RM_SLOW_FWD;


		if (dcc_info->pAudioSource) {
			if (dcc_info->FSMstate == RM_PSM_Playing) {
		
				if (dcc_info->RM_PSM_commands & RM_PSM_USE_MUTE_DURING_TRICKMODES) {
					unMuteAudio(dcc_info);
					routeAudioTimerToDisplayPTS(dcc_info, FALSE);
				}
				else {
					err = DCCPlayAudioSource(dcc_info->pAudioSource);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Error playing audio source %d\n", err));
						return err;
					}
				}
			}

			else {

				if (dcc_info->RM_PSM_commands & RM_PSM_USE_MUTE_DURING_TRICKMODES) {
					muteAudio(dcc_info);
					routeAudioTimerToDisplayPTS(dcc_info, TRUE);
				}
				else {
					actions->performedActions = RM_PSM_AUDIO_STOPPED;
					
					err = DCCStopAudioSource(dcc_info->pAudioSource);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Error stopping audio source %d\n", err));
						return err;
					}
				}
			}
		}
		else if (dcc_info->pMultipleAudioSource) {
			if (dcc_info->FSMstate == RM_PSM_Playing) {
		
				if (dcc_info->RM_PSM_commands & RM_PSM_USE_MUTE_DURING_TRICKMODES) {
					unMuteAudio(dcc_info);
					routeAudioTimerToDisplayPTS(dcc_info, FALSE);
				}
				else {
					err = DCCPlayMultipleAudioSource(dcc_info->pMultipleAudioSource);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Error playing multiple audio source %d\n", err));
						return err;
					}
				}
			}

			else {

				if (dcc_info->RM_PSM_commands & RM_PSM_USE_MUTE_DURING_TRICKMODES) {
					muteAudio(dcc_info);
					routeAudioTimerToDisplayPTS(dcc_info, TRUE);
				}
				else {
					actions->performedActions = RM_PSM_AUDIO_STOPPED;
					
					err = DCCStopMultipleAudioSource(dcc_info->pMultipleAudioSource);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Error stopping multiple audio source %d\n", err));
						return err;
					}
				}
			}
		}


		break;
	case KEY_CMD_FAST_FWD:
		if (!(dcc_info->RM_PSM_commands & RM_PSM_ENABLE_FASTER)) {
			actions->cmd = RM_FAST_FWD;
			actions->cmdProcessed = FALSE;
			break;
		}
			
		actions->cmd = RM_NONE;

		if ((dcc_info->FSMstate == RM_PSM_Stopped) || 
		    (dcc_info->FSMstate == RM_PSM_Paused) ||
		    (dcc_info->FSMstate == RM_PSM_NextPic)) {
			fprintf(stderr, "Enter Play state first...\n");
			break;
		}

		if (((dcc_info->pVideoSource) || (dcc_info->pAudioSource) || (dcc_info->pMultipleAudioSource)) && (dcc_info->pStcSource)) {
			RMint32 N;
			RMuint32 M, positiveN;
				
			DCCSTCGetSpeed(dcc_info->pStcSource, &N, &M);
				
			if ((N == 0) || (M == 0)) {
				N = 1;
				M = 1;
			}
				
			positiveN = (N<0) ? (RMuint32) (-N) : (RMuint32) N;

				
			positiveN = 4*positiveN;
			M = 3*M;
			PGCD((RMint32 *)&positiveN, &M);
			if ((positiveN >= M) && (positiveN > MAX_SPEED)) {
				RMuint32 f = (positiveN + MAX_SPEED - 1) / MAX_SPEED;
				M = RMmax(1, M/f);
				positiveN = MAX_SPEED;
			}
			else if (M > MAX_SPEED) {
				RMuint32 f = (M + MAX_SPEED - 1) / MAX_SPEED;
				positiveN = RMmax(1, positiveN/f);
				M = MAX_SPEED;
			} 
				
			N = (N<0) ? (RMint32) -positiveN : (RMint32) positiveN;
				
			DCCSTCSetSpeed(dcc_info->pStcSource, N, M);
				
			fprintf(stderr, "Speed %ld/%ld...", N, M);

			dcc_info->previousFSMState = dcc_info->FSMstate;

			if ((dcc_info->FSMstate != RM_PSM_IForward) && (dcc_info->FSMstate != RM_PSM_IRewind) && (dcc_info->FSMstate != RM_PSM_Rewind)) {
				if (positiveN < M) {
					dcc_info->FSMstate = RM_PSM_Slow;
					fprintf(stderr, "slow forward\n");
				}
				else if (positiveN > M) {
					dcc_info->FSMstate = RM_PSM_Fast;
					fprintf(stderr, "fast forward\n");
				}
				else if (positiveN == M) {
					dcc_info->FSMstate = RM_PSM_Playing;
					fprintf(stderr, "normal play\n");
				}
			}
			else
				fprintf(stderr, "\n");
		}

		if (dcc_info->FSMstate != RM_PSM_Rewind)
			actions->toDoActions = RM_PSM_RESYNC_TIMER;

		actions->cmd = RM_FAST_FWD;

		if (dcc_info->pAudioSource) {
			if (dcc_info->FSMstate == RM_PSM_Playing) {
		
				if (dcc_info->RM_PSM_commands & RM_PSM_USE_MUTE_DURING_TRICKMODES) {
					unMuteAudio(dcc_info);
					routeAudioTimerToDisplayPTS(dcc_info, FALSE);
				}
				else {
					err = DCCPlayAudioSource(dcc_info->pAudioSource);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Error playing audio source %d\n", err));
						return err;
					}
				}
			}

			else {

				if (dcc_info->RM_PSM_commands & RM_PSM_USE_MUTE_DURING_TRICKMODES) {
					muteAudio(dcc_info);
					routeAudioTimerToDisplayPTS(dcc_info, TRUE);
				}
				else {
					actions->performedActions = RM_PSM_AUDIO_STOPPED;
					
					err = DCCStopAudioSource(dcc_info->pAudioSource);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Error stopping audio source %d\n", err));
						return err;
					}
				}
			}
		}
		else if (dcc_info->pMultipleAudioSource) {
			if (dcc_info->FSMstate == RM_PSM_Playing) {
		
				if (dcc_info->RM_PSM_commands & RM_PSM_USE_MUTE_DURING_TRICKMODES) {
					unMuteAudio(dcc_info);
					routeAudioTimerToDisplayPTS(dcc_info, FALSE);
				}
				else {
					err = DCCPlayMultipleAudioSource(dcc_info->pMultipleAudioSource);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Error playing multiple audio source %d\n", err));
						return err;
					}
				}
			}

			else {

				if (dcc_info->RM_PSM_commands & RM_PSM_USE_MUTE_DURING_TRICKMODES) {
					muteAudio(dcc_info);
					routeAudioTimerToDisplayPTS(dcc_info, TRUE);
				}
				else {
					actions->performedActions = RM_PSM_AUDIO_STOPPED;
					
					err = DCCStopMultipleAudioSource(dcc_info->pMultipleAudioSource);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Error stopping multiple audio source %d\n", err));
						return err;
					}
				}
			}
		}


		break;
	case KEY_CMD_SPEED_FACTOR:
		if (!(dcc_info->RM_PSM_commands & RM_PSM_ENABLE_SPEED)) {
			fprintf(stderr, "speed command not enabled!\n");
			actions->cmd = RM_SPEED;
			actions->cmdProcessed = FALSE;
			break;
		}
			
		actions->cmd = RM_NONE;

		if ((dcc_info->FSMstate == RM_PSM_Stopped) || 
		    (dcc_info->FSMstate == RM_PSM_Paused) ||
		    (dcc_info->FSMstate == RM_PSM_NextPic)) {
			fprintf(stderr, "Enter Play state first...\n");
			break;
		}


		if (((dcc_info->pVideoSource) || (dcc_info->pAudioSource) || (dcc_info->pMultipleAudioSource)) && (dcc_info->pStcSource)) {
			RMint32 N, speed;
			RMuint32 M, positiveN;
			RMint32 direction;

			fprintf(stderr, "Speed factor [1/256] : ");
			RMTermGetUint32((RMuint32 *) &speed);

			direction = (speed > 0) ? 1 : -1;
			speed *= direction;
			if (speed >= 256) {
				M = 1;
				N = (speed * direction) / 256;
			}
			else {
				N = direction;
				M = 256 / speed;
			}

			positiveN = (N<0) ? (RMuint32) (-N) : (RMuint32) N;
				
			DCCSTCSetSpeed(dcc_info->pStcSource, N, M);

			fprintf(stderr, "Speed %ld/%ld...", N, M);

			dcc_info->previousFSMState = dcc_info->FSMstate;

			if ((dcc_info->FSMstate != RM_PSM_IForward) && (dcc_info->FSMstate != RM_PSM_IRewind) && (dcc_info->FSMstate != RM_PSM_Rewind)) {
				if (positiveN < M) {
					dcc_info->FSMstate = RM_PSM_Slow;
					fprintf(stderr, "slow forward\n");
				}
				else if (positiveN > M) {
					dcc_info->FSMstate = RM_PSM_Fast;
					fprintf(stderr, "fast forward\n");
				}
				else if (positiveN == M) {
					dcc_info->FSMstate = RM_PSM_Playing;
					fprintf(stderr, "normal play\n");
				}
			}
			else
				fprintf(stderr, "\n");
		}

		if (dcc_info->FSMstate != RM_PSM_Rewind)
			actions->toDoActions = RM_PSM_RESYNC_TIMER;

		actions->cmd = RM_SPEED;

		if (dcc_info->pAudioSource) {
			if (dcc_info->FSMstate == RM_PSM_Playing) {
		
				if (dcc_info->RM_PSM_commands & RM_PSM_USE_MUTE_DURING_TRICKMODES) {
					unMuteAudio(dcc_info);
					routeAudioTimerToDisplayPTS(dcc_info, FALSE);
				}
				else {
					err = DCCPlayAudioSource(dcc_info->pAudioSource);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Error playing audio source %d\n", err));
						return err;
					}
				}
			}

			else {

				if (dcc_info->RM_PSM_commands & RM_PSM_USE_MUTE_DURING_TRICKMODES) {
					muteAudio(dcc_info);
					routeAudioTimerToDisplayPTS(dcc_info, TRUE);
				}
				else {
					actions->performedActions = RM_PSM_AUDIO_STOPPED;
					
					err = DCCStopAudioSource(dcc_info->pAudioSource);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Error stopping audio source %d\n", err));
						return err;
					}
				}
			}
		}
		else if (dcc_info->pMultipleAudioSource) {
			if (dcc_info->FSMstate == RM_PSM_Playing) {
		
				if (dcc_info->RM_PSM_commands & RM_PSM_USE_MUTE_DURING_TRICKMODES) {
					unMuteAudio(dcc_info);
					routeAudioTimerToDisplayPTS(dcc_info, FALSE);
				}
				else {
					err = DCCPlayMultipleAudioSource(dcc_info->pMultipleAudioSource);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Error playing multiple audio source %d\n", err));
						return err;
					}
				}
			}

			else {

				if (dcc_info->RM_PSM_commands & RM_PSM_USE_MUTE_DURING_TRICKMODES) {
					muteAudio(dcc_info);
					routeAudioTimerToDisplayPTS(dcc_info, TRUE);
				}
				else {
					actions->performedActions = RM_PSM_AUDIO_STOPPED;
					
					err = DCCStopMultipleAudioSource(dcc_info->pMultipleAudioSource);
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Error stopping multiple audio source %d\n", err));
						return err;
					}
				}
			}
		}


		break;
	case KEY_CMD_REWIND: // silent rewind. The STC goes backwards but there's no output
		if (!(dcc_info->RM_PSM_commands & RM_PSM_ENABLE_REWIND)) {
			fprintf(stderr, "rewind command not enabled!\n");
			actions->cmd = RM_REWIND;
			actions->cmdProcessed = FALSE;
			break;
		}
			
		actions->cmd = RM_NONE;

		if ((dcc_info->FSMstate == RM_PSM_Stopped) || 
		    (dcc_info->FSMstate == RM_PSM_Paused) ||
		    (dcc_info->FSMstate == RM_PSM_NextPic)) {
			fprintf(stderr, "Enter Play state first...\n");
			break;
		}

		if (dcc_info->FSMstate == RM_PSM_Rewind)
			break;

		fprintf(stderr, "Rewind. Use + to set the speed...\n");

		if (dcc_info->pVideoSource) {
			err = DCCStopVideoSource(dcc_info->pVideoSource, DCCStopMode_LastFrame);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error stopping video source %d\n", err));
				return err;
			}
			actions->performedActions |= RM_PSM_VIDEO_STOPPED;
		}

		if (dcc_info->pAudioSource) {
			err = DCCStopAudioSource(dcc_info->pAudioSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error stopping audio source %d\n", err));
				return err;
			}
			actions->performedActions |= RM_PSM_AUDIO_STOPPED;
		}
		else if (dcc_info->pMultipleAudioSource) {
			err = DCCStopMultipleAudioSource(dcc_info->pMultipleAudioSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error stopping multiple audio source %d\n", err));
				return err;
			}
			actions->performedActions |= RM_PSM_AUDIO_STOPPED;
		}


		if (dcc_info->pStcSource) {
			RMint32 N;
			RMuint32 M;
				
			//DCCSTCStop(dcc_info->pStcSource);

			DCCSTCGetSpeed(dcc_info->pStcSource, &N, &M);

			if ((N == 0) || (M == 0)) {
				N = 1;
				M = 1;
			}
				
			if (N > 0)
				N *= -1;

			DCCSTCSetSpeed(dcc_info->pStcSource, N, M);
		}

		dcc_info->previousFSMState = dcc_info->FSMstate;
		dcc_info->FSMstate = RM_PSM_Rewind;
		actions->toDoActions = 0;
		actions->cmd = RM_REWIND;

		break;

	case KEY_CMD_IFRAME_FWD:
		if (!(dcc_info->RM_PSM_commands & RM_PSM_ENABLE_IFWD)) {
			fprintf(stderr, "ifwd command not enabled!\n");
			actions->cmd = RM_IFWD;
			actions->cmdProcessed = FALSE;
			break;
		}
			
		actions->cmd = RM_NONE;

		if ((dcc_info->FSMstate == RM_PSM_Stopped) || 
		    (dcc_info->FSMstate == RM_PSM_Paused) ||
		    (dcc_info->FSMstate == RM_PSM_NextPic)) {
			fprintf(stderr, "Enter Play state first...\n");
			break;
		}

		if (dcc_info->FSMstate == RM_PSM_IForward)
			break;

		fprintf(stderr, "Forward I-Frame mode. Use + to set the speed...\n");


		if (dcc_info->pAudioSource) {
			err = DCCStopAudioSource(dcc_info->pAudioSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error stopping audio source %d\n", err));
				return err;
			}
		}
		else if (dcc_info->pMultipleAudioSource) {
			err = DCCStopMultipleAudioSource(dcc_info->pMultipleAudioSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error stopping multiple audio source %d\n", err));
				return err;
			}
		}

		if (dcc_info->pStcSource) {
			RMint32 N;
			RMuint32 M;
				
			DCCSTCGetSpeed(dcc_info->pStcSource, &N, &M);

			if ((N == 0) || (M == 0)) {
				N = 1;
				M = 1;
			}
				
			if (N < 0)
				N *= -1;

			DCCSTCSetSpeed(dcc_info->pStcSource, N, M);
		}

		if (dcc_info->FSMstate == RM_PSM_IRewind) {
			RMDBGLOG((ENABLE, "irewind to iforward transition, flushing fifos...\n"));
			actions->toDoActions = RM_PSM_FLUSH_VIDEO;
		}

		dcc_info->previousFSMState = dcc_info->FSMstate;
		dcc_info->FSMstate = RM_PSM_IForward;
		actions->performedActions = RM_PSM_AUDIO_STOPPED;
		actions->toDoActions |= (RM_PSM_DEMUX_IFRAME | RM_PSM_RESYNC_TIMER);
		actions->cmd = RM_IFWD;

		break;
	case KEY_CMD_IFRAME_BWD:
		if (!(dcc_info->RM_PSM_commands & RM_PSM_ENABLE_IRWD)) {
			fprintf(stderr, "irwd command not enabled!\n");
			actions->cmd = RM_IRWD;
			actions->cmdProcessed = FALSE;
			break;
		}
			
		actions->cmd = RM_NONE;

		if ((dcc_info->FSMstate == RM_PSM_Stopped) || 
		    (dcc_info->FSMstate == RM_PSM_Paused) ||
		    (dcc_info->FSMstate == RM_PSM_NextPic)) {
			fprintf(stderr, "Enter Play state first...\n");
			break;
		}

		if (dcc_info->FSMstate == RM_PSM_IRewind)
			break;

		fprintf(stderr, "Backward I-Frame mode. Use + to set the speed...\n");

		if (dcc_info->pAudioSource) {
			err = DCCStopAudioSource(dcc_info->pAudioSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error stopping audio source %d\n", err));
				return err;
			}
		}
		else if (dcc_info->pMultipleAudioSource) {
			err = DCCStopMultipleAudioSource(dcc_info->pMultipleAudioSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error stopping multiple audio source %d\n", err));
				return err;
			}
		}


		if (dcc_info->pStcSource) {
			RMint32 N;
			RMuint32 M;
				
			DCCSTCStop(dcc_info->pStcSource);

			DCCSTCGetSpeed(dcc_info->pStcSource, &N, &M);

			if ((N == 0) || (M == 0)) {
				N = 1;
				M = 1;
			}
				
			if (N > 0)
				N *= -1;

			DCCSTCSetSpeed(dcc_info->pStcSource, N, M);
		}

		dcc_info->previousFSMState = dcc_info->FSMstate;
		dcc_info->FSMstate = RM_PSM_IRewind;
		actions->performedActions = RM_PSM_AUDIO_STOPPED | RM_PSM_STC_STOPPED;
		actions->toDoActions = (RM_PSM_DEMUX_IFRAME | RM_PSM_FLUSH_VIDEO | RM_PSM_RESYNC_TIMER);
		actions->cmd = RM_IRWD;

		break;

	case KEY_CMD_QUIT:
		if (manutest != TRUE)
			fprintf(stderr, "Quitting...\n");
		actions->cmd = RM_QUIT;
		actions->cmdProcessed = FALSE;
		break;

	case KEY_CMD_MANU_YES:
		if (manutest == TRUE) {
			actions->cmd = RM_MANU_QUIT_OK;
			actions->cmdProcessed = FALSE;
			break;
		}
	
	case KEY_CMD_SEEK:
		if (dcc_info->RM_PSM_commands & RM_PSM_ENABLE_SEEK) {
			fprintf(stderr, "Seeking ...\n");
			fprintf(stderr, "Enter seek time (s) : ");
				
			RMTermGetUint32(&(dcc_info->seek_time));
				
			actions->cmd = RM_SEEK;
			actions->cmdProcessed = FALSE;
			fprintf(stderr, "seeking to: %lu\n", dcc_info->seek_time);
			break;
		}
		fprintf(stderr, "seek command not enabled!\n");
		actions->cmdProcessed = FALSE;
		break;

#ifdef WITH_TIME_SHIFT
	case KEY_CMD_TIME_SHIFT: 
		{// time shift mode toggles based on boolean variable timeshift_mode
			static RMbool timeshift_mode = FALSE;
			if (dcc_info->FSMstate == RM_PSM_Playing) {
				if( timeshift_mode == FALSE ) {
					fprintf(stderr, "Time Shift Mode on...\n");
					timeshift_mode = TRUE;
					if( alt_filename[0] != '\0' )
						SwtichToSoftwareDemux();
				}
				else {
					fprintf(stderr, "Time Shift Mode off...\n");
					timeshift_mode = FALSE;
					actions->cmd = RM_QUIT;
					actions->cmdProcessed = FALSE;
				}
			}
			else {
				fprintf( stderr, "System not playing\n" );
				;
			}
			break;
		}	
#endif
	case KEY_CMD_DISABLE_STC:
		{
			struct DisplayBlock_SurfaceSTC_type param;

			if (dcc_info->video_decoder == 0)
				break;

			err = RUAGetProperty(dcc_info->pRUA, dcc_info->video_decoder, RMGenericPropertyID_Surface, &(param.surface), sizeof(param.surface));
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot get video surface %d\n", err));
				return RM_ERROR;
			}
			
			if (dcc_info->disable_stc) {
				err = DCCSTCGetModuleId(dcc_info->pStcSource, &(param.STCModuleId));
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Cannot get STC module ID\n"));
					return err;
				}
				dcc_info->disable_stc = FALSE;
			}
			else {
				param.STCModuleId = 0;
				dcc_info->disable_stc = TRUE;
			}

			err = RUASetProperty(dcc_info->pRUA, DisplayBlock, RMDisplayBlockPropertyID_SurfaceSTC, &param, sizeof(param), 0);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot set STC ModuleID %lu to surface 0x%08lx\n", param.STCModuleId, param.surface));
				return err;
			}
		}
		break;

	default:
		actions->cmdProcessed = FALSE;
		return RM_NOTIMPLEMENTED; // we didnt process the key because it was not implemented
	}

	
	return RM_OK; // we processed the key

}





RMstatus WaitForRuaEvents(struct dcc_context *dcc_info,
	struct RUAEvent** ppEventsIn,
	RMuint32* pnEvents,
	RMuint32 timeout)
{
#define EM8XXX_EVENTCOUNT_MAX 32 // keep in sync with emhwlib_kernel/include/em8xxx_uk.h
	RMstatus err = RM_OK;
	RMuint32 index, i;
	struct RUAEvent Events[EM8XXX_EVENTCOUNT_MAX];

	if(*pnEvents > EM8XXX_EVENTCOUNT_MAX)
		return RM_ERROR;
	
	RMMemcpy(Events, *ppEventsIn, *pnEvents * sizeof(struct RUAEvent));

	while (*pnEvents) {
		RMbool valid_event;

 		if (verbose_stderr != 0) {
			fprintf(stderr, "   wait %lx events ", *pnEvents );
			for(i=0;i<(*pnEvents);i++)
//				RMDBGPRINT((ENABLE, "[0x%lx=%s%ld \t= 0x%08lx] ", Events[i].ModuleID, EMhwlibModuleName[EMHWLIB_MODULE_CATEGORY(Events[i].ModuleID)], EMHWLIB_MODULE_INDEX(Events[i].ModuleID), Events[i].Mask));
				fprintf(stderr, "[0x%lx = 0x%08lx] ", Events[i].ModuleID, Events[i].Mask);
			fprintf(stderr, "\n" );
		}

		valid_event = FALSE;
		err = RUAWaitForMultipleEvents(dcc_info->pRUA, Events, *pnEvents, timeout, &index);
		if ( err != RM_OK) {
			// basically timeout
			goto over;
		}
		if( index >= *pnEvents) {
			RMDBGLOG((ENABLE, "RUAWaitForMultipleEvents ERROR - ??????\n"));
			err = RM_ERROR;
			goto over;
		}
 		if (verbose_stderr != 0) 
			fprintf(stderr, "   get 0x%lx = 0x%08lx\n", Events[index].ModuleID, Events[index].Mask);
		if (Events[index].Mask & RUAEVENT_INBAND_COMMAND) {
			struct InbandCommandX_type ibcx;
			while (1) { /* the EOS inband was set with INBAND_COMMAND_CONSUMED_BY_USER */
				err = RUAGetProperty(dcc_info->pRUA, Events[index].ModuleID, RMGenericPropertyID_InbandCommandX, &ibcx, sizeof(ibcx));
				if ( err != RM_OK) {
	 				if (verbose_stderr != 0) 
						fprintf(stderr, "inband_event 0x%lx without tag - hwlib already process it\n", Events[index].ModuleID);
					break;
				}
				else if ((ibcx.flags_tag & 0xff) == INBAND_COMMAND_TAG_EOS) {
					valid_event = TRUE;
					if (manutest != TRUE)
						fprintf(stderr, "WaitForEOS 0x%lx OK\n", Events[index].ModuleID);
				}
				else {
					if (manutest != TRUE)
						fprintf(stderr, "inband_event 0x%lx with tag=%lx\n", Events[index].ModuleID, ibcx.flags_tag);
				}
			}
		}
		else if (Events[index].ModuleID == EMHWLIB_MODULE(DisplayBlock, 0)) {
			struct InbandCommandX_type ibcx;
			while (1) { /* the EOS inband was set with INBAND_COMMAND_CONSUMED_BY_USER */
				err = RUAGetProperty(dcc_info->pRUA, dcc_info->video_decoder, RMVideoDecoderPropertyID_DisplayInbandCommandX, &ibcx, sizeof(ibcx));
				if ( err != RM_OK) {
	 				if (verbose_stderr != 0) 
						fprintf(stderr, "inband_event display without tag - hwlib already process it\n");
					break;
				}
				else if ((ibcx.flags_tag & 0xff) == INBAND_COMMAND_TAG_EOS) {
					valid_event = TRUE;
					if (manutest != TRUE)
						fprintf(stderr, "WaitForEOS display OK \n");
				}
				else {
					if (manutest != TRUE)
						fprintf(stderr, "display_inband_event with tag=%lx\n", ibcx.flags_tag);
				}
			}
		}

		if (valid_event)
			(*ppEventsIn)[index].Mask &= ~Events[index].Mask;

		if ((*ppEventsIn)[index].Mask == 0) {
			RMMemcpy(Events+index, Events+index+1, sizeof(struct RUAEvent) * (*pnEvents - index - 1));
			RMMemcpy((*ppEventsIn)+index, (*ppEventsIn)+index+1, sizeof(struct RUAEvent) * (*pnEvents - index - 1));
			*pnEvents = (*pnEvents) - 1;
		}
		else 
			Events[index].Mask = (*ppEventsIn)[index].Mask;
	}
over:
	return err;
}


#define MAX_SAME_PTS_COUNT_ALLOWED 2000              //we're sampling the pts at 1/TIMEOUT_10MS, so 2000 = 20sec

RMstatus CommonWaitForEOS(struct dcc_context *dcc_info, RMuint32 *pcmd, RMuint32 eos_bit_field, RMuint32 key_flags)
{
	RMstatus err;
	struct InbandCommand_type InbandCmd;
	static struct RUAEvent e[4];
	struct RUAEvent* pEvents = e; 
	RMuint32 nEvents = 0, i;
	RMuint32 last_audio_pts = 0;
	RMuint64 t0 = get_ustime();
	RMuint32 SameLastAudioPTScount = 0;
	RMint32 N = 0;
	RMuint32 M = 0;
	RMuint32 scale = 1;
	RMuint32 trickTimeOutAfter = 0;


	if (dcc_info->state == RM_PLAYING_TRICKMODE) {
		trickTimeOutAfter = MAX_SAME_PTS_COUNT_ALLOWED;
		DCCSTCGetSpeed(dcc_info->pStcSource, &N, &M);
		if (N > 0)
			scale = (RMuint32)N / M;
		else
			scale = (RMuint32)(-1 * N) / M;
		
		if (scale != 0)
			trickTimeOutAfter = (MAX_SAME_PTS_COUNT_ALLOWED / scale);
		if (trickTimeOutAfter <= 2)
			trickTimeOutAfter = MAX_SAME_PTS_COUNT_ALLOWED;
		RMDBGLOG((ENABLE, "speed %ld/%lu = %lu, samePTS timeout set to %lu\n", N, M, scale, trickTimeOutAfter));
	}

	/* in case we use the hardware demux */
	InbandCmd.Tag = EMhwlibInbandCommand_EOS | INBAND_COMMAND_CONSUMED_BY_USER | INBAND_COMMAND_TYPE_BYTECOUNT | INBAND_COMMAND_NO_COORDINATE;
	InbandCmd.Coordinate = 0;

	if (eos_bit_field & EOS_BIT_FIELD_VIDEO) {
		e[nEvents].ModuleID = EMHWLIB_MODULE(DisplayBlock, 0);
		e[nEvents].Mask = EMHWLIB_DISPLAY_INBAND_COMMAND_EVENT_ID(dcc_info->SurfaceID);

		RMDBGLOG((ENABLE, "Display [0x%lx = 0x%08lx]\n", e[nEvents].ModuleID, e[nEvents].Mask));

		RUAResetEvent(dcc_info->pRUA, &e[nEvents]);
		RUASetProperty(dcc_info->pRUA, e[nEvents].ModuleID, RMGenericPropertyID_EnableEvent, &e[nEvents].Mask, sizeof(e[nEvents].Mask), 0);
		nEvents++;
		
		e[nEvents].ModuleID = dcc_info->video_decoder;
		e[nEvents].Mask = RUAEVENT_INBAND_COMMAND;
		RUAResetEvent(dcc_info->pRUA, &e[nEvents]);
		if ((eos_bit_field & EOS_BIT_FIELD_DEMUX) == 0) {
			RMDBGLOG((ENABLE, "End Of Sequence\n"));

			InbandCmd.Tag = INBAND_COMMAND_TAG_END_SEQUENCE | INBAND_COMMAND_TYPE_BYTECOUNT | INBAND_COMMAND_NO_COORDINATE | INBAND_COMMAND_ACTION_CONTINUE;
			RUASetProperty(dcc_info->pRUA, dcc_info->video_decoder, RMGenericPropertyID_InbandCommand, &InbandCmd, sizeof(InbandCmd), 0);

			//			InbandCmd.Tag = EMhwlibInbandCommand_EOS | INBAND_COMMAND_CONSUMED_BY_USER | INBAND_COMMAND_TYPE_BYTECOUNT | INBAND_COMMAND_NO_COORDINATE | INBAND_COMMAND_ACTION_CONTINUE;
			//			RUASetProperty(dcc_info->pRUA, dcc_info->video_decoder, RMGenericPropertyID_InbandCommand, &InbandCmd, sizeof(InbandCmd), 0);			
		}
		else
			InbandCmd.Tag |= INBAND_COMMAND_DEST_VIDEO;
		
		nEvents++;
	}

	if (eos_bit_field & EOS_BIT_FIELD_AUDIO) {
		e[nEvents].ModuleID = dcc_info->audio_decoder;
		e[nEvents].Mask = RUAEVENT_INBAND_COMMAND;

		RMDBGLOG((ENABLE, "Audio [0x%lx = 0x%08lx]\n", e[nEvents].ModuleID, e[nEvents].Mask));

		RUAResetEvent(dcc_info->pRUA, &e[nEvents]);
		if ((eos_bit_field & EOS_BIT_FIELD_DEMUX) == 0) {
			// INBAND_COMMAND_ACTION_STOP required by audio ucode in order to propagate the inband to audio output
			InbandCmd.Tag = EMhwlibInbandCommand_EOS | INBAND_COMMAND_CONSUMED_BY_USER | INBAND_COMMAND_TYPE_BYTECOUNT | INBAND_COMMAND_NO_COORDINATE | INBAND_COMMAND_ACTION_STOP;
			RUASetProperty(dcc_info->pRUA, dcc_info->audio_decoder, RMGenericPropertyID_InbandCommand, &InbandCmd, sizeof(InbandCmd), 0);
		}
		else
			// INBAND_COMMAND_ACTION_STOP required by audio ucode in order to propagate the inband to audio output
			InbandCmd.Tag |= INBAND_COMMAND_DEST_AUDIO | INBAND_COMMAND_ACTION_STOP;
		
		DCCSetAudioBtsThreshold(dcc_info->pAudioSource, 0);

		nEvents++;
	}

	if (eos_bit_field & EOS_BIT_FIELD_DEMUX) {
		e[nEvents].ModuleID = dcc_info->demux;
		e[nEvents].Mask = RUAEVENT_INBAND_COMMAND;

		RMDBGLOG((ENABLE, "Demux [0x%lx = 0x%08lx]\n", e[nEvents].ModuleID, e[nEvents].Mask));

		RUAResetEvent(dcc_info->pRUA, &e[nEvents]);
		RUASetProperty(dcc_info->pRUA, dcc_info->demux, RMGenericPropertyID_InbandCommand, &InbandCmd, sizeof(InbandCmd), 0);
		nEvents++;
	}
	
	if (nEvents == 0)
		return RM_OK;
	
	while(1) {
		if (WaitForRuaEvents(dcc_info, &pEvents, &nEvents, TIMEOUT_1SEC) == RM_OK) {
 			if (verbose_stderr != 0) 
				fprintf(stderr, " EOS_InbandCmd after %lld us\n", get_ustime() - t0);
			return RM_OK;
		}
		else {
			for (i=0 ; i<nEvents ; i++) {
				if ((eos_bit_field & EOS_BIT_FIELD_AUDIO) && (pEvents[i].ModuleID == dcc_info->audio_decoder)) {
					RMuint32 tmp;
					err = RUAGetProperty(dcc_info->pRUA, dcc_info->audio_decoder, 
							     RMAudioDecoderPropertyID_CurrentPTS, 
							     &tmp, sizeof(tmp));
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Cannot get current audio PTS %d\n", err));
						return err;
					}
					
					if (tmp == last_audio_pts)
						SameLastAudioPTScount++;
					else {
						last_audio_pts = tmp;
						SameLastAudioPTScount = 0;
					}

					if (dcc_info->state == RM_PLAYING_TRICKMODE) {
						if (SameLastAudioPTScount > trickTimeOutAfter) {
							fprintf(stderr, " EOS_InbandCmd audio TIMEOUT (last PTS %lu), count %lu\n", last_audio_pts, SameLastAudioPTScount);
							return RM_OK;
						}
					}
					else if (SameLastAudioPTScount) {
						eos_bit_field &= ~EOS_BIT_FIELD_AUDIO;
						fprintf(stderr, " EOS_InbandCmd audio TIMEOUT (last PTS %lu)\n", last_audio_pts);
					}

				}

				if ((eos_bit_field & EOS_BIT_FIELD_VIDEO) && (pEvents[i].ModuleID == EMHWLIB_MODULE(DisplayBlock, 0))) {
					RMuint64 decoded_pts, displayed_pts;
					err = RUAGetProperty(dcc_info->pRUA, dcc_info->video_decoder, 
							     RMVideoDecoderPropertyID_LastDecodedPTS, 
							     &decoded_pts, sizeof(decoded_pts));
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Cannot get last decoded PTS %d\n", err));
						return err;
					}
					err = RUAGetProperty(dcc_info->pRUA, dcc_info->SurfaceID, 
							     RMGenericPropertyID_CurrentDisplayPTS, 
							     &displayed_pts, sizeof(displayed_pts));
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Cannot get current display PTS %d\n", err));
						return err;
					}
					
					if (decoded_pts == displayed_pts) {
						eos_bit_field &= ~EOS_BIT_FIELD_VIDEO;
						if (manutest != TRUE) 
							fprintf(stderr, " EOS_InbandCmd last video frame displayed (last PTS %llu)\n", decoded_pts);
					}
				}
			}
			if ( (eos_bit_field & (EOS_BIT_FIELD_VIDEO | EOS_BIT_FIELD_AUDIO )) == 0 ) {
				if (manutest != TRUE) 
					fprintf(stderr, " EOS_InbandCmd TIMEOUT after %lld us\n", get_ustime() - t0);
				return RM_OK;
			}
		}
		
		err = process_key(dcc_info, pcmd, key_flags);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error while processing key %d\n", err));
			*pcmd = RM_QUIT;
			return RM_KEY_WHILE_WAITING_EOS;
		}
		if ( (*pcmd == RM_QUIT) || (*pcmd == RM_STOP) || (*pcmd == RM_STOP_SEEK_ZERO) || (*pcmd == RM_PLAY) || (*pcmd == RM_SEEK))
			return RM_KEY_WHILE_WAITING_EOS;
		if ( (manutest == TRUE) && (*pcmd == RM_MANU_QUIT_OK) )
			return RM_KEY_WHILE_WAITING_EOS;
	}

	return RM_OK;
}
	

#define USE_TIMEOUT 0


RMstatus WaitForEOSWithCommand(struct RM_PSM_Context *PSMcontext, struct dcc_context *dcc_info_array[], struct RM_PSM_Actions *pActions, RMuint32 eos_bit_field)
{
	RMstatus err;
	struct InbandCommand_type InbandCmd;
	static struct RUAEvent e[4];
	struct RUAEvent *pEvents = e;
	RMuint32 nEvents = 0, i;
	RMuint64 t0 = get_ustime();
	RMint32 N = 0, N1;
	RMuint32 M = 0;
	RMuint32 scale = 1;
	RMuint32 trickTimeOutAfter = 0;
	struct dcc_context *dcc_info;

	RMuint32 audio_instances = 1;

#if USE_TIMEOUT
	RMuint32 last_audio_pts = 0;
	RMuint32 SameLastAudioPTScount = 0;
#endif

	if ((PSMcontext->currentActivePSMContext <= PSMcontext->validPSMContexts) &&
	    (PSMcontext->currentActivePSMContext != 0)) {
		dcc_info = dcc_info_array[PSMcontext->currentActivePSMContext - 1];
	}
	else {
		RMDBGLOG((ENABLE, "process_command is using defaut context\n"));
		dcc_info = dcc_info_array[0];
	}


	if(dcc_info->pMultipleAudioSource){
		DCCMultipleAudioSourceGetNumberOfInstances(dcc_info->pMultipleAudioSource, &audio_instances);
	}

	trickTimeOutAfter = MAX_SAME_PTS_COUNT_ALLOWED;
	DCCSTCGetSpeed(dcc_info->pStcSource, &N, &M);
	
	N1 = N;
	if (N < 0)
		N *= -1;

	if ((RMuint32)N > M) {
		scale = (RMuint32)N / M;
	}
	else if ((RMuint32)N < M) {
		scale = (RMuint32)M / N;
	}

	trickTimeOutAfter *= M;
	trickTimeOutAfter /= (RMuint32)N;


	if (trickTimeOutAfter <= 2)
		trickTimeOutAfter = MAX_SAME_PTS_COUNT_ALLOWED;

	RMDBGLOG((ENABLE, "speed %ld/%lu = %lu, samePTS timeout set to %lu\n", N1, M, scale, trickTimeOutAfter));

	RMDBGLOG((ENABLE, "EOS flags 0x%lx, video 0x%lx audio 0x%lx demux 0x%lx\n", 
		  eos_bit_field, 
		  EOS_BIT_FIELD_VIDEO,
		  EOS_BIT_FIELD_AUDIO,
		  EOS_BIT_FIELD_DEMUX));

	if (eos_bit_field & EOS_BIT_FIELD_VIDEO)
		RMDBGLOG((ENABLE, "wait for video EOS\n"));
	if (eos_bit_field & EOS_BIT_FIELD_AUDIO)
		RMDBGLOG((ENABLE, "wait for audio EOS\n"));
	if (eos_bit_field & EOS_BIT_FIELD_DEMUX)
		RMDBGLOG((ENABLE, "wait for demux EOS\n"));		

	/* in case we use the hardware demux */
	InbandCmd.Tag = EMhwlibInbandCommand_EOS | INBAND_COMMAND_CONSUMED_BY_USER | INBAND_COMMAND_TYPE_BYTECOUNT | INBAND_COMMAND_NO_COORDINATE;
	InbandCmd.Coordinate = 0;

	if (eos_bit_field & EOS_BIT_FIELD_VIDEO) {
		e[nEvents].ModuleID = EMHWLIB_MODULE(DisplayBlock, 0);
		e[nEvents].Mask = EMHWLIB_DISPLAY_INBAND_COMMAND_EVENT_ID(dcc_info->SurfaceID);

		RMDBGLOG((ENABLE, "Display [0x%lx = 0x%08lx]\n", e[nEvents].ModuleID, e[nEvents].Mask));

		RUAResetEvent(dcc_info->pRUA, &e[nEvents]);
		RUASetProperty(dcc_info->pRUA, e[nEvents].ModuleID, RMGenericPropertyID_EnableEvent, &e[nEvents].Mask, sizeof(e[nEvents].Mask), 0);
		nEvents++;
		
		e[nEvents].ModuleID = dcc_info->video_decoder;
		e[nEvents].Mask = RUAEVENT_INBAND_COMMAND;
		RUAResetEvent(dcc_info->pRUA, &e[nEvents]);
		if ((eos_bit_field & EOS_BIT_FIELD_DEMUX) == 0) {
			
#if 1
			/* send an end of sequence to the video to flush all pictures to the display */
			InbandCmd.Tag = INBAND_COMMAND_TAG_END_SEQUENCE | INBAND_COMMAND_TYPE_BYTECOUNT | INBAND_COMMAND_NO_COORDINATE | INBAND_COMMAND_ACTION_CONTINUE;
			RMDBGLOG((ENABLE, "send inband cmd 0x%lx to video decoder\n", InbandCmd.Tag));
			RUASetProperty(dcc_info->pRUA, dcc_info->video_decoder, RMGenericPropertyID_InbandCommand, &InbandCmd, sizeof(InbandCmd), 0);
#endif
			InbandCmd.Tag = EMhwlibInbandCommand_EOS | INBAND_COMMAND_CONSUMED_BY_USER | INBAND_COMMAND_TYPE_BYTECOUNT | INBAND_COMMAND_NO_COORDINATE | INBAND_COMMAND_ACTION_CONTINUE;
			RMDBGLOG((ENABLE, "send inband cmd 0x%lx to video decoder\n", InbandCmd.Tag));
			RUASetProperty(dcc_info->pRUA, dcc_info->video_decoder, RMGenericPropertyID_InbandCommand, &InbandCmd, sizeof(InbandCmd), 0);
		}
		else
			InbandCmd.Tag |= INBAND_COMMAND_DEST_VIDEO;
		
		nEvents++;
	}

	if (eos_bit_field & EOS_BIT_FIELD_AUDIO) {

		if (dcc_info->pAudioSource) {
			e[nEvents].ModuleID = dcc_info->audio_decoder;
			e[nEvents].Mask = RUAEVENT_INBAND_COMMAND;
			
			RMDBGLOG((ENABLE, "Audio [0x%lx = 0x%08lx]\n", e[nEvents].ModuleID, e[nEvents].Mask));
			
			RUAResetEvent(dcc_info->pRUA, &e[nEvents]);
			if ((eos_bit_field & EOS_BIT_FIELD_DEMUX) == 0) {
				// INBAND_COMMAND_ACTION_STOP required by audio ucode in order to propagate the inband to audio output
				
				InbandCmd.Tag = EMhwlibInbandCommand_EOS | INBAND_COMMAND_CONSUMED_BY_USER | INBAND_COMMAND_TYPE_BYTECOUNT | INBAND_COMMAND_NO_COORDINATE | INBAND_COMMAND_ACTION_STOP;
				RMDBGLOG((ENABLE, "send inband cmd 0x%lx to audio decoder\n", InbandCmd.Tag));

				RUASetProperty(dcc_info->pRUA, dcc_info->audio_decoder, RMGenericPropertyID_InbandCommand, &InbandCmd, sizeof(InbandCmd), 0);
			}
			else
				// INBAND_COMMAND_ACTION_STOP required by audio ucode in order to propagate the inband to audio output
				InbandCmd.Tag |= INBAND_COMMAND_DEST_AUDIO | INBAND_COMMAND_ACTION_STOP;
			
		
			DCCSetAudioBtsThreshold(dcc_info->pAudioSource, 0);

			nEvents++;
		}
		else if (dcc_info->pMultipleAudioSource) {
			struct DCCAudioSourceHandle audioHandle;

			for (i = 0; i < audio_instances; i++) {

				err = DCCMultipleAudioSourceGetSingleDecoderHandleForInstance(dcc_info->pMultipleAudioSource, i, &audioHandle);
				if (err != RM_OK)
					return err;


				e[nEvents].ModuleID = audioHandle.moduleID;
				e[nEvents].Mask = RUAEVENT_INBAND_COMMAND;
				
				RMDBGLOG((ENABLE, "Audio Instance %lu [0x%lx = 0x%08lx]\n", i, e[nEvents].ModuleID, e[nEvents].Mask));
				
				RUAResetEvent(dcc_info->pRUA, &e[nEvents]);
				if ((eos_bit_field & EOS_BIT_FIELD_DEMUX) == 0) {
					// INBAND_COMMAND_ACTION_STOP required by audio ucode in order to propagate the inband to audio output
					

					InbandCmd.Tag = EMhwlibInbandCommand_EOS | INBAND_COMMAND_CONSUMED_BY_USER | INBAND_COMMAND_TYPE_BYTECOUNT | INBAND_COMMAND_NO_COORDINATE | INBAND_COMMAND_ACTION_STOP;
					RMDBGLOG((ENABLE, "send inband cmd 0x%lx to audio decoder 0x%lx\n", InbandCmd.Tag, audioHandle.moduleID));

					RUASetProperty(dcc_info->pRUA, audioHandle.moduleID, RMGenericPropertyID_InbandCommand, &InbandCmd, sizeof(InbandCmd), 0);
				}
				else
					// INBAND_COMMAND_ACTION_STOP required by audio ucode in order to propagate the inband to audio output
					InbandCmd.Tag |= INBAND_COMMAND_DEST_AUDIO | INBAND_COMMAND_ACTION_STOP;

				nEvents++;
			}


			DCCSetMultipleAudioBtsThreshold(dcc_info->pMultipleAudioSource, 0);
		}

		
	}

	if (eos_bit_field & EOS_BIT_FIELD_DEMUX) {
		struct InbandCommand_type EndSequenceCmd;
		
		e[nEvents].ModuleID = dcc_info->demux;
		e[nEvents].Mask = RUAEVENT_INBAND_COMMAND;

		RMDBGLOG((ENABLE, "Demux [0x%lx = 0x%08lx]\n", e[nEvents].ModuleID, e[nEvents].Mask));

		/* send an end of sequence to the video to flush all pictures to the display */
		EndSequenceCmd.Tag = INBAND_COMMAND_TAG_END_SEQUENCE | INBAND_COMMAND_TYPE_BYTECOUNT | INBAND_COMMAND_NO_COORDINATE | INBAND_COMMAND_ACTION_CONTINUE;
		EndSequenceCmd.Tag |= INBAND_COMMAND_DEST_VIDEO;
		EndSequenceCmd.Coordinate = 0;
		RMDBGLOG((ENABLE, "send inband cmd 0x%lx to demux\n", EndSequenceCmd.Tag));
		RUASetProperty(dcc_info->pRUA, dcc_info->demux, RMGenericPropertyID_InbandCommand, &EndSequenceCmd, sizeof(EndSequenceCmd), 0);

		RUAResetEvent(dcc_info->pRUA, &e[nEvents]);
		RMDBGLOG((ENABLE, "send inband cmd 0x%lx to demux\n", InbandCmd.Tag));
		RUASetProperty(dcc_info->pRUA, dcc_info->demux, RMGenericPropertyID_InbandCommand, &InbandCmd, sizeof(InbandCmd), 0);
		nEvents++;
	}
	
	if (nEvents == 0)
		return RM_OK;

	for (i=0 ; i<nEvents ; i++)
		RMDBGLOG((ENABLE, "event %lu is [0x%lx = 0x%08lx]\n", i, e[i].ModuleID, e[i].Mask));

	
	while(1) {
		if (WaitForRuaEvents(dcc_info, &pEvents, &nEvents, TIMEOUT_100MS) == RM_OK) {
 			if (verbose_stderr != 0) 
				fprintf(stderr, " EOS_InbandCmd after %lld us\n", get_ustime() - t0);
			return RM_OK;
		}
		else {
#if USE_TIMEOUT
			for (i=0 ; i<nEvents ; i++) {
				if ((eos_bit_field & EOS_BIT_FIELD_AUDIO) && (pEvents[i].ModuleID == dcc_info->audio_decoder)) {
					RMuint32 tmp;
					err = RUAGetProperty(dcc_info->pRUA, dcc_info->audio_decoder, 
							     RMAudioDecoderPropertyID_CurrentPTS, 
							     &tmp, sizeof(tmp));
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Cannot get current audio PTS %d\n", err));
						return err;
					}
					
					if (tmp == last_audio_pts)
						SameLastAudioPTScount++;
					else {
						last_audio_pts = tmp;
						SameLastAudioPTScount = 0;
					}

					if (SameLastAudioPTScount > trickTimeOutAfter) {
						fprintf(stderr, " EOS_InbandCmd audio TIMEOUT (last PTS %lu), count %lu\n", last_audio_pts, SameLastAudioPTScount);
						return RM_OK;
					}
				}

				if ((eos_bit_field & EOS_BIT_FIELD_VIDEO) && (pEvents[i].ModuleID == EMHWLIB_MODULE(DisplayBlock, 0))) {
					RMuint64 decoded_pts, displayed_pts;
					err = RUAGetProperty(dcc_info->pRUA, dcc_info->video_decoder, 
							     RMVideoDecoderPropertyID_LastDecodedPTS, 
							     &decoded_pts, sizeof(decoded_pts));
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Cannot get last decoded PTS %d\n", err));
						return err;
					}
					err = RUAGetProperty(dcc_info->pRUA, dcc_info->SurfaceID, 
							     RMGenericPropertyID_CurrentDisplayPTS, 
							     &displayed_pts, sizeof(displayed_pts));
					if (RMFAILED(err)) {
						RMDBGLOG((ENABLE, "Cannot get current display PTS %d\n", err));
						return err;
					}
					
					if (decoded_pts == displayed_pts) {
						eos_bit_field &= ~EOS_BIT_FIELD_VIDEO;
						if (manutest != TRUE) 
							fprintf(stderr, " EOS_InbandCmd last video frame displayed (last PTS %llu)\n", decoded_pts);
					}
				}
			}
#endif

#if 0
			if ( (eos_bit_field & (EOS_BIT_FIELD_VIDEO | EOS_BIT_FIELD_AUDIO )) == 0 ) {
				if (manutest != TRUE) 
					fprintf(stderr, " EOS_InbandCmd TIMEOUT after %lld us\n", get_ustime() - t0);
				return RM_OK;
			}
#endif
		}
		err = process_command(PSMcontext, dcc_info_array, pActions);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error while processing key %d\n", err));
			pActions->cmd = RM_QUIT;
			pActions->cmdProcessed = FALSE;
			return RM_KEY_WHILE_WAITING_EOS;
		}

		if (((pActions->cmd != RM_NONE) && (pActions->cmd != RM_UNKNOWN)) || (pActions->cmdProcessed))
			return RM_KEY_WHILE_WAITING_EOS;

		RMDBGLOG((DISABLE, "EOS flags 0x%lx, video 0x%lx audio 0x%lx demux 0x%lx\n", 
			  eos_bit_field, 
			  EOS_BIT_FIELD_VIDEO,
			  EOS_BIT_FIELD_AUDIO,
			  EOS_BIT_FIELD_DEMUX));

		if ( (eos_bit_field & (EOS_BIT_FIELD_VIDEO | EOS_BIT_FIELD_AUDIO )) == 0 ) {
			if (manutest != TRUE) 
				fprintf(stderr, " EOS_InbandCmd TIMEOUT after %lld us\n", get_ustime() - t0);
			return RM_OK;
		}

	}

	return RM_OK;
}
	

/* send a hilight button */
void send_hilight_button(struct dcc_context *dcc_info) {
	struct SpuDecoder_Hilight_type		spuHilight;
	RMstatus							err = RM_OK;

	RMDBGLOG((ENABLE, "send_hilight_button()\n"));
	memset(&spuHilight, 0, sizeof(struct SpuDecoder_Hilight_type));

	spuHilight.leftb	= 10;
	spuHilight.topb		= 10;
	spuHilight.rightb	= 100;
	spuHilight.bottomb	= 100;
	spuHilight.color	= 0x8888;
	spuHilight.contrast = 0xff00;
	spuHilight.on		= TRUE;
	spuHilight.pts		= 0x2a00000;

	err = RUASetProperty(dcc_info->pRUA, dcc_info->spu_decoder, RMSpuDecoderPropertyID_Hilight, &spuHilight, sizeof(spuHilight), 0);

	return;
}


