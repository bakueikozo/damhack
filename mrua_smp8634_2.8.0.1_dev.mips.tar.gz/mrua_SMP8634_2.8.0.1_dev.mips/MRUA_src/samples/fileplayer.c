#define ALLOW_OS_CODE 1


#include "../samples/common.h"

#include "../rmdef/rmdef.h"
#include "../rmlibcw/include/rmfile.h"
#include "../samples/rminputstream.h"
#include "../rmproperties/include/rmexternalproperties.h"
#include "../rmdetectorapi/include/rmdetectorapi.h"

#include "../rmvdemux/include/rmvdemuxapi.h"

#include "../rmasfdemux/include/rmasfdemuxapi.h"

#include "../rmavicore/include/rmavipushapi.h"

#if 1
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

/* #### Begin CARDEA code #### */
#include "rmupnp/rmlibwmdrmnd/include/ms_cardea.h"
/* #### End CARDEA code #### */



#define ERROR_CLEANUP(i)	do { error = (i); goto cleanup; }  while(0)

#define VIDEO_KEYFLAGS         (SET_KEY_PLAYBACK)
#define AUDIO_KEYFLAGS         (SET_KEY_PLAYBACK | SET_KEY_AUDIO)
#define AUDIO_VIDEO_KEYFLAGS   (SET_KEY_PLAYBACK | SET_KEY_AUDIO)



struct detection_callback_info{
	RMdetectorHandle detector;
	RMuint32 parsedBytes;
	RMuint64 last_pts;
	RMuint64 first_pts;
	RMbool audio_detected;
	RMbool pcm_detected;
	eAudioFormat_type audio_type;
	RMuint32 audio_channels;
	RMuint32 audio_freq;
	RMuint32 audio_depth;
	RMuint32 audio_bitrate;
};

#define AUDIO_DETECTION_THRESHOLD (64 * 1024)


// jpeg header parsing reads: 
// SOF to get the width and height and determine color subsample scheme based on the sample factors
// EXIF APP1 to get the orientation of the jpeg picture as in enum PictureOrientation
#define EXIFDBG DISABLE
#define JPEGDBG DISABLE
#define EXIF_MAX_IFD0_SIZE 16*12+2 /*ifd0 contains a max of 16 entries*/

enum exifAlign{
	intel_align = 0,
	motorola_align
};
static inline RMuint32 readExif32(RMuint8* buf, enum exifAlign align)
{
	if(align == motorola_align)
		return RMbeBufToUint32(buf);
	return RMleBufToUint32(buf);
}
static inline RMuint32 readExif16(RMuint8* buf, enum exifAlign align)
{
	if(align == motorola_align)
		return RMbeBufToUint16(buf);
	return RMleBufToUint16(buf);
}

#define JPEG_MAX_MARKER_SIZE 0x10000
#define JPEG_MAX_COLOR_COMP 4
typedef enum {			// JPEG markers
	JPEG_MARKER_SOF0  = 0xc0,
	JPEG_MARKER_SOF1  = 0xc1,
	JPEG_MARKER_SOF2  = 0xc2,
	JPEG_MARKER_SOF3  = 0xc3,

	JPEG_MARKER_SOF5  = 0xc5,
	JPEG_MARKER_SOF6  = 0xc6,
	JPEG_MARKER_SOF7  = 0xc7,

	JPEG_MARKER_JPG   = 0xc8,
	JPEG_MARKER_SOF9  = 0xc9,
	JPEG_MARKER_SOF10 = 0xca,
	JPEG_MARKER_SOF11 = 0xcb,

	JPEG_MARKER_SOF13 = 0xcd,
	JPEG_MARKER_SOF14 = 0xce,
	JPEG_MARKER_SOF15 = 0xcf,

	JPEG_MARKER_DHT   = 0xc4,

	JPEG_MARKER_DAC   = 0xcc,

	JPEG_MARKER_RST0  = 0xd0,
	JPEG_MARKER_RST1  = 0xd1,
	JPEG_MARKER_RST2  = 0xd2,
	JPEG_MARKER_RST3  = 0xd3,
	JPEG_MARKER_RST4  = 0xd4,
	JPEG_MARKER_RST5  = 0xd5,
	JPEG_MARKER_RST6  = 0xd6,
	JPEG_MARKER_RST7  = 0xd7,

	JPEG_MARKER_SOI   = 0xd8,
	JPEG_MARKER_EOI   = 0xd9,
	JPEG_MARKER_SOS   = 0xda,
	JPEG_MARKER_DQT   = 0xdb,
	JPEG_MARKER_DNL   = 0xdc,
	JPEG_MARKER_DRI   = 0xdd,
	JPEG_MARKER_DHP   = 0xde,
	JPEG_MARKER_EXP   = 0xdf,

	JPEG_MARKER_APP0  = 0xe0,
	JPEG_MARKER_APP1  = 0xe1,
	JPEG_MARKER_APP2  = 0xe2,
	JPEG_MARKER_APP3  = 0xe3,
	JPEG_MARKER_APP4  = 0xe4,
	JPEG_MARKER_APP5  = 0xe5,
	JPEG_MARKER_APP6  = 0xe6,
	JPEG_MARKER_APP7  = 0xe7,
	JPEG_MARKER_APP8  = 0xe8,
	JPEG_MARKER_APP9  = 0xe9,
	JPEG_MARKER_APP10 = 0xea,
	JPEG_MARKER_APP11 = 0xeb,
	JPEG_MARKER_APP12 = 0xec,
	JPEG_MARKER_APP13 = 0xed,
	JPEG_MARKER_APP14 = 0xee,
	JPEG_MARKER_APP15 = 0xef,

	JPEG_MARKER_JPG0  = 0xf0,
	JPEG_MARKER_JPG13 = 0xfd,
	JPEG_MARKER_COM   = 0xfe,

	JPEG_MARKER_TEM   = 0x01,

	JPEG_MARKER_ERROR = 0x100
} JPEG_MARKER;


static RMstatus jpeg_header_skip_marker( RMfile file, RMuint32 * byte_count ) 
{
	RMuint8 buf[2];
	RMuint32 read;
	RMuint32 length;
	RMstatus err;
	err = RMReadFile(file, buf, 2, &read); // get the length
	if(RMFAILED(err) || (read!=2)) {
		RMDBGLOG((JPEGDBG, "jpeg_header_skip_marker Error reading file\n"));
		return RM_ERROR;
	}
	length = ((RMuint32)buf[0]<<8) + buf[1];
	RMDBGLOG((JPEGDBG, "jpeg_header_skip_marker length %d (0x%x 0x%x)\n", length, buf[0], buf[1] ));
	if( length <2 ) {
		RMDBGLOG((JPEGDBG, "jpeg_header_skip_marker bad length\n"));
		return RM_ERROR;
	}
	*byte_count += length;
	length -= 2;
	while( length != 0 ) {
		if( length < JPEG_MAX_MARKER_SIZE ) {
			err = RMSeekFile(file, length, RM_FILE_SEEK_CURRENT);
			length = 0;
		}
		else {
			err = RMSeekFile(file, JPEG_MAX_MARKER_SIZE, RM_FILE_SEEK_CURRENT); 
			length -= JPEG_MAX_MARKER_SIZE;
		}
		if(RMFAILED(err)) {
			RMDBGLOG((JPEGDBG, "jpeg_header_skip_marker Error reading file size=%d\n", length));
			return RM_ERROR;
		}
	}
	return RM_OK;
}


// process SOF marker
static RMstatus jpeg_header_get_sof( RMfile file, RMuint32 * width, RMuint32 * height, RMuint32 *profile, RMuint32 * byte_count ) 
{
	RMuint8 buf[JPEG_MAX_MARKER_SIZE];
	RMuint8* p;
	RMuint32 read = 0;
	RMuint32 length;
	RMstatus err;
	RMuint32 precision;
	RMuint32 components;
	RMuint32 i;
	RMuint32 component_id[JPEG_MAX_COLOR_COMP];
	RMuint32 h_samp_factor[JPEG_MAX_COLOR_COMP];
	RMuint32 v_samp_factor[JPEG_MAX_COLOR_COMP];
	RMuint32 quant_table[JPEG_MAX_COLOR_COMP];
	
	err = RMReadFile(file, buf, 2, &read); // get the length
	if(RMFAILED(err) || (read!= 2)) {
		RMDBGLOG((JPEGDBG, "jpeg_header_get_sof Error reading file\n"));
		return RM_ERROR;
	}
	length = ((RMuint32)buf[0]<<8) + buf[1];
	RMDBGLOG((JPEGDBG, "jpeg_header_get_sof sof length %d (0x%x 0x%x)\n", length, buf[0], buf[1]));
	if( length <2 ) {
		RMDBGLOG((JPEGDBG, "jpeg_header_get_sof bad length\n"));
		return RM_ERROR;
	}
	*byte_count += length;
	length -= 2;

	err = RMReadFile(file, buf, length, &read); // get marker data
	if(RMFAILED(err) || (read!= length)) {
		RMDBGLOG((JPEGDBG, "jpeg_header_get_sof Error reading file size=%d\n", length));
		RMSeekFile( file, *byte_count, RM_FILE_SEEK_START );
		return RM_ERROR;
	}
	p = buf;
	precision = (RMuint32)(p[0]);
	p++;
	RMDBGLOG((JPEGDBG, "jpeg_header_get_sof precision %d \n", precision));

	*height = ((RMuint32)p[0]<<8) + p[1];
	p+=2;
	RMDBGLOG((JPEGDBG, "jpeg_header_get_sof height %d \n", *height));
	*width = ((RMuint32)p[0]<<8) + p[1];
	p+=2;
	RMDBGLOG((JPEGDBG, "jpeg_header_get_sof width %d \n", *width));

	components = (RMuint32)(p[0]);
	p++;
	RMDBGLOG((JPEGDBG, "jpeg_header_get_sof components %d \n", components));

	if( length-6 != components * 3) {
		RMDBGLOG((JPEGDBG, "jpeg_header_get_sof bad length =%d\n", length));
		RMSeekFile( file, *byte_count, RM_FILE_SEEK_START );
		return RM_ERROR;
	}
	if( components > JPEG_MAX_COLOR_COMP ) {
		RMDBGLOG((JPEGDBG, "jpeg_header_get_sof too many colors =%d\n", components));
		components = JPEG_MAX_COLOR_COMP; // can only handle this many 
	}

	for( i = 0; i < components; i++ ) {
		component_id[i] = *p;
		p++;
		h_samp_factor[i] = (*p >> 4) & 0x0f;
		v_samp_factor[i] = (*p) & 0x0f;
		p++;
		quant_table[i] = *p;
		p++;
		RMDBGLOG((JPEGDBG, "jpeg_header_get_sof components %d hs %d vs %d\n", component_id[i], h_samp_factor[i], v_samp_factor[i] ));
	}

	if( components == 3 ) { // only detect the 3 color component pitures
		if( component_id[0] == 82 && component_id[1] == 71 && component_id[2] == 66 ) { //assume this is RGB color
			RMDBGLOG((JPEGDBG, "jpeg_header_get_sof rgb color \n" ));
			*profile = EMhwlib_JPEG_Max_Profile;  // no subsampling 
		}
		else { // rest assume to be YCbCr
			if( h_samp_factor[1] != h_samp_factor[2] || v_samp_factor[1] != v_samp_factor[2] ) {
				RMDBGLOG((JPEGDBG, "jpeg_header_get_sof Cb Cr have different sample factor Cb %d %d Cr %d %d\n", h_samp_factor[1], v_samp_factor[1], h_samp_factor[2], v_samp_factor[2] ));
				return RM_ERROR;
			}
			if( (h_samp_factor[0] == 2) && (v_samp_factor[0] == 2 ) && (h_samp_factor[1] == 1) && (v_samp_factor[1] == 1 )  )
				*profile = EMhwlibJPEGProfile_2211;
			else if( (h_samp_factor[0] == 1) && (v_samp_factor[0] == 1 ) && (h_samp_factor[1] == 1) && (v_samp_factor[1] == 1 )  )
				*profile = EMhwlibJPEGProfile_2222;
			else if( (h_samp_factor[0] == 2) && (v_samp_factor[0] == 1 ) && (h_samp_factor[1] == 1) && (v_samp_factor[1] == 1 )  )
				*profile = EMhwlibJPEGProfile_2111;
			else if( (h_samp_factor[0] == 1) && (v_samp_factor[0] == 2 ) && (h_samp_factor[1] == 1) && (v_samp_factor[1] == 1 )  )
				*profile = EMhwlibJPEGProfile_1211;
			else if( (h_samp_factor[0] == 2) && (v_samp_factor[0] == 2 ) && (h_samp_factor[1] == 1) && (v_samp_factor[1] == 2 )  )
				*profile = EMhwlibJPEGProfile_2212;
			else if( (h_samp_factor[0] == 2) && (v_samp_factor[0] == 2 ) && (h_samp_factor[1] == 2) && (v_samp_factor[1] == 1 )  )
				*profile = EMhwlibJPEGProfile_2221;
			else
				*profile = EMhwlibJPEGProfile_Unknown;
		}
	}
	return RM_OK;
}

// process EXIF APP1 marker
static RMstatus jpeg_header_get_app1( RMfile file, RMuint32 *orientation, RMuint32 * byte_count ) 
{
	RMstatus err;
	enum exifAlign align = motorola_align; 
	RMuint8 buf[JPEG_MAX_MARKER_SIZE];
	RMuint8 *p = 0;
	RMuint32 read;
	RMuint32 length;
	RMuint32 tmp32; 
	RMuint16 tmp16;
	RMuint32 i;

	RMDBGLOG((JPEGDBG, "jpeg_header_get_app1\n"));

	err = RMReadFile(file, buf, 2, &read); // get the length
	if(RMFAILED(err) || (read!= 2)) {
		RMDBGLOG((JPEGDBG, "jpeg_header_get_app1 Error reading file\n"));
		return RM_ERROR;
	}
	length = ((RMuint32)buf[0]<<8) + buf[1];
	RMDBGLOG((JPEGDBG, "jpeg_header_get_app1 length %d (0x%x 0x%x)\n", length, buf[0], buf[1]));
	if( length <2 ) {
		RMDBGLOG((JPEGDBG, "jpeg_header_get_app1 bad length\n"));
		return RM_ERROR;
	}
	*byte_count += length;
	length -= 2;
	
	err = RMReadFile(file, buf, 14, &read); // get marker data
	if(RMFAILED(err) || (read!= 14)) {
		RMDBGLOG((JPEGDBG, "jpeg_header_get_app1 Error reading file size=%d\n", length));
		RMSeekFile( file, *byte_count, RM_FILE_SEEK_START );
		return RM_ERROR;
	}
	p = buf;
	// check the app1 data id
	if( p[0] != 0x45 || p[1] != 0x78 || p[2] != 0x69 || p[3] != 0x66 || p[4] != 0x00 || p[5] != 0x00 ) {
		RMDBGLOG((JPEGDBG, "jpeg_header_get_app1 Error while parsing APP1 data chunk\n"));
		RMSeekFile( file, *byte_count, RM_FILE_SEEK_START );
		return RM_ERROR;
	}
	p+=6;
	switch( readExif16(p, align) ) {
	case 0x4949: // intel (little endian)
		RMDBGLOG((JPEGDBG, "JPEG: INTEL ALIGN (little endian)\n"));
		align = intel_align;
		break;
	case 0x4d4d: // motorola (big endian)
		RMDBGLOG((JPEGDBG, "JPEG: MOTOROLA ALIGN (big endian)\n"));
		align = motorola_align;
		break;
	default:
		RMDBGLOG((JPEGDBG, "jpeg_header_get_app1 Error while parsing endian\n"));
		RMSeekFile( file, *byte_count, RM_FILE_SEEK_START );
		return RM_ERROR;
	}
	p+=2;
	if( readExif16(p, align) != 0x002a) { //0x002a tag
		RMDBGLOG((JPEGDBG, "jpeg_header_get_app1 Error while parsing 2a tag\n"));
		RMSeekFile( file, *byte_count, RM_FILE_SEEK_START );
		return RM_ERROR;
	}
	p+=2; 
	tmp32 = readExif32(p, align);
	p+=4; // offset to IFD

	if(tmp32 != 8){
		RMDBGLOG((JPEGDBG, "jpeg_header_get_app1 skipping %ld extra bytes\n", tmp32-8));
		err = RMSeekFile( file, tmp32-8, RM_FILE_SEEK_CURRENT);
		if(RMFAILED(err)){
			RMDBGLOG((JPEGDBG, "Error seeking file\n"));
			return RM_ERROR;
		}
	}
	err = RMReadFile( file, buf, EXIF_MAX_IFD0_SIZE, &read );	
	if(RMFAILED(err) || (read!= EXIF_MAX_IFD0_SIZE)){
		RMDBGLOG((JPEGDBG, "jpeg_header_get_app1 Error reading file\n"));
		RMSeekFile( file, *byte_count, RM_FILE_SEEK_START );
		return RM_ERROR;
	}
	p = buf;
	tmp16 = readExif16(p, align);
	p+=2; /*ifd number of entries*/
	RMDBGLOG((JPEGDBG, "jpeg_header_get_app1 Number of entries is %d\n", tmp16));
	if(tmp16 >16)
		RMDBGLOG((JPEGDBG, "jpeg_header_get_app1 number of entries > 16\n", tmp16));
	for (i = 0; i<tmp16; i++) {
		// each entry is tag(2):data_format(2):num_components(4):data_or_offset(4)
		RMuint16 tag, format;
		RMuint32 comp_count, offset;
		tag = readExif16(p, align);
		p+=2;
		format = readExif16(p, align);
		p+=2;
		comp_count = readExif32(p, align);
		p+=4; 
		offset = readExif32(p, align);
		p+=4;
		RMDBGLOG((EXIFDBG, "TAG: 0x%04x\n", tag));

		switch(tag){
		case 0x0112: // orientation
			if((format != 3) || (comp_count != 1)){
				RMDBGLOG((JPEGDBG, "Wrong marker\n"));
				return RM_ERROR;
			}
			if(align == motorola_align)
				*orientation = (offset>>16) & 0xffff;
			else
				*orientation = (offset & 0xffff);
			RMDBGLOG((JPEGDBG, "ORIENTATION: 0x%08lx\n", *orientation));
			break;
		default:
			break;
		}
	}

	return RMSeekFile( file, *byte_count, RM_FILE_SEEK_START );
}


static RMstatus detect_jpeg_header_info( RMfile file, RMuint32 * width, RMuint32 * height, RMuint32 * profile, enum PictureOrientation *orientation )
{
	RMuint8 header[2];
	RMuint32 read_size;
	RMstatus err;
	RMbool more_marker = FALSE;
	RMuint32 marker_count = 0;
	RMuint32 byte_count = 0;

	if( ! file ){
		RMDBGLOG((JPEGDBG, "detect_jpeg_header_info file %x not opened \n", file ));
		return RM_ERROR;
	}
	// wind the file to the beginning
	err = RMSeekFile( file, 0, RM_FILE_SEEK_START );
	if(RMFAILED(err)){
		RMDBGLOG((JPEGDBG, "detect_jpeg_header_info Error seeking file\n"));
		return RM_ERROR;
	}
	//read first marker jpeg is identified by 0xffd8
	err = RMReadFile(file, header, 2, &read_size); // get 2 bytes
	if(RMFAILED(err) || (read_size!= 2)){
		RMDBGLOG((JPEGDBG, "detect_jpeg_header_info Error reading file\n"));
		return RM_ERROR;
	}

	if( header[0] != 0xff || header[1] != JPEG_MARKER_SOI ) {  // SOI has to be the first marker
		RMDBGLOG((JPEGDBG, "detect_jpeg_header_info Error while parsing SOI chunk(%02x%02x)\n", header[0], header[1] ));
		return RM_ERROR;
	}
	
	marker_count ++;
	byte_count += 2;
	more_marker = TRUE;

	while( more_marker ) {
		
		err = RMReadFile(file, header, 2, &read_size); // get 2 bytes
		if(RMFAILED(err) || (read_size!= 2)){
			RMDBGLOG((JPEGDBG, "Error reading file \n"));
			return RM_ERROR;
		}
		byte_count += 2;

		RMDBGLOG((JPEGDBG, " Got marker 0x%02x%02x \n", header[0], header[1]));
		if( header[0] != 0xff ) {
			RMDBGLOG((JPEGDBG, "Error marker %02x %02x\n", header[0], header[1]));
			return RM_ERROR;
		}
		
		switch( header[1] ) {
		case JPEG_MARKER_EOI:  // EOI is the last marker
			more_marker = FALSE;  // end of the jpeg stream?
			break;
		case JPEG_MARKER_SOS:
			more_marker = FALSE; // end of the jpeg header
			break;
		case JPEG_MARKER_SOF0:
		case JPEG_MARKER_SOF1:
		case JPEG_MARKER_SOF2:
		case JPEG_MARKER_SOF9:
		case JPEG_MARKER_SOF10:
			RMDBGLOG((JPEGDBG, "calling jpeg_header_get_sof\n"));
			err = jpeg_header_get_sof( file, width, height, profile, &byte_count);
			if(RMFAILED(err) ) {
				RMDBGLOG((JPEGDBG, "jpeg_header_get_sof Error\n"));
				return RM_ERROR;
			}
			RMDBGLOG((JPEGDBG, "jpeg_header_get_sof W %d H %d P %d \n", *width, *height, *profile));
			more_marker = TRUE;
			break;
		case JPEG_MARKER_APP1:  // APP1
			RMDBGLOG((JPEGDBG, "calling jpeg_header_get_app1\n"));
			jpeg_header_get_app1( file, (RMuint32*)orientation, &byte_count );
			if(RMFAILED(err) ) {
				RMDBGLOG((JPEGDBG, "jpeg_header_get_app1 Error\n"));
				return RM_ERROR;
			}
			RMDBGLOG((JPEGDBG, "jpeg_header_get_app1 %d \n", *orientation));
			more_marker = TRUE;
			break;
		case JPEG_MARKER_RST0:
		case JPEG_MARKER_RST1:
		case JPEG_MARKER_RST2:
		case JPEG_MARKER_RST3:
		case JPEG_MARKER_RST4:
		case JPEG_MARKER_RST5:
		case JPEG_MARKER_RST6:
		case JPEG_MARKER_RST7:
		case JPEG_MARKER_TEM:
			// no reading
			more_marker = TRUE;
			break;
		default:  // skip a marker
			err = jpeg_header_skip_marker( file, &byte_count );
			if(RMFAILED(err) ) {
				RMDBGLOG((JPEGDBG, "jpeg_header_skip_marker Error\n"));
				return RM_ERROR;
			}
			more_marker = TRUE;
		}
		marker_count ++;
		RMDBGLOG((JPEGDBG, "detect_jpeg_header_info unhandled marker %d bytes %d\n", marker_count, byte_count ));
	}

	return RM_OK;
}


static inline enum rfp_application get_app_from_stream_info(struct rfp_stream_info *stream_info)
{
	switch(stream_info->system_type){
	case RM_SYSTEM_MPEG4:
		return APP_MP4;
	case RM_SYSTEM_ASF:
		return APP_ASF;
	case RM_SYSTEM_ELEMENTARY_VIDEO:
		switch(stream_info->video_type){
		case RM_VIDEO_MPEG12:
		case RM_VIDEO_MPEG4:
		case RM_VIDEO_H263:
		case RM_VIDEO_H264:
		case RM_VIDEO_WMV:
		case RM_VIDEO_VC1:
		case RM_VIDEO_DIVX3:
		case RM_VIDEO_DIVX4:
		case RM_VIDEO_XVID:
		case RM_VIDEO_MJPEG:
			return APP_VIDEO;
		case RM_VIDEO_BMP:
		case RM_VIDEO_TIFF:
		case RM_VIDEO_GIF:
		case RM_VIDEO_PNG:
		case RM_VIDEO_JPEG:
			return APP_PICTURE;
		case RM_VIDEO_UNKNOWN:
			return NOT_SUPPORTED;
		}
		break;
	case RM_SYSTEM_ELEMENTARY_AUDIO:
		return APP_AUDIO;
	case RM_SYSTEM_MPEG2_TRANSPORT:
	case RM_SYSTEM_MPEG2_TRANSPORT_192:
		return APP_DEMUX;
	case RM_SYSTEM_MPEG1:
	case RM_SYSTEM_MPEG2_PROGRAM:
	case RM_SYSTEM_MPEG2_DVD:
		return APP_DEMUX;
	case RM_SYSTEM_AVI:
		return APP_AVI;

		/* the following are deprecated types (use RM_SYTEM_AVI instead) */
	case RM_SYSTEM_MPEG2_DVD_AUDIO:
	case RM_SYSTEM_DIVX_MP3:
	case RM_SYSTEM_DIVX_AC3:
	case RM_SYSTEM_DIVX_MPEG1:
	case RM_SYSTEM_DIVX_PCM:
	case RM_SYSTEM_DIVX_WMA:
	case RM_SYSTEM_DIVX_WMV9_MP3:
	case RM_SYSTEM_DIVX_WMV9_AC3:
	case RM_SYSTEM_DIVX_WMV9_MPEG1:
	case RM_SYSTEM_DIVX_WMV9_PCM:
	case RM_SYSTEM_DIVX3_MP3:
	case RM_SYSTEM_DIVX3_AC3:
	case RM_SYSTEM_DIVX3_MPEG1:
	case RM_SYSTEM_DIVX3_PCM:
	case RM_SYSTEM_RIFFCDXA:
	case RM_SYSTEM_ID3:
	case RM_SYSTEM_UNKNOWN:
		break;
	}
	return NOT_SUPPORTED;
}


static inline RMbool AudioFormatToCodec(eAudioFormat_type audio_format, struct audio_cmdline *audio_opt)
{
	switch(audio_format){
	case eAudioFormat_MPEG1_LAYER3:
	case eAudioFormat_MPEG2_LAYER1:
	case eAudioFormat_MPEG2_LAYER2:
	case eAudioFormat_MPEG2_LAYER3:
	case eAudioFormat_MPEG2:
	case eAudioFormat_MPEG1:
		RMDBGLOG((LOCALDBG, "audio type is mpeg1\n"));
		fprintf(stderr, "audio type is mpeg1\n");
		audio_opt->Codec = AudioDecoder_Codec_MPEG1;
		break;
	case eAudioFormat_AC3:
		RMDBGLOG((LOCALDBG, "audio type is ac3\n"));
		fprintf(stderr, "audio type is ac3\n");
		audio_opt->Codec = AudioDecoder_Codec_AC3;
		break;
	case eAudioFormat_PCM:
		RMDBGLOG((LOCALDBG, "audio type is pcm\n"));
		fprintf(stderr, "audio type is pcm\n");
		audio_opt->Codec = AudioDecoder_Codec_PCM;
		break;
	case eAudioFormat_DTS:
		RMDBGLOG((LOCALDBG, "audio type is dts\n"));
		fprintf(stderr, "audio type is dts\n");
		audio_opt->Codec = AudioDecoder_Codec_DTS;
		break;
	case eAudioFormat_DVD_AUDIO:
		RMDBGLOG((LOCALDBG, "audio type is dvda\n"));
		fprintf(stderr, "audio type is dvda\n");
		audio_opt->Codec = AudioDecoder_Codec_DVDA;
		break;
	case eAudioFormat_AAC_ADTS:
		RMDBGLOG((LOCALDBG, "audio type is aac_adts\n"));
		fprintf(stderr, "audio type is aac_adts\n");
		audio_opt->Codec = AudioDecoder_Codec_AAC;
		audio_opt->AACParams.InputFormat = 1;	// adts, sync word
		break;
	case eAudioFormat_AAC_ADIF:
		RMDBGLOG((LOCALDBG, "audio type is aac_adif\n"));
		fprintf(stderr, "audio type is aac_adif\n");
		audio_opt->Codec = AudioDecoder_Codec_AAC;
		audio_opt->AACParams.InputFormat = 0;	// adif, no sync word
		break;
	case eAudioFormat_AAC_LATM:
		RMDBGLOG((LOCALDBG, "audio type is aac_latm\n"));
		fprintf(stderr, "audio type is aac_latm\n");
		audio_opt->Codec = AudioDecoder_Codec_AAC;
		audio_opt->AACParams.InputFormat = 3;	// latm
		break;
	case eAudioFormat_WMA:
		RMDBGLOG((LOCALDBG, "audio type is wma\n"));
		fprintf(stderr, "audio type is wma\n");
		audio_opt->Codec = AudioDecoder_Codec_WMA;
		break;
	default:
		RMDBGLOG((LOCALDBG, "Can't translate eAudioFormat_type %ld\n", audio_format));
		fprintf(stderr, "audio type is unknown\n");
		return FALSE;
	}
	return TRUE;
}


static inline RMbool VideoFormatToCodec(RMvideoType video_type, struct video_cmdline *video_opt, struct rfp_detect_options *detect_opt)
{
	switch(video_type){
	case RM_VIDEO_MPEG12:
		if(!detect_opt->force_sd){
			RMDBGLOG((LOCALDBG, "video type is mpeg2 HD video\n" ));
			fprintf(stderr, "video type is mpeg2 HD\n");
			video_opt->MPEGProfile = Profile_MPEG2_HD;
			video_opt->Codec = VideoDecoder_Codec_MPEG2_HD;
		}
		else{
			RMDBGLOG((LOCALDBG, "video type is mpeg2 SD video\n" ));
			fprintf(stderr, "video type is mpeg2 SD\n");
			video_opt->MPEGProfile = Profile_MPEG2_HD;
			video_opt->Codec = VideoDecoder_Codec_MPEG2_HD;
		}
		break;
	case RM_VIDEO_MPEG4:
		if(!detect_opt->force_sd){
			RMDBGLOG((LOCALDBG, "video type is mpeg4 HD video\n" ));
			fprintf(stderr, "video type is mpeg4 HD\n");
			video_opt->MPEGProfile = Profile_MPEG4_HD;
			video_opt->Codec = VideoDecoder_Codec_MPEG4_HD;
		}
		else{
			RMDBGLOG((LOCALDBG, "video type is mpeg4 SD video\n" ));
			fprintf(stderr, "video type is mpeg4 SD\n");
			video_opt->MPEGProfile = Profile_MPEG4_SD;
			video_opt->Codec = VideoDecoder_Codec_MPEG4_SD;
		}
		break;
	case RM_VIDEO_H263:

		RMDBGLOG((LOCALDBG, "video type is h263 video, set codec to mpeg4\n" ));
		fprintf(stderr, "video type is mpeg4\n");
		video_opt->MPEGProfile = Profile_MPEG4_HD;
		video_opt->Codec = VideoDecoder_Codec_MPEG4_HD;

		break;
	case RM_VIDEO_WMV:
		if(!detect_opt->force_sd){
			RMDBGLOG((LOCALDBG, "video type is WMV HD video\n" ));
			fprintf(stderr, "video type is WMV HD\n");
			video_opt->MPEGProfile = Profile_WMV_HD;
			video_opt->Codec = VideoDecoder_Codec_WMV_HD;
		}
		else{
			RMDBGLOG((LOCALDBG, "video type is WMV SD video\n" ));
			fprintf(stderr, "video type is WMV SD\n");
			video_opt->MPEGProfile = Profile_WMV_816P;
			video_opt->Codec = VideoDecoder_Codec_WMV_816P;
		}
		break;
	case RM_VIDEO_VC1:
		if(!detect_opt->force_sd){
			RMDBGLOG((LOCALDBG, "video type is vc1 HD video\n" ));
			fprintf(stderr, "video type is vc1 HD\n");
			video_opt->MPEGProfile = Profile_VC1_HD;
			video_opt->Codec = VideoDecoder_Codec_VC1_HD;
		}
		else{
			RMDBGLOG((LOCALDBG, "video type is vc1 SD video\n" ));
			fprintf(stderr, "video type is vc1 SD\n");
			video_opt->MPEGProfile = Profile_VC1_SD;
			video_opt->Codec = VideoDecoder_Codec_VC1_SD;
		}
		break;
	case RM_VIDEO_DIVX3:
		if(!detect_opt->force_sd){
			RMDBGLOG((LOCALDBG, "video type is divx3 HD video\n" ));
			fprintf(stderr, "video type is divx3 HD\n");
			video_opt->MPEGProfile = Profile_DIVX3_HD;
			video_opt->Codec = VideoDecoder_Codec_DIVX3_HD;
		}
		else {
			RMDBGLOG((LOCALDBG, "video type is divx3 SD video\n" ));
			video_opt->MPEGProfile = Profile_DIVX3_SD;
			video_opt->Codec = VideoDecoder_Codec_DIVX3_SD;
		}
		break;
	case RM_VIDEO_XVID:
		if(!detect_opt->force_sd){
			RMDBGLOG((LOCALDBG, "video type is xvid HD video\n" ));
			fprintf(stderr, "video type is xvid HD\n");
			video_opt->MPEGProfile = Profile_MPEG4_HD_Padding;
			video_opt->Codec = VideoDecoder_Codec_MPEG4_HD_Padding;
		}
		else{
			RMDBGLOG((LOCALDBG, "video type is xvid SD video\n" ));
			video_opt->MPEGProfile = Profile_MPEG4_SD_Padding;
			video_opt->Codec = VideoDecoder_Codec_MPEG4_SD_Padding;
		}
		break;
	case RM_VIDEO_H264:
		if(!detect_opt->force_sd){
			RMDBGLOG((LOCALDBG, "video type is h264 HD video\n" ));
			fprintf(stderr, "video type is h264 HD\n");
			video_opt->MPEGProfile = Profile_H264_HD;
			video_opt->Codec = VideoDecoder_Codec_H264_HD;
		}
		else{
			RMDBGLOG((LOCALDBG, "video type is h264 SD video\n" ));
			video_opt->MPEGProfile = Profile_H264_SD;
			video_opt->Codec = VideoDecoder_Codec_H264_SD;
		}
		break;
	case RM_VIDEO_JPEG:
		video_opt->vcodec = EMhwlibJPEGCodec;
		break;
	case RM_VIDEO_DIVX4:
		RMDBGLOG((ENABLE, "video type is divx4 video\n" ));
		RMDBGLOG((ENABLE, "NOT SUPPORTED YET\n" ));
		return FALSE;
	case RM_VIDEO_MJPEG:
	case RM_VIDEO_BMP:
	case RM_VIDEO_TIFF:
	case RM_VIDEO_GIF:
	case RM_VIDEO_PNG:
	case RM_VIDEO_UNKNOWN:
		RMDBGLOG((ENABLE, "video type is not recognized\n" ));
		return FALSE;

	}
	return TRUE;
}

static void DetectionPESCallback(RMuint8 *buffer, RMuint32 length, RMuint64 PTS, RMbool isPtsValid,
				RMvdemuxDataType dataType, RMuint64 PESOffset, void *detect_info)
{
	struct detection_callback_info *dinfo = (struct detection_callback_info*) detect_info;

	if((dataType == RMVDEMUX_AUDIO) && (! dinfo->audio_detected)) {
		dinfo->parsedBytes += length;

		RMFDetectAudio(dinfo->detector, buffer, length, &(dinfo->audio_type),
			       &(dinfo->audio_freq), &(dinfo->audio_channels), &(dinfo->audio_bitrate), 
			       &(dinfo->audio_detected));
		
		if (dinfo->parsedBytes < AUDIO_DETECTION_THRESHOLD) {
			if ((dinfo->audio_type == eAudioFormat_AAC) && dinfo->audio_detected) {
				RMDBGLOG((ENABLE, "clearing AAC false positive (byteCount %lu)\n", dinfo->parsedBytes));
				dinfo->audio_detected = FALSE;
			}
		}

		if(dinfo->audio_detected)
			RMDBGLOG((ENABLE, "Detected Audio Format type %ld\n", dinfo->audio_type));
		
	}
	if ((isPtsValid) && (PTS > dinfo->last_pts)){
		dinfo->last_pts = PTS;
		RMDBGLOG((ENABLE, "Last pts is %lld\n", dinfo->last_pts));
	}
	if ((isPtsValid) && (PTS < dinfo->first_pts)){
		dinfo->first_pts = PTS;
		RMDBGLOG((ENABLE, "First pts is %lld\n", dinfo->first_pts));
	}
}

static void LPCMCallback(RMuint8 numberOfFrameHeaders, RMuint16 firstAccessUnitPointer, RMuint32 frequency,
			 RMuint8 numberOfChannels, RMvdemuxQuantization quantizationWordLength, void *detect_info)
{
	struct detection_callback_info *dinfo = (struct detection_callback_info*) detect_info;
	dinfo->pcm_detected = TRUE;
	dinfo->audio_freq = frequency;
	dinfo->audio_depth = quantizationWordLength;
	dinfo->audio_channels = numberOfChannels;
	return;
}


// ASF Duration detection routines

struct detect_asf_context {
	ExternalRMASFDemux vASFDemux;

	RMuint64 Duration;

	RMuint64 headerObjectSize;
	RMuint32 packetSize;
};

static void detect_asf_duration_file_properties_callback(void *context,
							 unsigned long long File_Size,
							 unsigned long long Creation_Date,
							 unsigned long long Data_Packets_Count,
							 unsigned long long Play_Duration,
							 unsigned long long Send_Duration,
							 unsigned long long Preroll,
							 unsigned long Minimum_Data_Packet_Size,
							 unsigned long Maximum_Data_Packet_Size,
							 unsigned long Maximum_Bitrate,
							 unsigned char Broadcast,
							 unsigned char Seekable) {
	
	RMuint64 duration;
	RMuint64 hour, min, sec, milisec;
	struct detect_asf_context *pSendContext = (struct detect_asf_context *) context;

	RMDBGLOG((ENABLE, "    Send Duration = %llu ms\n", Send_Duration / 10000));
	RMDBGLOG((ENABLE, "    Preroll = %llu ms\n", Preroll));

	pSendContext->Duration = (Play_Duration / 10000) - Preroll;

	RMDBGLOG((ENABLE, "    Play Duration = %llu ms\n", pSendContext->Duration));

	RMDBGLOG((ENABLE, "    Maximum_Bitrate = %lu bits/s\n", Maximum_Bitrate));
	RMDBGLOG((ENABLE, "    Minimum_Data_Packet_Size = %lu, Maximum_Data_Packet_Size = %lu\n",
		  Minimum_Data_Packet_Size, Maximum_Data_Packet_Size));


	duration = pSendContext->Duration;
	hour = duration / (3600 * 1000);
	duration -= (hour * 3600 * 1000);
	min = duration / (60 * 1000);
	duration -= min * 60 * 1000;
	sec = duration / 1000;
	duration -= sec * 1000;
	milisec = duration;
	RMDBGLOG((ENABLE, ">>> Duration %ldh %ldm %lds %ldms\n", (RMuint32)hour, (RMuint32)min, (RMuint32)sec, (RMuint32)milisec));

	RMDBGLOG((ENABLE, "\tCreation Data = %llu\n", Creation_Date));
	RMDBGLOG((ENABLE, "\tFile Size = %llu %s %s\n", File_Size, ((Broadcast) ? "[Broadcast (play and send duration invalid!)]":""), ((Seekable) ? "[Seekable]":"")));
	RMDBGLOG((ENABLE, "\tData Packets Count = %llu\n", Data_Packets_Count));
	
}



static RMstatus detect_asf_duration(RMfile fileHandle, RMuint64 *duration)
{
	struct detect_asf_context DetectContext = {0,};
	RMstatus err = RM_OK;
	RMuint64 position;

	DetectContext.vASFDemux = NULL;

	*duration = 0;

	RMDBGLOG((ENABLE, "begin asf duration detection\n"));

	RMDBGLOG((ENABLE, "create asf demux\n"));
	err = RMCreateASFVDemux(&DetectContext.vASFDemux);
	if (err != RM_OK) {
		fprintf(stderr, "error creating demux\n");
		return err;
	}

	err = RMASFVDemuxInit(DetectContext.vASFDemux, &DetectContext);
	if (err != RM_OK) {
		fprintf(stderr, "error during demux init\n");
		return err;
	}

	err = RMASFVDemuxSetCallbacks(DetectContext.vASFDemux,
				      NULL,
				      detect_asf_duration_file_properties_callback,
				      NULL,
				      NULL,
				      NULL,
				      NULL,
				      NULL,
				      NULL,
				      NULL,
				      NULL,
				      NULL,
				      NULL,
				      NULL,
				      NULL,
				      NULL,
				      NULL);

	if (err != RM_OK) {
		fprintf(stderr, "error registering callbacks\n");
		return err;
	}

	/* Check current position only if seek is supported */
	RMGetCurrentPositionOfFile(fileHandle, (RMint64*)&position);
	RMDBGLOG((ENABLE, "current position %lld\n", position));

	err = RMASFVDemuxBuildIndexWithHandle(DetectContext.vASFDemux, 
					      fileHandle, 
					      &DetectContext.packetSize, 
					      &DetectContext.headerObjectSize);


	/* seek to first packet, at position [headerSize+50] */
	RMSeekFile(fileHandle, position, RM_FILE_SEEK_START);
	
		
	/* Check current position only if seek is supported */
	RMGetCurrentPositionOfFile(fileHandle, (RMint64*)&position);
	RMDBGLOG((ENABLE, "current position %lld\n", position));


	if (DetectContext.vASFDemux) {
		RMDBGLOG((ENABLE, "delete demux\n"));
		RMDeleteASFVDemux(DetectContext.vASFDemux);
	}

	*duration = DetectContext.Duration;

	return RM_OK;

}

struct parse_avi_context {
	RMaviPushHandle pAvi;
	RMbool packed;
	RMuint32 version;
	RMuint32 build;
};


#define PARSE_AVI_BUF_SIZE 4096


static void avi_demux_callback (RMuint8 chunkid[4], RMuint8 *chunk, RMuint32 chunkLength, RMuint32 flags, void *context)
{
	RMuint32 i;
	struct parse_avi_context *pContext = (struct parse_avi_context*)context;

	if ((chunkid[2] == 'd') && ((chunkid[3] == 'c') || (chunkid[3] == 'b'))){
		//RMDBGLOG((ENABLE, "video chunk, size %lu\n", chunkLength));

		if (chunkLength > 3) {
			for (i = 0; i < chunkLength - 3; i++) {
				if ((chunk[i] == 'D') &&
				    (chunk[i+1] == 'i') &&
				    (chunk[i+2] == 'v') &&
				    (chunk[i+3] == 'X')) {
					int parsed, build, version;
					char packed;
					RMuint32 j = 0;

					RMDBGPRINT((ENABLE, "\n"));
					while((chunk[i+j] >= 32) && (chunk[i+j] <= 126)) {
						RMDBGPRINT((ENABLE, "%c", chunk[i+j]));
						j++;
					}
					RMDBGPRINT((ENABLE, "\n"));					

					parsed = sscanf((char *)&chunk[i], "DivX%dBuild%d%c", &version, &build, &packed);
					if (parsed < 2)
						parsed = sscanf((char *)&chunk[i], "DivX%db%d%c", &version, &build, &packed);

					if ((parsed == 3) && (packed == 'p')) {
						pContext->packed = TRUE;
					}

					pContext->version = (RMuint32)version;
					pContext->build = (RMuint32)build;

					RMDBGLOG((ENABLE, "parsed %lu, version %lu, build %lu, packed '%c'\n", (RMuint32)parsed, (RMuint32)version, (RMuint32)build, packed));
				}
			}
		}

	}		
	else if ((chunkid[2] == 'w') && (chunkid[3] == 'b')){
		RMDBGLOG((DISABLE, "audio, size %lu\n", chunkLength));

	}
}



static RMstatus parse_avi(RMfile fileHandle, struct parse_avi_context *avi_info)
{
       

	RMuint8 buf[PARSE_AVI_BUF_SIZE];
	RMuint32 parsed_bytes = 0, max_parsed_bytes;
	RMuint32 buf_size = PARSE_AVI_BUF_SIZE;
	RMuint32 movi_offset, movi_size;
	
	RMstatus err = RM_OK;


	RMDBGLOG((ENABLE, "enter parse_avi\n"));

	err = RMAviPushOpenExternal(fileHandle, &(avi_info->pAvi));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error opening avi file\n"));
		goto exit;
	}

	err = RMAviPushGetMoviOffset(avi_info->pAvi, &movi_offset);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get movi offset\n"));
		goto exit;
	}

	err = RMAviPushGetMoviSize(avi_info->pAvi, &movi_size);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get movi size\n"));
		goto exit;
	}
	err = RMSeekFile(fileHandle, movi_offset, RM_FILE_SEEK_START);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error seeking file to movi\n"));
		goto exit;
	}
	
	RMAviPushInitDemuxMovi (avi_info->pAvi, avi_demux_callback, NULL);


	max_parsed_bytes = RMmin(1024*1024, movi_size/4);

	while(parsed_bytes < max_parsed_bytes){
		RMuint32 count;

		err = RMReadFile(fileHandle, buf, buf_size, &count);
		if (RMFAILED(err)) {
			break;
		}
		RMAviPushDemuxMovi(avi_info->pAvi, buf, count, (void*)avi_info);
		parsed_bytes += count;
		
	}


 exit:
	if (avi_info->pAvi != NULL) {
		err = RMAviPushClose(avi_info->pAvi);
		avi_info->pAvi = NULL;
	}

	RMDBGLOG((ENABLE, "exit parse_avi\n"));
	return err;

	return RM_OK;


}



RMstatus rfp_open_file(struct mono_info *app_params, struct rfp_stream_info *stream_info, struct rfp_file *pfile)
{
	/* the passed *stream_info could be NULL...  */
	struct rfp_stream_info stream_info_loc;
	struct playback_cmdline *play_opt = app_params->play_opt;

	pfile->file = (RMfile) NULL;

	if(stream_info == NULL){
		stream_info = &stream_info_loc;
	}

	stream_info->system_type = RM_SYSTEM_UNKNOWN;
	stream_info->audio_type = eAudioFormat_UNKNOWN;
	stream_info->video_type = RM_VIDEO_UNKNOWN;


	/* #### Begin CARDEA code #### */
	{
		if ( find_cardea_url(play_opt->filename) != NULL ) {
			RMDBGLOG((ENABLE, "Playing cardea file, skip detection ... (only ASF supported).\n"));
			stream_info->system_type = RM_SYSTEM_ASF;
			return RM_OK;
		}
	}
	/* #### End CARDEA code #### */


	/* open the stream */
	pfile->file = open_stream(play_opt->filename, RM_FILE_OPEN_READ, &app_params->stream_opts);
	if (pfile->file == NULL) {
		RMDBGLOG((ENABLE, "Cannot open file %s\n", play_opt->filename));
		goto open_error;
	}

	return RM_OK;

 open_error:
	rfp_close_file(pfile);
	return RM_ERROR;
}

RMstatus rfp_close_file(struct rfp_file *pfile)
{
	if (pfile->file)
		RMCloseFile(pfile->file);

	return RM_OK;
}

RMstatus rfp_detect(struct mono_info *app_params, 
		    struct rfp_detect_options *detect_opt,
		    enum rfp_application *app,
		    struct rfp_stream_info *stream_info)
{
	struct rfp_file rfpfile;
	RMstatus err;
	/* the passed *stream_info could be NULL...  */
	struct rfp_stream_info stream_info_loc;
#ifndef NDEBUG
	struct playback_cmdline *play_opt = app_params->play_opt;
#endif
	if(stream_info == NULL){
		stream_info = &stream_info_loc;
	}

	err = rfp_open_file(app_params, stream_info, &rfpfile);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot open File %s\n", play_opt->filename));
		return err;
	}
	
	if (stream_info->system_type == RM_SYSTEM_ASF) {
		*app = get_app_from_stream_info(stream_info);
		/* In this case file is not open */
		err = RM_OK;
	}
	else {
		err = rfp_detect_open_file(rfpfile.file, app_params, detect_opt, app, stream_info);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot detect file %s\n", play_opt->filename));
		}
		
		err = rfp_close_file(&rfpfile);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot close file %s\n", play_opt->filename));
		}
	}
	
	return err;	
}


RMstatus rfp_detect_open_file(RMfile file, 
			      struct mono_info *app_params, 
			      struct rfp_detect_options *detect_opt,
			      enum rfp_application *app,
			      struct rfp_stream_info *stream_info)
{

	RMstatus err;
	RMdetectorHandle detector = NULL;
	RMFDetector_type type;
	RMuint32 frequency = 0, channel_count = 0, bitrate = 0;
	RMint64 file_size = 0;
	RMbool detected;
	RMint32 error = 0;

	struct playback_cmdline *play_opt = app_params->play_opt;
	struct video_cmdline *video_opt = app_params->video_opt;
	struct audio_cmdline *audio_opt = app_params->audio_opt;
	struct demux_cmdline *demux_opt = app_params->demux_opt;

		
	/* give the stream and the filename to the detector */
	detector = RMFDetectorCreate();
	RMDBGLOG((LOCALDBG, "Created detector handle\n"));

	RMFDetectOnOpenFile(detector, play_opt->filename, file,  &type);
		
	switch(type){
	case DETECTOR_AUDIO:
		fprintf(stderr, "audio\n");

		err = RMSizeOfOpenFile(file, &file_size);
		if(RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot get size of file %s\n", play_opt->filename));
		}

		/* this works because the detector has not been reset */
		{
			struct RM_Detection_Specific_Info specificInfo;
			eAudioFormat_type detectedAudioType;

			err = RMFGetDetectedAudioType(detector, &detectedAudioType);
			if (err != RM_OK) {
				RMDBGLOG((ENABLE, "error getting detected audio type\n"));
			}

			err = RMFGetAudioSpecificInfo(detector, detectedAudioType, &specificInfo);
			if (err != RM_OK) {
				RMDBGLOG((ENABLE, "error getting specific information!\n"));
				ERROR_CLEANUP(-1);
			}

			switch (specificInfo.audioType) {
			case eAudioFormat_PCM:
				RMDBGLOG((ENABLE, "PCM\n"));

				bitrate = specificInfo.data.wave.bitrate;
				frequency = specificInfo.data.wave.sampleRate;
				channel_count = specificInfo.data.wave.channels;

				audio_opt->skip_first_n_bytes = specificInfo.data.wave.payloadOffset;
				audio_opt->send_n_bytes = specificInfo.data.wave.payloadLength;

				audio_opt->PcmCdaParams.BitsPerSample = specificInfo.data.wave.bitsPerSample; /*bitrate/(frequency*channel_count);*/
				if(audio_opt->PcmCdaParams.BitsPerSample <=8)
					audio_opt->SignedPCM = FALSE; 
				
				audio_opt->SubCodec = 0;

				/* if the detector could tell it is PCM, it must be from a WAVE file */
				audio_opt->PcmCdaParams.MsbFirst = FALSE;

				switch(channel_count){
				case 1:
					audio_opt->PcmCdaParams.ChannelAssign = PcmCda1_C;
					audio_opt->OutputDualMode = DualMode_MixMono;
					break;
				case 2:
					audio_opt->PcmCdaParams.ChannelAssign = PcmCda2_LR;
					audio_opt->OutputDualMode = DualMode_Stereo;
					break;
				}

				break;

			case eAudioFormat_AC3:
				RMDBGLOG((ENABLE, "AC3\n"));
				
				bitrate = specificInfo.data.ac3.bitrate;
				frequency = specificInfo.data.ac3.sampleRate;
				channel_count = specificInfo.data.ac3.channels;

				break;

			case eAudioFormat_DTS:
				RMDBGLOG((ENABLE, "DTS\n"));
				
				bitrate = specificInfo.data.dts.bitrate;
				frequency = specificInfo.data.dts.sampleRate;
				channel_count = specificInfo.data.dts.channels;

				break;

			case eAudioFormat_MPEG1:
			case eAudioFormat_MPEG2_LAYER1:
			case eAudioFormat_MPEG2:
			case eAudioFormat_MPEG2_LAYER2:
			case eAudioFormat_MPEG1_LAYER3:
			case eAudioFormat_MPEG2_LAYER3:
				RMDBGLOG((ENABLE, "MPEG\n"));
				
				if (!specificInfo.data.mpegAudio.isVBR)
					bitrate = specificInfo.data.mpegAudio.bitrate;
				else
					bitrate = 0;

				frequency = specificInfo.data.mpegAudio.sampleRate;
				channel_count = specificInfo.data.mpegAudio.channels;

				break;

			case eAudioFormat_AAC_ADTS:
				RMDBGLOG((ENABLE, "AAC ADTS\n"));
				
				bitrate = 0;
				frequency = specificInfo.data.adts.sampleRate;
				channel_count = specificInfo.data.adts.channels;
		
				break;

			case eAudioFormat_AAC_ADIF:
				RMDBGLOG((ENABLE, "AAC ADIF\n"));
				
				if (!specificInfo.data.adif.isVBR)
					bitrate = specificInfo.data.adif.bitrate;
				else
					bitrate = 0;

				frequency = specificInfo.data.adif.sampleRate;
				channel_count = specificInfo.data.adif.channels;

				break;
				
			case eAudioFormat_UNKNOWN:
				RMDBGLOG((ENABLE, "the specific info request seems to be invalid\n"));
				break;
			default:
				RMDBGLOG((ENABLE, "unrecognised specific info!\n"));
				break;
			}

			RMDBGLOG((ENABLE, "sampleRate %lu, bitrate %lu, channels %lu\n", frequency, bitrate, channel_count));

			stream_info->audio_type = detectedAudioType;

		}
		

		if (bitrate) {
			play_opt->duration = (8000*file_size)/bitrate;
			RMDBGLOG((LOCALDBG, "estimated duration is %lld (bitrate %lu)\n", play_opt->duration, bitrate));
		}
		else
			RMDBGLOG((ENABLE, "Could not estimate duration\n"));

		AudioFormatToCodec(stream_info->audio_type, audio_opt);
		
		audio_opt->SamplingFrequency = 0;  // default: same as SampleRate
		if (audio_opt->dh_info && audio_opt->dh_info->pDH) {  // HDMI is active, up/downsample to basic HDMI audio frequencies
			if (audio_opt->Codec == AudioDecoder_Codec_PCM) {
				RMDBGLOG((LOCALDBG, "Setting PCM audio sampling rate to %ld\n", frequency));
				audio_opt->SamplingFrequency = frequency;  // maintain source sample rate for uncompressed audio
			}
			switch (frequency) {
			case 8000: 
			case 12000: 
			case 16000: 
			case 32000: 
			case 64000: 
			case 128000: 
				audio_opt->SampleRate = 32000;
				break;
			case 11025: 
			case 22050: 
			case 44100: 
			case 88200: 
			case 176400: 
				audio_opt->SampleRate = 44100;
				break;
			case 24000: 
			case 48000: 
			case 96000: 
			case 192000: 
			default:
				audio_opt->SampleRate = 48000;
				break;
			}
		} else {
			audio_opt->SampleRate = frequency;
		}
		audio_opt->ForceSampleRate = TRUE;

		RMDBGLOG((LOCALDBG, "Setting audio sample rate to %ld\n", audio_opt->SampleRate));

		stream_info->system_type = RM_SYSTEM_ELEMENTARY_AUDIO;
		break;

	case DETECTOR_VIDEO_MPEG1:
	case DETECTOR_VIDEO_MPEG2:
		fprintf(stderr, "video\n");

		RMFDetectVideo(detector, NULL, 0, &stream_info->video_type, &bitrate, &detected);

		VideoFormatToCodec(stream_info->video_type, video_opt, detect_opt);
		stream_info->system_type = RM_SYSTEM_ELEMENTARY_VIDEO;
		break;
	case DETECTOR_VIDEO_MPEG4:
		fprintf(stderr, "video\n");
		VideoFormatToCodec(RM_VIDEO_MPEG4, video_opt, detect_opt);
		stream_info->video_type = RM_VIDEO_MPEG4;
		stream_info->system_type = RM_SYSTEM_ELEMENTARY_VIDEO;
		break;
	case DETECTOR_VIDEO_H263:
		fprintf(stderr, "video\n");
		VideoFormatToCodec(RM_VIDEO_H263, video_opt, detect_opt);
		stream_info->video_type = RM_VIDEO_H263;
		stream_info->system_type = RM_SYSTEM_ELEMENTARY_VIDEO;
		break;
	case DETECTOR_VIDEO_H264:
		fprintf(stderr, "video\n");
		VideoFormatToCodec(RM_VIDEO_H264, video_opt, detect_opt);
		stream_info->video_type = RM_VIDEO_H264;
		stream_info->system_type = RM_SYSTEM_ELEMENTARY_VIDEO;
		break;
	case DETECTOR_VIDEO_VC1:
		fprintf(stderr, "video\n");
		VideoFormatToCodec(RM_VIDEO_VC1, video_opt, detect_opt);
		stream_info->video_type = RM_VIDEO_VC1;
		stream_info->system_type = RM_SYSTEM_ELEMENTARY_VIDEO;
		break;
	case DETECTOR_SYSTEM_M1S:
		fprintf(stderr, "m1s\n");
		RMDBGLOG((LOCALDBG, "DETECTOR_SYSTEM_M1S (%ld)\n", type));
		demux_opt->system_type = RM_SYSTEM_MPEG1;
		demux_opt->repack_sample = FALSE;
		stream_info->system_type = RM_SYSTEM_MPEG1;
		break;
	case DETECTOR_SYSTEM_M2P:
		fprintf(stderr, "m2p\n");
		RMDBGLOG((LOCALDBG, "DETECTOR_SYSTEM_M2P (%ld)\n", type));
		demux_opt->system_type = RM_SYSTEM_MPEG2_PROGRAM;
		demux_opt->repack_sample = FALSE;
		stream_info->system_type = RM_SYSTEM_MPEG2_PROGRAM;
		break;
	case DETECTOR_SYSTEM_M2T_192:
		fprintf(stderr, "m2t_192\n");
		RMDBGLOG((LOCALDBG, "DETECTOR_SYSTEM_M2T_192 (%ld)\n", type));
		demux_opt->system_type = RM_SYSTEM_MPEG2_TRANSPORT_192;
		demux_opt->repack_sample = TRUE;
		stream_info->system_type = RM_SYSTEM_MPEG2_TRANSPORT_192;
		break;
	case DETECTOR_SYSTEM_M2T:
		fprintf(stderr, "m2t\n");
		RMDBGLOG((LOCALDBG, "DETECTOR_SYSTEM_M2T (%ld)\n", type));
		demux_opt->system_type = RM_SYSTEM_MPEG2_TRANSPORT;
		demux_opt->repack_sample = TRUE;
		stream_info->system_type = RM_SYSTEM_MPEG2_TRANSPORT;
		break;
	case DETECTOR_SYSTEM_M4T:
		fprintf(stderr, "m4t\n");
		RMDBGLOG((LOCALDBG, "DETECTOR_SYSTEM_M4T (%ld)\n", type));
		demux_opt->system_type = RM_SYSTEM_MPEG2_TRANSPORT;
		demux_opt->repack_sample = TRUE;
		stream_info->system_type = RM_SYSTEM_MPEG2_TRANSPORT;
		break;
	case DETECTOR_SYSTEM_M4P:
		fprintf(stderr, "m4p\n");
		RMDBGLOG((LOCALDBG, "DETECTOR_SYSTEM_M4P (%ld)\n", type));
		demux_opt->system_type = RM_SYSTEM_MPEG2_PROGRAM;
		stream_info->system_type = RM_SYSTEM_MPEG2_PROGRAM;
		demux_opt->repack_sample = FALSE;
		break;
	case DETECTOR_SYSTEM_VOB:
		fprintf(stderr, "vob\n");
		RMDBGLOG((LOCALDBG, "DETECTOR_SYSTEM_VOB (%ld)\n", type));
		demux_opt->system_type = RM_SYSTEM_MPEG2_DVD;
		demux_opt->repack_sample = FALSE;
		stream_info->system_type = RM_SYSTEM_MPEG2_DVD;
		break;
	case DETECTOR_SYSTEM_AVI:
		fprintf(stderr, "avi\n");
		
		/* create a avi demux, demux video and find user data */
		{
			struct parse_avi_context context = {0,};

			/* #### Begin DTCP code #### */
			if (!app_params->dtcpCookieHandle)
			/* #### End DTCP code #### */
				parse_avi(file, &context);
			
			/* #### Begin DTCP code #### */
			else {
				RMfile dtcp_file;
			
				/* Open the stream with caching if it is DTCP, because we seek a lot during parsing */
				app_params->stream_opts.http_flags |=  RM_HTTP_OPEN_CACHED;
				dtcp_file = open_stream(play_opt->filename, RM_FILE_OPEN_READ, &app_params->stream_opts);
				if (dtcp_file == NULL) {
					RMDBGLOG((ENABLE, "Cannot open file %s\n", play_opt->filename));
					break;
				}
				parse_avi(dtcp_file, &context);
				RMCloseFile(dtcp_file);
				
			}
			/* #### End DTCP code #### */
	
			if (context.packed) {
				RMDBGLOG((ENABLE, "PACKED!!     version %lu, build %lu\n", context.version, context.build));
				video_opt->skipNCP = TRUE;
			}
			else {
				RMDBGLOG((ENABLE, "NOT PACKED!! version %lu, build %lu\n", context.version, context.build));
				video_opt->skipNCP = FALSE;
			}

		}

		{
			struct RM_Detection_Specific_Info specificInfo;

			err = RMFGetSystemSpecificInfo(detector, RM_SYSTEM_AVI, &specificInfo);
			if (err != RM_OK) {
				RMDBGLOG((ENABLE, "error getting specific information!\n"));
				ERROR_CLEANUP(-1);
			}


			stream_info->video_type = specificInfo.data.avi.videoType;

			if ((stream_info->video_type == RM_VIDEO_H264) ||
			    (stream_info->video_type == RM_VIDEO_MPEG4) ||
			    (stream_info->video_type == RM_VIDEO_XVID) ||
			    (stream_info->video_type == RM_VIDEO_VC1)) {
				RMDBGLOG((ENABLE, "dont send mpeg4/h264/vc1 pts\n"));
				play_opt->dontSendMPEG4pts = TRUE;
			}

			if(VideoFormatToCodec(stream_info->video_type, video_opt, detect_opt)){
				RMDBGLOG((LOCALDBG, "DETECTOR_SYSTEM_AVI (%ld)\n", type));
				stream_info->system_type = RM_SYSTEM_AVI;
			}
			else{
				RMDBGLOG((ENABLE, "Found SYSTEM_AVI, but the video codec is unsupported\n"));
			}
			break;
		}
		break;
	case DETECTOR_SYSTEM_ASF: /* -9 */
		fprintf(stderr, "asf\n");
		RMDBGLOG((LOCALDBG, "DETECTOR_SYSTEM_ASF (%ld)\n", type));
		stream_info->system_type = RM_SYSTEM_ASF;
		break;
	case DETECTOR_PICTURE_JPEG:
		fprintf(stderr, "jpg\n");
		app_params->osd_scaler = 2;
		RMDBGLOG((LOCALDBG, "Picture (%ld)\n", type));
		stream_info->system_type = RM_SYSTEM_ELEMENTARY_VIDEO;
		stream_info->video_type = RM_VIDEO_JPEG;
		VideoFormatToCodec(stream_info->video_type, video_opt, detect_opt);
		{
			RMuint32 width = 0;
			RMuint32 height = 0;
			enum PictureOrientation orientation = 0;
			RMuint32 profile = EMhwlib_JPEG_Invalid_Profile;
			err = detect_jpeg_header_info(file, &width, &height, &profile, &orientation);
			if(RMFAILED(err)){ 
				RMDBGLOG((ENABLE, "Picture detect_jpeg_header_info failed, use default jpeg parameters\n"));
			}
			// if not changed by the detect functions, give them some default value
			if( profile == EMhwlib_JPEG_Invalid_Profile ) {
				RMDBGLOG((ENABLE, "Invalid jpeg profile 0x%lx\n", profile ));
			}
			video_opt->vcodec_profile = profile;
			if( profile == EMhwlib_JPEG_444_Profile ) {
				video_opt->vcodec_profile = EMhwlib_JPEG_Invalid_Profile;
				RMDBGLOG((ENABLE, "Not supporting jpeg 444 profile, set to invalid 0x%lx\n", video_opt->vcodec_profile ));
			}
			if( orientation == 0 )
				video_opt->vcodec_orientation = 1; //no rotation
			else
				video_opt->vcodec_orientation = (RMuint32)orientation;
			if( height == 0 )
				video_opt->vcodec_max_height = 2448;
			else
				video_opt->vcodec_max_height = height;  // use the dimension stored in jpeg header
			if( width == 0 )
				video_opt->vcodec_max_width = 3264;
			else
				video_opt->vcodec_max_width = width;
			video_opt->vcodec_extra_pictures = -2;  // not to allocate the extra picture buffer for jpeg
			RMDBGLOG((LOCALDBG, "Picture W %d H %d Profile %d Orientation %d\n", video_opt->vcodec_max_width, video_opt->vcodec_max_height, video_opt->vcodec_profile, video_opt->vcodec_orientation ));
		}
		break;
	case DETECTOR_PICTURE_BMP:
		fprintf(stderr, "bmp\n");
		stream_info->system_type = RM_SYSTEM_ELEMENTARY_VIDEO;
		app_params->osd_scaler = 0;
		RMDBGLOG((LOCALDBG, "Picture (%ld)\n", type));
		stream_info->video_type = RM_VIDEO_BMP;
		break;
	case DETECTOR_PICTURE_TIFF:
		fprintf(stderr, "tiff\n");
		stream_info->video_type = RM_VIDEO_TIFF;

		stream_info->system_type = RM_SYSTEM_ELEMENTARY_VIDEO;
		app_params->osd_scaler = 0;
		RMDBGLOG((LOCALDBG, "Picture (%ld)\n", type));
		break;
	case DETECTOR_PICTURE_GIF:
		fprintf(stderr, "gif\n");
		stream_info->video_type = RM_VIDEO_GIF;
		stream_info->system_type = RM_SYSTEM_ELEMENTARY_VIDEO;
		app_params->osd_scaler = 0;
		RMDBGLOG((LOCALDBG, "Picture (%ld)\n", type));
		break;
	case DETECTOR_PICTURE_PNG:
		fprintf(stderr, "png\n");
		stream_info->video_type = RM_VIDEO_PNG;
		stream_info->system_type = RM_SYSTEM_ELEMENTARY_VIDEO;
		app_params->osd_scaler = 0;
		RMDBGLOG((LOCALDBG, "Picture (%ld)\n", type));
		break;
	case DETECTOR_SYSTEM_MP4:
		fprintf(stderr, "mp4\n");
		RMDBGLOG((LOCALDBG, "DETECTOR_SYSTEM_MP4 (%ld)\n", type));
		stream_info->system_type = RM_SYSTEM_MPEG4;
		break;
	case DETECTOR_SYSTEM_RIFFCDXA:
		fprintf(stderr, "riff/cdxa, format not supported\n");
		break;
 	case DETECTOR_TYPE_UNKNOWN:
	default:
		fprintf(stderr, "unknown type!\n");
		RMDBGLOG((LOCALDBG, "unknown type!\n"));
		break;

	}
	
	if((stream_info->system_type == RM_SYSTEM_MPEG1) ||
	   (stream_info->system_type == RM_SYSTEM_MPEG2_PROGRAM) ||
	   (stream_info->system_type == RM_SYSTEM_MPEG2_TRANSPORT_192) ||
	   (stream_info->system_type == RM_SYSTEM_MPEG2_TRANSPORT) ||
	   (stream_info->system_type == RM_SYSTEM_MPEG2_PROGRAM) ||
	   (stream_info->system_type == RM_SYSTEM_MPEG2_DVD)){
		RMint32 index;
		RMuint32 i, numStreams, count, streamType;
		RMuint16 pid;
		RMuint8 buf[512], subId;
		RMbool got_audio = FALSE, got_video = FALSE;
		ExternalRMvdemux demux;
		struct detection_callback_info detection_info = { 0, };

		/* takes only the first audio and the first video */
		demux_opt->video_pid = 0;
		demux_opt->audio_pid = 0;
		demux_opt->audio_subid = 0;
		demux_opt->spu_subid = 0;
		demux_opt->data_type = 0;
		demux_opt->xfer_count = 0; /* let the application set this */
		demux_opt->fifo_size = 0;  /* let the application set this */

		
		if (demux_opt->system_type != RM_SYSTEM_UNKNOWN) {
			err = RMCreateVdemux(&demux);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot create demux %d\n", err));
				ERROR_CLEANUP(-1);
			}
			RMvdemuxSetType(demux, demux_opt->system_type);
		}
		RMvdemuxReset(demux);
		RMvdemuxSetVideoStream(demux, 0, 0);
		RMvdemuxSetAudioStream(demux, 0, 0);
		RMvdemuxSetCallbackData(demux, DetectionPESCallback, &(detection_info));
		RMvdemuxSetAudioCallbacks(demux, NULL, LPCMCallback, NULL, NULL);

		detection_info.detector = detector;
		detection_info.last_pts = 0;
		detection_info.first_pts = (RMuint64)-1;
		detection_info.audio_detected = FALSE;
		detection_info.pcm_detected = FALSE;

		RMFDetectorReset(detection_info.detector);

		if (RMSeekFile(file, 0 , RM_FILE_SEEK_START) != RM_OK) {
			RMDBGLOG((ENABLE, "Error seeking file\n"));
			ERROR_CLEANUP(-1);
		}

		index = 0;
		numStreams = 0;

		/* parse at least 16*512 bytes to make sure we get a PMT */
		/* todo: make this cleaner */
		while (((!detection_info.audio_detected) || (index < 16) || (numStreams<2)) 
			&& (index < 16384)) {
			err = RMReadFile(file, buf, 512, &count);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error reading file %s", RMstatusToString(err)));
				break;
			}
			RMvdemuxDemux(demux, buf, count);
			RMvdemuxGetNumberOfStreams(demux, &numStreams);
			index++;
		}

		for(i = 0; i< numStreams; i++){
			RMvdemuxGetStreamType(demux, i, &pid, &subId,  &streamType);
			fprintf(stderr, "stream %lu/%lu (pid %3lu [0x%02lx] subId %3lu [0x%02lx] type %3lu [0x%02lx])\n", 
				i, 
				numStreams-1,
				(RMuint32)pid,
				(RMuint32)pid,
				(RMuint32)subId,
				(RMuint32)subId,
				(RMuint32)streamType,
				(RMuint32)streamType);
			switch(streamType){
			case STREAM_TYPE_PCM:
			case STREAM_TYPE_AOB_PCM:
				if((!got_audio) && detection_info.pcm_detected){
					fprintf(stderr, "system audio pcm\n");
					detection_info.audio_type = eAudioFormat_PCM;
					demux_opt->audio_subid = 0x7 & subId;
					audio_opt->SubCodec = 1;
					audio_opt->SamplingFrequency = detection_info.audio_freq;
					audio_opt->LpcmVobParams.ChannelAssign = LpcmVob2_LR;
					audio_opt->LpcmVobParams.BitsPerSample = detection_info.audio_depth;
					switch(detection_info.audio_channels){
					case 1:
						audio_opt->PcmCdaParams.ChannelAssign = LpcmVob1_C;
						audio_opt->OutputDualMode = DualMode_MixMono;
						break;
					case 2:
						audio_opt->PcmCdaParams.ChannelAssign = LpcmVob2_LR;
						audio_opt->OutputDualMode = DualMode_Stereo;
						break;
					}
					RMDBGLOG((LOCALDBG, "Setting audio frequency to %ld\n", audio_opt->SampleRate));
					got_audio = TRUE;
				}
				else
					fprintf(stderr, "ignore this audio stream, another one was already found\n");
				break;
			case STREAM_TYPE_MPEG1_VIDEO:
			case STREAM_TYPE_MPEG2_VIDEO:
				fprintf(stderr, "system video mpeg12\n");
				if (!got_video) {
					VideoFormatToCodec(RM_VIDEO_MPEG12, video_opt, detect_opt);
					stream_info->video_type = RM_VIDEO_MPEG12;
				}
				else
					fprintf(stderr, "ignore this video stream, another one was already found (type %lu)\n", (RMuint32)stream_info->video_type);

				got_video = TRUE;
				break;
			case STREAM_TYPE_MPEG4_VIDEO:
				fprintf(stderr, "system video mpeg4\n");
				if (!got_video) {
					VideoFormatToCodec(RM_VIDEO_MPEG4, video_opt, detect_opt);
					stream_info->video_type = RM_VIDEO_MPEG4;
				}
				else
					fprintf(stderr, "ignore this video stream, another one was already found (type %lu)\n", (RMuint32)stream_info->video_type);

				got_video = TRUE;
				break;
			case STREAM_TYPE_H264_VIDEO:
				fprintf(stderr, "system video h264\n");
				if (!got_video) {
					VideoFormatToCodec(RM_VIDEO_H264, video_opt, detect_opt);
					stream_info->video_type = RM_VIDEO_H264;
				}
				else
					fprintf(stderr, "ignore this video stream, another one was already found (type %lu)\n", (RMuint32)stream_info->video_type);

				got_video = TRUE;
				break;
			case STREAM_TYPE_VC1_VIDEO:
				fprintf(stderr, "system video vc1\n");
				if (!got_video) {
					VideoFormatToCodec(RM_VIDEO_VC1, video_opt, detect_opt);
					stream_info->video_type = RM_VIDEO_VC1;
				}
				else
					fprintf(stderr, "ignore this video stream, another one was already found (type %lu)\n", (RMuint32)stream_info->video_type);

				got_video = TRUE;
				break;
			case STREAM_TYPE_AC3:
			case STREAM_TYPE_DTS:
				fprintf(stderr, "system audio %s\n", (streamType==STREAM_TYPE_AC3)?"ac3":"dts");

				if (!got_audio) {
					
					/*take three last bits of substream for audio_subid*/
					demux_opt->audio_subid = 0x7 & subId;
					//detection_info.audio_type = (streamType==STREAM_TYPE_AC3)?eAudioFormat_AC3:eAudioFormat_DTS;

					if(app_params->noDolby){
						RMDBGLOG((ENABLE, "NO DOLBY\n"));
						audio_opt->Spdif = OutputSpdif_NoDecodeCompressed;
					}
					got_audio = TRUE;
				}
				else
					fprintf(stderr, "ignore this audio stream, another one was already found\n");
				break;
			case STREAM_TYPE_MPEG4_AUDIO:
				fprintf(stderr, "system audio latm\n");

				detection_info.audio_type = eAudioFormat_AAC_LATM;
				demux_opt->audio_subid = 0x7 & subId;

				got_audio = TRUE;

				//RMDBGLOG((LOCALDBG, "Found LATM audio stream on pid %d. This format is unsupported.\n", pid));
				break;
			case STREAM_TYPE_AAC_ADTS:
				fprintf(stderr, "system audio aac_adts\n");

				if (!got_audio) {
					struct RM_Detection_Specific_Info specificInfo;

					err = RMFGetAudioSpecificInfo(detector, eAudioFormat_AAC_ADTS, &specificInfo);
					if (err != RM_OK) {
						RMDBGLOG((ENABLE, "error getting specific information!\n"));
						ERROR_CLEANUP(-1);
					}

					if (specificInfo.audioType == eAudioFormat_AAC_ADTS) {
						bitrate = 0;
						frequency = specificInfo.data.adts.sampleRate;
						channel_count = specificInfo.data.adts.channels;
					
						detection_info.audio_type = eAudioFormat_AAC_ADTS;
						
						detection_info.audio_freq = frequency;
						RMDBGLOG((LOCALDBG, "Audio is AAC_ADTS: Setting audio frequency to %ld\n", detection_info.audio_freq));
						got_audio = TRUE;
					}
				}
				else
					fprintf(stderr, "ignore this audio stream, another one was already found\n");

 				break;
			case STREAM_TYPE_MPEG1_AUDIO:		
				fprintf(stderr, "system audio mpeg1\n");
				if (!got_audio) {
					detection_info.audio_type = eAudioFormat_MPEG1;
					demux_opt->audio_subid = 0x7 & subId;
					got_audio = TRUE;
				}
				else
					fprintf(stderr, "ignore this audio stream, another one was already found\n");

				break;
			case STREAM_TYPE_MPEG2_AUDIO:
				fprintf(stderr, "system audio mpeg2\n");
				if (!got_audio) {
					detection_info.audio_type = eAudioFormat_MPEG2;
					demux_opt->audio_subid = 0x7 & subId;
					got_audio = TRUE;
				}
				else
					fprintf(stderr, "ignore this audio stream, another one was already found\n");

				break;
			case STREAM_TYPE_RESERVED:
			case STREAM_TYPE_MPEG2_PRIVATE:		
			case STREAM_TYPE_MPEG2_PES_PRIVATE:		
			case STREAM_TYPE_MHEG:		
			case STREAM_TYPE_DSMCC:		
			case STREAM_TYPE_H222:		
			case STREAM_TYPE_DSMCC_A:		
			case STREAM_TYPE_DSMCC_B:		
			case STREAM_TYPE_DSMCC_C:		
			case STREAM_TYPE_DSMCC_D:		
			case STREAM_TYPE_MPEG1_AUX:		
			case STREAM_TYPE_FLEXMUX_PES:		
			case STREAM_TYPE_FLEXMUX_SYSTEM:		
			case STREAM_TYPE_DSMCC_SDP:		
			case STREAM_TYPE_SUBPICTURE:		
			case STREAM_TYPE_NAVIGATION:		
			case STREAM_TYPE_MLP:		
				fprintf(stderr, "system: unsupported stream\n");
				RMDBGLOG((ENABLE, "Found unsupported stream on pid %d\n", pid));
				break;
			}
		}
		
		if(!got_video){
			RMDBGLOG((ENABLE, "Did not find an MPEG1, MPEG2 or MPEG4 video stream\n"));
			ERROR_CLEANUP(-1);
		}

		if (got_audio)
			detection_info.audio_detected = TRUE;

		if(detection_info.audio_detected && AudioFormatToCodec(detection_info.audio_type, audio_opt)){
			stream_info->audio_type = detection_info.audio_type;
			audio_opt->SampleRate = detection_info.audio_freq;
			audio_opt->ForceSampleRate = TRUE;
			RMDBGLOG((LOCALDBG, "Setting audio frequency to %ld\n", audio_opt->SampleRate));
		}
		else{
			play_opt->send_audio = FALSE;
			fprintf(stderr, "Audio stream not found (sending only video)\n");
		}
		
		index = 0;
		detection_info.last_pts = 0;
		while ((detection_info.last_pts == 0) && (index < 512)) {
			RMuint32 parsed_bytes;
			index ++;
			RMvdemuxResetState(demux);

			if (RMSeekFile(file, -262144*index, RM_FILE_SEEK_END) != RM_OK) {
				RMDBGLOG((ENABLE, "error seeking file to the last %ld K\n", index*64));
				break;
			}
			parsed_bytes = 0;
			while (1) {
				err = RMReadFile(file, buf, 512, &count);
				
				if (err == RM_ERRORREADFILE) {
					RMDBGLOG((ENABLE, "Error reading file %d", err));
					detection_info.last_pts = 0;
					break;
				}
				
				if (err == RM_ERRORENDOFFILE) {
					break;
				}
				
				RMvdemuxDemux(demux, buf, count);
				parsed_bytes += count;
				if(parsed_bytes > 262144){
					break;
				}
				
			}
			RMFDetectorReset(detection_info.detector);
		}
		
		if(detection_info.last_pts == 0) {
			RMDBGLOG((ENABLE, "Could not find last valid PTS!!\n"));
			detection_info.first_pts = 0;
		}
		play_opt->duration = (detection_info.last_pts - detection_info.first_pts)/90;
		RMDBGLOG((LOCALDBG, "Detected duration is %lld [ms](first pts %lld - last pts %lld)\n", 
			  play_opt->duration, 
			  detection_info.first_pts,
			  detection_info.last_pts ));

		if (play_opt->duration) {
			video_opt->first_pts_in_stream = detection_info.first_pts / 90;
			RMDBGLOG((LOCALDBG, "first_pts_in_stream %lld [ms]\n", video_opt->first_pts_in_stream));
		}

		err = RMDeleteVdemux(demux);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot delete demux %d\n", err));
			ERROR_CLEANUP(-1);
		}
			
	}

	if (stream_info->system_type == RM_SYSTEM_ASF) {
		err = detect_asf_duration(file, &play_opt->duration);
		if (err != RM_OK) {
			RMDBGLOG((ENABLE, "error getting asf duration\n"));
		}
		RMDBGLOG((ENABLE, "ASF Detected duration is %lld [ms]\n", play_opt->duration));
	}
	
	if(app)
		*app = get_app_from_stream_info(stream_info);	

 cleanup:
	if (detector)
		RMFDetectorDestruct(detector);

	if(error)
		return RM_ERROR;

	return RM_OK;
}


RMstatus rfp_play(struct mono_info *app_params, enum rfp_application app)
{
	RMint32 error = 0;

	struct playback_cmdline local_play_opt;
	struct video_cmdline local_video_opt;
	struct audio_cmdline local_audio_opt[MAX_AUDIO_DECODER_INSTANCES];
	struct demux_cmdline local_demux_opt;
	struct mono_info local_app_params;

	// copy app_params

	if (app_params->play_opt)
		RMMemcpy(&local_play_opt, app_params->play_opt, sizeof(local_play_opt));

	if (app_params->demux_opt)
		RMMemcpy(&local_demux_opt, app_params->demux_opt, sizeof(local_demux_opt));

	if (app_params->audio_opt)
		RMMemcpy(&local_audio_opt, app_params->audio_opt, sizeof(local_audio_opt));

	if (app_params->video_opt) 
		RMMemcpy(&local_video_opt, app_params->video_opt, sizeof(local_video_opt));

	if (app_params)
		RMMemcpy(&local_app_params, app_params, sizeof(local_app_params));

	/* de-activate closed caption if not supported by the app */
	if((app != APP_DEMUX) && 
	   (app != APP_DEMUX_SOFT) && 
	   (app != APP_VIDEO)){
		app_params->video_opt->display_cc = FALSE;
	}

	/* a quick and dirty change to swtich to software jpeg, shall be removed when jpeg 444 support is up*/
	if( app == APP_VIDEO && app_params->video_opt->vcodec_profile == EMhwlib_JPEG_Invalid_Profile ) {  
		RMDBGLOG((ENABLE, "Unsupported picture format, use software decoder\n"));
		app = APP_PICTURE;
	}

	switch(app){
	case APP_DEMUX:
		RMDBGLOG((LOCALDBG, "calling psf hw demux\n"));
		display_key_usage(AUDIO_VIDEO_KEYFLAGS);
		error = (RMint32)main_psfdemux(app_params);
		break;
	case APP_DEMUX_SOFT:
		RMDBGLOG((LOCALDBG, "calling soft demux\n"));
		display_key_usage(AUDIO_VIDEO_KEYFLAGS);
		error = (RMint32)main_demux(app_params);
		break;
	case APP_VIDEO:
		RMDBGLOG((LOCALDBG, "calling video\n"));
		display_key_usage(VIDEO_KEYFLAGS);
		error = (RMint32)main_video(app_params);
		break;
	case APP_AUDIO:
 		RMDBGLOG((LOCALDBG, "calling audio\n"));
		display_key_usage(AUDIO_KEYFLAGS);
		error = (RMint32)main_audio(app_params);
		break;
	case APP_PICTURE:
		RMDBGLOG((LOCALDBG, "calling picture\n"));
		display_key_usage(VIDEO_KEYFLAGS);
		error = (RMint32)main_picture(app_params);
		if(error && (app_params->osd_scaler != 0)){
			app_params->osd_scaler = 0;
			error = (RMint32)main_picture(app_params);
		}
		break;
	case APP_AVI:
		RMDBGLOG((LOCALDBG, "calling avi push\n"));
		display_key_usage(AUDIO_VIDEO_KEYFLAGS);
		error = (RMint32)main_avi_push(app_params);
		break;
	case APP_AVI_PULL:
		RMDBGLOG((ENABLE, "AVI DEMUX PULL MODEL IS NOT SUPPORTED\n"));
		return RM_ERROR;
	case APP_ASF:
		RMDBGLOG((LOCALDBG, "calling asf\n"));
		display_key_usage(AUDIO_VIDEO_KEYFLAGS);
		error = (RMint32)main_asf(app_params);
		break;
	case APP_MP4:
		RMDBGLOG((LOCALDBG, "calling mp4\n"));
		display_key_usage(AUDIO_VIDEO_KEYFLAGS);
		error = (RMint32)main_mp4(app_params);
		break;
	case NOT_SUPPORTED:
		// params haven't been changed so no need to restore them
		return RM_ERROR;
	}
	
	// restore app_params

	if (app_params->play_opt)
		RMMemcpy(app_params->play_opt, &local_play_opt, sizeof(local_play_opt));

	if (app_params->demux_opt)
		RMMemcpy(app_params->demux_opt, &local_demux_opt, sizeof(local_demux_opt));

	if (app_params->audio_opt)
		RMMemcpy(app_params->audio_opt, &local_audio_opt, sizeof(local_audio_opt));

	if (app_params->video_opt)
		RMMemcpy(app_params->video_opt, &local_video_opt, sizeof(local_video_opt));

	if (app_params)
		RMMemcpy(app_params, &local_app_params, sizeof(local_app_params));


	if (error > 0)
		return error;
	else if (error < 0)
		return RM_ERROR;
	else
		return RM_OK;
	
}

RMstatus play_file(struct mono_info *app_params, struct player_options *player_conf)
{
	RMstatus status;
	struct rfp_detect_options detect_opt;
	enum rfp_application app;
	struct rfp_stream_info stream_info;
	/* #### Begin CARDEA code #### */
	{
		if (  find_cardea_url(app_params->play_opt->filename) != NULL ){
			RMDBGLOG((LOCALDBG,"Playing cardea file, skip detection ... (only ASF supported).\n"));
			app = APP_ASF;
			goto skip_detection;
		}
	}
	/* #### End CARDEA code #### */

 
	/* keep compatibility with deprecated player_conf struct */
	detect_opt.force_sd = player_conf->forceSD;

	status = rfp_detect(app_params, &detect_opt, &app, &stream_info);
	if(RMFAILED(status)){
		RMDBGLOG((ENABLE, "Detection failed\n"));
		return status;
	}

	/* keep compatibility with old player_conf struct */
	if((app == APP_DEMUX) && (!player_conf->use_hwdemux)){
		app = APP_DEMUX_SOFT;
	}

	if((app == APP_AVI) && (!player_conf->use_avi_push)){
		app = APP_AVI_PULL;
	}


	/* #### Begin CARDEA code #### */
 skip_detection:
	/* #### End CARDEA code #### */

	status = rfp_play(app_params, app);
	if(RMFAILED(status)){
		RMDBGLOG((ENABLE, "Playback failed\n"));
		return status;
	}

	return RM_OK;
}

