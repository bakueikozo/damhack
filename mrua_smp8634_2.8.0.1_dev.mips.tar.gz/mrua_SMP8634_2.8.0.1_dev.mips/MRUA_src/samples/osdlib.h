/*
 *
 * Copyright (c) Sigma Designs, Inc. 2003. All rights reserved.
 *
 */

/**
 * @file osdbuf_control.h
 * @brief basic types and enums to handle OSD buffers on 86XX
 * 
 * @author Julien Lerouge
 */

#ifndef __OSDLIB_H__
#define __OSDLIB_H__

#define BASE_PALETTE 0x79000	//Base address of the palette in DRAM

#define OSD_CREATE 	0x00000001
#define OSD_SET_FORMAT 	0x00000002
#define OSD_SET_CSC    	0x00000004
#define OSD_GET_PARAMS 	0x00000008
#define OSD_DEL    	0x00000010
#define OSD_GET_INFOS  	0x00000020
#define OSD_SET_KCOLOR 	0x00000040
#define OSD_SET_ADAPT 	0x00000080
#define OSD_SET_TAPS 	0x00000100
#define OSD_SET_ANTIF 	0x00000200
#define OSD_SET_A0 	0x00000400
#define OSD_SET_A1 	0x00000800
#define OSD_SET_FADING 	0x00001000
#define OSD_SET_OUTPUT 	0x00002000
#define OSD_BIND_FB	0x00004000
#define OSD_UNBIND_FB	0x00008000

#include "../rua/include/rua.h"
#include "../dcc/include/dcc.h"
#include "common.h"

struct osd_format_string_s {
	RMascii *name;
	RMascii *comment;
};

/* Helper structure to handle everything */
struct osd_descriptor{
	RMuint32 bpp;
	RMuint32 LumaAddr, LumaSize;
	RMuint32 ChromaAddr, ChromaSize;
	struct DCCOSDProfile profile;
	struct DispOSDScaler_ScalingConfig_type scaling_config;
	struct dcc_context dcc_info;
	struct EMhwlibKeyColor kcolor;
	struct EMhwlibDisplayWindow input_window;
	RMuint32 alpha0, alpha1;
	RMbool fading;
	RMuint32 chip_num;
	RMascii *fb;
};

struct osd_rectangle{                            //Simple rectangle				 
	RMuint32 x;
	RMuint32 y;
	RMuint32 width;
	RMuint32 height;
};
				
#define CROP(v,max)  if ((v) > (max)) (v) = (max) 
#define CROPV(v,max) (v) > (max) ? (max) : (v) 


/** Print infos on the given OSD
 * @param p_osd - filled osd_descriptor
 * @return void
 */
void print_osd_full_info(struct osd_descriptor *p_osd);

/** Get the BPP corresponding to one mode:submode 
 * @param osd_format
 * @param osd_subformat
 * @return bpp 0 on error
 */
RMuint32 get_osd_bpp(RMuint32 osd_format, RMuint32 osd_subformat);

/** Get current OSD buffer info, store it in p_osd
 * @param p_rua - rua handle
 * @param p_osd - table where to store info
 * @return RMstatus
 */
RMstatus get_osd_infos(struct osd_descriptor *p_osd);


/** Unregister the current OSD
 * @param p_rua - rua handle
 * @return RMstatus RM_OK on success
 */
//RMstatus del_current_osd(struct RUA *p_rua);

/** Create a new OSD Buffer
 * @param p_osd osd_descriptor of the buffer to create
 * @return RM_OK on success
 */
RMstatus create_osd_buf(struct osd_descriptor *p_osd);

/** Put an osd buffer on screen 
 * @param p_rua - rua handle
 * @param p_osd - osd to setup (format, size, start addreess, width and height should be setup)
 * @param standard - TV standard
 * @param output - TV outpout to use
 * @param mixer - mixer to use
 * @param scaler - scaler to use
 * @return RM_OK on success
 */
//RMstatus init_display_osd(struct RUA *p_rua, struct osd_descriptor *p_osd, enum TVStandard standard, 
//TV_Output output, RMuint32 mixer, RMuint32 scaler);

/** Helpers functions to convert format or csc strings to format or csc*/
RMuint32 get_osd_color_mode(RMascii *m_osd_format_string, RMuint32 *osd_color_mode);
RMuint32 get_osd_csc(RMascii *m_csc_string, RMuint32 *osd_csc_index);
RMuint32 get_osd_color_format(RMascii *m_osd_subformat_string, RMuint32 *osd_color_format);


/** Set palette entry for OSD to 0xaarrggbb
 * @param p_osd - osd descriptor, should be initialized
 * @param i - palette entry index
 * @param r,g,b 
 * @return RM_OK upon success
 */
RMstatus set_osdbuf_palette(struct osd_descriptor *p_osd, RMuint32 i, RMascii r, 
			    RMascii g, RMascii b, RMascii alpha);

/** Set a pixel on the OSD
 * @param p_osd - osd descriptor, should be initialized (at least widht, height, bpp)
 * @param base_addr - user space addr where osd buffer is mapped
 * @param x,y - pixel position
 * @param data - data to write (lut index if lut mode, pixel data otherwise)
 */
void osdbuf_set_pixel(struct osd_descriptor *p_osd, RMuint8 *base_addr, RMuint32 x, RMuint32 y, RMuint32 data);

/** Get a pixel on the OSD
 * @param p_osd - osd descriptor, should be initialized (at least widht, height, bpp)
 * @param base_addr - user space addr where osd buffer is mapped
 * @param x,y - pixel position
 * @return RMuint32 - pixel value
 */
RMuint32 osdbuf_get_pixel(struct osd_descriptor *p_osd, RMuint8 *base_addr, RMuint32 x, RMuint32 y);

/** Draw an horizontal line from (x,y)
 * @param p_osd - osd descriptor, should be initialized (at least widht, height, bpp)
 * @param base_addr - user space addr where osd buffer is mapped
 * @param x,y - pixel position
 * @param size
 * @param data - data to write, color or lut index
 */
//void osd_draw_horizontal_line(struct osd_descriptor *p_osd, RMuint8 *base_addr, RMuint32 x, RMuint32 y, 
//                               RMuint32 size, RMuint32 data);


/** Draw a vertical line from (x,y)
 * @param p_osd - osd descriptor, should be initialized (at least widht, height, bpp)
 * @param base_addr - user space addr where osd buffer is mapped
 * @param x,y - pixel position
 * @param size
 * @param data - data to write, color or lut index
 */
//void osd_draw_vertical_line(struct osd_descriptor *p_osd, RMuint8 *base_addr, RMuint32 x, RMuint32 y, 
//                            RMuint32 size, RMuint32 data);


/** Draw a rectanlge at (x,y)
 * @param p_osd - osd descriptor, should be initialized (at least widht, height, bpp)
 * @param base_addr - user space addr where osd buffer is mapped
 * @param rect - rect to draw
 * @param data - data to write, color or lut index
 * @param fill - true to fill the rectangle
 */
//void osd_draw_rectangle(struct osd_descriptor *p_osd, RMuint8 *base_addr, struct osd_rectangle *rect, 
//                        RMuint32 data, RMbool fill);

/** Change the size of rectanlge at (x,y)
 * @param p_osd - osd descriptor, should be initialized (at least widht, height, bpp)
 * @param base_addr - user space addr where osd buffer is mapped
 * @param old_rect - old rectangle to resize
 * @param new_rect - new rectangle 
 * @param erase_data - data to put in erased zones
 */
//void osd_change_rectangle_size(struct osd_descriptor *p_osd, RMuint8 *base_addr, struct osd_rectangle *old_rect, 
//                               struct osd_rectangle *new_rect, RMuint8 erase_data);

/** Clear a non mapped OSD buffer
 * @param  p_osd - osd descriptor
 * @return RMstatus, RM_OK upon success
 */
RMstatus clear_osdbuf(struct osd_descriptor *p_osd);


/** Enable/Disable an OSD mapping a graphic frame buffer
 * @param p_rua - rua handle
 * @param enable - enable or disable
 * @return RM_OK on success
 */
RMstatus set_osdbuf_out_enable(struct RUA *p_rua, RMbool enable);

#endif //__OSDLIB_H__
