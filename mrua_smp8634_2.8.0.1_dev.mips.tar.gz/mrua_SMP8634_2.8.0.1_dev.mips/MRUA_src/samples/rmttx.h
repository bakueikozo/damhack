

/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
*****************************************/


#ifndef _RMTTX_H_
#define _RMTTX_H_

#define RMTTX_BUFFER_SIZE 0x1000

// RMttx represents a ttx decoder
// It extract EBU teletext data from TTX stram
// TTX data is demultiplexed by the demux and passed to this module in the form of
// pes packet.  This ttx decoder decode the PES, extract the data and PTS
// and push data into the TTXFifo in the emhwlib
struct RMttx {
	struct RUA * pRUA;  // so this modules can open hw modules
	RMuint32 fifo_module_id;
	RMuint32 module_address;
	RMuint32 module_size;
	RMuint32 bts_byte_count;  // byte count of data coming out of demux
	RMuint8 * decode_buffer;
	RMuint32 decode_buffer_size;
	struct EMhwlibTTXPicture current_ttx;
};

struct RMttx * RMTTXOpen( struct RUA * pRUA, RMuint32 fifo_module_id, RMuint32 ttx_fifo_size );
	// create a ttx decoder
	
void RMTTXClose( struct RMttx* ttx);  
	// destory the ttx decoder
	
void RMTTXFlush( struct RMttx* ttx );
	// clear buffers in the decoder and connecting ttx fifo (in emhwlib)

RMstatus RMTTXDecode(struct RMttx* ttx,  RMuint8* buf, RMuint32 size );  
	// parse the demux output buffer and add to the fifo
	// this function has to be called periodically whenever a buffer is available

#endif // #ifndef _RMTTX_H_

