/*****************************************
 Copyright � 2001-2005  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   spuapi.h
  @brief  Nero Digital SPU API

  @author Sebastian Frias Feltrer
  @date   2005-08-11
*/

#ifndef __NERO_SPU_API_H__
#define __NERO_SPU_API_H__

#include "../rmdef/rmdef.h"
#include "../rmproperties/include/rmexternalproperties.h"


typedef void *RMNeroSPUDecoderHandle;

typedef struct {
    RMuint8   Alpha;
    RMuint8   Y;
    RMuint8   Cb;
    RMuint8   Cr;
} RMspuPalette_AYUV;

typedef struct {
	RMuint8 *pData[4];
	RMint32	width;
	RMint32	height;
} RMspuFrame;


RMNeroSPUDecoderHandle RMOpenNeroSPUDecoder(RMuint32 width, RMuint32 height, RMspuPalette_AYUV *palette, RMuint8 *buffer);
void RMCloseNeroSPUDecoder(RMNeroSPUDecoderHandle pDecoder);
RMstatus RMNeroSPUDecoderProcessSample(RMNeroSPUDecoderHandle pDecoder, RMuint8 *data, RMuint32 len, RMuint64 pts, RMuint32 flags);
RMstatus RMNeroSPUDecoderReset(RMNeroSPUDecoderHandle pDecoder);
RMstatus RMNeroSPUDecoderSetStatus(RMNeroSPUDecoderHandle pDecoder, RMbool state);
RMbool RMNeroSPUDecoderBlend(RMNeroSPUDecoderHandle pDecoder, RMspuFrame **frame, RMuint64 time);






#endif // __NERO_SPU_API_H__
