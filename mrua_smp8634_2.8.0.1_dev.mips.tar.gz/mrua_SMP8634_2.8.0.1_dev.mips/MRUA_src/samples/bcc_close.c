#include "bcc.h"

#include "ccparse.h"

#include "rua/include/rua_property.h"
#include "rmdef/rmdef.h"

#define DEBUG	ENABLE

static RMstatus destroy_bcc_parser(struct bcc *);
static RMstatus close_cc_fifo     (struct bcc *, struct RUA *);

RMstatus bcc_close(struct bcc *pbcc, struct RUA *pRUA)
{
	RMstatus status = RM_OK;

	if (RMFAILED((status = destroy_bcc_parser(pbcc))))
	{
		RMDBGLOG((ENABLE, "Failed to destroy the BCC parser.\n"));
	}
	if (RMFAILED((status = close_cc_fifo(pbcc, pRUA))))
	{
		RMDBGLOG((ENABLE, "Failed to close CC fifo.\n"));
	}
	
	return status;
}

static RMstatus destroy_bcc_parser(struct bcc *pbcc)
{
	RMstatus status = RM_OK;
	
	if (RMFAILED((status = rmbcc_close(pbcc->bcc_parser))))
	{
		RMDBGLOG((ENABLE, "Error %s: failed to close BCC parser!\n"
				"Destroying anyways.\n", RMstatusToString(status)));
	}
	if (RMFAILED((status = rmbcc_destroy(pbcc->bcc_parser))))
	{
		RMDBGLOG((ENABLE, "Error %s: failed to destroy BCC parser!\n",
				RMstatusToString(status)));
	}
	
	return status;
}

static RMstatus close_cc_fifo(struct bcc *pbcc, struct RUA *pRUA)
{
	RMstatus status = RM_OK;

	while (RM_PENDING == (status = RUASetProperty(pRUA, pbcc->ccfifo_id, 
			RMCCFifoPropertyID_Clear, NULL, 0, 0)));
	if (RMFAILED(status))
	{
		RMDBGLOG((ENABLE, "Error %s: cannot clear CC fifo.\n"
				"Closing anyways.\n", RMstatusToString(status)));
	}
	while ((status = RUASetProperty(pRUA, pbcc->ccfifo_id,
			RMCCFifoPropertyID_Close, NULL, 0, 0)) == RM_PENDING);
	if (RMFAILED(status))
	{
		RMDBGLOG((ENABLE, "Error %s: cannot close CC fifo.\n"
				"Freeing buffer memory anyways.\n",
				RMstatusToString(status)));
	}
	RUAFree(pRUA, pbcc->ccfifo_buffer);

	RMDBGLOG((ENABLE, "Done closing CC fifo #%lu.\n",
				EMHWLIB_MODULE_INDEX(pbcc->ccfifo_id)));
	return status;
}       

