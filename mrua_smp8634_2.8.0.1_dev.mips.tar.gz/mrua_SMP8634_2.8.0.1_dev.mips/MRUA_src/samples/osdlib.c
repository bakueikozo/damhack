/*
 *
 * Copyright (c) Sigma Designs, Inc. 2002. All rights reserved.
 *
 */

/**
 * @file osdbuf_control.c
 * @brief libray control OSD buffers on 86XX
 * 
 * @author Julien Lerouge
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <getopt.h>

#define ALLOW_OS_CODE 1

#include "osdlib.h"

/* For debug/verbose output */
#if 1
#define DEB(f) (f)
#else
#define DEB(f)
#endif

struct osd_format_string_s osd_color_mode_string[EMhwlibColorMode_TrueColorWithKey+1] = {
	{"",""},
	{"lut1bpp", "clut with 1bpp"},
	{"lut2bpp", "clut with 2bpp"},
	{"lut4bpp", "clut with 4bpp"},
	{"lut8bpp", "clut with 8bpp"},
	{"tc", "true color"},
	{"tck", "true color with alpha key"},
};

struct osd_format_string_s osd_color_format_string[EMhwlibColorFormat_16BPP_4444+1] = {
	{"",""},
	{"24bpp_565","24 bpp 5:6:5 (alpha0)"},
	{"24bpp","24 bpp 8:8:8 (alpha0)"},
	{"32bpp_4444","32 bpp 4:4:4:4"},
	{"32bpp","32 bpp 8:8:8:8"},
	{"16bpp_565","16 bpp 5:6:5 (alpha0)"},
	{"16bpp_1555","16 bpp 1:5:5:5 (alpha0 or alpha1)"},
	{"16bpp_4444","16 bpp 4:4:4:4"}
};

struct osd_format_string_s osd_csc[EMhwlibColorSpace_YUV_709+1] = {
	{"", ""},
	{"rgb_16_235","RGB 16 235"},
	{"rgb_0_255","RGB 0 255"},
	{"yuv_601","YUV 601"},
	{"yuv_709","YUV 709"},
};

#define RUASP(pRUA, moduleID, propertyID, pValue, ValueSize)                                                    \
        while ((status = RUASetProperty(pRUA, moduleID, propertyID, pValue, ValueSize, 0)) == RM_PENDING);         \
                                                                                                                \
        if (status != RM_OK) {                                                                                     \
                RMDBGLOG((ENABLE, "Cannot set Property %d on module %d, %d\n", propertyID, moduleID, status));     \
                return status;                                                                                     \
        }

#define RUAGP(pRUA, moduleID, propertyID, pValue, ValueSize)                                                    \
        while ((status = RUAGetProperty(pRUA, moduleID, propertyID, pValue, ValueSize)) == RM_PENDING);         \
                                                                                                                \
        if (status != RM_OK) {                                                                                     \
                RMDBGLOG((ENABLE, "Cannot get Property %d on module %d, %d\n", propertyID, moduleID, status));     \
                return status;                                                                                     \
        }

#define RUAEP(pRUA, moduleID, propertyID, pValueIn, ValueInSize, pValueOut, ValueOutSize)                       \
        while ((status = RUAExchangeProperty(pRUA, moduleID, propertyID, pValueIn, ValueInSize,			\
	                                     pValueOut, ValueOutSize)) == RM_PENDING);         			\
                                                                                                                \
        if (status != RM_OK) {                                                                                     	\
                RMDBGLOG((ENABLE, "Cannot exchange Property %d on module %d, %d\n", propertyID, moduleID, status));     \
                return status;                                                                                     	\
        }



/** Print infos on the given OSD
 * @param p_osd - filled osd_descriptor
 * @return void
 */
void print_osd_full_info(struct osd_descriptor *p_osd)
{
	RMuint32 range = 1 << p_osd->kcolor.Range;
	RMuint32 end_r = p_osd->kcolor.R_Cr + range;
	RMuint32 end_g = p_osd->kcolor.G_Y + range;
	RMuint32 end_b = p_osd->kcolor.B_Cb + range;
	
	if (p_osd == NULL )
		return;
	if (p_osd->LumaAddr){
		fprintf(stdout,"Persistent OSD at 0x%08lX with %7lu bytes\n",
		        p_osd->LumaAddr, p_osd->LumaSize);

		/* FIXME some properties are missing*/
		fprintf(stdout,"Format                    : %s:%s\n", osd_color_mode_string[p_osd->profile.ColorMode].name,
		        osd_color_format_string[p_osd->profile.ColorFormat].name);
		fprintf(stdout,"Resolution                : %ldx%ld\n", p_osd->profile.Width, p_osd->profile.Height);
		fprintf(stdout,"Color Space Conversion    : %s\n", osd_csc[p_osd->profile.ColorSpace].comment);
		fprintf(stdout,"Input Resolution          : %ldx%ld\n", p_osd->input_window.Width, p_osd->input_window.Height);
		fprintf(stdout,"Taps                      : %d\n", p_osd->scaling_config.Taps ? 4 : 2);
		fprintf(stdout,"Anti Flicker Color        : %ld\n", p_osd->scaling_config.AntiFlickerColor);
		fprintf(stdout,"Anti Flicker Alpha        : %ld\n", p_osd->scaling_config.AntiFlickerAlpha);
		fprintf(stdout,"Direction estimation      : %s\n", p_osd->scaling_config.AdaptativeEnable ? "enabled" : "disabled" );
		fprintf(stdout,"Alpha0                    : %ld\n", p_osd->alpha0);
		fprintf(stdout,"Alpha1                    : %ld\n", p_osd->alpha1);
		fprintf(stdout,"Fading                    : %s\n", p_osd->fading ? "enabled" : "disabled" );
		fprintf(stdout,"OSD output channel status : %s\n", p_osd->dcc_info.disp_info->osd_enable[0] ? "enabled" : "disabled" );
		if (p_osd->profile.ColorMode == EMhwlibColorMode_TrueColorWithKey)
			fprintf(stdout,"Key color (R/Cr,G/Y,B/Cb) : [%lu,%lu[, [%lu,%lu[, [%lu,%lu[\n", 
			        p_osd->kcolor.R_Cr, CROPV(end_r,256), 
				p_osd->kcolor.G_Y, CROPV(end_g,256),
				p_osd->kcolor.B_Cb, CROPV(end_b,256));
	}else{
		fprintf(stdout,"No persistent OSD buffer registered\n");
	}
}

/** Get the BPP corresponding to one mode:submode 
 * @param osd_color_mode
 * @param osd_color_format
 * @return bpp 0 on error
 */
RMuint32 get_osd_bpp(RMuint32 osd_color_mode, RMuint32 osd_color_format)
{
	switch(osd_color_mode){
		case EMhwlibColorMode_LUT_1BPP:
		case EMhwlibColorMode_LUT_2BPP:
		case EMhwlibColorMode_LUT_4BPP:
		case EMhwlibColorMode_LUT_8BPP:
			return (1 << (osd_color_mode - EMhwlibColorMode_LUT_1BPP));
		case EMhwlibColorMode_TrueColor:
		case EMhwlibColorMode_TrueColorWithKey:
			switch(osd_color_format){
				case EMhwlibColorFormat_16BPP_4444:
				case EMhwlibColorFormat_16BPP_565:
				case EMhwlibColorFormat_16BPP_1555:
					return 16;
				case EMhwlibColorFormat_24BPP:      //24BPP is really 32BPP
				case EMhwlibColorFormat_24BPP_565:  
				case EMhwlibColorFormat_32BPP:
				case EMhwlibColorFormat_32BPP_4444:
					return 32;
				default:
					return 0;
			}
		default:
			return 0;
	}
}

/** Get current OSD buffer info, store it in p_osd
 * @param p_osd - osd handle
 * @return RMstatus
 */
RMstatus get_osd_infos(struct osd_descriptor *p_osd)
{
	RMstatus status;
	RMuint32 surface;
	struct DisplayBlock_SurfaceSize_in_type size_in;
	struct DisplayBlock_SurfaceSize_out_type size_out;
	struct DisplayBlock_SurfaceInfo_out_type config;

	DEB(fprintf(stderr,"begin get_osd_infos\n"));
	if (p_osd == NULL || p_osd->dcc_info.pDCC == NULL || p_osd->dcc_info.pRUA == NULL)
		return RM_ERROR;

	status = DCCGetScalerModuleID(p_osd->dcc_info.pDCC, p_osd->dcc_info.route, DCCSurface_OSD, 0, 
	                              &p_osd->dcc_info.disp_info->osd_scaler[0]);
	if (RMFAILED(status)){
		fprintf(stderr,"Error getting OSD scaler\n");
		return status;
	}

	RUAGP(p_osd->dcc_info.pRUA, p_osd->dcc_info.disp_info->osd_scaler[0], RMGenericPropertyID_Surface,
	      &surface, sizeof(surface));
	DEB(fprintf(stderr,"surface = 0x%08lx, surf addr=%p\n",surface,&surface));
	if (surface == 0){
		p_osd->LumaAddr = 0;
		p_osd->LumaSize = 0;
		p_osd->ChromaAddr = 0;
		p_osd->ChromaSize = 0;
		return RM_OK;
	}
	
	RUAEP(p_osd->dcc_info.pRUA, DisplayBlock, RMDisplayBlockPropertyID_SurfaceInfo,
	      (void *) &surface, sizeof(void *), &config, sizeof(config));

	RUAGP(p_osd->dcc_info.pRUA, p_osd->dcc_info.disp_info->osd_scaler[0],RMGenericPropertyID_Enable,
	      &p_osd->dcc_info.disp_info->osd_enable[0], sizeof(p_osd->dcc_info.disp_info->osd_enable[0]));
			
	RUAGP(p_osd->dcc_info.pRUA, p_osd->dcc_info.disp_info->osd_scaler[0],RMDispOSDScalerPropertyID_ScalingConfig,
	      &p_osd->scaling_config, sizeof(p_osd->scaling_config));

	RUAGP(p_osd->dcc_info.pRUA, p_osd->dcc_info.disp_info->osd_scaler[0],RMGenericPropertyID_Alpha0,
	      &p_osd->alpha0, sizeof(p_osd->alpha0));

	RUAGP(p_osd->dcc_info.pRUA, p_osd->dcc_info.disp_info->osd_scaler[0],RMGenericPropertyID_Alpha1,
	      &p_osd->alpha1, sizeof(p_osd->alpha1));

	RUAGP(p_osd->dcc_info.pRUA, p_osd->dcc_info.disp_info->osd_scaler[0],RMGenericPropertyID_EnableFading,
	      &p_osd->fading, sizeof(p_osd->fading));

	RUAGP(p_osd->dcc_info.pRUA, p_osd->dcc_info.disp_info->osd_scaler[0],RMGenericPropertyID_KeyColor,
	      &p_osd->kcolor, sizeof(p_osd->kcolor));

	RUAGP(p_osd->dcc_info.pRUA, p_osd->dcc_info.disp_info->osd_scaler[0],RMGenericPropertyID_ScalerInputWindow,
	      &p_osd->input_window, sizeof(p_osd->input_window));

	size_in.Width = config.Width;
	size_in.Height = config.Height;
	size_in.ColorMode = config.ColorMode;
	size_in.ColorFormat = config.ColorFormat;
	size_in.SamplingMode = config.SamplingMode;
	
	RUAEP(p_osd->dcc_info.pRUA, DisplayBlock, RMDisplayBlockPropertyID_SurfaceSize, &size_in,
	      sizeof(size_in), &size_out, sizeof(size_out));

	p_osd->LumaAddr = config.LumaAddress;
	p_osd->LumaSize = size_out.LumaSize;
	
	p_osd->ChromaAddr = config.ChromaAddress;
	p_osd->ChromaSize = size_out.ChromaSize;

	/* Copy at the right place */
	p_osd->bpp = get_osd_bpp(config.ColorMode, config.ColorFormat);
	p_osd->profile.SamplingMode = config.SamplingMode;
	p_osd->profile.ColorMode = config.ColorMode;
	p_osd->profile.ColorFormat = config.ColorFormat;
	p_osd->profile.Width = config.Width;
	p_osd->profile.Height = config.Height;
	p_osd->profile.ColorSpace = config.ColorSpace;

	DEB(fprintf(stderr,"end get_osd_infos\n"));
	return RM_OK;
}	

/** Create a new OSD Buffer
 * @param p_osd osd_descriptor of the buffer to create
 * @return RM_OK on success
 */
RMstatus create_osd_buf(struct osd_descriptor *p_osd)
{
	RMstatus status;
	RMbool persistent = TRUE;

	if (p_osd == NULL || p_osd->dcc_info.pRUA == NULL || p_osd->dcc_info.pDCC == NULL ){
		return RM_ERROR;
	}
	
	status = DCCOpenOSDVideoSource(p_osd->dcc_info.pDCC, &p_osd->profile, &p_osd->dcc_info.pOSDSource[0]);
	if (RMFAILED(status)){
		fprintf(stderr,"Error opening OSD video source\n");
		return status;
	}

	status = DCCGetScalerModuleID(p_osd->dcc_info.pDCC, p_osd->dcc_info.route, DCCSurface_OSD, 0, 
	                              &p_osd->dcc_info.disp_info->osd_scaler[0]);
	if (RMFAILED(status)){
		fprintf(stderr,"Error getting surface to display OSD source\n");
		return status;
	}

	status = DCCClearOSDVideoSource(p_osd->dcc_info.pOSDSource[0]);
	if (RMFAILED(status)){
		fprintf(stderr,"Error clearing OSD source\n");
		return status;
	}

	status = DCCSetSurfaceSource(p_osd->dcc_info.pDCC, p_osd->dcc_info.disp_info->osd_scaler[0], p_osd->dcc_info.pOSDSource[0]);
	if (RMFAILED(status)){
		fprintf(stderr,"Error setting OSD surface source\n");
		return status;
	}

	/* Set the buffer to be persistent */
	RUASP(p_osd->dcc_info.pRUA, p_osd->dcc_info.disp_info->osd_scaler[0], RMGenericPropertyID_PersistentSurface, &persistent, sizeof(persistent));

	return RM_OK;
}	

/** Enable/Disable an OSD mapping a graphic frame buffer
 * @param p_rua - rua handle
 * @param enable - enable or disable
 * @return RM_OK on success
 */
#if 1
RMstatus set_osdbuf_out_enable(struct RUA *p_rua, RMbool enable)
{
	RMstatus status = RM_OK;
	

	return status;
}
#endif

#if 0
/** Put an osd buffer on screen 
 * @param p_rua - rua handle
 * @param p_osd - osd to setup (format, size, start addreess, width and height should be setup)
 * @param standard - TV standard
 * @param output - TV outpout to use
 * @param mixer - mixer to use
 * @param scaler - scaler to use
 * @return RM_OK on success
 */
RMstatus init_display_osd(struct RUA *p_rua, struct osd_descriptor *p_osd, enum TVStandard standard, 
                          TV_Output output, RMuint32 mixer, RMuint32 scaler)
{
	RMstatus status = RM_OK;
	struct DispOSDScaler_SurfaceInputFormat_type osd_buffer;
	enum DispOSDScaler_Source_type src = DispOSDScaler_Source_Surface;
	RMuint32 target_x_pos, target_y_pos;
	RMuint32 x_size, y_size, target_x_size, target_y_size;
	RMbool interlaced;

	DEB(fprintf(stderr,"begin init_display_osd\n"));
	if (p_rua == NULL || p_osd == NULL)
		return RM_ERROR;

	get_video_size(p_rua, standard, &x_size, &y_size, &interlaced); 
	DEB(fprintf(stderr,"Standard %d => %ldx%ld, interlaced = %d\n",standard,x_size,y_size,interlaced));
	DEB(fprintf(stderr,"Target     => %ldx%ld\n",p_osd->width,p_osd->height));
	
	//osd_vpos = y_size - (interlaced ? 60 : 120);  // low end of screen
	target_x_size = p_osd->width;
	target_y_size = p_osd->height;
	if (interlaced) target_y_size /= 2;

	/* Scale picture down if too big for screen */
	if (target_x_size > x_size) {
		if (target_y_size * x_size / target_x_size > y_size) {
			target_x_size = target_x_size * y_size / target_y_size;
			target_y_size = y_size;
		} else {
			target_y_size = target_y_size * x_size / target_x_size;
			target_x_size = x_size;
		}
	} else if (target_y_size > y_size) {
		if (target_x_size * y_size / target_y_size > x_size) {
			target_y_size = target_y_size * x_size / target_x_size;
			target_x_size = x_size;
		} else {
			target_x_size = target_x_size * y_size / target_y_size;
			target_y_size = y_size;
		}
	}
	
	target_x_pos = (x_size - target_x_size) / 2;  // center
	target_y_pos = (y_size - target_y_size) / 2;
	DEB(fprintf(stderr,"scale : %ldx%ld\n",target_x_size,target_y_size));
	status = set_scaler(p_rua, standard, output, mixer, scaler, target_x_size, 
	                    target_y_size, ColorSpaceConversion_RGB_601);
	if (RMFAILED(status))
		fprintf(stderr,"Error setting scaler : %s\n",RMstatusToString(status));
	DEB(fprintf(stderr,"scaler : position %ldx%ld\n",target_x_pos,target_y_pos));
	move_scaler(p_rua, mixer, scaler, target_x_pos, target_y_pos);
	if (RMFAILED(status))
		fprintf(stderr,"Error setting move scaler : %s\n",RMstatusToString(status));


	osd_buffer.FormatMode = p_osd->format.FormatMode;
	osd_buffer.FormatSubmode = p_osd->format.FormatSubmode;
	osd_buffer.XSize = p_osd->width;
	osd_buffer.YSize = p_osd->height;
	osd_buffer.XPad = FALSE;
	osd_buffer.YPad = FALSE;
	osd_buffer.StartBuffer = p_osd->dram_address;
	osd_buffer.SizeBuffer = p_osd->size; //currently not used in EMhwlib

	DEB(fprintf(stderr,"OSD : %ldx%ld, starting at 0x%lx (%ld bytes)\n", osd_buffer.XSize, osd_buffer.YSize, 
	            osd_buffer.StartBuffer, osd_buffer.SizeBuffer));
	DEB(fprintf(stderr,"OSD : %s:%s (%ld:%ld) format\n", osd_color_mode_string[osd_buffer.FormatMode].name, 
	            osd_color_format_string[osd_buffer.FormatSubmode].name, osd_buffer.FormatMode, osd_buffer.FormatSubmode));

	/* pass bitmap buffer to hardware lib */
	status = RUASetProperty(p_rua, DispOSDScaler, RMDispOSDScalerPropertyID_Source, &src, sizeof(src), 0);
	if (RMFAILED(status)){
		fprintf(stderr,"  error setting RMDispOSDScalerPropertyID_Source\n");
		return RM_ERROR;
	}
	status = RUASetProperty(p_rua, DispOSDScaler, RMDispOSDScalerPropertyID_SurfaceInputFormat, 
			     &osd_buffer, sizeof(osd_buffer), 0);
	if (RMFAILED(status)) 
		fprintf(stderr,"Error %d setting property: DispOSDScalerProperty_Buffer\n", status);

	DEB(fprintf(stderr,"end init_display_osd\n"));
	return RM_OK;
}
#endif

RMuint32 get_osd_color_mode(RMascii *m_osd_color_mode_string, RMuint32 *osd_color_mode)
{
	RMuint32 i;
	for (i=1;i<=EMhwlibColorMode_TrueColorWithKey;i++)
		if (strcmp(m_osd_color_mode_string,osd_color_mode_string[i].name) == 0){
			*osd_color_mode=i;
			return 1; //found
		}
	return 0; //not found
}

RMuint32 get_osd_csc(RMascii *m_csc_string, RMuint32 *osd_csc_index)
{
	RMuint32 i;
	for (i=1;i<=EMhwlibColorSpace_YUV_709;i++)
		if (strcmp(m_csc_string,osd_csc[i].name) == 0){
			*osd_csc_index=i;
			return 1; //found
		}
	return 0; //not found
}

RMuint32 get_osd_color_format(RMascii *m_osd_color_format_string, RMuint32 *osd_color_format)
{
	RMuint32 i;
	for (i=0;i<=EMhwlibColorFormat_16BPP_4444;i++)
		if (strcmp(m_osd_color_format_string,osd_color_format_string[i].name) == 0){
			*osd_color_format=i;
			return 1; //found
		}
	return 0; //not found
}


#if 1
/** Set palette entry for OSD to 0xaarrggbb
 * @param p_osd - osd descriptor, should be initialized
 * @param i - palette entry index
 * @param r,g,b 
 * @param alpha
 * @return RM_OK upon success
 */
RMstatus set_osdbuf_palette(struct osd_descriptor *p_osd, RMuint32 i, RMascii r, 
			    RMascii g, RMascii b, RMascii alpha)
{
	RMstatus status;
	struct ScalerLUT p_lut;
	RMuint32 PropertyID = RMGenericPropertyID_8BPP_LUT;
	
	switch(p_osd->profile.ColorMode) {
	case EMhwlibColorMode_LUT_1BPP:
		PropertyID = RMGenericPropertyID_1BPP_LUT;
                p_lut.Size = 2;
		break;
	case EMhwlibColorMode_LUT_2BPP:
		PropertyID = RMGenericPropertyID_2BPP_LUT;
                p_lut.Size = 4;
		break;
	case EMhwlibColorMode_LUT_4BPP:
		PropertyID = RMGenericPropertyID_4BPP_LUT;
                p_lut.Size = 16;
		break;
	case EMhwlibColorMode_LUT_8BPP:
		PropertyID = RMGenericPropertyID_8BPP_LUT;
                p_lut.Size = 256;
		break;
	default:
		DEB(fprintf(stderr,"I don't know wha to do here ...\n"));
		break;
	}
	
	RUAGP(p_osd->dcc_info.pRUA, p_osd->dcc_info.disp_info->osd_scaler[0], PropertyID, &p_lut.Data, sizeof(p_lut.Data));
	
	if ( i < p_lut.Size ) {
		p_lut.Data[i] = 0;
		if (p_osd->profile.ColorFormat <= EMhwlibColorFormat_32BPP) {
			RMinsShiftBits(&(p_lut.Data[i]), alpha, 8, 24);
			RMinsShiftBits(&(p_lut.Data[i]), r,     8, 16);
			RMinsShiftBits(&(p_lut.Data[i]), g,     8,  8); 
			RMinsShiftBits(&(p_lut.Data[i]), b,     8,  0);
		} else {
			switch(p_osd->profile.ColorFormat) {
			case EMhwlibColorFormat_16BPP_565:
				RMinsShiftBits(&(p_lut.Data[i]), r, 5, 11);
				RMinsShiftBits(&(p_lut.Data[i]), g, 6,  5); 
				RMinsShiftBits(&(p_lut.Data[i]), b, 5,  0);
				break;
			case EMhwlibColorFormat_16BPP_1555:
				RMinsShiftBits(&(p_lut.Data[i]), alpha, 1, 15);
				RMinsShiftBits(&(p_lut.Data[i]), r,     5, 10);
				RMinsShiftBits(&(p_lut.Data[i]), g,     5,  5);
				RMinsShiftBits(&(p_lut.Data[i]), b,     5,  0);
				break;
			case EMhwlibColorFormat_16BPP_4444:
				RMinsShiftBits(&(p_lut.Data[i]), alpha, 4, 12);
				RMinsShiftBits(&(p_lut.Data[i]), r,     4,  8);
				RMinsShiftBits(&(p_lut.Data[i]), g,     4,  4);
				RMinsShiftBits(&(p_lut.Data[i]), b,     4,  0);
				break;
			default:
				fprintf(stderr,"Error setting LUT : unknown submode : %ld\n",
					(long int)p_osd->profile.ColorFormat);
				break;
			}
		}
		DEB(fprintf(stderr,"LUT %ld = 0x%08lx\n",i,p_lut.Data[i]));
	}
	RMuint32ToLeBuf(p_lut.Data[i], (RMuint8 *) &(p_lut.Data[i]));
	RUASP(p_osd->dcc_info.pRUA, p_osd->dcc_info.disp_info->osd_scaler[0], PropertyID, &p_lut.Data, sizeof(p_lut.Data));
	RUASP(p_osd->dcc_info.pRUA, p_osd->dcc_info.disp_info->osd_scaler[0], RMGenericPropertyID_Validate, NULL, 0);
	return RM_OK;
}
#endif

/** Clear a non mapped OSD buffer
 * @param  p_osd - osd descriptor
 * @return RMstatus, RM_OK upon success
 */
#if 1
RMstatus clear_osdbuf(struct osd_descriptor *p_osd)
{
	if(p_osd == NULL) return RM_ERROR;
	return DCCClearOSDVideoSource(p_osd->dcc_info.pOSDSource[0]);
}
#endif

/** Set a pixel on the OSD
 * @param p_osd - osd descriptor, should be initialized (at least widht, height, bpp)
 * @param base_addr - user space addr where osd buffer is mapped
 * @param x,y - pixel position
 * @param data - data to write (lut index if lut mode, pixel data otherwise)
 */
#if 1
void osdbuf_set_pixel(struct osd_descriptor *p_osd, RMuint8 *base_addr, RMuint32 x, RMuint32 y, RMuint32 data)
{
	RMuint32 width = 0, height = 0;

	if ( p_osd == NULL || 
	     p_osd->bpp == 0 || 
	     p_osd->profile.Width == 0 || 
	     p_osd->profile.Height == 0 ) return;

	width = p_osd->profile.Width;
	height = p_osd->profile.Height;
	
	if ( x >= width || y >= height ) return;
	
	//We keep only the lower part of data, user has to take care of the mode he is using;
	switch (p_osd->bpp){
		case 32:
			{
				RMuint32 *addr= (RMuint32 *)base_addr+(y*width+x);
				RMuint32ToLeBuf(data, (RMuint8 *) addr);
			}
			break;
		case 24:
			{
				RMuint32 *addr= (RMuint32 *)base_addr+(y*width+x);
				RMuint32ToLeBuf((0x00FFFFFF) & data, (RMuint8 *) addr);
			}
			break;
		case 16:
			{
				RMuint16 *addr = (RMuint16 *) base_addr+(y*width+x);
				RMuint16ToLeBuf((RMuint16) data, (RMuint8 *) addr);
			}
			break;
		case 8:
			{
				RMuint8 *addr = (RMuint8 *)base_addr+(y*width+x);
				*addr = (RMuint8) data;
			}
			break;
		case 4:
			{
				RMuint8 *addr = (RMuint8 *)base_addr+(y*width+x) / 2;
				RMuint32 bit = (RMuint32) ((RMuint8 *)base_addr+(y*width+x) % 2);
				RMuint8 pixel = *addr;
				pixel = pixel & ( 0x0F << bit * 4 );
				data = ( data & 0x0000000F ) << 4;
				*addr = pixel | ( (RMuint8) data >> bit * 4 );
			}
			break;
		case 2:
			{
				RMuint8 *addr = (RMuint8 *)base_addr+(y*width+x) / 4;
				RMuint32 bit = (RMuint32) ((RMuint8 *)base_addr+(y*width+x) % 4);
				RMuint8 pixel = *addr;
				pixel = pixel & ( 0xFF ^ ( 0x3 << bit * 2));
				data = data & 0x00000003;
				*addr = pixel | ( (RMuint8) data << bit * 2 );
			}
			break;
		case 1:
			{
				RMuint8 *addr = (RMuint8 *)base_addr+(y*width+x) / 8;
				RMuint32 bit = (RMuint32) ((RMuint8 *)base_addr+(y*width+x) % 8);
				RMuint8 pixel = *addr;
				pixel = pixel & ( 0xFF ^ ( 0x1 << bit ));
				data = data & 0x00000001;
				*addr = pixel | ( (RMuint8) data << bit );
			}
			break;
		default:
			fprintf(stderr,"Unknown bpp : %ld\n",p_osd->bpp);
			break;
	}
}
#endif

/** Get a pixel on the OSD
 * @param p_osd - osd descriptor, should be initialized (at least widht, height, bpp)
 * @param base_addr - user space addr where osd buffer is mapped
 * @param x,y - pixel position
 * @return RMuint32 - pixel value
 */
#if 1
RMuint32 osdbuf_get_pixel(struct osd_descriptor *p_osd, RMuint8 *base_addr, RMuint32 x, RMuint32 y)
{
	RMuint32 width = 0, height = 0;
	
	if ( p_osd == NULL || 
	     p_osd->bpp == 0 || 
	     p_osd->profile.Width == 0 || 
	     p_osd->profile.Height == 0 ) return 0;
	
	width = p_osd->profile.Width;
	height = p_osd->profile.Height;
	
	if ( x >= width || y >= height )
		return 0;
	
	switch (p_osd->bpp){
		case 32:
			{
				RMuint32 *addr= (RMuint32 *)base_addr+(y*width+x);
				return (*addr);
			}
			break;
		case 24:
			{
				RMuint32 *addr= (RMuint32 *)base_addr+(y*width+x);
				return (*addr);
			}
			break;
		case 16:
			{
				RMuint16 *addr = (RMuint16 *) base_addr+(y*width+x);
				return (RMuint32)(*addr);
			}
			break;
		case 8:
			{
				RMuint8 *addr = (RMuint8 *)base_addr+(y*width+x);
				return (RMuint32)(*addr);
			}
			break;
		case 4:
			{
				RMuint8 *addr = (RMuint8 *)base_addr+(y*width+x) / 2;
				RMuint32 bit = (RMuint32) ((RMuint8 *)base_addr+(y*width+x) % 2);
				RMuint8 pixel = *addr;
				pixel = pixel & ( 0x0F << bit * 4 );
				return (RMuint32) pixel;
			}
			break;
		case 2:
			{
				RMuint8 *addr = (RMuint8 *)base_addr+(y*width+x) / 4;
				RMuint32 bit = (RMuint32) ((RMuint8 *)base_addr+(y*width+x) % 4);
				RMuint8 pixel = *addr;
				pixel = pixel & ( 0xFF ^ ( 0x3 << bit * 2));
				return (RMuint32) pixel;
			}
			break;
		case 1:
			{
				RMuint8 *addr = (RMuint8 *)base_addr+(y*width+x) / 8;
				RMuint32 bit = (RMuint32) ((RMuint8 *)base_addr+(y*width+x) % 8);
				RMuint8 pixel = *addr;
				pixel = pixel & ( 0xFF ^ ( 0x1 << bit ));
				return (RMuint32) pixel;
			}
			break;
		default:
			fprintf(stderr,"Unknown bpp : %ld\n",p_osd->bpp);
			return 0;
			break;
	}
	return 0;
}
#endif

#if 0
void osd_draw_horizontal_line(struct osd_descriptor *p_osd, RMuint8 *base_addr, RMuint32 x, RMuint32 y, 
                               RMuint32 size, RMuint32 data)
{
	RMuint32 i, j;

	// lines need to be 2 pixels large
	for(j=0; j<2; j++)
		for (i=0;i<size;i++)
			osd_set_pixel(p_osd, base_addr, (x+i), (y+j), data);
}

void osd_draw_vertical_line(struct osd_descriptor *p_osd, RMuint8 *base_addr, RMuint32 x, RMuint32 y, 
                             RMuint32 size, RMuint32 data)
{
	RMuint32 i, j;

	// lines need to be 2 pixels large
	for(j=0; j<2; j++)
		for (i=0;i<size;i++)
			osd_set_pixel(p_osd, base_addr, (x+j), (y+i), data);
}


void osd_draw_rectangle(struct osd_descriptor *p_osd, RMuint8 *base_addr, struct osd_rectangle *rect, 
                        RMuint32 data, RMbool fill)
{
	RMuint32 i;

	if((rect->x > p_osd->width) ||
	   (rect->y > p_osd->height) ||
	   (rect->x+rect->width > p_osd->width) ||
	   (rect->y+rect->height > p_osd->height)){
		return;
	}

	if(fill != 0)
		for(i=0;i<rect->width; i++)
			osd_draw_vertical_line(p_osd, base_addr, rect->x+i, rect->y, rect->height, data);
	else {
		osd_draw_vertical_line(p_osd, base_addr, rect->x, rect->y, rect->height, data);	
		osd_draw_vertical_line(p_osd, base_addr, rect->x+rect->width, rect->y, rect->height, data);
		osd_draw_horizontal_line(p_osd, base_addr, rect->x, rect->y, rect->width, data);
		osd_draw_horizontal_line(p_osd, base_addr, rect->x, rect->y+rect->height, rect->width, data);
	}
}

void osd_change_rectangle_size(struct osd_descriptor *p_osd, RMuint8 *base_addr, struct osd_rectangle *old_rect, 
                               struct osd_rectangle *new_rect, RMuint8 erase_data)
{
	RMuint32 i,j;
	RMuint32 data;

	if(new_rect->height == 0){
		osd_draw_rectangle(p_osd, base_addr, old_rect, erase_data, TRUE);
		return;
	}

	if((old_rect->x > p_osd->width) ||
	   (old_rect->y > p_osd->height) ||
	   (old_rect->x+old_rect->width > p_osd->width) ||
	   (old_rect->y+old_rect->height > p_osd->height))
		return;

	if((new_rect->x > p_osd->width) ||
	   (new_rect->y > p_osd->height) ||
	   (new_rect->x+new_rect->width > p_osd->width) ||
	   (new_rect->y+new_rect->height > p_osd->height))
		return;

	if(((old_rect->x+old_rect->width) < new_rect->x) ||
	   ((old_rect->y+old_rect->height) < new_rect->y)) {
		fprintf(stderr, "Error, old rectangle and new rectangles are in 2 differents places !!\n");
		return;
	}

	data = osd_get_pixel(p_osd, base_addr, old_rect->x, old_rect->y);

	// width+1 and height+1 because writeVerticalLine and writeHorizontalLine draw 2 lines
	// write new rectangle
	for(i=0;i<(new_rect->width+1);i++) {
		for(j=0;j<(new_rect->height+1);j++){
			if((((new_rect->x+i) < old_rect->x) ||
			    ((new_rect->x+i) > (old_rect->x+(old_rect->width+1)))) ||
			   (((new_rect->y+j) < old_rect->y) ||
			    ((new_rect->y+j) > (old_rect->y+(old_rect->height+1))))){
				osd_set_pixel(p_osd, base_addr, (new_rect->x+i), (new_rect->y+j), data);	
			}
		}
	}
	
	// erase old rectangle
	for(i=0;i<(old_rect->width+1);i++) {
		for(j=0;j<(old_rect->height+1);j++){
			if((((old_rect->x+i) < new_rect->x) ||
			    ((old_rect->x+i) > (new_rect->x+(new_rect->width+1)))) ||
			   (((old_rect->y+j) < new_rect->y) ||
			    ((old_rect->y+j) > (new_rect->y+(new_rect->height+1))))){
				osd_set_pixel(p_osd, base_addr, (old_rect->x+i), (old_rect->y+j), erase_data);
			}
		}
	
	}
}
#endif
