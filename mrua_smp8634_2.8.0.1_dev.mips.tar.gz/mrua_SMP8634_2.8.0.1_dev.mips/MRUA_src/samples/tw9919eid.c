
#include "tw9919eid.h"
#include "i2c.h"
RMuint8 TW9919E_CCIR_NTSC_DataSet[][2] = {			
	
	//	 {0x02, 0x70},		// for 27MHz PLL unstable on power reset time
	{0x81, 0x09},		// for MCLK unstable
	{0x03, 0xa2},
	{0x05, 0x00},		// for RevE
	{0x09, 0xf6},
//	{0x0a, 0x21},		// For adjusting H position	
	{0x0a, 0xf},		// For adjusting H position	
	{0x0f, 0x1},		
	{0x12, 0x12},
	{0x19, 0x57},
//	{0x19, 0x5f},
	{0x1a, 0x07},
//	{0x1b, 0x20},		// for RevE clk2--> vclk, clk1 --> clkx1(freerun)
	{0x1b, 0x10}, //A Tho
	{0x21, 0x62},		//for white saturation on low sync level
	//	{0x23, 0xec},		//for RevE, use default value(0xd8)
	{0x23, 0xd8},		// Not sure 
	{0x28, 0x02},		//for solve from even/odd switch suddenly
	{0x29, 0x02},		//Changed for v-sync out scheme
	{0x2d, 0x54},		// for prevent field error on bad tape
	{0x33, 0x08},		//for improving HV shaking on week signal
//	{0x33, 0x05}, //dung huynh restore default value
	{0x36, 0x00},
//	{0x39, 0x0b},
	{0x39, 0x02}, //A Tho

	{0x55, 0x10},
	{0x6b, 0x26},
	{0x6c, 0x36},
	{0x6d, 0x25},		//Changed for v-sync out scheme
	{0x6e, 0x40},		//Changed for v-sync out scheme
//	{0x70, 0x0a},		// for RevE
	{0x70, 0x07}, //A Tho
	{0x73, 0xc0}, //A Tho
	{0x75, 0x04},		// for RevE
	{0x76, 0x95}, //A Tho
	{0x81, 0x08},
	{0x06, 0x80},	// Reset .	

};


RMuint8 TW9919E_CCIR_PAL_DataSet[][2] = {		
	//	 {0x02, 0x70},		// for PLL unstable on power reset time
	{0x81, 0x09},		// for MCLK unstable
	{0x03, 0xa2},
	{0x05, 0x88},		// for RevE (Not sure )
//	{0x0a, 0x16},		// For adjusting H position
	{0x0a, 0xf},		// For adjusting H position
	{0x0f, 0x1},		
	{0x12, 0x12},
	{0x19, 0x57},
	{0x1a, 0x07},
//	{0x1b, 0x20},		// for RevE clk2--> vclk, clk1 --> clkx1(freerun)
	{0x1b, 0x10}, //A Tho
	{0x21, 0x62},		//for white saturation on low sync level
	//	{0x23, 0xec},		//for RevE, use default value(0xd8)
	{0x23, 0xd8},		// Not sure 
	{0x28, 0x02},		//for solve from even/odd switch suddenly
	{0x29, 0x02},		//Changed for v-sync out scheme
	{0x2d, 0x54},		// for prevent field error on bad tape
	{0x33, 0x08},		//for improving HV shaking on week signal
//	{0x33, 0xc8},
	{0x36, 0x00},
//	{0x39, 0x0b},
	{0x39, 0x02}, //A Tho
	{0x6b, 0x26},
	{0x6c, 0x36},
//	{0x6d, 0x25},		//Changed for v-sync out scheme
//	{0x6e, 0x40},		//Changed for v-sync out scheme
	{0x6d, 0x00},		//Changed for v-sync out scheme
	{0x6e, 0x20},		//Changed for v-sync out scheme
//	{0x70, 0x0a},		// for RevE
	{0x70, 0x07}, //A Tho
	{0x73, 0xc0}, //A Tho
	{0x75, 0x04},		// for RevE
	{0x76, 0x95}, //A Tho
	{0x81, 0x08},
	{0x06, 0x80},	//Reset			

	//
};

//Audio clock generation for frequency of 27 Mhz :

RMuint8 TW9919E_AMCLK_48KHZ_NTSC[][2]={
	//ACKI 0x40 - 0x42
	{0x40,	0x15},
	{0x41,	0x41},
	{0x42,	0x3a},
	//ACKN 0x43 - 0x45
	{0x43,	0xcd},
	{0x44,	0x20},
	{0x45,	0x03},
};

RMuint8 TW9919E_AMCLK_48KHZ_PAL[][2]={
	//ACKI 0x40 - 0x42
	{0x40,	0x15},
	{0x41,	0x41},
	{0x42,	0x3a},
	//ACKN 0x43 - 0x45
	{0x43,	0x00},
	{0x44,	0xc0},
	{0x45,	0x03},
};
RMuint8 TW9919E_AMCLK_44KHZ_NTSC[][2]={
	//ACKI 0x40 - 0x42
	{0x40,	0x65},
	{0x41,	0x85},
	{0x42,	0x35},
	//ACKN 0x43 - 0x45
	{0x43,	0xbc},
	{0x44,	0xdf},
	{0x45,	0x02},
};

RMuint8 TW9919E_AMCLK_44KHZ_PAL[][2]={
	//ACKI 0x40 - 0x42
	{0x40,	0x65},
	{0x41,	0x85},
	{0x42,	0x35},
	//ACKN 0x43 - 0x45
	{0x43,	0x00},
	{0x44,	0x72},
	{0x45,	0x03},
};

RMuint8 TW9919E_AMCLK_32KHZ_NTSC[][2]={
	//ACKI 0x40 - 0x42
	{0x40,	0x0e},
	{0x41,	0xd6},
	{0x42,	0x26},
	//ACKN 0x43 - 0x45
	{0x43,	0xde},
	{0x44,	0x15},
	{0x45,	0x02},
};

RMuint8 TW9919E_AMCLK_32KHZ_PAL[][2]={
	//ACKI 0x40 - 0x42
	{0x40,	0x0e},
	{0x41,	0xd6},
	{0x42,	0x26},
	//ACKN 0x43 - 0x45
	{0x43,	0x00},
	{0x44,	0x80},
	{0x45,	0x02},
};

RMuint8 TW9919E_AMCLK_8KHZ_NTSC[][2]={
	//ACKI 0x40 - 0x42
	{0x40,	0x83},
	{0x41,	0xb5},
	{0x42,	0x09},
	//ACKN 0x43 - 0x45
	{0x43,	0x78},
	{0x44,	0x85},
	{0x45,	0x00},
};

RMuint8 TW9919E_AMCLK_8KHZ_PAL[][2]={
	//ACKI 0x40 - 0x42
	{0x40,	0x83},
	{0x41,	0xb5},
	{0x42,	0x09},
	//ACKN 0x43 - 0x45
	{0x43,	0x00},
	{0x44,	0xa0},
	{0x45,	0x00},
};
RMuint8 TW9919E_CC_Enable[][2] = {			// Enable NTSC ClosedCaption slicing
	
	{0x19, 0xd7},	//enable VBI raw
	{0x52, 0xa1},  // anc data output
	{0x6f, 0x91},  // VBIDELAY- Enbalbe VBI data slicer
	{0x6e, 0x00}, 	
	{0xa5, 0x80}, 	
	
	
	{0x56, 0x00},  // lines 6 / 
	{0x57, 0x00},  // lines 7 / 
	{0x58, 0x00},  // lines 8 / 
	{0x59, 0x00},  // lines 9 /
	{0x5a, 0x00},  // lines 10 / 
	{0x5b, 0x00},  // lines 11 / 
	{0x5c, 0x00},  // lines 12 / 
	{0x5d, 0x00},  // lines 13 / 
	{0x5e, 0x00},  // lines 14 / 
	{0x5f, 0x00},  // lines 15 / 
	{0x60, 0x00},  // lines 16 / 
	{0x61, 0x00},  // lines 17 / 
	{0x62, 0x00},  // lines 18 / 
	{0x63, 0x00},  // lines 19 / 
	{0x64, 0x00},  // lines 20 / 
	{0x65, 0x40},  // lines 21 / 
	
	{0x66, 0x00},  // lines 22 / 
	{0x67, 0x00},  // lines 23 / 
	{0x68, 0x00},  // lines 24 /
	{0x69, 0x00},  // lines 25 / 
	{0x6a, 0x00},  // lines 26 / 
	
};
RMuint8 TW9919E_TT_Enable[][2] = {  // Enable PAL TeleText slicing
	
	{0x19, 0xd7},	//enable VBI raw
	{0x52, 0xb1},  // anc data output
	{0x6f, 0x91},  // VBIDELAY- Enbalbe VBI data slicer
	{0x6e, 0x00}, 
};
RMuint8 TW9919E_TT_B[][2] = {  // Enable TeleText system B (WST)	
	
	{0xab, 0xb0},
//	{0x55, 0x20},  //hamming check
	{0xa5, 0xb8},
	
	{0x56, 0x11},  // lines 6 / 320
	{0x57, 0x11},  // lines 7 / 321
	{0x58, 0x11},  // lines 8 / 322
	{0x59, 0x11},  // lines 9 / 323
	{0x5a, 0x11},  // lines 10 / 324
	{0x5b, 0x11},  // lines 11 / 325
	{0x5c, 0x11},  // lines 12 / 326
	{0x5d, 0x11},  // lines 13 / 327
	{0x5e, 0x11},  // lines 14 / 328
	{0x5f, 0x11},  // lines 15 / 329
	{0x60, 0x11},  // lines 16 / 330
	{0x61, 0x11},  // lines 17 / 331
	{0x62, 0x11},  // lines 18 / 332
	{0x63, 0x11},  // lines 19 / 333
	{0x64, 0x11},  // lines 20 / 334
	{0x65, 0x11},  // lines 21 / 335
	{0x66, 0xff},  // lines 22 / 336
	{0x67, 0xff},  // lines 23 / 337
	{0x68, 0xff},  // lines 24 / 338
	{0x69, 0xff},  // lines 25 / 339
	{0x6a, 0xff},  // lines 26 / 340
	
	
};
//sizeOfRam = {16,32,64} MB
RMstatus tw9919eid_setSizeOfSDRAM(struct RUA *pInstance,RMuint8 delay,RMuint32 dev,RMuint8 sizeOfRam) 
{
	RMstatus err=RM_OK;
	RMuint32 regAddr=0x00;
	RMuint32 regValue=0x00;

	regAddr=0x72;
	err = read_i2c(pInstance,delay,dev,regAddr,&regValue);	
	if (err!=RM_OK) {
		printf("setSizeOfSDRAM Error <1>  \n");
		return err;
	}
	switch(sizeOfRam){
	case 16:		
		err=write_i2c(pInstance,delay,dev,regAddr,regValue & 0xe7);
		if (err!=RM_OK) {
			printf("setSizeOfSDRAM Error 2 \n");
			return err;
		}
		break;
	case 32:	
		
		err=write_i2c(pInstance,delay,dev,regAddr,(regValue & 0xef)|0x08);
		if (err!=RM_OK) {
			printf("setSizeOfSDRAM Error 3 \n");
			return err;
		}
		
		break;
	default: 		
		printf("Only support 16,32,64 MB SD Ram. 64 Mb by default ! \n");
	case 64:	//64 MB SD RAM	
		regValue &= 0xf7;
		regValue |=0x10;
		err=write_i2c(pInstance,delay,dev,regAddr,regValue);
		if (err!=RM_OK) {
			printf("setSizeOfSDRAM Error 4 \n");
			return err;
		}		
		break;
	}
	return err;
}

	/*
	 	1 : Capture CVBS port
		2 : Capture S-Video port
	 */
RMstatus tw9919eid_setCapturePort(struct RUA *pInstance, RMuint8 dev, RMuint8 delay,RMuint8 port)
{
	RMstatus err=RM_OK;
	//	RMuint32 regValue=0;
	switch (port) {
				case 1:      	
					err = write_i2c(pInstance, delay, dev, 0x02,0x41 ); //dh capture cvbs .
					//					err = write_i2c(pInstance, delay, dev, 0x39,0x02 ); //dh 
					break;
				case 2:    
					err = write_i2c(pInstance, delay, dev, 0x02,0x55 ); //dh 					
					//					err = write_i2c(pInstance, delay, dev, 0x39,0x02 ); //dh 
					break;
				case 3:    
					err = write_i2c(pInstance, delay, dev, 0x02,0x49 ); 
					//err = write_i2c(pInstance, delay, dev, 0x39,0x02 ); //dh 
					break;
					

				default: 
					printf("Only support CVBS and S-Video Capture Port ! CVBS By default !\n");
					err = write_i2c(pInstance, delay, dev, 0x02,0x41 ); //dh capture cvbs .
					//					err = write_i2c(pInstance, delay, dev, 0x39,0x02 ); //dh 
					//					err = RM_ERROR;
					break;
				}
	usleep(50);	
	return err;
}

RMuint8 tw9919eid_isVideoIn(struct RUA *pInstance, RMuint8 dev, RMuint8 delay)
{
	RMuint8 retValue=1;
	RMuint32 regValue=0;
	if (RMFAILED(read_i2c(pInstance, delay, dev, 0x01, &regValue))) {
		fprintf(stderr, "tw9919eid_isVideoIn() failed to read reg 0x01\n");
		return -1; //Error .
	}
	if ((regValue & 0x80)) {
		retValue=0;//No video in.
	}
	return retValue;
}

RMuint8 tw9919eid_isStandardSignal(struct RUA *pInstance, RMuint8 dev, RMuint8 delay)
{
	RMstatus err=RM_OK;
	RMuint8 retValue=1;
	RMuint32 regValue=0;
	RMuint32 regAdd=0x31;
	err = read_i2c(pInstance, delay, dev, regAdd, &regValue); 
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return -1;
	}
	
	if (!(regValue & 0x10)) {
		retValue=0;//Not standard signal . 
	}
	return retValue;
}

RMuint8 tw9919eid_isNTSC(struct RUA *pInstance, RMuint8 dev, RMuint8 delay)
{
	RMuint8 retValue=1;
	RMuint32 regValue=0;
	if (RMFAILED(read_i2c(pInstance, delay, dev, 0x01, &regValue))) {
		fprintf(stderr, "tw9919eid_isVideoIn() failed to read reg 0x01\n");
		return -1; //Error .
	}
	if ((regValue & 0x01)) {  // NTSC 525/59.94	
		retValue=0;//PAL 625/50
	}
	return retValue;
}

RMstatus tw9919eid_setRegColorSystem(
								  struct RUA *pInstance, 								  
								  RMuint8 dev, 
								  RMuint8 delay ,								  
								  RMuint8 isNTSC)
{
	RMstatus err=RM_OK;
	usleep(20);
	
	if (isNTSC) {
		err=init_i2c(pInstance,delay,dev,TW9919E_CCIR_NTSC_DataSet,sizeof(TW9919E_CCIR_NTSC_DataSet)/2/sizeof(RMuint8));					
		if (err!=RM_OK) {
			printf("init_capture_TW9919 Error <1>\n");
		}
	}else{
		err=init_i2c(pInstance,delay,dev,TW9919E_CCIR_PAL_DataSet,sizeof(TW9919E_CCIR_PAL_DataSet)/2/sizeof(RMuint8));
		if (err!=RM_OK) {
			printf("init_capture_TW9919 Error <2>\n");
		}
	}
	
	if (isNTSC) {		
		RMuint8 TW9919E_NTSC[][2] = {{0x09, 0xf6},{0x0a, 0xf},{0x55, 0x10},};
		printf("NTSC detected ! \n");
		err=init_i2c(pInstance,delay,dev,TW9919E_NTSC,sizeof(TW9919E_NTSC)/2/sizeof(RMuint8));
		if (err!=RM_OK) {
			printf("init_capture_TW9919() ERROR 5 !\n");
			
		}
	}else{
		RMuint8 TW9919E_PAL[][2]  = {{0x09, 0xf0},{0x0a, 0xf},{0x0c, 0xcc},{0x55, 0x00},};
		printf("PAL detected ! \n");
		err=init_i2c(pInstance,delay,dev,TW9919E_PAL,sizeof(TW9919E_PAL)/2/sizeof(RMuint8));
		if (err!=RM_OK) {
			printf("init_capture_TW9919() ERROR 5 !\n");
		}
	}
	return err;
}

RMstatus tw9919eid_setRegOutputInterface(struct RUA *pInstance, 								  
										 RMuint8 dev, 
										 RMuint8 delay ,								  
									 RMuint8 isNTSC)
{
	RMstatus err=RM_OK;
	if (isNTSC) {
		err=write_i2c(pInstance,delay,dev,0x07,0x02);
		//err=write_i2c(pInstance,delay,dev,0x07,0x10);
		if (RMFAILED(err)) {
			fprintf(stderr, "get_format_TW9919() Failed to write reg 0x07\n");
			return err;
		}
		
		err=write_i2c(pInstance,delay,dev,0x08,0x12);
		//err=write_i2c(pInstance,delay,dev,0x08,0x0c);
		if (RMFAILED(err)) {
			fprintf(stderr, "get_format_TW9919() Failed to write reg 0x08\n");
			return err;
		}
		err=write_i2c(pInstance,delay,dev,0x09,0xf4);
		//err=write_i2c(pInstance,delay,dev,0x09,0xf6);
		//err=write_i2c(pInstance,delay,dev,0x09,0x18);
		if (RMFAILED(err)) {
			fprintf(stderr, "get_format_TW9919() Failed to write reg 0xf6\n");
			return err;
		}
		//only cvbs or s-video
		err=write_i2c(pInstance,delay,dev,0x0b,0xd0);
		if (RMFAILED(err)) {
			fprintf(stderr, "get_format_TW9919() Failed to write reg 0x0b\n");
			return err;
		}
	}else {
		err=write_i2c(pInstance,delay,dev,0x07,0x12);
		if (RMFAILED(err)) {
			fprintf(stderr, "get_format_TW9919() Failed to write reg 0x07\n");
			return err;
		}
		
		err=write_i2c(pInstance,delay,dev,0x08,0x18);
		if (RMFAILED(err)) {
			fprintf(stderr, "get_format_TW9919() Failed to write reg 0x08\n");
			return err;
		}
		err=write_i2c(pInstance,delay,dev,0x09,0x20);
		if (RMFAILED(err)) {
			fprintf(stderr, "get_format_TW9919() Failed to write reg 0xf6\n");
			return err;
		}
		//only cvbs or s-video
		err=write_i2c(pInstance,delay,dev,0x0b,0xd0);
		if (RMFAILED(err)) {
			fprintf(stderr, "get_format_TW9919() Failed to write reg 0x0b\n");
			return err;
		}
	}
	
	return err;
}

static RMuint8 tw9919eid_getAudioFrequencyType(RMuint32 sampleRate)
{
	RMuint8 rt=audio_frequency_44khz;
	if (sampleRate<20000) 
		rt=audio_frequency_8khz;
	else 
		if (sampleRate<38000) 
			rt=audio_frequency_32khz;
		else
			if (sampleRate<46000) 
				rt=audio_frequency_44khz;
			else
				rt=audio_frequency_48khz;
	return rt;			
}

RMstatus tw9919eid_setAudioClock(
									 struct RUA *pInstance, 								  
									 RMuint8 dev, 
									 RMuint8 delay ,								  
									 RMuint8 isNTSC,
									 RMuint32 afreqHz)
{
	RMstatus err=RM_OK;
	RMuint8 afreq=audio_frequency_44khz;
	afreq=tw9919eid_getAudioFrequencyType(afreqHz);
	if (isNTSC) {
		switch(afreq) {
		case audio_frequency_48khz:
			err=init_i2c(pInstance,delay,dev,TW9919E_AMCLK_48KHZ_NTSC,sizeof(TW9919E_AMCLK_48KHZ_NTSC)/2/sizeof(RMuint8));
			if (err!=RM_OK) {
				printf("tw9919eid_setAudioClock Error <1>\n");
			}
			break;
		default:
		case audio_frequency_44khz:
			err=init_i2c(pInstance,delay,dev,TW9919E_AMCLK_44KHZ_NTSC,sizeof(TW9919E_AMCLK_44KHZ_NTSC)/2/sizeof(RMuint8));
			if (err!=RM_OK) {
				printf("tw9919eid_setAudioClock Error <2>\n");
			}
			break;
		case audio_frequency_32khz:
			err=init_i2c(pInstance,delay,dev,TW9919E_AMCLK_32KHZ_NTSC,sizeof(TW9919E_AMCLK_32KHZ_NTSC)/2/sizeof(RMuint8));
			if (err!=RM_OK) {
				printf("tw9919eid_setAudioClock Error <3>\n");
			}
			break;
		case audio_frequency_8khz:
			err=init_i2c(pInstance,delay,dev,TW9919E_AMCLK_8KHZ_NTSC,sizeof(TW9919E_AMCLK_8KHZ_NTSC)/2/sizeof(RMuint8));
			if (err!=RM_OK) {
				printf("tw9919eid_setAudioClock Error <4>\n");
			}
			break;	
		}
		
	}
	else{
		switch(afreq) {
		case audio_frequency_48khz:
			err=init_i2c(pInstance,delay,dev,TW9919E_AMCLK_48KHZ_PAL,sizeof(TW9919E_AMCLK_48KHZ_PAL)/2/sizeof(RMuint8));
			if (err!=RM_OK) {
				printf("tw9919eid_setAudioClock Error <5>\n");
			}
			break;
		default:
		case audio_frequency_44khz:
			err=init_i2c(pInstance,delay,dev,TW9919E_AMCLK_44KHZ_PAL,sizeof(TW9919E_AMCLK_44KHZ_PAL)/2/sizeof(RMuint8));
			if (err!=RM_OK) {
				printf("tw9919eid_setAudioClock Error <6>\n");
			}
			break;
		case audio_frequency_32khz:
			err=init_i2c(pInstance,delay,dev,TW9919E_AMCLK_32KHZ_PAL,sizeof(TW9919E_AMCLK_32KHZ_PAL)/2/sizeof(RMuint8));
			if (err!=RM_OK) {
				printf("tw9919eid_setAudioClock Error <7>\n");
			}
			break;
		case audio_frequency_8khz:
			err=init_i2c(pInstance,delay,dev,TW9919E_AMCLK_8KHZ_PAL,sizeof(TW9919E_AMCLK_8KHZ_PAL)/2/sizeof(RMuint8));
			if (err!=RM_OK) {
				printf("tw9919eid_setAudioClock Error <8\n");
			}
			break;	
		}
		
	}
	
	return err;
}

RMstatus tw9919eid_setStandardAutoDetect(struct RUA *pInstance, 								  
										 RMuint8 dev, 
										 RMuint8 delay )
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0;
	RMuint32 regAdd=0x1c;
	err = read_i2c(pInstance, delay, dev, regAdd, &regValue); 
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	err=write_i2c(pInstance,delay,dev,regAdd,regValue | 0x07); //Auto standard
	//err=write_i2c(pInstance,delay,dev,0x07,0x10);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
		return err;
	}
	return err;
}

//Use H
static float H(float curVal,float matchVal,float maxPoint)
{
	float result=0;
	float minus=0;	
	//minus = abs(Curval-matchVal);
	if ((curVal==0) || (matchVal==0)) {
		result = 0; 
	}else
		if (curVal >= matchVal) {
			minus=curVal-matchVal;
			result=maxPoint-(minus/curVal)*maxPoint;
			if (result<maxPoint/2) {
				result=0;
			}
		}else{
			minus=matchVal-curVal;		
			result=maxPoint-(minus/matchVal)*maxPoint;
			if (result<maxPoint/2) {
				result=0;
			}
		}
		return result;
		
}

RMstatus tw9919eid_getCaptureStandard(	struct RUA *pInstance,
								   RMuint32 numHsyncPerVsync,
								   enum EMhwlibTVStandard tvStandartSupportedList[],
								   RMuint8 sizeOftvStandartSupportedList,
								   enum EMhwlibTVStandard *newTVStandard)
{
	RMstatus err=RM_OK;
	struct EMhwlibTVFormatDigital formatDigital;
	RMuint32 curLinesPerField;
	float maxH=96;
	float curH=0;	
	RMuint8 i=0;
	
	*newTVStandard=EMhwlibTVStandard_Custom;
	
	
	for(i=0;i<sizeOftvStandartSupportedList;i++)
	{		
		curH=0; 
		err = RUAExchangeProperty(pInstance, DisplayBlock, 
			RMDisplayBlockPropertyID_TVFormatDigital, 
			&tvStandartSupportedList[i], sizeof(tvStandartSupportedList[i]), 
			&formatDigital, sizeof(formatDigital));
		if RMFAILED(err) {
			fprintf(stderr, "Can not get format!\n");
			return err;
		}
		curLinesPerField = formatDigital.VTotalSize;
		if (formatDigital.TopFieldHeight) curLinesPerField /= 2;
		
		printf("%d > compare %ld with %ld\n",i,numHsyncPerVsync,curLinesPerField);
		curH += H((float)numHsyncPerVsync,(float)curLinesPerField,100);
		if (maxH<curH) {
			*newTVStandard=tvStandartSupportedList[i];
			maxH=curH;			
		}
	}
	
	//printf("H = %f\n",maxH);	
	
	return err;
}

RMstatus tw9919eid_checkStandardDetected(struct RUA *pInstance, 								  
										 RMuint8 dev, 
										 RMuint8 delay )
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0;
	err = read_i2c(pInstance,delay,dev,0x1c,&regValue);	
	if (err!=RM_OK) {
		printf("setSizeOfSDRAM Error <1>  \n");
		return err;
	}
	fprintf(stderr, "TW9919	: Detected 60Hz %s, setting up CC\n", 
		(((regValue & 0x70)>>4) == 0) ? "NTSC(M)" : 
	(((regValue & 0x70)>>4) == 1) ? "PAL (B,D,G,H,I)" : 
	(((regValue & 0x70)>>4) == 2) ? "SECAM" : 
	(((regValue & 0x70)>>4) == 3) ? "NTSC4.43" :
	(((regValue & 0x70)>>4) == 4) ? "PAL (M)" :
	(((regValue & 0x70)>>4) == 5) ? "PAL (CN)" :
	(((regValue & 0x70)>>4) == 6) ? "PAL 60" :  "Not valid" );
	return err;
}

RMstatus tw9919eid_checkRegisterSet(struct RUA *pInstance, 
										   RMuint32 dev ,
										   RMuint8 delay)

{
	RMstatus err=RM_OK;
	RMuint32 addr;
	//		RMuint32 *data;
	RMuint32 reg;
/*
	
	for(addr=0x00;addr<=0xed;addr++)
	{
		err = read_i2c(pInstance, delay, dev, addr, &reg);
		if (RMFAILED(err))
		{
			printf("Can't Read I2C \n");
			return err;
		}
		printf(" reg %lx = %lx \n",addr,reg);			
	}*/

	printf("\n---------------------------\n");
	printf("RMuint8 i2c_data[][2] = { \n");
	
	for(addr=0x00;addr<=0xed;addr++)
	{
		err = read_i2c(pInstance, delay, dev, addr, &reg);
		if (RMFAILED(err))
		{
			printf("Can't Read I2C \n");
			//return err;
		}
		printf(" { 0x%lx , 0x%lx },\n",addr,reg);	
	}
	printf("};\n");
	printf("\n---------------------------\n");
	return err;
}

RMstatus tw9919eid_setContrast(struct RUA *pInstance, 								  
							   RMuint8 dev, 
							   RMuint8 delay,
							   RMuint32 contrastValue)
{
	RMstatus err=RM_OK;
	// if contrastValue = 0x80 or 0x90 -> No effect on the video data
	if ((contrastValue>=0)&&(contrastValue<=255)) {
		RMuint32 regValue=0;
		RMuint32 regAdd=0x11;
		regValue=contrastValue & 0xff;
		err=write_i2c(pInstance,delay,dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
			return err;
		}		
	}
	return err;
}

RMstatus tw9919eid_getContrast(struct RUA *pInstance, 								  
							   RMuint8 dev, 
							   RMuint8 delay,
							   RMuint32 *contrastValue)
{
	RMstatus err=RM_OK;
	// if contrastValue = 0x80 or 0x90 -> No effect on the video data
	
	RMuint32 regValue=0;
	RMuint32 regAdd=0x11;
	err=read_i2c(pInstance,delay,dev,regAdd,&regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}

	*contrastValue=regValue & 0xff;

	return err;
}

RMstatus tw9919eid_isContrastValid(struct RUA *pInstance, 								  
								RMuint8 dev, 
								RMuint8 delay,
								RMuint32 contrastValue)
{
	RMstatus err=RM_OK;
	// if contrastValue = 0x80 or 0x90 -> No effect on the video data
	if ((contrastValue<0)||(contrastValue>255)) {
		err=RM_ERROR;
	}
	return err;
}
RMstatus tw9919eid_setBrightness(struct RUA *pInstance, 								  
							   RMuint8 dev, 
							   RMuint8 delay,
							   RMint32 brightnessValue)
{
	RMstatus err=RM_OK;
	// if contrastValue = 0x80 or 0x90 -> No effect on the video data
	if ((brightnessValue>=-128)&&(brightnessValue<=127)) {
		RMuint32 regValue=0;
		RMuint32 regAdd=0x10;
		regValue=brightnessValue & 0xff;
		err=write_i2c(pInstance,delay,dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
			return err;
		}		
	}
	return err;
}


RMstatus tw9919eid_getBrightness(struct RUA *pInstance, 								  
							  RMuint8 dev, 
							  RMuint8 delay,
							  RMint32 *brightnessValue)
{
	RMstatus err=RM_OK;
	// if contrastValue = 0x80 or 0x90 -> No effect on the video data
	
	RMuint32 regValue=0;
	RMuint32 regAdd=0x10;	
	err=read_i2c(pInstance,delay,dev,regAdd,&regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	
	*brightnessValue=regValue & 0xff;
	
	return err;
}

RMstatus tw9919eid_isBrightnessValid(struct RUA *pInstance, 								  
								  RMuint8 dev, 
								  RMuint8 delay,
								  RMint32 brightnessValue)
{
	RMstatus err=RM_OK;
	// if brightnessValue = 0x80 or 0x90 -> No effect on the video data
	if ((brightnessValue<-128)||(brightnessValue>127)) {
		err=RM_ERROR;
	}
	return err;
}

RMstatus tw9919eid_setSaturationU(struct RUA *pInstance, 								  
								 RMuint8 dev, 
								 RMuint8 delay,
								 RMuint32 saturationUValue)
{
	RMstatus err=RM_OK;
	
	if ((saturationUValue>=0)&&(saturationUValue<=255)) {
		RMuint32 regValue=0;
		RMuint32 regAdd=0x13;
		regValue=saturationUValue & 0xff;
		err=write_i2c(pInstance,delay,dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
			return err;
		}		
	}
	return err;
}

RMstatus tw9919eid_setSaturationV(struct RUA *pInstance, 								  
								  RMuint8 dev, 
								  RMuint8 delay,
								  RMuint32 saturationVValue)
{
	RMstatus err=RM_OK;
	
	if ((saturationVValue>=0)&&(saturationVValue<=255)) {
		RMuint32 regValue=0;
		RMuint32 regAdd=0x14;
		regValue=saturationVValue & 0xff;
		err=write_i2c(pInstance,delay,dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
			return err;
		}		
	}
	return err;
}

RMstatus tw9919eid_setSaturation(struct RUA *pInstance, 								  
								  RMuint8 dev, 
								  RMuint8 delay,
								  RMuint32 saturationValue)
{
	RMstatus err=RM_OK;
	
	if ((saturationValue>=0)&&(saturationValue<=255)) {
		err=tw9919eid_setSaturationU(pInstance,dev,delay,saturationValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to setSaturationU\n");
			return err;
		}
		err=tw9919eid_setSaturationV(pInstance,dev,delay,saturationValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to setSaturationV\n");
			return err;
		}
	}
	return err;
}
RMstatus tw9919eid_setHue(struct RUA *pInstance, 								  
						  RMuint8 dev, 
						  RMuint8 delay,
						  RMint32 hueValue)
{
	RMstatus err=RM_OK;	
	if ((hueValue>=-128)&&(hueValue<=127)) {
		RMuint32 regValue=0;
		RMuint32 regAdd=0x15;
		regValue=hueValue & 0xff;
		err=write_i2c(pInstance,delay,dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
			return err;
		}		
	}
	return err;
}
RMstatus tw9919eid_setSharpness(struct RUA *pInstance, 								  
								RMuint8 dev, 
								RMuint8 delay,
								RMuint32 sharpnessValue)
{
	RMstatus err=RM_OK;	
	if ((sharpnessValue>=0)&&(sharpnessValue<=15)) {
		RMuint32 regValue=0;
		RMuint32 regAdd=0x12;
		err = read_i2c(pInstance, delay, dev, regAdd, &regValue); 
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
			return err;
		}
		regValue=regValue & 0xf0;
		regValue=regValue | (sharpnessValue & 0xff);

		printf("reg 0x12 = 0x%lx\n",regValue);
		err=write_i2c(pInstance,delay,dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
			return err;
		}		
	}
	return err;
}

RMstatus tw9919eid_setCTI(struct RUA *pInstance, 								  
						  RMuint8 dev, 
						  RMuint8 delay,
						  RMuint32 ctiValue)
{
	RMstatus err=RM_OK;	
	if ((ctiValue>=0)&&(ctiValue<=3)) {
		RMuint32 regValue=0;
		RMuint32 regAdd=0x12;
		err = read_i2c(pInstance, delay, dev, regAdd, &regValue); 
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
			return err;
		}
		regValue=regValue & 0xcf;
		regValue=regValue | ((ctiValue & 0xff)<<4);
		printf("reg 0x12 = 0x%lx\n",regValue);
		err=write_i2c(pInstance,delay,dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
			return err;
		}		
	}
	return err;
}


RMstatus tw9919eid_setYGain(struct RUA *pInstance, 								  
							RMuint8 dev, 
							RMuint8 delay,
							RMuint32 value)
{
	RMstatus err=RM_OK;	
	if ((value>=0)&&(value<=3)) {
		RMuint32 regValue=0;
		RMuint32 regAdd=0x70;
		err = read_i2c(pInstance, delay, dev, regAdd, &regValue); 
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
			return err;
		}
		regValue=regValue & 0x0f;
		regValue=regValue | ((value & 0xff)<<4);
		printf("write to 0x%lx value 0x%lx\n",regAdd,regValue);
		err=write_i2c(pInstance,delay,dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
			return err;
		}		
	}
	return err;
}
RMstatus tw9919eid_setCGain(struct RUA *pInstance, 								  
							RMuint8 dev, 
							RMuint8 delay,
							RMuint32 value)
{
	RMstatus err=RM_OK;	
	if ((value>=0)&&(value<=3)) {
		RMuint32 regValue=0;
		RMuint32 regAdd=0x71;
		err = read_i2c(pInstance, delay, dev, regAdd, &regValue); 
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
			return err;
		}
		regValue=regValue & 0x0f;
		regValue=regValue | ((value & 0xff)<<4);
		printf("write to 0x%lx value 0x%lx\n",regAdd,regValue);
		err=write_i2c(pInstance,delay,dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
			return err;
		}		
	}
	return err;
}
RMstatus tw9919eid_setMDLevel1(struct RUA *pInstance, 								  
							   RMuint8 dev, 
							   RMuint8 delay,
							   RMuint32 value)
{
	RMstatus err=RM_OK;	
	if ((value>=0)&&(value<=3)) {
		RMuint32 regValue=0;
		RMuint32 regAdd=0x73;
		err = read_i2c(pInstance, delay, dev, regAdd, &regValue); 
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
			return err;
		}
		regValue=regValue & 0xf0;
		regValue=regValue | (value & 0xff);
		printf("write to 0x%lx value 0x%lx\n",regAdd,regValue);
		err=write_i2c(pInstance,delay,dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
			return err;
		}		
	}
	return err;
}
RMstatus tw9919eid_setMDLevel2(struct RUA *pInstance, 								  
							   RMuint8 dev, 
							   RMuint8 delay,
							   RMuint32 value)
{
	RMstatus err=RM_OK;	
	if ((value>=0)&&(value<=3)) {
		RMuint32 regValue=0;
		RMuint32 regAdd=0x74;
		regValue=(value & 0xff);
		printf("write to 0x%lx value 0x%lx\n",regAdd,regValue);
		err=write_i2c(pInstance,delay,dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
			return err;
		}		
	}
	return err;
}

RMstatus tw9919eid_setMDLevel3(struct RUA *pInstance, 								  
							   RMuint8 dev, 
							   RMuint8 delay,
							   RMuint32 value)
{
	RMstatus err=RM_OK;	
	if ((value>=0)&&(value<=3)) {
		RMuint32 regValue=0;
		RMuint32 regAdd=0x75;
		regValue=(value & 0xff);
		printf("write to 0x%lx value 0x%lx\n",regAdd,regValue);
		err=write_i2c(pInstance,delay,dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
			return err;
		}		
	}
	return err;
}

RMstatus tw9919eid_setMIX(struct RUA *pInstance, 								  
						  RMuint8 dev, 
						  RMuint8 delay,
							   RMuint32 value)
{
	RMstatus err=RM_OK;	
	if ((value>=0)&&(value<=3)) {
		RMuint32 regValue=0;
		RMuint32 regAdd=0x76;
		err = read_i2c(pInstance, delay, dev, regAdd, &regValue); 
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
			return err;
		}
		regValue=regValue & 0x8f;
		regValue=regValue | ((value & 0xff)<<4);
		printf("write to 0x%lx value 0x%lx\n",regAdd,regValue);
		err=write_i2c(pInstance,delay,dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
			return err;
		}		
	}
	return err;
}
//3D FILTER ////////////////////////////////////////////////////////////////////////

static RMstatus SetNRGain(struct RUA *pInstance, 								  
			   RMuint8 dev, 
			   RMuint8 delay,
			   RMuint32 val){
	
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x77;	
	err=read_i2c(pInstance,delay,dev,regAdd,&regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}	
	regValue &= 0xcf ;
	regValue |= (val<<4) ;
	err=write_i2c(pInstance,delay,dev,regAdd,regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
		return err;
	}	
	return err;
}

static RMstatus SetNRLevel(struct RUA *pInstance, 								  
				RMuint8 dev, 
				RMuint8 delay,
				RMuint32 val){

	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x77;
	err=read_i2c(pInstance,delay,dev,regAdd,&regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	regValue &= 0xf0;
	regValue |= val;
	err=write_i2c(pInstance,delay,dev,regAdd,regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
		return err;
	}
	
	return err;
}

RMstatus tw9919eid_Enable3DNRDemo(struct RUA *pInstance, 								  
					RMuint8 dev, 
					RMuint8 delay)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;
	
	SetNRGain(pInstance,dev,delay,0x00);					// NR gain 0
	SetNRLevel(pInstance,dev,delay,0x0f);				// NR Max
	//SetNRLevel(pInstance,dev,delay,0x0e);

	regAdd=0x82;
	err=read_i2c(pInstance,delay,dev,regAdd,&regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	
//	regValue |= 0x40 ;						// NR Demo mode : bit 6
	regValue |= 0x02 ;						// NR double : bit 2
		
	err=write_i2c(pInstance,delay,dev,regAdd,regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
		return err;
	}
	
	return err;
	
}


RMstatus tw9919eid_Disable3DNRDemo(struct RUA *pInstance, 								  
					 RMuint8 dev, 
					 RMuint8 delay)
{
	
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;
	
	SetNRGain(pInstance,dev,delay,0x01);					// NR gain default
	SetNRLevel(pInstance,dev,delay,0x04);				// NR level default

	regAdd=0x82;
	err=read_i2c(pInstance,delay,dev,regAdd,&regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	
	regValue &= ~0x40;					// NR Demo mode : bit 6 
	regValue &= ~0x02;					// NR double : bit 2
	
	err=write_i2c(pInstance,delay,dev,regAdd,(regValue & 0xbf));
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
		return err;
	}
	
	return err;	
}

RMstatus tw9919eid_Enable3DCombFilter(struct RUA *pInstance, 								  
									  RMuint8 dev, 
									  RMuint8 delay)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;
	regAdd=0x72;
	err=read_i2c(pInstance,delay,dev,regAdd,&regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	//100xxxxx 3D  Adaptive mode
	regValue &= 0x9c;					
	regValue |= 0x80; 
	
	err=write_i2c(pInstance,delay,dev,regAdd,regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
		return err;
	}
	
	return err;	
	
}

RMstatus tw9919eid_Disable3DCombFilter(struct RUA *pInstance, 								  
									   RMuint8 dev, 
									   RMuint8 delay)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;
	regAdd=0x72;
	err=read_i2c(pInstance,delay,dev,regAdd,&regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	//001xxxxx 2D Adaptive Mode
	regValue &= 0x3c;
	regValue |= 0x20;
	
	//011xxxxx 2D Fixed Mode
	regValue &= 0x7c;
	regValue |= 0x60;
	
	
	err=write_i2c(pInstance,delay,dev,regAdd,regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
		return err;
	}
	
	return err;	
}

RMstatus tw9919eid_PowerDown(struct RUA *pInstance, 								  
									   RMuint8 dev, 
									   RMuint8 delay)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;
	regAdd=0x06;
	regValue=0x27;
	err=write_i2c(pInstance,delay,dev,regAdd,regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
		return err;
	}
	
	return err;
}

RMstatus tw9919eid_PowerUp(struct RUA *pInstance, 								  
							 RMuint8 dev, 
							 RMuint8 delay)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;
	regAdd=0x06;
	regValue=0x0;
	err=write_i2c(pInstance,delay,dev,regAdd,regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
		return err;
	}
	
	return err;
}

RMstatus tw9919eid_EnableBlueScreen(struct RUA *pInstance, 								  
						   RMuint8 dev, 
						   RMuint8 delay)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;
	regAdd=0x2f;
	err=read_i2c(pInstance,delay,dev,regAdd,&regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	regValue |= 0x06;
	err=write_i2c(pInstance,delay,dev,regAdd,regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
		return err;
	}
	
	return err;
}

RMstatus tw9919eid_DisableBlueScreen(struct RUA *pInstance, 								  
									RMuint8 dev, 
									RMuint8 delay)
{
	RMstatus err=RM_OK;
	RMuint32 regValue=0x00;
	RMuint32 regAdd=0x00;
	regAdd=0x2f;
	err=read_i2c(pInstance,delay,dev,regAdd,&regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to read reg 0x%lx\n",regAdd);
		return err;
	}
	regValue &= 0xf9;
	err=write_i2c(pInstance,delay,dev,regAdd,regValue);
	if (RMFAILED(err)) {
		fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
		return err;
	}
	
	return err;
}

static RMstatus tw9919eid_TestRegister(struct RUA *pInstance, 								  
									   RMuint8 dev, 
									   RMuint8 delay,
									   RMuint32 regAdd,
									   RMuint32 isAsc)
{

	RMstatus err=RM_OK;
	RMuint32 regValue=0;
	RMuint32 i=0;

	for(i=0;i<=255;i++)
	{
		if (!isAsc) 
			regValue=255-i;
		else
			regValue=i;
		err=write_i2c(pInstance,delay,dev,regAdd,regValue);
		if (RMFAILED(err)) {
			fprintf(stderr, "Failed to write reg 0x%lx\n",regAdd);
			return err;
		}
		usleep(50000);
		printf("0x%lx = 0x%lx\n",regAdd,regValue);
		
	}
	return err;
}

void tw9919eid_Debug(struct 
					 RUA *pInstance, 								  
					 RMuint8 dev, 
					 RMuint8 delay,
					 RMuint8 key)
{
	switch(key) {
	case 'w':
		{
			
			RMuint32 regAdd;
			RMuint32 regValue;
			printf("Write regAdd = ");scanf("%lx",&regAdd);
			printf("regValue = ");scanf("%lx",&regValue);
			write_i2c(pInstance,delay,dev,regAdd,regValue);
			printf("Write to 0x%lx value 0x%lx\n",regAdd,regValue);
			break;
		}
	case 'r':
		{
			
			RMuint32 regAdd;
			RMuint32 regValue;
			printf("Read regAdd = ");scanf("%lx",&regAdd);							
			read_i2c(pInstance,delay,dev,regAdd,&regValue);
			printf("Read to 0x%lx value 0x%lx\n",regAdd,regValue);
			break;
		}
	case 'a':
		{
			
			tw9919eid_checkRegisterSet(pInstance,dev,delay);
			break;
		}	
	case '3':
		
		if (tw9919eid_Enable3DCombFilter(pInstance,dev,delay)==RM_OK) {
			printf("Enable 3D CombFilter \n");
		}
		
		break;
	case '2':
		if (tw9919eid_Disable3DCombFilter(pInstance,dev,delay)==RM_OK) {
			printf("Disable 3D CombFilter \n");
		}
		break;
		
	case '6':
		
		if (tw9919eid_Enable3DNRDemo(pInstance,dev,delay)==RM_OK) {
			printf("Enable 3D Noise Reduction \n");
		}
		
		break;
	case '4':
		if (tw9919eid_Disable3DNRDemo(pInstance,dev,delay)==RM_OK) {
			printf("Disable 3D Noise Reduction \n");
		}
		break;

	case '0':
		{
		
			RMuint32 regAdd;
			printf("Write regAdd = ");scanf("%lx",&regAdd);			
			tw9919eid_TestRegister(pInstance,dev,delay,regAdd,1);
			break;
		}
	case '1':
		{
			
			RMuint32 regAdd;
			printf("Write regAdd = ");scanf("%lx",&regAdd);			
			tw9919eid_TestRegister(pInstance,dev,delay,regAdd,0);
			break;
		}
	default:
		break;
	}
}

RMstatus tw9919eid_setManualColorSystem(struct RUA *pInstance,
						  RMuint8 dev, 
						  RMuint8 delay,
						  RMuint8 isNTSC
						  )
{
	   		
	RMstatus err=RM_OK;
//	RMuint32 regValue=0;
	RMuint32 Reg1C, Reg30;//, Colorsystem, LastColorSystem; // PAL	
	
	//delay(50);
	usleep(50);		
	err = read_i2c(pInstance, delay, dev, 0x1c, &Reg1C); 
	if (RMFAILED(err)) {
		fprintf(stderr, "setManualColorSystem() Error <2>\n");
		return err;
	}
	printf("reg 0x1c = 0x%02lx\n",Reg1C);
	err = read_i2c(pInstance, delay, dev, 0x30, &Reg30); 
	if (RMFAILED(err)) {
		fprintf(stderr, "setManualColorSystem() Error <3>\n");
		return err;
	}
	printf("reg 0x30 = 0x%02lx\n",Reg30);
	printf("setManualColorSystem <0>\n");
	{
			if( !isNTSC ) // 50Hz ? Pal 
			{
				printf("setManualColorSystem <1>\n");
				switch( Reg1C & 0x07) {
					case 0x01 : // PAL
						printf("setManualColorSystem <0>\n");
						if( ( Reg30 & 0xF0 ) == 0x50 ) 
						{
							printf(" ==> Changed Colorsystem to SECAM \r\n");
							err=write_i2c(pInstance,delay,dev,0x1c,0x02);
							if (RMFAILED(err)) {
								fprintf(stderr, "setManualColorSystem() Error <4>\n");
								return err;
							}
							
						}
						else if ( (( Reg30 & 0xF0 ) == 0x20 ) )
						{
							printf(" ==> Changed Colorsystem to PAL-N \r\n");
							err=write_i2c(pInstance,delay,dev,0x1c,0x05);
							if (RMFAILED(err)) {
								fprintf(stderr, "setManualColorSystem() Error <5>\n");
								return err;
							}
						}
						break;	
					case 0x02 : // SECAM
						if( (( Reg30 & 0xF0 ) == 0xD0 ) ) // Weak signal
						{
							printf(" ==> Changed Colorsystem to PAL \r\n");
							err=write_i2c(pInstance,delay,dev,0x1c,0x01);
							if (RMFAILED(err)) {
								fprintf(stderr, "setManualColorSystem() Error <6>\n");
								return err;
							}
							usleep(1);
							err = read_i2c(pInstance, delay, dev, 0x30, &Reg30); 
							if (RMFAILED(err)) {
								fprintf(stderr, "setManualColorSystem() Error <7>\n");
								return err;
							}
							
							if(((Reg30 &0xF0) == 0x20))
							{
								printf(" ==> Changed Colorsystem to PAL-N \r\n");
								//MonWriteI2C(0x88, 0x1c, 0x05);	// Go to PAL-N
								err=write_i2c(pInstance,delay,dev,0x1c,0x05);
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <7>\n");
									return err;
								}
							}
						}
						else if( ( Reg30 & 0xF0 ) == 0xF0 ) 
						{
							printf(" ==> Changed Colorsystem to PAL-N \r\n");
							//MonWriteI2C(0x88, 0x1c, 0x05);	// Go to PAL-N
							err=write_i2c(pInstance,delay,dev,0x1c,0x05);
							if (RMFAILED(err)) {
								fprintf(stderr, "setManualColorSystem() Error <8>\n");
								return err;
							}
						}
						break;

					case 0x00 : // NTSC
						if( (( Reg30 & 0xF0 ) == 0x20 ) 
							|| (( Reg30 & 0xF0 ) == 0x00 )
							|| (( Reg30 & 0xF0 ) == 0x10 ) )	// Weak signal
						{
							printf(" ==> Changed Colorsystem to PAL \r\n");
							//MonWriteI2C(0x88, 0x1c, 0x01);	// Go to PAL
							err=write_i2c(pInstance,delay,dev,0x1c,0x01);
							if (RMFAILED(err)) {
								fprintf(stderr, "setManualColorSystem() Error <9>\n");
								return err;
							}
							
							//delay(10);
							usleep(10);
							//Reg30 = ReadTW99(0x30);
							err = read_i2c(pInstance, delay, dev, 0x30, &Reg30); 
							if (RMFAILED(err)) {
								fprintf(stderr, "setManualColorSystem() Error <10>\n");
								return err;
							}
							if(((Reg30 &0xF0) == 0x50))
							{
								printf(" ==> Changed Colorsystem to SECAM \r\n");
								//MonWriteI2C(0x88, 0x1c, 0x02);	// Go to SECAM
								err=write_i2c(pInstance,delay,dev,0x1c,0x02);
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <11>\n");
									return err;
								}
							}
						}
						else if( ( Reg30 & 0xF0 ) == 0x30 ) 
						{
							printf(" ==> Changed Colorsystem to SECAM \r\n");
							//MonWriteI2C(0x88, 0x1c, 0x02);	// Go to SECAM
							err=write_i2c(pInstance,delay,dev,0x1c,0x02);
							if (RMFAILED(err)) {
								fprintf(stderr, "setManualColorSystem() Error <12>\n");
								return err;
							}
						}
						else if( ( Reg30 & 0xF0 ) == 0x50 ) 
						{
							printf(" ==> Changed Colorsystem to PAL-N \r\n");
							//MonWriteI2C(0x88, 0x1c, 0x05);	// Go to PAL-N
							err=write_i2c(pInstance,delay,dev,0x1c,0x05);
							if (RMFAILED(err)) {
								fprintf(stderr, "setManualColorSystem() Error <13>\n");
								return err;
							}
						}
						break;
						
					case 0x04 : // PAL-M
						if( (( Reg30 & 0xF0 ) == 0x20 ) 
							|| (( Reg30 & 0xF0 ) == 0x10 )   // Weak signal
							|| (( Reg30 & 0xF0 ) == 0x00 ))	
						{
							printf(" ==> Changed Colorsystem to PAL \r\n");
							//MonWriteI2C(0x88, 0x1c, 0x01);	// Go to PAL
							err=write_i2c(pInstance,delay,dev,0x1c,0x01);
							if (RMFAILED(err)) {
								fprintf(stderr, "setManualColorSystem() Error <14>\n");
								return err;
							}

							//delay(15);
							usleep(15);
							//Reg30 = ReadTW99(0x30);
							err = read_i2c(pInstance, delay, dev, 0x30, &Reg30); 
							if (RMFAILED(err)) {
								fprintf(stderr, "setManualColorSystem() Error <10>\n");
								return err;
							}
							
							if( ( Reg30 & 0xF0 ) == 0x50 ) { 
								printf(" ==> Changed Colorsystem to SECAM \r\n");
								//MonWriteI2C(0x88, 0x1c, 0x02);	// Go to SECAM
								err=write_i2c(pInstance,delay,dev,0x1c,0x02);
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <15>\n");
									return err;
								}
							}
							else if( ( Reg30 & 0xF0 ) == 0x20 ) 
							{
								printf(" ==> Changed Colorsystem to PAL-N \r\n");
								//MonWriteI2C(0x88, 0x1c, 0x05);	// Go to PAL-N
								err=write_i2c(pInstance,delay,dev,0x1c,0x05);
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <15>\n");
									return err;
								}
							}
						}
						else if( ( Reg30 & 0xF0 ) == 0x70 ) 
						{ 
							printf(" ==> Changed Colorsystem to SECAM \r\n");
							//MonWriteI2C(0x88, 0x1c, 0x02);	// Go to SECAM
							err=write_i2c(pInstance,delay,dev,0x1c,0x02);
							if (RMFAILED(err)) {
								fprintf(stderr, "setManualColorSystem() Error <15>\n");
								return err;
							}
						}
						
					       break;
				
					case 0x05 : // PAL-N
						if( (( Reg30 & 0xF0 ) == 0x20 ) 
							|| (( Reg30 & 0xF0 ) == 0x50 ) // Weak signal
							|| (( Reg30 & 0xF0 ) == 0x10 ))	//JR-020705
						{
							printf(" ==> Changed Colorsystem to PAL \r\n");
							//MonWriteI2C(0x88, 0x1c, 0x01);	// Go to PAL
							err=write_i2c(pInstance,delay,dev,0x1c,0x01);
							if (RMFAILED(err)) {
								fprintf(stderr, "setManualColorSystem() Error <15>\n");
								return err;
							}

							//delay(15); 
							usleep(15);
							//Reg30 = ReadTW99(0x30);
							err = read_i2c(pInstance, delay, dev, 0x30, &Reg30); 
							if (RMFAILED(err)) {
								fprintf(stderr, "setManualColorSystem() Error <10>\n");
								return err;
							}
							
							if( ( Reg30 & 0xF0 ) == 0x50 ) { 
								printf(" ==> Changed Colorsystem to SECAM \r\n");
								//MonWriteI2C(0x88, 0x1c, 0x02);	// Go to SECAM
								err=write_i2c(pInstance,delay,dev,0x1c,0x02);
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <15>\n");
									return err;
								}
							}
						}
						else if( (( Reg30 & 0xF0 ) == 0x70 )
							    || ((Reg30 & 0xF0) == 0x40)
							    || ((Reg30 & 0xF0) == 0x30) )
						{ 
							printf(" ==> Changed Colorsystem to SECAM \r\n");
							//MonWriteI2C(0x88, 0x1c, 0x02);	// Go to SECAM
							err=write_i2c(pInstance,delay,dev,0x1c,0x02);
							if (RMFAILED(err)) {
								fprintf(stderr, "setManualColorSystem() Error <15>\n");
								return err;
							}
						}
						break;		
							
					case 0x03: // NTSC4.43
						if (( Reg30 & 0xF0 ) == 0x40 ) 
						{
							printf(" ==> Changed Colorsystem to PAL \r\n");
							//MonWriteI2C(0x88, 0x1c, 0x01);	// Go to PAL
							err=write_i2c(pInstance,delay,dev,0x1c,0x01);
							if (RMFAILED(err)) {
								fprintf(stderr, "setManualColorSystem() Error <15>\n");
								return err;
							}
						}
						else if( (( Reg30 & 0xF0 ) == 0x50 ) || (( Reg30 & 0xF0 ) == 0x10 ))
						{
							printf(" ==> Changed Colorsystem to SECAM \r\n");
							//MonWriteI2C(0x88, 0x1c, 0x02);	// Go to SECAM
							err=write_i2c(pInstance,delay,dev,0x1c,0x02);
							if (RMFAILED(err)) {
								fprintf(stderr, "setManualColorSystem() Error <15>\n");
								return err;
							}
							//delay(1);
							usleep(1);
							//Reg30 = ReadTW99(0x30);
							err = read_i2c(pInstance, delay, dev, 0x30, &Reg30); 
							if (RMFAILED(err)) {
								fprintf(stderr, "setManualColorSystem() Error <10>\n");
								return err;
							}
							
							if( (( Reg30 & 0xF0 ) == 0xF0 ) || ((Reg30 & 0xF0) == 0xD0))
							{
								printf(" ==> Changed Colorsystem to PAL-N \r\n");
								//MonWriteI2C(0x88, 0x1c, 0x05);	// Go to PAL-N
								err=write_i2c(pInstance,delay,dev,0x1c,0x05);
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <15>\n");
									return err;
								}
							}
							}
							else if( (( Reg30 & 0xF0 ) == 0x70 ) )
							{
								printf(" ==> Changed Colorsystem to PAL-N \r\n");
								//MonWriteI2C(0x88, 0x1c, 0x05);	// Go to PAL-N
								err=write_i2c(pInstance,delay,dev,0x1c,0x05);
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <15>\n");
									return err;
								}
							}
							break;		
							
					case 0x06: // PAL60
						if( (Reg30 & 0xF0 ) == 0 ) 
						{
							printf(" ==> Changed Colorsystem to PAL \r\n");
							//MonWriteI2C(0x88, 0x1c, 0x01);	// Go to PAL
							err=write_i2c(pInstance,delay,dev,0x1c,0x01);
							if (RMFAILED(err)) {
								fprintf(stderr, "setManualColorSystem() Error <15>\n");
								return err;
							}
							//delay(1);
							usleep(1);
							//Reg30 = ReadTW99(0x30);
							err = read_i2c(pInstance, delay, dev, 0x30, &Reg30); 
							if (RMFAILED(err)) {
								fprintf(stderr, "setManualColorSystem() Error <10>\n");
								return err;
							}
							
							if( ( Reg30 & 0xF0 ) == 0x20 )
							{
								printf(" ==> Changed Colorsystem to PAL-N \r\n");
								//MonWriteI2C(0x88, 0x1c, 0x05);	// Go to PAL-N
								err=write_i2c(pInstance,delay,dev,0x1c,0x05);
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <15>\n");
									return err;
								}
							}
						}
						else if( ((Reg30 & 0xF0) == 0x10) || (( Reg30 & 0xF0 ) == 0x50 )) 
						{
							printf(" ==> Changed Colorsystem to SECAM \r\n");
							//MonWriteI2C(0x88, 0x1c, 0x02);	// Go to SECAM
							err=write_i2c(pInstance,delay,dev,0x1c,0x02);
							if (RMFAILED(err)) {
								fprintf(stderr, "setManualColorSystem() Error <15>\n");
								return err;
							}
						}
						else if( ( Reg30 & 0xF0 ) == 0x20) 
						{
							printf(" ==> Changed Colorsystem to PAL-N \r\n");
							//MonWriteI2C(0x88, 0x1c, 0x05);	// Go to PAL-N
							err=write_i2c(pInstance,delay,dev,0x1c,0x05);
							if (RMFAILED(err)) {
								fprintf(stderr, "setManualColorSystem() Error <15>\n");
								return err;
							}
						}
  					       break;
				}//switch
			}
			else 	// 60Hz
			{
				printf("setManualColorSystem <2>\n");
					switch( Reg1C & 0x07) {
						case 0x00 : // NTSC
							if( ( Reg30 & 0xF0 ) == 0x50 )
							{
								printf(" ==> Changed Colorsystem to PAL-M \r\n");
								//MonWriteI2C(0x88, 0x1c, 0x04);	// Go to PAL-M
								err=write_i2c(pInstance,delay,dev,0x1c,0x04);
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <15>\n");
									return err;
								}
							}	
							else if( ( Reg30 & 0xF0 ) == 0x20 )
							{ 
								printf(" ==> Changed Colorsystem to NTSC4.43 \r\n");
								//MonWriteI2C(0x88, 0x1c, 0x03);	// Go to NTSC4.43
								err=write_i2c(pInstance,delay,dev,0x1c,0x03);
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <15>\n");
									return err;
								}
								
								//delay(1); // Feb/7/2005
								usleep(1);
								if( ( Reg30 & 0xF0 ) == 0x40 ) { 
								printf(" ==> Changed Colorsystem to PAL60 \r\n");
								//MonWriteI2C(0x88, 0x1c, 0x06);	// Go to PAL60
								err=write_i2c(pInstance,delay,dev,0x1c,0x06);
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <15>\n");
									return err;
								}
								}
							}
							break;

						case 0x01: // PAL
							if( (( Reg30 & 0xF0 ) == 0x20 )
								|| (( Reg30 & 0xF0 ) == 0x30 ) ) { 
						
								printf(" ==> Changed Colorsystem to NTSC \r\n");
								//MonWriteI2C(0x88, 0x1c, 0x00);	// Go to NTSC
								err=write_i2c(pInstance,delay,dev,0x1c,0x00);
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <15>\n");
									return err;
								}

								//delay(10);
								usleep(10);
								//Reg30 = ReadTW99(0x30);
								err = read_i2c(pInstance, delay, dev, 0x30, &Reg30); 
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <10>\n");
									return err;
								}
								if( ( Reg30 & 0xF0 ) == 0x50 ) { 
									printf(" ==> Changed Colorsystem to PAL-M \r\n");
									//MonWriteI2C(0x88, 0x1c, 0x04);	// Go to PAL-M
									err=write_i2c(pInstance,delay,dev,0x1c,0x04);
									if (RMFAILED(err)) {
										fprintf(stderr, "setManualColorSystem() Error <15>\n");
										return err;
									}
								}
							}
							else if( ( Reg30 & 0xF0 ) == 0x40 ) { 
						
								printf(" ==> Changed Colorsystem to NTSC4.43 \r\n");
//								MonWriteI2C(0x88, 0x1c, 0x03);	// Go to NTSC4.43
								err=write_i2c(pInstance,delay,dev,0x1c,0x03);
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <15>\n");
									return err;
								}
							}
							else if( ( Reg30 & 0xF0 ) == 0x00 ) { 
								printf(" ==> Changed Colorsystem to PAL60 \r\n");
								//MonWriteI2C(0x88, 0x1c, 0x06);	// Go to PAL60
								err=write_i2c(pInstance,delay,dev,0x1c,0x06);
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <15>\n");
									return err;
								}
							}
							
							break;

						case 0x02: // SECAM
							if (( Reg30 & 0xF0 ) == 0xF0 ) 
							{ 
						
								printf(" ==> Changed Colorsystem to NTSC \r\n");
								//MonWriteI2C(0x88, 0x1c, 0x00);	// Go to NTSC
								err=write_i2c(pInstance,delay,dev,0x1c,0x00);
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <15>\n");
									return err;
								}

								//delay(15);
								usleep(15);
								//Reg30 = ReadTW99(0x30);
								err = read_i2c(pInstance, delay, dev, 0x30, &Reg30); 
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <10>\n");
									return err;
								}
								if( ( Reg30 & 0xF0 ) == 0x50 ) { 
									printf(" ==> Changed Colorsystem to PAL-M \r\n");
									//MonWriteI2C(0x88, 0x1c, 0x04);	// Go to PAL-M
									err=write_i2c(pInstance,delay,dev,0x1c,0x04);
									if (RMFAILED(err)) {
										fprintf(stderr, "setManualColorSystem() Error <15>\n");
										return err;
									}
								}
							}
							else if( ( Reg30 & 0xF0 ) == 0x30 ) { 
									printf(" ==> Changed Colorsystem to PAL-M \r\n");
									//MonWriteI2C(0x88, 0x1c, 0x04);	// Go to PAL-M
									err=write_i2c(pInstance,delay,dev,0x1c,0x04);
									if (RMFAILED(err)) {
										fprintf(stderr, "setManualColorSystem() Error <15>\n");
										return err;
									}
							}
							else if( ( Reg30 & 0xF0 ) == 0xd0 ) { 
						
								printf(" ==> Changed Colorsystem to NTSC4.43 \r\n");
								//MonWriteI2C(0x88, 0x1c, 0x03);	// Go to NTSC4.43
								err=write_i2c(pInstance,delay,dev,0x1c,0x03);
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <15>\n");
									return err;
								}
							}
							else if( ( Reg30 & 0xF0 ) == 0x90 ) { 
								printf(" ==> Changed Colorsystem to PAL60 \r\n");
								//MonWriteI2C(0x88, 0x1c, 0x06);	// Go to PAL60
								err=write_i2c(pInstance,delay,dev,0x1c,0x06);
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <15>\n");
									return err;
								}
							}
							break;

						case 0x03: // NTSC4.43
							if( ( Reg30 & 0xF0 ) == 0x60 ) { 
						
								printf(" ==> Changed Colorsystem to NTSC \r\n");
								//MonWriteI2C(0x88, 0x1c, 0x00);	// Go to NTSC
								err=write_i2c(pInstance,delay,dev,0x1c,0x00);
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <15>\n");
									return err;
								}
                                                        }	
							else if( ( Reg30 & 0xF0 ) == 0x70 ) { 
									printf(" ==> Changed Colorsystem to PAL-M \r\n");
									//MonWriteI2C(0x88, 0x1c, 0x04);	// Go to PAL-M
									err=write_i2c(pInstance,delay,dev,0x1c,0x04);
									if (RMFAILED(err)) {
										fprintf(stderr, "setManualColorSystem() Error <15>\n");
										return err;
									}
							}
							else if( ( Reg30 & 0xF0 ) == 0x40 ) { 
								printf(" ==> Changed Colorsystem to PAL60 \r\n");
								//MonWriteI2C(0x88, 0x1c, 0x06);	// Go to PAL60
								err=write_i2c(pInstance,delay,dev,0x1c,0x06);
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <15>\n");
									return err;
								}
							}

							break;
						case 0x04: // PAL-M
							if( ( Reg30 & 0xF0 ) == 0x50 ) { 
						
								printf(" ==> Changed Colorsystem to NTSC \r\n");
								//MonWriteI2C(0x88, 0x1c, 0x00);	// Go to NTSC
								err=write_i2c(pInstance,delay,dev,0x1c,0x00);
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <15>\n");
									return err;
								}
							}
							else if( ( Reg30 & 0xF0 ) == 0x20 ) { 
						
								printf(" ==> Changed Colorsystem to NTSC4.43 \r\n");
								//MonWriteI2C(0x88, 0x1c, 0x03);	// Go to NTSC4.43
								err=write_i2c(pInstance,delay,dev,0x1c,0x03);
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <15>\n");
									return err;
								}

								//delay(1);
								usleep(1);
								//Reg30 = ReadTW99(0x30);
								err = read_i2c(pInstance, delay, dev, 0x30, &Reg30); 
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <10>\n");
									return err;
								}
								if( ( Reg30 & 0xF0 ) == 0x40 ) { 
									printf(" ==> Changed Colorsystem to PAL60 \r\n");
									//MonWriteI2C(0x88, 0x1c, 0x06);	// Go to PAL60
									err=write_i2c(pInstance,delay,dev,0x1c,0x06);
									if (RMFAILED(err)) {
										fprintf(stderr, "setManualColorSystem() Error <15>\n");
										return err;
									}
									
								}
							}
							break;

						case 0x05: // PAL-N
							if( ( Reg30 & 0xF0 ) == 0x50 ) { 
								printf(" ==> Changed Colorsystem to NTSC \r\n");
								//MonWriteI2C(0x88, 0x1c, 0x00);	// Go to NTSC 
								err=write_i2c(pInstance,delay,dev,0x1c,0x00);
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <15>\n");
									return err;
								}
								

							}
							else if( ( Reg30 & 0xF0 ) == 0x20 ) { 
						
								printf(" ==> Changed Colorsystem to NTSC4.43 \r\n");
								//MonWriteI2C(0x88, 0x1c, 0x03);	// Go to NTSC4.43
								err=write_i2c(pInstance,delay,dev,0x1c,0x03);
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <15>\n");
									return err;
								}
								
								//delay(1);
								usleep(1);
								//Reg30 = ReadTW99(0x30);
								err = read_i2c(pInstance, delay, dev, 0x30, &Reg30); 
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <10>\n");
									return err;
								}
								if( ( Reg30 & 0xF0 ) == 0x40 ) { 
									printf(" ==> Changed Colorsystem to PAL60 \r\n");
									//MonWriteI2C(0x88, 0x1c, 0x06);	// Go to PAL60
									err=write_i2c(pInstance,delay,dev,0x1c,0x06);
									if (RMFAILED(err)) {
										fprintf(stderr, "setManualColorSystem() Error <15>\n");
										return err;
									}
								}
							}
							else if( ( Reg30 & 0xF0 ) == 0x10 ) { 
						
								printf(" ==> Changed Colorsystem to PAL-M \r\n");
								//MonWriteI2C(0x88, 0x1c, 0x04);	// Go to PAL-M
								err=write_i2c(pInstance,delay,dev,0x1c,0x04);
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <15>\n");
									return err;
								}

							}
							break;
						case 0x06: //PAL60
							if( ( Reg30 & 0xF0 ) == 0x20 ) { 	
								printf(" ==> Changed Colorsystem to NTSC \r\n");
								//MonWriteI2C(0x88, 0x1c, 0x00);	// Go to NTSC
								err=write_i2c(pInstance,delay,dev,0x1c,0x00);
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <15>\n");
									return err;
								}
								//delay(1);
								usleep(1);
								//Reg30 = ReadTW99(0x30);
								err = read_i2c(pInstance, delay, dev, 0x30, &Reg30); 
								if (RMFAILED(err)) {
									fprintf(stderr, "setManualColorSystem() Error <10>\n");
									return err;
								}
								if( ( Reg30 & 0xF0 ) == 0x50 ) { 
									printf(" ==> Changed Colorsystem to PAL-M \r\n");
								//	MonWriteI2C(0x88, 0x1c, 0x04);	// Go to PAL-M
									err=write_i2c(pInstance,delay,dev,0x1c,0x04);
									if (RMFAILED(err)) {
										fprintf(stderr, "setManualColorSystem() Error <15>\n");
										return err;
									}
								}
							}
							break;
						}//switch
						
				   }
			}
	return err;				
}

void tw9919eid_showMenu()
{
	
	printf(" \n ******************** MENU ************************\n");
	printf("  c: decrease contrast   - C: increase contrast\n");
	printf("  b: decrease brightness - B: increase brightness\n");
	printf("  t: decrease saturation - T: increase saturation\n");
	printf("  h: decrease hue		 - H: increase hue\n");
	printf("  s: decrease sharpness	 - S: increase sharpness\n");
#ifndef NO_AUDIO
	printf("  v: decrease Volume	 - V: increase Volume\n");
#endif
	printf("  z: Switch CVBS -> SVIDEO -> TUNER.\n");
#ifndef NO_AUDIO
	printf("  x: Switch Audio Output HeadPhone <--> LoudSpeaker.\n");
	printf("  y: Switch Audio Input Scart1 <--> Audio Input Scart4.\n");
#endif	
	printf("  q: Exit .\n");
	printf(" \n **************************************************\n");
	
	
}
RMstatus tw9919eid_EnableTT(struct RUA *pInstance, 	//Enable Teletext
							RMuint8 dev, 
							RMuint8 delay)
{
	RMstatus err=RM_OK;
	
	err=init_i2c(pInstance,delay,dev,TW9919E_TT_Enable,sizeof(TW9919E_TT_Enable)/2/sizeof(RMuint8));					
	if (RMFAILED(err)) {
		fprintf(stderr, " tw9919eid EnableTT Failed\n");
		return err;
	}
	err=init_i2c(pInstance,delay,dev,TW9919E_TT_B,sizeof(TW9919E_TT_B)/2/sizeof(RMuint8));					
	if (RMFAILED(err)) {
		fprintf(stderr, " tw9919eid EnableTT System B Failed\n");
		return err;
	}
	return err;
}
RMstatus tw9919eid_EnableCC(struct RUA *pInstance, 	//Enable Close Caption							  
							RMuint8 dev, 
							RMuint8 delay)
{
	RMstatus err=RM_OK;
	
	err=init_i2c(pInstance,delay,dev,TW9919E_CC_Enable,sizeof(TW9919E_CC_Enable)/2/sizeof(RMuint8));					
	if (RMFAILED(err)) {
		fprintf(stderr, " tw9919eid EnableCC Failed\n");
		return err;
	}
	
	return err;
}
