/*
 *
 * Copyright (c) Sigma Designs, Inc. 2005. All rights reserved.
 *
 */

/**
	@file parse_display_cmdline.c
	@brief sample application to access the 86xx chip family
	
	@author Christian Wolff
*/

#include "sample_os.h"

#define ALLOW_OS_CODE 1
#include "../rua/include/rua.h"
#include "../dcc/include/dcc.h"
#include "../dcc/include/dcc_macros.h"
#include "../rmcore/include/rmstatustostring.h"
#include "common.h"
#include "outports_options.h"

#include "../emhwlib/include/emhwlib_videoformatnames.h"

#include "sigma_logo.h"

// to enable or disable the debug messages of this source file, put 1 or 0 below
#if 1
#define LOCALDBG ENABLE
#else
#define LOCALDBG DISABLE
#endif

#define SCART_ENABLE_GPIO 13
#define SCART_WIDESCREEN_GPIO 14

#define NUM_DBC 4  // how many DBCs to allocate

// CEA 861-C video mode bitmasks matching certain mode criteria
// by frame rate
#define CEA861_MASK_24HZ  0x0000000100000000LL
#define CEA861_MASK_25HZ  0x0000000200000000LL
#define CEA861_MASK_30HZ  0x0000000400000000LL
#define CEA861_MASK_50HZ  0x000000E0FFFE0000LL
#define CEA861_MASK_60HZ  0x000000180001FFFELL
#define CEA861_MASK_100HZ 0x00003F0000000000LL
#define CEA861_MASK_120HZ 0x000FC00000000000LL
#define CEA861_MASK_200HZ 0x00F0000000000000LL
#define CEA861_MASK_240HZ 0x0F00000000000000LL

// by nominal resolution
#define CEA861_MASK_BASIC 0x0000000087FF00FELL
#define CEA861_MASK_VGA   0x0000000000000002LL
#define CEA861_MASK_480I  0x0C0C000000003FC0LL
#define CEA861_MASK_576I  0x00C030001FE00000LL
#define CEA861_MASK_480P  0x030300180000C00CLL
#define CEA861_MASK_576P  0x00300C6060060000LL
#define CEA861_MASK_720P  0x0000820000080010LL
#define CEA861_MASK_1080I 0x0000418000100020LL
#define CEA861_MASK_1080P 0x0000000780010000LL
#define CEA861_MASK_SD    (CEA861_MASK_480I | CEA861_MASK_576I)  // 0x0CCC30001FE03FC0LL
#define CEA861_MASK_ED    (CEA861_MASK_480P | CEA861_MASK_576P)  // 0x03330C786006C00CLL
#define CEA861_MASK_HD    (CEA861_MASK_720P | CEA861_MASK_1080I | CEA861_MASK_1080P)

// by aspect ratio
#define CEA861_MASK_4x3   0x055514282AA25546LL
#define CEA861_MASK_16x9  0x0AAAEBD7D55DAAB8LL

extern RMbool manutest;

static RMstatus apply_outports_videomode(struct dcc_context *dcc_info, struct display_cmdline *options, RMbool hdmi_active);

RMstatus GetTVStandard(RMascii *StandardName, enum EMhwlibTVStandard *Standard)
{
	RMuint32 i;

	if (StandardName == NULL)
		return RM_ERROR;

	for (i=0 ; i<sizeof(TVFormatString)/sizeof(RMuint32) ; i++) {
		RMuint32 c=0;

		while (1) {
			if (StandardName[c] == '\0') {
				if (TVFormatString[i][c] == '\0') {
					*Standard = i + 1;
					return RM_OK;
				}
				else
					break;
			}

			if (StandardName[c] != TVFormatString[i][c]) 
				break;

			c++;
		}
	}

	return RM_ERROR;
}

RMstatus GetTVStandardName(enum EMhwlibTVStandard Standard, RMascii **StandardName)
{
	if (StandardName == NULL)
		return RM_ERROR;
	
	if (! Standard) {
		*StandardName = "Custom";
		return RM_OK;
	}
	
	Standard--;
	if ((Standard < 0) || (Standard >= sizeof(TVFormatString) / sizeof(RMuint32))) {
		*StandardName = "OutOfRange";
		return RM_ERROR;
	}
	
	*StandardName = (RMascii *)(TVFormatString[Standard]);
	
	return RM_OK;
}

#define DISP_OPT_MAX_LINE_LENGTH 64

RMstatus PrintTVStandardNames(void){
	RMuint32 video_format_num;
	RMuint32 line_length = DISP_OPT_MAX_LINE_LENGTH;
	for (video_format_num = 0; video_format_num < (sizeof TVFormatString / sizeof TVFormatString[0]); video_format_num++) {
		RMuint32 next_length = RMasciiLength(TVFormatString[video_format_num]);
		if (((line_length + next_length) > DISP_OPT_MAX_LINE_LENGTH) && (line_length != 0)) {
			fprintf(stderr, "\n\t\t");
			line_length = 0;
		}
		fprintf(stderr, "%s ", TVFormatString[video_format_num]);
		line_length += (next_length + 1);
	}
	return RM_OK;
}

RMstatus init_display_options(struct display_cmdline *options)
{
	RMuint32 i;
	
	RMMemset(options, 0, sizeof(struct display_cmdline));
	
	options->configure_outports = TRUE;
	options->standard = EMhwlibTVStandard_NTSC_M;
	options->sd_standard = EMhwlibTVStandard_Custom;
	options->sd_standard_50Hz = EMhwlibTVStandard_PAL_BG;  // PAL_N?
	options->sd_standard_60Hz = EMhwlibTVStandard_NTSC_M;  // NTSC_M_Japan? PAL_M?
	options->use_hdsd_conversion = FALSE;
	options->sd_component = FALSE;
	options->sd_cav_1080p = FALSE;
	options->allow_otf = TRUE;
	options->allow_buf = TRUE;
	options->sd_autodetect = FALSE;
	options->vidmode_filename[0] = '\0';
	options->vga_standard = EMhwlibTVStandard_Custom;
	options->connector = DCCVideoConnector_SVIDEO;
	options->component = EMhwlibComponentMode_YUV_SMPTE;
	options->color_space = EMhwlibColorSpace_YUV_601;
	options->mixer_color_space = EMhwlibColorSpace_None;
	options->bus_size = 24;

	options->ar_x = 4;
	options->ar_y = 3;
	options->active_format_valid = FALSE;
	options->active_format = EMhwlibAF_same_as_picture;
	options->sd_ar_x = 4;
	options->sd_ar_y = 3;
	options->sd_active_format_valid = FALSE;
	options->sd_active_format = EMhwlibAF_same_as_picture;
	options->target_ar_x = 0;
	options->target_ar_y = 0;
	
	options->force_route = FALSE;
	options->route = DCCRoute_Main;

	set_default_out_window(&(options->source_window));
	set_default_out_window(&(options->output_window));

	options->dump_osd_dir = NULL;

	options->show_hwc = FALSE;
	options->nonlinearmode.Width = 0;
	options->nonlinearmode.Level = 0;
	options->blackstrip.Horizontal = 4096;
	options->blackstrip.Vertical = 4096;
	options->cutstrip.Horizontal = 4096;
	options->cutstrip.Vertical = 4096;
	options->scalingmode = EMhwlibScalingMode_LetterBox;
	options->deinterlacingmode = EMhwlibDeinterlacingMode_Discard_Bob;
	options->luma_key.LumaMin = 0xff;
	options->luma_key.LumaMax = 0x00;
	options->do_pulldown = FALSE;
	options->lock_scaler = 0;

	options->deinterlacing_motion_config.Value0 = 0x00;
	options->deinterlacing_motion_config.Value8 = 0x04;
	options->deinterlacing_motion_config.Value16 = 0x40;
	options->deinterlacing_motion_config.Value32 = 0xC0;

	options->deinterlacing_proportion.ExistingLineProportion = 4;
	options->deinterlacing_proportion.NewLineProportion = 12;


	options->color_degradation_boundary = 0;

	options->agc_level = 0;
	options->agc_version = (RMuint32)EMhwlibAGCVersion_ConstantBPP;
	options->aps_level = 0;
	options->rcd = 0;
	options->asb = 0;
	options->cgmsa = 0;

	options->component_order = EMhwlibComponentOrder_RGB;
	options->field_selection = EMhwlibScalerFieldSelection_BestFieldType;
	options->dh_info = NULL;
	options->dh_first_run = FALSE;
	options->dvi_hdmi_part = DH_auto_detect;
	options->dvi_hdmi_state = DH_uninitialized;
	options->dvi_hdmi_hdcp = FALSE;
	options->dvi_hdmi_display_edid = FALSE;
	options->edid_sel = DH_EDID_none;
	options->vga_edid_sel = DH_EDID_none;
	options->dvi_hdmi_edid_descriptor = 0;
	options->dvi_hdmi_edid_vfreq = 59;
	options->dvi_hdmi_edid_hsize = 1920;
	options->dvi_hdmi_edid_vsize = 1080;
	options->dvi_hdmi_edid_intl = TRUE;
	options->hdmi_monitor = FALSE;
	options->hdmi_force = FALSE;
	options->hdmi_de = FALSE;
	options->edid_exclude_mask = 0;
	options->edid_exclude_mask_vfreq = 0;
	options->edid_exclude_mask_asp = 0;
	options->edid_force_mask = 0;
	options->edid_force_mask_vfreq = 0;
	options->edid_force_mask_asp = 0;
	options->edid_max_pixclk = 0;
	options->edid_min_pixclk = 0;
	options->edid_max_hfreq = 0;
	options->edid_min_hfreq = 0;
	options->edid_max_vfreq = 0;
	options->edid_min_vfreq = 0;
	options->dvi_hdmi_edid_write = FALSE;
	options->dvi_hdmi_edid_read = FALSE;
	options->dvi_hdmi_edid_override = FALSE;
	options->dvi_hdmi_edid_file = NULL;

	options->init_mode = DCCInitMode_LeaveDisplay;
	options->dig_protocol = EMhwlibDigitalTimingSignal_601;
	options->dig_force_doublerate = FALSE;
	options->dig_doublerate = FALSE;
	options->dig_clk_normal = FALSE;
	options->dig_ddr = FALSE;
	options->dig_inv_cap_clk = FALSE;
	options->dig_delay = 2300;
	options->dig_force_delay = FALSE;
	options->dig_vsync_delay = FALSE;
	options->dig_trailing_edge = FALSE;
	options->chroma_sync = FALSE;
	options->scart_enable = FALSE;
	options->scart_en_pio = 0;
	options->scart_widescreen = FALSE;
	options->scart_ws_pio = 0;
	options->i2c_module = 1;
	options->i2c_speed = 0;  // don't force
	options->i2c_ddc_on_tx = FALSE;
	options->dvi_reset_gpio = 0;  // no GPIO used to reset DVI chip
	options->video_scaler = 0;
	options->video_alpha = 0x80;
	options->hdmi_active_format_valid = FALSE;
	options->hdmi_active_format = DH_af_same_as_picture;
	options->hdmi_bar_top = 0;
	options->hdmi_bar_bottom = 4096;
	options->hdmi_bar_left = 0;
	options->hdmi_bar_right = 4096;
	options->hdmi_scan = EMhwlibScanInfo_NoData;
	options->hdmi_spd_vendor = NULL;
	options->hdmi_spd_product = NULL;
	options->hdmi_spd_class = DH_source_dev_unknown;
	options->tmds_threshold = 0;
	options->tmds_gpio = 0;
	options->filter_gpio_start = 0;
	options->filter_gpio_num = 0;
	options->filter_gpio_val = 0;
	
	options->genlock_input = 0;
	options->genlock_min = 0;
	options->genlock_max = 0;
	options->input = 0;
	options->input_videosource = NULL;
	options->input_mode = EMhwlibTVStandard_Custom;
	options->input_timingsignal = EMhwlibDigitalTimingSignal_656;
	options->input_vvld = FALSE;
	options->input_bussize = 8;
	options->input_invv = FALSE;
	options->input_invh = FALSE;
	options->input_usev2 = FALSE;
	options->input_interlaced = TRUE;
	options->time_interval.Mode = EMhwlibDisplayIntervalMode_None;
	
	for (i = 0; i < 2; i++) {
		options->osd_pictures[i].enable = FALSE;
		options->osd_pictures[i].filename = NULL;
		options->osd_pictures[i].alpha_merge = FALSE;
		options->osd_pictures[i].alpha_filename = NULL;
		options->osd_pictures[i].dramblock = 0;
		options->osd_pictures[i].alpha = 128;
		options->osd_pictures[i].scaler = 0;
		options->osd_pictures[i].zoom = FALSE;
		options->osd_pictures[i].color_space = EMhwlibColorSpace_None;
		options->osd_pictures[i].orientation = FRTop_FCLeft;
		options->osd_pictures[i].nonlinearmode.Width = 0;
		options->osd_pictures[i].nonlinearmode.Level = 0;
		options->osd_pictures[i].blackstrip.Horizontal = 4096;
		options->osd_pictures[i].blackstrip.Vertical = 4096;
		options->osd_pictures[i].cutstrip.Horizontal = 0;
		options->osd_pictures[i].cutstrip.Vertical = 0;
		set_default_out_window(&(options->osd_pictures[i].source_window));
		set_default_out_window(&(options->osd_pictures[i].output_window));
	}
	
	options->force_DACCompDisable = FALSE;
	options->DACCompDisable = FALSE;
	options->force_DACDisable = FALSE;
	options->DACDisable.DAC1SVideoY = FALSE;
	options->DACDisable.DAC2SVideoC = FALSE;
	options->DACDisable.DAC3CVBS    = FALSE;
	options->DACDisable.DAC4Y  = FALSE;
	options->DACDisable.DAC5Cb = FALSE;
	options->DACDisable.DAC6Cr = FALSE;
	options->force_LumaChromaDelay = FALSE;
	options->LumaChromaDelay = EMhwlibLumaChromaDelay_NoDelay;
	options->force_TripleCVBS = FALSE;
	options->TripleCVBS = FALSE;
	options->force_LineCrop = FALSE;
	options->LineCrop.CropLeftPos = 0;
	options->LineCrop.CropRightPos = 4095;
	options->LineCrop.ColorSpace = options->color_space;
	options->LineCrop.CropControl = FALSE;
	options->gamma_table = 0;
	options->disable_pixel_timer = FALSE;
	options->hdmi_convert = FALSE;
	options->hdmi_color_space = EMhwlibColorSpace_None;
	options->hdmi_sampling_mode = EMhwlibSamplingMode_444;
	options->hdmi_component_depth = 8;
	options->downscalingmode.Discard = FALSE;
	options->downscalingmode.FilterBoundary[0] = 384;
	options->downscalingmode.FilterBoundary[1] = 256;
	options->downscalingmode.FilterBoundary[2] = 128;
	options->filtermode.Boundary_0_1 = 0x1400;
	options->filtermode.Boundary_1_2 = 0x1c00;
	options->filtermode.Boundary_2_3 = 0x2c00;
	
	return RM_OK;
}


void show_display_options(void)
{
	fprintf(stderr, "DISPLAY OPTIONS (default values inside brackets)\n"
		"\t-no_disp: do not configure the outports\n"
		"Select the video timing mode with either -f, -r or -vmf\n"
		"\t-f standard: Sets output format, default is NTSC_M");
	PrintTVStandardNames();
	fprintf(stderr, "\n"
		"\t\tedid (to use preferred standard from EDID info)\n"
		"\t-edmode <width> <height> <vfreq> <interlaced>: use closest matching EDID short descriptor\n"
		"\t-r <resolution>: shortcut for -edmode, to set common video resolutions: [pref]=EDID preferred, \n"
		"\t\t480i[59], 480i60, 480p[59], 480p60, 576i[50], 576p[50], 720p50, 720p[59], 720p60, \n"
		"\t\t1080i50, 1080i[59], 1080i60, 1080p23, 1080p24, 1080p50, 1080p[59], 1080p60, vga, <VIC>\n"
		"\t-edforce: Force the mode selected by -edmode/-r, independent of display support\n"
		"\t-vmf <filename.vmf>: specify a filename with a video mode line, used instead of -f options\n"
		"\t\tWARNING: Incorrect values in the .vmf file can cause damage to the monitor or TV!\n"
		"\t\tSigma Designs is not responsible for any such damage.\n"
		"\t-vgaf standard: sets output format for VGA/DVI output separately \n"
		"\t\tfrom analog out\n"
		"\t-cs colorspace: Sets the output colorspace. [YCC601]\n"
		"\t-mcs colorspace: Sets the mixer colorspace. [none]\n"
		"\t-ocs colorspace: Sets the OSD source colorspace [none]\n"
		"\tColorspaces:\n"
		"\t\tlimited range (black at 16, white at 235): RGBl, YCC601, YCC709, extended gamut: xvYCC601, xvYCC709\n"
		"\t\tfull range (black at 0, white at 255): RGB, YCC601f, YCC709f, extended gamut: xvYCC601f, xvYCC709f\n"
		"\t-sm mode : Sets display scaling mode [letterBox] panScan ARIB\n"
		"\t-asp x y: Sets display aspect ratio  (x y in [0-255] range) [4 3]\n"
		"\t\t(0 0 means that the source aspect ratio is used for the display\n"
		"\t\taspect ratio (used with WSS).\n"
		"\t-afd <active format>: designate the portion of the screen containing actual picture information:\n"
		"\t\t[none], full, 16x9top, 14x9top, 64x27, 4x3, 16x9, 14x9, 4x3_14x9, 16x9_14x9, 16x9_4x3\n"
		"\t\tThe last 3 are optional clipping formats, e.g. the last is a 16x9 format that could be cropped to 4x3\n"
		"\t-zoom x y w h: Selects the input window to display [0 0 width height]\n"
		"\t-window x y w h: Selects the output window to display [0 0 width height] \n"
		"\t\tall zoom values: 0..4095: absolute pixel, 4096..8192: 0%%..100%% relative size\n"
		"\t-o output: Selects the output (shortcuts in brackets)\n"
		"\t\t[svideo] composite(cvbs) dvi_8 dvi_16 dvi_24(hdmi,dvi) dig_8 dig_16 dig_24 lvds\n"
		"\t\tvga scart component_rgb_scart component_rgb_sog component_rgb_smpte\n"
		"\t\tcomponent_yuv_betacam component_yuv_m2 component_yuv_smpte(cav)\n"
		"\t-dvi_hdmi [siI164] siI170 siI9030 siI9034 siI9134 anx9030 lvds none - Selects supported DVI/HDMI chip\n"
		"\t-hdmi state - Force HDMI (AVI info frames and audio) or DVI mode (no AVI/audio), state is optional: [1] 0\n"
		"\t-hdcp - Enable HDCP (only valid on siI170 and siI9030 DVI chip)\n"
		"\t-edid - Display EDID information of the TV/Monitor\n"
		"\t-ed n: use video format from EDID short descriptor number 'n'\n"
		"\t\t(instead of detailed descriptor with '-f edid')\n"
		"\t-edid_exclude <mode>: exclude certain video mode from being used with EDID\n"
		"\t-edid_force <mode>: force certain video modes to be used with EDID, if available in the display\n"
		"\t\t<mode> can be either of: 24hz 25hz 30hz 50hz 60hz 100hz 120hz 200hz 240hz 4x3 16x9 \n"
		"\t\tsd ed hd 480i 480p 576i 576p 720p 1080i 1080p (sd = 480i, 576i, ed = 480p, 576p, hd = 720p, 1080i, 1080p)\n"
		"\t\tmultiple specifications of -edid_exclude and -edid_force are possible.\n"
		"\t-edid_limits <min_pix> <max_pix> <min_hfreq> <max_hfreq> <min_vfreq> <max_vfreq>: limit EDID mode\n"
		"\t\tdetection to the range specified. all values in Hz. use 0 to disable a range limit.\n"
		"\t\tIf all exclusions and limits leave no mode available, 640x480p will be used.\n"
		"\t-edwrite <filename>: write data from file (binary, multiple of 128 bytes) to display's EDID EEPROM\n"
		"\t-edread <filename>: read data from display's EDID and write to a binary file\n"
		"\t-force_edid <filename>: use EDID data from the specified file instead of the display's EDID\n"
		"\t-hdmi_de: Generate DE signal by HDMI chip instead of using the one from 86xx digital out\n"
		"\t-hdmi_act <active format>: designate the portion of the screen containing actual picture information:\n"
		"\t\t[none], full, 16x9top, 14x9top, 64x27, 4x3, 16x9, 14x9, 4x3_14x9, 16x9_14x9, 16x9_4x3\n"
		"\t\tThe last 3 are optional clipping formats, e.g. the last is a 16x9 format that could be cropped to 4x3\n"
		"\t-hdmi_bars <top> <bottom> <left> <right>: designate filler bars on the screen, 0..4096:\n"
		"\t\ttop:end of horizontal bar at top [0], bottom: start of horizontal bar at bottom [4096]\n"
		"\t\tleft:end of vertical bar at left [0], right: start of vertical bar at right [4096]\n"
		"\t-hdmi_scan [under|over]: tag picture as underscanned (computer) or overscanned (video)\n"
		"\t-hdmi_spd Vendor Product [<class>]: Send HDMI SPD info frame, identifying source product\n"
		"\t\tclass: STB, DVD, DVHS, HDD, DVC, DSC, VCD, Game, PC, BluRay, SACD\n"
		"\t-tmds_mode <gpio> <threshold>: Set GPIO pin 'gpio' to 1 when HDMI pixel clock is above 'threshold' MHz\n"
		"\t-hdmi2c n [speed]: use I2C module 'n' for DVI/HDMI init (0=software, [1]=hardware, 2=built-in hdmi)\n"
		"\t\tspeed: optional, I2C bus speed in kHz, default: 100\n"
		"\t-hdmi_ddc_tx: use same I2C bus for DDC and Tx-Chip access (on some standalone boards)\n"
		"\t-dvi_reset <GPIO>: use a GPIO pin to reset DVI chip [0](disabled) (use 4 or 11 on some standalone boards)\n"
		"\t-agc_version level: Sets the macrovision version [0] 1\n"
		"\t-agc level: Sets the macrovision level [0] 1 2 3\n"
		"\t-aps level: Sets the aps level [0] 1 2 3\n"
		"\t-cgmsa level: Sets the cgms level [0] 1 2 3\n"
		"\t-rcd: Sets the rcd bit [0] 1 \n"
		"\t-asb: Sets the asb bit [0] 1 \n"
		"\t-vscaler scaler_index: Selects the scaler to use to display the video\n"
		"\tPossible values: 'mv', 'vcr', 'gfx')"
		"\t-route main vcr cb: Selects the display route to use. Default: selected by application\n"
		"\t-va video_alpha_level (0..255) [128]\n"
#ifndef WITH_MONO
		"\t-b osd_bitmap_filename: Displays an OSD bitmap at the same time\n"	
		"\t-ba alpha_bitmap_filename: 8bpp-alpha bitmap to be merged with osd\n"	
		"\t-vgab osd_bitmap_filename: Displays an OSD bitmap on the seconday\n"
		"\t\toutput (VGA)\n"
		"\t-oa osd_alpha_level (0..255) [128]\n"
		"\t-ozoom x y w h: Selects the osd input window to display [0 0 width height] \n"
		"\t-owindow x y w h: Selects the osd output window to display [0 0 width height] \n"
		"\t-odump <directory>: dumps bitmap.bin, dvi.bin and userpref.bin in\n"
		"\t\the specified directory.\n"
		"\t-oscaler scaler_name: Selects the scaler to use to display the osd image.\n"
#endif
		"\tPossible values: 'osd', 'gfx', 'mv'"
#ifdef RMFEATURE_HAS_VCR_SCALER
		" ,'vcr'"
#endif
#ifdef RMFEATURE_HAS_SPU_SCALER
		" ,'spu'"
#endif
#ifdef RMFEATURE_HAS_VIDEO_PLANE
		" ,'vp'"
#endif

		"\n "
		"\t-lock_scaler <scaler>: lock the scaling mode to the given scaler. [none] vcr gfx crt osd spu mv\n"
		"\t-vgadram: put secondary output bitmap into second DRAM bank\n"
		"\t-hwc: Displays Sigma logo using the hardware cursor\n"
		"\t-swap order: swaps the output's color component order [rgb] rbg grb\n"
		"\t\tgbr brg bgr\n"
		"\t-fs type: Selects the field selection algorithm\n"
		"\t\t[type] : to select the input field ID that matches the output field ID\n"
		"\t\ttime: to select the input field the most time accurate\n"
		"\t\tone: to select only one field per frame\n"
		"\t-strips h v : Sets display horizontal and vertical black strip mode\n"
		"\t\t(h v in [0-4096] range) [4096 4096]\n"
		"\t-cutstrips h v : Sets display horizontal and vertical cut strip mode\n"
		"\t\t(h v in [0-4096] range) [4096 4096]\n"
		"\t-nonlin w l: select non-linear scaling width (0..3) and level (0..3) [0 0]\n"
		"\t\tNote: also specify '-strips 4096 0' or -nonlin will have no visible effect!\n"
		"\t-D mode: selects the deinterlacing mode\n"
		"\t\t0: Bob - no deinterlacing\n"
		"\t\t1: modulated Weave\n"
		"\t\t2: motion adaptative\n"
		"\t\t3: Weave\n"
		"\t-32pd: enables the 3:2 pulldown. Is only active in case of motion adaptative deinterlacing [disable]\n"
		"\t-motion_config config: configures the motion deinterlacer format:V16V8V4V0\n"
		"\t-d2_proportion config: configures the existing vs new field proportion in deinterlacing type 2:0xEFNF\n"
		"\t-disp_init: force reinitialisation of the display\n"
		"\t-cdb <boundary>: sets the color degradation boundary (0..512) [0]\n"
		"\t-dp <protocol>: sets the protocol on the digital output (601, 656, vip) [601]\n"
		"\t-dig_dr [0|1] : Forces whether to use the DoubleRate feature or not. Default: on for HDMI 480i/576i modes\n"
		"\t-dclk: don't invert the digital video clock (inverted by default)\n"
		"\t-ddr: use double data rate mode on the digital out (data on both edges of the clock)\n"
		"\t-ddr_delay: set a DDR data delay (0..7) [2] -- Obsolete, use -dig_delay instead!\n"
		"\t-dig_no_delay: disable the 400 pSec data delay in non-DDR mode -- Obsolete, use -dig_delay instead!\n"
		"\t-dig_delay <n>: set a data delay of n picoseconds in both, DDR and non-DDR modes [2300/400]\n"
		"\t-inv_cap_clk: invert the capture clock, when external H- and V-Sync is used for the digital sync.\n"
		"\t-vsync_delay: delay the VSync on the digital output port by one pixel clock\n"
		"\t-trailing_edge: enable the field ID logic on the HSync trailing edge of the digital output\n"
		"\t-chroma_sync <EIA|SMPTE>: sync on Pb/Pr of component output: EIA = no sync present (default), SMPTE = sync embedded\n"
		"\t-scart_en <0|1> <pio> <inv>: disable/standby (0) or enable (1) the SCART\n"
		"\t\tdisplay. pio is optional, defaults to 13. inv is optional, whether to\n"
		"\t\tinvert the pio polarity or not.\n"
		"\t-scart_ws <0|1|a> <pio> <inv>: signal 4:3 (0) or 16:9 (1) or automatic (a) aspect ratio to\n"
		"\t\tthe SCART connector. pio is optional, defaults to 14. inv is optional,\n"
		"\t\twhether to invert the pio polarity or not\n"
#ifdef RMFEATURE_HAS_HDSD_CONVERTER
		"\t-sdf [<standard>]: Enable HD->SD conversion and set the specified SD format, or auto-detect PAL/NTSC from HDTV frame rate if no parameter\n"
		"\t-sdf50 <standard>: video mode to be used for auto detection, 50 Hz [PAL_BG] (needs -sdf option)\n"
		"\t-sdf60 <standard>: video mode to be used for auto detection, 59.94 and 60 Hz [NTSC_M] (needs -sdf option)\n"
		"\t-sdbuf: Forces the buffered HD->SD conversion mode (needs -sdf option)\n"
		"\t-sdotf: Forces the 'on-the-fly' HD->SD conversion mode (needs -sdf option)\n"
		"\t-sdcav: Sets the SD standard on the component output, when HD->SD conversion is enabled (needs -sdf option)\n"
		"\t-hdcav: Allows 1080p to be used on the component output, when HD->SD conversion is enabled (default: up to 1080i)\n"
		"\t-sdasp x y: Sets display aspect ratio for the SD output when HD->SD conversion is enabled\n"
		"\t\t(x y in [0-255] range) [4 3]\n"
#endif
		"\t-genlock <v|g> [<min> <max>]: Enable genlocking, sync source is either VideoIn (v) or GraphicIn (g).\n"
		"\t\tmin, max: target phase range, 0..255 (256 = 360 degrees)\n"
		"\t-input <v|g|v2|g2> <bus size> [<656|601|601v> <input standard> [invv] [invh]]: \n"
		"\t\tSet up dummy mode on video or graphic input, for genlock.\n"	
		"\t-time_interval <start-end>: defines the time interval to play\n" 
		"\t-dac_comp <enable>: enable or disable DAC compensation on the component output, disable: 0, enable: 1 [1]\n"
		"\t-gamma <n>: Select gamma table <n>: [0]=no gama correction, 1=neutral, 2=experimental, 3=inverse\n"
		"\t-lumakey <min> <max>: set the luma key range [0xff 0x00]\n"
		"\t-dis_pix_timer: disable timer-based pixel clock correction (enabled by default, on SMP8634 only)\n"
		"\t-hdmi_convert <colorspace> <422:444> <bits per component>: convert the 86xx video to a different format on the HDMI output\n"
		"\t-filter_gpio <gpio> <num> <value>: Sets the <value> on <num> GPIO pins, starting at GPIO <gpio> (LSB first)\n"
		"\t-luma_lpf <filter_no>: Forces a low pass luma filter applied to the luma. Possible values are 0 1 2 3 and auto.\n"
		"\t-mv_filter <filter_no>: Forces the type of filter applied to luma and chroma. Possible values are 0 1 2 3 and auto.\n"
		);

}

static RMstatus parse_hdmi_mask(RMascii *arg, RMuint64 *mask_res, RMuint64 *mask_vfreq, RMuint64 *mask_asp)
{
	if      (RMCompareAscii(arg, "24hz"))  *mask_vfreq |= CEA861_MASK_24HZ;
	else if (RMCompareAscii(arg, "25hz"))  *mask_vfreq |= CEA861_MASK_25HZ;
	else if (RMCompareAscii(arg, "30hz"))  *mask_vfreq |= CEA861_MASK_30HZ;
	else if (RMCompareAscii(arg, "50hz"))  *mask_vfreq |= CEA861_MASK_50HZ;
	else if (RMCompareAscii(arg, "60hz"))  *mask_vfreq |= CEA861_MASK_60HZ;
	else if (RMCompareAscii(arg, "100hz")) *mask_vfreq |= CEA861_MASK_100HZ;
	else if (RMCompareAscii(arg, "120hz")) *mask_vfreq |= CEA861_MASK_120HZ;
	else if (RMCompareAscii(arg, "200hz")) *mask_vfreq |= CEA861_MASK_200HZ;
	else if (RMCompareAscii(arg, "240hz")) *mask_vfreq |= CEA861_MASK_240HZ;
	else if (RMCompareAscii(arg, "4x3"))   *mask_asp   |= CEA861_MASK_4x3;
	else if (RMCompareAscii(arg, "16x9"))  *mask_asp   |= CEA861_MASK_16x9;
	else if (RMCompareAscii(arg, "vga"))   *mask_res   |= CEA861_MASK_VGA;
	else if (RMCompareAscii(arg, "sd"))    *mask_res   |= CEA861_MASK_SD;
	else if (RMCompareAscii(arg, "ed"))    *mask_res   |= CEA861_MASK_ED;
	else if (RMCompareAscii(arg, "hd"))    *mask_res   |= CEA861_MASK_HD;
	else if (RMCompareAscii(arg, "480i"))  *mask_res   |= CEA861_MASK_480I;
	else if (RMCompareAscii(arg, "480p"))  *mask_res   |= CEA861_MASK_480P;
	else if (RMCompareAscii(arg, "576i"))  *mask_res   |= CEA861_MASK_576I;
	else if (RMCompareAscii(arg, "576p"))  *mask_res   |= CEA861_MASK_576P;
	else if (RMCompareAscii(arg, "720p"))  *mask_res   |= CEA861_MASK_720P;
	else if (RMCompareAscii(arg, "1080i")) *mask_res   |= CEA861_MASK_1080I;
	else if (RMCompareAscii(arg, "1080p")) *mask_res   |= CEA861_MASK_1080P;
	else return RM_ERROR;
	return RM_OK;
}

static RMstatus parse_color_space(RMascii *arg, enum EMhwlibColorSpace *pColorSpace)
{
	RMstatus err = RM_OK;
	
	if (RMCompareAsciiCaseInsensitively(arg, "none")) {
		*pColorSpace = EMhwlibColorSpace_None;
	// backwards compatibility
	} else if (RMCompareAscii(arg, "yuv_601")) {
		*pColorSpace = EMhwlibColorSpace_YUV_601;
	} else if (RMCompareAscii(arg, "yuv_709")) {
		*pColorSpace = EMhwlibColorSpace_YUV_709;
	} else if (RMCompareAscii(arg, "xv_601")) {
		*pColorSpace = EMhwlibColorSpace_xvYCC_601;
	} else if (RMCompareAscii(arg, "xv_709")) {
		*pColorSpace = EMhwlibColorSpace_xvYCC_709;
	} else if (RMCompareAscii(arg, "rgb_0_255")) {
		*pColorSpace = EMhwlibColorSpace_RGB_0_255;
	} else if (RMCompareAscii(arg, "rgb_16_235")) {
		*pColorSpace = EMhwlibColorSpace_RGB_16_235;
	// new notation
	} else if (RMCompareAsciiCaseInsensitively(arg, "YCC601")) {
		*pColorSpace = EMhwlibColorSpace_YUV_601;
	} else if (RMCompareAsciiCaseInsensitively(arg, "YCC601f")) {
		*pColorSpace = EMhwlibColorSpace_YUV_601_0_255;
	} else if (RMCompareAsciiCaseInsensitively(arg, "YCC709")) {
		*pColorSpace = EMhwlibColorSpace_YUV_709;
	} else if (RMCompareAsciiCaseInsensitively(arg, "YCC709f")) {
		*pColorSpace = EMhwlibColorSpace_YUV_709_0_255;
	} else if (RMCompareAsciiCaseInsensitively(arg, "xvYCC601")) {
		*pColorSpace = EMhwlibColorSpace_xvYCC_601;
	} else if (RMCompareAsciiCaseInsensitively(arg, "xvYCC601f")) {
		*pColorSpace = EMhwlibColorSpace_xvYCC_601_0_255;
	} else if (RMCompareAsciiCaseInsensitively(arg, "xvYCC709")) {
		*pColorSpace = EMhwlibColorSpace_xvYCC_709;
	} else if (RMCompareAsciiCaseInsensitively(arg, "xvYCC709f")) {
		*pColorSpace = EMhwlibColorSpace_xvYCC_709_0_255;
	} else if (RMCompareAsciiCaseInsensitively(arg, "RGB")) {
		*pColorSpace = EMhwlibColorSpace_RGB_0_255;
	} else if (RMCompareAsciiCaseInsensitively(arg, "RGBl")) {
		*pColorSpace = EMhwlibColorSpace_RGB_16_235;
	} else {
		err = RM_ERROR;
	}
	
	return err;
}

// returns TRUE if 'ch' is not the first char of another option, or potential filename
static RMbool opt_arg(RMascii ch) {
	return (ch != '-') && (ch != '.') && (ch != '/') && (ch != '\\') && (ch != '_');
}

RMstatus parse_display_cmdline(int argc, char **argv, int *index, struct display_cmdline *options)
{
	RMstatus err = RM_PENDING;
	int i = *index;
	RMuint32 j;

	if (RMCompareAscii(argv[i], "-f")) {
		if (argc > i+1) { 
			if (RMCompareAscii(argv[i+1], "edid")) {
				options->standard = EMhwlibTVStandard_HDMI_480p59;  // fallback standard
				options->edid_sel = DH_EDID_auto;
				err = RM_OK;
			} else {
				err = GetTVStandard(argv[i+1], &(options->standard));
			}
			i += 2;
		}
		else 
			err = RM_ERROR;
		
	}
	else if (RMCompareAscii(argv[i], "-r")) {
		if ((argc > i+1) && (argv[i+1][0] != '-')) {
			i++;
			err = RM_OK;
			if (options->edid_sel != DH_EDID_fmatch) {
				options->edid_sel = DH_EDID_match;
			}
			options->standard = EMhwlibTVStandard_HDMI_480p59;  // fallback standard
			if (RMCompareAscii(argv[i], "pref")) {
				options->edid_sel = DH_EDID_auto;
			} else if (RMCompareAscii(argv[i], "480i") || RMCompareAscii(argv[i], "480i59")) {
				options->dvi_hdmi_edid_hsize = 720;
				options->dvi_hdmi_edid_vsize = 480;
				options->dvi_hdmi_edid_vfreq = 59;
				options->dvi_hdmi_edid_intl = TRUE;
			} else if (RMCompareAscii(argv[i], "480i60")) {
				options->dvi_hdmi_edid_hsize = 720;
				options->dvi_hdmi_edid_vsize = 480;
				options->dvi_hdmi_edid_vfreq = 60;
				options->dvi_hdmi_edid_intl = TRUE;
			} else if (RMCompareAscii(argv[i], "480p") || RMCompareAscii(argv[i], "480p59")) {
				options->dvi_hdmi_edid_hsize = 720;
				options->dvi_hdmi_edid_vsize = 480;
				options->dvi_hdmi_edid_vfreq = 59;
				options->dvi_hdmi_edid_intl = FALSE;
			} else if (RMCompareAscii(argv[i], "480p60")) {
				options->dvi_hdmi_edid_hsize = 720;
				options->dvi_hdmi_edid_vsize = 480;
				options->dvi_hdmi_edid_vfreq = 60;
				options->dvi_hdmi_edid_intl = FALSE;
			} else if (RMCompareAscii(argv[i], "576i") || RMCompareAscii(argv[i], "576i50")) {
				options->dvi_hdmi_edid_hsize = 720;
				options->dvi_hdmi_edid_vsize = 576;
				options->dvi_hdmi_edid_vfreq = 50;
				options->dvi_hdmi_edid_intl = TRUE;
			} else if (RMCompareAscii(argv[i], "576p") || RMCompareAscii(argv[i], "576p50")) {
				options->dvi_hdmi_edid_hsize = 720;
				options->dvi_hdmi_edid_vsize = 576;
				options->dvi_hdmi_edid_vfreq = 50;
				options->dvi_hdmi_edid_intl = FALSE;
			} else if (RMCompareAscii(argv[i], "720p50")) {
				options->dvi_hdmi_edid_hsize = 1280;
				options->dvi_hdmi_edid_vsize = 720;
				options->dvi_hdmi_edid_vfreq = 50;
				options->dvi_hdmi_edid_intl = FALSE;
			} else if (RMCompareAscii(argv[i], "720p") || RMCompareAscii(argv[i], "720p59")) {
				options->dvi_hdmi_edid_hsize = 1280;
				options->dvi_hdmi_edid_vsize = 720;
				options->dvi_hdmi_edid_vfreq = 59;
				options->dvi_hdmi_edid_intl = FALSE;
			} else if (RMCompareAscii(argv[i], "720p60")) {
				options->dvi_hdmi_edid_hsize = 1280;
				options->dvi_hdmi_edid_vsize = 720;
				options->dvi_hdmi_edid_vfreq = 60;
				options->dvi_hdmi_edid_intl = FALSE;
			} else if (RMCompareAscii(argv[i], "1080i50")) {
				options->dvi_hdmi_edid_hsize = 1920;
				options->dvi_hdmi_edid_vsize = 1080;
				options->dvi_hdmi_edid_vfreq = 50;
				options->dvi_hdmi_edid_intl = TRUE;
			} else if (RMCompareAscii(argv[i], "1080i") || RMCompareAscii(argv[i], "1080i59")) {
				options->dvi_hdmi_edid_hsize = 1920;
				options->dvi_hdmi_edid_vsize = 1080;
				options->dvi_hdmi_edid_vfreq = 59;
				options->dvi_hdmi_edid_intl = TRUE;
			} else if (RMCompareAscii(argv[i], "1080i60")) {
				options->dvi_hdmi_edid_hsize = 1920;
				options->dvi_hdmi_edid_vsize = 1080;
				options->dvi_hdmi_edid_vfreq = 60;
				options->dvi_hdmi_edid_intl = TRUE;
			} else if (RMCompareAscii(argv[i], "1080p23")) {
				options->dvi_hdmi_edid_hsize = 1920;
				options->dvi_hdmi_edid_vsize = 1080;
				options->dvi_hdmi_edid_vfreq = 23;
				options->dvi_hdmi_edid_intl = FALSE;
			} else if (RMCompareAscii(argv[i], "1080p24")) {
				options->dvi_hdmi_edid_hsize = 1920;
				options->dvi_hdmi_edid_vsize = 1080;
				options->dvi_hdmi_edid_vfreq = 24;
				options->dvi_hdmi_edid_intl = FALSE;
			} else if (RMCompareAscii(argv[i], "1080p50")) {
				options->dvi_hdmi_edid_hsize = 1920;
				options->dvi_hdmi_edid_vsize = 1080;
				options->dvi_hdmi_edid_vfreq = 50;
				options->dvi_hdmi_edid_intl = FALSE;
			} else if (RMCompareAscii(argv[i], "1080p") || RMCompareAscii(argv[i], "1080p59")) {
				options->dvi_hdmi_edid_hsize = 1920;
				options->dvi_hdmi_edid_vsize = 1080;
				options->dvi_hdmi_edid_vfreq = 59;
				options->dvi_hdmi_edid_intl = FALSE;
			} else if (RMCompareAscii(argv[i], "1080p60")) {
				options->dvi_hdmi_edid_hsize = 1920;
				options->dvi_hdmi_edid_vsize = 1080;
				options->dvi_hdmi_edid_vfreq = 60;
				options->dvi_hdmi_edid_intl = FALSE;
			} else if (RMCompareAscii(argv[i], "vga")) {
				options->dvi_hdmi_edid_hsize = 640;
				options->dvi_hdmi_edid_vsize = 480;
				options->dvi_hdmi_edid_vfreq = 60;
				options->dvi_hdmi_edid_intl = FALSE;
			} else if ((argv[i][0] >= '0') && (argv[i][0] <= '9')) {
				RMint32 VIC;
				RMasciiToInt32(argv[i], &VIC);
				if ((VIC == 0) || (VIC > 59)) {
					fprintf(stderr, "VIC out of range: %lu\n", VIC);
					err = RM_ERROR;
				} else {
					options->dvi_hdmi_edid_descriptor = VIC;  // hack
				}
			} else {
				fprintf(stderr, "Unknown resolution: -r %s\n", argv[i]);
				err = RM_ERROR;
			}
		} else {
			err = RM_OK;
			options->edid_sel = DH_EDID_auto;
			options->standard = EMhwlibTVStandard_HDMI_480p59;  // fallback standard
		}
		i++;
	}
#ifdef RMFEATURE_HAS_HDSD_CONVERTER
	else if (RMCompareAscii(argv[i], "-sdf50")) {
		if (argc > i+1) {
			err = GetTVStandard(argv[i+1], &(options->sd_standard_50Hz));
			i += 2;
		} else {
			err = RM_ERROR;
		}
	}
	else if (RMCompareAscii(argv[i], "-sdf60")) {
		if (argc > i+1) {
			err = GetTVStandard(argv[i+1], &(options->sd_standard_60Hz));
			i += 2;
		} else {
			err = RM_ERROR;
		}
	}
	else if (RMCompareAscii(argv[i], "-sdf")) {
		options->use_hdsd_conversion = TRUE;
		if ((argc > i+1) && (argv[i+1][0] != '-')) {
			err = GetTVStandard(argv[i+1], &(options->sd_standard));
			i++;
		} else {
			options->sd_autodetect = TRUE;
			err = RM_OK;
		}
		i++;
	}
	else if (RMCompareAscii(argv[i], "-sdbuf")) {
		i++;
		options->allow_otf = FALSE;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-sdotf")) {
		i++;
		options->allow_buf = FALSE;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-sdcav")) {
		i++;
		options->sd_component = TRUE;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-hdcav")) {
		i++;
		options->sd_cav_1080p = TRUE;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-sdasp")) {
		if (argc > i+2) {
 			RMasciiToUInt32(argv[i+1], &(options->sd_ar_x));
			RMasciiToUInt32(argv[i+2], &(options->sd_ar_y));
			i += 3;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
		
	}
#endif
	else if (RMCompareAscii(argv[i], "-vgaf")) {
		if (argc > i+1) { 
			if (RMCompareAscii(argv[i+1], "edid")) {
				options->vga_standard = EMhwlibTVStandard_HDMI_480p59;  // fallback standard
				options->vga_edid_sel = DH_EDID_auto;
				err = RM_OK;
			} else {
				err = GetTVStandard(argv[i+1], &(options->vga_standard));
			}
			i += 2;
		}
		else 
			err = RM_ERROR;
		
	}
	else if (RMCompareAscii(argv[i], "-vmf")) {
		if (argc > i+1) { 
			strncpy(options->vidmode_filename, argv[i + 1], 2048);
			options->vidmode_filename[2047] = '\0';
			options->standard = EMhwlibTVStandard_Custom;
			err = RM_OK;
			i += 2;
		}
		else 
			err = RM_ERROR;
		
	}
	else if (RMCompareAscii(argv[i], "-o")) {
		if (argc > i+1) {
			if (RMCompareAscii(argv[i+1], "svideo")) {
				options->connector = DCCVideoConnector_SVIDEO;
			}
			else if (RMCompareAscii(argv[i+1], "composite") || RMCompareAscii(argv[i+1], "cvbs")) {
				options->connector = DCCVideoConnector_COMPOSITE;
			}
			else if (RMCompareAscii(argv[i+1], "component_rgb_scart")) {
				options->connector = DCCVideoConnector_COMPONENT;
				options->component = EMhwlibComponentMode_RGB_SCART;
			}
			else if (RMCompareAscii(argv[i+1], "component_rgb_sog")) {
				options->connector = DCCVideoConnector_COMPONENT;
				options->component = EMhwlibComponentMode_RGB_SOG;
			}
			else if (RMCompareAscii(argv[i+1], "component_rgb_smpte")) {
				options->connector = DCCVideoConnector_COMPONENT;
				options->component = EMhwlibComponentMode_RGB_SMPTE;
			}
			else if (RMCompareAscii(argv[i+1], "component_yuv_betacam")) {
				options->connector = DCCVideoConnector_COMPONENT;
				options->component = EMhwlibComponentMode_YUV_BETACAM;
			}
			else if (RMCompareAscii(argv[i+1], "component_yuv_m2")) {
				options->connector = DCCVideoConnector_COMPONENT;
				options->component = EMhwlibComponentMode_YUV_M2;
			}
			else if (RMCompareAscii(argv[i+1], "component_yuv_smpte") || RMCompareAscii(argv[i+1], "cav")) {
				options->connector = DCCVideoConnector_COMPONENT;
				options->component = EMhwlibComponentMode_YUV_SMPTE;
			}
			else if (RMCompareAscii(argv[i+1], "scart")) {
				options->connector = DCCVideoConnector_SCART;
			}
			else if (RMCompareAscii(argv[i+1], "dvi_8")) {
				options->connector = DCCVideoConnector_DVI;
				options->bus_size = 8;
			}
			else if (RMCompareAscii(argv[i+1], "dvi_16")) {
				options->connector = DCCVideoConnector_DVI;
				options->bus_size = 16;
			}
			else if (RMCompareAscii(argv[i+1], "dvi_24") || RMCompareAscii(argv[i+1], "dvi") || RMCompareAscii(argv[i+1], "hdmi")) {
				options->connector = DCCVideoConnector_DVI;
				options->bus_size = 24;
			}
			else if (RMCompareAscii(argv[i+1], "lvds")) {
				options->connector = DCCVideoConnector_LVDS;
				options->bus_size = 24;
			}
			else if (RMCompareAscii(argv[i+1], "dig_8")) {
				options->connector = DCCVideoConnector_Digital;
				options->bus_size = 8;
			}
			else if (RMCompareAscii(argv[i+1], "dig_16")) {
				options->connector = DCCVideoConnector_Digital;
				options->bus_size = 16;
			}
			else if (RMCompareAscii(argv[i+1], "dig_24")) {
				options->connector = DCCVideoConnector_Digital;
				options->bus_size = 24;
			}
			else if (RMCompareAscii(argv[i+1], "vga")) {
				options->connector = DCCVideoConnector_VGA;
			}
			else
				err = RM_ERROR;
			
			if (err != RM_ERROR) {
				switch (options->connector) {
				case DCCVideoConnector_DVI:
					// HDMI: default to video mode from EDID
					if ((options->standard == EMhwlibTVStandard_NTSC_M) && (options->edid_sel == DH_EDID_none)) {
						options->edid_sel = DH_EDID_auto;
						options->standard = EMhwlibTVStandard_HDMI_480p59;  // fallback standard
					}
					break;
				case DCCVideoConnector_VGA:
				case DCCVideoConnector_LVDS:
				case DCCVideoConnector_Digital:
					// LVDS/VGA: default to VGA resolution (640x480)
					if (options->standard == EMhwlibTVStandard_NTSC_M) {
						options->standard = EMhwlibTVStandard_VESA_640x480x60;  // fallback standard
					}
					break;
				default:
					break;
				}
				err = RM_OK;
			}
			i += 2;
		}
		else 
			err = RM_ERROR;
		
	}
	else if (RMCompareAscii(argv[i], "-cs")) {
		if (argc > i+1) {
			err = parse_color_space(argv[i + 1], &(options->color_space));
			if (options->color_space == EMhwlibColorSpace_None) err = RM_ERROR;
			i += 2;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-mcs")) {
		if (argc > i+1) {
			err = parse_color_space(argv[i + 1], &(options->mixer_color_space));
			i += 2;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-asp")) {
		if (argc > i+2) {
 			RMasciiToUInt32(argv[i+1], &(options->ar_x));
			RMasciiToUInt32(argv[i+2], &(options->ar_y));
			i += 3;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
		
	}
	else if (RMCompareAscii(argv[i], "-afd")) {
		if (argc > i+1) {
			options->active_format_valid = TRUE;
			if (RMCompareAscii(argv[i+1], "none")) {
				options->active_format_valid = FALSE;
			} else if (RMCompareAscii(argv[i+1], "full")) {
				options->active_format = EMhwlibAF_same_as_picture;
			} else if (RMCompareAscii(argv[i+1], "16x9top")) {
				options->active_format = EMhwlibAF_16x9_top;
			} else if (RMCompareAscii(argv[i+1], "14x9top")) {
				options->active_format = EMhwlibAF_14x9_top;
			} else if (RMCompareAscii(argv[i+1], "64x27")) {
				options->active_format = EMhwlibAF_64x27_centered;
			} else if (RMCompareAscii(argv[i+1], "4x3")) {
				options->active_format = EMhwlibAF_4x3_centered;
			} else if (RMCompareAscii(argv[i+1], "16x9")) {
				options->active_format = EMhwlibAF_16x9_centered;
			} else if (RMCompareAscii(argv[i+1], "14x9")) {
				options->active_format = EMhwlibAF_14x9_centered;
			} else if (RMCompareAscii(argv[i+1], "4x3_14x9")) {
				options->active_format = EMhwlibAF_4x3_centered_prot_14x9;
			} else if (RMCompareAscii(argv[i+1], "16x9_14x9")) {
				options->active_format = EMhwlibAF_16x9_centered_prot_14x9;
			} else if (RMCompareAscii(argv[i+1], "16x9_4x3")) {
				options->active_format = EMhwlibAF_16x9_centered_prot_4x3;
			} else {
				err = RM_ERROR;
			}
			if (err != RM_ERROR)
			
				err = RM_OK;
			i += 2;
		}
		else 
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-zoom")) {
		if (argc > i+4) {
			RMuint32 x, y, w, h;
			RMasciiToInt32(argv[i+1], (RMint32*)&x);
			RMasciiToInt32(argv[i+2], (RMint32*)&y);
			RMasciiToUInt32(argv[i+3], &w);
			RMasciiToUInt32(argv[i+4], &h);
			options->source_window.X =      (x >= 4096) ? (x - 4096) : x;
			options->source_window.Y =      (y >= 4096) ? (y - 4096) : y;
			options->source_window.Width =  (w >= 4096) ? (w - 4096) : w;
			options->source_window.Height = (h >= 4096) ? (h - 4096) : h;
			options->source_window.XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
			options->source_window.YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
			options->source_window.XMode =      (x >= 4096) ? EMhwlibDisplayWindowValueMode_Relative : EMhwlibDisplayWindowValueMode_Fixed;
			options->source_window.YMode =      (y >= 4096) ? EMhwlibDisplayWindowValueMode_Relative : EMhwlibDisplayWindowValueMode_Fixed;
			options->source_window.WidthMode =  (w >= 4096) ? EMhwlibDisplayWindowValueMode_Relative : EMhwlibDisplayWindowValueMode_Fixed;
			options->source_window.HeightMode = (h >= 4096) ? EMhwlibDisplayWindowValueMode_Relative : EMhwlibDisplayWindowValueMode_Fixed;
			i += 5;
			err = RM_OK;
		}
		else
 			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-window")) {
		if (argc > i+4) {
			RMasciiToInt32(argv[i+1], &(options->output_window.X));
			RMasciiToInt32(argv[i+2], &(options->output_window.Y));
			RMasciiToUInt32(argv[i+3], &(options->output_window.Width));
			RMasciiToUInt32(argv[i+4], &(options->output_window.Height));
			options->output_window.XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
			options->output_window.YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
			options->output_window.XMode = EMhwlibDisplayWindowValueMode_Fixed;
			options->output_window.YMode = EMhwlibDisplayWindowValueMode_Fixed;
			options->output_window.WidthMode = EMhwlibDisplayWindowValueMode_Fixed;
			options->output_window.HeightMode = EMhwlibDisplayWindowValueMode_Fixed;
			i += 5;
			err = RM_OK;
		}
		else
 			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-vscaler")) {
		if (argc > i+1) {
			err = RM_OK;
			if(RMCompareAscii(argv[i+1], "mv") || RMCompareAscii(argv[i+1], "0")) {
				options->video_scaler = 0;
			}
			else if(RMCompareAscii(argv[i+1], "vcr") || RMCompareAscii(argv[i+1], "1")) {
				options->video_scaler = 1;
			}
			else if(RMCompareAscii(argv[i+1], "gfx") || RMCompareAscii(argv[i+1], "2")) {
				options->video_scaler = 2;
			}
			else
				err = RM_ERROR;
			i += 2;
		}
		else
			err = RM_ERROR;

	}
	else if (RMCompareAscii(argv[i], "-va") ){
		if (argc> i+1) {
			RMasciiToUInt32(argv[i+1], &options->video_alpha);
			if (options->video_alpha > 0xFF)
				err = RM_ERROR;
			else {
				i += 2;
				err = RM_OK;
			}
		}
		else
			err = RM_ERROR;

	}
	else if (RMCompareAscii(argv[i], "-lock_scaler")) {
		if (argc > i+1) {
			err = RM_OK;
			if(RMCompareAscii(argv[i+1], "osd")) {
				options->lock_scaler = DispOSDScaler;
			}
			else if(RMCompareAscii(argv[i+1], "gfx")) {
				options->lock_scaler = DispGFXMultiScaler;
			}
			else if(RMCompareAscii(argv[i+1], "vcr")) {
				options->lock_scaler = DispVCRMultiScaler;
			}
			else if(RMCompareAscii(argv[i+1], "crt")) {
				options->lock_scaler = DispCRTMultiScaler;
			}
			else if(RMCompareAscii(argv[i+1], "spu")) {
				options->lock_scaler = DispSubPictureScaler;
			}
			else if(RMCompareAscii(argv[i+1], "mv")) {
				options->lock_scaler = DispMainVideoScaler;
			}
			else
				err = RM_ERROR;
			i += 2;
		}
		else
			err = RM_ERROR;
	}
#ifndef WITH_MONO
	else if (RMCompareAscii(argv[i], "-ozoom")) {
		if (argc > i+4) {
			options->osd_pictures[0].zoom = TRUE;
			RMasciiToInt32(argv[i+1], &(options->osd_pictures[0].source_window.X));
			RMasciiToInt32(argv[i+2], &(options->osd_pictures[0].source_window.Y));
			RMasciiToUInt32(argv[i+3], &(options->osd_pictures[0].source_window.Width));
			RMasciiToUInt32(argv[i+4], &(options->osd_pictures[0].source_window.Height));
			options->osd_pictures[0].source_window.XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
			options->osd_pictures[0].source_window.YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
			options->osd_pictures[0].source_window.XMode = EMhwlibDisplayWindowValueMode_Fixed;
			options->osd_pictures[0].source_window.YMode = EMhwlibDisplayWindowValueMode_Fixed;
			options->osd_pictures[0].source_window.WidthMode = EMhwlibDisplayWindowValueMode_Fixed;
			options->osd_pictures[0].source_window.HeightMode = EMhwlibDisplayWindowValueMode_Fixed;
			i += 5;
			err = RM_OK;
		}
		else
 			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-ocs")) {
		if (argc > i+1) {
			err = parse_color_space(argv[i + 1], &(options->osd_pictures[0].color_space));
			i += 2;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-owindow")) {
		if (argc > i+4) {
			RMasciiToInt32(argv[i+1], &(options->osd_pictures[0].output_window.X));
			RMasciiToInt32(argv[i+2], &(options->osd_pictures[0].output_window.Y));
			RMasciiToUInt32(argv[i+3], &(options->osd_pictures[0].output_window.Width));
			RMasciiToUInt32(argv[i+4], &(options->osd_pictures[0].output_window.Height));
			options->osd_pictures[0].output_window.XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
			options->osd_pictures[0].output_window.YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
			options->osd_pictures[0].output_window.XMode = EMhwlibDisplayWindowValueMode_Fixed;
			options->osd_pictures[0].output_window.YMode = EMhwlibDisplayWindowValueMode_Fixed;
			options->osd_pictures[0].output_window.WidthMode = EMhwlibDisplayWindowValueMode_Fixed;
			options->osd_pictures[0].output_window.HeightMode = EMhwlibDisplayWindowValueMode_Fixed;
			i += 5;
			err = RM_OK;
		}
		else
 			err = RM_ERROR;
	}

	else if (RMCompareAscii(argv[i], "-b")) {
		if(argc > i+1 ){
			if (argv[i+1][0]!='-') { 
				options->osd_pictures[0].filename = argv[i+1];
				options->osd_pictures[0].enable = TRUE;
				i+=2;
				err = RM_OK;
			}
			else
				err = RM_ERROR;
		}
		else
			err = RM_ERROR;
	
	}
	else if (RMCompareAscii(argv[i], "-ba")) {
		if(argc > i+1 ){
			if (argv[i+1][0]!='-') { 
				options->osd_pictures[0].alpha_filename = argv[i+1];
				options->osd_pictures[0].alpha_merge = TRUE;
				i+=2;
				err = RM_OK;
			}
			else
				err = RM_ERROR;
		}
		else
			err = RM_ERROR;
	
	}
	else if (RMCompareAscii(argv[i], "-vgab")) {
		if(argc > i+1 ){
			if (argv[i+1][0]!='-') { 
				options->osd_pictures[1].filename = argv[i+1];
				options->osd_pictures[1].enable = TRUE;
				i+=2;
				err = RM_OK;
			}
			else
				err = RM_ERROR;
		}
		else
			err = RM_ERROR;
	}	
	else if (RMCompareAscii(argv[i], "-oa") ){
		if (argc> i+1) {
			RMasciiToUInt32(argv[i+1], &options->osd_pictures[0].alpha);
			if (options->agc_level > 0xFF)
				err = RM_ERROR;
			else {
				i += 2;
				err = RM_OK;
			}
		}
		else
			err = RM_ERROR;

	}
	else if (RMCompareAscii(argv[i], "-odump")) {
		if (argc > i+1) {
			options->dump_osd_dir = argv[i+1];
			i += 2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-oscaler")) {
		if (argc > i+1) {
			err = RM_OK;
			RMDBGLOG((ENABLE, "oscaler is %s\n", argv[i+1]));
			if(RMCompareAscii(argv[i+1], "osd") || RMCompareAscii(argv[i+1], "0")) {
				options->osd_pictures[0].scaler = 0;
			}
			else if(RMCompareAscii(argv[i+1], "gfx") || RMCompareAscii(argv[i+1], "1")) {
				options->osd_pictures[0].scaler = 1;
			}
			else if(RMCompareAscii(argv[i+1], "mv") || RMCompareAscii(argv[i+1], "2")) {
				options->osd_pictures[0].scaler = 2;
			}
			else if(RMCompareAscii(argv[i+1], "vcr") || RMCompareAscii(argv[i+1], "3")) {
				options->osd_pictures[0].scaler = 3;
			}
			else if(RMCompareAscii(argv[i+1], "spu") || RMCompareAscii(argv[i+1], "5")) {
				options->osd_pictures[0].scaler = 5;
			}
			else if(RMCompareAscii(argv[i+1], "vp") || RMCompareAscii(argv[i+1], "6")) {
				options->osd_pictures[0].scaler = 6;
			}
			else
				err = RM_ERROR;
			i += 2;
		}
		else
			err = RM_ERROR;
		
	}

#endif /*WITH_MONO*/
	else if (RMCompareAscii(argv[i], "-route")) {
		if (argc > i+1) {
			err = RM_OK;
			options->force_route = TRUE;
			if(RMCompareAscii(argv[i+1], "main")) {
				options->route = DCCRoute_Main;
			}
			else if(RMCompareAscii(argv[i+1], "cb")) {
				options->route = DCCRoute_ColorBars;
			}
#ifdef RMFEATURE_HAS_VCR_CHANNEL
			else if(RMCompareAscii(argv[i+1], "vcr")) {
				options->route = DCCRoute_Secondary;
			}
#endif
			else
				err = RM_ERROR;
			i += 2;
		}
		else
			err = RM_ERROR;
		
	}


	else if (RMCompareAscii(argv[i], "-agc_version")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options->agc_version));
			if (options->agc_version > EMhwlibAGCVersion_AlternateBPP)
				err = RM_ERROR;
			else {
				i += 2;
				err = RM_OK;
			}
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-agc")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options->agc_level));
			if (options->agc_level > 3)
				err = RM_ERROR;
			else {
				i += 2;
				err = RM_OK;
			}
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-aps")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options->aps_level));
			if (options->aps_level > 3)
				err = RM_ERROR;
			else {
				i += 2;
				err = RM_OK;
			}
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-rcd")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options->rcd));
			if (options->rcd > 1)
				err = RM_ERROR;
			else {
				i += 2;
				err = RM_OK;
			}
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-asb")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options->asb));
			if (options->asb > 1)
				err = RM_ERROR;
			else {
				i += 2;
				err = RM_OK;
			}
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-cgmsa")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &options->cgmsa);
			if (options->cgmsa > 3)
				err = RM_ERROR;
			else {
				i += 2;
				err = RM_OK;
			}
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-hwc")) {
		options->show_hwc = TRUE;
		i++;
		err = RM_OK;
	}




	else if (RMCompareAscii(argv[i], "-vgadram")) {
		options->osd_pictures[1].dramblock = 1;
		i++;
		err = RM_OK;
	
	}

	else if (RMCompareAscii(argv[i], "-nonlin")) {
		if (argc > i+2) {
			RMasciiToUInt32(argv[i+1], &(options->nonlinearmode.Width));
			RMasciiToUInt32(argv[i+2], &(options->nonlinearmode.Level));
			if ((options->nonlinearmode.Width > 3) || (options->nonlinearmode.Level > 3)) {
				err = RM_ERROR;
			} else {
				i += 3;
				err = RM_OK;
			}
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-swap")) {
		if (argc > i+1) {
			if(RMCompareAscii(argv[i+1], "rgb")) {
				options->component_order = EMhwlibComponentOrder_RGB;
			}
			else if(RMCompareAscii(argv[i+1], "rbg")) {
				options->component_order = EMhwlibComponentOrder_RBG;
			}
			else if(RMCompareAscii(argv[i+1], "grb")) {
				options->component_order = EMhwlibComponentOrder_GRB;
			}
			else if(RMCompareAscii(argv[i+1], "gbr")) {
				options->component_order = EMhwlibComponentOrder_GBR;
			}
			else if(RMCompareAscii(argv[i+1], "brg")) {
				options->component_order = EMhwlibComponentOrder_BRG;
			}
			else if(RMCompareAscii(argv[i+1], "bgr")) {
				options->component_order = EMhwlibComponentOrder_BGR;
			}
			else
				err = RM_ERROR;
			if (err != RM_ERROR)
				err = RM_OK;
			i += 2;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-fs")) {
		if (argc > i+1) {
			if (RMCompareAscii(argv[i+1], "time")) {
				options->field_selection = EMhwlibScalerFieldSelection_BestFieldTime;
			}
			else if (RMCompareAscii(argv[i+1], "type")) {
				options->field_selection = EMhwlibScalerFieldSelection_BestFieldType;
			}
			else if (RMCompareAscii(argv[i+1], "one")) {
				options->field_selection = EMhwlibScalerFieldSelection_OneField;
			}
			else
				err = RM_ERROR;
			if (err != RM_ERROR)
				err = RM_OK;
			i += 2;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-dvi_hdmi")) {
		if (argc > i+1) {
			if (RMCompareAscii(argv[i+1], "siI164")) {
				options->dvi_hdmi_part = DH_siI164;
			} else if (RMCompareAscii(argv[i+1], "siI170")) {
				options->dvi_hdmi_part = DH_siI170;
			} else if (RMCompareAscii(argv[i+1], "siI9030")) {
				options->dvi_hdmi_part = DH_siI9030;
			} else if (RMCompareAscii(argv[i+1], "siI9034")) {
				options->dvi_hdmi_part = DH_siI9034;
			} else if (RMCompareAscii(argv[i+1], "siI9134")) {
				options->dvi_hdmi_part = DH_siI9134;
			} else if (RMCompareAscii(argv[i+1], "anx9030")) {
				options->dvi_hdmi_part = DH_ANX9030;
			} else if (RMCompareAscii(argv[i+1], "lvds")) {
				options->dvi_hdmi_part = DH_lvds;
			} else if (RMCompareAscii(argv[i+1], "none")) {
				options->dvi_hdmi_part = DH_no_chip;
			}
			else
				err = RM_ERROR;
			if (err != RM_ERROR)
				err = RM_OK;
			i += 2;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-hdmi")) {
		options->hdmi_force = TRUE;
		options->hdmi_monitor = TRUE;  // force HDMI
		i++;
		if ((argc > i) && opt_arg(argv[i][0])) {
			// optional argument: force DVI or HDMI
			options->hdmi_monitor = ((argv[i][0] == '0') || (argv[i][0] == 'd') || (argv[i][0] == 'D')) ? FALSE : TRUE;
			i++;
		}
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-hdcp")) {
		options->dvi_hdmi_hdcp = TRUE;
		i++;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-edid")) {
		options->dvi_hdmi_display_edid = TRUE;
		i++;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-hdmi_de")) {
		options->hdmi_de = TRUE;
		i++;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-no_disp")) {
		options->configure_outports = FALSE;
		i++;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-edmode")) {
		if (argc > i + 4) {
			RMuint32 intl;
			RMasciiToUInt32(argv[i + 1], &(options->dvi_hdmi_edid_hsize));
			RMasciiToUInt32(argv[i + 2], &(options->dvi_hdmi_edid_vsize));
			RMasciiToUInt32(argv[i + 3], &(options->dvi_hdmi_edid_vfreq));
			if ((argv[i + 4][0] == 'p') || (argv[i + 4][0] == 'P')) {
				intl = FALSE;
			} else if ((argv[i + 4][0] == 'i') || (argv[i + 4][0] == 'I')) {
				intl = TRUE;
			} else {
				RMasciiToUInt32(argv[i + 4], &intl);
			}
			options->dvi_hdmi_edid_intl = (intl ? TRUE : FALSE);
			options->standard = EMhwlibTVStandard_HDMI_480p59;  // fallback standard
			if (options->edid_sel != DH_EDID_fmatch) {
				options->edid_sel = DH_EDID_match;
			}
			i += 5;
			err = RM_OK;
		}
		else err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-edforce")) {
		if (options->edid_sel == DH_EDID_none) {
			options->standard = EMhwlibTVStandard_HDMI_480p59;  // fallback standard
		}
		options->edid_sel = DH_EDID_fmatch;
		i++;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-edid_exclude")) {
		i++;
		if (argc <= i) err = RM_ERROR;
		while ((err != RM_ERROR) && (argc > i) && opt_arg(argv[i][0])) {
			err = parse_hdmi_mask(argv[i], &(options->edid_exclude_mask), &(options->edid_exclude_mask_vfreq), &(options->edid_exclude_mask_asp));
			if (RMSUCCEEDED(err)) {
				options->standard = EMhwlibTVStandard_HDMI_480p59;  // fallback standard
				options->edid_sel = DH_EDID_mask;
			}
			i++;
		}
	}
	else if (RMCompareAscii(argv[i], "-edid_force")) {
		i++;
		if (argc <= i) err = RM_ERROR;
		while ((err != RM_ERROR) && (argc > i) && opt_arg(argv[i][0])) {
			err = parse_hdmi_mask(argv[i], &(options->edid_force_mask), &(options->edid_force_mask_vfreq), &(options->edid_force_mask_asp));
			if (RMSUCCEEDED(err)) {
				options->standard = EMhwlibTVStandard_HDMI_480p59;  // fallback standard
				options->edid_sel = DH_EDID_mask;
			}
			i++;
		}
	}
	else if (RMCompareAscii(argv[i], "-edid_limits")) {
		options->edid_min_pixclk = 0;
		options->edid_max_pixclk = 0;
		options->edid_min_hfreq = 0;
		options->edid_max_hfreq = 0;
		options->edid_min_vfreq = 0;
		options->edid_max_vfreq = 0;
		i++;
		if ((argc > i) && opt_arg(argv[i][0])) {
			RMasciiToUInt32(argv[i], &(options->edid_min_pixclk));
			i++;
			if ((argc > i) && opt_arg(argv[i][0])) {
				RMasciiToUInt32(argv[i], &(options->edid_max_pixclk));
				i++;
				if ((argc > i) && opt_arg(argv[i][0])) {
					RMasciiToUInt32(argv[i], &(options->edid_min_hfreq));
					i++;
					if ((argc > i) && opt_arg(argv[i][0])) {
						RMasciiToUInt32(argv[i], &(options->edid_max_hfreq));
						i++;
						if ((argc > i) && opt_arg(argv[i][0])) {
							RMasciiToUInt32(argv[i], &(options->edid_min_vfreq));
							i++;
							if ((argc > i) && opt_arg(argv[i][0])) {
								RMasciiToUInt32(argv[i], &(options->edid_max_vfreq));
								i++;
							}
						}
					}
				}
			}
		}
		if (options->edid_sel == DH_EDID_none) {
			options->standard = EMhwlibTVStandard_HDMI_480p59;  // fallback standard
			options->edid_sel = DH_EDID_mask;
		}
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-edwrite")) {
		if (argc > i + 1) {
			options->dvi_hdmi_edid_write = TRUE;
			options->dvi_hdmi_edid_file = argv[i + 1];
			i += 2;
			err = RM_OK;
		} else {
			err = RM_ERROR;
		}
	}
	else if (RMCompareAscii(argv[i], "-edread")) {
		if (argc > i + 1) {
			options->dvi_hdmi_edid_read = TRUE;
			options->dvi_hdmi_edid_file = argv[i + 1];
			i += 2;
			err = RM_OK;
		} else {
			err = RM_ERROR;
		}
	}
	else if (RMCompareAscii(argv[i], "-force_edid")) {
		if (argc > i + 1) {
			options->dvi_hdmi_edid_override = TRUE;
			options->dvi_hdmi_edid_file = argv[i + 1];
			i += 2;
			err = RM_OK;
		} else {
			err = RM_ERROR;
		}
	}
	else if (RMCompareAscii(argv[i], "-ed")) {
		if (argc > i+1) {
			if (argv[i + 1][0] == 'n') {
				options->edid_sel = DH_EDID_native;
			} else {
				RMasciiToUInt32(argv[i+1], &(options->dvi_hdmi_edid_descriptor));
				options->edid_sel = DH_EDID_force;
			}
			options->standard = EMhwlibTVStandard_HDMI_480p59;  // fallback standard
			i += 2;
			err = RM_OK;
		}
		else err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-hdmi2c")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options->i2c_module));
			i += 2;
			if ((argc > i) && (argv[i][0] >= '0') && (argv[i][0] <= '9')) {
				RMasciiToUInt32(argv[i], &(options->i2c_speed));
				i++;
			}
			err = RM_OK;
		}
		else err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-hdmi_ddc_tx")) {
		options->i2c_ddc_on_tx = TRUE;
		i++;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-dvi_reset")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options->dvi_reset_gpio));
			i += 2;
			err = RM_OK;
		}
		else err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-hdmi_act")) {
		if (argc > i+1) {
			options->hdmi_active_format_valid = TRUE;
			if (RMCompareAscii(argv[i+1], "none")) {
				options->hdmi_active_format_valid = FALSE;
			} else if (RMCompareAscii(argv[i+1], "full")) {
				options->hdmi_active_format = DH_af_same_as_picture;
			} else if (RMCompareAscii(argv[i+1], "16x9top")) {
				options->hdmi_active_format = DH_af_16x9_top;
			} else if (RMCompareAscii(argv[i+1], "14x9top")) {
				options->hdmi_active_format = DH_af_14x9_top;
			} else if (RMCompareAscii(argv[i+1], "64x27")) {
				options->hdmi_active_format = DH_af_64x27_centered;
			} else if (RMCompareAscii(argv[i+1], "4x3")) {
				options->hdmi_active_format = DH_af_4x3_centered;
			} else if (RMCompareAscii(argv[i+1], "16x9")) {
				options->hdmi_active_format = DH_af_16x9_centered;
			} else if (RMCompareAscii(argv[i+1], "14x9")) {
				options->hdmi_active_format = DH_af_14x9_centered;
			} else if (RMCompareAscii(argv[i+1], "4x3_14x9")) {
				options->hdmi_active_format = DH_af_4x3_centered_prot_14x9;
			} else if (RMCompareAscii(argv[i+1], "16x9_14x9")) {
				options->hdmi_active_format = DH_af_16x9_centered_prot_14x9;
			} else if (RMCompareAscii(argv[i+1], "16x9_4x3")) {
				options->hdmi_active_format = DH_af_16x9_centered_prot_4x3;
			} else {
				err = RM_ERROR;
			}
			if (err != RM_ERROR)
			
				err = RM_OK;
			i += 2;
		}
		else 
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-hdmi_bars")) {
		if (argc > i+4) {
			RMasciiToUInt32(argv[i+1], &(options->hdmi_bar_top));
			RMasciiToUInt32(argv[i+2], &(options->hdmi_bar_bottom));
			RMasciiToUInt32(argv[i+3], &(options->hdmi_bar_left));
			RMasciiToUInt32(argv[i+4], &(options->hdmi_bar_right));
			err = RM_OK;
			i+=5;
		}
		else 
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-hdmi_underscan")) {
		options->hdmi_scan = EMhwlibScanInfo_Underscanned;
		i++;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-hdmi_scan")) {
		if (argc > i + 1) {
			i++;
			err = RM_OK;
			if ((argv[i][0] == 'o') || (argv[i][0] == 'O')) {
				options->hdmi_scan = EMhwlibScanInfo_Overscanned;
			} else if ((argv[i][0] == 'u') || (argv[i][0] == 'U')) {
				options->hdmi_scan = EMhwlibScanInfo_Underscanned;
			} else {
				err = RM_ERROR;
			}
		} else err = RM_ERROR;
		i++;
	}
	else if (RMCompareAscii(argv[i], "-hdmi_spd")) {
		if (argc > i + 2) {
			options->hdmi_spd_vendor = argv[i + 1];
			options->hdmi_spd_product = argv[i + 2];
			options->hdmi_spd_class = DH_source_dev_unknown;
			err = RM_OK;
			i += 3;
			if ((argc > i) && opt_arg(argv[i][0])) {
				if (RMCompareAscii(argv[i], "STB")) {
					options->hdmi_spd_class = DH_source_dev_DigitalSTB;
				} else if (RMCompareAscii(argv[i], "DVD")) {
					options->hdmi_spd_class = DH_source_dev_DVD;
				} else if (RMCompareAscii(argv[i], "DVHS")) {
					options->hdmi_spd_class = DH_source_dev_DVHS;
				} else if (RMCompareAscii(argv[i], "HDD")) {
					options->hdmi_spd_class = DH_source_dev_HDDVideo;
				} else if (RMCompareAscii(argv[i], "DVC")) {
					options->hdmi_spd_class = DH_source_dev_DVC;
				} else if (RMCompareAscii(argv[i], "DSC")) {
					options->hdmi_spd_class = DH_source_dev_DSC;
				} else if (RMCompareAscii(argv[i], "VCD")) {
					options->hdmi_spd_class = DH_source_dev_VideoCD;
				} else if (RMCompareAscii(argv[i], "Game")) {
					options->hdmi_spd_class = DH_source_dev_Game;
				} else if (RMCompareAscii(argv[i], "PC")) {
					options->hdmi_spd_class = DH_source_dev_PC;
				} else if (RMCompareAscii(argv[i], "BluRay")) {
					options->hdmi_spd_class = DH_source_dev_BluRay;
				} else if (RMCompareAscii(argv[i], "SACD")) {
					options->hdmi_spd_class = DH_source_dev_SACD;
				} else {
					fprintf(stderr, "Unknown HDMI SPD class: %s\n", argv[i]);
					err = RM_ERROR;
				}
				i++;
			}
		} else err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-tmds_mode")) {
		if (argc > i+2) {
			RMuint32 gpio;
			RMasciiToUInt32(argv[i+1], &(gpio));
			options->tmds_gpio = (enum GPIOId_type)gpio;
			RMasciiToUInt32(argv[i+2], &(options->tmds_threshold));
			i += 3;
			err = RM_OK;
		}
		else err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-filter_gpio")) {
		if (argc > i+3) {
			RMuint32 gpio;
			RMasciiToUInt32(argv[i+1], &(gpio));
			options->filter_gpio_start = (enum GPIOId_type)gpio;
			RMasciiToUInt32(argv[i+2], &(options->filter_gpio_num));
			RMasciiToUInt32(argv[i+3], &(options->filter_gpio_val));
			i += 4;
			err = RM_OK;
		}
		else err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-mv_filter")) {
		if (argc > i+1) {
			if (RMCompareAscii(argv[i], "0")) {
				options->filtermode.Boundary_0_1 = 0x4000;
				options->filtermode.Boundary_1_2 = 0x4000;
				options->filtermode.Boundary_2_3 = 0x4000;

			} else if (RMCompareAscii(argv[i+1], "1")) {
				options->filtermode.Boundary_0_1 = 0x0000;
				options->filtermode.Boundary_1_2 = 0x4000;
				options->filtermode.Boundary_2_3 = 0x4000;

			} else if (RMCompareAscii(argv[i+1], "2")) {
				options->filtermode.Boundary_0_1 = 0x0000;
				options->filtermode.Boundary_1_2 = 0x0000;
				options->filtermode.Boundary_2_3 = 0x4000;

			} else if (RMCompareAscii(argv[i+1], "3")) {
				options->filtermode.Boundary_0_1 = 0x0000;
				options->filtermode.Boundary_1_2 = 0x0000;
				options->filtermode.Boundary_2_3 = 0x0000;

			} else if (RMCompareAscii(argv[i+1], "auto")) {
				options->filtermode.Boundary_0_1 = 0x1400;
				options->filtermode.Boundary_1_2 = 0x1c00;
				options->filtermode.Boundary_2_3 = 0x2c00;
			}
			else
				err = RM_ERROR;
			i += 2;
			err = RM_OK;
		}
		else err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-luma_lpf")) {
		if (argc > i+1) {
			if (RMCompareAscii(argv[i], "0")) {
				options->downscalingmode.Discard = FALSE;
				options->downscalingmode.FilterBoundary[0] = 0;
				options->downscalingmode.FilterBoundary[1] = 0;
				options->downscalingmode.FilterBoundary[2] = 0;

			} else if (RMCompareAscii(argv[i+1], "1")) {
				options->downscalingmode.Discard = FALSE;
				options->downscalingmode.FilterBoundary[0] = 512;
				options->downscalingmode.FilterBoundary[1] = 0;
				options->downscalingmode.FilterBoundary[2] = 0;


			} else if (RMCompareAscii(argv[i+1], "2")) {
				options->downscalingmode.Discard = FALSE;
				options->downscalingmode.FilterBoundary[0] = 512;
				options->downscalingmode.FilterBoundary[1] = 512;
				options->downscalingmode.FilterBoundary[2] = 0;


			} else if (RMCompareAscii(argv[i+1], "3")) {
				options->downscalingmode.Discard = FALSE;
				options->downscalingmode.FilterBoundary[0] = 512;
				options->downscalingmode.FilterBoundary[1] = 512;
				options->downscalingmode.FilterBoundary[2] = 512;

			} else if (RMCompareAscii(argv[i+1], "auto")) {
				options->downscalingmode.Discard = FALSE;
				options->downscalingmode.FilterBoundary[0] = 384;
				options->downscalingmode.FilterBoundary[1] = 256;
				options->downscalingmode.FilterBoundary[2] = 128;
			}
			else
				err = RM_ERROR;
			i += 2;
			err = RM_OK;
		}
		else err = RM_ERROR;
	}

	else if (RMCompareAscii(argv[i], "-strips")) {
		if (argc > i+2) {
			RMasciiToUInt32(argv[i+1], &(options->blackstrip.Horizontal));
			RMasciiToUInt32(argv[i+2], &(options->blackstrip.Vertical));
			err = RM_OK;
			i+=3;
		}
		else 
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-cutstrips")) {
		if (argc > i+2) {
			RMasciiToUInt32(argv[i+1], &(options->cutstrip.Horizontal));
			RMasciiToUInt32(argv[i+2], &(options->cutstrip.Vertical));
			err = RM_OK;
			i+=3;
		}
		else 
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-sm")) {
		if (argc > i+1) {
			if (RMCompareAscii(argv[i+1], "letterBox")) {
				options->scalingmode = EMhwlibScalingMode_LetterBox;
			}
			else if (RMCompareAscii(argv[i+1], "panScan")) {
				options->scalingmode = EMhwlibScalingMode_PanScan;
			}		
			else if (RMCompareAscii(argv[i+1], "ARIB")) {
				options->scalingmode = EMhwlibScalingMode_ARIB;
			}		
			else
				err = RM_ERROR;
			if (err != RM_ERROR)
				err = RM_OK;
			i+=2;
		}
		else 
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-D")) {
		if (argc > i+1) {
			if (RMCompareAscii(argv[i+1], "0")) {
				options->deinterlacingmode = EMhwlibDeinterlacingMode_Discard_Bob;
			}
			else if (RMCompareAscii(argv[i+1], "1")) {
				options->deinterlacingmode = EMhwlibDeinterlacingMode_ConstantBlend;
			}
			else if (RMCompareAscii(argv[i+1], "2")) {
				options->deinterlacingmode = EMhwlibDeinterlacingMode_MotionAdaptative;
			}
			else if (RMCompareAscii(argv[i+1], "3")) {
				options->deinterlacingmode = EMhwlibDeinterlacingMode_Weave;
			}
			else
				err = RM_ERROR;
			if (err != RM_ERROR)
				err = RM_OK;
			i+=2;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-32pd")) {
		options->do_pulldown = TRUE;
		i++;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-motion_config")) {
		if (argc > i+1) {
			RMuint32 config;
			
			if (RMNCompareAscii(argv[i+1], "0x", 2)) 
				RMasciiHexToUint32(argv[i+1]+2, &(config));
			else
				RMasciiToUInt32(argv[i+1], &(config));
			options->deinterlacing_motion_config.Value0 = (config >> 0) & 0xff;
			options->deinterlacing_motion_config.Value8 = (config >> 8) & 0xff;
			options->deinterlacing_motion_config.Value16 = (config >> 16) & 0xff;
			options->deinterlacing_motion_config.Value32 = (config >> 24) & 0xff;
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-d2_proportion")) {
		if (argc > i+1) {
			RMuint32 config;
			
			if (RMNCompareAscii(argv[i+1], "0x", 2)) 
				RMasciiHexToUint32(argv[i+1]+2, &(config));
			else
				RMasciiToUInt32(argv[i+1], &(config));
			options->deinterlacing_proportion.ExistingLineProportion = (config >> 0) & 0xff;
			options->deinterlacing_proportion.NewLineProportion = (config >> 8) & 0xff;
			i+=2;
			err = RM_OK;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-disp_init")) {
		options->init_mode = DCCInitMode_InitDisplay;
		i++;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-cdb")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options->color_degradation_boundary));
		}
		else
			err = RM_ERROR;
		if (err != RM_ERROR)
			err = RM_OK;
		i+=2;
	}
	else if (RMCompareAscii(argv[i], "-dp")) {
		if (argc > i + 1) {
			if (RMCompareAscii(argv[i + 1], "601")) {
				options->dig_protocol = EMhwlibDigitalTimingSignal_601;
			}
			else if (RMCompareAscii(argv[i + 1], "656")) {
				options->dig_protocol = EMhwlibDigitalTimingSignal_656;
			}
			else if (RMCompareAscii(argv[i + 1], "vip")) {
				options->dig_protocol = EMhwlibDigitalTimingSignal_656_VIP;
			}
			else
				err = RM_ERROR;
			if (err != RM_ERROR)
				err = RM_OK;
			i += 2;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-dig_dr")) {
		if (argc > i+1) {
			RMuint32 param;
			RMasciiToUInt32(argv[i+1], &param);
			options->dig_force_doublerate = TRUE;
			options->dig_doublerate = param ? TRUE : FALSE;
			i += 2;
			err = RM_OK;
		}
		else err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-dclk")) {
		options->dig_clk_normal = TRUE;
		i++;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-ddr")) {
		options->dig_ddr = TRUE;
		i++;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-ddr_delay")) {
		fprintf(stderr, "parse_display_cmdline.c.c: -ddr_delay option is obsolete, use -dig_delay instead!\n");
		if (argc > i+1) {
			RMuint32 dig_ddr_delay;
			RMasciiToUInt32(argv[i+1], &(dig_ddr_delay));
			dig_ddr_delay &= 0x07;
			options->dig_delay = dig_ddr_delay * 800;
			options->dig_force_delay = TRUE;
			err = RM_OK;
		} else {
			err = RM_ERROR;
		}
		i += 2;
	}
	else if (RMCompareAscii(argv[i], "-dig_delay")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options->dig_delay));
			options->dig_force_delay = TRUE;
			err = RM_OK;
		} else {
			err = RM_ERROR;
		}
		i += 2;
	}
	else if (RMCompareAscii(argv[i], "-dig_no_delay")) {
		fprintf(stderr, "parse_display_cmdline.c.c: -dig_no_delay option is obsolete, use -dig_delay instead!\n");
		options->dig_force_delay = TRUE;
		if ((argc > i+1) && opt_arg(argv[i+1][0])) {
			options->dig_delay = (argv[i+1][0] != '0') ? 0 : 400;
			i++;
		} else {
			options->dig_delay = 0;
		}
		i++;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-inv_cap_clk")) {
		options->dig_inv_cap_clk = TRUE;
		i++;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-vsync_delay")) {
		options->dig_vsync_delay = TRUE;
		i++;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-trailing_edge")) {
		options->dig_trailing_edge = TRUE;
		i++;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-chroma_sync")) {
		if ((argc > i + 1) && opt_arg(argv[i + 1][0])) {
			i++;
			if ((argv[i][0] == 's') || (argv[i][0] == 'S') || (argv[i][0] == '1'))
				options->chroma_sync = TRUE;
		}
		i++;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-scart_en")) {
		if (argc > i + 1) {
			RMuint32 param;
			RMasciiToUInt32(argv[i + 1], &param);
			options->scart_enable = param ? TRUE : FALSE;
			if ((argc > i + 2) && opt_arg(argv[i + 2][0])) {
				RMasciiToUInt32(argv[i + 2], &(options->scart_en_pio));
				options->scart_en_pio++;
				if ((argc > i + 3) && opt_arg(argv[i + 3][0])) {
					if (argv[i + 3][0] != '0') options->scart_en_pio |= 0x100;
					i++;
				}
				i++;
			} else {
				options->scart_en_pio = SCART_ENABLE_GPIO + 1;
			}
			err = RM_OK;
		} else {
			err = RM_ERROR;
		}
		i += 2;
	}
	else if (RMCompareAscii(argv[i], "-scart_ws")) {
		if (argc > i + 1) {
			RMuint32 param;
			if (argv[i + 1][0] != 'a') {
				RMasciiToUInt32(argv[i + 1], &param);
				options->scart_widescreen = param ? TRUE : FALSE;
				options->scart_ws_pio |= 0x200;  // force WS
			}
			if ((argc > i + 2) && opt_arg(argv[i + 2][0])) {
				RMasciiToUInt32(argv[i + 2], &param);
				options->scart_ws_pio = (options->scart_ws_pio & 0xFF00) | (param + 1);
				if ((argc > i + 3) && opt_arg(argv[i + 3][0])) {
					if (argv[i + 3][0] != '0') options->scart_ws_pio |= 0x100;
					i++;
				}
				i++;
			} else {
				options->scart_ws_pio = (options->scart_ws_pio & 0xFF00) | (SCART_WIDESCREEN_GPIO + 1);
			}
			err = RM_OK;
		} else {
			err = RM_ERROR;
		}
		i += 2;
	}
	else if (RMCompareAscii(argv[i], "-genlock")) {
		options->genlock_min = 0;
		options->genlock_max = 0;
		i++;
		if ((argc > i) && ((argv[i][0] == 'v') || (argv[i][0] == 'V'))) {
			options->genlock_input = DispVideoInput;
		} else if ((argc > i) && ((argv[i][0] == 'g') || (argv[i][0] == 'G'))) {
			options->genlock_input = DispGraphicInput;
		} else {
			options->genlock_input = 0;
			fprintf(stderr, "specify either 'v' or 'g' after -genlock\n");
			err = RM_ERROR;
		}
		if (options->genlock_input) {
			RMuint32 val;
			i++;
			if ((argc > i) && opt_arg(argv[i][0])) {
				RMasciiToUInt32(argv[i], &val);
				options->genlock_min = val & 0xFF;
				i++;
				if ((argc > i) && opt_arg(argv[i][0])) {
					RMasciiToUInt32(argv[i], &val);
					options->genlock_max = val & 0xFF;
					i++;
				}
			}
			err = RM_OK;
		}
	}
	else if (RMCompareAscii(argv[i], "-input")) {
		err = RM_OK;
		i++;
		if ((argc > i) && ((argv[i][0] == 'v') || (argv[i][0] == 'V'))) {
			options->input = DispVideoInput;
			if (argv[i][1] == '2') options->input_usev2 = TRUE;
		} else if ((argc > i) && ((argv[i][0] == 'g') || (argv[i][0] == 'G'))) {
			options->input = DispGraphicInput;
			if (argv[i][1] == '2') options->input_usev2 = TRUE;
		} else {
			options->input = 0;
			fprintf(stderr, "specify either 'v' or 'g' after -input\n");
			err = RM_ERROR;
		}
		if (options->input) {
			if ((i + 1 < argc) && opt_arg(argv[i + 1][0])) {
				i++;
				RMasciiToUInt32(argv[i], &(options->input_bussize));
				if ((i + 1 < argc) && opt_arg(argv[i + 1][0])) {
					i++;
					if (! strcmp(argv[i], "601")) {
						options->input_timingsignal = EMhwlibDigitalTimingSignal_601;
						options->input_vvld = FALSE;
					} else if (! strcmp(argv[i], "601v")) {
						options->input_timingsignal = EMhwlibDigitalTimingSignal_601;
						options->input_vvld = TRUE;
					} else if (! strcmp(argv[i], "656")) {
						options->input_timingsignal = EMhwlibDigitalTimingSignal_656;
					} else {
						fprintf(stderr, "unknown protocol: %s!\n", argv[i]);
						err = RM_ERROR;
					}
					i++;
					if ((i + 1 < argc) && opt_arg(argv[i + 1][0])) {
						i++;
						if (RMFAILED(GetTVStandard(argv[i], &(options->input_mode)))) {
							fprintf(stderr, "unknown TV standard: %s!\n", argv[i]);
							err = RM_ERROR;
						}
					} else {
						if (options->input_timingsignal == EMhwlibDigitalTimingSignal_601) {
							fprintf(stderr, "please specify a TV standard after -input 601\n");
							err = RM_ERROR;
						} else {
							options->input_mode = EMhwlibTVStandard_ITU_Bt656_525;
						}
					}
					while ((i + 1 < argc) && opt_arg(argv[i + 1][0])) {
						i++;
						if (! strcmp(argv[i], "invv")) {
							options->input_invv = TRUE;
						} else if (! strcmp(argv[i], "invh")) {
							options->input_invh = TRUE;
						} else if (! strcmp(argv[i], "v2")) {
							options->input_usev2 = TRUE;
						}
					}
				} else if (options->input_timingsignal == EMhwlibDigitalTimingSignal_656) {
					options->input_mode = EMhwlibTVStandard_ITU_Bt656_525;
				}
			} else if (options->input_timingsignal == EMhwlibDigitalTimingSignal_656) {
				options->input_mode = EMhwlibTVStandard_ITU_Bt656_525;
			}
		}
		i++;
	}
	else if (RMCompareAscii(argv[i], "-time_interval")) {
		if (argc > i+1) {
			for (j=0 ; j<RMasciiLength(argv[i+1]) ; j++) 
				if (argv[i+1][j] == '-')
					break;

			if (j==0)
				options->time_interval.Mode = EMhwlibDisplayIntervalMode_End;
			else if (j == RMasciiLength(argv[i+1]) - 1)
				options->time_interval.Mode = EMhwlibDisplayIntervalMode_Start;
			else if (j < RMasciiLength(argv[i+1])) {
				options->time_interval.Mode = EMhwlibDisplayIntervalMode_StartEnd;
			}

			if (j < strlen(argv[i+1])) {
				argv[i+1][j] = '\0';
				
				RMasciiToUInt32(argv[i+1], &(options->time_interval.StartPTSLo));
				options->time_interval.StartPTSHi = 0;
				RMasciiToUInt32(argv[i+1]+j+1, &(options->time_interval.EndPTSLo));
				options->time_interval.EndPTSHi = 0;
				i += 2;
				err = RM_OK;
			}
			else 
				err = RM_ERROR;
		}
		else
			err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-dac_comp")) {
		if (argc > i + 1) {
			options->force_DACCompDisable = TRUE;
			options->DACCompDisable = (argv[i + 1][0] == '0');
			i += 2;
			err = RM_OK;
		}
		else err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-gamma")) {
		if (argc > i+1) {
			RMasciiToUInt32(argv[i+1], &(options->gamma_table));
			i += 2;
			err = RM_OK;
		}
		else err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-lumakey")) {
		if (argc > i+2) {
			if (RMNCompareAscii(argv[i+1], "0x", 2)) 
				RMasciiHexToUint32(argv[i+1]+2, &(options->luma_key.LumaMin));
			else
				RMasciiToUInt32(argv[i+1], &(options->luma_key.LumaMin));
			
			if (RMNCompareAscii(argv[i+2], "0x", 2)) 
				RMasciiHexToUint32(argv[i+2]+2, &(options->luma_key.LumaMax));
			else
				RMasciiToUInt32(argv[i+2], &(options->luma_key.LumaMax));

			i+=3;
			err = RM_OK;
		}
		else err = RM_ERROR;
	}
	else if (RMCompareAscii(argv[i], "-dis_pix_timer")) {
		options->disable_pixel_timer = TRUE;
		i++;
		err = RM_OK;
	}
	else if (RMCompareAscii(argv[i], "-hdmi_convert")) {
		if (argc > i + 3) {
			options->hdmi_convert = TRUE;
			err = parse_color_space(argv[i + 1], &(options->hdmi_color_space));
			if (RMCompareAscii(argv[i+2], "422")) {
				options->hdmi_sampling_mode = EMhwlibSamplingMode_422;
			} else if (RMCompareAscii(argv[i+2], "444")) {
				options->hdmi_sampling_mode = EMhwlibSamplingMode_444;
			} else err = RM_ERROR;
			RMasciiToUInt32(argv[i+3], &(options->hdmi_component_depth));
			if (err != RM_ERROR) err = RM_OK;
			i += 4;
		}
		else
			err = RM_ERROR;
	}
	
	*index = i;
	
	return err;
}

static RMstatus parse_line_element(RMascii *line, RMuint32 *pPos, RMuint32 *pValue)
{
	RMuint32 s;
	
	// skip initial non-digits
	while ((line[*pPos] != '\0') && ((line[*pPos] < '0') || (line[*pPos] > '9'))) (*pPos)++;
	// check if string end is reached
	if (line[*pPos] == '\0') return RM_ERROR;
	// remember start of number
	s = *pPos;
	// search for first non-digit after number
	while ((line[*pPos] >= '0') && (line[*pPos] <= '9')) (*pPos)++;
	// turn into string end
	line[*pPos] = '\0';
	// skip pointer over string end to next element
	(*pPos)++;
	// turn number string into integer
	RMasciiToUInt32(&line[s], pValue);
	return RM_OK;
}

RMstatus parse_video_mode_file(
	RMascii *filename, 
	struct EMhwlibTVFormatDigital *pDig, 
	struct EMhwlibTVFormatAnalog *pAna)
{
	RMstatus err;
	RMfile fp;
	RMascii line[2048];
	struct CEADetailedTimingDescriptor DTD;
	RMuint32 p;
	RMuint32 pix, ha, va, ht, hfp, hs, hbp, hp, vt, vfp, vs, vbp, vp;
	
	// read first non-comment line from file
	fp = open_stream(filename, RM_FILE_OPEN_READ, 0);
	if (fp == NULL) return RM_ERROR;
	do {
		err = RMReadLineFile(fp, line, 2048);
	} while (RMSUCCEEDED(err) && (line[0] == '#'));
	RMCloseFile(fp);
	
	if (RMSUCCEEDED(err)) {
		// parse line into video mode parameters
		p = 0;
		err = parse_line_element(line, &p, &pix);
		if (RMFAILED(err)) return err;
		err = parse_line_element(line, &p, &ha);
		if (RMFAILED(err)) return err;
		err = parse_line_element(line, &p, &va);
		if (RMFAILED(err)) return err;
		err = parse_line_element(line, &p, &ht);
		if (RMFAILED(err)) return err;
		err = parse_line_element(line, &p, &hfp);
		if (RMFAILED(err)) return err;
		err = parse_line_element(line, &p, &hs);
		if (RMFAILED(err)) return err;
		err = parse_line_element(line, &p, &hbp);
		if (RMFAILED(err)) return err;
		err = parse_line_element(line, &p, &hp);
		if (RMFAILED(err)) return err;
		err = parse_line_element(line, &p, &vt);
		if (RMFAILED(err)) return err;
		err = parse_line_element(line, &p, &vfp);
		if (RMFAILED(err)) return err;
		err = parse_line_element(line, &p, &vs);
		if (RMFAILED(err)) return err;
		err = parse_line_element(line, &p, &vbp);
		if (RMFAILED(err)) return err;
		err = parse_line_element(line, &p, &vp);
		if (RMFAILED(err)) return err;
		if (ha + hfp + hs + hbp != ht) 
			fprintf(stderr, "Warning: horizontal paraneters don't add up to toal size\n");
		// create DTD struct
		DTD.PixelClock = pix;
		DTD.NbHorizActivePixels = ha;
		DTD.NbHorizBlankingPixels = ht - ha;
		DTD.NbVertActiveLines = va;
		DTD.NbVertBlankingLines = vt - va;
		DTD.HorizSyncOffset = hfp;
		DTD.HorizSyncPulseWidth = hs;
		DTD.VertSyncOffset = vfp;
		DTD.VertSyncPulseWidth = vs;
		DTD.HorizImageSize_mm = 0;
		DTD.VertImageSize_mm = 0;
		DTD.HorizBorder = 0;
		DTD.VertBorder = 0;
		DTD.Interlaced = (va < (vt / 2)) ? TRUE : FALSE;
		DTD.StereoModeDecode = 0;
		DTD.SyncSignalDescription = 3;
		DTD.SyncSignalInfo = (hp ? 0x01 : 0x00) | (vp ? 0x02 : 0x00);
		// turn DTD struct into emhwlib video formats
		if (RMFAILED(err = DHGetEmhwlibDigitalFormatFromCEADetailedTimingDescriptor(&DTD, pDig))) return err;
		if (RMFAILED(err = DHGetEmhwlibAnalogFormatFromCEADetailedTimingDescriptor(&DTD, pAna))) return err;
	}
	return RM_OK;
}

static RMstatus display_edid_header(struct EDID_Data *pedid)
{
	RMstatus err = RM_OK;
	RMascii ID[4];
	RMuint32 i;

	fprintf(stderr, "\n");
	fprintf(stderr, "******************************************\n");
	fprintf(stderr, "Displaying EDID Version.Revision %d.%d\n", pedid->EDID_Version, pedid->EDID_Revision);
	fprintf(stderr, "******************************************\n");
	
	// EDID should start with 0x00 0xFF 0xFF 0xFF 0xFF 0xFF 0xFF 0x00
	if ((pedid->EDID_Header[0] != 0) || (pedid->EDID_Header[7] != 0))
		err = RM_ERROR;
	for (i = 1; i <= 6; i++) {
		if (pedid->EDID_Header[i] != 0xFF) {
			err = RM_ERROR;
			break;
		}
	}
	fprintf(stderr, "Header %02x %02x %02x %02x %02x %02x %02x %02x - %s\n",
		pedid->EDID_Header[0], pedid->EDID_Header[1], pedid->EDID_Header[2], pedid->EDID_Header[3], 
		pedid->EDID_Header[4], pedid->EDID_Header[5], pedid->EDID_Header[6], pedid->EDID_Header[7],
		(RMFAILED(err)) ? "Error" : "OK");
	
	ID[0] = 'A' + ((pedid->EDID_ManufacturerName[0] >> 2) & 0x1F) - 1;
	ID[1] = 'A' + ((pedid->EDID_ManufacturerName[0] & 0x03) << 3) + ((pedid->EDID_ManufacturerName[1] >> 5) & 0x07) - 1;
	ID[2] = 'A' + (pedid->EDID_ManufacturerName[1] & 0x1F) - 1;
	ID[3] = '\0';
	fprintf(stderr, "Vendor: %s, Product: 0x%02X%02X, Serial#: 0x%02X%02X%02X%02X, %02u/%4d\n", 
		ID, pedid->EDID_ProductCode[0], pedid->EDID_ProductCode[1], 
		pedid->EDID_SerialNumber[0], pedid->EDID_SerialNumber[1], 
		pedid->EDID_SerialNumber[2], pedid->EDID_SerialNumber[3], 
		pedid->EDID_ManufactureWeek[0], pedid->EDID_ManufactureYear[0] + 1990);
	
	fprintf(stderr, "Display - InputDef: 0x%02X, Size: %ux%u cm, Gamma: %u.%02u, \n", 
		pedid->EDID_BasicData[0], 
		pedid->EDID_BasicData[1], pedid->EDID_BasicData[2],
		(pedid->EDID_BasicData[3] + 100) / 100, (pedid->EDID_BasicData[3] + 100) % 100);
	fprintf(stderr, "  Features: %sStandby, %sSuspend, %sActive Off, \n", 
		(pedid->EDID_BasicData[4] & 0x80) ? "" : "No ", 
		(pedid->EDID_BasicData[4] & 0x40) ? "" : "No ", 
		(pedid->EDID_BasicData[4] & 0x20) ? "" : "No ");
	fprintf(stderr, "  %s Display, %ssRGB, %sPreferred Timing, %sGTF\n", 
		((pedid->EDID_BasicData[4] & 0x18) == 0) ? "Monochrome" : 
		((pedid->EDID_BasicData[4] & 0x18) == 1) ? "RGB" : 
		((pedid->EDID_BasicData[4] & 0x18) == 2) ? "Non-RGB" : "Undefined", 
		(pedid->EDID_BasicData[4] & 0x04) ? "" : "No ", 
		(pedid->EDID_BasicData[4] & 0x02) ? "" : "No ", 
		(pedid->EDID_BasicData[4] & 0x01) ? "" : "No ");
	
	// TODO: EDID_Phos_Filter, EDID_Estab_Timing, EDID_Stand_Timing_mode0, EDID_Stand_Timing_mode1
	
	fprintf(stderr, "Number of 128 bytes EDID Extension blocks: %d\n", pedid->EDID_Extension);
	return err;
}

static RMstatus display_edid_timing_extension_header(RMuint8 *pedid)
{
	RMstatus err = RM_OK;
	
	fprintf(stderr, "\n");
	if (pedid[0] != 0x2) {
		fprintf(stderr, "Not an EDID extension timing!\n");
		return RM_ERROR;
	}

	fprintf(stderr, "******************************************\n");
	fprintf(stderr, "Displaying EDID timing extension\n");
	fprintf(stderr, "******************************************\n");

	fprintf(stderr, "Revision number %d\n", pedid[1]);
	fprintf(stderr, "Extended block type: ");
	if (pedid[1] == 2)
		fprintf(stderr, "CEA 861A\n");
	else if (pedid[1] == 3)
		fprintf(stderr, "CEA 861B\n");
	else {
		fprintf(stderr, "Unknown!\n");
		return RM_ERROR;
	}

	fprintf(stderr, "Total number of native formats %d\n", pedid[3] & 0x0F); // Lower 4 bits
	if (pedid[3] & 0x80)
		fprintf(stderr, "Monitor supports underscan\n");
	else
		fprintf(stderr, "Monitor does not support underscan\n");
	if (pedid[3] & 0x40)
		fprintf(stderr, "Monitor supports basic audio\n");
	else
		fprintf(stderr, "Monitor does not support basic audio\n");
	if (pedid[3] & 0x20)
		fprintf(stderr, "Monitor supports YC(B)C(R) 4:4:4 in addition to RGB\n");
	else
		fprintf(stderr, "Monitor does not support YC(B)C(R) 4:4:4\n");
	if (pedid[3] & 0x10)
		fprintf(stderr, "Monitor supports YC(B)C(R) 4:2:2 in addition to RGB\n");
	else
		fprintf(stderr, "Monitor does not support YC(B)C(R) 4:2:2\n");
	return err;
}


#ifdef _DEBUG
#define NB_SHORT_VIDEO_DESCRIPTORS 60
static RMascii *CEA861_ShortDescriptorVideoResolutions[NB_SHORT_VIDEO_DESCRIPTORS] = {
	"No video code",
	"640x480p 59.94/60Hz (4:3)",          // 1
	"720x480p 59.94/60Hz (4:3)",          // 2
	"720x480p 59.94/60Hz (16:9)",         // 3
	"1280x720p 59.94/60Hz (16:9)",        // 4
	"1920x1080i 59.94/60Hz (16:9)",       // 5
	"720(1440)x480i 59.94/60Hz (4:3)",    // 6
	"720(1440)x480i 59.94/60Hz (16:9)",   // 7
	"720(1440)x240p 59.94/60Hz (4:3)",    // 8
	"720(1440)x240p 59.94/60Hz (16:9)",   // 9
	"(2880)x480i 59.94/60Hz (4:3)",       // 10
	"(2880)x480i 59.94/60Hz (16:9)",      // 11
	"(2880)x240p 59.94/60Hz (4:3)",       // 12
	"(2880)x240p 59.94/60Hz (16:9)",      // 13
	"1440x480p 59.94/60Hz (4:3)",         // 14
	"1440x480p 59.94/60Hz (16:9)",        // 15
	"1920x1080p 59.94/60Hz (16:9)",       // 16
	"720x576p 50Hz (4:3)",                // 17
	"720x576p 50Hz (16:9)",               // 18
	"1280x720p 50Hz (16:9)",              // 19
	"1920x1080i 50Hz (16:9)",             // 20
	"720(1440)x576i 50Hz (4:3)",          // 21
	"720(1440)x576i 50Hz (16:9)",         // 22
	"720(1440)x288p 50Hz (4:3)",          // 23
	"720(1440)x288p 50Hz (16:9)",         // 24
	"(2880)x576i 50Hz (4:3)",             // 25
	"(2880)x576i 50Hz (16:9)",            // 26
	"(2880)x288p 50Hz (4:3)",             // 27
	"(2880)x288p 50Hz (16:9)",            // 28
	"1440x576p 50Hz (4:3)",               // 29
	"1440x576p 50Hz (16:9)",              // 30
	"1920x1080p 50Hz (16:9)",             // 31
	"1920x1080p 23.97/24Hz (16:9)",       // 32
	"1920x1080p 25Hz (16:9)",             // 33
	"1920x1080p 29.97/30Hz (16:9)",       // 34
	"(2880)x480p 59.94/60Hz (4:3)",       // 35
	"(2880)x480p 59.94/60Hz (16:9)",      // 36
	"(2880)x576p 50Hz (4:3)",             // 37
	"(2880)x576p 50Hz (16:9)",            // 38
	"1920x1080i(1250) 50Hz (16:9)",       // 39
	"1920x1080i 100Hz (16:9)",            // 40
	"1280x720p 100Hz (16:9)",             // 41
	"720x576p 100Hz (4:3)",               // 42
	"720x576p 100Hz (16:9)",              // 43
	"720(1440)x576i 100Hz (4:3)",         // 44
	"720(1440)x576i 100Hz (16:9)",        // 45
	"1920x1080i 119.88/120Hz (16:9)",     // 46
	"1280x720p 119.88/120Hz (16:9)",      // 47
	"720x480p 119.88/120Hz (4:3)",        // 48
	"720x480p 119.88/120Hz (16:9)",       // 49
	"720(1440)x480i 119.88/120Hz (4:3)",  // 50
	"720(1440)x480i 119.88/120Hz (16:9)", // 51
	"720x576p 200Hz (4:3)",               // 52
	"720x576p 200Hz (16:9)",              // 53
	"720(1440)x576i 200Hz (4:3)",         // 54
	"720(1440)x576i 200Hz (16:9)",        // 55
	"720x480p 239.76/240Hz (4:3)",        // 56
	"720x480p 239.76/240Hz (16:9)",       // 57
	"720(1440)x480i 239.76/240Hz (4:3)",  // 58
	"720(1440)x480i 239.76/240Hz (16:9)", // 59
};
#else
#define NB_SHORT_VIDEO_DESCRIPTORS 1
static RMascii *CEA861_ShortDescriptorVideoResolutions[NB_SHORT_VIDEO_DESCRIPTORS] = {
	"no video code description",
};
#endif

static void display_cea861B_data_block_collection(struct CEA861BDataBlockCollection *pDBC)
{
	fprintf(stderr, "\n******* CEA Data Block collection ********\n");
	
	if (pDBC->BasicTVValid) {
		fprintf(stderr, "BasicTVSupport: 0x%02X (underscan=%u, basicaudio=%u, yuv444=%u, yuv422=%u)\n", pDBC->BasicTVSupport, 
			pDBC->BasicTVSupport & TV_SUPPORT_UNDERSCAN ? 1 : 0, 
			pDBC->BasicTVSupport & TV_SUPPORT_BASIC_AUDIO ? 1 : 0, 
			pDBC->BasicTVSupport & TV_SUPPORT_YUV444 ? 1 : 0, 
			pDBC->BasicTVSupport & TV_SUPPORT_YUV422 ? 1 : 0);
	}
	if (pDBC->SpeakerValid) {
		fprintf(stderr, "SpeakerConfigurationCode: 0x%02X\n", pDBC->SpeakerConfigurationCode);
	}
	fprintf(stderr, "HDMI_sink: %u\n", pDBC->HDMI_sink ? 1 : 0);
	if (pDBC->HDMI_sink) {
		fprintf(stderr, "HDMI_PhysAddr: %u.%u.%u.%u\n", 
			(pDBC->HDMI_PhysAddr >> 12) & 0x0F, 
			(pDBC->HDMI_PhysAddr >>  8) & 0x0F, 
			(pDBC->HDMI_PhysAddr >>  4) & 0x0F, 
			pDBC->HDMI_PhysAddr & 0x0F);
	}
	if (pDBC->CEASinkValid) {
		fprintf(stderr, "SinkCapability: 0x%02X (AI=%u, DC48=%u, DC36=%u, DC30=%u, DC444=%u, DVIDual=%u\n", pDBC->SinkCapability, 
			pDBC->SinkCapability & SINK_SUPPORT_AI ? 1 : 0, 
			pDBC->SinkCapability & SINK_SUPPORT_DEEP_COLOR_48 ? 1 : 0, 
			pDBC->SinkCapability & SINK_SUPPORT_DEEP_COLOR_36 ? 1 : 0, 
			pDBC->SinkCapability & SINK_SUPPORT_DEEP_COLOR_30 ? 1 : 0, 
			pDBC->SinkCapability & SINK_SUPPORT_DEEP_COLOR_444 ? 1 : 0, 
			pDBC->SinkCapability & SINK_SUPPORT_DVI_DUAL ? 1 : 0);
	}
	if (pDBC->CEATMDSValid) {
		fprintf(stderr, "MaxTMDSClock: %u MHz\n", pDBC->MaxTMDSClock * 5);
	}
	if (pDBC->CEALatencyValid) {
		if (pDBC->LatencyPresent & SINK_LATENCY_PRESENT) {
			if (pDBC->LatencyPresent & SINK_LATENCY_INTERLACED_PRESENT) {
				fprintf(stderr, "Progressive Video Latency=");
				if (pDBC->VideoLatency == 0) fprintf(stderr, "unknown\n");
				else if (pDBC->VideoLatency == 255) fprintf(stderr, "no video\n");
				else fprintf(stderr, "%u mSec\n", (pDBC->VideoLatency - 1) * 2);
				fprintf(stderr, "Progressive Audio Latency=");
				if (pDBC->AudioLatency == 0) fprintf(stderr, "unknown\n");
				else if (pDBC->AudioLatency == 255) fprintf(stderr, "no audio\n");
				else fprintf(stderr, "%u mSec\n", (pDBC->AudioLatency - 1) * 2);
				fprintf(stderr, "Interlaced Video Latency=");
				if (pDBC->InterlacedVideoLatency == 0) fprintf(stderr, "unknown\n");
				else if (pDBC->InterlacedVideoLatency == 255) fprintf(stderr, "no video\n");
				else fprintf(stderr, "%u mSec\n", (pDBC->InterlacedVideoLatency - 1) * 2);
				fprintf(stderr, "Interlaced Audio Latency=");
				if (pDBC->InterlacedAudioLatency == 0) fprintf(stderr, "unknown\n");
				else if (pDBC->InterlacedAudioLatency == 255) fprintf(stderr, "no audio\n");
				else fprintf(stderr, "%u mSec\n", (pDBC->InterlacedAudioLatency - 1) * 2);
			} else {
				fprintf(stderr, "Video Latency=");
				if (pDBC->VideoLatency == 0) fprintf(stderr, "unknown\n");
				else if (pDBC->VideoLatency == 255) fprintf(stderr, "no video\n");
				else fprintf(stderr, "%u mSec\n", (pDBC->VideoLatency - 1) * 2);
				fprintf(stderr, "Audio Latency=");
				if (pDBC->AudioLatency == 0) fprintf(stderr, "unknown\n");
				else if (pDBC->AudioLatency == 255) fprintf(stderr, "no audio\n");
				else fprintf(stderr, "%u mSec\n", (pDBC->AudioLatency - 1) * 2);
			}
		} else {
			fprintf(stderr, "No Latency data present.\n");
		}
	}
	if (pDBC->ColorimetryValid) {
		fprintf(stderr, "ColorimetrySupport: 0x%02X (xvYCC601=%u, xvYCC709=%u)\n", pDBC->ColorimetrySupport, 
			pDBC->ColorimetrySupport & TV_SUPPORT_COLORIMETRY_XVYCC601 ? 1 : 0, 
			pDBC->ColorimetrySupport & TV_SUPPORT_COLORIMETRY_XVYCC709 ? 1 : 0);
		fprintf(stderr, "MetaDataProfile: 0x%02X\n", pDBC->MetaDataProfile);
	}
	if (pDBC->VideoValid) {
		fprintf(stderr, "VideoCapability: 0x%02X (CE over=%u, under=%u, IT over=%u, under=%u, PT over=%u, under=%u, AVI-Q=%u)\n", pDBC->VideoCapability, 
			pDBC->VideoCapability & TV_SUPPORT_VIDEO_CE_OVERSCAN ? 1 : 0, 
			pDBC->VideoCapability & TV_SUPPORT_VIDEO_CE_UNDERSCAN ? 1 : 0, 
			pDBC->VideoCapability & TV_SUPPORT_VIDEO_IT_OVERSCAN ? 1 : 0, 
			pDBC->VideoCapability & TV_SUPPORT_VIDEO_IT_UNDERSCAN ? 1 : 0, 
			pDBC->VideoCapability & TV_SUPPORT_VIDEO_PT_OVERSCAN ? 1 : 0, 
			pDBC->VideoCapability & TV_SUPPORT_VIDEO_PT_UNDERSCAN ? 1 : 0, 
			pDBC->VideoCapability & TV_SUPPORT_VIDEO_QUANTISATION ? 1 : 0);
	}
	
	if (pDBC->NbShortAudioDescriptors) {
		RMuint32 i, b;
		RMbool f;
		
		fprintf(stderr, "Number of audio descriptors: %d\n", pDBC->NbShortAudioDescriptors);
		for (i = 0; i < pDBC->NbShortAudioDescriptors; i++) {
			fprintf(stderr, "%2lu: Format #%u %s, up to %u channels, fs:", 
				i + 1, pDBC->ShortAudioDescriptors[i].AudioFormatCode, 
				(pDBC->ShortAudioDescriptors[i].AudioFormatCode == DH_AudioCodingType_PCM) ? "Linear PCM" : 
				(pDBC->ShortAudioDescriptors[i].AudioFormatCode == DH_AudioCodingType_AC3) ? "AC3 (Dolby Digital)" : 
				(pDBC->ShortAudioDescriptors[i].AudioFormatCode == DH_AudioCodingType_MPEG1_12) ? "MPEG1(I/II)" : 
				(pDBC->ShortAudioDescriptors[i].AudioFormatCode == DH_AudioCodingType_MPEG1_3) ? "MPEG1(III)" : 
				(pDBC->ShortAudioDescriptors[i].AudioFormatCode == DH_AudioCodingType_MPEG2) ? "MPEG2" : 
				(pDBC->ShortAudioDescriptors[i].AudioFormatCode == DH_AudioCodingType_AAC) ? "AAC" : 
				(pDBC->ShortAudioDescriptors[i].AudioFormatCode == DH_AudioCodingType_DTS) ? "DTS" : 
				(pDBC->ShortAudioDescriptors[i].AudioFormatCode == DH_AudioCodingType_ATRAC) ? "ATRAC" : 
				(pDBC->ShortAudioDescriptors[i].AudioFormatCode == DH_AudioCodingType_OneBit) ? "One Bit Audio" : 
				(pDBC->ShortAudioDescriptors[i].AudioFormatCode == DH_AudioCodingType_DDPlus) ? "Dolby Digital +" : 
				(pDBC->ShortAudioDescriptors[i].AudioFormatCode == DH_AudioCodingType_DTSHD) ? "DTS-HD" : 
				(pDBC->ShortAudioDescriptors[i].AudioFormatCode == DH_AudioCodingType_MLP) ? "MAT (MLP)" : 
				(pDBC->ShortAudioDescriptors[i].AudioFormatCode == DH_AudioCodingType_DST) ? "DST" : 
				(pDBC->ShortAudioDescriptors[i].AudioFormatCode == DH_AudioCodingType_WMAPro) ? "WMA Pro" : 
				"reserved", 
				pDBC->ShortAudioDescriptors[i].MaxNumberOfChannels);
			f = FALSE;
			for (b = 0; b < 7; b++) {
				if (pDBC->ShortAudioDescriptors[i].FrequencyMask & (1 << b)) {
					if (f) fprintf(stderr, "/");
					f = TRUE;
					fprintf(stderr, "%s", 
						(b == 0) ? "32" : 
						(b == 1) ? "44.1" : 
						(b == 2) ? "48" : 
						(b == 3) ? "88.2" : 
						(b == 4) ? "96" : 
						(b == 5) ? "176.4" : 
						"192");
				}
			}
			fprintf(stderr, " kHz");
			if (pDBC->ShortAudioDescriptors[i].AudioFormatCode == DH_AudioCodingType_PCM) {
				fprintf(stderr, ", ");
				f = FALSE;
				for (b = 0; b < 3; b++) {
					if (pDBC->ShortAudioDescriptors[i].u.BitMask & (1 << b)) {
						if (f) fprintf(stderr, "/");
						f = TRUE;
						fprintf(stderr, "%u", (b == 0) ? 16 : (b == 1) ? 20 : 24);
					}
				}
				fprintf(stderr, " bit\n");
			} else if ((pDBC->ShortAudioDescriptors[i].AudioFormatCode >= DH_AudioCodingType_AC3) && (pDBC->ShortAudioDescriptors[i].AudioFormatCode <= DH_AudioCodingType_ATRAC)) {
				fprintf(stderr, ", up to %lu kBit/Sec.\n", pDBC->ShortAudioDescriptors[i].u.MaximumBitrate / 1000);
			} else if (pDBC->ShortAudioDescriptors[i].AudioFormatCode == DH_AudioCodingType_DTSHD) {
				fprintf(stderr, "%s\n", (pDBC->ShortAudioDescriptors[i].u.Option & 0x01) ? ", with MasterAudio" : "");
			} else {
				fprintf(stderr, "\n");
			}
		}
	}
	if (pDBC->NbShortVideoDescriptors) {
		RMuint32 i;
		
		fprintf(stderr, "Number of short video descriptors: %d\n", pDBC->NbShortVideoDescriptors);
		for (i = 0; i < pDBC->NbShortVideoDescriptors; i++) {
			RMuint32 n = pDBC->ShortVideoDescriptors[i] & 0x7F;
			if (n >= NB_SHORT_VIDEO_DESCRIPTORS) n = 0;
			fprintf(stderr, "%2lu: VIC %2u - %s%s\n", 
				i + 1, 
				pDBC->ShortVideoDescriptors[i] & 0x7F, 
				CEA861_ShortDescriptorVideoResolutions[n], 
				(pDBC->ShortVideoDescriptors[i] & 0x80) ? " - Native" : "");
		}
	}
}

static void display_detailed_timing_descriptor(RMuint8 edid_block_index, struct CEADetailedTimingDescriptor *pDTD)
{
	RMuint32 TotalPixelPerLine = pDTD->NbHorizActivePixels + pDTD->NbHorizBlankingPixels;
	RMuint32 TotalNumberOfLines = pDTD->NbVertActiveLines + pDTD->NbVertBlankingLines;
	RMuint32 FieldRate100 = (RMuint32)((RMuint64)pDTD->PixelClock * 100 / TotalPixelPerLine);
	
	if (pDTD->Interlaced) FieldRate100 = FieldRate100 * 2 / (TotalNumberOfLines * 2 + 1);
	else FieldRate100 /= TotalNumberOfLines;
	
	fprintf(stderr, "\n");
	fprintf(stderr, "******************************************\n");
	fprintf(stderr, "Detailed timing / Descriptor block %d", edid_block_index);
	if (edid_block_index == 1) {
		fprintf(stderr, " (Preferred)\n");
	} else {
		fprintf(stderr, "\n");
	}
	fprintf(stderr, "Resolution: %dx%d%c (%d.%02dHz)\n", 
		(int) pDTD->NbHorizActivePixels, 
		(int) pDTD->NbVertActiveLines * (pDTD->Interlaced ? 2 : 1),
		pDTD->Interlaced ? 'i' : 'p', (int) FieldRate100 / 100, (int) FieldRate100 % 100);
	fprintf(stderr, "******************************************\n");
	fprintf(stderr, "Pixel Clock: %d.%03dMhz\n", (int) pDTD->PixelClock / 1000000, (int) (pDTD->PixelClock % 1000000) / 1000);
	fprintf(stderr, "Image size: Hor %d mm x Vert %d mm\n", pDTD->HorizImageSize_mm, pDTD->VertImageSize_mm);
	fprintf(stderr, "Horizontal: Border: %d pixels, Sync Offset: %d pixels, Sync Pulse Width: %d pixels (Total Blanking = %d)\n",
		pDTD->HorizBorder, pDTD->HorizSyncOffset, pDTD->HorizSyncPulseWidth, pDTD->NbHorizBlankingPixels);
	fprintf(stderr, "Vertical: Border: %d lines, Sync Offset: %d lines, Sync Pulse Width: %d lines (Total Blanking = %d)\n",
		pDTD->VertBorder, pDTD->VertSyncOffset, pDTD->VertSyncPulseWidth, pDTD->NbVertBlankingLines);
}

static void display_monitor_descriptor(RMuint8 edid_block_index, RMuint8 *edid)
{
	RMuint32 i;
	RMascii name[14];
	
	fprintf(stderr, "\n");
	fprintf(stderr, "******************************************\n");
	fprintf(stderr, "Detailed timing / Descriptor block %d\n", edid_block_index);
	if (edid[0] || edid[1] || edid[2]) {
		fprintf(stderr, "Invalid monitor descriptor!\n");
		return;
	}
	if (edid[3] == 0xFC) {  // Monitor Name
		strncpy(name, (RMascii *)&(edid[5]), 13);
		name[13] = '\0';
		for (i = 0; i < 13; i++) {
			if (name[i] == '\012') name[i] = '\0';
		}
		fprintf(stderr, "Monitor Name - Flag: 0x%02X, Name: \"%s\"\n", 
			edid[4], name);
	} else if (edid[3] == 0xFD) {  // Monitor Range Limits
		fprintf(stderr, "Monitor Range Limits - Flag: 0x%02X, Vert. %u-%u Hz, Hor. %u-%u kHz, PixClk up to %u0 MHz\n", 
			edid[4], edid[5], edid[6], edid[7], edid[8], edid[9]);
	}
	fprintf(stderr, "******************************************\n");
}

RMstatus apply_genlock(struct RUA *pRUA, struct display_cmdline *disp_opt)
{
	RMstatus err;
	RMuint32 output, sync_master;
	struct EMhwlibOutputGenlock genlock;
	
	if (disp_opt->genlock_input) {
		genlock.InputID = disp_opt->genlock_input;
		genlock.PhaseMin = disp_opt->genlock_min & 0xFF;
		genlock.PhaseMax = disp_opt->genlock_max & 0xFF;
		
		output = EMHWLIB_MODULE(DispDigitalOut, 0);
		err = RUAGetProperty(pRUA, output, RMGenericPropertyID_SyncSourceModuleID, &sync_master, sizeof(sync_master));
		if (RMSUCCEEDED(err) && (output == sync_master)) {
			if (! manutest) fprintf(stderr, "Enabling Genlock on DispDigitalOut, Sync from %s, Frame Phase Range: 0x%02X..0x%02X\n", 
				(genlock.InputID == DispVideoInput) ? "DispVideoInput" : "DispGraphicInput", 
				genlock.PhaseMin, genlock.PhaseMax);
			DCCSPERR(pRUA, output, RMGenericPropertyID_Genlock, &genlock, sizeof(genlock), "Cannot set genlock on output");
			DCCSPERR(pRUA, output, RMGenericPropertyID_Validate, NULL, 0, "Can not Validate output");
		}
		
		output = EMHWLIB_MODULE(DispMainAnalogOut, 0);
		err = RUAGetProperty(pRUA, output, RMGenericPropertyID_SyncSourceModuleID, &sync_master, sizeof(sync_master));
		if (RMSUCCEEDED(err) && (output == sync_master)) {
			if (! manutest) fprintf(stderr, "Enabling Genlock on DispMainAnalogOut, Sync from %s, Frame Phase Range: 0x%02X..0x%02X\n", 
				(genlock.InputID == DispVideoInput) ? "DispVideoInput" : "DispGraphicInput", 
				genlock.PhaseMin, genlock.PhaseMax);
			DCCSPERR(pRUA, output, RMGenericPropertyID_Genlock, &genlock, sizeof(genlock), "Cannot set genlock on output");
			DCCSPERR(pRUA, output, RMGenericPropertyID_Validate, NULL, 0, "Can not Validate output");
		}
		
#ifdef RMFEATURE_HAS_COMPONENT_OUT
		output = EMHWLIB_MODULE(DispComponentOut, 0);
		err = RUAGetProperty(pRUA, output, RMGenericPropertyID_SyncSourceModuleID, &sync_master, sizeof(sync_master));
		if (RMSUCCEEDED(err) && (output == sync_master)) {
			if (! manutest) fprintf(stderr, "Enabling Genlock on DispComponentOut, Sync from %s, Frame Phase Range: 0x%02X..0x%02X\n", 
				(genlock.InputID == DispVideoInput) ? "DispVideoInput" : "DispGraphicInput", 
				genlock.PhaseMin, genlock.PhaseMax);
			DCCSPERR(pRUA, output, RMGenericPropertyID_Genlock, &genlock, sizeof(genlock), "Cannot set genlock on output");
			DCCSPERR(pRUA, output, RMGenericPropertyID_Validate, NULL, 0, "Can not Validate output");
		}
#endif
		
#ifdef RMFEATURE_HAS_COMPOSITE_OUT
		output = EMHWLIB_MODULE(DispCompositeOut, 0);
		err = RUAGetProperty(pRUA, output, RMGenericPropertyID_SyncSourceModuleID, &sync_master, sizeof(sync_master));
		if (RMSUCCEEDED(err) && (output == sync_master)) {
			if (! manutest) fprintf(stderr, "Enabling Genlock on DispCompositeOut, Sync from %s, Frame Phase Range: 0x%02X..0x%02X\n", 
				(genlock.InputID == DispVideoInput) ? "DispVideoInput" : "DispGraphicInput", 
				genlock.PhaseMin, genlock.PhaseMax);
			DCCSPERR(pRUA, output, RMGenericPropertyID_Genlock, &genlock, sizeof(genlock), "Cannot set genlock on output");
			DCCSPERR(pRUA, output, RMGenericPropertyID_Validate, NULL, 0, "Can not Validate output");
		}
#endif
	} else {
		// disable Genlock on all outputs
		genlock.InputID = 0;
		genlock.PhaseMin = 0;
		genlock.PhaseMax = 0;
		
		output = EMHWLIB_MODULE(DispDigitalOut, 0);
		DCCSPERR(pRUA, output, RMGenericPropertyID_Genlock, &genlock, sizeof(genlock), "Cannot set genlock on output");
		DCCSPERR(pRUA, output, RMGenericPropertyID_Validate, NULL, 0, "Can not Validate output");
		
		output = EMHWLIB_MODULE(DispMainAnalogOut, 0);
		DCCSPERR(pRUA, output, RMGenericPropertyID_Genlock, &genlock, sizeof(genlock), "Cannot set genlock on output");
		DCCSPERR(pRUA, output, RMGenericPropertyID_Validate, NULL, 0, "Can not Validate output");
		
#ifdef RMFEATURE_HAS_COMPONENT_OUT
		output = EMHWLIB_MODULE(DispComponentOut, 0);
		DCCSPERR(pRUA, output, RMGenericPropertyID_Genlock, &genlock, sizeof(genlock), "Cannot set genlock on output");
		DCCSPERR(pRUA, output, RMGenericPropertyID_Validate, NULL, 0, "Can not Validate output");
#endif
		
#ifdef RMFEATURE_HAS_COMPOSITE_OUT
		output = EMHWLIB_MODULE(DispCompositeOut, 0);
		DCCSPERR(pRUA, output, RMGenericPropertyID_Genlock, &genlock, sizeof(genlock), "Cannot set genlock on output");
		DCCSPERR(pRUA, output, RMGenericPropertyID_Validate, NULL, 0, "Can not Validate output");
#endif
	}
	
	return RM_OK;
}

RMstatus setup_dummy_capture(
	struct RUA *pRUA, 
	struct DCC *pDCC, 
	struct display_cmdline *disp_opt, 
	RMuint32 TimerNumber)
{
	RMstatus err;
	struct DCCCaptureProfile cp;
	RMuint32 x_size, y_size;
	enum EMhwlibColorSpace InputColorSpace;
	enum EMhwlibInputColorFormat InputColorFormat;
	RMbool use_gpio = FALSE;
	RMbool inv_fid = FALSE;
	
	InputColorSpace = (disp_opt->input == DispVideoInput) ? EMhwlibColorSpace_YUV_601 : EMhwlibColorSpace_RGB_0_255;
	
	if (disp_opt->input_mode != EMhwlibTVStandard_Custom) {
		struct EMhwlibTVFormatDigital format;
		
		err = RUAExchangeProperty(pRUA, DisplayBlock, 
			RMDisplayBlockPropertyID_TVFormatDigital, 
			&(disp_opt->input_mode), sizeof(disp_opt->input_mode), 
			&format, sizeof(format));
		if (RMFAILED(err)) {
			if (! manutest) fprintf(stderr, "Could not find video format #%u: %s\n", disp_opt->input_mode, RMstatusToString(err));
			return err;
		} else {
			disp_opt->input_interlaced = format.TopFieldHeight ? TRUE : FALSE;
			x_size = format.ActiveWidth;
			y_size = format.ActiveHeight;
			if (disp_opt->input_interlaced) {
				y_size += format.ActiveHeight - format.YOffsetBottom + format.YOffsetTop;
			}
		}
	}
	
	cp.SamplingMode = EMhwlibSamplingMode_422;
	cp.ColorMode = EMhwlibColorMode_VideoInterleaved;
	cp.Width = 1;
	cp.Height = 1;
	cp.OrigWidth = 1;
	cp.OrigHeight = 1;
	cp.Interlaced = disp_opt->input_interlaced;
	cp.ColorSpace = InputColorSpace;
	cp.DeInt = FALSE;
	cp.UseV2Pads = disp_opt->input_usev2;
	
	if (disp_opt->input_bussize <= 16) {
		cp.ColorFormat = EMhwlibColorFormat_16BPP_565;
		InputColorFormat = EMhwlibInputColorFormat_16BPP_565;
	} else {
		cp.ColorFormat = EMhwlibColorFormat_24BPP;
		InputColorFormat = EMhwlibInputColorFormat_24BPP;
	}
	
	cp.PixelAspectRatio.X = 1;
	cp.PixelAspectRatio.Y = 1;
	cp.PictureAspectRatio.X = 4;
	cp.PictureAspectRatio.Y = 3;
	
	// open (and potentially create) video source
	if (EMHWLIB_MODULE_CATEGORY(disp_opt->input) == DispVideoInput) {
		err = DCCOpenVideoInputSource(pDCC, &cp, TimerNumber, 0, &(disp_opt->input_videosource));
	} else if (EMHWLIB_MODULE_CATEGORY(disp_opt->input) == DispGraphicInput) {
		err = DCCOpenGraphicInputSource(pDCC, &cp, TimerNumber, 0, &(disp_opt->input_videosource));
	} else {
		err = RM_ERROR;
	}
	if (RMFAILED(err)) {
		if (! manutest) fprintf(stderr, "Could not open video source: %s\n", RMstatusToString(err));
		return err;
	}
	
	// set up input
	if (disp_opt->input == DispGraphicInput) {
		err = DCCSetupGraphicInput(pDCC, 
			disp_opt->input_mode, 
			disp_opt->input_timingsignal, 
			disp_opt->input_vvld, 
			disp_opt->input_bussize, 
			0, 0, 0, 0, 
			FALSE, FALSE, FALSE, 
			InputColorFormat, 
			InputColorSpace, 
			disp_opt->input_invv, 
			disp_opt->input_invh, 
			inv_fid, use_gpio);
		if (RMFAILED(err)) {
			if (! manutest) fprintf(stderr, "Error setting graphic input: %s\n", RMstatusToString(err));
			return err;
		}
	} else {
		if (disp_opt->input_bussize > 16) {
			if (! manutest) fprintf(stderr, "video input can't capture 24 or 32 bit video!\n");
			return RM_ERROR;
		}
		err = DCCSetupVideoInput(pDCC, 
			disp_opt->input_mode, 
			disp_opt->input_timingsignal, 
			disp_opt->input_vvld, 
			disp_opt->input_bussize, 
			0, 0, 0, 0, 
			disp_opt->input_invv, 
			disp_opt->input_invh, 
			inv_fid, use_gpio);
		if (RMFAILED(err)) {
			if (! manutest) fprintf(stderr, "Error setting video input: %s\n", RMstatusToString(err));
			return err;
		}
	}
	
	// disable ANC type vbi capture
	err = DCCSetupVBICaptureANC(pDCC, disp_opt->input, 
		FALSE, 0, 0, 0, 0, 0, 0);
	if (RMFAILED(err)) return err;
	
	// disable Raw type vbi capture
	err = DCCSetupVBICaptureRaw(pDCC, disp_opt->input, 
		0, 0, 0, 0, 0, 0);
	if (RMFAILED(err)) return err;
	
	// disable 601 type vbi capture
	err = DCCSetupVBICapture(pDCC, disp_opt->input, 
		0, 0, 0, 0, 0, 0);
	if (RMFAILED(err)) return err;
	
	return RM_OK;
}

RMstatus close_dummy_capture(
	struct display_cmdline *disp_opt)
{
	RMstatus err = RM_OK;
	
	// close input and remove old surface
	if (disp_opt->input_videosource) {
		//if (! manutest) fprintf(stderr, "Closing VideoSource\n");
		err = DCCCloseVideoSource(disp_opt->input_videosource);
		disp_opt->input_videosource = NULL;
		if (RMFAILED(err)) {
			if (! manutest) fprintf(stderr, "Could not clean surface: %s\n", RMstatusToString(err));
		}
	}
	
	return err;
}





RMstatus apply_osd_pictureX(struct dcc_context *dcc_info, 
			    struct osd_picture_info *osd, 	
			    struct DCCOSDProfile *osd_profile, 
			    struct DCCVideoSource **osd_source,
			    struct display_cmdline *options)
{
	RMuint32 *pLut;
	struct DisplayBlock_SetPaletteOnPicture_type palette_info;

	enum EMhwlibColorMode color_mode;
	struct RMBitmapFileOptions bitmap_opts;
	struct RMBitmapFileInfo color_bfi;
	enum EMhwlibMixerSourceState state;
	struct DCCOSDProfile bitmap_profile;

	RMuint32 osd_scaler = 0, osd_mixer = 0,  lutAddr, src_index, mixer_src;
	RMbool enable, force_rgb = FALSE;
	RMuint8 *pLuma = NULL, *pChroma = NULL, *pAlpha = NULL;
	RMuint32 LumaAddr, LumaSize, ChromaAddr, ChromaSize, picture;
	RMstatus err;
	RMuint32 i = 0;
	RMuint32 dram_bpp = 32;
	RMbool use_pic_fifo = TRUE;
	
	if(options){
		if(options->dump_osd_dir){
			use_pic_fifo = FALSE;
		}
	}


	pLut = (palette_info.Palette);

	switch (osd->route) {
	case DCCRoute_Main:
		osd_mixer = EMHWLIB_MODULE(DispMainMixer, 0);
		break;
	case DCCRoute_Secondary:
#ifdef RMFEATURE_HAS_VCR_MIXER
		osd_mixer = EMHWLIB_MODULE(DispVCRMixer, 0);
#else
#ifndef RMFEATURE_HAS_VCR_CHANNEL
		return RM_ERROR;
#endif
#endif
		break;
	case DCCRoute_ColorBars:
	case DCCRoute_HDSD:
		return RM_ERROR;
	}


	err = DCCGetScalerModuleID(dcc_info->pDCC, osd->route, DCCSurface_OSD, osd->scaler, &(osd_scaler));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get surface to display OSD source %d\n", err));
		return RM_ERROR;
	}
	if (osd_mixer) {
		err = RUAExchangeProperty(dcc_info->pRUA, osd_mixer, RMGenericPropertyID_MixerSourceIndex, &osd_scaler, sizeof(osd_scaler), &src_index, sizeof(src_index));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot get scaler index\n"));
			return err;
		}
		mixer_src = EMHWLIB_TARGET_MODULE(osd_mixer, 0, src_index);
		state = EMhwlibMixerSourceState_Master;
		DCCSPERR(dcc_info->pRUA, mixer_src, RMGenericPropertyID_MixerSourceState, &state, sizeof(state), "Cannot set scaler's state on mixer");
		DCCSPERR(dcc_info->pRUA, mixer_src, RMGenericPropertyID_MixerSourceWindow, &(osd->output_window), sizeof(osd->output_window), "Cannot set scaler input window");
		DCCSPERR(dcc_info->pRUA, mixer_src, RMGenericPropertyID_LockMixerSourceScalingMode, &(osd->lock_scaler), sizeof(osd->lock_scaler), "Cannot set lock scaler");
		DCCSPERR(dcc_info->pRUA, mixer_src, RMGenericPropertyID_Validate, NULL, 0, "Can not validate mixer");
	}
	
		
	enable = FALSE;
	err =  RUASetProperty(dcc_info->pRUA, osd_scaler, RMGenericPropertyID_Enable, &enable, sizeof(enable), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot enable scaler\n"));
		return err;
	}
		
	/* check if the scaler supports YUV, if not, force rgb buffer */
	color_mode = EMhwlibColorMode_VideoNonInterleaved;
	err = RUASetProperty(dcc_info->pRUA, osd_scaler, RMGenericPropertyID_IsColorModeSupported, &(color_mode), sizeof(color_mode), 0);
	if(RMFAILED(err)){
		force_rgb = TRUE;
	}

		
	bitmap_opts.alpha = osd->alpha;
	bitmap_opts.force_rgb = force_rgb;
	bitmap_opts.orientation = osd->orientation;

	err = RMOpenBitmapFile(osd->filename, &color_bfi, &bitmap_opts, &bitmap_profile);
	if (RMFAILED(err)) {
		if (! manutest) fprintf(stderr, "Cannot open bitmap %s : %d\n", osd->filename, err);
		return RM_ERROR;
	}
	
	if (osd->color_space != EMhwlibColorSpace_None) {
		bitmap_profile.ColorSpace = osd->color_space;
	}

	switch (bitmap_profile.ColorMode) {
	case EMhwlibColorMode_LUT_1BPP:
		dram_bpp = 1;
		break;
	case EMhwlibColorMode_LUT_2BPP:
		dram_bpp = 2;
		break;
	case EMhwlibColorMode_LUT_4BPP:
		dram_bpp = 4;
		break;
	case EMhwlibColorMode_LUT_8BPP:
		dram_bpp = 8;
		break;
	case EMhwlibColorMode_TrueColor:
	case EMhwlibColorMode_TrueColorWithKey:
		switch (bitmap_profile.ColorFormat) {
		case EMhwlibColorFormat_24BPP_565:
		case EMhwlibColorFormat_24BPP:
		case EMhwlibColorFormat_32BPP_4444:
		case EMhwlibColorFormat_32BPP:
			dram_bpp = 32;
			break;
		case EMhwlibColorFormat_16BPP_565:
		case EMhwlibColorFormat_16BPP_1555:
		case EMhwlibColorFormat_16BPP_4444:
			dram_bpp = 16;
			break;
		}
		break;
	case EMhwlibColorMode_VideoInterleaved:
	case EMhwlibColorMode_16BPP_Alpha_LUT:
		dram_bpp = 16;
		break; 		
	case EMhwlibColorMode_VideoNonInterleaved:
		dram_bpp = 8;
		break; 		
	}

	if(((dram_bpp * bitmap_profile.Width) / 8) > 8191){
		if (! manutest) {
			fprintf(stderr, "Cannot display picture: too wide.\nMaximum widths are:\n");
			fprintf(stderr, "\t32bpp: 2047\n");
			fprintf(stderr, "\t16bpp (interleaved): 4095\n");
			fprintf(stderr, "\t16bpp (luma/chroma split): 8191\n");
			fprintf(stderr, "\t8bpp, 4bpp, 1bpp: 8191\n");
		}
		RMCloseBitmapFile(&color_bfi);
		return RM_ERROR;
	}

			
	if((osd->alpha_merge) && (osd->alpha_filename != NULL)){
		struct RMBitmapFileInfo alpha_bfi;
		struct DCCOSDProfile alpha_profile;

		/* see if the current mode supports alpha merge */
		switch(bitmap_profile.ColorMode){
		case EMhwlibColorMode_LUT_8BPP:
			/* only if the scaler supports EMhwlibColorMode_16BPP_Alpha_LUT */
			bitmap_profile.ColorMode = EMhwlibColorMode_16BPP_Alpha_LUT;
			err = RUASetProperty(dcc_info->pRUA, osd_scaler, RMGenericPropertyID_IsColorModeSupported, &(bitmap_profile.ColorMode), sizeof(bitmap_profile.ColorMode), 0);
			if(RMFAILED(err)){
				if (! manutest) fprintf(stderr, "Can't merge alpha on this type of bitmap\n");
				return RM_ERROR;
			}
		
			break;
		case EMhwlibColorMode_TrueColor:
		case EMhwlibColorMode_TrueColorWithKey:
			/* only if for 4-bytes modes */
			if((bitmap_profile.ColorFormat != EMhwlibColorFormat_32BPP) &&
			   (bitmap_profile.ColorFormat != EMhwlibColorFormat_24BPP)){
				if (! manutest) fprintf(stderr, "Can't merge alpha on this type of bitmap\n");
				return RM_ERROR;
			}
	
			break;
		case EMhwlibColorMode_16BPP_Alpha_LUT:
			/* impossible */
		case EMhwlibColorMode_VideoInterleaved:
		case EMhwlibColorMode_VideoNonInterleaved:
		case EMhwlibColorMode_LUT_1BPP:
		case EMhwlibColorMode_LUT_2BPP:
		case EMhwlibColorMode_LUT_4BPP:
			if (! manutest) fprintf(stderr, "Can't merge alpha on this type of bitmap\n");
			return RM_ERROR;
		}
		err = RMOpenBitmapFile(osd->alpha_filename, &alpha_bfi, &bitmap_opts, &alpha_profile);
		if (RMFAILED(err)) {
			if (! manutest) fprintf(stderr, "Cannot open bitmap %s : %d\n", osd->alpha_filename, err);
			return RM_ERROR;
		}
		if(alpha_profile.ColorMode != EMhwlibColorMode_LUT_8BPP){
			if (! manutest) fprintf(stderr, "Can't merge alpha on this type of bitmap\n");
			return RM_ERROR;
		}
		if((alpha_profile.Width != bitmap_profile.Width ) ||
		   (alpha_profile.Height != bitmap_profile.Height )){
			if (! manutest) fprintf(stderr, "Can't merge alpha on this type of bitmap\n");
			return RM_ERROR;
		}

		pAlpha = RMMalloc(alpha_profile.Width * alpha_profile.Height);
		RMBitmapToRaw(pAlpha, NULL, &alpha_bfi);
		RMCloseBitmapFile(&alpha_bfi);
	}


	if(use_pic_fifo){
		err = DCCOpenMultiplePictureOSDVideoSource(dcc_info->pDCC, &bitmap_profile, 1, osd_source, NULL);
		if (RMFAILED(err)) {
			if (! manutest) fprintf(stderr, "Cannot open OSD decoder %d\n", err);
			return RM_ERROR;
		}
		err = DCCInsertPictureInMultiplePictureOSDVideoSource(*osd_source, 0, 0);
		if (RMFAILED(err)) {
			if (! manutest) fprintf(stderr, "Cannot insert picture inside surface %d\n", err);
			return RM_ERROR;
		}
	}
	else{
		err = DCCOpenOSDVideoSource(dcc_info->pDCC, &bitmap_profile, osd_source);
		if (RMFAILED(err)) {
			if (! manutest) fprintf(stderr, "Cannot get osd buffer info %d\n", err);
			return RM_ERROR;
		}

	}
	err = DCCGetOSDPictureInfo(*osd_source, 0, &(picture), &LumaAddr, &LumaSize, &ChromaAddr, &ChromaSize);
	if (RMFAILED(err)) {
		if (! manutest) fprintf(stderr, "Cannot get osd buffer info %d\n", err);
		return RM_ERROR;
	}



#if (EM86XX_MODE == EM86XX_MODEID_WITHHOST)

	/* on withost mode decode into a host buffer, since we cannot lock/map more than 4MB of pci address space */

	pLuma = RMMalloc(LumaSize);
	if (pLuma == NULL) {
		RMDBGLOG((ENABLE, "Error allocating OSD buffer at 0x%08lX (0x%08lX bytes)\n", LumaSize));
		return RM_ERROR;
	}
	if(ChromaSize){
		pChroma = RMMalloc(ChromaSize);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error allocating OSD buffer at 0x%08lX (0x%08lX bytes)\n", ChromaSize));
			return err;
		}
	}

#else /* standalone */
	
	err = RUALock(dcc_info->pRUA, LumaAddr, LumaSize);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error locking OSD buffer at 0x%08lX (0x%08lX bytes)\n", LumaAddr, LumaSize));
		return err;
	}
	pLuma = RUAMap(dcc_info->pRUA, LumaAddr, LumaSize);
	if (pLuma == NULL) {
		RMDBGLOG((ENABLE, "Error mapping OSD buffer at 0x%08lX (0x%08lX bytes)\n", LumaAddr, LumaSize));
		return RM_ERROR;
	}
	if(ChromaSize){
		err = RUALock(dcc_info->pRUA, ChromaAddr, ChromaSize);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error locking OSD buffer at 0x%08lX (0x%08lX bytes)\n", ChromaAddr, ChromaSize));
			return err;
		}
		pChroma = RUAMap(dcc_info->pRUA, ChromaAddr, ChromaSize);
		if (pChroma == NULL) {
			RMDBGLOG((ENABLE, "Error mapping OSD buffer at 0x%08lX (0x%08lX bytes)\n", ChromaAddr, ChromaSize));
			return RM_ERROR;
		}
	}
#endif /* standalone / withhost */

	RMBitmapToRaw(pLuma, pChroma, &color_bfi);

	if(pAlpha != NULL){ 
		/* do the merge */
		if(bitmap_profile.ColorMode == EMhwlibColorMode_16BPP_Alpha_LUT){
			i = (bitmap_profile.Width * bitmap_profile.Height);
			while(i){
				i--;
				pLuma[2*i]   = pLuma[i];
				pLuma[2*i+1] = pAlpha[i];
			}
		}
		else if (bitmap_profile.ColorMode == EMhwlibColorMode_TrueColor){
			/* todo : use the gfx engine to do this */
			i = 0;
			while(i < bitmap_profile.Width * bitmap_profile.Height){
				pLuma[4*i+3] = pAlpha[i];
				i++;
			}
		}
		RMFree(pAlpha);
	}

	


	RMBitmapGetPalette(pLut, &color_bfi);
	/* RMOpenBitmapFile might give a bigger image size because the decoder needs it */
	/* this function sets the source_window to area that needs to be displayed */
	if(!osd->zoom)
		RMBitmapSetSourceWindow(&(osd->source_window), &color_bfi);


#if (EM86XX_MODE == EM86XX_MODEID_WITHHOST)


	for(i = 0; i < 2; i++){
		RMuint32 remaining_bytes = 0;
		RMuint8 *map_addr, *user_addr = NULL;
		RMuint32 rua_addr = 0;
			
		switch(i){
		case 0:
			remaining_bytes = LumaSize;
			user_addr = pLuma;
			rua_addr = LumaAddr;
			break;
		case 1:
			remaining_bytes = ChromaSize;
			user_addr = pChroma;
			rua_addr = ChromaAddr;
			break;
		}
		while (remaining_bytes) {
		
			RMuint32 chunk = RMmin(remaining_bytes, 0x100000);
		
			err = RUALock(dcc_info->pRUA, rua_addr, chunk);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error locking OSD buffer at 0x%08lX (0x%08lX bytes): %s\n", rua_addr, chunk, RMstatusToString(err)));
				return err;
			}
			map_addr = RUAMap(dcc_info->pRUA, rua_addr, chunk);
			if (map_addr == NULL) {
				RMDBGLOG((ENABLE, "Error mapping OSD buffer at 0x%08lX (0x%08lX bytes)\n", rua_addr, chunk));
				return RM_ERROR;
			}
			RMMemcpy(map_addr, user_addr, chunk);
		
			RUAUnMap(dcc_info->pRUA, map_addr, chunk);

			err = RUAUnLock(dcc_info->pRUA, rua_addr, chunk);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Error unlocking OSD buffer at 0x%08lX (0x%08lX bytes): %s\n", rua_addr, chunk, RMstatusToString(err)));
				return err;
			}
			user_addr += chunk;
			rua_addr += chunk;
			remaining_bytes -= chunk;
		}
	}

	if(pLuma)
		RMFree(pLuma);
	if(pChroma)
		RMFree(pChroma);


#else /* standalone */

	RUAUnMap(dcc_info->pRUA, pLuma, LumaSize);
	err = RUAUnLock(dcc_info->pRUA, LumaAddr, LumaSize);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error unlocking OSD buffer at 0x%08lX (0x%08lX bytes)\n", LumaAddr, LumaSize));
		return err;
	}

	if(ChromaSize){
		RUAUnMap(dcc_info->pRUA, pChroma, ChromaSize);
		err = RUAUnLock(dcc_info->pRUA, ChromaAddr, ChromaSize);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error unlocking OSD buffer at 0x%08lX (0x%08lX bytes)\n", ChromaAddr, ChromaSize));
			return err;
		}
	}

	
#endif /* standalone / withhost */



	RMCloseBitmapFile(&color_bfi);

	/* despite of the value of force_rgb, opening a bmp file always creates a RGB buffer */
	err = RUASetProperty(dcc_info->pRUA, osd_scaler, RMGenericPropertyID_IsColorModeSupported, &(bitmap_profile.ColorMode),sizeof(bitmap_profile.ColorMode) , 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "The scaler you selected does not support colorspace %d\n", bitmap_profile.ColorMode));
		return RM_ERROR;
	}
		 
	/* clear the surface first */
	err = DCCSetSurfaceSource(dcc_info->pDCC, osd_scaler, NULL);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set the surface source: %s\n", RMstatusToString(err)));
		return RM_ERROR;
	}


	/* for video modes, the alpha value information is set on the scaler */
	/* for 16bpp_1555 the alpha value is set on the scaler too */
	if ((bitmap_profile.ColorMode == EMhwlibColorMode_VideoNonInterleaved) ||
	   (bitmap_profile.ColorMode == EMhwlibColorMode_VideoInterleaved) ||
	   (bitmap_profile.ColorFormat == EMhwlibColorFormat_16BPP_1555)){
		DCCSPERR(dcc_info->pRUA, osd_scaler, RMGenericPropertyID_Alpha0, &(osd->alpha), sizeof(osd->alpha), "Cannot set the alpha value on the scaler");
		/* some 16bpp .bmp files may set the alpha bit to 1 */
		if(bitmap_profile.ColorFormat == EMhwlibColorFormat_16BPP_1555){
			DCCSPERR(dcc_info->pRUA, osd_scaler, RMGenericPropertyID_Alpha1, &(osd->alpha), sizeof(osd->alpha), "Cannot set the alpha value on the scaler");
		}
	}
	
	DCCSPERR(dcc_info->pRUA, osd_scaler, RMGenericPropertyID_ScalerInputWindow, &(osd->source_window), sizeof(osd->source_window), "Cannot set scaler input window on OSD surface");
	DCCSPERROK(RM_INVALIDMODE, dcc_info->pRUA, osd_scaler, RMGenericPropertyID_NonLinearScalingMode, &osd->nonlinearmode, sizeof(osd->nonlinearmode), "Error setting current scaler non-linear selection");
	DCCSPERROK(RM_INVALIDMODE, dcc_info->pRUA, osd_scaler, RMGenericPropertyID_BlackStripMode, &osd->blackstrip, sizeof(osd->blackstrip), "Error setting current scaler blackstrip mode");
	DCCSPERROK(RM_INVALIDMODE, dcc_info->pRUA, osd_scaler, RMGenericPropertyID_CutStripMode, &osd->cutstrip, sizeof(osd->cutstrip), "Error setting current scaler cutstrip mode");
	
	err = DCCSetSurfaceSource(dcc_info->pDCC, osd_scaler, *osd_source);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set the surface source: %s\n", RMstatusToString(err)));
		return RM_ERROR;
	}

	err = RUAGetProperty(dcc_info->pRUA, osd_scaler, RMGenericPropertyID_LUTAddress, &lutAddr, sizeof(lutAddr));
	if (err == RM_OK) {
		switch(bitmap_profile.ColorMode){
		case EMhwlibColorMode_LUT_1BPP:
			palette_info.PaletteSize = 2*4;
			break;
		case EMhwlibColorMode_LUT_2BPP:
			palette_info.PaletteSize = 4*4;
			break;
		case EMhwlibColorMode_LUT_4BPP:
			palette_info.PaletteSize = 16*4;
			break;
		case EMhwlibColorMode_LUT_8BPP:
			palette_info.PaletteSize = 256*4;
			break;
		default:
			palette_info.PaletteSize = 0;
			break;
		}
		if(palette_info.PaletteSize){
			palette_info.Picture = picture;
			DCCSPERR(dcc_info->pRUA, DisplayBlock, RMDisplayBlockPropertyID_SetPaletteOnPicture, &palette_info, sizeof(palette_info), "Cannot validate scaler input window");
		}
	}

	DCCSPERR(dcc_info->pRUA, osd_scaler, RMGenericPropertyID_Validate, NULL, 0, "Cannot validate scaler input window");

	enable = TRUE;
	err =  RUASetProperty(dcc_info->pRUA, osd_scaler, RMGenericPropertyID_Enable, &enable, sizeof(enable), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot enable scaler\n"));
		return err;
	}

	
	if(osd_profile != NULL)
		RMMemcpy(osd_profile, &bitmap_profile, sizeof(struct DCCOSDProfile));

	return RM_OK;

}

	
RMstatus apply_osd_picture(struct dcc_context *dcc_info, struct osd_picture_info *osd, 	struct DCCOSDProfile *osd_profile, struct DCCVideoSource **osd_source)
{
	return apply_osd_pictureX(dcc_info, osd, osd_profile, osd_source, NULL);
}

static RMstatus set_up_pads(struct dcc_context *dcc_info, struct display_cmdline *options);

RMstatus dump_dvi_init(struct dcc_context *dcc_info, struct display_cmdline *options)
{
	RMstatus err;
	RMuint32 dvi_size, dvi_init[50];
	
	dvi_size = sizeof(dvi_init) / sizeof(RMuint32);
	err = DHGetChipInit(options->dh_info->pDH, dvi_init, &dvi_size);
	if (RMSUCCEEDED(err) && dvi_size) {
		int fd;
		RMascii filename[2048];
		RMuint32 sum, i;
		RMuint8 out_buf[4];
		RMint32 len;
		
		snprintf(filename, 2048, "%s/%s", options->dump_osd_dir, "dvi.bin"); 
		fd = open(filename, O_CREAT | O_WRONLY | O_TRUNC, S_IRWXU | S_IRWXG | S_IRWXO);
		if (fd == -1) {
			if (! manutest) fprintf(stderr, "Could not open %s\n" , filename);
			return RM_ERROR;
		}
		sum = 0;
		for (i = 0; i < dvi_size; i++) {
			RMuint32ToLeBuf(dvi_init[i], out_buf);
			len = write(fd, out_buf, 4);
			if (len < 4) {
				if (! manutest) fprintf(stderr, "Error while writing dvi init! %ld\n", len);
				return RM_ERROR;
			}
			sum += dvi_init[i];
		}
		sum = ~sum + 1;
		RMuint32ToLeBuf(sum, out_buf);
		len = write(fd, out_buf, 4);
		if (len < 4) {
			if (! manutest) fprintf(stderr, "Error while writing sum of dvi init! %ld\n", len);
			return RM_ERROR;
		}
		close(fd);
	}
	
	return RM_OK;
}


RMstatus apply_hdcp(struct dcc_context *dcc_info, struct display_cmdline *options) 
{
	RMstatus err;
	
	// experimental SRMs
	static RMuint8 SRM0[] = {
		0x80, 0x00, 0x00, 0x02,  // version
		0x00, 0x00, 0x00, 0x31,  // length
		0x01,  // number of keys
		0x86, 0x88, 0x4d, 0x5d, 0x9f,  // key of Sony Wega KV-30HS420
		// invalid DSS signature
		0xe3, 0x17, 0xe6, 0x46, 0x6e, 0xc3, 0xef, 0xbd, 
		0x4c, 0xca, 0x0d, 0x4f, 0x76, 0x2a, 0x15, 0x96, 
		0xce, 0x62, 0x22, 0x2b, 0xe5, 0xc9, 0xa3, 0x72, 
		0xef, 0x26, 0x76, 0xcf, 0x30, 0x50, 0x4e, 0x55, 
		0x59, 0x9e, 0x79, 0xc3, 0x36, 0xe1, 0xaa, 0xfd, 
	};
	static RMuint8 SRM1[] = {
		0x80, 0x00, 0x00, 0x01,  // version
		0x00, 0x00, 0x00, 0x2b,  // length
		// no keys
		// "DCP LLC" production DSS signature
		0xd2, 0x48, 0x9e, 0x49, 0xd0, 0x57, 0xae, 0x31, 
		0x5b, 0x1a, 0xbc, 0xe0, 0x0e, 0x4f, 0x6b, 0x92, 
		0xa6, 0xba, 0x03, 0x3b, 0x98, 0xcc, 0xed, 0x4a, 
		0x97, 0x8f, 0x5d, 0xd2, 0x27, 0x29, 0x25, 0x19, 
		0xa5, 0xd5, 0xf0, 0x5d, 0x5e, 0x56, 0x3d, 0x0e 
	};
	static RMuint8 SRM2[] = {
		0x80, 0x00, 0x00, 0x02,  // version
		0x00, 0x00, 0x00, 0x31,  // length
		0x01,  // number of keys
		0x51, 0x1e, 0xf2, 0x1a, 0xcd,  // key
		// "facsimile" DSS signature
		0xe3, 0x17, 0xe6, 0x46, 0x6e, 0xc3, 0xef, 0xbd, 
		0x4c, 0xca, 0x0d, 0x4f, 0x76, 0x2a, 0x15, 0x96, 
		0xce, 0x62, 0x22, 0x2b, 0xe5, 0xc9, 0xa3, 0x72, 
		0xef, 0x26, 0x76, 0xcf, 0x30, 0x50, 0x4e, 0x55, 
		0x59, 0x9e, 0x79, 0xc3, 0x36, 0xe1, 0xaa, 0xfd, 
	};
	static RMuint8 SRM3[] = {
		0x80, 0x00, 0x00, 0x03,  // version
		0x00, 0x00, 0x00, 0x31,  // length
		0x01,  // number of keys
		0xe7, 0x26, 0x97, 0xf4, 0x01,  // key
		// "facsimile" DSS signature
		0xdd, 0x1f, 0x00, 0x30, 0x37, 0x0d, 0x0b, 0x54, 
		0xff, 0x91, 0x02, 0xbb, 0x07, 0x9e, 0x48, 0x3c, 
		0xfe, 0x58, 0x9b, 0xfc, 0x74, 0x57, 0xb7, 0x25, 
		0x67, 0xdd, 0x72, 0xc2, 0x55, 0xe4, 0x1a, 0xed, 
		0x99, 0x09, 0x47, 0xb8, 0x24, 0x21, 0x85, 0xcc, 
	};
	static RMuint8 SRM4[] = {
		0x80, 0x00, 0x00, 0x04,  // version
		0x00, 0x00, 0x00, 0x36,  // length
		0x02,  // number of keys
		0x51, 0x1e, 0xf2, 0x1a, 0xcd,  // key
		0xe7, 0x26, 0x97, 0xf4, 0x01,  // key
		// "facsimile" DSS signature
		0x7a, 0xdf, 0x4f, 0xd5, 0x66, 0xe0, 0x19, 0xeb, 
		0x4e, 0xd3, 0xe0, 0x1c, 0x1a, 0xb3, 0xc2, 0x8d, 
		0xec, 0x8b, 0xe8, 0x7f, 0x9d, 0xc0, 0x01, 0x2d, 
		0x1b, 0xda, 0xc8, 0x30, 0xd8, 0x30, 0x05, 0xa0, 
		0x66, 0x1d, 0x2d, 0x26, 0x25, 0x0d, 0x20, 0x66, 
	};
	
	if (options->dh_info->pSRM == NULL) {
		// Application needs to provide real SRM from DVD:/HDCP.SRM or BluRay:/HDCP.srm
		if (! manutest) fprintf(stderr, "parse_display_cmdline.c: Application did not specify HDCP SRM, providing empty SRM!\n");
		if (0) options->dh_info->pSRM = SRM0;
		if (1) options->dh_info->pSRM = SRM1;
		if (0) options->dh_info->pSRM = SRM2;
		if (0) options->dh_info->pSRM = SRM3;
		if (0) options->dh_info->pSRM = SRM4;
	}
	
	err = DHSetSRM(options->dh_info->pDH, options->dh_info->pSRM);
	
	if (options->dvi_hdmi_hdcp) {
		err = DHRequestHDCP(options->dh_info->pDH);
		if (RMSUCCEEDED(err)) {
			if (! manutest) fprintf(stderr, "HDCP encrytion requested, OK to play protected content!\n");
			if (options->dh_info->dvi_hdmi_state != DH_enabled_encrypted) {
				options->dh_info->dvi_hdmi_state = DH_enabled_encrypted;
				RMDBGLOG((LOCALDBG, "DCC-HDCP State is now: ENABLED-ENCRYPTED\n"));
			}
		} else {
			if (err == RM_DRM_INVALID_KEY) {
				if (! manutest) fprintf(stderr, "HDCP failed, the display's key has been revoked!\n");
			} else {
				if (! manutest) fprintf(stderr, "HDCP failed, can NOT play protected content!\n");
			}
			if (options->dh_info->dvi_hdmi_state != DH_enabled) {
				options->dh_info->dvi_hdmi_state = DH_enabled;
				RMDBGLOG((LOCALDBG, "DCC-HDCP State is now: ENABLED\n"));
			}
		}
	} else {
		err = DHCancelHDCP(options->dh_info->pDH);
	}
	
	return RM_OK;
}

// let HDMI know about the current digital video mode
// apply double rate and VVLD settings
static RMstatus update_hdmi_videomode(
	struct dcc_context *dcc_info, 
	struct display_cmdline *options, 
	struct EMhwlibTVFormatDigital *pTVFormat)
{
	RMstatus err;
	struct EMhwlibTVFormatDigital format_digital;
	RMbool DoubleRate;
	RMbool EnableVVLDPAD;
	
	if (options->dig_force_doublerate) {
		DoubleRate = options->dig_doublerate;
	} else {
		DoubleRate = DCCGetDoubleRate(options->standard);
	}
	
	RMDBGLOG((ENABLE, "Applying DoubleRate(%s)\n", DoubleRate ? "TRUE" : "FALSE"));
	DCCSPERR(dcc_info->pRUA, DispDigitalOut, RMDispDigitalOutPropertyID_DoubleRate, &DoubleRate, sizeof(DoubleRate), "Can not set DoubleRate");
	DCCSPERR(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_Validate, NULL, 0, "Can not Validate output");
	
	if (options->dig_protocol != EMhwlibDigitalTimingSignal_601) {
		options->hdmi_de = FALSE;
		EnableVVLDPAD = FALSE;
	} else {
		EnableVVLDPAD = TRUE;
	}
	
	DCCSPERR(dcc_info->pRUA, DispDigitalOut, RMDispDigitalOutPropertyID_EnableVVLDPAD, &EnableVVLDPAD, sizeof(EnableVVLDPAD), "Cannot set EnableVVLDPAD on DispDigitalOut output");
	DCCSPERR(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_Validate, NULL, 0, "Can not Validate DispDigitalOut output");
	
	if ((options->dh_info == NULL) || (options->dh_info->pDH == NULL)) return RM_OK;
	
	if (options->standard != EMhwlibTVStandard_Custom) {
		// get generic TVFormat struct for the current TVStandard
		err = RUAExchangeProperty(dcc_info->pRUA, DisplayBlock, 
			RMDisplayBlockPropertyID_TVFormatDigital, 
			&(options->standard), sizeof(options->standard), 
			&format_digital, sizeof(format_digital));
	} else {
		if (pTVFormat != NULL) {
			// use provided TVFormat
			format_digital = *pTVFormat;
		} else {
			// get actual TVFormat from digital output
			err = RUAGetProperty(dcc_info->pRUA, DispDigitalOut, 
				RMGenericPropertyID_DigitalTVFormat, 
				&format_digital, sizeof(format_digital));
		}
	}
	
	if (DoubleRate) format_digital.PixelClock *= 2;
	
	return DHSetDEGeneratorFromTVFormat(options->dh_info->pDH, options->hdmi_de, options->dig_protocol != EMhwlibDigitalTimingSignal_601, options->bus_size == 8, &format_digital);
}

/* Maintain HDCP integrity and check for HDMI monitor plug/unplug */
/* audio_opt may be NULL for video-only apps */
RMstatus update_hdmi(struct dcc_context *dcc_info, struct display_cmdline *disp_opt, struct audio_cmdline *audio_opt)
{
	RMstatus err;
	
	// Check if permission to change the display has been given
	if (! disp_opt || ! disp_opt->dh_info) {
		if (audio_opt && audio_opt->dh_info && audio_opt->dh_info->pDH) {
			// No display, but audio permission is given, check only audio
			return update_hdmi_audio(dcc_info, audio_opt);
		} else {
			return RM_FATALINVALIDPOINTER;
		}
	}
	
	// Perform HotPlug/HDCP checks 
	if (disp_opt->dh_info->pDH != NULL) {
		struct DH_HDMI_state HDMIState;
		HDMIState.ReceiverSignal = FALSE;  // only set to TRUE if Rx signal is supported by hardware
		err = DHCheckHDMI(disp_opt->dh_info->pDH, &HDMIState);
		if (RMSUCCEEDED(err) || (err == RM_DRM_INVALID_KEY)) {
			if (err == RM_DRM_INVALID_KEY) {
				if (! manutest) fprintf(stderr, "\n    #### HDCP #### failed, the display's key has been revoked!\n\n");
			}
			if (HDMIState.HDCPLost) {
				if (! manutest) fprintf(stderr, "\n    #### HDCP #### has been lost, do not play protected content.\n\n");
			}
			if (HDMIState.HDCPState != disp_opt->dh_info->HDMIState.HDCPState) {
				if (HDMIState.HDCPState) {
					if (! manutest) fprintf(stderr, "\n    #### HDCP #### is now on, OK to play protected content.\n\n");
				} else {
					if (! manutest) fprintf(stderr, "\n    #### HDCP #### is now off, do not play protected content.\n\n");
				}
			}
			if (disp_opt->configure_outports && 
				(HDMIState.HotPlugChanged || HDMIState.ReceiverChanged || disp_opt->dh_first_run) && // HPD or Rx has changed
				(HDMIState.HotPlugState && (HDMIState.ReceiverSignal == HDMIState.ReceiverState)) // both HPD and Rx are on, or just HPD, if Rx is not supported
			) {
				if (! manutest) fprintf(stderr, "\n"
					"  HH  HH  HHHHH   HH   HH  HHHH      HHHH   HH   HH\n"
					"  HH  HH  HH  HH  HHH HHH   HH      HH  HH  HHH  HH\n"
					"  HHHHHH  HH  HH  HH H HH   HH      HH  HH  HH H HH\n"
					"  HH  HH  HH  HH  HH   HH   HH      HH  HH  HH  HHH\n"
					"  HH  HH  HHHHH   HH   HH  HHHH      HHHH   HH   HH\n"
					"\n");
				set_videomode_from_EDID(dcc_info, disp_opt);
				if (disp_opt->hdmi_monitor) {
					if (! manutest) fprintf(stderr, "Monitor is HDMI\n");
					if (audio_opt) apply_dvi_hdmi_audio_options(dcc_info, audio_opt, 0, FALSE, FALSE, FALSE);
				} else {
					if (! manutest) fprintf(stderr, "Monitor is DVI / VGA\n");
				}
				if (! disp_opt->dh_first_run) {
					update_output_afd_settings(dcc_info, disp_opt, NULL);
				}
				disp_opt->dh_first_run = FALSE;
			} else 
			// Display has been switched off or has been disconnected
			if (disp_opt->configure_outports && (
				((HDMIState.HotPlugChanged || disp_opt->dh_first_run) && ! HDMIState.HotPlugState) || 
				(HDMIState.ReceiverSignal && (HDMIState.ReceiverChanged || disp_opt->dh_first_run) && ! HDMIState.ReceiverState)
			)) {
				// turn off HDMI, leave analog on
				if (! manutest) fprintf(stderr, "\n"
					"  HH  HH  HHHHH   HH   HH  HHHH      HHHH   HHHHHH  HHHHHH\n"
					"  HH  HH  HH  HH  HHH HHH   HH      HH  HH  HH      HH    \n"
					"  HHHHHH  HH  HH  HH H HH   HH      HH  HH  HHHHH   HHHHH \n"
					"  HH  HH  HH  HH  HH   HH   HH      HH  HH  HH      HH    \n"
					"  HH  HH  HHHHH   HH   HH  HHHH      HHHH   HH      HH    \n"
					"\n");
				err = set_component_videomode_from_edmode(dcc_info, disp_opt);
				err = apply_outports_videomode(dcc_info, disp_opt, FALSE);
				if (! disp_opt->dh_first_run) {
					update_output_afd_settings(dcc_info, disp_opt, NULL);
				}
				disp_opt->dh_first_run = FALSE;
			}
			disp_opt->dh_info->HDMIState = HDMIState;
			
			// Search for other ports with HotPlug active
			if (! HDMIState.HotPlugState && (disp_opt->dh_info->nDH > 1)) {
				RMuint32 i;
				for (i = 0; i < disp_opt->dh_info->nDH; i++) {
					if (i != disp_opt->dh_info->DH_sel) {
						struct DH_HDMI_state HDMIStateProbe;
						HDMIStateProbe.ReceiverSignal = FALSE;
						err = DHCheckHDMI(disp_opt->dh_info->pDH_array[i], &HDMIStateProbe);
						if (RMSUCCEEDED(err) && HDMIStateProbe.HotPlugState) {
							if (! manutest) fprintf(stderr, "\n\n\nSwitching to HDMI chip #%lu\n\n\n\n", i);
							disp_opt->dh_info->DH_sel = i;
							disp_opt->dh_info->pDH = disp_opt->dh_info->pDH_array[i];
							disp_opt->dh_info->HDMIState = HDMIStateProbe;
							disp_opt->dh_first_run = TRUE;
							if (disp_opt->dh_info->nDH > 1) {
#ifdef RMFEATURE_HAS_HDMI
								if (disp_opt->dh_info->DH_sel == 0) 
									disp_opt->i2c_module = 2;
								else 
#endif
								disp_opt->i2c_module = 1;
							}
							disp_opt->dig_ddr = FALSE;
							set_up_pads(dcc_info, disp_opt);
							DHSetDDRMode(disp_opt->dh_info->pDH, disp_opt->dig_ddr);
							break;
						}
					}
				}
			}
		}
		
		// Update audio settings to HDMI
		if (disp_opt->hdmi_monitor && audio_opt) {
			RMuint32 SampleRate;
			err = RUAGetProperty(dcc_info->pRUA, 
				EMHWLIB_MODULE(AudioEngine, audio_opt->AudioEngineID), 
				RMAudioEnginePropertyID_SampleFrequency, 
				&(SampleRate), sizeof(SampleRate));
			if (RMSUCCEEDED(err) && (SampleRate != audio_opt->SampleRate)) {
				if (! manutest) fprintf(stderr, "\n\n\nSetting new Audio Sample Clock while polling in update_hdmi(): %lu Hz\n\n\n", SampleRate);
				audio_opt->SampleRate = SampleRate;
				apply_dvi_hdmi_audio_options(dcc_info, audio_opt, 0, FALSE, FALSE, FALSE);
			}
		}
		
		// Update dh_info states (legacy compatibility)
		DHGetState(disp_opt->dh_info->pDH, &(disp_opt->dh_info->dvi_hdmi_state), &(disp_opt->dh_info->dvi_hdmi_cable));
	}
	
	return RM_OK;
}

static RMstatus fill_avi_info_frame(
	struct dcc_context *dcc_info, 
	struct display_cmdline *options, 
	struct DH_AVIInfoFrame *pAVIInfoFrame)
{
	struct DH_VideoFormatInfo video_format_info;
	struct EMhwlibTVFormatDigital fmt_d;
	
	video_format_info.VIC = 0;
	DHGetVideoFormatInfo(options->standard, options->ar_x, options->ar_y, &video_format_info);
	RUAExchangeProperty(dcc_info->pRUA, DisplayBlock, 
		RMDisplayBlockPropertyID_TVFormatDigital, 
		&(options->standard), sizeof(options->standard), 
		&fmt_d, sizeof(fmt_d));
	
	pAVIInfoFrame->Version = 0x02;
	pAVIInfoFrame->color_space = options->hdmi_convert ? options->hdmi_color_space : options->color_space;
	pAVIInfoFrame->sampling = options->hdmi_convert ? options->hdmi_sampling_mode : (options->bus_size == 16) ? EMhwlibSamplingMode_422 : EMhwlibSamplingMode_444;
	pAVIInfoFrame->scan_info = 
		(options->hdmi_scan == EMhwlibScanInfo_Underscanned) ? DH_underscanned : 
		(options->hdmi_scan == EMhwlibScanInfo_Overscanned) ? DH_overscanned : 
		DH_scan_undefined;
	pAVIInfoFrame->aspect_ratio.X = options->ar_x;
	pAVIInfoFrame->aspect_ratio.Y = options->ar_y;
	pAVIInfoFrame->active_format_valid = options->hdmi_active_format_valid || options->active_format_valid;
	pAVIInfoFrame->active_aspect_ratio = options->hdmi_active_format_valid ? options->hdmi_active_format : options->active_format;
	pAVIInfoFrame->non_linear_scaling = options->nonlinearmode;
	pAVIInfoFrame->pixel_repetition = video_format_info.pixel_rep;
	pAVIInfoFrame->VIC = video_format_info.VIC;
	pAVIInfoFrame->info_bars = 
		(((options->hdmi_bar_top != 0) || (options->hdmi_bar_bottom != 4096)) ? DH_horiz_bar_info_valid : 0) | 
		(((options->hdmi_bar_left != 0) || (options->hdmi_bar_right != 4096)) ? DH_vert_bar_info_valid : 0);
	pAVIInfoFrame->end_top_bar_line_num = options->hdmi_bar_top * fmt_d.ActiveHeight / 4096;
	pAVIInfoFrame->start_bottom_bar_line_num = options->hdmi_bar_bottom * fmt_d.ActiveHeight / 4096 + 1;
	pAVIInfoFrame->end_left_bar_pixel_num = options->hdmi_bar_left * fmt_d.ActiveWidth / 4096;
	pAVIInfoFrame->start_right_bar_pixel_num = options->hdmi_bar_right * fmt_d.ActiveWidth / 4096 + 1;
	if (pAVIInfoFrame->info_bars) {
		if (! manutest) fprintf(stderr, "Bars inside %lu*%lu frame (%lu:%lu): Hor.Bars to %u, from %u. Vert.Bars to %u, from %u\n", 
			fmt_d.ActiveWidth, fmt_d.ActiveHeight, 
			pAVIInfoFrame->aspect_ratio.X, pAVIInfoFrame->aspect_ratio.Y, 
			pAVIInfoFrame->end_top_bar_line_num, pAVIInfoFrame->start_bottom_bar_line_num, 
			pAVIInfoFrame->end_left_bar_pixel_num, pAVIInfoFrame->start_right_bar_pixel_num);
	} else // info bars have precedence over active format
	if (pAVIInfoFrame->active_format_valid) {
		if (! manutest) fprintf(stderr, "Active format inside %lu*%lu frame (%lu:%lu): %s\n", 
			fmt_d.ActiveWidth, fmt_d.ActiveHeight, 
			pAVIInfoFrame->aspect_ratio.X, pAVIInfoFrame->aspect_ratio.Y, 
			(pAVIInfoFrame->active_aspect_ratio == DH_af_16x9_top) ? "16:9 content: at top of 4:3 frame, fills up 16:9 frame" : 
			(pAVIInfoFrame->active_aspect_ratio == DH_af_14x9_top) ? "14:9 content: at top of 4:3 frame, centered on 16:9 frame" : 
			(pAVIInfoFrame->active_aspect_ratio == DH_af_64x27_centered) ? "Cinemascope widescreen (2.35:1, 64:27) content: centered on 4:3 or 16:9 frame" : 
			(pAVIInfoFrame->active_aspect_ratio == DH_af_same_as_picture) ? "content fills up frame" : 
			(pAVIInfoFrame->active_aspect_ratio == DH_af_4x3_centered) ? "4:3 content: fills up 4:3 frame, centered on 16:9 frame" : 
			(pAVIInfoFrame->active_aspect_ratio == DH_af_16x9_centered) ? "16:9 content: centered on 4:3 frame, fills up 16:9 frame" : 
			(pAVIInfoFrame->active_aspect_ratio == DH_af_14x9_centered) ? "14:9 content: centered on 4:3 frame, centered on 16:9 frame" : 
			(pAVIInfoFrame->active_aspect_ratio == DH_af_4x3_centered_prot_14x9) ? "4:3 content with essential content in 14:9 centered portion" : 
			(pAVIInfoFrame->active_aspect_ratio == DH_af_16x9_centered_prot_14x9) ? "16:9 content with essential content in 14:9 centered portion" : 
			(pAVIInfoFrame->active_aspect_ratio == DH_af_16x9_centered_prot_4x3) ? "16:9 content with essential content in 4:3 centered portion" : 
			"unknown format code!");
	}
	
	return RM_OK;
}

/* 
  set options->standard to component video mode closest matching the parameters specified by the -edmode option: 
  options->dvi_hdmi_edid_vfreq 
  options->dvi_hdmi_edid_hsize 
  options->dvi_hdmi_edid_vsize 
  options->dvi_hdmi_edid_intl 
  options->edid_max_pixclk 
  options->edid_min_pixclk 
  options->edid_max_hfreq 
  options->edid_min_hfreq 
  options->edid_max_vfreq 
  options->edid_min_vfreq 
*/
RMstatus set_component_videomode_from_edmode(struct dcc_context *dcc_info, struct display_cmdline *options)
{
	RMstatus err = RM_ERROR;
	RMuint32 asp_x, asp_y, vfreq, hsize, vsize;
	RMuint32 i, match, bestmatch = 0;
	RMbool intl, sixtyhertz, onethousandone, hdtv;
	enum EMhwlibTVStandard std;
	struct EMhwlibTVFormatDigital fmt_d;
	enum EMhwlibTVStandard match_list[] = {
		EMhwlibTVStandard_1080p59, 
		EMhwlibTVStandard_1080p50, 
		EMhwlibTVStandard_1080p29, 
		EMhwlibTVStandard_1080p25, 
		EMhwlibTVStandard_1080p23, 
		// entry 5 is first non-1080p
		EMhwlibTVStandard_1080i59, 
		EMhwlibTVStandard_1080i50, 
		EMhwlibTVStandard_1080i47, 
		EMhwlibTVStandard_720p59, 
		EMhwlibTVStandard_720p50, 
		EMhwlibTVStandard_720p29, 
		EMhwlibTVStandard_720p25, 
		EMhwlibTVStandard_720p23, 
		// entry 13 is first non-HDTV
		EMhwlibTVStandard_NTSC_M, 
		EMhwlibTVStandard_480p59, 
		EMhwlibTVStandard_PAL_BG, 
		EMhwlibTVStandard_576p50, 
	};
	
	if (options->edid_sel == DH_EDID_auto) {
		// "preferred": target 1080i59
		vfreq = 59;
		hsize = 1920;
		vsize = 1080;
		intl = TRUE;
		asp_x = 16;
		asp_y = 9;
	} else if ((options->edid_sel == DH_EDID_match) || (options->edid_sel == DH_EDID_fmatch)) {
		if (options->dvi_hdmi_edid_descriptor) {
			enum EMhwlibTVStandard TVStandard;
			struct EMhwlibTVFormatDigital TVFormat;
			err = DHGetVideoInfoFromCEAVideoIdentificationCode(options->dvi_hdmi_edid_descriptor, FALSE, &TVStandard, &asp_x, &asp_y, NULL, NULL);
			err = RUAExchangeProperty(dcc_info->pRUA, DisplayBlock, 
				RMDisplayBlockPropertyID_TVFormatDigital, 
				&TVStandard, sizeof(TVStandard), 
				&TVFormat, sizeof(TVFormat));
			vfreq = TVFormat.PixelClock / (TVFormat.Progressive ? TVFormat.HTotalSize : (TVFormat.HTotalSize / 2)) / TVFormat.VTotalSize;
			hsize = TVFormat.ActiveWidth;
			vsize = TVFormat.Progressive ? TVFormat.ActiveHeight : (TVFormat.ActiveHeight * 2);
			intl = ! TVFormat.Progressive;
		} else {
			vfreq = options->dvi_hdmi_edid_vfreq;
			hsize = options->dvi_hdmi_edid_hsize;
			vsize = options->dvi_hdmi_edid_vsize;
			intl = options->dvi_hdmi_edid_intl;
			asp_x = (options->ar_x) ? options->ar_x : (hsize > 720) ? 16 : 4;
			asp_y = (options->ar_y) ? options->ar_y : (hsize > 720) ? 9 : 3;
		}
	} else {
		return RM_OK;  // nothing to do
	}
	
	sixtyhertz = ((vfreq == 24) || (vfreq == 30) || (vfreq == 60) || (vfreq == 120) || (vfreq == 240));
	onethousandone = ((vfreq == 23) || (vfreq == 29) || (vfreq == 47) || (vfreq == 59) || (vfreq == 119) || (vfreq == 239));
	if (onethousandone) vfreq++;
	RMDBGLOG((LOCALDBG, "set_component_videomode_from_edmode(): match v=%lu%s, w=%lu, h=%lu, i=%u, x=%lu, y=%lu\n", 
		vfreq, onethousandone ? "/1.001" : "", hsize, vsize, intl, asp_x, asp_y));
	
	std = EMhwlibTVStandard_Custom;
	hdtv = FALSE;
	for (i = (options->sd_cav_1080p ? 0 : 5); i < (sizeof(match_list) / sizeof(enum EMhwlibTVStandard)); i++) {
		RUAExchangeProperty(dcc_info->pRUA, DisplayBlock, 
			RMDisplayBlockPropertyID_TVFormatDigital, 
			&(match_list[i]), sizeof(match_list[i]), 
			&fmt_d, sizeof(fmt_d));
		match = DHGetVideoModeMatchValue(&fmt_d, 0, 0, 
			vfreq, hsize, vsize, intl, onethousandone, asp_x, asp_y, 
			options->edid_max_pixclk, options->edid_min_pixclk, 
			options->edid_max_hfreq, options->edid_min_hfreq, 
			options->edid_max_vfreq, options->edid_min_vfreq);
		if (match > bestmatch) {
			bestmatch = match;
			std = match_list[i];
			hdtv = (i <= 12);
			err = RM_OK;
		}
	}
	if (RMSUCCEEDED(err) && (options->standard != std)) {
		RMascii *StandardName;
		GetTVStandardName(std, &StandardName);
		RMDBGLOG((LOCALDBG, "Found new mode: %s\n", StandardName));
		options->standard = std;
		if (hdtv) {
			options->color_space = EMhwlibColorSpace_YUV_709;
			options->ar_x = 16;
			options->ar_y = 9;
		} else {
			options->color_space = EMhwlibColorSpace_YUV_601;
		}
	}
	
	return err;
}

RMstatus set_videomode_from_EDID(struct dcc_context *dcc_info, struct display_cmdline *options)
{
	RMstatus err;
	struct EMhwlibTVFormatDigital format_digital, *pFD = NULL;
	struct EMhwlibTVFormatAnalog format_analog, *pFA = NULL;
	RMbool UseStandard;
	RMuint32 VIC;
	RMbool hdmi_monitor;
	
	if (options->target_ar_x && options->target_ar_y) {
		// restore original user-specified value
		options->ar_x = options->target_ar_x;
		options->ar_y = options->target_ar_y;
	} else {
		// remember original value for future calls
		options->target_ar_x = options->ar_x;
		options->target_ar_y = options->ar_y;
	}
	options->dh_info->nDBC = NUM_DBC;
	if (options->dh_info->pDBC == NULL) {
		options->dh_info->pDBC = (struct CEA861BDataBlockCollection *)RMMalloc(options->dh_info->nDBC * sizeof(struct CEA861BDataBlockCollection));
		if (options->dh_info->pDBC == NULL) options->dh_info->nDBC = 0;
	}
	if (options->edid_sel == DH_EDID_none) {
		// Determine HDMI/DVI mode of display and audio capabilities
		err = DHGetVideoModeFromEDID(options->dh_info->pDH, 
			NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
			&hdmi_monitor, 
			options->dh_info->pDBC, &(options->dh_info->nDBC), 
			NULL);
		UseStandard = TRUE;
	} else {
		pFD = &format_digital;
		pFA = &format_analog;
		err = DHGetVideoModeFromEDID(options->dh_info->pDH, 
			&(options->standard), pFD, pFA, &UseStandard, &VIC, &(options->ar_x), &(options->ar_y), 
			&hdmi_monitor, 
			options->dh_info->pDBC, &(options->dh_info->nDBC), 
			&(options->color_space));
		if (options->standard != EMhwlibTVStandard_Custom) {
			RMascii *StandardName;
			GetTVStandardName(options->standard, &StandardName);
			if (! manutest) fprintf(stderr, "HDMI TVStandard from EDID: %s, %lux%lu\n", StandardName ? StandardName : "<unknown>", options->ar_x, options->ar_y);
		} else {
			if (! manutest) fprintf(stderr, "HDMI detailed TVFormat from EDID: %lux%lu\n", options->ar_x, options->ar_y);
		}
	}
	if (RMFAILED(err)) {
		options->dh_info->nDBC = 0;
	}
	
	if (! options->hdmi_force) options->hdmi_monitor = hdmi_monitor;
	if (options->hdmi_monitor) {
		if (! manutest) fprintf(stderr, "Monitor is HDMI\n");
	} else {
		if (! manutest) fprintf(stderr, "Monitor is DVI / VGA\n");
	}
	err = DHSetHDMIMode(options->dh_info->pDH, options->hdmi_monitor);
	if (RMFAILED(err)) {
		if (! manutest) fprintf(stderr, "Chipset does not support HDMI, defaulting to DVI\n");
		options->hdmi_monitor = FALSE;
	}
	if ((! options->hdmi_monitor) && (options->color_space != EMhwlibColorSpace_RGB_0_255)) {
		if (! manutest) fprintf(stderr, "DVI display, using RGB 0-255\n");
		options->color_space = EMhwlibColorSpace_RGB_0_255;
	}
	
	// Turn off TMDS to avoid video noise
	DHDisableOutput(options->dh_info->pDH);
	
	{
		RMbool EnableVVLDPAD;
		
		if (options->dig_protocol != EMhwlibDigitalTimingSignal_601) {
			options->hdmi_de = FALSE;
			EnableVVLDPAD = FALSE;
		} else {
			EnableVVLDPAD = TRUE;
		}
		
		DCCSPERR(dcc_info->pRUA, DispDigitalOut, RMDispDigitalOutPropertyID_EnableVVLDPAD, &EnableVVLDPAD, sizeof(EnableVVLDPAD), "Cannot set EnableVVLDPAD on DispDigitalOut output");
		DCCSPERROK(RM_OK, dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_Validate, NULL, 0, "Can not Validate DispDigitalOut output");
	}
	if (UseStandard || options->use_hdsd_conversion || (options->standard != EMhwlibTVStandard_Custom)) {
		err = apply_outports_videomode(dcc_info, options, TRUE);
	} else {
		// disable analog outputs by calling apply_outports_videomode with VGA resolution
		options->standard = EMhwlibTVStandard_HDMI_640x480p59;
		err = apply_outports_videomode(dcc_info, options, TRUE);
		options->standard = EMhwlibTVStandard_Custom;
		// TODO extend outport_options to accept TVFormat
		DCCSP(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_DigitalTVFormat, &format_digital, sizeof(format_digital));
		DCCSP(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_Validate, NULL, 0);
		update_hdmi_videomode(dcc_info, options, &format_digital);
	}
	
	err = DHEnableOutput(options->dh_info->pDH);
	if (RMFAILED(err)) {
		if (! manutest) fprintf(stderr, "Cannot enable DVI/HDMI chip!!!!\n");
	}
	
	if ((options->ar_x == 0) || (options->ar_y == 0)) {
		if (dcc_info->SurfaceID) {
			err = DCCSetRouteDisplayAspectRatioFromSource(dcc_info->pDCC, dcc_info->route, dcc_info->SurfaceID);
		} else {
			err = RM_ERROR;
		}
	} else {
		err = DCCSetRouteDisplayAspectRatio(dcc_info->pDCC, dcc_info->route, options->ar_x, options->ar_y);
	}
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set display aspect ratio: %s\n", RMstatusToString(err)));
	}
	
	switch (options->connector) {
	case DCCVideoConnector_DVI:
	case DCCVideoConnector_LVDS:
	case DCCVideoConnector_Digital:
		if (! manutest) fprintf(stderr, "HDMI Colorspace is now: %s\n", 
			(options->color_space == EMhwlibColorSpace_RGB_0_255) ? "RGB full range" : 
			(options->color_space == EMhwlibColorSpace_RGB_16_235) ? "RGB limited range" : 
			(options->color_space == EMhwlibColorSpace_YUV_601) ? "YCbCr 601" : 
			(options->color_space == EMhwlibColorSpace_YUV_709) ? "YCbCr 709" : 
			(options->color_space == EMhwlibColorSpace_xvYCC_601) ? "xvYCC 601" : 
			(options->color_space == EMhwlibColorSpace_xvYCC_709) ? "xvYCC 709" : 
			(options->color_space == EMhwlibColorSpace_YUV_601_0_255) ? "YCbCr 601 full range" : 
			(options->color_space == EMhwlibColorSpace_YUV_709_0_255) ? "YCbCr 709 full range" : 
			(options->color_space == EMhwlibColorSpace_xvYCC_601_0_255) ? "xvYCC 601 full range" : 
			(options->color_space == EMhwlibColorSpace_xvYCC_709_0_255) ? "xvYCC 709 full range" : 
			"Unknown!");
		DCCSetDVIOutFormat(dcc_info->pDCC, 
			(options->vga_standard == EMhwlibTVStandard_Custom) ? dcc_info->route : DCCRoute_Secondary, 
			options->color_space, 
			options->dig_protocol, 
			options->bus_size);
		break;
	default:
		break;
	}
	
	if (options->hdmi_convert) {
		// Forced setting: convert to different format inside HDMI chip
		err = DHSetConversionVideoFormat(options->dh_info->pDH, 
			options->color_space, EMhwlibSamplingMode_444, 8, 
			options->hdmi_color_space, options->hdmi_sampling_mode, options->hdmi_component_depth);
	} else {
		// Default setup: 24 bit video, no conversion inside HDMI chip
		err = DHSetConversionVideoFormat(options->dh_info->pDH, 
			options->color_space, EMhwlibSamplingMode_444, 8, 
			options->color_space, EMhwlibSamplingMode_444, 8);
	}
	
	if (options->hdmi_monitor) {
		struct DH_AVIInfoFrame AVIInfoFrame;
		
		fill_avi_info_frame(dcc_info, options, &AVIInfoFrame);
		
		err = DHEnableAVIInfoFrame(options->dh_info->pDH, &AVIInfoFrame);
		if (RMFAILED(err)) if (! manutest) fprintf(stderr, "HDMI Error, can not send AVI info frames!\n");
		
		if (options->hdmi_spd_vendor && options->hdmi_spd_product) {
			struct DH_SPDInfoFrame SPDInfoFrame;
			
			SPDInfoFrame.Version = 0x01;
			SPDInfoFrame.VendorName = options->hdmi_spd_vendor;
			SPDInfoFrame.ProductDescription = options->hdmi_spd_product;
			SPDInfoFrame.SDI = options->hdmi_spd_class;
			DHEnableSPDInfoFrame(options->dh_info->pDH, &SPDInfoFrame, 0);
		}
	} else {
		if (! manutest) fprintf(stderr, "No HDMI monitor, can not send AVI info frames!\n");
	}
	
	return err;
}

RMstatus load_edid_block_from_file(RMfile fd, RMuint32 *mode, RMuint8 *data)
{
	RMstatus err = RM_OK;
	RMuint32 size;
	
	if (*mode == 0) {  // init
		err = RMReadFile(fd, data, 8, &size);
		if (RMFAILED(err) || (size < 8)) return err;
		if ((data[0]==0x00) && (data[1]==0xFF) && (data[2]==0xFF) && (data[3]==0xFF) && (data[4]==0xFF) && (data[5]==0xFF) && (data[6]==0xFF) && (data[7]==0x00)) {
			fprintf(stderr, "EDID file is binary\n");
			*mode = 1;
			err = RMReadFile(fd, &(data[8]), 120, &size);
			if (RMSUCCEEDED(err) && (size < 120)) err = RM_ERROR;
			return err;
		} else {
			fprintf(stderr, "EDID file might be hexdump\n");
			*mode = 2;
			RMSeekFile(fd, 0, RM_FILE_SEEK_START);
		}
	}
	if (*mode == 1) {
		err = RMReadFile(fd, data, 128, &size);
	} else {
		RMascii line[80];
		RMuint32 i, n, b, s, d[8];
		size = 0;
		do {
			if (RMEndOfFile(fd)) break;
			err = RMReadLineFile(fd, line, sizeof(line) / sizeof(RMascii));
			if (RMFAILED(err)) break;
			if (! RMMatchNAscii(line, "EDID", 4)) {
				n = sscanf(line, "EDID[%lu][%lx]: %lx %lx %lx %lx %lx %lx %lx %lx", 
					&b, &s, &(d[0]), &(d[1]), &(d[2]), &(d[3]), &(d[4]), &(d[5]), &(d[6]), &(d[7]));
				if (n != 10) {
					fprintf(stderr, "Parse error in line:\n  \"%s\"\nExpecting:\n  \"EDID[x][xx]: xx xx xx xx xx xx xx xx\"\n", line);
					return RM_ERROR;
				}
				if (s != size) {
					fprintf(stderr, "Warning, wrong offset 0x%02lX instead of 0x%02lX in line: \"%s\"\n", s, size, line);
				}
			} else {
				n = sscanf(line, "%lx %lx %lx %lx %lx %lx %lx %lx", 
					&(d[0]), &(d[1]), &(d[2]), &(d[3]), &(d[4]), &(d[5]), &(d[6]), &(d[7]));
				if (n != 8) {
					fprintf(stderr, "Parse error in line:\n  \"%s\"\nExpecting:\n  \"xx xx xx xx xx xx xx xx\"\n", line);
					return RM_ERROR;
				}
			}
			for (i = 0; i < 8; i++) {
				data[size++] = d[i] & 0xFF;
			}
		} while (size < 128);
	}
	return (RMFAILED(err)) ? err : (size == 128) ? RM_OK : RM_ERROR;
}

RMstatus upload_edid_file(struct display_cmdline *options)
{
	RMstatus err;
	RMuint8 data[128];
	RMuint32 block = 0, mode = 0;
	RMfile fd;
	RMnonAscii *naname = RMnonAsciiFromAscii(options->dvi_hdmi_edid_file);
	
	fd = RMOpenFile(naname, RM_FILE_OPEN_READ);
	RMFreeNonAscii(naname);
	if (fd) {
		do {
			err = load_edid_block_from_file(fd, &mode, data);
			if (RMFAILED(err) || ((block == 0) && (data[0] || (data[1]!=0xFF) || (data[2]!=0xFF) || (data[3]!=0xFF) || (data[4]!=0xFF) || (data[5]!=0xFF) || (data[6]!=0xFF) || data[7]))) {
				fprintf(stderr, "Error, file %s does not contain EDID data for block %lu!\n", options->dvi_hdmi_edid_file, block);
				break;
			} else {
				RMuint32 i, sum = 0;
				for (i = 0; i < 0x7F; i++) {
					sum += data[i];
				}
				data[0x7F] = (0x100 - (sum & 0xFF)) & 0xFF;
				RMDBGLOG((ENABLE, "Checksum of EDID block %lu: 0x%02X\n", block, data[0x7F]));
				err = DHWriteEDIDBlock(options->dh_info->pDH, block, data, 0x80);
				if (RMFAILED(err)) {
					fprintf(stderr, "Error writing %u bytes of EDID data to block %lu!\n", 0x80, block);
				}
			}
			block++;
		} while (RMSUCCEEDED(err));
		RMCloseFile(fd);
		return RM_OK;
	} else {
		return RM_ERROR;
	}
}

RMstatus download_edid_file(struct display_cmdline *options)
{
	RMstatus err;
	RMuint8 data[128];
	RMuint32 size;
	RMfile fd;
	RMnonAscii *naname = RMnonAsciiFromAscii(options->dvi_hdmi_edid_file);
	
	fd = RMOpenFile(naname, RM_FILE_OPEN_WRITE);
	RMFreeNonAscii(naname);
	if (fd) {
		RMuint32 i = 0;
		do {
			err = DHLoadEDIDBlock(options->dh_info->pDH, i, data, 128);
			if (RMSUCCEEDED(err)) {
				err = RMWriteFile(fd, data, 128, &size);
				if (size != 128) break;
			}
			i++;
		} while (RMSUCCEEDED(err));
		RMCloseFile(fd);
		return RM_OK;
	} else {
		return RM_ERROR;
	}
}


RMstatus force_edid_file(struct display_cmdline *options)
{
	RMstatus err;
	RMuint8 data[1024];
	RMuint32 size = 0, mode = 0;
	RMfile fd;
	RMnonAscii *naname = RMnonAsciiFromAscii(options->dvi_hdmi_edid_file);
	
	fd = RMOpenFile(naname, RM_FILE_OPEN_READ);
	RMFreeNonAscii(naname);
	if (fd) {
		do {
			err = load_edid_block_from_file(fd, &mode, &(data[size]));
			if (RMSUCCEEDED(err)) size += 128;
		} while (RMSUCCEEDED(err) && (size < (sizeof(data) / sizeof(RMuint8))));
		RMCloseFile(fd);
		if ((size < 128) || data[0] || (data[1]!=0xFF) || (data[2]!=0xFF) || (data[3]!=0xFF) || (data[4]!=0xFF) || (data[5]!=0xFF) || (data[6]!=0xFF) || data[7]) {
			fprintf(stderr, "Error, file %s does not contain EDID data!\n", options->dvi_hdmi_edid_file);
		} else {
			RMuint32 i, sum = 0;
			for (i = 0; i < size; i++) {
				if ((i & 0x7F) == 0x7F) {
					data[i] = (256 - (sum & 0xFF)) & 0xFF;
					sum = 0;
					RMDBGLOG((ENABLE, "Checksum of EDID block %lu: 0x%02X\n", i >> 7, data[i]));
				} else {
					sum += data[i];
				}
			}
			DHSetEDID(options->dh_info->pDH, data, size / 128);
		}
		return RM_OK;
	} else {
		return RM_ERROR;
	}
}

RMstatus display_edid(struct display_cmdline *options)
{
	struct EDID_Data edid;
	struct CEA861BDataBlockCollection DBC;
	struct CEADetailedTimingDescriptor DTD;
	RMuint8 edid_block[128];
	RMuint8 edid_block_index;
	RMbool HDMI = FALSE;
	
	if (RMFAILED(DHLoadEDIDVersion1(options->dh_info->pDH, &edid))) {
		fprintf(stderr, "Cannot load EDID Version 1 information from EEPROM (or info is incorrect!)\n");
	}
	else {
		display_edid_header(&edid);
		
		if (RMSUCCEEDED(DHGetCEADetailedTimingDescriptor(edid.EDID_Descriptor1, &DTD))) {
			if (DTD.PixelClock) {
				display_detailed_timing_descriptor(1, &DTD);
			}
		}
		if (RMSUCCEEDED(DHGetCEADetailedTimingDescriptor(edid.EDID_Descriptor2, &DTD))) {
			if (DTD.PixelClock) {
				display_detailed_timing_descriptor(2, &DTD);
			}
		}
		if (RMSUCCEEDED(DHGetCEADetailedTimingDescriptor(edid.EDID_Descriptor3, &DTD))) {
			if (DTD.PixelClock) {
				display_detailed_timing_descriptor(3, &DTD);
			} else {
				display_monitor_descriptor(3, edid.EDID_Descriptor3);
			}
		}
		if (RMSUCCEEDED(DHGetCEADetailedTimingDescriptor(edid.EDID_Descriptor4, &DTD))) {
			if (DTD.PixelClock) {
				display_detailed_timing_descriptor(4, &DTD);
			} else {
				display_monitor_descriptor(4, edid.EDID_Descriptor4);
			}
		}
		fprintf(stderr, "\n");
		
		for (edid_block_index = 1; edid_block_index <= edid.EDID_Extension; edid_block_index++) { // From 1 to number of blocks
			if (RMSUCCEEDED(DHLoadEDIDBlock(options->dh_info->pDH, edid_block_index, edid_block, sizeof(edid_block)))) {
				display_edid_timing_extension_header(edid_block);
			}
			
			if (RMSUCCEEDED(DHGetCEADataBlockCollection(edid_block, sizeof(edid_block), &DBC))) {
				HDMI |= DBC.HDMI_sink;
				display_cea861B_data_block_collection(&DBC);
			}
		}
		if (HDMI) {
			fprintf(stderr, "Monitor is HDMI\n");
		} else {
			fprintf(stderr, "Monitor is DVI / VGA\n");
		}
	}
	return RM_OK;
}

static RMstatus set_up_pads(struct dcc_context *dcc_info, struct display_cmdline *options)
{
#ifdef RMFEATURE_HAS_HDMI
	{  // enable/disable tango2 internal SiI9030
		RMstatus err;
		struct DisplayBlock_HDMIConfig_type hc;
		
		hc.ClkDiv = FALSE;
		hc.AudioClkInv = TRUE;
		if ((options->connector == DCCVideoConnector_DVI) && (options->i2c_module == 2)) {
			hc.PowerUpPhy = TRUE;
			hc.OutputSelect = TRUE;
			// force DDR on digital pads when using internal SiI9030
			options->dig_ddr = TRUE;
		} else {
			hc.PowerUpPhy = FALSE;
			hc.OutputSelect = FALSE;
		}
		if (RMFAILED(err = RUASetProperty(dcc_info->pRUA, 
			DisplayBlock, RMDisplayBlockPropertyID_HDMIConfig, 
			&hc, sizeof(hc), 0))) {
			RMDBGLOG((ENABLE, "Error setting internal HDMI config! %s\n", RMstatusToString(err)));
			return err;
		}
	}
#endif
	
	if (options->connector == DCCVideoConnector_DVI) {
		if (options->dig_ddr) {
			// set DDR delay 2 on HDMI when in DDR mode
			if (! options->dig_force_delay) options->dig_delay = 2300;
		} else {
			// set -dig_no_delay on HDMI when not in DDR mode
			if (! options->dig_force_delay) options->dig_delay = 0;
		}
	} else {
		if (! options->dig_ddr && ! options->dig_force_delay) options->dig_delay = 400;
	}
	
	{  // set up Digital Out Pads
		struct DispDigitalOut_PadsControl_type pads;
		RMMemset(&pads, 0, sizeof(pads));
		pads.APIVersion = 1;
		pads.ModifyInvertClock = TRUE;
		pads.InvertClock = ! options->dig_clk_normal;
		pads.ModifyDDRdout = TRUE;
		pads.DDRdout = options->dig_ddr;
		pads.ModifyInvertCaptureClock = TRUE;
		pads.InvertCaptureClock = options->dig_inv_cap_clk;
		pads.ModifyDelay = TRUE;
		pads.Delay = options->dig_delay;
		DCCSPERR(dcc_info->pRUA, DispDigitalOut, RMDispDigitalOutPropertyID_PadsControl, &pads, sizeof(pads), "Can not set PadsControl");
		DCCSPERR(dcc_info->pRUA, DispDigitalOut, RMDispDigitalOutPropertyID_VSyncDelay1PixClk, &(options->dig_vsync_delay), sizeof(options->dig_vsync_delay), "Can not set VSyncDelay1PixClk");
		DCCSPERR(dcc_info->pRUA, DispDigitalOut, RMDispDigitalOutPropertyID_TrailingEdge, &(options->dig_trailing_edge), sizeof(options->dig_trailing_edge), "Can not set TrailingEdge");
		// important, don't forget to validate!!!
		DCCSPERR(dcc_info->pRUA, DispDigitalOut, RMGenericPropertyID_Validate, NULL, 0, "Can not validate DispDigitalOut");
	}
	
	return RM_OK;
}

RMstatus apply_videomode_from_vmf_file(struct dcc_context *dcc_info, RMascii *vidmode_filename)
{
	RMstatus err;
	struct EMhwlibTVFormatDigital format_digital;
	struct EMhwlibTVFormatAnalog format_analog;
	
	err = parse_video_mode_file(vidmode_filename, &format_digital, &format_analog);
	if (RMFAILED(err)) {
		if (! manutest) fprintf(stderr, "Error %s (%d): cannot parse video mode file %s\n", RMstatusToString(err), err, vidmode_filename);
		return err;
	}
	err = DCCSetTVFormat(dcc_info->pDCC, dcc_info->route, &format_digital, &format_analog);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error %s (%d): cannot open display.\n", RMstatusToString(err), err));
		return err;
	}
	return err;
}

/* set up either a static picture or color bars on the VGA output and initialize the other outputs with a different mode for normal use */
static RMstatus apply_dual_videomode(struct dcc_context *dcc_info, struct display_cmdline *options, RMuint32 mixer) 
{
	RMstatus err;
	
	if (options->osd_pictures[1].enable) {  // OSD on secondary (VGA)
		RMuint32 vcr_mixer, osd_scaler, src_index;
		enum EMhwlibMixerSourceState state;
		
		// find out which scaler will be used
		err = DCCGetScalerModuleID(dcc_info->pDCC, options->osd_pictures[1].route, DCCSurface_OSD, options->osd_pictures[1].scaler, &osd_scaler);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error %s (%d): cannot get surface to "
				  "display OSD source\n", RMstatusToString(err), err));
			return err;
		}
		
		// put that scaler in "slave" mode on main mixer, so that it does not get handled twice.
		if (mixer) {
			err = RUAExchangeProperty(dcc_info->pRUA, mixer, RMGenericPropertyID_MixerSourceIndex, &osd_scaler, sizeof(osd_scaler), &src_index, sizeof(src_index));
			if (err != RM_OK) {
				RMDBGLOG((ENABLE, "Cannot get scaler index, %s\n", RMstatusToString(err)));
				return err;
			}
			vcr_mixer = EMHWLIB_TARGET_MODULE(EMHWLIB_MODULE_CATEGORY(mixer), EMHWLIB_MODULE_INDEX(mixer), src_index);
			state = EMhwlibMixerSourceState_Slave;
			DCCSP(dcc_info->pRUA, vcr_mixer, RMGenericPropertyID_MixerSourceState, &state, sizeof(state));
		}
		
		err = DCCSetStandardDual(dcc_info->pDCC, dcc_info->route, options->osd_pictures[1].route, options->standard, options->vga_standard);
	} else {  // colorbars on secondary (VGA)
		RMuint32 colorbars;
		RMbool enable;
		RMuint32 intensity = 0;
		enum EMhwlibColorBarsStandard standard = EMhwlibColorBarsStandard_NTSC;
		colorbars = EMHWLIB_MODULE(DispColorBars, 0);
		DCCSPERR(dcc_info->pRUA, colorbars, RMDispColorBarsPropertyID_Intensity, &intensity, sizeof(intensity), "Cannot set color bars intensity");
		DCCSPERR(dcc_info->pRUA, colorbars, RMDispColorBarsPropertyID_Standard, &standard, sizeof(standard), "Cannot set color bars standard");
		DCCSPERR(dcc_info->pRUA, colorbars, RMGenericPropertyID_Validate, NULL, 0, "Cannot validate color bars properties");
		enable = TRUE;
		DCCSPERR(dcc_info->pRUA, colorbars, RMGenericPropertyID_Enable, &enable, sizeof(enable), "Cannot enable color bars");
		err = DCCSetStandardDual(dcc_info->pDCC, dcc_info->route, DCCRoute_ColorBars, options->standard, options->vga_standard);
	}
	update_hdmi_videomode(dcc_info, options, NULL);
	
	return err;
}

/* create and apply outports configuration, based on display options. */
static RMstatus apply_outports_videomode(struct dcc_context *dcc_info, struct display_cmdline *display_options, RMbool hdmi_active)
{
	RMuint32 i;
	RMbool sd_component, sd_autodetect, handled = FALSE;
	struct outports_options outport_options;
	RMascii *StandardNameHDMI, *StandardNameCAV, *StandardNameCVBS;
	enum EMhwlibTVStandard sd_standard, hdmi_cav_match[][2] = {  // equivalent HDMI <=> component video modes
#ifdef RMFEATURE_HAS_DOUBLE_RATE
		{EMhwlibTVStandard_HDMI_480i59,  EMhwlibTVStandard_NTSC_M}, 
		{EMhwlibTVStandard_HDMI_576i50,  EMhwlibTVStandard_PAL_BG}, 
#endif
		{EMhwlibTVStandard_HDMI_480p59,  EMhwlibTVStandard_480p59}, 
		{EMhwlibTVStandard_HDMI_720p59,  EMhwlibTVStandard_720p59}, 
		{EMhwlibTVStandard_HDMI_720p60,  EMhwlibTVStandard_720p60}, 
		{EMhwlibTVStandard_HDMI_1080i59, EMhwlibTVStandard_1080i59}, 
		{EMhwlibTVStandard_HDMI_1080i60, EMhwlibTVStandard_1080i60}, 
		{EMhwlibTVStandard_HDMI_1080p59, EMhwlibTVStandard_1080p59}, 
		{EMhwlibTVStandard_HDMI_1080p60, EMhwlibTVStandard_1080p60}, 
		{EMhwlibTVStandard_HDMI_576p50,  EMhwlibTVStandard_576p50}, 
		{EMhwlibTVStandard_HDMI_720p50,  EMhwlibTVStandard_720p50}, 
		{EMhwlibTVStandard_HDMI_1080i50, EMhwlibTVStandard_1080i50}, 
		{EMhwlibTVStandard_HDMI_1080p50, EMhwlibTVStandard_1080p50}, 
		{EMhwlibTVStandard_HDMI_1080p23, EMhwlibTVStandard_1080p23}, 
		{EMhwlibTVStandard_HDMI_1080p24, EMhwlibTVStandard_1080p24}, 
		{EMhwlibTVStandard_HDMI_1080p25, EMhwlibTVStandard_1080p25}, 
		{EMhwlibTVStandard_HDMI_1080p29, EMhwlibTVStandard_1080p29}, 
		{EMhwlibTVStandard_HDMI_1080p30, EMhwlibTVStandard_1080p30}, 
	};
	
	init_outports_options(&outport_options);
	
	// disable digital out when not explicitly selected with '-o'
	switch (display_options->connector) {
	case DCCVideoConnector_DVI:
	case DCCVideoConnector_LVDS:
	case DCCVideoConnector_Digital:
		// enable/disable HDMI as requested
		break;
	case DCCVideoConnector_VGA:
	case DCCVideoConnector_SCART:
		// Special sync setup
		DCCEnableVideoConnector(dcc_info->pDCC, dcc_info->route, display_options->connector, TRUE);
		display_options->component = EMhwlibComponentMode_RGB_SCART;
		display_options->color_space = EMhwlibColorSpace_RGB_0_255;
	default:
		RMDBGLOG((LOCALDBG, "[outports] Digital output disabled (not selected)\n"));
		hdmi_active = FALSE;
	}
	
	// gather local SD settings
	sd_component = display_options->sd_component && hdmi_active;
	sd_standard = display_options->sd_standard;
	sd_autodetect = (sd_standard == EMhwlibTVStandard_Custom) || display_options->sd_autodetect;
	
	// Exclude analog when HDMI mode not supported by HD->SD converter
	switch (display_options->standard) {
	case EMhwlibTVStandard_Custom:

	case EMhwlibTVStandard_HDMI_640x480p59: 
	case EMhwlibTVStandard_HDMI_640x480p60: 
#ifndef RMFEATURE_HAS_DOUBLE_RATE
	case EMhwlibTVStandard_HDMI_480i59: 
#endif
	case EMhwlibTVStandard_HDMI_480i60: 
	case EMhwlibTVStandard_HDMI_1440x480i59: 
	case EMhwlibTVStandard_HDMI_1440x480i60: 
	case EMhwlibTVStandard_HDMI_240p59: 
	case EMhwlibTVStandard_HDMI_240p60: 
	case EMhwlibTVStandard_HDMI_1440x240p59: 
	case EMhwlibTVStandard_HDMI_1440x240p60: 
	case EMhwlibTVStandard_HDMI_2880x480i59: 
	case EMhwlibTVStandard_HDMI_2880x480i60: 
	case EMhwlibTVStandard_HDMI_2880x240p59: 
	case EMhwlibTVStandard_HDMI_2880x240p60: 
	case EMhwlibTVStandard_HDMI_1440x480p59: 
	case EMhwlibTVStandard_HDMI_1440x480p60: 
#ifndef RMFEATURE_HAS_DOUBLE_RATE
	case EMhwlibTVStandard_HDMI_576i50: 
#endif
	case EMhwlibTVStandard_HDMI_1440x576i50: 
	case EMhwlibTVStandard_HDMI_288p50: 
	case EMhwlibTVStandard_HDMI_1440x288p50: 
	case EMhwlibTVStandard_HDMI_2880x576i50: 
	case EMhwlibTVStandard_HDMI_2880x288p50: 
	case EMhwlibTVStandard_HDMI_1440x576p50: 
	case EMhwlibTVStandard_HDMI_2880x480p59: 
	case EMhwlibTVStandard_HDMI_2880x480p60: 
	case EMhwlibTVStandard_HDMI_2880x576p50: 
	case EMhwlibTVStandard_HDMI_576p100: 
	case EMhwlibTVStandard_HDMI_576i100: 
	case EMhwlibTVStandard_HDMI_1440x576i100: 
	case EMhwlibTVStandard_HDMI_480p119: 
	case EMhwlibTVStandard_HDMI_480p120: 
	case EMhwlibTVStandard_HDMI_480i119: 
	case EMhwlibTVStandard_HDMI_480i120: 
	case EMhwlibTVStandard_HDMI_1440x480i119: 
	case EMhwlibTVStandard_HDMI_1440x480i120: 
	case EMhwlibTVStandard_HDMI_576p200: 
	case EMhwlibTVStandard_HDMI_576i200: 
	case EMhwlibTVStandard_HDMI_1440x576i200: 
	case EMhwlibTVStandard_HDMI_480p239: 
	case EMhwlibTVStandard_HDMI_480p240: 
	case EMhwlibTVStandard_HDMI_480i239: 
	case EMhwlibTVStandard_HDMI_480i240: 
	case EMhwlibTVStandard_HDMI_1440x480i239: 
	case EMhwlibTVStandard_HDMI_1440x480i240: 
		if (hdmi_active) {
			RMDBGLOG((LOCALDBG, "[outports] HDMI active with incompatible mode, disable all analog outputs\n"));
			break;
		}
	default:
		switch (sd_standard) {
		case EMhwlibTVStandard_480p59: 
		case EMhwlibTVStandard_576p50: 
		case EMhwlibTVStandard_480p59_714: 
		case EMhwlibTVStandard_576p50_702: 
		case EMhwlibTVStandard_576p50_704: 
			// no EDTV modes on Composite/S-Video
			break;
		default:
			RMDBGLOG((LOCALDBG, "[outports] Enabling analog SDTV output\n"));
			outport_options.analog.action = DCCOutportState_Enable;
		}
		RMDBGLOG((LOCALDBG, "[outports] Enabling component output\n"));
		outport_options.component.action = DCCOutportState_Enable;
		break;
	}
	if (hdmi_active) {
		RMDBGLOG((LOCALDBG, "[outports] Enabling digital output\n"));
		outport_options.digital.action = DCCOutportState_Enable;
	}
	
	// set up standards
	outport_options.digital.standard = display_options->standard;
	outport_options.analog.standard = sd_standard;
	outport_options.component.standard = (sd_component) ? sd_standard : display_options->standard;
	
	// match digital vs. analog modes
	for (i = 0; i < sizeof(hdmi_cav_match) / sizeof(hdmi_cav_match[0]); i++) {
		if (display_options->standard == hdmi_cav_match[i][0]) {
			// Analog equivalent on component, if not '-sdcav'
			if (! sd_component) {
				RMDBGLOG((LOCALDBG, "[outports] Found analog equivalent of digital mode\n"));
				outport_options.component.standard = hdmi_cav_match[i][1];
				if (! hdmi_active) {  // use 4X modes if HDMI is not active
					switch (outport_options.component.standard) {
#ifdef RMFEATURE_HAS_DOUBLE_RATE
					case EMhwlibTVStandard_HDMI_480i59:
						outport_options.component.standard = EMhwlibTVStandard_NTSC_M;
						break;
					case EMhwlibTVStandard_HDMI_576i50:
						outport_options.component.standard = EMhwlibTVStandard_PAL_BG;
						break;
#endif
					case EMhwlibTVStandard_HDMI_480p59:
						outport_options.component.standard = EMhwlibTVStandard_480p59;
						break;
					case EMhwlibTVStandard_HDMI_576p50:
						outport_options.component.standard = EMhwlibTVStandard_576p50;
						break;
					default:
						break;
					}
				}  // TODO: else, HDMI_xxx modes on analog don't carry a sync, needs to be fixed!
			}
			handled = TRUE;
			break;
		} else if (display_options->standard == hdmi_cav_match[i][1]) {
			// Digital equivalent on HDMI
			RMDBGLOG((LOCALDBG, "[outports] Found digital equivalent of analog mode\n"));
			outport_options.digital.standard = hdmi_cav_match[i][0];
			handled = TRUE;
			break;
		}
	}
	
	// no equivalent mode found, try to match with similar mode
	if (! handled) {
		switch (display_options->standard) {
		
		// Component only mode, no immediate digital equivalent
		case EMhwlibTVStandard_1080i48: 
			outport_options.digital.standard = EMhwlibTVStandard_HDMI_1080p24;
			if (0) 
		case EMhwlibTVStandard_1080i47: 
			outport_options.digital.standard = EMhwlibTVStandard_HDMI_1080p23;
			if (0) 
		case EMhwlibTVStandard_1080i50_1250: 
			outport_options.digital.standard = EMhwlibTVStandard_HDMI_1080i50;
			if (0) 
		case EMhwlibTVStandard_1080p50_1250: 
			outport_options.digital.standard = EMhwlibTVStandard_HDMI_1080p50;
			if (0) 
		case EMhwlibTVStandard_720p30: 
		case EMhwlibTVStandard_720p29: 
		case EMhwlibTVStandard_720p24: 
		case EMhwlibTVStandard_720p23: 
		case EMhwlibTVStandard_720p25: 
			outport_options.digital.standard = EMhwlibTVStandard_HDMI_720p50;
			if (0) 
		case EMhwlibTVStandard_480p59_714: 
			outport_options.digital.standard = EMhwlibTVStandard_HDMI_480p59;
			if (0) 
		case EMhwlibTVStandard_576p50_702: 
		case EMhwlibTVStandard_576p50_704: 
			outport_options.digital.standard = EMhwlibTVStandard_HDMI_576p50;
			// common switch statement:
			if (hdmi_active && ! sd_component) {
				// conflict: set target mode on component, SDTV on analog, and disable HDMI
				RMDBGLOG((LOCALDBG, "[outports] Disabling digital output, due to incompatible analog mode\n"));
				outport_options.digital.action = DCCOutportState_Disable;
				hdmi_active = FALSE;
			}
			// otherwise, no conflict: equivalent mode on HDMI, SDTV on component and analog, 
			// or target mode on component, SDTV on analog, no HDMI
			break;
		
#ifdef RMFEATURE_HAS_DOUBLE_RATE
		// 59.94 Hz SDTV mode, 480i on HDMI, SDTV on component
		case EMhwlibTVStandard_ITU_Bt656_525: 
		case EMhwlibTVStandard_ITU_Bt656_240p: 
		case EMhwlibTVStandard_NTSC_M_Japan: 
		case EMhwlibTVStandard_NTSC_M: 
		case EMhwlibTVStandard_PAL_60: 
		case EMhwlibTVStandard_PAL_M: 
		case EMhwlibTVStandard_NTSC_M_Japan_714: 
		case EMhwlibTVStandard_NTSC_M_714: 
		case EMhwlibTVStandard_PAL_60_714: 
		case EMhwlibTVStandard_PAL_M_714: 
			RMDBGLOG((LOCALDBG, "[outports] Selecting digital mode 480i\n"));
			outport_options.digital.standard = EMhwlibTVStandard_HDMI_480i59;
			if (! sd_component) {
				outport_options.analog.standard = outport_options.component.standard;
			}
			break;
		
		// 50 Hz SDTV mode, 576i on HDMI, SDTV on component
		case EMhwlibTVStandard_ITU_Bt656_625: 
		case EMhwlibTVStandard_ITU_Bt656_288p: 
		case EMhwlibTVStandard_PAL_BG: 
		case EMhwlibTVStandard_PAL_N: 
		case EMhwlibTVStandard_PAL_BG_702: 
		case EMhwlibTVStandard_PAL_N_702: 
		case EMhwlibTVStandard_PAL_BG_704: 
		case EMhwlibTVStandard_PAL_N_704: 
			RMDBGLOG((LOCALDBG, "[outports] Selecting digital mode 576i\n"));
			outport_options.digital.standard = EMhwlibTVStandard_HDMI_576i50;
			if (! sd_component) {
				outport_options.analog.standard = outport_options.component.standard;
			}
			break;
#endif
		
		// No analog equivalent, force '-sdcav'
		default:
			switch (display_options->connector) {
			case DCCVideoConnector_SVIDEO:
			case DCCVideoConnector_DVI:
			case DCCVideoConnector_LVDS:
			case DCCVideoConnector_Digital:
			case DCCVideoConnector_SCART:
			case DCCVideoConnector_COMPONENT:
			case DCCVideoConnector_COMPOSITE:
				RMDBGLOG((LOCALDBG, "[outports] No compatible analog mode found, using SDTV mode\n"));
				outport_options.component.standard = outport_options.analog.standard;
				sd_component = TRUE;
				break;
			default:
				RMDBGLOG((LOCALDBG, "[outports] No compatible analog mode found, probably VESA.\n"));
				break;
			}
		}
	}
	
	// omit 1080p resolutions on component output
	if ((! display_options->sd_cav_1080p) && (! sd_component)) {
		switch (outport_options.component.standard) {
		case EMhwlibTVStandard_1080p59:
		case EMhwlibTVStandard_1080p60:
		case EMhwlibTVStandard_1080p50:
		case EMhwlibTVStandard_1080p23:
		case EMhwlibTVStandard_1080p24:
		case EMhwlibTVStandard_1080p25:
		case EMhwlibTVStandard_1080p29:
		case EMhwlibTVStandard_1080p30:
			// component 1080p not allowed (no '-hdcav'), force '-sdcav'
			RMDBGLOG((LOCALDBG, "[outports] Prohibiting 1080p on analog output\n"));
			outport_options.component.standard = outport_options.analog.standard;
			sd_component = TRUE;
			break;
		default:
			break;
		}
	}
	
	// Set SDTV mode based on frame rate of HDTV mode
	if (sd_autodetect) {
		struct EMhwlibTVFormatDigital fmt_d;
		enum EMhwlibTVStandard std;
		RMuint32 pix_per_field, pix_clk, vfreq;
		
		if (hdmi_active) {
			std = outport_options.digital.standard;
		} else {
			std = outport_options.component.standard;
		}
		RUAExchangeProperty(dcc_info->pRUA, DisplayBlock, 
			RMDisplayBlockPropertyID_TVFormatDigital, 
			&(std), sizeof(std), 
			&fmt_d, sizeof(fmt_d));
		pix_per_field = fmt_d.HTotalSize * (fmt_d.Progressive ? fmt_d.VTotalSize : (fmt_d.VTotalSize / 2));
		pix_clk = fmt_d.PixelClock;
		vfreq = (pix_clk + (pix_per_field / 2)) / pix_per_field;
		if ((vfreq == 50) || (vfreq == 25)) {  // 50 Hz mode
			RMDBGLOG((LOCALDBG, "[outports] Detected 50 Hz, adjusting SDTV mode\n"));
			sd_standard = display_options->sd_standard_50Hz;
		} else {  // 59.94 or 60 Hz mode
			RMDBGLOG((LOCALDBG, "[outports] Detected 60 Hz, adjusting SDTV mode\n"));
			sd_standard = display_options->sd_standard_60Hz;
		}
		// Change component mode as well, if same as analog mode
		if (sd_component) {
			RMDBGLOG((LOCALDBG, "[outports] adjusting component mode to SDTV mode\n"));
			outport_options.component.standard = sd_standard;
		}
		outport_options.analog.standard = sd_standard;
	}
	
#ifdef RMFEATURE_HAS_DUAL_MAINANALOGOUT
	// make analog same as component, they share a hardware block
	if ((! sd_component) && (outport_options.analog.standard != outport_options.component.standard)) {
		RMDBGLOG((LOCALDBG, "[outports] Dual analog output, disable analog due to different mode than component\n"));
		outport_options.analog.action = DCCOutportState_Disable;
		//outport_options.analog.standard = outport_options.component.standard;
		//display_options->sd_ar_x = display_options->ar_x;
		//display_options->sd_ar_y = display_options->ar_y;
		//display_options->sd_active_format_valid = display_options->active_format_valid;
		//display_options->sd_active_format = display_options->active_format;
	}
#endif
	
	// enforce HD-to-SD limitations
	if (
		((dcc_info->route == DCCRoute_ColorBars) || (! display_options->use_hdsd_conversion)) && 
		(hdmi_active || (outport_options.analog.standard != outport_options.component.standard))
	) {
		RMDBGLOG((LOCALDBG, "[outports] Disabling SDTV outputs, HD-to-SD prohibited or Color Bars\n"));
		outport_options.analog.action = DCCOutportState_Disable;
		if (sd_component) {
			outport_options.component.action = DCCOutportState_Disable;
		}
	}
	
	// Translate display_options to outport_options
	outport_options.global.allow_otf = display_options->allow_otf;
	outport_options.global.allow_buf = display_options->allow_buf;
	outport_options.analog.ar_x = display_options->sd_ar_x;
	outport_options.analog.ar_y = display_options->sd_ar_y;
	outport_options.analog.active_format_valid = display_options->sd_active_format_valid;
	outport_options.analog.active_format = display_options->sd_active_format;
	outport_options.analog.afd_used = TRUE;
	outport_options.analog.wss_used = FALSE;
	if (sd_component) {
		RMDBGLOG((LOCALDBG, "[outports] Using SD aspect ratio for component output\n"));
		outport_options.component.ar_x = display_options->sd_ar_x;
		outport_options.component.ar_y = display_options->sd_ar_y;
		outport_options.component.active_format_valid = display_options->sd_active_format_valid;
		outport_options.component.active_format = display_options->sd_active_format;
	} else {
		RMDBGLOG((LOCALDBG, "[outports] Using HD aspect ratio for component output\n"));
		outport_options.component.ar_x = display_options->ar_x;
		outport_options.component.ar_y = display_options->ar_y;
		outport_options.component.active_format_valid = display_options->active_format_valid;
		outport_options.component.active_format = display_options->active_format;
	}
	outport_options.component.afd_used = TRUE;
	outport_options.component.wss_used = FALSE;
	outport_options.digital.ar_x = display_options->ar_x;
	outport_options.digital.ar_y = display_options->ar_y;
	outport_options.digital.active_format_valid = display_options->active_format_valid;
	outport_options.digital.active_format = display_options->active_format;
	outport_options.digital.afd_used = TRUE;
	outport_options.digital.wss_used = FALSE;
	
	outport_options.analog.route = dcc_info->route;
	outport_options.component.route = dcc_info->route;
	outport_options.digital.route = dcc_info->route;
	
	outport_options.analog.agc_level = display_options->agc_level;
	outport_options.component.agc_level = display_options->agc_level;
	outport_options.digital.agc_level = display_options->agc_level;
	
	outport_options.analog.agc_version = display_options->agc_version;
	outport_options.component.agc_version = display_options->agc_version;
	outport_options.digital.agc_version = display_options->agc_version;
	
	outport_options.analog.aps_level = display_options->aps_level;
	outport_options.component.aps_level = display_options->aps_level;
	outport_options.digital.aps_level = display_options->aps_level;
	
	outport_options.analog.cgmsa = display_options->cgmsa;
	outport_options.component.cgmsa = display_options->cgmsa;
	outport_options.digital.cgmsa = display_options->cgmsa;
	
	outport_options.analog.rcd = display_options->rcd;
	outport_options.component.rcd = display_options->rcd;
	outport_options.digital.rcd = display_options->rcd;
	
	outport_options.analog.asb = display_options->asb;
	outport_options.component.asb = display_options->asb;
	outport_options.digital.asb = display_options->asb;
	
	outport_options.analog.color_space = EMhwlibColorSpace_YUV_601;
	if (sd_component) {
		outport_options.component.color_space = outport_options.analog.color_space;
	} else {
		switch (outport_options.component.standard) {
		case EMhwlibTVStandard_NTSC_M_Japan: 
		case EMhwlibTVStandard_NTSC_M: 
		case EMhwlibTVStandard_PAL_60: 
		case EMhwlibTVStandard_PAL_M: 
		case EMhwlibTVStandard_480p59: 
		case EMhwlibTVStandard_NTSC_M_Japan_714: 
		case EMhwlibTVStandard_NTSC_M_714: 
		case EMhwlibTVStandard_PAL_60_714: 
		case EMhwlibTVStandard_PAL_M_714: 
		case EMhwlibTVStandard_480p59_714: 
		case EMhwlibTVStandard_ITU_Bt656_625: 
		case EMhwlibTVStandard_ITU_Bt656_288p: 
		case EMhwlibTVStandard_PAL_BG: 
		case EMhwlibTVStandard_PAL_N: 
		case EMhwlibTVStandard_576p50: 
		case EMhwlibTVStandard_PAL_BG_702: 
		case EMhwlibTVStandard_PAL_N_702: 
		case EMhwlibTVStandard_576p50_702: 
		case EMhwlibTVStandard_PAL_BG_704: 
		case EMhwlibTVStandard_PAL_N_704: 
		case EMhwlibTVStandard_576p50_704: 
			RMDBGLOG((LOCALDBG, "[outports] Component: selecting Bt.601 color space\n"));
			outport_options.component.color_space = EMhwlibColorSpace_YUV_601;
			break;
		default:
			RMDBGLOG((LOCALDBG, "[outports] Component: selecting Bt.709 color space\n"));
			outport_options.component.color_space = EMhwlibColorSpace_YUV_709;
		}
	}
	outport_options.digital.color_space = display_options->color_space;
	
	outport_options.analog.component_order = display_options->component_order;
	outport_options.component.component_order = display_options->component_order;
	outport_options.digital.component_order = display_options->component_order;
	outport_options.component.component_mode = display_options->component;
	outport_options.component.valid_component_mode = TRUE;
	
	outport_options.digital.bus_size = display_options->bus_size;
	outport_options.digital.digital_protocol = display_options->dig_protocol;
	outport_options.digital.dvi_hdmi_state = display_options->dh_info->dvi_hdmi_state;
	outport_options.digital.dvi_hdmi_part = display_options->dvi_hdmi_part;
	outport_options.digital.dvi_hdmi_hdcp = display_options->dvi_hdmi_hdcp;
	outport_options.digital.hdmi_monitor = display_options->hdmi_monitor;
	outport_options.digital.hdmi_force = TRUE;
	outport_options.digital.dvi_hdmi_edid_file = NULL;
	outport_options.digital.i2c_module = display_options->i2c_module;
	outport_options.digital.i2c_speed = display_options->i2c_speed;
	outport_options.digital.i2c_ddc_on_tx = display_options->i2c_ddc_on_tx;
	outport_options.digital.dvi_reset_gpio = display_options->dvi_reset_gpio;
	outport_options.digital.hdmi_de = display_options->hdmi_de;
	outport_options.digital.hdmi_active_format = display_options->hdmi_active_format;
	outport_options.digital.hdmi_bar_top = display_options->hdmi_bar_top;
	outport_options.digital.hdmi_bar_bottom = display_options->hdmi_bar_bottom;
	outport_options.digital.hdmi_bar_left = display_options->hdmi_bar_left;
	outport_options.digital.hdmi_bar_right = display_options->hdmi_bar_right;
	outport_options.digital.hdmi_scan = display_options->hdmi_scan;
	outport_options.digital.use_active_format = display_options->hdmi_active_format_valid;
	outport_options.digital.hdmi_spd_vendor = display_options->hdmi_spd_vendor;
	outport_options.digital.hdmi_spd_product = display_options->hdmi_spd_product;
	outport_options.digital.hdmi_spd_class = display_options->hdmi_spd_class;
	outport_options.digital.tmds_threshold = display_options->tmds_threshold;
	outport_options.digital.tmds_gpio = display_options->tmds_gpio;
	outport_options.digital.dig_clk_normal = display_options->dig_clk_normal;
	outport_options.digital.dig_ddr = display_options->dig_ddr;
	outport_options.digital.dig_inv_cap_clk = display_options->dig_inv_cap_clk;
	outport_options.digital.dig_delay = display_options->dig_delay;
	outport_options.digital.dig_force_delay = display_options->dig_force_delay;
	outport_options.digital.dig_vsync_delay = display_options->dig_vsync_delay;
	outport_options.digital.dig_trailing_edge = display_options->dig_trailing_edge;
	
	outport_options.component.filter_gpio_start = display_options->filter_gpio_start;
	outport_options.component.filter_gpio_num = display_options->filter_gpio_num;
	outport_options.component.filter_gpio_val = display_options->filter_gpio_val;
	
	outport_options.analog.chroma_sync = display_options->chroma_sync;
	outport_options.component.chroma_sync = display_options->chroma_sync;
	
	outport_options.analog.scart_enable = display_options->scart_enable;
	outport_options.component.scart_enable = display_options->scart_enable;
	outport_options.analog.scart_en_pio = display_options->scart_en_pio;
	outport_options.component.scart_en_pio = display_options->scart_en_pio;
	outport_options.analog.scart_widescreen = display_options->scart_widescreen;
	outport_options.component.scart_widescreen = display_options->scart_widescreen;
	outport_options.analog.scart_ws_pio = display_options->scart_ws_pio;
	outport_options.component.scart_ws_pio = display_options->scart_ws_pio;
	
	outport_options.analog.force_DACCompDisable = display_options->force_DACCompDisable;
	outport_options.component.force_DACCompDisable = display_options->force_DACCompDisable;
	outport_options.analog.DACCompDisable = display_options->DACCompDisable;
	outport_options.component.DACCompDisable = display_options->DACCompDisable;
	outport_options.analog.force_DACDisable = display_options->force_DACDisable;
	outport_options.component.force_DACDisable = display_options->force_DACDisable;
	outport_options.analog.DACDisable = display_options->DACDisable;
	outport_options.component.DACDisable = display_options->DACDisable;
	outport_options.analog.force_LumaChromaDelay = display_options->force_LumaChromaDelay;
	outport_options.component.force_LumaChromaDelay = display_options->force_LumaChromaDelay;
	outport_options.analog.LumaChromaDelay = display_options->LumaChromaDelay;
	outport_options.component.LumaChromaDelay = display_options->LumaChromaDelay;
	outport_options.analog.force_TripleCVBS = display_options->force_TripleCVBS;
	outport_options.component.force_TripleCVBS = display_options->force_TripleCVBS;
	outport_options.analog.TripleCVBS = display_options->TripleCVBS;
	outport_options.component.TripleCVBS = display_options->TripleCVBS;
	outport_options.analog.force_LineCrop = display_options->force_LineCrop;
	outport_options.component.force_LineCrop = display_options->force_LineCrop;
	outport_options.analog.LineCrop = display_options->LineCrop;
	outport_options.component.LineCrop = display_options->LineCrop;
	
	outport_options.analog.dh_info = display_options->dh_info;
	outport_options.component.dh_info = display_options->dh_info;
	outport_options.digital.dh_info = display_options->dh_info;
	
	GetTVStandardName(outport_options.analog.standard, &StandardNameCVBS);
	GetTVStandardName(outport_options.component.standard, &StandardNameCAV);
	GetTVStandardName(outport_options.digital.standard, &StandardNameHDMI);
	RMDBGLOG((ENABLE, "Applying outports options - HDMI=\"%s\", CAV=\"%s\", CVBS=\"%s\"\n", 
		(outport_options.digital.action == DCCOutportState_Enable) ? StandardNameHDMI : "NONE", 
		(outport_options.component.action == DCCOutportState_Enable) ? StandardNameCAV : "NONE", 
		(outport_options.analog.action == DCCOutportState_Enable) ? StandardNameCVBS : "NONE"));
	
	return apply_outports_options(dcc_info->pDCC, &outport_options);
}

static RMstatus init_dvi_hdmi_chip(struct display_cmdline *options)
{
	RMstatus err;
	
	err = DHSetTMDSMode(options->dh_info->pDH, 
		options->tmds_gpio,
		options->tmds_threshold * 1000000);
	err = DHSetEDIDMode(options->dh_info->pDH, 
		options->edid_sel, 
		options->dvi_hdmi_edid_descriptor, 
		options->dvi_hdmi_edid_vfreq, 
		options->dvi_hdmi_edid_hsize, 
		options->dvi_hdmi_edid_vsize, 
		options->dvi_hdmi_edid_intl);
	
	options->edid_exclude_mask |= options->edid_exclude_mask_vfreq;
	options->edid_exclude_mask |= options->edid_exclude_mask_asp;
	err = DHSetEDIDExcludeMask(options->dh_info->pDH, 
		options->edid_exclude_mask);
	
	if (options->edid_force_mask_vfreq) {
		if (options->edid_force_mask) {
			options->edid_force_mask &= options->edid_force_mask_vfreq;
		} else {
			options->edid_force_mask = options->edid_force_mask_vfreq;
		}
	}
	if (options->edid_force_mask_asp) {
		if (options->edid_force_mask) {
			options->edid_force_mask &= options->edid_force_mask_asp;
		} else {
			options->edid_force_mask = options->edid_force_mask_asp;
		}
	}
	err = DHSetEDIDForceMask(options->dh_info->pDH, 
		options->edid_force_mask);
	err = DHSetEDIDFrequencyLimits(options->dh_info->pDH, 
		options->edid_max_pixclk, 
		options->edid_min_pixclk, 
		options->edid_max_hfreq, 
		options->edid_min_hfreq, 
		options->edid_max_vfreq, 
		options->edid_min_vfreq);
	
	DHSetEDID(options->dh_info->pDH, NULL, 0);  // don't override EDID
	if (options->dvi_hdmi_edid_file) {
		if (options->dvi_hdmi_edid_override) {
			err = force_edid_file(options);  // use content of a file instead of display's EDID
		} else {
			if (options->dvi_hdmi_edid_write) {
				err = upload_edid_file(options);  // program content of a file into display's EDID EEPROM
			} else if (options->dvi_hdmi_edid_read) {
				err = download_edid_file(options);  // read display's EDID into a file
			}
		}
	}
	
	if (options->dvi_hdmi_display_edid) {
		display_edid(options);
	}
	
	return RM_OK;
}

static RMstatus setup_dvi_chip(struct dcc_context *dcc_info, struct display_cmdline *options)
{
	RMstatus err = RM_OK;
	RMuint32 i;
	
	if (options->dh_info->pDH == NULL) {
		struct DH_DriverOptions DriverOptions = {
			APIVersion: 4, 
			AutoRiCheckEnable: TRUE,  // need to enable, since update_hdmi() is not called on every VSync
			ReReadEDIDEnable: TRUE,  // enable additional safe-guard against missing short hot plug pulses
			TMDSPLL480p: {0x98, 0x33, 0x00}, 
			TMDSPLL720p: {0x59, 0x19, 0x00}, 
			TMDSPLL1080p: {0x1B, 0x18, 0x01}, 
			DummyReadKSVFIFO: TRUE, 
			HDCPTMDSCycleTimeOut: 0, 
			HDCPKeySyncErrorDelay: FALSE, 
		};
		
		options->dh_info->nDH = 0;
		options->dh_info->DH_sel = 0;
		if ((options->dh_info->dvi_hdmi_part == DH_auto_detect) && (options->dvi_reset_gpio == 0)) {
			err = DHOpenMultipleChips(dcc_info->pRUA, options->dh_info->pDH_array, &(options->dh_info->nDH));
			if (RMFAILED(err)) options->dh_info->nDH = 0;
			if (options->dh_info->nDH > 0) {
				if (options->dh_info->nDH > 1) {
					for (i = 0; i < options->dh_info->nDH; i++) {
						struct DH_HDMI_state HDMIStateProbe;
						HDMIStateProbe.ReceiverSignal = FALSE;
						err = DHCheckHDMI(options->dh_info->pDH_array[i], &HDMIStateProbe);
						if (RMSUCCEEDED(err) && HDMIStateProbe.HotPlugState) {
							options->dh_info->DH_sel = i;
							break;
						}
					}
				}
#ifdef RMFEATURE_HAS_HDMI
				if (options->dh_info->DH_sel == 0) 
					options->i2c_module = 2;
				else 
#endif
					options->i2c_module = 1;
			}
		}
		if (options->dh_info->nDH == 0) {
			err = DHOpenChip(dcc_info->pRUA, options->dh_info->dvi_hdmi_part, FALSE, 
				options->dvi_reset_gpio, 
				options->i2c_module, GPIOId_Sys_0, GPIOId_Sys_1, options->i2c_speed, 
				options->i2c_module, 
				options->i2c_ddc_on_tx ? GPIOId_Sys_0 : GPIOId_Sys_2, 
				options->i2c_ddc_on_tx ? GPIOId_Sys_1 : GPIOId_Sys_3, 
				options->i2c_speed, 
				&(options->dh_info->pDH));
			options->dh_info->nDH = 1;
			options->dh_info->pDH_array[0] = options->dh_info->pDH;
		}
		if (RMFAILED(err)) {
			if (! manutest) fprintf(stderr, "Cannot connect to DVI/HDMI chip!!!!\n");
			return err;
		}
		if (! manutest) fprintf(stderr, "\n\n\nSelecting HDMI chip #%lu of %lu\n\n\n\n", options->dh_info->DH_sel, options->dh_info->nDH);
		options->dh_info->dvi_hdmi_state = DH_disabled;
		RMDBGLOG((LOCALDBG, "DCC-HDCP State is now: DISABLED\n"));
		
		for (i = 0; i < options->dh_info->nDH; i++) {
			options->dh_info->pDH = options->dh_info->pDH_array[i];
			DHConfigure(options->dh_info->pDH, &DriverOptions);
		}
		options->dh_info->pDH = options->dh_info->pDH_array[options->dh_info->DH_sel];
		set_up_pads(dcc_info, options);
		DHSetDDRMode(options->dh_info->pDH, options->dig_ddr);
	} else {
		err = DHGetState(options->dh_info->pDH, 
			&(options->dh_info->dvi_hdmi_state), 
			&(options->dh_info->dvi_hdmi_cable));
	}
	
	return err;
}

static RMstatus init_dvi_hdmi(struct dcc_context *dcc_info, struct display_cmdline *options)
{
	RMstatus err;
	RMuint32 i;
	
	err = setup_dvi_chip(dcc_info, options);
	if (RMFAILED(err)) return err;
	
	for (i = 0; i < options->dh_info->nDH; i++) {
		options->dh_info->pDH = options->dh_info->pDH_array[i];
		init_dvi_hdmi_chip(options);
	}
	options->dh_info->pDH = options->dh_info->pDH_array[options->dh_info->DH_sel];
	
	return RM_OK;
}

static RMstatus apply_dvi_hdmi(struct dcc_context *dcc_info, struct display_cmdline *options)
{
	RMstatus err;
	
	if (options->dh_info->pDH == NULL) {
		init_dvi_hdmi(dcc_info, options);
	}
	
	// Prepare HDCP (content protection)
	apply_hdcp(dcc_info, options);
	
	RMDBGLOG((LOCALDBG, "INITIAL update_hdmi()\n"));
	options->dh_first_run = TRUE;
	update_hdmi(dcc_info, options, NULL);
	
	if (options->dh_info->dvi_hdmi_state != DH_disabled) {
		err = DHCheckHDCPKeyMem(options->dh_info->pDH);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "ERROR: HDCP key memory failure!!!\n"));
		} else {
			RMDBGLOG((ENABLE, "HDCP key memory OK\n"));
		}
	}
	
	return RM_OK;
}

static RMstatus enable_lvds_panel(struct dcc_context *dcc_info, struct display_cmdline *options)
{
	// These GPIO pin numbers depend on the board, be careful!
	{  // enable Field ID output on GPIO 11 to the LVDS Parity line
		struct DispDigitalOut_GPIOFieldID_type GPIOFieldID;
		GPIOFieldID.GPIONumber = 11;
		GPIOFieldID.Delay = 5400;
		DCCSPERR(dcc_info->pRUA, DispDigitalOut, RMDispDigitalOutPropertyID_GPIOFieldID, &GPIOFieldID, sizeof(GPIOFieldID), "Cannot set GPIO Field ID on digital out");
		if (GPIOFieldID.Delay) 
			RMDBGPRINT((ENABLE, "Field ID on GPIO %ld after %ld ticks\n", GPIOFieldID.GPIONumber, GPIOFieldID.Delay));
	}
	{  // turn on panel with GPIO 14
		struct SystemBlock_GPIO_type gpio;
		gpio.Bit = GPIOId_Sys_14;
		gpio.Data = TRUE;
		RUASetProperty(dcc_info->pRUA, SystemBlock, RMSystemBlockPropertyID_GPIO, &gpio, sizeof(gpio), 0);
	}
	
	return RM_OK;
}

static RMstatus setup_scart(struct dcc_context *dcc_info, struct display_cmdline *options)
{
	RMstatus err = RM_OK;
	
	if (options->scart_en_pio) {
		enum EMhwlibSCARTWideBitState wideState;
		
		if (options->scart_ws_pio & 0x200) {
			wideState = (options->scart_widescreen) ? EMhwlibSCARTWideState_16_9 : EMhwlibSCARTWideState_4_3;
		} else {
			wideState = EMhwlibSCARTWideState_Auto;
		}
		
		DCCSetSCART(dcc_info->pDCC, dcc_info->route, options->connector, 
			options->scart_enable, 
			(options->scart_en_pio & 0xFF) - 1, 
			(options->scart_en_pio & 0x100) ? TRUE : FALSE, 
			(options->scart_ws_pio & 0xFF) ? ((options->scart_ws_pio & 0xFF) - 1) : (options->scart_en_pio & 0xFF), 
			(options->scart_ws_pio & 0xFF) ? ((options->scart_ws_pio & 0x100) ? TRUE : FALSE) : FALSE, 
			wideState);
	} else {
		if (options->connector == DCCVideoConnector_SCART) {
			DCCSetSCART(dcc_info->pDCC, dcc_info->route, options->connector, 
				TRUE, SCART_ENABLE_GPIO, FALSE, SCART_WIDESCREEN_GPIO, FALSE, EMhwlibSCARTWideState_Auto);
		} else {
			DCCSetSCART(dcc_info->pDCC, dcc_info->route, options->connector, 
				FALSE, 0, FALSE, 0, FALSE, EMhwlibSCARTWideState_Auto);
		}
	}
	
	return err;
}

static RMstatus show_osd_picture(struct dcc_context *dcc_info, struct display_cmdline *options, RMuint32 picture)
{
	RMstatus err = RM_OK;
	
	if (options->osd_pictures[picture].enable) {
		struct DCCOSDProfile osd_profile;
		RMuint32 osd_scaler;
		
		err = DCCGetScalerModuleID(dcc_info->pDCC, options->osd_pictures[picture].route, DCCSurface_OSD, options->osd_pictures[picture].scaler, &(osd_scaler));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot get surface to display OSD source: %s\n", RMstatusToString(err)));
			return RM_ERROR;
		}
		
		/* set lock scaler for OSD */
		options->osd_pictures[picture].lock_scaler = options->lock_scaler;

		/* set up the picture-specific options on the scalers used by the pictures */
		err = apply_osd_pictureX(dcc_info, &(options->osd_pictures[picture]), &osd_profile, &(dcc_info->pOSDSource[picture]), options);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set osd picture\n"));
			return err;
		}
		
		/* set up the generic display options on the scalers used by the pictures */
		
		DCCSPERR(dcc_info->pRUA, osd_scaler, RMGenericPropertyID_ScalerFieldSelection, &(options->field_selection), sizeof(options->field_selection), "Error setting current scaler field selection");
		/* warning: write to dcc_info */
		dcc_info->field_selection = options->field_selection;
		if((osd_profile.ColorMode == EMhwlibColorMode_TrueColor) || 
		   (osd_profile.ColorMode ==  EMhwlibColorMode_TrueColorWithKey)){
			DCCSPERROK(RM_NOT_FOUND, dcc_info->pRUA, osd_scaler, RMGenericPropertyID_ColorDegradationBoundary, &(options->color_degradation_boundary), sizeof(options->color_degradation_boundary), "Cannot set color degradation boundary");
		}
		
		DCCSPERR(dcc_info->pRUA, osd_scaler, RMGenericPropertyID_Validate, NULL, 0, "Cannot validate scaler config");
		if (dcc_info->disp_info != NULL) {
			dcc_info->disp_info->osd_scaler[picture] = osd_scaler;
			dcc_info->disp_info->osd_window[picture] = options->osd_pictures[picture].output_window;
			dcc_info->disp_info->osd_enable[picture] = TRUE;
		}
		if ((picture == 0) && (options->dump_osd_dir != NULL)) {
			
			RMuint32 lutAddr;
			RMDBGLOG((ENABLE, "FOR EXAMPLE, I'm HERE\n"));
			RUAGetProperty(dcc_info->pRUA, osd_scaler, RMGenericPropertyID_LUTAddress, &lutAddr, sizeof(lutAddr));
			dumpBitmapInfo(dcc_info, dcc_info->pOSDSource[0], &osd_profile, lutAddr, options->dump_osd_dir);
			dump_dvi_init(dcc_info, options);
		}
	}
	else {
		dcc_info->pOSDSource[picture] = NULL;
	}
	
	return err;
}

static RMstatus show_hwcursor(struct dcc_context *dcc_info, struct display_cmdline *options, RMuint32 mixer)
{
	RMstatus err;
	enum EMhwlibMixerSourceState state;
	RMuint32 cursor, src_index, mixer_src;
	struct DispHardwareCursor_Size_type cursor_size;
	RMCursorLut cursor_lut;
	
	struct EMhwlibDisplayWindow cursor_window;
	
	RMbool enable;
	cursor = EMHWLIB_MODULE(DispHardwareCursor, 0);
	err = RUAExchangeProperty(dcc_info->pRUA, mixer, RMGenericPropertyID_MixerSourceIndex, &cursor, sizeof(cursor), &src_index, sizeof(src_index));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get cursor index\n"));
		return err;
	}
	mixer_src = EMHWLIB_TARGET_MODULE(mixer, 0 , src_index);
	
	cursor_window.X = 720;
	cursor_window.Y = 512;
	cursor_window.XPositionMode = EMhwlibDisplayWindowPositionMode_RearEdgeToBorder;
	cursor_window.YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
	cursor_window.XMode = EMhwlibDisplayWindowValueMode_Relative;
	cursor_window.YMode = EMhwlibDisplayWindowValueMode_Relative;
	
	DCCSPERR(dcc_info->pRUA, mixer_src, RMGenericPropertyID_MixerSourceWindow, &cursor_window, sizeof(cursor_window), "Cannot set cursor window");
	
	state = EMhwlibMixerSourceState_Master;
	err =  RUASetProperty(dcc_info->pRUA, mixer_src, RMGenericPropertyID_MixerSourceState, &state, sizeof(state), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set cursor's state on mixer\n"));
		return err;
	}
	
	DCCSPERR(dcc_info->pRUA, mixer, RMGenericPropertyID_Validate, NULL, 0, "Cannot RMGenericPropertyID_Validate mixer");
	
	enable = TRUE;
	err =  RUASetProperty(dcc_info->pRUA, cursor, RMGenericPropertyID_Enable, &enable, sizeof(enable), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot enable cursor\n"));
		return err;
	}
	
	err =  RUASetProperty(dcc_info->pRUA, cursor,  RMDispHardwareCursorPropertyID_Bitmap , sigma_logo, 64*10, 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set cursor bitmap\n"));
		return err;
	}
	cursor_lut[0] = 0x0;
	cursor_lut[1] = 0xfc801080;
	cursor_lut[2] = 0xfcfc8000;
	
	err =  RUASetProperty(dcc_info->pRUA, cursor,  RMDispHardwareCursorPropertyID_Lut ,(RMuint32 *) &cursor_lut, sizeof(cursor_lut), 0);
	
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot set cursor lut\n"));
		return err;
	}
	cursor_size.Width = 64;
	cursor_size.Height = 20;
	err =  RUASetProperty(dcc_info->pRUA, cursor,  RMDispHardwareCursorPropertyID_Size , &cursor_size, sizeof(cursor_size), 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set cursor size %ld\n",err ));
		return err;
	}
	
	err =  RUASetProperty(dcc_info->pRUA, cursor,  RMGenericPropertyID_Validate , NULL, 0, 0);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot validate cursor\n"));
		return err;
	}
	
	return err;
}

static RMstatus surface_basic_setup(struct dcc_context *dcc_info, struct display_cmdline *options, RMuint32 mixer)
{
	RMstatus err;
	RMuint32 mixer_src, src_index;
	enum EMhwlibMixerSourceState state;
	
	DCCSPERR(dcc_info->pRUA, dcc_info->SurfaceID, RMGenericPropertyID_ScalerInputWindow, &(options->source_window), sizeof(options->source_window), "Cannot set scaler input window on video surface");
	DCCSPERROK(RM_INVALIDMODE, dcc_info->pRUA, dcc_info->SurfaceID, RMGenericPropertyID_ScalerFieldSelection, &(options->field_selection), sizeof(options->field_selection), "Error setting current scaler field selection");
	/* warning: write to dcc_info */
	dcc_info->field_selection = options->field_selection;
	
	DCCSPERROK(RM_INVALIDMODE, dcc_info->pRUA, dcc_info->SurfaceID, RMGenericPropertyID_NonLinearScalingMode, &options->nonlinearmode, sizeof(options->nonlinearmode), "Error setting current scaler non-linear selection");
	DCCSPERROK(RM_INVALIDMODE, dcc_info->pRUA, dcc_info->SurfaceID, RMGenericPropertyID_BlackStripMode, &options->blackstrip, sizeof(options->blackstrip), "Error setting current scaler blackstrip mode");
	DCCSPERROK(RM_INVALIDMODE, dcc_info->pRUA, dcc_info->SurfaceID, RMGenericPropertyID_CutStripMode, &options->cutstrip, sizeof(options->cutstrip), "Error setting current scaler cutstrip mode");
	DCCSPERROK(RM_INVALIDMODE, dcc_info->pRUA, dcc_info->SurfaceID, RMGenericPropertyID_ScalingMode, &(options->scalingmode), sizeof(options->scalingmode), "Cannot set scaling mode");
	{	/* down scaling for main and crt vct gfx only */
		enum RMcategoryID surface_category = EMHWLIB_MODULE_CATEGORY(dcc_info->SurfaceID);
		if( surface_category==DispMainVideoScaler 
		 || surface_category==DispVCRMultiScaler
		 || surface_category==DispCRTMultiScaler
		 || surface_category==DispGFXMultiScaler )
			DCCSPERR(dcc_info->pRUA, dcc_info->SurfaceID, RMGenericPropertyID_DownScalingMode, &(options->downscalingmode), sizeof(options->downscalingmode), "Cannot set scaler input window on video surface");
	}
	if (options->deinterlacingmode == EMhwlibDeinterlacingMode_MotionAdaptative) {
		struct DispMainMixer_LayerOrder_type layer;
		RMuint32 deinterlacing_scaler;
		RMbool enable = TRUE;
		
		layer.Layer0SourceModuleID = EMHWLIB_MODULE(DispCRTMultiScaler, 0);
		layer.Layer1SourceModuleID = EMHWLIB_MODULE(DispVCRMultiScaler, 0);
		layer.Layer2SourceModuleID = EMHWLIB_MODULE(DispGFXMultiScaler, 0);
		layer.Layer3SourceModuleID = EMHWLIB_MODULE(DispMainVideoScaler, 0);
		layer.Layer4SourceModuleID = EMHWLIB_MODULE(DispOSDScaler, 0);
		layer.Layer5SourceModuleID = EMHWLIB_MODULE(DispSubPictureScaler, 0);
		layer.Layer6SourceModuleID = EMHWLIB_MODULE(DispGraphicInput, 0);
		DCCSPERR(dcc_info->pRUA, DispMainMixer, RMDispMainMixerPropertyID_LayerOrder, &layer, sizeof(layer), "Cannot set layer order (for deinterlacing type 2)");
 
		/* TODO: leave the choice of the deinterlacing scaler to the user */
		deinterlacing_scaler = EMHWLIB_MODULE(DispGFXMultiScaler, 0);

		DCCSPERR(dcc_info->pRUA, deinterlacing_scaler, RMGenericPropertyID_Enable, &enable, sizeof(enable), "Cannot enable scaler");
		DCCSPERR(dcc_info->pRUA, deinterlacing_scaler, RMGenericPropertyID_Validate, NULL, 0, "Cannot Validate mixer");

		err = RUAExchangeProperty(dcc_info->pRUA, mixer, RMGenericPropertyID_MixerSourceIndex, &(deinterlacing_scaler), sizeof(deinterlacing_scaler), &src_index, sizeof(src_index));
		if (err != RM_OK) {
			RMDBGLOG((ENABLE, "Cannot get scaler index: %s\n", RMstatusToString(err)));
			return err;
		}
		mixer_src = EMHWLIB_TARGET_MODULE(EMHWLIB_MODULE_CATEGORY(mixer), 0 , src_index);
		
		/* the deinterlacing scaler MUST be set as slave in the mixer */
		state = EMhwlibMixerSourceState_Slave;
		DCCSPERR(dcc_info->pRUA, mixer_src, RMGenericPropertyID_MixerSourceState, &state, sizeof(state), "Cannot set scaler's state on mixer");
		DCCSPERR(dcc_info->pRUA, mixer, RMGenericPropertyID_Validate, NULL, 0, "Cannot Validate mixer");
		DCCSPERR(dcc_info->pRUA, dcc_info->SurfaceID, RMDispMainVideoScalerPropertyID_DeinterlacingMotionScaler, &deinterlacing_scaler, sizeof(deinterlacing_scaler), "Cannot set scaler's state on mixer");
		DCCSP(dcc_info->pRUA, DispMainVideoScaler, RMDispMainVideoScalerPropertyID_DeinterlacingMotionConfig, &(options->deinterlacing_motion_config), sizeof(options->deinterlacing_motion_config));
		DCCSP(dcc_info->pRUA, DispMainVideoScaler, RMDispMainVideoScalerPropertyID_DeinterlacingProportion, &(options->deinterlacing_proportion), sizeof(options->deinterlacing_proportion));
		DCCSP(dcc_info->pRUA, DispMainVideoScaler, RMGenericPropertyID_Validate, NULL, 0);
	}
	
	DCCSPERROK(RM_INVALIDMODE, dcc_info->pRUA, dcc_info->SurfaceID, RMDispMainVideoScalerPropertyID_DeinterlacingMode, &(options->deinterlacingmode), sizeof(options->deinterlacingmode), "Cannot set deinterlacing mode");
	DCCSPERROK(RM_OK, dcc_info->pRUA, dcc_info->SurfaceID, RMGenericPropertyID_Alpha0, &(options->video_alpha), sizeof(options->video_alpha), "Cannot set luma keying");
	DCCSPERROK(RM_OK, dcc_info->pRUA, dcc_info->SurfaceID, RMGenericPropertyID_LumaKeying, &(options->luma_key), sizeof(options->luma_key), "Cannot set luma keying");
	DCCSPERROK(RM_INVALIDMODE, dcc_info->pRUA, dcc_info->SurfaceID, RMDispMainVideoScalerPropertyID_Enable_3_2_PullDownDetection, &(options->do_pulldown), sizeof(options->do_pulldown), "Cannot enable 3:2 pulldown detection");
	DCCSPERROK(RM_INVALIDMODE, dcc_info->pRUA, dcc_info->SurfaceID, RMGenericPropertyID_DisplayTimeInterval, &(options->time_interval), sizeof(options->time_interval), "Cannot set time interval");
	DCCSPERROK(RM_INVALIDMODE, dcc_info->pRUA, dcc_info->SurfaceID, RMDispMainVideoScalerPropertyID_FilterSelection, &(options->filtermode), sizeof(options->filtermode), "Cannot set deinterlacing mode");

	RMDBGLOG((ENABLE, "Time Interval: %d %lu %lu\n", options->time_interval.Mode, options->time_interval.StartPTSLo, options->time_interval.EndPTSLo)); 
	
	DCCSPERR(dcc_info->pRUA, dcc_info->SurfaceID, RMGenericPropertyID_Validate, NULL, 0, "Cannot validate scaler input window");
	if (mixer) {
		err = RUAExchangeProperty(dcc_info->pRUA, mixer, RMGenericPropertyID_MixerSourceIndex, &(dcc_info->SurfaceID), sizeof(dcc_info->SurfaceID), &src_index, sizeof(src_index));
		if (err != RM_OK) {
			RMDBGLOG((ENABLE, "Cannot get scaler index: %s\n", RMstatusToString(err)));
			return err;
		}
		mixer_src = EMHWLIB_TARGET_MODULE(EMHWLIB_MODULE_CATEGORY(mixer), 0 , src_index);
		
		state = EMhwlibMixerSourceState_Master;
		DCCSPERR(dcc_info->pRUA, mixer_src, RMGenericPropertyID_MixerSourceState, &state, sizeof(state), "Cannot set scaler's state on mixer");
		DCCSPERR(dcc_info->pRUA, mixer_src, RMGenericPropertyID_MixerSourceWindow, &(options->output_window), sizeof(options->output_window), "Cannot set scaler input window");
		DCCSPERR(dcc_info->pRUA, mixer_src, RMGenericPropertyID_LockMixerSourceScalingMode, &(options->lock_scaler), sizeof(options->lock_scaler), "Cannot set lock scaler");
		DCCSPERR(dcc_info->pRUA, mixer, RMGenericPropertyID_Validate, NULL, 0, "Cannot validate scaler input window");
	}
	
	return RM_OK;
}

static RMstatus output_basic_setup(struct dcc_context *dcc_info, struct display_cmdline *options, RMuint32 VideoConnectorModuleID)
{
	RMint8 brightness, hue;
	RMuint8 contrast, saturation;
	RMbool PixelClockVCXOTimer = ! options->disable_pixel_timer;
	
	contrast = 128;
	saturation = 128;
	brightness = 0;
	hue = 0;
	
	if (dcc_info->disp_info != NULL){
		dcc_info->disp_info->contrast = contrast;
		dcc_info->disp_info->saturation = saturation;
		dcc_info->disp_info->brightness = brightness;
		dcc_info->disp_info->hue = hue;
	}
	
 	DCCSP(dcc_info->pRUA, VideoConnectorModuleID, RMGenericPropertyID_Contrast, &(contrast), sizeof(contrast));
 	DCCSP(dcc_info->pRUA, VideoConnectorModuleID, RMGenericPropertyID_CbSaturation, &(saturation), sizeof(saturation));
 	DCCSP(dcc_info->pRUA, VideoConnectorModuleID, RMGenericPropertyID_CrSaturation, &(saturation), sizeof(saturation));
	DCCSP(dcc_info->pRUA, VideoConnectorModuleID, RMGenericPropertyID_Brightness, &(brightness), sizeof(brightness));
	DCCSP(dcc_info->pRUA, VideoConnectorModuleID, RMGenericPropertyID_Hue, &(hue), sizeof(hue));
	if (VideoConnectorModuleID != DispCompositeOut) {
		DCCSP(dcc_info->pRUA, VideoConnectorModuleID, RMGenericPropertyID_ComponentOrder, &(options->component_order), sizeof(options->component_order));
	}
	
	// apply disable_pixel_timer
	DCCSPERR(dcc_info->pRUA, VideoConnectorModuleID, RMGenericPropertyID_PixelClockVCXOTimer, &PixelClockVCXOTimer, sizeof(PixelClockVCXOTimer), "Cannot set PixelClockVCXOTimer");
	
	if (VideoConnectorModuleID != DispDigitalOut) {
		struct EMhwlibCopyControlWithVersion cciset;
		cciset.cci_version = EMhwlibCopyControlVersion_0;
		cciset.cci.agc_version = options->agc_version;
		cciset.cci.agc_level = options->agc_level;
		cciset.cci.aps_level = options->aps_level;
		cciset.cci.cgmsa = options->cgmsa;
		cciset.cci.rcd = options->rcd;
		cciset.cci.asb = options->asb;
		
		RMDBGLOG((LOCALDBG, "set agc=%d aps=%d cgmsa=%d rcd=%d asb=%d\n",
			options->agc_level, options->aps_level, options->cgmsa, options->rcd, options->asb));
		DCCSPERR(dcc_info->pRUA, VideoConnectorModuleID, RMGenericPropertyID_CopyControl, &(cciset), sizeof(cciset), "Cannot set CopyControl");
	}
	
	if ((VideoConnectorModuleID == DispMainAnalogOut) || (VideoConnectorModuleID == DispComponentOut)) {
		if (options->force_DACCompDisable) {
			DCCSPERR(dcc_info->pRUA, VideoConnectorModuleID, RMGenericPropertyID_DACCompDisable, &(options->DACCompDisable), sizeof(options->DACCompDisable), "Cannot set property DACCompDisable");
		}
		DCCSPERR(dcc_info->pRUA, VideoConnectorModuleID, RMGenericPropertyID_SyncOnPbPr, &(options->chroma_sync), sizeof(options->chroma_sync), "Cannot set property SyncOnPbPr");
	}
	
	if (VideoConnectorModuleID == DispDigitalOut) {
		RMbool Enable;
		RMpalette_8BPP gamma_table[] = {
			{
			0x000000, 0x010101, 0x020202, 0x030303, 0x040404, 0x050505, 0x060606, 0x070707,
			0x080808, 0x090909, 0x0A0A0A, 0x0B0B0B, 0x0C0C0C, 0x0D0D0D, 0x0E0E0E, 0x0F0F0F,
			0x101010, 0x111111, 0x121212, 0x131313, 0x141414, 0x151515, 0x161616, 0x171717,
			0x181818, 0x191919, 0x1A1A1A, 0x1B1B1B, 0x1C1C1C, 0x1D1D1D, 0x1E1E1E, 0x1F1F1F,
			0x202020, 0x212121, 0x222222, 0x232323, 0x242424, 0x252525, 0x262626, 0x272727,
			0x282828, 0x292929, 0x2A2A2A, 0x2B2B2B, 0x2C2C2C, 0x2D2D2D, 0x2E2E2E, 0x2F2F2F,
			0x303030, 0x313131, 0x323232, 0x333333, 0x343434, 0x353535, 0x363636, 0x373737,
			0x383838, 0x393939, 0x3A3A3A, 0x3B3B3B, 0x3C3C3C, 0x3D3D3D, 0x3E3E3E, 0x3F3F3F,
			0x404040, 0x414141, 0x424242, 0x434343, 0x444444, 0x454545, 0x464646, 0x474747,
			0x484848, 0x494949, 0x4A4A4A, 0x4B4B4B, 0x4C4C4C, 0x4D4D4D, 0x4E4E4E, 0x4F4F4F,
			0x505050, 0x515151, 0x525252, 0x535353, 0x545454, 0x555555, 0x565656, 0x575757,
			0x585858, 0x595959, 0x5A5A5A, 0x5B5B5B, 0x5C5C5C, 0x5D5D5D, 0x5E5E5E, 0x5F5F5F,
			0x606060, 0x616161, 0x626262, 0x636363, 0x646464, 0x656565, 0x666666, 0x676767,
			0x686868, 0x696969, 0x6A6A6A, 0x6B6B6B, 0x6C6C6C, 0x6D6D6D, 0x6E6E6E, 0x6F6F6F,
			0x707070, 0x717171, 0x727272, 0x737373, 0x747474, 0x757575, 0x767676, 0x777777,
			0x787878, 0x797979, 0x7A7A7A, 0x7B7B7B, 0x7C7C7C, 0x7D7D7D, 0x7E7E7E, 0x7F7F7F,
			0x808080, 0x818181, 0x828282, 0x838383, 0x848484, 0x858585, 0x868686, 0x878787,
			0x888888, 0x898989, 0x8A8A8A, 0x8B8B8B, 0x8C8C8C, 0x8D8D8D, 0x8E8E8E, 0x8F8F8F,
			0x909090, 0x919191, 0x929292, 0x939393, 0x949494, 0x959595, 0x969696, 0x979797,
			0x989898, 0x999999, 0x9A9A9A, 0x9B9B9B, 0x9C9C9C, 0x9D9D9D, 0x9E9E9E, 0x9F9F9F,
			0xA0A0A0, 0xA1A1A1, 0xA2A2A2, 0xA3A3A3, 0xA4A4A4, 0xA5A5A5, 0xA6A6A6, 0xA7A7A7,
			0xA8A8A8, 0xA9A9A9, 0xAAAAAA, 0xABABAB, 0xACACAC, 0xADADAD, 0xAEAEAE, 0xAFAFAF,
			0xB0B0B0, 0xB1B1B1, 0xB2B2B2, 0xB3B3B3, 0xB4B4B4, 0xB5B5B5, 0xB6B6B6, 0xB7B7B7,
			0xB8B8B8, 0xB9B9B9, 0xBABABA, 0xBBBBBB, 0xBCBCBC, 0xBDBDBD, 0xBEBEBE, 0xBFBFBF,
			0xC0C0C0, 0xC1C1C1, 0xC2C2C2, 0xC3C3C3, 0xC4C4C4, 0xC5C5C5, 0xC6C6C6, 0xC7C7C7,
			0xC8C8C8, 0xC9C9C9, 0xCACACA, 0xCBCBCB, 0xCCCCCC, 0xCDCDCD, 0xCECECE, 0xCFCFCF,
			0xD0D0D0, 0xD1D1D1, 0xD2D2D2, 0xD3D3D3, 0xD4D4D4, 0xD5D5D5, 0xD6D6D6, 0xD7D7D7,
			0xD8D8D8, 0xD9D9D9, 0xDADADA, 0xDBDBDB, 0xDCDCDC, 0xDDDDDD, 0xDEDEDE, 0xDFDFDF,
			0xE0E0E0, 0xE1E1E1, 0xE2E2E2, 0xE3E3E3, 0xE4E4E4, 0xE5E5E5, 0xE6E6E6, 0xE7E7E7,
			0xE8E8E8, 0xE9E9E9, 0xEAEAEA, 0xEBEBEB, 0xECECEC, 0xEDEDED, 0xEEEEEE, 0xEFEFEF,
			0xF0F0F0, 0xF1F1F1, 0xF2F2F2, 0xF3F3F3, 0xF4F4F4, 0xF5F5F5, 0xF6F6F6, 0xF7F7F7,
			0xF8F8F8, 0xF9F9F9, 0xFAFAFA, 0xFBFBFB, 0xFCFCFC, 0xFDFDFD, 0xFEFEFE, 0xFFFFFF
			}, 
			{
			0x000000, 0x1C1C1C, 0x252525, 0x2B2B2B, 0x303030, 0x353535, 0x393939, 0x3D3D3D,
			0x404040, 0x434343, 0x464646, 0x494949, 0x4B4B4B, 0x4E4E4E, 0x505050, 0x525252,
			0x545454, 0x565656, 0x585858, 0x5A5A5A, 0x5C5C5C, 0x5E5E5E, 0x606060, 0x616161,
			0x636363, 0x656565, 0x666666, 0x686868, 0x696969, 0x6B6B6B, 0x6C6C6C, 0x6E6E6E,
			0x6F6F6F, 0x717171, 0x727272, 0x737373, 0x757575, 0x767676, 0x777777, 0x787878,
			0x7A7A7A, 0x7B7B7B, 0x7C7C7C, 0x7D7D7D, 0x7E7E7E, 0x7F7F7F, 0x818181, 0x828282,
			0x838383, 0x848484, 0x858585, 0x868686, 0x878787, 0x888888, 0x898989, 0x8A8A8A,
			0x8B8B8B, 0x8C8C8C, 0x8D8D8D, 0x8E8E8E, 0x8F8F8F, 0x909090, 0x919191, 0x929292,
			0x939393, 0x949494, 0x959595, 0x959595, 0x969696, 0x979797, 0x989898, 0x999999,
			0x9A9A9A, 0x9B9B9B, 0x9B9B9B, 0x9C9C9C, 0x9D9D9D, 0x9E9E9E, 0x9F9F9F, 0xA0A0A0,
			0xA0A0A0, 0xA1A1A1, 0xA2A2A2, 0xA3A3A3, 0xA4A4A4, 0xA4A4A4, 0xA5A5A5, 0xA6A6A6,
			0xA7A7A7, 0xA7A7A7, 0xA8A8A8, 0xA9A9A9, 0xAAAAAA, 0xAAAAAA, 0xABABAB, 0xACACAC,
			0xADADAD, 0xADADAD, 0xAEAEAE, 0xAFAFAF, 0xAFAFAF, 0xB0B0B0, 0xB1B1B1, 0xB1B1B1,
			0xB2B2B2, 0xB3B3B3, 0xB3B3B3, 0xB4B4B4, 0xB5B5B5, 0xB6B6B6, 0xB6B6B6, 0xB7B7B7,
			0xB7B7B7, 0xB8B8B8, 0xB9B9B9, 0xB9B9B9, 0xBABABA, 0xBBBBBB, 0xBBBBBB, 0xBCBCBC,
			0xBDBDBD, 0xBDBDBD, 0xBEBEBE, 0xBEBEBE, 0xBFBFBF, 0xC0C0C0, 0xC0C0C0, 0xC1C1C1,
			0xC2C2C2, 0xC2C2C2, 0xC3C3C3, 0xC3C3C3, 0xC4C4C4, 0xC5C5C5, 0xC5C5C5, 0xC6C6C6,
			0xC6C6C6, 0xC7C7C7, 0xC7C7C7, 0xC8C8C8, 0xC9C9C9, 0xC9C9C9, 0xCACACA, 0xCACACA,
			0xCBCBCB, 0xCBCBCB, 0xCCCCCC, 0xCDCDCD, 0xCDCDCD, 0xCECECE, 0xCECECE, 0xCFCFCF,
			0xCFCFCF, 0xD0D0D0, 0xD0D0D0, 0xD1D1D1, 0xD1D1D1, 0xD2D2D2, 0xD3D3D3, 0xD3D3D3,
			0xD4D4D4, 0xD4D4D4, 0xD5D5D5, 0xD5D5D5, 0xD6D6D6, 0xD6D6D6, 0xD7D7D7, 0xD7D7D7,
			0xD8D8D8, 0xD8D8D8, 0xD9D9D9, 0xD9D9D9, 0xDADADA, 0xDADADA, 0xDBDBDB, 0xDBDBDB,
			0xDCDCDC, 0xDCDCDC, 0xDDDDDD, 0xDDDDDD, 0xDEDEDE, 0xDEDEDE, 0xDFDFDF, 0xDFDFDF,
			0xE0E0E0, 0xE0E0E0, 0xE1E1E1, 0xE1E1E1, 0xE2E2E2, 0xE2E2E2, 0xE3E3E3, 0xE3E3E3,
			0xE4E4E4, 0xE4E4E4, 0xE5E5E5, 0xE5E5E5, 0xE6E6E6, 0xE6E6E6, 0xE6E6E6, 0xE7E7E7,
			0xE7E7E7, 0xE8E8E8, 0xE8E8E8, 0xE9E9E9, 0xE9E9E9, 0xEAEAEA, 0xEAEAEA, 0xEBEBEB,
			0xEBEBEB, 0xEBEBEB, 0xECECEC, 0xECECEC, 0xEDEDED, 0xEDEDED, 0xEEEEEE, 0xEEEEEE,
			0xEFEFEF, 0xEFEFEF, 0xF0F0F0, 0xF0F0F0, 0xF0F0F0, 0xF1F1F1, 0xF1F1F1, 0xF2F2F2,
			0xF2F2F2, 0xF3F3F3, 0xF3F3F3, 0xF3F3F3, 0xF4F4F4, 0xF4F4F4, 0xF5F5F5, 0xF5F5F5,
			0xF6F6F6, 0xF6F6F6, 0xF6F6F6, 0xF7F7F7, 0xF7F7F7, 0xF8F8F8, 0xF8F8F8, 0xF8F8F8,
			0xF9F9F9, 0xF9F9F9, 0xFAFAFA, 0xFAFAFA, 0xFBFBFB, 0xFBFBFB, 0xFBFBFB, 0xFCFCFC,
			0xFCFCFC, 0xFDFDFD, 0xFDFDFD, 0xFDFDFD, 0xFEFEFE, 0xFEFEFE, 0xFFFFFF, 0xFFFFFF
			}, 
			{
			0xFFFFFF, 0xFEFEFE, 0xFDFDFD, 0xFCFCFC, 0xFBFBFB, 0xFAFAFA, 0xF9F9F9, 0xF8F8F8,
			0xF7F7F7, 0xF6F6F6, 0xF5F5F5, 0xF4F4F4, 0xF3F3F3, 0xF2F2F2, 0xF1F1F1, 0xF0F0F0,
			0xEFEFEF, 0xEEEEEE, 0xEDEDED, 0xECECEC, 0xEBEBEB, 0xEAEAEA, 0xE9E9E9, 0xE8E8E8,
			0xE7E7E7, 0xE6E6E6, 0xE5E5E5, 0xE4E4E4, 0xE3E3E3, 0xE2E2E2, 0xE1E1E1, 0xE0E0E0,
			0xDFDFDF, 0xDEDEDE, 0xDDDDDD, 0xDCDCDC, 0xDBDBDB, 0xDADADA, 0xD9D9D9, 0xD8D8D8,
			0xD7D7D7, 0xD6D6D6, 0xD5D5D5, 0xD4D4D4, 0xD3D3D3, 0xD2D2D2, 0xD1D1D1, 0xD0D0D0,
			0xCFCFCF, 0xCECECE, 0xCDCDCD, 0xCCCCCC, 0xCBCBCB, 0xCACACA, 0xC9C9C9, 0xC8C8C8,
			0xC7C7C7, 0xC6C6C6, 0xC5C5C5, 0xC4C4C4, 0xC3C3C3, 0xC2C2C2, 0xC1C1C1, 0xC0C0C0,
			0xBFBFBF, 0xBEBEBE, 0xBDBDBD, 0xBCBCBC, 0xBBBBBB, 0xBABABA, 0xB9B9B9, 0xB8B8B8,
			0xB7B7B7, 0xB6B6B6, 0xB5B5B5, 0xB4B4B4, 0xB3B3B3, 0xB2B2B2, 0xB1B1B1, 0xB0B0B0,
			0xAFAFAF, 0xAEAEAE, 0xADADAD, 0xACACAC, 0xABABAB, 0xAAAAAA, 0xA9A9A9, 0xA8A8A8,
			0xA7A7A7, 0xA6A6A6, 0xA5A5A5, 0xA4A4A4, 0xA3A3A3, 0xA2A2A2, 0xA1A1A1, 0xA0A0A0,
			0x9F9F9F, 0x9E9E9E, 0x9D9D9D, 0x9C9C9C, 0x9B9B9B, 0x9A9A9A, 0x999999, 0x989898,
			0x979797, 0x969696, 0x959595, 0x949494, 0x939393, 0x929292, 0x919191, 0x909090,
			0x8F8F8F, 0x8E8E8E, 0x8D8D8D, 0x8C8C8C, 0x8B8B8B, 0x8A8A8A, 0x898989, 0x888888,
			0x878787, 0x868686, 0x858585, 0x848484, 0x838383, 0x828282, 0x818181, 0x808080,
			0x7F7F7F, 0x7E7E7E, 0x7D7D7D, 0x7C7C7C, 0x7B7B7B, 0x7A7A7A, 0x797979, 0x787878,
			0x777777, 0x767676, 0x757575, 0x747474, 0x737373, 0x727272, 0x717171, 0x707070,
			0x6F6F6F, 0x6E6E6E, 0x6D6D6D, 0x6C6C6C, 0x6B6B6B, 0x6A6A6A, 0x696969, 0x686868,
			0x676767, 0x666666, 0x656565, 0x646464, 0x636363, 0x626262, 0x616161, 0x606060,
			0x5F5F5F, 0x5E5E5E, 0x5D5D5D, 0x5C5C5C, 0x5B5B5B, 0x5A5A5A, 0x595959, 0x585858,
			0x575757, 0x565656, 0x555555, 0x545454, 0x535353, 0x525252, 0x515151, 0x505050,
			0x4F4F4F, 0x4E4E4E, 0x4D4D4D, 0x4C4C4C, 0x4B4B4B, 0x4A4A4A, 0x494949, 0x484848,
			0x474747, 0x464646, 0x454545, 0x444444, 0x434343, 0x424242, 0x414141, 0x404040,
			0x3F3F3F, 0x3E3E3E, 0x3D3D3D, 0x3C3C3C, 0x3B3B3B, 0x3A3A3A, 0x393939, 0x383838,
			0x373737, 0x363636, 0x353535, 0x343434, 0x333333, 0x323232, 0x313131, 0x303030,
			0x2F2F2F, 0x2E2E2E, 0x2D2D2D, 0x2C2C2C, 0x2B2B2B, 0x2A2A2A, 0x292929, 0x282828,
			0x272727, 0x262626, 0x252525, 0x242424, 0x232323, 0x222222, 0x212121, 0x202020,
			0x1F1F1F, 0x1E1E1E, 0x1D1D1D, 0x1C1C1C, 0x1B1B1B, 0x1A1A1A, 0x191919, 0x181818,
			0x171717, 0x161616, 0x151515, 0x141414, 0x131313, 0x121212, 0x111111, 0x101010,
			0x0F0F0F, 0x0E0E0E, 0x0D0D0D, 0x0C0C0C, 0x0B0B0B, 0x0A0A0A, 0x090909, 0x080808,
			0x070707, 0x060606, 0x050505, 0x040404, 0x030303, 0x020202, 0x010101, 0x000000
			}
		};
		if (options->gamma_table > sizeof(gamma_table) / sizeof(gamma_table[0])) {
			RMDBGLOG((ENABLE, "Error, gamma table index too large! Disabling gamma correction.\n"));
			options->gamma_table = 0;
		}
		if (options->gamma_table) {
			DCCSPERR(dcc_info->pRUA, VideoConnectorModuleID, RMDispDigitalOutPropertyID_GammaLut, &(gamma_table[options->gamma_table - 1]), sizeof(gamma_table[0]), "Cannot set property GammaLut");
			Enable = TRUE;
		} else {
			Enable = FALSE;
		}
		DCCSPERR(dcc_info->pRUA, VideoConnectorModuleID, RMDispDigitalOutPropertyID_EnableGammaCorrection, &Enable, sizeof(Enable), "Cannot set property EnableGammaCorrection");
	}
	
	DCCSPERR(dcc_info->pRUA, VideoConnectorModuleID, RMGenericPropertyID_Validate, NULL, 0, "Cannot validate output");
	
	return RM_OK;
}

static RMstatus apply_mixer_color_space(struct dcc_context *dcc_info, struct display_cmdline *options)
{
	struct EMhwlibColor YCbCrFull_black    = {128,   0, 128};
	struct EMhwlibColor YCbCrLimited_black = {128,  16, 128};
	struct EMhwlibColor RGBFull_black      = {  0,   0,   0};
	struct EMhwlibColor RGBLimited_black   = { 16,  16,  16};
	struct EMhwlibColor *black = NULL;
	RMuint32 mixer = 0;
	RMbool enable;
	
	switch (dcc_info->route) {
	case DCCRoute_Main:
		mixer = EMHWLIB_MODULE(DispMainMixer, 0);
		break;
	case DCCRoute_Secondary:
#ifdef RMFEATURE_HAS_VCR_MIXER
		mixer = EMHWLIB_MODULE(DispVCRMixer, 0);
#else
#ifdef RMFEATURE_HAS_VCR_CHANNEL
		mixer = 0;
#else
		return RM_ERROR;
#endif
#endif
		break;
	case DCCRoute_ColorBars:
		mixer = 0;
		break;
	default:
		RMDBGLOG((ENABLE, "route error\n"));
		return RM_ERROR;
	}
	if (! mixer) return RM_OK;
	
	DCCSPERR(dcc_info->pRUA, mixer, RMGenericPropertyID_ColorSpace, &(options->mixer_color_space), sizeof(options->mixer_color_space), "Cannot set property ColorSpace on mixer");
	switch (options->mixer_color_space) {
		case EMhwlibColorSpace_None:
			break;
		case EMhwlibColorSpace_RGB_16_235:
			black = &RGBLimited_black;
			break;
		case EMhwlibColorSpace_RGB_0_255: 
			black = &RGBFull_black;
			break;
		case EMhwlibColorSpace_YUV_601:
		case EMhwlibColorSpace_YUV_709:
		case EMhwlibColorSpace_xvYCC_601:
		case EMhwlibColorSpace_xvYCC_709:
			black = &YCbCrLimited_black;
			break;
		case EMhwlibColorSpace_YUV_601_0_255:
		case EMhwlibColorSpace_YUV_709_0_255:
		case EMhwlibColorSpace_xvYCC_601_0_255:
		case EMhwlibColorSpace_xvYCC_709_0_255:
			black = &YCbCrFull_black;
			break;
	}
	if (black) {
		DCCSPERR(dcc_info->pRUA, mixer, RMGenericPropertyID_BackgroundColor, black, sizeof(struct EMhwlibColor), "Can not set property BackgroundColor on mixer");
		enable = TRUE;
	} else {
		enable = FALSE;
	}
	DCCSPERR(dcc_info->pRUA, mixer, RMGenericPropertyID_ForceBackGround, &enable, sizeof(enable), "Can not set property ForceBackGround on mixer");
	DCCSPERR(dcc_info->pRUA, mixer, RMGenericPropertyID_Validate, NULL, 0, "Can not Validate mixer");
	
	return RM_OK;
}

RMstatus apply_display_options(struct dcc_context *dcc_info, struct display_cmdline *options)
{
	RMstatus err = RM_ERROR;
	RMuint32 VideoConnectorModuleID;
	RMuint32 mixer;
	RMuint32 i;
	RMbool dcc_set = FALSE;

	if (options->dh_info == NULL) {
		RMDBGLOG((ENABLE, "dh_info is null\n"));
		return RM_ERROR;
	}
	if (dcc_info->dh_info == NULL) {
		dcc_info->dh_info = options->dh_info;
	}
	
	if (options->force_route) {
		dcc_info->route = options->route;
	}
	
	switch (dcc_info->route) {
	case DCCRoute_Main:
		mixer = EMHWLIB_MODULE(DispMainMixer, 0);
		break;
	case DCCRoute_Secondary:
#ifdef RMFEATURE_HAS_VCR_MIXER
		mixer = EMHWLIB_MODULE(DispVCRMixer, 0);
#else
#ifdef RMFEATURE_HAS_VCR_CHANNEL
		mixer = 0;
#else
		return RM_ERROR;
#endif
#endif
		break;
	case DCCRoute_ColorBars:
		mixer = 0;
		break;
	default:
		RMDBGLOG((ENABLE, "route error\n"));
		return RM_ERROR;
	}
	
	options->osd_pictures[0].route = dcc_info->route;
	options->osd_pictures[1].route = (dcc_info->route == DCCRoute_Main) ? DCCRoute_Secondary : DCCRoute_Main;
	
	options->dh_info->dvi_hdmi_part = options->dvi_hdmi_part;
	options->dh_info->dvi_hdmi_state = options->dvi_hdmi_state;
	
	// open handle to DVI/HDMI chip
	if (options->connector == DCCVideoConnector_DVI) {  // Called when using -o dvi_xx
		if (options->configure_outports) {
			init_dvi_hdmi(dcc_info, options);
		}
	}
	
	/* initial mode setup */
	if (! options->configure_outports) {
		err = RM_OK;  // do nothing
	} else if (strlen(options->vidmode_filename) > 0) {
		dcc_set = TRUE;
		err = apply_videomode_from_vmf_file(dcc_info, options->vidmode_filename);
	} else if (options->connector == DCCVideoConnector_DVI) {
		err = RM_OK;  // HDMI/DVI output is set up later, based on EDID settings
	} else if (options->vga_standard != EMhwlibTVStandard_Custom) {
		err = apply_dual_videomode(dcc_info, options, mixer);  // TODO need to do this with outport_options
		dcc_set = TRUE;
	} else {
		if (  // "video" mode outputs
			(options->connector == DCCVideoConnector_SVIDEO) || 
			(options->connector == DCCVideoConnector_COMPONENT) || 
			(options->connector == DCCVideoConnector_COMPOSITE) || 
			(options->connector == DCCVideoConnector_SCART) 
		) {
			err = set_component_videomode_from_edmode(dcc_info, options);
			err = apply_outports_videomode(dcc_info, options, TRUE);
		} else {  // "computer" mode VGA, LVDS, digital 601
			dcc_set = TRUE;
			err = DCCSetStandard(dcc_info->pDCC, dcc_info->route, options->standard);
		}
	}
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error %s (%d): cannot open display.\n", RMstatusToString(err), err));
		return err;
	}
	
	// first set up pads here, otherwise we might get a messed up digital output signal
	if (options->configure_outports) {
		err = set_up_pads(dcc_info, options);
		if (RMFAILED(err)) 
			return err;
	}
	
	switch (options->connector) {
	case DCCVideoConnector_COMPONENT:
		if (options->configure_outports && dcc_set) {
			if (! manutest) fprintf(stderr, "COMPONENT Colorspace is now: %s\n", 
				(options->color_space == EMhwlibColorSpace_RGB_0_255) ? "RGB full range" : 
				(options->color_space == EMhwlibColorSpace_RGB_16_235) ? "RGB limited range" : 
				(options->color_space == EMhwlibColorSpace_YUV_601) ? "YCbCr 601" : 
				(options->color_space == EMhwlibColorSpace_YUV_709) ? "YCbCr 709" : 
				(options->color_space == EMhwlibColorSpace_xvYCC_601) ? "xvYCC 601" : 
				(options->color_space == EMhwlibColorSpace_xvYCC_709) ? "xvYCC 709" : 
				(options->color_space == EMhwlibColorSpace_YUV_601_0_255) ? "YCbCr 601 full range" : 
				(options->color_space == EMhwlibColorSpace_YUV_709_0_255) ? "YCbCr 709 full range" : 
				(options->color_space == EMhwlibColorSpace_xvYCC_601_0_255) ? "xvYCC 601 full range" : 
				(options->color_space == EMhwlibColorSpace_xvYCC_709_0_255) ? "xvYCC 709 full range" : 
				"Unknown!");
			/* this is done on set_outports */
			DCCSetComponentOutFormat(dcc_info->pDCC, dcc_info->route, options->color_space, options->component);
		}
		// no break
	case DCCVideoConnector_COMPOSITE: 
	case DCCVideoConnector_SVIDEO: 
	case DCCVideoConnector_SCART: 
		setup_scart(dcc_info, options);
		break;
	case DCCVideoConnector_DVI: // Called when using -o dvi_xx
		err = apply_dvi_hdmi(dcc_info, options);  // includes call to DCCSetDVIOutFormat()
		if (RMSUCCEEDED(DCCGetVideoConnectorModuleID(dcc_info->pDCC, dcc_info->route, DCCVideoConnector_COMPONENT, &VideoConnectorModuleID))) {
			DCCSP(dcc_info->pRUA, VideoConnectorModuleID, RMGenericPropertyID_ComponentMode, &(options->component), sizeof(options->component));
		}
		break;
	case DCCVideoConnector_LVDS:  // same as DCCVideoConnector_Digital, but with certain GPIO inits for panels
		enable_lvds_panel(dcc_info, options);
		// no break;
	case DCCVideoConnector_Digital:
		DCCSetDVIOutFormat(dcc_info->pDCC, 
			(options->vga_standard == EMhwlibTVStandard_Custom) ? dcc_info->route : DCCRoute_Secondary, 
			options->color_space, 
			options->dig_protocol, 
			options->bus_size);
		break;
	case DCCVideoConnector_VGA: 
		break;
	}
	
	if (dcc_set) {
		/* always enable svideo connector */
		if (options->configure_outports) {
			DCCEnableVideoConnector(dcc_info->pDCC, dcc_info->route, options->connector, TRUE);
		} else {
			RMDBGLOG((ENABLE, "NOT enabling DCC video connectors\n"));
		}
		
		DCCGetVideoConnectorModuleID(dcc_info->pDCC, dcc_info->route, options->connector, &VideoConnectorModuleID);
		if (options->configure_outports) {
			/* this is done by set_outports */
			err = output_basic_setup(dcc_info, options, VideoConnectorModuleID);
		} else {
			RMDBGLOG((ENABLE, "NOT doing output_basic_setup (cbs)\n"));
		}
		if (RMFAILED(err)) 
			return err;
		if (options->configure_outports) {
			apply_mixer_color_space(dcc_info, options);
			if ((options->ar_x == 0) || (options->ar_y == 0)) {
				if (dcc_info->SurfaceID > 0) {
					err = DCCSetRouteDisplayAspectRatioFromSource(dcc_info->pDCC, dcc_info->route, dcc_info->SurfaceID);
				} else {
					err = RM_ERROR;
				}
			} else {
				err = DCCSetRouteDisplayAspectRatio(dcc_info->pDCC, dcc_info->route, options->ar_x, options->ar_y);
			}
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot set display aspect ratio: %s\n", RMstatusToString(err)));
				if(err == RM_ERROR) return err;
			}
			
			if (options->vga_standard != EMhwlibTVStandard_Custom) {
				DCCGetVideoConnectorModuleID(dcc_info->pDCC, DCCRoute_Secondary, DCCVideoConnector_VGA, &VideoConnectorModuleID);
				err = output_basic_setup(dcc_info, options, VideoConnectorModuleID);
				if (RMFAILED(err)) return err;
				
				err = DCCSetRouteDisplayAspectRatio(dcc_info->pDCC, DCCRoute_Secondary, options->ar_x, options->ar_y);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Cannot set display aspect ratio: %s\n", RMstatusToString(err)));
					return err;
				}
			}
			
			/* Set up low pass filter for component output on the board
			Sigma BluRay eval. board:
			-filter_gpio 36 2 0 (8 MHz, 480i)
			-filter_gpio 36 2 1 (16 MHz, 480p)
			-filter_gpio 36 2 2 (32 MHz, 720p, 1080i)
			-filter_gpio 36 2 3 (bypass)
			Sigma Envision/Vantage eval. boards:
			-filter_gpio 36 1 0 (bypass, 480p, 720p, 1080i)
			-filter_gpio 36 1 1 (?? MHz, 480i)
			*/
			if (options->filter_gpio_num) {
				RMuint32 i;
				struct SystemBlock_GPIO_type gpio;
				
				for (i = 0; i < options->filter_gpio_num; i++) {
					gpio.Bit = (enum GPIOId_type)(options->filter_gpio_start + i);
					gpio.Data = (options->filter_gpio_val & (1 << i)) ? TRUE : FALSE;
					if (RMFAILED(err = RUASetProperty(dcc_info->pRUA, SystemBlock, RMSystemBlockPropertyID_GPIO, &gpio, sizeof(gpio), 0))) {
						RMDBGLOG((LOCALDBG, "Error setting GPIO %u to set external filter: %s\n", gpio.Bit, RMstatusToString(err)));
					}
				}
			}
			
			if (options->input) {
				setup_dummy_capture(dcc_info->pRUA, dcc_info->pDCC, options, 0);
			}
			apply_genlock(dcc_info->pRUA, options);
		}
	}
	
	if (dcc_info->SurfaceID > 0) {
		err = surface_basic_setup(dcc_info, options, mixer);
		if (RMFAILED(err)) return err;
	}
	
	for (i = 0; i < 2; i++) {
		err = show_osd_picture(dcc_info, options, i);
		if (RMFAILED(err)) return err;
	}
	
	if (options->show_hwc) {
		err = show_hwcursor(dcc_info, options, mixer);
		if (RMFAILED(err)) return err;
	}
	
	if (dcc_info->disp_info != NULL) {
		dcc_info->disp_info->out_window = options->output_window;
		dcc_info->disp_info->nonlinearmode = options->nonlinearmode;
		dcc_info->disp_info->blackstrip = options->blackstrip;
		dcc_info->disp_info->cutstrip = options->cutstrip;
/* 		set_display_out_window(dcc_info); */
	}
	
	if (options->active_format_valid) {
		struct EMhwlibActiveFormatDescription output_afd;
		output_afd.FrameAspectRatio.X = options->ar_x;
		output_afd.FrameAspectRatio.Y = options->ar_y;
		output_afd.ActiveFormat = options->active_format;
		output_afd.ActiveFormatValid = options->active_format_valid;
		apply_active_format_output(dcc_info->pRUA, 
			(dcc_info->route == DCCRoute_Main) ? DispMainMixer : 
			(dcc_info->route == DCCRoute_Secondary) ? DispVCRMixer : 
			(dcc_info->route == DCCRoute_HDSD) ? DispHDSDConverter : 
			(dcc_info->route == DCCRoute_ColorBars) ? DispColorBars : 0, 
			options->dh_info->pDH, 
			output_afd);
	}
	
	update_output_afd_settings(dcc_info, options, NULL);
	
	return RM_OK;
}

RMstatus clear_display_options(struct dcc_context *dcc_info, struct display_cmdline *options) 
{
	RMstatus err;
	RMuint32 i;
	RMint8 brightness, hue;
	RMuint8 contrast, saturation;
	
	if (! options->configure_outports) {
		RMDBGLOG((ENABLE, "clear_display_options(): called with '-no_disp', doing nothing.\n"));
		return RM_OK;
	}
	
	// end HDMI
	if (options->dh_info->pDH != NULL) {
		DHDone(options->dh_info->pDH);
		options->dh_info->pDH = NULL;
	}
	
	if (options->dh_info->pDBC) {
		RMFree(options->dh_info->pDBC);
		options->dh_info->pDBC = NULL;
	}
	
//	if (! options->use_hdsd_conversion) {
	if (0) {
		close_dummy_capture(options);
	}
	
	// close OSD surface
	for(i = 0; i < 2; i++){
		if (dcc_info->pOSDSource[i] != NULL) {
			/*clean the scaler's input window selection*/
			/*this is not (re)set by apply_display_options*/
			struct EMhwlibDisplayWindow source_window;
			RMuint32 osd_scaler;

			err = DCCGetScalerModuleID(dcc_info->pDCC, options->osd_pictures[0].route, DCCSurface_OSD, options->osd_pictures[0].scaler, &(osd_scaler));
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot get surface to display OSD source: %s\n", RMstatusToString(err)));
				return RM_ERROR;
			}

			set_default_out_window(&(source_window));
			DCCSPERR(dcc_info->pRUA, osd_scaler, RMGenericPropertyID_ScalerInputWindow, &source_window, sizeof(source_window), "Cannot set scaler input window on OSD surface");
			DCCSPERR(dcc_info->pRUA, osd_scaler, RMGenericPropertyID_Validate, NULL, 0, "Cannot validate scaler input window");
			err = DCCCloseVideoSource(dcc_info->pOSDSource[i]);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot close osd source %s\n", RMstatusToString(err)));
				return err;
			}	
			/* warning: write to dcc_info */
			dcc_info->pOSDSource[i] = NULL;
		}
	}
	if(options->show_hwc){
		enum EMhwlibMixerSourceState state;
		RMuint32 cursor, src_index, mixer = 0; 
		RMbool enable = FALSE;
		cursor = EMHWLIB_MODULE(DispHardwareCursor, 0);

		err =  RUASetProperty(dcc_info->pRUA, cursor, RMGenericPropertyID_Enable, &enable, sizeof(enable), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot disable cursor %lu\n", err));
			return err;
		}
		mixer = EMHWLIB_MODULE(DispMainMixer, 0); 

		err = RUAExchangeProperty(dcc_info->pRUA, mixer, RMGenericPropertyID_MixerSourceIndex, &cursor, sizeof(cursor), &src_index, sizeof(src_index));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot get cursor index\n"));
			return err;
		}
		mixer = EMHWLIB_TARGET_MODULE(DispMainMixer, 0 , src_index);
		state = EMhwlibMixerSourceState_Disable;
		err =  RUASetProperty(dcc_info->pRUA, mixer, RMGenericPropertyID_MixerSourceState, &state, sizeof(state), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set cursor's state on mixer\n"));
			return err;
		}
		DCCSPERR(dcc_info->pRUA, mixer, RMGenericPropertyID_Validate, NULL, 0, "Cannot validate mixer");
	}

	contrast = 128;
	saturation = 128;
	brightness = 0;
	hue = 0;
	if(dcc_info->disp_info != NULL){
		dcc_info->disp_info->contrast = contrast;
		dcc_info->disp_info->saturation = saturation;
		dcc_info->disp_info->brightness = brightness;
		dcc_info->disp_info->hue = hue;
	}

	if (options->deinterlacingmode == EMhwlibDeinterlacingMode_MotionAdaptative) {
		struct DispMainMixer_LayerOrder_type layer;
		layer.Layer0SourceModuleID = EMHWLIB_MODULE(DispCRTMultiScaler, 0);
		layer.Layer1SourceModuleID = EMHWLIB_MODULE(DispVCRMultiScaler, 0);
		layer.Layer2SourceModuleID = EMHWLIB_MODULE(DispMainVideoScaler, 0);
		layer.Layer3SourceModuleID = EMHWLIB_MODULE(DispGFXMultiScaler, 0);
		layer.Layer4SourceModuleID = EMHWLIB_MODULE(DispOSDScaler, 0);
		layer.Layer5SourceModuleID = EMHWLIB_MODULE(DispSubPictureScaler, 0);
		layer.Layer6SourceModuleID = EMHWLIB_MODULE(DispGraphicInput, 0);
		DCCSP(dcc_info->pRUA, DispMainMixer, RMDispMainMixerPropertyID_LayerOrder, &layer, sizeof(layer));
		DCCSP(dcc_info->pRUA, DispMainMixer, RMGenericPropertyID_Validate, NULL, 0);
	}

	RMDBGLOG((ENABLE, "done cleaning\n"));
	
	return RM_OK;
}


/* this function is only called when sample apps are not used as lib */
RMstatus set_display_out_window(struct dcc_context *dcc_info)
{
	RMuint32 mixer=0, scaler, src_index;
	RMstatus err;
	RMbool enable;
	enum EMhwlibMixerSourceState state;

	if(dcc_info->disp_info == NULL)
		return RM_ERROR;
	
	switch (dcc_info->route) {
	case DCCRoute_Main:
		mixer = DispMainMixer;
		break;
	case DCCRoute_Secondary:
		mixer = DispVCRMixer;
		break;
	case DCCRoute_ColorBars:
		mixer = DispColorBars;
		break;
	case DCCRoute_HDSD:
		mixer = DispHDSDConverter;
		break;
	}

	if (dcc_info->disp_info->active_window == &(dcc_info->disp_info->out_window)) {
		scaler = dcc_info->SurfaceID;
		enable = dcc_info->disp_info->video_enable;
	}
	else if (dcc_info->disp_info->active_window == &(dcc_info->disp_info->osd_window[0])) {
		scaler = dcc_info->disp_info->osd_scaler[0];
		enable = dcc_info->disp_info->osd_enable[0];
	}
	else if (dcc_info->disp_info->active_window == &(dcc_info->disp_info->osd_window[1])) {
		scaler = dcc_info->disp_info->osd_scaler[1];
		enable = dcc_info->disp_info->osd_enable[1];
	}
	else
		return RM_ERROR;
	

	if (scaler == 0)
		return RM_ERROR;

	err = RUAExchangeProperty(dcc_info->pRUA, mixer, RMGenericPropertyID_MixerSourceIndex, &scaler, sizeof(scaler), &src_index, sizeof(src_index));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot get scaler index: %s\n", RMstatusToString(err)));
		return err;
	}
	mixer = EMHWLIB_TARGET_MODULE(EMHWLIB_MODULE_CATEGORY(mixer), 0 , src_index);

 	DCCSPERR(dcc_info->pRUA, mixer, RMGenericPropertyID_MixerSourceWindow, dcc_info->disp_info->active_window, sizeof(*(dcc_info->disp_info->active_window)), "Cannot set scaler input window");
	
	state = (enable) ? EMhwlibMixerSourceState_Master : EMhwlibMixerSourceState_Disable;
	DCCSPERR(dcc_info->pRUA, mixer, RMGenericPropertyID_MixerSourceState, &state, sizeof(state), "Cannot set mixer source state");
	DCCSPERR(dcc_info->pRUA, mixer, RMGenericPropertyID_Validate, NULL, 0, "Cannot validate scaler input window");
	DCCSPERROK(RM_INVALIDMODE, dcc_info->pRUA, scaler, RMGenericPropertyID_NonLinearScalingMode, &dcc_info->disp_info->nonlinearmode, sizeof(dcc_info->disp_info->nonlinearmode), "Error setting current scaler non-linear selection");
	DCCSPERROK(RM_INVALIDMODE, dcc_info->pRUA, scaler, RMGenericPropertyID_BlackStripMode, &dcc_info->disp_info->blackstrip, sizeof(dcc_info->disp_info->blackstrip), "Error setting current scaler blackstrip mode");
	DCCSPERROK(RM_INVALIDMODE, dcc_info->pRUA, scaler, RMGenericPropertyID_CutStripMode, &dcc_info->disp_info->cutstrip, sizeof(dcc_info->disp_info->cutstrip), "Error setting current scaler cutstrip mode");
	DCCSPERR(dcc_info->pRUA, scaler, RMGenericPropertyID_Validate, NULL, 0, "Cannot validate scaler");

	return RM_OK;
}

// zoom helper defines and functions
#undef ZOOM_0
#undef ZOOM_1
#define ZOOM_0 4096  // 0% zoom position
#define ZOOM_1 8192  // 100% zoom position

// 0..4095: absolute
// 4096..8192: 0%..100% relative
RMstatus set_scaler_source_zoom(
	struct RUA *pRUA, 
	RMuint32 ScalerModuleID, 
	RMuint32 x, 
	RMuint32 y, 
	RMuint32 w, 
	RMuint32 h)
{
	struct EMhwlibDisplayWindow source_window;
	
	if (! manutest) {
		fprintf(stderr, "current zoom window on scaler 0x%08lX: ", ScalerModuleID);
		if (x >= ZOOM_0) {
			RMuint32 xx = (((x - ZOOM_0) * 10000) + ((ZOOM_1 - ZOOM_0) / 2)) / (ZOOM_1 - ZOOM_0);
			fprintf(stderr, "x=%ld.%02ld%% ", xx / 100, xx % 100);
		} else fprintf(stderr, "x=%ld ", x);
		if (y >= ZOOM_0) {
			RMuint32 yy = (((y - ZOOM_0) * 10000) + ((ZOOM_1 - ZOOM_0) / 2)) / (ZOOM_1 - ZOOM_0);
			fprintf(stderr, "y=%ld.%02ld%% ", yy / 100, yy % 100);
		} else fprintf(stderr, "y=%ld ", y);
		if (w >= ZOOM_0) {
			RMuint32 ww = (((w - ZOOM_0) * 10000) + ((ZOOM_1 - ZOOM_0) / 2)) / (ZOOM_1 - ZOOM_0);
			fprintf(stderr, "w=%ld.%02ld%% ", ww / 100, ww % 100);
		} else fprintf(stderr, "w=%ld ", w);
		if (h >= ZOOM_0) {
			RMuint32 hh = (((h - ZOOM_0) * 10000) + ((ZOOM_1 - ZOOM_0) / 2)) / (ZOOM_1 - ZOOM_0);
			fprintf(stderr, "h=%ld.%02ld%% ", hh / 100, hh % 100);
		} else fprintf(stderr, "h=%ld ", h);
		fprintf(stderr, "\n");
	}
	
	source_window.X =      (x >= ZOOM_0) ? (x - ZOOM_0) : x;
	source_window.Y =      (y >= ZOOM_0) ? (y - ZOOM_0) : y;
	source_window.Width =  (w >= ZOOM_0) ? (w - ZOOM_0) : w;
	source_window.Height = (h >= ZOOM_0) ? (h - ZOOM_0) : h;
	source_window.XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
	source_window.YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
	source_window.XMode =      (x >= ZOOM_0) ? EMhwlibDisplayWindowValueMode_Relative : EMhwlibDisplayWindowValueMode_Fixed;
	source_window.YMode =      (y >= ZOOM_0) ? EMhwlibDisplayWindowValueMode_Relative : EMhwlibDisplayWindowValueMode_Fixed;
	source_window.WidthMode =  (w >= ZOOM_0) ? EMhwlibDisplayWindowValueMode_Relative : EMhwlibDisplayWindowValueMode_Fixed;
	source_window.HeightMode = (h >= ZOOM_0) ? EMhwlibDisplayWindowValueMode_Relative : EMhwlibDisplayWindowValueMode_Fixed;
	
	DCCSPERR(pRUA, ScalerModuleID, RMGenericPropertyID_ScalerInputWindow, &source_window, sizeof(source_window), "Error setting ScalerInputWindow");
	DCCSPERR(pRUA, ScalerModuleID, RMGenericPropertyID_Validate, NULL, 0, "Failed to validate input");
	
	return RM_OK;
}

void reduce_aspect_ratio(
	RMuint32 *X, 
	RMuint32 *Y, 
	RMuint32 boundary)
{
	RMuint32 num, den, mod, max;
	
	if (*X && *Y) {
		num = *X;
		den = *Y;
		while ((mod = num % den) > 0) {
			num = den;
			den = mod;
		}
		(*X) /= den;
		(*Y) /= den;
		if (boundary) {
			max = RMmax(*X, *Y);
			if (max > boundary) {
				den = (max + boundary - 1) / boundary;
				*X /= den;
				*Y /= den;
			}
		}
	}
}

RMascii *get_afd_name(enum EMhwlibActiveFormat ActiveFormat)
{
	return 
		(ActiveFormat == EMhwlibAF_no_info) ? "no info" : 
		(ActiveFormat == EMhwlibAF_16x9_top) ? "16:9 content, at top" : 
		(ActiveFormat == EMhwlibAF_14x9_top) ? "14:9 content, at top" : 
		(ActiveFormat == EMhwlibAF_64x27_centered) ? "64:27 content, centered" : 
		(ActiveFormat == EMhwlibAF_same_as_picture) ? "full frame content" : 
		(ActiveFormat == EMhwlibAF_4x3_centered) ? "4:3 content, centered" : 
		(ActiveFormat == EMhwlibAF_16x9_centered) ? "16:9 content, centered" : 
		(ActiveFormat == EMhwlibAF_14x9_centered) ? "14:9 content, centered" : 
		(ActiveFormat == EMhwlibAF_4x3_centered_prot_14x9) ? "4:3 content with essential content in 14:9 centered portion" : 
		(ActiveFormat == EMhwlibAF_16x9_centered_prot_14x9) ? "16:9 content with essential content in 14:9 centered portion" : 
		(ActiveFormat == EMhwlibAF_16x9_centered_prot_4x3) ? "16:9 content with essential content in 4:3 centered portion" : 
		"unknown active format code!";
}

static RMstatus apply_active_format_common(
	struct EMhwlibActiveFormatDescription content_afd, 
	struct EMhwlibAspectRatio *output_ar, // might be modified
	RMbool output_variable_ar, 
	struct EMhwlibActiveFormatDescription *output_afd, 
	RMbool *input_16x9, 
	RMbool *input_4x3, 
	RMbool *output_16x9, 
	RMbool *output_4x3, 
	RMbool *content_16x9, 
	RMbool *content_4x3, 
	struct EMhwlibAspectRatio *content_ar)
{
	// Currently, only 4:3 and 16:9 input frames are fully supported
	*input_16x9 = ((content_afd.FrameAspectRatio.X * 9) == (content_afd.FrameAspectRatio.Y * 16));
	*input_4x3  = ((content_afd.FrameAspectRatio.X * 3) == (content_afd.FrameAspectRatio.Y *  4));
	
	// Determine content aspect ratio
	*content_ar = content_afd.FrameAspectRatio;
	if (content_afd.ActiveFormatValid) {
		switch (content_afd.ActiveFormat) {
		case EMhwlibAF_4x3_centered: // 4:3 center
		case EMhwlibAF_4x3_centered_prot_14x9: // 4:3 center, prot. 14:9
			content_ar->X = 4;
			content_ar->Y = 3;
			break;
		case EMhwlibAF_16x9_top: // 16:9 top
		case EMhwlibAF_16x9_centered: // 16:9 center
		case EMhwlibAF_16x9_centered_prot_4x3: // 16:9 center, prot, 4:3
		case EMhwlibAF_16x9_centered_prot_14x9: // 16:9 center, prot. 14:9
			content_ar->X = 16;
			content_ar->Y =  9;
			break;
		case EMhwlibAF_14x9_top: // 14:9 top
		case EMhwlibAF_14x9_centered: // 14:9 center
			content_ar->X = 14;
			content_ar->Y =  9;
			break;
		case EMhwlibAF_64x27_centered: // more than 16:9 (assume cinemascope, 2.35:1, use 64:27: 720*270(NTSC), 720*324(PAL), 1280*540, 1920*810)
			content_ar->X = 64;
			content_ar->Y = 27;
			break;
		default:
			break;
		}
	}
	*content_16x9 = ((content_ar->X * 9) == (content_ar->Y * 16));
	*content_4x3  = ((content_ar->X * 3) == (content_ar->Y *  4));
	
	// if possible, modify output aspect ratio to match content; otherwise leave as-is
	if (output_variable_ar && ((content_ar->X * 9) > (content_ar->Y * 14))) {  // wider than 14:9
		output_ar->X = 16;
		output_ar->Y = 9;
	} else if (output_variable_ar && ((content_ar->X * 9) < (content_ar->Y * 14))) {  // narrower than 14:9
		output_ar->X = 4;
		output_ar->Y = 3;
	}
	*output_16x9 = ((output_ar->X * 9) == (output_ar->Y * 16));
	*output_4x3  = ((output_ar->X * 3) == (output_ar->Y *  4));
	
	// Set output active format based on new content
	// This assumes the scaler blackstrip and cutstrip values to be 4096
	// TODO handle other blackstrip/cutstrip value
	if (output_afd) {
		output_afd->FrameAspectRatio = *output_ar;
		output_afd->ActiveFormat = content_afd.ActiveFormat;
		output_afd->ActiveFormatValid = content_afd.ActiveFormatValid;
		if (content_afd.ActiveFormatValid) {
			switch (content_afd.ActiveFormat) {
			case EMhwlibAF_4x3_centered: // 4:3 center
				if (*output_4x3) output_afd->ActiveFormat = EMhwlibAF_same_as_picture;
				break;
			case EMhwlibAF_4x3_centered_prot_14x9: // 4:3 center, prot. 14:9
				if (*output_16x9) output_afd->ActiveFormat = EMhwlibAF_14x9_centered;
				break;
			case EMhwlibAF_16x9_top: // 16:9 top
				output_afd->ActiveFormat = EMhwlibAF_16x9_centered;
				break;
			case EMhwlibAF_16x9_centered: // 16:9 center
				if (*output_16x9) output_afd->ActiveFormat = EMhwlibAF_same_as_picture;
				break;
			case EMhwlibAF_16x9_centered_prot_4x3: // 16:9 center, prot, 4:3
				if (*output_4x3) output_afd->ActiveFormat = EMhwlibAF_same_as_picture;
				break;
			case EMhwlibAF_16x9_centered_prot_14x9: // 16:9 center, prot. 14:9
				if (*output_4x3) output_afd->ActiveFormat = EMhwlibAF_14x9_centered;
				break;
			case EMhwlibAF_14x9_top: // 14:9 top
				output_afd->ActiveFormat = EMhwlibAF_14x9_centered;
				break;
			case EMhwlibAF_14x9_centered: // 14:9 center
				break;
			case EMhwlibAF_64x27_centered: // more than 16:9 (assume cinemascope, 2.35:1, use 64:27: 720*270(NTSC), 720*324(PAL), 1280*540, 1920*810)
				break;
			default:
				// modify ambivalent active format
				if (*input_16x9 && ! *output_16x9) {
					output_afd->ActiveFormat = EMhwlibAF_16x9_centered;
				} else if (*input_4x3 && ! *output_4x3) {
					output_afd->ActiveFormat = EMhwlibAF_4x3_centered;
				} else {
					output_afd->ActiveFormat = EMhwlibAF_same_as_picture;
				}
				break;
			}
		} else {
			// create active format for new content
			if (*content_16x9) {
				output_afd->ActiveFormatValid = TRUE;
				output_afd->ActiveFormat = EMhwlibAF_16x9_centered;
			} else if ((content_ar->X * 9) == (content_ar->Y * 14)) {
				output_afd->ActiveFormatValid = TRUE;
				output_afd->ActiveFormat = EMhwlibAF_14x9_centered;
			} else if (*content_4x3) {
				output_afd->ActiveFormatValid = TRUE;
				output_afd->ActiveFormat = EMhwlibAF_4x3_centered;
			}
		}
	}
	
	return RM_OK;
}

// has to be called with full frame zoom window in x, y, w, h, absolute values
RMstatus apply_active_format_abs(
	struct EMhwlibActiveFormatDescription content_afd, 
	struct EMhwlibAspectRatio output_ar, 
	RMbool output_variable_ar, // TRUE: output can be both, 16:9 and 4:3
	struct EMhwlibActiveFormatDescription *output_afd, 
	RMuint32 *x, 
	RMuint32 *y, 
	RMuint32 *w, 
	RMuint32 *h, 
	RMbool *update_zoom)
{
	// zoom helper defines and functions
	#undef ZOOM_FRAC_X
	#undef ZOOM_FRAC_Y
	#undef ZOOM_CENTER_X
	#undef ZOOM_CENTER_Y
	#define ZOOM_FRAC_X(n, m) ((zoom_w * (n) + ((m) - 1)) / (m))  // rounding division ZOOM * n / m
	#define ZOOM_FRAC_Y(n, m) ((zoom_h * (n) + ((m) - 1)) / (m))  // rounding division ZOOM * n / m
	#define ZOOM_CENTER_X(n) ((zoom_w - (n)) / 2 + zoom_x)  // positioning a width or height 'n' in the center of the frame
	#define ZOOM_CENTER_Y(n) ((zoom_h - (n)) / 2 + zoom_y)  // positioning a width or height 'n' in the center of the frame
	
	RMuint32 zoom_x = *x;
	RMuint32 zoom_y = *y;
	RMuint32 zoom_w = *w;
	RMuint32 zoom_h = *h;
	RMuint32 prot = ZOOM_FRAC_X(7, 8);  // 7/8 ratio: protect 14:9 portion of 16:9 frame
	RMbool input_16x9, input_4x3, output_16x9, output_4x3, content_16x9, content_4x3;
	struct EMhwlibAspectRatio content_ar;
	
	apply_active_format_common(content_afd, &output_ar, output_variable_ar, output_afd, 
		&input_16x9, &input_4x3, &output_16x9, &output_4x3, 
		&content_16x9, &content_4x3, &content_ar);
	
	// apply active format
	if (update_zoom) *update_zoom = content_afd.ActiveFormatValid;
	if (content_afd.ActiveFormatValid) {
		switch (content_afd.ActiveFormat) {
		default:
			if (update_zoom) *update_zoom = FALSE;
			return RM_ERROR;
		case EMhwlibAF_no_info: // don't apply active format
			if (update_zoom) *update_zoom = FALSE;
			break;
		case EMhwlibAF_16x9_top: // 16:9 top
			if (input_4x3) {
				*h = ZOOM_FRAC_Y(3, 4);  // 3/4 height
			} else if (! input_16x9) {
				if (update_zoom) *update_zoom = FALSE;  // TODO
			}
			break;
		case EMhwlibAF_14x9_top: // 14:9 top
			if (input_16x9) {
				*w = ZOOM_FRAC_X(7, 8);  // 7/8 width
				*x = ZOOM_CENTER_X(*w);  // center horizontally
			} else if (input_4x3) {
				*h = ZOOM_FRAC_Y(6, 7);  // 6/7 height
			} else {
				if (update_zoom) *update_zoom = FALSE;  // TODO
			}
			break;
		case EMhwlibAF_64x27_centered: // more than 16:9 (assume no less than cinemascope, 2.35:1, use 64:27: 720*270(NTSC), 720*324(PAL), 1280*540, 1920*810)
			// crop captured image (which will be 16:9) vertically?
			*h = ZOOM_FRAC_Y(output_ar.Y * 16, output_ar.X * 9);  // make height fit into scaler
			if (input_16x9) {
				prot = ZOOM_FRAC_Y(3, 4);  // 3/4 height
			} else if (input_4x3) {
				*h = RMmin(*h, ZOOM_FRAC_Y(3, 4));  // 3/4 height
				prot = ZOOM_FRAC_Y(9, 16);  // 9/16 height
			} else {
				*update_zoom = FALSE;  // TODO
			}
			*h = RMmin(*h, zoom_h);  // not more than 100% height
			*h = RMmax(*h, prot);  // not less than 64:27 center portion
			*y = ZOOM_CENTER_Y(*h);  // center vertically
			break;
		case EMhwlibAF_same_as_picture: // same as picture, full screen zoom
			break;
		case EMhwlibAF_4x3_centered_prot_14x9: // 4:3 center, prot. 14:9
			// crop captured image (which will be 4:3) vertically?
			*h = ZOOM_FRAC_Y(output_ar.Y * 4, output_ar.X * 3);  // make height fit into scaler
			*h = RMmin(*h, zoom_h);  // not more than 100% height
			*h = RMmax(*h, ZOOM_FRAC_Y(6, 7));  // not less than 14:9 center portion, 6/7 height
			*y = ZOOM_CENTER_Y(*h);  // center vertically
			// no break;
		case EMhwlibAF_4x3_centered: // 4:3 center
			// crop 16:9 image horizontally to get rid of black bars
			if (input_16x9) {
				*w = ZOOM_FRAC_X(3, 4);  // 3/4 width
				*x = ZOOM_CENTER_X(*w);  // center horizontally
			} else if (! input_4x3) {
				if (update_zoom) *update_zoom = FALSE;  // TODO
			}
			break;
		case EMhwlibAF_16x9_centered_prot_4x3: // 16:9 center, prot, 4:3
			prot = ZOOM_FRAC_X(3, 4);
			// no break;
		case EMhwlibAF_16x9_centered_prot_14x9: // 16:9 center, prot. 14:9
			// crop captured image (which will be 16:9) horizontally?
			*w = ZOOM_FRAC_X(output_ar.X * 9, output_ar.Y * 16);  // make width fit into scaler
			*w = RMmin(*w, zoom_w);  // not more than 100% width
			*w = RMmax(*w, prot);  // protect 14:9 center portion, 7/8 width, or 4:3 center portion, 4/3 width
			*x = ZOOM_CENTER_X(*w);  // center horizontally
			// no break;
		case EMhwlibAF_16x9_centered: // 16:9 center
			// crop 4:3 vertically (chop off black bars)
			if (input_4x3) {
				*h = ZOOM_FRAC_Y(3, 4);  // 3/4 height
				*y = ZOOM_CENTER_Y(*h);  // center vertically
			} else if (! input_16x9) {
				if (update_zoom) *update_zoom = FALSE;  // TODO
			}
			break;
		case EMhwlibAF_14x9_centered: // 14:9 center
			if (input_16x9) {
				*w = ZOOM_FRAC_X(7, 8);  // 7/8 width
				*x = ZOOM_CENTER_X(*w);  // center horizontally
			} else if (input_4x3) {
				*h = ZOOM_FRAC_Y(6, 7);  // 6/7 height
				*y = ZOOM_CENTER_Y(*h);  // center vertically
			} else {
				if (update_zoom) *update_zoom = FALSE;  // TODO
			}
			break;
		}
	}
	return RM_OK;
}

// faster implementation with fixed zoom values (for relative zoom window values)
RMstatus apply_active_format_rel(
	struct EMhwlibActiveFormatDescription content_afd, 
	struct EMhwlibAspectRatio output_ar, 
	RMbool output_variable_ar, // TRUE: output can be both, 16:9 and 4:3
	struct EMhwlibActiveFormatDescription *output_afd, 
	RMuint32 *x, 
	RMuint32 *y, 
	RMuint32 *w, 
	RMuint32 *h, 
	RMbool *update_zoom)
{
	// zoom helper defines and functions
	#undef ZOOM_FRAC
	#undef ZOOM_CENTER
	#define ZOOM_FRAC(n, m) (((ZOOM_1 - ZOOM_0) * (n) + ((m) - 1)) / (m) + ZOOM_0)  // rounding division ZOOM * n / m
	#define ZOOM_CENTER(n) ((ZOOM_1 - (n)) / 2 + ZOOM_0)  // positioning a width or height 'n' in the center of the frame
	
	RMuint32 prot = ZOOM_FRAC(7, 8);  // 7/8 ratio: protect 14:9 portion of 16:9 frame
	RMbool input_16x9, input_4x3, output_16x9, output_4x3, content_16x9, content_4x3;
	struct EMhwlibAspectRatio content_ar;
	
	// set to neutral zoom window
	*x = ZOOM_0; *y = ZOOM_0; *w = ZOOM_1; *h = ZOOM_1;
	
	apply_active_format_common(content_afd, &output_ar, output_variable_ar, output_afd, 
		&input_16x9, &input_4x3, &output_16x9, &output_4x3, 
		&content_16x9, &content_4x3, &content_ar);
	
	// apply active format
	*update_zoom = content_afd.ActiveFormatValid;
	if (content_afd.ActiveFormatValid) {
		switch (content_afd.ActiveFormat) {  // adapt to active format
		default:
			*update_zoom = FALSE;
			return RM_ERROR;
		case EMhwlibAF_no_info: // don't apply active format
			*update_zoom = FALSE;
			break;
		case EMhwlibAF_16x9_top: // 16:9 top
			if (input_4x3) {
				*h = ZOOM_FRAC(3, 4);  // 3/4 height
			} else if (! input_16x9) {
				*update_zoom = FALSE;  // TODO
			}
			break;
		case EMhwlibAF_14x9_top: // 14:9 top
			if (input_16x9) {
				*w = ZOOM_FRAC(7, 8);  // 7/8 width
				*x = ZOOM_CENTER(*w);  // center horizontally
			} else if (input_4x3) {
				*h = ZOOM_FRAC(6, 7);  // 6/7 height
			} else { //if (content_afd.FrameAspectRatio.X * 9 > content_afd.FrameAspectRatio.Y * 14) {
				*update_zoom = FALSE;  // TODO
			}
			break;
		case EMhwlibAF_64x27_centered: // more than 16:9 (assume no less than cinemascope, 2.35:1, use 64:27: 720*270(NTSC), 720*324(PAL), 1280*540, 1920*810)
			// crop captured image (which will be 16:9) vertically?
			*h = ZOOM_FRAC(output_ar.Y * 16, output_ar.X * 9);  // make height fit into scaler
			if (input_16x9) {
				prot = ZOOM_FRAC(3, 4);  // 3/4 height
			} else if (input_4x3) {
				*h = RMmin(*h, ZOOM_FRAC(3, 4));  // 3/4 height
				prot = ZOOM_FRAC(9, 16);  // 9/16 height
			} else {
				*update_zoom = FALSE;  // TODO
			}
			*h = RMmin(*h, ZOOM_1);  // not more than 100% height
			*h = RMmax(*h, prot);  // not less than 64:27 center portion
			*y = ZOOM_CENTER(*h);  // center vertically
			break;
		case EMhwlibAF_same_as_picture: // same as picture, full screen zoom
			break;
		case EMhwlibAF_4x3_centered_prot_14x9: // 4:3 center, prot. 14:9
			// crop captured image (which will be 4:3) vertically?
			*h = ZOOM_FRAC(output_ar.Y * 4, output_ar.X * 3);  // make height fit into scaler
			*h = RMmin(*h, ZOOM_1);  // not more than 100% height
			*h = RMmax(*h, ZOOM_FRAC(6, 7));  // not less than 14:9 center portion, 6/7 height
			*y = ZOOM_CENTER(*h);  // center vertically
			// no break;
		case EMhwlibAF_4x3_centered: // 4:3 center
			// crop 16:9 image horizontally to get rid of black bars
			if (input_16x9) {
				*w = ZOOM_FRAC(3, 4);  // 3/4 width
				*x = ZOOM_CENTER(*w);  // center horizontally
			} else if (! input_4x3) {
				*update_zoom = FALSE;  // TODO
			}
			break;
		case EMhwlibAF_16x9_centered_prot_4x3: // 16:9 center, prot, 4:3
			prot = ZOOM_FRAC(3, 4);
			// no break;
		case EMhwlibAF_16x9_centered_prot_14x9: // 16:9 center, prot. 14:9
			// crop captured image (which will be 16:9) horizontally?
			*w = ZOOM_FRAC(output_ar.X * 9, output_ar.Y * 16);  // make width fit into scaler
			*w = RMmin(*w, ZOOM_1);  // not more than 100% width
			*w = RMmax(*w, prot);  // protect 14:9 center portion, 7/8 width, or 4:3 center portion, 4/3 width
			*x = ZOOM_CENTER(*w);  // center horizontally
			// no break;
		case EMhwlibAF_16x9_centered: // 16:9 center
			// crop 4:3 vertically (chop off black bars)
			if (input_4x3) {
				*h = ZOOM_FRAC(3, 4);  // 3/4 height
				*y = ZOOM_CENTER(*h);  // center vertically
			} else if (! input_16x9) {
				*update_zoom = FALSE;  // TODO
			}
			break;
		case EMhwlibAF_14x9_centered: // 14:9 center
			if (input_16x9) {
				*w = ZOOM_FRAC(7, 8);  // 7/8 width
				*x = ZOOM_CENTER(*w);  // center horizontally
			} else if (input_4x3) {
				*h = ZOOM_FRAC(6, 7);  // 6/7 height
				*y = ZOOM_CENTER(*h);  // center vertically
			} else {
				*update_zoom = FALSE;  // TODO
			}
			break;
		}
	}
	return RM_OK;
}

static RMint32 get_window_value(RMuint32 max_val, RMint32 val, enum EMhwlibDisplayWindowValueMode mode)
{
	RMint32 rc = 0;
	
	switch (mode) {
	case EMhwlibDisplayWindowValueMode_Fixed:
		rc = val;
		break;
	case EMhwlibDisplayWindowValueMode_Relative:
		rc = (RMint32)(val * max_val) / ZOOM_0;
		break;
	}
	
	return rc;
}

/*
static RMint32 get_window_position(RMuint32 total_size, RMuint32 size, RMint32 pos, enum EMhwlibDisplayWindowPositionMode mode)
{
	RMint32 val = 0;
	
	switch (mode) {
	case EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder:
		val = pos; 
		break;
	case EMhwlibDisplayWindowPositionMode_RearEdgeToBorder:
		val = total_size - pos - size;
		break;
	case EMhwlibDisplayWindowPositionMode_FrontEdgeToCenter:
		val = pos - size / 2;
		break;
	case EMhwlibDisplayWindowPositionMode_RearEdgeToCenter:
		val = total_size - pos - size / 2;
		break;
	}
		
	return val;
}
*/

RMstatus get_scaler_output_aspect_ratio(struct RUA *pRUA, 
	RMuint32 ScalerModuleID,  // scaler module ID
	RMuint32 MixerModuleID,  // module ID of the scaler's mixer
	struct EMhwlibAspectRatio *scaler_ar, 
	RMbool *variable_output)  // TRUE: scaler is full-screen, can modify output aspect ratio and active format
{
	RMstatus err;
	RMuint32 ScalerSrcIndex, MixerScalerModuleID;
	struct EMhwlibDisplayWindow scaler_out_window, default_out_window;
	struct EMhwlibAspectRatio output_ar;
	struct DispRouting_Routing_type routing;
	RMuint32 OutputModuleID;
	RMuint32 OutputWidth, OutputHeight;
	RMuint32 ScalerWidth, ScalerHeight;
	struct EMhwlibAspectRatio pixel_ar;
	
	// Get scaler output window
	err = RUAExchangeProperty(pRUA, MixerModuleID, 
		RMGenericPropertyID_MixerSourceIndex, 
		&ScalerModuleID, sizeof(ScalerModuleID), 
		&ScalerSrcIndex, sizeof(ScalerSrcIndex));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Can not get scaler index: %s\n", RMstatusToString(err)));
		return err;
	}
	MixerScalerModuleID = EMHWLIB_TARGET_MODULE(MixerModuleID, 0, ScalerSrcIndex);
	do {
		err = RUAGetProperty(pRUA, MixerScalerModuleID, 
			RMGenericPropertyID_MixerSourceWindow, 
			&(scaler_out_window), sizeof(scaler_out_window));
	} while (err == RM_PENDING);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Can not get scaler output window: %s\n", RMstatusToString(err)));
		return err;
	}
	
	// get mixer aspect ratio
	err = RUAGetProperty(pRUA, MixerModuleID, 
		RMGenericPropertyID_DisplayAspectRatio, 
		&output_ar, sizeof(output_ar));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Can not get mixer aspect ratio: %s\n", RMstatusToString(err)));
		return err;
	}
	RMDBGLOG((LOCALDBG, "Output aspect ratio: %lu:%lu\n", output_ar.X, output_ar.Y));
	
	scaler_ar->X = output_ar.X;
	scaler_ar->Y = output_ar.Y;
	
	// scaler window might be full screen
	if (variable_output) *variable_output = TRUE;
	
	// compare to default DCC window
	set_default_out_window(&default_out_window);
	if (RMMemcmp(&default_out_window, &scaler_out_window, sizeof(struct EMhwlibDisplayWindow)) == 0) {
		return RM_OK;  // done.
	}
	
	// compare to default HDMI window
	default_out_window.X = 0;
	default_out_window.Y = 0;
	default_out_window.Width = ZOOM_0;
	default_out_window.Height = ZOOM_0;
	default_out_window.XPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
	default_out_window.YPositionMode = EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder;
	default_out_window.XMode = EMhwlibDisplayWindowValueMode_Relative;
	default_out_window.YMode = EMhwlibDisplayWindowValueMode_Relative;
	default_out_window.WidthMode = EMhwlibDisplayWindowValueMode_Relative;
	default_out_window.HeightMode = EMhwlibDisplayWindowValueMode_Relative;
	if (RMMemcmp(&default_out_window, &scaler_out_window, sizeof(struct EMhwlibDisplayWindow)) == 0) {
		return RM_OK;  // done.
	}
	
	// scaler window is not full screen
	if (variable_output) *variable_output = FALSE;
	
	// find an output connected to the mixer
	err = RUAGetProperty(pRUA, DispRouting, 
		RMDispRoutingPropertyID_Routing, 
		&routing, sizeof(routing));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Can not get routing info: %s\n", RMstatusToString(err)));
		return err;
	}
	if (routing.DigitalOutputEnable && (routing.DigitalOutputSourceModuleID == MixerModuleID)) {
		OutputModuleID = DispDigitalOut;
	} else if (routing.MainAnalogOutputEnable && (routing.MainAnalogOutputSourceModuleID == MixerModuleID)) {
		OutputModuleID = DispMainAnalogOut;
	} else if (routing.ComponentOutputEnable && (routing.ComponentOutputSourceModuleID == MixerModuleID)) {
		OutputModuleID = DispComponentOut;
	} else if (routing.CompositeOutputEnable && (routing.CompositeOutputSourceModuleID == MixerModuleID)) {
		OutputModuleID = DispCompositeOut;
	} else {
		RMDBGLOG((ENABLE, "Can not get output ID\n"));
		return RM_ERROR;
	}
	
	// get output size
	if (OutputModuleID == DispDigitalOut) {
		struct EMhwlibTVFormatDigital tv_format;
		err = RUAGetProperty(pRUA, OutputModuleID, 
			RMGenericPropertyID_DigitalTVFormat, 
			&tv_format, sizeof(tv_format));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Can not get output size: %s\n", RMstatusToString(err)));
			return err;
		}
		OutputWidth = tv_format.ActiveWidth;
		OutputHeight = tv_format.ActiveHeight;
	} else {
		struct EMhwlibTVFormatAnalog tv_format;
		err = RUAGetProperty(pRUA, OutputModuleID, 
			RMGenericPropertyID_AnalogTVFormat, 
			&tv_format, sizeof(tv_format));
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Can not get output size: %s\n", RMstatusToString(err)));
			return err;
		}
		OutputWidth = tv_format.ActiveWidth;
		OutputHeight = tv_format.ActiveHeight;
	}
	RMDBGLOG((LOCALDBG, "Output size: %lux%lu\n", OutputWidth, OutputHeight));
	
	// calculate scaler output window size
	ScalerWidth  = get_window_value(OutputWidth,  scaler_out_window.Width,  scaler_out_window.WidthMode); 
	ScalerHeight = get_window_value(OutputHeight, scaler_out_window.Height, scaler_out_window.HeightMode);
	RMDBGLOG((LOCALDBG, "Scaler size: %lux%lu\n", ScalerWidth, ScalerHeight));
	
	// calculate output pixel aspect ratio
	pixel_ar.X = output_ar.X * OutputHeight;
	pixel_ar.Y = output_ar.Y * OutputWidth;
	reduce_aspect_ratio(&(pixel_ar.X), &(pixel_ar.Y), 4095);
	RMDBGLOG((LOCALDBG, "Pixel aspect ratio: %lu:%lu\n", pixel_ar.X, pixel_ar.Y));
	
	// calculate scaler picture aspect ratio
	scaler_ar->X = pixel_ar.X * ScalerWidth;
	scaler_ar->Y = pixel_ar.Y * ScalerHeight;
	reduce_aspect_ratio(&(scaler_ar->X), &(scaler_ar->Y), 4095);
	RMDBGLOG((LOCALDBG, "Scaler aspect ratio: %lu:%lu\n", scaler_ar->X, scaler_ar->Y));
	
	return RM_OK;
}

/** Apply active format and frame aspect ratio to a scaler */
/* If output_afd is used, and different from previuous one, apply to output with apply_active_format_output() */
RMstatus apply_active_format_input(struct RUA *pRUA, 
	RMuint32 ScalerModuleID,  // scaler module ID of the content surface
	RMuint32 MixerModuleID,  // module ID of the scaler's mixer
	struct EMhwlibActiveFormatDescription content_afd,  // active format description of the content and picture aspect ratio of the input frame
	RMbool zoom_abs,  // TRUE: sets scaler input window with absolute pixel values, current input window needs to be set to full frame and absolute; FALSE: sets scaler input window with relative values, uses complete input frame
	RMuint32 *x_abs,  // for zoom_abs=TRUE, these full frame window values will be used, unless they are NULL.
	RMuint32 *y_abs,  // if not NULL, these values will be filled with the new zoom window for set_scaler_source_zoom()
	RMuint32 *w_abs, 
	RMuint32 *h_abs, 
	RMbool output_variable_ar,  // TRUE: output is capable of both, 4:3 and 16:9 (e.g. 480i, 480p); FALSE: output only supports current aspect ratio
	struct EMhwlibActiveFormatDescription *output_afd)  // new active format and frame aspect ratio for the output (needs to be applied to output by caller)
{
	RMstatus err;
	RMuint32 x, y, w, h;  // input and output of scaler
	RMbool update_zoom = FALSE, variable_output = TRUE;
	struct EMhwlibAspectRatio scaler_ar;
	struct EMhwlibActiveFormatDescription prev_output_afd = {0,};
	
	if (output_afd) {
		prev_output_afd = *output_afd;
	}
	
	if (ScalerModuleID) {
		err = get_scaler_output_aspect_ratio(pRUA, ScalerModuleID, MixerModuleID, &scaler_ar, &variable_output);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Can not get scaler output aspect ratio! %s\n", RMstatusToString(err)));
			return err;
		}
	} else {
		scaler_ar.X = output_afd->FrameAspectRatio.X;
		scaler_ar.Y = output_afd->FrameAspectRatio.Y;
	}
	if (! variable_output) {
		output_variable_ar = FALSE;
	}
	
	RMDBGLOG((LOCALDBG, "Setting up input window of Scaler 0x%08lX with %salid Active Format \"%s\" (%u), Frame Aspect Ratio %lu:%lu\n", 
		ScalerModuleID, 
		content_afd.ActiveFormatValid ? "V" : "Inv", 
		get_afd_name(content_afd.ActiveFormat), 
		content_afd.ActiveFormat, 
		content_afd.FrameAspectRatio.X, 
		content_afd.FrameAspectRatio.Y));
	
	// determine new scaler input window
	if (zoom_abs && ScalerModuleID) {
		if (x_abs && y_abs && w_abs && h_abs) {
			x = *x_abs;
			y = *y_abs;
			w = *w_abs;
			h = *h_abs;
		} else {
			struct EMhwlibDisplayWindow zoom;
			err = RUAGetProperty(pRUA, ScalerModuleID, 
				RMGenericPropertyID_ScalerInputWindow, 
				&zoom, sizeof(zoom));
			if (RMSUCCEEDED(err) &&  // make sure, current input window is abolute
				(zoom.XPositionMode == EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder) && 
				(zoom.YPositionMode == EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder) && 
				(zoom.XMode == EMhwlibDisplayWindowValueMode_Fixed) && 
				(zoom.YMode == EMhwlibDisplayWindowValueMode_Fixed) && 
				(zoom.WidthMode == EMhwlibDisplayWindowValueMode_Fixed) && 
				(zoom.HeightMode == EMhwlibDisplayWindowValueMode_Fixed)
			) {
				x = zoom.X;
				y = zoom.Y;
				w = zoom.Width;
				h = zoom.Height;
			} else {
				RMDBGLOG((ENABLE, "Scaler input window needs to be set with absolute pixel values!\n"));
				return RM_ERROR;
			}
		}
		err = apply_active_format_abs(content_afd, scaler_ar, 
			output_variable_ar, output_afd, 
			&x, &y, &w, &h, &update_zoom);
	} else {
		err = apply_active_format_rel(content_afd, scaler_ar, 
			output_variable_ar, output_afd, 
			&x, &y, &w, &h, &update_zoom);
	}
	if (RMSUCCEEDED(err) && update_zoom && ScalerModuleID) {
		err = set_scaler_source_zoom(pRUA, ScalerModuleID, x, y, w, h);
		if (x_abs && y_abs && w_abs && h_abs) {
			*x_abs = x;
			*y_abs = y;
			*w_abs = w;
			*h_abs = h;
		}
	}
	
	// Restore original output_afd, if output can not be changed
	if (! variable_output && output_afd) {
		*output_afd = prev_output_afd;
	}
	
	return err;
}

RMstatus apply_active_format_output_module(struct RUA *pRUA, 
	RMuint32 OutputModuleID, 
	struct DH_control *pDH, 
	struct EMhwlibActiveFormatDescription output_afd)
{
	RMstatus err;
	
	RMDBGLOG((LOCALDBG, "Setting up %s output with %salid Active Format \"%s\" (%u), Frame Aspect Ratio %lu:%lu\n", 
		(OutputModuleID == DispDigitalOut) ? "Digital" : 
		(OutputModuleID == DispMainAnalogOut) ? "Main Analog" : 
		(OutputModuleID == DispComponentOut) ? "Component" : 
		(OutputModuleID == DispCompositeOut) ? "Composite" : 
		"unknown", 
		output_afd.ActiveFormatValid ? "V" : "Inv", 
		get_afd_name(output_afd.ActiveFormat), 
		output_afd.ActiveFormat, 
		output_afd.FrameAspectRatio.X, 
		output_afd.FrameAspectRatio.Y));
	
	// Set output active format
	if (OutputModuleID == DispDigitalOut) {
		if (pDH) {
			DHModifyAVIAspectRatio(pDH, output_afd.FrameAspectRatio);
			DHModifyAVIActiveFormat(pDH, output_afd.ActiveFormatValid, output_afd.ActiveFormat);
		}
	} else {
		// "read - modify - write" of active format inside AnalogFrameInfo
		RMuint32 APIVersion = 1;  // this is the API version of the AnalogFrameInfo property currently supported by this application
		struct EMhwlibAnalogFrameInfo frame_info;
		
		err = RUAExchangeProperty(pRUA, OutputModuleID, 
			RMGenericPropertyID_AnalogFrameInfoQuery, 
			&APIVersion, sizeof(APIVersion), 
			&frame_info, sizeof(frame_info));
		if (RMSUCCEEDED(err)) {
			frame_info.Frame.AFD = output_afd;
			DCCSPERR(pRUA, OutputModuleID, RMGenericPropertyID_AnalogFrameInfo, &frame_info, sizeof(frame_info), "Error setting OutputActiveFormat");
		}
	}
	
	// Validate output
	DCCSPERR(pRUA, OutputModuleID, RMGenericPropertyID_Validate, NULL, 0, "Failed to validate output");
	
	return RM_OK;
}

/** Apply active format and frame aspect ratio to output (as returned by apply_active_format_input()) */
RMstatus apply_active_format_output(struct RUA *pRUA, 
	RMuint32 MixerModuleID,  // module ID of the output's mixer
	struct DH_control *pDH,  // current HDMI output handle, or NULL
	struct EMhwlibActiveFormatDescription output_afd)  // active format and frame aspect ratio for the output
{
	RMstatus err;
	struct DispRouting_Routing_type routing;
	
	RMDBGLOG((LOCALDBG, "Setting up all outputs on Mixer 0x%08lX with %salid Active Format \"%s\" (%u), Frame Aspect Ratio %lu:%lu\n", 
		MixerModuleID, 
		output_afd.ActiveFormatValid ? "V" : "Inv", 
		get_afd_name(output_afd.ActiveFormat), 
		output_afd.ActiveFormat, 
		output_afd.FrameAspectRatio.X, 
		output_afd.FrameAspectRatio.Y));
	
	// find all outputs connected to the mixer
	err = RUAGetProperty(pRUA, DispRouting, 
		RMDispRoutingPropertyID_Routing, 
		&routing, sizeof(routing));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Can not get routing info: %s\n", RMstatusToString(err)));
		return err;
	}
	
	RMDBGLOG((DISABLE, "Routing: DIG:%u,0x%08lX, MAO:%u,0x%08lX, CAV:%u,0x%08lX, CVBS:%u,0x%08lX\n", 
		routing.DigitalOutputEnable, routing.DigitalOutputSourceModuleID, 
		routing.MainAnalogOutputEnable, routing.MainAnalogOutputSourceModuleID, 
		routing.ComponentOutputEnable, routing.ComponentOutputSourceModuleID, 
		routing.CompositeOutputEnable, routing.CompositeOutputSourceModuleID));
	
	if (routing.DigitalOutputEnable && (routing.DigitalOutputSourceModuleID == MixerModuleID)) {
		err = apply_active_format_output_module(pRUA, DispDigitalOut,    pDH, output_afd);
	}
	if (routing.MainAnalogOutputEnable && (routing.MainAnalogOutputSourceModuleID == MixerModuleID)) {
		err = apply_active_format_output_module(pRUA, DispMainAnalogOut, pDH, output_afd);
	}
	if (routing.ComponentOutputEnable && (routing.ComponentOutputSourceModuleID == MixerModuleID)) {
		err = apply_active_format_output_module(pRUA, DispComponentOut,  pDH, output_afd);
	}
	if (routing.CompositeOutputEnable && (routing.CompositeOutputSourceModuleID == MixerModuleID)) {
		err = apply_active_format_output_module(pRUA, DispCompositeOut,  pDH, output_afd);
	}
	
	// Set frame aspect ratio
	DCCSPERR(pRUA, MixerModuleID, RMGenericPropertyID_DisplayAspectRatio, &(output_afd.FrameAspectRatio), sizeof(output_afd.FrameAspectRatio), "Error setting DisplayAspectRatio");
	
	// Validate mixer
	DCCSPERR(pRUA, MixerModuleID, RMGenericPropertyID_Validate, NULL, 0, "Failed to validate mixer");
	
	return RM_OK;
}
	
RMstatus get_output_variable_aspect_ratio(
	enum EMhwlibTVStandard TVStandard, 
	RMbool *output_variable_ar)
{
	switch (TVStandard) {
	case EMhwlibTVStandard_HDMI_480p59: 
	case EMhwlibTVStandard_HDMI_480p60: 
	case EMhwlibTVStandard_HDMI_480i59: 
	case EMhwlibTVStandard_HDMI_480i60: 
	case EMhwlibTVStandard_HDMI_1440x480i59: 
	case EMhwlibTVStandard_HDMI_1440x480i60: 
	case EMhwlibTVStandard_HDMI_240p59: 
	case EMhwlibTVStandard_HDMI_240p60: 
	case EMhwlibTVStandard_HDMI_1440x240p59: 
	case EMhwlibTVStandard_HDMI_1440x240p60: 
	case EMhwlibTVStandard_HDMI_2880x480i59: 
	case EMhwlibTVStandard_HDMI_2880x480i60: 
	case EMhwlibTVStandard_HDMI_2880x240p59: 
	case EMhwlibTVStandard_HDMI_2880x240p60: 
	case EMhwlibTVStandard_HDMI_1440x480p59: 
	case EMhwlibTVStandard_HDMI_1440x480p60: 
	case EMhwlibTVStandard_HDMI_576p50: 
	case EMhwlibTVStandard_HDMI_576i50: 
	case EMhwlibTVStandard_HDMI_1440x576i50: 
	case EMhwlibTVStandard_HDMI_288p50: 
	case EMhwlibTVStandard_HDMI_1440x288p50: 
	case EMhwlibTVStandard_HDMI_2880x576i50: 
	case EMhwlibTVStandard_HDMI_2880x288p50: 
	case EMhwlibTVStandard_HDMI_1440x576p50: 
	case EMhwlibTVStandard_HDMI_2880x480p59: 
	case EMhwlibTVStandard_HDMI_2880x480p60: 
	case EMhwlibTVStandard_HDMI_2880x576p50: 
	case EMhwlibTVStandard_HDMI_576p100: 
	case EMhwlibTVStandard_HDMI_576i100: 
	case EMhwlibTVStandard_HDMI_1440x576i100: 
	case EMhwlibTVStandard_HDMI_480p119: 
	case EMhwlibTVStandard_HDMI_480p120: 
	case EMhwlibTVStandard_HDMI_480i119: 
	case EMhwlibTVStandard_HDMI_480i120: 
	case EMhwlibTVStandard_HDMI_1440x480i119: 
	case EMhwlibTVStandard_HDMI_1440x480i120: 
	case EMhwlibTVStandard_HDMI_576p200: 
	case EMhwlibTVStandard_HDMI_576i200: 
	case EMhwlibTVStandard_HDMI_1440x576i200: 
	case EMhwlibTVStandard_HDMI_480p239: 
	case EMhwlibTVStandard_HDMI_480p240: 
	case EMhwlibTVStandard_HDMI_480i239: 
	case EMhwlibTVStandard_HDMI_480i240: 
	case EMhwlibTVStandard_HDMI_1440x480i239: 
	case EMhwlibTVStandard_HDMI_1440x480i240: 
	case EMhwlibTVStandard_ITU_Bt656_525: 
	case EMhwlibTVStandard_ITU_Bt656_240p: 
	case EMhwlibTVStandard_NTSC_M_Japan: 
	case EMhwlibTVStandard_NTSC_M: 
	case EMhwlibTVStandard_PAL_60: 
	case EMhwlibTVStandard_PAL_M: 
	case EMhwlibTVStandard_480p59: 
	case EMhwlibTVStandard_NTSC_M_Japan_714: 
	case EMhwlibTVStandard_NTSC_M_714: 
	case EMhwlibTVStandard_PAL_60_714: 
	case EMhwlibTVStandard_PAL_M_714: 
	case EMhwlibTVStandard_480p59_714: 
	case EMhwlibTVStandard_ITU_Bt656_625: 
	case EMhwlibTVStandard_ITU_Bt656_288p: 
	case EMhwlibTVStandard_PAL_BG: 
	case EMhwlibTVStandard_PAL_N: 
	case EMhwlibTVStandard_576p50: 
	case EMhwlibTVStandard_PAL_BG_702: 
	case EMhwlibTVStandard_PAL_N_702: 
	case EMhwlibTVStandard_576p50_702: 
	case EMhwlibTVStandard_PAL_BG_704: 
	case EMhwlibTVStandard_PAL_N_704: 
	case EMhwlibTVStandard_576p50_704: 
		*output_variable_ar = TRUE;
		break;
	default: 
		*output_variable_ar = FALSE;
		break;
	}
	return RM_OK;
}

// call this when the output video mode has changed
RMstatus update_output_afd_settings(
	struct dcc_context *dcc_info, 
	struct display_cmdline *disp_opt, 
	RMbool *pUpdate)
{
	RMbool update = FALSE, variable;
	
	if (dcc_info == NULL) return RM_FATALINVALIDPOINTER;
	if (disp_opt == NULL) return RM_FATALINVALIDPOINTER;
	
	switch (dcc_info->route) {
		default:
		case DCCRoute_Main:
			if (disp_opt->afd_info.MixerModuleID != DispMainMixer) update = TRUE;
			disp_opt->afd_info.MixerModuleID = DispMainMixer;
			break;
		case DCCRoute_Secondary:
			if (disp_opt->afd_info.MixerModuleID != DispVCRMixer) update = TRUE;
			disp_opt->afd_info.MixerModuleID = DispVCRMixer;
			break;
		case DCCRoute_ColorBars:
			if (disp_opt->afd_info.MixerModuleID != DispColorBars) update = TRUE;
			disp_opt->afd_info.MixerModuleID = DispColorBars;
			break;
	}
	if (disp_opt->afd_info.MixerAFD.FrameAspectRatio.X != disp_opt->ar_x) update = TRUE;
	disp_opt->afd_info.MixerAFD.FrameAspectRatio.X = disp_opt->ar_x;
	if (disp_opt->afd_info.MixerAFD.FrameAspectRatio.Y != disp_opt->ar_y) update = TRUE;
	disp_opt->afd_info.MixerAFD.FrameAspectRatio.Y = disp_opt->ar_y;
	if (disp_opt->afd_info.MixerAFD.ActiveFormat != disp_opt->active_format) update = TRUE;
	disp_opt->afd_info.MixerAFD.ActiveFormat = disp_opt->active_format;
	if (disp_opt->afd_info.MixerAFD.ActiveFormatValid != disp_opt->active_format_valid) update = TRUE;
	disp_opt->afd_info.MixerAFD.ActiveFormatValid = disp_opt->active_format_valid;
	get_output_variable_aspect_ratio(disp_opt->standard, &variable);
	if (disp_opt->afd_info.MixerVariableAR != variable) update = TRUE;
	disp_opt->afd_info.MixerVariableAR = variable;
	
	if (disp_opt->afd_info.HDSDModuleID != (RMuint32)((disp_opt->use_hdsd_conversion) ? DispHDSDConverter : 0)) update = TRUE;
	disp_opt->afd_info.HDSDModuleID = (disp_opt->use_hdsd_conversion) ? DispHDSDConverter : 0;
	if (disp_opt->use_hdsd_conversion) {
		if (disp_opt->afd_info.HDSDAFD.FrameAspectRatio.X != disp_opt->sd_ar_x) update = TRUE;
		disp_opt->afd_info.HDSDAFD.FrameAspectRatio.X = disp_opt->sd_ar_x;
		if (disp_opt->afd_info.HDSDAFD.FrameAspectRatio.Y != disp_opt->sd_ar_y) update = TRUE;
		disp_opt->afd_info.HDSDAFD.FrameAspectRatio.Y = disp_opt->sd_ar_y;
		if (disp_opt->afd_info.HDSDAFD.ActiveFormat != disp_opt->sd_active_format) update = TRUE;
		disp_opt->afd_info.HDSDAFD.ActiveFormat = disp_opt->sd_active_format;
		if (disp_opt->afd_info.HDSDAFD.ActiveFormatValid != disp_opt->sd_active_format_valid) update = TRUE;
		disp_opt->afd_info.HDSDAFD.ActiveFormatValid = disp_opt->sd_active_format_valid;
		get_output_variable_aspect_ratio(disp_opt->sd_standard, &variable);
		if (disp_opt->afd_info.HDSDVariableAR != variable) update = TRUE;
		disp_opt->afd_info.HDSDVariableAR = variable;
	}
	
	if (update) {
		RMDBGLOG((LOCALDBG, "Current ActiveFormat setup of the Mixer 0x%08lX: %salid Active Format \"%s\" (%u), Frame Aspect Ratio %lu:%lu\n", 
			disp_opt->afd_info.MixerModuleID, 
			disp_opt->afd_info.MixerAFD.ActiveFormatValid ? "V" : "Inv", 
			get_afd_name(disp_opt->afd_info.MixerAFD.ActiveFormat), 
			disp_opt->afd_info.MixerAFD.ActiveFormat, 
			disp_opt->afd_info.MixerAFD.FrameAspectRatio.X, 
			disp_opt->afd_info.MixerAFD.FrameAspectRatio.Y));
		if (disp_opt->afd_info.HDSDModuleID) {
			RMDBGLOG((LOCALDBG, "Current ActiveFormat setup of the HD-to-SD downconverter 0x%08lX: %salid Active Format \"%s\" (%u), Frame Aspect Ratio %lu:%lu\n", 
				disp_opt->afd_info.HDSDModuleID, 
				disp_opt->afd_info.HDSDAFD.ActiveFormatValid ? "V" : "Inv", 
				get_afd_name(disp_opt->afd_info.HDSDAFD.ActiveFormat), 
				disp_opt->afd_info.HDSDAFD.ActiveFormat, 
				disp_opt->afd_info.HDSDAFD.FrameAspectRatio.X, 
				disp_opt->afd_info.HDSDAFD.FrameAspectRatio.Y));
		}
	}
	
	if (pUpdate != NULL) *pUpdate = update;
	
	return RM_OK;
}

RMstatus apply_active_format(
	struct RUA *pRUA, 
	struct display_cmdline *disp_opt, 
	struct EMhwlibActiveFormatDescription ContentAFD,  // active format description of the content and picture aspect ratio of the input frame
	RMuint32 ScalerModuleID)  // scaler module ID of the content surface
{
	if (pRUA == NULL) return RM_FATALINVALIDPOINTER;
	if (disp_opt == NULL) return RM_FATALINVALIDPOINTER;
	
	// Apply content AFD to the scaler input window (zoom)
	apply_active_format_input(pRUA, 
		ScalerModuleID, 
		disp_opt->afd_info.MixerModuleID, 
		ContentAFD, 
		FALSE, NULL, NULL, NULL, NULL, 
		disp_opt->afd_info.MixerVariableAR, 
		&(disp_opt->afd_info.MixerAFD));
	
	// Modify output AFD, as needed
	if (
		(disp_opt->afd_info.MixerAFD.FrameAspectRatio.X && (disp_opt->afd_info.MixerAFD.FrameAspectRatio.X != disp_opt->ar_x)) || 
		(disp_opt->afd_info.MixerAFD.FrameAspectRatio.Y && (disp_opt->afd_info.MixerAFD.FrameAspectRatio.Y != disp_opt->ar_y)) || 
		(disp_opt->afd_info.MixerAFD.ActiveFormatValid && (disp_opt->afd_info.MixerAFD.ActiveFormat != disp_opt->active_format)) || 
		(disp_opt->afd_info.MixerAFD.ActiveFormatValid != disp_opt->active_format_valid)
	) {
		apply_active_format_output(pRUA, 
			disp_opt->afd_info.MixerModuleID, 
			disp_opt->dh_info->pDH, 
			disp_opt->afd_info.MixerAFD);
		disp_opt->ar_x = disp_opt->afd_info.MixerAFD.FrameAspectRatio.X;
		disp_opt->ar_y = disp_opt->afd_info.MixerAFD.FrameAspectRatio.Y;
		disp_opt->active_format_valid = disp_opt->afd_info.MixerAFD.ActiveFormatValid;
		disp_opt->active_format = disp_opt->afd_info.MixerAFD.ActiveFormat;
		
		RMDBGLOG((LOCALDBG, "New ActiveFormat setup of the Mixer 0x%08lX: %salid Active Format \"%s\" (%u), Frame Aspect Ratio %lu:%lu\n", 
			disp_opt->afd_info.MixerModuleID, 
			disp_opt->afd_info.MixerAFD.ActiveFormatValid ? "V" : "Inv", 
			get_afd_name(disp_opt->afd_info.MixerAFD.ActiveFormat), 
			disp_opt->afd_info.MixerAFD.ActiveFormat, 
			disp_opt->afd_info.MixerAFD.FrameAspectRatio.X, 
			disp_opt->afd_info.MixerAFD.FrameAspectRatio.Y));
		
		if (disp_opt->afd_info.HDSDModuleID) {
			apply_active_format_input(pRUA, 
				0, // no ScalerModuleID
				disp_opt->afd_info.HDSDModuleID, 
				disp_opt->afd_info.MixerAFD, 
				FALSE, NULL, NULL, NULL, NULL, 
				disp_opt->afd_info.HDSDVariableAR, 
				&(disp_opt->afd_info.HDSDAFD));
			
			// Modify output AFD, as needed
			if (
				(disp_opt->afd_info.MixerAFD.FrameAspectRatio.X && (disp_opt->afd_info.MixerAFD.FrameAspectRatio.X != disp_opt->sd_ar_x)) || 
				(disp_opt->afd_info.MixerAFD.FrameAspectRatio.Y && (disp_opt->afd_info.MixerAFD.FrameAspectRatio.Y != disp_opt->sd_ar_y)) || 
				(disp_opt->afd_info.MixerAFD.ActiveFormatValid && (disp_opt->afd_info.MixerAFD.ActiveFormat != disp_opt->sd_active_format)) || 
				(disp_opt->afd_info.MixerAFD.ActiveFormatValid != disp_opt->sd_active_format_valid)
			) {
				apply_active_format_output(pRUA, 
					disp_opt->afd_info.HDSDModuleID, 
					disp_opt->dh_info->pDH, 
					disp_opt->afd_info.HDSDAFD);
				disp_opt->sd_ar_x = disp_opt->afd_info.MixerAFD.FrameAspectRatio.X;
				disp_opt->sd_ar_y = disp_opt->afd_info.MixerAFD.FrameAspectRatio.Y;
				disp_opt->sd_active_format_valid = disp_opt->afd_info.MixerAFD.ActiveFormatValid;
				disp_opt->sd_active_format = disp_opt->afd_info.MixerAFD.ActiveFormat;
				
				RMDBGLOG((LOCALDBG, "New ActiveFormat setup of the HD-to-SD downconverter 0x%08lX: %salid Active Format \"%s\" (%u), Frame Aspect Ratio %lu:%lu\n", 
					disp_opt->afd_info.HDSDModuleID, 
					disp_opt->afd_info.HDSDAFD.ActiveFormatValid ? "V" : "Inv", 
					get_afd_name(disp_opt->afd_info.HDSDAFD.ActiveFormat), 
					disp_opt->afd_info.HDSDAFD.ActiveFormat, 
					disp_opt->afd_info.HDSDAFD.FrameAspectRatio.X, 
					disp_opt->afd_info.HDSDAFD.FrameAspectRatio.Y));
			}
		}
	}
	
	return RM_OK;
}

