/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   main_apps.h
  @brief  main application entry points

  @author Julien Soulier
  @date   2005-03-11
*/

#ifndef __MAIN_APPS_H__
#define __MAIN_APPS_H__

#include "../rmproperties/include/rmexternalproperties.h"
#include "../rmdetectorapi/include/rmdetectorapi.h"

enum rfp_application{
	NOT_SUPPORTED = 0,
	APP_DEMUX,
	APP_VIDEO,
	APP_AUDIO,
	APP_PICTURE,
	APP_AVI,
	APP_ASF,
	APP_MP4,
	APP_DEMUX_SOFT,
	APP_AVI_PULL
};

/* filled by rfp_detect */
struct rfp_stream_info{
	RMsystemType system_type;
	RMvideoType video_type;
	eAudioFormat_type audio_type;

	/* deprecated, do not use */
	RMFDetector_type detected_type;
};

/* read by rfp_detect */
struct rfp_detect_options{
	RMbool force_sd;
};


/* fields that are required by the play_xxx functions */	
struct mono_info{
	struct DCC *pDCC;
	struct RUA *pRUA;
	RMuint32 video_scaler;
	RMuint32 osd_scaler;
	struct playback_cmdline *play_opt;
	struct video_cmdline *video_opt;
	struct display_cmdline *disp_opt;
	struct audio_cmdline *audio_opt;
	struct demux_cmdline *demux_opt;
	void *context;
	void *dtcpCookieHandle;
	RMbool noDolby;
	struct stream_options_s stream_opts;
};

	

struct OSDdoubleBuffer {
	RMuint8 *buf0;
	RMuint32 buf0Size;
	RMuint32 buf0Addr;
	RMbool isBuf0inUse;
	RMbool buf0Cleared;

	RMuint8 *buf1;
	RMuint32 buf1Size;
	RMuint32 buf1Addr;
	RMbool isBuf1inUse;
	RMbool buf1Cleared;

	RMuint32 width;
	RMuint32 height;
	
};

struct rfp_file {
	RMfile file;
};

RM_EXTERN_C_BLOCKSTART



RMstatus rfp_detect(struct mono_info *app_params, 
		    struct rfp_detect_options *detect_opt,
		    enum rfp_application *app,
		    struct rfp_stream_info *stream_info);

RMstatus rfp_detect_open_file(RMfile file, 
			      struct mono_info *app_params, 
			      struct rfp_detect_options *detect_opt,
			      enum rfp_application *app,
			      struct rfp_stream_info *stream_info);

RMstatus rfp_open_file(struct mono_info *app_params, 
		       struct rfp_stream_info *stream_info, 
		       struct rfp_file *pfile);

RMstatus rfp_close_file(struct rfp_file *pfile);

RMstatus rfp_play(struct mono_info *app_params, enum rfp_application app);



/* this structure is deprecated and will disappear */		   
struct player_options{
	RMbool forceSD;
	RMbool use_hwdemux;
	RMbool use_avi_push;
};


/* this function is deprecated and will disappear */		   
RMstatus play_file(struct mono_info *app_params,
		   struct player_options *player_conf);






// callback to pass DCC context to application
void RMDCCInfo(struct dcc_context *dcc_info);


/* this callback is called when the avi demux found a non interleaved DIVX. 
   Returns TRUE to play it and FALSE to skip it */
RMbool RMPlayNonInterleavedAVI(void);


/* this is the EOS callback, must be implemented by curacao */
void RMEOSCallback(void);

/* this is the subtitle callback, must be implemented by curacao or mono which
   handle the OSD

   if (usePTS == TRUE), the application must show the subtitle according to 
   the current time and the pts of the subtitle.
   if (usePTS == FALSE), the application must show the subtitle as soon as possible
   because the synchronisation was done before calling RMSubtitleCallback
*/

void RMSubtitleCallback(RMuint8 *string, RMuint64 pts, RMbool usePTS);

 // callback to pass stream information to the application, DRM protected, number of chapters, etc
void RMFileStreamInfoCallback(struct RMFileStreamInfo *streamInfo);
 

/* used for NeroDigital SPU */

RMstatus RMInitDoubleBufferOSD(RMuint32 *moduleID, struct DCCOSDProfile osdProfile, struct OSDdoubleBuffer *doubleBuffer);
RMstatus RMInitSPU(RMuint32 width, RMuint32 height);
RMstatus RMBlendSPU(RMuint8 *buffer);
RMstatus RMClearSPU(void);
RMstatus RMCloseSPU(void);

/* this is the subtitle callback, must be implemented by curacao or mono which
   handle the OSD

   if (usePTS == TRUE), the application must show the subtitle according to 
   the current time and the pts of the subtitle.
   if (usePTS == FALSE), the application must show the subtitle as soon as possible
   because the synchronisation was done before calling RMSubtitleCallback
*/

void RMSubtitleCallback(RMuint8 *string, RMuint64 pts, RMbool usePTS);

/**
   @param mono  
   @return
*/
int main_demux(struct mono_info *mono);

/**
   @param mono  
   @return
*/
int main_psfdemux(struct mono_info *mono);

/**
   @param mono
   @return
*/
int main_asf(struct mono_info *mono);

/**
   @param mono
   @return
*/
int main_avi_push(struct mono_info *mono);

/**
   @param mono
   
   @return
*/
int main_mp4(struct mono_info *mono);

/**
   @param mono
   @return
*/
int main_video(struct mono_info *mono);

/**
   @param mono
   @return
*/
int main_audio(struct mono_info *mono);

/**
   @param mono
   @return
*/

int main_picture(struct mono_info *mono);


/* the following calls are used to get informations when playing wmvhd discs */

/**
   @param context       
   @param time_sec      
   @return 
*/
RMstatus asf_get_video_duration(void *context, RMuint32 *time_sec);

/**
   @param context       
   @param time_sec      
   @return
*/
RMstatus asf_get_playback_position(void *context, RMuint32 *time_sec);

/**
   @param context       
   @param languageID    
   @return
*/
RMstatus asf_get_audio_languageId(void *context, RMasfdemuxLanguageID * languageID);

/**
   @param context       
   @param stream        
   @return
*/
RMstatus asf_get_current_audio_stream(void *context, RMuint32 *stream);

/**
   @param context       
   @param count 
   @return
*/
RMstatus asf_get_audio_stream_count(void *context, RMuint32 *count);

/**
   @param context       
   @param time_sec      
   @param true_time_sec 
   @return
*/
RMstatus asf_get_real_seek_position(void *context, RMuint32 time_sec, RMuint32 *true_time_sec);

RM_EXTERN_C_BLOCKEND

#endif // __MAIN_APPS_H__
