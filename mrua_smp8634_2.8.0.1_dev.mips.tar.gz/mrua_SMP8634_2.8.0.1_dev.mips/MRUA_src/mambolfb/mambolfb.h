#ifndef __MAMBOLFB_H__
#define __MAMBOLFB_H__

/** Minimum parameters to define a buffer for this FB */
struct mambolfb_config_s {
	unsigned long videomemory;
	unsigned long videomemorysize;
	unsigned long palette;
	unsigned long xres;
	unsigned long yres;
	unsigned long bits_per_pixel;
};

/** IOCTL commands to set/get the underlying buffer */
#define MAMBOLFBIO_SETBUFFER	0x4619
#define MAMBOLFBIO_GETBUFFER	0x461a
	
#endif /* __MAMBOLFB_H__ */



	
