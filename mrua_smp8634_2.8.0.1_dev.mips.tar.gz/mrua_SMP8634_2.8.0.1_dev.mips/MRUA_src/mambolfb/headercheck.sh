#!/bin/sh
# whoever wrote this script, thank you
echo "#define __KERNEL__
#include <linux/mm.h>
int do_test_remap_page_range(void) {
   pgprot_t pgprot;
   remap_page_range(NULL, 0, 0, 0, pgprot);
}" > $1/remap_page_range.c

if [ -z "$MUM_KI" ] ; then
MUM_KI="-I/usr/src/linux-`uname -r`/include -I/usr/src/linux-2.4/include"
fi
${CROSS}gcc $MUM_KI -c $1/remap_page_range.c -o $1/remap_page_range.o >/dev/null 2>&1

if test -f $1/remap_page_range.o; then
  rm -f $1/remap_page_range.*
  echo  -DREMAP_PAGE_RANGE_FIVE_ARGS=1
else
  rm -f $1/remap_page_range.*
fi
