/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   undef_callid.h
  @brief  

  long description

  @author Julien Soulier
  @date   2003-08-25
*/

#ifndef __UNDEF_CALLID_H__
#define __UNDEF_CALLID_H__

#define GBUS_SPIN_LOCK_IRQ                  1
#define GBUS_SPIN_UNLOCK_IRQ                2
#define GBUS_MUTEX_LOCK                     3
#define GBUS_MUTEX_TRYLOCK                  4

RMuint32 do_undef_call_2(RMuint32 callid, RMuint32 arg1);
RMuint32 do_undef_call_3(RMuint32 callid, RMuint32 arg1, RMuint32 arg2);
RMuint32 do_undef_call_4(RMuint32 callid, RMuint32 arg1, RMuint32 arg2, RMuint32 arg3);

#endif // __UNDEF_CALLID_H__
