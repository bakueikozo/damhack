/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   irq_handler_labels.h
  @brief  

  long description

  @author Emmanuel Michon
  @date   2004-02-20
*/

#ifndef __IRQ_HANDLER_LABELS_H__
#define __IRQ_HANDLER_LABELS_H__

#if (EM86XX_CHIP==EM86XX_CHIPID_MAMBOLIGHT)

#if (EM86XX_MODE==EM86XX_MODEID_WITHHOST)
#include "irq_handler_mambolight_withhost_labels.h"
#define irq_handler_labels irq_handler_mambolight_withhost_labels
#elif (EM86XX_MODE==EM86XX_MODEID_STANDALONE)
#include "irq_handler_mambolight_standalone_labels.h"
#define irq_handler_labels irq_handler_mambolight_standalone_labels
#else
#error EM86XX_MODE is not set in RMCFLAGS: refer to emhwlib/include/emhwlib_modes.h.
#endif // EM86XX_MODE = ...

#elif (EM86XX_CHIP==EM86XX_CHIPID_MAMBO)

#if (EM86XX_MODE==EM86XX_MODEID_WITHHOST)
#include "irq_handler_mambo_withhost_labels.h"
#define irq_handler_labels irq_handler_mambo_withhost_labels
#elif (EM86XX_MODE==EM86XX_MODEID_STANDALONE)
#include "irq_handler_mambo_standalone_labels.h"
#define irq_handler_labels irq_handler_mambo_standalone_labels
#else
#error EM86XX_MODE is not set in RMCFLAGS: refer to emhwlib/include/emhwlib_modes.h.
#endif // EM86XX_MODE = ...

#elif (EM86XX_CHIP==EM86XX_CHIPID_TANGOLIGHT)

#if (EM86XX_MODE==EM86XX_MODEID_WITHHOST)
#include "irq_handler_tangolight_withhost_labels.h"
#define irq_handler_labels irq_handler_tangolight_withhost_labels
#elif (EM86XX_MODE==EM86XX_MODEID_STANDALONE)
#include "irq_handler_tangolight_standalone_labels.h"
#define irq_handler_labels irq_handler_tangolight_standalone_labels
#else
#error EM86XX_MODE is not set in RMCFLAGS: refer to emhwlib/include/emhwlib_modes.h.
#endif // EM86XX_MODE = ...

#elif (EM86XX_CHIP==EM86XX_CHIPID_TANGO15)

#if (EM86XX_MODE==EM86XX_MODEID_WITHHOST)
#include "irq_handler_tango15_withhost_labels.h"
#define irq_handler_labels irq_handler_tango15_withhost_labels
#elif (EM86XX_MODE==EM86XX_MODEID_STANDALONE)
#include "irq_handler_tango15_standalone_labels.h"
#define irq_handler_labels irq_handler_tango15_standalone_labels
#else
#error EM86XX_MODE is not set in RMCFLAGS: refer to emhwlib/include/emhwlib_modes.h.
#endif // EM86XX_MODE = ...

#elif (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)

#if (EM86XX_MODE==EM86XX_MODEID_WITHHOST)
#include "irq_handler_tango2_withhost_labels.h"
#define irq_handler_labels irq_handler_tango2_withhost_labels
#elif (EM86XX_MODE==EM86XX_MODEID_STANDALONE)
#include "irq_handler_tango2_standalone_labels.h"
#define irq_handler_labels irq_handler_tango2_standalone_labels
#else
#error EM86XX_MODE is not set in RMCFLAGS: refer to emhwlib/include/emhwlib_modes.h.
#endif // EM86XX_MODE = ...

#else

#error EM86XX_CHIP is not set in RMCFLAGS: refer to emhwlib/include/emhwlib_chips.h.

#endif

#endif // __IRQ_HANDLER_LABELS_H__

