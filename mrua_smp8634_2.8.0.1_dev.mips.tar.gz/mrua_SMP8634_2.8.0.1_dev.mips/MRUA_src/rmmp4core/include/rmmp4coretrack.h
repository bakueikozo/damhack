/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   rmmp4coretrack.h
  @brief  

  

  @author Julien Soulier
  @date   2003-02-04
*/

#ifndef __RMMP4CORETRACK_H__
#define __RMMP4CORETRACK_H__

#include "../../rmdef/rmdef.h"

struct rmmp4coretrack;

/**
   Opens a track with track ID trackId.
   returns NULL if the track does not exist.

   @param mp4file       
   @param trackId       
*/
RM_EXTERN_C struct rmmp4coretrack *rmmp4coretrack_open(struct rmmp4corefile *mp4file, RMuint32 trackId);

/**
   Close a track previously opened by rmmp4coretrack_open

   @param mp4track      
*/
RM_EXTERN_C void rmmp4coretrack_close(struct rmmp4coretrack *mp4track);

/**
   print to stderr all track informations.

   @param mp4track      
*/
RM_EXTERN_C void rmmp4coretrack_print(struct rmmp4coretrack *mp4track);

/**
   Gets the next sample in track mp4track. Gets at most maxSize bytes
   of this sample. See RMmp4Sample definition in rmmpeg4types for a
   descriptions of all fields contained in sample.

   returns FALSE when the track reached the end, TRUE otherwise.

   @param mp4track      
   @param sample        
   @param maxSize       
   @return 
*/
RM_EXTERN_C RMstatus rmmp4coretrack_get_next_sample(struct rmmp4coretrack *mp4track, RMmp4Sample *sample, RMuint32 maxSize);

/**
   Gets the next random access sample in the track (for video a random
   access point is an I Frame).

   returns FALSE when the track reached the end, TRUE otherwise.

   @param mp4track      
   @param mp4Sample     
   @param maxSize       
   @return 
*/
RM_EXTERN_C RMstatus rmmp4coretrack_get_next_random_access_point(struct rmmp4coretrack *mp4track, RMmp4Sample *mp4Sample, RMuint32 maxSize);

/**
   Gets the previous random access sample in the track (for video a
   random access point is an I Frame).

   returns FALSE when the track reached the start, TRUE otherwise.

   @param mp4track      
   @param mp4Sample     
   @param maxSize       
   @return 
*/
RM_EXTERN_C RMstatus rmmp4coretrack_get_prev_random_access_point(struct rmmp4coretrack *mp4track, RMmp4Sample *mp4Sample, RMuint32 maxSize);

/**
   Gets The elementary stream descriptor for the track. This
   descriptor may contains the Decoder Specific Information. 
   You don't have to allocate the returned buffer nor to free it.
   *size will contained the size of the returned buffer.

   @param mp4track      
   @param size  
*/
RM_EXTERN_C RMuint8 *rmmp4coretrack_get_ESD(struct rmmp4coretrack *mp4track, RMuint32 *size);

/**
   Seeks in the mp4track so that next call to get_next_sample will
   return sample sampleIndex. SampleIndex 0 corresponds to the first
   sample in track.

   @param mp4track      
   @param sampleIndex   
   @return 
*/
RM_EXTERN_C RMstatus rmmp4coretrack_seekto_sample(struct rmmp4coretrack *mp4track, RMuint32 sampleIndex);

/**
   Seeks in the mp4track so that next call to get_next_sample will
   return a sample with a Composition Time Stamp equal to cts.
   cts is in track timescale unit.

   @param mp4track      
   @param cts   
   @return 
*/
RM_EXTERN_C RMstatus rmmp4coretrack_seekto_CTS(struct rmmp4coretrack *mp4track, RMuint64 cts, RMuint64 *realCTS);

/**
   returns TRUE if all samples are random access points FALSE otherwise.

   @param mp4track      
   @return 
*/
RM_EXTERN_C RMbool rmmp4coretrack_is_random_seekable(struct rmmp4coretrack *mp4track);

/**
   Returns the media type of the track. See rmmp4core.h for a complete
   list of all supported media.

   @param mp4track      
   @return 
*/
RM_EXTERN_C RMuint32 rmmp4coretrack_get_media_type(struct rmmp4coretrack *mp4track);

/**
   returns the track timescale.

   @param mp4track      
   @return 
*/
RM_EXTERN_C RMuint32 rmmp4coretrack_get_timescale(struct rmmp4coretrack *mp4track);

/**
   returns the duration of the track in track timescale unit.

   @param mp4track      
   @return 
*/
RM_EXTERN_C RMuint64 rmmp4coretrack_get_duration(struct rmmp4coretrack *mp4track);

/**
   returns the number of samples in the track.

   @param mp4track      
   @return 
*/
RM_EXTERN_C RMuint32 rmmp4coretrack_get_sample_count(struct rmmp4coretrack *mp4track);

/**
   returns the number of random access samples in the track.

   @param mp4track      
   @return 
*/
RM_EXTERN_C RMuint32 rmmp4coretrack_get_random_access_sample_count(struct rmmp4coretrack *mp4track);

/**
   returns the remain next sample size in bytes. Before calling the
   first time get_next_sample get_next_sample_size returns the total
   size of the next sample. After each call to get_next_sample
   get_next_sample_size is decreased by the size already read. When a
   sample has been completely read get_next_sample_size returns the
   total size of the next sample. (this call behaves the same way with
   get_next_random_access_point and get_prev_random_access_point).

   @param mp4track      
   @return 
*/
RM_EXTERN_C RMuint32 rmmp4coretrack_get_next_sample_size(struct rmmp4coretrack *mp4track);

/**
   Returns the track id of the track.

   @param mp4track      
   @return 
*/
RM_EXTERN_C RMuint32 rmmp4coretrack_get_trackid(struct rmmp4coretrack *mp4track);

/**
   returns TRUE is a descriptor decoder is needed to parse the ESD.

   @param mp4track      
   @return
*/
RM_EXTERN_C RMbool rmmp4coretrack_is_esd_with_descriptor(struct rmmp4coretrack *mp4track);

RM_EXTERN_C RMstatus rmmp4coretrack_get_track_width(struct rmmp4coretrack *mp4track, RMuint32 *width);
RM_EXTERN_C RMstatus rmmp4coretrack_get_track_height(struct rmmp4coretrack *mp4track, RMuint32 *height);

RM_EXTERN_C RMstatus rmmp4coretrack_get_track_size(struct rmmp4coretrack *mp4track, RMuint32 *trackSize, RMuint32 *sampleCount);

RM_EXTERN_C RMstatus rmmp4coretrack_get_next_sample_position_in_file(struct rmmp4coretrack *mp4track, RMuint64 *nextReadPos);

RM_EXTERN_C RMuint32 rmmp4coretrack_get_sample_type(struct rmmp4coretrack *mp4track);

RM_EXTERN_C RMstatus rmmp4coretrack_get_track_sample_rate(struct rmmp4coretrack *mp4track, RMuint32 *sampleRate);
RM_EXTERN_C RMstatus rmmp4coretrack_get_track_channel_count(struct rmmp4coretrack *mp4track, RMuint32 *channelCount);
RM_EXTERN_C RMstatus rmmp4coretrack_get_track_bit_per_sample(struct rmmp4coretrack *mp4track, RMuint32 *bitPerSample);

RM_EXTERN_C RMstatus rmmp4coretrack_get_h264_level(struct rmmp4coretrack *mp4track, RMuint32 *level);
RM_EXTERN_C RMstatus rmmp4coretrack_get_h264_profile(struct rmmp4coretrack *mp4track, RMuint32 *profile);
RM_EXTERN_C RMstatus rmmp4coretrack_get_h264_LengthSize(struct rmmp4coretrack *mp4track, RMuint32 *lengthSize);


#endif // __RMMP4CORETRACK_H__
