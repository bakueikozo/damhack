/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmmp4core.h
  @brief  

  long description

  @author Julien Soulier
  @date   2003-02-05
*/

#ifndef __RMMP4CORE_H__
#define __RMMP4CORE_H__

#include "../../rmmpeg4types/rmmpeg4types.h"

#define NO_MEDIA                  0
#define AUDIO_MEDIA               1
#define VIDEO_MEDIA               2
#define HINT_MEDIA                3
#define OBJECT_DESCRIPTOR_MEDIA   4
#define CLOCK_REFERENCE_MEDIA     5
#define SCENE_DESCRIPTION_MEDIA   6
#define MPEG7_MEDIA               7 
#define OBJECT_CONTENT_INFO_MEDIA 8
#define IPMP_MEDIA                9
#define MPEGJ_MEDIA              10

/* for NeroDigital */
#define SPU_MEDIA                11
#define SUBTITLE_MEDIA           12

/* for QuickTime */
#define TIMECODE_MEDIA           13
#define TEXT_MEDIA               14

#endif // __RMMP4CORE_H__
