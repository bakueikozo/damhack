/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file   rmmp4corefile.h
  @brief  

  

  @author Julien Soulier
  @date   2003-02-04
*/

#ifndef __RMMP4COREFILE_H__
#define __RMMP4COREFILE_H__

#include "../../rmdef/rmdef.h"
#include "rmmp4coretrack.h"

struct rmmp4corefile;

/**
   opens a mp4 file with filename mp4filename.
   Each "large" box will be cached with a cache size of cache_size.

   On success returns RM_OK, if mp4filename is invalid returns
   RM_ERROR, and if the file is not a mp4 file returns RM_ERROR_NOT_MP4.
 
   @param mp4filename   
   @param cache_size    
   @param handle        
   @return 
*/
RM_EXTERN_C RMstatus rmmp4corefile_open(const RMnonAscii *mp4filename, RMuint32 cache_size, struct rmmp4corefile **handle);

/**
   opens a mp4 file with an already opened file.
   Each "large" box will be cached with a cache size of cache_size.

   On success returns RM_OK, if mp4filename is invalid returns
   RM_ERROR, and if the file is not a mp4 file returns RM_ERROR_NOT_MP4.
 
   @param mp4filename   
   @param cache_size    
   @param handle        
   @return 
*/
RM_EXTERN_C RMstatus rmmp4corefile_open_external(RMfile file, RMuint32 cache_size, struct rmmp4corefile **handle);

/**
   Closes a mp4file previously opened by rmmp4corefile_open

   @param mp4file       
*/
RM_EXTERN_C void rmmp4corefile_close(struct rmmp4corefile *mp4file);

/**
   Prints to stderr all box informations contained in the mp4 file.

   @param mp4file       
*/
RM_EXTERN_C void rmmp4corefile_print(struct rmmp4corefile *mp4file);

/**
   Gets the Initial Object Descriptor from the mp4 file. It is needed
   only for MPEG-4 system compliant player.

   @param mp4file       
   @param size  
*/
RM_EXTERN_C RMuint8 *rmmp4corefile_get_iod(struct rmmp4corefile *mp4file, RMuint32 *size);

/**
   Gets the video track id. A mp4 file may contain several video tracks
   (still pictures are also considered as video track). Therefore this
   function returns the video trackID of the longer video track. (in
   term of duration)

   If there is no video track, 0 is returned.
   @param mp4file       
   @return 
*/
RM_EXTERN_C RMuint32 rmmp4corefile_get_video_trackid(struct rmmp4corefile *mp4file);

/**
   Gets the audio track id. A mp4 file may contain several audio
   tracks. Therefore this function returns the audio trackID of the
   longer audio track. (in term of duration)

   @param mp4file       
   @return 
*/
RM_EXTERN_C RMuint32 rmmp4corefile_get_audio_trackid(struct rmmp4corefile *mp4file);

/**
   Returns in pixel the width of the scene. (this is normally the
   width of the video track)

   @param mp4file       
   @return 
*/
RM_EXTERN_C RMuint32 rmmp4corefile_get_video_width(struct rmmp4corefile *mp4file);

/**
   Returns in pixel the height of the scene. (this is normally the
   height of the video track)

   @param mp4file       
   @return 
*/
RM_EXTERN_C RMuint32 rmmp4corefile_get_video_height(struct rmmp4corefile *mp4file);


RM_EXTERN_C RMuint32 rmmp4corefile_count_tracks_of_type(struct rmmp4corefile *mp4file, RMuint32 type);

/**
   >>>>>>>>>>> NERO SPECIFIC <<<<<<<<<<<

   Returns the name ('chapterName') and time ('nextChapterTime_100ns') of the 
   current chapter plus signed chapter offset 'chapter'

   @param mp4file
   @param currentTime_100ns
   @param nextChapterTime_100ns
   @param chapterName
   @param maxNameLen
   @param chapter
   @return 
*/
RM_EXTERN_C RMstatus rmmp4corefile_get_closest_chapter(struct rmmp4corefile *mp4file, RMuint64 currentTime_100ns, RMuint64 *nextChapterTime_100ns, RMuint8 *chapterName, RMuint32 maxNameLen, RMint32 chapter);


RM_EXTERN_C RMstatus rmmp4corefile_get_chapter_by_index(struct rmmp4corefile *mp4file, RMuint32 index, RMuint64 *ChapterTime_100ns, RMuint8 *chapterName, RMuint32 maxNameLen);

/**

   Returns true if a NeroDigital compatible brand is found on ftyp box, else false

   @return 
*/
RM_EXTERN_C RMbool rmmp4corefile_is_nero_file(struct rmmp4corefile *mp4file);


/**
   >>>>>>>>>>> NERO SPECIFIC <<<<<<<<<<<

   Returns true or false according to NeroDigital DRM, if file is not NeroDigital returns true

   @return 
*/
RM_EXTERN_C RMbool rmmp4corefile_can_be_played(struct rmmp4corefile *mp4file);


RM_EXTERN_C RMstatus rmmp4corefile_get_trackid_by_index_and_type(struct rmmp4corefile *mp4file, RMuint32 index, RMuint32 type, RMuint32 *trackID);


#endif // __RMMP4COREFILE_H__
