/*
 *
 * Copyright (c) Sigma Designs, Inc. 2005. All rights reserved.
 *
 */

/**
 *	@file rmdrm.c
 *	@brief DRM dynamic module loader
 *
 *	@author Julien Lerouge
 */

#define ALLOW_OS_CODE

#include "rmdef/rmdef.h"
#include "../include/rmdrm.h"
#include <dlfcn.h>


#include "llad/include/gbus.h"
#include "emhwlib/include/emhwlib_event.h"

#if (EM86XX_CHIP == EM86XX_CHIPID_TANGO2)
#include "xos/include/xos_xrpc.h"
#endif



#if 0
#define RMDRMDEBUG ENABLE
#else
#define RMDRMDEBUG DISABLE
#endif

#define xstr(s) str(s)
#define str(s) #s

#if (EM86XX_MODE == EM86XX_MODEID_WITHHOST) || (EM86XX_CHIP == EM86XX_CHIPID_TANGO2)
/* Only compiled on systems with shared libraries */
#ifdef _DEBUG
static const RMascii *drm_string[DRM_COUNT] = {
#undef RMDRM_DEFINE
#define RMDRM_DEFINE(id, drm, lib)  #drm ,
#include "../include/rmdrm.inc"
};
#endif

static const RMascii *drm_filename[DRM_COUNT] = {
#undef RMDRM_DEFINE
#define RMDRM_DEFINE(id, drm, lib)  #lib ,
#include "../include/rmdrm.inc"
};

static void *drm_interface[DRM_COUNT];
static void *drm_handle[DRM_COUNT];
#endif




/**
 * Load a given DRM
 * @param id - id of the module to load
 * @return pointer to the DRM interface, NULL on error
 */
void * load_drm(enum drm_module_id id, const RMascii *filename)
{
#if (EM86XX_MODE == EM86XX_MODEID_WITHHOST) || (EM86XX_CHIP == EM86XX_CHIPID_TANGO2)
	RMascii *error;
	RMascii **symbol;
	RMuint32 nsymbols,i;
	void **interface;
	
	if (id >= DRM_COUNT)
		return NULL;

	if (drm_interface[id])
		return drm_interface[id];

	if(filename==NULL) filename=drm_filename[id];
	
	RMDBGLOG((RMDRMDEBUG,"Try loading %s module (%s)\n", drm_string[id], filename));
	drm_handle[id] = dlopen(filename, RTLD_LAZY);
	if (!drm_handle[id]) {
		RMDBGLOG((ENABLE, "Error loading %s : %s\n", filename, dlerror()));
		return NULL;
	}

	RMDBGLOG((RMDRMDEBUG,"dlopened %s\n", drm_string[id]));
	dlerror();
	symbol = dlsym(drm_handle[id], xstr(RMDRM_INTERFACE));
	if ((error = dlerror()) != NULL || symbol == NULL) {
		RMDBGLOG((ENABLE, "Error getting %s interface : %s\n", drm_string[id], error));
		dlclose(drm_handle[id]);
		drm_handle[id] = NULL;
		drm_interface[id] = NULL;
		return NULL;
	}

	for (nsymbols = 0; symbol[nsymbols] != NULL; nsymbols++);
	if (nsymbols == 0) {
		RMDBGLOG((ENABLE, "Error, no symbol to load in %s\n", filename));
		return NULL;
	}

	interface = (void **) RMMalloc(sizeof(void *)*nsymbols);
	if (interface == NULL) {
		RMDBGLOG((ENABLE,"Error : malloc\n"));
		return NULL;
	}

	for (i = 0; i < nsymbols; i++){
		RMDBGLOG((RMDRMDEBUG,"Loading symbol %s\n", symbol[i]));
		interface[i] = dlsym(drm_handle[id], symbol[i]);
		if ((error = dlerror()) != NULL || interface[i] == NULL) {
			RMDBGLOG((ENABLE, "Error loading symbol %s : %s\n", symbol[i], error));
			dlclose(drm_handle[id]);
			drm_handle[id] = NULL;
			drm_interface[id] = NULL;
			RMFree(interface);
			return NULL;
		}
	}
	
	drm_interface[id] = interface;
	RMDBGLOG((RMDRMDEBUG,"got interface %p\n", drm_interface[id]));
	return drm_interface[id];
#else
	/* No shared libraries on pt110 */
	return NULL;
#endif
}

/**
 * Unload a given DRM
 * @param id - id of the module to unload
 * @return RM_OK on success
 */
RMstatus unload_drm(enum drm_module_id id)
{
#if (EM86XX_MODE == EM86XX_MODEID_WITHHOST) || (EM86XX_CHIP == EM86XX_CHIPID_TANGO2)

	if (id >= DRM_COUNT || drm_interface[id] == NULL)
		return RM_ERROR;

	dlclose(drm_handle[id]);
	drm_handle[id] = NULL;
	if (drm_interface[id])
		RMFree(drm_interface[id]);
	drm_interface[id] = NULL;

	return RM_OK;
#else
	/* No shared libraries on pt110 */
	return RM_ERROR;
#endif
}
