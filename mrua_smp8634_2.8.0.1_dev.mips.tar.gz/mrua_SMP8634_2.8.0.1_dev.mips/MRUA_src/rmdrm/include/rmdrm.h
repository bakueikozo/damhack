/*
 *
 * Copyright (c) Sigma Designs, Inc. 2005. All rights reserved.
 *
 */

/**
 *	@file rmdrm.h
 *	@brief DRM dynamic module loader
 *
 *	@author Julien Lerouge
 */

#ifndef __RM_DRM_H__
#define __RM_DRM_H__

#include "rmdef/rmdef.h"

/** Interface symbol we are looking for in a DRM module */
#define RMDRM_INTERFACE rmdrm_interface


/** Possible drms this modules can dynamically load */
enum drm_module_id {
#undef RMDRM_DEFINE
#define RMDRM_DEFINE(id, drm, lib)     drm=id,
#include "rmdrm.inc"
       DRM_COUNT
};

/**
 * Load a given DRM
 * @param id - id of the module to load
 * @param filename - library filename, if NULL use the default defined in rmdrm.inc
 * @return pointer to the DRM interface, NULL on error
 */
void *load_drm(enum drm_module_id id, const RMascii *filename);


/**
 * Unload a given DRM
 * @param id - id of the module to unload
 * @return RM_OK on success
 */
RMstatus unload_drm(enum drm_module_id id);


#endif /* __RM_DRM_H__ */

