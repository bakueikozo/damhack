/*****************************************
 Copyright � 2004-2005
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   xos_csf.h
  @brief  

  System and Cpu Frequency

  @author Emmanuel Michon
  @date   2005-06-09
*/

#ifndef __XOS_CSF_H__
#define __XOS_CSF_H__

struct csf_config {
	RMuint32 pll3;
	RMuint32 mux;
};

/*
  Always advised to have m small (bits 16-23) for cleanliness of clock

  eps=-3000000; while [ $eps -lt 3000000 ]; do freq set 3 $[150000000+eps] >/dev/null; freq dump |grep pll3; eps=$[eps+100000]; done |sort -n |uniq |head -10

  ~150MHz:
  pll3 0x01000014/0x00000202 means f=297.000MHz f/d1=148.500MHz f/d2=148.500MHz
  pll3 0x01010020/0x00000202 means f=306.000MHz f/d1=153.000MHz f/d2=153.000MHz
 *pll3 0x01030036/0x00000202 means f=302.400MHz f/d1=151.200MHz f/d2=151.200MHz
  pll3 0x01040041/0x00000202 means f=301.500MHz f/d1=150.750MHz f/d2=150.750MHz

  ~166MHz:
  pll3 0x01000017/0x00000202 means f=337.500MHz f/d1=168.750MHz f/d2=168.750MHz
 *pll3 0x01010023/0x00000202 means f=333.000MHz f/d1=166.500MHz f/d2=166.500MHz
  pll3 0x0102002f/0x00000202 means f=330.750MHz f/d1=165.375MHz f/d2=165.375MHz
  pll3 0x0103003b/0x00000202 means f=329.400MHz f/d1=164.700MHz f/d2=164.700MH

  ~180MHz:
  pll3 0x01000019/0x00000202 means f=364.500MHz f/d1=182.250MHz f/d2=182.250MHz
 *pll3 0x01010026/0x00000202 means f=360.000MHz f/d1=180.000MHz f/d2=180.000MHz
  pll3 0x01020033/0x00000202 means f=357.750MHz f/d1=178.875MHz f/d2=178.875MHz
  pll3 0x01030040/0x00000202 means f=356.400MHz f/d1=178.200MHz f/d2=178.200MHz

  ~200MHz:
  pll3 0x0100001c/0x00000202 means f=405.000MHz f/d1=202.500MHz f/d2=202.500MHz
  pll3 0x0101002a/0x00000202 means f=396.000MHz f/d1=198.000MHz f/d2=198.000MHz
 *pll3 0x01020039/0x00000202 means f=398.250MHz f/d1=199.125MHz f/d2=199.125MHz
  pll3 0x01030047/0x00000202 means f=394.200MHz f/d1=197.100MHz f/d2=197.100MHz

  ~250MHz:
  pll3 0x01000023/0x00000202 means f=499.500MHz f/d1=249.750MHz f/d2=249.750MHz
  pll3 0x01010035/0x00000202 means f=495.000MHz f/d1=247.500MHz f/d2=247.500MHz
 *pll3 0x01010036/0x00000202 means f=504.000MHz f/d1=252.000MHz f/d2=252.000MHz
  pll3 0x0103005a/0x00000202 means f=496.800MHz f/d1=248.400MHz f/d2=248.400MHz

  pll3 0x01030061/0x00000202 means f=534.600MHz f/d1=267.300MHz f/d2=267.300MHz
  pll3 0x01020057/0x00000202 means f=600.750MHz f/d1=300.375MHz f/d2=300.375MHz
  pll3 0x01010048/0x00000202 means f=666.000MHz f/d1=333.000MHz f/d2=333.000MHz
  pll3 0x0101004e/0x00000202 means f=720.000MHz f/d1=360.000MHz f/d2=360.000MHz
  pll3 0x01010057/0x00000202 means f=801.000MHz f/d1=400.500MHz f/d2=400.500MHz
*/

#define S100 0x01030025
#define S150 0x01030036
#define S166 0x01010023
#define S180 0x01010026
#define S200 0x01020039
#define S250 0x01010036
#define S270 0x01030061
#ifdef XOS_PLL3_601
#define S300 0x01010041
#else
#define S300 0x01010040
#endif
#define S333 0x01010048
#define S360 0x0101004e
#define S400 0x01010057

#define CSF_DEFAULT 2

const struct csf_config supported_csf_config[]={
	{ S250, 0x701 }, // #0 SUPPORTED cpu @250 system @166 (should be default)
	{ S166, 0x001 }, // #1 SUPPORTED cpu @166 system @166 (default)
	{ S300, 0x701 }, // #2 SUPPORTED cpu @300 system @200 (only with >=200MHz DRAM)
	{ S300, 0x101 }, // #3 SUPPORTED cpu @300 system @150 

	//////////////////////////////////////////////
	//////// UNSUPPORTED /////////////////////////

	/*
	  Testing DRAM for acceptable reliability in heavy bandwidth applications
	  is not an easy task.
	  
	  Do not conclude setting is ok if, for instance, Linux idles
	  one hour without crashing.

	  Writing a fancy setting to xenv on a standalone design may
	  bring you in a situation where getting control back on the
	  board is difficult (JTAG required).

	  Also, pll not supposed to work above 700MHz.
	*/

	{ S270, 0x701 }, // #4           cpu @270 system @180 (works on some chips)
	{ S333, 0x101 }, // #5           cpu @333 system @166 (works on some chips)
	{ S360, 0x101 }, // #6           cpu @360 system @180 (crash < 3 sec)
	{ S400, 0x101 }, // #7           cpu @400 system @200 (untested)

	{ S150, 0x001 }, // #8 SUPPORTED cpu @150 system @150 (Vincent, 28 jul 2005)
};
	
#endif // __XOS_CSF_H__
