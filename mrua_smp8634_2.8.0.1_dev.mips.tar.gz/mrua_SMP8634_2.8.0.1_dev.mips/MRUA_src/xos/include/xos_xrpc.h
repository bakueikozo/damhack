/*****************************************
 Copyright � 2004-2005
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   xrpc.h
  @brief  

  This interface allows any entity to request
  a service (secure remote procedure call) to SMP8630 xpu
  
  Some request by XRPC_CALLERID_NOBODY do not require authentication.

  Others use a PKCS#1 RSA digital signature. Each callerid is
  associated with a 2048-bit RSA public key stored in xpu serial
  flash.

  @author Emmanuel Michon
  @date   2004-10-19
*/

#ifndef __XOS_XRPC_H__
#define __XOS_XRPC_H__

/*
  Informative
  Software SHA-1 @200MHz can digest data at a rate of 4.7MByte/s
 */
#define XRPC_HIDESIZE (256*1024)
#define XRPC_MAXSIZE (10*1024*1024)

#define XRPC_CALLERID_IGNORED 0

#define XLOAD_CERTTYPE_ZBOOT       0
#define XLOAD_CERTTYPE_CPU         1
#define XLOAD_CERTTYPE_XTASK1      2
#define XLOAD_CERTTYPE_UCODE_VIDEO 3
#define XLOAD_CERTTYPE_UCODE_AUDIO 4
#define XLOAD_CERTTYPE_UCODE_DEMUX 5
#define XLOAD_CERTTYPE_IH          6
#define XLOAD_CERTTYPE_XTASK2      7
#define XLOAD_CERTTYPE_XTASK3      8
#define XLOAD_CERTTYPE_XTASK4      9
#define XLOAD_CERTTYPE_XOSU     0xff

#define XLOAD_SEKID_MAX 14
#define XLOAD_SEKID_CLEAR 0xff

#define UCODE_ONES 100
#define XLOAD_CLEAR_HEADERSIZE 772
#define XLOAD_CIPHERED_HEADERSIZE 1044

/////////////////////////// xprc ids. Do not use holes. They have been created by become-obsolete xrpc's.

#define	XRPC_ID_GETSERIAL      0 // return chip serial number to param0..3
#define	XRPC_ID_GETRANDOM      2 // return 32bit of true random to param0
#define XRPC_ID_BONDINGCOMMENT 3 // return the bonding comment to param0..1
#define XRPC_ID_SHA1XOS        4 // outputs SHA-1 of burnt signablearea-xosMxy.bin to param0..4
#define XRPC_ID_XLOAD          5
#define XRPC_ID_DRAM          15 /* --- deprecated in xosMa0 */
#define XRPC_ID_XUNLOAD       17
#define XRPC_ID_CACHEDUMP     18 // not implemented in release build
#define XRPC_ID_REBOOT        19
#define XRPC_ID_XBIND         20 // bind/unbind certificate to xload.
#define XRPC_ID_XSTART        21 // start xtask
#define XRPC_ID_XKILL         22 // signal or stop xtask
#define XRPC_ID_GETPROTECTION 23 // Get protection registers
#define XRPC_ID_GETBINDING    24 // Get binding hash
#define XRPC_ID_GETOWNER      25 // Get sector ownership hash
#define XRPC_ID_SETENHANCEDMODE 26 // enhanced mode 
#define XRPC_ID_VERSION       27 // Get XOS build version string (!= sha1)

///////////////////////// xrpc return codes

/*
  xos examines memory starting at the block header according to:
  
  | header | payload |
  
*/
struct xrpc_block_header {
	RMuint32 callerid; // deprecated field, put XRPC_CALLERID_IGNORED
	RMuint32 xrpcid;
	
	// parameters (input and output)
	RMuint32 param0;
	RMuint32 param1;
	RMuint32 param2;
	RMuint32 param3;
	RMuint32 param4;
	
	RMuint32 headerandblocksize;
};

#ifndef __XOS_H__

#include "../../gbuslib/include/gbus_mutex.h"
#include "../../emhwlib/include/emhwlib_resources.h"

/// 
/**
   Make a synchronous remote procedure call to SMP8630 xpu.

   The output parameters of the xrpc itself appear as pB->rc
   when this function returns.

   @param pgbus 
   @param pB: gbus address of struct xrpc_block_header *
   @return <ReturnValue>: RM_OK on success, other on failure
*/
static inline RMstatus doxrpc(struct gbus *pgbus,RMuint32 pB)
{
	RMstatus rc;
	
	gbus_mutex_lock(pgbus,XRPC_MUTEX);
	
	gbus_write_uint32(pgbus,REG_BASE_cpu_block+LR_XPU_STAGE,pB);
	gbus_write_uint32(pgbus,REG_BASE_xpu_block+CPU_irq_softset,SOFT_IRQ_XRPC);
	while ((gbus_read_uint32(pgbus,REG_BASE_xpu_block+CPU_irq_softset)&SOFT_IRQ_XRPC)!=0);
	rc=(RMstatus)gbus_read_uint32(pgbus,REG_BASE_cpu_block+LR_XPU_STAGE);

	gbus_mutex_unlock(pgbus,XRPC_MUTEX);
	
	return rc;
}

static inline void unlock_xrpc(struct gbus *pgbus)
{
	gbus_mutex_unlock(pgbus,XRPC_MUTEX);
}
#endif

// backward compatibility esp. for xosu script!
#define	XRPC_ID_XOSSELFUPDATE 9
#define XRPC_ID_IH_LOAD 13
#define	XRPC_CALLERID_SIGMA_SER 0xffffffff


#endif // __XOS_XRPC_H__
