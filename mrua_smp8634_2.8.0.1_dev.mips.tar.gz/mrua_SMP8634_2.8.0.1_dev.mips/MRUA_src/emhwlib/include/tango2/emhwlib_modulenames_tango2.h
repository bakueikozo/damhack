/******************************************************/
/* This file is generated automatically, DO NOT EDIT! */
/******************************************************/
/*
 * include/tango2/emhwlib_modulenames_tango2.h
 *
 * Copyright (c) 2001-2003 Sigma Designs, Inc. 
 * All Rights Reserved. Proprietary and Confidential.
 *
 */
 
/**
  @file include/tango2/emhwlib_modulenames_tango2.h
  @brief emhwlib generated file
   
  @author Jacques Mahe, Christian Wolff, Julien Soulier, Emmanuel Michon
  @ingroup hwlproperties
*/

#ifndef __EMHWLIB_MODULENAMES_TANGO2_H__
#define __EMHWLIB_MODULENAMES_TANGO2_H__

static const RMascii *EMhwlibModuleName[] = {
	"Enumerator", 
	"SystemBlock", 
	"CPUBlock", 
	"XPUBlock", 
	"DisplayBlock", 
	"DispOSDScaler", 
	"DispHardwareCursor", 
	"DispMainVideoScaler", 
	"DispSubPictureScaler", 
	"DispVCRMultiScaler", 
	"DispGFXMultiScaler", 
	"DispMainMixer", 
	"DispColorBars", 
	"DispRouting", 
	"DispVideoInput", 
	"DispGraphicInput", 
	"DispDigitalOut", 
	"DispMainAnalogOut", 
	"DispComponentOut", 
	"DemuxEngine", 
	"MpegEngine", 
	"VideoDecoder", 
	"AudioEngine", 
	"AudioDecoder", 
	"AudioCapture", 
	"VoipCodec", 
	"CRCDecoder", 
	"XCRCDecoder", 
	"StreamCapture", 
	"RawDataTransfer", 
	"I2C", 
	"GFXEngine", 
	"MM", 
	"SpuDecoder", 
	"PictureTransform", 
	"ClosedCaptionDecoder", 
	"RTC", 
	"Cipher", 
	"STC", 
	"PLL", 
	"DemuxCipher", 
	"DemuxTask", 
	"DemuxOutput", 
	"CCFifo", 
	"DispVideoPlane", 
	"DispHDSDConverter", 
	"Sha1Sum", 
	"XTask", 
	"TTXFifo", 
	"VCXO", 
	"PPF", 
};

#endif /* __EMHWLIB_MODULENAMES_TANGO2_H__ */

/* End of generated file include/tango2/emhwlib_modulenames_tango2.h */
