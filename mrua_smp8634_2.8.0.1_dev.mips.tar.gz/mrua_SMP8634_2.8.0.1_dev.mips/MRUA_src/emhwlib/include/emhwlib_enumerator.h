/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   emhwlib_enumerator.h
  @brief  

  long description

  @author Emmanuel Michon
  @date   2003-05-15
*/

#ifndef __EMHWLIB_ENUMERATOR_H__
#define __EMHWLIB_ENUMERATOR_H__

enum RMEnumeratorPropertyID {
	RMEnumeratorPropertyID_IndexToCategoryID,	// Exchange. in=RMuint32 out=enum RMcategoryID
	RMEnumeratorPropertyID_CategoryIDToNumberOfInstances,	// Exchange. in=enum RMcategoryID out=RMuint32
	RMEnumeratorPropertyID_CategoryIDToCategoryName,	// Exchange. in=enum RMcategoryID out=RMascii *
};

#endif // __EMHWLIB_ENUMERATOR_H__
