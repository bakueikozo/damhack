/******************************************************/
/* This file is generated automatically, DO NOT EDIT! */
/******************************************************/
/*
 * include/emhwlib_properties_6000.h
 *
 * Copyright (c) 2001-2003 Sigma Designs, Inc. 
 * All Rights Reserved. Proprietary and Confidential.
 *
 */
 
/**
  @file include/emhwlib_properties_6000.h
  @brief emhwlib generated file
   
  @author Jacques Mahe, Christian Wolff, Julien Soulier, Emmanuel Michon
  @ingroup hwlproperties
*/

#ifndef __EMHWLIB_PROPERTIES_6000_H__
#define __EMHWLIB_PROPERTIES_6000_H__

/** Module Enum Default */
enum RMSystemBlockPropertyID {
	RMSystemBlock_unused = 0, 
};

/** Module Enum Default */
enum RMCPUBlockPropertyID {
	RMCPUBlock_unused = 0, 
};

/** Module Enum Default */
enum RMXPUBlockPropertyID {
	RMXPUBlock_unused = 0, 
};

/** Module Enum Default */
enum RMIPUBlockPropertyID {
	RMIPUBlock_unused = 0, 
};

/** Module Enum Default */
enum RMDisplayBlockPropertyID {
	/** DisplayBlock_InitSurface_in_type and DisplayBlock_InitSurface_out_type, (R/W Exchange) @par 
		initialize a static surface */
	RMDisplayBlockPropertyID_InitSurface = 6001,
	/** DisplayBlock_InitMultiplePictureSurface_type, (W) @par 
		initialize a picture fifo surface */
	RMDisplayBlockPropertyID_InitMultiplePictureSurface = 6002,
	/** DisplayBlock_InitMultiplePictureSurfaceX_type, (W) @par 
		initialize a picture fifo surface */
	RMDisplayBlockPropertyID_InitMultiplePictureSurfaceX = 6191,
	/** DisplayBlock_SurfaceInfo_in_type and DisplayBlock_SurfaceInfo_out_type, (R/W Exchange) @par 
		Get the surface fields */
	RMDisplayBlockPropertyID_SurfaceInfo = 6003,
	/** DisplayBlock_PictureInfo_in_type and DisplayBlock_PictureInfo_out_type, (R/W Exchange) @par 
		Get some picture fields */
	RMDisplayBlockPropertyID_PictureInfo = 6183,
	/** DisplayBlock_SurfaceAspectRatio_type, (W) @par 
		initialize a static surface */
	RMDisplayBlockPropertyID_SurfaceAspectRatio = 6004,
	/** DisplayBlock_SurfaceSTC_type, (W) @par 
		Set/Get the STC Module ID attached to a surface */
	RMDisplayBlockPropertyID_SurfaceSTC = 6204,
	/** DisplayBlock_ForcePictureBufferAddress_type, (W) @par 
		force the picture buffer address */
	RMDisplayBlockPropertyID_ForcePictureBufferAddress = 6005,
	/** DisplayBlock_EnableGFXInteraction_type, (W) @par 
		initialize a static surface */
	RMDisplayBlockPropertyID_EnableGFXInteraction = 6006,
	/** DisplayBlock_VBUSBandwidth_type, (R/W) @par 
		@note Used to program the VBUS bandwidth arbiter */
	RMDisplayBlockPropertyID_VBUSBandwidth = 6007,
	/** DisplayBlock_ConnectReader_in_type and DisplayBlock_ConnectReader_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_ConnectReader = 6197,
	/** ::struct EMhwlibSurfaceReader, (W) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_DisconnectReader = 6198,
};

/** Module Enum Default */
enum RMDispOSDScalerPropertyID {
	/** DispOSDScaler_ScalingConfig_type, (R/W) @par 
		Sets the OSD scaling mode */
	RMDispOSDScalerPropertyID_ScalingConfig = 6014,
};

/** The hardware cursor block generates a small picture to the main mixer block.@n An arbitrary bitmap is stored in 4 bit/pixel format in  a 512x32 on-chip SRAM. Thus no external memory bandwidth is required to support the cursor.@n On chips earlier than SMP8634, each 4-bit pixel is fed to a 16x6x4 lookup table to produce an output stream of 24-bit (6-6-6-6 format) aYcbCr pixels.@note Each video component is multiplied by four, and the akpha value is extended to 8 bits before being sent to the main mixer.@n On SMP8634 and later chips, each 4-bit pixel is fed to a 16x32 look-up table which outputs 32 bit 8888 aYCbCr pixels.@n The horizontal and vertical dimensions of the cursor picture is constrained as follows: @li X size less than or equal to 255 @li Y size less than or equal to 255 */
enum RMDispHardwareCursorPropertyID {
	/** ::RMCursorPix, (W) @par 
		Enum Default; */
	RMDispHardwareCursorPropertyID_Bitmap = 6031,
	/** ::RMCursorLut, (W) @par 
		Enum Default; */
	RMDispHardwareCursorPropertyID_Lut = 6032,
	/** DispHardwareCursor_Size_type, (W) @par 
		Enum Default; */
	RMDispHardwareCursorPropertyID_Size = 6033,
};

/** The main video scaler is similar in general structure to the multi-format scalers with several important differences:\n @li Only video input data formats are supported (no graphics) @li 4-tap H and V-scalers are implemented rather than 2-tap @li A special deinterlacing mode supports vertical scaling using a 2-tap filter combining previous field and current field data @li HD (ITU 709) <-> SD (ITU 601) colorimetry conversion is supported  (both directions).\n\n The main video scaler supports deinterlacing using either of two algorithms, Type 1 and Type 2.\n\n @li In the Type 1 algorithm, output frame N is constructed from both the current (field N) and previous field (field N-1). Each field has  its missing lines reconstructed by a linear interpolation of its neighboring lines. For each output line, the actual (or interpolated) data from field N is combined with the interpolated (or actual) data from field N-1, using the weighted summation: @n @verbatim Lnew = [A* LN-1 + (16 A)* LN] / 16  or Lnew = [B* LN-1 + (16-B)* LN] / 16 @endverbatim where A and B are programmed parameters. Parameter A is used when Lnew exists in the current field (N); parameter B is used when Lnew exists in the previous field (N-1).@li Type 2 deinterlacing uses 3 fields, and is motion-adaptive. Output frame N is built from frame N-1, N, and N+1. Field N-1 and N+1 luma values are compared over 4x2 pixel blocks, resulting in a localized motion detection. Fields N-1 and N are both upscaled, and information from field N-1 is inserted into the output frame depending on how much motion is detected. In other words, the algorithm shifts between inter-field (weave) deinterlacing in regions with little motion, and intra-field (bob) deinterlacing in regions with significant motion.  The Type 2 algorithm supports concurrent deinterlacing and resizing, such as converting 480i input to 720p format. Implementing the Type 2 algorithm involves a coordinated usage of the main video scaler, an available multi-scaler, and the primary mixer block. */
enum RMDispMainVideoScalerPropertyID {
	/** ::enum EMhwlibDeinterlacingMode, (R/W) @par 
		Sets the deinterlacing mode (0,1,2) */
	RMDispMainVideoScalerPropertyID_DeinterlacingMode = 6045,
	/** DispMainVideoScaler_DeinterlacingProportion_type, (R/W) @par 
		Sets the proportion of field N-1 to generate frame N */
	RMDispMainVideoScalerPropertyID_DeinterlacingProportion = 6046,
	/** DispMainVideoScaler_DeinterlacingMotionConfig_type, (R/W) @par 
		Sets the alpha motion modulation function */
	RMDispMainVideoScalerPropertyID_DeinterlacingMotionConfig = 6047,
	/** ::RMuint32, (R/W) @par 
		Sets the scaler id of the scaler needed for motion adaptative deinterlacing */
	RMDispMainVideoScalerPropertyID_DeinterlacingMotionScaler = 6048,
	/** ::RMbool, (R/W) @par 
		Enum Default; */
	RMDispMainVideoScalerPropertyID_Enable_3_2_PullDownDetection = 6049,
	/** DispMainVideoScaler_FilterSelection_type, (R/W) @par 
		Sets the scaling filter selection boundaries */
	RMDispMainVideoScalerPropertyID_FilterSelection = 6050,
};

/** Module Enum Default */
enum RMDispSubPictureScalerPropertyID {
	/** DispSubPictureScaler_ScalingConfig_type, (R/W) @par 
		Sets the SPU scaling mode */
	RMDispSubPictureScalerPropertyID_ScalingConfig = 6053,
};

/** The three multi-format scalers (VCR/CRT/GFX) are general-purpose scaling units which can accept all supported video and graphics data formats (except sub-picture). A 256x32 lookup table in each scaler supports color expansion in 1, 2, 4 and 8 bit/pixel input modes. Due to internal RAM size limitations, these scalers support a maximum of 1024 pixels/line in 32 bit/pixel modes, and a maximum of 2048 pixels/line in 16 (or less) bit/pixel modes. Each scaler processes the video stream in the YC domain, and implements 2-tap H and V-scalers with a scaling range of 0.25 to infinity. Additional downscaling is possible by employing a pre-downscaler before the 2-tap scalers. Each scaler can properly support the differing chrominance sample alignment of MPEG-1 versus MPEG-2. */
enum RMDispVCRMultiScalerPropertyID {
	RMDispVCRMultiScaler_unused = 0, 
};

/** The three multi-format scalers (VCR/CRT/GFX) are general-purpose scaling units which can accept all supported video and graphics data formats (except sub-picture). A 256x32 lookup table in each scaler supports color expansion in 1, 2, 4 and 8 bit/pixel input modes. Due to internal RAM size limitations, these scalers support a maximum of 1024 pixels/line in 32 bit/pixel modes, and a maximum of 2048 pixels/line in 16 (or less) bit/pixel modes. Each scaler processes the video stream in the YC domain, and implements 2-tap H and V-scalers with a scaling range of 0.25 to infinity. Additional downscaling is possible by employing a pre-downscaler before the 2-tap scalers. Each scaler can properly support the differing chrominance sample alignment of MPEG-1 versus MPEG-2. */
enum RMDispCRTMultiScalerPropertyID {
	RMDispCRTMultiScaler_unused = 0, 
};

/** The three multi-format scalers (VCR/CRT/GFX) are general-purpose scaling units which can accept all supported video and graphics data formats (except sub-picture). A 256x32 lookup table in each scaler supports color expansion in 1, 2, 4 and 8 bit/pixel input modes. Due to internal RAM size limitations, these scalers support a maximum of 1024 pixels/line in 32 bit/pixel modes, and a maximum of 2048 pixels/line in 16 (or less) bit/pixel modes. Each scaler processes the video stream in the YC domain, and implements 2-tap H and V-scalers with a scaling range of 0.25 to infinity. Additional downscaling is possible by employing a pre-downscaler before the 2-tap scalers. Each scaler can properly support the differing chrominance sample alignment of MPEG-1 versus MPEG-2. */
enum RMDispGFXMultiScalerPropertyID {
	RMDispGFXMultiScaler_unused = 0, 
};

/** The main mixer receives the picture streams from each of the eight sources.@n @image html DispMainMixer_Block.png "Main Mixer" @n Each incoming stream passes through a positioning block, which places the input picture at a specified horizontal and vertical position within the active display window. Within the mixer, the positioned streams are then sorted according to a programmable ordering. The highest priority (top layer) is always assigned to the hardware cursor. For each pixel, layer 5 is alpha-blended with layer 4, layer 6 is alpha-blended with the result, and layer 7 is alpha-blended to form the output pixel. If any pixel is transparent, the sort moves down the layer order until a non-transparent pixel is found. Thus the output pixel stream consists of the merged combination of the four highest priority non-transparent layers. The output of the main mixer is sent to the display routing block. @image html DispMainMixer_Position.png Position Block */
enum RMDispMainMixerPropertyID {
	/** DispMainMixer_LayerOrder_type, (R/W) @par 
		@note Only a maximum of 4 planes can be blended per pixel. A transparent pixel is not considered as alpha blended.@note Layer 7 is reserved for the Hardware Cursor */
	RMDispMainMixerPropertyID_LayerOrder = 6056,
};

/** Module Enum Default */
enum RMDispVCRMixerPropertyID {
	/** DispVCRMixer_LayerOrder_type, (R/W) @par 
		@note Only a maximum of 4 planes can be blended per pixel. A transparent pixel is not considered as alpha blended.@note Layer 7 is reserved for the Hardware Cursor */
	RMDispVCRMixerPropertyID_LayerOrder = 6065,
};

/** Module Enum Default */
enum RMDispColorBarsPropertyID {
	/** ::RMuint32, (R/W) @par 
		Enum Default; */
	RMDispColorBarsPropertyID_Intensity = 6066,
	/** ::enum EMhwlibColorBarsStandard, (R/W) @par 
		Enum Default; */
	RMDispColorBarsPropertyID_Standard = 6067,
};

/** Module Enum Default */
enum RMDispRoutingPropertyID {
	RMDispRouting_unused = 0, 
};

/** Module Enum Default */
enum RMDispVideoInputPropertyID {
	/** ::RMuint32, (R/W) @par 
		Number of bits (8 or 16) on the video input. */
	RMDispVideoInputPropertyID_BusSize = 6069,
	/** DispVideoInput_InputFormat_type, (R/W) @par 
		Enum Default; */
	RMDispVideoInputPropertyID_InputFormat = 6070,
};

/** Module Enum Default */
enum RMDispGraphicInputPropertyID {
	/** DispGraphicInput_InputFormat_type, (R/W) @par 
		Subset for video input. For all features of graphics input, use Format property. */
	RMDispGraphicInputPropertyID_InputFormat = 6079,
	/** DispGraphicInput_OutputFormat_type, (R/W) @par 
		Specifies the output surface characteristics */
	RMDispGraphicInputPropertyID_OutputFormat = 6080,
	/** DispGraphicInput_KeyColor_type, (R/W) @par 
		Enum Default; */
	RMDispGraphicInputPropertyID_KeyColor = 6081,
	/** ::RMuint32, (R/W) @par 
		Routing source of the H- and V-Sync outputs. @note Allowed module IDs: @li DispGraphicInput @li DispDigitalOut @li DispMainAnalogOut @li DispComponentOut @li DispCompositeOut */
	RMDispGraphicInputPropertyID_SyncControlModuleID = 6082,
};

/** Module Enum Default */
enum RMDispDigitalOutPropertyID {
	/** ::enum EMhwlibDigitalTimingSignal, (R/W) @par 
		Enable CCIR 656 embedded sync signals. */
	RMDispDigitalOutPropertyID_TimingSignal = 6083,
	/** ::RMbool, (R/W) @par 
		Luma or RGB components are clipped between 16 and 235, chroma is clipped from 16 to 240, if active. */
	RMDispDigitalOutPropertyID_EnableClipping = 6084,
	/** DispDigitalOut_ClippingLevel_enum, (R/W) @par 
		Luma or RGB components are clipped between 16 and 235, chroma is clipped from 16 to 240, if active. */
	RMDispDigitalOutPropertyID_ClippingLevel = 6085,
	/** ::RMuint32, (R/W) @par 
		Number of bits (8, 16 or 24) on the digital output. */
	RMDispDigitalOutPropertyID_BusSize = 6086,
	/** ::RMbool, (R/W) @par 
		Define the YUV format following MPEG2 (0) specification or MPEG1 (1) specification */
	RMDispDigitalOutPropertyID_EnableMPEG1Chroma = 6087,
	/** ::enum EMhwlibColorOrder, (R/W) @par 
		Specify the order of the digital data to: @li 24 bit R-G-B (0) or R-B-G (1) @li 24 bit Cr-Y-Cb (0) or Cr-Cb-Y (1) @li 16 bit Y-CbCr (0) CbCr-Y (1) */
	RMDispDigitalOutPropertyID_ColorOrder = 6088,
	/** ::RMbool, (R/W) @par 
		Sets the DoubleRate feature of EM863x. If TRUE, each pixel will be sent twice, doubling the pixel clock and all horizontal timing values at the digital output pads. */
	RMDispDigitalOutPropertyID_DoubleRate = 6089,
	/** ::RMbool, (R/W) @par 
		If TRUE, Delays VSYNC by one pixel clock. */
	RMDispDigitalOutPropertyID_VSyncDelay1PixClk = 6184,
	/** ::RMbool, (R/W) @par 
		If TRUE, sets the field ID logic on the HSync trailing edge. */
	RMDispDigitalOutPropertyID_TrailingEdge = 6185,
	/** ::RMuint32, (R/W) @par 
		Routing source of the H- and V-Sync outputs. @note Allowed module IDs: @li DispDigitalOut @li DispMainAnalogOut @li DispComponentOut */
	RMDispDigitalOutPropertyID_SyncControlModuleID = 6090,
	/** ::RMbool, (R/W) @par 
		enables the data pad. */
	RMDispDigitalOutPropertyID_EnableDataPAD = 6091,
	/** ::RMbool, (R/W) @par 
		enables the sync pad. */
	RMDispDigitalOutPropertyID_EnableSyncPAD = 6092,
	/** ::RMbool, (R/W) @par 
		enables the vvld pad. */
	RMDispDigitalOutPropertyID_EnableVVLDPAD = 6093,
	/** DispDigitalOut_PadsConfig_type, (R/W) @par 
		Several output options - OBSOLETE, use PadsControl/QueryPadsControl instead! */
	RMDispDigitalOutPropertyID_PadsConfig = 6094,
	/** DispDigitalOut_InputPadsConfig_type, (R/W) @par 
		Several input options - OBSOLETE, use PadsControl/QueryPadsControl instead! */
	RMDispDigitalOutPropertyID_InputPadsConfig = 6095,
	/** DispDigitalOut_PadsControl_type, (W) @par 
		Several options for the digital input and output ports */
	RMDispDigitalOutPropertyID_PadsControl = 6202,
	/** DispDigitalOut_QueryPadsControl_in_type and DispDigitalOut_QueryPadsControl_out_type, (R/W Exchange) @par 
		Get the current state of several options for the digital input and output ports */
	RMDispDigitalOutPropertyID_QueryPadsControl = 6203,
	/** ::void, (W) @par 
		Trigger an update of the xtal counter values for VSyncTimes. Need to be followed by a Validate call. */
	RMDispDigitalOutPropertyID_UpdateVSyncTimes = 6209,
	/** DispDigitalOut_VSyncTimes_type, (R) @par 
		Retreive the xtal counter value at the time of each input and output vsync resp. frame start */
	RMDispDigitalOutPropertyID_VSyncTimes = 6208,
};

/** Module Enum Default */
enum RMDispMainAnalogOutPropertyID {
	/** ::RMbool, (R/W) @par 
		Defines if the SD input signal is oversampled 2 times */
	RMDispMainAnalogOutPropertyID_EnableSDTVInput2xOversample = 6107,
	/** ::RMbool, (R/W) @par 
		Saves energy! */
	RMDispMainAnalogOutPropertyID_EnableSync = 6108,
	/** ::RMbool, (R/W) @par 
		Blackout the picture */
	RMDispMainAnalogOutPropertyID_EnablePicture = 6109,
	/** ::enum EMhwlibSharpnessControl, (R/W) @par 
		Sharpness/Notch filter allows to scale the luma amplitude around the chroma carrier frequency. A complete notch is performed by setting to 0 the luma amplitude around the chroma carrier frequency. Sharpness is done by amplifying luma amplitude on its high frequency (the high frequency is the chroma carrier frequency) */
	RMDispMainAnalogOutPropertyID_Sharpness = 6110,
	/** ::enum EMhwlibChromaFilter, (R/W) @par 
		Sets/Gets the Chroma filter */
	RMDispMainAnalogOutPropertyID_ChromaFilter = 6111,
	/** ::enum EMhwlibLumaFilter, (R/W) @par 
		Sets/Gets the Luma filter */
	RMDispMainAnalogOutPropertyID_LumaFilter = 6112,
	/** ::enum EMhwlibColorSpace, (R/W) @par 
		Enum Default; */
	RMDispMainAnalogOutPropertyID_ColorSpaceCVBS = 6113,
};

/** Module Enum Default */
enum RMDispComponentOutPropertyID {
	/** ::RMbool, (R/W) @par 
		Defines if the SD input signal is oversampled 2 times */
	RMDispComponentOutPropertyID_EnableSDTVInput2xOversample = 6114,
	/** ::RMbool, (R/W) @par 
		Saves energy! */
	RMDispComponentOutPropertyID_EnableSync = 6115,
	/** ::RMbool, (R/W) @par 
		Blackout the picture */
	RMDispComponentOutPropertyID_EnablePicture = 6116,
	/** ::enum EMhwlibChromaFilter, (R/W) @par 
		Sets/Gets the Chroma filter */
	RMDispComponentOutPropertyID_ChromaFilter = 6117,
	/** ::enum EMhwlibLumaFilter, (R/W) @par 
		Sets/Gets the Luma filter */
	RMDispComponentOutPropertyID_LumaFilter = 6118,
};

/** Module Enum Default */
enum RMDispCompositeOutPropertyID {
	/** ::RMbool, (R/W) @par 
		Defines if the SD input signal is oversampled 2 times */
	RMDispCompositeOutPropertyID_EnableSDTVInput2xOversample = 6119,
	/** ::RMbool, (R/W) @par 
		Saves energy! */
	RMDispCompositeOutPropertyID_EnableSync = 6120,
	/** ::RMbool, (R/W) @par 
		Blackout the picture */
	RMDispCompositeOutPropertyID_EnablePicture = 6121,
	/** ::enum EMhwlibSharpnessControl, (R/W) @par 
		Sharpness/Notch filter allows to scale the luma amplitude around the chroma carrier frequency. A complete notch is performed by setting to 0 the luma amplitude around the chroma carrier frequency. Sharpness is done by amplifying luma amplitude on its high frequency (the high frequency is the chroma carrier frequency) */
	RMDispCompositeOutPropertyID_Sharpness = 6122,
	/** ::enum EMhwlibChromaFilter, (R/W) @par 
		Sets/Gets the Chroma filter */
	RMDispCompositeOutPropertyID_ChromaFilter = 6123,
	/** ::enum EMhwlibLumaFilter, (R/W) @par 
		Sets/Gets the Luma filter */
	RMDispCompositeOutPropertyID_LumaFilter = 6124,
};

/** Module Enum Default */
enum RMDemuxEnginePropertyID {
	RMDemuxEngine_unused = 0, 
};

/** Module Enum Default */
enum RMMpegEnginePropertyID {
	RMMpegEngine_unused = 0, 
};

/** Module Enum Default */
enum RMVideoDecoderPropertyID {
	/** ::RMuint32, (R) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_FrameCounter = 6132,
	/** ::RMbool, (W) @par 
		If FALSE, video decoder skips all frames until first SequenceHeader/VOL in stream. If TRUE video decoder starts decoding from the first IFrame in stream, using the previous stored SequenceHeader/VOL. It should be set after video stop and before video play. After video stop the decoder modifies it to FALSE. */
	RMVideoDecoderPropertyID_StorePreviousVideoHeader = 6133,
	/** ::struct VideoDecoder_NextPicture_type, (R) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_PeekNextPicture = 6134,
	/** VideoDecoder_ConnectReader_in_type and VideoDecoder_ConnectReader_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_ConnectReader = 6135,
	/** ::void, (W) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_DisconnectReader = 6136,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_ReleasePicture = 6137,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_AcquirePicture = 6138,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_KeepPictureBeforeFlushing = 6139,
	/** ::void, (W) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_FlushReaderDisplayFIFO = 6140,
	/** ::struct VideoDecoder_NextPicture_type, (R) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_NextPicture = 6141,
	/** ::struct EMhwlibActiveFormatDescription, (R) @par 
		Returns the current active format (extracted from the user data) and the picture aspect ratio of the encoded frame. */
	RMVideoDecoderPropertyID_ActiveFormat = 6192,
};

/** This module provides access to the Audio DSP specific functionalities */
enum RMAudioEnginePropertyID {
	RMAudioEngine_unused = 0, 
};

/** This module provides access to the Audio decoder settings */
enum RMAudioDecoderPropertyID {
	/** ::RMuint32, (R) @par 
		Enum Default; */
	RMAudioDecoderPropertyID_CurrentPTS = 6143,
	/** AudioDecoder_SynchroniseAudioWithDisplayPTS_type, (W) @par 
		Enum Default; */
	RMAudioDecoderPropertyID_SynchroniseAudioWithDisplayPTS = 6145,
	/** AudioDecoder_AudioPlayTime_type, (W) @par 
		Enum Default; */
	RMAudioDecoderPropertyID_AudioPlayTime = 6187,
	/** AudioDecoder_AudioBDJPanning_type, (W) @par 
		BDJ panning parameter in (x, y) coordinate. */
	RMAudioDecoderPropertyID_AudioBDJPanning = 6199,
	/** AudioDecoder_AudioBDJGain_type, (W) @par 
		BDJ gain parameter [-51dB to +12dB], Note:-51=-OO, -50=-50dB and so on. */
	RMAudioDecoderPropertyID_AudioBDJGain = 6200,
	/** AudioDecoder_AudioControlPCMX_type, (R/W) @par 
		PCMX decoder control (0:nothing change, 1: to flush bts fifo, 2:EOS Signal). */
	RMAudioDecoderPropertyID_AudioControlPCMX = 6207,
};

/** This module provides access to the Audio decoder settings */
enum RMAudioCapturePropertyID {
	RMAudioCapture_unused = 0, 
};

/** This module provides access to the Voip codec settings */
enum RMVoipCodecPropertyID {
	RMVoipCodec_unused = 0, 
};

/** Module Enum Default */
enum RMCRCDecoderPropertyID {
	RMCRCDecoder_unused = 0, 
};

/** Module Enum Default */
enum RMXCRCDecoderPropertyID {
	RMXCRCDecoder_unused = 0, 
};

/** Module Enum Default */
enum RMStreamCapturePropertyID {
	RMStreamCapture_unused = 0, 
};

/** Module Enum Default */
enum RMRawDataTransferPropertyID {
	RMRawDataTransfer_unused = 0, 
};

/** Module Enum Default */
enum RMI2CPropertyID {
	/** I2C_DeviceParams_type, (R/W) @par 
		Obsolete, use DeviceParameter / QueryDeviceParameter instead! */
	RMI2CPropertyID_DeviceParams = 6146,
	/** ::struct EMhwlibI2CDeviceParameter, (W) @par 
		Enum Default; */
	RMI2CPropertyID_DeviceParameter = 6205,
	/** I2C_QueryDeviceParameter_in_type and I2C_QueryDeviceParameter_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMI2CPropertyID_QueryDeviceParameter = 6206,
	/** I2C_WriteRMuint8_type, (W) @par 
		Enum Default; */
	RMI2CPropertyID_WriteRMuint8 = 6147,
	/** I2C_QueryRMuint8_in_type and I2C_QueryRMuint8_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMI2CPropertyID_QueryRMuint8 = 6148,
	/** ::RMuint8, (R/W) @par 
		Enum Default; */
	RMI2CPropertyID_RMuint8Access_NoSubAddress = 6149,
	/** I2C_WriteData_type, (W) @par 
		Enum Default; */
	RMI2CPropertyID_WriteData = 6150,
	/** I2C_QueryData_in_type and I2C_QueryData_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMI2CPropertyID_QueryData = 6151,
	/** I2C_SelectSegment_type, (W) @par 
		Enum Default; */
	RMI2CPropertyID_SelectSegment = 6152,
};

/** Module Enum Default */
enum RMGFXEnginePropertyID {
	RMGFXEngine_unused = 0, 
};

/** Module Enum Default */
enum RMMMPropertyID {
	RMMM_unused = 0, 
};

/** Module Enum Default */
enum RMSpuDecoderPropertyID {
	/** ::RMuint32, (W) @par 
		sets the scaler associated to the spu decoder */
	RMSpuDecoderPropertyID_Scaler = 6153,
	/** SpuDecoder_Palette_type, (W) @par 
		fill all 16*4 PGC_SP_PLT entries into LUT, with 0,Y,Cr,Cb) */
	RMSpuDecoderPropertyID_Palette = 6154,
	/** SpuDecoder_StreamType_enum, (W) @par 
		Description of the current sub picture stream number from PGC_SPST_CTL */
	RMSpuDecoderPropertyID_StreamType = 6155,
	/** ::RMbool, (R/W) @par 
		To turn the Sub Picture display on (TRUE) or off (FALSE). The GetProperty returns the actual state, e.g. it returns always TRUE if the sub picture stream is force-on. */
	RMSpuDecoderPropertyID_SubpictureOn = 6156,
	/** SpuDecoder_Hilight_type, (R/W) @par 
		 */
	RMSpuDecoderPropertyID_Hilight = 6157,
	/** SpuDecoder_BDRLECommand_type, (R/W) @par 
		 */
	RMSpuDecoderPropertyID_BDRLECommand = 6158,
	/** SpuDecoder_BDRLEBatchCommand_type, (W) @par 
		 */
	RMSpuDecoderPropertyID_BDRLEBatchCommand = 6190,
	/** ::RMuint32, (R) @par 
		returns the address of the previously allocated and filled struct vsync_surface */
	RMSpuDecoderPropertyID_VSyncSurface = 6160,
};

/** Module Enum Default */
enum RMPictureTransformPropertyID {
	RMPictureTransform_unused = 0, 
};

/** Module Enum Default */
enum RMClosedCaptionDecoderPropertyID {
	RMClosedCaptionDecoder_unused = 0, 
};

/** Module Enum Default */
enum RMRTCPropertyID {
	RMRTC_unused = 0, 
};

/** Module Enum Default */
enum RMCipherPropertyID {
	RMCipher_unused = 0, 
};

/** Module Enum Default */
enum RMSTCPropertyID {
	RMSTC_unused = 0, 
};

/** Module Enum Default */
enum RMPLLPropertyID {
	RMPLL_unused = 0, 
};

/** Module Enum Default */
enum RMDemuxCipherPropertyID {
	RMDemuxCipher_unused = 0, 
};

/** Module Enum Default */
enum RMDemuxTaskPropertyID {
	/** ::RMcss_chlgkey, (R) @par 
		implemented only for EM8622 */
	RMDemuxTaskPropertyID_CSSchlgkey1 = 6177,
	/** ::RMcss_key, (W) @par 
		implemented only for EM8622 */
	RMDemuxTaskPropertyID_CSSkey1 = 6178,
	/** ::RMcss_chlgkey, (W) @par 
		implemented only for EM8622 */
	RMDemuxTaskPropertyID_CSSchlgkey2 = 6179,
	/** ::RMcss_key, (R) @par 
		implemented only for EM8622 */
	RMDemuxTaskPropertyID_CSSkey2 = 6180,
	/** ::RMcss_disckey, (W) @par 
		implemented only for EM8622 */
	RMDemuxTaskPropertyID_CSSdisckey = 6181,
	/** ::RMcss_titlekey, (W) @par 
		implemented only for EM8622 */
	RMDemuxTaskPropertyID_CSStitlekey = 6182,
};

/** Module Enum Default */
enum RMDemuxOutputPropertyID {
	RMDemuxOutput_unused = 0, 
};

/** Module Enum Default */
enum RMCCFifoPropertyID {
	RMCCFifo_unused = 0, 
};

/** Module Enum Default */
enum RMDispVideoPlanePropertyID {
	/** DispVideoPlane_Transparency_type, (R/W) @par 
		Specifies what color becomes transparent.@note The alpha plane below this plane will be visible */
	RMDispVideoPlanePropertyID_Transparency = 6161,
};

/** Converts a HD content to a SD content */
enum RMDispHDSDConverterPropertyID {
	/** DispHDSDConverter_OnTheFlyModeParameters_in_type and DispHDSDConverter_OnTheFlyModeParameters_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDispHDSDConverterPropertyID_OnTheFlyModeParameters = 6162,
	/** DispHDSDConverter_OnTheFlyModeParametersX_in_type and DispHDSDConverter_OnTheFlyModeParametersX_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDispHDSDConverterPropertyID_OnTheFlyModeParametersX = 6163,
	/** DispHDSDConverter_BufferedModeParameters_in_type and DispHDSDConverter_BufferedModeParameters_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDispHDSDConverterPropertyID_BufferedModeParameters = 6164,
	/** DispHDSDConverter_BufferedModeParametersX_in_type and DispHDSDConverter_BufferedModeParametersX_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDispHDSDConverterPropertyID_BufferedModeParametersX = 6165,
	/** DispHDSDConverter_Open_type, (W) @par 
		Enum Default; */
	RMDispHDSDConverterPropertyID_Open = 6166,
	/** DispHDSDConverter_OpenX_type, (W) @par 
		Enum Default; */
	RMDispHDSDConverterPropertyID_OpenX = 6167,
	/** ::RMuint32, (R/W) @par 
		Enum Default; */
	RMDispHDSDConverterPropertyID_DumpedLines = 6168,
	/** ::RMuint32, (R/W) @par 
		Enum Default; */
	RMDispHDSDConverterPropertyID_DumpedPixels = 6169,
	/** ::void, (W) @par 
		Enum Default; */
	RMDispHDSDConverterPropertyID_Close = 6170,
	/** ::enum EMhwlibHDSDConversionMode, (W) @par 
		Enum Default; */
	RMDispHDSDConverterPropertyID_ConversionMode = 6171,
	/** DispHDSDConverter_ConversionBuffer_type, (R) @par 
		Enum Default; */
	RMDispHDSDConverterPropertyID_ConversionBuffer = 6172,
	/** ::enum EMhwlib422DownSamplingMode, (R/W) @par 
		 */
	RMDispHDSDConverterPropertyID_422DownSamplingMode = 6174,
	/** ::RMbool, (R/W) @par 
		Enum Default; */
	RMDispHDSDConverterPropertyID_ConstrainedOutput = 6195,
};

/** Module Enum Default */
enum RMSha1SumPropertyID {
	RMSha1Sum_unused = 0, 
};

/** Module Enum Default */
enum RMXTaskPropertyID {
	RMXTask_unused = 0, 
};

/** Module Enum Default */
enum RMTTXFifoPropertyID {
	RMTTXFifo_unused = 0, 
};

/** Module Enum Default */
enum RMVCXOPropertyID {
	RMVCXO_unused = 0, 
};

/** Module Enum Default */
enum RMPPFPropertyID {
	RMPPF_unused = 0, 
};

enum RMGenericPropertyID {
	RMGenericPropertyID_Name = 6175,
	RMGenericPropertyID_LockMixerSourceScalingMode = 6060,
	RMGenericPropertyID_DefaultSurface = 6012,
	RMGenericPropertyID_ForceBackGround = 6063,
	RMGenericPropertyID_LUTAddress = 6024,
	RMGenericPropertyID_CutStripMode = 6044,
	RMGenericPropertyID_TransparentStrips = 6043,
	RMGenericPropertyID_VBIData = 6074,
	RMGenericPropertyID_ColorDegradationBoundary = 6028,
	RMGenericPropertyID_LumaKeying = 6196,
	RMGenericPropertyID_Stop = 6034,
	RMGenericPropertyID_2BPP_LUT = 6021,
	RMGenericPropertyID_MixerSourceWindow = 6058,
	RMGenericPropertyID_IsColorFormatSupported = 6027,
	RMGenericPropertyID_VBIReadbackI2C = 6075,
	RMGenericPropertyID_DownScalingMode = 6040,
	RMGenericPropertyID_ScalerInputWindow = 6030,
	RMGenericPropertyID_ForceInterlacedBoundary = 6029,
	RMGenericPropertyID_Alpha1 = 6016,
	RMGenericPropertyID_MasterClockGenerator = 6100,
	RMGenericPropertyID_EnableFading = 6017,
	RMGenericPropertyID_ScalingMode = 6039,
	RMGenericPropertyID_ColorSpace = 6061,
	RMGenericPropertyID_VBICaptureRaw = 6072,
	RMGenericPropertyID_RemoveSlaveOutput = 6097,
	RMGenericPropertyID_Detect = 6076,
	RMGenericPropertyID_CurrentDisplayPTS = 6051,
	RMGenericPropertyID_SyncOnPbPr = 6186,
	RMGenericPropertyID_Genlock = 6101,
	RMGenericPropertyID_Validate = 6010,
	RMGenericPropertyID_Enable = 6008,
	RMGenericPropertyID_SCARTWideScreen = 6106,
	RMGenericPropertyID_SlaveOutput = 6098,
	RMGenericPropertyID_4BPP_LUT = 6022,
	RMGenericPropertyID_1BPP_LUT = 6020,
	RMGenericPropertyID_Step = 6036,
	RMGenericPropertyID_NonLinearScalingMode = 6041,
	RMGenericPropertyID_TimingResetMaster = 6099,
	RMGenericPropertyID_BlackStripMode = 6042,
	RMGenericPropertyID_Surface = 6011,
	RMGenericPropertyID_DeinterlacingMode = 6054,
	RMGenericPropertyID_VBICaptureANC = 6073,
	RMGenericPropertyID_ComponentMode = 6102,
	RMGenericPropertyID_DisplayTimeInterval = 6037,
	RMGenericPropertyID_BackgroundColor = 6062,
	RMGenericPropertyID_Profile = 6144,
	RMGenericPropertyID_PersistentSurface = 6013,
	RMGenericPropertyID_IsColorModeSupported = 6026,
	RMGenericPropertyID_SubPictureSurface = 6038,
	RMGenericPropertyID_CaptureDelay = 6078,
	RMGenericPropertyID_ScalerFieldSelection = 6009,
	RMGenericPropertyID_Flush = 6035,
	RMGenericPropertyID_VBIReadbackI2CCC = 6210,
	RMGenericPropertyID_SCART = 6105,
	RMGenericPropertyID_SCARTConfig = 6104,
	RMGenericPropertyID_MixerSourceIndex = 6057,
	RMGenericPropertyID_SourceDisplayAspectRatio = 6052,
	RMGenericPropertyID_VBIStore = 6071,
	RMGenericPropertyID_8BPP_LUT = 6023,
	RMGenericPropertyID_IsColorSpaceSupported = 6025,
	RMGenericPropertyID_AddSlaveOutput = 6096,
	RMGenericPropertyID_KeyColor = 6019,
	RMGenericPropertyID_DisplayAspectRatio = 6055,
	RMGenericPropertyID_CompositeMode = 6103,
	RMGenericPropertyID_Alpha0 = 6015,
	RMGenericPropertyID_EnableGammaCorrection = 6018,
	RMGenericPropertyID_MixerSourceState = 6059,
	RMGenericPropertyID_TTXFifo = 6189,
	RMGenericPropertyID_SyncSourceModuleID = 6077,
	RMGenericPropertyID_PixelClockVCXOTimer = 6201,
	RMGenericPropertyID_DACEnable = 6188,
	RMGenericPropertyID_CCFifo = 6064,
	RMGenericPropertyID_TVStandard = 6068,
};

#endif /* __EMHWLIB_PROPERTIES_6000_H__ */

/* End of generated file include/emhwlib_properties_6000.h */
