/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   emhwlib_versions.h
  @brief  

  Should be set to the cvs tag just before build (see #4281)
  Do not use cvs keywords

  @author Emmanuel Michon
  @date   2003-05-21
*/

#ifndef __EMHWLIB_VERSIONS_H__
#define __EMHWLIB_VERSIONS_H__

#define EMHWLIB_TAG_STRING(M, m, w, s, e)	"v" #M "_" #m "_" #w "_" #s #e
#define EMHWLIB_TAG_MAKER(M, m, w, s, e)	EMHWLIB_TAG_STRING(M, m, w, s, e)

#define EMHWLIB_VERSION_STRING(M, m, w, s, e)	#M "." #m "." #w "." #s #e
#define EMHWLIB_VERSION_MAKER(M, m, w, s, e)	EMHWLIB_VERSION_STRING(M, m, w, s, e)




#define EMHWLIB_VERSION_MAJOR	2
#define EMHWLIB_VERSION_MINOR	8
#define EMHWLIB_VERSION_WEEK	0
#define EMHWLIB_VERSION_SUB	0
#define EMHWLIB_VERSION_EXTRA
#define EMHWLIB_TAG_EXTRA

#define EMHWLIB_VERSION 	( (EMHWLIB_VERSION_MAJOR << 24) \
				| (EMHWLIB_VERSION_MINOR << 16) \
				| (EMHWLIB_VERSION_WEEK  <<  8) \
				|  EMHWLIB_VERSION_SUB)
#define EMHWLIB_VERSION_S	EMHWLIB_VERSION_MAKER(\
					EMHWLIB_VERSION_MAJOR, \
					EMHWLIB_VERSION_MINOR, \
					EMHWLIB_VERSION_WEEK,  \
					EMHWLIB_VERSION_SUB,   \
					EMHWLIB_VERSION_EXTRA)
#define EMHWLIB_TAG_S		EMHWLIB_TAG_MAKER(\
					EMHWLIB_VERSION_MAJOR, \
					EMHWLIB_VERSION_MINOR, \
					EMHWLIB_VERSION_WEEK,  \
					EMHWLIB_VERSION_SUB,   \
					EMHWLIB_TAG_EXTRA)


#endif // __EMHWLIB_VERSIONS_H__
