/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   emhwlib_resources.h
  @brief  

  Central repository for mutexes, pt110 local ram

  @author Emmanuel Michon
  @date   2003-07-09
*/

#ifndef __EMHWLIB_RESOURCES_H__
#define __EMHWLIB_RESOURCES_H__

#include "emhwlib_dram.h"
#include "../../emhwlib_hal/include/emhwlib_lram.h"

// mutexes:

/* 
   Mpeg engine:
   The policy of Laurian is to use mpeg engine mutexes in increasing order, one per stream.

   Audio engine:
   Though 16bit fifos are not used on audio riscs, audio riscs mutexes will also be used
   for irq signalling (consistency of applying a mask and raising a bit).

   Other ones:
   Let's take them from audio engine 1 starting from the last...
*/

#if (EM86XX_CHIP==EM86XX_CHIPID_MAMBOLIGHT)
#include "mambolight/emhwlib_resources_mambolight.h"
#elif (EM86XX_CHIP==EM86XX_CHIPID_MAMBO)
#include "mambo/emhwlib_resources_mambo.h"
#elif (EM86XX_CHIP==EM86XX_CHIPID_TANGOLIGHT)
#include "tangolight/emhwlib_resources_tangolight.h"
#elif (EM86XX_CHIP==EM86XX_CHIPID_TANGO15)
#include "tango15/emhwlib_resources_tango15.h"
#elif (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
#include "tango2/emhwlib_resources_tango2.h"
#elif (EM86XX_CHIP==EM86XX_CHIPID_TANGO3)
#include "tango3/emhwlib_resources_tango3.h"
#else
#error EM86XX_CHIP is not set in RMCFLAGS: refer to emhwlib/include/emhwlib_chips.h.
#endif

#include "emhwlib_resources_shared.h"

#endif // __EMHWLIB_RESOURCES_H__
