/*****************************************
 Copyright  2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   emhwlib_globaltypes.h
  @brief  

  long description

  @author Emmanuel Michon
  @date   2003-05-09
*/

#ifndef __EMHWLIB_GLOBALTYPES_H__
#define __EMHWLIB_GLOBALTYPES_H__

#include "emhwlib_videoformats.h"
#include "emhwlib_displaytypes.h"
#include "../../emhwlib_hal/pll/include/pll_hal_types.h"

struct EMhwlibMacrovisionParam {
	RMuint32 N0;
	RMuint32 N1;
	RMuint32 N2;
	RMuint32 N3;
	RMuint32 N4;
	RMuint32 N5;
	RMuint32 N6;
	RMuint32 N7;
	RMuint32 N8;
	RMuint32 N9;
	RMuint32 N10;
	RMuint32 N11;
	RMuint32 N12;
	RMuint32 N13;
	RMuint32 N14;
	RMuint32 N15;
	RMuint32 N16;
	RMuint32 N17;
	RMuint32 N18;
	RMuint32 N19;
	RMuint32 N20;
	RMuint32 N21;
	RMuint32 N22;
};
	
struct EMhwlibClockGenerator {
	enum PLLGen PLL;
	enum PLLOut PLLOut;
};

struct EMhwlibSubPictureSurface_type {
	RMuint32 Scaler;  // the scaler to be used for displaying the sub picture, or 0 to disable
	RMuint32 Surface;  // the surface ID for the sub picture
};

enum EMhwlibCCType{
	EMhwlibCCType_TopField = 0,
	EMhwlibCCType_BottomField = 1,
	EMhwlibCCType_DTVCCData = 2,
	EMhwlibCCType_DTVCCHeader = 3
};

enum EMhwlibCCSelect{
	EMhwlibCCSelect_CC1 = 1,
	EMhwlibCCSelect_CC2 = 2,
	EMhwlibCCSelect_CC3 = 3,
	EMhwlibCCSelect_CC4 = 4,
};

#define	RUA_DRAM0_ZONEA 2
#define	RUA_DRAM1_ZONEA 3
#define	RUA_DRAM0_ZONEB 4
#define	RUA_DRAM1_ZONEB 5

enum RUADramType { 
	RUA_DRAM_UNPROTECTED = 57,
	RUA_DRAM_CACHED = RUA_DRAM_UNPROTECTED,
	RUA_DRAM_UNCACHED = RUA_DRAM_UNPROTECTED,
	RUA_DRAM_ZONEA,
	RUA_DRAM_PB = RUA_DRAM_ZONEA, // picture buffer zone, alternate name
	RUA_DRAM_ZONEB,
	RUA_DRAM_BB = RUA_DRAM_ZONEB, // bitstream buffer zone, alternate name
};

enum FIFOType {
	FIFO32BitRel,  // 32bit abs gbus address 'start', 32bit 'size' in byte, 32bit 'readptr'and 'writeptr' 0..size-1
	FIFO16BitRel,  // same as 32BitRel, but each ptr as 16BitHi/16BitLo in MPEG-DMem. use semaphores.
	FIFO16BitRelDemo,  // same as 16BitRel, but for guillaume's demo code. different semaphores and wrptr is 4 bytes further.
	FIFO32BitDemux,  // 32 Bit abs demux dmem address 'start', ??? (have to check my docs) to get gbus addr, take Rd/WrPtr * 4 + (base & 0xFFFF0000)
	FIFO32BitEraser  // ??? what is this eraser thingy?
};

enum InputFormat {
	InputFormat_24bpp = 0, 
	InputFormat_24bpp_8565 = 1, 
	InputFormat_24bpp_5676 = 2, 
	InputFormat_32bpp = 3, 
	InputFormat_16bpp_565 = 4, 
	InputFormat_16bpp_1555 = 5, 
	InputFormat_16bpp_4444 = 6, 
	InputFormat_31bpp_7888 = 7
};

enum ProcessorState {
	CPU_RUNNING,
	CPU_STOPPED,
	CPU_RESET
};

enum ClockInputSelect {
	ClockInputSelect_PowerDown = 0, 
	ClockInputSelect_XTAL = 1, 
	ClockInputSelect_VCXO0 = 2, 
	ClockInputSelect_VCXO1 = 3, 
	ClockInputSelect_RCLK0 = 4, 
	ClockInputSelect_RCLK1 = 5, 
	ClockInputSelect_VI0 = 6, 
	ClockInputSelect_VI1 = 7
};

enum MPEG_Profile {
	Profile_FIRST_ = 0, 
	Profile_MPEG2_SD,
	Profile_MPEG2_DVD,
	Profile_MPEG2_HD,
	Profile_MPEG4_SD,
	Profile_MPEG4_SD_Padding,
	Profile_MPEG4_HD,
	Profile_MPEG4_HD_Padding,
	Profile_MPEG2_SD_Packed,
	Profile_MPEG2_DVD_Packed,
	Profile_MPEG2_HD_Packed,
	Profile_MPEG4_SD_Packed,
	Profile_MPEG4_HD_Packed,
	Profile_MPEG2_SD_DeInt,
	Profile_MPEG2_DVD_DeInt,
	Profile_MPEG2_HD_DeInt,
	Profile_MPEG4_SD_DeInt,
	Profile_MPEG4_SD_DeInt_Padding,
	Profile_MPEG4_HD_DeInt,
	Profile_MPEG4_HD_DeInt_Padding,
	Profile_MPEG2_SD_Packed_DeInt,
	Profile_MPEG2_DVD_Packed_DeInt,
	Profile_MPEG2_HD_Packed_DeInt,
	Profile_MPEG4_SD_Packed_DeInt,
	Profile_MPEG4_HD_Packed_DeInt,
	Profile_WMV_SD,
	Profile_WMV_816P,
	Profile_WMV_HD,
	Profile_DIVX3_SD,
	Profile_DIVX3_HD,
	Profile_DIVX3_SD_Packed,
	Profile_DIVX3_HD_Packed,
	Profile_H264_SD,
	Profile_H264_HD,
	Profile_H264_SD_DeInt,
	Profile_H264_HD_DeInt,
	Profile_VC1_SD,
	Profile_VC1_HD,
	Profile_LAST_
};

enum AACInputFormat {
	ADIF_header = 0,
	ADTS_header = 1,
	DSI_header = 2
};

enum TestToneType {
	Ttone_WhiteNoise = 0,
	Ttone_other
};

enum DemuxSourceType {
	SourceType_atsc,
	SourceType_payload,	/* no information about input - used for decryption or encryption */
	SourceType_dvd,
	SourceType_m1s,
	SourceType_m2t,
	SourceType_cipher_only /* replace unused SourceType_dvb */
};

enum DemuxSpiType {
	No_Spi,
	Serial_Spi,
	Paralel_Spi
};

enum DemuxTriggerType {
	Trigger_None,
	Trigger_PCR,
	Trigger_VideoPts,
	Trigger_AudioPts,
	Trigger_VideoOrAudioPts,
	Trigger_PayloadUnitStartIndicator
};

enum DemuxOutputTrigger_type {
	DemuxOutputTrigger_None,
	DemuxOutputTrigger_Pts,
	DemuxOutputTrigger_PayloadUnitStartIndicator /* used only for transport stream */
};

enum TransferTaskCallback {
	TRANSFER_TASK_CALLBACK_NONE,
	TRANSFER_TASK_CALLBACK_GFX,
	TRANSFER_TASK_CALLBACK_DEMUX,
	TRANSFER_TASK_CALLBACK_DEMUX_OUTPUT,
};

enum TransferTaskDirection {
	TRANSFER_TASK_DIRECTION_WRITE,
	TRANSFER_TASK_DIRECTION_READ,
};

/* this enum is used for indexing an array (fifo_ops) */
enum TransferTaskFifoMode {
	TRANSFER_TASK_FIFO_MODE_WRITE_PTS_DMEM_32 = 0,
	TRANSFER_TASK_FIFO_MODE_WRITE_PTS_DMEM_16,
	TRANSFER_TASK_FIFO_MODE_WRITE_MUTEX_PTS_DMEM_16,
	TRANSFER_TASK_FIFO_MODE_WRITE_PTS_ERASER,
	TRANSFER_TASK_FIFO_MODE_READ_PTS_DMEM_32,
	TRANSFER_TASK_FIFO_MODE_READ_PTS_DMEM_16,
	TRANSFER_TASK_FIFO_MODE_READ_MUTEX_PTS_DMEM_16,
	TRANSFER_TASK_FIFO_MODE_READ_PTS_ERASER,
};

#define MAX_AUDIO_PARAM_EXTENSIONS 9
struct AudioSpecificParams {
	RMuint32 DecoderParams;
	RMuint32 DecodeParamExtensions[MAX_AUDIO_PARAM_EXTENSIONS];
};

struct ScalerLUT {
	RMuint32 Size;
	RMuint32 Data[256];
};


struct CursorLUT {
 	RMuint32 Data[16];
};

struct BWArbiterParam{
	RMuint32 MaxBW;
	RMuint32 MinBW;
	RMbool Enable;
};



struct TeleTextBuffer {
	RMuint32 Size;
	RMuint32 Data[0x300];
};

/*
  This is meant to transfer large amounts of data by properties,
  to be used for very special data (like microcode).
  
  Since this structure embeds a pointer, it cannot be used in
  situations where the adressing space changes (user/kernel transition,
  remote network access situations).
*/
struct emhwlib_datablock {
	RMuint8 *data;
	RMuint32 size;
};

#define TIME_STAMP_INFO			0x00000001
#define FIRST_ACCESS_UNIT_POINTER_INFO	0x00000002

/*
  Meant to transfer specific information associated with data to be transferred
*/
struct emhwlib_info {
	RMuint32 ValidFields;		// or-ed flags: TIME_STAMP_INFO, FIRST_ACCESS_UNIT_INFO
	RMuint64 TimeStamp;
	RMuint32 FirstAccessUnitPointer;
};

struct mm_spec {
	RMuint32 start;
	RMuint32 size;
	void *syncCookie;
};

struct DecoderProcessInterrupt_type {
	RMuint32 stream;
	RMuint32 *pEstatus;
};

struct ReadBufferInfo {
	RMuint32 address;
	RMuint32 size;
	void *context;
};

enum RawDataTransferDirection {
	RawDataTransferDirection_Read = 32,
	RawDataTransferDirection_Write,
};

struct SoftIrqTaskEvent {
	RMuint32 TaskAddress;
	RMuint32 EventMask;
};

struct InbandCommand_type {
	RMuint32 Tag;
	RMuint32 Coordinate;
};

enum EMhwlibInbandCommmand {
	EMhwlibInbandCommand_EOS = 0x16
};

typedef RMuint32 RMpalette_1BPP[2];
typedef RMuint32 RMpalette_2BPP[4];
typedef RMuint32 RMpalette_4BPP[16];
typedef RMuint32 RMpalette_8BPP[256];

typedef RMuint32 RMCursorLut[16];
typedef RMuint32 RMCursorPix[512];

typedef RMuint8 RMcss_chlgkey[10];
typedef RMuint8 RMcss_key[5];
typedef RMuint8 RMcss_disckey[2028];
typedef RMuint8 RMcss_titlekey[5];

typedef RMuint8 RMAESKey[16];
typedef RMuint8 RMDESKey[8];
typedef RMuint8 RMRC4Key[32];

typedef RMuint8  RMuint8x6[6];		/* array of 6 RMuint8 - used for C2 key */
typedef RMuint8  RMuint8x8[8];		/* array of 8 RMuint8 - used for DES key */
typedef RMuint8  RMuint8x32[32];	/* array of 32 RMuint8 - used for Demux Encryption */
typedef RMuint8  RMuint8x256[256];	/* array of 256 RMuint8 - used for C2 cipher */
typedef RMuint16 RMuint16x8[8];		/* array of  8 RMuint16 - used for AudioDecoder LpcmAobParameters */
typedef RMuint16 RMuint16x6[6];		/* array of  6 RMuint16 - used for AudioDecoder LpcmVobParameters*/
typedef RMuint32 RMuint32x6[6];		/* array of  6 RMuint32 - used for VideoDecoder InbandParams */
typedef RMint32  RMuint32x64[64];	/* array of 64 RMuint32 - used for AudioDecoder WMAParameters */

typedef RMuint32 RMuint32x4[4];		/* array of  4 RMuint32 */
typedef RMint32  RMint32x5[5];		/* array of  5 RMint32 - used for AudioDecoder WMAParameters */

typedef RMuint32 RMsha1Sum[5];

typedef RMuint32 RMVSyncXtal[6][2]; /* current and last xtal counter value at the time of each vsync [0:CVBS, 1:YUV, 2:MAO, 3:DIG, 4:VID, 5:GFX][0:current, 1:last] */

enum EncryptionType {
	AES_128 = 1,
	AES_256
};

struct RMcipherBuffer {
	RMuint32 FromAddress;
	RMuint32 ToAddress;
	RMuint32 Size;
};

struct DRAMSizeXferFIFO_in_type {
	RMuint32 XferFIFOSize;
	RMuint32 XferFIFOCount;
};

struct DRAMSizeXferFIFO_out_type {
	RMuint32 CachedSize;
	RMuint32 UncachedSize;
};

struct AddXferFIFO_type {
	RMuint32 XferFIFOSize;
	RMuint32 XferFIFOCount;
	RMuint32 CachedAddress;
	RMuint32 CachedSize;
	RMuint32 UncachedAddress;
	RMuint32 UncachedSize;
};

struct ReceiveThreshold_type {
	RMbool partial_read;	/* if TRUE the buffer is completed after every interrupt, even if it is not full */
	RMuint32 size;		/* interrupt is issued after writting "size" bytes */ 
};

/* information about send/receive data fifo:
	- VideoDecoder target 0 = sent bitstream
	- VideoDecoder target 1 = received user_data
	- AudioDecoder target 0 = sent bitstream
	- SpuDecoder target 0 = sent bitstream
	- Demux target 0 = sent bitstream
	- Demux target 1 = received pid filter
	- Demux target 2 = received record data
	- StreamCapture target 0 = received spi data
All the sizes are expressed in bytes.
Writable is the number of bytes that can be written inside the fifo. Writable express the emptiness of the fifo.
Readable is the number of bytes that should be read by decoder. Readable express the fullness of the fifo.
*/
struct DataFIFOInfo {
	RMuint32 StartAddress;
	RMuint32 Size;
	RMuint32 Writable;
	RMuint32 Readable;
};

struct UserDataFIFOInfo {
	RMuint32 ContainerAddress;
	RMuint32 StartAddress;
	RMuint32 Size;
	RMuint32 WrPtr;
	RMuint32 RdPtr;
};

/* information about send/receive the list of buffers queued for send or receive - so called xfer fifo.
Modules and targets same as for DataFIFOInfo.
All the sizes are expressed in entry units. One entry is one buffer.
Writable is the number of entries that can be written inside the fifo. Writable express the emptiness of the fifo.
Readable is the number of entries that should be read by decoder. Readable express the fullness of the fifo.
Erasable is the number of entries that were read by decoder, but not yet freed.
*/
struct XferFIFOInfo_type {
	RMuint32 StartAddress;
	RMuint32 Size;
	RMuint32 Writable;
	RMuint32 Readable;
	RMuint32 Erasable;
};

struct PSFMatchSection_type {
	RMuint8			expand_link_index;	// reserved for extending the lenght of section filter, value between 0...31 or 0xFF if not used
	RMuint8			and_link_index;		// reserved for "logical and" two section filters, value between 0...31 or 0xFF if not used
	RMuint8			mask[12];		// 96 bit mask - 1 means the mask is active
	RMuint8			mode[12];		// 96 bit mask - 1 means positive match, 0 means negative match
	RMuint8			comp[12];		// 96 bit value
};

struct PSFRangeSection_type {
	RMuint8			expand_link_index;	// reserved for extending the lenght of section filter, value between 0...31 or 0xFF if not used
	RMuint8			and_link_index;		// reserved for "logical and" two section filters, value between 0...31 or 0xFF if not used
	RMuint16		min_mask;		// 12 bit mask for the 12 bytes to be compared for min
	RMuint16		max_mask;		// 12 bit mask for the 12 bytes to be compared for max
	RMuint16		range_mask;		// 12 bit mask for the 12 bytes to be compared indicating inrange/outrange comparison
	RMuint8			min_comp[12];
	RMuint8			max_comp[12];
};

typedef RMascii EMhwlibString[256];

enum PictureOrientation{
	FRTop_FCLeft = 1,
	FRTop_FCRight,
	FRBottom_FCRight,
	FRBottom_FCLeft,
	FRLeft_FCTop,
	FRRight_FCTop,
	FRLeft_FCBottom,
	FRRight_FCBottom
};

struct GFXEngine_MoveReplaceRectangle_type {
	RMuint32 SrcX;
	RMuint32 SrcY;
	RMuint32 AlphaX; //alpha takes same width and height than dest
	RMuint32 AlphaY;
	RMuint32 DstX;
	RMuint32 DstY;
	RMuint32 Width;
	RMuint32 Height;
	enum gfx_merge_mode Merge;
};


struct GFXEngine_MoveReplaceScaleRectangle_type {
	RMuint32 SrcX;
	RMuint32 SrcY;
	RMuint32 AlphaX; //alpha takes same width and height than dest
	RMuint32 AlphaY;
	RMuint32 DstX;
	RMuint32 DstY;
	RMuint32 SrcWidth;
	RMuint32 SrcHeight;
	RMuint32 DstWidth;
	RMuint32 DstHeight;
	enum gfx_merge_mode Merge;
};

struct GFXEngine_MoveReplace_type {
	RMuint32 SrcX;
	RMuint32 SrcY;
	RMuint32 SrcWidth;
	RMuint32 SrcHeight;
	enum gfx_input_type SrcInput;
	enum gfx_surface_id SrcId;
	RMuint32 AlphaX;
	RMuint32 AlphaY;
	RMuint32 DstX;
	RMuint32 DstY;
	RMuint32 DstWidth;
	RMuint32 DstHeight;
	enum gfx_merge_mode Merge;
	RMuint32 Color;
};


struct GFXEngine_FillReplaceGradient_type {
	RMuint32 AlphaX;
	RMuint32 AlphaY;
	RMuint32 DstX;
	RMuint32 DstY;
	RMuint32 Width;
	RMuint32 Height;
	enum gfx_merge_mode Merge;
};

enum ScalerCommand {
	ScalerCommand_Uninit,  // reset to initial state
	ScalerCommand_Init,    // prepare for operation, results in state 'Stop'
	ScalerCommand_Stop,    // stop and display last frame
	ScalerCommand_Play,    // play
	ScalerCommand_Pause,   // pause and display last frame
	ScalerCommand_Flush,   // stop and flush last image, display black
};

enum ScalerState {
	ScalerState_Uninit, 
	ScalerState_UninitPending, 
	ScalerState_InitPending, 
	ScalerState_Stop, 
	ScalerState_StopPending, 
	ScalerState_Play, 
	ScalerState_PlayPending, 
	ScalerState_Pause, 
	ScalerState_PausePending, 
	ScalerState_Flush, 
	ScalerState_FlushPending, 
};

enum PanScanMode_type {
	NoPanScan,
	DefaultPanScan,
	ZoomedPanScan	// useless ??
};

enum MClkFactor {
	MClkFactor_128Xfs, 
	MClkFactor_256Xfs
};

enum OutputDualMode_type {
	DualMode_Stereo = 0,
	DualMode_LeftMono,
	DualMode_RightMono,
	DualMode_MixMono
};

enum AudioPlayMode_type {
	Audio_Play_Disable = 0,		// Disable Audio play control
	Audio_Play_From,			// Audio starts from preset PTS and plays to the end
	Audio_Play_To,				// Audio starts from very begining and plays to the preset PTS
	Audio_Play_From_To			// Audio starts from PTS0 and plays to PTS1
};

enum AudioChannelMap_type {
	Audio_L = 0,
	Audio_C = 1,
	Audio_R = 2,
	Audio_Ls = 3,
	Audio_Rs = 4,
	Audio_Lfe = 5,
	Audio_Lb = 6,
	Audio_Rb = 7,	
	Audio_SL = 8,		//Stereo Left
	Audio_SR = 9,		//Stereo Right
	Audio_SPDIFL = 10,	//spdif Left
	Audio_SPDIFR = 11	//spdif Right
};

enum AudioOutputChannels_type {			        //format: Rear/Surround/Front
	Audio_Out_Ch_C = 0x01,            //   00 0001      (0/0/1)
	Audio_Out_Ch_LR = 0x02,           //   00 0010      (0/0/2)
	Audio_Out_Ch_LCR = 0x03,          //   00 0011      (0/0/3)
	Audio_Out_Ch_LRS = 0x12,          //   01 0010      (0/1/2)
	Audio_Out_Ch_LCRS = 0x13,         //   01 0011      (0/1/3)
	Audio_Out_Ch_LRLsRs = 0x22,       //   10 0010      (0/2/2)
	Audio_Out_Ch_LCRLsRs = 0x23,      //   10 0011      (0/2/3)
	Audio_Out_Ch_LCRLsRsSs = 0x63,    // 1 10 0011      (1/2/3)
	Audio_Out_Ch_LRLsRsLssRss = 0xA2, //10 10 0010      (2/2/2) 
	Audio_Out_Ch_LCRLsRsLssRss = 0xA3 //10 10 0011      (2/2/3)
};

enum AacOutputChannels_type {
	Aac_C = 0x01,
	Aac_LR = 0x02,
	Aac_LCR = 0x03,
	Aac_LRS = 0x12,
	Aac_LCRS = 0x13,
	Aac_LRLsRs = 0x22,
	Aac_LCRLsRs = 0x23
};

enum AudioOutputSurround20_type {
	SurroundAsStream = 0,	/* surround enabled or disabled as in stream */
	SurroundEnable = 5,
	SurroundDisable = 4
};

/** customized downmixing tables, e.g, ARIB. */
enum AudioEngine_dmx_tables_type {
	/** In Enum default */
	AudioEngine_dmx_tables_dual_2_C_LCR_LCRS_LCRLsRs_left = 0,
	/** In Enum default */
	AudioEngine_dmx_tables_dual_2_C_LCR_LCRS_LCRLsRs_right = 1,
	/** In Enum default */
	AudioEngine_dmx_tables_dual_2_C_LCR_LCRS_LCRLsRs_mix = 2,
	/** In Enum default */
	AudioEngine_dmx_tables_dual_2_LR_LRS_LRLsRs_LCR_LCRS_LCRLsRs_stereo = 3,
	/** In Enum default */
	AudioEngine_dmx_tables_dual_2_LR_LRS_LRLsRs_left = 4,
	/** In Enum default */
	AudioEngine_dmx_tables_dual_2_LR_LRS_LRLsRs_right = 5,
	/** In Enum default */
	AudioEngine_dmx_tables_dual_2_LR_LRS_LRLsRs_mix = 6,
	/** In Enum default */
	AudioEngine_dmx_tables_C_2_C_LCR_LCRS_LCRLsRs = 7,
	/** In Enum default */
	AudioEngine_dmx_tables_C_2_C_LR_LRS_LRLsRs = 8,
	/** In Enum default */
	AudioEngine_dmx_tables_LR_2_C = 9,
	/** In Enum default */
	AudioEngine_dmx_tables_LR_2_LR_LRS_LRLsRs_LCR_LCRS_LCRLsRs = 10,
	/** In Enum default */
	AudioEngine_dmx_tables_LCR_2_C = 11,
	/** In Enum default */
	AudioEngine_dmx_tables_LCR_2_LtRt = 12,
	/** In Enum default */
	AudioEngine_dmx_tables_LCR_2_LoRo_LRS_LRLsRs = 13,
	/** In Enum default */
	AudioEngine_dmx_tables_LCR_2_LCR_LCRS_LCRLsRs = 14,
	/** In Enum default */
	AudioEngine_dmx_tables_LRS_2_C = 15,
	/** In Enum default */
	AudioEngine_dmx_tables_LRS_2_LoRo_LCR = 16,
	/** In Enum default */
	AudioEngine_dmx_tables_LRS_2_LtRt = 17,
	/** In Enum default */
	AudioEngine_dmx_tables_LRS_2_LRS_LCRS = 18,
	/** In Enum default */
	AudioEngine_dmx_tables_LRS_2_LRLsRs_LCRLsRs = 19,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRS_2_C = 20,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRS_2_LtRt = 21,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRS_2_LoRo = 22,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRS_2_LRS = 23,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRS_2_LRLsRs = 24,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRS_2_LCR = 25,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRS_2_LCRS = 26,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRS_2_LCRLsRs = 27,
	/** In Enum default */
	AudioEngine_dmx_tables_LRLsRs_2_C = 28,
	/** In Enum default */
	AudioEngine_dmx_tables_LRLsRs_2_LoRo_LCR = 29,
	/** In Enum default */
	AudioEngine_dmx_tables_LRLsRs_2_LtRt = 30,
	/** In Enum default */
	AudioEngine_dmx_tables_LRLsRs_2_LRS_LCRS = 31,
	/** In Enum default */
	AudioEngine_dmx_tables_LRLsRs_2_LRLsRs_LCRLsRs = 32,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLsRs_2_C = 33,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLsRs_2_LtRt = 34,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLsRs_2_LoRo = 35,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLsRs_2_LRS = 36,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLsRs_2_LRLsRs = 37,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLsRs_2_LCR = 38,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLsRs_2_LCRS = 39,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLsRs_2_LCRLsRs = 40,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLsRsLssRss_2_LoRo = 41,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLsRsLssRss_2_LtRt = 42,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLsRsLssRss_2_LCR = 43,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLsRsLssRss_2_LRLsRs = 44,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLsRsLssRss_2_LRLsRsLssRss = 45,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLsRsLssRss_2_LCRLsRs = 46,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLsRsLssRss_2_LCRLSRsLssRss = 47,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLssRss_2_LoRo = 48,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLssRss_2_LtRt = 49,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLssRss_2_LCR = 50,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLssRss_2_LRLsRs = 51,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLssRss_2_LRLsRsLssRss = 52,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLssRss_2_LCRLsRs = 53,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLssRss_2_LCRLsRsLssRss = 54,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLsRsLssRss_2_LCRLsRsCs = 55,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLssRss_2_LCRLsRsCs = 56,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLsRsCs_2_LoRo = 57,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLsRsCs_2_LtRt = 58,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLsRsCs_2_LCR = 59,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLsRsCs_2_LRLsRs = 60,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLsRsCs_2_LRLsRsLssRss = 61,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLsRsCs_2_LCRLsRs = 62,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLsRsCs_2_LCRLsRsLssRss = 63,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRLsRsCs_2_LCRLsRsCs = 64,
	/** In Enum default */
	AudioEngine_dmx_tables_LRLsRsLssRss_2_LoRo = 65,
	/** In Enum default */
	AudioEngine_dmx_tables_LRLsRsLssRss_2_LtRt = 66,
	/** In Enum default */
	AudioEngine_dmx_tables_LRLsRsLssRss_2_LRLsRs = 67,
	/** In Enum default */
	AudioEngine_dmx_tables_LRLsRsLssRss_2_LCRLsRsLssRss = 68,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRCs_2_LtRt = 69,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRCs_2_LoRo = 70,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRCs_2_LCRLsRsCs = 71,
	/** In Enum default */
	AudioEngine_dmx_tables_LCRCs_2_LCRLsRsLssRss = 72,
	/** In Enum default */
	AudioEngine_dmx_tables_LRLssRss_2_LtRt = 73,
	/** In Enum default */
	AudioEngine_dmx_tables_LRLssRss_2_LoRo = 74,
	/** In Enum default */
	AudioEngine_dmx_tables_LRLssRss_2_LCRLsRsLssRss = 75,
	/** In Enum default */
	AudioEngine_dmx_tables_LRLsRsCs_2_LtRt = 76,
	/** In Enum default */
	AudioEngine_dmx_tables_LRLsRsCs_2_LoRo = 77,
	/** In Enum default */
	AudioEngine_dmx_tables_LRLsRsCs_2_LCRLsRsCs = 78,
	/** In Enum default */
	AudioEngine_dmx_tables_LRLsRsCs_2_LCRLSRsLssRss = 79,
};

enum AudioChannelMask_type {
	Audio_Mask_Disable_All = 0,
	Audio_Mask_L = (1<<0),
	Audio_Mask_C = (1<<2),
	Audio_Mask_R = (1<<1),
	Audio_Mask_Ls = (1<<4),
	Audio_Mask_Rs = (1<<5),
	Audio_Mask_Lfe = (1<<3),
	Audio_Mask_Lb = (1<<6),
	Audio_Mask_Rb = (1<<7)
};

enum Ac3OutputChannels_type {
	Ac3_C = 0x01,
	Ac3_LR = 0x02,
	Ac3_LCR = 0x03,
	Ac3_LRS = 0x12,
	Ac3_LCRS = 0x13,
	Ac3_LRLsRs = 0x22,
	Ac3_LCRLsRs = 0x23
};

enum Ac3CompMode_type {
	CompMode_analog,
	CompMode_digital,
	CompMode_line_out,
	CompMode_RF
};

enum DtsOutputChannels_type {
	Dts_C = 0x01,
	Dts_LR = 0x02,
	Dts_LCR = 0x03,
	Dts_LRS = 0x12,
	Dts_LCRS = 0x13,
	Dts_LRLsRs = 0x22,
	Dts_LCRLsRs = 0x23
};

/* Fl = front left, Fr = front right, Fc = front center,
   Bl = back left,  Br = back right,  Bc = back center,
   Flc = front left of center, Frc = front right of center,
   Sl = side left, Sr = side right
   Lf = low frequency or subwoofer
 */
enum WmaproOutputChannels_type {
	Wmapro_1 = 0x10,	/* Wmapro_Fc */

	Wmapro_2 = 0x20,	/* Wmapro_FlFr */

	Wmapro_3 = 0x30,	/* Wmapro_FlFrFc */

	Wmapro_4 = 0x40,	/* Wmapro_FlFrFcBc */
	Wmapro_41 = 0x41,	/* Wmapro_FlFrBlBr */

	Wmapro_5 = 0x50,	/* Wmapro_FlFrFcSlSr */
	Wmapro_51 = 0x51,	/* Wmapro_FlFrFcBlBr */

	Wmapro_6 = 0x60,	/* Wmapro_FlFrFcLfSlSr */
	Wmapro_61 = 0x61,	/* Wmapro_FlFrFcLfBlBr */
	Wmapro_62 = 0x62,	/* Wmapro_FlFrFcBcSlSr */
	Wmapro_63 = 0x63,	/* Wmapro_FlFrFcBcBlBr */

	Wmapro_7 = 0x70,	/* Wmapro_FlFrFcLfBcSlSr */
	Wmapro_71 = 0x71,	/* Wmapro_FlFrFcLfBlBrBc */
	Wmapro_72 = 0x72,	/* Wmapro_FlFrFcBlBrSlSr */
	Wmapro_73 = 0x73,	/* Wmapro_FlFrFcBlBrFlcFrc */

	Wmapro_8 = 0x80,	/* Wmapro_FlFrFcLfBlBrSlSr */
	Wmapro_81 = 0x81	/* Wmapro_FlFrFcLfBlBrFlcFrc */
};
enum WmaproDynamicRangeControl_type {
	Drc_high,
	Drc_med,
	Drc_low,
};

enum PcmByteOrder {
	PCM_ORDER_MSBFIRST,
	PCM_ORDER_LSBFIRST,
};

enum LpcmVobChannelAssign_type {
	// according to C.1-2 table
	// number of chanels and channel assign are specified
	LpcmVob1_C = 0,        // 0x00

	LpcmVob2_LR,           // 0x01

	LpcmVob3_LfRfS,        // 0x02
	LpcmVob4_LfRfLsRs,     // 0x03
	LpcmVob3_LfRfLfe,      // 0x04
	LpcmVob4_LfRfLfeS,     // 0x05
	LpcmVob5_LfRfLfeLsRs,  // 0x06
	LpcmVob3_LfRfC,        // 0x07
	LpcmVob4_LfRfCS,       // 0x08
	LpcmVob5_LfRfCLsRs,    // 0x09
	LpcmVob4_LfRfCLfe,     // 0x0a
	LpcmVob5_LfRfCLfeS,    // 0x0b
	LpcmVob6_LfRfCLfeLsRs, // 0x0c

	LpcmVob5_LRLfRfS,      // 0x0d
	LpcmVob6_LRLfRfLsRs,   // 0x0e
	LpcmVob5_LRLfRfLfe,    // 0x0f
	LpcmVob6_LRLfRfLfeS,   // 0x10
	LpcmVob7_LRLfRfLfeLsRs,// 0x11

	LpcmVob5_LRLfRfC,      // 0x12
	LpcmVob6_LRLfRfCS,     // 0x13
	LpcmVob7_LRLfRfCLsRs,  // 0x14
	LpcmVob6_LRLfRfCLfe,   // 0x15
	LpcmVob7_LRLfRfCLfeS,  // 0x16
	LpcmVob8_LRLfRfCLfeLsRs,// 0x17
        LpcmVobVR_DualMono,    //0x18
};

enum LpcmAobChannelAssign_type {
	// according to C.1-1 table
	// 1st digit after LpcmAob represents nchannels GR1, 2nd digit = nchannels GR2
	LpcmAob10_C = 0,        // 0x00

	LpcmAob20_LR,           // 0x01
	LpcmAob21_LfRfS,        // 0x02
	LpcmAob22_LfRfLsRs,     // 0x03
	LpcmAob21_LfRfLfe,      // 0x04
	LpcmAob22_LfRfLfeS,     // 0x05
	LpcmAob23_LfRfLfeLsRs,  // 0x06
	LpcmAob21_LfRfC,        // 0x07
	LpcmAob22_LfRfCS,       // 0x08
	LpcmAob23_LfRfCLsRs,    // 0x09
	LpcmAob22_LfRfCLfe,     // 0x0a
	LpcmAob23_LfRfCLfeS,    // 0x0b
	LpcmAob24_LfRfCLfeLsRs, // 0x0c

	LpcmAob31_LfRfCS,       // 0x0d
	LpcmAob32_LfRfCLsRs,    // 0x0e
	LpcmAob31_LfRfCLfe,     // 0x0f
	LpcmAob32_LfRfCLfeS,    // 0x10
	LpcmAob33_LfRfCLfeLsRs, // 0x11

	LpcmAob41_LfRfLsRsLfe,  // 0x12
	LpcmAob41_LfRfLsRsC,    // 0x13
	LpcmAob42_LfRfLsRsCLfe, // 0x14
};

enum PcmCdaChannelAssign_type {
	// according to C.1-1 table
	// 1st digit after PcmCda represents nchannels
	PcmCda1_C = 0,        // 0x00

	PcmCda2_LR,           // 0x01
	PcmCda3_LfRfS,        // 0x02
	PcmCda4_LfRfLsRs,     // 0x03
	PcmCda3_LfRfLfe,      // 0x04
	PcmCda4_LfRfLfeS,     // 0x05
	PcmCda5_LfRfLfeLsRs,  // 0x06
	PcmCda3_LfRfC,        // 0x07
	PcmCda4_LfRfCS,       // 0x08
	PcmCda5_LfRfCLsRs,    // 0x09
	PcmCda4_LfRfCLfe,     // 0x0a
	PcmCda5_LfRfCLfeS,    // 0x0b
	PcmCda6_LfRfCLfeLsRs, // 0x0c

	PcmCda5_LfRfLsRsLfe = 0x12,// 0x12
	PcmCda5_LfRfLsRsC,    // 0x13
	PcmCda6_LfRfLsRsCLfe, // 0x14
};

/** Disable SPDIF or selects between uncompressed and compressed.@note @li Some formats such as MPEG and AAC can only play uncompressed. */
enum OutputSpdif_type {
	/** SPDIF output is disabled. Stream is decoded - when decoder available - and sent to I2S. */
	OutputSpdif_Disable = 0,
	/** SPDIF output is compressed whenever possible (AC3, DTS...). MPEG or AAC will not be sent compressed over SPDIF. Stream is decoded - when decoder available - and sent to I2S. */
	OutputSpdif_Compressed = 1,
	/** SPDIF output consists in 2 channels PCM. Stream is decoded - when decoder available - and sent to I2S. @note @li Use codec dependent settings for additional options such as surround */
	OutputSpdif_Uncompressed = 3,
	/** SPDIF output is compressed whenever possible (AC3, DTS...), audio not decoded at all (I2S is blank). */
	OutputSpdif_NoDecodeCompressed = 5
};

/*
  Note: Please verify it with audio.global.h in /ucode_lib/ucode/audio/commmo_new
 */
enum AudioChannelAssignment_type {
	Audio_Ch_ASSI_DUAL = 0,		//DUAL    (LR,1+1)
	Audio_Ch_ASSI_C,			//MODE10  (C,1/0)
	Audio_Ch_ASSI_LR,			//MODE20  (L, R, 2/0) 
	Audio_Ch_ASSI_LCR,			//MODE30  (L, C, R, 3/0)
	Audio_Ch_ASSI_LRS,			//MODE21  (L, R, S, 2/1)
	Audio_Ch_ASSI_LCRS,			//MODE31  (L, C, R, S, 3/1)
	Audio_Ch_ASSI_LRLsRs,		//MODE22  (L, R, Ls, Rs, 2/2)
	Audio_Ch_ASSI_LCRLsRs,		//MODE32  (L, C, R, Ls, Rs, 3/2)
	Audio_Ch_ASSI_LCRLsRsLssRss,//MODE322 (L, C, R, Ls, Rs, Lss, Rss, 3/2/2)
	Audio_Ch_ASSI_LCRLssRss,	//MODE302 (L, C, R, Lss, Rss, 3/0/2)	
	Audio_Ch_ASSI_LCRLsRsSs,	//MODE321 (L, C, R, Ls, Rs, Ss, 3/2/1)
	Audio_Ch_ASSI_LRLsRsLssRss,	//MODE222 (L, R, Ls, Rs, Lss, Rss, 2/2/2)
	AUDIO_Ch_ASSI_LCRCs,		//MODE301 (L, C, R, Cs)
	AUDIO_Ch_ASSI_LRLssRss,		//MODE202 (L, R, Lss, Rss)
	AUDIO_Ch_ASSI_LRLsRsCs,		//MODE221 (L, R, Ls, Rs, Cs)
	Audio_Ch_ASSI_NOT_SUPPORTED	//(Not supported)
};

// Reporting audio decoding status.
struct AudioDecoderInfo {
	RMuint32 CodecID;			// Decoder ID
	RMuint32 SampleRate;		// Audio source sample rate
	RMuint32 ChannelNumber;		// Channle Number
	RMuint32 SampleCount;		// decoded sample count
	RMuint32 ByteCount;			// Consumed byte count
	RMuint32 ErrorCount;		// Number of error happened.
	RMuint32 BassMode;
	RMuint32 SpeakerConfig;	
	RMuint32 lfe;
	RMuint32 DualMode;
	RMuint32 SpdifMode;
	enum AudioChannelAssignment_type ChannelAssignment; // enum AudioChannelAssignment_type
	RMuint32 SkippedFrameCount;
};

struct auxiliary_data_type1 {
	RMuint32 data[4];
};

/* struct EMhwlibCopyControlWithVersion is used for RMGenericPropertyID_CopyControl property that replaces
  RMGenericPropertyID_MacrovisionLevel and RMGenericPropertyID_CGMSA.
  RMGenericPropertyID_MacrovisionLevel sets agc_level and the aps of line20, line21_xds with the same value.
  New requirements ask for different levels for agc and aps for line 20, 21_xds.
  Also macrovision changed the coefficient table for AACS -> need for agc_version.
*/
enum EMhwlibAGCVersion {
	EMhwlibAGCVersion_ConstantBPP = 0,
	EMhwlibAGCVersion_AlternateBPP,
};

/* The EMhwlibCopyControlVersion is added for eventual changes in the future. */
enum EMhwlibCopyControlVersion {
	EMhwlibCopyControlVersion_0 = 0, /* It matches the current EMhwlibCopyControl structure */
};

struct EMhwlibCopyControl {
	/* start for EMhwlibCopyControlVersion_0 */
	enum EMhwlibAGCVersion agc_version;
	RMuint32 agc_level;          /* macrovision pulses 0, 1, 2, 3. Usually is same value as aps. */

	RMuint32 cgmsa;              /* copy generation management system 0, 1, 2, 3. Sent on line 20 and
					in "Copy and Redistribution Control Packet" on line21_xds. */
	RMuint32 aps_level;          /* analog protection system 0, 1, 2, 3. Sent on line 20 and
					in "Copy and Redistribution Control Packet" on line21_xds. */
	RMuint32 rcd;                /* redistribution control descriptor. Sent on line 20 and
					in "Copy and Redistribution Control Packet" on line21_xds. */
	RMuint32 asb;                /* analog source bit. Sent on line 20 and
					in "Copy and Redistribution Control Packet" on line21_xds. */
	/* end for EMhwlibCopyControlVersion_0 */
};

struct EMhwlibCopyControlWithVersion {
	enum EMhwlibCopyControlVersion cci_version;
	struct EMhwlibCopyControl cci;
};

struct SurfaceAspectRatio_type {
	/** picture aspect ratio (default), pixel aspect ratio or display aspect ratio */
	enum EMhwlibAspectRatioType type;
	/** pixel or display aspect ratio of the surface, value ignored when picture aspect ratio is selected as type */
	struct EMhwlibAspectRatio ar;
};

#define NO_TIMER 0xFFFFFFFF
enum Master_type {
	Master_STC = 0,
	Master_Audio
};	

enum StcFilter_type {
	NoFilter = 0,
	/*Filter1,*/
};	

enum CorrectionMethod_type {
	NoCorrection = 0,
	CleanDividerAdjust, 
	VCXOAdjust, 
	/*InternalAutoAdjust,*/ 
};

struct Speed_type {
	RMint32 enumerator;
	RMuint32 denominator;
};

typedef struct {
	RMuint32 Address;
	RMuint32 Size;
} MMBlockArray[256];

enum EMhwlibClosedCaptionType {
	EMhwlibClosedCaptionType_None = 1,
	EMhwlibClosedCaptionType_ATSC,
	EMhwlibClosedCaptionType_DVD,
	EMhwlibClosedCaptionType_SCTE,
	EMhwlibClosedCaptionType_29,
};

struct user_data_context {
#ifndef NO_USER_DATA_REORDERING
#else
	RMuint32 anchor_cc_data[32];
	RMuint32 anchor_cc_pts_hi[32];
	RMuint32 anchor_cc_pts_lo[32];
	RMuint32 anchor_cc_count;
#endif
	enum EMhwlibClosedCaptionType cc_type;
	RMbool afd_done;  // set to TRUE by user data parser, set to FALSE by VideoDecoder
	enum EMhwlibActiveFormat afd;  // active format description, extracted from user data
	RMbool afd_valid;
};

enum DiscontinuityType {
	PcrDiscontinuity = 0,
	/*VideoPtsDiscontinuity,
	AudioPtsDiscontinuity*/
};

enum EMhwlibDataType_type {
	EMhwlibData_TS,            /*  0 - store transport stream as it is */
	EMhwlibData_PSI,           /*  1 - section filtering according 13818-1, 2.4.4. */
	EMhwlibData_TSpayload,     /*  2 - reserved */
	EMhwlibData_VPES,          /*  3 - store video PES packets. Video can have PES_lenght=0 in transport files. */
	EMhwlibData_APES,          /*  4 - store PES packets with PES_lenght not 0.  */
	EMhwlibData_PCR,           /*  5 - used in case of PCR extracted by firmware from PidBank filter.
	                                   The pid must be different than the video pid.
					   The output fifo size can be 0. */
	EMhwlibData_Reserved0,     /*  6 - reserved */
	EMhwlibData_Vpayload_pts,  /*  7 - store payload in output bitstream fifo and PTS in output pts fifo.
					   If pts fifo has size 0, the pts-es are not stored. */
	EMhwlibData_ASpayload_pts, /*  8 - store payload in output bitstream fifo and PTS in output pts fifo.
					   If pts fifo has size 0, the pts-es are not stored. */
	EMhwlibData_RDI,           /*  9 - RDI is used for CPRM PES packets */
	EMhwlibData_Private,       /* 10 - reserved */
	EMhwlibData_DSM_CC,        /* 11 - section filtering according 13818-6, 9.2.3. The only difference
					   between PSI ans DSMCC is that the section_syntax_indicator and
					   the private_indicator should be complement. */
	EMhwlibData_DMB_OD,        /* 12 - reserved */
	EMhwlibData_DMB_BIFS       /* 13 - reserved */
};

enum EMhwlibPidInput_type {
	EMhwlibPid_Ts = 0, /* The TS packets with transport_scrambling_control not null are NOT sent
                              to the outputs if the cipher and the key are not enabled. */
	EMhwlibPid_Ts1     /* the TS packets with transport_scrambling_control not null are sent
                              to the outputs even there is no valid cipher and key. */
};

enum EMhwlibPesInput_type {
	EMhwlibPes_packet = 0, /* The PES packets with scrambling_control not null are NOT sent
                              to the outputs if the cipher and the key are not enabled. */
	EMhwlibPes_packet1     /* the PES packets with scrambling_control not null are sent
                              to the outputs even there is no valid cipher and key. */
};

#define EMHWLIB_OUTPUT_SAMPLES_PROTECTED   1
#define EMHWLIB_PICTURE_PROTECTED          1
#define EMHWLIB_BITSTREAM_PROTECTED        2
#define EMHWLIB_USE_ERASER_FIFO            4

#define EMHWLIB_SPLICING_ENABLE                    1 /* not implemented */
#define EMHWLIB_IGNORE_CONTINUITY_COUNTER_ERROR    2 /* if set the packets with CC error are saved in the output buffers */
#define EMHWLIB_IGNORE_ERROR_INDICATOR             4 /* if set the packets with error are saved in the output buffers */

struct EMhwlibPidEntry_type {
	RMuint16                  pid;        /* 13 bit value */
	enum EMhwlibPidInput_type input_type;
	RMuint32                  flags;      /* reserved bit field for ignore_error_indicator, ignore_continuity_counter, splicing_enable */
};

struct EMhwlibFixedPidEntry_type { /* PAT, CAT, MGT */
	enum EMhwlibPidInput_type input_type;
	RMuint32                  flags;      /* reserved bit field for ignore_error_indicator, ignore_continuity_counter, splicing_enable */
};

struct EMhwlibPCRPidEntry_type {
	RMuint16                  pid;        /* 13 bit value */
	RMuint32                  clock_recovery_id; /* 0 or 1. Selects the hardware clock recovery that extracts the PCR. There are only two blocks for EM8634. */
};

struct EMhwlibPCRPidEntryInfo_type {
	RMuint16                  pid;        /* 13 bit value */
	RMuint32                  clock_recovery_id; /* 0 or 1. Selects the hardware clock recovery that extracts the PCR. There are only two blocks for EM8634. */
	RMbool                    enable;         /* if FALSE the pid entry is ignored */
};

struct EMhwlibPidEntryInfo_type {
	RMuint16                  pid;            /* 13 bit value */
	enum EMhwlibPidInput_type input_type;
	RMuint32                  flags;          /* reserved bit field for ignore_error_indicator, ignore_continuity_counter, splicing_enable */
	RMbool                    enable;         /* if FALSE the pid entry is ignored */
	RMuint32                  output_mask[1]; /* 32 bit mask indicating the output buffers for this pid.*/
	RMuint32                  cipher_mask;    /* indicates what cipher is enabled - bit mask. Only one cipher supported in current implementation. */
	RMuint32                  cipher_index[1];/* indicates what cipher entries from CipherTable is used */
	RMuint32                  channel_id;     /* indicates the stream channel used for filtering */
};

struct EMhwlibPesEntry_type {
	RMuint8                   stream_id;
	RMuint8                   substream_id;
	enum EMhwlibPesInput_type input_type;
	RMbool                    enable;         /* if FALSE the pes entry is ignored */
	RMuint32                  output_mask[1]; /* 32 bit mask indicating the output buffers for this pid.*/
	RMuint32                  cipher_mask;    /* indicates what cipher is enabled - bit mask. Only on cipher supported. */
	RMuint32                  cipher_index[1];/* indicates what cipher is used */
};

struct EMhwlibEntryOutputMask_type {
	RMuint32                  entry_index;
	RMuint32                  output_mask[1]; /* 32 bit mask indicating the output buffers for this pid/pes entry.*/
};

struct EMhwlibOutputMask_type {
	RMuint32	output_mask[1]; /* 32 bit mask indicating the output buffers for this
					   pid/pes entry */
};

enum EMhwlibTimerSync {	/* to replace DemuxProgram_TimerSync_type */
	EMhwlibTimerSync_None,
	
	EMhwlibTimerSync_FirstPcrSetPlayStc,/* First Pcr or Pts encountered after a stop/play sequence is set in stc,video,audio timers associated with the demux program. The timers are activated. */
	EMhwlibTimerSync_PcrUpdateStc,
	EMhwlibTimerSync_FirstPcrSetStc,/* First Pcr or Pts encountered after a stop/play sequence is set in stc,video,audio timers associated with the demux program. */
};

enum EMhwlibTransportPriority_type {
	EMhwlibTransportPriority_Disable = 0, /* default, all the TS packets from pid are parsed by demux */
	EMhwlibTransportPriority_0 = 2,    /* only TS packets with transport priority bit 0 are parsed by demux */
	EMhwlibTransportPriority_1,        /* only TS packets with transport priority bit 1 are parsed by demux */
};

enum EMhwlibDESCipherMode{
	EMhwlibDES_ECB_encryption,
	EMhwlibDES_CBC_encryption,
	EMhwlibDES_OFB_encryption,
	EMhwlibDES_ECB_decryption,
	EMhwlibDES_CBC_decryption,
	EMhwlibDES_OFB_decryption
};

enum EMhwlibDESEncryptedPacketFormat {
	EMhwlibDES_Reserved
};

enum EMhwlibAESCipherMode{
	EMhwlibAES_ECB_decryption,
	EMhwlibAES_ECB_encryption,
	EMhwlibAES_OFB_decryption_encryption,
	EMhwlibAES_CTR_decryption_encryption,
	EMhwlibAES_CBC_decryption,
	EMhwlibAES_CBC_encryption,
	EMhwlibAES_CFB_decryption,
	EMhwlibAES_CFB_encryption,
	EMhwlibAES_AACS_hash_generation,
	EMhwlibAES_VCPS_hash_generation,
	EMhwlibAES_NDS_proprietary
};

enum EMhwlibAESEncryptedPacketFormat {
	EMhwlibAES_UDAC, /* 0 - encryption starting from start of TS payload */
	EMhwlibAES_Synamedia, /* 1 - encryption starting from end of TS payload */
	EMhwlibAES_OFB,
	EMhwlibAES_NSA,
	EMhwlibAES_CipherModes_11 = EMhwlibAES_NSA,
};

enum EMhwlibMulti2CipherMode{
	EMhwlibMulti2_ECB_decryption,
	EMhwlibMulti2_CBC_decryption,
	EMhwlibMulti2_OFB_decryption,
	EMhwlibMulti2_CFB_decryption,
	EMhwlibMulti2_ECB_encryption,
	EMhwlibMulti2_CBC_encryption,
	EMhwlibMulti2_OFB_encryption,
	EMhwlibMulti2_CFB_encryption
};

enum EMhwlibC2CipherMode{
	EMhwlibC2_ECB_decryption,
	EMhwlibC2_CBC_decryption,
	EMhwlibC2_ECB_encryption,
	EMhwlibC2_CBC_encryption
};

enum EMhwlibCipher {
	EMhwlibCipher_DES,    /* 0 */
	EMhwlibCipher_AES,    /* 1 */
	EMhwlibCipher_RC4,    /* 2 */
	EMhwlibCipher_DVD,    /* 3 */
	EMhwlibCipher_Multi2, /* 4 */
	EMhwlibCipher_DVBCSA, /* 5 */
	EMhwlibCipher_C2      /* 6 */
};


enum EMhwlibScramblingBits{
	EMhwlibScramblingBits_None,      /* key is not applied */
	EMhwlibScramblingBits_10_11,     /* mid cipher key is applied when packets have scrambling bits == 10, 11 */
	EMhwlibScramblingBits_10,        /* mid cipher key is applied when packets have scrambling bits == 10 */
	EMhwlibScramblingBits_11,        /* mid cipher key is applied when packets have scrambling bits == 11 */
	EMhwlibScramblingBits_PreCipher, /* pre cipher key is applied for all the incoming data */
};

enum EMhwlibInbandOffset{
	EMhwlibInbandOffset_Ignore,	/* emhwlib byte counter is used as bytecounter for inband */
	EMhwlibInbandOffset_Relative,	/* the offset is added to emhwlib byte counter and used as bytecounter for inband */
	EMhwlibInbandOffset_Absolute	/* the offset is used as bytecounter for inband */
};

/* Video codec profiles */

/*
  Jpeg profile are defined as EMhwlibJPEGProfile_XYZW
  where X, Y, Z, W are:
  X: luma horizontal sampling factor
  Y: luma vertical sampling factor
  Z: chroma horizontal sampling factor
  W: chroma vertical sampling factor
*/

enum EMhwlibJPEGProfile{
	/* 
	   the value of the labels is explicited here because
	   the sample apps (play_video) ask the user to input
	   the profile directly by its value
	*/
	EMhwlibJPEGProfile_Unknown = 0,      /* This is what application passes when it does not know the profile */
	EMhwlibJPEGProfile_2222 = 2222,      /*444*/
	EMhwlibJPEGProfile_2212 = 2212,      /*422*/
	EMhwlibJPEGProfile_2211 = 2211,      /*420*/
	EMhwlibJPEGProfile_2111 = 2111,      /*ucode's 422h*/
	EMhwlibJPEGProfile_2221 = 2221,      /*ucode's 422rot*/
	EMhwlibJPEGProfile_1211 = 1211,      /*ucode's 422hrot*/
};

#define EMhwlib_H264_BaselineProfile   0
#define EMhwlib_H264_MainProfile       1
#define EMhwlib_H264_ExtendedProfile   2
#define EMhwlib_H264_MaxProfile       EMhwlib_H264_ExtendedProfile


/* DEPRECATED LABELS, USE THE ONES IN enum EMhwlibJPEGProfile */
#define EMhwlib_JPEG_Invalid_Profile  0xff
#define EMhwlib_JPEG_420_Profile      EMhwlibJPEGProfile_2211
#define EMhwlib_JPEG_422_Profile      EMhwlibJPEGProfile_2221
#define EMhwlib_JPEG_444_Profile      EMhwlibJPEGProfile_2222
#define EMhwlib_JPEG_Max_Profile      EMhwlibJPEGProfile_2221

#define EMhwlib_JPEG_is_422(x)  ( (x)== EMhwlibJPEGProfile_2212    \
				       || (x)==EMhwlibJPEGProfile_2111  \
				       || (x)==EMhwlibJPEGProfile_2221  \
				       || (x)==EMhwlibJPEGProfile_1211 )


/* Video codec levels */
#define EMhwlib_H264_Level_1   0  /*   qcif */
#define EMhwlib_H264_Level_11  1  /*    cif */
#define EMhwlib_H264_Level_12  2  /*    cif */
#define EMhwlib_H264_Level_13  3  /*    cif */
#define EMhwlib_H264_Level_2   4  /*    cif */
#define EMhwlib_H264_Level_21  5  /* halfD1 */
#define EMhwlib_H264_Level_22  6  /*     D1 */
#define EMhwlib_H264_Level_3   7  /*     D1 */
#define EMhwlib_H264_Level_31  8  /*   720p */
#define EMhwlib_H264_Level_32  9  /*   ???? */
#define EMhwlib_H264_Level_4  10  /*   1080 */
#define EMhwlib_H264_Level_41 11  /*   1080 */
#define EMhwlib_H264_Level_42 12  /*   1080 */
#define EMhwlib_H264_Level_5  13  /*   ???? */
#define EMhwlib_H264_Level_51 14  /*   ???? */
#define EMhwlib_H264_MaxLevel EMhwlib_H264_Level_51

enum EMhwlibVideoCodec{
	EMhwlibVideoCodec_MPEG2 = 1,
	EMhwlibVideoCodec_MPEG4,
	EMhwlibVideoCodec_MPEG4_Padding,
	EMhwlibVideoCodec_DIVX3,
	EMhwlibVideoCodec_VC1,
	EMhwlibVideoCodec_WMV,
	EMhwlibVideoCodec_H264,
	EMhwlibJPEGCodec,
	EMhwlibDVDSpuCodec,
	EMhwlibBDRLECodec,
};

struct ConnectToDemuxOutput_in_type {
	RMuint32 demux_output_module_id;
	RMuint32 demux_output_bts_fifo;
};
struct ConnectToDemuxOutput_out_type {
	RMuint32 decoder_stc_module_id;
	RMuint32 decoder_pts_fifo; /* pts_fifo is followed by inband fifo*/
};

struct VideoDecoder_NextPicture_type {
	struct EMhwlibNewPicture Picture;
	RMuint32 PictureAddress;
};


struct EMhwlibSurfaceReader {
	RMuint32 SurfaceAddress;
	RMuint32 ReaderID;
	/* 
	   This field is used temporarily to pass the picture address in 
	   AcquirePicture and ReleasePicture.
	   It is not passed on a cleaner way because it is not needed when
	   the multiple display consumers code is enabled, and we choose an
	   api that will be clean with that code.
	   The field will be removed soon.
	*/
	RMuint32 emhwlibReserved;
};


struct EMhwlibPictureInfo {
	struct EMhwlibNewPicture Picture;
	RMuint32 PictureAddress;
};


enum EMhwlibScanMode {
	EMhwlibScanMode_Source, 
	EMhwlibScanMode_Progressive,
	EMhwlibScanMode_Interlaced_TopFieldFirst,
	EMhwlibScanMode_Interlaced_BotFieldFirst,
};
	
struct EMhwlibDemuxErrorInfo {
	RMuint32 EngineError; /* error per engine */
	RMuint32 TaskError; /* error per task */

	RMuint32 InputDiscontinuityCounter; /* incremented when the demux detects errors in input Continuity counter */
	RMuint32 InputSyncLossCounter; /* incremented when the transport filter loose the 0x47 sync */

	RMuint32 OutputOverflowCounter; /* incremented in spi, when the demux cannot write data in one output */
	RMuint32 PTSOutputOverflowCounter; /* incremented in spi, when the demux cannot write data in PTS output fifo */
};

enum EMhwlibHeartBeatCountersVersion {
	EMhwlibHeartBeatCountersVersion_0 = 0,
};

struct EMhwlibHeartBeatCounters {
	RMuint32 MpegEngine0;  /* incremented by mpeg engine 0 */
	RMuint32 MpegEngine1;  /* incremented by mpeg engine 1. Set to 0 if mpeg engine 1 doesn't exit. */
	RMuint32 AudioEngine0; /* incremented by audio engine 0 */
	RMuint32 AudioEngine1; /* incremented by audio engine 1.  Set to 0 if audio engine 1 doesn't exit.*/
	RMuint32 DemuxEngine0; /* incremented by demux engine 0 */
	RMuint32 CPU0;         /* incremented by kernel module */
	RMuint32 XPU0;         /* incremented by xos */
	RMuint32 Host;         /* incremented by kernel module ? */
	RMuint32 VsyncOutport; /* incremented when any vsync interrupt updates the hw registers */
};
	
/* The TVStandard property was not generic when it was first created,
 * so old code might be using the module-specific property id's. 
 * This is here to keep old code compilable but new code should use
 * RMGenericPropertyID_TVStandard
 */
 
#define RMDispComponentOutPropertyID_TVStandard  RMGenericPropertyID_TVStandard
#define RMDispMainAnalogOutPropertyID_TVStandard RMGenericPropertyID_TVStandard
#define RMDispDigitalOutPropertyID_TVStandard    RMGenericPropertyID_TVStandard
#define RMDispCompositeOutPropertyID_TVStandard  RMGenericPropertyID_TVStandard

/* The TVFormat property was not generic when it was first created,
 * so old code might be using the module-specific property id's. 
 * This is here to keep old code compilable but new code should use
 * RMGenericPropertyID_AnalogTVFormat or RMGenericPropertyID_DigitalTVFormat
 */
 
#define RMDispComponentOutPropertyID_TVFormat  RMGenericPropertyID_AnalogTVFormat
#define RMDispMainAnalogOutPropertyID_TVFormat RMGenericPropertyID_AnalogTVFormat
#define RMDispDigitalOutPropertyID_TVFormat    RMGenericPropertyID_DigitalTVFormat
#define RMDispCompositeOutPropertyID_TVFormat  RMGenericPropertyID_AnalogTVFormat



/* this is for BDRLE decoding. The application can send command through user data fifo to control the 
 * decoding of graphics object.  Three types of commands are available.  The value of these commands
 * are currently decided by microcode, so do not change unless advised by microcode 
 */
#define SpuDecoder_BDRLE_GraphicObject_Start 0x00000100
#define SpuDecoder_BDRLE_GraphicObject_Chunk 0x00000101
#define SpuDecoder_BDRLE_GraphicObject_End   0x00000111

#define MAX_RDRLE_COMMANDS  64

struct SpuDecoder_BDRLECommandType {
	RMuint32 command;
	RMuint32 parameter1;
	RMuint32 parameter2;
};

struct SpuDecoder_BDRLECommands{
	RMuint32 command_count;  // identify how many valid commands are there in the "commands"
	struct SpuDecoder_BDRLECommandType commands[MAX_RDRLE_COMMANDS];
};


/* defines used for RMVideoDecoderPropertyID_InterlacedProgressiveAlgorithm.
 Keep them synchronized with SOURCE_TYPE_DERIVATION_.... from ucode/video/decoder/codec.h */

//#define SOURCE_TYPE_DERIVATION_USING_DECODER_SPEC                       0
#define INTERLACED_PROGRESSIVE_ALGORITHM_USING_DECODER_SPECIFICATION      0

//#define SOURCE_TYPE_DERIVATION_USING_MPEG2_PROGRESSIVE_SEQ              1
#define INTERLACED_PROGRESSIVE_ALGORITHM_USING_MPEG2_PROGRESSIVE_SEQ      1

//#define SOURCE_TYPE_DERIVATION_USING_MPEG2_FRAME_CNT_IN_SEQ             4
#define INTERLACED_PROGRESSIVE_ALGORITHM_USING_MPEG2_MENU_PROGRESSIVE     4

/* To be added when they will be implemented
//#define SOURCE_TYPE_DERIVATION_USING_H264_FRAME_MBS_ONLY_FLAG           2
#define INTERLACED_PROGRESSIVE_ALGORITHM_USING_H264_FRAME_MBS_ONLY_FLAG   2
//#define SOURCE_TYPE_DERIVATION_USING_H264_POC                           3
#define INTERLACED_PROGRESSIVE_ALGORITHM_USING_H264_POC                   3
*/

struct VoipCodec_Tone {
	RMint32 freq1;
	RMint32 freq2;
	RMint32 time_on;
	RMint32 time_off;
	RMint32 level;
	RMint32 ring;
};

enum VoipCodec_Buffer_mode {
	VOIP_BUFFER_MODE_FULLNESS = 0,
	VOIP_BUFFER_MODE_EMPTYNESS = 1
};

struct VoipCodec_Cid {
 	RMint8 month[3];
	RMint8 day[3];
	RMint8 hour[3];
	RMint8 min[3];
	RMint32 numlen;
	RMint8 number[11];
	RMint32 namelen;
	RMint8 name[80];
};

struct VoipChunk {
	RMuint32 size;
	RMuint8 data[512];
};

struct EMhwlibTimerAudioClockConfig {
	RMuint32 valid;            // TRUE if this structure has been filled
	RMuint32 dirty;            // TRUE if this structure has been updated by the emhwlib
	RMuint32 afs;              // TRUE: audio uCode is dermining fs from stream, FALSE: preferred fs is set by emhwlib
	RMuint32 mclk_factor;      // 128 or 256
	RMuint32 cd_freq;          // frequency of the clean divider input clock
	RMuint32 dmem_base;        // audio engine DMem Base
	RMuint32 outputmode_reg;   // gbus address of outputmode register in audio uCode
	RMuint32 freq_offs;        // bit position inside outputmode_reg of 4 bit frequency tag
	RMuint32 force_offs;       // bit position inside outputmode_reg of force flag
	RMuint32 chctrl;           // value for channel_control register from emhwlib (frac select bit [15] will be set by timer)
	RMuint32 cd_reg;           // clean divider register address
	RMuint32 fs;               // 4 bit fs value from audio uCode
};


#define VCXO_CLK_ID_DIGITAL   0
#define VCXO_CLK_ID_ANALOG    1
#define VCXO_CLK_ID_COMPONENT 2
#define VCXO_CLK_ID_AUDIO_0   3
#define VCXO_CLK_ID_AUDIO_1   4


#define EMHWLIB_DECODE_BW_MPEG2_HD  400*1024
#define EMHWLIB_DECODE_BW_MPEG4_HD  400*1024
#define EMHWLIB_DECODE_BW_MPEG2_SD   80*1024
#define EMHWLIB_DECODE_BW_MPEG4_SD   80*1024
#define EMHWLIB_DECODE_BW_DIVX3      80*1024
#define EMHWLIB_DECODE_BW_VC1_HD    880*1024
#define EMHWLIB_DECODE_BW_WMV_HD    880*1024
#define EMHWLIB_DECODE_BW_VC1_LHD   780*1024
#define EMHWLIB_DECODE_BW_WMV_LHD   780*1024
#define EMHWLIB_DECODE_BW_VC1_SD    150*1024
#define EMHWLIB_DECODE_BW_WMV_SD    150*1024
#define EMHWLIB_DECODE_BW_H264_HD   880*1024
#define EMHWLIB_DECODE_BW_H264_SD   400*1024
#define EMHWLIB_DECODE_BW_JPEG             0

#if 1
/* Demux modules cleanup.
   Structures generated in previous emhwlib_propertytypes.h are still used
   in current applications. Until we get rid of them we define these types here.*/

/* added for DCCHD backward compatibility */
struct DemuxProgram_TransportParameters_type {
	RMuint16 VideoPID;
	RMuint16 AudioPID;
	RMuint16 PCRPID;
};

struct DemuxProgram_ProgramParameters_type {
	RMuint8 VideoSID;
	RMuint8 AudioSID;
	RMuint8 AudioSSID;
	RMuint8 SubpictureSID;
	RMuint8 SubpictureSSID;
};

struct DemuxProgram_OutputControl_type {
	RMbool Video;
	RMbool Audio;
	RMbool Subpicture;
	RMbool VideoPts;
	RMbool AudioPts;
	RMbool SubpicturePts;
	enum DemuxTriggerType Trigger;
};

enum Demux_Command_type {
	Demux_Command_Play,
	Demux_Command_Pause,
	Demux_Command_Stop,
};

enum Demux_State_type {
	Demux_State_Playing,
	Demux_State_Paused,
	Demux_State_Stopped,
	Demux_State_PlayPending,
	Demux_State_PausePending,
	Demux_State_StopPending,
};

struct Demux_InputParameters_type {
	enum DemuxSpiType Spi;
	enum DemuxSourceType SourceType;
};
#endif /* end demux modules cleanup */

struct EMhwlibMemoryBlockDescriptor{
 	RMuint32 Address;
 	RMuint32 Size;
};

struct EMhwlibMemoryBlockList{
	RMuint32 BlockCount;
	struct EMhwlibMemoryBlockDescriptor Blocks[64];
};


typedef RMstatus (*emhwlib_ppf_get_engine_mem_func)(struct EMhwlibMemoryBlockList *requiredmemblocks);
typedef RMstatus (*emhwlib_ppf_set_engine_mem_func)(struct EMhwlibMemoryBlockList *allocatedmemblocks);
typedef RMstatus (*emhwlib_ppf_get_output_mem_func)(RMuint32 output_slot, struct EMhwlibMemoryBlockList *requiredmemblocks);
typedef RMstatus (*emhwlib_ppf_set_output_mem_func)(RMuint32 output_slot, struct EMhwlibMemoryBlockList *allocatedmemblocks);
typedef RMstatus (*emhwlib_ppf_get_output_func)(RMuint32 output_slot, RMuint32 *output_surface);
typedef RMstatus (*emhwlib_ppf_set_input_func)(RMuint32 input_slot, RMuint32 input_surface);
typedef RMstatus (*emhwlib_ppf_set_command_func)(void *command_param, RMuint32 param_size, void *command_result, RMuint32 result_size);
/* these are not part of the handler */
typedef RMuint32 (*emhwlib_ppf_run_filter_func)(void *pE, RMuint32 ModuleID, RMuint32 mask);
typedef RMstatus (*emhwlib_ppf_init_func)(void);
typedef RMstatus (*emhwlib_ppf_deinit_func)(void);

struct EMhwlibPPFHandle {
	emhwlib_ppf_get_engine_mem_func get_engine_mem;

	emhwlib_ppf_set_engine_mem_func set_engine_mem;

	emhwlib_ppf_get_output_mem_func get_output_mem;

	emhwlib_ppf_set_output_mem_func set_output_mem;
	emhwlib_ppf_set_input_func set_input;
	emhwlib_ppf_get_output_func get_output;
	emhwlib_ppf_set_command_func set_command;
/* 	emhwlib_ppf_run_filter_func run_filter; */
/* 	emhwlib_ppf_init_func init; */
/* 	emhwlib_ppf_deinit_func deinit; */
};

/** Device settings for the I2C bus */
struct EMhwlibI2CDeviceParameter {
	/** Set to 1 (used for future extensions) */
	RMuint32 APIVersion;
	/** GPIO of the I2C data line (software I2C only) */
	enum GPIOId_type Clock;
	/** GPIO of the I2C clock line (software I2C only) */
	enum GPIOId_type Data;
	/** I2C device address (write uses DevAddr, read uses DevAddr + 1) */
	RMuint8 DevAddr;
	/** I2C delay, in uSec */
	RMuint32 Delay;
	/** frequency of the I2C bit transfer, in kHz (e.g. 100 or 400) */
	RMuint32 Speed;
};

#define PID_USED_IN_PID_BANK    1
#define PID_USED_AS_HWPCR       2
#define PID_USED_AS_PAT         4
#define PID_USED_AS_CAT         8
#define PID_USED_AS_MGT      0x10

struct EMhwlibPidUsage_type {
	RMuint32 flags; /* combination of any of PID_USED_IN_PID_BANK, PID_USED_AS_HWPCR,
	                   PID_USED_AS_PAT, PID_USED_AS_CAT, PID_USED_AS_MGT.*/
	RMuint32 count; /* number of pid entries already set with the same pid value.
	                   Count can be greater than 4, maximum size of the array returned. */
	RMuint32x4 pid_entries; /* array of maximum 4 pid entries. The valid count
	                           of these entries is RMmin(count, 4). */
};

enum DiscontinuityProcessingMethod_type {
	DiscontinuityProcessingMethod_1 = 1, /* As soon as the demux sends a discontinuity interrupt or RMSTCPropertyID_Discontinuity
	                                  is called the pcr is set in the master timer.
	                                  When video or audio inband comes the current master timer is set in video/audio timers.
					  The issue is that video and audio will skip frames in order to resynchronize.
					  The result is worse when the video/audio fifo is big. */
	DiscontinuityProcessingMethod_2, /* As soon as the demux sends a discontinuity interrupt or RMSTCPropertyID_Discontinuity
	                                  is called the pcr value is stored internally but the master timer is not modified.
					  When first discontinuity inband interrupt comes from any of the decoders
					  the stored pcr is set in the master timer and also in the corresponding decoder's timer.
					  The other timer will be set when the inband will come, using the current master timer.
					  This method should drastically reduce the number of frames skipped at discontinuity point. */
};


enum EMhwlibPictureOrientation{
	EMhwlibPictureOrientation_HFlip,
	EMhwlibPictureOrientation_VFlip,
	EMhwlibPictureOrientation_BLDiagonalFlip,
	EMhwlibPictureOrientation_TLDiagonalFlip,
	EMhwlibPictureOrientation_90,
	EMhwlibPictureOrientation_180,
	EMhwlibPictureOrientation_270,
};

enum EMhwlibPictureTransformType{
	EMhwlibPictureTransformType_Orientation,
};

struct EMhwlibBWMonitorSample{
	RMuint32 DRAMControllerId;
	RMuint32 TotalTransfers;
	RMuint32 SelectedTransfers;
	RMuint32 Interval;
	RMuint32 SampleRef;
};

#define BWM_VOID                     0xff
#define BWM_ALL_BUSES_W              0x1e
#define BWM_ALL_BUSES_R              0x9e              

#define BWM_MBUS_HOST0_R             0x80
#define BWM_MBUS_HOST1_R             0x81
#define BWM_MBUS_AUDIO0_R            0x82
#define BWM_MBUS_AUDIO1_R            0x83
#define BWM_MBUS_TRANSPORT_R         0x84
#define BWM_MBUS_VIDEO_MISC0_R       0x85
#define BWM_MBUS_VIDEO_MISC1_R       0x86
#define BWM_MBUS_VIDEO_DBLK0_R       0x87
#define BWM_MBUS_VIDEO_DBLK1_R       0x88
#define BWM_MBUS_VIDEO_STORE0_R      0x89
#define BWM_MBUS_VIDEO_STORE1_R      0x8a
#define BWM_MBUS_ALL_R               0x9d

#define BWM_MBUS_HOST0_W             0x00
#define BWM_MBUS_HOST1_W             0x01
#define BWM_MBUS_AUDIO0_W            0x02
#define BWM_MBUS_AUDIO1_W            0x03
#define BWM_MBUS_TRANSPORT_W         0x04
#define BWM_MBUS_VIDEO_MISC0_W       0x05
#define BWM_MBUS_VIDEO_MISC1_W       0x06
#define BWM_MBUS_VIDEO_DBLK0_W       0x07
#define BWM_MBUS_VIDEO_DBLK1_W       0x08
#define BWM_MBUS_VIDEO_STORE0_W      0x09
#define BWM_MBUS_VIDEO_STORE1_W      0x0a
#define BWM_MBUS_ALL_W               0x1d

#define BWM_VBUS_MV_L_R              0xa0     
#define BWM_VBUS_MV_C_R              0xa1
#define BWM_VBUS_VCR_L_R             0xa2
#define BWM_VBUS_VCR_C_R             0xa3
#define BWM_VBUS_VP_R                0xa4
#define BWM_VBUS_HDSD_R              0xa5
#define BWM_VBUS_GFX_L_R             0xa6
#define BWM_VBUS_GFX_C_R             0xa7
#define BWM_VBUS_OSD_R               0xa8
#define BWM_VBUS_SPU_R               0xa9
#define BWM_VBUS_GACC_Y_R            0xaa
#define BWM_VBUS_GACC_X_R            0xab
#define BWM_VBUS_ALL_R               0xbd

#define BWM_VBUS_GRAPH_IN_W          0x20
#define BWM_VBUS_VIDEO_IN_W          0x21
#define BWM_VBUS_GACC_W              0x22
#define BWM_VBUS_HDSD_W              0x23
#define BWM_VBUS_ALL_W               0x3d

#define BWM_GBUS_R                   0xdd
#define BWM_GBUS_W                   0x5d


struct EMhwlibChunk256 {
	RMuint32 size;
	RMuint8 data[256];
};

enum EMhwlibReadBufferCompletionMode {
	EMhwlibReadBufferCompletionMode_Full,        /* complete the buffer when it is full; default behavior */
	EMhwlibReadBufferCompletionMode_NoDelay,     /* complete the buffer as soon as the microcode sends data.
	                                                This can guarantee one or multiple access units in the data.
							 Note. Access unit can be: section, PES, user data, etc. */
	EMhwlibReadBufferCompletionMode_MinimumSize, /* complete the buffer when the buffer has more than the threshold value */
	EMhwlibReadBufferCompletionMode_ExactSize,   /* complete the buffer when the buffer has exactly the threshold value */
};

struct EMhwlibReadBufferCompletion {
	/** By default the DMA buffers are completed when they are full. */
	enum EMhwlibReadBufferCompletionMode mode;
	/** Limited to max 1MB=0x100000. Used only when the mode is ..._MinimumSize or ..._ExactSize. */
	RMuint32 threshold;
};

enum EMhwlibRecipherMode {
	EMhwlibRecipher_passthrough, /* It reciphers only the encrypted TS packets. */
	EMhwlibRecipher_always       /* It reciphers all TS packets - clear or encrypted. */
};


struct EMhwlibTTXFifoInfo {
	RMuint32 base;
	RMuint32 size;
	RMuint32 readable;
	RMuint32 writable;
};

/*Logic OR-ed flags needed for RMVideoDecoderPropertyID_SequenceEndCodeResetFlags */
#define VIDEO_SEQUENCE_END_CODE_RESET_REFERENCES        1 /* It prevents prediction across the boundaries of video sequences */
#define VIDEO_SEQUENCE_END_CODE_RESET_DISPLAY_SIZE      2 /* It prevents display size propagation across the boundaries of video sequences */
#define VIDEO_SEQUENCE_END_CODE_RESET_COLOR_DESCRIPTION 4 /* It prevents color description propagation across the boundaries of video sequences */

enum EMhwlibInbandPanScanMode {
	EMhwlibInbandPanScan_DefaultPicture = 0, /* the window coordinates are ignored */
	EMhwlibInbandPanScan_AbsoluteWindow,     /* the window coordinates are in 1/16 pixel accuracy. For an image width of 720 pixels the coordinate should be 720*16. */
	EMhwlibInbandPanScan_RelativeWindow,     /* the window coordinates are relative to the decoded picture, on a scale of 4096. 100% = 4096. */
	EMhwlibInbandPanScan_LetterBox_Center,   /* the window coordinates are ignored */
	EMhwlibInbandPanScan_LetterBox_Top,      /* the window coordinates are ignored */
};

struct EMhwlibInbandPanScan {
	enum EMhwlibInbandPanScanMode mode;
	struct EMhwlibWindow window;
};

#endif // __EMHWLIB_GLOBALTYPES_H__
