/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   emhwlib_shortcuts.h
  @brief  

  A scalar property is a property that fits in a RMuint32
  (enums, RMbool, RMint8, RMint16, RMint32).

  If you accept that the failure cases are caught by RMPanic(),
  it is quicker to use the functions in this file and makes
  code more readable.

  Hack: second macro may be not compilable with other than gcc (check this)

  @author Emmanuel Michon
  @date   2003-05-15
*/

#ifndef __EMHWLIB_SHORTCUTS_H__
#define __EMHWLIB_SHORTCUTS_H__

#define EMSP(pEMhwlib,ModuleID,PropertyID,type,val)				\
do {										\
	type tmp=(val);								\
										\
	if (EMhwlibSetProperty(pEMhwlib,					\
			       ModuleID,					\
			       PropertyID,					\
			       &tmp,						\
			       sizeof(type))!=RM_OK) RMPanic(RM_FATAL);		\
} while (0)									\
     
#define EMGP(pEMhwlib,ModuleID,PropertyID,type)					\
({										\
	type val;								\
										\
	if (EMhwlibGetProperty(pEMhwlib,					\
			       ModuleID,					\
			       PropertyID,					\
			       &val,						\
			       sizeof(type))!=RM_OK) RMPanic(RM_FATAL);		\
										\
	val;									\
})

#define SetConfigBits(pEMhwlib, pStorage, begin, end, value) do { \
	RMuint32 config_reg; \
	config_reg = gbus_read_uint32((pEMhwlib)->pGBus, (RMuint32)&(pInfo->config_reg)); \
	RMsetConsecutiveBitsVar(&config_reg, begin, end, value); \
	gbus_write_uint32(pEMhwlib->pGBus, (RMuint32)&(pInfo->config_reg), config_reg); \
	(pStorage)->dirty |= VSYNC_DIRTY_CONFIG; \
} while(0)

#define SetConfig2Bits(pEMhwlib, pStorage, begin, end, value) do { \
	RMuint32 config2_reg; \
	config2_reg = gbus_read_uint32((pEMhwlib)->pGBus, (RMuint32)&(pInfo->config2_reg)); \
	RMsetConsecutiveBitsVar(&config2_reg, begin, end, value); \
	gbus_write_uint32(pEMhwlib->pGBus, (RMuint32)&(pInfo->config2_reg), config2_reg); \
	(pStorage)->dirty |= VSYNC_DIRTY_CONFIG; \
} while(0)

#define SetFormatBits(pEMhwlib, pStorage, begin, end, value) do { \
	RMuint32 format_reg; \
	format_reg = gbus_read_uint32((pEMhwlib)->pGBus, (RMuint32)&(pInfo->format_reg)); \
	RMsetConsecutiveBitsVar(&format_reg, begin, end, value); \
	gbus_write_uint32(pEMhwlib->pGBus, (RMuint32)&(pInfo->format_reg), format_reg); \
	(pStorage)->dirty |= VSYNC_INPUT_DIRTY_FORMAT; \
} while(0)

#define SetFormat2Bits(pEMhwlib, pStorage, begin, end, value) do { \
	RMuint32 format_reg; \
	format_reg = gbus_read_uint32((pEMhwlib)->pGBus, (RMuint32)&(pInfo->format2_reg)); \
	RMsetConsecutiveBitsVar(&format_reg, begin, end, value); \
	gbus_write_uint32(pEMhwlib->pGBus, (RMuint32)&(pInfo->format2_reg), format_reg); \
	(pStorage)->dirty |= VSYNC_INPUT_DIRTY_FORMAT2; \
} while(0)

#endif // __EMHWLIB_SHORTCUTS_H__
