/*
 *
 * Copyright (c) Sigma Designs, Inc. 2002,2003. All rights reserved.
 *
 */

/**
	@file emhwlib_gfx.h
	@brief header for some common definition for user and kernel mode
	
	@author Julien Crozon
	@date   2003-07-05
*/

#ifndef _EMHWLIB_GFX_H_
#define _EMHWLIB_GFX_H_

// here is some closed-caption defines used in the ClosedCaptionDecoder_storage type
#define CC_TEXT_NB_COLUMN	32									// nb columns
#define CC_TEXT_NB_ROW		15									// nb rows
#define CC_TEXT_NB_CHAR		(CC_TEXT_NB_COLUMN*CC_TEXT_NB_ROW)	// nb char
#define CC_FEED_DECODER_SIZE	0x100

typedef enum
{
	GFX_COLOR_LUT_1BPP = 0,
	GFX_COLOR_LUT_2BPP,
	GFX_COLOR_LUT_4BPP,
	GFX_COLOR_LUT_8BPP,
	//GFX_COLOR_16BPP_565,
	//GFX_COLOR_16BPP_1555,
	GFX_COLOR_16BPP_4444,
	GFX_COLOR_24BPP,
	//GFX_COLOR_24BPP_565,
	GFX_COLOR_32BPP
	//GFX_COLOR_32BPP_4444
} tdGFXColorDepth;

#endif // _EMHWLIB_GFX_H_
