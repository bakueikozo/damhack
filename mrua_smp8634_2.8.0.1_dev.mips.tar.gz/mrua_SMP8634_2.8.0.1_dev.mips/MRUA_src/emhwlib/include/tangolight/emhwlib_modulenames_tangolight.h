/******************************************************/
/* This file is generated automatically, DO NOT EDIT! */
/******************************************************/
/*
 * include/tangolight/emhwlib_modulenames_tangolight.h
 *
 * Copyright (c) 2001-2003 Sigma Designs, Inc. 
 * All Rights Reserved. Proprietary and Confidential.
 *
 */
 
/**
  @file include/tangolight/emhwlib_modulenames_tangolight.h
  @brief emhwlib generated file
   
  @author Jacques Mahe, Christian Wolff, Julien Soulier, Emmanuel Michon
  @ingroup hwlproperties
*/

#ifndef __EMHWLIB_MODULENAMES_TANGOLIGHT_H__
#define __EMHWLIB_MODULENAMES_TANGOLIGHT_H__

static const RMascii *EMhwlibModuleName[] = {
	"Enumerator", 
	"SystemBlock", 
	"CPUBlock", 
	"DisplayBlock", 
	"DispOSDScaler", 
	"DispHardwareCursor", 
	"DispMainVideoScaler", 
	"DispSubPictureScaler", 
	"DispGFXMultiScaler", 
	"DispMainMixer", 
	"DispColorBars", 
	"DispRouting", 
	"DispVideoInput", 
	"DispDigitalOut", 
	"DispMainAnalogOut", 
	"DemuxEngine", 
	"MpegEngine", 
	"VideoDecoder", 
	"AudioEngine", 
	"AudioDecoder", 
	"AudioCapture", 
	"CRCDecoder", 
	"XCRCDecoder", 
	"StreamCapture", 
	"RawDataTransfer", 
	"I2C", 
	"GFXEngine", 
	"MM", 
	"SpuDecoder", 
	"ClosedCaptionDecoder", 
	"RTC", 
	"Cipher", 
	"STC", 
	"PLL", 
	"DemuxTask", 
	"DemuxOutput", 
	"CCFifo", 
	"TTXFifo", 
};

#endif /* __EMHWLIB_MODULENAMES_TANGOLIGHT_H__ */

/* End of generated file include/tangolight/emhwlib_modulenames_tangolight.h */
