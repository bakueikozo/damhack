/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   emhwlib_chipspecific_tangolight.h
  @brief  

  long description

  @author Emmanuel Michon
  @date   2004-01-23
*/

#ifndef __EMHWLIB_CHIPSPECIFIC_TANGOLIGHT_H__
#define __EMHWLIB_CHIPSPECIFIC_TANGOLIGHT_H__

#include "../../../emhwlib_hal/include/emhwlib_registers.h"
#include "../emhwlib_interface.h"

static inline void hostsbox_loopback_channel1(struct gbus *pGBus)
{
	gbus_write_uint32(pGBus, REG_BASE_host_interface + output_SBOX_PCI_MASTER, 1|(input_unconnected_SBOX<<8));
	gbus_write_uint32(pGBus, REG_BASE_host_interface + output_SBOX_MBUS_W1, 1|(input_MBUS_R1_SBOX<<4));
}

static inline void hostsbox_pcislave_channel0(struct gbus *pGBus)
{
	gbus_write_uint32(pGBus, REG_BASE_host_interface + output_SBOX_PCI_SLAVE, 1|(input_MBUS_R0_SBOX<<12));
	// no need to or with bit 0 
	gbus_write_uint32(pGBus, REG_BASE_host_interface + output_SBOX_MBUS_W0, input_PCI_SLAVE_SBOX);
}

static inline void hostsbox_pcimaster_channel1(struct gbus *pGBus)
{
	gbus_write_uint32(pGBus, REG_BASE_host_interface + output_SBOX_PCI_MASTER, 1|(input_MBUS_R1_SBOX<<8));
	gbus_write_uint32(pGBus, REG_BASE_host_interface + output_SBOX_MBUS_W1, 1|(input_PCI_MASTER_SBOX<<4));
}

static inline RMuint32 pll_get_sysclk(struct gbus *pGBus)
{
	RMuint32 reg, clk = 27000000;
	
	reg = gbus_read_uint32(pGBus, REG_BASE_system_block + SYS_sysclk_mux);
	if (reg & 0x01) {
		RMuint32 m, n;
		reg = gbus_read_uint32(pGBus, REG_BASE_system_block + SYS_clkgen0_pll);
		m = RMunshiftBits(reg, 7, 16);
		n = RMunshiftBits(reg, 10, 0);
		clk = EMhwlibMul64x32Div32(clk, n + 2, m + 2);
	}
	
	return clk / 2;
}

static inline RMstatus hal_set_gpio(struct gbus *pGBus, enum GPIOId_type gpio, RMbool data)
{
	RMuint32 bit;
	RMstatus rc = RM_PARAMETER_OUT_OF_RANGE;

	switch (gpio) {
	case GPIOId_Sys_0:
	case GPIOId_Sys_1:
	case GPIOId_Sys_2:
	case GPIOId_Sys_3:
	case GPIOId_Sys_4:
	case GPIOId_Sys_5:
	case GPIOId_Sys_6:
	case GPIOId_Sys_7:
	case GPIOId_Sys_8:
	case GPIOId_Sys_9:
	case GPIOId_Sys_10:
	case GPIOId_Sys_11:
	case GPIOId_Sys_12:
	case GPIOId_Sys_13:
	case GPIOId_Sys_14:
	case GPIOId_Sys_15:
		bit = gpio;
		gbus_write_uint32(pGBus, REG_BASE_system_block + SYS_gpio_dir, 0x00010001 << bit);
		gbus_write_uint32(pGBus, REG_BASE_system_block + SYS_gpio_data, (0x00010000 | (data ? 1 : 0)) << bit);
		rc = RM_OK;
		break;

	case GPIOId_Eth_0:
	case GPIOId_Eth_1:
	case GPIOId_Eth_2:
	case GPIOId_Eth_3:
	case GPIOId_Eth_4:
	case GPIOId_Eth_5:
	case GPIOId_Eth_6:
	case GPIOId_Eth_7:
	case GPIOId_Eth_8:
	case GPIOId_Eth_9:
	case GPIOId_Eth_10:
	case GPIOId_Eth_11:
	case GPIOId_Eth_12:
	case GPIOId_Eth_13:
	case GPIOId_Eth_14:
	case GPIOId_Eth_15:
	case GPIOId_Eth_16:
	case GPIOId_Eth_17:
	case GPIOId_Eth_18:
	case GPIOId_Eth_19:
	case GPIOId_Eth_20:
	case GPIOId_Eth_21:
	case GPIOId_Eth_22:
	case GPIOId_Eth_23:
	case GPIOId_Eth_24:
	case GPIOId_Eth_25:
	case GPIOId_Eth_28:
	case GPIOId_Eth_29:
	case GPIOId_Eth_30:
	case GPIOId_Eth_31:
	case GPIOId_Eth_32:
	case GPIOId_Eth_33:
	case GPIOId_Eth_34:
	case GPIOId_Eth_35:
	case GPIOId_tdmx_0:
	case GPIOId_tdmx_1:
	case GPIOId_uart0_0:
	case GPIOId_uart0_1:
	case GPIOId_uart0_2:
	case GPIOId_uart0_3:
	case GPIOId_uart0_4:
	case GPIOId_uart0_5:
	case GPIOId_uart0_6:
	case GPIOId_uart1_0:
	case GPIOId_uart1_1:
	case GPIOId_uart1_2:
	case GPIOId_uart1_3:
	case GPIOId_uart1_4:
	case GPIOId_uart1_5:
	case GPIOId_uart1_6:
	case GPIOId_scard_0:
	case GPIOId_scard_1:
	case GPIOId_scard_2:
		break;
	}

	return rc;
}

#endif // __EMHWLIB_CHIPSPECIFIC_TANGOLIGHT_H__
