/****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   emhwlib_displaytypes.h
  @brief  

  long description

  @author Julien Soulier
  @date   2004-01-23
*/

#ifndef __EMHWLIB_DISPLAYTYPES_H__
#define __EMHWLIB_DISPLAYTYPES_H__

#include "../../gbuslib/include/gbus_fifo_eraser.h"

enum EMhwlibColorBarsStandard {
	EMhwlibColorBarsStandard_NTSC = 1,
	EMhwlibColorBarsStandard_PAL
};

enum EMhwlibMixerSourceState {
	EMhwlibMixerSourceState_Disable = 1,
	EMhwlibMixerSourceState_Master,
	EMhwlibMixerSourceState_Slave
};

enum EMhwlibDisplayCommand {
	EMhwlibDisplayCommand_Disable = 0,
	EMhwlibDisplayCommand_Enable,
	EMhwlibDisplayCommand_Flush,
	EMhwlibDisplayCommand_FlushKeepCurrent
};


enum EMhwlibComponentMode {
	EMhwlibComponentMode_Disable = 0,
	EMhwlibComponentMode_RGB_SCART,
	EMhwlibComponentMode_RGB_SOG,
	EMhwlibComponentMode_RGB_SMPTE,
	EMhwlibComponentMode_YUV_BETACAM,
	EMhwlibComponentMode_YUV_M2,
	EMhwlibComponentMode_YUV_SMPTE
};

enum EMhwlibCompositeMode {
	EMhwlibCompositeMode_Disable = 0,
	EMhwlibCompositeMode_NTSC_M,
	EMhwlibCompositeMode_PAL_BG,
	EMhwlibCompositeMode_PAL_60,
	EMhwlibCompositeMode_PAL_M
};	

enum EMhwlibComponentOrder {
	EMhwlibComponentOrder_RGB = 0,  // no swap
	EMhwlibComponentOrder_RBG, 
	EMhwlibComponentOrder_GRB, 
	EMhwlibComponentOrder_GBR, 
	EMhwlibComponentOrder_BRG, 
	EMhwlibComponentOrder_BGR
};

enum EMhwlibChromaFilter {
	EMhwlibChromaFilter_0_65_MHz = 0,
	EMhwlibChromaFilter_1_MHz,
	EMhwlibChromaFilter_1_3_MHz,
	EMhwlibChromaFilter_2_MHz,
	EMhwlibChromaFilter_3_25_MHz,
	EMhwlibChromaFilter_6_5_MHz
};

enum EMhwlibLumaFilter {
	EMhwlibLumaFilter_4_5_MHz = 0,
	EMhwlibLumaFilter_6_5_MHz
};

enum EMhwlibSharpnessControl {
	EMhwlibSharpnessControl_Disable = 0,
	EMhwlibSharpnessControl_Amplify_12_percent,
	EMhwlibSharpnessControl_Amplify_25_percent,
	EMhwlibSharpnessControl_Amplify_50_percent,
	EMhwlibSharpnessControl_Amplify_100_percent,
	EMhwlibSharpnessControl_Amplify_200_percent,
	EMhwlibSharpnessControl_Attenuate_12_percent,
	EMhwlibSharpnessControl_Attenuate_25_percent,
	EMhwlibSharpnessControl_Attenuate_50_percent,
	EMhwlibSharpnessControl_Notch
};

enum EMhwlibColorSpace {
	EMhwlibColorSpace_None = 1,
	EMhwlibColorSpace_RGB_16_235,
	EMhwlibColorSpace_RGB_0_255, 
	EMhwlibColorSpace_YUV_601, 
	EMhwlibColorSpace_YUV_709,
	EMhwlibColorSpace_YUV_601_0_255,
	EMhwlibColorSpace_YUV_709_0_255, 
	EMhwlibColorSpace_xvYCC_601, 
	EMhwlibColorSpace_xvYCC_709, 
	EMhwlibColorSpace_xvYCC_601_0_255, 
	EMhwlibColorSpace_xvYCC_709_0_255, 
};

enum EMhwlibColorOrder {
	EMhwlibColorOrder_RGB = 0,
	EMhwlibColorOrder_RBG
};

enum EMhwlibFieldType {
	EMhwlibFieldType_Frame = 0,
	EMhwlibFieldType_Top,
	EMhwlibFieldType_Bottom
};

enum EMhwlibVbiStandard {
	EMhwlibVbiStandard_Custom = 0,
	EMhwlibVbiStandard_525i,
	EMhwlibVbiStandard_525i_pal60,
	EMhwlibVbiStandard_625i,
	EMhwlibVbiStandard_525p,
	EMhwlibVbiStandard_625p,
	EMhwlibVbiStandard_hdtv720,
	EMhwlibVbiStandard_hdtv1080,
};

struct EMhwlibTVFormatAnalog {
	enum EMhwlibVbiStandard VbiStandard;
	RMuint32 PixelClock;
	/** Member default range 0 -> 4095 */
	RMuint32 ActiveWidth;
	/** Member default range 0 -> 4095 */
	RMuint32 ActiveHeight;
	/** Member default range 0 -> 4095 */
	RMuint32 XOffset;
	/** Member default range 0 -> 4095 */
	RMuint32 YOffsetTop;
	/** Member default range 0 -> 4095 */
	RMuint32 YOffsetBottom;
	/** Member default */
	RMbool VSyncActiveLow;
	/** Member default */
	RMbool HSyncActiveLow;
	/** Member default */
	enum EMhwlibComponentMode ComponentMode;
	/** Member default */
	enum EMhwlibCompositeMode CompositeMode;
	/** Member default */
	enum EMhwlibColorSpace ColorSpace;
	/** Member default */
	RMbool HDTVMode;
	/** Member default */
	RMbool Progressive;
	/** Member default */
	RMbool HDSyncDown;
	/** Member default */
	RMbool OversampledInput;
	/** Member default range 0 -> 5 */
	enum EMhwlibChromaFilter ChromaFilter;
	/** Member default */
	enum EMhwlibLumaFilter LumaFilter;
	/** Member default */
	RMbool SyncOnPbPr;
	/** Member default */
	RMbool Pedestal;
	/** Member default range 0 -> 4095 */
	RMuint32 Width;
	/** Member default range 0 -> 4095 */
	RMuint32 Height;
	/** Member default range 0 -> 4095 */
	RMuint32 HSync0;
	/** Member default range 0 -> 4095 */
	RMuint32 HSync1;
	/** Member default range 0 -> 4095 */
	RMuint32 VSyncO0Line;
	/** Member default range 0 -> 4095 */
	RMuint32 VSyncO0Pixel;
	/** Member default range 0 -> 4095 */
	RMuint32 VSyncO1Line;
	/** Member default range 0 -> 4095 */
	RMuint32 VSyncO1Pixel;
	/** Member default range 0 -> 4095 */
	RMuint32 VSyncE0Line;
	/** Member default range 0 -> 4095 */
	RMuint32 VSyncE0Pixel;
	/** Member default range 0 -> 4095 */
	RMuint32 VSyncE1Line;
	/** Member default range 0 -> 4095 */
	RMuint32 VSyncE1Pixel;
	/** Member default range 0 -> 4095 */
	RMuint32 HDHSyncWidth;
	/** Member default range 0 -> 4095 */
	RMuint32 HDVSyncWidth;
	/** Member default range 0 -> 4095 */
	RMuint32 HDVSyncStart;
};

/** Gets the default output display parameters based on a provided TV standard.@note This does not program the display, this is just an informational property */
struct EMhwlibTVFormatDigital {
	enum EMhwlibVbiStandard VbiStandard;
	RMuint32 PixelClock;
	/** Member default range 0 -> 4095 */
	RMuint32 ActiveWidth;
	/** Member default range 0 -> 4095 */
	RMuint32 ActiveHeight;
	/** Member default range 0 -> 4095 */
	RMuint32 XOffset;
	/** Member default range 0 -> 4095 */
	RMuint32 YOffsetTop;
	/** Member default range 0 -> 4095 */
	RMuint32 YOffsetBottom;
	/** Member default */
	RMbool VSyncActiveLow;
	/** Member default */
	RMbool HSyncActiveLow;
	/** Member default range 0 -> 8191 */
	RMuint32 TopFieldHeight;
	/** Member default range 0 -> 4095 */
	RMuint32 HTotalSize;
	/** Member default range 0 -> 4095 */
	RMuint32 VTotalSize;
	/** Member default range 0 -> 4095 */
	RMuint32 HSyncWidth;
	/** Member default range 0 -> 8191 */
	RMuint32 VSyncWidth;
	/** Member default range 0 -> 65535 */
	RMuint32 VSyncFineAdjust;
	/** Define the color space for blanking interval to RGB (0) or YUV (1) */
	enum EMhwlibColorSpace ColorSpace;
	/** Member Default */
	RMbool TrailingEdge;
	/** Delays VSYNC by one pixel clock */
	RMbool VSyncDelay1PixClk;
	/** Member default */
	RMbool Progressive;
	/** FALSE: analog standard is 4X oversampled, TRUE: analog standard is not oversampled */
	RMbool HDTVMode;
	/* [OP] WARNING: This field is not initialized by the emhwlib yet. */
	RMbool DoubleRateMode;
	
};

enum EMhwlibTVFormatType{
	EMhwlibTVFormatType_Analog,
	EMhwlibTVFormatType_Digital,
};

struct EMhwlibGenericTVFormat{
	enum EMhwlibTVFormatType Type;
	union{
		struct EMhwlibTVFormatAnalog Analog;
		struct EMhwlibTVFormatDigital Digital;
	}Format;
};

	


enum gfx_alpha_format {
	GFX_ALPHA_FORMAT_LUT_1BPA  = 1,
	GFX_ALPHA_FORMAT_LUT_2BPA,
	GFX_ALPHA_FORMAT_TRUE_4BPA,
	GFX_ALPHA_FORMAT_TRUE_8BPA
};

#define GFX_SURFACE_COUNT 4

enum gfx_surface_id {
	GFX_SURFACE_ID_X = 0,
	GFX_SURFACE_ID_Y, 
	GFX_SURFACE_ID_Z,
	GFX_SURFACE_ID_NX
};

enum gfx_blend_mode{
	GFX_BLEND_Y_ON_X = 0,
	GFX_BLEND_X_ON_Y = 1,	
	GFX_BLEND_Y_ON_Z = 2,	
	GFX_BLEND_Z_ON_Y = 3,
	GFX_BLEND_X_ON_Z = 4,
	GFX_BLEND_Z_ON_X = 5,
	GFX_RASTER_Y_ON_X,
	GFX_RASTER_Z_ON_X,
};

enum gfx_merge_mode{
	GFX_MERGE_MODE_DISABLE = 0,
	GFX_MERGE_MODE_X = 1,
	GFX_MERGE_MODE_MODULATE
};

enum gfx_alpha_fill_mode{
	GFX_ALPHA_FILL_MODE_OVERWRITE,
	GFX_ALPHA_FILL_MODE_MODULATE
};

enum gfx_input_type{
	GFX_INPUT_DIRECT,
	GFX_INPUT_SCALER,
	GFX_INPUT_COLOR,
	GFX_INPUT_GRADIENT
};

enum gfx_correction_mode{
	GFX_CORRECTION_NONE,
	GFX_CORRECTION_FADE,
	GFX_CORRECTION_LUT
};


enum EMhwlibHDSDConversionMode {
	EMhwlibHDSDConversionMode_OnTheFly = 1,
	EMhwlibHDSDConversionMode_Buffered
};	


enum EMhwlibDigitalTimingSignal {
	EMhwlibDigitalTimingSignal_601 = 1,
	EMhwlibDigitalTimingSignal_656,
	EMhwlibDigitalTimingSignal_656_VIP
};

struct EMhwlibColorConversionMatrix {
	RMint32 Mat00;
	RMint32 Mat01;
	RMint32 Mat02;
	RMint32 Mat10;
	RMint32 Mat11;
	RMint32 Mat12;
	RMint32 Mat20;
	RMint32 Mat21;
	RMint32 Mat22;
 	RMint32 Cst0;
 	RMint32 Cst1;
 	RMint32 Cst2;
};

enum EMhwlibDisplayWindowPositionMode {
	EMhwlibDisplayWindowPositionMode_FrontEdgeToBorder = 1,
	EMhwlibDisplayWindowPositionMode_RearEdgeToBorder,
	EMhwlibDisplayWindowPositionMode_FrontEdgeToCenter,
	EMhwlibDisplayWindowPositionMode_RearEdgeToCenter
};

enum EMhwlibDisplayWindowValueMode {
	EMhwlibDisplayWindowValueMode_Fixed = 1,
	EMhwlibDisplayWindowValueMode_Relative
};

struct EMhwlibDisplayWindow {
	RMint32 X;
	RMint32 Y;
	RMuint32 Width;
	RMuint32 Height;
	enum EMhwlibDisplayWindowPositionMode XPositionMode;
	enum EMhwlibDisplayWindowPositionMode YPositionMode;
	enum EMhwlibDisplayWindowValueMode XMode;
	enum EMhwlibDisplayWindowValueMode YMode;
	enum EMhwlibDisplayWindowValueMode WidthMode;
	enum EMhwlibDisplayWindowValueMode HeightMode;
};

enum EMhwlibSamplingMode {
	EMhwlibSamplingMode_444 = 1,
	EMhwlibSamplingMode_411,
	EMhwlibSamplingMode_422,
	EMhwlibSamplingMode_420,
	EMhwlibSamplingMode_420_MPEG1
};

enum EMhwlibColorMode {
	EMhwlibColorMode_LUT_1BPP = 1,
	EMhwlibColorMode_LUT_2BPP,
	EMhwlibColorMode_LUT_4BPP,
	EMhwlibColorMode_LUT_8BPP,
	EMhwlibColorMode_TrueColor, 
	EMhwlibColorMode_TrueColorWithKey, 
	EMhwlibColorMode_VideoInterleaved,
	EMhwlibColorMode_VideoNonInterleaved,
 	EMhwlibColorMode_16BPP_Alpha_LUT
};

enum EMhwlibColorFormat {
	EMhwlibColorFormat_24BPP_565 = 1,
	EMhwlibColorFormat_24BPP,
	EMhwlibColorFormat_32BPP_4444,
	EMhwlibColorFormat_32BPP,
	EMhwlibColorFormat_16BPP_565,
	EMhwlibColorFormat_16BPP_1555,
	EMhwlibColorFormat_16BPP_4444
};

enum EMhwlibInputColorFormat {
	EMhwlibInputColorFormat_24BPP = 1,
	EMhwlibInputColorFormat_24BPP_8565,
	EMhwlibInputColorFormat_24BPP_5676,
	EMhwlibInputColorFormat_32BPP,
	EMhwlibInputColorFormat_16BPP_565,
	EMhwlibInputColorFormat_16BPP_1555,
	EMhwlibInputColorFormat_16BPP_4444,
	EMhwlibInputColorFormat_31BPP_7888
};

struct EMhwlibAspectRatio {
	RMuint32 X;
	RMuint32 Y;
};

enum EMhwlibAspectRatioType {
	EMhwlibAspectRatio_Picture = 1,		/* use default picture aspect ratio and disable inband/outband */
	EMhwlibAspectRatio_Pixel,		/* pixel aspect ratio of the surface should be provided */
	EMhwlibAspectRatio_Display		/* display aspect ratio of the surface should be provided */
};

union aspect_ratio_union {
	struct EMhwlibAspectRatio par;	/* pixel aspect ratio of the surface */
	struct EMhwlibAspectRatio dar;	/* display aspect ratio of the surface */
};

struct EMhwlibWindow {
	RMuint32 x;
	RMuint32 y;
	RMuint32 width;
	RMuint32 height;
};

struct EMhwlibFilmGrain {
	RMuint32 block_info_start_address;
	RMuint32 block_info_width;
	RMuint32 pixel_x_offset;
	RMuint32 pixel_y_offset;
	RMuint32 field1;
	RMuint32 field2;
	RMuint32 filed3;
};	

/*  WARNING: This structure must be kept in sync with the definition of
 *  "decoder_picture_buffer_t dma struct" in /ucode_lib/ucode/video/global.h
 */

/* keep in sync with "decoder_picture_buffer_t dma struct"
   from ucode/video/decoder/global.h */
struct EMhwlibNewPicture {
	RMuint32 luma_address;                          /* 0x00 */
	RMuint32 luma_total_width;                      /* 0x04 */
	RMuint32 chroma_address;                        /* 0x08 */
	RMuint32 chroma_total_width;                    /* 0x0c */
	struct EMhwlibWindow luma_position_in_buffer;   /* 0x10 */
	struct EMhwlibWindow chroma_position_in_buffer; /* 0x20 */
	RMuint32 scaled_width;                          /* 0x30 */
	RMuint32 scaled_height;                         /* 0x34 */
	struct EMhwlibWindow panscan_1;                 /* 0x38 */
	struct EMhwlibWindow panscan_2;                 /* 0x48 */
	struct EMhwlibWindow panscan_3;                 /* 0x58 */
	struct EMhwlibWindow panscan_4;                 /* 0x68 */
	RMuint32 ar_x;                                  /* 0x78 */
	RMuint32 ar_y;                                  /* 0x7c */
	RMuint32 color_description;                     /* 0x80 */
	RMuint32 first_pts_lo;                          /* 0x84 */
	RMuint32 first_pts_hi;                          /* 0x88 */
	RMuint32 delta_pts;                             /* 0x8c */
	RMuint32 system_pts;                            /* 0x90 */
	RMuint32 timecode;                              /* 0x94 */
	RMuint32 time_increment_resolution;             /* 0x98 */
	RMuint32 picture_display_data;                  /* 0x9c */
	RMuint32 luma_scale;                            /* 0xa0 */
	RMuint32 chroma_scale;                          /* 0xa4 */
	RMuint32 picture_bytecount;                     /* 0xa8 */
	RMuint32 user_metadata;                         /* 0xac */
#ifndef NO_USER_DATA_REORDERING
	RMuint32 user_data_entry_status;	        /* 0xb0 */
	RMuint32 user_data_entry_size;                  /* 0xb4 */
#endif // USER_DATA_REORDERING 
	RMuint32 picture_decode_status;                 /* 0xb8 - 0xb0 */
	RMuint32 picture_display_status;                /* 0xbc - 0xb4 */
	RMuint32 error_status;                          /* 0xc0 - 0xb8 */
	struct EMhwlibFilmGrain film_grain;             /* 0xc4 - 0xbc */
  	RMuint32 palette_address;                       /* 0xe0 - 0xd8 */ 
	RMuint32 palette_size;                          /* 0xe4 - 0xdc */
	RMuint32 palette_buffer_size;                   /* 0xe8 - 0xe0 */
        RMuint32 frame_count;                           /* 0xec - 0xe4 */
};

enum EMhwlibDefaultColorSpaceAlgorithm {
	EMhwlibDefaultColorSpaceAlgoritm_601 = 0,  /* keep 0 for backward compatibility */
	EMhwlibDefaultColorSpaceAlgoritm_709,
	EMhwlibDefaultColorSpaceAlgoritm_SD601_HD709,
};

struct EMhwlibSurface {
	RMuint32 module_id;			/* module_id of the owner of surface. If not NULL the module_id receive callback when the display event is set */
	RMuint32 video_timer_index;		/* index of the video timer */
	RMuint32 picture_fifo;			/* address of DisplayFifo (fifo) or zero (single picture) */
	RMuint32 picture_mem_base;		/* DMEM base of video decoder (fifo) or address of struct vsync_picture (single) */
	RMuint32 forced_flags;
	union aspect_ratio_union ar;
	enum EMhwlibSamplingMode sampling_mode;
 	enum EMhwlibColorSpace color_space;
	enum EMhwlibColorMode color_mode;
	enum EMhwlibColorFormat color_format;
	RMuint32 tiled;
	RMuint32 force_Y_addr;
	RMuint32 force_UV_addr;
	RMuint32 valid_force_addr;
	struct gbus_fifo_eraser inband_cmd_fifo;
	RMuint32 palette_buffer_addr;
	RMuint32 palette_buffer_size;
	enum EMhwlibDefaultColorSpaceAlgorithm default_cs_algo;
	struct EMhwlibNewPicture sequence_picture; /* picture describing the current sequence */
};

/* keep in sync with "decoder_subpicture_buffer_t dma struct"
   from ucode/video/decoder/subpicture/subpicture_struct.h */
struct EMhwlibSubPicture {
	RMuint32 start_address;                         /* 0x00 */ /* [IH] old structure member: addr   */
	RMuint32 reserved0;                             /* 0x04 */
	RMuint32 reserved1;                             /* 0x08 */
	RMuint32 reserved2;                             /* 0x0c */
	struct EMhwlibWindow bitmap_position_in_buffer; /* 0x10 */ /* [IH] old structure members: hz_offset, vt_offset, width, height   */
	struct EMhwlibWindow reserved3;                 /* 0x20 */
	RMuint32 scaled_width;                          /* 0x30 */ /* old structure member: width (duplicated !)   */
	RMuint32 scaled_height;                         /* 0x34 */ /* old structure member: height  (duplicated !) */
	struct EMhwlibWindow reserved4;                 /* 0x38 */
	struct EMhwlibWindow reserved5;                 /* 0x48 */
	struct EMhwlibWindow reserved6;                 /* 0x58 */
	struct EMhwlibWindow reserved7;                 /* 0x68 */
	RMuint32 ar_x;                                  /* 0x78 */ /* old structure member: NONE  set always to 1 */
	RMuint32 ar_y;                                  /* 0x7c */ /* old structure member: NONE  set always to 1 */
	RMuint32 new_command;                           /* 0x80 */ /* old structure member: command    */
	RMuint32 first_pts_lo;                          /* 0x84 */ /* old structure member: pts64_lo   */
	RMuint32 first_pts_hi;                          /* 0x88 */ /* old structure member: pts64_hi   */
	RMuint32 reserved8;                             /* 0x8c */
	RMuint32 system_pts;                            /* 0x90 */ /* old structure member: NONE  set always to 0 */
	RMuint32 reserved9;                             /* 0x94 */
	RMuint32 reserved10;                            /* 0x98 */ 
	RMuint32 subpicture_type;                       /* 0x9c */ /* old structure member: type   */  
	RMuint32 dcsq_command;                          /* 0xa0 */ /* [IH] old structure member: dcsq_command   */
	RMuint32 reserved11;                            /* 0xa4 */
	RMuint32 reserved12;                            /* 0xa8 */
	RMuint32 reserved13;                            /* 0xac */
	RMuint32 reserved14;	                        /* 0xb0 */
	RMuint32 reserved15;                            /* 0xb4 */
	RMuint32 picture_decode_status;                 /* 0xb8 */ /* old structure member: decoder_status   */
	RMuint32 picture_display_status;                /* 0xbc */ /* [IH] old structure member: display_status   */
	RMuint32 error_status;                          /* 0xc0 */ /* old structure member: NONE  set always to 0 */
	struct EMhwlibFilmGrain reserved16;             /* 0xc4 */
	RMuint32 reserved17;                            /* 0xe0 */
	RMuint32 reserved18;                            /* 0xe4 */
	RMuint32 reserved19;                            /* 0xe8 */   
	RMuint32 frame_count;                           /* 0xec */
};


#define EMHWLIB_CCSURFACE_608_TYPE   (1<<0)
#define EMHWLIB_CCSURFACE_708_TYPE   (1<<1)

struct EMhwlibCCSurface {
	RMuint32 allowed_types; /* bit field */
	RMuint32 fifo;
	RMuint32 timer_index;
	RMuint32 mixer;
	RMuint32 decoder;
	RMuint32 command;
	RMuint32 clear_state;
	RMuint32 enable;
	RMuint32 mute;
};

#define TTX_FIFO_SIZE 1024
#define TTX_MAX_LINES 18
#define TTX_MAX_BYTES_PER_LINE 44
#define TTX_MAX_DWORD_PER_LINE 11
#define TTX_LINE_NUMBER_BASE 6
#define TTX_DISPLAYED_BY_VSYNC_0 0x00000001
#define TTX_DISPLAYED_BY_VSYNC_1 0x00000002
#define TTX_DISPLAYED_BY_VSYNC_2 0x00000004
#define TTX_DISPLAYED_BY_VSYNC_3 0x00000008

struct EMhwlibTTXField {
	RMuint32 field_parity;   // 1 bit
	RMuint32 framing_code;   // 1 byte, framing code actually does not change, keep it here so display can check tv system
	RMuint32 line_mask;     // bit 0 to 17 are valid, system B has the maximum usage of 18 lines
	RMuint32 data[TTX_MAX_LINES*TTX_MAX_DWORD_PER_LINE];
	RMuint32 display_flags;  // flags used for display purposes
};

struct EMhwlibTTXPicture {   // represents the ttx data on one frame
	struct EMhwlibTTXField fields[2];
	RMuint64 pts;
};

struct EMhwlibTTXSurface {
	RMuint32 fifo;
	RMuint32 mixer;
	RMuint32 decoder;
	RMuint32 stc;
	RMuint32 enable;
};

struct EMhwlibPictureOverride {
	RMbool Enable;
	enum EMhwlibColorFormat ColorFormat;
	RMuint32 Width;
	RMuint32 Height;
};


struct EMhwlibBlackStripMode {
	RMuint32 Horizontal;
	RMuint32 Vertical;
};
  
struct EMhwlibCutStripMode {
	RMuint32 Horizontal;
	RMuint32 Vertical;
};

struct EMhwlibNonLinearScalingMode {
	RMuint32 Width;
	RMuint32 Level;
};

enum EMhwlibScalingMode {
	EMhwlibScalingMode_PanScan = 1,
	EMhwlibScalingMode_LetterBox,
	EMhwlibScalingMode_ARIB
};

/* if downscale <= FilterBoundary[n], filter selection is n+1 */  
struct EMhwlibDownScalingMode {
	RMuint32 Discard;
	RMuint32 FilterBoundary[3];
};	

enum EMhwlib422DownSamplingMode {
	EMhwlib422DownSamplingMode_Discard = 1,
	EMhwlib422DownSamplingMode_Average,
};
	
enum EMhwlibDeinterlacingMode {
	EMhwlibDeinterlacingMode_Discard_Bob = 1,
	EMhwlibDeinterlacingMode_Weave,
	EMhwlibDeinterlacingMode_ConstantBlend,
	EMhwlibDeinterlacingMode_MotionAdaptative
};
	
struct EMhwlibKeyColor {
	RMuint32 R_Cr;
	RMuint32 G_Y;
	RMuint32 B_Cb;
	RMuint32 Range;
};

struct EMhwlibLumaKeying {
	RMuint32 LumaMin;
	RMuint32 LumaMax;
};

struct EMhwlibColor {  // Pixel Color with 8 bits per component
	RMuint32 R_Cr;
	RMuint32 G_Y;
	RMuint32 B_Cb;
};

struct EMhwlibDeepColor {  // Pixel Color with variable component bit depth
	RMuint32 R_Cr;  // Red or Chroma Red component
	RMuint32 G_Y;   // Green or Luma component
	RMuint32 B_Cb;  // Blue or Chroma Blue component
	RMuint32 ComponentBitDepth;  // Number of significant bits in each component
};

/* starts with 0 so that irq_handler default value is valid */
enum EMhwlibScalerFieldSelection {
	EMhwlibScalerFieldSelection_BestFieldTime = 0,
	EMhwlibScalerFieldSelection_BestFieldType,
	EMhwlibScalerFieldSelection_OneField,
};	

enum EMhwlibSCARTWideBitState {
	EMhwlibSCARTWideState_Auto = 1,
	EMhwlibSCARTWideState_16_9,
	EMhwlibSCARTWideState_4_3
};	

enum EMhwlibDisplayTimeIntervalMode {
	EMhwlibDisplayIntervalMode_None = 1,
	EMhwlibDisplayIntervalMode_Start,
	EMhwlibDisplayIntervalMode_End,
	EMhwlibDisplayIntervalMode_StartEnd
};

struct EMhwlibDisplayTimeInterval {
	enum EMhwlibDisplayTimeIntervalMode Mode;
	RMuint32 StartPTSLo;
	RMuint32 StartPTSHi;
	RMuint32 EndPTSLo;
	RMuint32 EndPTSHi;
};

enum GPIOId_type {
	/** GPIO from the system block */
	/** pin name : GPIO0 */
	GPIOId_Sys_0 = 0,
	/** pin name : GPIO1 */
	GPIOId_Sys_1 = 1,
	/** pin name : GPIO2 */
	GPIOId_Sys_2 = 2,
	/** pin name : GPIO3 */
	GPIOId_Sys_3 = 3,
	/** pin name : GPIO4 */
	GPIOId_Sys_4 = 4,
	/** pin name : GPIO5 */
	GPIOId_Sys_5 = 5,
	/** pin name : GPIO6 */
	GPIOId_Sys_6 = 6,
	/** pin name : GPIO7 */
	GPIOId_Sys_7 = 7,
	/** pin name : GPIO8 */
	GPIOId_Sys_8 = 8,
	/** pin name : GPIO9 */
	GPIOId_Sys_9 = 9,
	/** pin name : GPIO10 */
	GPIOId_Sys_10 = 10,
	/** pin name : GPIO11 */
	GPIOId_Sys_11 = 11,
	/** pin name : GPIO12 */
	GPIOId_Sys_12 = 12,
	/** pin name : GPIO13 */
	GPIOId_Sys_13 = 13,
	/** pin name : GPIO14 */
	GPIOId_Sys_14 = 14,
	/** pin name : GPIO15 */
	GPIOId_Sys_15 = 15,

	/** GPIO from the ethernet block in the host interface  (dir1)
	    ONLY ON SMP8634 and EM8624 */
	/** pin name : ETH_TXCLK */
	GPIOId_Eth_0 = 16,
	/** pin name : ETH_TX_EN */
	GPIOId_Eth_1 = 17,
	/** pin name : ETH_TXD0 */
	GPIOId_Eth_2 = 18,
	/** pin name : ETH_TXD1 */
	GPIOId_Eth_3 = 19,
	/** pin name : ETH_TXD2 */
	GPIOId_Eth_4 = 20,
	/** pin name : ETH_TXD3 */
	GPIOId_Eth_5 = 21,
	/** pin name : ETH_RXCLK */
	GPIOId_Eth_6 = 22,
	/** pin name : ETH_RX_DV */
	GPIOId_Eth_7 = 23,
	/** pin name : ETH_RX_ER */
	GPIOId_Eth_8 = 24,
	/** pin name : ETH_RXD0 */
	GPIOId_Eth_9 = 25,
	/** pin name : ETH_RXD1 */
	GPIOId_Eth_10 = 26,
	/** pin name : ETH_RXD2 */
	GPIOId_Eth_11 = 27,
	/** pin name : ETH_RXD3 */
	GPIOId_Eth_12 = 28,
	/** pin name : ETH_CRS */
	GPIOId_Eth_13 = 29,
	/** pin name : ETH_COL */
	GPIOId_Eth_14 = 30,
	/** pin name : ETH_MDC */
	GPIOId_Eth_15 = 31,
	/** pin name : ETH_MDIO */
	GPIOId_Eth_16 = 32,
	/** pin name : ETH_MDINT (ONLY ON SMP8634) */
	GPIOId_Eth_17 = 33,
	
	/** GPIO from the ethernet block in the host interface (dir2)
	    ONLY ON SMP8634 */
	/** pin name : GPIO16 */
	GPIOId_Eth_18 = 34,
	/** pin name : GPIO17 */
	GPIOId_Eth_19 = 35,
	/** pin name : GPIO18 */
	GPIOId_Eth_20 = 36,
	/** pin name : GPIO19 */
	GPIOId_Eth_21 = 37,
	/** pin name : GPIO20 */
	GPIOId_Eth_22 = 38,
	/** pin name : GPIO21 */
	GPIOId_Eth_23 = 39,
	/** pin name : GPIO22 */
	GPIOId_Eth_24 = 40,
	/** pin name : GPIO23 */
	GPIOId_Eth_25 = 41,
	/** pin name : GPIO24 */
	GPIOId_Eth_28 = 42,
	/** pin name : GPIO25 */
	GPIOId_Eth_29 = 43,
	/** pin name : GPIO26 */
	GPIOId_Eth_30 = 44,
	/** pin name : GPIO27 */
	GPIOId_Eth_31 = 45,
	/** pin name : GPIO28 */
	GPIOId_Eth_32 = 46,
	/** pin name : GPIO29 */
	GPIOId_Eth_33 = 47,
	/** pin name : GPIO30 */
	GPIOId_Eth_34 = 48,
	/** pin name : GPIO31 */
	GPIOId_Eth_35 = 49,
    
	/** GPIO from the transport demux ONLY ON SMP8634,
	    EM8622 and EM8624 */
	/** pin name : TDMX_GPIO0 */
	GPIOId_tdmx_0 = 50,
	/** pin name : TDMX_GPIO1 */
	GPIOId_tdmx_1 = 51,

	/** GPIO from the UART in the cpu block ONLY ON SMP8634,
	    EM8622 and EM8624 */
	/** pin name : UART0_RX */
	GPIOId_uart0_0 = 52,
	/** pin name : UART0_CTS */
	GPIOId_uart0_1 = 53,
	/** pin name : UART0_DSR */
	GPIOId_uart0_2 = 54,
	/** pin name : UART0_DCD */
	GPIOId_uart0_3 = 55,
	/** pin name : UART0_TX */
	GPIOId_uart0_4 = 56,
	/** pin name : UART0_RTS */
	GPIOId_uart0_5 = 57,
	/** pin name : UART0_DTR */
	GPIOId_uart0_6 = 58,
	/** pin name : UART1_RX */
	GPIOId_uart1_0 = 59,
	/** pin name : UART1_CTS */
	GPIOId_uart1_1 = 60,
	/** pin name : UART1_DSR */
	GPIOId_uart1_2 = 61,
	/** pin name : UART1_DCD */
	GPIOId_uart1_3 = 62,
	/** pin name : UART1_TX */
	GPIOId_uart1_4 = 63,
	/** pin name : UART1_RTS */
	GPIOId_uart1_5 = 64,
	/** pin name : UART1_DTR */
	GPIOId_uart1_6 = 65,

	/** GPIO from the smart card in the cpu block ONLY ON SMP8634 */
	/** pin name : SCARD_CTL0 */
	GPIOId_scard_0 = 66,
	/** pin name : SCARD_CTL1 */
	GPIOId_scard_1 = 67,
	/** pin name : SCARD_CTL2 */
	GPIOId_scard_2 = 68,
};

struct EMhwlibSCARTConfig {
	enum GPIOId_type EnableBit;  /* Number of the GPIO pin used to switch to the SCART output */
	RMuint32 EnableInvert;       /* Polarity the Enable GPIO, FALSE: GPIO-Low switches to the SCART (normal), TRUE: GPIO-High switches to SCART (inverted) */
	enum GPIOId_type WideBit;    /* Number of the GPIO pin used to switch SCART to wide screen */
	RMuint32 WideInvert;         /* Polarity the Wide GPIO, FALSE: GPIO-High switches to wide screen (normal), TRUE: GPIO-Low switches to wide screen (inverted) */
};

/** Set up Output V-Sync phase-lock with V-Sync of Input. The Input has to be set up separately, a surface pointer of NULL will avoid video capture data transfers. If output phase falls outside of PhaseMin..PhaseMax range, output frame height will be adapted to make next output V-Sync occur in the middle between PhaseMin and PhaseMax. The output video signal may become invalid for one frame, with unpredictable effects on the display quality. These effects are dependant on the particular monitor logic. */
struct EMhwlibOutputGenlock {
	/** ModuleID of Input to synchronize with, or 0 to disable */
	RMuint32 InputID;
	/** Lowest acceptable phase of input where output vsync can occur. Phase is based on full frames, 256 is equivalent to 360 degrees. */
	RMuint8 PhaseMin;
	/** Highest acceptable phase of input where output vsync can occur. Phase is based on full frames, 256 is equivalent to 360 degrees. */
	RMuint8 PhaseMax;
};

/** Disable single DACs of an analog output block, FALSE = normal operation, TRUE = disable DAC */
struct EMhwlibDACDisable {
	/** TRUE: Disable DAC for S-Video Y signal (Component Y in component mode) */
	RMbool DAC1SVideoY;
	/** TRUE: Disable DAC for S-Video C signal (Component Cb in component mode) */
	RMbool DAC2SVideoC;
	/** TRUE: Disable DAC for Composite signal (Component Cr in component mode) */
	RMbool DAC3CVBS;
	/** TRUE: Disable DAC for Component Y signal (MainAnalogOut of "light" display block only) */
	RMbool DAC4Y;
	/** TRUE: Disable DAC for Component Cb signal (MainAnalogOut of "light" display block only) */
	RMbool DAC5Cb;
	/** TRUE: Disable DAC for Component Cr signal (MainAnalogOut of "light" display block only) */
	RMbool DAC6Cr;
};

/** Luma to Chroma relative delay */
enum EMhwlibLumaChromaDelay {
	/** No delay between Luma and Chroma */
	EMhwlibLumaChromaDelay_NoDelay = 0, 
	/** Chroma delayed by one pixel clock against Luma */
	EMhwlibLumaChromaDelay_DelayChroma1Clock, 
	/** Chroma delayed by two pixel clocks against Luma */
	EMhwlibLumaChromaDelay_DelayChroma2Clock, 
	/** Chroma delayed by three pixel clocks against Luma */
	EMhwlibLumaChromaDelay_DelayChroma3Clock, 
	/** No delay between Luma and Chroma (Reserved) */
	EMhwlibLumaChromaDelay_Reserved,  /* another NoDelay */
	/** Luma delayed by one pixel clock against Chroma */
	EMhwlibLumaChromaDelay_DelayLuma1Clock, 
	/** Luma delayed by two pixel clocks against Chroma */
	EMhwlibLumaChromaDelay_DelayLuma2Clock, 
	/** Luma delayed by three pixel clocks against Chroma */
	EMhwlibLumaChromaDelay_DelayLuma3Clock
};

/** Cropping of the video lines */
struct EMhwlibLineCrop {
	/** Number of pixels dropped on the left, range 0 -> 15 */
	RMuint32 CropLeftPos;
	/** First of the pixels dropped on the right, range 0 -> 4095 */
	RMuint32 CropRightPos;
	/** Define the color space for replacement black (RGB or YUV) */
	enum EMhwlibColorSpace ColorSpace;
	/** FALSE: replace cropped pixels with black, TRUE: replace cropped pixels with sync level */
	RMbool CropControl;
};

enum EMhwlibSubtitlingMode {
	EMhwlibSubtitlingMode_none = 0,            // No open subtitles in the image
	EMhwlibSubtitlingMode_inside_active_area,  // Subtiles inside the active image area
	EMhwlibSubtitlingMode_outside_active_area, // Subtitle outside of the active image area (as defined by the active format descriptor)
	EMhwlibSubtitlingMode_reserved             // reserved value
};

/** Extra information for WSS 625 (ETSI EN 300 294) */
struct EMhwlibWSSEnhancedServices {
	/** FALSE: Camera mode, TRUE: Film mode, used for PAL Plus (ITU Bt.1197) */
	RMbool FilmBit;
	/** FALSE: Standard coding, TRUE: Motion Adaptive Colour Plus, used for PAL Plus (ITU Bt.1197) */
	RMbool ColourCoding;
	/** FALSE: No helper, TRUE: Modulated PAL Plus helper in the U color sub carrier of the letterbox bars, used for PAL Plus (ITU Bt.1197) */
	RMbool Helper;
	/** FALSE: No subtitles within TeleText, TRUE: Subtitles within TeleText */
	RMbool Subtitles;
	/** Mode of subtitling */
	enum EMhwlibSubtitlingMode SubtitlingMode;
	/** FALSE: No surround sound information, TRUE: surround sound mode */
	RMbool SurroundSound;
};

/** Description of the active format in the picture frame (active: other than black bars) */
enum EMhwlibActiveFormat {    // See CEA-861C (HDMI), Table 83, page 144, Annex H, or ETSI TR 101 154 (DVB), Annex B, or CEA-805C (Component VBI)
	EMhwlibAF_no_info                 = 0x0, // active format not known (only used in CEA-805C, use "same_as_picture" for others)
	EMhwlibAF_reserved_1              = 0x1, // 
	EMhwlibAF_16x9_top                = 0x2, // 16x9 content: at top of 4x3 frame, fills up 16x9 frame
	EMhwlibAF_14x9_top                = 0x3, // 14x9 content: at top of 4x3 frame, centered on 16x9 frame
	EMhwlibAF_64x27_centered          = 0x4, // Cinemascope widesceeen (2.35x1) content: centered on 4x3 or 16x9 frame
	EMhwlibAF_reserved_5              = 0x5, // 
	EMhwlibAF_reserved_6              = 0x6, // 
	EMhwlibAF_reserved_7              = 0x7, // 
	EMhwlibAF_same_as_picture         = 0x8, // active content fills up frame
	EMhwlibAF_4x3_centered            = 0x9, // 4x3 content: fills up 4x3 frame, centered on 16x9 frame
	EMhwlibAF_16x9_centered           = 0xA, // 16x9 content: centered on 4x3 frame, fills up 16x9 frame
	EMhwlibAF_14x9_centered           = 0xB, // 14x9 content: centered on 4x3 frame, centered on 16x9 frame
	EMhwlibAF_reserved_12             = 0xC, // 
	EMhwlibAF_4x3_centered_prot_14x9  = 0xD, // 4x3 content with essential content in 14x9 centered portion
	EMhwlibAF_16x9_centered_prot_14x9 = 0xE, // 16x9 content with essential content in 14x9 centered portion
	EMhwlibAF_16x9_centered_prot_4x3  = 0xF  // 16x9 content with essential content in 4x3 centered portion
};

/** Full description of the active picture */
struct EMhwlibActiveFormatDescription {
	/** TRUE: ActiveFormat contains valid information. */
	RMbool ActiveFormatValid;
	/** Active format inside current frame */
	enum EMhwlibActiveFormat ActiveFormat;
	/** Picture aspect ratio of current frame */
	struct EMhwlibAspectRatio FrameAspectRatio;
};

/** Description of fill bars around the edge of the picture in the frame, in absolute line/pixel values */
struct EMhwlibActiveFormatBarInfo {
	/** Width of the frame this bar info applies to. 
	    Zero if unknown. */
	RMuint32 FrameSizeX;
	/** Height of the frame this bar info applies to. 
	    Zero if unknown. */
	RMuint32 FrameSizeY;
	
	/** TRUE: EndLeftBarPixelNum and StartRightBarPixelNum 
	    contain valid information. */
	RMbool VerticalBarDataValid;
	/** TRUE: EndTopBarLineNum and StartBottomBarLineNum 
	    contain valid information. */
	RMbool HorizontalBarDataValid;
	
	/** Pixel number of the last horizontal pixel of a vertical 
	    pillar-bar area at the left side of the picture. 
	    Zero means no bar is present. */
	RMuint16 EndLeftBarPixelNum;
	/** Pixel number of the first horizontal pixel of a vertical 
	    pillar-bar area at the right side of the picture. 
	    A value greater than FrameSizeX means no bar is present. */
	RMuint16 StartRightBarPixelNum;
	
	/** Line number of the last line of a horizontal 
	    letterbox bar area at the top of the picture. 
	    Zero means no bar is present. */
	RMuint16 EndTopBarLineNum;
	/** Line number of the first line of a horizontal 
	    letterbox bar area at the bottom of the picture. 
	    A value greater than FrameSizeY means no bar is present. */
	RMuint16 StartBottomBarLineNum;
};

enum EMhwlibScanInfo {
	EMhwlibScanInfo_NoData = 0,        // unknown
	EMhwlibScanInfo_Overscanned = 1,   // (television, sink may crop edge of picture)
	EMhwlibScanInfo_Underscanned = 2   // (computer, sink shall not crop picture)
};

/** Describes the video frame format and the picture content of the video frame */
struct EMhwlibVideoFrameDescription {
	/** frame aspect ratio and content active format description. set FrameAspectRatio=0,0 for autodetect. */
	struct EMhwlibActiveFormatDescription AFD;
	/** content bar data. set FrameSizeX,Y=0,0 for autodetect. */
	struct EMhwlibActiveFormatBarInfo BarInfo;
	/** color space. set EMhwlibColorSpace_None for autodetect. */
	enum EMhwlibColorSpace ColorSpace;
	/** sampling mode (relevant for digital domain only) */
	enum EMhwlibSamplingMode SamplingMode;
	/** over- or underscanned. set EMhwlibScanInfo_NoData for autodetect. */
	enum EMhwlibScanInfo ScanInfo;
	/** non-linear scaling which has been applied to the content material. */
	struct EMhwlibNonLinearScalingMode NonLinearScaling;
	/** 0=unique pixel, 1=pixels repeated once (sent out twice) etc. (digital domain only) */
	RMuint32 PixelRepetition;
};

enum EMhwlibCCEnable {
	CC_EnableTopBottom = 0,
	CC_EnableBottom,
	CC_EnableTop,
	CC_DisableTopBottom
};

enum EMhwlibCGMSWSSEnable {
	CGMSWSS_DisableTopBottom = 0,
	CGMSWSS_EnableBottom,
	CGMSWSS_EnableTop,
	CGMSWSS_EnableTopBottom
};

/** obsolete, will be internally transcoded to struct EMhwlibAnalogFrameInfo */
enum EMhwlibWSSPictureFormat {
	WSSNormal = 0,
	WSSLetterBox
};

/** obsolete, will be internally transcoded to struct EMhwlibAnalogFrameInfo */
enum EMhwlibWSSPicturePosition {
	WSSTop = 0,
	WSSCentre
};

/** obsolete, will be internally transcoded to struct EMhwlibAnalogFrameInfo */
struct EMhwlibCGMSWSS_525 {
	enum EMhwlibCGMSWSSEnable Enable;
	enum EMhwlibWSSPictureFormat PictureFormat;
	struct EMhwlibAspectRatio dar;	// if X=0 the output display aspect ratio is used
};

/** obsolete, will be internally transcoded to struct EMhwlibAnalogFrameInfo */
struct EMhwlibCGMSWSS_625 {
	enum EMhwlibCGMSWSSEnable Enable;
	enum EMhwlibWSSPictureFormat PictureFormat;
	enum EMhwlibWSSPicturePosition PicturePosition;
	struct EMhwlibAspectRatio dar;	// if X=0 the output display aspect ratio is used
};

/** Send out VBI data packets on either field */
enum EMhwlibVBIEnable {
	EMhwlibVBIEnable_Disable = 0,
	EMhwlibVBIEnable_EnableBottom,
	EMhwlibVBIEnable_EnableTop,
	EMhwlibVBIEnable_EnableTopBottom
};

/** Information for VBI data according to IEC-61880/ETSI-EN-300-294/CEA-805-TypeB on analog video outputs */
/* This replaces structs EMhwlibCGMSWSS_525 (IEC-61880) and EMhwlibCGMSWSS_625 (ETSI-EN-300-294) */
struct EMhwlibAnalogFrameInfo {
	/** Set to '1'. Used for future extension of this API */
	RMuint32 APIVersion;
	/** Enable IEC-61880/ETSI-EN-300-294 and/or CEA-805 Type B packets in either field, if applicable */
	enum EMhwlibVBIEnable VBIEnable;
	/** Describes the video frame format and the picture content of the video frame */
	struct EMhwlibVideoFrameDescription Frame;
	/** Optional information for 625 line WSS signalling */
	struct EMhwlibWSSEnhancedServices WSSEnhancedServices;
	/** RCI, CGMS and APS are not in the scope of this struct, they are set up separately in VSync IRQ handler */
};

/** Information for digital outputs (AVI info frame) according to CEA-861 on digital video outputs */
struct EMhwlibDigitalFrameInfo {
	/** Set to '1'. Used for future extension of this API */
	RMuint32 APIVersion;
	/** CEA-861 Video ID Code */
	RMuint32 VIC;
	/** Describes the video frame format and the picture content of the video frame */
	struct EMhwlibVideoFrameDescription Frame;
	/** RCI, CGMS and APS are not in the scope of this struct, they are set up separately in VSync IRQ handler */
};

/** store a rectangular window (e.g. VBI data) of each frame of the decoded video into a buffer. */
struct Input_VBIStore_type {
	/** horizontal position of the VBI window's left edge in the decoded video picture, range 0 -> 0xFFF */
	RMuint32 x;
	/** vertical position of the VBI window's top edge in the decoded video picture, range 0 -> 0xFFF */
	RMuint32 y;
	/** width of the VBI window in the decoded video picture, range 0 -> 0xFFF */
	RMuint32 w;
	/** height of the VBI window in the decoded video picture, range 0 -> 0xFFF */
	RMuint32 h;
	/** start address of the destination buffer in DRAM */
	RMuint32 Buffer;
	/** size of the destination buffer in DRAM @note 2 bytes per pixel are stored, plus 12 byte header information before each data block */
	RMuint32 BufferSize;
};

/** set up capture of video lines with raw VBI data (for Tango and up) */
struct Input_VBICaptureRaw_type {
	/** first line in top field where VBI data is expected */
	RMuint32 TopVBIOffset;
	/** bit mask for lines where VBI data is expected in top field (Bit0: line TopVBIOffset, Bit1: line TopVBIOffset+1, etc., 24 Bits) */
	RMuint32 TopVBILineEnable;
	/** first line in bottom field where VBI data is expected */
	RMuint32 BottomVBIOffset;
	/** bit mask for lines where VBI data is expected in bottom field (Bit0: line BottomVBIOffset, Bit1: line BottomVBIOffset+1, etc., 24 Bits) */
	RMuint32 BottomVBILineEnable;
	/** start address of the destination buffer in DRAM */
	RMuint32 Buffer;
	/** size of the destination buffer in DRAM @note 2 bytes per pixel are stored, plus 12 byte header information before each data block. give enough space for several buffers */
	RMuint32 BufferSize;
};

/** set up capture of ANC type sliced VBI data separate from 656 video capture (for Tango2 and up) */
struct Input_VBICaptureANC_type {
	/** TRUE: capture VBI data within horizontal blanking (656, ANC formatted) */
	RMbool Enable;
	/** ActiveWidth of VBI data window, in bytes (starts at first byte after EAV of line) */
	RMuint32 ActiveWidth;
	/** ActiveHeight of VBI data window, in lines */
	RMuint32 ActiveHeight;
	/** YOffsetTop of VBI data window, in lines */
	RMuint32 YOffsetTop;
	/** YOffsetBottom of VBI data window, in lines */
	RMuint32 YOffsetBottom;
	/** start address of the destination buffer in DRAM */
	RMuint32 Buffer;
	/** size of the destination buffer in DRAM @note 2 bytes per pixel are stored, plus 12 byte header information before each data block. give enough space for several buffers */
	RMuint32 BufferSize;
};

/** returns the next available block of VBI data. */
struct Input_VBIData_type {
	/** Flags for this data block. [0]:always 1, [1]:top field first */
	RMuint32 Flags;
	/** PTS when this VBI data block was received */
	RMuint32 PTS;
	/** size of the data block @note 2 bytes per pixel are stored */
	RMuint32 DataSize;
	/** starting at 1, the sequence number of the data chunk in case it doesn't fit into the Data[] param at once, or 0 for the final/only block */
	RMuint32 SequenceNumber;
	/** data block, up to 2048 bytes */
	RMuint16 Data[1024];
};

/** VBI data. */
struct Input_VBIReadbackI2C_type {
	/** raw i2c device address of the philips 7119, usually 0x20 or 0x21 */
	RMuint8 I2CDevice;
	/** i2c delay, usually 0 */
	RMuint8 I2CDelay;
	/** Wether to enable readback of 5 bytes ClosedCaption data after every frame */
	RMbool Enable_CC;
	/** Wether to enable readback of 7 bytes WideScreenSignalling data after every frame */
	RMbool Enable_WSS;
};


/** read several detected values to estimate input video format */
struct Input_Detect_type {
	/** 27 MHz ticks between two vsync interrupts */
	RMuint32 XtalPerField;
	/** pixel clock ticks between two vsync interrupts, 0 if not available @note set rclk_out in ClockMux property of SystemBlock to 7 to make this work */
	RMuint32 ClocksPerField;
	/** number of hsyncs per vsyncs, 0 if not available */
	RMuint32 LinesPerField;
	/** pixel clock ticks between two hsyncs, 0 if not available */
	RMuint32 ClocksPerLine;
};

/** use the signal from a GPIO pin to override the field ID in case it cannot determined correctly */
struct Input_GPIOFieldID_type {
	/** number of the GPIO pin from where to take the next field ID */
	enum GPIOId_type GPIONumber;
	/** whether to enable the feature */
	RMbool Enable;
	/** whether to invert the field ID */
	RMbool Invert;
};

/** Readback of ClosedCaption data from a capture chip over I2C */
struct EMhwlibInputReadbackI2CCC {
	RMuint32 APIVersion;  // set to 1
	RMbool Enable;        // TRUE: perform the readback operation
	RMuint32 Speed;       // I2C speed in kHz
	RMuint32 Delay;       // I2C delay in uSec
	RMuint8 WriteDevice;  // I2C device address for init command, or 0 to disable
	RMuint8 WriteSubAddr; // I2C sub address for init command
	RMuint8 WriteData;    // Byte to be written to WriteDevice:WriteSubAddr before every read
	RMuint8 ReadDevice;   // I2C device address for read access to data
	RMuint8 ReadSubAddr;  // I2C sub address
	RMuint32 ReadSize;    // data size (up to 32 bytes)
	RMuint32 OddStatusOffs;   // Odd field: CC valid = (data[OddStatusOffs] & OddStatusMask == OddStatusExpect)
	RMuint8 OddStatusMask;
	RMuint8 OddStatusExpect;
	RMuint32 OddByte1Offs;    // offset in data for CC byte 1.
	RMuint32 OddByte2Offs;    // offset in data for CC byte 2.
	RMuint32 EvenStatusOffs;  // Even field: CC valid = (data[EvenStatusOffs] & EvenStatusMask == EvenStatusExpect)
	RMuint8 EvenStatusMask;
	RMuint8 EvenStatusExpect;
	RMuint32 EvenByte1Offs;   // offset in data for CC byte 1.
	RMuint32 EvenByte2Offs;   // offset in data for CC byte 2.
};

#endif // __EMHWLIB_DISPLAYTYPES_H__
