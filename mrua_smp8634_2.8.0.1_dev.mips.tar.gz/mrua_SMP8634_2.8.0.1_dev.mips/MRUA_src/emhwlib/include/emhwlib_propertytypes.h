/******************************************************/
/* This file is generated automatically, DO NOT EDIT! */
/******************************************************/
/*
 * include/emhwlib_propertytypes.h
 *
 * Copyright (c) 2001-2003 Sigma Designs, Inc. 
 * All Rights Reserved. Proprietary and Confidential.
 *
 */
 
/**
  @file include/emhwlib_propertytypes.h
  @brief emhwlib generated file
   
  @author Jacques Mahe, Christian Wolff, Julien Soulier, Emmanuel Michon
  @ingroup hwlproperties
*/

#ifndef __EMHWLIB_PROPERTYTYPES_H__
#define __EMHWLIB_PROPERTYTYPES_H__

/** struct Default */
struct SystemBlock_GPIO_type {
	/** Member default */
	enum GPIOId_type Bit;
	/** Member default */
	RMbool Data;
};

/** control of the pulse width modulation generators on GPIO pins 14 and 15 */
struct SystemBlock_PWM_type {
	/** PWM generator number. @note 0 for GPIO 14, 1 for GPIO 15 range 0 -> 1 */
	RMuint32 GeneratorNumber;
	/** if TRUE, enables PWM generator on GPIO 14 or 15, overrides GPIO setting */
	RMbool Enable;
	/** Width of the high pulse, translates into a voltage level after a low pass filter range 0 -> 65535 */
	RMuint32 Level;
	/** system clock pre divider. @note The minimum pulse width is equal to 2 ^ (Log2Div + 1) system clock periods. range 0 -> 7 */
	RMuint32 Log2Div;
};

/** struct Default */
struct SystemBlock_DRAMConfig_type {
	/** Member default range 0 -> 2 */
	RMuint32 Controller;
	/** Member default range 0 -> 31 */
	RMuint32 refresh;
	/** Member default range 0 -> 7 */
	RMuint32 tRFC;
	/** Member default range 0 -> 7 */
	RMuint32 CCL;
	/** Member default range 0 -> 7 */
	RMuint32 DCL;
	/** Member default */
	RMbool d;
	/** Member default range 1 -> 3 */
	RMuint32 col;
	/** Member default */
	RMbool a;
	/** Member default */
	RMbool s;
};

/** struct Default */
struct SystemBlock_DRAMDelay_type {
	/** Member default range 0 -> 2 */
	RMuint32 Controller;
	/** Member default range 0 -> 15 */
	RMuint32 DQS0;
	/** Member default range 0 -> 15 */
	RMuint32 DQS1;
	/** Member default range 0 -> 15 */
	RMuint32 DQS2;
	/** Member default range 0 -> 15 */
	RMuint32 DQS3;
	/** Member default range 0 -> 15 */
	RMuint32 Dout;
};

/** struct Default */
struct SystemBlock_DRAMDelayAuto_type {
	/** Member default range 0 -> 2 */
	RMuint32 Controller;
	/** Member default range 0 -> 15 */
	RMuint32 DQS00;
	/** Member default range 0 -> 15 */
	RMuint32 DQS10;
	/** Member default range 0 -> 15 */
	RMuint32 DQS20;
	/** Member default range 0 -> 15 */
	RMuint32 DQS30;
	/** Member default range 0 -> 15 */
	RMuint32 Dout0;
	/** Member default range 0 -> 15 */
	RMuint32 DQS01;
	/** Member default range 0 -> 15 */
	RMuint32 DQS11;
	/** Member default range 0 -> 15 */
	RMuint32 DQS21;
	/** Member default range 0 -> 15 */
	RMuint32 DQS31;
	/** Member default range 0 -> 15 */
	RMuint32 Dout1;
	/** Member default range 0 -> 31 */
	RMuint32 RefMan;
	/** Member default */
	RMbool A;
	/** Member default range 0 -> 31 */
	RMuint32 RefAuto;
	/** Member default range 0 -> 15 */
	RMuint32 min;
	/** Member default range 0 -> 15 */
	RMuint32 range;
};

/** struct Default */
struct SystemBlock_BWMonitorSelection_type {
	/** Member default range 0 -> 1 */
	RMuint32 DRAMControllerId;
	/** Member default */
	RMuint8 ChannelA;
	/** Member default */
	RMuint8 ChannelB;
	/** Member default */
	RMuint8 ChannelC;
	/** Member default */
	RMuint8 ChannelD;
	/** Member default */
	RMuint32 AddressHi;
	/** Member default */
	RMuint32 AddressLo;
	/** Member default */
	RMuint8 ConfigId;
};

/** struct Default */
struct SystemBlock_BWMonitorEnable_type {
	/** Member default range 0 -> 1 */
	RMuint32 DRAMControllerId;
	/** Member default */
	RMbool Enable;
};

/** enum Default */
enum CPUBlock_State_type {
	/** In Enum default */
	CPUBlock_State_RUNNING = 0,
	/** In Enum default */
	CPUBlock_State_STOPPED = 1,
	/** In Enum default */
	CPUBlock_State_RESET = 2,
};

/** struct Default */
struct CPUBlock_ProcessInterrupt_type {
	/** Member default */
	RMuint32 status;
	/** Member default */
	void * context;
};

/** struct Default */
struct CPUBlock_AddDataFifoXferTask_type {
	/** Member default */
	RMuint32 task_address;
	/** Member default */
	RMuint32 priority;
	/** Member default */
	RMuint32 host_notification_threshold;
	/** Member default */
	enum TransferTaskCallback callback;
	/** Member default */
	void * context;
	/** Member default */
	RMuint32 data_fifo;
	/** Member default */
	RMuint32 data_mutex;
	/** Member default */
	RMuint32 pts_fifo;
	/** Member default */
	RMuint32 dmem_base;
	/** Member default */
	RMuint32 soft_irq_task_addr;
	/** Member default */
	enum TransferTaskDirection direction;
	/** Member default */
	enum TransferTaskFifoMode fifo_mode;
	/** Member default */
	RMuint32 size;
};

/** struct Default */
struct CPUBlock_AddRawDataXferTask_type {
	/** Member default */
	RMuint32 task_address;
	/** Member default */
	RMuint32 priority;
	/** Member default */
	RMuint32 host_notification_threshold;
	/** Member default */
	enum TransferTaskCallback callback;
	/** Member default */
	void * context;
	/** Member default */
	RMuint32 soft_irq_task_addr;
	/** Member default */
	enum TransferTaskDirection direction;
	/** Member default */
	RMuint32 size;
};

/** struct Default */
struct CPUBlock_AddSoftIrqTask_type {
	/** Member default */
	RMuint32 task_address;
	/** Member default */
	RMuint32 task_head;
	/** Member default */
	RMuint32 module_id;
	/** Member default */
	RMuint32 mutex;
	/** Member default */
	RMuint32 pMask;
	/** Member default */
	RMuint32 pStatus;
	/** Member default */
	RMuint32 status_fifo_addr;
};

/** struct Default */
struct CPUBlock_DataFifoChunk_type {
	/** Member default */
	RMuint32 task_address;
	/** Member default */
	RMuint32 src;
	/** Member default */
	RMuint32 size;
	/** Member default */
	void * context;
	/** Member default */
	RMuint32 pts;
	/** Member default */
	RMbool pts_valid;
	/** Member default */
	RMuint32 first_access_unit_pointer;
};

/** struct Default */
struct CPUBlock_RawDataChunk_type {
	/** Member default */
	RMuint32 task_address;
	/** Member default */
	RMuint32 src;
	/** Member default */
	RMuint32 size;
	/** Member default */
	void * context;
};

/** struct Default */
struct CPUBlock_AddDataFifoReadBuffer_type {
	/** Member default */
	RMuint32 task_address;
	/** Member default */
	RMuint32 src;
	/** Member default */
	RMuint32 size;
	/** Member default */
	void * context;
};

/** struct Default */
struct CPUBlock_AddRawDataReadBuffer_type {
	/** Member default */
	RMuint32 task_address;
	/** Member default */
	RMuint32 src;
	/** Member default */
	RMuint32 size;
	/** Member default */
	void * context;
};

/** struct Default */
struct CPUBlock_ProgramRawDataXfer_type {
	/** Member default */
	RMuint32 task_address;
	/** Member default */
	RMuint32 Address;
	/** Member default */
	RMuint32 Size;
	/** Member default */
	RMuint32 Width;
	/** Member default */
	RMuint32 TotalWidth;
	/** Member default */
	RMbool Tiled;
};

/** struct Default */
struct CPUBlock_Error_type {
	/** Member default */
	RMuint32 module_id;
	/** Member default */
	RMstatus error;
	/** Member default */
	RMuint32 time;
};

/** struct Default */
struct CPUBlock_EMhwlibError_type {
	/** Member default */
	RMuint32 module_id;
	/** Member default */
	RMstatus error;
	/** Member default */
	RMuint32 time;
};

/** struct Default */
struct CPUBlock_ReadBufferThreshold_type {
	/** Member default */
	RMuint32 task_address;
	/** Member default */
	RMuint32 threshold;
};

/** struct Default */
struct XPUBlock_Error_type {
	/** Member default */
	RMuint32 module_id;
	/** Member default */
	RMstatus error;
	/** Member default */
	RMuint32 time;
};

/** struct Default */
struct IPUBlock_Error_type {
	/** Member default */
	RMuint32 module_id;
	/** Member default */
	RMstatus error;
	/** Member default */
	RMuint32 time;
};

/** struct Default */
struct DisplayBlock_VsyncApiInfo_type {
	/** Member default */
	RMuint32 Address;
	/** Member default */
	RMuint32 Size;
};

/** initialize a picture fifo surface */
struct DisplayBlock_InitMultiplePictureSurface_type {
	/** format mode of the image */
	enum EMhwlibColorMode ColorMode;
	/** format submode of the image */
	enum EMhwlibColorFormat ColorFormat;
	/** Chroma mode of the image */
	enum EMhwlibSamplingMode SamplingMode;
	/** amount of data that has to be allocated by the application */
	RMuint32 Address;
	/** color space of the surface */
	enum EMhwlibColorSpace ColorSpace;
	/** pixel aspect ratio of the surface */
	struct EMhwlibAspectRatio PixelAspectRatio;
	/** number of pictures in the FIFO */
	RMuint32 PictureCount;
	/** index of the STC module */
	RMuint32 STCModuleId;
};

/** initialize a picture fifo surface */
struct DisplayBlock_InitMultiplePictureSurfaceX_type {
	/** format mode of the image */
	enum EMhwlibColorMode ColorMode;
	/** format submode of the image */
	enum EMhwlibColorFormat ColorFormat;
	/** Chroma mode of the image */
	enum EMhwlibSamplingMode SamplingMode;
	/** amount of data that has to be allocated by the application */
	RMuint32 Address;
	/** color space of the surface */
	enum EMhwlibColorSpace ColorSpace;
	/** pixel aspect ratio of the surface */
	struct EMhwlibAspectRatio PixelAspectRatio;
	/** number of pictures in the FIFO */
	RMuint32 PictureCount;
	/** index of the STC module */
	RMuint32 STCModuleId;
	/** TRUE is tiled pictures, FALSE is linear pictures */
	RMbool Tiled;
};

/** insert a picture inside the surface picture's fifo */
struct DisplayBlock_InsertPictureInSurfaceFifo_type {
	/** surface to insert the picture to */
	RMuint32 Surface;
	/** picture to insert in the surface's Fifo */
	RMuint32 Picture;
	/** pts of the inserted picture */
	RMuint64 Pts;
};

/** insert a picture inside the surface picture's fifo */
struct DisplayBlock_SetPaletteOnPicture_type {
	/** picture to insert in the surface's Fifo */
	RMuint32 Picture;
	/** picture to insert in the surface's Fifo */
	RMpalette_8BPP Palette;
	/** picture to insert in the surface's Fifo */
	RMuint32 PaletteSize;
};

/** initialize a static surface */
struct DisplayBlock_SurfaceAspectRatio_type {
	/** Member default */
	RMuint32 surface;
	/** picture aspect ratio (default), pixel aspect ratio or display aspect ratio */
	enum EMhwlibAspectRatioType type;
	/** pixel or display aspect ratio of the surface, value ignored when picture aspect ratio is selected as type */
	struct EMhwlibAspectRatio ar;
};

/** Set/Get the STC Module ID attached to a surface */
struct DisplayBlock_SurfaceSTC_type {
	/** Member default */
	RMuint32 surface;
	/** Member default */
	RMuint32 STCModuleId;
};

/** force the picture buffer address */
struct DisplayBlock_ForcePictureBufferAddress_type {
	/** Member default */
	RMuint32 Surface;
	/** Member default */
	RMuint32 LumaAddress;
	/** Member default */
	RMuint32 ChromaAddress;
};

/** initialize a static surface */
struct DisplayBlock_EnableGFXInteraction_type {
	/** Member default */
	RMuint32 Surface;
	/** Member default */
	RMbool Enable;
};

/** Configure which GPIO pin at which polarity is used with property AlternateOutput */
struct DisplayBlock_AltOutConfig_type {
	/** number of the GPIO pin used to switch the alternate output, -1 to disable GPIO usage */
	RMint32 GPIO;
	/** Polarity the GPIO, FALSE: GPIO-High switches to the alternate out, TRUE: GPIO-Low switches to the alternate out */
	RMbool Invert;
};

/**  */
struct DisplayBlock_AnalogSDParams_type {
	/** gbus address of struct vsync_analog_SD_registers */
	struct vsync_analog_SD_registers * Struct;
	/** Member default */
	struct EMhwlibTVFormatAnalog * Format;
};

/**  */
struct DisplayBlock_AnalogHDParams_type {
	/** gbus address of struct vsync_analog_HD_registers */
	struct vsync_analog_HD_registers * Struct;
	/** Member default */
	struct EMhwlibTVFormatAnalog * Format;
};

/**  */
struct DisplayBlock_AnalogOffsetParams_type {
	/** gbus address of struct vsync_analog_Offset_registers */
	struct vsync_analog_Offset_registers * Struct;
	/** Member default */
	struct EMhwlibTVFormatAnalog * Format;
};

/**  */
struct DisplayBlock_DigitalParams_type {
	/** gbus address of struct vsync_digital_registers */
	struct vsync_digital_registers * Struct;
	/** Member default */
	struct EMhwlibTVFormatDigital * Format;
};

/** @note Used to program the VBUS bandwidth arbiter */
struct DisplayBlock_VBUSBandwidth_type {
	/** Member default */
	struct BWArbiterParam VideoIn;
	/** Member default */
	struct BWArbiterParam GraphicsIn;
	/** Member default */
	struct BWArbiterParam MainVideoScalerLuma;
	/** Member default */
	struct BWArbiterParam MainVideoScalerChroma;
	/** Member default */
	struct BWArbiterParam GFXScalerLuma;
	/** Member default */
	struct BWArbiterParam GFXScalerChroma;
	/** Member default */
	struct BWArbiterParam VCRScalerLuma;
	/** Member default */
	struct BWArbiterParam VCRScalerChroma;
	/** Member default */
	struct BWArbiterParam CRTScalerLuma;
	/** Member default */
	struct BWArbiterParam CRTScalerChroma;
	/** Member default */
	struct BWArbiterParam OSDScaler;
	/** Member default */
	struct BWArbiterParam SPUScaler;
	/** Member default */
	struct BWArbiterParam GFXEngineX;
	/** Member default */
	struct BWArbiterParam GFXEngineY;
	/** Member default */
	struct BWArbiterParam GFXEngineNX;
};

/** enum Default */
enum DisplayBlock_HDMIState_type {
	/** Normal operation */
	DisplayBlock_HDMIState_Running = 0,
	/** Reset HDMI configuration in SiI9030 */
	DisplayBlock_HDMIState_ResetHDMI = 1,
	/** Reset I2C block and key memeory @note: don't use from CPU, if keymem is protected */
	DisplayBlock_HDMIState_ResetKeymemI2C = 2,
	/** Reset complete SiI9030, I2C and keymem @note: don't use from CPU, if keymem is protected */
	DisplayBlock_HDMIState_ResetConfig = 3,
};

/** struct Default */
struct DisplayBlock_HDMIConfig_type {
	/** HDMI clk divider @note: FALSE = clk, TRUE = clk / 2 */
	RMbool ClkDiv;
	/** State of the external physical transmitter @note: FALSE = power down, TRUE = normal operation */
	RMbool PowerUpPhy;
	/** Selects which pads are routet to the VO0 output pins @note: FALSE = DigitalOut (bypassing HDMI), TRUE = HDMI */
	RMbool OutputSelect;
	/** Whether to invert the audio SClk @note: FALSE = not inverted, TRUE = inverted */
	RMbool AudioClkInv;
};

/** struct Default */
struct DisplayBlock_PixelClock_type {
	/** ModuleID of the output block */
	RMuint32 OutputModuleID;
	/** Frequency of the pixel clock needed at the output block */
	RMuint32 PixelClock;
	/** PLL to be used (PLL or CD) */
	enum PLLGen PLL;
	/** PLL output to be used */
	enum PLLOut PLLOut;
	/** Whether the pixel clock for the Analog output for this mode is 4 times oversampled */
	RMbool Analog4XOver;
	/** Pointer (Has to be effectively a GBus address) to the PLL register struct in the Info struct */
	struct PLLRegSet * pConfigPLL;
};

/** struct Default */
struct DisplayBlock_SurfaceDefaultColorSpaceAlgorithm_type {
	/** surface to set the default colorspace algo */
	RMuint32 Surface;
	/** default colorspace algorithm */
	enum EMhwlibDefaultColorSpaceAlgorithm Algorithm;
};

/** Sets the OSD scaling mode */
struct DispOSDScaler_ScalingConfig_type {
	/** Member default */
	RMbool AdaptativeEnable;
	/** Member default range 0 -> 1 */
	RMuint32 Taps;
	/** Member default range 0 -> 3 */
	RMuint32 AntiFlickerColor;
	/** Member default range 0 -> 3 */
	RMuint32 AntiFlickerAlpha;
};

/** struct Default */
struct DispHardwareCursor_Size_type {
	/** Horizontal dimension of the cursor range 0 -> 255 */
	RMuint32 Width;
	/** Vertical dimension of the cursor range 0 -> 255 */
	RMuint32 Height;
};

/** Sets the proportion of field N-1 to generate frame N */
struct DispMainVideoScaler_DeinterlacingProportion_type {
	/** Member default range 0 -> 16 */
	RMuint32 NewLineProportion;
	/** Member default range 0 -> 16 */
	RMuint32 ExistingLineProportion;
};

/** Sets the alpha motion modulation function */
struct DispMainVideoScaler_DeinterlacingMotionConfig_type {
	/** Member default range 0 -> 255 */
	RMuint32 Value0;
	/** Member default range 0 -> 255 */
	RMuint32 Value8;
	/** Member default range 0 -> 255 */
	RMuint32 Value16;
	/** Member default range 0 -> 255 */
	RMuint32 Value32;
};

/** Sets the scaling filter selection boundaries */
struct DispMainVideoScaler_FilterSelection_type {
	/** Member default */
	RMuint32 Boundary_0_1;
	/** Member default */
	RMuint32 Boundary_1_2;
	/** Member default */
	RMuint32 Boundary_2_3;
};

/** Sets the SPU scaling mode */
struct DispSubPictureScaler_ScalingConfig_type {
	/** Member default */
	RMbool AdaptativeEnable;
	/** Member default range 0 -> 3 */
	RMuint32 AntiFlickerColor;
	/** Member default range 0 -> 3 */
	RMuint32 AntiFlickerAlpha;
};

/** @note Only a maximum of 4 planes can be blended per pixel. A transparent pixel is not considered as alpha blended.@note Layer 7 is reserved for the Hardware Cursor */
struct DispMainMixer_LayerOrder_type {
	/** Top alpha layer */
	RMuint32 Layer6SourceModuleID;
	/** Member default */
	RMuint32 Layer5SourceModuleID;
	/** Member default */
	RMuint32 Layer4SourceModuleID;
	/** Member default */
	RMuint32 Layer3SourceModuleID;
	/** Member default */
	RMuint32 Layer2SourceModuleID;
	/** Member default */
	RMuint32 Layer1SourceModuleID;
	/** Bottom alpha layer */
	RMuint32 Layer0SourceModuleID;
};

/** @note Only a maximum of 4 planes can be blended per pixel. A transparent pixel is not considered as alpha blended.@note Layer 7 is reserved for the Hardware Cursor */
struct DispVCRMixer_LayerOrder_type {
	/** Member default */
	RMuint32 Layer3SourceModuleID;
	/** Member default */
	RMuint32 Layer2SourceModuleID;
	/** Member default */
	RMuint32 Layer1SourceModuleID;
	/** Bottom alpha layer */
	RMuint32 Layer0SourceModuleID;
};

/** struct Default */
struct DispRouting_Route_type {
	/** Member default */
	RMuint32 SourceModuleID;
	/** Member default */
	RMuint32 DestinationModuleID;
	/** Member default */
	RMuint32 Enable;
};

/** struct Default */
struct DispRouting_Routing_type {
	/** Member default */
	RMbool DigitalOutputEnable;
	/** Member default */
	RMuint32 DigitalOutputSourceModuleID;
	/** Member default */
	RMbool MainAnalogOutputEnable;
	/** Member default */
	RMuint32 MainAnalogOutputSourceModuleID;
	/** Member default */
	RMbool ComponentOutputEnable;
	/** Member default */
	RMuint32 ComponentOutputSourceModuleID;
	/** Member default */
	RMbool CompositeOutputEnable;
	/** Member default */
	RMuint32 CompositeOutputSourceModuleID;
};

/** struct Default */
struct DispVideoInput_Open_type {
	/** format mode of the image */
	enum EMhwlibColorMode ColorMode;
	/** format submode of the image */
	enum EMhwlibColorFormat ColorFormat;
	/** Chroma mode of the image */
	enum EMhwlibSamplingMode SamplingMode;
	/** width of the image in pixel range 0 -> 4095 */
	RMuint32 Width;
	/** height of the image in pixel range 0 -> 4095 */
	RMuint32 Height;
	/** number of picture buffers range 0 -> 10 */
	RMuint32 NumBuffer;
	/** adress of data that was allocated by the application */
	RMuint32 BufferAddress;
	/** amount of data that was allocated by the application */
	RMuint32 BufferSize;
	/** color space of the surface */
	enum EMhwlibColorSpace ColorSpace;
	/** pixel aspect ratio of the surface */
	struct EMhwlibAspectRatio PixelAspectRatio;
	/** Number of the STC timer used for this input */
	RMuint32 STCIndex;
};

/** struct Default */
struct DispVideoInput_InputFormat_type {
	/** Member default */
	RMbool ProtocolV;
	/** Member default */
	RMbool ProtocolM;
	/** Member default */
	RMbool ComponentOrderReverse;
	/** Member default */
	RMbool TrailingEdge;
	/** Member default */
	RMbool VSyncDelay;
};

/** struct Default */
struct DispGraphicInput_Open_type {
	/** format mode of the image */
	enum EMhwlibColorMode ColorMode;
	/** format submode of the image */
	enum EMhwlibColorFormat ColorFormat;
	/** Chroma mode of the image */
	enum EMhwlibSamplingMode SamplingMode;
	/** width of the image in pixel range 0 -> 4095 */
	RMuint32 Width;
	/** height of the image in pixel range 0 -> 4095 */
	RMuint32 Height;
	/** number of picture buffers range 0 -> 10 */
	RMuint32 NumBuffer;
	/** adress of data that was allocated by the application */
	RMuint32 BufferAddress;
	/** amount of data that was allocated by the application */
	RMuint32 BufferSize;
	/** color space of the surface */
	enum EMhwlibColorSpace ColorSpace;
	/** pixel aspect ratio of the surface */
	struct EMhwlibAspectRatio PixelAspectRatio;
	/** Number of the STC timer used for this input */
	RMuint32 STCIndex;
};

/** Subset for video input. For all features of graphics input, use Format property. */
struct DispGraphicInput_InputFormat_type {
	/** Member default */
	enum EMhwlibInputColorFormat InputColorFormat;
	/** Member default */
	RMbool ProtocolV;
	/** Member default */
	RMbool ProtocolL;
	/** Member default */
	RMbool ProtocolP;
	/** Member default */
	RMbool ComponentOrderRBG;
	/** Member default */
	RMbool TrailingEdge;
	/** Member default */
	RMbool VSyncDelay;
};

/** Specifies the output surface characteristics */
struct DispGraphicInput_OutputFormat_type {
	/** Member default */
	RMuint32 OutRouteModuleID;
	/** storage size of a pixel, 8, 16 or 32 bit range 8 -> 32 */
	RMuint32 BusSize;
	/** Member default range 0 -> 255 */
	RMuint32 Alpha0;
	/** Member default range 0 -> 255 */
	RMuint32 Alpha1;
	/** Member default */
	RMbool FadingEnable;
	/** Member default */
	RMbool DualEdgeInvert;
	/** Member default */
	RMbool DualEdge;
	/** Member default */
	RMbool DualEdgeWidth;
};

/** struct Default */
struct DispGraphicInput_KeyColor_type {
	/** Member default */
	RMbool KeyEnable;
	/** Member default range 0 -> 255 */
	RMuint32 KeyColorRCr;
	/** Member default range 0 -> 255 */
	RMuint32 KeyColorGY;
	/** Member default range 0 -> 255 */
	RMuint32 KeyColorBCb;
	/** Member default range 0 -> 15 */
	RMuint32 KeyColorRange;
};

/** Luma or RGB components are clipped between 16 and 235, chroma is clipped from 16 to 240, if active. */
enum DispDigitalOut_ClippingLevel_type {
	/** In Enum default */
	DispDigitalOut_ClippingLevel_Clip_16_240 = 1,
	/** In Enum default */
	DispDigitalOut_ClippingLevel_Clip_1_254 = 2,
};

/** Several output options - OBSOLETE, use PadsControl/QueryPadsControl instead! */
struct DispDigitalOut_PadsConfig_type {
	/** Member default */
	RMbool InvertClock;
	/** Member default */
	RMbool DDRdout;
	/** Member default */
	RMbool InvertCaptureClock;
	/** Member default range 0 -> 7 */
	RMuint32 DDRdelay;
	/** Member default */
	RMbool DisableDataDelay;
};

/** Several input options - OBSOLETE, use PadsControl/QueryPadsControl instead! */
struct DispDigitalOut_InputPadsConfig_type {
	/** Select V2 pads as the input pins for the DispVideoInput */
	RMbool VideoInputV2;
	/** Select V2 pads as the input pins for the DispGraphicInput */
	RMbool GraphicInputV2;
};

/** Several options for the digital input and output ports */
struct DispDigitalOut_PadsControl_type {
	/** version of this struct. set to 1 */
	RMuint32 APIVersion;
	/** Member default */
	RMbool ModifyInvertClock;
	/** Member default */
	RMbool InvertClock;
	/** Member default */
	RMbool ModifyDDRdout;
	/** Member default */
	RMbool DDRdout;
	/** Member default */
	RMbool ModifyInvertCaptureClock;
	/** Member default */
	RMbool InvertCaptureClock;
	/** Member default */
	RMbool ModifyDelay;
	/** in pSec range 0 -> 6300 */
	RMuint32 Delay;
	/** Member default */
	RMbool ModifyVideoInputV2;
	/** Select V2 pads as the input pins for the DispVideoInput */
	RMbool VideoInputV2;
	/** Member default */
	RMbool ModifyGraphicInputV2;
	/** Select V2 pads as the input pins for the DispGraphicInput */
	RMbool GraphicInputV2;
	/** Member default */
	RMbool ModifySCARTControl;
	/** Member default range 0 -> 3 */
	RMuint32 SCARTControl;
	/** Member default */
	RMbool ModifyPadsLoop;
	/** Connects the digital output to the both inputs */
	RMbool PadsLoop;
};

/** struct Default */
struct DispDigitalOut_TimingResetMaster_type {
	/** Member default */
	RMuint32 ResetSourceID;
	/** Member default */
	RMuint32 DelayLines;
	/** Member default */
	RMuint32 DelayPixels;
};

/** struct Default */
struct DispDigitalOut_GPIOFieldID_type {
	/** number of the GPIO pin where to output the next field ID */
	RMuint32 GPIONumber;
	/** delay after vsync start in 27 MHz clocks, set to 0 to disable */
	RMuint32 Delay;
};

/** Retreive the xtal counter value at the time of each input and output vsync resp. frame start */
struct DispDigitalOut_VSyncTimes_type {
	/** Member default */
	RMVSyncXtal VSyncTime;
	/** Member default */
	RMVSyncXtal FrameTime;
};

/** struct Default */
struct DispMainAnalogOut_TimingResetMaster_type {
	/** Member default */
	RMuint32 ResetSourceID;
	/** Member default */
	RMuint32 DelayLines;
	/** Member default */
	RMuint32 DelayPixels;
};

/** struct Default */
struct DispComponentOut_TimingResetMaster_type {
	/** Member default */
	RMuint32 ResetSourceID;
	/** Member default */
	RMuint32 DelayLines;
	/** Member default */
	RMuint32 DelayPixels;
};

/** struct Default */
struct DemuxEngine_Microcode_type {
	/** Member default */
	RMuint32 MicrocodeVersion;
	/** Member default */
	RMuint32 Address;
};

/** struct Default */
struct MpegEngine_Microcode_type {
	/** Member default */
	RMuint32 MicrocodeVersion;
	/** Member default */
	RMuint32 Address;
};

/** struct Default */
struct MpegEngine_DecoderSharedMemory_type {
	/** DRAM shared by all decoders on the MpegEngine */
	RMuint32 Address;
	/** Member default */
	RMuint32 Size;
};

/** struct Default */
struct MpegEngine_SchedulerSharedMemory_type {
	/** DRAM used for task table */
	RMuint32 Address;
	/** Member default */
	RMuint32 Size;
};

/** connect/disconnect video/spu tasks to mpeg engine. */
struct MpegEngine_ConnectTask_type {
	/** Member default */
	RMbool connect;
	/**  */
	RMuint32 task_index;
};

/** struct Default */
struct VideoDecoder_Open_type {
	/** Member default */
	enum MPEG_Profile MPEGProfile;
	/** Member default */
	RMuint32 BitstreamFIFOSize;
	/** Member default */
	RMuint32 XferFIFOCount;
	/** Member default */
	RMuint32 CachedAddress;
	/** Member default */
	RMuint32 CachedSize;
	/** Member default */
	RMuint32 UncachedAddress;
	/** Member default */
	RMuint32 UncachedSize;
	/** index of DemuxProgram */
	RMuint32 DemuxProgramId;
	/** index of STC */
	RMuint32 TimerId;
};

/** Selects the type of video codec. The value should be supported by MPEG_profile selected at Open.@note The maximum codec value (MPEG4_HD) corresponds to the maximum DRAM reqirement. @li The video codec can be selected in stop mode and it should be followed by Init command. */
enum VideoDecoder_Codec_type {
	/** Selects video MPEG2_SD */
	VideoDecoder_Codec_MPEG2_SD = Profile_MPEG2_SD,
	/** Selects video MPEG2_DVD */
	VideoDecoder_Codec_MPEG2_DVD = Profile_MPEG2_DVD,
	/** Selects video MPEG2_HD */
	VideoDecoder_Codec_MPEG2_HD = Profile_MPEG2_HD,
	/** Selects video MPEG4_SD */
	VideoDecoder_Codec_MPEG4_SD = Profile_MPEG4_SD,
	/** Selects video MPEG4_SD_Padding */
	VideoDecoder_Codec_MPEG4_SD_Padding = Profile_MPEG4_SD_Padding,
	/** Selects video MPEG4_HD */
	VideoDecoder_Codec_MPEG4_HD = Profile_MPEG4_HD,
	/** Selects video MPEG4_HD_Padding */
	VideoDecoder_Codec_MPEG4_HD_Padding = Profile_MPEG4_HD_Padding,
	/** Selects video MPEG2_SD */
	VideoDecoder_Codec_MPEG2_SD_Packed = Profile_MPEG2_SD_Packed,
	/** Selects video MPEG2_DVD */
	VideoDecoder_Codec_MPEG2_DVD_Packed = Profile_MPEG2_DVD_Packed,
	/** Selects video MPEG2_HD */
	VideoDecoder_Codec_MPEG2_HD_Packed = Profile_MPEG2_HD_Packed,
	/** Selects video MPEG4_SD */
	VideoDecoder_Codec_MPEG4_SD_Packed = Profile_MPEG4_SD_Packed,
	/** Selects video MPEG4_HD */
	VideoDecoder_Codec_MPEG4_HD_Packed = Profile_MPEG4_HD_Packed,
	/** Selects video MPEG2_SD */
	VideoDecoder_Codec_MPEG2_SD_DeInt = Profile_MPEG2_SD_DeInt,
	/** Selects video MPEG2_DVD */
	VideoDecoder_Codec_MPEG2_DVD_DeInt = Profile_MPEG2_DVD_DeInt,
	/** Selects video MPEG2_HD */
	VideoDecoder_Codec_MPEG2_HD_DeInt = Profile_MPEG2_HD_DeInt,
	/** Selects video MPEG4_SD */
	VideoDecoder_Codec_MPEG4_SD_DeInt = Profile_MPEG4_SD_DeInt,
	/** Selects video MPEG4_SD_Padding */
	VideoDecoder_Codec_MPEG4_SD_DeInt_Padding = Profile_MPEG4_SD_DeInt_Padding,
	/** Selects video MPEG4_HD */
	VideoDecoder_Codec_MPEG4_HD_DeInt = Profile_MPEG4_HD_DeInt,
	/** Selects video MPEG4_HD_Padding */
	VideoDecoder_Codec_MPEG4_HD_DeInt_Padding = Profile_MPEG4_HD_DeInt_Padding,
	/** Selects video MPEG2_SD */
	VideoDecoder_Codec_MPEG2_SD_Packed_DeInt = Profile_MPEG2_SD_Packed_DeInt,
	/** Selects video MPEG2_DVD */
	VideoDecoder_Codec_MPEG2_DVD_Packed_DeInt = Profile_MPEG2_DVD_Packed_DeInt,
	/** Selects video MPEG2_HD */
	VideoDecoder_Codec_MPEG2_HD_Packed_DeInt = Profile_MPEG2_HD_Packed_DeInt,
	/** Selects video MPEG4_SD */
	VideoDecoder_Codec_MPEG4_SD_Packed_DeInt = Profile_MPEG4_SD_Packed_DeInt,
	/** Selects video MPEG4_HD */
	VideoDecoder_Codec_MPEG4_HD_Packed_DeInt = Profile_MPEG4_HD_Packed_DeInt,
	/** Selects video WMV_SD */
	VideoDecoder_Codec_WMV_SD = Profile_WMV_SD,
	/** Selects video WMV_816P */
	VideoDecoder_Codec_WMV_816P = Profile_WMV_816P,
	/** Selects video WMV_HD */
	VideoDecoder_Codec_WMV_HD = Profile_WMV_HD,
	/** Selects video DIVX3_SD */
	VideoDecoder_Codec_DIVX3_SD = Profile_DIVX3_SD,
	/** Selects video DIVX3_HD */
	VideoDecoder_Codec_DIVX3_HD = Profile_DIVX3_HD,
	/** Selects video DIVX3_SD */
	VideoDecoder_Codec_DIVX3_SD_Packed = Profile_DIVX3_SD_Packed,
	/** Selects video DIVX3_HD */
	VideoDecoder_Codec_DIVX3_HD_Packed = Profile_DIVX3_HD_Packed,
	/** Selects video H264_SD */
	VideoDecoder_Codec_H264_SD = Profile_H264_SD,
	/** Selects video H264_HD */
	VideoDecoder_Codec_H264_HD = Profile_H264_HD,
	/** Selects video H264_SD */
	VideoDecoder_Codec_H264_SD_DeInt = Profile_H264_SD_DeInt,
	/** Selects video H264_HD */
	VideoDecoder_Codec_H264_HD_DeInt = Profile_H264_HD_DeInt,
	/** Selects video VC1_SD */
	VideoDecoder_Codec_VC1_SD = Profile_VC1_SD,
	/** Selects video VC1_HD */
	VideoDecoder_Codec_VC1_HD = Profile_VC1_HD,
};

/** enum Default */
enum VideoDecoder_Command_type {
	/** In Enum default */
	VideoDecoder_Command_Uninit,
	/** results in state 'InitPending' and then state 'Stop' */
	VideoDecoder_Command_Init,
	/** In Enum default */
	VideoDecoder_Command_Stop,
	/** In Enum default */
	VideoDecoder_Command_PlayFwd,
	/** Play a GOP backward. Unsupported for now */
	VideoDecoder_Command_PlayBwd,
	/** Decode only I Frames.@note Forward/Backward playback of I frames is handled in the display */
	VideoDecoder_Command_PlayIFrame,
	/** In Enum default */
	VideoDecoder_Command_DecodeFwdToEvent,
};

/** enum Default */
enum VideoDecoder_State_type {
	/** In Enum default */
	VideoDecoder_State_Uninit,
	/** In Enum default */
	VideoDecoder_State_UninitPending,
	/** results in state 'Stop' */
	VideoDecoder_State_InitPending,
	/** In Enum default */
	VideoDecoder_State_Stop,
	/** In Enum default */
	VideoDecoder_State_StopPending,
	/** In Enum default */
	VideoDecoder_State_PlayFwd,
	/** In Enum default */
	VideoDecoder_State_PlayFwdPending,
	/** In Enum default */
	VideoDecoder_State_PlayBwd,
	/** In Enum default */
	VideoDecoder_State_PlayBwdPending,
	/** In Enum default */
	VideoDecoder_State_PlayIFrame,
	/** In Enum default */
	VideoDecoder_State_PlayIFramePending,
	/** In Enum default */
	VideoDecoder_State_DecodeFwdToEvent,
	/** In Enum default */
	VideoDecoder_State_DecodeFwdToEventPending,
};

/** struct Default */
struct VideoDecoder_VopInfo_type {
	/** Number of ticks per second, used only for mpeg4 video. The DSI packet has to parsed in order to obtain VopTimeIncrementResolution. */
	RMuint32 VopTimeIncrementResolution;
	/** Used only for mpeg4 video. If TRUE video will play at fixed rate = VopTimeIncrementResolution/FixedVopTimeIncrement */
	RMbool FixedVopRate;
	/** Used only for mpeg4 video. If TRUE video will play at fixed rate = VopTimeIncrementResolution/FixedVopTimeIncrement */
	RMuint32 FixedVopTimeIncrement;
};

/** struct Default */
struct VideoDecoder_VideoTimeScale_type {
	/** If TRUE, VideoTimeScale replaces the VopTimeIncrementResolution (from DSI or from user fixed rate). */
	RMbool enable;
	/** Number of ticks per second, defining the time stamp unit. Used only for mpeg4 video. For EM8620L only values of 16 bit are supported. */
	RMuint32 time_resolution;
};

/** struct Default */
struct VideoDecoder_WMV9VSProp_type {
	/** Member default */
	RMuint32 Sequence;
	/** Member default */
	RMuint16 Image_Width;
	/** Member default */
	RMuint16 Image_Height;
	/** Member default */
	RMuint16 MB_Width;
	/** Member default */
	RMuint16 MB_Height;
};

/** struct Default */
struct VideoDecoder_DIVX3VSProp_type {
	/** Member default */
	RMuint16 Image_Width;
	/** Member default */
	RMuint16 Image_Height;
};

/** force the color space of the video source */
struct VideoDecoder_ForceColorSpace_type {
	/** force or not the color space */
	RMbool Enable;
	/** color space to force */
	enum EMhwlibColorSpace ColorSpace;
};

/** struct Default */
struct VideoDecoder_OpenX_type {
	/**  */
	RMuint32 ProtectedFlags;
	/** input video stream data fifo */
	RMuint32 BitstreamFIFOSize;
	/** data fifo needed for decoder to dump the user data embedded in video stream */
	RMuint32 UserDataSize;
	/** total data size needed for decoder for picture buffers and context */
	RMuint32 DecoderDataSize;
	/** decoder context memory - to be calculated inside microcode and removed from interface */
	RMuint32 DecoderContextSize;
	/** number of buffers needed for deinterlacing, gfx access.  By default emhwlib reserves two extra buffers for display and vsync. In order to renounce to them negative numbers of -1, -2 are accepted. */
	RMint32 ExtraPictureBufferCount;
	/** Member default */
	RMuint32 XferFIFOCount;
	/** Member default */
	RMuint32 PtsFIFOCount;
	/** Member default */
	RMuint32 InbandFIFOCount;
	/** Member default */
	RMuint32 XtaskInbandFIFOCount;
	/** index of STC */
	RMuint32 STCId;
	/** index of Xtask module */
	RMuint32 XtaskId;
	/** Member default */
	RMuint32 PictureProtectedAddress;
	/** Member default */
	RMuint32 PictureProtectedSize;
	/** Member default */
	RMuint32 BitstreamProtectedAddress;
	/** Member default */
	RMuint32 BitstreamProtectedSize;
	/** Member default */
	RMuint32 UnprotectedAddress;
	/** Member default */
	RMuint32 UnprotectedSize;
};

/** struct Default */
struct VideoDecoder_AnchorErrPropagation_type {
	/**  */
	RMuint32 AnchorErrPropagationThreshold;
	/**  */
	RMuint32 AnchorErrPropagationLength;
};

/** Select and load the Audio DSP microcode. @note @li This property should be called only when the DSP is in stopped state.\n @li Use the ::RMAudioEnginePropertyID_MicrocodeDRAMSize  property followed by a call to ::RUAMalloc to allocate the memory specified by the Address parameter */
struct AudioEngine_Microcode_type {
	/** @li 1 == Audio microcode handling PCM, AC3, MPEG Layer 1, 2 and 3 (mp3) Audio codecs.@li 4 == XCRC 32 bit test microcode used to test DMA transfers, interrupt mechanisms... */
	RMuint32 MicrocodeVersion;
	/** DRAM location where mirocrocode overlays and data will be stored */
	RMuint32 Address;
};

/** Extended version of property SampleFrequency. @note SampleFrequency is the same as SampleFrequencyFromSource, with GeneratorNumber = 3, Source = 1 (XtalIn) at 27MHz and IntermediateFrequency = 148500000. */
struct AudioEngine_SampleFrequencyFromSource_type {
	/** Number of the PLL */
	RMuint32 GeneratorNumber;
	/** Sample frequency in Hz */
	RMuint32 SampleFrequency;
	/** Intermediate PLL output frequency. Needs to be 148500000 for AC3 decoding, should be multiple of SampleFrequency for others. */
	RMuint32 IntermediateFrequency;
	/** PLL clock source: 1=XtalIn, 2=VCXO0, 3=VCXO1, 4=RClkIn0, 5=RClkIn1, 6=Vi0In (GraphicInput), 7=Vi1In (VideoInput). */
	RMuint32 Source;
	/** nominal Frequency of the source (e.g. 27000000 for XtalIn) */
	RMuint32 SourceFrequency;
};

/** Set audio output channel FIFO volume.@li Increasing the audio volume above 0db may cause distortion (cropping) on the audio output depending on the audio source.@li This volume is the master output volume for the specified channel. Even though this volume will be applied to 2 audio decoders, there are currently no way to control the volume separately on these 2 decoders. */
struct AudioEngine_Volume_type {
	/** Defines the targeted output channel from 0 to (N-1) channels. range 0 -> 11 */
	RMuint32 Channel;
	/** Specifies the audio attenuation from +24db to -infinite. 0db is represented by Volume=0x10000000. Shifting this value by 1 bit on the left will increase the volume by 6db. Maximum gain is 0xFFFFFFFF ~=24db. Shifting the 0db value by 1 bit on the right will decrease the volume by 6db until the value reaches 0 (infinite, i.e. mute). @note @li Volume is a 4.28 fix point number. Volume = 0x10000000 * 2^(Gain/6), where Gain has unit dB. range 0 -> 0xFFFFFFFF */
	RMuint32 Volume;
};

/** Set audio output channel FIFO volume.@li Increasing the audio volume above 0db may cause distortion (cropping) on the audio output depending on the audio source.@li This volume is the master output volume for the specified channel. Even though this volume will be applied to 2 audio decoders, there are currently no way to control the volume separately on these 2 decoders. */
struct AudioEngine_Delay_type {
	/** Specifies the audio channel delay from 0 to 330 step=0.1 ms. range 0 -> 330 */
	RMuint32 Delay_ch0;
	/** Specifies the audio channel delay from 0 to 330 step=0.1 ms. range 0 -> 330 */
	RMuint32 Delay_ch1;
	/** Specifies the audio channel delay from 0 to 330 step=0.1 ms. range 0 -> 330 */
	RMuint32 Delay_ch2;
	/** Specifies the audio channel delay from 0 to 330 step=0.1 ms. range 0 -> 330 */
	RMuint32 Delay_ch3;
	/** Specifies the audio channel delay from 0 to 330 step=0.1 ms. range 0 -> 330 */
	RMuint32 Delay_ch4;
	/** Specifies the audio channel delay from 0 to 330 step=0.1 ms. range 0 -> 330 */
	RMuint32 Delay_ch5;
	/** Specifies the audio channel delay from 0 to 330 step=0.1 ms. range 0 -> 330 */
	RMuint32 Delay_ch6;
	/** Specifies the audio channel delay from 0 to 330 step=0.1 ms. range 0 -> 330 */
	RMuint32 Delay_ch7;
	/** Specifies the audio sample frequency. range 8000 -> 192000 */
	RMuint32 sample_frequency;
};

/** Set ProLogic IIx parameters */
struct AudioEngine_PL2x_type {
	/** Specifies the ProLogic IIx decoding mode. range 0 -> 10 */
	RMuint32 mode;
	/** Disable the ProLogic IIx Autobalance. */
	RMbool a;
	/** Specifies the ProLogic IIx dimension setting. range 0 -> 14 */
	RMuint32 d;
	/** Enable the ProLogic IIx Surround Channel Shelf Filter. */
	RMbool f;
	/** Specifies the ProLogic IIx  PCM scale factor. range 0 -> 1 */
	RMuint32 p;
	/** Enable the ProLogic IIx Rs polarity Inversion. */
	RMbool r;
	/** Enable the ProLogic IIx Panorama mode. */
	RMbool t;
	/** Specifies the ProLogic IIx  Center width Control Setting. range 0 -> 7 */
	RMuint32 w;
	/** Enable the ProLogic IIx inverted matrix. */
	RMbool x;
	/** Enable ProLogic IIx. */
	RMbool on;
	/** Enable auto Detection for EX flag for ProLogic IIx. */
	RMbool autoEX;
};

/** Set or Get serialout enable */
enum AudioEngine_SerialOut_type {
	/** Serial Out Enabled */
	AudioEngine_SerialOut_SO_ENABLE = 0,
	/** Serial Out Disabled */
	AudioEngine_SerialOut_SO_DISABLE = 1,
};

/** Set I2S audio output configuration. Both audio decoders will share same channel status. */
struct AudioEngine_I2SConfig_type {
	/** Number of bits the data is shifted against the L/R-Clock. */
	RMuint32 DataAlignment;
	/** Bit order. TRUE=MSB first, FALSE=LSB first. */
	RMbool SClkInvert;
	/** Bit order. TRUE=MSB first, FALSE=LSB first. */
	RMbool FrameInvert;
	/** Bit order. TRUE=MSB first, FALSE=LSB first. */
	RMbool MSBFirst;
	/** Sample size. TRUE=16 bit, FALSE=32 bit. */
	RMbool SampleSize16Bit;
};

/** Set or Get spdifout enable */
enum AudioEngine_SpdifOut_type {
	/** spdif output disabled */
	AudioEngine_SpdifOut_Disabled = 0,
	/** spdif output enabled, data is forced to 0, or 1 if polarity bit is 1 */
	AudioEngine_SpdifOut_ActiveData0 = 1,
	/** spdif output enabled */
	AudioEngine_SpdifOut_Active = 3,
};

/** Set or Get i2sout enable */
enum AudioEngine_I2sOut_type {
	/** i2s output disabled (i2s clock output disabled) */
	AudioEngine_I2sOut_i2s_Disabled = 0,
	/** i2s0 output enabled, data is forced to 0, or 1 if polarity bit is 1 */
	AudioEngine_I2sOut_ActiveData0_i2s0 = 1,
	/** i2s1 output enabled, data is forced to 0, or 1 if polarity bit is 1 */
	AudioEngine_I2sOut_ActiveData0_i2s1 = 2,
	/** i2s2 output enabled, data is forced to 0, or 1 if polarity bit is 1 */
	AudioEngine_I2sOut_ActiveData0_i2s2 = 4,
	/** i2s3 output enabled, data is forced to 0, or 1 if polarity bit is 1 */
	AudioEngine_I2sOut_ActiveData0_i2s3 = 8,
	/** i2s4 output enabled, data is forced to 0, or 1 if polarity bit is 1 */
	AudioEngine_I2sOut_ActiveData0_i2s4 = 16,
	/** i2s0 output enabled */
	AudioEngine_I2sOut_Active_i2s0 = 32,
	/** i2s1 output enabled */
	AudioEngine_I2sOut_Active_i2s1 = 64,
	/** i2s2 output enabled */
	AudioEngine_I2sOut_Active_i2s2 = 128,
	/** i2s3 output enabled */
	AudioEngine_I2sOut_Active_i2s3 = 256,
	/** i2s4 output enabled */
	AudioEngine_I2sOut_Active_i2s4 = 512,
};

/** Set SPDIF audio output channel status. Both audio decoders will share same channel status. */
struct AudioEngine_ChannelStatus_type {
	/** Specifies the bit mask that will be owned by application. The bits set to 1 in Mask are left unchanged by emhwlib. */
	RMuint32 Mask;
	/** Specifies the value to be set in ChannelStatus. This Value will be and logic with Mask. */
	RMuint32 Value;
};

/** STC maintained by a clock derived from the I2S output clock */
struct AudioEngine_STC_type {
	/**  */
	RMbool Enable;
	/**  */
	RMuint32 time_resolution;
	/**  */
	RMuint64 time;
};

/** Operate dram2dram dmacopy on idle DSP */
struct AudioEngine_Memcpy_type {
	/** Member default */
	RMuint32 dest;
	/** Member default */
	RMuint32 src;
	/** Member default */
	RMuint32 n;
};

/** Get SPDIF audio input channel status. */
struct AudioEngine_InputSPDIFStatus_type {
	/** ChannelStatus of the SPDIF input. */
	RMuint32 ChannelStatus;
	/** Pc (Burst Info) value from the most recent IEC61937 burst header. */
	RMuint16 Pc;
	/** Pd (Burst Length) value from the most recent IEC61937 burst header. */
	RMuint16 Pd;
	/** Pe (Extended Data Type) value from the most recent IEC61937 burst header with Pc==0x001F. */
	RMuint16 Pe;
	/** Pf value from the most recent IEC61937 burst header with Pc==0x001F. */
	RMuint16 Pf;
};

/** struct Default */
struct AudioEngine_DecoderSharedMemory_type {
	/** DRAM shared by all audio decoders on the AudioEngine - memory used for post processing */
	RMuint32 Address;
	/** Member default */
	RMuint32 Size;
};

/** connect/disconnect audio tasks to audio engine. */
struct AudioEngine_ConnectTask_type {
	/** Member default */
	RMbool connect;
	/**  */
	RMuint32 task_index;
};

/** customized downmixing tables, e.g, ARIB. */
struct AudioEngine_Downmixing_tables_type {
	/** Member default */
	enum AudioEngine_dmx_tables_type dmx_table_index;
	/** Member default */
	RMuint32 dmx_table_pointer;
};

/** Sets the audio decoder Profile. The profile consist in defining the maximum number of resources (Memory, Number of channels...) the audio decoder will use.@note @li The CachedSize and UncachedSize values can be obtained using the ::RMAudioDecoderPropertyID_DRAMSize exchange properties. The application has to provide these values since it is solely responsible for the DDR-DRAM memory allocation in each DRAM controller.@li The CachedAddress and UncachedAddress can be obtained in the RUA interface by calling RUAMalloc. Refer to the em86xx REALmagic User API document for more info.@li In order to release the resources or change the decoder profile, use the ::RMAudioDecoderPropertyID_Close. You cannot free the memory used by the decoder before calling the ::RMAudioDecoderPropertyID_Close property. */
struct AudioDecoder_Open_type {
	/** Member default */
	RMuint32 MaxChannelOutCount;
	/** Member default */
	RMuint32 PCMLineCount;
	/** Member default */
	RMuint32 BitstreamFIFOSize;
	/** Member default */
	RMuint32 XferFIFOCount;
	/** Member default */
	RMuint32 CachedAddress;
	/** Member default */
	RMuint32 CachedSize;
	/** Member default */
	RMuint32 UncachedAddress;
	/** Member default */
	RMuint32 UncachedSize;
	/** index of DemuxProgram */
	RMuint32 DemuxProgramId;
	/** index of STC or timer */
	RMuint32 TimerId;
};

/** Sets the audio decoder Profile. The profile consist in defining the maximum number of resources (Memory, Number of channels...) the audio decoder will use.@note @li The CachedSize and UncachedSize values can be obtained using the ::RMAudioDecoderPropertyID_DRAMSize exchange properties. The application has to provide these values since it is solely responsible for the DDR-DRAM memory allocation in each DRAM controller.@li The CachedAddress and UncachedAddress can be obtained in the RUA interface by calling RUAMalloc. Refer to the em86xx REALmagic User API document for more info.@li In order to release the resources or change the decoder profile, use the ::RMAudioDecoderPropertyID_Close. You cannot free the memory used by the decoder before calling the ::RMAudioDecoderPropertyID_Close property. */
struct AudioDecoder_OpenPCMX_type {
	/** Member default */
	RMuint32 BitstreamFIFOSize0;
	/** Member default */
	RMuint32 XferFIFOCount0;
	/** Member default */
	RMuint32 BitstreamFIFOSize1;
	/** Member default */
	RMuint32 XferFIFOCount1;
	/** Member default */
	RMuint32 BitstreamFIFOSize2;
	/** Member default */
	RMuint32 XferFIFOCount2;
	/** Member default */
	RMuint32 BitstreamFIFOSize3;
	/** Member default */
	RMuint32 XferFIFOCount3;
	/** Member default */
	RMuint32 BitstreamFIFOSize4;
	/** Member default */
	RMuint32 XferFIFOCount4;
	/** Member default */
	RMuint32 BitstreamFIFOSize5;
	/** Member default */
	RMuint32 XferFIFOCount5;
	/** Member default */
	RMuint32 BitstreamFIFOSize6;
	/** Member default */
	RMuint32 XferFIFOCount6;
	/** Member default */
	RMuint32 BitstreamFIFOSize7;
	/** Member default */
	RMuint32 XferFIFOCount7;
	/** Member default */
	RMuint32 BitstreamFIFOSize8;
	/** Member default */
	RMuint32 XferFIFOCount8;
	/** Member default */
	RMuint32 UnProtectedAddress;
	/** Member default */
	RMuint32 UnProtectedSize;
};

/** Set the Audio decoder playback mode (Play, pause or stop).@note @li This property should be called only once the DSP microcode has been loaded using the ::RMAudioEnginePropertyID_MicrocodeVersion property.@li The init command is used to set the microcode in stop mode. The stop mode is mode where the audio codec is already know and must therefore be selected prior to the init command.@li Use the ::RMAudioDecoderPropertyID_State to wait for the command command completion.@li The audio codec can be selected only in stop mode and before the init command. */
enum AudioDecoder_Command_type {
	/** Set the decoder into play mode. */
	AudioDecoder_Command_Play = 1,
	/** Set the decoder into pause mode. */
	AudioDecoder_Command_Pause = 2,
	/** Set the decoder into stop mode. */
	AudioDecoder_Command_Stop = 3,
	/** Initializes the decoder. This command has to be called after loading and running the microcode and before any other command. Note that the codec must be selected prior to calling this function. */
	AudioDecoder_Command_Init = 6,
	/** Uninitializes the decoder. This command should be called before a new Init to change the decoder type will come. */
	AudioDecoder_Command_Uninit = 7,
};

/** State machine of the Audio decoder */
enum AudioDecoder_State_type {
	/** Audio decoder not initialized yet */
	AudioDecoder_State_Uninitialized = 0,
	/** The microcode is error state and should be stopped or reset */
	AudioDecoder_State_Error = 1,
	/** A stop command has been issued but has not been completed yet. @note @li you can use ::RUAWaitForMultipleEvents to wait for command completion */
	AudioDecoder_State_StopPending = 2,
	/** In Enum default */
	AudioDecoder_State_Stopped = 3,
	/** In Enum default */
	AudioDecoder_State_PlayPending = 4,
	/** In Enum default */
	AudioDecoder_State_Playing = 5,
	/** In Enum default */
	AudioDecoder_State_PausePending = 6,
	/** In Enum default */
	AudioDecoder_State_Paused = 7,
	/** In Enum default */
	AudioDecoder_State_UninitPending = 8,
	/** In Enum default */
	AudioDecoder_State_Closed = 9,
};

/** Select the audio codec (Currently supported codecs: PCM, MPEG1 L1/2/3 or AC3).@note @li The audio codec can be selected only in stop mode or before the init command. */
enum AudioDecoder_Codec_type {
	/** Selects audio AC3 codecs */
	AudioDecoder_Codec_AC3 = 1,
	/** Selects the audio MPEG1 codec. It supports layer 1, 2 and 3 (Also known as mp3) and MPEG2 backward compatible audio layers (Only support for 2 channels). */
	AudioDecoder_Codec_MPEG1 = 2,
	/** Selects the AAC codec. It supports several types of payload formats (see ::RMAudioDecoderPropertyID_AACParameters) */
	AudioDecoder_Codec_AAC = 3,
	/** Select the DVD Audio code. Not supported yet */
	AudioDecoder_Codec_DVDA = 4,
	/** Select the PCM codecs. It supports several types of PCM formats (see ::RMAudioDecoderPropertyID_PcmParameters) */
	AudioDecoder_Codec_PCM = 5,
	/** Supported */
	AudioDecoder_Codec_DTS = 6,
	/** Supported */
	AudioDecoder_Codec_WMA = 7,
	/** Supported */
	AudioDecoder_Codec_WMAPRO = 8,
	/** EVD ExAC supported */
	AudioDecoder_Codec_EXAC = 9,
	/** Supported. */
	AudioDecoder_Codec_ATX = 10,
	/** Compressed WMAPRO over SPDIF. */
	AudioDecoder_Codec_WMAPRO_SPDIF = 11,
	/** Select the PCMX codecs. */
	AudioDecoder_Codec_PCMX = 12,
	/** MPEG-4 BSAC decoder. */
	AudioDecoder_Codec_BSAC = 13,
	/** Test tone generator. */
	AudioDecoder_Codec_TTONE = 14,
};

/** struct Default */
struct AudioDecoder_PCMXParameters_type {
	/** Member default */
	enum PcmCdaChannelAssign_type ChannelAssign;
	/** Member default range 8 -> 24 */
	RMuint32 BitsPerSample;
	/** Member default */
	RMuint32 SamplingFrequency;
	/** Member default */
	RMbool MsbFirst;
	/** Member default */
	enum OutputDualMode_type OutputDualMode;
	/** Member default */
	enum AudioOutputChannels_type OutputChannels;
	/** Member default */
	RMbool OutputLfe;
	/** Member default */
	RMbool SignedPCM;
	/** Selects between disable, uncompressed and compressed SpdifOutput. */
	enum OutputSpdif_type OutputSpdif;
	/** Member default */
	enum AudioOutputSurround20_type OutputSurround20;
	/** Member default */
	RMuint32 BassMode;
};

/** struct Default */
struct AudioDecoder_AACParameters_type {
	/** Member default */
	enum AACInputFormat InputFormat;
	/** Selects between disable, uncompressed and compressed SpdifOutput. */
	enum OutputSpdif_type OutputSpdif;
	/** Member default */
	enum OutputDualMode_type OutputDualMode;
	/** Member default */
	enum AacOutputChannels_type OutputChannels;
	/** Member default */
	RMbool Acmod2DualMode;
	/** Member default */
	RMbool OutputLfe;
	/** Member default */
	enum AudioOutputSurround20_type OutputSurround20;
	/** Member default */
	RMuint32 BassMode;
};

/** struct Default */
struct AudioDecoder_DVDAParameters_type {
	/** Member default */
	RMuint32 Chconfig;
	/** Member default */
	RMuint32 DRCenable;
	/** Member default */
	RMuint32 DRCboost;
	/** Member default */
	RMuint32 DRCcut;
	/** Member default */
	RMint32 DRCdialref;
	/** Member default */
	RMbool Lossless;
	/** Selects between disable, uncompressed and compressed SpdifOutput. */
	enum OutputSpdif_type OutputSpdif;
	/** Member default */
	enum OutputDualMode_type OutputDualMode;
	/** Member default */
	enum AudioOutputChannels_type OutputChannels;
	/** Member default */
	RMbool OutputLfe;
	/** Member default */
	enum AudioOutputSurround20_type OutputSurround20;
	/** Member default */
	RMuint32 BassMode;
};

/** struct Default */
struct AudioDecoder_TToneParameters_type {
	/** Member default */
	enum TestToneType TToneType;
	/** Member default */
	enum AudioChannelMask_type TToneChannelMask;
	/** Selects between disable, uncompressed and compressed SpdifOutput. */
	enum OutputSpdif_type OutputSpdif;
	/** Member default */
	enum OutputDualMode_type OutputDualMode;
	/** Member default */
	enum AacOutputChannels_type OutputChannels;
	/** Member default */
	RMbool OutputLfe;
	/** Member default */
	RMuint32 BassMode;
};

/** struct Default */
struct AudioDecoder_BSACParameters_type {
	/** Member default */
	enum AACInputFormat InputFormat;
	/** Selects between disable, uncompressed and compressed SpdifOutput. */
	enum OutputSpdif_type OutputSpdif;
	/** Member default */
	enum OutputDualMode_type OutputDualMode;
	/** Member default */
	enum AacOutputChannels_type OutputChannels;
	/** Member default */
	RMbool OutputLfe;
	/** Member default */
	enum AudioOutputSurround20_type OutputSurround20;
	/** Member default */
	RMuint32 BassMode;
};

/** struct Default */
struct AudioDecoder_Ac3Parameters_type {
	/** Member default */
	enum OutputDualMode_type OutputDualMode;
	/** Member default */
	enum Ac3OutputChannels_type OutputChannels;
	/** Member default */
	RMbool OutputLfe;
	/** Member default */
	enum AudioOutputSurround20_type OutputSurround20;
	/** Selects between disable, uncompressed and compressed SpdifOutput. */
	enum OutputSpdif_type OutputSpdif;
	/** Member default */
	RMbool Acmod2DualMode;
	/** Member default */
	enum Ac3CompMode_type CompMode;
	/** Member default */
	RMuint32 DynScaleHi;
	/** Member default */
	RMuint32 DynScaleLo;
	/** Member default */
	RMuint32 PcmScale;
	/** Member default */
	RMuint32 BassMode;
};

/** struct Default */
struct AudioDecoder_DtsParameters_type {
	/** supported in Postprocessing */
	enum OutputDualMode_type OutputDualMode;
	/** Selects between disable, uncompressed and compressed SpdifOutput. */
	enum OutputSpdif_type OutputSpdif;
	/** Member default */
	enum DtsOutputChannels_type OutputChannels;
	/** Member default */
	RMbool OutputLfe;
	/** Member default */
	enum AudioOutputSurround20_type OutputSurround20;
	/** Member default */
	RMuint32 BassMode;
	/** Member default */
	RMbool dts_CD;
};

/** struct Default */
struct AudioDecoder_LpcmVobParameters_type {
	/** Member default */
	enum LpcmVobChannelAssign_type ChannelAssign;
	/** Member default range 8 -> 24 */
	RMuint32 BitsPerSample;
	/** Member default */
	RMuint32 SamplingFrequency;
	/** Member default */
	RMbool DownMix;
	/** Member default */
	RMuint16x8 CoefLR;
	/** Member default */
	enum OutputDualMode_type OutputDualMode;
	/** Member default */
	enum AudioOutputChannels_type OutputChannels;
	/** Member default */
	RMbool OutputLfe;
	/** Member default */
	enum AudioOutputSurround20_type OutputSurround20;
	/** Selects between disable, uncompressed and compressed SpdifOutput. */
	enum OutputSpdif_type OutputSpdif;
	/** Member default */
	RMuint32 BassMode;
};

/** struct Default */
struct AudioDecoder_LpcmAobParameters_type {
	/** Member default */
	enum LpcmAobChannelAssign_type ChannelAssign;
	/** Member default range 8 -> 24 */
	RMuint32 BitsPerSampleGroup1;
	/** Member default range 0 -> 24 */
	RMuint32 BitsPerSampleGroup2;
	/** Member default */
	RMuint32 SamplingFrequencyGroup1;
	/** Member default */
	RMuint32 SamplingFrequencyGroup2;
	/** Member default */
	RMbool DownMix;
	/** Member default */
	RMuint16x6 CoefLR;
	/** Member default */
	RMuint32 PhaseLR;
	/** Member default */
	RMuint32 Group2Shift;
	/** Member default */
	enum OutputDualMode_type OutputDualMode;
	/** Member default */
	enum AudioOutputChannels_type OutputChannels;
	/** Member default */
	RMbool OutputLfe;
	/** Member default */
	enum AudioOutputSurround20_type OutputSurround20;
	/** Selects between disable, uncompressed and compressed SpdifOutput. */
	enum OutputSpdif_type OutputSpdif;
	/** Member default */
	RMbool DownSample;
	/** Member default */
	RMuint32 BassMode;
};

/** struct Default */
struct AudioDecoder_PcmCdaParameters_type {
	/** Member default */
	enum PcmCdaChannelAssign_type ChannelAssign;
	/** Member default range 8 -> 24 */
	RMuint32 BitsPerSample;
	/** Member default */
	RMuint32 SamplingFrequency;
	/** Member default */
	RMbool MsbFirst;
	/** Member default */
	enum OutputDualMode_type OutputDualMode;
	/** Member default */
	enum AudioOutputChannels_type OutputChannels;
	/** Member default */
	RMbool OutputLfe;
	/** Member default */
	enum AudioOutputSurround20_type OutputSurround20;
	/** Member default */
	RMbool SignedPCM;
	/** Selects between disable, uncompressed and compressed SpdifOutput. */
	enum OutputSpdif_type OutputSpdif;
	/** Member default */
	RMuint32 BassMode;
};

/** struct Default */
struct AudioDecoder_LpcmBDParameters_type {
	/** Member default */
	enum PcmCdaChannelAssign_type ChannelAssign;
	/** Member default range 8 -> 24 */
	RMuint32 BitsPerSample;
	/** Member default */
	RMuint32 SamplingFrequency;
	/** Member default */
	enum OutputDualMode_type OutputDualMode;
	/** Member default */
	enum AudioOutputChannels_type OutputChannels;
	/** Member default */
	RMbool OutputLfe;
	/** Member default */
	enum AudioOutputSurround20_type OutputSurround20;
	/** Selects between disable, uncompressed and compressed SpdifOutput. */
	enum OutputSpdif_type OutputSpdif;
	/** Member default */
	RMuint32 BassMode;
};

/** struct Default */
struct AudioDecoder_MpegParameters_type {
	/** Member default */
	enum OutputDualMode_type OutputDualMode;
	/** Member default */
	RMbool Acmod2DualMode;
	/** Member default */
	enum AudioOutputChannels_type OutputChannels;
	/** Member default */
	RMbool OutputLfe;
	/** Member default */
	enum AudioOutputSurround20_type OutputSurround20;
	/** Selects between disable, uncompressed and compressed SpdifOutput. */
	enum OutputSpdif_type OutputSpdif;
	/** Member default */
	RMuint32 BassMode;
};

/** struct Default */
struct AudioDecoder_WMAParameters_type {
	/** Member default */
	RMuint16 VersionNumber;
	/** Member default */
	RMuint32 SamplingFrequency;
	/** Member default */
	RMuint8 NumberOfChannels;
	/** Member default */
	RMbool OutputLfe;
	/** Member default */
	RMuint32 Bitrate;
	/** Member default */
	RMuint32 PacketSize;
	/** Member default */
	RMuint16 EncoderOptions;
	/** Member default */
	RMuint8 BitsPerSample;
	/** Member default */
	RMuint8 WMAProValidBitsPerSample;
	/** Member default */
	RMuint16 WMAProChannelMask;
	/** Member default */
	RMuint8 WMAProVersionNumber;
	/** Member default */
	enum OutputDualMode_type OutputDualMode;
	/** Selects between disable, uncompressed and compressed SpdifOutput. */
	enum OutputSpdif_type OutputSpdif;
	/** For Wmapro_6 6 channels play on 6 outputs, else 6 channels are downmixed in 2 outputs */
	enum WmaproOutputChannels_type OutputChannels;
	/** Member default */
	enum AudioOutputSurround20_type OutputSurround20;
	/** not yet implemented */
	RMbool ValidDownMixCoef;
	/** not yet implemented */
	RMuint32x64 DownMixCoef;
	/** not yet implemented */
	enum WmaproDynamicRangeControl_type DynamicRangeControl;
	/** not yet implemented */
	RMint32x5 DrcCoef;
	/** Member default */
	RMuint32 BassMode;
};

/** struct Default */
struct AudioDecoder_AudioPostProcessingInfo_type {
	/** Member default */
	RMuint32 dataReady;
};

/** struct Default */
struct AudioDecoder_AudioPostProcessingBuffer_type {
	/** Member default */
	RMuint32 frameSize;
	/** Member default */
	RMuint32 inputChCfg;
	/** Member default */
	RMuint32* tmpBufAddr;
};

/** Audio Decoder Mixing Weights */
struct AudioDecoder_MixerWeight_type {
	/**  */
	RMuint32 MixerValue_ch0;
	/**  */
	RMuint32 MixerValue_ch1;
	/**  */
	RMuint32 MixerValue_ch2;
	/**  */
	RMuint32 MixerValue_ch3;
	/**  */
	RMuint32 MixerValue_ch4;
	/**  */
	RMuint32 MixerValue_ch5;
	/**  */
	RMuint32 MixerValue_ch6;
	/**  */
	RMuint32 MixerValue_ch7;
};

/** struct Default */
struct AudioDecoder_OpenX_type {
	/**  */
	RMuint32 ProtectedFlags;
	/** input audio stream data fifo */
	RMuint32 BitstreamFIFOSize;
	/** Member default */
	RMuint32 XferFIFOCount;
	/** Member default */
	RMuint32 PtsFIFOCount;
	/** Member default */
	RMuint32 InbandFIFOCount;
	/** Member default */
	RMuint32 MaxChannelOutCount;
	/** Member default */
	RMuint32 PCMLineCount;
	/** Member default */
	RMuint32 XtaskInbandFIFOCount;
	/** index of STC */
	RMuint32 STCId;
	/** index of Xtask module */
	RMuint32 XtaskId;
	/** Member default */
	RMuint32 OutputSamplesProtectedAddress;
	/** Member default */
	RMuint32 OutputSamplesProtectedSize;
	/** Member default */
	RMuint32 BitstreamProtectedAddress;
	/** Member default */
	RMuint32 BitstreamProtectedSize;
	/** Member default */
	RMuint32 UnprotectedAddress;
	/** Member default */
	RMuint32 UnprotectedSize;
};

/** struct Default */
struct AudioDecoder_SynchroniseAudioWithDisplayPTS_type {
	/** Member default */
	RMuint32 ModuleID;
	/** Member default */
	RMbool Enable;
};

/** struct Default */
struct AudioDecoder_AudioPlayTime_type {
	/** Member default */
	enum AudioPlayMode_type PlayMode;
	/** Member default */
	RMuint64 PlayStartPTS;
	/** Member default */
	RMuint64 PlayEndPTS;
};

/** BDJ panning parameter in (x, y) coordinate. */
struct AudioDecoder_AudioBDJPanning_type {
	/** Member default range 0 -> 8 */
	RMuint32 src;
	/** Member default */
	RMint32 x;
	/** Member default */
	RMint32 y;
};

/** BDJ gain parameter [-51dB to +12dB], Note:-51=-OO, -50=-50dB and so on. */
struct AudioDecoder_AudioBDJGain_type {
	/** Member default range 0 -> 8 */
	RMuint32 src;
	/** Member default range -51 -> 12 */
	RMint32 gain;
};

/** PCMX decoder control (0:nothing change, 1: to flush bts fifo, 2:EOS Signal). */
struct AudioDecoder_AudioControlPCMX_type {
	/** Member default */
	RMint32 control_pcmx0;
	/** Member default */
	RMint32 control_pcmx1;
	/** Member default */
	RMint32 control_pcmx2;
	/** Member default */
	RMint32 control_pcmx3;
	/** Member default */
	RMint32 control_pcmx4;
	/** Member default */
	RMint32 control_pcmx5;
	/** Member default */
	RMint32 control_pcmx6;
	/** Member default */
	RMint32 control_pcmx7;
	/** Member default */
	RMint32 control_pcmx8;
};

/** Sets the audio capture Profile. The profile consist in defining the maximum number of resources (Memory, ...) the audio capture module will use.@note @li The CachedSize and UncachedSize values can be obtained using the ::RMAudioCapturePropertyID_DRAMSize exchange properties. The application has to provide these values since it is solely responsible for the DDR-DRAM memory allocation in each DRAM controller.@li The CachedAddress and UncachedAddress can be obtained in the RUA interface by calling RUAMalloc. Refer to the em86xx REALmagic User API document for more info.@li In order to release the resources or change the capture profile, use the ::RMAudioCapturePropertyID_Close. You cannot free the memory used by the decoder before calling the ::RMAudioCapturePropertyID_Close property. */
struct AudioCapture_Open_type {
	/** 0=Capture to Disk, 1=Playback */
	RMuint32 CaptureMode;
	/** Delay to start */
	RMuint32 Delay;
	/** Serialin Configuration */
	RMuint32 SI_CONF;
	/** Member default */
	RMuint32 SerialInFIFOSize;
	/** Member default */
	RMuint32 XferFIFOCount;
	/** Member default */
	RMuint32 CachedAddress;
	/** Member default */
	RMuint32 CachedSize;
	/** Member default */
	RMuint32 UncachedAddress;
	/** Member default */
	RMuint32 UncachedSize;
};

/**  */
enum AudioCapture_Capture_type {
	/** Start capture */
	AudioCapture_Capture_Off = 0,
	/** Stop capture */
	AudioCapture_Capture_On = 1,
};

/**  */
enum AudioCapture_Source_type {
	/** Capture data on I2S */
	AudioCapture_Source_I2S = 0,
	/** Capture data on SPDIF */
	AudioCapture_Source_SPDIF = 1,
};

/** Select the audio codec (Currently supported codecs: PCM, MPEG1 L1/2/3 or AC3).@note @li The audio codec can be selected only in stop mode or before the init command. */
enum AudioCapture_AudioStd_type {
	/** Audio standard AC3 */
	AudioCapture_AudioStd_AC3 = 0,
	/** Audio standard PCM */
	AudioCapture_AudioStd_PCM = 1,
	/** Audio standard DTS */
	AudioCapture_AudioStd_DTS = 2,
};

/** Set the capture mode */
enum AudioCapture_SpdifDataType_type {
	/** Data Type not specified */
	AudioCapture_SpdifDataType_NotSpecified = 0,
	/** PCM Data */
	AudioCapture_SpdifDataType_PCM = 1,
	/** Compressed Data */
	AudioCapture_SpdifDataType_Compressed = 2,
};

/** Sets the voip codec Profile. The profile consist in defining the maximum number of resources (Memory, ...) the voip codec module will use.@note @li The CachedSize and UncachedSize values can be obtained using the ::RMVoipCodecPropertyID_DRAMSize exchange properties. The application has to provide these values since it is solely responsible for the DDR-DRAM memory allocation in each DRAM controller.@li The CachedAddress and UncachedAddress can be obtained in the RUA interface by calling RUAMalloc. Refer to the em86xx REALmagic User API document for more info.@li In order to release the resources or change the capture profile, use the ::RMVoipCodecPropertyID_Close. You cannot free the memory used by the decoder before calling the ::RMVoipCodecPropertyID_Close property. */
struct VoipCodec_Open_type {
	/** Member default */
	RMuint32 BTSInFIFOSize;
	/** Member default */
	RMuint32 BTSOutFIFOSize;
	/** Member default */
	RMuint32 DTMFCharFIFOSize;
	/** Member default */
	RMuint32 CachedAddress;
	/** Member default */
	RMuint32 CachedSize;
	/** Member default */
	RMuint32 UncachedAddress;
	/** Member default */
	RMuint32 UncachedSize;
};

/** Select the voip codec (Currently supported codecs: g711 Linear/alaw/ulaw, g723.1 , g726, g728, g729).@note @li The voip codec can be selected only in stop mode or before the init command. */
enum VoipCodec_Encoder_Codec_type {
	/** Audio PCM linear 16 bit */
	VoipCodec_Encoder_Codec_G711_LINEAR = 1,
	/** ITU G711 logarithmic alaw compressed pcm */
	VoipCodec_Encoder_Codec_G711_ALAW = 2,
	/** ITU G711 logarithmic ulaw compressed pcm */
	VoipCodec_Encoder_Codec_G711_ULAW = 3,
	/** ITU.T G.723.1 multirate codec */
	VoipCodec_Encoder_Codec_G723_1 = 4,
	/** ITU.T G.726 codec */
	VoipCodec_Encoder_Codec_G726 = 5,
	/** ITU.T G.728 codec */
	VoipCodec_Encoder_Codec_G728 = 6,
	/** ITU.T G.729 codec */
	VoipCodec_Encoder_Codec_G729 = 7,
};

/** Select the voip codec (Currently supported codecs: g711 Linear/alaw/ulaw, g723.1 , g726, g728, g729).@note @li The voip codec can be selected only in stop mode or before the init command. */
enum VoipCodec_Decoder_Codec_type {
	/** Audio PCM linear 16 bit */
	VoipCodec_Decoder_Codec_G711_LINEAR = 1,
	/** ITU G711 logarithmic alaw compressed pcm */
	VoipCodec_Decoder_Codec_G711_ALAW = 2,
	/** ITU G711 logarithmic ulaw compressed pcm */
	VoipCodec_Decoder_Codec_G711_ULAW = 3,
	/** ITU.T G.723.1 multirate codec */
	VoipCodec_Decoder_Codec_G723_1 = 4,
	/** ITU.T G.726 codec */
	VoipCodec_Decoder_Codec_G726 = 5,
	/** ITU.T G.728 codec */
	VoipCodec_Decoder_Codec_G728 = 6,
	/** ITU.T G.729 codec */
	VoipCodec_Decoder_Codec_G729 = 7,
};

/**  */
enum VoipCodec_Command_type {
	/** Start capture */
	VoipCodec_Command_Capture_Start = 1,
	/** Stop capture */
	VoipCodec_Command_Capture_Stop = 2,
	/** Start playback */
	VoipCodec_Command_Playback_Start = 3,
	/** Stop playback */
	VoipCodec_Command_Playback_Stop = 4,
	/** Init encoder */
	VoipCodec_Command_Encoder_Init = 5,
	/** Start encoder */
	VoipCodec_Command_Encoder_Start = 6,
	/** Stop encoder */
	VoipCodec_Command_Encoder_Stop = 7,
	/** Init encoder vad */
	VoipCodec_Command_Encoder_Vad_Init = 8,
	/** Encoder Voice Activity Detection start */
	VoipCodec_Command_Encoder_Vad_Start = 9,
	/** Encoder Voice Activity Detection stop */
	VoipCodec_Command_Encoder_Vad_Stop = 10,
	/** Init decoder */
	VoipCodec_Command_Decoder_Init = 11,
	/** Start decoder */
	VoipCodec_Command_Decoder_Start = 12,
	/** Stop decoder */
	VoipCodec_Command_Decoder_Stop = 13,
	/** Init echo cancellation */
	VoipCodec_Command_Aec_Init = 14,
	/** Reset echo cancellation */
	VoipCodec_Command_Aec_Reset = 15,
	/** Start echo cancellation */
	VoipCodec_Command_Aec_Start = 16,
	/** Stop echo cancellation */
	VoipCodec_Command_Aec_Stop = 17,
	/** Init non linear processing and comfort noise generation */
	VoipCodec_Command_NlpCng_Init = 18,
	/** Start non linear processing and comfort noise generation */
	VoipCodec_Command_NlpCng_Start = 19,
	/** Stop non linear processing and comfort noise generation */
	VoipCodec_Command_NlpCng_Stop = 20,
	/** Init tone generator */
	VoipCodec_Command_ToneGen_Init = 21,
	/** Reset tone generator */
	VoipCodec_Command_ToneGen_Reset = 22,
	/** Start tone generator */
	VoipCodec_Command_ToneGen_Start = 23,
	/** Stop tone generator */
	VoipCodec_Command_ToneGen_Stop = 24,
	/** Init dtmf detector */
	VoipCodec_Command_DTMF_Init = 25,
	/** Start dtmf detector */
	VoipCodec_Command_DTMF_Start = 26,
	/** Stop dtmf detector */
	VoipCodec_Command_DTMF_Stop = 27,
	/** Init Aec disabler tone detector */
	VoipCodec_Command_AecTdd_Init = 28,
	/** Start Aec disabler tone detector */
	VoipCodec_Command_AecTdd_Start = 29,
	/** Stop Aec disabler tone detector */
	VoipCodec_Command_AecTdd_Stop = 30,
	/** Init caller id generator */
	VoipCodec_Command_Cid_Init = 31,
	/** Reset caller id structure */
	VoipCodec_Command_Cid_Reset = 32,
	/** Start caller id generation */
	VoipCodec_Command_Cid_Start = 33,
	/** Stop caller id generation */
	VoipCodec_Command_Cid_Stop = 34,
};

/** Get the serial in interrupt status */
enum VoipCodec_Capture_type {
	/** serial in interrupt disabled */
	VoipCodec_Capture_Disabled = 0,
	/** serial in interrupt enabled */
	VoipCodec_Capture_Enabled = 1,
};

/** Get the serial out interrupt status */
enum VoipCodec_Playback_type {
	/** serial out interrupt disabled */
	VoipCodec_Playback_Disabled = 0,
	/** serial out interrupt enabled */
	VoipCodec_Playback_Enabled = 1,
};

/** State machine of the Voip Encoder */
enum VoipCodec_CoderState_type {
	/** Voip encoder not initialized yet */
	VoipCodec_CoderState_Uninitialized = 0,
	/** The microcode is error state and should be stopped or reset */
	VoipCodec_CoderState_Error = 1,
	/** A stop command has been issued but has not been completed yet. @note @li you can use ::RUAWaitForMultipleEvents to wait for command completion */
	VoipCodec_CoderState_StopPending = 2,
	/** In Enum default */
	VoipCodec_CoderState_Stopped = 3,
	/** In Enum default */
	VoipCodec_CoderState_PlayPending = 4,
	/** In Enum default */
	VoipCodec_CoderState_Playing = 5,
};

/** State machine of the Voip Encoder voice activity detector */
enum VoipCodec_CoderVadState_type {
	/** Voip encoder voice activity detector not initialized yet */
	VoipCodec_CoderVadState_Uninitialized = 0,
	/** The microcode is error state and should be stopped or reset */
	VoipCodec_CoderVadState_Error = 1,
	/** A stop command has been issued but has not been completed yet. @note @li you can use ::RUAWaitForMultipleEvents to wait for command completion */
	VoipCodec_CoderVadState_StopPending = 2,
	/** In Enum default */
	VoipCodec_CoderVadState_Stopped = 3,
	/** In Enum default */
	VoipCodec_CoderVadState_PlayPending = 4,
	/** In Enum default */
	VoipCodec_CoderVadState_Playing = 5,
};

/** State machine of the Voip Decoder */
enum VoipCodec_DecoderState_type {
	/** Voip decoder not initialized yet */
	VoipCodec_DecoderState_Uninitialized = 0,
	/** The microcode is error state and should be stopped or reset */
	VoipCodec_DecoderState_Error = 1,
	/** A stop command has been issued but has not been completed yet. @note @li you can use ::RUAWaitForMultipleEvents to wait for command completion */
	VoipCodec_DecoderState_StopPending = 2,
	/** In Enum default */
	VoipCodec_DecoderState_Stopped = 3,
	/** In Enum default */
	VoipCodec_DecoderState_PlayPending = 4,
	/** In Enum default */
	VoipCodec_DecoderState_Playing = 5,
};

/** State machine of the Voip Tone Generator */
enum VoipCodec_ToneGeneratorState_type {
	/** Voip tone generator not initialized yet */
	VoipCodec_ToneGeneratorState_Uninitialized = 0,
	/** The microcode is error state and should be stopped or reset */
	VoipCodec_ToneGeneratorState_Error = 1,
	/** A stop command has been issued but has not been completed yet. @note @li you can use ::RUAWaitForMultipleEvents to wait for command completion */
	VoipCodec_ToneGeneratorState_StopPending = 2,
	/** In Enum default */
	VoipCodec_ToneGeneratorState_Stopped = 3,
	/** In Enum default */
	VoipCodec_ToneGeneratorState_PlayPending = 4,
	/** In Enum default */
	VoipCodec_ToneGeneratorState_Playing = 5,
};

/** State machine of the Voip Caller id Generator */
enum VoipCodec_CidGeneratorState_type {
	/** Voip caller id generator not initialized yet */
	VoipCodec_CidGeneratorState_Uninitialized = 0,
	/** The microcode is error state and should be stopped or reset */
	VoipCodec_CidGeneratorState_Error = 1,
	/** A stop command has been issued but has not been completed yet. @note @li you can use ::RUAWaitForMultipleEvents to wait for command completion */
	VoipCodec_CidGeneratorState_StopPending = 2,
	/** In Enum default */
	VoipCodec_CidGeneratorState_Stopped = 3,
	/** In Enum default */
	VoipCodec_CidGeneratorState_PlayPending = 4,
	/** In Enum default */
	VoipCodec_CidGeneratorState_Playing = 5,
};

/** State machine of the Voip Echo cancellation algorithm */
enum VoipCodec_AecState_type {
	/** Voip echo canceller not initialized yet */
	VoipCodec_AecState_Uninitialized = 0,
	/** The microcode is error state and should be stopped or reset */
	VoipCodec_AecState_Error = 1,
	/** A stop command has been issued but has not been completed yet. @note @li you can use ::RUAWaitForMultipleEvents to wait for command completion */
	VoipCodec_AecState_StopPending = 2,
	/** In Enum default */
	VoipCodec_AecState_Stopped = 3,
	/** In Enum default */
	VoipCodec_AecState_PlayPending = 4,
	/** In Enum default */
	VoipCodec_AecState_Playing = 5,
};

/** State machine of the Voip DTMF algorithm */
enum VoipCodec_DTMFState_type {
	/** Voip echo canceller not initialized yet */
	VoipCodec_DTMFState_Uninitialized = 0,
	/** The microcode is error state and should be stopped or reset */
	VoipCodec_DTMFState_Error = 1,
	/** A stop command has been issued but has not been completed yet. @note @li you can use ::RUAWaitForMultipleEvents to wait for command completion */
	VoipCodec_DTMFState_StopPending = 2,
	/** In Enum default */
	VoipCodec_DTMFState_Stopped = 3,
	/** In Enum default */
	VoipCodec_DTMFState_PlayPending = 4,
	/** In Enum default */
	VoipCodec_DTMFState_Playing = 5,
};

/** State machine of the Aec tone disabler detector algorithm */
enum VoipCodec_AecTddState_type {
	/** Voip echo canceller not initialized yet */
	VoipCodec_AecTddState_Uninitialized = 0,
	/** The microcode is error state and should be stopped or reset */
	VoipCodec_AecTddState_Error = 1,
	/** A stop command has been issued but has not been completed yet. @note @li you can use ::RUAWaitForMultipleEvents to wait for command completion */
	VoipCodec_AecTddState_StopPending = 2,
	/** In Enum default */
	VoipCodec_AecTddState_Stopped = 3,
	/** In Enum default */
	VoipCodec_AecTddState_PlayPending = 4,
	/** In Enum default */
	VoipCodec_AecTddState_Playing = 5,
};

/** State machine of the Voip Non linear processing and Comfort noise generation algorithm */
enum VoipCodec_NlpCngState_type {
	/** Voip echo canceller not initialized yet */
	VoipCodec_NlpCngState_Uninitialized = 0,
	/** The microcode is error state and should be stopped or reset */
	VoipCodec_NlpCngState_Error = 1,
	/** A stop command has been issued but has not been completed yet. @note @li you can use ::RUAWaitForMultipleEvents to wait for command completion */
	VoipCodec_NlpCngState_StopPending = 2,
	/** In Enum default */
	VoipCodec_NlpCngState_Stopped = 3,
	/** In Enum default */
	VoipCodec_NlpCngState_PlayPending = 4,
	/** In Enum default */
	VoipCodec_NlpCngState_Playing = 5,
};

/** struct Default */
struct CRCDecoder_Open_type {
	/** Member default */
	RMuint32 SlowCycle;
	/** Member default */
	RMuint32 UcodeChunkSize;
	/** Member default */
	RMuint32 BitstreamFIFOSize;
	/** Member default */
	RMuint32 XferFIFOCount;
	/** Member default */
	RMuint32 CachedAddress;
	/** Member default */
	RMuint32 CachedSize;
	/** Member default */
	RMuint32 UncachedAddress;
	/** Member default */
	RMuint32 UncachedSize;
};

/** enum Default */
enum CRCDecoder_Command_type {
	/** In Enum default */
	CRCDecoder_Command_Play,
	/** In Enum default */
	CRCDecoder_Command_Pause,
	/** In Enum default */
	CRCDecoder_Command_Flush,
};

/** enum Default */
enum CRCDecoder_State_type {
	/** In Enum default */
	CRCDecoder_State_Playing,
	/** In Enum default */
	CRCDecoder_State_Flushing,
	/** In Enum default */
	CRCDecoder_State_Flushed,
	/** In Enum default */
	CRCDecoder_State_Pausing,
};

/** struct Default */
struct XCRCDecoder_Open_type {
	/** Member default */
	RMuint32 SlowCycle;
	/** Member default */
	RMuint32 UcodeChunkSize;
	/** Member default */
	RMuint32 BitstreamFIFOSize;
	/** Member default */
	RMuint32 XferFIFOCount;
	/** Member default */
	RMuint32 CachedAddress;
	/** Member default */
	RMuint32 CachedSize;
	/** Member default */
	RMuint32 UncachedAddress;
	/** Member default */
	RMuint32 UncachedSize;
};

/** enum Default */
enum XCRCDecoder_Command_type {
	/** In Enum default */
	XCRCDecoder_Command_Play,
	/** In Enum default */
	XCRCDecoder_Command_Pause,
	/** In Enum default */
	XCRCDecoder_Command_Flush,
};

/** enum Default */
enum XCRCDecoder_State_type {
	/** In Enum default */
	XCRCDecoder_State_Playing,
	/** In Enum default */
	XCRCDecoder_State_Flushing,
	/** In Enum default */
	XCRCDecoder_State_Flushed,
	/** In Enum default */
	XCRCDecoder_State_Pausing,
};

/** struct Default */
struct StreamCapture_Open_type {
	/** Member default */
	RMuint32 SpiChannel;
	/** Member default */
	RMbool SerialSpi;
	/** Member default */
	RMuint32 BitstreamFIFOSize;
	/** Member default */
	RMuint32 XferFIFOCount;
	/** Member default */
	RMuint32 CachedAddress;
	/** Member default */
	RMuint32 CachedSize;
	/** Member default */
	RMuint32 UncachedAddress;
	/** Member default */
	RMuint32 UncachedSize;
};

/** enum Default */
enum StreamCapture_Command_type {
	/** In Enum default */
	StreamCapture_Command_Play,
	/** In Enum default */
	StreamCapture_Command_Pause,
	/** In Enum default */
	StreamCapture_Command_Flush,
};

/** enum Default */
enum StreamCapture_State_type {
	/** In Enum default */
	StreamCapture_State_Playing,
	/** In Enum default */
	StreamCapture_State_Flushing,
	/** In Enum default */
	StreamCapture_State_Flushed,
	/** In Enum default */
	StreamCapture_State_Pausing,
};

/** struct Default */
struct RawDataTransfer_Open_type {
	/** Member default */
	RMuint32 XferFIFOCount;
	/** Member default */
	RMuint32 CachedAddress;
	/** Member default */
	RMuint32 CachedSize;
	/** Member default */
	RMuint32 UncachedAddress;
	/** Member default */
	RMuint32 UncachedSize;
};

/** struct Default */
struct RawDataTransfer_ProgramLinearTransfer_type {
	/** Member default */
	enum RawDataTransferDirection Direction;
	/** Member default */
	RMuint32 Address;
	/** Member default */
	RMuint32 Size;
};

/** struct Default */
struct RawDataTransfer_ProgramRectangleTransfer_type {
	/** Member default */
	enum RawDataTransferDirection Direction;
	/** Member default */
	RMuint32 Address;
	/** Member default */
	RMuint32 Width;
	/** Member default */
	RMuint32 Height;
	/** Member default */
	RMuint32 TotalWidth;
	/** Member default */
	RMbool Tiled;
};

/** Obsolete, use DeviceParameter / QueryDeviceParameter instead! */
struct I2C_DeviceParams_type {
	/** Member default */
	RMuint8 PioClock;
	/** Member default */
	RMuint8 PioData;
	/** Member default */
	RMuint8 WrAddr;
	/** Member default */
	RMuint8 RdAddr;
	/** Member default */
	RMuint32 DelayUs;
};

/** struct Default */
struct I2C_WriteRMuint8_type {
	/** Member default */
	RMuint8 SubAddr;
	/** Member default */
	RMuint8 Data;
};

/** struct Default */
struct I2C_WriteData_type {
	/** Member default */
	RMbool UseSubAddr;
	/** Member default */
	RMuint8 SubAddr;
	/** Member default */
	RMuint32 DataSize;
	/** Member default */
	RMuint8 Data[256];
};

/** struct Default */
struct I2C_SelectSegment_type {
	/** address of the segment pointer */
	RMuint8 SegmentPtr;
	/** number of the segment to be accessed */
	RMuint8 Segment;
};

/** struct Default */
struct GFXEngine_Open_type {
	/** Member default */
	RMuint32 CommandFIFOCount;
	/** Member default */
	RMuint32 Priority;
	/** Member default */
	RMuint32 CachedAddress;
	/** Member default */
	RMuint32 CachedSize;
	/** Member default */
	RMuint32 UncachedAddress;
	/** Member default */
	RMuint32 UncachedSize;
};

/** struct Default */
struct GFXEngine_Correction_type {
	/** Member default */
	enum gfx_surface_id SurfaceID;
	/** Member default */
	enum gfx_correction_mode AlphaCorrect;
	/** Member default */
	enum gfx_correction_mode ColorCorrect;
};

/** struct Default */
struct GFXEngine_ColorFormat_type {
	/** Member default */
	enum gfx_surface_id SurfaceID;
	/** Member default */
	enum EMhwlibColorMode MainMode;
	/** Member default */
	enum EMhwlibColorFormat SubMode;
	/** Member default */
	enum EMhwlibSamplingMode SamplingMode;
	/** Member default */
	enum EMhwlibColorSpace ColorSpace;
};

/** struct Default */
struct GFXEngine_AlphaFormat_type {
	/** Member default */
	enum gfx_alpha_format AlphaFormat;
};

/** struct Default */
struct GFXEngine_Surface_type {
	/** Member default */
	enum gfx_surface_id SurfaceID;
	/** Member default */
	RMuint32 TotalWidth;
	/** Member default */
	RMbool Tiled;
	/** Member default */
	RMuint32 StartAddress;
	/** Member default */
	RMuint32 ChromaStartAddress;
	/** Member default */
	RMuint32 ChromaTotalWidth;
};

/** struct Default */
struct GFXEngine_BCS_type {
	/** Member default */
	enum gfx_surface_id SurfaceID;
	/** Member default */
	RMint32 Brightness;
	/** Member default */
	RMuint32 Contrast;
	/** Member default */
	RMuint32 SaturationCb;
	/** Member default */
	RMuint32 SaturationCr;
};

/** struct Default */
struct GFXEngine_FillRectangle_type {
	/** Member default */
	RMuint32 X;
	/** Member default */
	RMuint32 Y;
	/** Member default */
	RMuint32 Width;
	/** Member default */
	RMuint32 Height;
	/** Member default */
	RMuint32 Color;
};

/** struct Default */
struct GFXEngine_BlendRectangles_type {
	/** Member default */
	RMuint32 Src1X;
	/** Member default */
	RMuint32 Src1Y;
	/** Member default */
	RMuint32 Src2X;
	/** Member default */
	RMuint32 Src2Y;
	/** Member default */
	RMuint32 DstX;
	/** Member default */
	RMuint32 DstY;
	/** Member default */
	RMuint32 Width;
	/** Member default */
	RMuint32 Height;
	/** Member default */
	RMbool SaturateAlpha;
};

/** struct Default */
struct GFXEngine_BlendGradient_type {
	/** Member default */
	RMuint32 Src2X;
	/** Member default */
	RMuint32 Src2Y;
	/** Member default */
	RMuint32 DstX;
	/** Member default */
	RMuint32 DstY;
	/** Member default */
	RMuint32 Width;
	/** Member default */
	RMuint32 Height;
	/** Member default */
	RMbool SaturateAlpha;
};

/** struct Default */
struct GFXEngine_RasterBlendGradient_type {
	/** Member default */
	RMuint32 Src2X;
	/** Member default */
	RMuint32 Src2Y;
	/** Member default */
	RMuint32 DstX;
	/** Member default */
	RMuint32 DstY;
	/** Member default */
	RMuint32 Width;
	/** Member default */
	RMuint32 Height;
	/** Member default */
	RMuint32 RasterOp;
};

/** struct Default */
struct GFXEngine_RasterBlendRectangles_type {
	/** Member default */
	RMuint32 Src1X;
	/** Member default */
	RMuint32 Src1Y;
	/** Member default */
	RMuint32 Src2X;
	/** Member default */
	RMuint32 Src2Y;
	/** Member default */
	RMuint32 DstX;
	/** Member default */
	RMuint32 DstY;
	/** Member default */
	RMuint32 Width;
	/** Member default */
	RMuint32 Height;
	/** Member default */
	RMuint32 RasterOp;
};

/** struct Default */
struct GFXEngine_SingleColorBlendRectangles_type {
	/** Member default */
	RMuint32 SrcX;
	/** Member default */
	RMuint32 SrcY;
	/** Member default */
	RMuint32 DstX;
	/** Member default */
	RMuint32 DstY;
	/** Member default */
	RMuint32 Width;
	/** Member default */
	RMuint32 Height;
	/** Member default */
	RMuint32 Color;
	/** Member default */
	RMbool SaturateAlpha;
};

/** struct Default */
struct GFXEngine_BlendAndScaleRectangles_type {
	/** Member default */
	RMuint32 Src1X;
	/** Member default */
	RMuint32 Src1Y;
	/** Member default */
	RMuint32 Src2X;
	/** Member default */
	RMuint32 Src2Y;
	/** Member default */
	RMuint32 DstX;
	/** Member default */
	RMuint32 DstY;
	/** Member default */
	RMuint32 SrcWidth;
	/** Member default */
	RMuint32 SrcHeight;
	/** Member default */
	RMuint32 DstWidth;
	/** Member default */
	RMuint32 DstHeight;
	/** Member default */
	RMbool SaturateAlpha;
};

/** struct Default */
struct GFXEngine_Blend_type {
	/** Member default */
	RMuint32 Src1X;
	/** Member default */
	RMuint32 Src1Y;
	/** Member default */
	RMuint32 Src1Width;
	/** Member default */
	RMuint32 Src1Height;
	/** Member default */
	enum gfx_input_type Src1Input;
	/** Member default */
	RMuint32 Src2X;
	/** Member default */
	RMuint32 Src2Y;
	/** Member default */
	RMuint32 Src2Width;
	/** Member default */
	RMuint32 Src2Height;
	/** Member default */
	enum gfx_input_type Src2Input;
	/** Member default */
	RMuint32 DstX;
	/** Member default */
	RMuint32 DstY;
	/** Member default */
	RMuint32 DstWidth;
	/** Member default */
	RMuint32 DstHeight;
	/** Member default */
	RMbool SaturateAlpha;
	/** Member default */
	enum gfx_blend_mode BlendMode;
	/** Member default */
	RMuint32 Color;
};

/** insert a picture inside the surface picture's fifo */
struct GFXEngine_DisplayPicture_type {
	/** surface to insert the picture to */
	RMuint32 Surface;
	/** picture to insert in the surface's Fifo */
	RMuint32 Picture;
	/** pts to mark on the picture */
	RMuint64 Pts;
};

/** struct Default */
struct GFXEngine_LinearGradientSurface_type {
	/** Member default */
	RMuint32 Width;
	/** Member default */
	RMuint32 Height;
	/** Member default */
	RMuint32 Color0;
	/** Member default */
	RMuint32 Color1;
	/** Member default */
	RMuint32 Weave;
};

/** struct Default */
struct GFXEngine_RadialGradientSurface_type {
	/** Member default */
	RMuint32 IntRadius;
	/** Member default */
	RMuint32 ExtRadius;
	/** Member default */
	RMuint32 Color0;
	/** Member default */
	RMuint32 Color1;
	/** Member default */
	RMuint32 CenterX;
	/** Member default */
	RMuint32 CenterY;
	/** Member default */
	RMbool TransparentInt;
	/** Member default */
	RMbool TransparentExt;
	/** Member default */
	RMuint32 Weave;
};

/** struct Default */
struct GFXEngine_Palette_1BPP_type {
	/** Member default */
	enum gfx_surface_id SurfaceID;
	/** Member default */
	RMpalette_1BPP Palette;
};

/** struct Default */
struct GFXEngine_Palette_2BPP_type {
	/** Member default */
	enum gfx_surface_id SurfaceID;
	/** Member default */
	RMpalette_2BPP Palette;
};

/** struct Default */
struct GFXEngine_Palette_4BPP_type {
	/** Member default */
	enum gfx_surface_id SurfaceID;
	/** Member default */
	RMpalette_4BPP Palette;
};

/** struct Default */
struct GFXEngine_Palette_8BPP_type {
	/** Member default */
	enum gfx_surface_id SurfaceID;
	/** Member default */
	RMpalette_8BPP Palette;
};

/** struct Default */
struct GFXEngine_KeyColor_type {
	/** Member default */
	enum gfx_surface_id SurfaceID;
	/** Member default */
	RMuint32 Color;
	/** Member default */
	RMuint8 Range;
};

/** struct Default */
struct GFXEngine_FieldType_type {
	/** Member default */
	enum gfx_surface_id SurfaceID;
	/** Member default */
	enum EMhwlibFieldType FieldType;
	/** Member default */
	RMint32 LineSkipFactor;
};

/** struct Default */
struct GFXEngine_NonlinearScale_type {
	/** Member default */
	enum gfx_surface_id SurfaceID;
	/** Member default */
	RMuint32 Level;
	/** Member default */
	RMuint32 Width;
	/** Member default */
	RMuint32 PARQuotient;
};

/** struct Default */
struct GFXEngine_GlyphMask_type {
	/** Member default */
	RMuint32 GlyphAddr;
	/** Member default */
	RMuint32 Size;
	/** Member default */
	RMuint32 OutAddr;
	/** In 8.11 fixed point format, with unsigned integer part */
	RMuint32 ScaleFactor;
	/** Member default */
	RMint16 XMax;
	/** Member default */
	RMint16 XMin;
	/** Member default */
	RMint16 YMax;
	/** Member default */
	RMint16 YMin;
};

/** struct Default */
struct GFXEngine_GlyphScaleMatrix_type {
	/** In 2.14 fixed point format, with signed integer part */
	RMuint16 XScale;
	/** In 2.14 fixed point format, with signed integer part */
	RMuint16 YScale;
	/** In 2.14 fixed point format, with signed integer part */
	RMuint16 XYScale;
	/** In 2.14 fixed point format, with signed integer part */
	RMuint16 YXScale;
	/** Member default */
	RMint16 YOffset;
	/** Member default */
	RMint16 XOffset;
};

/** struct Default */
struct GFXEngine_LPFThresholds_type {
	/** Member default */
	enum gfx_surface_id SurfaceID;
	/** Member default */
	RMuint32 Threshold0;
	/** Member default */
	RMuint32 Threshold1;
	/** Member default */
	RMuint32 Threshold2;
	/** Member default */
	RMbool Discard;
};

/** insert a picture inside the surface picture's fifo */
struct GFXEngine_PictureBufferAddress_type {
	/** address to the surface that describes the picture */
	RMuint32 Surface;
	/** address to the picture's luma buffer */
	RMuint32 Y_addr;
};

/** struct Default */
struct GFXEngine_AlphaPalette_type {
	/** Member default */
	enum gfx_surface_id SurfaceID;
	/** Member default */
	RMuint8 Alpha0;
	/** Member default */
	RMuint8 Alpha1;
	/** Member default */
	RMuint8 Alpha2;
	/** Member default */
	RMuint8 Alpha3;
};

/** struct Default */
struct MM_MemoryArea_type {
	/** Member default */
	RMuint32 Address;
	/** Member default */
	RMuint32 Size;
};

/** struct Default */
struct MM_TopRemovableArea_type {
	/** Member default */
	RMuint32 Address;
	/** Member default */
	RMuint32 Size;
};

/** struct Default */
struct MM_Stats_type {
	/** Member default */
	RMuint32 TotalMallocCount;
	/** Member default */
	RMuint32 TotalFreeCount;
	/** Member default */
	RMint32 TotalBytesUsed;
	/** Member default */
	RMint32 MaximumBytesUsed;
};

/** struct Default */
struct SpuDecoder_Open_type {
	/** Member default */
	RMuint32 BitstreamFIFOSize;
	/** Member default */
	RMuint32 XferFIFOCount;
	/** Member default */
	RMuint32 CachedAddress;
	/** Member default */
	RMuint32 CachedSize;
	/** Member default */
	RMuint32 UncachedAddress;
	/** Member default */
	RMuint32 UncachedSize;
	/** Member default */
	RMuint32 DemuxProgramId;
};

/** enum Default */
enum SpuDecoder_Command_type {
	/** In Enum default */
	SpuDecoder_Command_Uninit,
	/** In Enum default */
	SpuDecoder_Command_Init,
	/** In Enum default */
	SpuDecoder_Command_Stop,
	/** In Enum default */
	SpuDecoder_Command_Play,
};

/** enum Default */
enum SpuDecoder_State_type {
	/** In Enum default */
	SpuDecoder_State_Uninitialized,
	/** In Enum default */
	SpuDecoder_State_UninitPending,
	/** In Enum default */
	SpuDecoder_State_InitPending,
	/** In Enum default */
	SpuDecoder_State_Stopped,
	/** In Enum default */
	SpuDecoder_State_StopPending,
	/** In Enum default */
	SpuDecoder_State_Playing,
	/** In Enum default */
	SpuDecoder_State_PlayPending,
};

/** fill all 16*4 PGC_SP_PLT entries into LUT, with 0,Y,Cr,Cb) */
struct SpuDecoder_Palette_type {
	/** Member default */
	RMuint8 LUT[16*4];
};

/** Description of the current sub picture stream number from PGC_SPST_CTL */
enum SpuDecoder_StreamType_type {
	/** In Enum default */
	SpuDecoder_StreamType_4by3 = 0,
	/** In Enum default */
	SpuDecoder_StreamType_Wide,
	/** In Enum default */
	SpuDecoder_StreamType_Letterbox,
	/** In Enum default */
	SpuDecoder_StreamType_PanScan,
};

/**  */
struct SpuDecoder_Hilight_type {
	/** Member default */
	RMuint16 leftb;
	/** Member default */
	RMuint16 topb;
	/** Member default */
	RMuint16 rightb;
	/** Member default */
	RMuint16 bottomb;
	/** Member default */
	RMuint16 color;
	/** Member default */
	RMuint16 contrast;
	/** Member default */
	RMbool on;
	/** Member default */
	RMuint64 pts;
};

/**  */
struct SpuDecoder_BDRLECommand_type {
	/** Member default */
	RMuint32 command;
	/** Member default */
	RMuint32 parameter1;
	/** Member default */
	RMuint32 parameter2;
};

/**  */
struct SpuDecoder_BDRLEBatchCommand_type {
	/** Member default */
	struct SpuDecoder_BDRLECommands commands;
};

/** struct Default */
struct SpuDecoder_OpenX_type {
	/**  */
	RMuint32 ProtectedFlags;
	/** input video stream data fifo */
	RMuint32 BitstreamFIFOSize;
	/** total data size needed for decoder for picture buffers and context */
	RMuint32 DecoderDataSize;
	/** decoder context memory - to be calculated inside microcode and removed from interface */
	RMuint32 DecoderContextSize;
	/** number of buffers needed for deinterlacing, gfx access */
	RMuint32 ExtraPictureBufferCount;
	/** Member default */
	RMuint32 XferFIFOCount;
	/** Member default */
	RMuint32 PtsFIFOCount;
	/** Member default */
	RMuint32 InbandFIFOCount;
	/** Member default */
	RMuint32 XtaskInbandFIFOCount;
	/** index of STC */
	RMuint32 STCId;
	/** index of Xtask module */
	RMuint32 XtaskId;
	/** Member default */
	RMuint32 PictureProtectedAddress;
	/** Member default */
	RMuint32 PictureProtectedSize;
	/** Member default */
	RMuint32 BitstreamProtectedAddress;
	/** Member default */
	RMuint32 BitstreamProtectedSize;
	/** Member default */
	RMuint32 UnprotectedAddress;
	/** Member default */
	RMuint32 UnprotectedSize;
	/** Number of buttons */
	RMuint32 HilightCount;
};

/** struct Default */
struct PictureTransform_Open_type {
	/** Member default */
	RMuint32 InputSurface;
	/** Member default */
	enum EMhwlibPictureTransformType TransformType;
	/** Member default */
	RMbool InPlace;
	/** Member default */
	RMuint32 STCId;
	/** Member default */
	RMuint32 InbandFIFOCount;
	/** Member default */
	RMuint32 DecoderDataAddress;
	/** Member default */
	RMuint32 DecoderInterfaceAddress;
	/** Member default */
	RMuint32 DecoderDataSize;
	/** Member default */
	RMuint32 DecoderInterfaceSize;
};

/** enum Default */
enum PictureTransform_Command_type {
	/** In Enum default */
	PictureTransform_Command_Uninit,
	/** In Enum default */
	PictureTransform_Command_Init,
	/** In Enum default */
	PictureTransform_Command_Stop,
	/** In Enum default */
	PictureTransform_Command_Play,
};

/** enum Default */
enum PictureTransform_State_type {
	/** In Enum default */
	PictureTransform_State_Uninitialized,
	/** In Enum default */
	PictureTransform_State_UninitPending,
	/** In Enum default */
	PictureTransform_State_InitPending,
	/** In Enum default */
	PictureTransform_State_Stopped,
	/** In Enum default */
	PictureTransform_State_StopPending,
	/** In Enum default */
	PictureTransform_State_Playing,
	/** In Enum default */
	PictureTransform_State_PlayPending,
};

/** struct Default */
struct ClosedCaptionDecoder_DRAMSize_type {
	/** Member default */
	RMuint32 CachedSize;
	/** Member default */
	RMuint32 UncachedSize;
};

/** struct Default */
struct ClosedCaptionDecoder_Open_type {
	/** Member default */
	RMuint32 CachedAddress;
	/** Member default */
	RMuint32 CachedSize;
	/** Member default */
	RMuint32 UncachedAddress;
	/** Member default */
	RMuint32 UncachedSize;
	/** Member default */
	RMuint32 ModuleNumber;
	/** Member default */
	RMuint32 OSDAddress;
	/** Member default */
	RMuint32 OSDWidth;
	/** Member default */
	RMuint32 OSDHeight;
	/** Member default */
	RMuint32 OSDVisiblePartX;
	/** Member default */
	RMuint32 OSDVisiblePartY;
	/** Member default */
	RMuint32 OSDColorDepth;
};

/** struct Default */
struct ClosedCaptionDecoder_FeedDecoder_type {
	/** Member default */
	RMuint8 Data[0x100];
	/** Member default */
	RMuint32 Size;
};

/** struct Default */
struct RTC_Alarm_type {
	/** Member default */
	RMuint32 EventID;
	/** Member default */
	RMuint32 Delay;
};

/**  */
struct Cipher_RC4_KeySetup_type {
	/** Member default */
	RMRC4Key key;
	/** Member default */
	RMuint32 size;
};

/** Set the timer Ids and master type. */
struct STC_Open_type {
	/** Member default */
	enum Master_type master;
	/** Member default */
	RMuint32 stc_timer_id;
	/** Member default */
	RMuint32 stc_time_resolution;
	/** Member default */
	RMuint32 video_timer_id;
	/** Member default */
	RMuint32 video_time_resolution;
	/** Member default */
	RMint32 video_offset;
	/** Member default */
	RMuint32 audio_timer_id;
	/** Member default */
	RMuint32 audio_time_resolution;
	/** Member default */
	RMint32 audio_offset;
};

/** The new offset is set. The video time is set according to the offset. */
struct STC_VideoOffset_type {
	/**  */
	RMuint32 time_resolution;
	/**  */
	RMint32 time;
};

/** The new offset is set. The video time is set according to the offset. */
struct STC_AudioOffset_type {
	/**  */
	RMuint32 time_resolution;
	/**  */
	RMint32 time;
};

/** The time is set for all dependent timers - stc, video and audio timers, according to their corresponding time resolution and offset. */
struct STC_Time_type {
	/**  */
	RMuint32 time_resolution;
	/**  */
	RMuint64 time;
};

/** The time resolution is multiplied by nominator and divided by denominator and set for every timer - stc, video, audio. */
struct STC_Speed_type {
	/**  */
	RMint32 nominator;
	/**  */
	RMuint32 denominator;
	/**  */
	enum StcFilter_type stc_filter;
	/** obsolete, unused */
	enum CorrectionMethod_type stc_correction_method;
	/** obsolete, unused */
	enum CorrectionMethod_type video_correction_method;
	/** obsolete, unused */
	enum CorrectionMethod_type audio_correction_method;
};

/**  */
struct STC_Discontinuity_type {
	/**  */
	RMuint32 time_resolution;
	/**  */
	RMuint64 time;
};

/**  */
struct STC_StcInfo_type {
	/** Member default */
	RMuint32 status;
	/** Member default */
	enum Master_type master;
	/** Member default */
	RMuint32 stc_timer_id;
	/** Member default */
	RMuint32 stc_time_resolution;
	/** Member default */
	RMuint32 video_timer_id;
	/** Member default */
	RMuint32 video_time_resolution;
	/** Member default */
	RMint32 video_offset;
	/** Member default */
	RMuint32 audio_timer_id;
	/** Member default */
	RMuint32 audio_time_resolution;
	/** Member default */
	RMint32 audio_offset;
};

/** struct Default */
struct PLL_PLL_type {
	/** specifies PLL range 0 -> 3 */
	enum PLLGen PLL;
	/** max value of PLL divider range 0 -> 127 */
	RMuint32 MaxM;
	/** Frequency of output 0, in Hz range 0 -> 1000000000 */
	RMuint32 Frequency0;
	/** Frequency of output 1, in Hz range 0 -> 500000000 */
	RMuint32 Frequency1;
	/** Frequency of output 2, in Hz range 0 -> 500000000 */
	RMuint32 Frequency2;
};

/** update internal values without changing PLL registers */
struct PLL_PLLUsage_type {
	/** specifies PLL range 0 -> 3 */
	enum PLLGen PLL;
	/** max value of PLL divider range 0 -> 127 */
	RMuint32 MaxM;
	/** Frequency of output 0, in Hz range 0 -> 1000000000 */
	RMuint32 Frequency0;
	/** Frequency of output 1, in Hz range 0 -> 500000000 */
	RMuint32 Frequency1;
	/** Frequency of output 2, in Hz range 0 -> 500000000 */
	RMuint32 Frequency2;
};

/** struct Default */
struct PLL_CD_type {
	/** specifies Clean Divider range 4 -> 14 */
	enum PLLGen PLL;
	/** Frequency of the output, in Hz range 0 -> 1000000000 */
	RMuint32 Frequency;
};

/** update internal values without changing PLL registers */
struct PLL_CDUsage_type {
	/** specifies Clean Divider range 4 -> 14 */
	enum PLLGen PLL;
	/** Frequency of the output, in Hz range 0 -> 1000000000 */
	RMuint32 Frequency;
};

/** struct Default */
struct PLL_PLLSource_type {
	/** specifies PLL range 0 -> 3 */
	enum PLLGen PLL;
	/** input clock signal of a PLL range 0 -> 7 */
	enum PLLSource ClockSource;
};

/** struct Default */
struct PLL_SourceFrequency_type {
	/** input clock signal of a PLL range 0 -> 7 */
	enum PLLSource ClockSource;
	/** Nominal frequency of the source range 1 -> 1000000000 */
	RMuint32 Frequency;
};

/** struct Default */
struct PLL_RouteClockFromPLL_type {
	/** specifies PLL or Clean Divider range 0 -> 14 */
	enum PLLGen PLL;
	/** specifies PLL output of CD post divider range 0 -> 2 */
	enum PLLOut PLLOutput;
	/** clock signal range 0 -> 19 */
	enum ClockSignal Clock;
};

/** struct Default */
struct PLL_RouteClockFromSource_type {
	/** input clock signal range 0 -> 7 */
	enum PLLSource ClockSource;
	/** clock signal range 0 -> 19 */
	enum ClockSignal Clock;
};

/** struct Default */
struct PLL_Frequency_type {
	/** specifies PLL or Clean Divider range 0 -> 14 */
	enum PLLGen PLL;
	/** specifies PLL output of CD post divider range 0 -> 2 */
	enum PLLOut PLLOutput;
	/** max value of PLL divider range 0 -> 127 */
	RMuint32 MaxM;
	/** clock signal range 0 -> 19 */
	enum ClockSignal Clock;
	/** Nominal frequency of the source range 1 -> 1000000000 */
	RMuint32 Frequency;
};

/** struct Default */
struct PLL_CounterSource_type {
	/** specifies configurable counter range 7 -> 11 */
	enum ClockCounter Counter;
	/** specified source signal for the counter range 1 -> 15 */
	enum ClockCounterSource Source;
};

/** struct Default */
struct PLL_Counter_type {
	/** specifies counter range 0 -> 11 */
	enum ClockCounter Counter;
	/** specified source signal for a configurable counter, ignored for others range 1 -> 15 */
	enum ClockCounterSource Source;
	/** counter value */
	RMuint32 Ticks;
};

/** struct Default */
struct PLL_BootirqSettings_type {
	/** Member default */
	RMuint32 SYS_cleandiv8_div_val;
	/** Member default */
	RMuint32 SYS_cleandiv8_ctrl_val;
	/** Member default */
	RMuint32 SYS_cleandiv9_div_val;
	/** Member default */
	RMuint32 SYS_cleandiv9_ctrl_val;
	/** Member default */
	RMuint32 SYS_cleandiv10_div_val;
	/** Member default */
	RMuint32 SYS_cleandiv10_ctrl_val;
	/** Member default */
	RMuint32 SYS_clkgen1_pll_val;
	/** Member default */
	RMuint32 SYS_clkgen1_div_val;
	/** Member default */
	RMuint32 SYS_sysclk_premux_val;
	/** Member default */
	RMuint32 SYS_avclk_mux_val;
};

/**  */
struct DemuxCipher_Open_type {
	/** Member default */
	RMuint32 UnprotectedAddress;
	/** Member default */
	RMuint32 UnprotectedSize;
	/** Member default */
	RMuint32 bufferCount;
};

/** Pointer to the DemuxInterface context */
struct DemuxCipher_DemuxInterface_type {
	/** This is the fifo that contains the CipherNodes (not data fifo) */
	RMuint32 fifoWrPtr;
	/** This is the fifo that contains the CipherNodes (not data fifo) */
	RMuint32 fifoRdPtr;
	/** Report status of CipherOnlyTask */
	RMuint32 errStatus;
};

/**  */
struct DemuxCipher_AESCipherEntry_type {
	/**  */
	RMuint32 index;
	/**  */
	enum EMhwlibAESCipherMode mode;
	/**  */
	RMuint32 key_size;
	/**  */
	RMuint32 block_size;
	/**  */
	enum EMhwlibAESEncryptedPacketFormat encrypted_packet_format;
};

/**  release a key_index for the specified cipher  */
struct DemuxCipher_FreeKeyEntry_type {
	/**  */
	enum EMhwlibCipher cipher_type;
	/**  */
	RMuint32 key_index;
};

/** change the key index instantaneously  */
struct DemuxCipher_OutbandKeyChange_type {
	/**  */
	enum EMhwlibCipher cipher_type;
	/** index in CipherTable */
	RMuint32 cipher_index;
	/**  */
	RMuint32 key_index;
	/** specifies the scrambling bits of the packets affected by the key */
	enum EMhwlibScramblingBits scrambling;
};

/** Sets the required resources (Memory ...) for demux.@note @li The ProtectedSize and UnprotectedSize values can be obtained using the ::RMDemuxPropertyID_DRAMSize exchange properties. The application has to provide these values since it is solely responsible for the DDR-DRAM memory allocation in each DRAM controller.@li The ProtectedAddress and UnprotectedAddress can be obtained in the RUA interface by calling RUAMalloc. */
struct DemuxTask_Open_type {
	/**  */
	RMuint32 ProtectedFlags;
	/** Member default */
	RMuint32 BitstreamFIFOSize;
	/** Member default */
	RMuint32 XferFIFOCount;
	/** input port streaming SPI */
	RMuint32 InputPort;
	/** MPM used for parsing */
	RMuint32 PrimaryMPM;
	/** MPM used for input for transport file playback, used for 8634, ignored for 8622. */
	RMuint32 SecondaryMPM;
	/** Member default */
	RMuint32 InbandFIFOCount;
	/** Member default */
	RMuint32 BitstreamProtectedAddress;
	/** Member default */
	RMuint32 BitstreamProtectedSize;
	/** Member default */
	RMuint32 UnprotectedAddress;
	/** Member default */
	RMuint32 UnprotectedSize;
};

/** Sets the required resources (Memory ...) for demux.@note @li The ProtectedSize and UnprotectedSize values can be obtained using the ::RMDemuxPropertyID_DRAMSize exchange properties. The application has to provide these values since it is solely responsible for the DDR-DRAM memory allocation in each DRAM controller.@li The ProtectedAddress and UnprotectedAddress can be obtained in the RUA interface by calling RUAMalloc. */
struct DemuxTask_OpenX_type {
	/**  */
	RMuint32 ProtectedFlags;
	/** Member default */
	RMuint32 BitstreamFIFOSize;
	/** Member default */
	RMuint32 XferFIFOCount;
	/** input port streaming SPI  */
	RMuint32 InputPort;
	/** MPM used for parsing */
	RMuint32 PrimaryMPM;
	/** MPM used for input for transport file playback  */
	RMuint32 SecondaryMPM;
	/** Member default */
	RMuint32 InbandFIFOCount;
	/** Member default */
	RMuint32 BitstreamProtectedAddress;
	/** Member default */
	RMuint32 BitstreamProtectedSize;
	/** Member default */
	RMuint32 UnprotectedAddress;
	/** Member default */
	RMuint32 UnprotectedSize;
	/** XTask module id */
	RMuint32 XTaskModuleId;
	/**  */
	RMuint32 XTaskContext;
	/** Member default */
	RMuint32 XTaskInbandFIFOCount;
};

/**  */
struct DemuxTask_AvailableResourcesInfo_type {
	/**  */
	RMuint32 pid_count;
	/**  */
	RMuint32 section_count;
	/**  */
	RMuint32 cipher_count;
	/**  */
	RMuint32 AES_key_count;
	/**  */
	RMuint32 DES_key_count;
	/**  */
	RMuint32 DVBCSA_key_count;
	/**  */
	RMuint32 Multi2_key_count;
	/**  */
	RMuint32 C2_key_count;
	/**  */
	RMuint32 DVD_key_count;
};

/**  Demux outband command (play, pause, stop).@note @li This property should be called after the microcode is loaded using the ::RMDemuxEnginePropertyID_MicrocodeVersion property.@li Use the RUAWaitForMultipleEvent or ::RMDemuxPropertyID_State to wait for the command completion. */
enum DemuxTask_Command_type {
	/** In Enum default */
	DemuxTask_Command_Play,
	/** In Enum default */
	DemuxTask_Command_Pause,
	/** In Enum default */
	DemuxTask_Command_Stop,
};

/**  */
enum DemuxTask_State_type {
	/** In Enum default */
	DemuxTask_State_Playing,
	/** In Enum default */
	DemuxTask_State_Paused,
	/** In Enum default */
	DemuxTask_State_Stopped,
	/** In Enum default */
	DemuxTask_State_PlayPending,
	/** In Enum default */
	DemuxTask_State_PausePending,
	/** In Enum default */
	DemuxTask_State_StopPending,
};

/**  */
struct DemuxTask_InputParameters_type {
	/** One of No_Spi, Serial_Spi, Paralel_Spi */
	enum DemuxSpiType Spi;
	/** One of SourceType_atsc, SourceType_dvb, SourceType_dvd, SourceType_m1s, SourceType_m2t */
	enum DemuxSourceType SourceType;
};

/**  */
struct DemuxTask_ConnectOutput_type {
	/** Member default */
	RMuint32 output_index;
	/** Member default */
	RMuint32 stc_module_id;
};

/** Additional auxiliary values required by the transport demux in some custom application (not a main-stream property) */
struct DemuxTask_AuxiliaryInfoValue_type {
	/** Member default */
	RMuint32 InfoIndex;
	/** Member default */
	RMuint32 InfoValue;
};

/** per task */
struct DemuxTask_Encryption_type {
	/**  */
	enum EncryptionType Type;
	/** support maximum 256 bits key = 32 bytes */
	RMuint8x32 Key;
	/** support maximum 256 bits key = 32 bytes */
	RMuint8x32 IV;
};

/** PesTable[index] is set to new PesEntry parameters. */
struct DemuxTask_PesEntry_type {
	/** Member default */
	RMuint32 index;
	/** stream id, substream id, input_type */
	struct EMhwlibPesEntry_type PesEntry;
};

/** SectionTable[Index] is set to new SectionEntry parameters. */
struct DemuxTask_MatchSectionEntry_type {
	/** Member default */
	RMuint32 Index;
	/**  expand_link_index, and_link_index, mask[12], mode[12], comp[12] */
	struct PSFMatchSection_type SectionEntry;
};

/** PidTable[index] is set to new PidEntry parameters. */
struct DemuxTask_PidEntry_type {
	/** Member default */
	RMuint32 index;
	/** pid value, input_type (TS ciphered or not), flags (bit field indicating ignore_error_indicator, ignore_continuity_counter, splicing_enable) */
	struct EMhwlibPidEntry_type PidEntry;
};

/** Add cipher for this PidEntry. The cipher should be already created. */
struct DemuxTask_PidEntryAddCipher_type {
	/**  */
	RMuint32 index;
	/** Value should be 0. Only one cipher is supported in current code. */
	RMuint32 pid_cipher_index;
	/** index pointing in CipherTable */
	RMuint32 cipher_index;
};

/** Remove cipher from this PidEntry. */
struct DemuxTask_PidEntryRemoveCipher_type {
	/**  */
	RMuint32 index;
	/**  */
	RMuint32 pid_cipher_index;
};

/**  */
struct DemuxTask_PcrDiscontinuity_type {
	/** When a Pcr discontinuity greater than the threshold is detected, demux microcode inserts inband commands for video/audio and issues interrupt to host */
	RMuint32 threshold;
	/**  */
	RMuint32 time_resolution;
};

/**  */
struct DemuxTask_OutputThreshold_type {
	/**  */
	RMuint32 output_index;
	/** TRUE means one section at a time, or get interrupt after threshold bytes. */
	RMbool partial_read;
	/** threshold in bytes */
	RMuint32 threshold;
};

/**  */
struct DemuxTask_OutputTimerSync_type {
	/**  */
	RMuint32 output_index;
	/** One of None, FirstPcrOnly, Pcr. First Pcr encountered after a stop/play sequence is set in output timer. The timer is activated. */
	enum EMhwlibTimerSync timer_sync;
};

/**  */
struct DemuxTask_PreprocessCipher_type {
	/**  */
	RMuint32 cipher_index;
	/** if TRUE the input will be descrambled before parsing */
	RMbool enable;
};

/**  */
struct DemuxTask_DESCipherEntry_type {
	/**  */
	RMuint32 index;
	/**  */
	enum EMhwlibDESCipherMode mode;
	/**  */
	enum EMhwlibDESEncryptedPacketFormat encrypted_packet_format;
};

/**  */
struct DemuxTask_TDESCipherEntry_type {
	/** same implementation as DESCipherEntry - remove it ??  */
	RMuint32 index;
	/**  */
	enum EMhwlibDESCipherMode mode;
	/**  */
	enum EMhwlibDESEncryptedPacketFormat encrypted_packet_format;
};

/**  */
struct DemuxTask_AESCipherEntry_type {
	/**  */
	RMuint32 index;
	/**  */
	enum EMhwlibAESCipherMode mode;
	/**  */
	RMuint32 key_size;
	/**  */
	RMuint32 block_size;
	/**  */
	enum EMhwlibAESEncryptedPacketFormat encrypted_packet_format;
};

/**  */
struct DemuxTask_RC4CipherEntry_type {
	/**  */
	RMuint32 index;
	/**  */
	RMuint32 key_size;
};

/**  */
struct DemuxTask_DVBCSACipherEntry_type {
	/**  */
	RMuint32 index;
};

/**  */
struct DemuxTask_Multi2CipherEntry_type {
	/**  */
	RMuint32 index;
	/**  */
	enum EMhwlibMulti2CipherMode mode;
	/**  */
	RMuint32 round_value;
};

/**  */
struct DemuxTask_C2CipherEntry_type {
	/**  */
	RMuint32 index;
	/**  */
	enum EMhwlibC2CipherMode mode;
};

/**  */
struct DemuxTask_DVDCSSCipherEntry_type {
	/**  */
	RMuint32 index;
};

/** change the key index instantaneously  */
struct DemuxTask_OutbandKeyChange_type {
	/**  */
	enum EMhwlibCipher cipher_type;
	/** index in CipherTable */
	RMuint32 cipher_index;
	/**  */
	RMuint32 key_index;
	/** specifies the scrambling bits of the packets affected by the key */
	enum EMhwlibScramblingBits scrambling;
};

/**  release a key_index for the specified cipher  */
struct DemuxTask_FreeKeyEntry_type {
	/**  */
	enum EMhwlibCipher cipher_type;
	/**  */
	RMuint32 key_index;
};

/**  */
struct DemuxTask_InbandKeyChange_type {
	/** index in CipherTable */
	RMuint32 cipher_index;
	/** index in specific key table. If key is not valid no cipher will be applied */
	RMuint32 key_index;
	/** specifies the scrambling bits of the packets affected by the key */
	enum EMhwlibScramblingBits scrambling;
	/** specifies if offset_value is used, is relative or absolute */
	enum EMhwlibInbandOffset offset_control;
	/** offset in bytes */
	RMuint32 offset_value;
};

/**  */
struct DemuxTask_DESKey_type {
	/** index in TDESTable, if key is not valid no cipher will be applied */
	RMuint32 key_index;
	/**  */
	RMuint8x8 key;
	/**  */
	RMuint8x8 iv;
};

/**  */
struct DemuxTask_TDESKey_type {
	/** index in TDESTable, if key is not valid no cipher will be applied */
	RMuint32 key_index;
	/**  */
	RMuint8x8 key1;
	/**  */
	RMuint8x8 key2;
	/**  */
	RMuint8x8 key3;
	/**  */
	RMuint8x8 iv;
};

/**  */
struct DemuxTask_AESKey_type {
	/** index in AESTable, if key is not valid no cipher will be applied */
	RMuint32 key_index;
	/** size of key and iv in bytes */
	RMuint32 key_size;
	/** 32 bytes is maximum size of the key */
	RMuint8x32 key;
	/**  */
	RMuint8x32 iv;
};

/**  */
struct DemuxTask_RC4Key_type {
	/** index in Rc4Table, if key is not valid no cipher will be applied */
	RMuint32 key_index;
	/**  */
	RMuint8x32 key;
};

/**  */
struct DemuxTask_DVBCSAKey_type {
	/** index in DVBCSATable, if key is not valid no cipher will be applied */
	RMuint32 key_index;
	/**  */
	RMuint8x8 key;
};

/**  */
struct DemuxTask_Multi2Key_type {
	/** index in Multi2Table, if key is not valid no cipher will be applied */
	RMuint32 key_index;
	/**  */
	RMuint8x32 system_key;
	/**  */
	RMuint8x8 data_key;
	/**  */
	RMuint8x8 iv;
};

/**  */
struct DemuxTask_C2Key_type {
	/** index in C2Table, if key is not valid no cipher will be applied */
	RMuint32 key_index;
	/**  */
	RMuint8x6 key;
};

/** To be used as extension to RMDemuxTaskPropertyID_TimerSync */
struct DemuxTask_FirstPcrOrPtsDetection_type {
	/**  Maximum time to wait for PCR value in stream. After that the first PTS coming is taken as PCR. Value expressed in 45k unit. Default 0.  */
	RMuint32 wait_for_pcr_time;
	/** In case the PTS is taken as PCR we should decrease the PTS value for prebuffering. Value expressed in 45k unit. Default 0.  */
	RMuint32 pts_taken_as_pcr_offset;
};

/** enable or disable reciphering for this PidEntry. The cipher should be already created. A Pid that will be reciphered cannot be parsed in the same time. */
struct DemuxTask_PidEntryRecipher_type {
	/** pid_index */
	RMuint32 index;
	/** Only one global cipher per task is supported. */
	RMbool enable;
};

/**  */
struct DemuxTask_RecipherOptions_type {
	/**  */
	RMuint32 cipher_index;
	/** EMhwlibRecipher_passthrough reciphers only the encrypted TS packets. EMhwlibRecipher_always reciphers all the TS packets. */
	enum EMhwlibRecipherMode mode;
	/** Used for the reciphered output when the input TS packet is clear.  */
	RMuint32 scrambling_bits;
};

/** Sets the required resources (Memory ...) for demux.@note @li The ProtectedSize and UnprotectedSize values can be obtained using the ::RMDemuxOutputPropertyID_DRAMSize exchange properties. The application has to provide the memory since it is solely responsible for the DDR-DRAM memory allocation in each DRAM controller. */
struct DemuxOutput_Open_type {
	/**  */
	RMuint32 ProtectedFlags;
	/** bitstream fifo */
	RMuint32 BitstreamFIFOSize;
	/** Member default */
	RMuint32 XferFIFOCount;
	/** timestamp fifo */
	RMuint32 PtsFIFOCount;
	/** inband fifo. */
	RMuint32 InbandFIFOCount;
	/**  */
	RMuint32 demux_task_module_id;
	/**  */
	RMuint32 stc_module_id;
	/** Member default */
	RMuint32 BitstreamProtectedAddress;
	/** Member default */
	RMuint32 BitstreamProtectedSize;
	/** Member default */
	RMuint32 UnprotectedAddress;
	/** Member default */
	RMuint32 UnprotectedSize;
};

/** Sets the required resources (Memory ...) for demux.@note @li The ProtectedSize and UnprotectedSize values can be obtained using the ::RMDemuxOutputPropertyID_DRAMSize exchange properties. The application has to provide the memory since it is solely responsible for the DDR-DRAM memory allocation in each DRAM controller. */
struct DemuxOutput_OpenX_type {
	/**  */
	RMuint32 ProtectedFlags;
	/** bitstream fifo */
	RMuint32 BitstreamFIFOSize;
	/** Member default */
	RMuint32 XferFIFOCount;
	/** timestamp fifo */
	RMuint32 PtsFIFOCount;
	/** inband fifo. */
	RMuint32 InbandFIFOCount;
	/**  */
	RMuint32 demux_task_module_id;
	/**  */
	RMuint32 stc_module_id;
	/** Member default */
	RMuint32 BitstreamProtectedAddress;
	/** Member default */
	RMuint32 BitstreamProtectedSize;
	/** Member default */
	RMuint32 UnprotectedAddress;
	/** Member default */
	RMuint32 UnprotectedSize;
	/** Xtask module id */
	RMuint32 XtaskModuleId;
	/**  */
	RMuint32 XtaskContext;
	/** Member default */
	RMuint32 XtaskInbandFIFOCount;
};

/** It connects the output generated by demux_task_module_id with the consumer_module_id. Consumers supported are VideoDecoder, AudioDecoder and SpuDecoder. */
struct DemuxOutput_Connect_type {
	/**  */
	RMuint32 demux_task_module_id;
	/**  */
	RMuint32 consumer_module_id;
};

/** It disconnects the output generated by demux_task_module_id from the consumer_module_id. If demux output was opened prior to Connect the open parameters are restored. Consumers supported are VideoDecoder, AudioDecoder and SpuDecoder. */
struct DemuxOutput_Disconnect_type {
	/**  */
	RMuint32 demux_task_module_id;
	/**  */
	RMuint32 consumer_module_id;
};

/**  */
struct DemuxOutput_Cipher_type {
	/** index in CipherTable */
	RMuint32 cipher_index;
	/** enable or disable cipher on the output */
	RMbool enable;
	/** if TRUE use input buffer as output */
	RMbool in_place;
};

/** struct Default */
struct DemuxOutput_Pts45kFifoEntry_type {
	/** Member default */
	RMuint32 pts;
	/** Member default */
	RMuint32 byte_counter;
};

/** struct Default */
struct CCFifo_Open_type {
	/** Member default */
	RMuint32 EntryCount;
	/** Member default */
	RMuint32 UncachedAddress;
	/** Member default */
	RMuint32 UncachedSize;
	/** Member default */
	RMuint32 STCModuleId;
};

/** struct Default */
struct CCFifo_AllowedTypes_type {
	/** Member default */
	RMbool Allow608;
	/** Member default */
	RMbool Allow708;
};

/** struct Default */
struct CCFifo_CCEntry_type {
	/** Member default */
	RMbool Enable;
	/** Member default */
	RMbool PtsEnable;
	/** Member default */
	enum EMhwlibCCType Type;
	/** Member default */
	RMuint64 Pts;
	/** Member default */
	RMuint8 CC1;
	/** Member default */
	RMuint8 CC2;
};

/** Specifies what color becomes transparent.@note The alpha plane below this plane will be visible */
struct DispVideoPlane_Transparency_type {
	/** Member default */
	RMbool Y_255;
	/** Member default */
	RMbool Y_0;
};

/** struct Default */
struct DispHDSDConverter_Open_type {
	/** Member default */
	struct EMhwlibTVFormatAnalog SDFormat;
	/** Member default */
	RMuint32 BufferAddress;
	/** Member default */
	RMuint32 BufferSize;
};

/** struct Default */
struct DispHDSDConverter_OpenX_type {
	/** Member default */
	struct EMhwlibGenericTVFormat HDFormat;
	/** Member default */
	struct EMhwlibGenericTVFormat SDFormat;
	/** Member default */
	RMuint32 BufferSize;
	/** Member default */
	RMuint32 BufferAddress;
};

/** struct Default */
struct DispHDSDConverter_ConversionBuffer_type {
	/** Member default */
	RMuint32 BufferAddress;
	/** Member default */
	RMuint32 BufferSize;
};

/** struct Default */
struct Sha1Sum_Open_type {
	/** Member default */
	RMuint32 BitstreamFIFOSize;
	/** Member default */
	RMuint32 XferFIFOCount;
	/** Member default */
	RMuint32 XTaskModuleID;
	/** Member default */
	RMuint32 KeyIndex;
	/** Member default */
	RMuint32 ClearAddress;
	/** Member default */
	RMuint32 ClearSize;
	/** Member default */
	RMuint32 EncryptedAddress;
	/** Member default */
	RMuint32 EncryptedSize;
};

/** struct Default */
struct XTask_AddDRMTask_type {
	/** Member default */
	RMuint32 drm_task_address;
	/** Member default */
	RMuint32 data_fifo;
	/** Member default */
	RMuint32 inband_cmd_fifo;
	/** Member default */
	RMuint32 decoder_inband_cmd_fifo;
	/** Member default */
	RMuint32 key_index;
	/** Member default */
	RMuint32 soft_irq_task;
};

/** struct Default */
struct TTXFifo_Open_type {
	/** Member default */
	RMuint32 EntryCount;
	/** Member default */
	RMuint32 UncachedAddress;
	/** Member default */
	RMuint32 UncachedSize;
	/** Member default */
	RMuint32 STCModuleId;
};

/** struct Default */
struct TTXFifo_TTXEntry_type {
	/** Member default */
	RMuint32 TtxPtr;
};

/** struct Default */
struct VCXO_Speed_type {
	/**  */
	RMint32 N;
	/**  */
	RMuint32 M;
};

/**  */
struct PPF_InputSurface_type {
	/**  */
	RMint32 Surface;
	/**  */
	RMuint32 Slot;
};

/** struct Default */
struct PPF_OpenOutputSurface_type {
	/** Member default */
	RMuint32 Slot;
	/** Member default */
	struct EMhwlibMemoryBlockList BlockList;
};

/**  */
struct PPF_TriggerEvent_type {
	/**  */
	RMint32 ModuleID;
	/**  */
	RMuint32 Mask;
};

/** struct Default */
struct SystemBlock_QueryGPIO_in_type {
	/** Member default */
	enum GPIOId_type Bit;
};

/** status information on the pulse width modulation generators on GPIO pins 14 and 15 */
struct SystemBlock_QueryPWM_in_type {
	/** PWM generator number. @note 0 for GPIO 14, 1 for GPIO 15 range 0 -> 1 */
	RMuint32 GeneratorNumber;
};

/** struct Default */
struct SystemBlock_DRAMSize_in_type {
	/** Member default range 0 -> 2 */
	RMuint32 Controller;
};

/** returns the required DRAM size, in bytes, as well as the buffer sizes for luma and chroma for a given format and image size. also allots space for vsync surface struct. the chroma plane has to follow the luma plane immediately in memory */
struct DisplayBlock_SurfaceSize_in_type {
	/** format mode of the image */
	enum EMhwlibColorMode ColorMode;
	/** format submode of the image */
	enum EMhwlibColorFormat ColorFormat;
	/** Chroma mode of the image */
	enum EMhwlibSamplingMode SamplingMode;
	/** width of the image in pixel range 1 -> 4096 */
	RMuint32 Width;
	/** height of the image in pixel range 1 -> 4096 */
	RMuint32 Height;
};

/** returns the required DRAM size, in bytes, as well as the buffer sizes for luma and chroma for a given format and image size. also allots space for vsync surface struct. the chroma plane has to follow the luma plane immediately in memory */
struct DisplayBlock_PictureSize_in_type {
	/** format mode of the image */
	enum EMhwlibColorMode ColorMode;
	/** format submode of the image */
	enum EMhwlibColorFormat ColorFormat;
	/** Chroma mode of the image */
	enum EMhwlibSamplingMode SamplingMode;
	/** width of the image in pixel range 1 -> 4096 */
	RMuint32 Width;
	/** height of the image in pixel range 1 -> 4096 */
	RMuint32 Height;
};

/** initialize a static surface */
struct DisplayBlock_InitSurface_in_type {
	/** format mode of the image */
	enum EMhwlibColorMode ColorMode;
	/** format submode of the image */
	enum EMhwlibColorFormat ColorFormat;
	/** Chroma mode of the image */
	enum EMhwlibSamplingMode SamplingMode;
	/** width of the image in pixel range 1 -> 4096 */
	RMuint32 Width;
	/** height of the image in pixel range 1 -> 4096 */
	RMuint32 Height;
	/** amount of data that has to be allocated by the application */
	RMuint32 Address;
	/** size, in bytes, of the luma plane in DRAM\n */
	RMuint32 LumaSize;
	/** size, in bytes, of the chroma plane in DRAM\n */
	RMuint32 ChromaSize;
	/** color space of the surface */
	enum EMhwlibColorSpace ColorSpace;
	/** pixel aspect ratio of the surface */
	struct EMhwlibAspectRatio PixelAspectRatio;
};

/** returns the required DRAM size, in bytes, as well as the buffer sizes for luma and chroma for a given format and image size. also allots space for vsync surface struct. the chroma plane has to follow the luma plane immediately in memory */
struct DisplayBlock_InitPicture_in_type {
	/** width of the image in pixel range 1 -> 4096 */
	RMuint32 Width;
	/** height of the image in pixel range 1 -> 4096 */
	RMuint32 Height;
	/** amount of data that has to be allocated by the application */
	RMuint32 Address;
	/** size, in bytes, of the luma plane in DRAM\n */
	RMuint32 LumaSize;
	/** size, in bytes, of the chroma plane in DRAM\n */
	RMuint32 ChromaSize;
};

/** returns the required DRAM size, in bytes, as well as the buffer sizes for luma and chroma for a given format and image size. also allots space for vsync surface struct. the chroma plane has to follow the luma plane immediately in memory */
struct DisplayBlock_InitPictureX_in_type {
	/** width of the image in pixel range 1 -> 4096 */
	RMuint32 Width;
	/** height of the image in pixel range 1 -> 4096 */
	RMuint32 Height;
	/** amount of data that has to be allocated by the application */
	RMuint32 Address;
	/** size, in bytes, of the luma plane in DRAM\n */
	RMuint32 LumaSize;
	/** size, in bytes, of the chroma plane in DRAM\n */
	RMuint32 ChromaSize;
	/** the Chroma buffer start address */
	RMuint32 PaletteSize;
};

/** struct Default */
struct DispVideoInput_DRAMSize_in_type {
	/** format mode of the image */
	enum EMhwlibColorMode ColorMode;
	/** format submode of the image */
	enum EMhwlibColorFormat ColorFormat;
	/** Chroma mode of the image */
	enum EMhwlibSamplingMode SamplingMode;
	/** width of the image in pixel range 0 -> 4095 */
	RMuint32 Width;
	/** height of the image in pixel range 0 -> 4095 */
	RMuint32 Height;
	/** number of picture buffers range 0 -> 10 */
	RMuint32 NumBuffer;
};

/** struct Default */
struct DispGraphicInput_DRAMSize_in_type {
	/** format mode of the image */
	enum EMhwlibColorMode ColorMode;
	/** format submode of the image */
	enum EMhwlibColorFormat ColorFormat;
	/** Chroma mode of the image */
	enum EMhwlibSamplingMode SamplingMode;
	/** width of the image in pixel range 0 -> 4095 */
	RMuint32 Width;
	/** height of the image in pixel range 0 -> 4095 */
	RMuint32 Height;
	/** number of picture buffers range 0 -> 10 */
	RMuint32 NumBuffer;
};

/** Get the current state of several options for the digital input and output ports */
struct DispDigitalOut_QueryPadsControl_in_type {
	/** version of the struct to be queried. set to 1 */
	RMuint32 APIVersion;
};

/** struct Default */
struct DemuxEngine_MicrocodeDRAMSize_in_type {
	/** Member default */
	RMuint32 MicrocodeVersion;
};

/**  */
struct DemuxEngine_PidUsage_in_type {
	/** Member default */
	RMuint32 pid_value;
	/** Member default */
	RMuint32 channel;
};

/** struct Default */
struct MpegEngine_MicrocodeDRAMSize_in_type {
	/** Member default */
	RMuint32 MicrocodeVersion;
};

/** struct Default */
struct VideoDecoder_DRAMSize_in_type {
	/** Member default */
	enum MPEG_Profile MPEGProfile;
	/** Member default */
	RMuint32 BitstreamFIFOSize;
	/** Member default */
	RMuint32 XferFIFOCount;
};

/** struct Default */
struct VideoDecoder_DecoderDataMemory_in_type {
	/** Member default */
	enum EMhwlibVideoCodec Codec;
	/** profile value depends on codec */
	RMuint32 Profile;
	/** level value depends on codec */
	RMuint32 Level;
	/** number of buffers needed for deinterlacing, gfx access. By default emhwlib reserves two extra buffers for display and vsync. In order to renounce to them negative numbers of -1, -2 are accepted. */
	RMint32 ExtraPictureBufferCount;
	/** maximum width of the picture */
	RMuint32 MaxWidth;
	/** maximum height of the picture */
	RMuint32 MaxHeight;
};

/** struct Default */
struct VideoDecoder_DRAMSizeX_in_type {
	/**  */
	RMuint32 ProtectedFlags;
	/** input video stream data fifo, size in bytes */
	RMuint32 BitstreamFIFOSize;
	/** data fifo needed for decoder to dump the user data embedded in video stream, size in bytes */
	RMuint32 UserDataSize;
	/** total data size needed for decoder for picture buffers and context, size in bytes */
	RMuint32 DecoderDataSize;
	/** size in entries */
	RMuint32 XferFIFOCount;
	/** size in entries */
	RMuint32 PtsFIFOCount;
	/** size in entries */
	RMuint32 InbandFIFOCount;
	/** size in entries */
	RMuint32 XtaskInbandFIFOCount;
};

/** Returns DDR-DRAM memory (cached or un-cached) requirements for a specified microcode. @note @li This function must be used before allocating the returned memory size using ::RUAMalloc. The ::RMAudioEnginePropertyID_Microcode  property needs this memory to store microcode specific overlays and data. \n @li The same Microcode version has to be used when calling ::RMAudioEnginePropertyID_Microcode. Failure to do so may result in insufficient memory or memory overrun. */
struct AudioEngine_MicrocodeDRAMSize_in_type {
	/** Specify the audio microcode version @sa ::RMAudioEnginePropertyID_Microcode */
	RMuint32 MicrocodeVersion;
};

/** Returns audio volume on a specified channel.@note @li This volume is the master output volume for the specified channel. Even though this volume will be applied to 2 audio decoders, there are currently no way to control the volume separately on these 2 decoders. */
struct AudioEngine_QueryVolume_in_type {
	/** Specifies the channel for which the volume will be returned. range 0 -> 9 */
	RMuint32 Channel;
};

/** struct Default */
struct AudioEngine_DecoderSharedMemoryInfo_in_type {
	/** reserved. It should be 0.  */
	RMuint32 Reserved1;
	/** reserved. It should be 0.  */
	RMuint32 Reserved2;
};

/** Gets the audio decoder DDR-DRAM memory size requirements (cacheable and non-cacheable) based on input/output characteristics.@note @li The CachedSize and UncachedSize values should be used to allocate memory in DDR-DRAM.@li The CachedAddress and UncachedAddress can be obtained in the RUA interface by calling ::RUAMalloc. Refer to the em86xx REALmagic User API document for more info.@li Cacheable memory is memory that is only used by the pt110. Any memory that involves DMA transfers (Either PCI master transfers or em86xx internal MBUS/VBUS transfers) as to be non-cacheable. This allows the pt110 to access data without flushing/reloading its cache and allows better performance. */
struct AudioDecoder_DRAMSize_in_type {
	/** Defines the maximum decompressed output channels. This number is used to allocate the PCM buffer in DDR-DRAM that will contain the 32 bit audio PCM samples. */
	RMuint32 MaxChannelOutCount;
	/** This number represents the number of lines in the decompressed PCM buffer in DDR-DRAM. One line contains 8 x 32 bit samples for each output channels. This number is used to allocate the PCM buffer in DDR-DRAM (Buffer = 8 x 4 x.MaxChannelOutCount x PCMLineCount) */
	RMuint32 PCMLineCount;
	/** Sets the compressed input stream (ex: AC3) buffer size. This size can vary depending on the maximum audio bit rate and the maximum input latency (i.e prevent audio discontinuities in extreme cases). */
	RMuint32 BitstreamFIFOSize;
	/** Sets the number of scatter-gather PCI FIFO entries. Each entry specifies an PCI BUS address, a DDR-DRAM destination, a 32 bit size and a context. */
	RMuint32 XferFIFOCount;
};

/** Gets the audio decoder DDR-DRAM memory size requirements (cacheable and non-cacheable) based on input/output characteristics.@note @li The CachedSize and UncachedSize values should be used to allocate memory in DDR-DRAM.@li The CachedAddress and UncachedAddress can be obtained in the RUA interface by calling ::RUAMalloc. Refer to the em86xx REALmagic User API document for more info.@li Cacheable memory is memory that is only used by the pt110. Any memory that involves DMA transfers (Either PCI master transfers or em86xx internal MBUS/VBUS transfers) as to be non-cacheable. This allows the pt110 to access data without flushing/reloading its cache and allows better performance. */
struct AudioDecoder_DRAMSizePCMX_in_type {
	/** Sets the compressed input stream (ex: AC3) buffer size. This size can vary depending on the maximum audio bit rate and the maximum input latency (i.e prevent audio discontinuities in extreme cases). */
	RMuint32 BitstreamFIFOSize0;
	/** Sets the number of scatter-gather PCI FIFO entries. Each entry specifies an PCI BUS address, a DDR-DRAM destination, a 32 bit size and a context. */
	RMuint32 XferFIFOCount0;
	/** Sets the compressed input stream (ex: AC3) buffer size. This size can vary depending on the maximum audio bit rate and the maximum input latency (i.e prevent audio discontinuities in extreme cases). */
	RMuint32 BitstreamFIFOSize1;
	/** Sets the number of scatter-gather PCI FIFO entries. Each entry specifies an PCI BUS address, a DDR-DRAM destination, a 32 bit size and a context. */
	RMuint32 XferFIFOCount1;
	/** Sets the compressed input stream (ex: AC3) buffer size. This size can vary depending on the maximum audio bit rate and the maximum input latency (i.e prevent audio discontinuities in extreme cases). */
	RMuint32 BitstreamFIFOSize2;
	/** Sets the number of scatter-gather PCI FIFO entries. Each entry specifies an PCI BUS address, a DDR-DRAM destination, a 32 bit size and a context. */
	RMuint32 XferFIFOCount2;
	/** Sets the compressed input stream (ex: AC3) buffer size. This size can vary depending on the maximum audio bit rate and the maximum input latency (i.e prevent audio discontinuities in extreme cases). */
	RMuint32 BitstreamFIFOSize3;
	/** Sets the number of scatter-gather PCI FIFO entries. Each entry specifies an PCI BUS address, a DDR-DRAM destination, a 32 bit size and a context. */
	RMuint32 XferFIFOCount3;
	/** Sets the compressed input stream (ex: AC3) buffer size. This size can vary depending on the maximum audio bit rate and the maximum input latency (i.e prevent audio discontinuities in extreme cases). */
	RMuint32 BitstreamFIFOSize4;
	/** Sets the number of scatter-gather PCI FIFO entries. Each entry specifies an PCI BUS address, a DDR-DRAM destination, a 32 bit size and a context. */
	RMuint32 XferFIFOCount4;
	/** Sets the compressed input stream (ex: AC3) buffer size. This size can vary depending on the maximum audio bit rate and the maximum input latency (i.e prevent audio discontinuities in extreme cases). */
	RMuint32 BitstreamFIFOSize5;
	/** Sets the number of scatter-gather PCI FIFO entries. Each entry specifies an PCI BUS address, a DDR-DRAM destination, a 32 bit size and a context. */
	RMuint32 XferFIFOCount5;
	/** Sets the compressed input stream (ex: AC3) buffer size. This size can vary depending on the maximum audio bit rate and the maximum input latency (i.e prevent audio discontinuities in extreme cases). */
	RMuint32 BitstreamFIFOSize6;
	/** Sets the number of scatter-gather PCI FIFO entries. Each entry specifies an PCI BUS address, a DDR-DRAM destination, a 32 bit size and a context. */
	RMuint32 XferFIFOCount6;
	/** Sets the compressed input stream (ex: AC3) buffer size. This size can vary depending on the maximum audio bit rate and the maximum input latency (i.e prevent audio discontinuities in extreme cases). */
	RMuint32 BitstreamFIFOSize7;
	/** Sets the number of scatter-gather PCI FIFO entries. Each entry specifies an PCI BUS address, a DDR-DRAM destination, a 32 bit size and a context. */
	RMuint32 XferFIFOCount7;
	/** Sets the compressed input stream (ex: AC3) buffer size. This size can vary depending on the maximum audio bit rate and the maximum input latency (i.e prevent audio discontinuities in extreme cases). */
	RMuint32 BitstreamFIFOSize8;
	/** Sets the number of scatter-gather PCI FIFO entries. Each entry specifies an PCI BUS address, a DDR-DRAM destination, a 32 bit size and a context. */
	RMuint32 XferFIFOCount8;
};

/** struct Default */
struct AudioDecoder_DRAMSizeX_in_type {
	/**  */
	RMuint32 ProtectedFlags;
	/** input video stream data fifo, size in bytes */
	RMuint32 BitstreamFIFOSize;
	/** size in entries */
	RMuint32 XferFIFOCount;
	/** size in entries */
	RMuint32 PtsFIFOCount;
	/** size in entries */
	RMuint32 InbandFIFOCount;
	/** Member default */
	RMuint32 MaxChannelOutCount;
	/** Member default */
	RMuint32 PCMLineCount;
	/** size in entries */
	RMuint32 XtaskInbandFIFOCount;
};

/** struct Default */
struct AudioCapture_DRAMSize_in_type {
	/** Member default */
	RMuint32 SerialInFIFOSize;
	/** Member default */
	RMuint32 XferFIFOCount;
};

/** struct Default */
struct VoipCodec_DRAMSize_in_type {
	/** Member default */
	RMuint32 BTSInFIFOSize;
	/** Member default */
	RMuint32 BTSOutFIFOSize;
	/** Member default */
	RMuint32 DTMFCharFIFOSize;
};

/** struct Default */
struct VoipCodec_WriteChunk_in_type {
	/** Member default */
	struct VoipChunk Chunk;
};

/** struct Default */
struct VoipCodec_ReadChunk_in_type {
	/** Member default */
	RMuint32 Size;
};

/** struct Default */
struct CRCDecoder_DRAMSize_in_type {
	/** Member default */
	RMuint32 BitstreamFIFOSize;
	/** Member default */
	RMuint32 XferFIFOCount;
};

/** struct Default */
struct XCRCDecoder_DRAMSize_in_type {
	/** Member default */
	RMuint32 BitstreamFIFOSize;
	/** Member default */
	RMuint32 XferFIFOCount;
};

/** struct Default */
struct StreamCapture_DRAMSize_in_type {
	/** Member default */
	RMuint32 BitstreamFIFOSize;
	/** Member default */
	RMuint32 XferFIFOCount;
};

/** struct Default */
struct RawDataTransfer_DRAMSize_in_type {
	/** Member default */
	RMuint32 XferFIFOCount;
};

/** struct Default */
struct I2C_QueryRMuint8_in_type {
	/** Member default */
	RMuint8 SubAddr;
};

/** struct Default */
struct I2C_QueryData_in_type {
	/** Member default */
	RMbool UseSubAddr;
	/** Member default */
	RMuint8 SubAddr;
	/** Member default */
	RMuint32 DataSize;
};

/** struct Default */
struct GFXEngine_DRAMSize_in_type {
	/** Member default */
	RMuint32 CommandFIFOCount;
};

/** struct Default */
struct MM_Malloc_in_type {
	/** Member default */
	enum RUADramType dramtype;
	/** Member default */
	RMuint32 Size;
};

/** struct Default */
struct MM_AreaSize_in_type {
	/** Member default */
	void * Address;
};

/** struct Default */
struct SpuDecoder_DRAMSize_in_type {
	/** Member default */
	RMuint32 BitstreamFIFOSize;
	/** Member default */
	RMuint32 XferFIFOCount;
};

/** struct Default */
struct SpuDecoder_DRAMSizeX_in_type {
	/**  */
	RMuint32 ProtectedFlags;
	/** input video stream data fifo, size in bytes */
	RMuint32 BitstreamFIFOSize;
	/** total data size needed for decoder for picture buffers and context, size in bytes */
	RMuint32 DecoderDataSize;
	/** size in entries */
	RMuint32 XferFIFOCount;
	/** size in entries */
	RMuint32 PtsFIFOCount;
	/** size in entries */
	RMuint32 InbandFIFOCount;
	/** size in entries */
	RMuint32 XtaskInbandFIFOCount;
	/** Number of buttons */
	RMuint32 HilightCount;
};

/** struct Default */
struct SpuDecoder_DecoderDataMemory_in_type {
	/** Member default */
	enum EMhwlibVideoCodec Codec;
	/** profile value depends on codec */
	RMuint32 Profile;
	/** level value depends on codec */
	RMuint32 Level;
	/** number of buffers needed for deinterlacing, gfx access */
	RMuint32 ExtraPictureBufferCount;
	/** maximum width of the picture */
	RMuint32 MaxWidth;
	/** maximum height of the picture */
	RMuint32 MaxHeight;
};

/** struct Default */
struct PictureTransform_DecoderMemory_in_type {
	/** Member default */
	enum EMhwlibPictureTransformType TransformType;
	/** Member default */
	RMbool InPlace;
	/** Member default */
	RMuint32 PictureCount;
	/** Member default */
	RMuint32 PictureSize;
	/** Member default */
	RMuint32 InbandFIFOCount;
};

/** struct Default */
struct PLL_QueryPLL_in_type {
	/** specifies PLL range 0 -> 3 */
	enum PLLGen PLL;
};

/** returns the last frequencies that were specified */
struct PLL_QueryPLLNominal_in_type {
	/** specifies PLL range 0 -> 3 */
	enum PLLGen PLL;
};

/** struct Default */
struct PLL_QueryClockRoute_in_type {
	/** clock signal range 0 -> 19 */
	enum ClockSignal Clock;
};

/** struct Default */
struct PLL_QueryCounterFrequency_in_type {
	/** specifies counter range 0 -> 11 */
	enum ClockCounter Counter;
	/** WARNING: This function will block for the specified time! range 0 -> 159 */
	RMuint32 uSecDelay;
};

/** struct Default */
struct DemuxCipher_DRAMSize_in_type {
	/** The total bufferCount to be used */
	RMuint32 bufferCount;
};

/** Gets the demux DDR-DRAM memory size requirements (cacheable and non-cacheable) based on input/output characteristics.@note @li The ProtectedSize and UnprotectedSize values should be used to allocate memory in DDR-DRAM.@li The ProtectedAddress and UnprotectedAddress can be obtained in the RUA interface by calling ::RUAMalloc. Refer to the em86xx REALmagic User API document for more info. */
struct DemuxTask_DRAMSize_in_type {
	/**  */
	RMuint32 ProtectedFlags;
	/** Sets the compressed input stream buffer size. This size can vary depending on the bit rate and the maximum input latency. It can be 0 for SPI input. */
	RMuint32 BitstreamFIFOSize;
	/** Sets the number of scatter-gather PCI FIFO entries. Each entry specifies an PCI BUS address, a DDR-DRAM destination, a 32 bit size and a context. */
	RMuint32 XferFIFOCount;
	/**  */
	RMuint32 InbandFIFOCount;
};

/** Gets the demux DDR-DRAM memory size requirements (cacheable and non-cacheable) based on input/output characteristics.@note @li The ProtectedSize and UnprotectedSize values should be used to allocate memory in DDR-DRAM.@li The ProtectedAddress and UnprotectedAddress can be obtained in the RUA interface by calling ::RUAMalloc. Refer to the em86xx REALmagic User API document for more info. */
struct DemuxTask_DRAMSizeX_in_type {
	/**  */
	RMuint32 ProtectedFlags;
	/** Sets the compressed input stream buffer size. This size can vary depending on the bit rate and the maximum input latency. It can be 0 for SPI input. */
	RMuint32 BitstreamFIFOSize;
	/** Sets the number of scatter-gather PCI FIFO entries. Each entry specifies an PCI BUS address, a DDR-DRAM destination, a 32 bit size and a context. */
	RMuint32 XferFIFOCount;
	/**  */
	RMuint32 InbandFIFOCount;
	/**  */
	RMuint32 XTaskModuleId;
	/** Member default */
	RMuint32 XTaskInbandFIFOCount;
};

/** Returns the current PCR from stream and the STC at the moment when PCR was received. */
struct DemuxTask_CurrentPcrInfo_in_type {
	/** Member default */
	RMuint32 time_resolution;
};

/** Gets the demux DDR-DRAM memory size requirements based on input/output characteristics. */
struct DemuxOutput_DRAMSize_in_type {
	/**  */
	RMuint32 ProtectedFlags;
	/** Sets the compressed input stream buffer size. This size can vary depending on the bit rate and the maximum input latency. It can be 0 for SPI input. */
	RMuint32 BitstreamFIFOSize;
	/** Sets the number of scatter-gather PCI FIFO entries for receive. Each entry specifies an PCI BUS address, a DDR-DRAM destination, a 32 bit size and a context. */
	RMuint32 XferFIFOCount;
	/** timestamp fifo */
	RMuint32 PtsFIFOCount;
	/** inband fifo that will receive commands from demux. */
	RMuint32 InbandFIFOCount;
};

/** Gets the demux DDR-DRAM memory size requirements based on input/output characteristics. */
struct DemuxOutput_DRAMSizeX_in_type {
	/**  */
	RMuint32 ProtectedFlags;
	/** Sets the compressed input stream buffer size. This size can vary depending on the bit rate and the maximum input latency. It can be 0 for SPI input. */
	RMuint32 BitstreamFIFOSize;
	/** Sets the number of scatter-gather PCI FIFO entries for receive. Each entry specifies an PCI BUS address, a DDR-DRAM destination, a 32 bit size and a context. */
	RMuint32 XferFIFOCount;
	/** timestamp fifo */
	RMuint32 PtsFIFOCount;
	/** inband fifo that will receive commands from demux. */
	RMuint32 InbandFIFOCount;
	/** Member default */
	RMuint32 XtaskInbandFIFOCount;
};

/** struct Default */
struct DispHDSDConverter_OnTheFlyModeParameters_in_type {
	/** Member default */
	struct EMhwlibTVFormatAnalog HDFormat;
	/** Member default */
	struct EMhwlibTVFormatAnalog SDFormat;
};

/** struct Default */
struct DispHDSDConverter_OnTheFlyModeParametersX_in_type {
	/** Member default */
	struct EMhwlibGenericTVFormat HDFormat;
	/** Member default */
	struct EMhwlibGenericTVFormat SDFormat;
};

/** struct Default */
struct DispHDSDConverter_BufferedModeParameters_in_type {
	/** Member default */
	struct EMhwlibTVFormatAnalog HDFormat;
	/** Member default */
	struct EMhwlibTVFormatAnalog SDFormat;
};

/** struct Default */
struct DispHDSDConverter_BufferedModeParametersX_in_type {
	/** Member default */
	struct EMhwlibGenericTVFormat HDFormat;
	/** Member default */
	struct EMhwlibGenericTVFormat SDFormat;
};

/** struct Default */
struct Sha1Sum_DRAMSize_in_type {
	/** Member default */
	RMuint32 BitstreamFIFOSize;
	/** Member default */
	RMuint32 XferFIFOCount;
	/** Member default */
	RMuint32 XTaskModuleID;
};

/** struct Default */
struct SystemBlock_QueryGPIO_out_type {
	/** Member default */
	RMbool Data;
};

/** status information on the pulse width modulation generators on GPIO pins 14 and 15 */
struct SystemBlock_QueryPWM_out_type {
	/** if TRUE, enables PWM generator on GPIO 14 or 15, overrides GPIO setting */
	RMbool Enable;
	/** Width of the high pulse, translates into a voltage level after a low pass filter range 0 -> 65535 */
	RMuint32 Level;
	/** system clock pre divider. @note The minimum pulse width is equal to 2 ^ (Log2Div + 1) system clock periods. range 0 -> 7 */
	RMuint32 Log2Div;
};

/** struct Default */
struct SystemBlock_DRAMSize_out_type {
	/** Member default */
	RMuint32 Size;
};

/** returns the required DRAM size, in bytes, as well as the buffer sizes for luma and chroma for a given format and image size. also allots space for vsync surface struct. the chroma plane has to follow the luma plane immediately in memory */
struct DisplayBlock_SurfaceSize_out_type {
	/** amount of data that has to be allocated by the application */
	RMuint32 BufferSize;
	/** size, in bytes, of the luma plane in DRAM\n */
	RMuint32 LumaSize;
	/** size, in bytes, of the chroma plane in DRAM\n */
	RMuint32 ChromaSize;
};

/** returns the required DRAM size, in bytes, as well as the buffer sizes for luma and chroma for a given format and image size. also allots space for vsync surface struct. the chroma plane has to follow the luma plane immediately in memory */
struct DisplayBlock_PictureSize_out_type {
	/** amount of data that has to be allocated by the application */
	RMuint32 BufferSize;
	/** size, in bytes, of the luma plane in DRAM\n */
	RMuint32 LumaSize;
	/** size, in bytes, of the chroma plane in DRAM\n */
	RMuint32 ChromaSize;
	/** size, in bytes, of the chroma plane in DRAM\n */
	RMuint32 PaletteSize;
};

/** initialize a static surface */
struct DisplayBlock_InitSurface_out_type {
	/** the Luma buffer start address */
	RMuint32 LumaAddress;
	/** the Chroma buffer start address */
	RMuint32 ChromaAddress;
	/** the Chroma buffer start address */
	RMuint32 PictureAddress;
};

/** returns the required DRAM size, in bytes, as well as the buffer sizes for luma and chroma for a given format and image size. also allots space for vsync surface struct. the chroma plane has to follow the luma plane immediately in memory */
struct DisplayBlock_InitPicture_out_type {
	/** the Luma buffer start address */
	RMuint32 LumaAddress;
	/** the Chroma buffer start address */
	RMuint32 ChromaAddress;
};

/** returns the required DRAM size, in bytes, as well as the buffer sizes for luma and chroma for a given format and image size. also allots space for vsync surface struct. the chroma plane has to follow the luma plane immediately in memory */
struct DisplayBlock_InitPictureX_out_type {
	/** the Luma buffer start address */
	RMuint32 LumaAddress;
	/** the Chroma buffer start address */
	RMuint32 ChromaAddress;
	/** the Luma buffer start address */
	RMuint32 PaletteAddress;
};

/** Surface info */
struct DisplayBlock_SurfaceInfo_out_type {
	/** width of the image in pixel range 1 -> 4096 */
	RMuint32 Width;
	/** height of the image in pixel range 1 -> 4096 */
	RMuint32 Height;
	/** format mode of the image */
	enum EMhwlibColorMode ColorMode;
	/** format submode of the image */
	enum EMhwlibColorFormat ColorFormat;
	/** color space of the surface */
	enum EMhwlibColorSpace ColorSpace;
	/** Chroma mode of the image */
	enum EMhwlibSamplingMode SamplingMode;
	/** the Luma buffer start address */
	RMuint32 LumaAddress;
	/** the Chroma buffer start address */
	RMuint32 ChromaAddress;
};

/** Picture info */
struct DisplayBlock_PictureInfo_out_type {
	/** width of the image in pixel range 1 -> 4096 */
	RMuint32 Width;
	/** height of the image in pixel range 1 -> 4096 */
	RMuint32 Height;
	/** the Luma buffer start address */
	RMuint32 LumaAddress;
	/** the Chroma buffer start address */
	RMuint32 ChromaAddress;
};

/** struct Default */
struct DispVideoInput_DRAMSize_out_type {
	/** amount of data that has to be allocated by the application */
	RMuint32 BufferSize;
};

/** struct Default */
struct DispGraphicInput_DRAMSize_out_type {
	/** amount of data that has to be allocated by the application */
	RMuint32 BufferSize;
};

/** Get the current state of several options for the digital input and output ports */
struct DispDigitalOut_QueryPadsControl_out_type {
	/** Member default */
	RMbool InvertClock;
	/** Member default */
	RMbool DDRdout;
	/** Member default */
	RMbool InvertCaptureClock;
	/** in pSec range 0 -> 6300 */
	RMuint32 Delay;
	/** Select V2 pads as the input pins for the DispVideoInput */
	RMbool VideoInputV2;
	/** Select V2 pads as the input pins for the DispGraphicInput */
	RMbool GraphicInputV2;
	/** Member default range 0 -> 3 */
	RMuint32 SCARTControl;
	/** Connects the digital output to the both inputs */
	RMbool PadsLoop;
};

/** struct Default */
struct DemuxEngine_MicrocodeDRAMSize_out_type {
	/** Member default */
	RMuint32 Size;
};

/**  */
struct DemuxEngine_PidUsage_out_type {
	/** count of pid entries already set with same pid value */
	RMuint32 count;
	/** array of first 4 pid entries used. The validity of those entries is based on count */
	RMuint32x4 pid_entries;
};

/** struct Default */
struct MpegEngine_MicrocodeDRAMSize_out_type {
	/** Member default */
	RMuint32 Size;
};

/** struct Default */
struct VideoDecoder_DRAMSize_out_type {
	/** Member default */
	RMuint32 CachedSize;
	/** Member default */
	RMuint32 UncachedSize;
};

/** struct Default */
struct VideoDecoder_DecoderDataMemory_out_type {
	/** total data size needed for decoder for picture buffers and context */
	RMuint32 DecoderDataSize;
	/** decoder context memory - to be calculated inside microcode and removed from interface */
	RMuint32 DecoderContextSize;
	/** shared memory used by all video decoders from one Mpeg engine */
	RMuint32 DecoderSharedSize;
};

/** struct Default */
struct VideoDecoder_DRAMSizeX_out_type {
	/** it can be 0 */
	RMuint32 PictureProtectedSize;
	/** Member default */
	RMuint32 BitstreamProtectedSize;
	/** Member default */
	RMuint32 UnprotectedSize;
};

/** Returns DDR-DRAM memory (cached or un-cached) requirements for a specified microcode. @note @li This function must be used before allocating the returned memory size using ::RUAMalloc. The ::RMAudioEnginePropertyID_Microcode  property needs this memory to store microcode specific overlays and data. \n @li The same Microcode version has to be used when calling ::RMAudioEnginePropertyID_Microcode. Failure to do so may result in insufficient memory or memory overrun. */
struct AudioEngine_MicrocodeDRAMSize_out_type {
	/** Returns DDR-DRAM memory (cached or un-cached) requirements in BYTEs. */
	RMuint32 Size;
};

/** Returns audio volume on a specified channel.@note @li This volume is the master output volume for the specified channel. Even though this volume will be applied to 2 audio decoders, there are currently no way to control the volume separately on these 2 decoders. */
struct AudioEngine_QueryVolume_out_type {
	/** Returns the audio attenuation from +24db to -infinite. 0db is represented by Volume=0x10000000. Shifting this value by 1 bit on the left will increase the volume by 6db. Maximum gain is 0xFFFFFFFF ~=24db. Shifting the 0db value by 1 bit on the right will decrease the volume by 6db until the value reaches 0 (infinite, i.e. mute). @note @li Volume is a 4.28 fix point number. Volume = 0x10000000 * 2^(Gain/6), where Gain has unit dB. range 0 -> 0xFFFFFFFF */
	RMuint32 Volume;
};

/** struct Default */
struct AudioEngine_DecoderSharedMemoryInfo_out_type {
	/** shared memory used by all audio decoders from one audio engine */
	RMuint32 DecoderSharedSize;
};

/** Gets the audio decoder DDR-DRAM memory size requirements (cacheable and non-cacheable) based on input/output characteristics.@note @li The CachedSize and UncachedSize values should be used to allocate memory in DDR-DRAM.@li The CachedAddress and UncachedAddress can be obtained in the RUA interface by calling ::RUAMalloc. Refer to the em86xx REALmagic User API document for more info.@li Cacheable memory is memory that is only used by the pt110. Any memory that involves DMA transfers (Either PCI master transfers or em86xx internal MBUS/VBUS transfers) as to be non-cacheable. This allows the pt110 to access data without flushing/reloading its cache and allows better performance. */
struct AudioDecoder_DRAMSize_out_type {
	/** Returns the cached memory size necessary to decode and play the audio bit stream based on the values passed in ::AudioDecoder_DRAMSize_in_type. */
	RMuint32 CachedSize;
	/** Returns the non-cached memory size necessary to decode and play the audio bit stream based on the values passed in ::AudioDecoder_DRAMSize_in_type. */
	RMuint32 UncachedSize;
};

/** Gets the audio decoder DDR-DRAM memory size requirements (cacheable and non-cacheable) based on input/output characteristics.@note @li The CachedSize and UncachedSize values should be used to allocate memory in DDR-DRAM.@li The CachedAddress and UncachedAddress can be obtained in the RUA interface by calling ::RUAMalloc. Refer to the em86xx REALmagic User API document for more info.@li Cacheable memory is memory that is only used by the pt110. Any memory that involves DMA transfers (Either PCI master transfers or em86xx internal MBUS/VBUS transfers) as to be non-cacheable. This allows the pt110 to access data without flushing/reloading its cache and allows better performance. */
struct AudioDecoder_DRAMSizePCMX_out_type {
	/** Returns the non-cached memory size necessary to decode and play the audio bit stream based on the values passed in ::AudioDecoder_DRAMSize_in_type. */
	RMuint32 UnProtectedSize;
};

/** struct Default */
struct AudioDecoder_DRAMSizeX_out_type {
	/** it can be 0 */
	RMuint32 OutputSamplesProtectedSize;
	/** Member default */
	RMuint32 BitstreamProtectedSize;
	/** Member default */
	RMuint32 UnprotectedSize;
};

/** struct Default */
struct AudioCapture_DRAMSize_out_type {
	/** Member default */
	RMuint32 CachedSize;
	/** Member default */
	RMuint32 UncachedSize;
};

/** struct Default */
struct VoipCodec_DRAMSize_out_type {
	/** Member default */
	RMuint32 CachedSize;
	/** Member default */
	RMuint32 UncachedSize;
};

/** struct Default */
struct VoipCodec_WriteChunk_out_type {
	/** Member default */
	RMuint32 WrittenSize;
};

/** struct Default */
struct VoipCodec_ReadChunk_out_type {
	/** Member default */
	struct VoipChunk Chunk;
};

/** struct Default */
struct CRCDecoder_DRAMSize_out_type {
	/** Member default */
	RMuint32 CachedSize;
	/** Member default */
	RMuint32 UncachedSize;
};

/** struct Default */
struct XCRCDecoder_DRAMSize_out_type {
	/** Member default */
	RMuint32 CachedSize;
	/** Member default */
	RMuint32 UncachedSize;
};

/** struct Default */
struct StreamCapture_DRAMSize_out_type {
	/** Member default */
	RMuint32 CachedSize;
	/** Member default */
	RMuint32 UncachedSize;
};

/** struct Default */
struct RawDataTransfer_DRAMSize_out_type {
	/** Member default */
	RMuint32 CachedSize;
	/** Member default */
	RMuint32 UncachedSize;
};

/** struct Default */
struct I2C_QueryRMuint8_out_type {
	/** Member default */
	RMuint8 Data;
};

/** struct Default */
struct I2C_QueryData_out_type {
	/** Member default */
	RMuint8 Data[256];
};

/** struct Default */
struct GFXEngine_DRAMSize_out_type {
	/** Member default */
	RMuint32 CachedSize;
	/** Member default */
	RMuint32 UncachedSize;
};

/** struct Default */
struct GFXEngine_GlyphOutputSize_out_type {
	/** Member default */
	RMuint32 Width;
	/** Member default */
	RMuint32 Height;
	/** Member default */
	RMuint32 Pitch;
};

/** struct Default */
struct MM_Malloc_out_type {
	/** Member default */
	void * Address;
};

/** struct Default */
struct MM_AreaSize_out_type {
	/** Member default */
	RMuint32 Size;
};

/** struct Default */
struct SpuDecoder_DRAMSize_out_type {
	/** Member default */
	RMuint32 CachedSize;
	/** Member default */
	RMuint32 UncachedSize;
};

/** struct Default */
struct SpuDecoder_DRAMSizeX_out_type {
	/** it can be 0 */
	RMuint32 PictureProtectedSize;
	/** Member default */
	RMuint32 BitstreamProtectedSize;
	/** Member default */
	RMuint32 UnprotectedSize;
};

/** struct Default */
struct SpuDecoder_DecoderDataMemory_out_type {
	/** total data size needed for decoder for picture buffers and context */
	RMuint32 DecoderDataSize;
	/** decoder context memory - to be calculated inside microcode and removed from interface */
	RMuint32 DecoderContextSize;
	/** shared memory used by all video decoders from one Mpeg engine */
	RMuint32 DecoderSharedSize;
};

/** struct Default */
struct PictureTransform_DecoderMemory_out_type {
	/** Member default */
	RMuint32 DecoderDataSize;
	/** Member default */
	RMuint32 DecoderInterfaceSize;
	/** Member default */
	RMuint32 DecoderSharedSize;
};

/** struct Default */
struct PLL_QueryPLL_out_type {
	/** Frequency of output 0 (PLL VCO), in Hz range 0 -> 1000000000 */
	RMuint32 Frequency0;
	/** Frequency of output 1 (post divider 1), in Hz range 0 -> 500000000 */
	RMuint32 Frequency1;
	/** Frequency of output 2 (post divider 2), in Hz range 0 -> 500000000 */
	RMuint32 Frequency2;
};

/** returns the last frequencies that were specified */
struct PLL_QueryPLLNominal_out_type {
	/** Nominal frequency of output 0 (PLL VCO), in Hz range 0 -> 1000000000 */
	RMuint32 Frequency0;
	/** Nominal frequency of output 1 (post divider 1), in Hz range 0 -> 500000000 */
	RMuint32 Frequency1;
	/** Nominal frequency of output 2 (post divider 2), in Hz range 0 -> 500000000 */
	RMuint32 Frequency2;
};

/** struct Default */
struct PLL_QueryClockRoute_out_type {
	/** input clock signal range 0 -> 7 */
	enum PLLSource ClockSource;
	/** specifies PLL or Clean Divider range 0 -> 14 */
	enum PLLGen PLL;
	/** specifies PLL output of CD post divider range 0 -> 2 */
	enum PLLOut PLLOutput;
	/** TRUE: PLL and PLLOutput are valid, FALSE: ClockSource is valid */
	RMbool PLLCD;
};

/** struct Default */
struct PLL_QueryCounterFrequency_out_type {
	/** Frequency at which the counter is running. Accuracy is approx. 333/uSecDelay ppm (100000ppm for 0) */
	RMuint32 Frequency;
};

/** struct Default */
struct DemuxCipher_DRAMSize_out_type {
	/** Pointer to store the memory size needed for the passed # of buffers. */
	RMuint32 UnprotectedSize;
};

/** Gets the demux DDR-DRAM memory size requirements (cacheable and non-cacheable) based on input/output characteristics.@note @li The ProtectedSize and UnprotectedSize values should be used to allocate memory in DDR-DRAM.@li The ProtectedAddress and UnprotectedAddress can be obtained in the RUA interface by calling ::RUAMalloc. Refer to the em86xx REALmagic User API document for more info. */
struct DemuxTask_DRAMSize_out_type {
	/** Returns the protected memory size, based on the values passed in ::DemuxTask_DRAMSize_in_type. */
	RMuint32 BitstreamProtectedSize;
	/** Returns the unprotected memory size, based on the values passed in ::DemuxTask_DRAMSize_in_type. */
	RMuint32 UnprotectedSize;
};

/** Gets the demux DDR-DRAM memory size requirements (cacheable and non-cacheable) based on input/output characteristics.@note @li The ProtectedSize and UnprotectedSize values should be used to allocate memory in DDR-DRAM.@li The ProtectedAddress and UnprotectedAddress can be obtained in the RUA interface by calling ::RUAMalloc. Refer to the em86xx REALmagic User API document for more info. */
struct DemuxTask_DRAMSizeX_out_type {
	/** Returns the protected memory size, based on the values passed in ::DemuxTask_DRAMSize_in_type. */
	RMuint32 BitstreamProtectedSize;
	/** Returns the unprotected memory size, based on the values passed in ::DemuxTask_DRAMSize_in_type. */
	RMuint32 UnprotectedSize;
};

/** Returns the current PCR from stream and the STC at the moment when PCR was received. */
struct DemuxTask_CurrentPcrInfo_out_type {
	/**  */
	RMuint64 pcr;
	/**  */
	RMuint64 stc;
};

/** Gets the demux DDR-DRAM memory size requirements based on input/output characteristics. */
struct DemuxOutput_DRAMSize_out_type {
	/** Returns the memory size necessary based on the values passed in ::DemuxOutput_DRAMSize_in_type. */
	RMuint32 BitstreamProtectedSize;
	/** Returns the memory size necessary based on the values passed in ::Demux_DRAMSize_in_type. */
	RMuint32 UnprotectedSize;
};

/** Gets the demux DDR-DRAM memory size requirements based on input/output characteristics. */
struct DemuxOutput_DRAMSizeX_out_type {
	/** Returns the memory size necessary based on the values passed in ::DemuxOutput_DRAMSize_in_type. */
	RMuint32 BitstreamProtectedSize;
	/** Returns the memory size necessary based on the values passed in ::Demux_DRAMSize_in_type. */
	RMuint32 UnprotectedSize;
};

/** struct Default */
struct DispHDSDConverter_OnTheFlyModeParameters_out_type {
	/** Member default */
	RMuint32 DumpedLines;
	/** Member default */
	RMuint32 DelayLines;
	/** Member default */
	RMuint32 DelayPixels;
};

/** struct Default */
struct DispHDSDConverter_OnTheFlyModeParametersX_out_type {
	/** Member default */
	RMuint32 DumpedLines;
	/** Member default */
	RMuint32 DelayLines;
	/** Member default */
	RMuint32 DelayPixels;
	/** Member default */
	RMbool HDFirst;
};

/** struct Default */
struct DispHDSDConverter_BufferedModeParameters_out_type {
	/** Member default */
	RMuint32 BufferSize;
};

/** struct Default */
struct DispHDSDConverter_BufferedModeParametersX_out_type {
	/** Member default */
	RMuint32 BufferSize;
};

/** struct Default */
struct Sha1Sum_DRAMSize_out_type {
	/** Member default */
	RMuint32 EncryptedSize;
	/** Member default */
	RMuint32 ClearSize;
};

struct GFXEngineCommand {
	RMuint32 CommandID;
	union{
		struct GFXEngine_Correction_type Correction;
		struct GFXEngine_ColorFormat_type ColorFormat;
		struct GFXEngine_AlphaFormat_type AlphaFormat;
		struct GFXEngine_Surface_type Surface;
		struct GFXEngine_BCS_type BCS;
		struct GFXEngine_FillRectangle_type FillRectangle;
		struct GFXEngine_BlendRectangles_type BlendRectangles;
		struct GFXEngine_BlendGradient_type BlendGradient;
		struct GFXEngine_RasterBlendGradient_type RasterBlendGradient;
		struct GFXEngine_RasterBlendRectangles_type RasterBlendRectangles;
		struct GFXEngine_FillReplaceGradient_type ReplaceGradient;
		struct GFXEngine_FillReplaceGradient_type FillGradient;
		struct GFXEngine_SingleColorBlendRectangles_type SingleColorBlendRectangles;
		struct GFXEngine_BlendAndScaleRectangles_type BlendAndScaleRectangles;
		struct GFXEngine_MoveReplaceRectangle_type MoveRectangle;
		struct GFXEngine_MoveReplaceRectangle_type ReplaceRectangle;
		struct GFXEngine_MoveReplaceScaleRectangle_type ReplaceAndScaleRectangle;
		struct GFXEngine_MoveReplaceScaleRectangle_type MoveAndScaleRectangle;
		struct GFXEngine_DisplayPicture_type DisplayPicture;
		RMuint32 WaitForPicture;
		struct GFXEngine_LinearGradientSurface_type LinearGradientSurface;
		struct GFXEngine_RadialGradientSurface_type RadialGradientSurface;
		struct GFXEngine_KeyColor_type KeyColor;
		struct GFXEngine_FieldType_type FieldType;
		struct GFXEngine_NonlinearScale_type NonlinearScale;
		struct GFXEngine_GlyphMask_type GlyphMask;
		struct GFXEngine_GlyphScaleMatrix_type GlyphScaleMatrix;
		struct GFXEngine_LPFThresholds_type LPFThresholds;
	} Command;
};

#endif /* __EMHWLIB_PROPERTYTYPES_H__ */

/* End of generated file include/emhwlib_propertytypes.h */
