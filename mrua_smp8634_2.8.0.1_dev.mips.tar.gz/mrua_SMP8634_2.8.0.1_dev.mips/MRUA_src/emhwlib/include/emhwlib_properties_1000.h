/******************************************************/
/* This file is generated automatically, DO NOT EDIT! */
/******************************************************/
/*
 * include/emhwlib_properties_1000.h
 *
 * Copyright (c) 2001-2003 Sigma Designs, Inc. 
 * All Rights Reserved. Proprietary and Confidential.
 *
 */
 
/**
  @file include/emhwlib_properties_1000.h
  @brief emhwlib generated file
   
  @author Jacques Mahe, Christian Wolff, Julien Soulier, Emmanuel Michon
  @ingroup hwlproperties
*/

#ifndef __EMHWLIB_PROPERTIES_1000_H__
#define __EMHWLIB_PROPERTIES_1000_H__

/** Module Enum Default */
enum RMSystemBlockPropertyID {
	/** SystemBlock_GPIO_type, (W) @par 
		Enum Default; */
	RMSystemBlockPropertyID_GPIO = 4001,
	/** SystemBlock_QueryGPIO_in_type and SystemBlock_QueryGPIO_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMSystemBlockPropertyID_QueryGPIO = 4002,
	/** SystemBlock_PWM_type, (W) @par 
		control of the pulse width modulation generators on GPIO pins 14 and 15 */
	RMSystemBlockPropertyID_PWM = 4003,
	/** SystemBlock_QueryPWM_in_type and SystemBlock_QueryPWM_out_type, (R/W Exchange) @par 
		status information on the pulse width modulation generators on GPIO pins 14 and 15 */
	RMSystemBlockPropertyID_QueryPWM = 4004,
	/** SystemBlock_DRAMSize_in_type and SystemBlock_DRAMSize_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMSystemBlockPropertyID_DRAMSize = 4005,
	/** SystemBlock_DRAMConfig_type, (W) @par 
		Enum Default; */
	RMSystemBlockPropertyID_DRAMConfig = 4006,
	/** SystemBlock_DRAMDelay_type, (W) @par 
		Enum Default; */
	RMSystemBlockPropertyID_DRAMDelay = 4007,
	/** SystemBlock_DRAMDelayAuto_type, (W) @par 
		Enum Default; */
	RMSystemBlockPropertyID_DRAMDelayAuto = 4008,
	/** SystemBlock_BWMonitorSelection_type, (W) @par 
		Enum Default; */
	RMSystemBlockPropertyID_BWMonitorSelection = 4575,
	/** SystemBlock_BWMonitorEnable_type, (W) @par 
		Enum Default; */
	RMSystemBlockPropertyID_BWMonitorEnable = 4577,
	/** ::struct EMhwlibBWMonitorSample, (R) @par 
		Enum Default; */
	RMSystemBlockPropertyID_BWMonitorSample = 4576,
	/** ::RMuint32, (R) @par 
		Enum Default; */
	RMSystemBlockPropertyID_Version = 1001,
};

/** Module Enum Default */
enum RMCPUBlockPropertyID {
	/** CPUBlock_State_enum, (R/W) @par 
		Enum Default; */
	RMCPUBlockPropertyID_State = 1,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMCPUBlockPropertyID_IRQHandler = 3001,
	/** CPUBlock_ProcessInterrupt_type, (W) @par 
		Enum Default; */
	RMCPUBlockPropertyID_ProcessInterrupt = 1002,
	/** CPUBlock_AddDataFifoXferTask_type, (W) @par 
		Enum Default; */
	RMCPUBlockPropertyID_AddDataFifoXferTask = 1003,
	/** CPUBlock_AddRawDataXferTask_type, (W) @par 
		Enum Default; */
	RMCPUBlockPropertyID_AddRawDataXferTask = 1004,
	/** CPUBlock_AddSoftIrqTask_type, (W) @par 
		Enum Default; */
	RMCPUBlockPropertyID_AddSoftIrqTask = 1005,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMCPUBlockPropertyID_DelTransferTask = 1006,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMCPUBlockPropertyID_DelSoftIrqTask = 1007,
	/** CPUBlock_DataFifoTransferTaskSize_in_type and CPUBlock_DataFifoTransferTaskSize_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMCPUBlockPropertyID_DataFifoTransferTaskSize = 1008,
	/** CPUBlock_RawDataTransferTaskSize_in_type and CPUBlock_RawDataTransferTaskSize_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMCPUBlockPropertyID_RawDataTransferTaskSize = 1009,
	/** ::RMuint32, (R) @par 
		Enum Default; */
	RMCPUBlockPropertyID_SoftIrqTaskSize = 1010,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMCPUBlockPropertyID_FlushTransferTask = 1011,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMCPUBlockPropertyID_EndOfStreamTransferTask = 1012,
	/** CPUBlock_DataFifoChunk_type, (R/W) @par 
		Enum Default; */
	RMCPUBlockPropertyID_DataFifoChunk = 1013,
	/** CPUBlock_RawDataChunk_type, (R/W) @par 
		Enum Default; */
	RMCPUBlockPropertyID_RawDataChunk = 1014,
	/** CPUBlock_AddDataFifoReadBuffer_type, (W) @par 
		Enum Default; */
	RMCPUBlockPropertyID_AddDataFifoReadBuffer = 1015,
	/** CPUBlock_AddRawDataReadBuffer_type, (W) @par 
		Enum Default; */
	RMCPUBlockPropertyID_AddRawDataReadBuffer = 1016,
	/** CPUBlock_ProgramRawDataXfer_type, (W) @par 
		Enum Default; */
	RMCPUBlockPropertyID_ProgramRawDataXfer = 4009,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMCPUBlockPropertyID_DisableTransferTask = 1017,
	/** ::struct SoftIrqTaskEvent, (W) @par 
		Enum Default; */
	RMCPUBlockPropertyID_SetSoftIrqTaskEvent = 1018,
	/** ::struct SoftIrqTaskEvent, (W) @par 
		Enum Default; */
	RMCPUBlockPropertyID_ClearSoftIrqTaskEvent = 1019,
	/** ::struct SoftIrqTaskEvent, (W) @par 
		Enum Default; */
	RMCPUBlockPropertyID_EnableSoftIrqTaskEvent = 1020,
	/** ::struct SoftIrqTaskEvent, (W) @par 
		Enum Default; */
	RMCPUBlockPropertyID_DisableSoftIrqTaskEvent = 1021,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMCPUBlockPropertyID_PCIEnableInterrupt = 3002,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMCPUBlockPropertyID_PCIDisableInterrupt = 3003,
	/** CPUBlock_Error_type, (R) @par 
		Enum Default; */
	RMCPUBlockPropertyID_Error = 4010,
	/** CPUBlock_EMhwlibError_type, (W) @par 
		Enum Default; */
	RMCPUBlockPropertyID_EMhwlibError = 1023,
	/** CPUBlock_HeartBeatCounters_in_type and CPUBlock_HeartBeatCounters_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMCPUBlockPropertyID_HeartBeatCounters = 4534,
	/** CPUBlock_ReadBufferThreshold_type, (W) @par 
		Enum Default; */
	RMCPUBlockPropertyID_ReadBufferThreshold = 1106,
};

/** Module Enum Default */
enum RMXPUBlockPropertyID {
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMXPUBlockPropertyID_DoXrpc = 3005,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMXPUBlockPropertyID_UnloadIrqHandler = 3006,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMXPUBlockPropertyID_ZeroIrqHandlerAPI = 3007,
	/** XPUBlock_Error_type, (R) @par 
		Enum Default; */
	RMXPUBlockPropertyID_Error = 4011,
};

/** Module Enum Default */
enum RMIPUBlockPropertyID {
	/** IPUBlock_Error_type, (R) @par 
		Enum Default; */
	RMIPUBlockPropertyID_Error = 4598,
};

/** Module Enum Default */
enum RMDisplayBlockPropertyID {
	/** DisplayBlock_VsyncApiInfo_type, (R) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_VsyncApiInfo = 4012,
	/** DisplayBlock_SurfaceSize_in_type and DisplayBlock_SurfaceSize_out_type, (R/W Exchange) @par 
		returns the required DRAM size, in bytes, as well as the buffer sizes for luma and chroma for a given format and image size. also allots space for vsync surface struct. the chroma plane has to follow the luma plane immediately in memory */
	RMDisplayBlockPropertyID_SurfaceSize = 4013,
	/** DisplayBlock_PictureSize_in_type and DisplayBlock_PictureSize_out_type, (R/W Exchange) @par 
		returns the required DRAM size, in bytes, as well as the buffer sizes for luma and chroma for a given format and image size. also allots space for vsync surface struct. the chroma plane has to follow the luma plane immediately in memory */
	RMDisplayBlockPropertyID_PictureSize = 4014,
	/** DisplayBlock_MultiplePictureSurfaceSize_in_type and DisplayBlock_MultiplePictureSurfaceSize_out_type, (R/W Exchange) @par 
		returns the required DRAM size, in bytes, as well as the buffer sizes for luma and chroma for a given format and image size. also allots space for vsync surface struct. the chroma plane has to follow the luma plane immediately in memory */
	RMDisplayBlockPropertyID_MultiplePictureSurfaceSize = 4015,
	/** DisplayBlock_InitSurface_in_type and DisplayBlock_InitSurface_out_type, (R/W Exchange) @par 
		initialize a static surface */
	RMDisplayBlockPropertyID_InitSurface = 6001,
	/** DisplayBlock_InitMultiplePictureSurface_type, (W) @par 
		initialize a picture fifo surface */
	RMDisplayBlockPropertyID_InitMultiplePictureSurface = 6002,
	/** DisplayBlock_InitMultiplePictureSurfaceX_type, (W) @par 
		initialize a picture fifo surface */
	RMDisplayBlockPropertyID_InitMultiplePictureSurfaceX = 6191,
	/** DisplayBlock_InitPicture_in_type and DisplayBlock_InitPicture_out_type, (R/W Exchange) @par 
		returns the required DRAM size, in bytes, as well as the buffer sizes for luma and chroma for a given format and image size. also allots space for vsync surface struct. the chroma plane has to follow the luma plane immediately in memory */
	RMDisplayBlockPropertyID_InitPicture = 4016,
	/** DisplayBlock_InitPictureX_in_type and DisplayBlock_InitPictureX_out_type, (R/W Exchange) @par 
		returns the required DRAM size, in bytes, as well as the buffer sizes for luma and chroma for a given format and image size. also allots space for vsync surface struct. the chroma plane has to follow the luma plane immediately in memory */
	RMDisplayBlockPropertyID_InitPictureX = 4470,
	/** DisplayBlock_SurfaceInfo_in_type and DisplayBlock_SurfaceInfo_out_type, (R/W Exchange) @par 
		Get the surface fields */
	RMDisplayBlockPropertyID_SurfaceInfo = 6003,
	/** DisplayBlock_PictureInfo_in_type and DisplayBlock_PictureInfo_out_type, (R/W Exchange) @par 
		Get some picture fields */
	RMDisplayBlockPropertyID_PictureInfo = 6183,
	/** DisplayBlock_InsertPictureInSurfaceFifo_type, (W) @par 
		insert a picture inside the surface picture's fifo */
	RMDisplayBlockPropertyID_InsertPictureInSurfaceFifo = 4017,
	/** DisplayBlock_SetPaletteOnPicture_type, (W) @par 
		insert a picture inside the surface picture's fifo */
	RMDisplayBlockPropertyID_SetPaletteOnPicture = 4471,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_ErasePicturesInSurfaceFifo = 4018,
	/** DisplayBlock_SurfaceAspectRatio_type, (W) @par 
		initialize a static surface */
	RMDisplayBlockPropertyID_SurfaceAspectRatio = 6004,
	/** DisplayBlock_SurfaceSTC_type, (W) @par 
		Set/Get the STC Module ID attached to a surface */
	RMDisplayBlockPropertyID_SurfaceSTC = 6204,
	/** DisplayBlock_ForcePictureBufferAddress_type, (W) @par 
		force the picture buffer address */
	RMDisplayBlockPropertyID_ForcePictureBufferAddress = 6005,
	/** DisplayBlock_EnableGFXInteraction_type, (W) @par 
		initialize a static surface */
	RMDisplayBlockPropertyID_EnableGFXInteraction = 6006,
	/** ::RMbool, (W) @par 
		Locks the display to activate several properties at once during vertical blanking.@note Failure to lock may cause artifacts created by partial output settings. */
	RMDisplayBlockPropertyID_Lock = 5006,
	/** DisplayBlock_AltOutConfig_type, (W) @par 
		Configure which GPIO pin at which polarity is used with property AlternateOutput */
	RMDisplayBlockPropertyID_AltOutConfig = 5007,
	/** ::RMbool, (W) @par 
		Sets GPIO4 to redirect the video to a different output.@note This property is board dependent. */
	RMDisplayBlockPropertyID_AlternateOutput = 5008,
	/** DisplayBlock_OutputNumber_in_type and DisplayBlock_OutputNumber_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_OutputNumber = 1024,
	/** DisplayBlock_OutputModuleID_in_type and DisplayBlock_OutputModuleID_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_OutputModuleID = 1025,
	/** DisplayBlock_InputNumber_in_type and DisplayBlock_InputNumber_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_InputNumber = 1026,
	/** DisplayBlock_InputModuleID_in_type and DisplayBlock_InputModuleID_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_InputModuleID = 1027,
	/** DisplayBlock_PortNumber_in_type and DisplayBlock_PortNumber_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_PortNumber = 1028,
	/** DisplayBlock_PortModuleID_in_type and DisplayBlock_PortModuleID_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_PortModuleID = 1029,
	/** DisplayBlock_TVPixelClockAnalog_in_type and DisplayBlock_TVPixelClockAnalog_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_TVPixelClockAnalog = 1030,
	/** DisplayBlock_TVPixelClockDigital_in_type and DisplayBlock_TVPixelClockDigital_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_TVPixelClockDigital = 1031,
	/** DisplayBlock_TVFormatAnalog_in_type and DisplayBlock_TVFormatAnalog_out_type, (R/W Exchange) @par 
		Gets the default output display parameters based on a provided TV standard.@note This does not program the display, this is just an informational property */
	RMDisplayBlockPropertyID_TVFormatAnalog = 1032,
	/** DisplayBlock_TVFormatDigital_in_type and DisplayBlock_TVFormatDigital_out_type, (R/W Exchange) @par 
		Gets the default output display parameters based on a provided TV standard.@note This does not program the display, this is just an informational property */
	RMDisplayBlockPropertyID_TVFormatDigital = 1033,
	/** DisplayBlock_AnalogSDParams_type, (W) @par 
		 */
	RMDisplayBlockPropertyID_AnalogSDParams = 1034,
	/** DisplayBlock_AnalogHDParams_type, (W) @par 
		 */
	RMDisplayBlockPropertyID_AnalogHDParams = 1035,
	/** DisplayBlock_AnalogOffsetParams_type, (W) @par 
		 */
	RMDisplayBlockPropertyID_AnalogOffsetParams = 1036,
	/** DisplayBlock_DigitalParams_type, (W) @par 
		 */
	RMDisplayBlockPropertyID_DigitalParams = 1037,
	/** DisplayBlock_VBUSBandwidth_type, (R/W) @par 
		@note Used to program the VBUS bandwidth arbiter */
	RMDisplayBlockPropertyID_VBUSBandwidth = 6007,
	/** ::RMbool, (R/W) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_EnableDirtyBits = 4021,
	/** ::RMbool, (R/W) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_EnableVBUSArbiter = 4022,
	/** DisplayBlock_HDMIState_enum, (R/W) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_HDMIState = 4023,
	/** DisplayBlock_HDMIConfig_type, (R/W) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_HDMIConfig = 4024,
	/** DisplayBlock_PixelClock_type, (W) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_PixelClock = 1038,
	/** DisplayBlock_AnalogFrameInfoToCGMSWSS525_in_type and DisplayBlock_AnalogFrameInfoToCGMSWSS525_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_AnalogFrameInfoToCGMSWSS525 = 1096,
	/** DisplayBlock_AnalogFrameInfoToCGMSWSS625_in_type and DisplayBlock_AnalogFrameInfoToCGMSWSS625_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_AnalogFrameInfoToCGMSWSS625 = 1097,
	/** DisplayBlock_CGMSWSS525ToAnalogFrameInfo_in_type and DisplayBlock_CGMSWSS525ToAnalogFrameInfo_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_CGMSWSS525ToAnalogFrameInfo = 1098,
	/** DisplayBlock_CGMSWSS625ToAnalogFrameInfo_in_type and DisplayBlock_CGMSWSS625ToAnalogFrameInfo_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_CGMSWSS625ToAnalogFrameInfo = 1099,
	/** DisplayBlock_PeekNextPicture_in_type and DisplayBlock_PeekNextPicture_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_PeekNextPicture = 1100,
	/** DisplayBlock_GetNextPicture_in_type and DisplayBlock_GetNextPicture_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_GetNextPicture = 1101,
	/** ::struct EMhwlibSurfaceReader, (W) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_AcquirePicture = 1102,
	/** ::struct EMhwlibSurfaceReader, (W) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_ReleasePicture = 1103,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_ErasePicture = 4548,
	/** DisplayBlock_SequencePicture_in_type and DisplayBlock_SequencePicture_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_SequencePicture = 4589,
	/** DisplayBlock_SurfaceDefaultColorSpaceAlgorithm_type, (W) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_SurfaceDefaultColorSpaceAlgorithm = 4590,
	/** DisplayBlock_ConnectReader_in_type and DisplayBlock_ConnectReader_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_ConnectReader = 6197,
	/** ::struct EMhwlibSurfaceReader, (W) @par 
		Enum Default; */
	RMDisplayBlockPropertyID_DisconnectReader = 6198,
};

/** Module Enum Default */
enum RMDispOSDScalerPropertyID {
	/** DispOSDScaler_ScalingConfig_type, (R/W) @par 
		Sets the OSD scaling mode */
	RMDispOSDScalerPropertyID_ScalingConfig = 6014,
};

/** The hardware cursor block generates a small picture to the main mixer block.@n An arbitrary bitmap is stored in 4 bit/pixel format in  a 512x32 on-chip SRAM. Thus no external memory bandwidth is required to support the cursor.@n On chips earlier than SMP8634, each 4-bit pixel is fed to a 16x6x4 lookup table to produce an output stream of 24-bit (6-6-6-6 format) aYcbCr pixels.@note Each video component is multiplied by four, and the akpha value is extended to 8 bits before being sent to the main mixer.@n On SMP8634 and later chips, each 4-bit pixel is fed to a 16x32 look-up table which outputs 32 bit 8888 aYCbCr pixels.@n The horizontal and vertical dimensions of the cursor picture is constrained as follows: @li X size less than or equal to 255 @li Y size less than or equal to 255 */
enum RMDispHardwareCursorPropertyID {
	/** ::RMCursorPix, (W) @par 
		Enum Default; */
	RMDispHardwareCursorPropertyID_Bitmap = 6031,
	/** ::RMCursorLut, (W) @par 
		Enum Default; */
	RMDispHardwareCursorPropertyID_Lut = 6032,
	/** DispHardwareCursor_Size_type, (W) @par 
		Enum Default; */
	RMDispHardwareCursorPropertyID_Size = 6033,
};

/** The main video scaler is similar in general structure to the multi-format scalers with several important differences:\n @li Only video input data formats are supported (no graphics) @li 4-tap H and V-scalers are implemented rather than 2-tap @li A special deinterlacing mode supports vertical scaling using a 2-tap filter combining previous field and current field data @li HD (ITU 709) <-> SD (ITU 601) colorimetry conversion is supported  (both directions).\n\n The main video scaler supports deinterlacing using either of two algorithms, Type 1 and Type 2.\n\n @li In the Type 1 algorithm, output frame N is constructed from both the current (field N) and previous field (field N-1). Each field has  its missing lines reconstructed by a linear interpolation of its neighboring lines. For each output line, the actual (or interpolated) data from field N is combined with the interpolated (or actual) data from field N-1, using the weighted summation: @n @verbatim Lnew = [A* LN-1 + (16 A)* LN] / 16  or Lnew = [B* LN-1 + (16-B)* LN] / 16 @endverbatim where A and B are programmed parameters. Parameter A is used when Lnew exists in the current field (N); parameter B is used when Lnew exists in the previous field (N-1).@li Type 2 deinterlacing uses 3 fields, and is motion-adaptive. Output frame N is built from frame N-1, N, and N+1. Field N-1 and N+1 luma values are compared over 4x2 pixel blocks, resulting in a localized motion detection. Fields N-1 and N are both upscaled, and information from field N-1 is inserted into the output frame depending on how much motion is detected. In other words, the algorithm shifts between inter-field (weave) deinterlacing in regions with little motion, and intra-field (bob) deinterlacing in regions with significant motion.  The Type 2 algorithm supports concurrent deinterlacing and resizing, such as converting 480i input to 720p format. Implementing the Type 2 algorithm involves a coordinated usage of the main video scaler, an available multi-scaler, and the primary mixer block. */
enum RMDispMainVideoScalerPropertyID {
	/** ::enum EMhwlibDeinterlacingMode, (R/W) @par 
		Sets the deinterlacing mode (0,1,2) */
	RMDispMainVideoScalerPropertyID_DeinterlacingMode = 6045,
	/** DispMainVideoScaler_DeinterlacingProportion_type, (R/W) @par 
		Sets the proportion of field N-1 to generate frame N */
	RMDispMainVideoScalerPropertyID_DeinterlacingProportion = 6046,
	/** DispMainVideoScaler_DeinterlacingMotionConfig_type, (R/W) @par 
		Sets the alpha motion modulation function */
	RMDispMainVideoScalerPropertyID_DeinterlacingMotionConfig = 6047,
	/** ::RMuint32, (R/W) @par 
		Sets the scaler id of the scaler needed for motion adaptative deinterlacing */
	RMDispMainVideoScalerPropertyID_DeinterlacingMotionScaler = 6048,
	/** ::RMbool, (R/W) @par 
		Enum Default; */
	RMDispMainVideoScalerPropertyID_Enable_3_2_PullDownDetection = 6049,
	/** DispMainVideoScaler_FilterSelection_type, (R/W) @par 
		Sets the scaling filter selection boundaries */
	RMDispMainVideoScalerPropertyID_FilterSelection = 6050,
};

/** Module Enum Default */
enum RMDispSubPictureScalerPropertyID {
	/** DispSubPictureScaler_ScalingConfig_type, (R/W) @par 
		Sets the SPU scaling mode */
	RMDispSubPictureScalerPropertyID_ScalingConfig = 6053,
};

/** The three multi-format scalers (VCR/CRT/GFX) are general-purpose scaling units which can accept all supported video and graphics data formats (except sub-picture). A 256x32 lookup table in each scaler supports color expansion in 1, 2, 4 and 8 bit/pixel input modes. Due to internal RAM size limitations, these scalers support a maximum of 1024 pixels/line in 32 bit/pixel modes, and a maximum of 2048 pixels/line in 16 (or less) bit/pixel modes. Each scaler processes the video stream in the YC domain, and implements 2-tap H and V-scalers with a scaling range of 0.25 to infinity. Additional downscaling is possible by employing a pre-downscaler before the 2-tap scalers. Each scaler can properly support the differing chrominance sample alignment of MPEG-1 versus MPEG-2. */
enum RMDispVCRMultiScalerPropertyID {
	RMDispVCRMultiScaler_unused = 0, 
};

/** The three multi-format scalers (VCR/CRT/GFX) are general-purpose scaling units which can accept all supported video and graphics data formats (except sub-picture). A 256x32 lookup table in each scaler supports color expansion in 1, 2, 4 and 8 bit/pixel input modes. Due to internal RAM size limitations, these scalers support a maximum of 1024 pixels/line in 32 bit/pixel modes, and a maximum of 2048 pixels/line in 16 (or less) bit/pixel modes. Each scaler processes the video stream in the YC domain, and implements 2-tap H and V-scalers with a scaling range of 0.25 to infinity. Additional downscaling is possible by employing a pre-downscaler before the 2-tap scalers. Each scaler can properly support the differing chrominance sample alignment of MPEG-1 versus MPEG-2. */
enum RMDispCRTMultiScalerPropertyID {
	RMDispCRTMultiScaler_unused = 0, 
};

/** The three multi-format scalers (VCR/CRT/GFX) are general-purpose scaling units which can accept all supported video and graphics data formats (except sub-picture). A 256x32 lookup table in each scaler supports color expansion in 1, 2, 4 and 8 bit/pixel input modes. Due to internal RAM size limitations, these scalers support a maximum of 1024 pixels/line in 32 bit/pixel modes, and a maximum of 2048 pixels/line in 16 (or less) bit/pixel modes. Each scaler processes the video stream in the YC domain, and implements 2-tap H and V-scalers with a scaling range of 0.25 to infinity. Additional downscaling is possible by employing a pre-downscaler before the 2-tap scalers. Each scaler can properly support the differing chrominance sample alignment of MPEG-1 versus MPEG-2. */
enum RMDispGFXMultiScalerPropertyID {
	RMDispGFXMultiScaler_unused = 0, 
};

/** The main mixer receives the picture streams from each of the eight sources.@n @image html DispMainMixer_Block.png "Main Mixer" @n Each incoming stream passes through a positioning block, which places the input picture at a specified horizontal and vertical position within the active display window. Within the mixer, the positioned streams are then sorted according to a programmable ordering. The highest priority (top layer) is always assigned to the hardware cursor. For each pixel, layer 5 is alpha-blended with layer 4, layer 6 is alpha-blended with the result, and layer 7 is alpha-blended to form the output pixel. If any pixel is transparent, the sort moves down the layer order until a non-transparent pixel is found. Thus the output pixel stream consists of the merged combination of the four highest priority non-transparent layers. The output of the main mixer is sent to the display routing block. @image html DispMainMixer_Position.png Position Block */
enum RMDispMainMixerPropertyID {
	/** DispMainMixer_LayerOrder_type, (R/W) @par 
		@note Only a maximum of 4 planes can be blended per pixel. A transparent pixel is not considered as alpha blended.@note Layer 7 is reserved for the Hardware Cursor */
	RMDispMainMixerPropertyID_LayerOrder = 6056,
};

/** Module Enum Default */
enum RMDispVCRMixerPropertyID {
	/** DispVCRMixer_LayerOrder_type, (R/W) @par 
		@note Only a maximum of 4 planes can be blended per pixel. A transparent pixel is not considered as alpha blended.@note Layer 7 is reserved for the Hardware Cursor */
	RMDispVCRMixerPropertyID_LayerOrder = 6065,
};

/** Module Enum Default */
enum RMDispColorBarsPropertyID {
	/** ::RMuint32, (R/W) @par 
		Enum Default; */
	RMDispColorBarsPropertyID_Intensity = 6066,
	/** ::enum EMhwlibColorBarsStandard, (R/W) @par 
		Enum Default; */
	RMDispColorBarsPropertyID_Standard = 6067,
};

/** Module Enum Default */
enum RMDispRoutingPropertyID {
	/** DispRouting_Route_type, (W) @par 
		Enum Default; */
	RMDispRoutingPropertyID_Route = 4031,
	/** DispRouting_Routing_type, (R) @par 
		Enum Default; */
	RMDispRoutingPropertyID_Routing = 4032,
};

/** Module Enum Default */
enum RMDispVideoInputPropertyID {
	/** DispVideoInput_DRAMSize_in_type and DispVideoInput_DRAMSize_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDispVideoInputPropertyID_DRAMSize = 4033,
	/** DispVideoInput_Open_type, (W) @par 
		Enum Default; */
	RMDispVideoInputPropertyID_Open = 4034,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMDispVideoInputPropertyID_Close = 4035,
	/** ::RMuint32, (R/W) @par 
		Number of bits (8 or 16) on the video input. */
	RMDispVideoInputPropertyID_BusSize = 6069,
	/** DispVideoInput_InputFormat_type, (R/W) @par 
		Enum Default; */
	RMDispVideoInputPropertyID_InputFormat = 6070,
};

/** Module Enum Default */
enum RMDispGraphicInputPropertyID {
	/** DispGraphicInput_DRAMSize_in_type and DispGraphicInput_DRAMSize_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDispGraphicInputPropertyID_DRAMSize = 4040,
	/** DispGraphicInput_Open_type, (W) @par 
		Enum Default; */
	RMDispGraphicInputPropertyID_Open = 4041,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMDispGraphicInputPropertyID_Close = 4042,
	/** DispGraphicInput_InputFormat_type, (R/W) @par 
		Subset for video input. For all features of graphics input, use Format property. */
	RMDispGraphicInputPropertyID_InputFormat = 6079,
	/** DispGraphicInput_OutputFormat_type, (R/W) @par 
		Specifies the output surface characteristics */
	RMDispGraphicInputPropertyID_OutputFormat = 6080,
	/** DispGraphicInput_KeyColor_type, (R/W) @par 
		Enum Default; */
	RMDispGraphicInputPropertyID_KeyColor = 6081,
	/** ::RMuint32, (R/W) @par 
		Routing source of the H- and V-Sync outputs. @note Allowed module IDs: @li DispGraphicInput @li DispDigitalOut @li DispMainAnalogOut @li DispComponentOut @li DispCompositeOut */
	RMDispGraphicInputPropertyID_SyncControlModuleID = 6082,
};

/** Module Enum Default */
enum RMDispDigitalOutPropertyID {
	/** ::enum EMhwlibDigitalTimingSignal, (R/W) @par 
		Enable CCIR 656 embedded sync signals. */
	RMDispDigitalOutPropertyID_TimingSignal = 6083,
	/** ::RMbool, (R/W) @par 
		Luma or RGB components are clipped between 16 and 235, chroma is clipped from 16 to 240, if active. */
	RMDispDigitalOutPropertyID_EnableClipping = 6084,
	/** DispDigitalOut_ClippingLevel_enum, (R/W) @par 
		Luma or RGB components are clipped between 16 and 235, chroma is clipped from 16 to 240, if active. */
	RMDispDigitalOutPropertyID_ClippingLevel = 6085,
	/** ::RMuint32, (R/W) @par 
		Number of bits (8, 16 or 24) on the digital output. */
	RMDispDigitalOutPropertyID_BusSize = 6086,
	/** ::RMbool, (R/W) @par 
		Define the YUV format following MPEG2 (0) specification or MPEG1 (1) specification */
	RMDispDigitalOutPropertyID_EnableMPEG1Chroma = 6087,
	/** ::enum EMhwlibColorOrder, (R/W) @par 
		Specify the order of the digital data to: @li 24 bit R-G-B (0) or R-B-G (1) @li 24 bit Cr-Y-Cb (0) or Cr-Cb-Y (1) @li 16 bit Y-CbCr (0) CbCr-Y (1) */
	RMDispDigitalOutPropertyID_ColorOrder = 6088,
	/** ::RMbool, (R/W) @par 
		Sets the DoubleRate feature of EM863x. If TRUE, each pixel will be sent twice, doubling the pixel clock and all horizontal timing values at the digital output pads. */
	RMDispDigitalOutPropertyID_DoubleRate = 6089,
	/** ::RMbool, (R/W) @par 
		If TRUE, Delays VSYNC by one pixel clock. */
	RMDispDigitalOutPropertyID_VSyncDelay1PixClk = 6184,
	/** ::RMbool, (R/W) @par 
		If TRUE, sets the field ID logic on the HSync trailing edge. */
	RMDispDigitalOutPropertyID_TrailingEdge = 6185,
	/** ::RMuint32, (R/W) @par 
		Routing source of the H- and V-Sync outputs. @note Allowed module IDs: @li DispDigitalOut @li DispMainAnalogOut @li DispComponentOut */
	RMDispDigitalOutPropertyID_SyncControlModuleID = 6090,
	/** ::RMbool, (R/W) @par 
		enables the data pad. */
	RMDispDigitalOutPropertyID_EnableDataPAD = 6091,
	/** ::RMbool, (R/W) @par 
		enables the sync pad. */
	RMDispDigitalOutPropertyID_EnableSyncPAD = 6092,
	/** ::RMbool, (R/W) @par 
		enables the vvld pad. */
	RMDispDigitalOutPropertyID_EnableVVLDPAD = 6093,
	/** DispDigitalOut_PadsConfig_type, (R/W) @par 
		Several output options - OBSOLETE, use PadsControl/QueryPadsControl instead! */
	RMDispDigitalOutPropertyID_PadsConfig = 6094,
	/** DispDigitalOut_InputPadsConfig_type, (R/W) @par 
		Several input options - OBSOLETE, use PadsControl/QueryPadsControl instead! */
	RMDispDigitalOutPropertyID_InputPadsConfig = 6095,
	/** DispDigitalOut_PadsControl_type, (W) @par 
		Several options for the digital input and output ports */
	RMDispDigitalOutPropertyID_PadsControl = 6202,
	/** DispDigitalOut_QueryPadsControl_in_type and DispDigitalOut_QueryPadsControl_out_type, (R/W Exchange) @par 
		Get the current state of several options for the digital input and output ports */
	RMDispDigitalOutPropertyID_QueryPadsControl = 6203,
	/** ::struct EMhwlibColorConversionMatrix, (R/W) @par 
		Colorimetry matrix : Output = [Mat] * Input + Cst */
	RMDispDigitalOutPropertyID_Matrix = 4043,
	/** ::RMbool, (R/W) @par 
		enable/disable Colorimetry matrix */
	RMDispDigitalOutPropertyID_EnableMatrix = 4044,
	/** DispDigitalOut_GPIOFieldID_type, (R/W) @par 
		Enum Default; */
	RMDispDigitalOutPropertyID_GPIOFieldID = 4047,
	/** ::RMpalette_8BPP, (R/W) @par 
		Enum Default; */
	RMDispDigitalOutPropertyID_GammaLut = 4048,
	/** ::RMbool, (R/W) @par 
		Enum Default; */
	RMDispDigitalOutPropertyID_EnableGammaCorrection = 4049,
	/** ::RMpalette_8BPP, (R/W) @par 
		Enum Default; */
	RMDispDigitalOutPropertyID_TemperatureLut = 4050,
	/** ::RMbool, (R/W) @par 
		Enum Default; */
	RMDispDigitalOutPropertyID_EnableTemperatureCorrection = 4051,
	/** ::void, (W) @par 
		Trigger an update of the xtal counter values for VSyncTimes. Need to be followed by a Validate call. */
	RMDispDigitalOutPropertyID_UpdateVSyncTimes = 6209,
	/** DispDigitalOut_VSyncTimes_type, (R) @par 
		Retreive the xtal counter value at the time of each input and output vsync resp. frame start */
	RMDispDigitalOutPropertyID_VSyncTimes = 6208,
};

/** Module Enum Default */
enum RMDispMainAnalogOutPropertyID {
	/** ::RMbool, (R/W) @par 
		Defines if the SD input signal is oversampled 2 times */
	RMDispMainAnalogOutPropertyID_EnableSDTVInput2xOversample = 6107,
	/** ::RMbool, (R/W) @par 
		Saves energy! */
	RMDispMainAnalogOutPropertyID_EnableSync = 6108,
	/** ::RMbool, (R/W) @par 
		Blackout the picture */
	RMDispMainAnalogOutPropertyID_EnablePicture = 6109,
	/** ::enum EMhwlibSharpnessControl, (R/W) @par 
		Sharpness/Notch filter allows to scale the luma amplitude around the chroma carrier frequency. A complete notch is performed by setting to 0 the luma amplitude around the chroma carrier frequency. Sharpness is done by amplifying luma amplitude on its high frequency (the high frequency is the chroma carrier frequency) */
	RMDispMainAnalogOutPropertyID_Sharpness = 6110,
	/** ::enum EMhwlibChromaFilter, (R/W) @par 
		Sets/Gets the Chroma filter */
	RMDispMainAnalogOutPropertyID_ChromaFilter = 6111,
	/** ::enum EMhwlibLumaFilter, (R/W) @par 
		Sets/Gets the Luma filter */
	RMDispMainAnalogOutPropertyID_LumaFilter = 6112,
	/** ::struct EMhwlibColorConversionMatrix, (R/W) @par 
		Colorimetry matrix : Output = [Mat] * Input + Cst */
	RMDispMainAnalogOutPropertyID_Matrix = 4052,
	/** ::RMbool, (R/W) @par 
		enable/disable Colorimetry matrix */
	RMDispMainAnalogOutPropertyID_EnableMatrix = 4053,
	/** ::struct EMhwlibColorConversionMatrix, (R/W) @par 
		Colorimetry matrix for CVBS/S-Video part of light display block: Output = [Mat] * Input + Cst */
	RMDispMainAnalogOutPropertyID_MatrixCVBS = 4054,
	/** ::RMbool, (R/W) @par 
		enable/disable Colorimetry matrix */
	RMDispMainAnalogOutPropertyID_EnableMatrixCVBS = 4055,
	/** ::enum EMhwlibColorSpace, (R/W) @par 
		Enum Default; */
	RMDispMainAnalogOutPropertyID_ColorSpaceCVBS = 6113,
};

/** Module Enum Default */
enum RMDispComponentOutPropertyID {
	/** ::RMbool, (R/W) @par 
		Defines if the SD input signal is oversampled 2 times */
	RMDispComponentOutPropertyID_EnableSDTVInput2xOversample = 6114,
	/** ::RMbool, (R/W) @par 
		Saves energy! */
	RMDispComponentOutPropertyID_EnableSync = 6115,
	/** ::RMbool, (R/W) @par 
		Blackout the picture */
	RMDispComponentOutPropertyID_EnablePicture = 6116,
	/** ::enum EMhwlibChromaFilter, (R/W) @par 
		Sets/Gets the Chroma filter */
	RMDispComponentOutPropertyID_ChromaFilter = 6117,
	/** ::enum EMhwlibLumaFilter, (R/W) @par 
		Sets/Gets the Luma filter */
	RMDispComponentOutPropertyID_LumaFilter = 6118,
	/** ::struct EMhwlibColorConversionMatrix, (R/W) @par 
		Colorimetry matrix : Output = [Mat] * Input + Cst */
	RMDispComponentOutPropertyID_Matrix = 4061,
	/** ::RMbool, (R/W) @par 
		enable/disable Colorimetry matrix */
	RMDispComponentOutPropertyID_EnableMatrix = 4062,
};

/** Module Enum Default */
enum RMDispCompositeOutPropertyID {
	/** ::RMbool, (R/W) @par 
		Defines if the SD input signal is oversampled 2 times */
	RMDispCompositeOutPropertyID_EnableSDTVInput2xOversample = 6119,
	/** ::RMbool, (R/W) @par 
		Saves energy! */
	RMDispCompositeOutPropertyID_EnableSync = 6120,
	/** ::RMbool, (R/W) @par 
		Blackout the picture */
	RMDispCompositeOutPropertyID_EnablePicture = 6121,
	/** ::enum EMhwlibSharpnessControl, (R/W) @par 
		Sharpness/Notch filter allows to scale the luma amplitude around the chroma carrier frequency. A complete notch is performed by setting to 0 the luma amplitude around the chroma carrier frequency. Sharpness is done by amplifying luma amplitude on its high frequency (the high frequency is the chroma carrier frequency) */
	RMDispCompositeOutPropertyID_Sharpness = 6122,
	/** ::enum EMhwlibChromaFilter, (R/W) @par 
		Sets/Gets the Chroma filter */
	RMDispCompositeOutPropertyID_ChromaFilter = 6123,
	/** ::enum EMhwlibLumaFilter, (R/W) @par 
		Sets/Gets the Luma filter */
	RMDispCompositeOutPropertyID_LumaFilter = 6124,
};

/** Module Enum Default */
enum RMDemuxEnginePropertyID {
	/** ::RMuint32, (R) @par 
		Enum Default; */
	RMDemuxEnginePropertyID_MicrocodeVersion = 4063,
	/** DemuxEngine_Microcode_type, (W) @par 
		Enum Default; */
	RMDemuxEnginePropertyID_Microcode = 4064,
	/** DemuxEngine_MicrocodeDRAMSize_in_type and DemuxEngine_MicrocodeDRAMSize_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDemuxEnginePropertyID_MicrocodeDRAMSize = 4065,
	/** ::ProcessorState, (R/W) @par 
		Enum Default; */
	RMDemuxEnginePropertyID_State = 4066,
	/** ::RMuint32, (R) @par 
		 */
	RMDemuxEnginePropertyID_AllocatePidEntry = 1048,
	/** ::RMuint32, (W) @par 
		 */
	RMDemuxEnginePropertyID_FreePidEntry = 1049,
	/** ::RMuint32, (R) @par 
		 */
	RMDemuxEnginePropertyID_AllocateSectionEntry = 1050,
	/** ::RMuint32, (W) @par 
		 */
	RMDemuxEnginePropertyID_FreeSectionEntry = 1051,
	/** ::RMuint32, (R) @par 
		 */
	RMDemuxEnginePropertyID_AllocateCipherEntry = 1052,
	/** ::RMuint32, (W) @par 
		 */
	RMDemuxEnginePropertyID_FreeCipherEntry = 1053,
	/** ::void, (W) @par 
		 */
	RMDemuxEnginePropertyID_TimerInit = 1054,
	/** DemuxEngine_PidUsage_in_type and DemuxEngine_PidUsage_out_type, (R/W Exchange) @par 
		 */
	RMDemuxEnginePropertyID_PidUsage = 1104,
};

/** Module Enum Default */
enum RMMpegEnginePropertyID {
	/** ::RMuint32, (R) @par 
		Enum Default; */
	RMMpegEnginePropertyID_MicrocodeVersion = 4101,
	/** MpegEngine_Microcode_type, (W) @par 
		Enum Default; */
	RMMpegEnginePropertyID_Microcode = 4102,
	/** MpegEngine_MicrocodeDRAMSize_in_type and MpegEngine_MicrocodeDRAMSize_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMMpegEnginePropertyID_MicrocodeDRAMSize = 4103,
	/** ::ProcessorState, (R/W) @par 
		Enum Default; */
	RMMpegEnginePropertyID_State = 4104,
	/** MpegEngine_DecoderSharedMemory_type, (R/W) @par 
		Enum Default; */
	RMMpegEnginePropertyID_DecoderSharedMemory = 4105,
	/** MpegEngine_SchedulerSharedMemory_type, (R/W) @par 
		Enum Default; */
	RMMpegEnginePropertyID_SchedulerSharedMemory = 4106,
	/** ::RMuint32, (R) @par 
		How many video/spu tasks are currently opened. */
	RMMpegEnginePropertyID_ConnectedTaskCount = 4107,
	/** MpegEngine_ConnectTask_type, (W) @par 
		connect/disconnect video/spu tasks to mpeg engine. */
	RMMpegEnginePropertyID_ConnectTask = 1059,
	/** ::void, (W) @par 
		needed only when microcode is loaded by xos to initialize heartbeat an scheduler symbols in video microcode */
	RMMpegEnginePropertyID_InitMicrocodeSymbols = 1091,
};

/** Module Enum Default */
enum RMVideoDecoderPropertyID {
	/** VideoDecoder_DRAMSize_in_type and VideoDecoder_DRAMSize_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_DRAMSize = 4108,
	/** VideoDecoder_Open_type, (W) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_Open = 4109,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_Close = 4110,
	/** VideoDecoder_Codec_enum, (R/W) @par 
		Selects the type of video codec. The value should be supported by MPEG_profile selected at Open.@note The maximum codec value (MPEG4_HD) corresponds to the maximum DRAM reqirement. @li The video codec can be selected in stop mode and it should be followed by Init command. */
	RMVideoDecoderPropertyID_Codec = 4111,
	/** VideoDecoder_Command_enum, (W) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_Command = 4112,
	/** VideoDecoder_State_enum, (R) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_State = 4113,
	/** VideoDecoder_VopInfo_type, (R/W) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_VopInfo = 4114,
	/** VideoDecoder_VideoTimeScale_type, (R/W) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_VideoTimeScale = 4115,
	/** ::struct InbandCommandX_type, (R) @par 
		 */
	RMVideoDecoderPropertyID_DisplayInbandCommandX = 4117,
	/** ::RMuint32, (R) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_FrameCounter = 6132,
	/** VideoDecoder_WMV9VSProp_type, (W) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_WMV9VSProp = 4118,
	/** VideoDecoder_DIVX3VSProp_type, (W) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_DIVX3VSProp = 4119,
	/** ::RMbool, (W) @par 
		If FALSE, video decoder skips all frames until first SequenceHeader/VOL in stream. If TRUE video decoder starts decoding from the first IFrame in stream, using the previous stored SequenceHeader/VOL. It should be set after video stop and before video play. After video stop the decoder modifies it to FALSE. */
	RMVideoDecoderPropertyID_StorePreviousVideoHeader = 6133,
	/** ::struct SurfaceAspectRatio_type, (W) @par 
		force the aspect ratio of video decoder surface based on inband command */
	RMVideoDecoderPropertyID_InbandSurfaceAspectRatio = 4120,
	/** ::enum EMhwlibScalingMode, (W) @par 
		force the scaling mode of video decoder based on inband command */
	RMVideoDecoderPropertyID_InbandScalingMode = 4121,
	/** VideoDecoder_ForceColorSpace_type, (W) @par 
		force the color space of the video source */
	RMVideoDecoderPropertyID_ForceColorSpace = 4122,
	/** ::enum EMhwlibScanMode, (W) @par 
		sets the scan mode (progressive/interlaced) of the video source */
	RMVideoDecoderPropertyID_ScanMode = 4123,
	/** ::RMuint64, (R) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_LastDecodedPTS = 4124,
	/** ::RMuint32, (R) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_DecodedPictureCount = 4125,
	/** ::RMuint32, (R) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_SkippedPictureCount = 4126,
	/** ::RMuint32, (R) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_Error = 4127,
	/** ::RMuint32, (R) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_Skip = 4128,
	/** ::RMuint32, (R) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_Overlay = 1061,
	/** ::struct VideoDecoder_NextPicture_type, (R) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_PeekNextPicture = 6134,
	/** VideoDecoder_ConnectReader_in_type and VideoDecoder_ConnectReader_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_ConnectReader = 6135,
	/** ::void, (W) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_DisconnectReader = 6136,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_ReleasePicture = 6137,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_AcquirePicture = 6138,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_KeepPictureBeforeFlushing = 6139,
	/** ::void, (W) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_FlushReaderDisplayFIFO = 6140,
	/** ::struct VideoDecoder_NextPicture_type, (R) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_NextPicture = 6141,
	/** VideoDecoder_DecoderDataMemory_in_type and VideoDecoder_DecoderDataMemory_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_DecoderDataMemory = 4129,
	/** VideoDecoder_DRAMSizeX_in_type and VideoDecoder_DRAMSizeX_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_DRAMSizeX = 4130,
	/** VideoDecoder_OpenX_type, (W) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_OpenX = 4131,
	/** ::enum EMhwlibVideoCodec, (R/W) @par 
		 */
	RMVideoDecoderPropertyID_CodecX = 4132,
	/** ::RMuint32, (R) @par 
		gbus address of bitstream fifo container. */
	RMVideoDecoderPropertyID_BtsFIFO = 4133,
	/** ::struct UserDataFIFOInfo, (R) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_UserDataFIFOInfo = 4134,
	/** ::RMstatus, (R) @par 
		status of the execution of the last command */
	RMVideoDecoderPropertyID_CommandStatus = 4135,
	/** ::RMuint32, (W) @par 
		pictures with an error count above this value are not sent to display */
	RMVideoDecoderPropertyID_DisplayErrorThreshold = 4479,
	/** VideoDecoder_AnchorErrPropagation_type, (W) @par 
		Enum Default; */
	RMVideoDecoderPropertyID_AnchorErrPropagation = 4560,
	/** ::RMbool, (W) @par 
		When set to TRUE it enables the low delay or video drip functionality. The video decoder needs at least 4 bytes of 0 at the end of every frame. The frame is displayed immediately, ignoring the display reordering. */
	RMVideoDecoderPropertyID_LowDelay = 4485,
	/** ::RMuint32, (W) @par 
		Property used to customize the display information from video stream is a specific way. Default is as standard. One option allows that flag progressive_sequence=0 for mpeg2 to be interpreted as always deinterlace. */
	RMVideoDecoderPropertyID_InterlacedProgressiveAlgorithm = 4487,
	/** ::RMuint64, (W) @par 
		Property used to set the initial hardware pts used for B frames in closed GOP. The unit is codec dependent. For mpeg2 is 45k. */
	RMVideoDecoderPropertyID_InitialHwPts = 4501,
	/** ::struct EMhwlibActiveFormatDescription, (R) @par 
		Returns the current active format (extracted from the user data) and the picture aspect ratio of the encoded frame. */
	RMVideoDecoderPropertyID_ActiveFormat = 6192,
	/** ::RMbool, (R/W) @par 
		the video decoder shall skip NotCoded P Frames (to handle DIVX packed streams that make an invalid use of NCP Frames) */
	RMVideoDecoderPropertyID_SkipNotCodedPFrames = 4559,
	/** ::RMuint32, (W) @par 
		Default 0. Logic OR-ed flags: VIDEO_SEQUENCE_END_CODE_RESET_REFERENCES, VIDEO_SEQUENCE_END_CODE_RESET_DISPLAY_SIZE, VIDEO_SEQUENCE_END_CODE_RESET_COLOR_DESCRIPTION  */
	RMVideoDecoderPropertyID_SequenceEndCodeResetFlags = 4606,
};

/** This module provides access to the Audio DSP specific functionalities */
enum RMAudioEnginePropertyID {
	/** ::RMuint32, (R) @par 
		Retrieves loaded Audio DSP Microcode Version */
	RMAudioEnginePropertyID_MicrocodeVersion = 4136,
	/** AudioEngine_Microcode_type, (W) @par 
		Select and load the Audio DSP microcode. @note @li This property should be called only when the DSP is in stopped state.\n @li Use the ::RMAudioEnginePropertyID_MicrocodeDRAMSize  property followed by a call to ::RUAMalloc to allocate the memory specified by the Address parameter */
	RMAudioEnginePropertyID_Microcode = 4137,
	/** AudioEngine_MicrocodeDRAMSize_in_type and AudioEngine_MicrocodeDRAMSize_out_type, (R/W Exchange) @par 
		Returns DDR-DRAM memory (cached or un-cached) requirements for a specified microcode. @note @li This function must be used before allocating the returned memory size using ::RUAMalloc. The ::RMAudioEnginePropertyID_Microcode  property needs this memory to store microcode specific overlays and data. \n @li The same Microcode version has to be used when calling ::RMAudioEnginePropertyID_Microcode. Failure to do so may result in insufficient memory or memory overrun. */
	RMAudioEnginePropertyID_MicrocodeDRAMSize = 4138,
	/** ::ProcessorState, (R/W) @par 
		Set or Get Audio DSP processor state. This property is used to reset, stop and run the DSP during initialization time. Once a DSP is running, it should remain as such until the system is in error state or shutdowned. @note @li This property should be used with extreme cautious since it affects directly the hardware state.\n @li DO NOT USE this call to control the audio decoding process. Use ::RMAudioDecoderPropertyID_Command property instead.@sa ::RMAudioEnginePropertyID_MicrocodeVersion */
	RMAudioEnginePropertyID_State = 4139,
	/** ::RMuint32, (R/W) @par 
		Set the decoder PLL input and Audio output frequencies (in Hz). @note @li This property should be called before sending any DSP command using ::RMAudioDecoderPropertyID_Command.@li An auto-detection frequency mechanism for compressed audio (i.e. not PCM data) may be added in later releases.@li The same output frequencies apply to all Audio decoders. All audio decoders other then PCM used on a single DSP currently require to be encoded at the same input frequency. PCM supports some frequency adjustments. */
	RMAudioEnginePropertyID_SampleFrequency = 4140,
	/** ::RMbool, (R/W) @par 
		Set forced sample frequency (FALSE, default) or sample frequency set from stream information by audio decoder (TRUE). */
	RMAudioEnginePropertyID_SampleFrequencyFromStream = 4141,
	/** AudioEngine_SampleFrequencyFromSource_type, (R/W) @par 
		Extended version of property SampleFrequency. @note SampleFrequency is the same as SampleFrequencyFromSource, with GeneratorNumber = 3, Source = 1 (XtalIn) at 27MHz and IntermediateFrequency = 148500000. */
	RMAudioEnginePropertyID_SampleFrequencyFromSource = 4142,
	/** ::enum MClkFactor, (R/W) @par 
		Set or Get the Master CLock factor, either 256 * fs or 128 * fs */
	RMAudioEnginePropertyID_MasterClockFactor = 4480,
	/** AudioEngine_Volume_type, (R/W) @par 
		Set audio output channel FIFO volume.@li Increasing the audio volume above 0db may cause distortion (cropping) on the audio output depending on the audio source.@li This volume is the master output volume for the specified channel. Even though this volume will be applied to 2 audio decoders, there are currently no way to control the volume separately on these 2 decoders. */
	RMAudioEnginePropertyID_Volume = 4143,
	/** AudioEngine_Delay_type, (W) @par 
		Set audio output channel FIFO volume.@li Increasing the audio volume above 0db may cause distortion (cropping) on the audio output depending on the audio source.@li This volume is the master output volume for the specified channel. Even though this volume will be applied to 2 audio decoders, there are currently no way to control the volume separately on these 2 decoders. */
	RMAudioEnginePropertyID_Delay = 4144,
	/** AudioEngine_PL2x_type, (W) @par 
		Set ProLogic IIx parameters */
	RMAudioEnginePropertyID_PL2x = 4594,
	/** AudioEngine_QueryVolume_in_type and AudioEngine_QueryVolume_out_type, (R/W Exchange) @par 
		Returns audio volume on a specified channel.@note @li This volume is the master output volume for the specified channel. Even though this volume will be applied to 2 audio decoders, there are currently no way to control the volume separately on these 2 decoders. */
	RMAudioEnginePropertyID_QueryVolume = 4145,
	/** AudioEngine_SerialOut_enum, (R/W) @par 
		Set or Get serialout enable */
	RMAudioEnginePropertyID_SerialOut = 4146,
	/** AudioEngine_I2SConfig_type, (R/W) @par 
		Set I2S audio output configuration. Both audio decoders will share same channel status. */
	RMAudioEnginePropertyID_I2SConfig = 4147,
	/** AudioEngine_SpdifOut_enum, (R/W) @par 
		Set or Get spdifout enable */
	RMAudioEnginePropertyID_SpdifOut = 4148,
	/** AudioEngine_I2sOut_enum, (R/W) @par 
		Set or Get i2sout enable */
	RMAudioEnginePropertyID_I2sOut = 4591,
	/** AudioEngine_ChannelStatus_type, (R/W) @par 
		Set SPDIF audio output channel status. Both audio decoders will share same channel status. */
	RMAudioEnginePropertyID_ChannelStatus = 4149,
	/** ::enum OutputSpdif_type, (W) @par 
		Set/reset channel status bit 1 when audio decoder changes the audio format compressed/uncompressed. */
	RMAudioEnginePropertyID_OutputSpdif = 1064,
	/** ::RMbool, (R/W) @par 
		Force 16bit PCM Spdif output */
	RMAudioEnginePropertyID_SpdifForce16Bit = 1092,
	/** AudioEngine_STC_type, (R/W) @par 
		STC maintained by a clock derived from the I2S output clock */
	RMAudioEnginePropertyID_STC = 4150,
	/** AudioEngine_Memcpy_type, (W) @par 
		Operate dram2dram dmacopy on idle DSP */
	RMAudioEnginePropertyID_Memcpy = 4151,
	/** AudioEngine_InputSPDIFStatus_type, (R) @par 
		Get SPDIF audio input channel status. */
	RMAudioEnginePropertyID_InputSPDIFStatus = 4572,
	/** AudioEngine_DecoderSharedMemoryInfo_in_type and AudioEngine_DecoderSharedMemoryInfo_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMAudioEnginePropertyID_DecoderSharedMemoryInfo = 4586,
	/** AudioEngine_DecoderSharedMemory_type, (R/W) @par 
		Enum Default; */
	RMAudioEnginePropertyID_DecoderSharedMemory = 4587,
	/** ::RMuint32, (R) @par 
		Number of audio tasks opened on this audio engine. */
	RMAudioEnginePropertyID_ConnectedTaskCount = 4588,
	/** AudioEngine_ConnectTask_type, (W) @par 
		connect/disconnect audio tasks to audio engine. */
	RMAudioEnginePropertyID_ConnectTask = 1108,
	/** AudioEngine_Downmixing_tables_type, (R/W) @par 
		customized downmixing tables, e.g, ARIB. */
	RMAudioEnginePropertyID_Downmixing_tables = 4592,
	/** ::RMbool, (R/W) @par 
		To use customized downmixing tables, make sure set those tables first!  */
	RMAudioEnginePropertyID_CustomizedDownmixing = 1109,
};

/** This module provides access to the Audio decoder settings */
enum RMAudioDecoderPropertyID {
	/** AudioDecoder_DRAMSize_in_type and AudioDecoder_DRAMSize_out_type, (R/W Exchange) @par 
		Gets the audio decoder DDR-DRAM memory size requirements (cacheable and non-cacheable) based on input/output characteristics.@note @li The CachedSize and UncachedSize values should be used to allocate memory in DDR-DRAM.@li The CachedAddress and UncachedAddress can be obtained in the RUA interface by calling ::RUAMalloc. Refer to the em86xx REALmagic User API document for more info.@li Cacheable memory is memory that is only used by the pt110. Any memory that involves DMA transfers (Either PCI master transfers or em86xx internal MBUS/VBUS transfers) as to be non-cacheable. This allows the pt110 to access data without flushing/reloading its cache and allows better performance. */
	RMAudioDecoderPropertyID_DRAMSize = 4152,
	/** AudioDecoder_Open_type, (W) @par 
		Sets the audio decoder Profile. The profile consist in defining the maximum number of resources (Memory, Number of channels...) the audio decoder will use.@note @li The CachedSize and UncachedSize values can be obtained using the ::RMAudioDecoderPropertyID_DRAMSize exchange properties. The application has to provide these values since it is solely responsible for the DDR-DRAM memory allocation in each DRAM controller.@li The CachedAddress and UncachedAddress can be obtained in the RUA interface by calling RUAMalloc. Refer to the em86xx REALmagic User API document for more info.@li In order to release the resources or change the decoder profile, use the ::RMAudioDecoderPropertyID_Close. You cannot free the memory used by the decoder before calling the ::RMAudioDecoderPropertyID_Close property. */
	RMAudioDecoderPropertyID_Open = 4153,
	/** AudioDecoder_DRAMSizePCMX_in_type and AudioDecoder_DRAMSizePCMX_out_type, (R/W Exchange) @par 
		Gets the audio decoder DDR-DRAM memory size requirements (cacheable and non-cacheable) based on input/output characteristics.@note @li The CachedSize and UncachedSize values should be used to allocate memory in DDR-DRAM.@li The CachedAddress and UncachedAddress can be obtained in the RUA interface by calling ::RUAMalloc. Refer to the em86xx REALmagic User API document for more info.@li Cacheable memory is memory that is only used by the pt110. Any memory that involves DMA transfers (Either PCI master transfers or em86xx internal MBUS/VBUS transfers) as to be non-cacheable. This allows the pt110 to access data without flushing/reloading its cache and allows better performance. */
	RMAudioDecoderPropertyID_DRAMSizePCMX = 4154,
	/** AudioDecoder_OpenPCMX_type, (W) @par 
		Sets the audio decoder Profile. The profile consist in defining the maximum number of resources (Memory, Number of channels...) the audio decoder will use.@note @li The CachedSize and UncachedSize values can be obtained using the ::RMAudioDecoderPropertyID_DRAMSize exchange properties. The application has to provide these values since it is solely responsible for the DDR-DRAM memory allocation in each DRAM controller.@li The CachedAddress and UncachedAddress can be obtained in the RUA interface by calling RUAMalloc. Refer to the em86xx REALmagic User API document for more info.@li In order to release the resources or change the decoder profile, use the ::RMAudioDecoderPropertyID_Close. You cannot free the memory used by the decoder before calling the ::RMAudioDecoderPropertyID_Close property. */
	RMAudioDecoderPropertyID_OpenPCMX = 4155,
	/** ::RMuint32, (W) @par 
		Free resources (DRAM buffers...) allocated during previous call to ::RMAudioDecoderPropertyID_Open.@note @li The application should call the close property after using the decoder or before next call to ::RMAudioDecoderPropertyID_Open (When changing profile for instance). */
	RMAudioDecoderPropertyID_Close = 4156,
	/** ::RMuint32, (W) @par 
		pcmx mix */
	RMAudioDecoderPropertyID_PCMXMix = 4157,
	/** AudioDecoder_Command_enum, (W) @par 
		Set the Audio decoder playback mode (Play, pause or stop).@note @li This property should be called only once the DSP microcode has been loaded using the ::RMAudioEnginePropertyID_MicrocodeVersion property.@li The init command is used to set the microcode in stop mode. The stop mode is mode where the audio codec is already know and must therefore be selected prior to the init command.@li Use the ::RMAudioDecoderPropertyID_State to wait for the command command completion.@li The audio codec can be selected only in stop mode and before the init command. */
	RMAudioDecoderPropertyID_Command = 4158,
	/** AudioDecoder_State_enum, (R) @par 
		State machine of the Audio decoder */
	RMAudioDecoderPropertyID_State = 4159,
	/** AudioDecoder_Codec_enum, (R/W) @par 
		Select the audio codec (Currently supported codecs: PCM, MPEG1 L1/2/3 or AC3).@note @li The audio codec can be selected only in stop mode or before the init command. */
	RMAudioDecoderPropertyID_Codec = 4160,
	/** ::RMuint32, (W) @par 
		bts threshold for playback (1 = 1k byts), 0 = flush bts. */
	RMAudioDecoderPropertyID_AudioBtsThreshold = 4161,
	/** AudioDecoder_PCMXParameters_type, (W) @par 
		Enum Default; */
	RMAudioDecoderPropertyID_PCMXParameters = 4162,
	/** AudioDecoder_AACParameters_type, (W) @par 
		Enum Default; */
	RMAudioDecoderPropertyID_AACParameters = 4163,
	/** AudioDecoder_DVDAParameters_type, (W) @par 
		Enum Default; */
	RMAudioDecoderPropertyID_DVDAParameters = 4482,
	/** AudioDecoder_TToneParameters_type, (W) @par 
		Enum Default; */
	RMAudioDecoderPropertyID_TToneParameters = 4603,
	/** AudioDecoder_BSACParameters_type, (W) @par 
		Enum Default; */
	RMAudioDecoderPropertyID_BSACParameters = 4481,
	/** AudioDecoder_Ac3Parameters_type, (W) @par 
		Enum Default; */
	RMAudioDecoderPropertyID_Ac3Parameters = 4164,
	/** AudioDecoder_DtsParameters_type, (W) @par 
		Enum Default; */
	RMAudioDecoderPropertyID_DtsParameters = 4165,
	/** AudioDecoder_LpcmVobParameters_type, (W) @par 
		Enum Default; */
	RMAudioDecoderPropertyID_LpcmVobParameters = 4166,
	/** AudioDecoder_LpcmAobParameters_type, (W) @par 
		Enum Default; */
	RMAudioDecoderPropertyID_LpcmAobParameters = 4167,
	/** AudioDecoder_PcmCdaParameters_type, (W) @par 
		Enum Default; */
	RMAudioDecoderPropertyID_PcmCdaParameters = 4168,
	/** AudioDecoder_LpcmBDParameters_type, (W) @par 
		Enum Default; */
	RMAudioDecoderPropertyID_LpcmBDParameters = 4169,
	/** AudioDecoder_MpegParameters_type, (W) @par 
		Enum Default; */
	RMAudioDecoderPropertyID_MpegParameters = 4170,
	/** AudioDecoder_WMAParameters_type, (W) @par 
		Enum Default; */
	RMAudioDecoderPropertyID_WMAParameters = 4171,
	/** ::RMuint32, (R) @par 
		Enum Default; */
	RMAudioDecoderPropertyID_CurrentPTS = 6143,
	/** ::RMuint32, (R) @par 
		Enum Default; */
	RMAudioDecoderPropertyID_Overlay = 1066,
	/** ::RMuint32, (R) @par 
		Enum Default; */
	RMAudioDecoderPropertyID_Skip = 4172,
	/** ::RMuint32, (W) @par 
		param: PTS delay */
	RMAudioDecoderPropertyID_PreFillBuffer = 4173,
	/** AudioDecoder_MixerWeight_type, (W) @par 
		Audio Decoder Mixing Weights */
	RMAudioDecoderPropertyID_MixerWeight = 4174,
	/** AudioDecoder_DRAMSizeX_in_type and AudioDecoder_DRAMSizeX_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMAudioDecoderPropertyID_DRAMSizeX = 4175,
	/** AudioDecoder_OpenX_type, (W) @par 
		Enum Default; */
	RMAudioDecoderPropertyID_OpenX = 4176,
	/** ::RMuint32, (R) @par 
		gbus address of bitstream fifo container. */
	RMAudioDecoderPropertyID_BtsFIFO = 4177,
	/** AudioDecoder_SynchroniseAudioWithDisplayPTS_type, (W) @par 
		Enum Default; */
	RMAudioDecoderPropertyID_SynchroniseAudioWithDisplayPTS = 6145,
	/** AudioDecoder_AudioPlayTime_type, (W) @par 
		Enum Default; */
	RMAudioDecoderPropertyID_AudioPlayTime = 6187,
	/** AudioDecoder_AudioBDJPanning_type, (W) @par 
		BDJ panning parameter in (x, y) coordinate. */
	RMAudioDecoderPropertyID_AudioBDJPanning = 6199,
	/** AudioDecoder_AudioBDJGain_type, (W) @par 
		BDJ gain parameter [-51dB to +12dB], Note:-51=-OO, -50=-50dB and so on. */
	RMAudioDecoderPropertyID_AudioBDJGain = 6200,
	/** AudioDecoder_AudioControlPCMX_type, (R/W) @par 
		PCMX decoder control (0:nothing change, 1: to flush bts fifo, 2:EOS Signal). */
	RMAudioDecoderPropertyID_AudioControlPCMX = 6207,
	/** ::RMbool, (R/W) @par 
		To enable/disable audio synchronization with STC. */
	RMAudioDecoderPropertyID_SyncSTCEnable = 4593,
};

/** This module provides access to the Audio decoder settings */
enum RMAudioCapturePropertyID {
	/** AudioCapture_DRAMSize_in_type and AudioCapture_DRAMSize_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMAudioCapturePropertyID_DRAMSize = 4179,
	/** AudioCapture_Open_type, (W) @par 
		Sets the audio capture Profile. The profile consist in defining the maximum number of resources (Memory, ...) the audio capture module will use.@note @li The CachedSize and UncachedSize values can be obtained using the ::RMAudioCapturePropertyID_DRAMSize exchange properties. The application has to provide these values since it is solely responsible for the DDR-DRAM memory allocation in each DRAM controller.@li The CachedAddress and UncachedAddress can be obtained in the RUA interface by calling RUAMalloc. Refer to the em86xx REALmagic User API document for more info.@li In order to release the resources or change the capture profile, use the ::RMAudioCapturePropertyID_Close. You cannot free the memory used by the decoder before calling the ::RMAudioCapturePropertyID_Close property. */
	RMAudioCapturePropertyID_Open = 4180,
	/** ::RMuint32, (W) @par 
		Free resources (DRAM buffers...) allocated during previous call to ::RMAudioCapturePropertyID_Open.@note @li The application should call the close property after using the decoder or before next call to ::RMAudioCapturePropertyID_Open (When changing profile for instance). */
	RMAudioCapturePropertyID_Close = 4181,
	/** AudioCapture_Capture_enum, (W) @par 
		 */
	RMAudioCapturePropertyID_Capture = 4182,
	/** AudioCapture_Source_enum, (W) @par 
		 */
	RMAudioCapturePropertyID_Source = 4183,
	/** AudioCapture_AudioStd_enum, (R) @par 
		Select the audio codec (Currently supported codecs: PCM, MPEG1 L1/2/3 or AC3).@note @li The audio codec can be selected only in stop mode or before the init command. */
	RMAudioCapturePropertyID_AudioStd = 4184,
	/** AudioCapture_SpdifDataType_enum, (W) @par 
		Set the capture mode */
	RMAudioCapturePropertyID_SpdifDataType = 4185,
	/** ::RMuint32, (W) @par 
		Set the bitstream number to be captured */
	RMAudioCapturePropertyID_SpdifBitstreamNumber = 4580,
};

/** This module provides access to the Voip codec settings */
enum RMVoipCodecPropertyID {
	/** VoipCodec_DRAMSize_in_type and VoipCodec_DRAMSize_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMVoipCodecPropertyID_DRAMSize = 4508,
	/** VoipCodec_Open_type, (W) @par 
		Sets the voip codec Profile. The profile consist in defining the maximum number of resources (Memory, ...) the voip codec module will use.@note @li The CachedSize and UncachedSize values can be obtained using the ::RMVoipCodecPropertyID_DRAMSize exchange properties. The application has to provide these values since it is solely responsible for the DDR-DRAM memory allocation in each DRAM controller.@li The CachedAddress and UncachedAddress can be obtained in the RUA interface by calling RUAMalloc. Refer to the em86xx REALmagic User API document for more info.@li In order to release the resources or change the capture profile, use the ::RMVoipCodecPropertyID_Close. You cannot free the memory used by the decoder before calling the ::RMVoipCodecPropertyID_Close property. */
	RMVoipCodecPropertyID_Open = 4509,
	/** ::RMuint32, (W) @par 
		Free resources (DRAM buffers...) allocated during previous call to ::RMVoipCodecPropertyID_Open.@note @li The application should call the close property after using the decoder or before next call to ::RMVoipCodecPropertyID_Open (When changing profile for instance). */
	RMVoipCodecPropertyID_Close = 4510,
	/** VoipCodec_Encoder_Codec_enum, (R/W) @par 
		Select the voip codec (Currently supported codecs: g711 Linear/alaw/ulaw, g723.1 , g726, g728, g729).@note @li The voip codec can be selected only in stop mode or before the init command. */
	RMVoipCodecPropertyID_Encoder_Codec = 4511,
	/** VoipCodec_Decoder_Codec_enum, (R/W) @par 
		Select the voip codec (Currently supported codecs: g711 Linear/alaw/ulaw, g723.1 , g726, g728, g729).@note @li The voip codec can be selected only in stop mode or before the init command. */
	RMVoipCodecPropertyID_Decoder_Codec = 4512,
	/** VoipCodec_Command_enum, (W) @par 
		 */
	RMVoipCodecPropertyID_Command = 4513,
	/** VoipCodec_Capture_enum, (R) @par 
		Get the serial in interrupt status */
	RMVoipCodecPropertyID_Capture = 4514,
	/** VoipCodec_Playback_enum, (R) @par 
		Get the serial out interrupt status */
	RMVoipCodecPropertyID_Playback = 4515,
	/** VoipCodec_CoderState_enum, (R) @par 
		State machine of the Voip Encoder */
	RMVoipCodecPropertyID_CoderState = 4516,
	/** VoipCodec_CoderVadState_enum, (R) @par 
		State machine of the Voip Encoder voice activity detector */
	RMVoipCodecPropertyID_CoderVadState = 4517,
	/** VoipCodec_DecoderState_enum, (R) @par 
		State machine of the Voip Decoder */
	RMVoipCodecPropertyID_DecoderState = 4518,
	/** VoipCodec_ToneGeneratorState_enum, (R) @par 
		State machine of the Voip Tone Generator */
	RMVoipCodecPropertyID_ToneGeneratorState = 4519,
	/** VoipCodec_CidGeneratorState_enum, (R) @par 
		State machine of the Voip Caller id Generator */
	RMVoipCodecPropertyID_CidGeneratorState = 4520,
	/** VoipCodec_AecState_enum, (R) @par 
		State machine of the Voip Echo cancellation algorithm */
	RMVoipCodecPropertyID_AecState = 4521,
	/** VoipCodec_DTMFState_enum, (R) @par 
		State machine of the Voip DTMF algorithm */
	RMVoipCodecPropertyID_DTMFState = 4522,
	/** ::RMbool, (R) @par 
		Returns true if the DTMF fifo is empty */
	RMVoipCodecPropertyID_DTMF_Empty = 4523,
	/** ::RMint8, (R) @par 
		Returns one DTMF character from the DTMF fifo */
	RMVoipCodecPropertyID_DTMF_Ascii = 4524,
	/** VoipCodec_AecTddState_enum, (R) @par 
		State machine of the Aec tone disabler detector algorithm */
	RMVoipCodecPropertyID_AecTddState = 4525,
	/** VoipCodec_NlpCngState_enum, (R) @par 
		State machine of the Voip Non linear processing and Comfort noise generation algorithm */
	RMVoipCodecPropertyID_NlpCngState = 4526,
	/** ::struct VoipCodec_Tone, (R/W) @par 
		Parameters of the tone to be generated */
	RMVoipCodecPropertyID_Tone_parameters = 4527,
	/** ::struct VoipCodec_Cid, (R/W) @par 
		Parameters of the caller-id to be generated */
	RMVoipCodecPropertyID_Cid_parameters = 4528,
	/** ::RMuint32, (R/W) @par 
		Digital scaling to be applied to the captured data */
	RMVoipCodecPropertyID_Recording_volume = 4529,
	/** ::RMuint32, (R/W) @par 
		Digital scaling to be applied to the decoded samples */
	RMVoipCodecPropertyID_Playback_volume = 4530,
	/** VoipCodec_WriteChunk_in_type and VoipCodec_WriteChunk_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMVoipCodecPropertyID_WriteChunk = 4531,
	/** VoipCodec_ReadChunk_in_type and VoipCodec_ReadChunk_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMVoipCodecPropertyID_ReadChunk = 4532,
};

/** Module Enum Default */
enum RMCRCDecoderPropertyID {
	/** CRCDecoder_DRAMSize_in_type and CRCDecoder_DRAMSize_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMCRCDecoderPropertyID_DRAMSize = 4186,
	/** CRCDecoder_Open_type, (W) @par 
		Enum Default; */
	RMCRCDecoderPropertyID_Open = 4187,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMCRCDecoderPropertyID_Close = 4188,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMCRCDecoderPropertyID_Reset = 4189,
	/** ::RMbool, (R/W) @par 
		Enum Default; */
	RMCRCDecoderPropertyID_EndOfStream = 4190,
	/** ::RMuint32, (R) @par 
		Enum Default; */
	RMCRCDecoderPropertyID_Sum = 4191,
	/** CRCDecoder_Command_enum, (W) @par 
		Enum Default; */
	RMCRCDecoderPropertyID_Command = 4192,
	/** CRCDecoder_State_enum, (R) @par 
		Enum Default; */
	RMCRCDecoderPropertyID_State = 4193,
};

/** Module Enum Default */
enum RMXCRCDecoderPropertyID {
	/** XCRCDecoder_DRAMSize_in_type and XCRCDecoder_DRAMSize_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMXCRCDecoderPropertyID_DRAMSize = 4194,
	/** XCRCDecoder_Open_type, (W) @par 
		Enum Default; */
	RMXCRCDecoderPropertyID_Open = 4195,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMXCRCDecoderPropertyID_Close = 4196,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMXCRCDecoderPropertyID_Reset = 4197,
	/** ::RMbool, (R/W) @par 
		Enum Default; */
	RMXCRCDecoderPropertyID_EndOfStream = 4198,
	/** ::RMuint32, (R) @par 
		Enum Default; */
	RMXCRCDecoderPropertyID_Sum = 4199,
	/** XCRCDecoder_Command_enum, (W) @par 
		Enum Default; */
	RMXCRCDecoderPropertyID_Command = 4200,
	/** XCRCDecoder_State_enum, (R) @par 
		Enum Default; */
	RMXCRCDecoderPropertyID_State = 4201,
};

/** Module Enum Default */
enum RMStreamCapturePropertyID {
	/** StreamCapture_DRAMSize_in_type and StreamCapture_DRAMSize_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMStreamCapturePropertyID_DRAMSize = 4202,
	/** StreamCapture_Open_type, (W) @par 
		Enum Default; */
	RMStreamCapturePropertyID_Open = 4203,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMStreamCapturePropertyID_Close = 4204,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMStreamCapturePropertyID_Reset = 4205,
	/** ::RMbool, (R/W) @par 
		Enum Default; */
	RMStreamCapturePropertyID_EndOfStream = 4206,
	/** StreamCapture_Command_enum, (W) @par 
		Enum Default; */
	RMStreamCapturePropertyID_Command = 4207,
	/** StreamCapture_State_enum, (R) @par 
		Enum Default; */
	RMStreamCapturePropertyID_State = 4208,
};

/** Module Enum Default */
enum RMRawDataTransferPropertyID {
	/** RawDataTransfer_DRAMSize_in_type and RawDataTransfer_DRAMSize_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMRawDataTransferPropertyID_DRAMSize = 4209,
	/** RawDataTransfer_Open_type, (W) @par 
		Enum Default; */
	RMRawDataTransferPropertyID_Open = 4210,
	/** RawDataTransfer_ProgramLinearTransfer_type, (W) @par 
		Enum Default; */
	RMRawDataTransferPropertyID_ProgramLinearTransfer = 4211,
	/** RawDataTransfer_ProgramRectangleTransfer_type, (W) @par 
		Enum Default; */
	RMRawDataTransferPropertyID_ProgramRectangleTransfer = 4212,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMRawDataTransferPropertyID_Close = 4213,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMRawDataTransferPropertyID_Reset = 4214,
};

/** Module Enum Default */
enum RMI2CPropertyID {
	/** I2C_DeviceParams_type, (R/W) @par 
		Obsolete, use DeviceParameter / QueryDeviceParameter instead! */
	RMI2CPropertyID_DeviceParams = 6146,
	/** ::struct EMhwlibI2CDeviceParameter, (W) @par 
		Enum Default; */
	RMI2CPropertyID_DeviceParameter = 6205,
	/** I2C_QueryDeviceParameter_in_type and I2C_QueryDeviceParameter_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMI2CPropertyID_QueryDeviceParameter = 6206,
	/** I2C_WriteRMuint8_type, (W) @par 
		Enum Default; */
	RMI2CPropertyID_WriteRMuint8 = 6147,
	/** I2C_QueryRMuint8_in_type and I2C_QueryRMuint8_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMI2CPropertyID_QueryRMuint8 = 6148,
	/** ::RMuint8, (R/W) @par 
		Enum Default; */
	RMI2CPropertyID_RMuint8Access_NoSubAddress = 6149,
	/** I2C_WriteData_type, (W) @par 
		Enum Default; */
	RMI2CPropertyID_WriteData = 6150,
	/** I2C_QueryData_in_type and I2C_QueryData_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMI2CPropertyID_QueryData = 6151,
	/** I2C_SelectSegment_type, (W) @par 
		Enum Default; */
	RMI2CPropertyID_SelectSegment = 6152,
};

/** Module Enum Default */
enum RMGFXEnginePropertyID {
	/** GFXEngine_DRAMSize_in_type and GFXEngine_DRAMSize_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMGFXEnginePropertyID_DRAMSize = 4215,
	/** GFXEngine_Open_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_Open = 4216,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_Close = 4217,
	/** ::struct GFXEngineCommand, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_CommandBuffer = 4463,
	/** GFXEngine_Correction_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_Correction = 4218,
	/** GFXEngine_ColorFormat_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_ColorFormat = 4219,
	/** GFXEngine_AlphaFormat_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_AlphaFormat = 4220,
	/** GFXEngine_Surface_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_Surface = 4221,
	/** GFXEngine_BCS_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_BCS = 4222,
	/** GFXEngine_FillRectangle_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_FillRectangle = 4223,
	/** GFXEngine_BlendRectangles_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_BlendRectangles = 4224,
	/** GFXEngine_BlendGradient_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_BlendGradient = 4225,
	/** GFXEngine_RasterBlendGradient_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_RasterBlendGradient = 4466,
	/** GFXEngine_RasterBlendRectangles_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_RasterBlendRectangles = 4465,
	/** ::struct GFXEngine_FillReplaceGradient_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_ReplaceGradient = 4226,
	/** ::struct GFXEngine_FillReplaceGradient_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_FillGradient = 4227,
	/** GFXEngine_SingleColorBlendRectangles_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_SingleColorBlendRectangles = 4228,
	/** GFXEngine_BlendAndScaleRectangles_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_BlendAndScaleRectangles = 4229,
	/** GFXEngine_Blend_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_Blend = 4230,
	/** ::struct GFXEngine_MoveReplace_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_Move = 4231,
	/** ::struct GFXEngine_MoveReplace_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_Replace = 4232,
	/** ::struct GFXEngine_MoveReplaceRectangle_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_MoveRectangle = 4233,
	/** ::struct GFXEngine_MoveReplaceRectangle_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_ReplaceRectangle = 4234,
	/** ::struct GFXEngine_MoveReplaceScaleRectangle_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_ReplaceAndScaleRectangle = 4235,
	/** ::struct GFXEngine_MoveReplaceScaleRectangle_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_MoveAndScaleRectangle = 4236,
	/** GFXEngine_DisplayPicture_type, (W) @par 
		insert a picture inside the surface picture's fifo */
	RMGFXEnginePropertyID_DisplayPicture = 4237,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_WaitForPicture = 4238,
	/** GFXEngine_LinearGradientSurface_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_LinearGradientSurface = 4239,
	/** GFXEngine_RadialGradientSurface_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_RadialGradientSurface = 4240,
	/** GFXEngine_Palette_1BPP_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_Palette_1BPP = 4241,
	/** GFXEngine_Palette_2BPP_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_Palette_2BPP = 4242,
	/** GFXEngine_Palette_4BPP_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_Palette_4BPP = 4243,
	/** GFXEngine_Palette_8BPP_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_Palette_8BPP = 4244,
	/** GFXEngine_KeyColor_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_KeyColor = 4245,
	/** GFXEngine_FieldType_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_FieldType = 4246,
	/** GFXEngine_NonlinearScale_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_NonlinearScale = 4247,
	/** GFXEngine_GlyphMask_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_GlyphMask = 4248,
	/** GFXEngine_GlyphScaleMatrix_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_GlyphScaleMatrix = 4249,
	/** GFXEngine_LPFThresholds_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_LPFThresholds = 4250,
	/** GFXEngine_GlyphOutputSize_in_type and GFXEngine_GlyphOutputSize_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMGFXEnginePropertyID_GlyphOutputSize = 4251,
	/** ::void, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_FlushCommandQueue = 4252,
	/** ::RMbool, (R) @par 
		Enum Default; */
	RMGFXEnginePropertyID_CommandQueueEmpty = 4253,
	/** GFXEngine_PictureBufferAddress_type, (W) @par 
		insert a picture inside the surface picture's fifo */
	RMGFXEnginePropertyID_PictureBufferAddress = 4254,
	/** ::RMbool, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_EnableAlphaFading = 4255,
	/** ::RMbool, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_HoldCommandQueue = 4256,
	/** ::void, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_ReleaseCommandQueue = 4257,
	/** GFXEngine_AlphaPalette_type, (W) @par 
		Enum Default; */
	RMGFXEnginePropertyID_AlphaPalette = 4258,
};

/** Module Enum Default */
enum RMMMPropertyID {
	/** MM_Malloc_in_type and MM_Malloc_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMMMPropertyID_Malloc = 1067,
	/** ::void *, (W) @par 
		Enum Default; */
	RMMMPropertyID_Free = 1068,
	/** ::MMBlockArray, (R) @par 
		Enum Default; */
	RMMMPropertyID_DumpMallocedBlocks = 1069,
	/** MM_AreaSize_in_type and MM_AreaSize_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMMMPropertyID_AreaSize = 1070,
	/** MM_MemoryArea_type, (R) @par 
		Enum Default; */
	RMMMPropertyID_MemoryArea = 4259,
	/** MM_TopRemovableArea_type, (R) @par 
		Enum Default; */
	RMMMPropertyID_TopRemovableArea = 4260,
	/** ::RMuint32, (R) @par 
		Enum Default; */
	RMMMPropertyID_MicrocodeROMFSStart = 1071,
	/** ::void, (W) @par 
		Enum Default; */
	RMMMPropertyID_RemoveTopRemovableArea = 4261,
	/** MM_Stats_type, (R) @par 
		Enum Default; */
	RMMMPropertyID_Stats = 4262,
};

/** Module Enum Default */
enum RMSpuDecoderPropertyID {
	/** SpuDecoder_DRAMSize_in_type and SpuDecoder_DRAMSize_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMSpuDecoderPropertyID_DRAMSize = 4263,
	/** SpuDecoder_Open_type, (W) @par 
		Enum Default; */
	RMSpuDecoderPropertyID_Open = 4264,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMSpuDecoderPropertyID_Close = 4265,
	/** SpuDecoder_Command_enum, (W) @par 
		Enum Default; */
	RMSpuDecoderPropertyID_Command = 4266,
	/** SpuDecoder_State_enum, (R) @par 
		Enum Default; */
	RMSpuDecoderPropertyID_State = 4267,
	/** ::RMuint32, (W) @par 
		sets the scaler associated to the spu decoder */
	RMSpuDecoderPropertyID_Scaler = 6153,
	/** SpuDecoder_Palette_type, (W) @par 
		fill all 16*4 PGC_SP_PLT entries into LUT, with 0,Y,Cr,Cb) */
	RMSpuDecoderPropertyID_Palette = 6154,
	/** SpuDecoder_StreamType_enum, (W) @par 
		Description of the current sub picture stream number from PGC_SPST_CTL */
	RMSpuDecoderPropertyID_StreamType = 6155,
	/** ::RMbool, (R/W) @par 
		To turn the Sub Picture display on (TRUE) or off (FALSE). The GetProperty returns the actual state, e.g. it returns always TRUE if the sub picture stream is force-on. */
	RMSpuDecoderPropertyID_SubpictureOn = 6156,
	/** SpuDecoder_Hilight_type, (R/W) @par 
		 */
	RMSpuDecoderPropertyID_Hilight = 6157,
	/** SpuDecoder_BDRLECommand_type, (R/W) @par 
		 */
	RMSpuDecoderPropertyID_BDRLECommand = 6158,
	/** SpuDecoder_BDRLEBatchCommand_type, (W) @par 
		 */
	RMSpuDecoderPropertyID_BDRLEBatchCommand = 6190,
	/** ::RMuint32, (R) @par 
		returns the address of the previously allocated and filled struct vsync_surface */
	RMSpuDecoderPropertyID_VSyncSurface = 6160,
	/** SpuDecoder_DRAMSizeX_in_type and SpuDecoder_DRAMSizeX_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMSpuDecoderPropertyID_DRAMSizeX = 4268,
	/** SpuDecoder_OpenX_type, (W) @par 
		Enum Default; */
	RMSpuDecoderPropertyID_OpenX = 4269,
	/** SpuDecoder_DecoderDataMemory_in_type and SpuDecoder_DecoderDataMemory_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMSpuDecoderPropertyID_DecoderDataMemory = 4270,
	/** ::enum EMhwlibVideoCodec, (R/W) @par 
		 */
	RMSpuDecoderPropertyID_CodecX = 4271,
	/** ::RMuint32, (R) @par 
		gbus address of bitstream fifo container. */
	RMSpuDecoderPropertyID_BtsFIFO = 4272,
	/** ::RMuint32, (R) @par 
		Enum Default; */
	RMSpuDecoderPropertyID_Error = 4273,
};

/** Module Enum Default */
enum RMPictureTransformPropertyID {
	/** PictureTransform_Open_type, (W) @par 
		Enum Default; */
	RMPictureTransformPropertyID_Open = 4562,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMPictureTransformPropertyID_Close = 4563,
	/** ::enum EMhwlibPictureOrientation, (W) @par 
		Enum Default; */
	RMPictureTransformPropertyID_OrientationMode = 4571,
	/** PictureTransform_Command_enum, (W) @par 
		Enum Default; */
	RMPictureTransformPropertyID_Command = 4565,
	/** PictureTransform_State_enum, (R) @par 
		Enum Default; */
	RMPictureTransformPropertyID_State = 4566,
	/** ::RMstatus, (R) @par 
		Enum Default; */
	RMPictureTransformPropertyID_CommandStatus = 4567,
	/** PictureTransform_DecoderMemory_in_type and PictureTransform_DecoderMemory_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMPictureTransformPropertyID_DecoderMemory = 4607,
};

/** Module Enum Default */
enum RMClosedCaptionDecoderPropertyID {
	/** ClosedCaptionDecoder_DRAMSize_type, (R) @par 
		Enum Default; */
	RMClosedCaptionDecoderPropertyID_DRAMSize = 4274,
	/** ClosedCaptionDecoder_Open_type, (W) @par 
		Enum Default; */
	RMClosedCaptionDecoderPropertyID_Open = 1072,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMClosedCaptionDecoderPropertyID_Close = 1073,
	/** ClosedCaptionDecoder_FeedDecoder_type, (W) @par 
		Enum Default; */
	RMClosedCaptionDecoderPropertyID_FeedDecoder = 1074,
};

/** Module Enum Default */
enum RMRTCPropertyID {
	/** ::RMuint32, (R/W) @par 
		Enum Default; */
	RMRTCPropertyID_FreeEventID = 4275,
	/** RTC_Alarm_type, (W) @par 
		Enum Default; */
	RMRTCPropertyID_Alarm = 4276,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMRTCPropertyID_CancelAlarm = 4277,
};

/** Module Enum Default */
enum RMCipherPropertyID {
	/** ::RMAESKey, (W) @par 
		 */
	RMCipherPropertyID_AES_128_KeySetup = 4278,
	/** ::RMAESKey, (W) @par 
		 */
	RMCipherPropertyID_AES_128_IVSetup = 4279,
	/** ::struct RMcipherBuffer, (W) @par 
		 */
	RMCipherPropertyID_AES_128_ECB_Encrypt = 4280,
	/** ::struct RMcipherBuffer, (W) @par 
		 */
	RMCipherPropertyID_AES_128_ECB_Decrypt = 4281,
	/** ::struct RMcipherBuffer, (W) @par 
		 */
	RMCipherPropertyID_AES_128_CTR_Cipher = 4282,
	/** ::RMDESKey, (W) @par 
		 */
	RMCipherPropertyID_DES_ECB_KeySetup = 4283,
	/** ::struct RMcipherBuffer, (W) @par 
		 */
	RMCipherPropertyID_DES_ECB_Encrypt = 4284,
	/** ::struct RMcipherBuffer, (W) @par 
		 */
	RMCipherPropertyID_DES_ECB_Decrypt = 4285,
	/** Cipher_RC4_KeySetup_type, (W) @par 
		 */
	RMCipherPropertyID_RC4_KeySetup = 4286,
	/** ::struct RMcipherBuffer, (W) @par 
		 */
	RMCipherPropertyID_RC4_Cipher = 4287,
	/** ::RMuint32, (R) @par 
		 */
	RMCipherPropertyID_RC4_KeySetup_Completion = 4288,
	/** ::RMuint32, (R) @par 
		 */
	RMCipherPropertyID_Hardware_Cipher_Completion = 4289,
	/** ::RMAESKey, (W) @par 
		 */
	RMCipherPropertyID_AES_128_KeySetupLE = 4290,
	/** ::RMAESKey, (W) @par 
		 */
	RMCipherPropertyID_AES_128_IVSetupLE = 4291,
	/** ::RMuint32, (R) @par 
		 */
	RMCipherPropertyID_RC4_BytesRemain = 4292,
	/** ::RMuint32, (W) @par 
		 */
	RMCipherPropertyID_Open = 4293,
	/** ::RMuint32, (W) @par 
		 */
	RMCipherPropertyID_Close = 4294,
};

/** Module Enum Default */
enum RMSTCPropertyID {
	/** STC_Open_type, (W) @par 
		Set the timer Ids and master type. */
	RMSTCPropertyID_Open = 4295,
	/** ::RMuint32, (W) @par 
		Notify the STC module of the audio engine module ID */
	RMSTCPropertyID_AudioEngineModuleID = 4296,
	/** ::RMuint32, (W) @par 
		Notify the STC module of the pixel clock master video output module ID */
	RMSTCPropertyID_VideoOutMasterModuleID = 4297,
	/** ::RMuint32, (W) @par 
		 */
	RMSTCPropertyID_Close = 4298,
	/** ::RMuint32, (R/W) @par 
		The new time_resolution is set. The stc time is scaled and set according to the time resolution. */
	RMSTCPropertyID_StcTimeResolution = 4299,
	/** ::RMuint32, (R/W) @par 
		The new time resolution is set. The video time and offset are scaled and set according to the time resolution. */
	RMSTCPropertyID_VideoTimeResolution = 4300,
	/** ::RMuint32, (R/W) @par 
		The new time resolution is set. The audio time and offset are scaled and set according to the time resolution. */
	RMSTCPropertyID_AudioTimeResolution = 4301,
	/** STC_VideoOffset_type, (W) @par 
		The new offset is set. The video time is set according to the offset. */
	RMSTCPropertyID_VideoOffset = 4302,
	/** STC_AudioOffset_type, (W) @par 
		The new offset is set. The video time is set according to the offset. */
	RMSTCPropertyID_AudioOffset = 4303,
	/** STC_Time_type, (W) @par 
		The time is set for all dependent timers - stc, video and audio timers, according to their corresponding time resolution and offset. */
	RMSTCPropertyID_Time = 4304,
	/** STC_TimeInfo_in_type and STC_TimeInfo_out_type, (R/W Exchange) @par 
		It returns the time for the master timer. */
	RMSTCPropertyID_TimeInfo = 4305,
	/** ::void, (W) @par 
		 */
	RMSTCPropertyID_Play = 4306,
	/** ::void, (W) @par 
		 */
	RMSTCPropertyID_Stop = 4307,
	/** STC_Speed_type, (R/W) @par 
		The time resolution is multiplied by nominator and divided by denominator and set for every timer - stc, video, audio. */
	RMSTCPropertyID_Speed = 4308,
	/** STC_Discontinuity_type, (W) @par 
		 */
	RMSTCPropertyID_Discontinuity = 4309,
	/** ::RMuint32, (R/W) @par 
		 */
	RMSTCPropertyID_VCXOModuleID = 1107,
	/** STC_StcInfo_type, (R) @par 
		 */
	RMSTCPropertyID_StcInfo = 4310,
	/** ::RMuint64, (R/W) @par 
		Direct access to the timer value. Emhwlib doesn't make any time_resolution or offset conversion. */
	RMSTCPropertyID_StcTimeDirectAccess = 4599,
	/** ::RMuint64, (R/W) @par 
		Direct access to the timer value. Emhwlib doesn't make any time_resolution or offset conversion. */
	RMSTCPropertyID_VideoTimeDirectAccess = 4600,
	/** ::RMuint64, (R/W) @par 
		Direct access to the timer value. Emhwlib doesn't make any time_resolution or offset conversion. */
	RMSTCPropertyID_AudioTimeDirectAccess = 4601,
};

/** Module Enum Default */
enum RMPLLPropertyID {
	/** PLL_PLL_type, (W) @par 
		Enum Default; */
	RMPLLPropertyID_PLL = 4311,
	/** PLL_PLLUsage_type, (W) @par 
		update internal values without changing PLL registers */
	RMPLLPropertyID_PLLUsage = 4312,
	/** PLL_QueryPLL_in_type and PLL_QueryPLL_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMPLLPropertyID_QueryPLL = 4313,
	/** PLL_QueryPLLNominal_in_type and PLL_QueryPLLNominal_out_type, (R/W Exchange) @par 
		returns the last frequencies that were specified */
	RMPLLPropertyID_QueryPLLNominal = 4314,
	/** PLL_CD_type, (W) @par 
		Enum Default; */
	RMPLLPropertyID_CD = 4315,
	/** PLL_CDUsage_type, (W) @par 
		update internal values without changing PLL registers */
	RMPLLPropertyID_CDUsage = 4316,
	/** PLL_QueryCD_in_type and PLL_QueryCD_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMPLLPropertyID_QueryCD = 4317,
	/** PLL_QueryCDNominal_in_type and PLL_QueryCDNominal_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMPLLPropertyID_QueryCDNominal = 4318,
	/** PLL_PLLSource_type, (W) @par 
		Enum Default; */
	RMPLLPropertyID_PLLSource = 4319,
	/** PLL_QueryPLLSource_in_type and PLL_QueryPLLSource_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMPLLPropertyID_QueryPLLSource = 4320,
	/** PLL_SourceFrequency_type, (W) @par 
		Enum Default; */
	RMPLLPropertyID_SourceFrequency = 4321,
	/** PLL_QuerySourceFrequency_in_type and PLL_QuerySourceFrequency_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMPLLPropertyID_QuerySourceFrequency = 4322,
	/** PLL_RouteClockFromPLL_type, (W) @par 
		Enum Default; */
	RMPLLPropertyID_RouteClockFromPLL = 4323,
	/** PLL_RouteClockFromSource_type, (W) @par 
		Enum Default; */
	RMPLLPropertyID_RouteClockFromSource = 4324,
	/** PLL_QueryClockRoute_in_type and PLL_QueryClockRoute_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMPLLPropertyID_QueryClockRoute = 4325,
	/** PLL_Frequency_type, (W) @par 
		Enum Default; */
	RMPLLPropertyID_Frequency = 4326,
	/** PLL_QueryFrequency_in_type and PLL_QueryFrequency_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMPLLPropertyID_QueryFrequency = 4327,
	/** PLL_CounterSource_type, (W) @par 
		Enum Default; */
	RMPLLPropertyID_CounterSource = 4328,
	/** PLL_QueryCounterSource_in_type and PLL_QueryCounterSource_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMPLLPropertyID_QueryCounterSource = 4329,
	/** PLL_Counter_type, (W) @par 
		Enum Default; */
	RMPLLPropertyID_Counter = 4330,
	/** PLL_QueryCounter_in_type and PLL_QueryCounter_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMPLLPropertyID_QueryCounter = 4331,
	/** PLL_QueryCounterFrequency_in_type and PLL_QueryCounterFrequency_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMPLLPropertyID_QueryCounterFrequency = 4332,
	/** PLL_BootirqSettings_type, (R) @par 
		Enum Default; */
	RMPLLPropertyID_BootirqSettings = 4333,
};

/** Module Enum Default */
enum RMDemuxCipherPropertyID {
	/** DemuxCipher_DRAMSize_in_type and DemuxCipher_DRAMSize_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDemuxCipherPropertyID_DRAMSize = 4558,
	/** DemuxCipher_Open_type, (W) @par 
		 */
	RMDemuxCipherPropertyID_Open = 4537,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMDemuxCipherPropertyID_Close = 4538,
	/** DemuxCipher_DemuxInterface_type, (R) @par 
		Pointer to the DemuxInterface context */
	RMDemuxCipherPropertyID_DemuxInterface = 4539,
	/** ::RMuint32, (R) @par 
		 */
	RMDemuxCipherPropertyID_AllocateCipherEntry = 4540,
	/** ::RMuint32, (W) @par 
		 */
	RMDemuxCipherPropertyID_FreeCipherEntry = 4541,
	/** DemuxCipher_AESCipherEntry_type, (W) @par 
		 */
	RMDemuxCipherPropertyID_AESCipherEntry = 4542,
	/** DemuxCipher_AllocateKeyEntry_in_type and DemuxCipher_AllocateKeyEntry_out_type, (R/W Exchange) @par 
		 returns a free key_index for the specified cipher  */
	RMDemuxCipherPropertyID_AllocateKeyEntry = 4543,
	/** DemuxCipher_FreeKeyEntry_type, (W) @par 
		 release a key_index for the specified cipher  */
	RMDemuxCipherPropertyID_FreeKeyEntry = 4544,
	/** DemuxCipher_OutbandKeyChange_type, (W) @par 
		change the key index instantaneously  */
	RMDemuxCipherPropertyID_OutbandKeyChange = 4545,
};

/** Module Enum Default */
enum RMDemuxTaskPropertyID {
	/** DemuxTask_DRAMSize_in_type and DemuxTask_DRAMSize_out_type, (R/W Exchange) @par 
		Gets the demux DDR-DRAM memory size requirements (cacheable and non-cacheable) based on input/output characteristics.@note @li The ProtectedSize and UnprotectedSize values should be used to allocate memory in DDR-DRAM.@li The ProtectedAddress and UnprotectedAddress can be obtained in the RUA interface by calling ::RUAMalloc. Refer to the em86xx REALmagic User API document for more info. */
	RMDemuxTaskPropertyID_DRAMSize = 4334,
	/** DemuxTask_Open_type, (W) @par 
		Sets the required resources (Memory ...) for demux.@note @li The ProtectedSize and UnprotectedSize values can be obtained using the ::RMDemuxPropertyID_DRAMSize exchange properties. The application has to provide these values since it is solely responsible for the DDR-DRAM memory allocation in each DRAM controller.@li The ProtectedAddress and UnprotectedAddress can be obtained in the RUA interface by calling RUAMalloc. */
	RMDemuxTaskPropertyID_Open = 4335,
	/** DemuxTask_DRAMSizeX_in_type and DemuxTask_DRAMSizeX_out_type, (R/W Exchange) @par 
		Gets the demux DDR-DRAM memory size requirements (cacheable and non-cacheable) based on input/output characteristics.@note @li The ProtectedSize and UnprotectedSize values should be used to allocate memory in DDR-DRAM.@li The ProtectedAddress and UnprotectedAddress can be obtained in the RUA interface by calling ::RUAMalloc. Refer to the em86xx REALmagic User API document for more info. */
	RMDemuxTaskPropertyID_DRAMSizeX = 4336,
	/** DemuxTask_OpenX_type, (W) @par 
		Sets the required resources (Memory ...) for demux.@note @li The ProtectedSize and UnprotectedSize values can be obtained using the ::RMDemuxPropertyID_DRAMSize exchange properties. The application has to provide these values since it is solely responsible for the DDR-DRAM memory allocation in each DRAM controller.@li The ProtectedAddress and UnprotectedAddress can be obtained in the RUA interface by calling RUAMalloc. */
	RMDemuxTaskPropertyID_OpenX = 4337,
	/** ::RMuint32, (W) @par 
		Free resources (DRAM buffers...) allocated during previous call to ::RMDemuxPropertyID_Open.@note @li The application should call the close property after using the decoder or before next call to ::RMDemuxPropertyID_Open. */
	RMDemuxTaskPropertyID_Close = 4338,
	/** DemuxTask_AvailableResourcesInfo_type, (W) @par 
		 */
	RMDemuxTaskPropertyID_AvailableResourcesInfo = 4339,
	/** DemuxTask_Command_enum, (W) @par 
		 Demux outband command (play, pause, stop).@note @li This property should be called after the microcode is loaded using the ::RMDemuxEnginePropertyID_MicrocodeVersion property.@li Use the RUAWaitForMultipleEvent or ::RMDemuxPropertyID_State to wait for the command completion. */
	RMDemuxTaskPropertyID_Command = 4340,
	/** DemuxTask_State_enum, (R) @par 
		 */
	RMDemuxTaskPropertyID_State = 4341,
	/** DemuxTask_InputParameters_type, (W) @par 
		 */
	RMDemuxTaskPropertyID_InputParameters = 4342,
	/** ::RMuint32, (W) @par 
		Number of bytes to discard between every 188 TS packets  */
	RMDemuxTaskPropertyID_TsSkipBytes = 4343,
	/** ::RMuint32, (R) @par 
		bit mask field specifying the outputs that received data through PCI or MBUS transfer. */
	RMDemuxTaskPropertyID_IrqOutputSource = 4345,
	/** ::RMuint32, (R) @par 
		bit mask field specifying the outputs that issued the interrupt SOFT_IRQ_EVENT_FILLING based on threshold. */
	RMDemuxTaskPropertyID_IrqThresholdOutputSource = 4346,
	/** ::RMuint32, (R) @par 
		bit mask field specifying the outputs  that issued the interrupt SOFT_IRQ_EVENT_DEMUX_SECTION_END based on section complete. */
	RMDemuxTaskPropertyID_IrqSectionOutputSource = 4347,
	/** ::RMuint32, (R) @par 
		bit mask field specifying the outputs  that issued the interrupt SOFT_IRQ_EVENT_DEMUX_PES_END based on pes packet complete. */
	RMDemuxTaskPropertyID_IrqPesOutputSource = 4348,
	/** ::RMuint32, (R) @par 
		 */
	RMDemuxTaskPropertyID_SoftIrq = 1075,
	/** ::RMuint32, (R) @par 
		 */
	RMDemuxTaskPropertyID_XferSourceAddress = 1076,
	/** DemuxTask_ConnectOutput_type, (W) @par 
		 */
	RMDemuxTaskPropertyID_ConnectOutput = 1077,
	/** ::struct auxiliary_data_type1, (W) @par 
		Additional auxiliary data required by the transport demux in some custom application (not a main-stream property) */
	RMDemuxTaskPropertyID_AuxiliaryData = 4349,
	/** DemuxTask_AuxiliaryInfoValue_type, (W) @par 
		Additional auxiliary values required by the transport demux in some custom application (not a main-stream property) */
	RMDemuxTaskPropertyID_AuxiliaryInfoValue = 4350,
	/** DemuxTask_Encryption_type, (W) @par 
		per task */
	RMDemuxTaskPropertyID_Encryption = 4351,
	/** DemuxTask_PesEntry_type, (W) @par 
		PesTable[index] is set to new PesEntry parameters. */
	RMDemuxTaskPropertyID_PesEntry = 4352,
	/** DemuxTask_PesEntryInfo_in_type and DemuxTask_PesEntryInfo_out_type, (R/W Exchange) @par 
		Get PesEntry parameters from PesTable[index]. */
	RMDemuxTaskPropertyID_PesEntryInfo = 4353,
	/** ::struct EMhwlibEntryOutputMask_type, (W) @par 
		Add a new output for this PesEntry. The output should be already created and connected to demux. */
	RMDemuxTaskPropertyID_PesEntryAddOutputs = 4354,
	/** ::struct EMhwlibEntryOutputMask_type, (W) @par 
		Remove an output from this PesEntry. */
	RMDemuxTaskPropertyID_PesEntryRemoveOutputs = 4355,
	/** ::RMuint32, (R) @par 
		 */
	RMDemuxTaskPropertyID_AllocateMatchSectionEntry = 4356,
	/** ::RMuint32, (W) @par 
		 */
	RMDemuxTaskPropertyID_FreeMatchSectionEntry = 4357,
	/** DemuxTask_MatchSectionEntry_type, (W) @par 
		SectionTable[Index] is set to new SectionEntry parameters. */
	RMDemuxTaskPropertyID_MatchSectionEntry = 4358,
	/** DemuxTask_MatchSectionEntryInfo_in_type and DemuxTask_MatchSectionEntryInfo_out_type, (R/W Exchange) @par 
		Get SectionEntry parameters from SectionTable[Index]. */
	RMDemuxTaskPropertyID_MatchSectionEntryInfo = 4359,
	/** ::RMuint32, (R) @par 
		It returns the index of a free pid entry in global PidTable. This index can be use for next properties: set PidEntry, PidEntryEnable/Disable, PidEntryAdd/RemoveCipher, PidEntryAdd/RemoveOutputs */
	RMDemuxTaskPropertyID_AllocatePidEntry = 4360,
	/** ::RMuint32, (W) @par 
		 */
	RMDemuxTaskPropertyID_FreePidEntry = 4361,
	/** DemuxTask_PidEntry_type, (W) @par 
		PidTable[index] is set to new PidEntry parameters. */
	RMDemuxTaskPropertyID_PidEntry = 4362,
	/** DemuxTask_PidEntryInfo_in_type and DemuxTask_PidEntryInfo_out_type, (R/W Exchange) @par 
		Get PidEntry parameters from PidTable[index]. */
	RMDemuxTaskPropertyID_PidEntryInfo = 4363,
	/** ::RMuint32, (W) @par 
		PidTable[Index] is enabled. */
	RMDemuxTaskPropertyID_PidEntryEnable = 4364,
	/** ::RMuint32, (W) @par 
		PidTable[Index] is enabled. */
	RMDemuxTaskPropertyID_PidEntryDisable = 4365,
	/** ::struct EMhwlibEntryOutputMask_type, (W) @par 
		Add output for this PidEntry. The output should be already created and connected to demux. */
	RMDemuxTaskPropertyID_PidEntryAddOutputs = 4366,
	/** ::struct EMhwlibEntryOutputMask_type, (W) @par 
		Remove an output from this PidEntry. */
	RMDemuxTaskPropertyID_PidEntryRemoveOutputs = 4367,
	/** DemuxTask_PidEntryAddCipher_type, (W) @par 
		Add cipher for this PidEntry. The cipher should be already created. */
	RMDemuxTaskPropertyID_PidEntryAddCipher = 4368,
	/** DemuxTask_PidEntryRemoveCipher_type, (W) @par 
		Remove cipher from this PidEntry. */
	RMDemuxTaskPropertyID_PidEntryRemoveCipher = 4369,
	/** ::struct EMhwlibFixedPidEntry_type, (W) @par 
		Only PAT, pid = 0. */
	RMDemuxTaskPropertyID_PATPidEntry = 4370,
	/** ::struct EMhwlibPidEntryInfo_type, (R) @par 
		Get PATPidEntry parameters. */
	RMDemuxTaskPropertyID_PATPidEntryInfo = 4371,
	/** ::RMuint32, (W) @par 
		PAT is enabled. */
	RMDemuxTaskPropertyID_PATPidEntryEnable = 4372,
	/** ::RMuint32, (W) @par 
		PAT is enabled. */
	RMDemuxTaskPropertyID_PATPidEntryDisable = 4373,
	/** ::struct EMhwlibOutputMask_type, (W) @par 
		Add output for this PidEntry. The output should be already created and connected to demux. */
	RMDemuxTaskPropertyID_PATPidEntryAddOutputs = 4374,
	/** ::struct EMhwlibOutputMask_type, (W) @par 
		Remove an output from this PidEntry. */
	RMDemuxTaskPropertyID_PATPidEntryRemoveOutputs = 4375,
	/** ::struct EMhwlibFixedPidEntry_type, (W) @par 
		Only CAT, pid = 1. */
	RMDemuxTaskPropertyID_CATPidEntry = 4376,
	/** ::struct EMhwlibPidEntryInfo_type, (R) @par 
		Get CATPidEntry parameters. */
	RMDemuxTaskPropertyID_CATPidEntryInfo = 4377,
	/** ::RMuint32, (W) @par 
		CAT is enabled. */
	RMDemuxTaskPropertyID_CATPidEntryEnable = 4378,
	/** ::RMuint32, (W) @par 
		CAT is enabled. */
	RMDemuxTaskPropertyID_CATPidEntryDisable = 4379,
	/** ::struct EMhwlibOutputMask_type, (W) @par 
		Add output for this PidEntry. The output should be already created and connected to demux. */
	RMDemuxTaskPropertyID_CATPidEntryAddOutputs = 4380,
	/** ::struct EMhwlibOutputMask_type, (W) @par 
		Remove an output from this PidEntry. */
	RMDemuxTaskPropertyID_CATPidEntryRemoveOutputs = 4381,
	/** ::struct EMhwlibFixedPidEntry_type, (W) @par 
		Only MGT, pid = 0x1ffb. */
	RMDemuxTaskPropertyID_MGTPidEntry = 4382,
	/** ::struct EMhwlibPidEntryInfo_type, (R) @par 
		Get MGTPidEntry parameters. */
	RMDemuxTaskPropertyID_MGTPidEntryInfo = 4383,
	/** ::RMuint32, (W) @par 
		MGT is enabled. */
	RMDemuxTaskPropertyID_MGTPidEntryEnable = 4384,
	/** ::RMuint32, (W) @par 
		MGT is enabled. */
	RMDemuxTaskPropertyID_MGTPidEntryDisable = 4385,
	/** ::struct EMhwlibOutputMask_type, (W) @par 
		Add output for this PidEntry. The output should be already created and connected to demux. */
	RMDemuxTaskPropertyID_MGTPidEntryAddOutputs = 4386,
	/** ::struct EMhwlibOutputMask_type, (W) @par 
		Remove an output from this PidEntry. */
	RMDemuxTaskPropertyID_MGTPidEntryRemoveOutputs = 4387,
	/** ::struct EMhwlibPCRPidEntry_type, (W) @par 
		Only PCR. */
	RMDemuxTaskPropertyID_PCRPidEntry = 4388,
	/** ::struct EMhwlibPCRPidEntryInfo_type, (R) @par 
		Get PCRPidEntry parameters. */
	RMDemuxTaskPropertyID_PCRPidEntryInfo = 4389,
	/** ::RMuint32, (W) @par 
		PCR is enabled. */
	RMDemuxTaskPropertyID_PCRPidEntryEnable = 4390,
	/** ::RMuint32, (W) @par 
		PCR is enabled. */
	RMDemuxTaskPropertyID_PCRPidEntryDisable = 4391,
	/** ::RMuint16, (W) @par 
		Selects the PCR extraction by firmware from the specified pid value. The hardware PCR pid should be disabled.  */
	RMDemuxTaskPropertyID_PidBankPCRPid = 4392,
	/** ::enum EMhwlibTimerSync, (W) @par 
		 */
	RMDemuxTaskPropertyID_TimerSync = 4393,
	/** DemuxTask_PcrDiscontinuity_type, (W) @par 
		 */
	RMDemuxTaskPropertyID_PcrDiscontinuity = 4394,
	/** DemuxTask_OutputThreshold_type, (W) @par 
		 */
	RMDemuxTaskPropertyID_OutputThreshold = 1078,
	/** DemuxTask_OutputTimerSync_type, (W) @par 
		 */
	RMDemuxTaskPropertyID_OutputTimerSync = 1079,
	/** DemuxTask_PreprocessCipher_type, (W) @par 
		 */
	RMDemuxTaskPropertyID_PreprocessCipher = 4395,
	/** ::RMuint32, (R) @par 
		 */
	RMDemuxTaskPropertyID_AllocateCipherEntry = 4397,
	/** ::RMuint32, (W) @par 
		 */
	RMDemuxTaskPropertyID_FreeCipherEntry = 4398,
	/** DemuxTask_DESCipherEntry_type, (W) @par 
		 */
	RMDemuxTaskPropertyID_DESCipherEntry = 4399,
	/** DemuxTask_TDESCipherEntry_type, (W) @par 
		 */
	RMDemuxTaskPropertyID_TDESCipherEntry = 4400,
	/** DemuxTask_AESCipherEntry_type, (W) @par 
		 */
	RMDemuxTaskPropertyID_AESCipherEntry = 4401,
	/** DemuxTask_RC4CipherEntry_type, (W) @par 
		 */
	RMDemuxTaskPropertyID_RC4CipherEntry = 4402,
	/** DemuxTask_DVBCSACipherEntry_type, (W) @par 
		 */
	RMDemuxTaskPropertyID_DVBCSACipherEntry = 4403,
	/** DemuxTask_Multi2CipherEntry_type, (W) @par 
		 */
	RMDemuxTaskPropertyID_Multi2CipherEntry = 4404,
	/** DemuxTask_C2CipherEntry_type, (W) @par 
		 */
	RMDemuxTaskPropertyID_C2CipherEntry = 4405,
	/** DemuxTask_DVDCSSCipherEntry_type, (W) @par 
		 */
	RMDemuxTaskPropertyID_DVDCSSCipherEntry = 4406,
	/** DemuxTask_OutbandKeyChange_type, (W) @par 
		change the key index instantaneously  */
	RMDemuxTaskPropertyID_OutbandKeyChange = 4407,
	/** ::RMuint32, (R) @par 
		returns how many entries are available to write */
	RMDemuxTaskPropertyID_InbandFifoWritableSize = 4408,
	/** DemuxTask_AllocateKeyEntry_in_type and DemuxTask_AllocateKeyEntry_out_type, (R/W Exchange) @par 
		 returns a free key_index for the specified cipher  */
	RMDemuxTaskPropertyID_AllocateKeyEntry = 4409,
	/** DemuxTask_FreeKeyEntry_type, (W) @par 
		 release a key_index for the specified cipher  */
	RMDemuxTaskPropertyID_FreeKeyEntry = 4410,
	/** DemuxTask_InbandKeyChange_type, (W) @par 
		 */
	RMDemuxTaskPropertyID_InbandKeyChange = 4411,
	/** DemuxTask_DESKey_type, (W) @par 
		 */
	RMDemuxTaskPropertyID_DESKey = 4412,
	/** DemuxTask_TDESKey_type, (W) @par 
		 */
	RMDemuxTaskPropertyID_TDESKey = 4413,
	/** DemuxTask_AESKey_type, (W) @par 
		 */
	RMDemuxTaskPropertyID_AESKey = 4414,
	/** DemuxTask_RC4Key_type, (W) @par 
		 */
	RMDemuxTaskPropertyID_RC4Key = 4415,
	/** DemuxTask_DVBCSAKey_type, (W) @par 
		 */
	RMDemuxTaskPropertyID_DVBCSAKey = 4416,
	/** DemuxTask_Multi2Key_type, (W) @par 
		 */
	RMDemuxTaskPropertyID_Multi2Key = 4417,
	/** DemuxTask_C2Key_type, (W) @par 
		 */
	RMDemuxTaskPropertyID_C2Key = 4418,
	/** DemuxTask_CurrentPcrInfo_in_type and DemuxTask_CurrentPcrInfo_out_type, (R/W Exchange) @par 
		Returns the current PCR from stream and the STC at the moment when PCR was received. */
	RMDemuxTaskPropertyID_CurrentPcrInfo = 4420,
	/** DemuxTask_FirstPcrInfo_in_type and DemuxTask_FirstPcrInfo_out_type, (R/W Exchange) @par 
		Returns first PCR from stream and the STC at the moment when PCR was received. */
	RMDemuxTaskPropertyID_FirstPcrInfo = 4421,
	/** ::struct EMhwlibOutputMask_type, (W) @par 
		Allows an application to disable and clear the context of some of the DemuxTask outputs while keeping the Demux in play mode and without affecting the other outputs. */
	RMDemuxTaskPropertyID_OutputDisableCommand = 4422,
	/** ::RMuint32, (R) @par 
		 */
	RMDemuxTaskPropertyID_CSSKeyPtr = 4423,
	/** ::RMuint32, (R) @par 
		 */
	RMDemuxTaskPropertyID_C2KeyPtr = 4424,
	/** ::RMuint32, (R) @par 
		 */
	RMDemuxTaskPropertyID_C2TablePtr = 4425,
	/** ::RMuint32, (R/W) @par 
		Needed only for EM8634 to be able to play file when SPI/SSI connectors are present. */
	RMDemuxTaskPropertyID_IdleInputPort = 4426,
	/** ::RMuint32, (W) @par 
		Number of valid packets to obtain the sync lock state */
	RMDemuxTaskPropertyID_TSSyncLockCount = 4427,
	/** ::RMuint32, (R) @par 
		Number of discontinuity detected at the demux level */
	RMDemuxTaskPropertyID_DiscontinuityCounter = 4428,
	/** ::struct EMhwlibDemuxErrorInfo, (R) @par 
		 */
	RMDemuxTaskPropertyID_ErrorInfo = 4469,
	/** ::RMcss_chlgkey, (R) @par 
		implemented only for EM8622 */
	RMDemuxTaskPropertyID_CSSchlgkey1 = 6177,
	/** ::RMcss_key, (W) @par 
		implemented only for EM8622 */
	RMDemuxTaskPropertyID_CSSkey1 = 6178,
	/** ::RMcss_chlgkey, (W) @par 
		implemented only for EM8622 */
	RMDemuxTaskPropertyID_CSSchlgkey2 = 6179,
	/** ::RMcss_key, (R) @par 
		implemented only for EM8622 */
	RMDemuxTaskPropertyID_CSSkey2 = 6180,
	/** ::RMcss_disckey, (W) @par 
		implemented only for EM8622 */
	RMDemuxTaskPropertyID_CSSdisckey = 6181,
	/** ::RMcss_titlekey, (W) @par 
		implemented only for EM8622 */
	RMDemuxTaskPropertyID_CSStitlekey = 6182,
	/** DemuxTask_PidUsage_in_type and DemuxTask_PidUsage_out_type, (R/W Exchange) @par 
		 The hardware pid filter does not support multiple pid entries with same pid value. This property checks if the pid_value is used already in the hardware PidBank or in the fixed pid entries. It returns the conflict type, the count and the array with the first max. 4 pid entries in conflict. */
	RMDemuxTaskPropertyID_PidUsage = 4561,
	/** DemuxTask_FirstPcrOrPtsDetection_type, (R/W Exchange) @par 
		To be used as extension to RMDemuxTaskPropertyID_TimerSync */
	RMDemuxTaskPropertyID_FirstPcrOrPtsDetection = 4595,
	/** DemuxTask_PidEntryRecipher_type, (W) @par 
		enable or disable reciphering for this PidEntry. The cipher should be already created. A Pid that will be reciphered cannot be parsed in the same time. */
	RMDemuxTaskPropertyID_PidEntryRecipher = 4596,
	/** DemuxTask_RecipherOptions_type, (W) @par 
		 */
	RMDemuxTaskPropertyID_RecipherOptions = 4597,
	/** ::RMuint32, (R) @par 
		gbus address of bitstream fifo container. */
	RMDemuxTaskPropertyID_BtsFIFO = 4602,
};

/** Module Enum Default */
enum RMDemuxOutputPropertyID {
	/** DemuxOutput_DRAMSize_in_type and DemuxOutput_DRAMSize_out_type, (R/W Exchange) @par 
		Gets the demux DDR-DRAM memory size requirements based on input/output characteristics. */
	RMDemuxOutputPropertyID_DRAMSize = 4429,
	/** DemuxOutput_Open_type, (W) @par 
		Sets the required resources (Memory ...) for demux.@note @li The ProtectedSize and UnprotectedSize values can be obtained using the ::RMDemuxOutputPropertyID_DRAMSize exchange properties. The application has to provide the memory since it is solely responsible for the DDR-DRAM memory allocation in each DRAM controller. */
	RMDemuxOutputPropertyID_Open = 4430,
	/** DemuxOutput_DRAMSizeX_in_type and DemuxOutput_DRAMSizeX_out_type, (R/W Exchange) @par 
		Gets the demux DDR-DRAM memory size requirements based on input/output characteristics. */
	RMDemuxOutputPropertyID_DRAMSizeX = 4431,
	/** DemuxOutput_OpenX_type, (W) @par 
		Sets the required resources (Memory ...) for demux.@note @li The ProtectedSize and UnprotectedSize values can be obtained using the ::RMDemuxOutputPropertyID_DRAMSize exchange properties. The application has to provide the memory since it is solely responsible for the DDR-DRAM memory allocation in each DRAM controller. */
	RMDemuxOutputPropertyID_OpenX = 4432,
	/** ::RMuint32, (W) @par 
		Free resources (DRAM buffers...) allocated during previous call to ::RMDemuxOutputPropertyID_Open.@note @li The application should call the close property after using the decoder or before next call to ::RMDemuxPropertyID_Open. */
	RMDemuxOutputPropertyID_Close = 4433,
	/** DemuxOutput_Connect_type, (W) @par 
		It connects the output generated by demux_task_module_id with the consumer_module_id. Consumers supported are VideoDecoder, AudioDecoder and SpuDecoder. */
	RMDemuxOutputPropertyID_Connect = 4434,
	/** DemuxOutput_Disconnect_type, (W) @par 
		It disconnects the output generated by demux_task_module_id from the consumer_module_id. If demux output was opened prior to Connect the open parameters are restored. Consumers supported are VideoDecoder, AudioDecoder and SpuDecoder. */
	RMDemuxOutputPropertyID_Disconnect = 4435,
	/** ::RMuint32, (W) @par 
		 */
	RMDemuxOutputPropertyID_Enable = 4436,
	/** ::RMuint32, (W) @par 
		To make sure that the demux will not send any data it is recomended to wait for completion on a DemuxTask command. */
	RMDemuxOutputPropertyID_Disable = 4437,
	/** ::RMuint32, (W) @par 
		It resets bts, pts, inband fifo containers */
	RMDemuxOutputPropertyID_Flush = 4438,
	/** ::RMuint32, (W) @par 
		bit field mask specifying the section entry */
	RMDemuxOutputPropertyID_SectionMask = 4439,
	/** ::enum EMhwlibDataType_type, (R/W) @par 
		TS, TSpayload, PSI+section_mask, PES, payload+PTS, payload. */
	RMDemuxOutputPropertyID_DataType = 4441,
	/** ::enum DemuxOutputTrigger_type, (R/W) @par 
		 */
	RMDemuxOutputPropertyID_Trigger = 4442,
	/** ::enum EMhwlibTimerSync, (R/W) @par 
		One of None, FirstPcrOnly, Pcr. First Pcr encountered after a stop/play sequence is set in output timer. The timer is activated. */
	RMDemuxOutputPropertyID_TimerSync = 4443,
	/** DemuxOutput_Cipher_type, (R/W) @par 
		 */
	RMDemuxOutputPropertyID_Cipher = 4444,
	/** ::RMbool, (W) @par 
		Enum Default; */
	RMDemuxOutputPropertyID_EndOfStream = 1086,
	/** ::RMuint32, (R) @par 
		gbus address of bitstream fifo container. */
	RMDemuxOutputPropertyID_BtsFIFO = 4445,
	/** ::enum EMhwlibTransportPriority_type, (R/W) @par 
		enable or disable the usage of transport priority bit from TS packets */
	RMDemuxOutputPropertyID_TransportPriority = 4446,
	/** ::RMbool, (W) @par 
		enabled by default */
	RMDemuxOutputPropertyID_EnablePts = 4467,
	/** DemuxOutput_Pts45kFifoEntry_type, (R) @par 
		Enum Default; */
	RMDemuxOutputPropertyID_Pts45kFifoEntry = 4488,
	/** ::RMuint32, (R) @par 
		it retrieves the current output byte counter */
	RMDemuxOutputPropertyID_ByteCounter = 4489,
	/** ::RMbool, (W) @par 
		disabled by default. When it is enabled the trickmode info is is dumped in the output inband fifo with tag INBAND_COMMAND_TAG_TRICKMODE_TS. */
	RMDemuxOutputPropertyID_EnableTrickModeTs = 4605,
};

/** Module Enum Default */
enum RMCCFifoPropertyID {
	/** CCFifo_DRAMSize_in_type and CCFifo_DRAMSize_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMCCFifoPropertyID_DRAMSize = 4447,
	/** CCFifo_Open_type, (W) @par 
		Enum Default; */
	RMCCFifoPropertyID_Open = 4448,
	/** CCFifo_AllowedTypes_type, (R/W) @par 
		Enum Default; */
	RMCCFifoPropertyID_AllowedTypes = 4449,
	/** ::void, (W) @par 
		Enum Default; */
	RMCCFifoPropertyID_Close = 4450,
	/** ::void, (W) @par 
		Enum Default; */
	RMCCFifoPropertyID_Flush = 4451,
	/** ::void, (W) @par 
		Enum Default; */
	RMCCFifoPropertyID_Clear = 4452,
	/** ::RMbool, (W) @par 
		Enum Default; */
	RMCCFifoPropertyID_Enable = 4453,
	/** ::RMbool, (W) @par 
		Enum Default; */
	RMCCFifoPropertyID_Mute = 4454,
	/** ::RMbool, (R) @par 
		Enum Default; */
	RMCCFifoPropertyID_FifoEmpty = 4455,
	/** CCFifo_CCEntry_type, (R/W) @par 
		Enum Default; */
	RMCCFifoPropertyID_CCEntry = 4456,
	/** ::RMuint32, (R) @par 
		Enum Default; */
	RMCCFifoPropertyID_CCSurface = 4457,
};

/** Module Enum Default */
enum RMDispVideoPlanePropertyID {
	/** DispVideoPlane_Transparency_type, (R/W) @par 
		Specifies what color becomes transparent.@note The alpha plane below this plane will be visible */
	RMDispVideoPlanePropertyID_Transparency = 6161,
};

/** Converts a HD content to a SD content */
enum RMDispHDSDConverterPropertyID {
	/** DispHDSDConverter_OnTheFlyModeParameters_in_type and DispHDSDConverter_OnTheFlyModeParameters_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDispHDSDConverterPropertyID_OnTheFlyModeParameters = 6162,
	/** DispHDSDConverter_OnTheFlyModeParametersX_in_type and DispHDSDConverter_OnTheFlyModeParametersX_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDispHDSDConverterPropertyID_OnTheFlyModeParametersX = 6163,
	/** DispHDSDConverter_BufferedModeParameters_in_type and DispHDSDConverter_BufferedModeParameters_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDispHDSDConverterPropertyID_BufferedModeParameters = 6164,
	/** DispHDSDConverter_BufferedModeParametersX_in_type and DispHDSDConverter_BufferedModeParametersX_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMDispHDSDConverterPropertyID_BufferedModeParametersX = 6165,
	/** DispHDSDConverter_Open_type, (W) @par 
		Enum Default; */
	RMDispHDSDConverterPropertyID_Open = 6166,
	/** DispHDSDConverter_OpenX_type, (W) @par 
		Enum Default; */
	RMDispHDSDConverterPropertyID_OpenX = 6167,
	/** ::RMuint32, (R/W) @par 
		Enum Default; */
	RMDispHDSDConverterPropertyID_DumpedLines = 6168,
	/** ::RMuint32, (R/W) @par 
		Enum Default; */
	RMDispHDSDConverterPropertyID_DumpedPixels = 6169,
	/** ::void, (W) @par 
		Enum Default; */
	RMDispHDSDConverterPropertyID_Close = 6170,
	/** ::enum EMhwlibHDSDConversionMode, (W) @par 
		Enum Default; */
	RMDispHDSDConverterPropertyID_ConversionMode = 6171,
	/** DispHDSDConverter_ConversionBuffer_type, (R) @par 
		Enum Default; */
	RMDispHDSDConverterPropertyID_ConversionBuffer = 6172,
	/** ::enum EMhwlib422DownSamplingMode, (R/W) @par 
		 */
	RMDispHDSDConverterPropertyID_422DownSamplingMode = 6174,
	/** ::RMbool, (R/W) @par 
		Enum Default; */
	RMDispHDSDConverterPropertyID_ConstrainedOutput = 6195,
};

/** Module Enum Default */
enum RMSha1SumPropertyID {
	/** Sha1Sum_DRAMSize_in_type and Sha1Sum_DRAMSize_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMSha1SumPropertyID_DRAMSize = 4458,
	/** Sha1Sum_Open_type, (W) @par 
		Enum Default; */
	RMSha1SumPropertyID_Open = 4459,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMSha1SumPropertyID_Close = 4460,
	/** ::RMsha1Sum, (R) @par 
		Enum Default; */
	RMSha1SumPropertyID_Sum = 4461,
	/** ::void, (W) @par 
		Enum Default; */
	RMSha1SumPropertyID_Flush = 4462,
};

/** Module Enum Default */
enum RMXTaskPropertyID {
	/** ::RMuint32, (R) @par 
		Enum Default; */
	RMXTaskPropertyID_DRMTaskSize = 1087,
	/** XTask_AddDRMTask_type, (W) @par 
		Enum Default; */
	RMXTaskPropertyID_AddDRMTask = 1088,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMXTaskPropertyID_DelDRMTask = 1089,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMXTaskPropertyID_FlushDRMTask = 1090,
};

/** Module Enum Default */
enum RMTTXFifoPropertyID {
	/** TTXFifo_DRAMSize_in_type and TTXFifo_DRAMSize_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMTTXFifoPropertyID_DRAMSize = 4490,
	/** TTXFifo_Open_type, (W) @par 
		Enum Default; */
	RMTTXFifoPropertyID_Open = 4491,
	/** ::void, (W) @par 
		Enum Default; */
	RMTTXFifoPropertyID_Close = 4492,
	/** ::void, (W) @par 
		Enum Default; */
	RMTTXFifoPropertyID_Flush = 4493,
	/** ::RMbool, (W) @par 
		Enum Default; */
	RMTTXFifoPropertyID_Enable = 4494,
	/** ::struct EMhwlibTTXFifoInfo, (R) @par 
		Enum Default; */
	RMTTXFifoPropertyID_FifoInfo = 4604,
	/** ::struct EMhwlibTTXPicture, (R/W) @par 
		Enum Default; */
	RMTTXFifoPropertyID_TTXPicture = 4503,
	/** ::RMuint32, (R/W) @par 
		Enum Default; */
	RMTTXFifoPropertyID_Stc = 4496,
	/** ::RMuint32, (R/W) @par 
		Enum Default; */
	RMTTXFifoPropertyID_Mixer = 4497,
	/** ::RMuint32, (R/W) @par 
		Enum Default; */
	RMTTXFifoPropertyID_Decoder = 4498,
	/** ::RMuint32, (R) @par 
		Enum Default; */
	RMTTXFifoPropertyID_Surface = 4499,
	/** TTXFifo_TTXEntry_type, (R) @par 
		Enum Default; */
	RMTTXFifoPropertyID_TTXEntry = 4500,
};

/** Module Enum Default */
enum RMVCXOPropertyID {
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMVCXOPropertyID_ConnectClock = 4506,
	/** ::RMuint32, (W) @par 
		Enum Default; */
	RMVCXOPropertyID_DisconnectClock = 4584,
	/** ::RMuint32, (R/W) @par 
		Enum Default; */
	RMVCXOPropertyID_STC = 4573,
	/** VCXO_Speed_type, (R/W) @par 
		Enum Default; */
	RMVCXOPropertyID_Speed = 4507,
	/** ::void, (W) @par 
		Enum Default; */
	RMVCXOPropertyID_Reset = 4585,
};

/** Module Enum Default */
enum RMPPFPropertyID {
	/** ::struct EMhwlibPPFHandle, (W) @par 
		Enum Default; */
	RMPPFPropertyID_RegisterFilter = 4549,
	/** PPF_InputSurface_type, (R/W) @par 
		 */
	RMPPFPropertyID_InputSurface = 4550,
	/** PPF_OutputSurface_in_type and PPF_OutputSurface_out_type, (R/W Exchange) @par 
		 */
	RMPPFPropertyID_OutputSurface = 4551,
	/** ::struct EMhwlibMemoryBlockList, (R) @par 
		Enum Default; */
	RMPPFPropertyID_EngineMemSize = 4554,
	/** PPF_OutputSurfaceMemSize_in_type and PPF_OutputSurfaceMemSize_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMPPFPropertyID_OutputSurfaceMemSize = 4555,
	/** ::struct EMhwlibMemoryBlockList, (W) @par 
		Enum Default; */
	RMPPFPropertyID_OpenEngine = 4556,
	/** PPF_OpenOutputSurface_type, (W) @par 
		Enum Default; */
	RMPPFPropertyID_OpenOutputSurface = 4557,
	/** PPF_TriggerEvent_type, (R/W) @par 
		 */
	RMPPFPropertyID_TriggerEvent = 4552,
	/** PPF_Command_in_type and PPF_Command_out_type, (R/W Exchange) @par 
		Enum Default; */
	RMPPFPropertyID_Command = 4553,
};

enum RMGenericPropertyID {
	RMGenericPropertyID_Name = 6175,
	RMGenericPropertyID_DisableEvent = 4020,
	RMGenericPropertyID_LockMixerSourceScalingMode = 6060,
	RMGenericPropertyID_DisplayDuplicateCount = 4030,
	RMGenericPropertyID_DisplayEvent = 1039,
	RMGenericPropertyID_ForcePostProcessingDownmixing = 1093,
	RMGenericPropertyID_TransparentStrips = 6043,
	RMGenericPropertyID_ColorDegradationBoundary = 6028,
	RMGenericPropertyID_ReadBufferCompletion = 4581,
	RMGenericPropertyID_DMAPoolMatchDataFifo = 4078,
	RMGenericPropertyID_ProcessInbandCallback = 1060,
	RMGenericPropertyID_LumaKeying = 6196,
	RMGenericPropertyID_DecoderProcessInterrupt = 1022,
	RMGenericPropertyID_AudioPostProcessingInfo = 4477,
	RMGenericPropertyID_DisplaySkipCount = 4029,
	RMGenericPropertyID_AnalogTVFormat = 1047,
	RMGenericPropertyID_LineCrop = 4476,
	RMGenericPropertyID_VBIReadbackI2C = 6075,
	RMGenericPropertyID_DownScalingMode = 6040,
	RMGenericPropertyID_ScalerInputWindow = 6030,
	RMGenericPropertyID_ReadChunk256 = 4579,
	RMGenericPropertyID_ForceInterlacedBoundary = 6029,
	RMGenericPropertyID_TripleCVBS = 4475,
	RMGenericPropertyID_Alpha1 = 6016,
	RMGenericPropertyID_EnableFading = 6017,
	RMGenericPropertyID_RemoveSlaveOutput = 6097,
	RMGenericPropertyID_CurrentDisplayPTS = 6051,
	RMGenericPropertyID_Genlock = 6101,
	RMGenericPropertyID_Validate = 6010,
	RMGenericPropertyID_Enable = 6008,
	RMGenericPropertyID_SCARTWideScreen = 6106,
	RMGenericPropertyID_InbandCommandX = 4116,
	RMGenericPropertyID_1BPP_LUT = 6020,
	RMGenericPropertyID_TimingResetMaster = 6099,
	RMGenericPropertyID_BlackStripMode = 6042,
	RMGenericPropertyID_I2S_SEL = 1095,
	RMGenericPropertyID_CGMSWSS_525 = 4058,
	RMGenericPropertyID_EnableEvent = 4019,
	RMGenericPropertyID_DisconnectFromDemuxOutput = 1063,
	RMGenericPropertyID_VBICaptureANC = 6073,
	RMGenericPropertyID_DeinterlacingMode = 6054,
	RMGenericPropertyID_ComponentMode = 6102,
	RMGenericPropertyID_DisplayTimeInterval = 6037,
	RMGenericPropertyID_BackgroundColor = 6062,
	RMGenericPropertyID_AddXferFIFO = 4039,
	RMGenericPropertyID_NextPTS = 1040,
	RMGenericPropertyID_IsColorModeSupported = 6026,
	RMGenericPropertyID_CopyControl = 4535,
	RMGenericPropertyID_VBIReadbackI2CCC = 6210,
	RMGenericPropertyID_MixerSourceIndex = 6057,
	RMGenericPropertyID_SourceDisplayAspectRatio = 6052,
	RMGenericPropertyID_AnalogFrameInfo = 4533,
	RMGenericPropertyID_DigitalTVFormat = 1044,
	RMGenericPropertyID_8BPP_LUT = 6023,
	RMGenericPropertyID_IsColorSpaceSupported = 6025,
	RMGenericPropertyID_Contrast = 4026,
	RMGenericPropertyID_DRAMSizeXferFIFO = 4038,
	RMGenericPropertyID_KeyColor = 6019,
	RMGenericPropertyID_ComponentOrder = 4046,
	RMGenericPropertyID_Alpha0 = 6015,
	RMGenericPropertyID_SyncSourceModuleID = 6077,
	RMGenericPropertyID_PictureOverride = 4570,
	RMGenericPropertyID_DACEnable = 6188,
	RMGenericPropertyID_CbSaturation = 4027,
	RMGenericPropertyID_CCFifo = 6064,
	RMGenericPropertyID_Brightness = 4025,
	RMGenericPropertyID_MacroVisionLevel = 4056,
	RMGenericPropertyID_OutputCenterUp = 1094,
	RMGenericPropertyID_DACCompDisable = 4472,
	RMGenericPropertyID_TVStandard = 6068,
	RMGenericPropertyID_AddReadBuffer = 3008,
	RMGenericPropertyID_DefaultSurface = 6012,
	RMGenericPropertyID_ForceBackGround = 6063,
	RMGenericPropertyID_LUTAddress = 6024,
	RMGenericPropertyID_CurrentPictureInfo = 4583,
	RMGenericPropertyID_LastTransferredHwPts = 4582,
	RMGenericPropertyID_CutStripMode = 6044,
	RMGenericPropertyID_VBIData = 6074,
	RMGenericPropertyID_2BPP_LUT = 6021,
	RMGenericPropertyID_Stop = 6034,
	RMGenericPropertyID_LumaChromaDelay = 4474,
	RMGenericPropertyID_Threshold = 4440,
	RMGenericPropertyID_MixerSourceWindow = 6058,
	RMGenericPropertyID_Hue = 4045,
	RMGenericPropertyID_IsColorFormatSupported = 6027,
	RMGenericPropertyID_CurrentDisplayPTSAddr = 1041,
	RMGenericPropertyID_CGMSWSS_625 = 4059,
	RMGenericPropertyID_ClosedCaption = 4060,
	RMGenericPropertyID_MacroVision = 3009,
	RMGenericPropertyID_MasterClockGenerator = 6100,
	RMGenericPropertyID_AudioPostProcessingBuffer = 4478,
	RMGenericPropertyID_ScalingMode = 6039,
	RMGenericPropertyID_ColorSpace = 6061,
	RMGenericPropertyID_TVFormat = 1042,
	RMGenericPropertyID_VBICaptureRaw = 6072,
	RMGenericPropertyID_Detect = 6076,
	RMGenericPropertyID_CGMSA = 4057,
	RMGenericPropertyID_SyncOnPbPr = 6186,
	RMGenericPropertyID_InbandCommand = 4079,
	RMGenericPropertyID_XferFIFOBytesQueued = 4075,
	RMGenericPropertyID_AudioDecoderLog = 4468,
	RMGenericPropertyID_SlaveOutput = 6098,
	RMGenericPropertyID_ClearEventMask = 3004,
	RMGenericPropertyID_4BPP_LUT = 6022,
	RMGenericPropertyID_AudioDecoderStatus = 4178,
	RMGenericPropertyID_Step = 6036,
	RMGenericPropertyID_NonLinearScalingMode = 6041,
	RMGenericPropertyID_PixelClock = 1043,
	RMGenericPropertyID_AnalogFrameInfoQuery = 4546,
	RMGenericPropertyID_Surface = 6011,
	RMGenericPropertyID_ConnectToDemuxOutput = 1062,
	RMGenericPropertyID_DataFIFOInfo = 4076,
	RMGenericPropertyID_Profile = 6144,
	RMGenericPropertyID_XferFIFOInfo = 4074,
	RMGenericPropertyID_PersistentSurface = 6013,
	RMGenericPropertyID_SubPictureSurface = 6038,
	RMGenericPropertyID_CaptureDelay = 6078,
	RMGenericPropertyID_GPIOFieldID = 4036,
	RMGenericPropertyID_Flush = 6035,
	RMGenericPropertyID_ScalerFieldSelection = 6009,
	RMGenericPropertyID_SCARTConfig = 6104,
	RMGenericPropertyID_SCART = 6105,
	RMGenericPropertyID_VBIStore = 6071,
	RMGenericPropertyID_AddSlaveOutput = 6096,
	RMGenericPropertyID_DisplayAspectRatio = 6055,
	RMGenericPropertyID_DACDisable = 4473,
	RMGenericPropertyID_CompositeMode = 6103,
	RMGenericPropertyID_MixerSourceState = 6059,
	RMGenericPropertyID_EnableGammaCorrection = 6018,
	RMGenericPropertyID_TTXFifo = 6189,
	RMGenericPropertyID_KeepInvalidPicture = 4037,
	RMGenericPropertyID_CopyControlInfo = 4536,
	RMGenericPropertyID_SlaveClockGenerator = 1046,
	RMGenericPropertyID_PixelClockVCXOTimer = 6201,
	RMGenericPropertyID_CrSaturation = 4028,
};

#endif /* __EMHWLIB_PROPERTIES_1000_H__ */

/* End of generated file include/emhwlib_properties_1000.h */
