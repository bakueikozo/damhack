/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   emhwlib.h
  @brief  

  long description

  @author Emmanuel Michon
  @date   2003-05-08
*/

#ifndef __EMHWLIB_H__
#define __EMHWLIB_H__

#include "../../llad/include/gbus.h"

#include "emhwlib_versions.h"
#include "emhwlib_globaltypes.h"
#include "emhwlib_displaytypes.h"
#include "emhwlib_categories.h"
#include "emhwlib_enumerator.h"
#include "emhwlib_gfx.h"
#include "emhwlib_propertytypes.h"
#include "emhwlib_interface.h"
#include "emhwlib_shortcuts.h"

#ifdef WITH_RUAUSERMODE

#if (EM86XX_MODE==EM86XX_MODEID_STANDALONE) 
#error cannot be ruauser and standalone. Use rmcflags ruauser withhost xlu bootirq.
#endif

#ifndef WITH_IRQHANDLER_BOOTLOADER
//#error cannot be ruauser and emhwlibirq. Use rmcflags ruauser withhost xlu bootirq.
#endif

#ifndef WITH_XLOADED_UCODE
//#error cannot be ruauser and noxlu. Use rmcflags ruauser withhost xlu bootirq.
#endif

#endif

#if (EM86XX_CHIP==EM86XX_CHIPID_TANGO2) && (EM86XX_REVISION<=3)
#error ES1 shuttle now unsupported
#endif

#endif // __EMHWLIB_H__
