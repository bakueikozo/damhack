/******************************************************/
/* This file is generated automatically, DO NOT EDIT! */
/******************************************************/
/*
 * include/emhwlib_categories.h
 *
 * Copyright (c) 2001-2003 Sigma Designs, Inc. 
 * All Rights Reserved. Proprietary and Confidential.
 *
 */
 
/**
  @file include/emhwlib_categories.h
  @brief emhwlib generated file
   
  @author Jacques Mahe, Christian Wolff, Julien Soulier, Emmanuel Michon
  @ingroup hwlproperties
*/

#ifndef __EMHWLIB_CATEGORIES_H__
#define __EMHWLIB_CATEGORIES_H__

#include "emhwlib_event.h"

enum RMcategoryID {
	Enumerator = 1,
	SystemBlock = 2, 
	CPUBlock = 22, 
	XPUBlock = 52, 
	IPUBlock = 59, 
	DisplayBlock = 3, 
	DispOSDScaler = 4, 
	DispHardwareCursor = 5, 
	DispMainVideoScaler = 6, 
	DispSubPictureScaler = 7, 
	DispVCRMultiScaler = 8, 
	DispCRTMultiScaler = 9, 
	DispGFXMultiScaler = 10, 
	DispMainMixer = 12, 
	DispVCRMixer = 13, 
	DispColorBars = 14, 
	DispRouting = 15, 
	DispVideoInput = 16, 
	DispGraphicInput = 17, 
	DispDigitalOut = 18, 
	DispMainAnalogOut = 19, 
	DispComponentOut = 20, 
	DispCompositeOut = 21, 
	DemuxEngine = 23, 
	MpegEngine = 25, 
	VideoDecoder = 26, 
	AudioEngine = 27, 
	AudioDecoder = 28, 
	AudioCapture = 40, 
	VoipCodec = 55, 
	CRCDecoder = 29, 
	XCRCDecoder = 30, 
	StreamCapture = 36, 
	RawDataTransfer = 37, 
	I2C = 31, 
	GFXEngine = 32, 
	MM = 33, 
	SpuDecoder = 34, 
	PictureTransform = 58, 
	ClosedCaptionDecoder = 35, 
	RTC = 38, 
	Cipher = 41, 
	STC = 42, 
	PLL = 43, 
	DemuxCipher = 57, 
	DemuxTask = 44, 
	DemuxOutput = 45, 
	CCFifo = 46, 
	DispVideoPlane = 50, 
	DispHDSDConverter = 51, 
	Sha1Sum = 47, 
	XTask = 48, 
	TTXFifo = 53, 
	VCXO = 54, 
	PPF = 56, 
};

/**
   Returns a ModuleID from the module category and module index. Assumes the target to be 0.
   
   @param category
   @param moduleIndex
   @return 
*/
static inline RMuint32 EMHWLIB_MODULE(enum RMcategoryID category, RMuint32 moduleIndex)
{
	return ((moduleIndex & 0xff) << 8) | (category & 0xff);
}

/**
   Returns a ModuleID from the module category, the module index and a target inside the module.
   
   @param category
   @param moduleIndex
   @param target
*/
static inline RMuint32 EMHWLIB_TARGET_MODULE(enum RMcategoryID category, RMuint32 moduleIndex, RMuint32 moduleTarget)
{
	return ((moduleTarget & 0xffff) << 16) | ((moduleIndex & 0xff) << 8) | (category & 0xff);
}

/**
   Returns the module category from a ModuleID
   
   @param moduleID
   @return 
*/
static inline enum RMcategoryID EMHWLIB_MODULE_CATEGORY(RMuint32 ModuleID)
{
	return (enum RMcategoryID)(ModuleID & 0xff);
}

/**
   Returns the module index from a ModuleID
   
   @param moduleID
   @return 
*/
static inline RMuint32 EMHWLIB_MODULE_INDEX(RMuint32 ModuleID)
{
	return (ModuleID >> 8) & 0xff;
}

/**
   Returns the module target from a ModuleID
   
   @param ModuleID
*/
static inline RMuint32 EMHWLIB_MODULE_TARGET(RMuint32 ModuleID)
{
	return (ModuleID >> 16) & 0xffff;
}

/**
   Returns the display event ID from a ModuleID
   
   @param ModuleID
*/
static inline RMuint32 EMHWLIB_DISPLAY_EVENT_ID(RMuint32 ModuleID)
{
	switch (EMHWLIB_MODULE_CATEGORY(ModuleID)) {
	default:
		break;
	
	case DispMainVideoScaler:
		return VSYNC_MAIN_VIDEO_SCALER_EVENT_ID;
	case DispVCRMultiScaler:
		return VSYNC_VCR_MULTI_SCALER_EVENT_ID;
#ifdef RMFEATURE_HAS_VIDEO_PLANE
	case DispVideoPlane:
		return VSYNC_VIDEO_PLANE_EVENT_ID;
#endif
#ifdef RMFEATURE_HAS_CRT_SCALER
	case DispCRTMultiScaler:
		return VSYNC_CRT_MULTI_SCALER_EVENT_ID;
#endif
	case DispGFXMultiScaler:
		return VSYNC_GFX_MULTI_SCALER_EVENT_ID;
	case DispOSDScaler:
		return VSYNC_OSD_SCALER_EVENT_ID;
	case DispHardwareCursor:
		return VSYNC_HARDWARE_CURSOR_EVENT_ID;
	case DispSubPictureScaler:
		return VSYNC_SPU_SCALER_EVENT_ID;
	case DispMainMixer:
		return VSYNC_MAIN_MIXER_EVENT_ID;
#ifdef RMFEATURE_HAS_VCR_MIXER
	case DispVCRMixer:
		return VSYNC_VCR_MIXER_EVENT_ID;
#endif
#ifdef RMFEATURE_HAS_HDSD_CONVERTER
	case DispHDSDConverter:
		return VSYNC_HDSD_CONVERTER_EVENT_ID;
#endif
	case DispColorBars:
		return VSYNC_COLOR_BARS_EVENT_ID;
	case DispRouting:
		return VSYNC_DISPLAY_ROUTING_EVENT_ID;
	case DispVideoInput:
		return VSYNC_VIDEO_IN_EVENT_ID;
	case DispGraphicInput:
		return VSYNC_GRAPHICS_IN_EVENT_ID;
	case DispDigitalOut:
		return VSYNC_DIGITAL_OUT_EVENT_ID;
	case DispMainAnalogOut:
		return VSYNC_MAIN_ANALOG_OUT_EVENT_ID;
	case DispComponentOut:
		return VSYNC_COMPONENT_OUT_EVENT_ID;
	case DispCompositeOut:
		return VSYNC_COMPOSITE_OUT_EVENT_ID;
	}
	
	return 0;
}

/**
   Returns the display EOS ID from a ModuleID
   
   @param ModuleID
*/
static inline RMuint32 EMHWLIB_DISPLAY_INBAND_COMMAND_EVENT_ID(RMuint32 ModuleID)
{
	switch (EMHWLIB_MODULE_CATEGORY(ModuleID)) {
	default:
		break;
	
	case DispMainVideoScaler:
		return VSYNC_MAIN_VIDEO_SCALER_INBAND_COMMAND_EVENT_ID;
	case DispVCRMultiScaler:
		return VSYNC_VCR_MULTI_SCALER_INBAND_COMMAND_EVENT_ID;
#ifdef RMFEATURE_HAS_VIDEO_PLANE
	case DispVideoPlane:
		return VSYNC_VIDEO_PLANE_INBAND_COMMAND_EVENT_ID;
#endif
#ifdef RMFEATURE_HAS_CRT_SCALER
	case DispCRTMultiScaler:
		return VSYNC_CRT_MULTI_SCALER_INBAND_COMMAND_EVENT_ID;
#endif
	case DispGFXMultiScaler:
		return VSYNC_GFX_MULTI_SCALER_INBAND_COMMAND_EVENT_ID;
	case DispOSDScaler:
		return VSYNC_OSD_SCALER_INBAND_COMMAND_EVENT_ID;
	case DispSubPictureScaler:
		return VSYNC_SPU_SCALER_INBAND_COMMAND_EVENT_ID;
	}
	
	return 0;
}

/**
   Returns the new picture event ID from a ModuleID
   
   @param ModuleID
*/
static inline RMuint32 EMHWLIB_DISPLAY_NEW_PICTURE_EVENT_ID(RMuint32 ModuleID)
{
	switch (EMHWLIB_MODULE_CATEGORY(ModuleID)) {
	default:
		break;
	
	case DispMainVideoScaler:
		return VSYNC_MAIN_VIDEO_SCALER_NEW_PICTURE_EVENT_ID;
	case DispVCRMultiScaler:
		return VSYNC_VCR_MULTI_SCALER_NEW_PICTURE_EVENT_ID;
#ifdef RMFEATURE_HAS_VIDEO_PLANE
        case DispVideoPlane:
		return VSYNC_VIDEO_PLANE_NEW_PICTURE_EVENT_ID;
#endif
#ifdef RMFEATURE_HAS_CRT_SCALER
	case DispCRTMultiScaler:
		return VSYNC_CRT_MULTI_SCALER_NEW_PICTURE_EVENT_ID;
#endif
	case DispGFXMultiScaler:
		return VSYNC_GFX_MULTI_SCALER_NEW_PICTURE_EVENT_ID;
	case DispOSDScaler:
		return VSYNC_OSD_SCALER_NEW_PICTURE_EVENT_ID;
	case DispSubPictureScaler:
		return VSYNC_SPU_SCALER_NEW_PICTURE_EVENT_ID;
	}
	
	return 0;
}


#endif /* __EMHWLIB_CATEGORIES_H__ */

/* End of generated file include/emhwlib_categories.h */
