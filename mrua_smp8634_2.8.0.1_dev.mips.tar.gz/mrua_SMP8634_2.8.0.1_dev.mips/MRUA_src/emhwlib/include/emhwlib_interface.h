/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   emhwlib.h
  @brief  describes the emhwlib api

  This is the lowest layer to access the hardware. 
  It works in both usermode or kernelmode.
  There is no OS dependency.

  @author Julien Soulier
  @date   2003-05-05
*/

#ifndef __EMHWLIB_INTERFACE_H__
#define __EMHWLIB_INTERFACE_H__

#include "../../llad/include/gbus.h"

struct EMhwlib;

/**
   Returns the hardware library structure size.

   @return 
*/
RMuint32 EMhwlibGetSize(void);

/**
   Creates a hardware library with the specified gbus in the allocated
   memory space pointed by pEMhwlib.

   @param gbus 
   @param pEMhwlib
   @return RM_OK, RM_ERROR
*/
RMstatus EMhwlibCreate(struct gbus *, struct EMhwlib *pEMhwlib);

/**
   Destroys a previously created hardware library

   @param pEMhwlib      
*/
RMstatus EMhwlibDestroy(struct EMhwlib *pEMhwlib);

/**
   Sets directly the property to the module identified by ModuleID to
   the value in pValue, ValueSize is large enough.

   An asynchronous property can return with a status of RM_PENDING and
   on completion an interrupt will be raised.

   @param pEMhwlib
   @param ModuleID      
   @param PropertyID    
   @param pValue        
   @param valueSize     
   @return RM_OK, RM_ERROR, RM_PENDING
*/
RMstatus EMhwlibSetProperty(struct EMhwlib *pEMhwlib, RMuint32 ModuleID, RMuint32 PropertyID, void *pValue, RMuint32 valueSize);

/**
   Gets directly the property to the module identified by ModuleID to
   the value in pValue, ValueSize is large enough.

   An asynchronous property can return with a status of RM_PENDING and
   on completion an interrupt will be raised.

   @param pEMhwlib
   @param ModuleID      
   @param PropertyID    
   @param pValue        
   @param valueSize     
   @return RM_OK, RM_ERROR, RM_PENDING
*/
RMstatus EMhwlibGetProperty(struct EMhwlib *pEMhwlib, RMuint32 ModuleID, RMuint32 PropertyID, void *pValue, RMuint32 valueSize);


/**
   Sets and gets a property to the module identified by ModuleID.
   Sets the property to the value in pValueIn and gets the property to
   the value in pValueOut if both valueInSize and valueOutSize are
   correct.

   An asynchronous property can return with a status of RM_PENDING and
   on completion an interrupt will be raised.

   @param pEMhwlib
   @param ModuleID      
   @param PropertyID    
   @param pValueIn      
   @param valueInSize   
   @param pValueOut     
   @param valueOutSize  
   @return RM_OK, RM_ERROR, RM_PENDING
*/
RMstatus EMhwlibExchangeProperty(struct EMhwlib *pEMhwlib, RMuint32 ModuleID, RMuint32 PropertyID, void *pValueIn, RMuint32 valueInSize, void *pValueOut, RMuint32 valueOutSize);

/**
   pushes a filled buffer to a module input FIFO, returns with an
   error if there is not enough room in the FIFO, the function has to
   be called again.  Once the buffer is consumed the module raises an
   interrupt.

   @param pEMhwlib
   @param ModuleID      
   @param BufferBusAddress      
   @param BufferSize    
   @param pInfo 
   @param InfoSize      
   @param context       
   @return RM_OK, RM_ERROR, RM_FIFO_FULL
*/
RMstatus EMhwlibSendBuffer(struct EMhwlib *pEMhwlib, RMuint32 ModuleID, RMuint32 BufferBusAddress, RMuint32 BufferSize, void *pInfo, RMuint32 InfoSize, void *context);


/**
   Pops a filled buffer from a module FIFO, returns with an error if
   there is not enough data to read.

   @param pEMhwlib      
   @param ModuleID      
   @param BufferBusAddress      
   @param BufferSize    
   @param pInfo 
   @param InfoSize      
   @param context       
   @return 
*/
RMstatus EMhwlibReceiveBuffer(struct EMhwlib *pEMhwlib, RMuint32 ModuleID, RMuint32 *BufferBusAddress, RMuint32 *BufferSize, void *pInfo, RMuint32 *InfoSize, void **context);

/**
   Processes the interruption status and retrieve associated events.
   For each event calls back the caller wirh the appropriate callback.

   @param pEMhwlib      
   @param status        
   @param context
   @return 
*/
RMstatus EMhwlibProcessInterrupt(struct EMhwlib *pEMhwlib, RMuint32 status, void *context);

/**
   Called by EMhwlib (from EmhwlibProcessInterrupt) whenever a buffer has been consumed.

   @param context       
   @param bus_address   
   @return 
*/
RMstatus EMhwlibSendBufferComplete(void *context, RMuint32 bus_address);

/**
   Called by EMhwlib (from EmhwlibProcessInterrupt) whenever an event has to be signalled.

   @param context       
   @param moduleID
   @param status        
   @return 
*/
RMstatus EMhwlibEventComplete(void *context, RMuint32 moduleID, RMuint32 *status);

/**
   Called by EMhwlib (from EmhwlibProcessInterrupt) whenever a property is complete.

   @param context       
   @param ModuleID      
   @param PropertyID    
   @return 
*/
RMstatus EMhwlibPropertyComplete(void *context, RMuint32 ModuleID, RMuint32 PropertyID);

/**
   Called by EMhwlib (from EmhwlibProcessInterrupt) whenever a tag has
   reached its destination.

   @param context       
   @param ModuleID      
   @param tag   
   @return 
*/
RMstatus EMhwlibTagReceived(void *context, RMuint32 ModuleID, RMuint32 tag);

/**
   Called by EMhwlib to register a propertyID to be called on process
   exit.  This is necessary to handle application interruption (^C) or
   uncleaned applications.

   @param pEMhwlib
   @param ModuleID      
   @param PropertyID    
   @param value	
   @return 
*/
RMstatus EMhwlibRegisterCleanable(struct EMhwlib *pEMhwlib, RMuint32 ModuleID, RMuint32 PropertyID, RMuint32 value);

/**
   Called by EMhwlib to unregister a previously registered propertyID.
   A correct application should leave with no propertyID unregistered.

   @param pEMhwlib
   @param ModuleID      
   @param PropertyID    
   @param value	
   @return 
*/
RMstatus EMhwlibUnregisterCleanable(struct EMhwlib *pEMhwlib, RMuint32 ModuleID, RMuint32 PropertyID, RMuint32 value);

/**
   Called by EMhwlib to add a refcount to an address. This is used to
   prevent an application to free a pointer in used. It also allows to
   have persistent address acrross applications (for example for osd
   buffer).


   @param pEMhwlib      
   @param address       
   @return 
*/
RMstatus EMhwlibAcquireAddress(struct EMhwlib *pEMhwlib, RMuint32 address);

/**
   Called by EMhwlib to remove a refcount to an address, when this
   address is no more needed by this part of EMhwlib. When the refcount
   is equal to zero, then the area containing the address can be freed
   by the application or an emergency exit.
   
   @param pEMhwlib 
   @param address
   @return 
*/
RMstatus EMhwlibReleaseAddress(struct EMhwlib *pEMhwlib, RMuint32 address);


/**
   Execute a division between two 64 bits integers.

   @param a     
   @param b     
   @return
*/
RMuint64 EMhwlibLongLongDiv(RMuint64 a, RMuint64 b);

/**
   Execute multiplication of signed 64bit with unsigned 32bit and division by unsigned 32bit.
   Return value on 64bit.
   Note. To avoid overflow the return value should be 96 bits.

   @param a     
   @param b     
   @param c     
   @return
*/
RMint64 EMhwlibMul64x32Div32 (RMint64 a, RMuint32 b, RMuint32 c);
 
#endif // __EMHWLIB_INTERFACE_H__
