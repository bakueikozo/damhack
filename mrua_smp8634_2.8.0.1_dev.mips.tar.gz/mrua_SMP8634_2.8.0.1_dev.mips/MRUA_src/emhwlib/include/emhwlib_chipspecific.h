/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   emhwlib_chipspecific.h
  @brief  

  long description

  @author Emmanuel Michon
  @date   2004-01-23
*/

#ifndef __EMHWLIB_CHIPSPECIFIC_H__
#define __EMHWLIB_CHIPSPECIFIC_H__

#include "emhwlib_displaytypes.h"

static inline void hostsbox_loopback_channel1(struct gbus *pGBus);
static inline void hostsbox_pcislave_channel0(struct gbus *pGBus);
static inline void hostsbox_pcimaster_channel1(struct gbus *pGBus);
static inline RMuint32 pll_get_sysclk(struct gbus *pGBus);
static inline RMstatus hal_set_gpio(struct gbus *pGBus, enum GPIOId_type gpio, RMbool data);

#if (EM86XX_CHIP==EM86XX_CHIPID_MAMBOLIGHT)
#include "mambolight/emhwlib_chipspecific_mambolight.h"
#elif (EM86XX_CHIP==EM86XX_CHIPID_MAMBO)
#include "mambo/emhwlib_chipspecific_mambo.h"
#elif (EM86XX_CHIP==EM86XX_CHIPID_TANGOLIGHT)
#include "tangolight/emhwlib_chipspecific_tangolight.h"
#elif (EM86XX_CHIP==EM86XX_CHIPID_TANGO15)
#include "tango15/emhwlib_chipspecific_tango15.h"
#elif (EM86XX_CHIP==EM86XX_CHIPID_TANGO2)
#include "tango2/emhwlib_chipspecific_tango2.h"
#elif (EM86XX_CHIP==EM86XX_CHIPID_TANGO3)
#include "tango3/emhwlib_chipspecific_tango3.h"
#else
#error EM86XX_CHIP is not set in RMCFLAGS: refer to emhwlib/include/emhwlib_chips.h.
#endif

#endif // __EMHWLIB_CHIPSPECIFIC_H__
