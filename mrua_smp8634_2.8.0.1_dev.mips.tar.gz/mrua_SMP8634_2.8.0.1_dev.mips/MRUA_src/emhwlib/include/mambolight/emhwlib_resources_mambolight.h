/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   emhwlib_resources_mambolight.h
  @brief  

  long description

  @author Emmanuel Michon
  @date   2004-01-28
*/

#ifndef __EMHWLIB_RESOURCES_MAMBOLIGHT_H__
#define __EMHWLIB_RESOURCES_MAMBOLIGHT_H__

#define VSYNC_PARAM_MUTEX   ((struct gbus_mutex *)(DMEM_BASE_audio_engine_1 + 4 * audio_mutex2))
#define PCI_IRQ_MUTEX       ((struct gbus_mutex *)(DMEM_BASE_audio_engine_1 + 4 * audio_mutex3))
#define GFX_MUTEX           ((struct gbus_mutex *)(DMEM_BASE_audio_engine_1 + 4 * audio_mutex4))
#define HOST_MBUS_MUTEX     ((struct gbus_mutex *)(DMEM_BASE_audio_engine_1 + 4 * audio_mutex5))
#define SOFT_IRQ_MUTEX_TASK ((struct gbus_mutex *)(DMEM_BASE_audio_engine_1 + 4 * audio_mutex6))
#define SOFT_IRQ_MUTEX_IRQ  ((struct gbus_mutex *)(DMEM_BASE_audio_engine_1 + 4 * audio_mutex7))
#define SOFT_IRQ_MUTEX_FIQ  ((struct gbus_mutex *)(DMEM_BASE_demux_engine   + 4 * demux_mutex1))
#define RTC_IRQ_MUTEX       ((struct gbus_mutex *)(DMEM_BASE_demux_engine   + 4 * demux_mutex2))

#define AUDIO_0_IRQ_MUTEX   ((struct gbus_mutex *)(DMEM_BASE_audio_engine_0 + 4 * audio_mutex0))
#define AUDIO_1_IRQ_MUTEX   ((struct gbus_mutex *)(DMEM_BASE_audio_engine_1 + 4 * audio_mutex0))
#define VIDEO_0_FIFO_MUTEX  ((struct gbus_mutex *)(DMEM_BASE_mpeg_engine_0  + 4 * mpeg_mutex0))
#define DEMUX_IRQ_MUTEX     ((struct gbus_mutex *)(DMEM_BASE_demux_engine   + 4 * demux_mutex0))

#define AUDIO_1_RPC_MUTEX ((struct gbus_mutex *)(DMEM_BASE_audio_engine_1 + 4 * audio_mutex1))

#endif // __EMHWLIB_RESOURCES_MAMBOLIGHT_H__
