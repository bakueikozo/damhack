/*****************************************
 Copyright © 2004-2005-2006
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   emhwlib_event.h
  @brief  

  Content
  -------

  * interrupt driven communication from 86xx processors to
  main cpu

  * inband command specifications:
  - commands (aka tags)
  - flags
  - structures and unions

  It is written to be includable as is in microcode (__ASSEMBLY__).

  Revision history
  ----------------
  Feb 13th. Rewrite by e.m. complying with Thursday, February 09, 2006 meeting conclusions
  Feb 14th. Second meeting

  @author Emmanuel Michon
  @date   2006-02-13
*/

#ifndef __EMHWLIB_EVENT_H__
#define __EMHWLIB_EVENT_H__

/****************************** events */
/****************************** events */
/****************************** events */

/* these are used for status that adds information since the last call */
#define SOFT_IRQ_DIRTY_BIT_EMHWLIB      (1<<0)
#define SOFT_IRQ_DIRTY_BIT_APPLICATION  (1<<1)

/* 
   the entities that can deliver a soft irq.  

   16 origins are available in hardware.  Some of them are used by
   emhwlib and some by the OS.  One origin is shared (for inter
   communication) and it is SOFT_IRQ_ORIGIN_PT110. Refers to the notes
   below about SOFT_IRQ_ORIGIN_PT110.

   The mask of interrupts that get inside the OS is 0xf010, meaning
   that the 4 MSB bits cannot be used here, and that
   SOFT_IRQ_ORIGIN_PT110 cannot change.

   Make sure to update SOFT_IRQ_ORIGIN_MASK and SOFT_IRQ_ORIGIN_COUNT
   when modifying/adding origins below.
*/
#define SOFT_IRQ_ORIGIN_MPEG_0  (1<<0) 
#define SOFT_IRQ_ORIGIN_MPEG_1  (1<<10) /* mambo and tango2 */
#define SOFT_IRQ_ORIGIN_AUDIO_0 (1<<1) 
#define SOFT_IRQ_ORIGIN_AUDIO_1 (1<<2) 
#define SOFT_IRQ_ORIGIN_DEMUX_0 (1<<3)

/* NEVER change the the value of SOFT_IRQ_ORIGIN_PT110, because
   uClinux IRQ handler will transmit SOFT_IRQ_ORIGIN_PT110 to uClinux
   only if it matches a fixed mask.
*/
#define SOFT_IRQ_ORIGIN_PT110   (1<<4)

#define SOFT_IRQ_ORIGIN_HOST    (1<<5)

/* HACK to be removed when all microcodes generate STARVING EVENTS */
#define SOFT_IRQ_ORIGIN_MBUS    (1<<6)
#define SOFT_IRQ_ORIGIN_ERROR   (1<<7)

/* 0x4af = bits 0 1 2 3 5 7 10 */
#define SOFT_IRQ_ORIGIN_MASK	0x4af

#define SOFT_IRQ_ORIGIN_COUNT	7

/* !!! uclinux uses soft irq bits 12..15 !!! */

/* mechanism by which you get a service from xpu on tango2 (!!! same as SOFT_IRQ_ORIGIN_PT110) 

   on tango2, SOFT_IRQ_ORIGIN_PT110 is never an input of the xpu irq controller,
   but sometimes an input of the cpu irq controller (gbus_host_interrupt): no conflict
 */
#define SOFT_IRQ_XRPC           (1<<4)
#define SOFT_IRQ_IH_INSTALL     (1<<8)
#define SOFT_IRQ_IH_UNINSTALL   (1<<9)
#define SOFT_IRQ_ORIGIN_MPEG_1  (1<<10) /* tango2 */
#define SOFT_IRQ_IH_MA          (1<<11)

/* risc irq status is 16 bits wide */
#define SOFT_IRQ_RISC_EVENT_MASK 0xffff

/* events applying to all riscs (16 lower bits) */
#define SOFT_IRQ_EVENT_COMMANDCOMPLETION         (1<<0)
#define SOFT_IRQ_EVENT_STARVING                  (1<<1) /* this bit is processed by pt110, not propagated */
#define SOFT_IRQ_EVENT_ENDOFSEQUENCE             (1<<2) /* not to be mismatched with `end of file' or `end of stream', same as crc microcode */
#define SOFT_IRQ_EVENT_INBAND_COMMAND            (1<<3)
#define SOFT_IRQ_EVENT_FILLING                   (1<<4) /* this bit is processed by pt110, then propagated. */

/* audio decoder specific events*/
#define SOFT_IRQ_EVENT_AU_ERROR                  (1<<2) /* audio decoding error, error count can be retrieved by RMGenericPropertyID_AudioDecoderStatus*/
#define SOFT_IRQ_EVENT_AU_DECODED                (1<<5) /* audio decoding status, including number of channel, sample frequency, etc, can be retrieved by RMGenericPropertyID_AudioDecoderStatus*/
#define SOFT_IRQ_EVENT_PCMX_EOS                  (1<<11)

/* video decoder specific events */
#define SOFT_IRQ_EVENT_VIDEO_ERROR               (1<<6) /* the error can be retrieved using get with RMVideoDecoderPropertyID_Error*/
#define SOFT_IRQ_EVENT_USER_DATA                 (1<<11)
#define SOFT_IRQ_EVENT_VIDEO_FATAL_ERROR         (1<<12) /* the error can be retrieved using get with RMVideoDecoderPropertyID_Error*/
#define SOFT_IRQ_EVENT_VIDEO_NO_PICTURE_SIZE     (1<<13) /* size null for picture from stream */

/* hwdemux specific events */
#define SOFT_IRQ_EVENT_DEMUX_PES_END             (1<<6)
#define SOFT_IRQ_EVENT_DEMUX_SECTION_END         (1<<9)
#define SOFT_IRQ_EVENT_DEMUX_PCR_UPDATE          (1<<7)
#define SOFT_IRQ_EVENT_DEMUX_PCR_DISCONTINUITY   (1<<11)

/* voip specific events */

#define SOFT_IRQ_EVENT_VOIP_FRAME_ENCODED        (1<<6)
#define SOFT_IRQ_EVENT_VOIP_FRAME_DECODED        (1<<7)
#define SOFT_IRQ_EVENT_VOIP_DTMF_READY           (1<<8)
#define SOFT_IRQ_EVENT_VOIP_ERROR                (1<<9)

/* events non related to riscs (16 upper bits) */
#define SOFT_IRQ_EVENT_LAST_FRAME_DISPLAYED	 (1<<16)
#define SOFT_IRQ_EVENT_XFER_FIFO_READY		 (1<<17)
#define SOFT_IRQ_EVENT_COMMANDCOMPLETION_DISPLAY (1<<18)
#define SOFT_IRQ_EVENT_ERROR			 (1<<19)
#define SOFT_IRQ_EVENT_XFER_RECEIVE_READY	 (1<<20)

/* useful for the soft_irq event id */
#define VSYNC_DIGITAL_OUT_EVENT_ID       (1<<0)
#define VSYNC_MAIN_ANALOG_OUT_EVENT_ID   (1<<1)
#define VSYNC_COMPONENT_OUT_EVENT_ID     (1<<2)
#define VSYNC_COMPOSITE_OUT_EVENT_ID     (1<<3)
#define VSYNC_COLOR_BARS_EVENT_ID        (1<<4)
#define VSYNC_DISPLAY_ROUTING_EVENT_ID   (1<<5)
#define VSYNC_MAIN_MIXER_EVENT_ID        (1<<6)
#ifdef RMFEATURE_HAS_VCR_MIXER
#define VSYNC_VCR_MIXER_EVENT_ID         (1<<7)
#else
#ifdef RMFEATURE_HAS_HDSD_CONVERTER
#define VSYNC_HDSD_CONVERTER_EVENT_ID    (1<<7)
#endif
#endif
#define VSYNC_OSD_SCALER_EVENT_ID        (1<<8)
#define VSYNC_HARDWARE_CURSOR_EVENT_ID   (1<<9)
#define VSYNC_MAIN_VIDEO_SCALER_EVENT_ID (1<<10)
#define VSYNC_SPU_SCALER_EVENT_ID        (1<<11)
#define VSYNC_VCR_MULTI_SCALER_EVENT_ID  (1<<12)
#ifdef RMFEATURE_HAS_CRT_SCALER
#define VSYNC_CRT_MULTI_SCALER_EVENT_ID  (1<<13)
#else
#ifdef RMFEATURE_HAS_VIDEO_PLANE
#define VSYNC_VIDEO_PLANE_EVENT_ID       (1<<13)
#endif
#endif
#define VSYNC_GFX_MULTI_SCALER_EVENT_ID  (1<<14)
#define VSYNC_VIDEO_IN_EVENT_ID          (1<<15)
#define VSYNC_GRAPHICS_IN_EVENT_ID       (1<<16)
#define VSYNC_MAIN_VIDEO_SCALER_INBAND_COMMAND_EVENT_ID   (1<<17)
#define VSYNC_OSD_SCALER_INBAND_COMMAND_EVENT_ID          (1<<18)
#define VSYNC_SPU_SCALER_INBAND_COMMAND_EVENT_ID          (1<<19)
#define VSYNC_VCR_MULTI_SCALER_INBAND_COMMAND_EVENT_ID    (1<<20)
#ifdef RMFEATURE_HAS_CRT_SCALER
#define VSYNC_CRT_MULTI_SCALER_INBAND_COMMAND_EVENT_ID    (1<<21)
#else
#ifdef RMFEATURE_HAS_VIDEO_PLANE
#define VSYNC_VIDEO_PLANE_INBAND_COMMAND_EVENT_ID         (1<<21)
#endif
#endif
#define VSYNC_GFX_MULTI_SCALER_INBAND_COMMAND_EVENT_ID    (1<<22)
#define VSYNC_MAIN_VIDEO_SCALER_NEW_PICTURE_EVENT_ID   (1<<23)
#define VSYNC_OSD_SCALER_NEW_PICTURE_EVENT_ID          (1<<24)
#define VSYNC_SPU_SCALER_NEW_PICTURE_EVENT_ID          (1<<25)
#define VSYNC_VCR_MULTI_SCALER_NEW_PICTURE_EVENT_ID    (1<<26)
#ifdef RMFEATURE_HAS_CRT_SCALER
#define VSYNC_CRT_MULTI_SCALER_NEW_PICTURE_EVENT_ID    (1<<27)
#else
#ifdef RMFEATURE_HAS_VIDEO_PLANE
#define VSYNC_VIDEO_PLANE_NEW_PICTURE_EVENT_ID         (1<<27)
#endif
#endif
#define VSYNC_GFX_MULTI_SCALER_NEW_PICTURE_EVENT_ID    (1<<28)
#define VSYNC_MAIN_VIDEO_SCALER_NEW_SEQUENCE_EVENT_ID  (1<<29)

/****************************** in band command framework */
/****************************** in band command framework */
/****************************** in band command framework */

/*
  Tags
  associated with RUAEVENT_INBAND_COMMAND.
  User tags INBAND_COMMAND_TAG_USERx will be passed by microcodes and emhwlib to application. 
  It is the responsability of the application to read the inbands when RUAEVENT_INBAND_COMMAND
  is signalled. 
*/

#define INBAND_COMMAND_TAG_ASPECT_RATIO         0x00000001
#define INBAND_COMMAND_TAG_SCALING_MODE         0x00000002
#define INBAND_COMMAND_TAG_PANSCAN_WINDOW       0x00000003
#define INBAND_COMMAND_TAG_DISCONTINUITY        0x0000000f
#define INBAND_COMMAND_TAG_END_SEQUENCE         0x00000010
#define INBAND_COMMAND_TAG_TRICKMODE_TS         0x00000015
#define INBAND_COMMAND_TAG_EOS                  0x00000016
#define INBAND_COMMAND_TAG_AACS                 0x0000007d
#define INBAND_COMMAND_TAG_PID                  0x0000007e
#define INBAND_COMMAND_TAG_PTS_OFFSET           0x0000007f
#define INBAND_COMMAND_TAG_TITLE_KEY            0x00000080 /* deprecated - used only for css tangolight */
#define INBAND_COMMAND_TAG_ENCRYPT              0x00000081 /* deprecated - used only for aes tangolight */
#define INBAND_COMMAND_TAG_KEY_CHANGE           0x00000082 /* used by RMDemuxTaskPropertyID_InbandKeyChange, for EMhwlibScramblingBits_10, 11 case */
#define INBAND_COMMAND_TAG_PRECIPHER_KEY_CHANGE 0x00000083 /* used by RMDemuxTaskPropertyID_InbandKeyChange, for EMhwlibScramblingBits_PreCipher case */
#define INBAND_COMMAND_TAG_STOP_PRECIPHER       0x00000084 /* disables the preciher when the incoming data is in clear */

/*
  The largest possible inband. For implementation testing
 */
#define INBAND_COMMAND_TAG_DUMMY          0x000000ef

#define INBAND_COMMAND_TAG_USER0          0x000000f0
#define INBAND_COMMAND_TAG_USER1          0x000000f1
#define INBAND_COMMAND_TAG_USER2          0x000000f2
#define INBAND_COMMAND_TAG_USER3          0x000000f3
#define INBAND_COMMAND_TAG_USER4          0x000000f4
#define INBAND_COMMAND_TAG_USER5          0x000000f5
#define INBAND_COMMAND_TAG_USER6          0x000000f6
#define INBAND_COMMAND_TAG_USER7          0x000000f7
#define INBAND_COMMAND_TAG_USER8          0x000000f8
#define INBAND_COMMAND_TAG_USER9          0x000000f9
#define INBAND_COMMAND_TAG_USERa          0x000000fa
#define INBAND_COMMAND_TAG_USERb          0x000000fb
#define INBAND_COMMAND_TAG_USERc          0x000000fc
#define INBAND_COMMAND_TAG_USERd          0x000000fd
#define INBAND_COMMAND_TAG_USERe          0x000000fe
#define INBAND_COMMAND_TAG_USERf          0x000000ff

#define INBAND_COMMAND_TAG_MASK           0x000000ff /* we should create an enum of known tags */
#define INBAND_COMMAND_GET_TAG(flags_tag) ((flags_tag)&INBAND_COMMAND_TAG_MASK)

/* 
   Flags 
*/

/*
  Dest Flags are obsolete for new developments (2/13/2006)

  New way is to use outputmask where the demux outputs are numbered 0..31
*/
#define INBAND_COMMAND_DEST_SPU           (1<<8)
#define INBAND_COMMAND_DEST_AUDIO         (1<<9)
#define INBAND_COMMAND_DEST_VIDEO         (1<<10)
#define INBAND_COMMAND_DEST_DEMUX         (1<<11)

#define INBAND_COMMAND_USE_COORDINATE     (1<<13)
#define INBAND_COMMAND_ACTION_STOP        (1<<14)
#define INBAND_COMMAND_ACTION_OUTPUT_STOP (1<<15)
/* Do not raise an interrupt when processing the command */
#define INBAND_COMMAND_NOINTERRUPT        (1<<16)
/* If the flag is set the EMhwlib does not take any action as: reading the last tag,
freing the inband fifo, resume playback, handle the discontinuity.
This could create problems if the user is not fast enough in handling the inband events. */
#define INBAND_COMMAND_CONSUMED_BY_USER  (1<<17)

/* would be nice to deprecate these: they are coding default behaviors and their value is zero */
#define INBAND_COMMAND_TYPE_BYTECOUNT     0
#define INBAND_COMMAND_ACTION_CONTINUE    0
#define INBAND_COMMAND_NO_COORDINATE      0

#define LOG2_MAXINBANDCOMMANDSIZE         6
#define MAXINBANDCOMMANDSIZE              (1<<LOG2_MAXINBANDCOMMANDSIZE) /* size in bytes*/

#ifdef __ASSEMBLY__

#ifdef EM86XX_ENGINE

#ifdef RMFEATURE_IS16BITDSP

/* 16bit structures to be written */

#else /* not RMFEATURE_IS16BITDSP */

RMuint32_type dma struct {
	bytes:  dw 4 dup (?)
}

aspect_ratio_params_type dma struct {
	dummy:  struct RMuint32_type
}

dummy_params_type dma struct {
	x:      struct RMuint32_type
	y:      struct RMuint32_type
	z:      struct RMuint32_type
	test:   dw (9*Size(RMuint32_type)) dup (?)
}

trickmode_ts_params_type dma struct {
	pid:                          struct RMuint32_type /* 13 bits */
	random_access_indicator:      struct RMuint32_type /* 1 bit */
	payload_unit_start_indicator: struct RMuint32_type /* 1 bit */
}

params_type dma union {
	aspect_ratio_params:          struct aspect_ratio_params_type;
	dummy_params:                 struct dummy_params_type;
	trickmode_ts_params:          struct trickmode_ts_params_type;
}

inbandCommandX_type dma struct {
	flags_tags: struct RMuint32_type
	byte_counter: struct RMuint32_type
	output_mask: struct RMuint32_type
	opaque0: struct RMuint32_type
	params: union params_type;
}

#endif /* RMFEATURE_IS16BITDSP */

#endif /* EM86XX_ENGINE */

#else /* not __ASSEMBLY__ */

#include "emhwlib_globaltypes.h"

/*
 *	NOTE:	This structure was expanded because of problems
 *			parsing it with em8600_probe. There is a problem
 *			parsing structures within structures and unions
 *			at this time.
 */

struct pts_offset_params_type {
	RMuint64 pts_offset;
	RMuint32 time_resolution;
};

struct aacs_params {
	RMuint32 cmd;	/* Command ID */
	RMuint32 spn;	/* Source Packet Number */
	RMuint32 slot;	/* Slot number */
	RMuint32 pl;	/* PlayList ID */
	RMuint32 item;	/* PlayItem ID */
	RMuint32 dir;	/* Dir */
	RMuint32 clip;	/* Clip */
};

struct dummy_params_type {
	RMuint32 x;
	RMuint32 y;
	RMuint32 z;
	RMuint32 test[9];
};

struct trickmode_ts_params_type {
	RMuint32 pid;                          /* 13 bits */
	RMuint32 random_access_indicator;      /*  1 bit */
	RMuint32 payload_unit_start_indicator; /*  1 bit */
};

union params_type {
	struct pts_offset_params_type pts_offset_params;
	struct SurfaceAspectRatio_type aspect_ratio_params;
	enum EMhwlibScalingMode scaling_params;
	RMuint32 key_change_params;
	struct aacs_params aacs;
	struct trickmode_ts_params_type trickmode_ts_params;
	struct EMhwlibInbandPanScan panscan_params;
	struct dummy_params_type dummy_params;
};

struct InbandCommandX_type {
	RMuint32 flags_tag;    // use INBAND_COMMAND_GET_TAG()
	RMuint32 offset_value; // bytecount or...
	RMuint32 output_mask;  // Specify the set of destinations. Only for demux microcode. 
	enum EMhwlibInbandOffset offset_control; // only for the Hardware Library

	union params_type params;
};

RMmustBeEqual(sizeof(struct InbandCommandX_type),1<<LOG2_MAXINBANDCOMMANDSIZE,inbandseed)

#endif /* __ASSEMBLY__ */

#endif /* __EMHWLIB_EVENT_H__ */
