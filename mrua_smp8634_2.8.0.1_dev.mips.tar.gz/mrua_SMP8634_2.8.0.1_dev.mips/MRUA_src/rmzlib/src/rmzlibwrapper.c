/*****************************************
 Copyright � 2001-2003	
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

#define RM_LIBRARY_SELF_COMPILING 1

#define ALLOW_OS_CODE 1
#include "../include/rmzlib.h"
#include "zlib/zlib.h"

RMuint8 *RMCompressBuffer(RMuint8 *bufIn, RMuint32 sizeIn, RMuint32 *sizeOut)
{
	RMint32 err;
	RMuint8 compr[MAX_COMPRESS_SIZE], *bufOut;
	RMuint32 comprLen;

	comprLen = MAX_COMPRESS_SIZE;
	err = compress(compr, &comprLen, bufIn, sizeIn);

	if (err != Z_OK) {
		bufOut = (RMuint8 *) NULL;
		*sizeOut = 0;
	}
	else {
		bufOut = (RMuint8 *) RMMalloc(comprLen);
		RMMemcpy(bufOut, compr, comprLen);
		*sizeOut = comprLen;
	}
	
	return bufOut;
}	


RMuint8 *RMUnCompressBuffer(RMuint8 *bufIn, RMuint32 sizeIn, RMuint32 *sizeOut)
{
	RMint32 err;
	RMuint8 uncompr[MAX_COMPRESS_SIZE], *bufOut;
	RMuint32 uncomprLen;

	uncomprLen = MAX_COMPRESS_SIZE;
	err = uncompress(uncompr, &uncomprLen, bufIn, sizeIn);

	if (err != Z_OK) {
		bufOut = (RMuint8 *) NULL;
		*sizeOut = 0;
	}
	else {
		bufOut = (RMuint8 *) RMMalloc(uncomprLen);
		RMMemcpy(bufOut, uncompr, uncomprLen);
		*sizeOut = uncomprLen;
	}
	
	return bufOut;
}	
	
	
