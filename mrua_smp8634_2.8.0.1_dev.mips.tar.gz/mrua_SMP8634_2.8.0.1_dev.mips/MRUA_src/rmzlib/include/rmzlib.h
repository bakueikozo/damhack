/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/

/**
  @file rmzlib.h 
  @brief Describes the prototypes to access the
  compression/decompression based on zlib.

  @author Julien Soulier
  @date   2002-01-11
*/

#ifndef __RMZLIB_H__
#define __RMZLIB_H__

#include "../../rmdef/rmdef.h"

RM_EXTERN_C_BLOCKSTART

/** This is the maximum size for a compressed buffer in zlib */
#define MAX_COMPRESS_SIZE 8192

/**
   Compress a buffer. The compressed buffer must be shorter that MAX_COMPRESS_SIZE

   @param bufIn the decompressed buffer
   @param sizeIn the decompressed buffer size       
   @param sizeOut the compressed buffer size
   @return the compressed buffer or NULL if an error occured
*/
RM_LIBRARY_IMPORT_EXPORT RMuint8 *RMCompressBuffer(RMuint8 *bufIn, RMuint32 sizeIn, RMuint32 *sizeOut);



/**
   UnCompress a buffer. The uncompressed buffer must be shorter that MAX_COMPRESS_SIZE

   @param bufIn the compressed buffer
   @param sizeIn the compressed buffer size       
   @param sizeOut the uncompressed buffer size
   @return the uncompressed buffer or NULL if an error occured
*/
RM_LIBRARY_IMPORT_EXPORT RMuint8 *RMUnCompressBuffer(RMuint8 *bufIn, RMuint32 sizeIn, RMuint32 *sizeOut);

RM_EXTERN_C_BLOCKEND

#endif // __RMZLIB_H__
