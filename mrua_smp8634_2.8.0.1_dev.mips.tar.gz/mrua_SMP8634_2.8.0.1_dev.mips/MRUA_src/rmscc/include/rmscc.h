/*****************************************
 Copyright � 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   rmscc.h
  @brief  

  RealMAGIC Software Closed Captions Decoder

  @author Oriol Prieto Gasco
  @date   2005-06-24
*/

#ifndef __RMSCC_H__
#define __RMSCC_H__

#include "../../rmrtk/include/rmrtk.h"

typedef struct _RMscc *RMscc; ///< Handle for the RMSCC library
typedef RMstatus (*RMResizeWindow) (RMuint32 x, RMuint32 y, RMuint32 width, RMuint32 height, void *context);

enum rmscc_ccselect {    //=EMhwlibCCSelect - 1
	rmscc_not_available = 0xff,  
	rmscc_cc_1 = 0,  
	rmscc_cc_2 = 1,
	rmscc_cc_3 = 2,
	rmscc_cc_4 = 3,
	rmscc_text_1 = 4,
	rmscc_text_2 = 5,
	rmscc_text_3 = 6,
	rmscc_text_4 = 7,
};

enum rmscc_format{
	rmscc_eia_608,
	rmscc_eia_708
};

struct rmscc_init{
	RMTrtk rtk;
	enum rmscc_format format;
	enum rmscc_ccselect cc_select;
	RMResizeWindow resize_callback;
	void *resize_context;
};


RMscc RMSCCOpen(struct rmscc_init *init);

RMstatus RMSCCClose(RMscc scc);

RMstatus RMSCCReset(RMscc scc);

RMstatus RMSCCDecode(RMscc scc, RMuint8* buf, RMuint32 size, RMuint64 ustime);

enum rmscc_ccselect RMSCCGetDisplayCCType(RMscc scc);  // in case of 608

RMstatus RMSCCSetResizeCallback(RMscc scc, RMResizeWindow resize_callback, void *resize_context);

RMstatus RMSCCGetPalette(RMscc scc, RMpalette_8BPP *palette, RMuint32 *used_colors);


#endif // __RMSCC_H__
