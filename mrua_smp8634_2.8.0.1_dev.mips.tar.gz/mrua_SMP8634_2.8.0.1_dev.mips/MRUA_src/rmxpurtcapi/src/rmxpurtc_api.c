/*****************************************
 *  Copyright <A9> 2006
 *  Sigma Designs, Inc. All Rights Reserved
 *  Proprietary and Confidential
 *  *****************************************/

/**
    @file   xpurtc_interface.c
    @brief  RMDRM loader macros for the xpurtc library interface
 
    @author David Bryson
    @date   2006-05-10
*/

#define ALLOW_OS_CODE 1
#include "rmdef/rmdef.h"
#include "rmdrm/include/rmdrm.h"
#include "dynamic_drmmanager.h"
#include "rmxpurtc_api.h"
#include "rmxpurtc_version.h"

#if 1
#define XPURTCDBG ENABLE
#else
#define XPURTCDBG DISABLE
#endif


RMascii *RMDRM_INTERFACE[] = {
#undef FUNC0
#undef FUNC1
#undef FUNC2

#define FUNC0(name, return_type, return_error)          \
#name,

#define FUNC1(name, return_type, return_error)          \
#name,

#define FUNC2(name, return_type, return_error)          \
#name,

NULL
};

#if (EM86XX_MODE == EM86XX_MODEID_WITHHOST) || (EM86XX_CHIP == EM86XX_CHIPID_TANGO2)
static struct xpurtc_interface_s *xpurtc_interface;

#undef FUNC0
#undef FUNC1
#undef FUNC2

#undef FUNC
#define FUNC(name, return_error, ...)							\
if (xpurtc_interface){ 									\
	RMDBGLOG((XPURTCDBG,"got %p for " #name "\n", xpurtc_interface->name));		\
	return xpurtc_interface->name(__VA_ARGS__);					\
} else {										\
	RMDBGLOG((XPURTCDBG,"Attempting to load XPURTC...\n"));				\
	if ((xpurtc_interface = load_drm(XPURTC, XPURTC_LIBRARY_NAME))) { \
		RMDBGLOG((XPURTCDBG,"got %p for " #name "\n", xpurtc_interface->name));	\
		return xpurtc_interface->name(__VA_ARGS__);				\
	} else {									\
		RMDBGLOG((XPURTCDBG,"Cannot load XPURTC\n"));				\
		return return_error;							\
	}										\
}

#define FUNC0(name, return_type, return_error)	\
	return_type name (void){ \
		FUNC(name, return_error)\
	}

#define FUNC1(name, return_type, return_error, t1, p1)						\
	return_type name (t1 p1){							\
		FUNC(name, return_error, p1)\
	}

#define FUNC2(name, return_type, return_error, t1, p1, t2, p2)		\
	return_type name (t1 p1, t2 p2){							\
		FUNC(name, return_error, p1, p2)\
	}

#include "../include/rmxpurtc_api.inc"

#endif /* EM86XX_MODEID_WITHHOST || EM86XX_CHIPID_TANGO2 */
