#include <stdio.h>
#include "rmdef/rmdef.h"

#define ALLOW_OS_CODE 1

#include "llad/include/gbus.h"
#include "rua/include/rua.h"

#include "dynamic_drmmanager.h"


#define BUF_SIZE 10 * 1024
#define	TWO_YEARS	86400 * 365 * 2

int main(int argc, char **argv)
{
	RMuint8 *xrpc_linux = NULL;
	RMuint8 *xrpc_gbus = NULL;
	RMuint32 *time;
	struct RUA *pInstance;
	RMstatus status;

	status = RUACreateInstance(&pInstance, 0);

	if (status != RM_OK) {
		RMDBGLOG((ENABLE, "Unable to talk to RUA instance\n"));
		return -1;
	}

	RMDBGLOG((ENABLE, "Created RUA instance...\n"));

	xrpc_gbus = (RMuint8*)RUAMalloc(pInstance, 0, RUA_DRAM_UNPROTECTED, BUF_SIZE);
	RUALock(pInstance, (RMuint32)xrpc_gbus, BUF_SIZE);
	xrpc_linux = (RMuint8*)RUAMap(pInstance, (RMuint32)xrpc_gbus, BUF_SIZE);

	if ((xrpc_gbus == NULL) || (xrpc_linux == NULL)) {
		RMDBGLOG((ENABLE,"Unable to alloc memory on gbus\n"));
		return -1;
	}

	if ( RMFAILED(status = xpurtc_initialize((RMuint32*)xrpc_gbus, BUF_SIZE)) ) 	{
		RMDBGLOG((ENABLE, "Unable to initialize xpurtc xtask\n"));
		return -1;
	}
	
	time = (RMuint32*)xrpc_linux + 1024;
	xpurtc_gettime((RMuint32*)xrpc_gbus + 1024);
	printf("XPU clock time now: %ld\n", *time);

	xpurtc_isvalid();

	*time += TWO_YEARS;
	xpurtc_settime((RMuint32*)xrpc_gbus + 1024);
	printf("Set time two years in the future\n");
	
	xpurtc_gettime((RMuint32*)xrpc_gbus + 1024);
	printf("XPU clock time: %ld\n", *time);
	
	*time -= TWO_YEARS;
	xpurtc_settime((RMuint32*)xrpc_gbus + 1024);
	printf("Set time back to: %ld\n", *time);
	
	xpurtc_terminate();
	RUAUnLock(pInstance, (RMuint32)xrpc_gbus, BUF_SIZE);
	RUAUnMap(pInstance, xrpc_gbus, BUF_SIZE);
	RUAFree(pInstance, (RMuint32)xrpc_gbus);
	RUADestroyInstance(pInstance);

	return 0;
}
