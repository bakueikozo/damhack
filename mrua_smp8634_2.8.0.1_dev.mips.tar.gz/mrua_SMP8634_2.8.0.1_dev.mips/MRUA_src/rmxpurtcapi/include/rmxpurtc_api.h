/*****************************************
 *  Copyright <A9> 2006
 *  Sigma Designs, Inc. All Rights Reserved
 *  Proprietary and Confidential
 *  *****************************************/

/**
    @file   rmxpurtc_interface.h
    @brief  RMDRM loader macros for the rmxpurtc library interface
 
    @author David Bryson
    @date   2006-12-05
*/


struct xpurtc_interface_s {

#undef FUNC0
#undef FUNC1
#undef FUNC2
	
#define FUNC0(name, return_type, return_error) \
	return_type (* name)(void);

#define FUNC1(name, return_type, return_error, t1, p1) \
	return_type (* name)(t1 p1);

#define FUNC2(name, return_type, return_error, t1, p1, t2, p2) \
	return_type (* name)(t1 p1, t2 p2);

#include "rmxpurtc_api.inc"
};
