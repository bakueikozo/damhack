#ifndef __XPURTC_VERSION_H__
#define __XPURTC_VERSION_H__

#define XPURTC_LIBRARY_NAME "librmxpurtc.so"

#endif
