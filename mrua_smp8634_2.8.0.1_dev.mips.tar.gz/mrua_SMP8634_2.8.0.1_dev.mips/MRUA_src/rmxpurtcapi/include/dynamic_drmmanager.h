/* ** WARNING **
* This file is part of the secure CVS. If you need to modify it, modify it in
* the secure CVS, and then copy it in the normal CVS.
*/


#ifndef __DYNAMIC_DRMMANAGER_H__
#define __DYNAMIC_DRMMANAGER_H__

#ifdef __cplusplus
extern "C" {
#endif

RMstatus xpurtc_initialize(RMuint32 *xrpc_base_addr, RMint32 buffer_size);
RMstatus xpurtc_terminate(void);
RMstatus xpurtc_isvalid(void);
RMstatus xpurtc_gettime(RMuint32 *time);
RMstatus xpurtc_settime(RMuint32 *time);
RMstatus xpurtc_restore(void);

#ifdef __cplusplus
}
#endif

#endif /* __DYNAMIC_DRMMANAGER_H__ */

